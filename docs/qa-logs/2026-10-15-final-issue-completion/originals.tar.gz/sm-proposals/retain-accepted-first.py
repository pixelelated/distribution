import pathlib, json, hashlib, tarfile, stat, pwd, grp, decimal, datetime, io
P=pathlib.Path
O=P('/workspace/tmp/pix-m7-sm8550-reader-20261015-01')
T=P('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05')
D=P('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-sm8550-abl-format/accepted')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert not D.exists();D.mkdir()
records={}
def add(p,n):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode),(p,'not regular/directory')
 assert n not in records
 if p.is_file():assert s.st_size<=2_000_000,(p,'too large')
 records[n]={'original':str(p),'kind':'file' if p.is_file() else 'directory','bytes':s.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'uname':pwd.getpwuid(s.st_uid).pw_name,'gname':grp.getgrgid(s.st_gid).gr_name,'mtime_ns':s.st_mtime_ns}
for sub in ['', 'artifacts','acceptance','acceptance/artifacts']:
 p=O/sub;add(p,'owner'+('/'+sub if sub else ''))
 for f in sorted(p.iterdir()):
  if f.is_file():add(f,'owner/'+str(f.relative_to(O)))
stages=[]
for name,sub in [('reader',''),('acceptance','acceptance')]:
 o=O/sub;run=P((o/'run.path').read_text().strip());add(run,'runs/'+name)
 for f in sorted(run.iterdir()):
  assert f.is_file(),f;add(f,'runs/'+name+'/'+f.name)
 receipt=load(run/'admission-consumed.json');cons=load(O/(name+'-consumption.json'));runner=load(run/'runner-result.json')
 assert receipt['state']=='consumed' and receipt['original_result']==runner==cons['original_result']
 assert all(runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
 assert cons['consumed_receipt_sha256']==sha(run/'admission-consumed.json')
 assert cons['completion_evidence_sha256']==sha(o/'admission-completion-evidence.json')
 for row in load(o/'admission-completion-evidence.json')['evidence']:assert sha(P(row['path']))==row['sha256'],row
 assert load(o/'launcher-result.json')['runner_returncode']==0
 assert all((o/f).read_text().strip()=='0' for f in ['inner.rc','outer.rc','tool-wrapper.rc'])
 assert (run/'build.rc').read_text().strip()=='0'
 stages.append({'stage':name,'run':str(run),'admission_id':receipt['id'],'consumed_receipt_sha256':sha(run/'admission-consumed.json'),'original_result':runner,'launcher_returncode':0,'inner_returncode':0,'outer_returncode':0,'wrapper_returncode':0,'consumption_sha256':sha(O/(name+'-consumption.json'))})
for s in [O/'seal.json',O/'acceptance/seal.json']:
 for p,h in load(s).items():assert sha(P(p))==h,(p,h)
a=load(O/'acceptance/artifacts/acceptance.json');assert sha(O/'acceptance/artifacts/acceptance.json')=='b576f190e56c01ed534bbec593dc669c5fc034317a69ccb68af14cb568787dd0'
assert a['result']=='PASS' and a['scratch_removed'] and a['source_unchanged'] and a['independent_bundle_inodes'] and a['producer_combined_run_returncode']==1
bundle=P(a['bundle']);assert sha(bundle/'manifest.json')==a['bundle_manifest_sha256'];add(bundle,'bundle')
for f in sorted(bundle.iterdir()):
 if f.name=='manifest.json' or f.name.endswith('.identity.json') or f.name.endswith('.sha256'):add(f,'bundle/'+f.name)
fail=P('/tmp/pix-m7-sm8550-verifier-failure-20261015')
for n in ['completion-evidence.json','investigation.json','assembled-output-manifest.json']:add(fail/n,'failed-producer/'+n)
failed=T/'.build-runs/20261015T081827Z-07dceee9'
for n in ['runner-result.json','admission-consumed.json','build.rc']:add(failed/n,'failed-producer/'+n)
old=P('/workspace/tmp/pix-m7-sm8550-refresh-20261015-02')
for n in ['build.py','launcher-result.json','inner.rc','outer.rc','tool-wrapper.rc']:add(old/n,'failed-producer/owner/'+n)
assert load(failed/'runner-result.json')['command_rc']==1 and load(failed/'runner-result.json')['monitor_rc']==0 and load(failed/'runner-result.json')['runner_rc']==1
assert sha(failed/'admission-consumed.json')=='f820b116c70bd2dbbc67b873bb11d881222fb8b1c15af15505aa6a710dc0049b'
s=load(O/'acceptance/artifacts/selected-state.stdout');assert (s['status'],s['blocked_count'],s['error_count'])==('pass',0,0)
assert (O/'acceptance/artifacts/selected-state.exit').read_text().strip()=='0'
assert (O/'acceptance/artifacts/selected-state.stderr').stat().st_size==0
counts={'arm_handoffs':len(load(O/'acceptance/artifacts/arm-handoff.json')),'affected_products':len(load(O/'acceptance/artifacts/affected-products.json')['products']),'fex_files':len(load(O/'acceptance/artifacts/fex-installed.json')['files']),'abl_files':len(a['variants'][0]['bootloader_files'])}
assert counts=={'arm_handoffs':188,'affected_products':48,'fex_files':14,'abl_files':5}
archive=D/'originals.tar.gz'
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
 for name,row in sorted(records.items()):
  p=P(row['original']);ti=tar.gettarinfo(str(p),arcname=name);ti.pax_headers['mtime']=str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(1_000_000_000));ti.uname=row['uname'];ti.gname=row['gname']
  if row['kind']=='file':
   with p.open('rb') as f:tar.addfile(ti,f)
  else:tar.addfile(ti)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(records)
 for ti in tar.getmembers():
  r=records[ti.name];p=P(r['original']);s=p.lstat()
  assert (ti.mode,ti.uid,ti.gid,ti.uname,ti.gname)==(r['mode'],r['uid'],r['gid'],r['uname'],r['gname'])
  assert int(decimal.Decimal(ti.pax_headers['mtime'])*1_000_000_000)==r['mtime_ns']==s.st_mtime_ns
  if ti.isfile():assert hashlib.sha256(tar.extractfile(ti).read()).hexdigest()==r['sha256']==sha(p)
manifest={'schema':1,'scope':'Compact exact originals; firmware/cache payloads excluded, identities retained in original reader and bundle manifests','archive':'originals.tar.gz','members':records}
dump(D/'members.json',manifest)
dump(D/'outcomes.json',{'source':a['distribution_commit'],'stages':stages,'acceptance_sha256':sha(O/'acceptance/artifacts/acceptance.json'),'bundle_manifest_sha256':a['bundle_manifest_sha256'],'counts':counts,'selected_state':{k:s[k] for k in ['status','blocked_count','error_count','input_kind','mode']},'producer_result':load(failed/'runner-result.json'),'producer_scope':'Canonical make completed before post-build verifier failure; original combined producer remains 1/0/1, launcher1. No successful combined producer receipt.','artifact_identities':load(O/'artifacts/output-manifest.json')['files'],'variants':a['variants'],'scope':a['scope'],'qualification_scope':a['qualification_scope']})
dump(D/'custody-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','archive_sha256':sha(archive),'member_count':len(records),'file_count':sum(r['kind']=='file' for r in records.values()),'original_file_bytes':sum(r['bytes'] for r in records.values()),'checks':['exact archive membership and all original file bytes','mode/uid/gid/uname/gname and exact PAX nanosecond mtime','unchanged originals after archiving','both prepared source seals','both completion evidence closures','runner/launcher/inner/outer/wrapper and ordinary consumed receipt equality','accepted result, selected-state result and count readback','bundle manifest digest equals accepted bundle identity'],'limits':['No firmware/cache payload rehash or copy; accepted original readback manifests carry those identities','No runtime, target code, preparer, admission, collector or new qualification executed','No deletion or new retention clearance']})
(D/'README.md').write_text('''# SM8550 independent artifact acceptance after #602\n\nThe fresh reader and independent artifact acceptance passed and were ordinarily consumed on 2026-10-15. `outcomes.json` records exact channels, source, artifact identities and scopes; `originals.tar.gz` retains the actual prepared source, binding/resource/retention/admission metadata, reports, launcher/runner channels and consumed receipts. `members.json` maps every member to its original path and exact bytes, modes, ownership and nanosecond timestamp.\n\nReader `20261015T092225Z-e7702372` and acceptance `20261015T092333Z-2bc44656` each returned command/monitor/runner 0/0/0 and launcher/inner/outer/wrapper 0. Acceptance completed at 09:23:58 UTC, with 188 ARM handoffs, 48 affected product mappings, 14 FEX files, five ABL files, and selected-state blocked/error counts 0/0. The independent reader compared raw/update SYSTEM and KERNEL, GPT and bootloader payloads, staged/extracted products and source identities. Scratch removal, unchanged source and independent bundle inodes are retained original checks.\n\nSource is `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea`; acceptance SHA256 `b576f190e56c01ed534bbec593dc669c5fc034317a69ccb68af14cb568787dd0`; candidate bundle manifest SHA256 `09addac6d353e2a30e06610d87fa46b72a4bdfa82c711fd77a658b9e7f1d3ca0`. The exact named signed ABL is ELF32/little-endian/EM_ARM40, SHA256 `8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c`; userland architecture checks remain unchanged. Host selected-state checker SHA256 is `65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6`.\n\nThe original canonical compiler/image command completed before the post-build verifier rejected ABL. Its combined producer run `20261015T081827Z-07dceee9` remains command/monitor/runner **1/0/1**, launcher/inner/outer/wrapper **1**, ordinarily consumed failed-investigated. This archive retains the exact failed channels, evidence and control-flow source separately. No successful combined producer receipt is inferred. The fresh reader and acceptance validate existing artifacts without repeating compilation or cache copying.\n\nThe source preparation and finite root/peer reviews are separately retained in `../source/`. This directory records later actual execution. Firmware, caches and bulk prior logs are deliberately excluded; full original output/bundle manifests retain large-file identities and original paths. The custodial check rehashed compact metadata and archive members, not firmware. Original stores remain held; this is no deletion authorization.\n\nScope is SM8550 firmware artifact integrity and selected-state checks on the named inputs. It does not establish physical boot, native FEX/game behavior, device smoke, RC, publication or legal/source-coverage clearance. #528 and #601 retain their separate scopes. No new runtime was executed while preparing this custody packet.\n''')
files=sorted(f for f in D.iterdir() if f.is_file());(D/'SHA256SUMS').write_text(''.join(sha(f)+'  '+f.name+'\n' for f in files))
print(json.dumps({'destination':str(D),'seal_sha256':sha(D/'SHA256SUMS'),'archive_sha256':sha(archive),'files':len(files),'archive_members':len(records),'archive_bytes':archive.stat().st_size,'original_file_bytes':sum(r['bytes'] for r in records.values())},indent=2))

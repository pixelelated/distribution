Parent #555 / #600, M7.P5. Found during the authorized continuation: “Please keep working.”

The canonical SM8550 build at source 9aa7affee9d4 completed 737/737 packages and image creation. Its post-build verifier then rejected `usr/share/bootloader/rocknix_abl/abl_signed-SM8550.elf` because a generic userland check requires every non-Steam ELF to be ELF64/AArch64. The exact upstream signed ABL is ELF32/little-endian/EM_ARM: 258,048 bytes, SHA256 8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c. Unpacked, package and staged bytes match the already retained archive member. This is a qualification-tool defect; it does not establish a broken firmware image.

Run 20261015T081827Z-07dceee9 finished 09:00:07 UTC with original command/monitor/runner 1/0/1 and launcher/inner/outer/wrapper 1. Actual launcher, runner, watcher and observer exited; the exact container is absent. Ordinary failed-investigated consumption retains the outputs. No original result or sealed owner will be edited. Compilation and cache copying need not be replayed for a reader-only correction.

Can this be done on the VM? Yes: this is a nonexecuting host artifact-reader defect, directly testable from synthetic ELF headers and exact built payloads. Native host verification and independent raw/update/SYSTEM readback are the correct environment; no device, account, cloud, native bootloader execution or physical exception is needed. Header characterization and checksums do not prove physical boot.

Scope/depth: bounded Local Issue review of the reader correction and fresh continuation. Keep the exact known ABL identity and all five-file/source/package/SYSTEM/raw equality checks; other executable payloads retain their existing architecture guard. Preserve failed originals and do not forge a successful combined producer receipt. The completed product audit remains unchanged.

Acceptance criteria:

- [x] Retain the original failed channels and ordinary consumption, actual owner/container exit evidence, and exact upstream-member/package/staged header/hash/size/mode characterization.
- [x] Prepare a minimal named-ABL validation branch with fail-closed positive/negative header, digest and unexpected-path controls; preserve the generic userland architecture check and all existing equality checks.
- [x] Review and run a fresh read-only installed/source reader against the already assembled SM05 artifacts with fresh resources and ordinary admission; retain the failed original producer and actual new result channels separately.
- [x] Complete independent raw/update/GPT/five-ABL/FEX/selected-state acceptance and consume its actual original-zero result before dependent runtime. Record exact firmware/source hashes and reconcile #555/#600/#599/M7 with actual completion timestamps; preserve the reporting-order deviation below.
- [x] Retain the finite review, evidence and work/friction records. No recompilation, physical operation, new RC or publication clearance is inferred.

Upstream: the signed format is in the exact official ROCKNIX ABL 1.2 asset. This generic assertion is our qualification wrapper, so no upstream product patch is indicated by this finding. #601 remains the separate future OpenABL/source-intake task.


## Reporting chronology correction — October15

The original criterion combined the technical dependency with a reporting sequence:

> Complete independent raw/update/GPT/five-ABL/FEX/selected-state acceptance and consume its actual original-zero result. Record exact firmware/source hashes and update #555/#600/#599/M7 before the single Steam VM bridge and #528 inventory.

Acceptance completed09:23:58 and its ordinary consumption preceded the Steam bridge09:26:39 and inventory09:33:46. The before-runtime technical dependency was enforced by exact consumed receipts. However, the requested updates to every linked tracker were later: #555/M7 were reconciled09:44, #52809:47, and #599/#600 at this closure. That original reporting sequence was not met and is not backdated. The criterion now distinguishes accepted execution order from completed retrospective reporting. This procedural deviation is retained in the published work/friction records; no test, identity guard or product requirement was waived.


## Completed evidence

The named ABL reader correction is qualified. The exact signed payload remains 258,048 bytes, SHA256 `8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c`, ELF32/little-endian/EM_ARM40. Twelve bounded original controls passed, including wrong digest/size/device/header/unexpected path refusal. Generic userland ELF64/AArch64 and all equality guards remain unchanged; finite source/peer reviews are retained.

The accepted SM8550 artifact source is `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea`. Reader `20261015T092225Z-e7702372` and acceptance `20261015T092333Z-2bc44656` each returned command/monitor/runner 0/0/0 and launcher/inner/outer/wrapper 0, ordinarily consumed under `eb71b6e59cf84600acdc52894169118a` and `40d2d16b1a4a42e0864bf5bf881a242f`. Acceptance SHA256 is `b576f190e56c01ed534bbec593dc669c5fc034317a69ccb68af14cb568787dd0`; bundle manifest SHA256 is `09addac6d353e2a30e06610d87fa46b72a4bdfa82c711fd77a658b9e7f1d3ca0`. It verifies 188 ARM handoffs, 48 affected mappings, 14 FEX files, all five ABL files, raw/update SYSTEM and KERNEL, GPT, and selected-state blocked/error 0/0. Exact originals and source are retained under `docs/qa-logs/2026-10-15-sm8550-abl-format/{source,accepted}/`; accepted custody seal is `a1aa6782bcb80d91f2b4fde6ed4583b68fa526ec4e51fd9997ddc3f36b385594`.

Original producer `20261015T081827Z-07dceee9` remains failed-investigated with command/monitor/runner **1/0/1** and launcher/inner/outer/wrapper **1**. Canonical compilation and image creation completed before the post-build reader failed; the checked subprocess control flow and original trace support that distinction. Fresh reader and artifact-acceptance successes qualify their own stages; no successful combined producer receipt or recompilation is claimed.

Already written: these host readers wrote qualification reports and an independent candidate bundle. The format correction changed no firmware, bootloader, player settings, accounts or cloud state. Failed originals remain immutable; corrected reports use the separate fresh owner. Exact source/artifact integrity is accepted, while physical boot, native FEX/game behavior, #528 source/publication holds and #601 remain separate.

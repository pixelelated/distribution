## October15 completed-scope reconciliation

The preservation criteria are complete within their recorded portable-script VM scope. The final [packaged-script bridge originals and review](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-steam-artifact-bridge-runtime/README.md) are run `20261015T092639Z-3b69cb85`, ordinarily consumed `deaa4df35a504a23b1462bd1eb0ef048`: VM/launcher/wrapper/command/monitor/runner and export original0, one complete caller, nine named caller stages (ten helper-exit events) in their recorded order, eighteen protected roots byte/type/mode/identity-equal, normal restoration and no recorded intervention/survivor. The nested native-client exec was deliberately denied with EACCES13; its original child exit126 remains in the trace and is not a native success.

The exact124399-byte SM8550 module has SHA256 `1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b`. Accepted staged/SYSTEM equality establishes its packaging provenance; the unchanged copied module ran with installed dependencies in the isolated no-NIC GENERIC_X64 guest. GENERIC does not package that installer. Synthetic FEX/transport/archive boundaries remain explicit; no provider, account, real game/save, native ARM Steam/FEX/Proton, physical device or RC/publication claim follows.

The historical failure matrices are carried by exact unchanged embedded-helper hashes, not replaced by this single success. SM combined producer1/0/1 remains failed and consumed; its independent fresh reader/acceptance0 and this VM0 qualify separate scopes. The older GENERIC #597 unknown launcher wait remains unchanged. Broader #563/#528/#601 and physical-device work is separate.

### Criterion evidence

1. [Proton56 original controls](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-13-library-vm/results/steam-results/result.json) retain failing download/extraction and incomplete-existing inventories; the Proton row's suite0 is distinct from the enclosing original FEX failure.
2. Those controls and the [complete caller](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-13-library-vm/results/steam-routes-results/result.json) prove staged validation/activation/retirement and interruption preservation within the synthetic contract.
3. The [installed curl/Bash metadata controls](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-steam-remaining-result/README.md) add normal parse0, oversize curl63, stalled curl28 after30.005878925s, exactly four requests and preserved prior families. The production10s failure display remains. Earlier contaminated/failed controls and historical audit scores stay unchanged.
4. The [final packaged-script VM bridge](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-steam-artifact-bridge-runtime/README.md) executes the current accepted module and complete portable caller, including bounded metadata arguments, using installed GENERIC dependencies. Native Proton/Wine/Steam readiness is explicitly unclaimed.

Already written: earlier installs may already have absent or partial support/runtime-family data. These fixes preserve complete known predecessors and refuse or hold ambiguous state; they do not recreate previously deleted bytes. Games and saves stay outside cleanup ownership.

## Historical intake and dated status

The dated text below is retained history. Its former remaining-client/image statements are superseded by the completed scope above; #582 has since closed. Original source/failure evidence is not relabelled.

## Reconciled October14 status

Proton preservation candidates have passing focused synthetic controls and participate in the repaired nine-step/12-root complete-caller proof. Existing families/game/save state are covered within the fixture's declared scope. The original failures and substituted payload boundaries remain explicit in local `docs/qa-logs/2026-10-13-library-vm/README.md`.

Remaining: #582 bootstrap repair and actual payload/native/installed-image qualification before final composition. No native Proton/Steam readiness is claimed by the synthetic caller. Focused upstream candidates are retained in #585 for after the initial build.

This is a scoped readiness update under #585; all broader unproved acceptance criteria remain open. Earlier sections below retain their dated source/evidence history.

## Earlier intake and evidence history

Owner direction: "Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate."

Found during #564 / #563 source review. Existing behavior appears in accepted bc9dfe8141 and selected ROCKNIX20261001; it is not newly introduced by the runtime fix. Source evidence: docs/qa-logs/2026-10-13-steam-runtime-followup/caller-disposition.md at c41a16ad804245285914a6f5b3410f36f9abc26a. No installer or owner-device action has run.

Can this be done on the VM? Yes for replacement, failure/recovery and preservation, using synthetic roots/archives and failed transport. Native Steam usability is separate architecture-specific evidence; no account, games or saves are needed for destructive-failure controls.

`install_proton_variant` removes older variant directories before the requested version is downloaded/extracted, and treats an existing destination directory as installed without checking completeness. This occurs after runtime replacement succeeds; it is not covered by rollback of the earlier runtime transaction.

Acceptance criteria:

- [x] Exact-source synthetic controls retain original exits and manifests for failed download/extraction and incomplete existing destination.
- [x] Stage and validate the requested variant before activation or retirement; failures/interruption preserve the usable previous variant and successful replacement has a validated manifest/required payload.
- [x] Retry and space/time bounds use one owned staging area, respect distinct Proton families and preserve all game/save/client data; receipts prove cleanup scope.
- [x] Candidate-source installed VM proof and review are linked before #563 acceptance; native Proton/Steam usability is separately identified.

Same installer writer as #564 and the FEX preservation issue. No account/game/save operation is authorized by this tracking item.
Parent #555 / #344, M7.P5. Found during the authorized next-candidate qualification; owner direction: “Please keep working.” This is a new host qualification defect, not a claim that personal data was found in the firmware.

H700 acceptance062354Z-101c418b passed DDR3/DDR4 raw/update SYSTEM, kernel and bootloader equality, then returned1 when the selected-state tool returned2 for `/usr/config/ppsspp/PSP/SYSTEM/ppsspp.ini`. It reported blocked_count0 and one input-invalid error. PPSSPP defaults contain `Enable Logging = False`; the generic scalar parser rejects internal key spaces. Source inspection also found PPSSPP's actual `[Achievements]` keys `AchievementsUserName` and `AchievementsToken` missing from the generic account classifier. The existing opaque token-file check remains necessary.

The original failure is preserved and ordinary-consumed (21f58942), outputs held, all recorded owners gone. No firmware mutation or physical operation occurred. Source characterization was initially tracked on #555; this separate issue is filed before implementation/test execution so the parser/account-coverage repair has its own exit criteria.

Can this be done on the VM? Yes — the parser uses synthetic configuration fixtures and offline payload readers, without target hardware. As a host qualification-tool defect, its native host suite and read-only real firmware TAR check are the direct execution environment; no physical-device exception or live account is needed. Actual package source/defaults must be compared with upstream syntax before changing interpretation.

## Acceptance criteria

- [x] Retain pinned/upstream PPSSPP parser and account-key evidence, all shipped default-profile syntax characterization, and the original failed reader receipt; distinguish shipped default state from owner data.
- [x] Accept supported PPSSPP spaced keys in its scoped parser while other configuration formats keep their strict syntax; regression output proves all supported shipped defaults parse without ignoring unexpected lines.
- [x] Detect populated PPSSPP achievement username/token values and opaque account files; preserve conflicting-duplicate, malformed/include, recovery-sibling, privacy-output and retained-storage controls. Exact host suite and focused positive/negative fixture originals pass.
- [x] A fresh original-zero selected-state read of the exact H700 update archive passes; preserve the earlier failure, bind the corrected host tool separately from unchanged f863 product bytes, and complete fresh independent firmware acceptance. Apply the same bound checker to SM8550 qualification.
- [x] Publish the bounded host-tool delta, local Issue review and precise results; update #555/M7 and the work/friction records without rewriting the completed product audit or claiming a new RC/publication clearance.

Already written: this host checker wrote only qualification reports. It did not write player accounts, config or device/cloud state. Existing packaged defaults and retained device settings are unchanged; prior selected-state results are scoped to their exact inputs, not evidence of untested PPSSPP coverage. The correction must fail closed on populated/ambiguous PPSSPP state and preserve original failures.

Review scope: bounded Local Issue verification of a host tool, with explicit parser/privacy controls and actual artifact readback. The completed independent product audit remains sealed and unchanged; this is not an independent cross-lab review or a waiver of final release gates.


## Current proof — October15 06:40UTC

Scoped host checker65ab515e and suite6e0b2eb9 passed212 controls, including40 PPSSPP controls and all14 shipped defaults. Actual run063831Z-c75018f3 returned command/monitor/runner0 and exec0; all recorded owners exited and disposable scratch is empty. The two earlier original2 runs failed the missing-mcopy prerequisite before fixtures; neither is relabeled. The successful run used only a private mcopy link to the existing H700 host toolchain utility. Source packetab24bb4b retains pinned/upstream syntax/account evidence and lookup limits. Local finite diff review found no remaining scoped issue; no external reviewer was invoked. Fresh H700 acceptance and same explicit checker binding for SM8550 remain due; firmwaref863 and completed product audit are unchanged.


Published correction and retained local review/212-control originals:8794630e8f on next and feature. Fresh H700 acceptance064734Z-8868082e now passes selected-state (blocked0/error0) using exact checker65ab515e; all original0 consumed4ebc249f, acceptanceSHAe8107b4b. Productf863 unchanged. The actual prepared SM8550 owner now copies and hash-binds the same checker65ab515e in its acceptance inputs/seal. Its cache copy is active. The remaining criterion stays open until that bound checker runs in SM8550 artifact qualification; no SM selected-state runtime result is yet claimed. Exact8794630e8f hosted record38694615876 and wordlist38694615883/38694529353 have all passed.


## Final artifact readback — 2026-10-15 09:23 UTC

The last criterion now has actual H700 and SM8550 evidence. H700 acceptance `20261015T064734Z-8868082e` passed and was ordinarily consumed; acceptance SHA256 `e8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db` and bundle `32f7a6523dfae61b5142cf803876bf4e09f9a21a3a6784a69ca74b9d9b587833` retain unchanged f863 product identity. SM8550 acceptance `20261015T092333Z-2bc44656` passed with all original channels zero and ordinary consumption `40d2d16b1a4a42e0864bf5bf881a242f`; acceptance SHA256 `b576f190e56c01ed534bbec593dc669c5fc034317a69ccb68af14cb568787dd0`.

Both actual selected-state reports pass with blocked_count0/error_count0 and bind the identical host checker SHA256 `65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6`. The original 212 controls, all 14 defaults, 40 PPSSPP controls, finite local review and published8794630e8f evidence remain retained under `docs/qa-logs/2026-10-15-ppsspp-state-check/`; later SM originals are under `docs/qa-logs/2026-10-15-sm8550-abl-format/accepted/`.

Earlier prerequisite failures, H700 selected-state failure and combined producer failures stay unchanged. These host results neither change firmware/player data nor establish physical behavior, whole-image arbitrary-secret absence, RC or public source-coverage clearance.

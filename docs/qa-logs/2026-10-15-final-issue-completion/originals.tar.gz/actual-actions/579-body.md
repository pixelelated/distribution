## October15 completed-scope reconciliation

The preservation criteria are complete within their recorded portable-script VM scope. The final [packaged-script bridge originals and review](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-steam-artifact-bridge-runtime/README.md) are run `20261015T092639Z-3b69cb85`, ordinarily consumed `deaa4df35a504a23b1462bd1eb0ef048`: VM/launcher/wrapper/command/monitor/runner and export original0, one complete caller, nine named caller stages (ten helper-exit events) in their recorded order, eighteen protected roots byte/type/mode/identity-equal, normal restoration and no recorded intervention/survivor. The nested native-client exec was deliberately denied with EACCES13; its original child exit126 remains in the trace and is not a native success.

The exact124399-byte SM8550 module has SHA256 `1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b`. Accepted staged/SYSTEM equality establishes its packaging provenance; the unchanged copied module ran with installed dependencies in the isolated no-NIC GENERIC_X64 guest. GENERIC does not package that installer. Synthetic FEX/transport/archive boundaries remain explicit; no provider, account, real game/save, native ARM Steam/FEX/Proton, physical device or RC/publication claim follows.

The historical failure matrices are carried by exact unchanged embedded-helper hashes, not replaced by this single success. SM combined producer1/0/1 remains failed and consumed; its independent fresh reader/acceptance0 and this VM0 qualify separate scopes. The older GENERIC #597 unknown launcher wait remains unchanged. Broader #563/#528/#601 and physical-device work is separate.

### Criterion evidence

1. [Corrected FEX originals](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-13-library-vm/results/steam-corrected-results/result.json) retain failed download/extraction/overlay baselines and inventories, then43 cases plus39 guard controls with suite0. The initial aggregate/fixture failure remains preserved.
2. The same originals prove staged replacement, failure/interruption preservation and retry within the declared synthetic contract; the exact embedded FEX helper remains unchanged.
3. FEX originals and the [complete caller](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-13-library-vm/results/steam-routes-results/result.json) cover bounded space/time, owned cleanup, recovery, intended refresh and unrelated roots/games/saves.
4. The [final packaged-script VM bridge](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-steam-artifact-bridge-runtime/README.md) records actual accepted SM module bytes executing the complete portable caller using installed GENERIC dependencies. SM acceptance independently binds14 package/SYSTEM FEX identities; this is artifact identity, not native FEXRootFSFetcher or ARM overlay execution.

Already written: earlier installs may already have absent or partial support/runtime-family data. These fixes preserve complete known predecessors and refuse or hold ambiguous state; they do not recreate previously deleted bytes. Games and saves stay outside cleanup ownership.

## Historical intake and dated status

The dated text below is retained history. Its former remaining-client/image statements are superseded by the completed scope above; #582 has since closed. Original source/failure evidence is not relabelled.

Owner direction: "Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate."

Found during #564 / #563 source review. Existing behavior appears in accepted bc9dfe8141 and selected ROCKNIX20261001; it is not newly introduced by the runtime fix. Source evidence: docs/qa-logs/2026-10-13-steam-runtime-followup/caller-disposition.md at c41a16ad804245285914a6f5b3410f36f9abc26a. No installer or owner-device action has run.

Can this be done on the VM? Yes for replacement, failure/recovery and preservation, using synthetic roots/archives and failed transport. Native Steam usability is separate architecture-specific evidence; no account, games or saves are needed for destructive-failure controls.

`ensure_fex_rootfs` removes ArchLinux* before FEXRootFSFetcher succeeds, on the normal installer path before the runtime replacement. A failed fetch can remove the existing support environment. Installed config copying and overlay files also need an explicit preservation boundary.

Acceptance criteria:

- [x] Exact-source synthetic failing control records original exits and before/after manifests for failed download/extraction or missing required overlay; distinguish source reasoning from executed reproduction.
- [x] Staged validated replacement preserves the prior complete environment and required files on download, extraction, validation, activation and interruption failure; manifests and retry receipts prove it.
- [x] Space/time bounds, owned cleanup and recovery are verified without touching Steam games/saves or unrelated FEX roots. Existing intended RootFS refresh remains supported.
- [x] Candidate-source installed VM proof and review are linked before #563 acceptance; native execution limits are explicit.

Depends on source coordination with #564; same installer file has one writer. This is a separate transaction from the ARM64 Steam runtime, not covered by its component fixtures.
## October15 completed-scope reconciliation

The preservation criteria are complete within their recorded portable-script VM scope. The final [packaged-script bridge originals and review](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-steam-artifact-bridge-runtime/README.md) are run `20261015T092639Z-3b69cb85`, ordinarily consumed `deaa4df35a504a23b1462bd1eb0ef048`: VM/launcher/wrapper/command/monitor/runner and export original0, one complete caller, nine named caller stages (ten helper-exit events) in their recorded order, eighteen protected roots byte/type/mode/identity-equal, normal restoration and no recorded intervention/survivor. The nested native-client exec was deliberately denied with EACCES13; its original child exit126 remains in the trace and is not a native success.

The exact124399-byte SM8550 module has SHA256 `1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b`. Accepted staged/SYSTEM equality establishes its packaging provenance; the unchanged copied module ran with installed dependencies in the isolated no-NIC GENERIC_X64 guest. GENERIC does not package that installer. Synthetic FEX/transport/archive boundaries remain explicit; no provider, account, real game/save, native ARM Steam/FEX/Proton, physical device or RC/publication claim follows.

The historical failure matrices are carried by exact unchanged embedded-helper hashes, not replaced by this single success. SM combined producer1/0/1 remains failed and consumed; its independent fresh reader/acceptance0 and this VM0 qualify separate scopes. The older GENERIC #597 unknown launcher wait remains unchanged. Broader #563/#528/#601 and physical-device work is separate.

### Criterion evidence

1. [The source-bound failure control](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-12-upstream-adoption/steam-failure-control.json) retains original1 for both versions: accepted predecessor preserves old runtime; selected stable source loses it after download failure.
2. [Runtime39 original controls](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-13-library-vm/results/steam-results/result.json) pass staging/failure/activation preservation within the synthetic contract; their parent aggregate remains FAIL because of its separate FEX fixture failure.
3. Those controls and the [nine-step complete caller](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-13-library-vm/results/steam-routes-results/result.json) establish bounded interruption/retry/space handling and unrelated-root preservation. Original negative exits remain negative.
4. The [final packaged-script VM bridge](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-steam-artifact-bridge-runtime/README.md) connects accepted SM module1694f7a9 to actual installed GENERIC dependencies. The [isolated runtime invocation controls](https://github.com/pixelelated/distribution/blob/next/docs/audits/2026_10_14-milestone-m7-next-candidate/source-controls02-readback.md) retain old1/corrected0. This is the new-source portable-script VM proof; no presentation change was selected, and the original installer call flow remains explicit.

## Historical intake and dated status

The dated text below is retained history. Its former remaining-client/image statements are superseded by the completed scope above; #582 has since closed. Original source/failure evidence is not relabelled.

## Reconciled October14 status

Runtime replacement preservation has a prepared repair and synthetic component/full-caller evidence in the library VM packet; the preserved original failure is not the only result anymore. The combined repaired caller passes all nine staged steps and12 preservation roots, with its synthetic payload/fetch boundaries recorded.

Remaining: #582 client-bootstrap implementation and contract decisions, relevant real-payload/native/installed-image qualification and final composition before #563 promotion. Do not treat a synthetic successful installer as native Steam readiness. Upstream repair preparation is tracked in #585 and submissions wait for the initial build.

This is a scoped readiness update under #585; all broader unproved acceptance criteria remain open. Earlier sections below retain their dated source/evidence history.

## Earlier intake and evidence history

## Found during #563 upstream intake

Owner direction: "I feel like our foundation for this build, since it's coming in October, should be the ROCKNIX 20261001 build."

The selected stable release imports51bebf5e1d's Steam runtime refresh. Its `install_steam_runtime_arm64` removes the existing runtime directory before `wget` and archive extraction succeed. A failed download can therefore remove the previously working runtime. This reproduced regression must be repaired before the new foundation's candidate build is accepted. Games and saves are outside this runtime path; do not broaden cleanup scope.

Already written: accepted bc9dfe8141 uses the earlier installer without that new pre-download removal; the new code is currently only on #563's isolated integration branch. No owner installer run or device mutation has been performed.

Can this be done on the VM? Yes: synthetic old-runtime markers, fake transport failures and disposable archives exercise the exact installer function without Steam accounts or a device. Start with adapted host controls for the source function; those are not an installed-image VM claim. Then qualify the repaired shipped script on the new VM.

## Acceptance criteria

- [x] A source-bound failing control shows the new function loses the prior runtime on download failure while the accepted predecessor preserves it.
- [x] A staged replacement preserves the complete working runtime and library links on download, extraction, validation and activation failure; successful replacement retires superseded runtime only after the new one is usable. Original return codes and before/after manifests prove each case.
- [x] Interruption/retry recovery and available-space handling are bounded, and saves/games outside the runtime are unchanged in VM fixtures.
- [x] New-source installed VM proof and review are recorded before #563's changed image is accepted. User-facing flow/copy evidence is updated if presentation changes.

Parent #563; M7.P5 source-repair step before new-image qualification. This issue does not authorize device actions or an upstream message.

## Adapted host control — 2026-10-12

Exact-function controls with synthetic runtime marker and wget returning9: accepted bc9dfe8141 returns1 and preserves the runtime; stable20261001 returns1 and removes it. `docs/qa-logs/2026-10-12-upstream-adoption/steam-failure-control.json` retains source/function hashes and outcomes. No account, network or device is used. This is host reproduction, not installed VM acceptance. The source remains only on #563 qualification branch; no product repair yet.

[Published failure-control evidence](https://github.com/pixelelated/distribution/blob/03660cbfb8acabec039c5e4b2b43d49dc4112fc9/docs/qa-logs/2026-10-12-upstream-adoption/steam-failure-control.json).

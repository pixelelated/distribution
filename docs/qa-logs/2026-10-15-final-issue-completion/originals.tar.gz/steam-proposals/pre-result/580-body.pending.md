## October15 reconciliation proposal — final VM evidence pending

Criteria1–3 below are supported within the recorded synthetic preservation/bounds scope. Criterion4 remains unchecked until the actual packaged-script VM export and ordinary consumption are reviewed. No completion or native ARM Steam readiness is asserted here. The earlier dated sections remain historical.

## Reconciled October14 status

Proton preservation candidates have passing focused synthetic controls and participate in the repaired nine-step/12-root complete-caller proof. Existing families/game/save state are covered within the fixture's declared scope. The original failures and substituted payload boundaries remain explicit in local `docs/qa-logs/2026-10-13-library-vm/README.md`.

Remaining: #582 bootstrap repair and actual payload/native/installed-image qualification before final composition. No native Proton/Steam readiness is claimed by the synthetic caller. Focused upstream candidates are retained in #585 for after the initial build.

This is a scoped readiness update under #585; all broader unproved acceptance criteria remain open. Earlier sections below retain their dated source/evidence history.

## Earlier intake and evidence history

Owner direction: "Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate."

Found during #564 / #563 source review. Existing behavior appears in accepted bc9dfe8141 and selected ROCKNIX20261001; it is not newly introduced by the runtime fix. Source evidence: docs/qa-logs/2026-10-13-steam-runtime-followup/caller-disposition.md at c41a16ad804245285914a6f5b3410f36f9abc26a. No installer or owner-device action has run.

Can this be done on the VM? Yes for replacement, failure/recovery and preservation, using synthetic roots/archives and failed transport. Native Steam usability is separate architecture-specific evidence; no account, games or saves are needed for destructive-failure controls.

`install_proton_variant` removes older variant directories before the requested version is downloaded/extracted, and treats an existing destination directory as installed without checking completeness. This occurs after runtime replacement succeeds; it is not covered by rollback of the earlier runtime transaction.

Acceptance criteria:

- [x] Exact-source synthetic controls retain original exits and manifests for failed download/extraction and incomplete existing destination.
- [x] Stage and validate the requested variant before activation or retirement; failures/interruption preserve the usable previous variant and successful replacement has a validated manifest/required payload.
- [x] Retry and space/time bounds use one owned staging area, respect distinct Proton families and preserve all game/save/client data; receipts prove cleanup scope.
- [ ] Candidate-source installed VM proof and review are linked before #563 acceptance; native Proton/Steam usability is separately identified.

Same installer writer as #564 and the FEX preservation issue. No account/game/save operation is authorized by this tracking item.

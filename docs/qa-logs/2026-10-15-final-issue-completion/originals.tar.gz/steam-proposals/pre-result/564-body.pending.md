## October15 reconciliation proposal — final VM evidence pending

Criteria1–3 below are supported within the recorded synthetic preservation/bounds scope. Criterion4 remains unchecked until the actual packaged-script VM export and ordinary consumption are reviewed. No completion or native ARM Steam readiness is asserted here. The earlier dated sections remain historical.

## Reconciled October14 status

Runtime replacement preservation has a prepared repair and synthetic component/full-caller evidence in the library VM packet; the preserved original failure is not the only result anymore. The combined repaired caller passes all nine staged steps and12 preservation roots, with its synthetic payload/fetch boundaries recorded.

Remaining: #582 client-bootstrap implementation and contract decisions, relevant real-payload/native/installed-image qualification and final composition before #563 promotion. Do not treat a synthetic successful installer as native Steam readiness. Upstream repair preparation is tracked in #585 and submissions wait for the initial build.

This is a scoped readiness update under #585; all broader unproved acceptance criteria remain open. Earlier sections below retain their dated source/evidence history.

## Earlier intake and evidence history

## Found during #563 upstream intake

Owner direction: "I feel like our foundation for this build, since it's coming in October, should be the ROCKNIX 20261001 build."

The selected stable release imports51bebf5e1d's Steam runtime refresh. Its `install_steam_runtime_arm64` removes the existing runtime directory before `wget` and archive extraction succeed. A failed download can therefore remove the previously working runtime. This reproduced regression must be repaired before the new foundation's candidate build is accepted. Games and saves are outside this runtime path; do not broaden cleanup scope.

Already written: accepted bc9dfe8141 uses the earlier installer without that new pre-download removal; the new code is currently only on #563's isolated integration branch. No owner installer run or device mutation has been performed.

Can this be done on the VM? Yes: synthetic old-runtime markers, fake transport failures and disposable archives exercise the exact installer function without Steam accounts or a device. Start with adapted host controls for the source function; those are not an installed-image VM claim. Then qualify the repaired shipped script on the new VM.

## Acceptance criteria

- [x] A source-bound failing control shows the new function loses the prior runtime on download failure while the accepted predecessor preserves it.
- [x] A staged replacement preserves the complete working runtime and library links on download, extraction, validation and activation failure; successful replacement retires superseded runtime only after the new one is usable. Original return codes and before/after manifests prove each case.
- [x] Interruption/retry recovery and available-space handling are bounded, and saves/games outside the runtime are unchanged in VM fixtures.
- [ ] New-source installed VM proof and review are recorded before #563's changed image is accepted. User-facing flow/copy evidence is updated if presentation changes.

Parent #563; M7.P5 source-repair step before new-image qualification. This issue does not authorize device actions or an upstream message.

## Adapted host control — 2026-10-12

Exact-function controls with synthetic runtime marker and wget returning9: accepted bc9dfe8141 returns1 and preserves the runtime; stable20261001 returns1 and removes it. `docs/qa-logs/2026-10-12-upstream-adoption/steam-failure-control.json` retains source/function hashes and outcomes. No account, network or device is used. This is host reproduction, not installed VM acceptance. The source remains only on #563 qualification branch; no product repair yet.

[Published failure-control evidence](https://github.com/pixelelated/distribution/blob/03660cbfb8acabec039c5e4b2b43d49dc4112fc9/docs/qa-logs/2026-10-12-upstream-adoption/steam-failure-control.json).

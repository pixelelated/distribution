#!/usr/bin/env python3
"""Prepare one source-bound owner after final readback; launches no process family."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
CASE_SEAL='0ad09832537aaaf3035194c062cb0edff216c27ae309755f29ad9105a046f67f'
COMMIT='d6a87f05c1935516115b2cca1af22151a0209224'
def sha(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def seal(root,expected=None):
    if expected:assert sha(root/'SHA256SUMS')==expected
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1);assert not Path(name).is_absolute() and '..' not in Path(name).parts and sha(root/name)==digest
p=argparse.ArgumentParser()
for name in ['checkout','verification','case-packet','owner']:p.add_argument('--'+name,type=Path,required=True)
p.add_argument('--vnc',type=int,required=True)
a=p.parse_args();tree=a.checkout.resolve(strict=True);verify=a.verification.resolve(strict=True);case=a.case_packet.resolve(strict=True);out=a.owner.absolute()
assert out.parent==Path('/workspace/tmp') and re.fullmatch('pix[A-Za-z0-9_-]+',out.name) and not out.exists() and 100<=a.vnc<=199
assert subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True).strip()==COMMIT
assert not subprocess.check_output(['git','-C',str(tree),'status','--porcelain'],text=True).strip()
seal(HERE);seal(case,CASE_SEAL)
v=json.loads((verify/'result.json').read_text());i=json.loads((verify/'inputs.json').read_text())
assert v['status']=='PASS' and v['source']==i['source']==COMMIT and v['es_commit']==i['es_commit']
images=[(Path(k),row) for k,row in i['artifacts'].items() if k.endswith('.img.gz')];assert len(images)==1
image,row=images[0];assert image.is_file() and not image.is_symlink() and image.stat().st_size==row['bytes']
helper=Path('/workspace/repos/rocknix.worktrees/m7-offline-vm-567/projects/ROCKNIX/devices/GENERIC_X64/vm/generic-x64-vm')
assert sha(helper)=='5b058ed8a8b11135cd5997e3d925939baff30726033125acf1244863a756318d'
inputs=json.loads((case/'inputs.json').read_text())
for r in inputs['staged'].values():
    f=Path(r['source']);assert f.is_file() and not f.is_symlink() and f.stat().st_size==r['bytes']
out.mkdir(mode=0o700)
for name in ['records','scan','logs','vm','source','lifecycle-owner']:(out/name).mkdir()
for name in ['vm-lifecycle.py','close.py','census.py']:shutil.copy2(HERE/name,out/name)
shutil.copytree(case,out/'source/case')
(out/'source/owner').mkdir()
for name in ['guest-owner.py','guest-manifest.py','census.py']:shutil.copy2(HERE/name,out/'source/owner'/name)
shutil.copy2(verify/'result.json',out/'records/final-image-result.json');shutil.copy2(verify/'inputs.json',out/'records/final-image-inputs.json')
binding={'case_seal':CASE_SEAL,'verification_sha256':sha(verify/'result.json'),
         'owner_files':{name:sha(out/'source/owner'/name) for name in ['guest-owner.py','guest-manifest.py','census.py']}}
write(out/'source/owner/binding.json',binding)
tools=[helper,helper.parent/'profile.json']+[tree/name for name in ['tools/vm-serial','tools/vm-stop','tools/watch-build','tools/watch-job','tools/watch-build-submit']]
config={'checkout':str(tree),'commit':COMMIT,'es_commit':v['es_commit'],'vnc':a.vnc,'helper':str(helper),
 'image':{'path':str(image),**row},'system':v['payload']['SYSTEM'],'verification_sha256':sha(verify/'result.json'),
 'verification_inputs_sha256':sha(verify/'inputs.json'),'case_seal':CASE_SEAL,
 'tools':{str(f):sha(f) for f in tools},'code':{name:sha(out/name) for name in ['vm-lifecycle.py','close.py','census.py']},
 'source':{str(f.relative_to(out/'source')):sha(f) for f in sorted((out/'source').rglob('*')) if f.is_file()},
 'work_seconds':1200,'cleanup_seconds':120,'guest_case_seconds':180,'guest_owner_seconds':210}
write(out/'config.json',config)
protected=[str(HERE),str(case),str(out/'source'),str(out/'records'),str(verify),str(image),str(tree/'tools/host-maintenance')]+[r['source'] for r in inputs['staged'].values()]
write(out/'retention-plan.json',{'volume':'/workspace','scan_roots':[str(out/'scan')],'reference_stores':[],'protected':protected,'candidates':[],
 'builds':[{'name':'m7-installed-native','terms_bytes':{'raw_image_ceiling':16*1024**3,'guest_disk':16*1024**3,'input_output_media':512*1024**2,'input_staging':64*1024**2},
 'basis':'One fresh final-image no-NIC8GiB/4CPU guest; selected native case only,180s work/210s guest owner. Full lifecycle1200s+120s cleanup includes hashing/inflation, normal boot,43MiB inputs, media/serial/export/stop. Existing accepted components and clean588 are not replayed.',
 'evidence':[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','records/final-image-result.json','vm-lifecycle.py','source/owner/guest-owner.py']]}]})
write(out/'admission-plan.json',{'checkout':str(tree),'retention_plan':str(out/'retention-plan.json'),'retention_report':str(out/'retention-report.json'),'stage':'m7-installed-native',
 'profiles':[{'PROJECT':'ROCKNIX','DEVICE':'GENERIC_X64','ARCH':'x86_64'}],
 'outputs':[{'path':str(out/'vm'),'issue':584,'kind':'qa-scratch','release_when':'Export original preparation/installed/descendant/host exits and tiny CHD; actual owners absent; coordinator consumes admission before retiring owned disk/media/UEFI.'}]})
print(json.dumps({'status':'PREPARED_UNRUN','owner':str(out),'work_seconds':1200,'cleanup_seconds':120}))

#!/usr/bin/env python3
"""Read-only static argv/input derivation; does not invoke compiler or Ninja."""
from pathlib import Path
import hashlib,json,os,shlex,shutil
OUT=Path(__file__).resolve().parent
PHYSICAL=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02')
ALIAS=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated')
REL=Path('build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4')
SRC=PHYSICAL/REL;BUILD=SRC/'.x86_64-rocknix-linux-gnu';CWD=ALIAS/REL/'.x86_64-rocknix-linux-gnu'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def resolve_cached(p):
 chain=[]
 for _ in range(40):
  assert p.is_relative_to(PHYSICAL),p
  current=PHYSICAL;changed=False;parts=p.relative_to(PHYSICAL).parts
  for i,part in enumerate(parts):
   current=current/part
   if current.is_symlink():
    target=os.readlink(current);chain.append({'host_path':str(current),'target':target})
    dest=Path(target) if target.startswith('/') else current.parent/target
    if dest.is_relative_to(ALIAS):dest=PHYSICAL/dest.relative_to(ALIAS)
    p=Path(os.path.normpath(str(dest.joinpath(*parts[i+1:]))));changed=True;break
  if not changed:
   assert p.is_file(),p
   return p,chain
 raise AssertionError('symlink loop')
lines=(BUILD/'build.ninja').read_text().splitlines();start=next(i for i,s in enumerate(lines) if s.startswith('build Binaries/dolphin-emu-nogui:'))
block=[]
for line in lines[start:]:
 if not line and block:break
 block.append(line)
(OUT/'link-edge.ninja').write_text('\n'.join(block)+'\n')
v=dict(s.strip().split(' = ',1) for s in block[1:] if ' = ' in s)
objects=shlex.split(block[0].split(': ',1)[1].split(' | ',1)[0])[1:];libs=shlex.split(v['LINK_LIBRARIES'])
assert v['PRE_LINK']==v['POST_BUILD']==':'
compiler=str(ALIAS/'build.pixelelated-GENERIC_X64.x86_64/toolchain/bin/x86_64-rocknix-linux-gnu-g++')
original_link=[compiler]+shlex.split(v['FLAGS'])+shlex.split(v['LINK_FLAGS'])+objects+['-o',v['TARGET_FILE']]+shlex.split(v.get('LINK_PATH',''))+libs
entry=next(x for x in json.loads((BUILD/'compile_commands.json').read_text()) if x['file'].endswith('/DolphinNoGUI/MainNoGUI.cpp'))
original_compile=shlex.split(entry['command']);assert original_compile[0]==compiler
compile_argv=original_compile.copy();compile_argv[compile_argv.index('-o')+1]='/work/MainNoGUI.cpp.o';compile_argv[compile_argv.index('-c')+1]='/work/MainNoGUI.cpp';compile_argv+=['-MD','-MF','/work/MainNoGUI.d']
link=original_link.copy();link[link.index('-o')+1]='/work/dolphin-emu-nogui.unstripped'
old_dep='-Wl,--dependency-file=Source/Core/DolphinNoGUI/CMakeFiles/dolphin-nogui.dir/link.d';assert link.count(old_dep)==1;link[link.index(old_dep)]='-Wl,--dependency-file=/work/link.d'
assert link.count('-flto=4')==1;link[link.index('-flto=4')]='-flto=2'
main='Source/Core/DolphinNoGUI/CMakeFiles/dolphin-nogui.dir/MainNoGUI.cpp.o';assert link.count(main)==1;link[link.index(main)]='/work/MainNoGUI.cpp.o'
required=[str(CWD/p) for p in objects]+[str(Path(p) if p.startswith('/') else CWD/p) for p in libs if not p.startswith('-')]
tc=PHYSICAL/'build.pixelelated-GENERIC_X64.x86_64/toolchain'
compiler_files=[tc/'bin'/n for n in ['x86_64-rocknix-linux-gnu-g++','x86_64-rocknix-linux-gnu-g++-15.2.0','ccache','x86_64-rocknix-linux-gnu-ld','x86_64-rocknix-linux-gnu-as','x86_64-rocknix-linux-gnu-strip','x86_64-rocknix-linux-gnu-readelf']]+[p for p in (tc/'lib/gcc/x86_64-rocknix-linux-gnu/15.2.0').iterdir() if not p.is_dir()]
source_files=[SRC/'Source/Core/DolphinNoGUI/MainNoGUI.cpp',SRC/'Source/Core/Core/AchievementManager.h',SRC/'Source/Core/Core/AchievementManager.cpp',BUILD/'CMakeCache.txt',BUILD/'build.ninja',BUILD/'CMakeFiles/rules.ninja',BUILD/'compile_commands.json']
required += [str(ALIAS/p.relative_to(PHYSICAL)) for p in compiler_files+source_files]
rows=[]
for alias in sorted(set(required)):
 p=PHYSICAL/Path(alias).relative_to(ALIAS);resolved,chain=resolve_cached(p)
 rows.append({'container_path':alias,'host_path':str(p),'sha256':sha(resolved),'bytes':resolved.stat().st_size,'symlink_chain':chain,'resolved_host_path':str(resolved)})
old=Path('/tmp/m7-dolphin-ra-init-20261015')
shutil.copyfile(old/'after/Source/Core/DolphinNoGUI/MainNoGUI.cpp',OUT/'MainNoGUI.cpp');shutil.copyfile(old/'018-nogui-achievements-lifecycle.patch',OUT/'018-nogui-achievements-lifecycle.patch')
plan={'status':'SOURCE_PREPARED_RUNTIME_UNRUN','physical_root':str(PHYSICAL),'container_root':str(ALIAS),'cwd':str(CWD),'distribution_commit':'fac608ff89940ce358ea9b8a95e9a08a6fe26568','dolphin_pin':'6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4','builder_image':'ghcr.io/pixelelated/build@sha256:988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39','original_compile':original_compile,'compile':compile_argv,'original_link':original_link,'link':link,'strip':[str(Path(compiler).with_name('x86_64-rocknix-linux-gnu-strip')),'--strip-unneeded','-o','/work/dolphin-emu-nogui','/work/dolphin-emu-nogui.unstripped'],'readelf':[str(Path(compiler).with_name('x86_64-rocknix-linux-gnu-readelf')),'-h','-d','/work/dolphin-emu-nogui'],'candidate_source_sha256':sha(OUT/'MainNoGUI.cpp'),'patch_sha256':sha(OUT/'018-nogui-achievements-lifecycle.patch'),'inputs':rows,'limits':{'seconds':900,'cleanup_seconds':600,'memory_bytes':4*1024**3,'cpus':2,'pids':256,'scratch_bytes':1024**3},'environment':{'TMPDIR':'/work/tmp','CCACHE_DISABLE':'1','CCACHE_DIR':'/work/ccache','CCACHE_TEMPDIR':'/work/tmp','LC_ALL':'C','LANG':'C'}}
(OUT/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'status':'STATIC_ONLY','inputs':len(rows),'input_bytes':sum(x['bytes'] for x in rows),'objects':len(objects),'library_args':len(libs),'all_resolved_within_frozen_tree':True}))

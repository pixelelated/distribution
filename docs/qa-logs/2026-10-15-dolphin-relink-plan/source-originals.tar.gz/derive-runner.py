#!/usr/bin/env python3
"""Source derivation only. Never imports or executes prepared runtime owners."""
from pathlib import Path
import hashlib,json,difflib,shutil
OUT=Path(__file__).resolve().parent
BASIS=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-14-chdman-build-runner')
rows=[]
def save(name,text):
 old=(BASIS/name).read_text();(OUT/name).write_text(text)
 rows.append({'file':name,'basis':str(BASIS/name),'basis_sha256':hashlib.sha256(old.encode()).hexdigest(),'changed':old!=text})
 if old!=text:(OUT/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='qualified/'+name,tofile='prepared/'+name)))
for name in ['docker_owner.py','watchdog.py']:save(name,(BASIS/name).read_text())
s=(BASIS/'common.py').read_text().replace("SEQUENCES = {'chdman':['chdman-export','chdman-bootstrap','chdman-configure','chdman-build']}","SEQUENCES = {'dolphin':['dolphin-relink']}").replace("LIMITS = {'chdman':1800}","LIMITS = {'dolphin':900}").replace('DISK_LIMIT = 6 * 1024**3','DISK_LIMIT = 1024**3')
start=s.index('def source_root(');end=s.index('def host_cgroup(',start);s=s[:start]+s[end:];save('common.py',s)
s=(BASIS/'run-stage.py').read_text().replace('from mame import predecessors','')
start=s.index('def verify_inputs(');end=s.index('\ndef main(',start)
s=s[:start]+'''def verify_inputs(binding):
    for row in binding['inputs']:
        path=Path(row['resolved_host_path'])
        require(path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],'frozen input changed: '+str(path))
        for item in row['symlink_chain']:
            require(os.readlink(item['host_path'])==item['target'],'frozen symlink changed')

'''+s[end:]
s=s.replace("verify_packet(HERE);extra=read(HERE/'bindings.json');sealed=args.checkout/extra['sealed_plan_path'];verify_packet(sealed)\n    require(sha(sealed/'SHA256SUMS')==extra['sealed_plan_manifest_sha256'],'sealed plan changed')\n    predecessors(owner,args.stage)","verify_packet(HERE);sealed=HERE")
s=s.replace("binding=read(sealed/'input-bindings.json')","binding=read(sealed/'build-plan.json')")
start=s.index("        if args.stage=='chdman-export':");end=s.index("        for path in (stage/'watchdog.stdout'",start);s=s[:start]+"        require(time.monotonic()<deadline,'family deadline exhausted during input checks')\n"+s[end:]
s=s.replace("physical=Path(binding['toolchain']['physical_root']).parents[1]","physical=Path(binding['physical_root'])").replace("inside=Path(binding['toolchain']['required_container_root']).parents[1]","inside=Path(binding['container_root'])")
s=s.replace("        if args.stage=='chdman-export':argv+=['-v',binding['chdman']['archive']['path']+':/mame-source.tar.gz:ro']\n",'').replace("binding['toolchain']['builder_image']","binding['builder_image']")
s=s.replace("'6GiB scratch forecast exceeded'","'1GiB scratch forecast exceeded'")
# Keep exact CID labels/name and ownership implementation from qualified basis.
save('run-stage.py',s)
s=(BASIS/'inner.py').read_text().replace('from mame import generated, configuration, frozen_generated\n','').replace('import resource','import resource\nimport shutil\nimport shlex')
s=s.replace(', verify_source','').replace("WORK=Path('/work/format-tools')","WORK=Path('/work')").replace('0<remaining<=1800','0<remaining<=900').replace("'6GiB scratch forecast exceeded'","'1GiB scratch forecast exceeded'")
s=s.replace("p=subprocess.Popen(receipt['argv'],env=env,stdout=out,stderr=err,start_new_session=True)","p=subprocess.Popen(receipt['argv'],env=env,cwd=binding['cwd'],stdout=out,stderr=err,start_new_session=True)")
start=s.index('    try:\n        verify_packet(PLAN)');end=s.index('    except BaseException as exc:result[',start)
s=s[:start]+'''    def verify_inputs():
        for row in binding['inputs']:
            path=Path(row['container_path'])
            require(path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],'frozen input changed: '+str(path))
            require(os.statvfs(path).f_flag&os.ST_RDONLY,'frozen input mount is writable')
    def dependencies(path):
        # GCC/GNU ld make dependency format: first logical rule only; -MP phony rules excluded.
        logical=path.read_text().replace(chr(92)+chr(10),'').splitlines()[0]
        require(': ' in logical,'unexpected dependency format')
        names=shlex.split(logical.split(': ',1)[1]);require(names,'empty dependencies')
        out=[]
        for name in sorted(set(names)):
            p=Path(name);p=p if p.is_absolute() else Path(binding['cwd'])/p
            if not p.exists():
                require(p.is_relative_to(WORK/'tmp') and ('.ltrans' in p.name or '.lto' in p.name),'persistent dependency absent: '+str(p))
                out.append({'path':str(p),'kind':'compiler-generated temporary already removed; raw dependency retained'});continue
            resolved=p.resolve();require(resolved.is_relative_to(binding['container_root']) or resolved.is_relative_to(WORK),'dependency escaped frozen/private roots: '+str(p))
            out.append({'path':str(p),'resolved':str(resolved),'bytes':p.stat().st_size,'sha256':sha(p)})
        return out
    try:
        verify_packet(PLAN);verify_packet(Path('/runner'));binding=read(PLAN/'build-plan.json')
        require(WORK.is_dir() and (WORK/'tmp').is_dir(),'private work/tmp absent')
        write(RECORDS/'inner-ready.json',{'pid':os.getpid(),'identity':identity(os.getpid()),
              'pid_namespace':os.stat('/proc/self/ns/pid').st_ino,'stage':stage})
        until=min(deadline,time.monotonic()+30)
        while not (RECORDS/'host-admitted.json').exists():
            require(time.monotonic()<until,'host PID handshake timed out');time.sleep(.1)
        require(read(RECORDS/'host-admitted.json')['stage']==stage,'wrong host handshake')
        thread=threading.Thread(target=sample);thread.start()
        env={'PATH':'/usr/bin:/bin',**binding['environment']}
        verify_inputs();require(sha(PLAN/'MainNoGUI.cpp')==binding['candidate_source_sha256'],'candidate source differs')
        require(sha(PLAN/'018-nogui-achievements-lifecycle.patch')==binding['patch_sha256'],'patch differs')
        require(not (WORK/'MainNoGUI.cpp').exists(),'private work already used; no replay')
        shutil.copyfile(PLAN/'MainNoGUI.cpp',WORK/'MainNoGUI.cpp')
        result['plan_sha256']=sha(PLAN/'build-plan.json');result['candidate_source_sha256']=sha(WORK/'MainNoGUI.cpp')
        for label in ['compile','link','strip','readelf']:child(label,binding[label],env)
        deps={name:dependencies(WORK/name) for name in ['MainNoGUI.d','link.d']}
        write(RECORDS/'consumed-dependencies.json',deps)
        verify_inputs()
        for rows in deps.values():
            for row in rows:
                if 'sha256' in row:require(sha(row['path'])==row['sha256'],'consumed dependency changed')
        artifact=WORK/'dolphin-emu-nogui'
        require(artifact.read_bytes()[:5]==b'\\x7fELF\\x02','not a 64-bit ELF')
        write(RECORDS/'target-artifact.json',{'path':str(artifact),'bytes':artifact.stat().st_size,'sha256':sha(artifact),
              'plan_sha256':result['plan_sha256'],'candidate_source_sha256':result['candidate_source_sha256'],
              'distribution_commit':binding['distribution_commit'],'dolphin_pin':binding['dolphin_pin'],
              'execution':'NOT EXECUTED; candidate relink, not installed image proof'})
        require(not fault,'resource monitor failed')
        result['final_cgroup']=telemetry();result['final_disk']=disk_usage([WORK,RECORDS,Path('/tmp')])
        require(max(result['final_disk'].values())<=DISK_LIMIT and time.monotonic()<deadline,'final resource bound exceeded')
        result['status']='PASS'
'''+s[end:]
start=s.index("        if 'source_after' not in result");end=s.index('        stop.set()',start);s=s[:start]+s[end:];save('inner.py',s)
(OUT/'runner-derivation.json').write_text(json.dumps(rows,indent=2)+'\n')

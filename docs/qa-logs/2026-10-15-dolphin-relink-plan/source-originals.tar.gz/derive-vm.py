#!/usr/bin/env python3
"""Copy qualified ownership and change only case binding/validation. Source-only."""
from pathlib import Path
import difflib,hashlib,json
OUT=Path(__file__).resolve().parent;B=OUT/'vm-basis';rows=[]
def save(name,text):
 old=(B/name).read_text();(OUT/name).write_text(text);rows.append({'file':name,'basis_sha256':hashlib.sha256(old.encode()).hexdigest(),'changed':old!=text})
 if old!=text:(OUT/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='qualified/'+name,tofile='prepared/'+name)))
for name in ['census.py','guest-manifest.py']:save(name,(B/name).read_text())
s=(B/'guest-owner.py').read_text();start=s.index("        require(json.loads((R/'preparation");end=s.index("        report['status']='PASS'",start)
s=s[:start]+"        observed=json.loads((R/'result.json').read_text())\n        require(observed['status']=='PASS' and len(observed['rows'])==4,'startup proof did not pass')\n"+s[end:];s=s.replace('one unchanged native case','four bounded Dolphin startup observations');save('guest-owner.py',s)
s=(B/'vm-lifecycle.py').read_text().replace(".strip()==C['commit']",".strip()==C['coordinator_commit']");save('vm-lifecycle.py',s)
s=(B/'close.py').read_text();start=s.index("        case=root/'case';prepared=");end=s.index('except BaseException as exc:validation_error',start)
s=s[:start]+'''        case=root/'case';proof=json.loads((case/'result.json').read_text())
        assert proof['status']=='PASS' and len(proof['rows'])==4
        assert [row['case'] for row in proof['rows']]==['baseline-enabled','candidate-enabled','candidate-disabled','candidate-failed-boot']
        assert all(row['status']=='PASS' and row['remaining_dolphin']==[] and not row.get('endpoint_errors') for row in proof['rows'])
        assert [row['original_exit'] for row in proof['rows']]==[0,0,0,1]
        assert proof['rows'][0]['observation']=='KNOWN_DEFECT_REPRODUCED'
        assert len(proof['rows'][1]['requests'])==1 and proof['rows'][1]['initialized']==proof['rows'][1]['shutdown']==1
        assert not proof['rows'][2]['requests'] and not proof['rows'][2]['initialized']
        assert proof['rows'][3]['boot_error'] and proof['rows'][3]['initialized']==proof['rows'][3]['shutdown']==1
'''+s[end:];save('close.py',s)
(OUT/'vm-derivation.json').write_text(json.dumps(rows,indent=2)+'\n')

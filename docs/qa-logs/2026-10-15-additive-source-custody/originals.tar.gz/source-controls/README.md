# Additive source guard controls — SOURCE ONLY, UNRUN

This small packet binds fresh additive source03. Sealed source01 remains unchanged. The02 correction excludes access time from the existing raw symlink-target identity readback; dev/inode/mode/uid/gid/size/mtime_ns/ctime_ns and exact target equality remain required.

`controls.py` extracts only the named definitions and the exact ten statements of the new pipe-drain block from the hash-bound source. It never imports/runs the collector or preparer. The fixture uses a private TemporaryDirectory, tiny files and an in-memory gzip stream; it verifies less than1MiB of scratch before normal cleanup. Process, pipe, selector, clock and process-identity results are deterministic mocks. No Git, subprocess, network, production archive or product input executes in the controls. Actual host process cleanup and collector behavior still require the independently allocated original run; these tests do not claim them.

Controls cover separate owner/custody accounting, exact/over aggregate and individual bounds, initial owner bytes, reserved failure share, whole failure JSON, overwrite/link/path/file-count refusals, every gzip header/body/trailer write, stable symlink identity versus atime, all eight changed identity fields and raw target mismatch, supervisor per-receipt/cumulative limits, immutable original receipts, both-pipe EOF, original nonzero waits, exact/over log limits, EOF before process-wait timeout, an open-pipe deadline and interruption retaining an original child0 without overriding the outer failure.

The log-overflow control intentionally distinguishes the original child result from the overall stage: a child which had completed0 can retain that original0, while the pipe-write refusal keeps the outer result failed. The existing consumer also requires all original outer channels and no execution error. No status is rewritten to make a refused collector pass.

Root's bounded command after source review/allocation:

```bash
timeout --signal=TERM --kill-after=2s 28s python3 -I -S -B /tmp/pix-m7-additive-source-controls-20261015-02/controls.py
```

The command has at most30s including kill allowance, creates no child through the Python fixture, and uses only a newly generated `/tmp/pix-m7-additive-controls-*` directory. Normal completion removes that exact TemporaryDirectory. If externally killed, root must preserve the original failure and inspect any named surviving fixture directory before cleanup; no cleanup success is invented. No controls have run yet. Static AST/hash/metadata inspection is recorded separately.

This controls revision changes only the source packet/seal binding and this command locator. controls.py is byte-identical to the original unrun controls. Source03 fixes the command-only owner locator caught by root before any runtime. Source02 and the prior control seal remain immutable.

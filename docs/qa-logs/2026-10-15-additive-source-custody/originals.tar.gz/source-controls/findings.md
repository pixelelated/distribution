# Finite source findings

The only concrete correction in this scope is the already reported atime-sensitive symlink comparison in sealed01 `templates/collect.py:184`. Fresh02 compares the raw target and dev/inode/mode/uid/gid/size/mtime_ns/ctime_ns, excluding atime. No other collector or lifecycle behavior changed in02. The original01 seal remains8c2baca89b655fc3895109623200a82c563f7327cab51500644e0894ffd024c1.

No additional source blocker was found in the requested Writer/reserve and supervisor pipe-drain boundaries. `reserve` checks distinct owner/custody and per-file counters before bytes are written; `put(...,failure=True)` checks the whole failure JSON against its share before opening, and the gzip output is routed through the same Writer, including close/trailer writes. The supervisor checks each chunk before writing and has a finite deadline through EOF and the original Popen wait. Its existing finally/custody path retains an observed original wait after a refusal or interruption and does not manufacture a missing one.

One status distinction is deliberate in the controls: after a log-bound refusal, the child might already have exited0. Its retained child result can still say0; the outer execution error and status remain failed. The success consumer independently requires all original outer channels0 and no execution error. This is not a claim that a refused collection qualified.

The controls exercise exact source AST against small local files and mocked process/pipe/wait interfaces. They have not run. They do not qualify kernel selectors, actual child identities, pidfds, Git archive contents, source acquisition, or a full collector run. Root owns those original runtime observations and consumption. No broad source/archive audit was repeated here.

Root's subsequent source review found a command-only default-owner locator defect in sealed02: broad packet-path replacement produced invalid02-01. Fresh03 assigns the packet and valid default owner explicitly, retaining the preparer regex and all collector/lifecycle bytes. No runtime was attempted. These fresh controls bind03; their implementation is unchanged.

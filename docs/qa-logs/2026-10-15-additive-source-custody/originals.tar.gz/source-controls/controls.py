#!/usr/bin/env python3
"""UNRUN exact-source controls: tiny owned files and mocked pipe/process behavior."""
from pathlib import Path,PurePosixPath
import ast,gzip,hashlib,io,json,os,signal,stat,subprocess,tempfile,time,types
P=Path(__file__).resolve().parent;binding=json.loads((P/'bindings.json').read_text())
A=Path(binding['packet']);sources={}
for n,h in binding['sources'].items():
 p=A/n;data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==h;sources[n]=data
assert hashlib.sha256((A/'SHA256SUMS').read_bytes()).hexdigest()==binding['packet_seal']
CT=ast.parse(sources['templates/collect.py']);ST=ast.parse(sources['templates/run.py']);passed=[]

def extracted(tree,names,ns):
 nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
 assert {n.name for n in nodes}==set(names)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'exact-bound-source-definitions','exec'),ns)

def refuses(name,call):
 try:call()
 except AssertionError:passed.append(name)
 else:raise AssertionError(name+' unexpectedly accepted')

# Fixture roots are private, newly generated and used only inside this context.
# All successful writes together are far below1MiB; no production paths are passed.
with tempfile.TemporaryDirectory(prefix='pix-m7-additive-controls-',dir='/tmp') as scratch:
 root=Path(scratch);O=root/'owner';D=root/'custody';O.mkdir();D.mkdir();sequence=0
 ns=dict(Path=Path,PurePosixPath=PurePosixPath,os=os,time=time,json=json,O=O,D=D)
 extracted(CT,['tick','safe','root_for','reserve','Writer','put','rawput'],ns)
 def setup(initial=0,**limits):
  r=dict(total_read_bytes=1024**2,soft_seconds=25,path_bytes=4096,output_files=64,per_file_bytes=16,custody_output_ceiling_bytes=40,owner_output_ceiling_bytes=32,supervisor_reserve_bytes=8,failure_receipt_budget_bytes=4)
  r.update(limits);ns.update(R=r,START=time.monotonic(),READ=0,OUTPUT={str(O):initial,str(D):0},WRITES={})
 def path(root=O):
  global sequence
  sequence+=1;return root/('file-'+str(sequence))
 def write(p,data,failure=False):
  with ns['Writer'](p,failure) as f:f.write(data)
 setup();a=path();write(a,b'a'*16);b=path();write(b,b'b'*8)
 assert ns['OUTPUT']=={str(O):24,str(D):0};passed.append('owner-exact-normal-bound')
 c=path();refuses('owner-over-bound-before-bytes',lambda:write(c,b'x'));assert c.stat().st_size==0 and ns['OUTPUT'][str(O)]==24
 setup();a=path(D);write(a,b'a'*16);b=path(D);write(b,b'b'*16);c=path(D);write(c,b'c'*8)
 assert ns['OUTPUT']=={str(O):0,str(D):40};passed.append('custody-exact-bound-separate-owner')
 q=path(D);refuses('custody-over-bound-before-bytes',lambda:write(q,b'x'));assert q.stat().st_size==0
 setup();a=path();refuses('per-file-before-write-bound',lambda:write(a,b'a'*17));assert a.stat().st_size==0 and ns['OUTPUT'][str(O)]==0
 setup(initial=8);a=path();write(a,b'a'*16);b=path();refuses('initial-owner-files-counted',lambda:write(b,b'x'));assert ns['OUTPUT'][str(O)]==24
 setup(initial=24);a=path();write(a,b'fail',True);assert ns['OUTPUT'][str(O)]==28;passed.append('failure-share-preserves-supervisor-margin')
 b=path();refuses('failure-share-cannot-be-used-twice',lambda:write(b,b'x',True));assert b.stat().st_size==0
 setup();a=path(D);refuses('failure-reserve-not-in-custody',lambda:write(a,b'x',True));assert a.stat().st_size==0
 setup();a=path();refuses('whole-failure-JSON-bounded-before-open',lambda:ns['put'](a,dict(error='too long'),True));assert not a.exists()
 setup();a=path();write(a,b'a');refuses('same-writer-path-refuses-overwrite',lambda:write(a,b'b'));assert a.read_bytes()==b'a'
 setup();a=path();a.write_bytes(b'old');refuses('existing-file-refuses-overwrite',lambda:write(a,b'new'));assert a.read_bytes()==b'old'
 setup();a=path();a.symlink_to(root/'absent');refuses('dangling-symlink-refused',lambda:write(a,b'x'));assert a.is_symlink()
 setup();refuses('outside-root-refused',lambda:write(root/'outside',b'x'));assert not (root/'outside').exists()
 setup();refuses('traversal-refused',lambda:write(O/'..'/'escape',b'x'));assert not (root/'escape').exists()
 setup(output_files=1);a=path();write(a,b'a');b=path();refuses('output-file-count-bound',lambda:write(b,b'b'));assert not b.exists()
 def compressed(p,data):
  with ns['Writer'](p) as sink:
   with gzip.GzipFile(filename='',fileobj=sink,mode='wb',mtime=0,compresslevel=6) as z:z.write(data)
 # Gzip header/body/trailer all pass through the exact Writer. Tiny3-byte input.
 probe=io.BytesIO()
 with gzip.GzipFile(filename='',fileobj=probe,mode='wb',mtime=0,compresslevel=6) as z:z.write(b'abc')
 length=len(probe.getvalue());setup(custody_output_ceiling_bytes=length,per_file_bytes=length)
 a=path(D);compressed(a,b'abc');assert gzip.decompress(a.read_bytes())==b'abc' and a.stat().st_size==length;passed.append('gzip-sink-exact-bound-including-trailer')
 setup(custody_output_ceiling_bytes=length-1,per_file_bytes=length);a=path(D)
 refuses('gzip-final-trailer-refuses-before-overrun',lambda:compressed(a,b'abc'));assert a.stat().st_size<=length-1 and ns['OUTPUT'][str(D)]<=length-1
 # New stable symlink fields: execute the exact three source statements, no extras().
 extras=next(n for n in CT.body if isinstance(n,ast.FunctionDef) and n.name=='extras')
 branch=next(n for n in ast.walk(extras) if isinstance(n,ast.If) and isinstance(n.test,ast.Call) and isinstance(n.test.func,ast.Attribute) and n.test.func.attr=='S_ISLNK')
 relevant=[]
 for n in branch.body:
  if isinstance(n,ast.Assert) and ('readlink' in ast.unparse(n) or 'getattr(after' in ast.unparse(n)):relevant.append(n)
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='after' for t in n.targets):relevant.append(n)
 assert len(relevant)==3
 stable={k:i+1 for i,k in enumerate(['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns'])};before=types.SimpleNamespace(**stable,st_atime_ns=1)
 def symlink_read(after,target='literal-target'):
  env=dict(os=types.SimpleNamespace(readlink=lambda p:target),p=types.SimpleNamespace(lstat=lambda:after),s=before,value='literal-target')
  exec(compile(ast.Module(body=relevant,type_ignores=[]),'exact-symlink-identity-statements','exec'),env)
 symlink_read(types.SimpleNamespace(**stable,st_atime_ns=999));passed.append('readlink-atime-change-accepted')
 for field in stable:
  changed=dict(stable);changed[field]+=1
  refuses('changed-'+field+'-refused',lambda changed=changed:symlink_read(types.SimpleNamespace(**changed,st_atime_ns=1)))
 refuses('changed-raw-symlink-target-refused',lambda:symlink_read(before,'different-target'))
 # Supervisor receipt guards: simulate existing accounted capacity, tiny new writes.
 sn=dict(json=json,SUPERVISOR_WRITTEN=0);extracted(ST,['write','write_once'],sn)
 a=path();refuses('supervisor-per-receipt-before-open',lambda:sn['write'](a,{'value':'x'*(1024**2)}));assert not a.exists()
 raw=(json.dumps({},indent=2,sort_keys=True)+'\n').encode();sn['SUPERVISOR_WRITTEN']=8*1024**2-len(raw)
 a=path();sn['write'](a,{});assert a.read_bytes()==raw;passed.append('supervisor-exact-cumulative-reserve')
 b=path();refuses('supervisor-cumulative-overrun-before-open',lambda:sn['write'](b,{}));assert not b.exists()
 sn['write_once'](a,{});passed.append('identical-original-receipt-idempotent')
 refuses('changed-original-receipt-refused',lambda:sn['write_once'](a,{'changed':True}));assert a.read_bytes()==raw
 # Execute the exact new pipe-drain statements and unchanged wait/cleanup helpers
 # against deterministic mock process/selector/clock/identity objects; never spawn.
 outer=next(n for n in ST.body if isinstance(n,ast.Try) and any(isinstance(x,ast.With) for x in n.body))
 block=next(n for n in outer.body if isinstance(n,ast.With))
 start=next(i for i,n in enumerate(block.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='selector' for t in n.targets))
 end=next(i for i,n in enumerate(block.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='active' for t in n.targets) and isinstance(n.value,ast.Constant) and n.value.value is None)
 exact=block.body[start:end+1];assert len(exact)==10
 wrapped=ast.FunctionDef(name='drain_exact',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),body=[ast.Global(names=['active','original_rc','log_bytes'])]+exact,decorator_list=[])
 pipecode=compile(ast.fix_missing_locations(ast.Module(body=[wrapped],type_ignores=[])),'exact-source-pipe-block','exec')
 class Clock:
  def __init__(self):self.now=0
  def monotonic(self):self.now+=.001;return self.now
  def sleep(self,n):self.now+=n
 class Pipe:
  def __init__(self,fd):self.fd=fd;self.closed=False
  def fileno(self):return self.fd
  def close(self):self.closed=True
 class Proc:
  def __init__(self,value,wait_timeout=False):self.pid=91;self.returncode=None;self.stdout=Pipe(1);self.stderr=Pipe(2);self.value=value;self.wait_timeout=wait_timeout;self.waits=0
  def wait(self,timeout):
   self.waits+=1
   if self.wait_timeout and self.waits==1:raise subprocess.TimeoutExpired(['mock'],timeout)
   self.returncode=self.value;return self.value
 def pipe_case(name,out,err=b'',value=0,wait_timeout=False,idle=False,interrupt=False,expect_error=False):
  clock=Clock();proc=Proc(value,wait_timeout);payloads={};stdout=io.BytesIO();stderr=io.BytesIO();calls=[]
  chunks={1:[out[i:i+65536] for i in range(0,len(out),65536)]+[b''],2:[err,b''] if err else [b'']}
  class Selector:
   def __init__(self):self.items={};self.closed=False
   def register(self,p,events,data):self.items[p.fd]=types.SimpleNamespace(fileobj=p,data=data)
   def unregister(self,p):del self.items[p.fd]
   def get_map(self):return self.items
   def select(self,timeout):
    if interrupt:env['stopped'](signal.SIGTERM,None)
    if idle:clock.now+=1;return []
    return [(k,1) for k in list(self.items.values())]
   def close(self):self.closed=True
  identity=dict(pid=91,start_ticks=123,ppid=5000,state='Z')
  row=dict(profile='synthetic-pipe',association_rc=None,timeout=False,interrupted=False)
  active=dict(proc=proc,row=row,key='association',directory=O,command=['mock'],identity=identity,original_rc=None,wait_observed=False,published=False,interrupted=False,timeout=False,payload=None,signal_start=0)
  def unexpected_signal(*args):raise AssertionError('mock zombie should never be signalled')
  fakeos=types.SimpleNamespace(getpid=lambda:5000,read=lambda fd,n:chunks[fd].pop(0))
  env=dict(proc=proc,stdout=stdout,stderr=stderr,selectors=types.SimpleNamespace(DefaultSelector=Selector,EVENT_READ=1),os=fakeos,time=clock,subprocess=subprocess,signal=signal,active=active,row=row,left=.1,cmd=['mock'],identities={},signals_sent=[],cleanup_errors=[],receipt_errors=[],reaped=[],interrupted_signals=[],finalizing=False,rc=0,I={'tree':lambda pid:[],'children':lambda pid:[],'identity':lambda pid:identity,'same':lambda row:False,'signal_child':unexpected_signal},write_once=lambda p,v:payloads.setdefault(str(p),v))
  extracted(ST,['observed','capture_wait','reap_adopted','cleanup_active','publish_active','stopped'],env);exec(pipecode,env)
  # Every case uses a distinct exact receipt path; no previous test receipt reused.
  directory=O/('pipe-'+name);directory.mkdir();active['directory']=directory
  failed=False
  try:env['drain_exact']()
  except (AssertionError,RuntimeError):
   failed=True;env['rc']=1;env['finalizing']=True;env['cleanup_active']();env['publish_active']()
  assert failed==expect_error,name
  receipt=payloads[str(directory/'association.result.json')]
  assert receipt['wait_observed']is True and receipt['original_child_returncode']==value and row['association_rc']==value
  assert (directory/'association.exit').read_text()==str(value)+'\n'
  assert proc.stdout.closed and proc.stderr.closed and proc.waits>=1
  assert len(stdout.getvalue())<=256*1024 and len(stderr.getvalue())<=256*1024
  if wait_timeout or idle:assert row['timeout']is True and receipt['qualification']is False
  if interrupt:assert receipt['interrupted']is True and receipt['qualification']is False
  if expect_error:assert env['rc']==1 # Original child0 must not overwrite the outer refusal.
  if not expect_error and not wait_timeout and not idle:assert stdout.getvalue()==out and stderr.getvalue()==err
  if value!=0:assert receipt['qualification']is False
  passed.append(name)
 pipe_case('both-pipes-EOF-original-zero',b'out',b'err')
 pipe_case('nonzero-original-retained',b'out',value=7)
 pipe_case('exact-log-ceiling',b'x'*(256*1024))
 pipe_case('over-log-ceiling-refuses-before-write',b'x'*(256*1024+1),expect_error=True)
 pipe_case('EOF-before-process-wait-timeout',b'',value=-15,wait_timeout=True)
 pipe_case('open-pipe-deadline-original-wait',b'',value=9,idle=True)
 pipe_case('interruption-original-zero-remains-failed',b'',interrupt=True,expect_error=True)
 # TemporaryDirectory owns every generated path. Check the promised bound before cleanup.
 actual=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink());assert actual<1024**2
 scratch_name=str(root)
assert not Path(scratch_name).exists(),'owned tiny fixture scratch not removed'
for name in passed:print('PASS '+name)
print(json.dumps(dict(result='PASS',controls=len(passed),scratch_bytes_before_removal=actual,scratch_removed=True,network=False,spawned_children=0,product_inputs=False,scope='Exact source guards and mocked original-wait/pipe behavior; no real process or collector qualification.')))

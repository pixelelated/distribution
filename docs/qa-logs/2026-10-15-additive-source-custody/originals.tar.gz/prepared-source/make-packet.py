from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;BASE=Path('/tmp/pix-m7-prebuilt-source-collection-20261015-02')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,d):(P/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
refs={}
def bind(p):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p.stat().st_size<16*1024**2;refs[str(p)]=sha(p);return json.loads(p.read_text())
delta=bind('/tmp/pix-m7-current-source-member-plan-20261015/member-delta.json');proj=bind('/tmp/pix-m7-source-custody-refresh-20261015/historical-member-projection.json')
profiles=[];dist={};archives={};git={}
for row in delta['inventory_bindings']:
 p=Path(row['path']);w=bind(p);assert refs[str(p)]==row['sha256'];ip=p.parent/'inventory-inputs.json';i=bind(ip);assert refs[str(ip)]==w['input_manifest_sha256']
 profiles.append(dict(profile=p.parent.name,worklist=str(p),inputs=str(ip),components=row['components']))
 c=i['distribution_commit'];spec=dict(commit=c,source_repository='/workspace/repos/rocknix',objects='/workspace/repos/rocknix/.git/objects',input_manifest=str(ip),roots=sorted({n.split('/')[0] for k in ['source_files','source_symlinks'] for n in i[k]}),source_files=len(i['source_files']),source_symlinks=len(i['source_symlinks']))
 if c in dist:
  prior=json.loads(Path(dist[c]['input_manifest']).read_text());assert i['source_files']==prior['source_files'] and i['source_symlinks']==prior['source_symlinks']
 else:dist[c]=spec
 for component in w['components']:
  for r in (component.get('unpacked_source') or {}).get('cache',[]):
   if 'sha256' in r:archives.setdefault(r['sha256'],dict(path=i['source_cache']+'/'+component['component']+'/'+r['name'],bytes=r['bytes'],sha256=r['sha256'],original_name=r['name'],kind='cache-archive'))
   else:git[r['git_head']]=r
cust={k:dict(v,manifest=str(Path(v['path'])/'manifest.json')) for k,v in proj['custodies'].items()}
for k,v in cust.items():
 d=bind(v['manifest']);assert refs[v['manifest']]==v['manifest_sha256']
 if k=='git':historical_git=d
held_path='/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-prebuilt-source-collection/held-source-archives.json';held=bind(held_path)
newsha=['88eef31acfa4104b20258bd5cea514ade30e6cdf35767ffc958009851d61898b','64034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7']
selected=[archives[h] for h in newsha]+[dict(path=r['path'],bytes=r['bytes'],sha256=r['sha256'],original_name=Path(r['path']).name,kind='held-rclone-source',held_identity=r) for r in held['archives']]
es='16dbac5211eea7e70db7394372033be2be7df829';ep='/workspace/cache/rocknix-sources/emulationstation/emulationstation-'+es
pugi='61c944895e071872370219cadade8423dc6e04dc';pugiref=historical_git['snapshots'][pugi]
put('collection-plan.json',dict(schema=1,scope='Additive exact corresponding-source custody with explicit unresolved generated/prebuilt/licence/retrieval/offhost scope',binding_refs=refs,profiles=profiles,current_unique_archive_count=606,current_unique_git_root_count=43,custodies=cust,archives=selected,distribution=list(dist.values()),git_root=dict(commit=es,source_repository=ep,objects=ep+'/.git/objects',submodules=[dict(path='external/pugixml',commit=pugi,source_repository=ep+'/external/pugixml',historical_snapshot=pugiref)]),doom_reuse=dict(path=cust['supplement']['path']+'/ff35cde05801cfb27005229a6c55f20130ffa8f026ca27d7717c03152634e168-doom.tar.gz',bytes=1689157,sha256='ff35cde05801cfb27005229a6c55f20130ffa8f026ca27d7717c03152634e168'),publication_bundle_complete=False,unresolved=['FEX/generated/Nix inputs and disposition','Tailscale exact module acquisition and notices','rclone upstream dirty-file list unknown','Licences/notices and redistribution dispositions','Independent retrieval/offhost backup/publication; no universal historic compiler-flag requirement inferred']))
put('resources.json',dict(cpu_affinity=[0,1],address_space_bytes=2147483648,collector_seconds=900,soft_seconds=870,outer_seconds=930,cleanup_seconds=15,owner_output_ceiling_bytes=67108864,custody_output_ceiling_bytes=1073741824,retention_budget_bytes=2147483648,normal_owner_ceiling_bytes=50331648,failure_receipt_budget_bytes=1048576,supervisor_reserve_bytes=16777216,per_file_bytes=268435456,archive_decoded_bytes=536870912,total_read_bytes=8589934592,git_commands=40,git_seconds=180,git_stdout_metadata_bytes=8388608,git_stderr_bytes=65536,tree_entries=32768,tar_entries=65536,extra_entries=4096,extra_bytes=67108864,extra_file_bytes=16777216,output_files=512,output_directories=64,process_observations=131072,path_bytes=4096))
shutil.copy2(BASE/'frozen-tools.json',P/'frozen-tools.json')
for n in ['run.py','run.sh','process-identity.py','consume.py','bindings.py','collect.py']:
 shutil.copy2(BASE/'templates'/n,P/'originals'/n)
for n in ['prepare-owner.py','commands.sh','resources.json']:shutil.copy2(BASE/n,P/'originals'/n)
for n in ['run.py','run.sh','process-identity.py']:shutil.copy2(BASE/'templates'/n,P/'templates'/n)
put('source-provenance.json',dict(lifecycle=str(BASE),lifecycle_files={str(p):sha(p) for p in sorted((P/'originals').iterdir())},historical_collectors=['docs/qa-logs/2026-10-08-source-custody/source-archives-02/run.py','docs/qa-logs/2026-10-08-source-custody/git-complete/run.py'],historical_lifecycle_reused=False,collector_executed=False))
print('Source packet data prepared',len(refs),'exact metadata refs; selected archive bytes',sum(r['bytes'] for r in selected))

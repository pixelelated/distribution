#!/usr/bin/env python3
"""Prepare an unrun owner after exact source/host CLI binding; no download or archive read."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy,shutil
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,o):
    with p.open('x') as f:json.dump(o,f,indent=2,sort_keys=True);f.write('\n')
def main():
    q=argparse.ArgumentParser(description=__doc__);q.add_argument('--owner',type=Path,required=True);q.add_argument('--curl-path',type=Path,required=True);q.add_argument('--curl-sha256',required=True);a=q.parse_args()
    names=[]
    for line in (P/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);p=P/n;assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink() and sha(p)==h;names.append(n)
    assert sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
    B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']();assert Path.cwd()==B['VM_TREE']
    O=a.owner;assert O.parent==Path('/workspace/tmp') and re.fullmatch('pix-m7-prebuilt-source-collection-20261015-[0-9]{2}',O.name)
    assert not O.exists() and not O.is_symlink()
    plan=json.loads((P/'collection-plan.json').read_text())
    for name,h in plan['binding_refs'].items():
        p=Path(name);assert p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2 and sha(p)==h
    actual=B['curl_identity'](a.curl_path);assert re.fullmatch('[0-9a-f]{64}',a.curl_sha256) and actual['sha256']==a.curl_sha256
    O.mkdir(mode=0o700);(O/'stage').mkdir();(O/'empty-retention-scan').mkdir()
    for p in sorted((P/'templates').iterdir()):shutil.copy2(p,O/p.name)
    for n in ['collection-plan.json','resources.json','frozen-tools.json']:shutil.copy2(P/n,O/n)
    put(O/'host-tools.json',dict(curl=dict(path=str(a.curl_path),identity=actual)))
    put(O/'preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),curl_cli_sha256=a.curl_sha256,pid_namespace=os.readlink('/proc/self/ns/pid'),user_namespace=os.readlink('/proc/self/ns/user'),uid_map=Path('/proc/self/uid_map').read_text(),gid_map=Path('/proc/self/gid_map').read_text(),archives_downloaded=False,collector_executed=False,publication_clearance=False))
    put(O/'retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=['/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources','/workspace/tmp/pix-m7-prebuilt-strip-20261015-02'],candidates=[],builds=[dict(name='m7-prebuilt-source-collection',terms_bytes={'source_archives_selected_notices_and_margin':1073741824},basis='Only2exact source archives and bounded selected member bytes;128MiB output ceiling plus1GiB margin. No payload deletion or cache scan.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])]))
    put(O/'admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-prebuilt-source-collection',profiles=[dict(PROJECT='ROCKNIX',DEVICE='GENERIC_X64',ARCH='x86_64')],outputs=[dict(path=str(O),kind='qa-scratch',issue=528,release_when='Original source collection consumed; exact source archives transferred to required source custody and compact receipts retained. Publication and dirty source gaps remain explicit.')]))
    put(O/'seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()})
    B['verify'](O)
    print(json.dumps(dict(owner=str(O),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),publication_clearance=False)))
if __name__=='__main__':main()

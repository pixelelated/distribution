#!/usr/bin/env python3
"""Nine exact selected prebuilts: offline archive/bytes/Go metadata association only."""
from pathlib import Path, PurePosixPath
import argparse, datetime, hashlib, json, os, resource, stat, subprocess, sys, tarfile, time, zipfile

O = Path(__file__).resolve().parent
started = time.monotonic()
read_bytes = 0
rows, archives, source_rows = [], {}, []
rc, error = 1, None

def put(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')

def identity(path):
    assert path.is_absolute() and path.resolve(strict=True) == path and not path.is_symlink(), path
    s = path.stat(); assert stat.S_ISREG(s.st_mode), path
    return dict(path=str(path), bytes=s.st_size, device=s.st_dev, inode=s.st_ino,
        mode=stat.S_IMODE(s.st_mode), uid=s.st_uid, gid=s.st_gid, mtime_ns=s.st_mtime_ns)

def block_check(n):
    global read_bytes
    read_bytes += n
    assert read_bytes <= 10*1024**3, '10 GiB named read ceiling'
    assert time.monotonic()-started < 580, '580-second soft collection deadline'

def stream_digest(stream, maximum, declared=None):
    h, count = hashlib.sha256(), 0
    for block in iter(lambda: stream.read(1024**2), b''):
        count += len(block); assert count <= maximum, 'individual input ceiling'
        block_check(len(block)); h.update(block)
    if declared is not None: assert count == declared, 'member length changed'
    return dict(bytes=count, sha256=h.hexdigest())

def digest(path, maximum):
    before = identity(path); assert before['bytes'] <= maximum, path
    with path.open('rb') as stream: result = stream_digest(stream, maximum, before['bytes'])
    assert identity(path) == before, 'input identity changed: '+str(path)
    return dict(before, **{'sha256': result['sha256']})

def safe_member(name):
    p = PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and '\0' not in name, 'unsafe archive member'
    assert str(p) == name.rstrip('/'), 'noncanonical archive member'
    return name.rstrip('/')

def archive(spec):
    # A genuinely absent locator is a gap. Permission/type/hash errors fail.
    if spec['path'] is None:
        return dict(status='UNAVAILABLE_NO_RETAINED_LOCATOR', expected_sha256=spec['sha256'], members={})
    path = Path(spec['path'])
    try: path.lstat()
    except FileNotFoundError:
        return dict(status='UNAVAILABLE_AT_RETAINED_LOCATOR', path=str(path), expected_sha256=spec['sha256'], members={})
    meta = digest(path, 256*1024**2); assert meta['sha256'] == spec['sha256'], 'archive checksum mismatch: '+str(path)
    found, names, total = {}, set(), 0
    if spec['format'] == 'zip':
        with zipfile.ZipFile(path) as z:
            entries = z.infolist(); assert len(entries) <= 8192
            for m in entries:
                name = safe_member(m.filename); assert name not in names, 'duplicate member'; names.add(name)
                assert not (m.flag_bits & 1), 'encrypted member'
                total += m.file_size; assert total <= 1024**3, 'archive expansion ceiling'
                if name not in spec['members']: continue
                assert not m.is_dir() and stat.S_IFMT(m.external_attr >> 16) in (0, stat.S_IFREG), 'selected member is not regular'
                with z.open(m) as stream: found[name] = stream_digest(stream, 256*1024**2, m.file_size)
    else:
        assert spec['format'] == 'tar.gz'
        with tarfile.open(path, 'r|gz') as tar:
            for m in tar:
                name = safe_member(m.name); assert name not in names, 'duplicate member'; names.add(name)
                assert len(names) <= 8192
                total += m.size; assert total <= 1024**3, 'archive expansion ceiling'
                block_check(0)
                if name not in spec['members']: continue
                assert m.isfile() and not m.issparse(), 'selected member is not regular'
                with tar.extractfile(m) as stream: found[name] = stream_digest(stream, 256*1024**2, m.size)
    assert set(found) == set(spec['members']), 'exact selected archive member missing'
    assert digest(path, 256*1024**2) == meta, 'archive changed during read'
    return dict(status='EXACT_ARCHIVE_READ', original=meta, members=found, member_count=len(names), declared_expansion_bytes=total)

def buildinfo(text):
    # Keep unparsed complete original output; only exact build records become settings.
    settings, modules, other = {}, [], []
    for line in text.splitlines()[1:]:
        fields = line.lstrip('\t').split('\t')
        if len(fields) == 2 and fields[0] == 'build' and '=' in fields[1]:
            key, value = fields[1].split('=', 1)
            assert key not in settings, 'duplicate Go build setting'; settings[key] = value
        elif fields and fields[0] in ('path', 'mod', 'dep', '=>'):
            modules.append(fields)
        else: other.append(line)
    assert modules or settings, 'Go reader emitted no build information'
    return dict(settings=settings, module_records=modules, other_records=other)

try:
    plan = json.loads((O/'association-plan.json').read_text())
    assert len(plan['binaries']) == 9 and len(plan['archives']) == 4
    for name, wanted in plan['binding_refs'].items():
        assert digest(Path(name), 8*1024**2)['sha256'] == wanted, name
    tools = json.loads((O/'host-tools.json').read_text())
    for item in tools.values():
        assert digest(Path(item['path']), 256*1024**2)['sha256'] == item['sha256']
        assert os.access(item['path'], os.X_OK)
    out = O/'collection'; out.mkdir(mode=0o700)
    for key, spec in plan['archives'].items():
        archives[key] = archive(spec); put(out/(key+'.json'), archives[key])
    for spec in plan['retained_source_archives']:
        result = archive(spec)
        if result['status'] == 'EXACT_ARCHIVE_READ':
            for name, wanted in spec['members'].items():
                assert result['members'][name]['sha256'] == wanted, 'retained source member mismatch'
        source_rows.append(dict(selection=spec, observation=result))
    put(out/'retained-source-identities.json', source_rows)
    for index, item in enumerate(plan['binaries'], 1):
        row = dict(selection=item, files={}, gaps=[])
        for role in ('source_root', 'package_file', 'image_file'):
            path = Path(item[role]); meta = digest(path, 256*1024**2)
            with path.open('rb') as stream: header = stream.read(64)
            assert header[:6] == b'\x7fELF\x02\x01' and int.from_bytes(header[18:20], 'little') == item['elf_machine'], path
            assert identity(path) == {k:v for k,v in meta.items() if k != 'sha256'}
            row['files'][role] = meta
        if item['source_binary_expected_sha256']:
            assert row['files']['source_root']['sha256'] == item['source_binary_expected_sha256'], 'inventory source binary mismatch'
        ar = archives[item['archive_key']]
        row['archive_status'] = ar['status']
        row['archive_to_unpacked_equal'] = None
        if ar['status'] == 'EXACT_ARCHIVE_READ':
            row['archive_to_unpacked_equal'] = ar['members'][item['archive_member']]['sha256'] == row['files']['source_root']['sha256']
            assert row['archive_to_unpacked_equal'], 'archive member differs from selected unpacked binary'
        else: row['gaps'].append('matching release archive unavailable; no archive-to-unpacked claim')
        row['unpacked_to_package_equal'] = row['files']['source_root']['sha256'] == row['files']['package_file']['sha256']
        row['package_to_staged_image_equal'] = row['files']['package_file']['sha256'] == row['files']['image_file']['sha256']
        if not row['unpacked_to_package_equal']: row['gaps'].append('unpacked/package bytes differ; recipe stripping is context, not proof of byte derivation')
        if not row['package_to_staged_image_equal']: row['gaps'].append('package/staged image bytes differ; unresolved association')
        row['gaps'].append('staged image file observed; no new independent accepted SYSTEM extraction in this collector')
        prefix = f'{index:02d}-{item["profile"]}-{item["binary"]}'
        stdout, stderr = out/(prefix+'.stdout'), out/(prefix+'.stderr')
        argv = [tools['timeout']['path'], '--signal=TERM', '--kill-after=5s', '30s', tools['go']['path'], 'version', '-m', item['image_file']]
        env = dict(PATH='/usr/bin:/bin', GOENV='off', GOTOOLCHAIN='local', GOPROXY='off', GOSUMDB='off', GOWORK='off',
            GOCACHE=str(out/'unused-go-cache'), GOMODCACHE=str(out/'unused-module-cache'))
        # Qualified outer supervisor is subreaper and retains/cleans this collector and any adopted child.
        # On interrupted collection, no missing Go wait is invented; the stage cannot qualify.
        with stdout.open('xb') as so, stderr.open('xb') as se:
            proc = subprocess.run(argv, stdout=so, stderr=se, cwd=out, env=env,
                preexec_fn=lambda: resource.setrlimit(resource.RLIMIT_FSIZE, (2*1024**2, 2*1024**2)))
        row['original_reader_returncode'] = proc.returncode; row['argv'] = argv
        put(out/(prefix+'.wait.json'), dict(original_reader_returncode=proc.returncode, argv=argv))
        row['stdout'] = digest(stdout, 2*1024**2); row['stderr'] = digest(stderr, 2*1024**2)
        row['after_metadata_binary'] = digest(Path(item['image_file']), 256*1024**2)
        put(out/(prefix+'.original.json'), row); rows.append(row)
        assert proc.returncode == 0, 'original Go metadata read failed/timed out'
        assert row['after_metadata_binary'] == row['files']['image_file'], 'binary changed during data read'
        row['go_buildinfo'] = buildinfo(stdout.read_text())
        settings = row['go_buildinfo']['settings']
        assert settings.get('GOARCH') == item['architecture'] and settings.get('GOOS') == 'linux', 'build metadata architecture mismatch'
        known_revision = plan['source_identities'][item['component']]['commit']
        row['retained_source_revision_matches_metadata'] = settings.get('vcs.revision') == known_revision if known_revision else None
        row['source_to_binary_reproduced'] = False
        row['gaps'].append('embedded dependencies and modified/reproducible source relationship remain separately reviewed; no licence clearance')
        put(out/(prefix+'.association.json'), row)
    # Exact final metadata refs remain unchanged; input tree reads are finite named files only.
    for name, wanted in plan['binding_refs'].items(): assert digest(Path(name), 8*1024**2)['sha256'] == wanted
    rc = 0
except BaseException as exc:
    error = type(exc).__name__+': '+str(exc)
finally:
    put(O/'collection-result.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        result='COLLECTED_WITH_EXPLICIT_GAPS' if rc == 0 else 'COLLECTION_FAILED', original_collector_exit=rc,
        error=error, rows=rows, archives=archives, retained_sources=source_rows, named_bytes_read=read_bytes,
        elapsed_seconds=time.monotonic()-started, target_execution=False, network_used=False,
        independent_SYSTEM_relation_established=False, publication_clearance=False, outputs_held=True, deleted_bytes=0))
sys.exit(rc)

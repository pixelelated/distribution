# Source-only structural readback; never import/execute any candidate/helper.
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
P=Path(__file__).resolve().parent
checks=[]
def check(value,label):
    assert value,label;checks.append(label)
def funcs(text):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
for f in sorted(P.rglob('*.py')):
    ast.parse(f.read_text(),filename=str(f));checks.append('AST '+str(f.relative_to(P)))
for f in [P/'commands.sh',P/'templates/run.sh']:
    r=subprocess.run(['bash','-n',str(f)],capture_output=True,text=True)
    check(r.returncode==0 and not r.stdout and not r.stderr,'bash -n '+str(f.relative_to(P)))
check((P/'templates/process-identity.py').read_bytes()==(P/'originals/process-identity.py').read_bytes(),'qualified identity helper byte identity')
a,b=funcs((P/'originals/run.py').read_text()),funcs((P/'templates/run.py').read_text())
for n in ['observed','capture_wait','reap_adopted','cleanup_active','publish_active','stopped','write','write_once']:
    check(a[n]==b[n],'qualified supervisor function AST '+n)
a,b=funcs((P/'originals/bindings.py').read_text()),funcs((P/'templates/bindings.py').read_text())
for n in ['sha','load','host_and_serialization']:check(a[n]==b[n],'binding helper AST '+n)
p=json.loads((P/'association-plan.json').read_text())
check(len(p['binaries'])==9 and len({(x['profile'],x['binary']) for x in p['binaries']})==9,'nine unique selected binaries')
check(len(p['archives'])==4 and len(p['retained_source_archives'])==1,'four release and one source archive selections')
for row in p['binaries']:
    check(row['archive_member'] in p['archives'][row['archive_key']]['members'],'exact archive member '+row['profile']+'/'+row['binary'])
    check(row['archive_expected_sha256']==p['archives'][row['archive_key']]['sha256'],'exact per-architecture archive hash '+row['profile']+'/'+row['binary'])
check(p['archives']['tailscale-amd64']['path'] is None,'unknown AMD64 locator remains null')
check(p['source_identities']['rclone']['commit'] is None,'no promoted historical rclone source commit')
diffs=[]
for n in ['bindings.py','run.py','run.sh','consume.py']:
    diffs.extend(difflib.unified_diff((P/'originals'/n).read_text().splitlines(True),(P/'templates'/n).read_text().splitlines(True),fromfile='qualified-inventory/'+n,tofile='association/'+n))
diffs.extend(difflib.unified_diff(Path('/tmp/pix-m7-current-notice-gaps-20261015/read-prebuilt-metadata.py').read_text().splitlines(True),(P/'templates/collect.py').read_text().splitlines(True),fromfile='sealed-source-only/read-prebuilt-metadata.py',tofile='association/collect.py'))
(P/'changes.diff').write_text(''.join(diffs))
result=dict(status='PASS_SOURCE_STRUCTURE_ONLY',checks=checks,collector_executed=False,preparer_executed=False,helpers_imported=False,archive_or_binary_inputs_read=False,tests_executed=False)
(P/'static-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],checks=len(checks))))

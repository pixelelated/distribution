#!/usr/bin/env python3
"""UNRUN. Prepare one immutable owner; no collectors, target execution or cache reads."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy,shutil,stat
P=Path(__file__).resolve().parent

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()

def put(p,obj):
    with p.open('x') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')

def main():
    q=argparse.ArgumentParser(description=__doc__)
    q.add_argument('--owner',type=Path,required=True)
    q.add_argument('--go-reader',type=Path,required=True);q.add_argument('--go-reader-sha256',required=True)
    q.add_argument('--timeout-reader',type=Path,required=True);q.add_argument('--timeout-reader-sha256',required=True)
    q.add_argument('--tailscale-amd64-archive',type=Path)
    a=q.parse_args()
    names=[]
    for line in (P/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);f=P/n
        assert not Path(n).is_absolute() and '..' not in Path(n).parts and f.is_file() and not f.is_symlink()
        assert sha(f)==h,n;names.append(n)
    assert sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
    B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']()
    assert Path.cwd()==B['VM_TREE']
    O=a.owner
    assert O.parent==Path('/workspace/tmp') and re.fullmatch('pix-m7-prebuilt-association-20261015-[0-9]{2}',O.name)
    assert not O.exists() and not O.is_symlink()
    plan=json.loads((P/'association-plan.json').read_text())
    for path,h in plan['binding_refs'].items():
        f=Path(path);assert f.is_absolute() and f.resolve(strict=True)==f and not f.is_symlink() and f.stat().st_size<8*1024**2
        assert sha(f)==h,path
    tools={}
    for name,path,h in [('go',a.go_reader,a.go_reader_sha256),('timeout',a.timeout_reader,a.timeout_reader_sha256)]:
        assert path.is_absolute() and path.resolve(strict=True)==path and not path.is_symlink()
        s=path.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<=256*1024**2 and os.access(path,os.X_OK)
        assert re.fullmatch('[0-9a-f]{64}',h) and sha(path)==h
        after=path.stat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
        tools[name]=dict(path=str(path),sha256=h,bytes=s.st_size,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
    if a.tailscale_amd64_archive is not None:
        # No archive read at preparation; actual collector must prove known exact release hash.
        assert a.tailscale_amd64_archive.is_absolute() and '..' not in a.tailscale_amd64_archive.parts
        plan['archives']['tailscale-amd64']['path']=str(a.tailscale_amd64_archive)
    O.mkdir(mode=0o700);(O/'stage').mkdir();(O/'empty-retention-scan').mkdir()
    for n in ['bindings.py','process-identity.py','collect.py','run.py','run.sh','consume.py']:shutil.copy2(P/'templates'/n,O/n)
    for n in ['resources.json','frozen-tools.json','historical-source-identities.json']:shutil.copy2(P/n,O/n)
    put(O/'association-plan.json',plan);put(O/'host-tools.json',tools)
    put(O/'preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),
        prior_inventory_admission='e73b73b3325f41c392a8eb6e7ddeb105',archive_inputs_read=False,collector_executed=False,
        publication_clearance=False,missing_archive_policy='Explicit gaps; checksum/type/member mismatches fail'))
    protected=sorted({str(Path(r['source_root']).parents[3]) for r in plan['binaries']}|{'/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources','/workspace/tmp/pix541-refresh72','/workspace/tmp/pix-m7-final-inventory-20261015-01'})
    retention=dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=protected,candidates=[],builds=[dict(name='m7-prebuilt-association',terms_bytes={'bounded_metadata_and_margin':1024**3},basis='128 MiB output ceiling plus operating margin. Exact selected inputs read only; no deletion credit or whole-volume classification.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])])
    put(O/'retention-plan.json',retention)
    put(O/'admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-prebuilt-association',profiles=[dict(PROJECT='ROCKNIX',DEVICE=d,ARCH=a) for d,a in [('GENERIC_X64','x86_64'),('H700','aarch64'),('SM8550','aarch64')]],outputs=[dict(path=str(O),kind='qa-scratch',issue=528,release_when='Original bounded association stage consumed and compact evidence retained; publication/source/notice gaps remain separately open.')]))
    put(O/'seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()})
    B['verify'](O)
    print(json.dumps(dict(owner=str(O),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),publication_clearance=False)))
if __name__=='__main__':main()

# #528 bounded offline prebuilt association — UNRUN

This is the next finite collection after accepted final inventory `e73b73b3325f41c392a8eb6e7ddeb105`. It inspects nine selected rclone/Tailscale executables across GENERIC_X64, H700 and SM8550, using 27 exact source/package/staged-image paths. It joins those observations to the four known architecture-specific release archive hashes and Tailscale's already retained source identity. It neither repeats the five-profile inventory nor grants publication clearance.

Current-gap review: `/tmp/pix-m7-current-notice-gaps-20261015/SHA256SUMS`, SHA256 `5dc79bf520e35caf5efc3525300e2f5a1ad799347011c8676e4ee9a9eb469897`. All 18 notice rows remain relevant across 49 profile occurrences. The sole reconstructed archive is SM LLVM22.1.8, not rclone. Current record checkpoint supplied by root: `6a8ff2a3fa94c56267c58241beca205ecfbc18f7`. No live issue read or tracker mutation is part of this packet.

## Exact scope and outcomes

- rclone1.75.2: AMD64 and ARM64 ZIP hashes from the retained #541/#554 binding, compared to exact unpacked binaries already hashed in the final inventory. Known ZIP locators may be absent; that is recorded as `UNAVAILABLE_AT_RETAINED_LOCATOR`, not silently replaced by a download or old rclone1.75.1 source. A present wrong hash/member/type fails.
- Tailscale1.98.8: AMD64 release hash `3a55b590…` and ARM64 `53eb3ce8…`. Final GENERIC inventory's shared-cache ARM64 association does not prove its AMD64 executable. Both `tailscale` and `tailscaled` are at `usr/sbin`, and both are checked. The historical AMD64 recovery receipt has no archive locator: preparation accepts an optional explicitly supplied path, but the collector still requires the known exact release hash. Without that path it records `UNAVAILABLE_NO_RETAINED_LOCATOR`. No search or download occurs.
- The one retained Tailscale source archive `05a91829316e055517a1e84f7b00016846ef4107` is hashed and four exact members (`LICENSE`, `PATENTS`, `go.mod`, `go.sum`) compared to retained custody hashes. Its version-tag source identity remains weaker than a reproducible binary relationship. Missing `vcs.revision` remains missing; `vcs.modified` is retained as observed.
- Nine host `go version -m` calls read the staged executables as data. None of the target executables runs. Exact stdout/stderr, original wait statuses, module/replacement records and build settings are retained. These are metadata observations, not complete embedded-dependency notice collection.
- Archive→unpacked equality is required whenever the matching archive is available. Unpacked→package and package→staged-image equality are separate observations. A byte difference becomes an explicit unresolved derivation gap; recipe stripping alone does not qualify it. Every row explicitly retains the absence of a new independent accepted SYSTEM extraction.
- Final collector status can be `COLLECTED_WITH_EXPLICIT_GAPS`, and successful supervisor/consumer status means only the bounded collection succeeded. It does not mean all associations or notices are resolved. Original inventory and VM/H700/SM producer failures/recovery dispositions remain unchanged; no common RC identity is inferred from mixed f863/9aa engineering artifacts.

## Finite implementation and reuse

`templates/collect.py` adds exact member reads to the prior source-only metadata reader. It uses Python stdlib ZIP/TAR readers without extracting archives, and no glob/walk of input build/cache trees. Four release archives plus one retained source archive are the only archive inputs. Full archive copies, firmware reads, containers, network and target execution are absent.

`templates/run.py` is a one-stage derivative of the qualified final-inventory supervisor. All six `process-identity.py` helper definitions and eight supervisor custody/receipt/signal functions are unchanged. The inherited numeric `/proc/stat` census, PID/start identity checks, pidfd-only descendant signals, subreaper, direct `Popen.wait` receipt handling, error-aware finalizer and no-forced-cleanup qualification remain. Only inventory bindings/stage orchestration/result scope change. `originals/` retains exact predecessor source. `changes.diff` exposes each derivative. No generic runner or cleanup service is introduced.

Each completed Go read publishes its original returncode before later hashing/parsing. If interruption prevents a Go wait receipt, it remains unavailable; the original collector wait and cleanup evidence make the stage nonqualified. On normal completion, every recorded Go wait must be numeric0, every collector/supervisor/outer/launcher/watch channel0, and all owned descendants absent before ordinary consumption. A failed run is kept and investigated; the success-only consumer refuses it. Root must not pre-create launcher-owned receipts.

## Proposed bounds

One collector, 600-second supervisor stage deadline, inherited13-second bounded cleanup, outer630 seconds plus15-second hard-kill allowance. Each Go read has30 seconds plus5-second kill grace; collector also checks a580-second soft read deadline. Two CPUs,2GiB address space,64MiB per outer output file,2MiB per Go stdout/stderr,128MiB owner-output ceiling,1GiB retention allocation including margin. Inputs:256MiB per binary/archive,8,192 members and1GiB declared expansion per archive,10GiB summed named reads. These are conservative proposed ceilings, not measured performance. Capacity/namespace/serialization are checked by existing tools when root allocates; no full-host root-FD claim.

## Root's exact next commands

Before preparation, root supplies actual resolved executable host Go and GNU timeout paths and their SHA256 values. They are required CLI inputs and are hashed at preparation and collection; no guessed future tool digest appears. `go version -m` uses offline environment controls (`GOENV=off`, `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOWORK=off`). This is a data-reading command, not a network sandbox or a target runtime test.

Default fresh owner: `/workspace/tmp/pix-m7-prebuilt-association-20261015-01`. Run the separately named steps only after source review and allocation:

```bash
bash /tmp/pix-m7-prebuilt-association-20261015/commands.sh prepare
bash /tmp/pix-m7-prebuilt-association-20261015/commands.sh preflight
bash /tmp/pix-m7-prebuilt-association-20261015/commands.sh report
bash /tmp/pix-m7-prebuilt-association-20261015/commands.sh admit
bash /tmp/pix-m7-prebuilt-association-20261015/commands.sh launch
# Root supervises at <=60-second intervals and reads original completion channels.
bash /tmp/pix-m7-prebuilt-association-20261015/commands.sh consume
```

Required environment: `TASK_GO_READER`, `TASK_GO_SHA256`, `TASK_TIMEOUT_READER`, `TASK_TIMEOUT_SHA256`; optional `TASK_OWNER` fresh01/02… and `TASK_TAILSCALE_AMD64_ARCHIVE` exact retained archive locator. Missing optional locator is a disclosed gap. Admission uses the frozen GENERIC f863 tools and three explicit profile tuples; it is an ordinary route, not #597 recovery. No collector/import/preparer/VM/test or bulk binary/archive hash has been executed in preparing this source packet.

After the original collection is consumed, root reviews the exact per-row gaps. A proven present ZIP can resolve cache absence for source custody; it cannot by itself resolve corresponding-source, modified-build, embedded notices, independent retrieval or off-host custody. A missing ZIP remains a retrieval/custody gap, while the exact binary's observed hash and Go metadata remain useful independent evidence. The remaining16 non-prebuilt notice rows retain the bounded selected-file/build-flag plan; this packet does not widen them or add a gate.

# Source-only emitter; never imports/executes a prepared collector or runtime helper.
from pathlib import Path
import ast, hashlib, json, shutil, difflib
P=Path('/tmp/pix-m7-prebuilt-association-20261015'); old=Path('/tmp/pix-m7-final-inventory-review-20261015-03')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,j):p.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
plan=json.loads(Path('/tmp/pix-m7-current-notice-gaps-20261015/prebuilt-read-plan.json').read_text())
plan['archives']={}
for component,arch,loc,h,fmt in [
 ('rclone','amd64','/workspace/tmp/pix541-refresh72/rclone-amd64.zip','349ac8fba6ff65d6247043f1750cdcb518ec5d500ef91463a10d37c0ccdf3702','zip'),
 ('rclone','arm64','/workspace/tmp/pix541-refresh72/rclone-arm64.zip','7e1e8d69654941b7b7df84ee74c5f7fb09cce7d5496947fb7bf16b55ff427d10','zip'),
 ('tailscale','amd64',None,'3a55b5900dd7e11e09b6c74d1e46d223d549dfbefbdc1f044a8ab7bdbafb933c','tar.gz'),
 ('tailscale','arm64','/workspace/cache/rocknix-sources/tailscale/tailscale-1.98.8.tgz','53eb3ce89d062fd34e393d24a6c8ec08c769fede8eb77fe9c6e347ad4ae00f84','tar.gz')]:
 version='1.75.2' if component=='rclone' else '1.98.8'; prefix=f'rclone-v{version}-linux-{arch}' if component=='rclone' else f'tailscale_{version}_{arch}'
 members={prefix+'/'+n:None for n in (['rclone'] if component=='rclone' else ['tailscale','tailscaled'])}
 plan['archives'][component+'-'+arch]=dict(path=loc,sha256=h,format=fmt,members=members,version=version,architecture=arch)
for row in plan['binaries']:
 key=row['component']+'-'+row['architecture'];row['archive_key']=key
 row['archive_member']=next(n for n in plan['archives'][key]['members'] if n.endswith('/'+row['binary']))
manifest=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-08-source-custody/git-complete/prebuilt-review/custody-manifest.json')
j=json.loads(manifest.read_text());t=next(x for x in j['components'] if x['component']=='tailscale')
base=Path('/workspace/artifacts/pixelelated-release-sources/m7-prebuilt-aeef83ae3a4de7ebaca3816508e804bf935e87285efdcff6226cb52bd2fc4827')
plan['retained_source_archives']=[dict(path=str(base/t['archive_member']),sha256=t['archive_sha256'],format='tar.gz',commit=t['commit'],
 members={'tailscale-'+t['commit']+'/'+x['path']:x['sha256'] for x in t['notices'] if x['path'] in ['LICENSE','PATENTS','go.mod','go.sum']})]
plan['source_identities']={'tailscale':dict(commit=t['commit'],tag=t['tag'],source_archive_sha256=t['archive_sha256'],scope='Retained version/tag source identity; source-to-binary reproducibility remains unproved'),
 'rclone':dict(commit=None,version='1.75.2',scope='Exact 1.75.2 source commit remains to be resolved from actual metadata; retained 1.75.1 source is historical only')}
for path in [manifest,Path('/tmp/pix-m7-notice-followup-20261015/references/rclone-1.75.2-binding.json'),Path('/tmp/pix-m7-notice-followup-20261015/references/tailscale-amd64-recovery.json'),Path('/tmp/pix-m7-current-notice-gaps-20261015/SHA256SUMS')]:plan['binding_refs'][str(path)]=sha(path)
plan['limits']=dict(binary_file_bytes=256*1024**2,archive_file_bytes=256*1024**2,archive_expansion_bytes=1024**3,archive_members=8192,named_read_bytes=10*1024**3,go_read_seconds=30,go_kill_grace_seconds=5,soft_collect_seconds=580,collector_seconds=600,outer_seconds=630,outer_kill_grace_seconds=15)
plan['scope']='Exact selected source/package/staged image bytes and retained per-architecture archive/Go build metadata only. No target execution, download, complete corresponding-source or independent SYSTEM verification, licence/publication/RC clearance.'
put(P/'association-plan.json',plan)
for n in ['run.py','run.sh','consume.py','process-identity.py','bindings.py']:shutil.copy2(old/'templates'/n,P/'originals'/n)
for n in ['frozen-tools.json','resources.json']:shutil.copy2(old/n,P/'originals'/n)
shutil.copy2(old/'templates/process-identity.py',P/'templates/process-identity.py');shutil.copy2(old/'frozen-tools.json',P/'frozen-tools.json')
source=(old/'templates/bindings.py').read_text();tree=ast.parse(source)
functions='\n\n'.join(ast.get_source_segment(source,n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['sha','load','host_and_serialization'])
text='''"""Bound accepted inventory metadata only; no cache walks or product mutation."""\nfrom pathlib import Path\nimport hashlib,json,os\nCOMMIT = 'f8636de1d105275dbf9420bbabbbc26f79abb10f'\nVM_TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')\n\n'''+functions+'''

def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<20*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    p=load(O/'association-plan.json')
    for name,h in p['binding_refs'].items():
        f=Path(name);assert f.is_absolute() and f.resolve(strict=True)==f and not f.is_symlink() and f.stat().st_size<8*1024**2
        assert sha(f)==h,name
    base=Path('/workspace/tmp/pix-m7-final-inventory-20261015-01')
    result=load(base/'result.json')
    assert result['result']=='PASS_INVENTORY_WITH_PUBLICATION_GAPS' and result['publication_bundle_complete'] is False
    consumed=load('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T093346Z-ed162eab/admission-consumed.json')
    assert consumed['id']=='e73b73b3325f41c392a8eb6e7ddeb105' and consumed['state']=='consumed'
    assert all(type(consumed['original_result'][k]) is int and consumed['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert len(p['binaries'])==9 and len({(r['profile'],r['binary']) for r in p['binaries']})==9
    return p
'''
(P/'templates/bindings.py').write_text(text)
# Narrow one-stage derivative, preserving all eight qualified process lifecycle functions/finalizer.
s=(old/'templates/run.py').read_text();a=s.index("    B = runpy.run_path(str(O/'bindings.py'))");b=s.index('\nexcept BaseException as error:',a)
body='''    B = runpy.run_path(str(O/'bindings.py'))
    assert Path.cwd() == B['VM_TREE']
    B['host_and_serialization'](run);B['verify'](O)
    limits = B['load'](O/'resources.json')
    d=O/'stage';key='association';row={'profile':'selected-prebuilt-association','association_rc':None,'timeout':False,'interrupted':False,'started_utc':utc()}
    rows.append(row);current_row=row
    cmd=['python3','-I','-S','-B',str(O/'collect.py')]
    left=limits['collector_seconds']
'''
# Reuse actual complete spawn/wait code; only dedent one nested level and replace paired stage assumptions.
a1=s.index('            with (d/(key+',a);b1=s.index('            if original_rc != 0',a1)
body+='\n'.join(line[8:] if line.startswith('        ') else line for line in s[a1:b1].splitlines())+'\n'
body+='''    row['finished_utc']=utc();write(d/'result.json',row);current_row=None
    assert original_rc==0 and not row['timeout'],'collector failed; preserve original stage receipt'
    report=B['load'](O/'collection-result.json')
    assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and report['original_collector_exit']==0
    assert len(report['rows'])==9 and report['publication_clearance'] is False
    assert report['target_execution'] is False and report['network_used'] is False
    B['verify'](O);B['host_and_serialization'](run)
    assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=limits['owner_output_ceiling_bytes']
    rc=0
'''
s=s[:a]+body+s[b:]
s=s.replace("O/'profiles'/current_row['profile']/'result.json'","O/'stage'/'result.json'")
a=s.index("    result = dict(utc=utc(), result=")
b=s.index('    try:\n        write(O/\'result.json\'',a)
s=s[:a]+'''    result = dict(utc=utc(), result='PASS_ASSOCIATION_COLLECTION_WITH_GAPS' if rc==0 else 'ASSOCIATION_INCOMPLETE',
        runtime_control_source=B['COMMIT'] if B is not None else None, stages=rows,
        execution_error=execution_error, interrupted_signals=interrupted_signals,
        cleanup_errors=cleanup_errors, receipt_errors=receipt_errors,
        publication_bundle_complete=False, independent_SYSTEM_relation_established=False,
        scope='Bounded offline association collection only; no source/notice, independent SYSTEM, reproducibility or publication clearance; prior producer dispositions unchanged.')
'''+s[b:]
(P/'templates/run.py').write_text(s)
(P/'templates/run.sh').write_text((old/'templates/run.sh').read_text().replace('--as=4294967296 --fsize=134217728','--as=2147483648 --fsize=67108864').replace('9000s','630s'))
put(P/'resources.json',dict(cpu_affinity=[0,1],address_space_bytes=2*1024**3,per_file_bytes=64*1024**2,owner_output_ceiling_bytes=128*1024**2,collector_seconds=600,outer_seconds=630,cleanup_seconds=15,retention_budget_bytes=1024**3,scope='One serialized offline data reader; exact named inputs only; no source/archive copy or deletion credit.'))
put(P/'historical-source-identities.json',dict(tailscale=t,rclone=next(x for x in j['components'] if x['component']=='rclone'),manifest_path=str(manifest),manifest_sha256=sha(manifest),scope='Exact retained historical rows; rclone1.75.1 explicitly does not establish1.75.2 source identity; Tailscale version-tag identity is not a reproducibility claim.'))

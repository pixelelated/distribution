# #528 finite reader/archive locator follow-up

No collector, preparer, Go command, target binary, archive reader, test or network operation ran. The sealed association packet `e818bfa1…` is unchanged. This additive source/metadata packet supplies its two missing preparation locators.

## Reader

Use `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/golang/bin/go`. It is a resolved regular0755 file,12,391,409bytes, uid/gid1000, and its first64 bytes identify ELF64 little-endian EM_X86_64(62). The sibling VERSION says `go1.21.4`. Root owns fresh complete binary/timeout hashing; `host-reader.json` intentionally does not manufacture that digest.

Final accepted GENERIC inventory binds Go1.21.4 archive SHA13b2395f… and host build stamp2c7dea86…. The frozen recipe's `makeinstall_host` copies the host toolchain into `toolchain/lib/golang`, which explains why PATH and `toolchain/bin/go` checks did not find it. Current VERSION, unpack/build stamps, recipe and four relevant source files are individually hash-referenced. This is retained build provenance, not a new independent rebuild proof.

Reader-source compatibility: `src/cmd/go/internal/version/version.go:148` invokes `buildinfo.ReadFile`; `src/debug/buildinfo/buildinfo.go:55` opens the named file as data. The latter supports ELF and both pointer/varint build-info layouts; the stored Go version is a string, without a newer-version refusal. It therefore has the required source capability to inspect these AMD64/ARM64 data files, independent of the reader's own AMD64 architecture. This is a source conclusion; actual binary compatibility remains unrun and must supply the original stdout/status.

`src/cmd/go/internal/cfg/cfg.go:474` discovers a relocated GOROOT from the executable's parent when `pkg/tool` exists (it does here). `src/cmd/go/internal/toolchain/select.go:217` returns for `GOTOOLCHAIN=local` before toolchain Exec. The prepared collector already sets local/offline Go environment values and refuses empty/incorrect architecture metadata. Note that Go1.21's version command can print some read errors without a nonzero return; the collector's nonempty build-info and GOARCH/GOOS checks are therefore meaningful additional gates. No command run is inferred from source inspection.

## Optional AMD64 Tailscale archive

Set `TASK_TAILSCALE_AMD64_ARCHIVE` to:

```
/workspace/artifacts/pixelelated-build-custody/issue-493-tailscale-amd64-20261012/objects/3a55b5900dd7e11e09b6c74d1e46d223d549dfbefbdc1f044a8ab7bdbafb933c
```

The exact October12 source custody manifest SHA792541fd… row478 supplies the locator and archive hash. Current metadata matches its retained device/inode/size/nsmtime/uid/mode:37,099,469bytes, inode126497532, nsmtime1791769678614236938,0664. No archive content was read or rehashed here. The allocated collector must still establish exact archive checksum and both member-to-unpacked relationships; matching metadata is not a substitute.

The historical recovery `c42f9994…` records official AMD64 checksum recovery and old executable equality, while the current shared cache retains ARM64. This separate content-addressed object is the appropriate optional input. The locator search followed the completed retention plan's named source manifest only; it did not traverse the cache or containers.

## Next bounded notice collection

After the prebuilt association originals are consumed, the smallest independent notice-selection stage is **four shader components across eight current profile occurrences**: common(H700), GLSL(H700), RetroPie(GENERIC/H700/SM8550), slang(GENERIC/H700/SM8550). Exact roots/pins/recipe hashes and selected prefixes are supplied in `next-shader-selection.json`, derived from the sealed current inventory selection. No additional whole inventory is needed.

Implement a small derivative of existing notice collector495fb9cb: replace hardcoded old roots and `next(glob())` with these exact selections, keep content-addressed notice retention, and load corrected basis5830ce00. Read only the eight selected package/source roots and three staged shader prefixes. Record each selected file's hash/mode/raw symlink target, complete source-member candidates, relevant included members, scoped notice files and full in-file notice-bearing text; do not decide a licence from filename or a short header. Bound65,536index rows,2MiB/text member,128MiB retained text,600+30seconds with existing watcher/ownership controls. Exceeding a bound must fail explicitly, not omit files.

H700 common and RetroPie overlap `usr/share/common-shaders`: compare both package trees to final selected bytes, retaining both matching origins when identical and unresolved collisions when not. GLSL's `nnedi3/LICENSE` must remain scoped apart from `crt/shaders/crt-royale/LICENSE.TXT`; neither becomes a collection-wide label. GLSL/slang Makefile install mappings must be retained as source metadata, never executed. Common/RetroPie cp-a-minus-Makefile/configure behavior needs no speculative build-flag collection. This avoids the much larger compiled vendor/ZeroTier selection problem in the first supplement.

A staged-image map alone still does not prove the final accepted SYSTEM relation. Either bind an existing exact SYSTEM prefix map or use the existing accepted firmware reader's bounded prefix-read mechanism in a separately reviewed read-only continuation; do not infer it from matching package stamps. Missing members/origins/scoped terms remain explicit. Result should be `COLLECTED_WITH_OPEN_DISPOSITIONS`, publication false; no aggregate licence/legal decision or new release gate. FreeJ2ME/OpenBOR/WildMIDI/HarfBuzz/ZeroTier build-selection and the remaining existing notice rows follow their already identified inputs, without broadening this first shader step. ABL#601 and Doom terms remain separate unresolved items.

This next shader stage is identified only: no collector implementation, traversal or new runtime was performed in this follow-up. Root retains allocation and shared records.

#!/usr/bin/env python3
"""UNRUN next-stage data reader: nine named prebuilts, no target execution/network."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,resource,stat,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--plan-sha256',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--go-reader',type=Path,required=True);p.add_argument('--go-reader-sha256',required=True);p.add_argument('--timeout-reader',type=Path,required=True);p.add_argument('--timeout-reader-sha256',required=True);a=p.parse_args()
started=time.monotonic();total=0

def digest(path,maximum):
    global total
    assert path.is_absolute() and path.resolve(strict=True)==path and path.is_file() and not path.is_symlink(),str(path)
    before=path.stat();assert stat.S_ISREG(before.st_mode) and before.st_size<=maximum,str(path)
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):
            h.update(b)
            assert time.monotonic()-started<590,'reader deadline'
    after=path.stat();assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),'input changed'
    return {'path':str(path),'sha256':h.hexdigest(),'bytes':before.st_size,'mode':stat.S_IMODE(before.st_mode),'device':before.st_dev,'inode':before.st_ino,'mtime_ns':before.st_mtime_ns}

def put(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')

assert digest(a.plan,1024**2)['sha256']==a.plan_sha256
plan=json.loads(a.plan.read_text());assert len(plan['binaries'])==9
assert a.output.is_absolute() and a.output.parent==Path('/workspace/tmp') and not a.output.exists() and not a.output.is_symlink()
for path,wanted in plan['binding_refs'].items():assert digest(Path(path),8*1024**2)['sha256']==wanted,path
host_go=digest(a.go_reader,256*1024**2);host_timeout=digest(a.timeout_reader,8*1024**2)
assert host_go['sha256']==a.go_reader_sha256 and host_timeout['sha256']==a.timeout_reader_sha256
assert os.access(a.go_reader,os.X_OK) and os.access(a.timeout_reader,os.X_OK)
a.output.mkdir(mode=0o700);rows=[];rc=1;error=None
try:
    for index,item in enumerate(plan['binaries'],1):
        row={'selection':item,'files':{}}
        for role in ['source_root','package_file','image_file']:
            f=Path(item[role]);meta=digest(f,plan['limits']['binary_bytes_max']);total+=meta['bytes'];assert total<=plan['limits']['total_binary_bytes_max']
            with f.open('rb') as stream:header=stream.read(64)
            assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==item['elf_machine'],str(f)
            meta['elf_machine']=int.from_bytes(header[18:20],'little');row['files'][role]=meta
        if item['source_binary_expected_sha256']:assert row['files']['source_root']['sha256']==item['source_binary_expected_sha256']
        # Hashes stay distinct when image assembly stripped the upstream binary.
        prefix=f'{index:02d}-{item["profile"]}-{item["binary"]}'
        out=a.output/(prefix+'.stdout');err=a.output/(prefix+'.stderr')
        argv=[str(a.timeout_reader),'--signal=TERM','--kill-after=5s','30s',str(a.go_reader),'version','-m',item['image_file']]
        env={'PATH':'/usr/bin:/bin','GOENV':'off','GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','GOWORK':'off','GOCACHE':str(a.output/'unused-go-cache'),'GOMODCACHE':str(a.output/'unused-module-cache')}
        # Existing host timeout owns its finite reader command. Never execute the inspected file.
        with out.open('xb') as stdout,err.open('xb') as stderr:
            command=subprocess.run(argv,stdout=stdout,stderr=stderr,cwd=a.output,env=env,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(plan['limits']['tool_output_bytes_max'],plan['limits']['tool_output_bytes_max'])))
        row['original_reader_returncode']=command.returncode;row['argv']=argv
        row['stdout']=digest(out,plan['limits']['tool_output_bytes_max']);row['stderr']=digest(err,plan['limits']['tool_output_bytes_max'])
        put(a.output/(prefix+'.json'),row);rows.append(row)
        assert command.returncode==0,'original metadata reader failed or reached timeout; retain status'
        assert digest(Path(item['image_file']),plan['limits']['binary_bytes_max'])==row['files']['image_file'],'binary changed during metadata read'
    rc=0
except BaseException as exc:
    error=type(exc).__name__+': '+str(exc)
finally:
    put(a.output/'result.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COLLECTED_WITH_OPEN_DISPOSITIONS' if rc==0 else 'FAILED','original_stage_exit':rc,'error':error,'plan_sha256':a.plan_sha256,'host_go':host_go,'host_timeout':host_timeout,'rows':rows,'bytes_hashed':total,'elapsed_seconds':time.monotonic()-started,'scope':plan['scope'],'target_executed':False,'network_used':False,'archive_members_compared':False,'independent_system_relation_established':False,'publication_clearance':False,'outputs_held':True,'deleted_bytes':0})
sys.exit(rc)

#!/bin/bash
# UNRUN. Root allocates this small host metadata stage after source/tool review.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-current-notice-gaps-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OUTPUT=${TASK_OUTPUT:?fresh /workspace/tmp output selected by root}
TASK_GO_READER=${TASK_GO_READER:?absolute resolved host Go data reader}
TASK_GO_SHA256=${TASK_GO_SHA256:?root-observed exact host Go SHA256}
TASK_TIMEOUT_READER=${TASK_TIMEOUT_READER:?absolute resolved GNU timeout}
TASK_TIMEOUT_SHA256=${TASK_TIMEOUT_SHA256:?root-observed exact timeout SHA256}
cd "$TASK_TREE"
# Small metadata-only run, no VM/compiler or target execution. Root still owns
# serialization/resource admission decision and original watcher consumption.
tools/watch-build --record-only -- "$TASK_TIMEOUT_READER" --signal=TERM --kill-after=30s 600s \
  python3 -I -S -B "$TASK_PACKET/read-prebuilt-metadata.py" \
  --plan "$TASK_PACKET/prebuilt-read-plan.json" --plan-sha256 9ec39683044d60c1eb3df5312dae485ba67ee5066c32807a3e1b56dd103fca48 \
  --output "$TASK_OUTPUT" --go-reader "$TASK_GO_READER" --go-reader-sha256 "$TASK_GO_SHA256" \
  --timeout-reader "$TASK_TIMEOUT_READER" --timeout-reader-sha256 "$TASK_TIMEOUT_SHA256"

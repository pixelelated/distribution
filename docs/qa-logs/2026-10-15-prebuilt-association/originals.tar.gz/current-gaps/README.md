# Current #528 notice gaps — final inventory reconciled

The next smallest action is one offline read of the nine named rclone/Tailscale binaries on the three main profiles, using host Go only as a data reader. This resolves current version/module/build-setting inputs and exposes the known Tailscale shared-cache association before notice collection chooses source/dependency members. `commands.sh` is the executable, UNRUN handoff after root binds the actual host Go/timeout tools and allocates the small stage. It does not rerun inventory or execute any target binary. The source is new and AST-read only, not runtime-qualified.

Actual inventory run093346Z-ed162eab is ordinarily consumed e73b73b3325f41c392a8eb6e7ddeb105, original command/monitor/runner0; all five profile source/component stages0. Result78270882 is PASS_INVENTORY_WITH_PUBLICATION_GAPS. `selected-current.json` binds all91 recorded input/result references, all18 notice rows,49 actual profile occurrences and exact current package/source/cache identities. No large firmware/source archive is copied. Root retains durable originals separately.

## Current relevance

G = GENERIC x86_64; H = H700 AArch64; S = SM8550 AArch64. H32/S32 are the compatibility ARM profiles. “Present” means a selected component row and image install stamp, not completed source/notices or an automatic source-to-every-installed-file map. Absence is only absence of the component row; it cannot prove no vendored copy occurs elsewhere.

| Existing notice row | Actual selected profiles | Remaining selected evidence |
| --- | --- | --- |
| common-shaders | H | Exact final common-shaders files versus both package/source origins; scoped headers/notices and collisions. |
| enet | G,H,S | Rebind retained exact LICENSE plus actual source/output/consumer mapping; empty AUTHORS is not coverage. |
| freej2me-lr | G,H,S | Actual JAR members/Ant selection and native link inputs; selected JLayer/libsdl4j/ASM/libretro notices. |
| glsl-shaders | H | Exact installed files; nnedi3/LICENSE and crt-royale notices remain scoped, not collection-wide. |
| harfbuzz-icu | G,H,S | Shared harfbuzz14.3.0 source and Meson target/source outputs; per-directory COPYING, not blanket test-font terms. |
| libretro-database | G,H,S | Exact installed cht/cursors/etc. and post-unpack removal of rdb, with attribution. |
| libspeexdsp | G,H,S | Retained COPYING/AUTHORS to actual library/static-consumer map. |
| libxmp-lite | G,H,S | Retained README permission text to current library/consumer map. |
| openbor | G,H,S | Root/engine/tools scope mapped to actual objects/install outputs. |
| opusfile | G,H,S,H32,S32 | All five source/library/handoff maps; retained Xiph COPYING/AUTHORS. |
| rclone | G,H,S | Actual1.75.2 per-arch binary/Go metadata, current source and selected dependency notices; old1.75.1 evidence is historical. |
| retropie-shaders | G,H,S | Exact installed common-shaders prefix and per-file notices; H additionally collides with common-shaders. |
| rocknix-abl | S | Five-file1.2 artifact mapping exists; LinuxLoader e9d37131 implementation/access and applicable notices remain #601. |
| slang-shaders | G,H,S | Exact installed shader/preset/texture member and scoped/in-file notice map. |
| tailscale | G,H,S | Exact final per-arch CLI/daemon identity and Go dependency/replacement data; shared cache filename is not sufficient. |
| wildmidi | G,H,S | Actual CMake WANT_PLAYER/WANT_ALSA/BUILD_SHARED_LIBS and target/install/link selection; library/player notices stay separate. |
| zerotier-one | G,H,S | Effective conditional flags, compile/link/dependency/header inputs and selected ext/nonfree notices; source-directory presence does not prove inclusion. |
| idtech-lr/doom.wad | H,S | Pinned archive identity and staged equality recorded; exact WAD redistribution/notice basis remains unresolved. |

All18 prior rows remain relevant. There is no nineteenth notice row added by this report. The current missing-recipe-field census is smaller—G3, H5, S4, compatibility profiles0—but declarations are not the existing scoped notice/source disposition. Keep the corrected basis5830ce00 and53 retained text-member references; do not recreate an aggregate shader label or treat populated recipe text as closure.

## Archive reconstruction: exact meaning

The single `archive_reconstructed_packages` entry is **LLVM22.1.8 in SM8550 AArch64**, outside these18 rows. It has no unpacked root or unpack stamp. The recorded source archive `llvm-22.1.8.tar.xz` is167061596bytes, SHA256922f1817a0df7b1489272d18134ee0087a8b068828f87ac63b9861b1a9965888, matching both recipe and checksum stamp. Host/target stamp0595bcd7 and three package/SYSTEM library hashes bind retained outputs. This is an identity reconstruction from retained archive/stamps/payload, not reconstruction of the absent unpacked source tree, original build flags, licence completion or an explanation for absence. The exact row is retained in `selected-current.json`; no archive was opened here.

Rclone is separate: all three current rows record the upstream ZIP absent from shared cache because the recipe deletes it. Current unpacked amd64 binary ised7ab1f17876bb006c3df3949a3044959671afd9112362dacaa5dd1647735bc1; H/S arm64 is5aa85195f836e62f76e9dbb94dada612bd08be892f8f4196ec54ed7fee01a3c0. Retained recipe/receipt gives amd64 ZIP349ac8fb and arm64 ZIP7e1e8d69, with historical locators `/workspace/tmp/pix541-refresh72/rclone-amd64.zip` and `rclone-arm64.zip`. Their present existence was not inspected; re-use exact retained bytes if available, not a new download by default. Matching pinned archive hash does not settle source/module notices.

The current GENERIC Tailscale source row names **ARM64 archive53eb3ce8**, just like H/S. This repeats the known shared-name association limitation, not evidence that the installed GENERIC binary is ARM64. Historical recoveryc42f9994 correctly identified amd64 archive3a55b590 and matched replacement15/16 binaries; that is not a final-GENERIC identity proof. The next stage must record current CLI/daemon architecture/hash/build metadata and retain the expected archive identities separately. Do not modify or relabel the accepted inventory; append a precise association supplement after actual comparison.

## Executable smallest next step

`prebuilt-read-plan.json` lists exactly nine binaries and27 source/package/assembly paths derived from the final inventory and frozen recipes. Tailscale paths are both `usr/sbin/tailscale` and `usr/sbin/tailscaled`; the prior general plan's possible usr/bin CLI path is narrowed accordingly. `read-prebuilt-metadata.py` streams hashes and reads ELF headers, then runs only a root-hash-bound host `go version -m <image-file>` under root-hash-bound GNU timeout. It does not run the inspected executable, fetch Go toolchains/modules, evaluate build files or follow unbound links. It preserves original per-command status/stdout/stderr, separate source/package/assembly hashes, timeout failures and all outputs. No invented successful archive/SYSTEM association is emitted.

Bounds:600s outer plus30s kill allowance; each host data-reader30s plus5s kill;256MiB per binary,4GiB total named input hashes,2MiB per command output enforced with RLIMIT_FSIZE; no directory walk, archive read, network or deletion. Root must inspect the source, resolve/hash actual trusted host Go and GNU timeout, choose a fresh `/workspace/tmp` output, and allocate/record/consume this host metadata action through existing rules. No automatic admission or success receipt is generated by the plan. Its output remains COLLECTED_WITH_OPEN_DISPOSITIONS, publication_clearance=false, archive_members_compared=false and independent_system_relation_established=false. Missing files/changed hashes/limit hits fail explicitly.

After those original identities are known, use the existing source/notice collector's small manifest-driven derivative described in `next-selection.md`. No repeat full inventory or generic framework is needed. Root still owns scheduling, source preparation/review, actual tool bindings and any network/custody follow-up.

## Scope of this report

I read completed inventory JSON, frozen recipes and retained textual evidence. I rehashed its completion-evidence files/consumed receipt and joined exact component names; no collector, target, host Go/timeout command, test, archive extraction/download, cache traversal, device/provider action or shared record was run or changed. New reader AST parsed only; no executable/helper import occurred. One attempted documentation locator included a nonexistent wildcard path and returned2; it produced no evidence of absence and was not used in conclusions. Original inventory and historical issue snapshots remain unchanged. This is a technical evidence plan, with no legal/publication clearance.

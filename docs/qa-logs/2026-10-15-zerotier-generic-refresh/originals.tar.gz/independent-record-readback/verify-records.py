from pathlib import Path
import hashlib,json,datetime
OUT=Path(__file__).parent
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
j=lambda p:json.loads(Path(p).read_text())
base=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03/.build-runs')
rows=[]
for tag,runname,owner,rc,evidence in [
 ('build01','20261015T161906Z-85b31cf2','/workspace/tmp/pix-m7-zerotier-generic-build-20261015-01',0,None),
 ('reader01','20261015T162636Z-fde98414','/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-01',1,'/tmp/pix-m7-generic-reader-failure01-20261015/consumption-evidence.json'),
 ('reader02','20261015T163127Z-5682551e','/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-02',0,None)]:
 r=base/runname;o=Path(owner); runner=j(r/'runner-result.json'); consumed=j(r/'admission-consumed.json'); launch=j(o/'launcher-result.json'); ep=Path(evidence) if evidence else o/'consumption-evidence.json'
 assert (runner['command_rc'],runner['monitor_rc'],runner['runner_rc'])==(rc,0,rc)
 assert consumed['original_result']==runner and consumed['state']=='consumed' and consumed['pid_namespace']==4026531836
 assert consumed['source']['head']=='077197e6cd3ea31f33b28aaf3882a694b3423b53'
 assert consumed['run']==str(r) and consumed['submission_owner']==str(o)
 assert consumed['evidence_sha256']==h(ep)
 assert launch['runner_returncode']==rc and (o/'tool-wrapper.rc').read_text()==str(rc)+'\n' and (r/'build.rc').read_text()==str(rc)+'\n'
 assert (o/'run.path').read_text().strip()==str(r)
 verified=[]
 for er in j(ep)['evidence']:
  p=Path(er['path']);assert p.is_file() and p.stat().st_size<8*1024**2,p
  assert h(p)==er['sha256'];verified.append(er)
 rows.append(dict(label=tag,run=str(r),owner=str(o),original_result=runner,launcher_returncode=rc,consumed_id=consumed['id'],consumed_sha256=h(r/'admission-consumed.json'),evidence_sha256=h(ep),verified_compact_evidence=verified))
o=Path('/workspace/tmp/pix-m7-zerotier-generic-build-20261015-01'); br=j(o/'owner-result.json');rr=j(o/'resource-result.json')
assert br['status']==rr['status']=='PASS' and br['cleanup']==br['signals']==rr['errors']==[] and rr['all_threads_exited']
assert set(x['stage'] for x in br['stages'])=={'clean-zerotier-one','build-zerotier-one','image'}
for x in br['stages']:
 assert x['original_host_make_rc']==0 and x['container_observed'] and x['observation_handshake']
 ir=j(o/'stages'/x['stage']/'inner-result.json');assert ir['original_command_rc']==ir['wrapper_rc']==0 and ir['signals']==[]
assert all(not v for v in br['surviving_host_command_groups'].values())
ro=Path('/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-02'); ar=j(ro/'artifacts/result.json');assert ar['status']=='PASS' and ar['runtime_qualified'] is False and ar['zerotier']['dependency_completeness_claim'] is False and ar['zerotier']['dependency_file_count']==0
assert ar['source']=='077197e6cd3ea31f33b28aaf3882a694b3423b53'
for rev in ['01','02']:
 ip=j(Path('/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-'+rev)/'artifacts/inputs.json');assert ip['build_inputs_sha256']==h(o/'build-inputs.json') and ip['source']==ar['source']
jo=Path('/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01'); jr=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T162920Z-33308c8a'); result=j(jo/'result.json'); rr=j(jr/'runner-result.json')
assert (rr['command_rc'],rr['monitor_rc'],rr['runner_rc'])==(0,0,0) and (jr/'build.rc').read_text()=='0\n'
assert result['status']=='PASS_METADATA_ONLY' and result['publication_bundle_complete'] is False and result['archives_opened']==result['source_payloads_opened']==0
for x in result['outputs']:assert (jo/x['name']).stat().st_size==x['bytes'] and h(jo/x['name'])==x['sha256']
seals=[]
for path,known in [('/tmp/pix-m7-zerotier-generic-refresh-20261015','6a12eb2a594f12c5b5251eec482828e131ddd31ee065970475c263c7998be410'),('/tmp/pix-m7-zerotier-generic-readback-plan-20261015-02',None),('/tmp/pix-m7-final-source-assembly-plan-20261015','773dff622bd42731ac2b19040c84dcac609fedc008ae1c5587b5ba06edc59d4e')]:
 p=Path(path);sp=p/'SHA256SUMS';digest=h(sp)
 if known:assert digest==known
 members=[]
 for line in sp.read_text().splitlines():
  expected,name=line.split('  ',1);f=p/name;assert f.is_relative_to(p) and h(f)==expected;members.append(name)
 seals.append(dict(path=path,seal=digest,payloads=len(members)))
pre=Path('/tmp/pix-m7-generic-readback-coordinator-20261015-02')
assert j(pre/'preflight.exit.json')['original_tool_exit']==1 and j(pre/'preflight-after-reclaim.exit.json')['original_exit']==0
receipt=dict(status='PASS_COMPACT_ORIGINAL_RECORD_READBACK',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_runs=rows,source_seals=seals,build_scope='Original three stages, owner/resource/launcher/watcher success; artifact and runtime qualification separate',reader02_result_sha256=h(ro/'artifacts/result.json'),reader02_scope=ar['scope'],runtime_qualified=False,dependency_completeness_claim=False,metadata_join={'run':str(jr),'original_result':rr,'result_sha256':h(jo/'result.json'),'result':result},initial_preflight=1,after_reclaim_preflight=0,large_payloads_read=False,live_process_or_container_census=False,swap_reclaim='Parent transcript observation only: helper hash prefix acfb, /swap.img success, 8388604 KiB free; no original reclaim-command receipt supplied or manufactured.')
(OUT/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'receipt_sha256':h(OUT/'record-readback.json'),'original_runs':len(rows)+1}))

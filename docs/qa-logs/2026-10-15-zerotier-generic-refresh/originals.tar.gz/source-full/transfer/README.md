# GENERIC ZeroTier cache custody — immutable source packet, unrun

Exact source:077197e6cd3ea31f33b28aaf3882a694b3423b53, published by root. Root already created the clean destination checkout `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03`, branch `build/m7-p5-20261015-03`. Only its `build.pixelelated-GENERIC_X64.x86_64` destination must be absent. This packet did not create the checkout, allocate, survey processes, move anything or run an admission.

Source is `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/build.pixelelated-GENERIC_X64.x86_64`, old commitf8636de1d105275dbf9420bbabbbc26f79abb10f. Single atomic `renameat2(RENAME_NOREPLACE)` from the accepted existing adapter; no copies, hardlinks, symlink alias, overwrite, fallback or rollback. Device/inode must be unchanged. The old tracked source, target and immutable receipts remain. The concrete accepted predecessor is `/workspace/tmp/pix-m7-next-cache-transfer-20261015-02/transfer-result.json`, run20261015T035306Z-b0f999e1. This is explicit stopped-cache ownership transfer following that accepted no-duplication precedent; device-builds' normal independent-copy recipe is not being silently reinterpreted.

Current producer e8ed7da80b97410086485381fb175702 stays `failed-investigated/reporting-failure`, qualificationfalse, original launcher returnunknown. Its actual four completed package/image stages were0; independent artifact acceptance8a98fa7142a045539d3755338c1da2ed qualified that artifact scope. `predecessor-binding.json` seals exact original receipts. The transfer validates both scopes instead of requiring or inventing a successful combined producer.

Source-proof root reports consumed73fc and its GENERIC cache dependency closed. This source-preparation lane also has no remaining old-cache content reader. Root must still explicitly resolve all other prepared consumers and obtain a fresh actual-host census and assessment. Original dependency assessor scope and age≤900s remain; this packet makes no current process-absence claim.

Commands below are intended for root's actual-host controlled execution, not source review. They make only the transfer owner/plans then follow existing preflight/report/admission/submit/consume mechanisms. The transfer owner must be fresh. No build is launched here.

```bash
TASK_PACKET=/tmp/pix-m7-zerotier-generic-refresh-20261015/transfer
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03
TASK_TRANSFER=/workspace/tmp/pix-m7-zerotier-generic-transfer-20261015-01
TASK_COMMIT=077197e6cd3ea31f33b28aaf3882a694b3423b53
TASK_ES_RECIPE_SHA=1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
mkdir -m 700 "$TASK_TRANSFER"
cd "$TASK_TREE"
tools/build-preflight
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" --expected-es 16dbac5211eea7e70db7394372033be2be7df829 --measurement "$TASK_PACKET/capacity-measurement.json" --owner "$TASK_TRANSFER" --stage transfer
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_TRANSFER/retention-plan.json" --output "$TASK_TRANSFER/retention-report.json"
tools/watch-build --record-only -- python3 -I "$TASK_PACKET/dependency-readback.py" --output "$TASK_TRANSFER/dependency-readback.json"
```

Root reviews original census errors/exemptions and prepared consumers before writing `dependency-assessed.json`, using the existing schema demonstrated by `/workspace/tmp/pix-m7-next-cache-transfer-20261015-02/dependency-assessed.json`: actual host namespace, original observation epoch (never refreshed), root/device/inode, raw readback path/hash, original errors and justified exemptions, resolved prepared consumers, no process matches/remaining consumers/active admissions, Docker mount observations and explicit scope. Transfer checks `status=CLEAR_WITH_STATED_SCOPE`, `root_identity`, `utc_epoch`, `prepared_consumers_resolved`, `process_matches`, `remaining_consumers`, `active_admissions`, `docker_all_mounts`. A historical CLEAR record is not reusable.

```bash
TASK_DEPENDENCY=$TASK_TRANSFER/dependency-assessed.json
TASK_DEPENDENCY_SHA=$(sha256sum "$TASK_DEPENDENCY")
TASK_DEPENDENCY_SHA=${TASK_DEPENDENCY_SHA%% *}
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_TRANSFER/admission-plan.json" --output "$TASK_TRANSFER/admission.json"
tools/watch-build-submit --owner "$TASK_TRANSFER" -- --admission "$TASK_TRANSFER/admission.json" --activity-dir "$TASK_TRANSFER" -- python3 -I "$TASK_PACKET/transfer-cache.py" --owner "$TASK_TRANSFER" --commit "$TASK_COMMIT" --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" --dependency-readback "$TASK_DEPENDENCY" --dependency-sha256 "$TASK_DEPENDENCY_SHA"
```

After the actual launcher is finished, root reads originals: `transfer-result.json`, `cache-ready.json`, inner.rc0; runner command/monitor/runner0; original launcher-result runner_returncode0 and tool-wrapper.rc0; same old/new device/inode; old cache absent; unchanged old target/source; no recorded owner survivors. Do not write launcher-owned receipts. Prepare a new `consumption-evidence.json` from those originals, matching the actual admission outputs, then:

```bash
TASK_TRANSFER_RUN=$(cat "$TASK_TRANSFER/run.path")
python3 -I tools/host-maintenance/build-admission consume --run "$TASK_TRANSFER_RUN" --evidence "$TASK_TRANSFER/consumption-evidence.json"
```

The existing consumer checks original terminal watcher/launcher channels and process/group absence. Failure remains failure; no build follows until successful transfer consumption. The sibling build packet will additionally require the actual consumed transfer SHA. This sealed transfer directory must not be edited while root is using it.

The125,726,416,896B cache measurement is the original completed producer's final sample, with original log SHA/time and24-hour age guard, not a new scan/current-occupancy assertion. Transfer reserves only existing custody/margin allowance, never a duplicate cache or speculative deletion credit. The new cache is retained only for the immediately queued ZeroTier package/image/readback and corresponding-source proof; old firmware remains only while named immediate clean/upgrade consumers need it. Subsequent retirement follows existing D-INFRA-022 workflow. No old image or receipt is deleted here.

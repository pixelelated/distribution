# GENERIC ZeroTier package/image refresh — executable source packet, unrun

This packet binds published source `077197e6cd3ea31f33b28aaf3882a694b3423b53`, ZeroTier recipe `b876990db897995a230330a78704e16ad881e5424f6ff172fee9d7f2203a1aba` and patch `5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5`. Root created the clean new checkout `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03` on `build/m7-p5-20261015-03`. Source preparation here did not run a preparer, dependency survey, admission, transfer, build, artifact reader, test or VM. Only `/tmp` source files were written and Python AST / shell syntax were checked.

The independently sealed `transfer/` subpacket is the execution authority for the cache move. Its SHA256SUMS seal is `24587f39a81d92a93d8606c3e3c4a02edf854a17b1d182837cf804aa97b438f8`; it remains unchanged while the following build/readback sources were completed. Read its README for exact transfer commands, failure-preserving predecessor binding, fresh consumer closure and atomic-rename precedent. Do not execute the root-level transfer copies in preference to that released subpacket.

## Scope and inherited mechanisms

The existing accepted owner now runs three canonical stages: `PACKAGE=zerotier-one make docker-package-clean`, `PACKAGE=zerotier-one make docker-package`, then non-DIRTY `make docker-GENERIC_X64`. Only the new cache's `.stamps/image/build_target` is explicitly removed before image assembly. No old Dolphin/ES clean/rebuild list is retained. Standard image housekeeping and normal matching cache reuse remain.

The predecessor source is f8636de1d105275dbf9420bbabbbc26f79abb10f. Its product delta to077197 is exactly the ZeroTier recipe/patch plus the already accepted, unselected-on-GENERIC ABL checksum correction. The final product delta from2426f88 is exactly the two ZeroTier paths. ES16dbac and the existing Dolphin pin/recipe remain bound. Extra product changes or another commit require a newly reviewed packet.

Reuse the original build-owner/inner-build/host-resources implementation, pinned builder988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39, nonroot actual UID/GID, canonical stable container checkout `/workspace/repos/rocknix.worktrees/m7-pixelelated`, shared source cache and main `.git` mount. The package stage keeps the original4CPU/24GiB ceiling and image24CPU/40GiB ceiling;7200s family bound,2048PID/no-swap container limits, host8GiB RAM/64GiB volume floors, real mktemp, nonce/CID handshake, resource sampling and bounded original cleanup are unchanged. These are inherited operating bounds, not new measured ZeroTier requirements. Do not extend an in-flight bound.

`prepare-owner.py` and `build-owner.py` now also bind the actual consumed cache-transfer receipt by hash. A cache-ready summary without consumption is insufficient. The old cache producer's #597 reporting-failure disposition remains unchanged in the sealed transfer originals; no prior launcher receipt is reconstructed.

Root has since completed transfer20261015T161403Z-91c45da4, all original channels0, consumedca5afc3cd3184396a56e9bcae9990cf0. `actual-transfer-binding.json` records its exact original hashes. The build preparer requires those actual cache-ready and admission-consumed bytes; it does not merely accept any later PASS.

## Build commands after successful transfer consumption

These commands are for root's actual-host supervised execution after source review. The owner paths must be unused. The supplied sources are not themselves admission receipts and no completed result is prefilled.

```bash
TASK_PACKET=/tmp/pix-m7-zerotier-generic-refresh-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03
TASK_TRANSFER=/workspace/tmp/pix-m7-zerotier-generic-transfer-20261015-01
TASK_BUILD=/workspace/tmp/pix-m7-zerotier-generic-build-20261015-01
TASK_COMMIT=077197e6cd3ea31f33b28aaf3882a694b3423b53
TASK_ES_RECIPE_SHA=1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
cd "$TASK_TREE"
# Optional normal successful transfer consumer if root has not already consumed it:
# python3 -I "$TASK_PACKET/consume-stage.py" --owner "$TASK_TRANSFER" --stage transfer
mkdir -m 700 "$TASK_BUILD"
tools/build-preflight
TASK_TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)
python3 -I "$TASK_PACKET/prepare-owner.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" --expected-es 16dbac5211eea7e70db7394372033be2be7df829 --owner "$TASK_BUILD" --cache-ready "$TASK_TRANSFER/cache-ready.json" --timestamp "$TASK_TIMESTAMP" --family-seconds 7200
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" --expected-es 16dbac5211eea7e70db7394372033be2be7df829 --measurement "$TASK_PACKET/capacity-measurement.json" --owner "$TASK_BUILD" --stage build
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_BUILD/retention-plan.json" --output "$TASK_BUILD/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_BUILD/admission-plan.json" --output "$TASK_BUILD/admission.json"
tools/watch-build-submit --owner "$TASK_BUILD" -- --admission "$TASK_BUILD/admission.json" -- python3 -I "$TASK_BUILD/build-owner.py"
```

Actively supervise the original watcher and launcher to actual completion. Submission return is not final wait status. Do not write `tool-wrapper.rc`, `launcher-result.json` or any other producer-owned output. After all originals are complete:

```bash
python3 -I "$TASK_PACKET/consume-stage.py" --owner "$TASK_BUILD" --stage build
```

This narrow derivative of the existing `consume-stage.py` checks actual runner/launcher/build rc0, owner/resource PASS, the exact three stage originals, source admission, completed PID identity, recorded process groups and retired exact container IDs. It creates only a completion-evidence record and invokes the frozen checkout's normal build-admission consumer, which independently verifies terminal watcher/launcher and process absence. A nonzero/missing channel stops this route for normal investigation; no failure is relabelled qualified.

## Existing artifact reader, rebound to the new build

The accepted full GPT/raw-image/update-payload reader is retained: bounded decompression and GPT CRC, raw/update SYSTEM+KERNEL equality, syslinux boot configuration, exact source/build identity, selected installed byte/mode/link mappings, immutable Dolphin Sys resources, and GENERIC Steam-installer exclusion. No target binary executes.

The installed reader tool hash is rebound to the actual final-source checker `65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6`, already separately accepted in the H700/SM8550 artifact continuations; the old f863 reader's6d061af8 literal would incorrectly reject this final source. No checker tool is edited here.

Added ZeroTier readback is limited to the changed package: absent `nonfree` tree, exact accepted patched `service/OneService.cpp` hash, bounded actual `.d` inventory rejecting a nonfree dependency, x86_64 ELF header, package-install→image-staging→independently extracted SYSTEM equality for the daemon/CLI/idtool and shipped helper/service. It records actual installed hashes and does not require equality to the isolated dd84354a compile. The earlier113-unit isolated dependency proof remains separate; this finite inventory is not a replacement or a claim to reconstruct assembly compilation.

Readback retains existing CPU0/8GiB address space/16GiB single-file/1500s+15s bounds and24GiB payload/records plus8GiB margin. Only after the new build is actually consumed:

```bash
TASK_READBACK=/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-01
mkdir -m 700 "$TASK_READBACK"
python3 -I "$TASK_PACKET/prepare-readback.py" --owner "$TASK_READBACK"
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_READBACK/retention-plan.json" --output "$TASK_READBACK/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_READBACK/admission-plan.json" --output "$TASK_READBACK/admission.json"
tools/watch-build-submit --owner "$TASK_READBACK" -- --admission "$TASK_READBACK/admission.json" -- bash "$TASK_READBACK/run.sh"
# After actual original watcher/launcher completion:
python3 -I "$TASK_PACKET/consume-stage.py" --owner "$TASK_READBACK" --stage readback
```

The small readback preparer materializes the same accepted plan/reader formats with actual build run, build-inputs SHA, consumed-receipt SHA, source and timestamp. The reader independently checks those exact bindings and actual original producer channels. Fresh empty artifacts and owner files are required. No target firmware hashes or completion receipts are guessed.

Can this be verified on the VM? Installed behavior: yes; this packet performs only the build and artifact prerequisite. Root then binds the existing affected clean-install and retained-storage VM checks to the actual new image. No broad runtime replay, provider join/account operation, ARM result, physical action, RC/publication claim or source-delivery waiver follows here.

## Capacity and retirement

`capacity-measurement.json` preserves the original completed engineering02 final allocation sample, original log hash/time and24-hour age guard. It is not a fresh scan or unchanged-occupancy assertion. Current preflight/admission and the unchanged owner resource monitors enforce actual capacity during execution. If the age/material-change guard fails, use the existing measurement workflow; do not fabricate a timestamp or count future deletion as capacity.

No cache was cloned. The transferred cache is retained for the immediately queued new package/image/readback and corresponding-source dependency. The old firmware/source receipts remain unchanged; old large firmware and generated scratch survive only while named immediate clean/upgrade/source verification needs them. Use the existing retention workflow to retire superseded payloads once those dependencies close, preserving compact source/licence/manifests/originals (D-INFRA-022). This source packet deletes nothing and introduces no persistent second cache.

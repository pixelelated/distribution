## Current source and notice status — 2026-10-15 16:35 UTC

Published source077197e6 now has a successful GENERIC_X64 ZeroTier package/image build (161906Z-85b31cf2, all originals0, consumed19ebce6dd8e44b299ad7abd74ff3600b) and independent image verification (163127Z-5682551e, all originals0, consumed ee024372b00f4314afa9fc96495b83de). Build took217.252 seconds. GPT/raw/update SYSTEM+KERNEL equality, clean source identity, selected package/install/SYSTEM bytes/modes/links and exact filtered ZeroTier source pass. These are engineering artifacts, not a public RC.

Reader01 remains failed1/0/1 and consumedf57142e9fc6842f7b29a4f0b061b6fcc: it incorrectly expected .d files emitted only by the earlier isolated diagnostic compile. Reader02 explicitly distinguishes canonical no-dependency-record output; the existing113-unit isolated proof remains separate. No build rerun was needed. The guarded installed swap helper completed before reader02; fresh preflight passed.

Next: focused clean-install and retained-storage VM proof, then H700 and SM8550 native package/image refresh and independent artifact verification using stopped warm caches. Both ARM companion profiles omit ZeroTier. No unrelated or FEX/Nix rebuild. Can this be done on the VM? **Yes**: actual installed ZeroTier service/CLI startup, local API, restart/stop and retained identity/configuration under an isolated no-NIC guest; no provider join/account needed. Keep unchanged component qualification evidence and all original failure channels.

The metadata-only source join162920Z-33308c8a passed:2366 original component rows,16 shared-source edges and two ARM companion links. It names39 remaining held-file custody copies totaling293582752B; no payload or archive was opened. All eight FEX archives, exact Nixpkgs tree, twenty held patches, two normalized patches, Koko editing sources and additive/Tailscale custody remain accepted. Complete applicable source/notice assembly, current image/profile bindings, independent retrieval and off-host custody remain separate.

Exact legacy ABL implementation and one MAME adaptation remain the two source questions. Both prepared upstream requests await the existing approval; no contact has occurred. Durable drafts: docs/qa-logs/2026-10-15-source-contact-drafts/. OpenABL remains separate#601. #603 primary review passed67 criteria; exact external Fable/OpenRouter transfers await the existing separate answer. Both077197 wordlists passed; record CI38766203570 failed only audit cadence. All five criteria below remain open; no deployment or RC designation.

---

## Historical source and notice status — 2026-10-15 15:08 UTC

Koko editing-source acquisition and local custody are complete: all five exact source objects (47,056,031 bytes), four XCF archive listings, the named export note and three-profile asset/source/notice mappings are retained. The broad shader classification is resolved under the previously selected distribution scope; one uncertain MAME adaptation remains.

All eight current FEX header-source archives are now held and match their selected checksums (270,251,656 bytes). The final four-source run145813Z-213c4a9b passed every original result channel and is consumed. The five prior failed runs remain recorded with their successful partial downloads preserved. No completed archive was downloaded again. The exact Nixpkgs snapshot (195,961,000-byte canonical NAR) and twenty patches passed separate local custody run150157Z-c3055ad7; its admission is consumed. The existing libglvnd archive reproduces the selected recursive hash without another download. Two exact normalized patch outputs remain to be acquired and verified; complete notice/source assembly and delivery remain separate.

The selected ZeroTier client excludes controller objects but unconditionally includes three nonfree headers. A one-file candidate guards those includes and pointer lifetimes using the existing controller macros. Its isolated compile attempt stopped before the compiler because the diagnostic extractor expected21 excluded entries while its exact bound index contains22. Original1/0/1 outcomes, clean container/process closure and failed-investigated consumption are retained. A fresh corrected helper is being prepared; the product candidate is not yet compilation-qualified or integrated. No feature removal or publication clearance is inferred.

ABL's selected binary still needs an accessible source locator for LinuxLoader e9d37131c0c2273076468156fb0f87aa6834202b and its exact recursive inputs/build instructions. OpenABL remains a different candidate. No source-owner contact is authorized or performed. JLayer and Doom finite notice findings are retained with their specific scope; historical evidence is unchanged.

Can this be done on the VM? Current work is host source custody and an isolated GENERIC_X64 compiler check, with no target execution or physical-device fact. Existing accepted VM/H700/SM engineering qualification remains unchanged. Finish the finite gaps and exact source/notice assembly, then independent retrieval/off-host custody and the existing downstream handoff. All five publication criteria below remain open.

#603's67 primary criteria are complete; its specifically requested external Fable/OpenRouter transfers still await their separate answer. At published2426f88 both wordlist checks passed; record38748205134 failed only audit cadence (16completed closures against threshold12). #604 remains a later helper correction outside the frozen audit packet. No new device transfer, public RC designation or release publication.

Evidence: docs/qa-logs/2026-10-15-koko-editing-source/, fex-source-continuation04/, fex-source-continuation05/, fex-source-continuation06/, fex-libglvnd-reuse/, fex-held-source-custody/, final-notice-scope/, zerotier-header-candidate/ and zerotier-compile-failure01/ (all dated2026-10-15). The compiled result remains pending.

---

## Historical source and notice status — 2026-10-15 13:49 UTC

#604 is closed completed after the published reader correction, 25 controls, full 18,523-mapping pass and retained original failure/success evidence. The shader review now resolves the broad classification work: include the 68 exact CC-BY-NC-SA members under the settled noncommercial scope (D-WORKFLOW-084/097/131), with full attribution, applicable license versions and modification/ShareAlike notices. Include the four identified Koko JPEGs with their supplied GPL subproject source/notices; missing individual sidecars are not four new approval gates. Named editing-source custody and one uncertain MAME adaptation remain. D-INFRA-016 remains scoped to observability.

FEX source acquisition is incomplete. The first run verified Linux 6.16.7 (152,673,392 bytes), then stopped on libdrm's connection reset. The seven-source continuation reverified held Linux but stopped before contacting an unlisted GNU redirect mirror: original curl0/HTTP302, 166-byte response, zero newly completed archives. Both collector runs retain original command/monitor/runner1/0/1, clean process exit and ordinary failed-investigation consumption. A fresh direct-GNU-route continuation is being prepared; no retry or complete acquisition is claimed. Exact Nixpkgs/libglvnd/patch custody remains separate; normalized fetchpatch hashes and recursive NAR hashes must not be checked as raw HTTP-body hashes.

ABL's selected binary is specifically tied to LinuxLoader e9d37131c0c2273076468156fb0f87aa6834202b. The package repository contains packaging, not that implementation. The bounded exact public commit search returned zero results; this is not proof of worldwide absence. OpenABL is a different candidate, not corresponding source for the selected binary. Accessible exact implementation, recursive inputs and build instructions remain needed; no source-owner contact or replacement adoption is claimed.

Completed additive and Tailscale source custody remain accepted. Complete source/notice materialization, independent retrieval and off-host custody still hold the five criteria below. Can this be done on the VM? This is host source inspection/acquisition/custody; no target execution, physical-device fact, personal cloud operation or device mutation is involved. Existing engineering firmware qualification remains unchanged.

#603's 67 primary criteria remain complete; the exact separately requested Fable/OpenRouter transfers await approval. At published7ef32024 both wordlist checks passed; record38741103629 failed only outstanding audit cadence. #604 is a later helper correction outside that frozen audit packet. No RC or publication clearance.

Evidence: docs/qa-logs/2026-10-15-shader-helper-closure/, shader-notice-disposition/, shader-provenance-followup/, shader-distribution-disposition/, abl-source-locator/, fex-source-acquisition/ and fex-source-continuation/ (all dated2026-10-15).

---

## Historical source and notice status — 2026-10-15 13:05 UTC

The shader-attribution correction passed all 25 focused controls and the complete bounded pass: eight records, 20,018 reported rows, 18,523 physical mappings, 8,062 distinct source members and 2,738 notice nodes. Original command/monitor/runner/launcher results are zero; no owned processes remain, and ordinary admission consumption completed. #604 preserves the failed first attempt separately. The 6,273 heuristic review entries are triage records, not 6,273 independent permission decisions; exact retained notice families are now being reviewed.

Tailscale dependency custody is complete: 89 source ZIPs, 89 member indexes, 130 notices and exact component/binary maps were independently copied and verified in a fresh immutable source supplement (314 files, 169,377,272 bytes). All original result channels are zero and the admission is consumed. This uses the prior accepted h1 result and verifies complete copied ZIP hashes without decoding or downloading again. Raw download streams and signed redirect URLs are excluded. Existing additive custody remains unchanged.

FEX now has all 13 generated sources, accepted ELF dependency readback and 13 exact selected header notices retained. The runtime ArchLinux rootfs is separate from the Nix build sysroot; no unspecified guest rootfs or whole compiler closure is added as a source gate. Eight selected header-source archives have exact acquisition identities; three other source archives match historical custody. Nixpkgs/libglvnd tree and applied-patch custody remain specifically scoped. Doom's exact data notice and version association are retained with the vendor-document limit recorded separately.

Can this be done on the VM? This is host source/artifact inspection and custody; no physical fact, device/cloud mutation or target execution is involved. Existing engineering qualification remains accepted. Remaining component dispositions, complete source mapping, independent retrieval and off-host custody still hold the five publication criteria below. #603's 67 primary criteria remain complete; the exact requested external transfers still await approval. Both ef95 wordlists passed; record CI fails only audit cadence.

Current evidence: `docs/qa-logs/2026-10-15-shader-attribution-accepted/`, `2026-10-15-shader-attribution-failure/`, `2026-10-15-tailscale-source-custody/`, `2026-10-15-fex-source-disposition/`, `2026-10-15-fex-dependency-disposition/` and `2026-10-15-doom-input-disposition/`.

---

## Historical source and notice status — 2026-10-15 12:55 UTC

Additive custody is complete: both current distribution source maps, current EmulationStation, the two changed cache inputs and rclone source/vendor archives are retained. Its 2,366-row component map covers 606 archive inputs and 43 Git roots, with historical custody reused by exact reference. The accepted 89 Tailscale source ZIPs are being prepared for the same durable source-custody arrangement; no new download is needed.

All 13 generated FEX guest-thunk sources are now retained, and passive readback matched all 13 accepted ELF hashes. Actual dynamic names are libstdc++.so.6 for all 13, plus libX11.so.6 for GL and libGL.so.1 for EGL. Runtime-provider and selected header/source notice disposition remains separate from the build-tool closure. The exact Doom WAD is associated with 1.9 shareware and contains an affirmative free-distribution notice; the referenced vendor document remains a specific question for disk vending or charged bundles, rather than an engine-GPL inference.

The first shader-attribution pass stopped on identical duplicate self-notice records; original 1/0/1 results and successful cleanup/failed-investigated consumption are preserved. #604 owns comparing full identity/reference equality, preserving original provenance and refusing conflicting duplicates before a fresh bounded analysis. No firmware changed.

Can this be done on the VM? These are host-side reads and custody of immutable source/artifact evidence; no physical fact, target execution, device mutation or personal cloud operation is involved. All five publication criteria below remain open. Existing engineering qualification is unchanged. Specific remaining terms, complete source mapping, independent retrieval and off-host custody still precede publication.

#603's 67 primary criteria remain complete; its exact external transfers await the existing separate approval request. Both ef95 wordlists passed and record CI failed only the outstanding audit cadence. Evidence: `docs/qa-logs/2026-10-15-additive-source-custody/`, `2026-10-15-fex-source-disposition/`, `2026-10-15-doom-input-disposition/` and `2026-10-15-shader-attribution-failure/`.

---

## Historical source and notice status — 2026-10-15 12:31 UTC

Tailscale's 89 selected dependency ZIPs are acquired and each matches the checksum embedded in the accepted binaries. The watched collection completed in 50.952 seconds with all original result channels zero and no surviving owned process; its single-use admission is consumed. All 89 modules have retained notice candidates (130 texts, 528,430 bytes), and all previously retained notice bytes match the selected ZIPs. This resolves the 18 tag-version exceptions and previous notice-locator gaps. Source response bodies remain held outside Git; private raw download streams stay outside the repository, with hashes and redacted records retained.

The remaining-component decision table resolves current shader origins, HarfBuzz library/test-font scope, OpenBOR notices, both shipped WildMIDI branches and the declared ZeroTier controller-object selection. These findings support complete applicable source/notice inclusion; missing historical expanded flags are not a new universal rebuild gate. FreeJ2ME's JLayer, ASM and libretro notices are now retained; libsdl4j is a README credit with no identified selected payload. The inherited JLayer MPEG wording, shader member/asset terms, ZeroTier header publication scope, Doom data terms and ABL implementation source remain specific questions.

Next is additive custody for the changed distribution/ES source and two changed cache archives, including held rclone source/vendor archives; completed historical sources are reused by exact reference. In parallel, current FEX generated/guest-thunk source mapping and shader attribution are being prepared from accepted evidence. OpenABL has a concrete public source locator under #601, but has not been adopted or treated as corresponding source for the current ABL binary.

Can this be done on the VM? This is host artifact/source inspection and custody, with no physical fact or device/cloud mutation. The accepted engineering artifacts remain unchanged. #603 primary audit covers all 67 literal criteria; its exact external transfers still await the separately requested approval. All five existing publication criteria remain open until their complete evidence is available. Independent retrieval and off-host custody are still required.

Evidence prepared for the next checkpoint: docs/qa-logs/2026-10-15-tailscale-source-acquisition/, remaining-notice-disposition/, freej2me-vendor-notices/ and source-scope-followup/.

---

## Historical source and notice status — 2026-10-15 11:50 UTC

The notice supplement is complete: all 43 component/profile occurrences are retained, including the 38 prior completed records and five newly collected records. Original collector, command, monitor, runner and launcher exits are zero, and the successful admission is consumed. The earlier failures remain separately recorded, including the third attempt's output-bound breach. The corrected continuation checked its bound before writes and stayed within it.

Current notice/source rebinding is accepted for enet, libspeexdsp, libxmp-lite and opusfile: 14 profile records, 57 positive library file/link matches and eight exact notice texts. Their disposition is conservative inclusion of complete component source, recipe/patch inputs and full notices. Missing historical consumer-link detail is informational for this treatment; it is not an added universal rebuild gate. Final bundle materialization and delivered notices still remain.

Both official rclone 1.75.2 source/vendor archives are now retained and hash-verified (34,770,062 bytes total). All 242 selected dependency versions match the vendor manifest and have retained notice candidates. This closes acquisition and selected-version matching, not the unknown upstream dirty-file list or full release-source clearance. Tailscale dependency and notice reconciliation continues against exact selected versions.

Can this be done on the VM? This is bounded host-side inspection of accepted artifacts and public source; no physical fact, device mutation or personal cloud operation is involved. The independent audit's primary phases now cover all 67 criteria; its exact external blind/refutation transfers await the separately requested approval. Component dispositions, complete source mapping, independent retrieval and required backup custody remain under the existing five criteria. None is waived or marked complete here.

Evidence: docs/qa-logs/2026-10-15-notice-supplement/accepted/, notice-supplement/disposition/ and docs/qa-logs/2026-10-15-prebuilt-source-collection/.

---

## Historical source and notice status — 2026-10-15 11:22 UTC

The selected prebuilt derivation check passed: stripping each of the nine release-binary copies reproduces its packaged and staged bytes, with original inputs unchanged. Primary upstream metadata supports rclone's exact release base and all 242 embedded dependency tuples, and Tailscale's main-source identity. Rclone's exact dirty-file list remains unknown; Tailscale has 18 selected dependency-version exceptions to its tag metadata and 15 selected module names absent from the upstream notice report. These are precise remaining reconciliation items, not a new universal rebuild requirement.

Next: retain the two already-published rclone source/vendor archives (about 35 MB) and reconcile selected dependency notices. The non-prebuilt notice collector has 38 completed records retained. Its third attempt stopped on a regular-file wildcard handling defect and also exposed aggregate output accounting that ran too late. Both failures remain recorded; a narrow continuation will reference the completed records, enforce the storage bound before writes, and process only five remaining records. No completed database or shader collection will be repeated.

Can this be done on the VM? These are bounded host-side reads of accepted artifacts and public source archives; no physical device fact or personal cloud operation is needed. Source collection grants no publication clearance. The independent completed-work audit continues in parallel under #603. Component dispositions, complete source mapping, independent retrieval and required backup custody remain open under the existing five criteria below.

---

## Current prebuilt association — 2026-10-15 10:26 UTC

Updated **2026-10-15 10:26 UTC**. The bounded offline prebuilt collection101845Z-84e4a2bc completed with all original channels0 and nine metadata-reader exits0, then ordinary consumption09ce2e41. All four rclone1.75.2/Tailscale1.98.8 architecture-specific release archives are present and hash-correct; all nine archive members match unpacked binaries, and all nine packaged copies match the staged image. All unpacked/package pairs differ: the next narrow check is private-copy stripping derivation. rclone records revisionbe8d6044 and vcs.modified=true; Tailscale lacks an embedded revision. These observations do not establish complete corresponding source, embedded notices, independent SYSTEM extraction or publication clearance. Exact compact evidence: docs/qa-logs/2026-10-15-prebuilt-association/.

#349 is closed completed after the accepted installed restore proof and published same-model guide in websitePR4/main6aac689c. #563's resource/VM/audit criteria4/5 are checked; source and physical/native clauses remain open. #576 is correctly deferred Backlog with no milestone, preserving all unproved criteria. #493 retirement verify refused protected-process visibility with no deletion; the fixed read-only follow-up requires user-terminal authentication, requested separately. About2TB is free; source work continues independently. No runtime is active at this checkpoint. No new RC/device/publication authority is implied.

The remaining18-row selected notice/build-source supplement is unchanged in scope. Current architecture associations are now observed; strip derivation, exact source/modified-build relationships, notices and required retrieval/off-host custody remain open. No inventory replay is selected.

## Current refresh — October15 completed final five-profile inventory

The [actual inventory and consumed originals](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-source-custody/final-inventory-runtime/README.md) now bind accepted VM/H700f863/ES16dbac and SM9aa7 (the sole product delta is the upstream ABL archive checksum correction). Run093346Z-ed162eab completed09:34:11UTC, all ten original collectors0, no timeout/interruption/cleanup errors; ordinary consumptione73b73b3. All seven final SM references bind actual reader/acceptance/completion/consumed/output/ARM/bundle files. Counts:594 GENERICx86,238 H700arm,616 H700aarch64,241 SMarm,677 SMaarch64. They are profile rows, not deduplicated components. Original result remains PASS_INVENTORY_WITH_PUBLICATION_GAPS, publication_bundle_complete=false, common_rc_identity=null. No inventory replay is needed.

[SM artifact acceptance](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-15-sm8550-abl-format/accepted/README.md) passed separately after the original combined producer1/0/1; no original failed channel is relabeled. The current inventory and exact sources are retained under final-inventory-runtime; reviewed executable proposal revision03 remains separately retained under final-inventory-source with its historical preparation status.

Next is the existing17 notice rows plus Doom, now bound to actual selected profiles, followed by exact fetched/generated input custody and independent retrieval/required off-host custody. The only archive-reconstructed row is SM LLVM22.1.8. Per-architecture rclone1.75.2 and Tailscale provenance needs explicit current selected-binary association; a shared-cache filename is not proof of the selected architecture. Aggregate shader/ABL terms, scoped vendor evidence and LinuxLoader implementation source remain unresolved. This reports current gaps, not evidence of a wrong shipped executable. #601 OpenABL is separate incoming scope. No licence/source completeness, off-host transfer, upstream outreach or publication authority is inferred. All five acceptance criteria remain open; partial inventory execution alone does not satisfy them.

## Historical runner preparation — superseded by the actual execution above

## Current refresh — October15 reviewed runner, waiting for accepted SM output

Accepted VM/H700 remain distributionf8636de1 / ES16dbac52. The #600 SM8550 retry uses9aa7affee9, whose entire product delta is the existing upstream ABL1.2 checksum correction. The current cache copy is active under #555; no new SM acceptance or inventory total is claimed. Historical October8 counts and custody remain attributed to their original images.

The retained collector proposal at `docs/qa-logs/2026-10-15-source-custody/plan/` derives rclone1.75.2 input names from the recipe, recognizes immutable Doom4cb65b68 provenance, and keeps static/vendor packages without install stamps unresolved. Finite source review found two runner lifecycle defects; the reviewed revision now uses identity-bound pidfd/adopted-child cleanup, preserves original interrupted wait results and restores the child's signal mask after protected spawn registration.

Executable source revision03 is retained in `docs/qa-logs/2026-10-15-source-custody/final-inventory-source/` (original6b2c7bf6, durable07e006fa). It requires exact per-device sources and complete product maps: VM/H700f863 and SM9aa7, allowing only the exact ABL checksum-line replacement. Ordinary control/admission stays in the frozen VM tree. Mixed engineering identities remain explicit; no common RC identity is invented. Root reviewed the narrow executable diff and independently checked132 archived members including original metadata. Source-only checks passed; collectors have NOT run.

Next, after actual SM build and independent acceptance: fill the seven original SM input/acceptance/completion/consumed/output/ARM/bundle path+hash references; fresh resource/retention/admission; execute the five profiles sequentially and consume only original successful results. Existing VM/H700 references are already concrete. Then finish selected-file/vendor notice attribution, exact fetched/generated input custody and independent retrieval/required off-host custody. The17 notice rows plus Doom, five aggregate gaps and LinuxLoader implementation source hold remain explicit. The separate #601 OpenABL review is incoming follow-up, not part of this inventory or checksum repair. No off-host transfer, account purchase, upstream outreach or publication implied. All five acceptance criteria remain open.

---

## Current reconciliation — #533

Current #533 dependency: firmware-affecting source/component choices must be resolved before final freeze; independent retrieval/off-host custody gates publication. The earlier #519-before-update paragraph is historical: alignment and three deployments are complete. Original local custody is not complete corresponding-source clearance.

[Scope and build plan](https://github.com/pixelelated/distribution/blob/next/docs/releases/next-candidate-scope.md).

## Source snapshot custody complete — 2026-10-08 22:41 UTC

#528 archive and tracked Git source custody is complete locally. #492 is closed completed with published inventory `5264a647a1ff541302e6b0070a73f268a87a4247` and both hosted checks successful. The 605 exact archive inputs (9,044,760,878 bytes) and both frozen distribution snapshots (6,552 files/180 raw symlinks each) are retained at `/workspace/artifacts/pixelelated-release-sources/m7-archives-a7022b76da76a9f6771bb7693d6f6e25854c6731db0750bb46dde29f14d49fce`. Git snapshot03 finished 22:37:06 UTC with all five original rc0 channels; actual host owners 1542320/1542321/1542322/1542352 exited, consumed at22:41:07. It preserves 372 exact tracked Git snapshots,43 root inputs,439 submodule edges and six separately archived extra-cache groups at `/workspace/artifacts/pixelelated-release-sources/m7-git-266c8393884189dec9419628b3e7e527b965598d7b9b31e4ea31fd9af2204dc9`. Every tracked blob/mode/symlink was checked. The sole LFS pointer is Teakra's 357,257,824-byte accuracy-test fixture: actual SM8550 flags disable tools/tests, the payload is absent, and no generated build edge or installed file uses it; preserve its pointer, with no unused download. Original archive01/Git01/Git02 failures remain unchanged. No source, compiler, VM or audit job is active. Next: finish remaining licence/vendor/special-input dispositions and independently verified retrieval/backup custody; the inventoried component-to-source map is complete locally. No RC or publication clearance; #519 still precedes the owner handheld update.


## Source index and prebuilt follow-up — 2026-10-08 22:55 UTC

The local source index now maps all2,327 component/profile rows (701 distinct names) to the retained archive/Git/local inputs, shared sources, ARM profiles and exact frozen recipes. Source-cited root/scoped licence evidence is recorded for13 of17 missing recipe declarations; per-file, dependency and output-use terms still require disposition. Common/GLSL/RetroPie/slang shader collections and ABL have no aggregate basis yet; see the current notice-scope correction below. No recipe or firmware changes.

Prebuilt source retention completed with all five original rc0 results and actual owner exits consumed22:51:00: rclone687d264b689b8c49a67e2e52a8a5e0caa01c04ce (2,617 blobs), Tailscale05a91829316e055517a1e84f7b00016846ef4107 (2,536), ABL packaging0e755e154874f7e874919ab7e080935c1444df68 (3), all exact tracked blobs with no omissions/substitutions. Custody `/workspace/artifacts/pixelelated-release-sources/m7-prebuilt-aeef83ae3a4de7ebaca3816508e804bf935e87285efdcff6226cb52bd2fc4827`; compact proof `docs/qa-logs/2026-10-08-source-custody/git-complete/`. rclone's binary reports the matching commit plusmodified=true; Tailscale's build metadata omits VCS revision. These observations are retained without a reproducibility claim.

ABL v1.1.9 records LinuxLoader4588733123554b1f7bf935b04e494e4284894546, but blitterbot's source-ref read returns404. The public packaging archive is not that implementation or its licence. Owner asked for an existing source/contact route; no upstream message was sent. This component's publication disposition remains open. Backup follows intendedB2 subject to the owner's comparison (D-WORKFLOW-107); a second directory on the same drive is not off-host custody. No source/compiler/VM/audit job is active. Continue remaining licence/vendor/special-input work and final retrieval/backup; #519 remains before owner update, with hardware/publication gates separate.


## Scope

Finish #344's component/source publication gate for the qualified VM18, H70002 and SM855003 images. #492 owns completed firmware builds and their exact per-image inventory attachment; this task owns remaining licence/source dispositions and publication custody. The M7 milestone body remains the ordered plan.

The five architecture profiles now map 584 VM, 224 H700 ARM, 615 H700 aarch64, 228 SM8550 ARM and 676 SM8550 aarch64 components. These are per-profile rows, not a unique-component total. The original failed inventory attempts remain unchanged; the final record explicitly composes individually successful reports. No firmware changes or new audit are implied.

Seventeen components lack recipe licence declarations: common-shaders, enet, freej2me-lr, glsl-shaders, harfbuzz-icu, libretro-database, libspeexdsp, libxmp-lite, openbor, opusfile, rclone, retropie-shaders, rocknix-abl, slang-shaders, tailscale, wildmidi and zerotier-one. Notice candidates are retained for 47 component/profile rows; absence or presence of a notice is not a licence conclusion.

Special inputs: ARM compatibility components; LLVM's exact pinned source archive and three installed libraries (the SM8550 unpacked root is absent); FEX's Nix toolchains/archives and 81 referenced store paths; recovered, hash-pinned amd64/arm64 rclone ZIPs that match the unpacked binaries; and exact installed Doom shareware bytes from idtech-lr's unpinned install-time URL. Do not classify a package as build-only merely because it lacks its own image install stamp: vendored/static dependencies require disposition too. A prebuilt archive is not corresponding source.

Can this be done on the VM? This is read-only host/artifact/source work; no physical fact, personal cloud or device mutation is needed. Hardware smoke, #519 owner alignment and publication authorization remain separate.

## Acceptance criteria

- [ ] Every selected image and ARM compatibility profile has a component inventory tied to its immutable bundle and original input-manifest hash, with a source/licence disposition per component, including embedded/vendored dependencies.
- [ ] The 17 missing declarations and special inputs above have source-cited dispositions and retained exact notices; no recipe-header licence is substituted for the shipped third-party work's licence. Any required product change has its own rebuilt/requalified artifact before release.
- [ ] A fork-owned corresponding-source bundle retains exact fetched source archives/git/submodules, fork patches and build scripts, with machine-readable hashes and a complete component-to-member map. Prebuilt rclone/ABL/shareware assets and Nix inputs are explicitly assessed rather than silently counted as source.
- [ ] Independent retrieval and hash verification of the source bundle pass, and the required backup custody is evidenced; local source-cache existence and public repository visibility alone do not close this criterion.
- [ ] #344, M7, the release manifest/notes and canonical checkpoint link the final inventory, bundle and any remaining physical/publication gates. Publication is not claimed while an unresolved disposition remains.

## Current evidence

Published [final inventory packet](https://github.com/pixelelated/distribution/tree/5264a647a1ff541302e6b0070a73f268a87a4247/docs/qa-logs/2026-10-08-final-inventory), with record37852763656 and wordlist37852763594 both successful. Supplement owner `/workspace/tmp/pixelelated-m7-source-supplement-01` completed with all five original rc0 results and actual process cleanup. Older inventory12 is historical and cannot substitute for these images.

The maintained contract is D-WORKFLOW-139 and #344's corresponding-source/component-inventory obligation. This is a concrete implementation child of that existing approved scope, not a new release policy.


## Source delivery verified — 2026-10-08 23:35 UTC

The prepared component index, prebuilt provenance and notice-basis packet was published as fab6fd5b916c97a31c3b8edfaa923194d1aec460. Exact-head record37856726819 and wordlist37856726976 both completed successfully and were consumed. This does not close the remaining licence/vendor/special-input, independent retrieval or off-host backup criteria. The LinuxLoader source/contact question remains pending; no upstream message or source-access assumption was made. Independent #519 VM rehearsal does not change this task's publication holds.


## Notice-scope correction — 2026-10-09T00:17:09.329714+00:00

The current notice basis is docs/qa-logs/2026-10-09-notice-scope/licence-basis-corrected.json. Independent readback of the exact GLSL archive corrected an earlier scope error: the LGPL text is nnedi3/LICENSE, not a collection-root licence. The original sealed basis remains unchanged and superseded for this label. A crt-royale notice is also retained. The13 count means some root or scoped evidence, never13 cleared components; five currently have no established aggregate basis: common, GLSL, RetroPie and slang shaders, plus ABL. All publication criteria remain open. No recipe, firmware or source-custody member changed.


## Original request and history

The complete original body and every comment are preserved in [the #533 snapshot](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-11-candidate-scope/tracker-before.json), entry #528. Retired criteria there are historical, not an execution queue. Existing GitHub comments also remain intact.

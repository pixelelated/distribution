#!/usr/bin/env python3
"""UNRUN: join exact held metadata only; never open source payloads or archives."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import time

HERE = Path(__file__).resolve().parent
START = time.monotonic()
READ = 0
WRITTEN = 0
LIMIT = 16 * 1024**2


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_ref(ref):
    global READ
    p = Path(ref['path'])
    require(p.is_absolute() and p.resolve() == p and not p.is_symlink(), 'metadata path changed')
    s = p.stat()
    require(s.st_size == ref['bytes'] <= 4*1024**2, 'metadata file bound')
    require(READ + s.st_size <= 32*1024**2, 'aggregate metadata read bound')
    READ += s.st_size
    body = p.read_bytes()
    require(len(body) == ref['bytes'] and sha(body) == ref['sha256'], 'metadata identity changed: '+str(p))
    return json.loads(body)


def write(out, name, value, receipt=False):
    global WRITTEN
    data = (json.dumps(value, sort_keys=True, separators=(',',':'))+'\n').encode()
    require(len(data) <= (1024**2 if receipt else LIMIT-1024**2), 'output size bound')
    require(WRITTEN+len(data) <= (LIMIT if receipt else LIMIT-1024**2), 'aggregate bound before write')
    WRITTEN += len(data)
    with (out/name).open('xb') as stream:
        stream.write(data)
    return {'name':name, 'bytes':len(data), 'sha256':sha(data)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    out = p.parse_args().output
    require(re.fullmatch('/workspace/tmp/pix-m7-final-source-assembly-index-20261015-[0-9]{2}',str(out))
            and out.parent.resolve() == out.parent and not out.exists(), 'fresh exact output owner required')
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(LIMIT,LIMIT))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    def expired(_sig,_frame):
        raise TimeoutError('30-second metadata work bound')
    signal.signal(signal.SIGALRM,expired)
    signal.alarm(30)
    out.mkdir(mode=0o700)
    result = {'status':'FAIL','source_payloads_opened':0,'archives_opened':0,'network_used':False,
              'source_execution':False,'publication_bundle_complete':False,'outputs':[]}
    try:
        plan = json.loads((HERE/'assembly-plan.json').read_text())
        refs = plan['refs']
        require(len(refs) == 35, 'input metadata membership changed')
        data = {key:load_ref(ref) for key,ref in refs.items()}
        base = data['base_components']
        require(refs['base_components']['sha256'] == data['base_manifest']['component_index_sha256'],
                'base index is not the accepted manifest member')
        require(len(base) == 2366, 'base row count changed')
        bykey = {(r['profile'],r['component']):r for r in base}
        require(len(bykey) == len(base), 'duplicate base component')
        additions = {key:{} for key in bykey}
        shared_rows = shared_edges = arm_edges = 0
        for profile in plan['profiles']:
            name = profile['profile']
            worklist = data[profile['worklist_ref']]
            inputs = data[profile['inputs_ref']]
            require(worklist['input_manifest_sha256'] == refs[profile['inputs_ref']]['sha256'] and
                    worklist['distribution_commit'] == inputs['distribution_commit'] == profile['distribution_commit'],
                    'profile source/input mismatch')
            require(len(worklist['components']) == profile['components'], 'profile count changed')
            for c in worklist['components']:
                key = (name,c['component'])
                require(key in bykey and c['recipe_sha256'] == bykey[key]['recipe_sha256'] ==
                        inputs['source_files'][c['recipe']], 'component recipe mismatch')
                extra = additions[key]
                prefix = str(Path(c['recipe']).parent)+'/'
                extra['local_recipe_files'] = {n:h for n,h in inputs['source_files'].items() if n.startswith(prefix)}
                extra['local_recipe_symlinks'] = {n:t for n,t in inputs['source_symlinks'].items() if n.startswith(prefix)}
                targets = list((c.get('unpacked_source') or {}).get('source_packages',{}))
                if targets:
                    require(all((name,t) in bykey for t in targets), 'unmapped shared-source target')
                    shared_rows += 1
                    shared_edges += len(targets)
                    extra['shared_source_components'] = [name+':'+t for t in targets]
                if c['component'] == 'lib32':
                    target = name.rsplit('-',1)[0]+'-arm'
                    require(any(p['profile']==target for p in plan['profiles']), 'ARM companion missing')
                    extra['companion_profile'] = target
                    arm_edges += 1
        require((shared_rows,shared_edges,arm_edges) == (12,16,2), 'shared/companion map differs')
        for supplement in ['tailscale','koko']:
            manifest = data[supplement+'_manifest']
            require(refs[supplement+'_components']['sha256'] == manifest['component_index_sha256'],
                    'supplement index differs from manifest')
            rows = data[supplement+'_components']
            require(len(rows) == 3, 'wrong supplement component count')
            for r in rows:
                original = r['original_component']
                key = (original['profile'],original['component'])
                require(bykey.get(key) == original and r['original_index_sha256'] == refs['base_components']['sha256'],
                        'supplement not bound to exact base row')
                additions[key][supplement+'_source_supplement'] = {'manifest':refs[supplement+'_manifest'],
                    'index':refs[supplement+'_components'], 'row':r}
        tailscale = data['prebuilt_source_findings']['tailscale']
        main = [r for r in data['prebuilt_main_sources']['components'] if r['component']=='tailscale']
        require(len(main)==1 and main[0]['commit']==tailscale['commit'] and tailscale['main_module_identity_supported'],
                'Tailscale main source identity mismatch')
        for key in bykey:
            if key[1]=='tailscale':
                additions[key]['main_source_snapshot'] = {'manifest':refs['prebuilt_main_sources'],
                    'source':main[0], 'identity_evidence':refs['prebuilt_source_findings']}
        fex_keys = [key for key in bykey if key[1]=='fex-emu']
        require(fex_keys == [('sm8550-aarch64','fex-emu')], 'FEX profile scope changed')
        fex_sources = data['fex_archives']['rows']+data['fex_archives']['reused_prior_archives']
        require(len(fex_sources)==8 and sum(x['archive']['bytes'] for x in fex_sources)==270251656,
                'FEX archive set changed')
        require(len(data['fex_generated']['generated_sources'])==13 and len(data['fex_header_notices']['notices'])==13
                and len(data['fex_held']['patches'])==20 and len(data['fex_patches']['inputs'])==2,
                'FEX special input set changed')
        additions[fex_keys[0]]['fex_sources'] = {'archive_inputs':[r['archive'] for r in fex_sources],
            'historical_reuse':data['fex_archives']['reused_historical_archives'],
            'nixpkgs':data['fex_held']['nixpkgs'], 'libglvnd':data['fex_held']['libglvnd_reused'],
            'patches':data['fex_held']['patches'], 'canonical_patch_manifest':refs['fex_patches'],
            'generated_source_readback':refs['fex_generated'], 'header_notices':refs['fex_header_notices'],
            'main_notices':refs['fex_main_notices'], 'guest_runtime_disposition':refs['fex_runtime_providers'],
            'scope':'Selected thunk/header inputs only; no whole compiler closure or unspecified guest-rootfs acquisition.'}
        zero = data['zerotier_filtered']
        require(zero['status']=='PASS' and zero['source_files']==3208 and zero['source_symlinks']==5,
                'ZeroTier source result changed')
        for key in bykey:
            if key[1]=='zerotier-one':
                additions[key]['pending_new_image_source_selection'] = {'manifest':refs['zerotier_filtered'],
                    'archive':zero['archive'], 'recipe_sha256':zero['product_recipe_sha256'],
                    'patch_sha256':zero['product_patch_sha256'], 'applicable_to_current_engineering_image':False,
                    'requires':plan['final_image_mapping']}
        for row in data['notice_collection']['rows']:
            key = (row['profile'],row['component'].split('/')[0])
            require(key in bykey, 'notice occurrence lacks component')
            additions[key].setdefault('historical_notice_occurrences',[]).append(row)
        joined = {'schema':1,'result':'ASSEMBLY_METADATA_JOIN_WITH_EXPLICIT_PENDING_INPUTS',
            'base_manifest':refs['base_manifest'],'base_component_index':refs['base_components'],
            'profiles':plan['profiles'],'component_rows':2366,'publication_bundle_complete':False,
            'final_image_mapping':plan['final_image_mapping'],'pending_source_questions':plan['pending_source_questions'],
            'notice_collection':refs['notice_collection'],'notice_index':refs['notice_index'],
            'shader_attribution':refs['shader_attribution'],
            'notice_scope':'Historical triage rows remain original. Later accepted dispositions are linked by README; this join does not turn collection into licence clearance.',
            'components':[{'original_component':r,'assembly_additions':additions[(r['profile'],r['component'])]} for r in base]}
        require(len(plan['copy_worklist'])==39 and sum(r['bytes'] for r in plan['copy_worklist'])==293582752,
                'copy proposal changed')
        result['outputs'].append(write(out,'source-assembly-index.json',joined))
        result['outputs'].append(write(out,'missing-custody-worklist.json',{
            'status':'PROPOSED_NOT_COPIED','files':plan['copy_worklist'],'bytes':293582752,
            'destination':plan['copy_destination_proposed'],'bounds':plan['bounds']}))
        for ref in refs.values():
            load_ref(ref)
        result.update(status='PASS_METADATA_ONLY',component_rows=2366,shared_source_rows=shared_rows,
                      shared_source_edges=shared_edges,arm_companion_edges=arm_edges)
    except BaseException as exc:
        result['error'] = str(exc)[:2048]
    finally:
        signal.alarm(0)
        result.update(elapsed_seconds=time.monotonic()-START,metadata_bytes_read=READ,output_bytes_before_receipt=WRITTEN)
        write(out,'result.json',result,receipt=True)
    print(json.dumps({'status':result['status'],'output':str(out)}))
    return 0 if result['status']=='PASS_METADATA_ONLY' else 1


if __name__=='__main__':
    raise SystemExit(main())

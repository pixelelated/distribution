This is a source-only executable proposal for joining accepted source custody,
not a new inventory, source collection, licence audit or completed bundle.
No archive body, source cache, generated source body, or binary was opened or
rehashed during preparation. No source was copied and no helper was executed.
The exact #528 snapshot is bound in assembly-plan.json; all five acceptance
criteria remain open. The three refreshed native images are still pending.

The existing assembly route is the accepted additive collector and its
component-member-index.json: 2,366 component/profile rows, 606 archive identities
and 43 Git roots, with exact references to historical custody. It already holds
the current RAOfflineProxy/ABL archives, current ES, both engineering distribution
snapshots, and rclone's current source/vendor archives. Reuse those exact members;
do not copy entire historical stores again. Their historical unresolved labels
remain original observations, not a fresh claim that completed supplements are
missing.

The historical October8 build-member-index.py established shared-source and
local-recipe mapping, but it opens distribution archives and is hard-coded to old
profiles. Do not rerun it. The additive collector's current index omits explicit
shared-source and ARM-companion links; accepted worklists supply 12 shared-source
rows with 16 edges, plus two lib32 companion edges. Their exact target components
exist. The new join restores these links and local recipe-directory file/symlink
maps using only the already accepted inventory-inputs metadata.

Tailscale and Koko already use compatible supplement indexes containing the
complete original component row and base-index hash. The join requires exact
equality before attaching them. It also explicitly links Tailscale's main source
05a91829316e055517a1e84f7b00016846ef4107 from historical prebuilt-source custody,
supported by the accepted main-module finding. The dependency supplement alone
does not supply that main-source member. Rclone's two current source/vendor
archives remain the additive index's existing additional source references;
the old historical rclone source version is not substituted.

FEX's single SM8550 aarch64 component receives references to all eight accepted
header-source archives, three historical archive reuses, accepted libglvnd reuse,
exact Nixpkgs NAR, 20 held patches, two canonical normalized patches, 13 generated
sources, and the retained notice/provider dispositions. Flat archive hashes,
recursive NAR identities, Go h1 identities and normalized patch hashes remain
distinct. In particular, Nixpkgs b6018f87da91d19d0ab4cf979885689b469cdd41 is the
195,961,000-byte NAR b705cf16a16caeb639af6f1987b1e89a0729da050c06043a5834bdf10ff7c452.
No 81-row compiler closure or unspecified external guest rootfs is added.

ZeroTier's filtered tar is 14,194,934 bytes, SHA256
10273d138a6c3c4d74468550965e06886f0b094167a7a0e23be157453e8a762a.
It has its own exact manifest, recipe, patch and BUILD.md. The join records it as
a pending selection for the three new native images, preserving the original
engineering rows. It must not be claimed as source for the old binaries that
included the three nonfree headers. For the future public source selection,
replace the ZeroTier upstream whole-source member with this separately named
filtered tar after the new artifact binding passes; keep the upstream archive
and diagnostic nonfree material in historical private custody. Do not blindly
publish all files from a historical source directory.

Run the bounded next step only after root allocation:

    bash /tmp/pix-m7-final-source-assembly-plan-20261015/commands.sh

It uses the existing watched record-only route and a fresh output owner
/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01. The helper has no
child processes, network, archive opening, extraction, payload hashing, or cache
walk. It reads exactly 35 named metadata inputs, each pinned by size/SHA256;
15,224,573 bytes per pass, verified before and after. The 32 MiB aggregate read
cap covers both passes. It has a 30-second alarm, 512 MiB address-space limit,
16 MiB output limit and at most three output files: source-assembly-index.json,
missing-custody-worklist.json and result.json. Normal output reserves 1 MiB for
the result and is bounded before write. The successful result is explicitly
PASS_METADATA_ONLY; it cannot close the bundle/retrieval/publication criteria.
Original watcher result and the helper's original exit must be retained. This
small join uses existing map schemas; no new supervisor or test framework is
introduced. Static preparation checks are recorded in static-review.json.

The next payload step is precisely 39 independent copies, 293,582,752 bytes:

| Held input | Files | Integration action |
| --- | ---: | --- |
| FEX eight acquired archives across owners01/03/04/06 | 8 | Copy from exact accepted body paths, preserving their flat SHA256 pins. |
| FEX retained generated source files | 13 | Copy the existing retained files; do not read the build cache or regenerate. |
| FEX retained selected header notice excerpts | 13 | Copy exact existing excerpts; preserve the separate full-text requirement. |
| ZeroTier filtered deliverable | 5 | Copy tar, manifest, recipe, patch and build notes together. |

assembly-plan.json already provides every exact source path, size, hash and
destination member. These are held inputs, not new acquisition requests. The
proposed fresh destination is
/workspace/artifacts/pixelelated-release-sources/m7-source-assembly-supplement-20261015-01.
Reuse the accepted Koko custody collector's copy_file/Writer/identity functions
and unchanged supervisor/process/admission lifecycle; replace only its five-object
selection loop with this exact 39-row worklist and the joined index binding.
existing-route.json pins those helper source identities. No duplicate source
framework is needed. Do not run the existing Koko selector unchanged: it asserts
its own five objects and is not a general 39-file command.

Proposed copy limits: 192 MiB per file (largest exact input 152,673,392 bytes),
384 MiB destination, 64 MiB owner with 16 MiB supervisor reserve and 1 MiB failure
receipt, 2 GiB total read allowance for before/copy/after/original verification,
300 seconds work, 64 output files, 16 directories, and 512 MiB retention
reservation including overhead. All
payload writes use the already qualified aggregate-before-write copy mechanism;
input/output inode separation, complete hash readback, immutable modes and
ordinary consumed originals remain required. This copy adaptation is the next
small implementation after the metadata join; it is not falsely presented as
an already runnable 39-file collector. Existing Nixpkgs/patch/Tailscale/Koko
payloads remain immutable references, and completed downloads are not replayed.

Notice materialization remains specific. The join keeps all 43 accepted notice
occurrences attributed to their original producers and links the retained shader
analysis. Its old triage strings are not current permission decisions. Use the
later accepted [source/notice acceptance](/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-source-notice-acceptance/README.md),
remaining-notice-disposition, freej2me-vendor-notices, shader-distribution-disposition,
doom-input-disposition, final-notice-scope and tailscale-notice-reconciliation
packets under coordinator docs/qa-logs/. The approved 68 CC members and Koko GPL
treatment are not reopened. FEX's header-notice record explicitly has
all_license_texts_complete=false: preserve selected header notices and bind full
applicable COPYING3/COPYING.RUNTIME, glibc/ALSA terms and other named texts from
the already held exact source archives under a separately bounded named-member
read. This proposal does not scan archives or claim those texts were extracted.

Final source selection still needs the three refreshed immutable image bundles,
their original input manifests and inventory/acceptance records, and a complete
new distribution snapshot containing the adopted ZeroTier recipe/patch. Reuse
the two ARM companion source selections only through the new accepted bindings.
The existing f863/9aa7 snapshots remain correct for the old engineering family.
Preserve all unaffected component identities and qualify only changed mappings;
do not replay unrelated builds or source collections.

The exact ABL implementation/access and one MAME adaptation declaration remain
pending. Contact approval is pending; no contact is performed here. Once the
remaining exact selections and notice links are resolved, the existing
tools/rasteratops-candidate-store can seal a final explicitly named flat source
archive/index set with input bindings. It rejects duplicate basenames and
manifest.json as input, and copies every supplied file, so it is not a substitute
for selective assembly or an excuse to duplicate all historical stores now.
Independent retrieval and required off-host backup need their own later original
hash/transfer/restore evidence. A local reference index is useful preparation,
not evidence of either operation or release clearance.

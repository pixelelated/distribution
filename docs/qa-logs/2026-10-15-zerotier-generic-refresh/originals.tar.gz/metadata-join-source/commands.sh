#!/bin/bash
# UNRUN. Root allocates this finite metadata join separately from image work.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-final-source-assembly-plan-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-player-setup
TASK_OUTPUT=${TASK_OUTPUT:-/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01}
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/assemble-index.py" --output "$TASK_OUTPUT"

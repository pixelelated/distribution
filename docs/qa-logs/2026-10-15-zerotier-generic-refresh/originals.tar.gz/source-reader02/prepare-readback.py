#!/usr/bin/env python3
"""Materialize the existing bounded image reader after actual build consumption; no launch."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03')
BUILD = Path('/workspace/tmp/pix-m7-zerotier-generic-build-20261015-01')
OWNER = Path('/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-02')
COMMIT = '077197e6cd3ea31f33b28aaf3882a694b3423b53'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2); f.write('\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--owner', type=Path, required=True)
    a = p.parse_args()
    owner = a.owner.resolve(strict=True)
    assert owner == OWNER and owner.is_dir() and not any(owner.iterdir())
    assert Path.cwd().resolve() == TREE
    cfg = json.loads((BUILD / 'build-inputs.json').read_text())
    assert cfg['commit'] == COMMIT and cfg['checkout'] == str(TREE)
    run = Path((BUILD / 'run.path').read_text().strip())
    consumed_path = run / 'admission-consumed.json'
    consumed = json.loads(consumed_path.read_text())
    assert consumed['state'] == 'consumed' and consumed['source']['head'] == COMMIT
    assert consumed['submission_owner'] == str(BUILD) and consumed['run'] == str(run)
    assert all(consumed['original_result'][k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
    assert json.loads((BUILD / 'launcher-result.json').read_text())['runner_returncode'] == 0
    assert (BUILD / 'tool-wrapper.rc').read_text().strip() == '0'
    assert json.loads((BUILD / 'owner-result.json').read_text())['status'] == 'PASS'
    assert json.loads((BUILD / 'resource-result.json').read_text())['status'] == 'PASS'
    for name in ['verify-image.py', 'run.sh', 'dolphin-sys-source-manifest.json']:
        shutil.copyfile(Path(__file__).with_name('readback') / name, owner / name)
        (owner / name).chmod(0o400)
    (owner / 'artifacts').mkdir()
    (owner / 'empty-scan').mkdir()
    inputs = {'scope': 'completed image identity, ZeroTier package provenance and selected installed mappings; no runtime qualification',
        'build_owner': str(BUILD), 'build_run': str(run), 'source': COMMIT,
        'build_timestamp': cfg['build_timestamp'], 'build_inputs_sha256': sha(BUILD / 'build-inputs.json'),
        'admission_consumed_sha256': sha(consumed_path),
        'verifier_sha256': sha(owner / 'verify-image.py'), 'run_script_sha256': sha(owner / 'run.sh'),
        'dolphin_sys_manifest_sha256': sha(owner / 'dolphin-sys-source-manifest.json'),
        'work_seconds': 1500, 'cleanup_seconds': 15, 'host_cpu_affinity': [0],
        'per_process_virtual_memory_bytes': 8 * 1024**3, 'scratch_ceiling_bytes': 24 * 1024**3,
        'status': 'MATERIALIZED_AFTER_CONSUMED_BUILD_NO_READER_EXECUTED'}
    write(owner / 'inputs.json', inputs)
    files = [owner / name for name in ['inputs.json', 'verify-image.py', 'run.sh', 'dolphin-sys-source-manifest.json']]
    retention = {'volume': '/workspace', 'scan_roots': [str(owner / 'empty-scan')], 'reference_stores': [],
        'protected': [str(TREE / 'target'), str(TREE / cfg['build_root']), str(BUILD / 'owner-result.json'), str(consumed_path)],
        'candidates': [], 'builds': [{'name': 'm7-zerotier-generic-image-readback',
            'terms_bytes': {'bounded_raw_payload_and_records': 24 * 1024**3, 'operating_margin': 8 * 1024**3},
            'basis': 'Existing serialized bounded GPT/raw-update/installed reader after actual successful build consumption. No reclamation or runtime qualification.',
            'evidence': [{'path': str(f), 'sha256': sha(f)} for f in files]}]}
    admission = {'checkout': str(TREE), 'retention_plan': str(owner / 'retention-plan.json'),
        'retention_report': str(owner / 'retention-report.json'), 'stage': 'm7-zerotier-generic-image-readback',
        'profiles': [{'PROJECT': 'ROCKNIX', 'DEVICE': 'GENERIC_X64', 'ARCH': 'x86_64'}],
        'outputs': [{'path': str(owner / 'artifacts'), 'issue': 528, 'kind': 'qa-scratch',
            'release_when': 'Immediately queued affected clean/retained qualification no longer needs raw image/SYSTEM/KERNEL; compact originals retained.'}]}
    write(owner / 'retention-plan.json', retention)
    write(owner / 'admission-plan.json', admission)
    print(json.dumps({'owner': str(owner), 'inputs_sha256': sha(owner / 'inputs.json'), 'launched': False}))


if __name__ == '__main__':
    main()

"""Two normalized FEX patch bindings; no product/cache traversal."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
PROPOSAL=Path('/tmp/pix-m7-fex-source-phaseb-20261015')
PROPOSAL_SEAL='0e6932cf357651cb633b0ea7f95a9515ab4c647faef260f71a0f73d52c950e6b'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    return h.hexdigest()
def load(path):
    p=Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size<8*1024**2,p
    return json.loads(p.read_text())
def host_and_serialization(own_run=None):
    assert (os.getuid(),os.getgid())==(1000,1000)
    assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]'
    assert os.readlink('/proc/self/ns/user')=='user:[4026531837]'
    jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values()
    active=[j for j in jobs if j['state']!='consumed']
    assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
    if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def cli_identity(path):
    p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<16*1024**2 and os.access(p,os.X_OK)
    h=sha(p);after=p.stat();assert all(getattr(after,k)==getattr(s,k) for k in ['st_dev','st_ino','st_size','st_mode','st_uid','st_gid','st_mtime_ns'])
    with p.open('rb') as f:header=f.read(64)
    assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==62,'resolved host AMD64 ELF CLI required; no unbound script wrapper'
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,sha256=h)

def verify_plan(plan):
    assert sha(PROPOSAL/'SHA256SUMS')==PROPOSAL_SEAL
    for name,h in plan['binding_refs'].items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2
        assert sha(p)==h,name
    missing=load(PROPOSAL/'missing-fetch-descriptors.json')[:2]
    assert len(plan['selected_patches'])==2
    for selection,record in zip(plan['selected_patches'],missing):
        assert selection['raw_url']==record['fetch_fields']['urls']
        assert selection['normalized_sha256']==record['outputs'][0][3] and selection['raw_sha256'] is None
    assert plan['package']['bytes']==82352 and plan['package']['sha256']=='241c8bed2c24bbf6b46a818278e3200f1dd99465815b3d7ec9de708552af0ba4'
    assert plan['package']['url']=='https://archive.ubuntu.com/ubuntu/pool/main/p/patchutils/patchutils_0.4.3-1ubuntu1_amd64.deb'
    assert plan['publication_clearance'] is False

def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    plan=load(O/'collection-plan.json');verify_plan(plan)
    tools=load(O/'host-tools.json');assert set(tools)=={'curl','dpkgdeb','python'}
    for tool in tools.values():assert cli_identity(tool['path'])==tool['identity']
    return plan

#!/usr/bin/env python3
"""Consume only original successful collection channels; gaps never become clearance."""
from pathlib import Path
import hashlib,json,runpy,subprocess,stat,tarfile
O=Path(__file__).resolve().parent
B=runpy.run_path(str(O/'bindings.py'));B['verify'](O)
assert Path.cwd()==B['VM_TREE']
load,sha=B['load'],B['sha']
run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs'
B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
for f in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert f.read_text().strip()=='0',f
result,cleanup=load(O/'result.json'),load(O/'cleanup.json')
assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete'] is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established'] is False
assert result['execution_error'] is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json')
assert child['wait_observed'] is True and type(child['original_child_returncode']) is int and child['original_child_returncode']==0
assert child['qualification'] is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json')
assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit']) is int and report['original_collector_exit']==0
assert report['publication_clearance'] is False and report['independent_SYSTEM_relation_established'] is False
assert not (O/'collection-failure.json').exists()
plan=load(O/'collection-plan.json');policy=plan['owner_output_enforcement'];limits=load(O/'resources.json')
assert report['owner_output_enforcement']==policy and policy['owner_ceiling_bytes']==64*1024**2
assert type(report['initial_owner_bytes'])is int and 0<report['initial_owner_bytes']<=limits['initial_owner_maximum_bytes']
assert report['accounted_owner_bytes_before_report']<=policy['owner_ceiling_bytes']-policy['supervisor_receipt_reserve_bytes']
assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=64*1024**2
assert len(report['rows'])==2 and len(report['requests'])==3
assert [r['selection'] for r in report['rows']]==plan['selected_patches']
assert report['source_rebuild'] is False and report['source_execution'] is False and report['target_execution'] is False
assert report['selected_package_tools_materialized'] is True and report['acquired_host_tools_executed'] is True
assert report['package_installed'] is False and report['patch_applied'] is False and report['network_used'] is True
assert report['outputs_held'] is True and report['deleted_bytes']==0
TOOLS=load(O/'host-tools.json')
def check_file(record,parent):
    p=Path(record['path']);assert p.parent==parent and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size==record['bytes'] and sha(p)==record['sha256']
    assert all(record[k]==v for k,v in dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns).items())
    return p

def check_child(record):
    w=record['wait'];key=record['key']
    assert type(w['original_returncode'])is int and w['original_returncode']==0 and w['wait_observed']is True
    assert not w['timeout'] and not w['cleanup_signals'] and w['identity'] is not None
    assert w['environment']=={'PATH':'/usr/bin:/bin','LC_ALL':'C','TMPDIR':str(O/'tmp')}
    assert w==load(O/'receipts'/(key+'.wait.json'))
    assert record==load(O/'receipts'/(key+'.result.json'))

def check_reservation(record,files,cap):
    r=record['reservation'];assert r in report['reservations'] and r['key']==record['key']
    assert r['paths']==[f['path'] for f in files] and r['per_file_limit']==cap
    assert r['reserved_bytes']==len(files)*cap and all(0<=f['bytes']<=cap for f in files)
    assert r['actual_bytes']==sum(f['bytes'] for f in files)
    assert r['released_bytes']==r['reserved_bytes']-r['actual_bytes'] and r['original_wait_observed']is True

package=plan['package']
expected=[(package['name'],package['url'],package['bytes'])]+[(r['name'],r['raw_url'],limits['raw_patch_bytes_each']) for r in plan['selected_patches']]
for (name,url,cap),request in zip(expected,report['requests']):
    assert request['key']=='get-'+name and request['url']==url;check_child(request)
    body=check_file(request['body'],O/'raw');out=check_file(request['stdout'],O/'streams');check_file(request['stderr'],O/'streams')
    assert body.name==name and out.read_text().splitlines()==['200',url,'']
    argv=[TOOLS['curl']['path'],'-q','--fail','--proto','=https','--connect-timeout',str(limits['connect_seconds']),
        '--max-time',str(limits['request_seconds']),'--max-filesize',str(cap),'--retry','0','--silent','--show-error',
        '--output',str(body),'--write-out','%{http_code}\n%{url_effective}\n%{redirect_url}\n',url]
    assert request['wait']['argv']==argv
    check_reservation(request,[request[k] for k in ['body','stdout','stderr']],cap)
assert report['requests'][0]['body']['bytes']==package['bytes'] and report['requests'][0]['body']['sha256']==package['sha256']
inspection=load(O/'package-inspection.json');assert inspection==report['package_inspection']
assert inspection['package']==report['requests'][0]['body'] and not inspection['installed'] and not inspection['maintainer_scripts_executed']
assert len(inspection['selected_tools'])==2 and len(inspection['members'])<=256
tar=check_file(inspection['tar'],O/'streams');assert inspection['tar']['bytes']<=limits['package_tar_bytes']
with tarfile.open(tar,'r:') as archive:
    index={}
    for member in archive:
        assert len(index)<256
        name=member.name
        while name.startswith('./'):name=name[2:]
        if not name:name='.'
        assert name not in index;index[name]=member
    for tool in inspection['selected_tools']:
        source=index[tool['resolved_member']];assert source.isfile() and 0<source.size<=limits['tool_binary_bytes_each']
        data=archive.extractfile(source).read(limits['tool_binary_bytes_each']+1)
        assert len(data)==source.size and hashlib.sha256(data).hexdigest()==tool['record']['sha256']
for name,tool in zip(['filterdiff','lsdiff'],inspection['selected_tools']):
    binary=check_file(tool['record'],O/'tools');assert binary.name==name and tool['record']['bytes']<=limits['tool_binary_bytes_each']
    with binary.open('rb') as f:header=f.read(64)
    assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==62
    TOOLS[name]=dict(path=str(binary),identity=tool['record'])
for operation in report['operations']:
    check_child(operation)
    for k in ['stdout','stderr']:check_file(operation[k],O/'streams')
    cap=operation['reservation']['per_file_limit'];assert cap in [65536,limits['package_tar_bytes'],limits['normalized_bytes_each']]
    check_reservation(operation,[operation[k] for k in ['stdout','stderr']],cap)
assert [r['wait'] for r in report['requests']+report['operations']]==report['child_waits']
assert [r['reservation'] for r in report['requests']+report['operations']]==report['reservations']
assert report['operations'][0]['wait']['argv']==[TOOLS['dpkgdeb']['path'],'--fsys-tarfile',report['requests'][0]['body']['path']]
for selection,row,request in zip(plan['selected_patches'],report['rows'],report['requests'][1:]):
    assert row==load(O/'receipts'/(selection['name']+'.normalized.json')) and row['raw']==request['body']
    output=check_file(row['normalized'],O/'normalized');assert output.name==selection['name']
    assert 0<row['normalized']['bytes']<=limits['normalized_bytes_each'] and row['normalized']['sha256']==selection['normalized_sha256']
    assert row['names'] in report['operations'] and row['names']['wait']['argv']==[TOOLS['lsdiff']['path'],row['raw']['path']]
    names=sorted(set(Path(row['names']['stdout']['path']).read_bytes().splitlines()))
    assert 0<len(names)<=limits['max_patch_paths'] and len(row['fragments'])==len(names)
    chunks=[]
    for name,fragment in zip(names,row['fragments']):
        pattern=name.decode('utf-8').replace('*','\\*').replace('?','\\?')
        op=fragment['operation'];assert op in report['operations'] and fragment['name_hex']==name.hex() and fragment['pattern']==pattern
        assert op['wait']['argv']==[TOOLS['filterdiff']['path'],'--include='+pattern,'--strip=0','--clean',row['raw']['path']]
        chunks.append(Path(op['stdout']['path']).read_bytes())
    intermediate=check_file(row['intermediate'],O/'normalized');assert intermediate.read_bytes()==b''.join(chunks)
    assert row['final'] in report['operations'] and row['final']['wait']['argv']==[TOOLS['filterdiff']['path'],'-p1',str(intermediate)]
    assert row['final']['stdout']['sha256']==row['normalized']['sha256']
assert len(report['child_waits'])<=limits['max_child_invocations']
assert cleanup['all_recorded_identities_absent'] is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped'] is False
# Same qualified final-inventory strict census and PID/start identity custody.
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']()
owned_keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']}
supervisor=cleanup['supervisor_identity'];assert supervisor is not None
owned_keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in owned_keys]
parents={r['pid'] for r in matching};descendants=[]
while parents:
    children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants]
    descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants,'recorded identity or owned descendant still present'
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[O/n for n in ['result.json','cleanup.json','collection-result.json','collection-plan.json','preparation.json','host-tools.json','seal.json','inner.rc','outer.rc','launcher-result.json','tool-wrapper.rc']]+[run/'runner-result.json',run/'build.rc']
files+=[O/'package-inspection.json']
files+=sorted(p for d in ['stage','raw','streams','receipts','normalized','tools'] for p in (O/d).rglob('*') if p.is_file())
assert len(files)<=512 and sum(p.stat().st_size for p in files)<=64*1024**2
out=O/'admission-completion-evidence.json'
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Two exact canonical normalized patch hashes established using selectively materialized trusted package tools; raw HTTP hashes retained separately. Original tool waits and custody checked. No package install, source-built code, target execution, patch application, full compiler closure or publication clearance. Raw bodies/package/tools/streams remain private.')
raw=(json.dumps(evidence,indent=2)+'\n').encode()
assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=64*1024**2,'completion receipt would exceed owner ceiling'
with out.open('xb') as f:f.write(raw)
subprocess.run([TOOLS['python']['path'],'-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed two canonical normalized patches; final source custody/notices/publication remain explicit')

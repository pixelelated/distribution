#!/usr/bin/env python3
"""Three exact requests and bounded pinned-package normalization; no installation."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,resource,runpy,signal,stat,subprocess,sys,tarfile,time
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());LIMITS=json.loads((O/'resources.json').read_text())
POLICY=PLAN['owner_output_enforcement'];INITIAL=sum(p.stat().st_size for p in O.rglob('*') if p.is_file())
OUTPUT=INITIAL;START=time.monotonic();READ=0
requests=[];rows=[];reservations=[];child_waits=[];operations=[];active=None;rc=1;package_inspection=None
I=runpy.run_path(str(O/'process-identity.py'))
ENV={'PATH':'/usr/bin:/bin','LC_ALL':'C','TMPDIR':str(O/'tmp')}  # No HOME/auth/proxy environment.
def account(n,failure=False):
    global OUTPUT
    assert type(n)is int and n>=0
    if failure:assert n<=POLICY['failure_receipt_budget_bytes']
    ceiling=POLICY['owner_ceiling_bytes']-(POLICY['supervisor_receipt_margin_bytes'] if failure else POLICY['supervisor_receipt_reserve_bytes'])
    assert OUTPUT+n<=ceiling,'owner-output reservation refused before write'
    OUTPUT+=n

def write(path,value,failure=False):
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    assert len(raw)<=LIMITS['max_json_bytes']
    assert not path.exists() and not path.is_symlink(),'refuse output overwrite'
    account(len(raw),failure)
    with path.open('xb') as f:f.write(raw)

def identity(path):
    assert path.is_absolute() and path.resolve(strict=True)==path and not path.is_symlink()
    s=path.stat();assert stat.S_ISREG(s.st_mode)
    return dict(path=str(path),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)

def budget(n=0):
    global READ
    READ+=n
    assert READ<=LIMITS['named_read_ceiling_bytes'] and time.monotonic()-START<LIMITS['collector_seconds']-20,'named-read/time ceiling'

def digest(path,cap):
    before=identity(path);assert before['bytes']<=cap
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):budget(len(b));h.update(b)
    assert identity(path)==before,'input identity changed'
    return dict(before,sha256=h.hexdigest())

def reserve(key,paths,cap):
    assert all(not p.exists() and not p.is_symlink() for p in paths)
    # Each file can grow to the common child RLIMIT, including headers/raw streams.
    total=len(paths)*cap;account(total)
    r=dict(key=key,paths=[str(p) for p in paths],per_file_limit=cap,reserved_bytes=total,
           actual_bytes=None,released_bytes=0,original_wait_observed=False)
    reservations.append(r)
    return r

def release(r,records):
    global OUTPUT
    assert not r['original_wait_observed'] and len(records)==len(r['paths'])
    assert [v['path'] for v in records]==r['paths']
    assert all(0<=v['bytes']<=r['per_file_limit'] for v in records)
    used=sum(v['bytes'] for v in records);unused=r['reserved_bytes']-used
    assert OUTPUT>=unused;OUTPUT-=unused
    r.update(actual_bytes=used,released_bytes=unused,original_wait_observed=True)

def child(key,argv,cap,wait_seconds,stdout,stderr,tool):
    global active
    assert digest(Path(tool['path']),16*1024**2)==tool['identity']
    row=dict(key=key,argv=argv,environment=ENV,original_returncode=None,wait_observed=False,
             timeout=False,cleanup_signals=[],identity=None,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    active=row
    with stdout.open('xb') as so,stderr.open('xb') as se:
        # Same direct-child pidfd helper as the accepted supervisor; no numeric-group signal.
        proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=so,stderr=se,
            cwd=O,env=ENV,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(cap,cap)))
        row['identity']=I['identity'](proc.pid)
        assert row['identity'] is not None and row['identity']['ppid']==os.getpid()
        try:
            proc.wait(timeout=wait_seconds)
        except subprocess.TimeoutExpired:
            row['timeout']=True
            row['cleanup_signals'].append(I['signal_child'](row['identity'],os.getpid(),signal.SIGKILL))
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:pass
        finally:
            if proc.returncode is not None:
                row.update(original_returncode=proc.returncode,wait_observed=True)
        row['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(O/'receipts'/(key+'.wait.json'),row)
    active=None
    assert row['wait_observed'],'original child wait unavailable; supervisor retains remaining custody'
    assert digest(Path(tool['path']),16*1024**2)==tool['identity'],'host CLI changed'
    return row


def rawput(path,data,mode=0o600):
    assert len(data)<=LIMITS['per_file_bytes'] and not path.exists() and not path.is_symlink()
    account(len(data))
    with path.open('xb') as f:f.write(data)
    os.chmod(path,mode)
    return digest(path,LIMITS['per_file_bytes'])

def invoke(key,tool,argv,cap,seconds):
    assert len(child_waits)<LIMITS['max_child_invocations'];budget()
    out=O/'streams'/(key+'.stdout');err=O/'streams'/(key+'.stderr')
    reserved=reserve(key,[out,err],cap)
    wait=child(key,argv,cap,min(seconds,max(.01,LIMITS['collector_seconds']-20-(time.monotonic()-START))),out,err,tool)
    child_waits.append(wait)
    records=[digest(p,cap) for p in [out,err]];release(reserved,records)
    row=dict(key=key,wait=wait,stdout=records[0],stderr=records[1],reservation=reserved)
    operations.append(row);write(O/'receipts'/(key+'.result.json'),row)
    assert wait['original_returncode']==0 and wait['wait_observed'] and not wait['timeout'] and not wait['cleanup_signals'],'original tool failure'
    return out,row

def fetch(name,url,cap,expected_sha=None,expected_bytes=None):
    assert len(requests)<3 and url in [PLAN['package']['url']]+[r['raw_url'] for r in PLAN['selected_patches']]
    key='get-'+name;body=O/'raw'/name;stdout=O/'streams'/(key+'.stdout');stderr=O/'streams'/(key+'.stderr')
    reserved=reserve(key,[body,stdout,stderr],cap)
    with body.open('xb'):pass
    tool=TOOLS['curl'];argv=[tool['path'],'-q','--fail','--proto','=https','--connect-timeout',str(LIMITS['connect_seconds']),
        '--max-time',str(LIMITS['request_seconds']),'--max-filesize',str(cap),'--retry','0','--silent','--show-error',
        '--output',str(body),'--write-out','%{http_code}\n%{url_effective}\n%{redirect_url}\n',url]
    wait=child(key,argv,cap,LIMITS['request_wait_seconds'],stdout,stderr,tool);child_waits.append(wait)
    records=[digest(p,cap) for p in [body,stdout,stderr]];release(reserved,records)
    row=dict(key=key,url=url,wait=wait,body=records[0],stdout=records[1],stderr=records[2],reservation=reserved)
    requests.append(row);write(O/'receipts'/(key+'.result.json'),row)
    assert wait['original_returncode']==0 and not wait['timeout'] and not wait['cleanup_signals'],'original curl failure'
    assert records[1]['bytes']<=16384
    assert stdout.read_text().splitlines()==['200',url,''],'HTTP status/effective URL/redirect differs'
    assert records[0]['bytes']>0,'empty response'
    if expected_sha is not None:assert records[0]['sha256']==expected_sha,'package SHA256 mismatch'
    if expected_bytes is not None:assert records[0]['bytes']==expected_bytes,'package exact size mismatch'
    return row

def canonical_member(name):
    if name in ['.','./']:return '.'
    while name.startswith('./'):name=name[2:]
    p=PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and len(name.encode())<=4096,'unsafe package member'
    return str(p)

def package_tools(package_request):
    body=Path(package_request['body']['path'])
    assert digest(body,82352)==package_request['body']
    out,operation=invoke('package-data-tar',TOOLS['dpkgdeb'],[TOOLS['dpkgdeb']['path'],'--fsys-tarfile',str(body)],LIMITS['package_tar_bytes'],20)
    members={};metadata=[]
    budget(operation['stdout']['bytes'])  # Account the bounded tar parser read separately.
    with tarfile.open(out,'r:') as archive:
        for member in archive:
            budget();assert len(metadata)<256,'package member count'
            name=canonical_member(member.name);assert name not in members,'duplicate package member'
            if name=='.':assert member.isdir()
            assert 0<=member.size<=LIMITS['package_tar_bytes']
            members[name]=member;metadata.append(dict(name=name,type=member.type.decode('ascii'),bytes=member.size,mode=member.mode,linkname=member.linkname))
        selected=[]
        for binary in ['filterdiff','lsdiff']:
            name='usr/bin/'+binary;assert name in members,'named package executable missing'
            member=members[name];resolved=name
            if member.issym():
                assert member.linkname in ['filterdiff','./filterdiff'],'unexpected tool symlink'
                resolved='usr/bin/filterdiff';member=members[resolved]
            elif member.islnk():
                resolved=canonical_member(member.linkname);assert resolved=='usr/bin/filterdiff';member=members[resolved]
            assert member.isfile() and 0<member.size<=LIMITS['tool_binary_bytes_each'] and member.mode&0o111
            stream=archive.extractfile(member);data=stream.read(LIMITS['tool_binary_bytes_each']+1);budget(len(data))
            assert len(data)==member.size and data[:6]==b'\x7fELF\x02\x01' and int.from_bytes(data[18:20],'little')==62,'host AMD64 ELF required'
            dest=O/'tools'/binary;record=rawput(dest,data,0o500)
            TOOLS[binary]=dict(path=str(dest),identity=record)
            selected.append(dict(name=name,resolved_member=resolved,record=record))
    assert digest(body,82352)==package_request['body']
    inspection=dict(package=package_request['body'],tar=operation['stdout'],members=metadata,selected_tools=selected,other_members_materialized=False,maintainer_scripts_executed=False,installed=False)
    write(O/'package-inspection.json',inspection)
    return inspection

def normalize(selection,raw_request):
    body=Path(raw_request['body']['path']);assert digest(body,LIMITS['raw_patch_bytes_each'])==raw_request['body']
    key=selection['name'];lsdiff=TOOLS['lsdiff'];filterdiff=TOOLS['filterdiff']
    names_path,ls=invoke('names-'+key,lsdiff,[lsdiff['path'],str(body)],65536,LIMITS['normalizer_child_seconds'])
    data=names_path.read_bytes();budget(len(data));assert data and b'\0' not in data and b'\r' not in data
    # Byte ordering is LC_ALL=C sort -u; sed's recorded replacement escapes only * and ?.
    names=sorted(set(data.splitlines()));assert 0<len(names)<=LIMITS['max_patch_paths']
    assert all(n and len(n)<=512 for n in names)
    fragments=[];combined=bytearray()
    for index,name in enumerate(names):
        text=name.decode('utf-8');pattern=text.replace('*','\\*').replace('?','\\?')
        path,op=invoke('part-'+key+'-'+str(index),filterdiff,[filterdiff['path'],'--include='+pattern,'--strip=0','--clean',str(body)],LIMITS['normalized_bytes_each'],LIMITS['normalizer_child_seconds'])
        piece=path.read_bytes();budget(len(piece));assert piece and len(combined)+len(piece)<=LIMITS['normalized_bytes_each'],'normalized intermediate cap'
        combined.extend(piece);fragments.append(dict(name_hex=name.hex(),pattern=pattern,operation=op))
    intermediate=rawput(O/'normalized'/(key+'.intermediate'),combined)
    out,final=invoke('final-'+key,filterdiff,[filterdiff['path'],'-p1',intermediate['path']],LIMITS['normalized_bytes_each'],LIMITS['normalizer_child_seconds'])
    result=digest(out,LIMITS['normalized_bytes_each'])
    assert result['bytes']>0 and result['sha256']==selection['normalized_sha256'],'canonical normalized patch SHA256 mismatch; no fallback'
    budget(result['bytes']);canonical=rawput(O/'normalized'/key,out.read_bytes())
    assert canonical['sha256']==selection['normalized_sha256']
    assert digest(body,LIMITS['raw_patch_bytes_each'])==raw_request['body']
    row=dict(selection=selection,raw=raw_request['body'],names=ls,fragments=fragments,intermediate=intermediate,final=final,normalized=canonical,
        identity_basis='Exact expected normalized output hash; no claim that patchutils versions are generally equivalent',patch_applied=False)
    rows.append(row);write(O/'receipts'/(key+'.normalized.json'),row)

try:
    assert INITIAL<=LIMITS['initial_owner_maximum_bytes'];account(0)
    TOOLS=json.loads((O/'host-tools.json').read_text());assert set(TOOLS)=={'curl','dpkgdeb','python'}
    assert json.loads((O/'preparation.json').read_text())['pinned_normalizer_execution_authorized'] is True
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    for name in ['raw','streams','receipts','normalized','tools','tmp']:(O/name).mkdir(mode=0o700)
    os.chmod(O/'tmp',0o500)  # No child temporary-file writes are authorized.
    package=PLAN['package'];package_request=fetch(package['name'],package['url'],package['bytes'],package['sha256'],package['bytes'])
    raw_requests=[fetch(r['name'],r['raw_url'],LIMITS['raw_patch_bytes_each']) for r in PLAN['selected_patches']]
    package_inspection=package_tools(package_request)
    for selection,request in zip(PLAN['selected_patches'],raw_requests):normalize(selection,request)
    assert len(rows)==2 and len(requests)==3
    assert len([p for p in O.rglob('*') if p.is_file()])<=512 and len([p for p in O.rglob('*') if p.is_dir()])<=16
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    report=dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,rows=rows,requests=requests,operations=operations,child_waits=child_waits,
        reservations=reservations,package_inspection=package_inspection,owner_output_enforcement=POLICY,initial_owner_bytes=INITIAL,
        accounted_owner_bytes_before_report=OUTPUT,named_bytes_read=READ,elapsed_seconds=time.monotonic()-START,network_used=True,
        source_rebuild=False,source_execution=False,target_execution=False,acquired_host_tools_executed=True,
        selected_package_tools_materialized=True,package_installed=False,patch_applied=False,independent_SYSTEM_relation_established=False,
        publication_clearance=False,outputs_held=True,deleted_bytes=0)
    write(O/'collection-result.json',report);rc=0
except BaseException as error:
    write(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(error).__name__+': '+str(error)[:4096],
        completed_normalized_patches=len(rows),active_child=active,reservations=reservations,requests=requests,operation_keys=[r['key'] for r in operations],
        child_outcomes=[{k:r[k] for k in ['key','original_returncode','wait_observed','timeout']} for r in child_waits],
        initial_owner_bytes=INITIAL,accounted_owner_bytes_before_failure=OUTPUT,named_bytes_read=READ,publication_clearance=False,outputs_held=True,deleted_bytes=0),failure=True)
sys.exit(rc)

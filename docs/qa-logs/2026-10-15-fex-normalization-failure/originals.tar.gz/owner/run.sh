#!/bin/bash
set -eu
umask 077
TASK_OWNER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
set +e
taskset -c 0,1 prlimit --as=1073741824 --fsize=1048576:4194304 -- timeout --signal=TERM --kill-after=15s 210s /usr/bin/python3.14 -I "$TASK_OWNER/run.py"
task_rc=$?
set -e
(set -C; printf '%s\n' "$task_rc" > "$TASK_OWNER/outer.rc")
exit "$task_rc"

# Two missing FEX normalized patches — #528, source-only proposal

UNRUN. This packet proposes one fresh, guarded host run for precisely two missing fetchpatch outputs. Root must review the wrapper and explicitly authorize the pinned host normalizer at preparation. No package, patch, candidate helper, normalizer, preparer or test was fetched or executed during source preparation. No installation or Nix/compiler closure is proposed.

| Patch | Exact public input | Required normalized flat SHA256 |
| --- | --- | --- |
| libglvnd large-file | `https://gitlab.freedesktop.org/glvnd/libglvnd/-/commit/956d2d3f531841cabfeddd940be4c48b00c226b4.patch` | `63a602cddfe36755593fd6c59479078f34b04a15de03b88959dc9fc69813da5d` |
| xorgproto meson | `https://aur.archlinux.org/cgit/aur.git/plain/meson.patch?h=mingw-w64-xorgproto&id=7b817efc3144a50e6766817c4ca7242f8ce49307` | `233cf3f489f9dd6ec20befa4d5b2ebefc892ae6c69166d5c1fca9c4a9a6da144` |

The exact held fetch derivations and `postFetch` pipelines are retained in `originals/`, with original metadata in `originals.json`. These hashes describe **normalized output**, not the raw response. Raw hashes are unknown until actual acquisition; the wrapper records them separately. Both expected normalized hashes must match before success. HTTP refusal, HTML response, empty normalization, different output or exceeded bounds stops and preserves the original failure. There is no automatic retry, mirror, output rewrite or expected-hash substitution.

The host-tool candidate is Ubuntu resolute `patchutils_0.4.3-1ubuntu1_amd64.deb`, **82,352 bytes**, SHA256 **`241c8bed2c24bbf6b46a818278e3200f1dd99465815b3d7ec9de708552af0ba4`**, at `https://archive.ubuntu.com/ubuntu/pool/main/p/patchutils/patchutils_0.4.3-1ubuntu1_amd64.deb`. Its exact package-index stanza and metadata provenance are already held; no fresh package metadata or network read was needed. This HTTPS package route was not previously HEAD-verified and may fail. No fallback is assumed.

The recorded Nix tool is patchutils0.3.3 with `drop-comments.patch`, which makes `--clean` remove trailing unified-hunk comments. The Ubuntu0.4.3 package is a proposed substitute, not an asserted version-equivalent implementation. Matching the two independently known output hashes is the bounded compatibility test. No whole historical compiler closure is needed to compare these exact bytes.

## Exact operations and authority

Preparation requires actual resolved host ELF paths/SHA256 for Python, curl and dpkg-deb; it passively reads their bytes and refuses unbound script wrappers. `--allow-pinned-normalizer-execution` explicitly records root's authorization to materialize and execute only filterdiff/lsdiff from the exact package above. The normalizer remains unexecuted until root separately admits and launches the owner.

The collector performs three direct HTTPS GETs, with `curl -q`, clean environment without HOME/auth/proxy variables, no redirect following, no retries, exact HTTP200/effective-URL/no-redirect checks and before-write full output reservations. It checks the package's exact size/hash. The two patch bodies are retained unmodified and hashed.

Hash-bound host `dpkg-deb --fsys-tarfile` writes a bounded tar stream; it does not install the package, run maintainer scripts or extract the package tree. Python inspects at most256 tar member metadata rows and materializes only `usr/bin/filterdiff` and `usr/bin/lsdiff` as two private files. A named lsdiff symlink/hardlink is accepted only when it points to the package's filterdiff member; no source link is followed. Both resolved payloads must be nonempty executable ELF64 little-endian AMD64 regular members. Exact package/member/tool identities are written to `package-inspection.json` **before the acquired tools run**. Other members and scripts are never materialized. The materialized binaries are the only newly acquired host code executed; patch text is never applied or executed.

The original pipeline is reproduced explicitly: `lsdiff RAW`; byte-sort and deduplicate names under LC_ALL=C; escape only `*` and `?` as the recorded sed does; call `filterdiff --include=NAME --strip=0 --clean RAW` for each name in order; concatenate those bounded outputs; call `filterdiff -p1 INTERMEDIATE`. Here `-p1` is the recorded selection operation; it is not reinterpreted as rewriting stored paths. Raw, name list, per-file outputs, intermediate, final and canonical copies remain available with exact argv, original waits, hashes and reservations. Host-library compatibility is observed through original normalizer exits, not presumed from metadata.

This remains one reviewed allocation. An earlier planning message suggested a separate inspection allocation; the concrete proposal instead requires the explicit preparation flag and records inspection before execution, so root can authorize the exact package/tool operation in advance. No generic acquired-tool runner or unrestricted execution path is added.

## Bounds and lifecycle

- Three requests, zero redirects/retries; package exactly82,352B; each raw patch at most1MiB.
- Package tar output at most4MiB; at most256 members; only two executable payloads, at most1MiB each.
- At most32 names per patch, at most512 bytes per name; each per-file/intermediate/final normalized output at most1MiB; at most76 child invocations. The two expected final hashes are mandatory.
- Owner64MiB, normal collector ceiling48MiB, failure receipt1MiB and at least8MiB supervisor margin within16MiB reserve; retention128MiB. Every body/stdout/stderr reserves its **full actual child RLIMIT_FSIZE** before start, then releases unused bytes only after the original wait. Existing files count toward the owner limit. Raw curl streams have the same cap as their response body; no smaller cap is falsely promised.
- Named read ceiling512MiB; at most512 retained files/16 directories. Two CPUs,1GiB address space; collector soft deadline160s, supervised180s, outer210s+15s cleanup; each HTTP request25s plus bounded wait, package tar child20s, normalizer child10s, with the family deadline taking precedence.

The accepted Koko acquisition supervisor, direct/adopted-child PID/start identity mechanics and ordinary admission/watch lifecycle are reused. Supervisor helper function ASTs and process-identity bytes remain unchanged; only scope/result checks and outer resource values change. `changes.diff` shows the full existing operational-source delta; `source-provenance.json` records exact reused identities. The collector's reservation, identity, digest and direct-wait helper bodies are retained, with an explicit bound-tool argument replacing Koko's tool selector. No new lifecycle framework is introduced.

The success consumer independently rehashes package/raw/normalized/tool/stream files, checks all exact invocation and reservation records, expected normalized hashes, original child/collector/runner/launcher status, cleanup and process absence, then uses the frozen ordinary consume tool. Failed/unknown/timed-out/interrupted/forced outcomes remain failures; outputs stay held. Original field labels distinguish acquired host-tool execution from source/target execution.

## Root command handoff

Fresh default owner: `/workspace/tmp/pix-m7-fex-normalized-patches-20261015-01`. Refuse existing owner. Source packet: `/tmp/pix-m7-fex-normalized-patches-source-20261015`. Set actual resolved `TASK_PYTHON_PATH`, `TASK_PYTHON_SHA256`, `TASK_CURL_PATH`, `TASK_CURL_SHA256`, `TASK_DPKGDEB_PATH`, `TASK_DPKGDEB_SHA256` at root preparation; no guessed identity is embedded.

```bash
TASK_PACKET=/tmp/pix-m7-fex-normalized-patches-source-20261015
# Root source review and explicit acquired-normalizer authorization precede preparation.
bash "$TASK_PACKET/commands.sh" prepare
bash "$TASK_PACKET/commands.sh" preflight
bash "$TASK_PACKET/commands.sh" report
# Inspect actual reports; serialized ownership must be free before ordinary admission.
bash "$TASK_PACKET/commands.sh" admit
bash "$TASK_PACKET/commands.sh" launch
# Actively supervise <=60-second intervals and review every original result.
bash "$TASK_PACKET/commands.sh" consume
```

No original or shared source/cache file changes. No source compilation, Nix invocation, patch application, target/VM execution, package installation, offhost custody or publication. Source bodies, package binaries and raw streams remain private outside Git. Held Nixpkgs/twenty-patch/libglvnd custody and phase-A archives keep their own original outcomes; this packet neither repeats nor qualifies those runs. Even success leaves final source-custody integration and applicable notices/publication disposition explicit.

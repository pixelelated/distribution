#!/usr/bin/env python3
"""Source/metadata inspection only: never imports or executes candidate code."""
from pathlib import Path
import ast,hashlib,json,stat,difflib
P=Path(__file__).resolve().parent;B=Path('/tmp/pix-m7-koko-editing-source-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def defs(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
parsed=[]
for p in sorted(P.rglob('*.py')):ast.parse(p.read_text(),filename=str(p));parsed.append(str(p.relative_to(P)))
for p in P.rglob('*.json'):json.loads(p.read_text())
assert (P/'templates/process-identity.py').read_bytes()==(B/'templates/process-identity.py').read_bytes()
assert (P/'frozen-tools.json').read_bytes()==(B/'frozen-tools.json').read_bytes()
a,b=defs(B/'templates/run.py'),defs(P/'templates/run.py');assert a==b
c,d=defs(B/'templates/collect.py'),defs(P/'templates/collect.py')
identical=[n for n in c if n in d and c[n]==d[n]]
assert set(identical)=={'account','write','identity','budget','digest','reserve','release'}
old=(B/'templates/collect.py').read_text();new=(P/'templates/collect.py').read_text()
oldchild=ast.get_source_segment(old,next(n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name=='child'))
newchild=ast.get_source_segment(new,next(n for n in ast.parse(new).body if isinstance(n,ast.FunctionDef) and n.name=='child'))
normalized=newchild.replace('def child(key,argv,cap,wait_seconds,stdout,stderr,tool):','def child(key,argv,cap,wait_seconds,stdout,stderr):').replace('    global active\n',"    global active\n    tool=TOOLS['curl' if key.startswith('get-') else 'sevenzip']\n")
assert normalized==oldchild
for r in json.loads((P/'originals.json').read_text()):
 f=Path(r['path']);copy=P/r['copy'];assert sha(f)==sha(copy)==r['sha256']
 s=copy.stat();assert [s.st_size,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns]==[r[k] for k in ['bytes','mode','uid','gid','mtime_ns']]
plan=json.loads((P/'collection-plan.json').read_text());missing=json.loads(Path('/tmp/pix-m7-fex-source-phaseb-20261015/missing-fetch-descriptors.json').read_text())
for row,original in zip(plan['selected_patches'],missing[:2]):
 assert row['normalized_sha256']==original['outputs'][0][3] and row['raw_url']==original['fetch_fields']['urls']
assert len(plan['selected_patches'])==2 and plan['package']['bytes']==82352
refs={n:dict(base=sha(B/n),candidate=sha(P/n),unchanged=(P/n).read_bytes()==(B/n).read_bytes()) for n in ['prepare-owner.py','commands.sh','templates/collect.py','templates/consume.py','templates/bindings.py','templates/run.py','templates/run.sh','templates/process-identity.py','frozen-tools.json']}
(P/'source-provenance.json').write_text(json.dumps(dict(base_packet=str(B),base_seal=sha(B/'SHA256SUMS'),files=refs,unchanged_supervisor_functions=sorted(a),unchanged_collector_helpers=identical,child_wait_helper_delta='Only explicit tool argument replaces the Koko-specific tool selector. Wait, pidfd, original status and cleanup code are unchanged.'),indent=2,sort_keys=True)+'\n')
diff=''
for n in refs:
 if not refs[n]['unchanged']:diff+=''.join(difflib.unified_diff((B/n).read_text().splitlines(True),(P/n).read_text().splitlines(True),fromfile='accepted-koko/'+n,tofile='proposed-normalized-patches/'+n))
(P/'changes.diff').write_text(diff)
report=dict(status='PASS_STATIC_SOURCE_READBACK_ONLY',parsed_files=parsed,supervisor_helper_AST_identity=True,process_identity_byte_identity=True,reservation_identity_hash_helper_AST_identity=True,original_refs_verified=len(json.loads((P/'originals.json').read_text())),known_normalized_hashes_verified=True,candidate_executed=False,tests_executed=False,normalizer_executed=False,downloads=False,preparer_executed=False,diff_sha256=sha(P/'changes.diff'))
(P/'static-review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2))

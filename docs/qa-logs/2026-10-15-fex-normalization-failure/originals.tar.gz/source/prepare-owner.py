#!/usr/bin/env python3
"""Prepare one unrun FEX normalized patch owner; no download, archive read or CLI execution."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy,shlex,shutil,sys
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,o):
    with p.open('x') as f:json.dump(o,f,indent=2,sort_keys=True);f.write('\n')
def main():
    q=argparse.ArgumentParser(description=__doc__);q.add_argument('--owner',type=Path,required=True)
    for name in ['curl','dpkgdeb','python']:
        q.add_argument('--'+name+'-path',type=Path,required=True);q.add_argument('--'+name+'-sha256',required=True)
    q.add_argument('--allow-pinned-normalizer-execution',action='store_true',required=True)
    a=q.parse_args();names=[]
    for line in (P/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);p=P/n
        assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink() and sha(p)==h
        names.append(n)
    assert sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
    B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']();assert Path.cwd()==B['VM_TREE']
    plan=json.loads((P/'collection-plan.json').read_text());B['verify_plan'](plan)
    for name,h in json.loads((P/'frozen-tools.json').read_text()).items():assert B['sha'](B['VM_TREE']/name)==h
    O=a.owner
    assert O.parent==Path('/workspace/tmp') and O.parent.resolve(strict=True)==O.parent and re.fullmatch('pix-m7-fex-normalized-patches-20261015-[0-9]{2}',O.name)
    assert not O.exists() and not O.is_symlink()
    tools={}
    for name in ['curl','dpkgdeb','python']:
        path=getattr(a,name+'_path');expected=getattr(a,name+'_sha256');actual=B['cli_identity'](path)
        assert re.fullmatch('[0-9a-f]{64}',expected) and actual['sha256']==expected
        tools[name]=dict(path=str(path),identity=actual)
    assert Path(sys.executable).resolve(strict=True)==a.python_path,'preparer interpreter differs from explicit host identity'
    os.umask(0o077);O.mkdir(mode=0o700);(O/'stage').mkdir();(O/'empty-retention-scan').mkdir()
    for p in sorted((P/'templates').iterdir()):shutil.copy2(p,O/p.name)
    for n in ['collection-plan.json','resources.json','frozen-tools.json']:shutil.copy2(P/n,O/n)
    run_text=(O/'run.sh').read_text();assert run_text.count('@PYTHON@')==1
    (O/'run.sh').write_text(run_text.replace('@PYTHON@',shlex.quote(str(a.python_path))))
    put(O/'host-tools.json',tools)
    put(O/'preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),host_tools=tools,pid_namespace=os.readlink('/proc/self/ns/pid'),user_namespace=os.readlink('/proc/self/ns/user'),uid_map=Path('/proc/self/uid_map').read_text(),gid_map=Path('/proc/self/gid_map').read_text(),archives_downloaded=False,archives_read=False,collector_executed=False,pinned_normalizer_execution_authorized=a.allow_pinned_normalizer_execution,publication_clearance=False))
    put(O/'retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=['/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources',str(P),str(B['PROPOSAL'])],candidates=[],builds=[dict(name='m7-fex-normalized-patches',terms_bytes={'raw_patches_pinned_package_normalized_outputs_and_original_channels':128*1024**2},basis='Three exact URL requests,82,352B package and two raw patches capped1MiB each;64MiB owner within128MiB reservation. Selective two-tool package materialization and normalization only; no installation/cache scan/deletion credit.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])]))
    put(O/'admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-fex-normalized-patches',profiles=[dict(PROJECT='ROCKNIX',DEVICE='GENERIC_X64',ARCH='x86_64')],outputs=[dict(path=str(O),kind='qa-scratch',issue=528,release_when='Original acquisition/normalization consumed; exact normalized patches require final source custody. Raw bodies/package/tools/streams remain private outside Git. No installation or publication clearance.')]))
    put(O/'seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()})
    B['verify'](O)
    print(json.dumps(dict(owner=str(O),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),publication_clearance=False)))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Compose source-only continuation metadata; never execute collection or acquisition."""
from pathlib import Path
import hashlib,json,ast,difflib
P=Path(__file__).resolve().parent
BASE=Path('/tmp/pix-m7-fex-source-acquisition-continuation04-20261015')
OWNER=Path('/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04')
REVIEW=Path('/tmp/pix-m7-fex-continuation04-failure-review-20261015')
def raw(p):
    assert p.is_file() and not p.is_symlink() and p.stat().st_size<8*1024**2
    return p.read_bytes()
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
def load(p):return json.loads(raw(p))
def put(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
assert sha(BASE/'SHA256SUMS')=='d15a8eab2cc21329ca185c43c3d1f37fdb0835fe000e2df8368af30ba25e5239'
names=[]
for line in raw(BASE/'SHA256SUMS').decode().splitlines():
    h,n=line.split('  ',1);assert sha(BASE/n)==h
    if n in ['README.md','changed-lines.json','changes.diff','packet-manifest.json','static-review.json','source-provenance.json']:continue
    names.append(n)
assert len(names)<128
for n in names:
    dest=P/n;assert not dest.exists()
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw(BASE/n))
plan=load(P/'collection-plan.json')
plan['selected_archives']=plan['selected_archives'][1:]
plan['logical_downloads']=4;plan['max_actual_http_requests']=20
plan['intended_order']=[r['key'] for r in plan['selected_archives']]
archive=OWNER/'collection/05-wayland-1.24.0.tar.xz.archive.json'
wait=OWNER/'collection/05-wayland-1.24.0.tar.xz-2.curl.wait.json'
http=OWNER/'collection/05-wayland-1.24.0.tar.xz-2.http.json'
plan['reused_prior_archives'].append(load(archive))
plan['prior_archive_custody'].append(dict(owner=str(OWNER),archive_receipt=str(archive),wait_receipt=str(wait),http_receipt=str(http)))
failure=load(OWNER/'collection-failure.json')
assert sum(r['actual_bytes'] for r in failure['payload_reservations'])==242664
assert failure['completed_archives']==1 and load(REVIEW/'consume-exit.json')=={'original_tool_exit':0}
plan['prior_failures'].append(dict(owner=str(OWNER),run='/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T140837Z-d296bdd6',disposition='failed-investigated',acceptance=str(REVIEW/'acceptance.json'),investigation=str(REVIEW/'investigation.json'),consume_exit=str(REVIEW/'consume-exit.json'),consume_exit_field='original_tool_exit',failure_receipt=str(OWNER/'collection-failure.json'),response_body_bytes=242664,completed_archives=1))
refs=[BASE/'SHA256SUMS',archive,wait,http,OWNER/'collection-failure.json',REVIEW/'investigation.json',REVIEW/'acceptance.json',REVIEW/'consume-exit.json',OWNER/'collection/05-wayland-1.24.0.tar.xz-0.http.json',OWNER/'collection/05-wayland-1.24.0.tar.xz-1.http.json']
for f in refs:
    h=sha(f);plan['binding_refs'][str(f)]=h
    (P/'originals'/(h+'-'+f.name)).write_bytes(raw(f))
held=sum(r['archive']['bytes'] for r in plan['reused_prior_archives'])
prior=sum(r['response_body_bytes'] for r in plan['prior_failures'])
assert held==266879580 and prior==266881546
plan['phase_A_response_body_accounting']=dict(original_aggregate_cap_bytes=402653184,held_verified_archive_bytes=held,prior_response_body_bytes=prior,prior_redirect_body_bytes=prior-held,continuation_response_body_cap_bytes=402653184-prior)
plan['status']='SOURCE_ONLY_DRAFT_PENDING_ROUTE_EVIDENCE'
put(P/'collection-plan.json',plan)
resources=load(P/'resources.json');resources.update(logical_downloads=4,max_http_requests_including_redirects=20,compressed_archive_aggregate_bytes=135771638)
resources['limits_basis']='Four missing sources only. 135,771,638 new response-body bytes + 266,879,580 verified held archive bytes + 1,966 prior redirect-body bytes = original 384 MiB cumulative phase-A cap. At most 20 actual requests, four redirects per logical source, with unchanged 192 MiB individual cap, 1 GiB owner, before-write reservations and deadlines.'
put(P/'resources.json',resources)
def change(name,replacements):
    p=P/name;s=p.read_text()
    for old,new in replacements:
        assert old in s,(name,old);s=s.replace(old,new)
    p.write_text(s)
change('templates/collect.py',[
('Acquire five missing exact full source archives and verify three held prior archives','Acquire four missing exact full source archives and verify four held prior archives'),
("len(PLAN['selected_archives'])==5 and PLAN['logical_downloads']==5","len(PLAN['selected_archives'])==4 and PLAN['logical_downloads']==4"),
("for r in PLAN['selected_archives']})==5","for r in PLAN['selected_archives']})==4"),
("len(PLAN['reused_prior_archives'])==3","len(PLAN['reused_prior_archives'])==4"),('logical_downloads=5,actual_http_requests','logical_downloads=4,actual_http_requests')])
change('templates/run.py',[
("len(report['rows'])==5 and report['logical_downloads']==5 and 5<=report['actual_http_requests']<=25","len(report['rows'])==4 and report['logical_downloads']==4 and 4<=report['actual_http_requests']<=20"),
("len(report['reused_prior_archives'])==3","len(report['reused_prior_archives'])==4"),
('Five missing FEX selected header-source archives plus verified held Linux/glibc/GCC references','Four missing FEX selected header-source archives plus verified held Linux/glibc/GCC/Wayland references')])
change('templates/consume.py',[
("report['compressed_bytes']+266638882","report['compressed_bytes']+266881546"),
("len(report['rows'])==5 and report['logical_downloads']==5 and 5<=len(report['downloads'])<=25","len(report['rows'])==4 and report['logical_downloads']==4 and 4<=len(report['downloads'])<=20"),
('Five missing exact flat source archives acquired and verified; held prior Linux/glibc/GCC reverified','Four missing exact flat source archives acquired and verified; held prior Linux/glibc/GCC/Wayland reverified'),
('PASS consumed five new exact FEX source archives with held Linux/glibc/GCC references','PASS consumed four new exact FEX source archives with held Linux/glibc/GCC/Wayland references')])
change('guard-controls.py',[("'max_http_requests_including_redirects':25","'max_http_requests_including_redirects':20"),
("[{}]*25;case('actual-http-request-twenty-six-refuses'","[{}]*20;case('actual-http-request-twenty-one-refuses'"),
("[{}]*24;case('actual-http-request-twenty-five-allowed'","[{}]*19;case('actual-http-request-twenty-allowed'")])
change('prepare-owner.py',[
("'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-03'],candidates=[]","'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-03','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04'],candidates=[]"),
('136014302B new body cap; prior266637816B Linux/glibc/GCC and1066B redirect bodies','135771638B new body cap; prior266879580B Linux/glibc/GCC/Wayland and1966B redirect bodies')])
change('commands.sh',[
('pix-m7-fex-source-acquisition-continuation04-20261015','pix-m7-fex-source-acquisition-continuation05-20261015'),
('pix-m7-fex-source-acquisition-20261015-04','pix-m7-fex-source-acquisition-20261015-05'),
('pix-m7-fex-source-acquisition-guards-20261015-04.json','pix-m7-fex-source-acquisition-guards-20261015-05.json')])
change('templates/bindings.py',[
("INTENDED_ORDER=['05-wayland-1.24.0.tar.xz', ","INTENDED_ORDER=["),
("len(plan['selected_archives'])==5 and plan['logical_downloads']==5","len(plan['selected_archives'])==4 and plan['logical_downloads']==4"),
("len(prior)==len(custody)==3","len(prior)==len(custody)==4"),
("[r['canonical_url'] for r in selected]==[proposal['phase_A']['files'][i]['urls'][0] for i in [4,5,6,7,1]]","[r.get('provenance_url',r['canonical_url']) for r in selected]==[proposal['phase_A']['files'][i]['urls'][0] for i in [5,6,7,1]]"),
("for i in [0,2,3]]","for i in [0,2,3,4]]"),
("len(failures)==3","len(failures)==4"),
("'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-03']","'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-03','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04']"),
('[152673392,166,113965324]','[152673392,166,113965324,242664]'),
('266637816','266879580'),('266638882','266881546'),('prior_redirect_body_bytes=1066','prior_redirect_body_bytes=1966'),('136014302','135771638'),
("limits['max_http_requests_including_redirects']==25","limits['max_http_requests_including_redirects']==20"),
("assert selected[0]['allowed_redirect_hosts']==route['allowed_redirect_hosts']", "assert prior[3]['selection']['allowed_redirect_hosts']==route['allowed_redirect_hosts']"),
("for r in selected[1:])","for r in selected)"),
("assert [r['allowed_redirect_hosts'] for r in selected[1:]]==[['ftp.x.org','xorg.freedesktop.org'],['ftp.x.org','xorg.freedesktop.org'],['ftp.x.org','xorg.freedesktop.org'],['dri.freedesktop.org']]","assert plan['status']=='SOURCE_ONLY_SEALED_UNRUN', 'route evidence must be finalized before allocation'")])
binding=load(P/'guard-controls-binding.json');binding['collector_sha256']=sha(P/'templates/collect.py');put(P/'guard-controls-binding.json',binding)
for p in P.rglob('*.py'):ast.parse(raw(p),filename=str(p))
print(json.dumps({'result':'SOURCE_DELTA_COMPOSED_PENDING_ROUTE_EVIDENCE','named_payloads_copied':len(names),'held_verified_archive_bytes':held,'prior_response_body_bytes':prior,'remaining_response_body_cap':402653184-prior,'candidate_executed':False}))

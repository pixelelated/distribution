#!/usr/bin/env python3
"""Bind observed routes and seal reviewable source. No candidate/network invocation."""
from pathlib import Path
import ast,hashlib,json,urllib.parse,difflib,datetime
P=Path(__file__).resolve().parent
BASE=Path('/tmp/pix-m7-fex-source-acquisition-continuation04-20261015')
D=Path('/tmp/pix-m7-freedesktop-mirrors-20261015')
def read(p):
    assert p.is_file() and not p.is_symlink() and p.stat().st_size<8*1024**2
    return p.read_bytes()
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def load(p):return json.loads(read(p))
def put(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
plan=load(P/'collection-plan.json')
assert plan['status']=='SOURCE_ONLY_DRAFT_PENDING_ROUTE_EVIDENCE'
diagnostic=load(D/'result.json');acceptance=load(D/'root-acceptance.json');redirects=load(D/'redirects.json')
assert diagnostic['head_only'] is True and diagnostic['source_bodies_downloaded'] is False and diagnostic['redirects_followed'] is False
assert acceptance['original_tool_exit']==0 and all(acceptance['runner'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert acceptance['head_only'] is True and acceptance['redirects_followed'] is False and acceptance['archives_downloaded'] is False
assert len(diagnostic['rows'])==4 and len(redirects)==3
rows={r['name']:r for r in diagnostic['rows']};loc={r['probe']:r for r in redirects}
routes=[('yehkri-x11','https://yehkri.com/mirror/xorg/individual/lib/libX11-1.8.12.tar.xz'),('yehkri-proto','https://yehkri.com/mirror/xorg/individual/proto/xorgproto-2024.1.tar.xz'),('yehkri-randr','https://yehkri.com/mirror/xorg/individual/lib/libXrandr-1.5.4.tar.xz'),('osuosl-drm','https://ftp2.osuosl.org/pub/blfs/conglomeration/libdrm/libdrm-2.4.129.tar.xz')]
for selected,(name,url) in zip(plan['selected_archives'],routes):
    row=rows[name];assert row['url']==url and row['original_curl_exit']==0 and row['wait_observed'] is True
    assert '--head' in row['argv'] and '--location' not in row['argv'] and row['argv'][row['argv'].index('--retry')+1]=='0'
    selected['provenance_url']=selected['canonical_url'];selected['canonical_url']=url
    selected['route_head_probe']=name
    if name.startswith('yehkri-'):
        observed=loc[name];target=observed['location'];parsed=urllib.parse.urlsplit(target)
        assert row['summary'].split()[0]=='301' and observed['header_sha256']==row['stderr_sha256']
        assert target==url.replace('https://yehkri.com/','https://florian-kirchner.com/')
        assert parsed.scheme=='https' and parsed.netloc==parsed.hostname=='florian-kirchner.com' and not parsed.query and not parsed.fragment and parsed.username is None
        selected['allowed_redirect_hosts']=['florian-kirchner.com','yehkri.com'];selected['allowed_redirect_urls']=[target]
    else:
        assert row['summary'].split()[0]=='200';selected['allowed_redirect_hosts']=['ftp2.osuosl.org'];selected['allowed_redirect_urls']=[]
    selected['route_disposition']='Public metadata only. Preserve original upstream flat digest; HEAD is route evidence, not proof of archive bytes. No automatic retries.'
for f in [D/'result.json',D/'root-acceptance.json',D/'redirects.json']:
    h=sha(f);plan['binding_refs'][str(f)]=h;(P/'originals'/(h+'-'+f.name)).write_bytes(read(f))
for f in sorted((P/'route-evidence').glob('*.json')):plan['binding_refs'][str(f)]=sha(f)
plan['mirror_route_revision']=dict(diagnostic_result=str(D/'result.json'),diagnostic_acceptance=str(D/'root-acceptance.json'),observed_redirects=str(D/'redirects.json'),official_xorg_mirror_page='https://www.x.org/Releases/Download/',official_blfs_mirror_page='https://www.linuxfromscratch.org/blfs/download.html',official_page_readback=str(P/'route-evidence/officialMirrorPages.json'),osuosl_root_readback=str(P/'route-evidence/mirrorRoots.json'),libdrm_directory_readback=str(P/'route-evidence/exactMirrorRows.json'),unattempted_redirects_refused=True,archive_bodies_read_for_route_verification=False)
plan['status']='SOURCE_ONLY_SEALED_UNRUN'
put(P/'collection-plan.json',plan)
def change(name,old,new):
    p=P/name;s=p.read_text();assert old in s,(name,old);p.write_text(s.replace(old,new))
change('templates/collect.py',"    if hop==0:assert url==selection['canonical_url'] and not u.query,'initial URL differs from exact source'", "    if hop==0:assert url==selection['canonical_url'] and not u.query,'initial URL differs from exact source'\n    elif 'allowed_redirect_urls' in selection:assert url in selection['allowed_redirect_urls'],'redirect differs from exact observed route'")
change('templates/consume.py',"        assert request['url_sha256']==hashlib.sha256(url.encode()).hexdigest()", "        if i and 'allowed_redirect_urls' in selection:assert url in selection['allowed_redirect_urls'],'unobserved redirect route'\n        assert request['url_sha256']==hashlib.sha256(url.encode()).hexdigest()")
change('guard-controls.py',"case('public-redirect-redacts-path-and-query'", "narrow=dict(selection,allowed_redirect_urls=['https://mirror.example/exact/source.tar.xz'])\ncase('exact-observed-mirror-path-accepted',lambda:ns['validate_request_url']('https://mirror.example/exact/source.tar.xz',narrow,1))\ncase('unobserved-path-on-authorized-host-refuses',lambda:ns['validate_request_url']('https://mirror.example/other/source.tar.xz',narrow,1),True)\ncase('unobserved-query-on-authorized-path-refuses',lambda:ns['validate_request_url']('https://mirror.example/exact/source.tar.xz?extra=value',narrow,1),True)\ncase('direct-route-with-no-observed-redirect-refuses',lambda:ns['validate_request_url']('https://mirror.example/exact/source.tar.xz',dict(narrow,allowed_redirect_urls=[]),1),True)\ncase('public-redirect-redacts-path-and-query'")
marker="    assert plan['status']=='SOURCE_ONLY_SEALED_UNRUN', 'route evidence must be finalized before allocation'"
replacement=marker+'''
    route=plan['mirror_route_revision'];diagnostic=load(route['diagnostic_result']);accepted=load(route['diagnostic_acceptance'])
    assert diagnostic['head_only'] is True and diagnostic['redirects_followed'] is False and diagnostic['source_bodies_downloaded'] is False
    assert accepted['original_tool_exit']==0 and all(type(accepted['runner'][k])is int and accepted['runner'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert accepted['head_only'] is True and accepted['redirects_followed'] is False and accepted['archives_downloaded'] is False
    rows={r['name']:r for r in diagnostic['rows']};locations={r['probe']:r for r in load(route['observed_redirects'])}
    assert len(rows)==4 and len(locations)==3 and diagnostic['requests']==4
    official=json.dumps(load(route['official_page_readback']))
    assert 'https://yehkri.com/mirror/xorg/' in official and 'ftp.osuosl.org/pub/blfs/' in official
    assert 'https://ftp2.osuosl.org/pub/blfs/' in json.dumps(load(route['osuosl_root_readback']))
    assert 'libdrm-2.4.129.tar.xz' in json.dumps(load(route['libdrm_directory_readback']))
    expected=[('yehkri-x11','https://yehkri.com/mirror/xorg/individual/lib/libX11-1.8.12.tar.xz'),('yehkri-proto','https://yehkri.com/mirror/xorg/individual/proto/xorgproto-2024.1.tar.xz'),('yehkri-randr','https://yehkri.com/mirror/xorg/individual/lib/libXrandr-1.5.4.tar.xz'),('osuosl-drm','https://ftp2.osuosl.org/pub/blfs/conglomeration/libdrm/libdrm-2.4.129.tar.xz')]
    for selection,(name,url) in zip(selected,expected):
        row=rows[name];assert selection['canonical_url']==row['url']==url and selection['route_head_probe']==name
        assert type(row['original_curl_exit'])is int and row['original_curl_exit']==0 and row['wait_observed'] is True
        assert '--head' in row['argv'] and '--location' not in row['argv'] and row['argv'][row['argv'].index('--retry')+1]=='0'
        if name.startswith('yehkri-'):
            observed=locations[name];target=observed['location'];u=urllib.parse.urlsplit(target)
            assert row['summary'].split()[0]=='301' and observed['header_sha256']==row['stderr_sha256']
            assert target==url.replace('https://yehkri.com/','https://florian-kirchner.com/')
            assert u.scheme=='https' and u.netloc==u.hostname=='florian-kirchner.com' and not u.query and not u.fragment and u.username is None
            assert selection['allowed_redirect_hosts']==['florian-kirchner.com','yehkri.com'] and selection['allowed_redirect_urls']==[target]
        else:
            assert row['summary'].split()[0]=='200' and selection['allowed_redirect_hosts']==['ftp2.osuosl.org'] and selection['allowed_redirect_urls']==[]
'''
change('templates/bindings.py',marker,replacement.rstrip())
binding=load(P/'guard-controls-binding.json');binding['collector_sha256']=sha(P/'templates/collect.py')
tree=ast.parse(read(P/'templates/collect.py'))
names={'account_output','effective_request_cap','reserve_payload','release_payload','validate_request_url','public_url','curl_argv','check_request_count','download'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
binding['extended_guard_ast_sha256']=hashlib.sha256(ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False).encode()).hexdigest()
put(P/'guard-controls-binding.json',binding)
print(json.dumps({'result':'SOURCE_ROUTE_BINDINGS_FINALIZED','candidate_executed':False,'new_urls':[r['canonical_url'] for r in plan['selected_archives']],'new_flat_sha256':[r['sha256'] for r in plan['selected_archives']]}))

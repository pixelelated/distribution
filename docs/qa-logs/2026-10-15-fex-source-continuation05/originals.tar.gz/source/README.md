# FEX phase-A continuation 05 — source only, unrun

This packet acquires exactly four remaining archives, in this order: **libX11 1.8.12, xorgproto 2024.1, libXrandr 1.5.4, libdrm 2.4.129**. Linux, glibc, GCC, and Wayland stay in their original owners and are verified before and after collection. The four new selections plus four prior receipts must equal all eight original upstream URL/hash identities, without overlap. Historical ALSA/libxcb/libXrender references remain unchanged.

| New archive | Original flat SHA-256 |
| --- | --- |
| libX11-1.8.12.tar.xz | `fa026f9bb0124f4d6c808f9aef4057aad65e7b35d8ff43951cef0abe06bb9a9a` |
| xorgproto-2024.1.tar.xz | `372225fd40815b8423547f5d890c5debc72e88b91088fbfb13158c20495ccb59` |
| libXrandr-1.5.4.tar.xz | `1ad5b065375f4a85915aa60611cc6407c060492a214d7f9daf214be752c3b4d3` |
| libdrm-2.4.129.tar.xz | `5978183f978d697e26a50ba066174964efb0ab97caa1ecaa1b861fbe5ddf77dc` |

The [official Xorg mirror list](https://www.x.org/Releases/Download/) names `https://yehkri.com/mirror/xorg/`. The three exact initial paths are its `individual/lib/libX11-1.8.12.tar.xz`, `individual/proto/xorgproto-2024.1.tar.xz`, and `individual/lib/libXrandr-1.5.4.tar.xz`. Root's original HEAD receipts returned curl 0 / HTTP 301 for each and observed the exact same paths on `https://florian-kirchner.com/`. Each selection permits only its single observed redirect URL, including exact path and no query. HTTPS, authority, no-userinfo, no-port, and no-fragment checks remain enforced. An additional redirect destination refuses before contact.

The [official BLFS download page](https://www.linuxfromscratch.org/blfs/download.html) names OSUOSL's BLFS mirror. Its HTTPS root resolves to `ftp2.osuosl.org`; the directory lists the exact libdrm filename. Root's HEAD of `https://ftp2.osuosl.org/pub/blfs/conglomeration/libdrm/libdrm-2.4.129.tar.xz` returned curl 0 / HTTP 200. This source has no authorized redirect URL. These HEAD results establish route provenance only: the collector must still observe HTTP 200 and verify each complete body against the unchanged upstream hash.

The route receipts are frozen at `/tmp/pix-m7-freedesktop-mirrors-20261015/{result.json,root-acceptance.json,redirects.json}` and copied under `originals/` by digest. Original raw diagnostic stderr remains private. Browser metadata receipts total 40,209 bytes; no archive URL was opened. Direct metadata requests in this source-reader sandbox failed DNS with zero transferred body bytes. Browser internal transfer sizes are not exposed; retained reader text is bounded below 2 MiB.

Four prior failed-investigated runs remain failures; their accepted individual completions are reused explicitly:

| Owner | Completed archives retained | Archive bytes | Redirect body bytes |
| --- | --- | ---: | ---: |
| 01 | Linux 6.16.7 | 152,673,392 | 0 |
| 02 | None | 0 | 166 |
| 03 | glibc 2.40 and GCC 14.3.0 | 113,964,424 | 900 |
| 04 | Wayland 1.24.0 | 241,764 | 900 |

Every reuse binds its original archive/HTTP/wait receipt, owning directory, and containing run's accepted failure consumption. The existing collector loops recheck all four bodies and file identities before/after. The consumer rehashes each under its own original owning archives directory. No completed archive is downloaded or copied again. Source preparation did not reread these archive bodies.

`266,879,580 held archive bytes + 1,966 prior redirect-body bytes + 135,771,638 new response-body bytes = 402,653,184 bytes (384 MiB)`.

The new allowance includes every redirect and partial body. Four logical downloads permit at most 20 actual requests, with four redirects maximum per source. There are no retries or fallback routes. Any failure stops collection and preserves originals for ordinary failed-investigation consumption.

Unchanged limits: 192 MiB per body, reduced before each request by remaining aggregate and owner capacity; 1 GiB fresh owner; 2 GiB retention reservation; 16 MiB normal receipt reserve; 1 MiB bounded failure receipt; 8 MiB supervisor receipt reserve use; full body-plus-both-log reservations before writes; 580-second soft / 600-second supervisor / 630+15-second outer deadlines; 120 seconds per logical source across redirects; 10-second connection cap; two CPUs; 2 GiB address space; 4 GiB named streamed reads; 512 files / 16 directories. One collector invokes one curl at a time; maximum 20 curl requests. No archive extraction, source execution, compiler, Nix, build, VM, listener, or target runtime.

Lifecycle changes are limited to four-new/four-reused counts and scope. Process-identity and base write controls are byte-identical to source04. Transport/reservation functions are unchanged except one precise observed-redirect-URL assertion in the existing URL validator, independently repeated by the consumer. The original 48 focused guards remain, with the count boundary tightened to 20; four focused URL controls bring the prepared suite to 52. **All candidate guards, preparation, and acquisition remain unrun.** `changes.diff` and `static-review.json` record the finite source review, including correction of one stale consumer aggregate constant before sealing.

Phase B is separately sealed at `/tmp/pix-m7-fex-source-phaseb-20261015`; this continuation does not perform it. Source custody is not notice, independent retrieval, offhost, or publication clearance. All future raw curl stdout/stderr remain private and excluded from Git.

Root reviews and allocates each command separately; `commands.sh` defaults to fresh owner suffix 05 and guard suffix 05. Run `guards`, set `TASK_GUARD_RUN`, `TASK_CURL_PATH`, and `TASK_CURL_SHA256` from original receipts, then run `prepare`, `preflight`, `report`, `admit`, and `launch`. Root actively supervises at intervals no longer than 60 seconds. Use `consume` only after every original success channel and custody check passes. Failure uses the existing failed-investigation process; never rerun a used owner or widen limits.

```bash
bash /tmp/pix-m7-fex-source-acquisition-continuation05-20261015/commands.sh guards
# Root exports the original guard run and exact host curl identity.
bash /tmp/pix-m7-fex-source-acquisition-continuation05-20261015/commands.sh prepare
bash /tmp/pix-m7-fex-source-acquisition-continuation05-20261015/commands.sh preflight
bash /tmp/pix-m7-fex-source-acquisition-continuation05-20261015/commands.sh report
bash /tmp/pix-m7-fex-source-acquisition-continuation05-20261015/commands.sh admit
bash /tmp/pix-m7-fex-source-acquisition-continuation05-20261015/commands.sh launch
# After original success and independent root review:
bash /tmp/pix-m7-fex-source-acquisition-continuation05-20261015/commands.sh consume
```

from pathlib import Path
import subprocess,resource,json,hashlib
P=Path(__file__).resolve().parent
rows=[]
for port,filename in [('xorg-libX11','libX11-1.8.12.tar.xz'),('xorg-libXrandr','libXrandr-1.5.4.tar.xz'),('xorg-xorgproto','xorgproto-2024.1.tar.xz')]:
 url='https://distfiles.macports.org/'+port+'/'
 def limits():
  resource.setrlimit(resource.RLIMIT_FSIZE,(262144,262144));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
 with (P/(port+'.html')).open('xb') as out,(P/(port+'.stderr')).open('xb') as err:
  c=subprocess.Popen(['/usr/bin/curl','-q','--fail','--silent','--show-error','--proto','=https','--connect-timeout','5','--max-time','12','--retry','0','--max-filesize','262144',url],stdin=subprocess.DEVNULL,stdout=out,stderr=err,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},preexec_fn=limits)
  try:rc=c.wait(timeout=15)
  except subprocess.TimeoutExpired:c.kill();rc=c.wait();raise RuntimeError('outer timeout')
 body=(P/(port+'.html')).read_bytes();row=dict(url=url,original_curl_exit=rc,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),filename=filename,filename_present=filename.encode() in body);rows.append(row);print(row,flush=True)
(P/'result.json').write_text(json.dumps(dict(rows=rows,archive_bodies=False,redirects_followed=False),indent=2)+'\n')

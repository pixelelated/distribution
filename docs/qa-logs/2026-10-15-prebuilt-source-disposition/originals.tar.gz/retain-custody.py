from pathlib import Path
from decimal import Decimal
import hashlib,json,stat,tarfile
P=Path(__file__).resolve().parent;C=P/'custody';C.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# Retain selected exact small evidence. Exclude unrelated issue-body search payload;
# its original fetch URL/hash/status and non-exhaustive result limit remain retained.
excluded={'upstream/rclone-dirty-release-issues.json'}
rows=[]
for f in sorted(P.rglob('*')):
 if not f.is_file() or C in f.parents or str(f.relative_to(P)) in excluded:continue
 assert not f.is_symlink();s=f.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<2*1024**2
 rows.append(dict(member=str(f.relative_to(P)),source=str(f),bytes=s.st_size,sha256=sha(f),mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns))
with tarfile.open(C/'originals.tar.gz','w:gz',format=tarfile.PAX_FORMAT) as tar:
 for r in rows:
  t=tarfile.TarInfo(r['member']);t.size=r['bytes'];t.mode=r['mode'];t.uid=r['uid'];t.gid=r['gid'];t.mtime=r['mtime_ns']//10**9;t.pax_headers={'mtime':str(Decimal(r['mtime_ns'])/Decimal(10**9))}
  with Path(r['source']).open('rb') as f:tar.addfile(t,f)
with tarfile.open(C/'originals.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  assert (m.name,m.size,m.mode,m.uid,m.gid)==(r['member'],r['bytes'],r['mode'],r['uid'],r['gid']) and m.isfile()
  assert Decimal(m.pax_headers['mtime'])*10**9==r['mtime_ns'] and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==r['sha256']
  p=Path(r['source']);s=p.stat();assert sha(p)==r['sha256'] and (s.st_size,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns)==(r['bytes'],r['mode'],r['uid'],r['gid'],r['mtime_ns'])
(C/'members.json').write_text(json.dumps(dict(archive='originals.tar.gz',archive_sha256=sha(C/'originals.tar.gz'),members=rows,regular_files_only=True,directory_metadata_claimed=False,excluded_originals=[dict(path=str(P/n),sha256=sha(P/n),reason='Unrelated general issue search body; URL/status/hash retained in fetch-round4, review-limit observation retained.') for n in sorted(excluded)]),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(members=len(rows),payload_bytes=sum(r['bytes'] for r in rows),archive_bytes=(C/'originals.tar.gz').stat().st_size,archive_sha256=sha(C/'originals.tar.gz'))))

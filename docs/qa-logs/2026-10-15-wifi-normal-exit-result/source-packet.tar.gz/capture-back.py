#!/usr/bin/env python3
"""UNRUN focused capture adapter; caller independently kills/reaps after12s."""
import argparse,hashlib,json,re,runpy,time
from pathlib import Path

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,row):path.write_text(json.dumps(row,indent=2)+'\n')

def main():
 p=argparse.ArgumentParser()
 p.add_argument('action',choices=['reference','back'])
 for name in ['tool','monitor','output']:p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--tool-sha256',required=True);p.add_argument('--vnc-port',type=int,required=True)
 p.add_argument('--reference',type=Path);p.add_argument('--reference-sha256');p.add_argument('--key')
 a=p.parse_args();assert sha(a.tool)==a.tool_sha256 and not a.output.exists();a.output.mkdir()
 tool=runpy.run_path(str(a.tool),run_name='pix_frozen_visual_capture')
 mon=None;frames=[];result={'status':'FAIL','action':a.action,'clock':'host monotonic','samples':[],'limit_seconds':1,'original_returncode':1}
 def capture(endpoint):
  began=time.monotonic();w,h,rgb=tool['vnc_frame'](*endpoint,timeout=.5);ended=time.monotonic()
  assert (w,h)==(640,480) and len(rgb)==640*480*3
  raw=b'P6\n640 480\n255\n'+rgb
  return raw,{'capture_started_monotonic':began,'rgb_received_monotonic':ended,'ppm_sha256':hashlib.sha256(raw).hexdigest()}
 try:
  mon=tool['Monitor'](str(a.monitor));endpoint=mon._vnc_endpoint()
  assert endpoint==('127.0.0.1',a.vnc_port),'VNC must be this admitted QEMU loopback endpoint'
  result['vnc_endpoint']=endpoint
  raw,row=capture(endpoint);frames.append(('reference' if a.action=='reference' else 'before-key',raw));result['pre_key_frame']=row
  if a.action=='reference':result.update(status='PASS',original_returncode=0)
  else:
   assert a.reference and sha(a.reference)==a.reference_sha256
   reference=a.reference.read_bytes();assert len(reference)==len(raw) and reference.startswith(b'P6\n640 480\n255\n')
   assert raw!=reference,'picker/searching must differ from reviewed return page before key'
   assert a.key and re.fullmatch('[a-z0-9_-]+',a.key)
   result['reference']={'path':str(a.reference),'sha256':a.reference_sha256}
   # No process startup, banner drain, endpoint discovery or PNG conversion in
   # this interval. All actual send, guest work and complete VNC acquisition stay.
   began=time.monotonic();result['key_send_started_monotonic']=began
   mon.sock.sendall(('sendkey '+a.key+'\n').encode('ascii'))
   result['key_send_finished_monotonic']=time.monotonic()
   for number in range(32):
    if time.monotonic()-began>=1:break
    raw,row=capture(endpoint);row.update(index=number,exact_reference_match=raw==reference,elapsed_upper_bound_seconds=row['rgb_received_monotonic']-began)
    frames.append(('sample-%02d'%number,raw));result['samples'].append(row)
    if row['exact_reference_match']:
     result['first_matching_sample']=number;result['upper_bound_seconds']=row['elapsed_upper_bound_seconds']
     if row['elapsed_upper_bound_seconds']<=1:result.update(status='PASS',original_returncode=0)
     break
   result['hmp_reply']=mon._drain(.1)
   assert not any(word in result['hmp_reply'].lower() for word in ['error','unknown','invalid'])
 except BaseException as error:
  result.update(status='FAIL',original_returncode=1,error=type(error).__name__+': '+str(error))
 finally:
  if mon is not None:mon.close()
  # Keep every original sampled frame, including late/nonmatching ones.
  for name,raw in frames:
   ppm=a.output/(name+'.ppm');ppm.write_bytes(raw);png=a.output/(name+'.png')
   assert tool['to_png'](str(ppm),str(png));result.setdefault('frames',[]).append({'name':name,'ppm_sha256':sha(ppm),'png_sha256':sha(png)})
  save(a.output/'result.json',result)
 return result['original_returncode']

if __name__=='__main__':raise SystemExit(main())

# #593 candidate Back/reopen continuation — SOURCE ONLY, UNRUN

Run02 remains failed. The actual returned Network Settings PNG and its earlier
reviewed selection PNG have identical SHA256
`1792ba79e417aae546e91240095dbd8e24a206790f5006e10d00fd50858346e2`.
Back reached the correct page. Its reported2.284990287s is the complete host
key command0.816019562s, explicit pause0.100530606s, screenshot command1.367923784s
and surrounding bookkeeping. The frozen vm-visual-qa starts a new HMP connection
for each command: two0.5s banner drains, key0.1s response drain plus0.15s gap,
shot0.3s drain and0.4s VNC endpoint discovery already impose about2.05s before
frame transport/PNG conversion. That composite cannot establish subsecond UI
response. No subtraction converts that old result into a pass; reopen was not
exercised. Exact originals are retained under `evidence/` with their source paths.

The new helper reuses the exact hash-bound frozen vm-visual-qa definitions at
allocated runtime. A reference capture saves full640x480 PPM and PNG pixels;
root reviews that same PNG before picker activation. For Back, HMP connection,
endpoint discovery and one searching pre-frame occur before the clock. The
pre-frame must differ from the reference. Time starts immediately before the
actual `sendkey` socket send, and ends at complete RGB receipt of the first
byte-identical reference frame. Every VNC connection, read, guest response and
intermediate sample stays inside the upper bound. There is no mask, tolerance,
pixel-change shortcut, fixed delay subtraction or threshold increase. The
original1s limit remains; a matching frame received late fails. All sampled
frames and receive times are retained, with at most32 samples. PNG encoding
occurs after timing; full unencoded RGB receipt is the observed event.

The capture helper has an independent12s outer timeout with original status,
kill/reap and failure preservation through the existing host execute function.
The existing per-VNC call timeout0.5s alone is not asserted to be a hard whole-call
deadline. Persistent HMP is warmed; VNC connections are deliberately retained
inside each measured acquisition. No product timing instrumentation is added.

Only candidate Back/reopen runs in this fresh owner. The preparer rehashes the
actual consumed run02 originals and their retained copies, checks all four worker
control statuses and exact compiled driver identities, and checks the actual
full-ES baseline negative plus candidate normal-SIGINT/join/custody results.
It requires consumed admission341087f6d3d44905b7447199e9713de1 and original
command/monitor/runner1/0/1. Root's failed-investigated review remains explicit.
Those facts are copied into a separately named imported-prerequisites receipt;
no local controls/review result is synthesized, and controls/baseline/refusal
actions are unavailable. Full-ES lifecycle is already qualified separately.

The candidate ES is still16dbac5211eea7e70db7394372033be2be7df829, binary
067defd8c760ae9085b1faba1ada643812be494be39e5690a472ab241258ab5d, explicitly
overlaid at the installed executable path in the frozen d4af/ES3178 image.
Final rebuilt-image acceptance remains pending. The original backend and GUI
observer, subprocess identity/census/pidfd custody, one-job assertion,75s first
backend wait,25s blocked handshake,30s production scan deadline, normal SIGINT
and no-forced-cleanup candidate oracle are unchanged. Reopen must show searching
and retain the same two blocked PID/start identities with exactly one enumeration.
Normal exit here closes this fresh fixture; it does not replace the prior proof.

Can this be done on the VM? Yes: menu input, real frontend response and process
ownership are VM-observable. No radio, physical panel, SIGTERM/fatal containment,
real network scan or hardware result is claimed. Root records the focused scope
in #593 before allocating. The unchanged presentation and flow references remain
docs/es-menu-map.md Wi-Fi picker, prior setup-qualification Back/reopen and the
accepted #577640/1280 frames; this continuation changes no label or layout and
does not replay the accepted full matrices.

One fresh no-NIC guest retains8GiB/4CPU/16GiB, existing host census/admission,
serial lock, stop/export and restore paths. Work is reduced to600s plus120s
cleanup. Export remains128MiB and4096files including manifest; frames64MiB.
Only system.cfg/es_settings are temporarily changed and restored as before;
no Dolphin config fixture is staged. Reference/matching pixels and four reviewed
frames are the new evidence. No current owner or sealed parent packet is edited.

Root-only preparation after the active1280 owner is completed and consumed:

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01
TASK_PACKET=/tmp/pix-m7-wifi-back-reopen-plan-20261015
TASK_OWNER=/workspace/tmp/pix-m7-wifi-back-reopen-20261015-01
python3 -I -S -B "$TASK_PACKET/prepare.py" --checkout "$TASK_TREE" \
  --verification /workspace/tmp/pix-m7-image-readback-20261015-01/artifacts \
  --author-owner /workspace/tmp/pix-m7-mkdcdisc-20261014-01 \
  --owner "$TASK_OWNER" --vnc 144
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
# Review originals, actual free VNC144 and sole runtime allocation first.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

After actual visual-ready:

```bash
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" init
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-start --mode candidate
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-select
```

View `wifi-candidate-selected-network` promptly inside the unchanged75s first
backend handshake. Only if WI-FI NETWORK is selected and ENABLE WI-FI is ON:

```bash
python3 -I -S -B "$TASK_OWNER/host-action.py" --owner "$TASK_OWNER" review \
  --label wifi-candidate-selected-network \
  --review 'WI-FI NETWORK selected; ENABLE WI-FI ON; activate this bound picker.'
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-activate && \
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-back-reopen && \
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-exit
```

The three actions must follow without a human review pause inside the unchanged
25s blocked handshake. Do not replay a failed input or extend an expired deadline.
If the measurement fails, preserve its original result and follow the existing
bounded owner failure/cleanup path. On success, perform normal `cleanup`, then
view/review the remaining three exact labels through unchanged host-action:
`wifi-candidate-searching`, `wifi-candidate-network-return`, and
`wifi-candidate-reopened-searching`. Review text must describe the observed page;
return must visibly equal the selected network page and reopen must show searching.

Run `host-audit.py --owner "$TASK_OWNER" finish`, await the original lifecycle
and launcher status, then unchanged `close.py --owner "$TASK_OWNER" --run ACTUAL_RUN
--packet FRESH_EXPORT`. Root reviews original exits, timing, group equality,
restoration and custody before consuming admission. This packet does not execute
preparation/runtime, stage, commit, promote source or assert unrun proof passed.

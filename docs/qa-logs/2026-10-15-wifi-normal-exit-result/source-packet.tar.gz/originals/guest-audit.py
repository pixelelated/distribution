#!/usr/bin/env python3
"""UNRUN additive actions inside a fresh accepted native no-NIC guest owner."""
import argparse,ctypes,hashlib,json,os,re,shlex,shutil,signal,stat,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE.parent))
from guest import R as NATIVE,api,identity,natives,run,save,sha
R=NATIVE.parent/'audit-ui';B=json.loads((HERE/'binding.json').read_text())
PRIVATE=Path('/run/pix-audit-ui');SYSTEM=Path('/storage/.config/system/configs/system.cfg');SETTINGS=Path('/storage/.config/emulationstation/es_settings.cfg')
def require_guest():
 assert os.getuid()==0 and sorted(x.name for x in Path('/sys/class/net').iterdir())==['lo']
 v=json.loads((HERE.parent.parent/'final-image-result.json').read_text());assert v['source']==B['guest_build_commit'] and v['status']=='PASS'
 assert 'BUILD_ID="'+B['guest_build_commit']+'"' in Path('/etc/os-release').read_text()
 assert NATIVE.is_dir() and not natives()
 for name,h in B['packet_files'].items():assert sha(HERE/name)==h,name
 assert re.fullmatch('[0-9a-f]{64}',B['candidate_es_sha256'])
def es_pids():
 rows=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   if (p/'comm').read_text().strip() in ['emulationstation','emulationstatio']:
    row=identity(int(p.name));row['exe_sha256']=sha(p/'exe');assert row['exe_sha256'] in [B['installed_inputs']['/usr/bin/emulationstation'],B['candidate_es_sha256']];rows.append(row)
  except (FileNotFoundError,ProcessLookupError):pass
 return rows
def mounts():
 return [line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()]
def bind(source,target):
 target=Path(target);assert str(target) not in mounts(),'pre-existing target bind refuses fixture'
 before={'path':str(target),'sha256':sha(target) if target.is_file() else None}
 run('audit-bind',['mount','--bind',source,target],5);run('audit-private',['mount','--make-private',target],5)
 assert target.stat().st_ino==Path(source).stat().st_ino and target.stat().st_dev==Path(source).stat().st_dev
 rows=json.loads((R/'mounts.json').read_text());rows.append(dict(before,source=str(source)));save(R/'mounts.json',rows)
def unbind_all():
 rows=json.loads((R/'mounts.json').read_text())
 for row in reversed(rows):
  target=Path(row['path']);source=Path(row['source']);assert mounts().count(str(target))==1
  assert target.stat().st_ino==source.stat().st_ino and target.stat().st_dev==source.stat().st_dev
  run('audit-unbind',['umount',target],5)
  if row['sha256']:assert sha(target)==row['sha256']
 save(R/'mounts.json',[])
def settings(language,wifi=False):
 values=[('system.language',language),('global.retroachievements','0'),('global.retroachievements.offlineproxy','0')]
 if wifi:values += [('wifi.enabled','1'),('wifi.adhoc.enabled','0')]
 run('audit-settings',['bash','-ec','. /etc/profile; '+ '; '.join('set_setting '+shlex.quote(k)+' '+shlex.quote(v) for k,v in values)],10)
 tree=ET.parse(SETTINGS);root=tree.getroot();assert root.tag=='config'
 for key,value in [('LogLevel','information'),('StartupSystem','wii')]:
  matches=root.findall("string[@name='"+key+"']");assert len(matches)<=1
  node=matches[0] if matches else ET.SubElement(root,'string',{'name':key});node.set('value',value)
 tree.write(SETTINGS,encoding='utf-8',xml_declaration=True)
def stop_es():
 assert not natives();run('audit-stop-es',['systemctl','stop','essway.service'],30);assert not es_pids()
def start_es():
 run('audit-start-es',['systemctl','start','essway.service'],40)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':return
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
def controls():
 out=R/'controls';out.mkdir();rows=[]
 for name,binary,mode,expected in [('baseline-explicit','baseline','explicit',1),('candidate-explicit','candidate','explicit',0),('candidate-atexit','candidate','atexit',0),('candidate-complete','candidate','complete',0)]:
  argv=['python3','-I','-S','-B',str(HERE/'worker-observer.py'),'--binary',str(HERE/'drivers'/binary),'--binary-sha256',B['drivers'][binary]['sha256'],'--backend-dir',str(HERE/'worker-proof/fixtures/bin'),'--output',str(out/name),'--mode',mode]
  row={'name':name,'argv':argv,'original_returncode':None,'expected_original_returncode':expected,'timed_out':False}
  with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
   p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True)
   fd=os.pidfd_open(p.pid,0)  # Unreaped direct child cannot be replaced by another PID.
   try:
    try:row['original_returncode']=p.wait(timeout=20)
    except subprocess.TimeoutExpired:
     row['timed_out']=True;signal.pidfd_send_signal(fd,signal.SIGTERM,None,0)
     try:row['original_returncode']=p.wait(timeout=6)
     except subprocess.TimeoutExpired:
      signal.pidfd_send_signal(fd,signal.SIGKILL,None,0);row['original_returncode']=p.wait(timeout=2)
   finally:os.close(fd)
  save(out/(name+'.command.json'),row);rows.append(row);save(out/'original-commands.json',rows)
  assert row['original_returncode']==expected and not row['timed_out']
  result=json.loads((out/name/'result.json').read_text());assert not result['survivors_after_cleanup'] and result['driver_original_returncode']==0
  if expected:assert result['status']=='FAIL' and result['owned_identities_still_present'] and result['original_observation_returncode']==1
  else:assert result['status']=='PASS' and not result['forced_cleanup']
 save(out/'review.json',{'rc':0,'originals':rows,'baseline_remains_failed':True});return {'rc':0,'controls':4}
def wifi_route():
 # Exact installed fresh-image hostname adds GuiMenu.cpp9910's NETWORK NAME row.
 # Read only these public fixture settings; never retain the whole live config.
 values={}
 for key in ['system.hostname','wifi.enabled','wifi.adhoc.enabled']:
  rows=[line.split('=',1)[1] for line in SYSTEM.read_text().splitlines() if line.startswith(key+'=')]
  assert len(rows)==1,(key,'missing or duplicate fixture setting');values[key]=rows[0]
 assert values=={'system.hostname':'GENERIC_X64','wifi.enabled':'1','wifi.adhoc.enabled':'0'},values
 return {'settings':values,'clean_network_name':'GENERIC-X64','conditional_network_name_row':True,'down_steps_to_wifi_network':6}
def wifi_start(mode):
 assert mode in ['baseline','candidate'];assert json.loads((R/'controls/review.json').read_text())['rc']==0
 if (R/'wifi-current.json').exists():assert json.loads((R/'wifi-current.json').read_text())['closed']
 stop_es();unbind_all();settings('en_US',True);route=wifi_route()
 if mode=='candidate':bind(HERE/'emulationstation','/usr/bin/emulationstation')
 bind(PRIVATE/'wifictl','/usr/bin/wifictl')
 expected=B['candidate_es_sha256'] if mode=='candidate' else B['installed_inputs']['/usr/bin/emulationstation']
 label='wifi-'+mode;argv=['python3','-I','-S','-B',str(HERE/'wifi-owner.py'),'--output',str(R/label),'--binary-sha256',expected]
 if mode=='baseline':argv+=['--known-bad']
 with (R/(label+'.owner.stdout')).open('xb') as out,(R/(label+'.owner.stderr')).open('xb') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True)
 row={'closed':False,'mode':mode,'output':str(R/label),'owner':identity(child.pid),'binary_sha256':expected,'menu_route':route};save(R/'wifi-current.json',row)
 deadline=time.monotonic()+45
 while not (R/label/'frontend-ready.json').exists():
  assert child.poll() is None and time.monotonic()<deadline;time.sleep(.1)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':break
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
 return row
def wifi_state():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output'])
 assert not row['closed'] and not (case/'owner-result.json').exists()
 owner_now=identity(row['owner']['pid']);assert owner_now['start_ticks']==row['owner']['start_ticks'] and owner_now['state']!='Z'
 frontend=json.loads((case/'frontend-ready.json').read_text())['identity'];frontend_now=identity(frontend['pid']);assert frontend_now['start_ticks']==frontend['start_ticks'] and frontend_now['state']!='Z'
 assert wifi_route()==row['menu_route']
 result={'case':row,'blocked':json.loads((case/'blocked-ready.json').read_text()) if (case/'blocked-ready.json').exists() else None,'calls':(case/'invocations').read_text().splitlines() if (case/'invocations').exists() else []}
 if result['blocked']:
  for item in result['blocked']['group']:
   actual=identity(item['pid']);assert actual['start_ticks']==item['start_ticks'] and actual['state']!='Z'
 return result
def wifi_exit():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output']);assert (case/'blocked-ready.json').exists()
 with (case/'continue-exit').open('x') as f:f.write('normal SIGINT after reviewed Back/reopen flow\n')
 deadline=time.monotonic()+20
 while not (case/'owner-result.json').exists():assert time.monotonic()<deadline;time.sleep(.05)
 owner=json.loads((case/'owner-result.json').read_text());result=json.loads((case/'result.json').read_text());expected=1 if row['mode']=='baseline' else 0
 assert owner['original_returncode']==expected and not owner['timed_out'] and result['final_returncode']==expected
 assert not result['survivors_after_cleanup']
 if expected:assert result['driver_original_returncode']==0 and result['owned_identities_still_present']
 else:assert result['driver_original_returncode']==0 and not result['forced_cleanup']
 while Path('/proc',str(row['owner']['pid'])).exists():assert time.monotonic()<deadline;time.sleep(.05)
 assert not es_pids();row['closed']=True;save(R/'wifi-current.json',row);return {'rc':0,'observation_original_returncode':expected,'result':result}
def config_manifest(path):
 # lstat preserves symlink targets/modes without following them outside the copy.
 rows=[];total=0
 for f in [path,*sorted(path.rglob('*'))]:
  st=f.lstat();row={'path':str(f.relative_to(path)),'mode':stat.S_IMODE(st.st_mode),'uid':st.st_uid,'gid':st.st_gid,'dev':st.st_dev,'ino':st.st_ino}
  if stat.S_ISLNK(st.st_mode):row.update(kind='link',target=os.readlink(f))
  elif stat.S_ISREG(st.st_mode):row.update(kind='file',bytes=st.st_size,sha256=sha(f));total+=st.st_size
  else:assert stat.S_ISDIR(st.st_mode),'unexpected config node';row['kind']='dir'
  rows.append(row);assert len(rows)<=4096 and total<=32*1024**2,'bounded config inventory'
 return rows

def content_manifest(rows):return [{k:v for k,v in row.items() if k not in ['dev','ino']} for row in rows]
def no_config_mount(path):
 assert not any(Path(m)==path or path in Path(m).parents for m in mounts()),'separately mounted config refuses fixture'
def rename_new(source,target):
 # Same Linux no-replace rename primitive used by the installed save-path helper.
 assert source.parent==target.parent==Path('/storage/.config')
 libc=ctypes.CDLL(None,use_errno=True);libc.renameat2.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];libc.renameat2.restype=ctypes.c_int
 if libc.renameat2(-100,os.fsencode(source),-100,os.fsencode(target),1)!=0:raise OSError(ctypes.get_errno(),'owned no-replace config rename failed')
def save_custody(row):
 save(R/('dolphin-config-'+row['language']+'-custody.json'),row);save(R/'dolphin-config-current.json',row)
def preserve_config(language):
 assert language in ['en_US','fr_FR']
 current=R/'dolphin-config-current.json'
 if current.exists():assert json.loads(current.read_text())['phase']=='restored'
 normal=Path('/storage/.config/dolphin-emu');stage=normal.with_name('.pix-audit-ui-dolphin-stage-'+language);held=normal.with_name('.pix-audit-ui-dolphin-original-'+language);done=normal.with_name('.pix-audit-ui-dolphin-completed-'+language)
 assert normal.is_dir() and not normal.is_symlink()
 for path in [normal,stage,held,done]:no_config_mount(path)
 for path in [stage,held,done]:assert not path.exists() and not path.is_symlink(),'fresh config custody paths required'
 original=config_manifest(normal);save(R/('dolphin-config-'+language+'-original-manifest.json'),original)
 shutil.copytree(normal,stage,symlinks=True);copied=config_manifest(stage);assert content_manifest(copied)==content_manifest(original),'ordinary copy differs'
 target=stage/'RetroAchievements.ini'
 if target.exists() or target.is_symlink():
  assert target.is_file() or target.is_symlink();saved=stage/'RetroAchievements.ini.fixture-original';assert not saved.exists() and not saved.is_symlink();target.rename(saved)
 target.mkdir();(target/'sentinel').write_text('private refusal target, preserve this member\n')
 row={'language':language,'normal':str(normal),'stage':str(stage),'held':str(held),'completed':str(done),'original_root':original[0],'copy_root':copied[0],'original_manifest_sha256':sha(R/('dolphin-config-'+language+'-original-manifest.json')),'phase':'prepared'};save_custody(row)
 assert config_manifest(normal)==original,'original config changed during copy'
 rename_new(normal,held);row['phase']='original-preserved';save_custody(row)
 assert config_manifest(held)==original,'preserved original changed'
 rename_new(stage,normal);row['phase']='active';save_custody(row)
 assert config_manifest(normal)[0]==row['copy_root'];no_config_mount(normal)
 return normal/'RetroAchievements.ini'
def restore_config():
 current=R/'dolphin-config-current.json'
 if not current.exists():return
 row=json.loads(current.read_text())
 if row['phase']=='restored':return
 assert row['phase']=='active','ambiguous config custody; preserve failure, never guess restoration'
 normal=Path(row['normal']);held=Path(row['held']);done=Path(row['completed'])
 assert normal==Path('/storage/.config/dolphin-emu') and held==normal.with_name('.pix-audit-ui-dolphin-original-'+row['language']) and done==normal.with_name('.pix-audit-ui-dolphin-completed-'+row['language'])
 for path in [normal,held,done]:no_config_mount(path)
 manifest=R/('dolphin-config-'+row['language']+'-original-manifest.json');assert sha(manifest)==row['original_manifest_sha256'];original=json.loads(manifest.read_text())
 assert config_manifest(held)==original,'held original bytes/link/mode/identity changed'
 copied=config_manifest(normal);assert copied[0]==row['copy_root'],'active config root identity changed'
 save(R/('dolphin-config-'+row['language']+'-completed-manifest.json'),copied)
 rename_new(normal,done);row['phase']='copy-retained';save_custody(row)
 rename_new(held,normal);assert config_manifest(normal)==original,'original config restoration differs'
 row['phase']='restored';row['original_exactly_restored']=True;save_custody(row)

def refusal(language):
 assert language in ['en_US','fr_FR'];assert json.loads((R/'wifi-current.json').read_text())['closed']
 stop_es();restore_config();unbind_all();settings(language)
 bind(HERE/'emulationstation','/usr/bin/emulationstation')
 bind(PRIVATE/'cheevos_dolphin.sh','/usr/bin/cheevos_dolphin.sh');bind(PRIVATE/'start_dolphin_wii.sh','/usr/bin/start_dolphin_wii.sh')
 target=preserve_config(language)
 run('audit-save-path-check',['python3','-I','-S','-B','/usr/bin/dolphin-save-paths','check','wii'],10)
 log=Path('/var/log/cheevos.log');log_before={'sha256':sha(log),'mtime_ns':log.stat().st_mtime_ns} if log.exists() else None
 start_es();before={'es':es_pids(),'exec_log_sha256':sha(Path('/var/log/exec.log')) if Path('/var/log/exec.log').exists() else None,'config_custody':json.loads((R/'dolphin-config-current.json').read_text()),'helper_log_before':log_before}
 save(R/('refusal-'+language+'-before.json'),before)
 prior_errors=Path('/var/log/es_log.txt').read_text().count('capture rotation: not recorded, the launch exited 250')
 launch=api('/launch','/storage/roms/wii/SuDokuL-Wii.dol');save(R/('refusal-'+language+'-launch.json'),launch)
 deadline=time.monotonic()+30
 while True:
  assert not natives(),'engine unexpectedly reached'
  text=Path('/var/log/es_log.txt').read_text()
  if text.count('capture rotation: not recorded, the launch exited 250')==prior_errors+1:break
  assert time.monotonic()<deadline;time.sleep(.1)
 assert (target/'sentinel').read_text()=='private refusal target, preserve this member\n'
 logs={}
 for name,path in [('exec-log','/var/log/exec.log'),('es-log','/var/log/es_log.txt'),('cheevos-log','/var/log/cheevos.log')]:
  f=Path(path);logs[name]={'path':path,'exists':f.exists()}
  if f.exists():
   raw=f.read_bytes();assert len(raw)<=2*1024**2;(R/('refusal-'+language+'-'+name)).write_bytes(raw);logs[name].update(sha256=sha(f),bytes=len(raw),mtime_ns=f.stat().st_mtime_ns)
 save(R/('refusal-'+language+'-log-manifest.json'),logs)
 expected='RetroAchievements are not enabled, please turn them on in Emulation Station.\nDolphin achievements settings could not be written; refusing launch.\n'
 assert logs['cheevos-log']['exists'] and log.read_text()==expected,'missing intended helper publication-error log;250 alone is insufficient'
 assert log_before is None or log.stat().st_mtime_ns!=log_before['mtime_ns'],'helper log was not freshly written'
 exec_text=(R/('refusal-'+language+'-exec-log')).read_text()
 assert "mv: '/storage/.config/dolphin-emu/RetroAchievements.ini' is a directory\n" in exec_text,'qualified target BusyBox mv refusal absent'
 assert 'A Dolphin save path is separately mounted.' not in exec_text,'wrong earlier refusal'
 title='DOLPHIN DID NOT START' if language=='en_US' else 'DOLPHIN N’A PAS DÉMARRÉ'
 message='Achievements settings could not be updated. Check the game storage and folder permissions, then try again.' if language=='en_US' else 'Les paramètres des succès n’ont pas pu être mis à jour. Vérifiez le stockage des jeux et les permissions des dossiers, puis réessayez.'
 result={'rc':0,'language':language,'original_launch_exit':250,'exit_evidence':'actual ES log; helper/launcher status propagation through installed runemu','es':es_pids(),'native_processes':natives(),'private_target_directory_preserved':True,'intended_helper_publication_error':True,'helper_log_sha256':sha(log),'expected_visible_title':title,'expected_visible_message':message,'frame_review':'pending exact localized title/body'}
 save(R/('refusal-'+language+'-result.json'),result);return result
def cleanup():
 if (R/'wifi-current.json').exists():
  row=json.loads((R/'wifi-current.json').read_text());assert row['closed'],'observer still owned; wait finite observer or abort guest, do not unbind live code'
 stop_es();restore_config();unbind_all()
 for src,dst in [('system.cfg',SYSTEM),('es_settings.cfg',SETTINGS)]:shutil.copy2(R/'originals'/src,dst);assert sha(dst)==sha(R/'originals'/src)
 for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
 start_es();save(R/'restored.json',{'rc':0,'original_input_hashes_restored':True,'mounts':json.loads((R/'mounts.json').read_text())});return {'rc':0}
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['init','controls','wifi-start','wifi-state','wifi-exit','refusal','cleanup']);p.add_argument('--mode',choices=['baseline','candidate']);p.add_argument('--language',choices=['en_US','fr_FR']);a=p.parse_args();require_guest()
 if a.action=='init':
  assert not R.exists() and not PRIVATE.exists();R.mkdir();PRIVATE.mkdir();(R/'originals').mkdir();save(R/'mounts.json',[])
  for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
  for src,name in [(SYSTEM,'system.cfg'),(SETTINGS,'es_settings.cfg')]:shutil.copy2(src,R/'originals'/name)
  shutil.copy2(HERE/'source/wifictl',PRIVATE/'wifictl');os.chmod(PRIVATE/'wifictl',0o755)
  shutil.copy2(HERE/'source/cheevos_dolphin.after.sh',PRIVATE/'cheevos_dolphin.sh');os.chmod(PRIVATE/'cheevos_dolphin.sh',0o755)
  before=(HERE/'source/launcher-wii.before.snippet').read_bytes();after=(HERE/'source/launcher-wii.after.snippet').read_bytes();raw=Path('/usr/bin/start_dolphin_wii.sh').read_bytes();assert raw.count(before)==1
  candidate=raw.replace(before,after,1);(PRIVATE/'start_dolphin_wii.sh').write_bytes(candidate);os.chmod(PRIVATE/'start_dolphin_wii.sh',0o755)
  save(R/'bindings.json',dict(B,derived_installed_launcher_sha256=hashlib.sha256(candidate).hexdigest()));result={'rc':0}
 else:
  assert R.is_dir()
  result={'controls':controls,'wifi-state':wifi_state,'wifi-exit':wifi_exit,'cleanup':cleanup}.get(a.action,lambda: wifi_start(a.mode) if a.action=='wifi-start' else refusal(a.language))()
 print('PIX_AUDIT_JSON='+json.dumps(result))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""UNRUN fresh candidate-only owner; verify consumed originals, never replay them."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=Path('/tmp/pix-m7-audit-ui-retry-plan-20261015');BASE_SEAL='08773c90fec208a277da993d6df63b38ab4150bd308c5cd98f199a884e68466c'
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sealed(p,seal):
 assert sha(p/'SHA256SUMS')==seal
 for line in (p/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert not Path(n).is_absolute() and '..' not in Path(n).parts and sha(p/n)==h,n
def prior_evidence():
 directory=HERE/'evidence'
 rows=json.loads((directory/'originals.json').read_text())
 for row in rows:
  copy=directory/row['name'];original=Path(row['original_path'])
  assert copy.stat().st_size==original.stat().st_size==row['bytes'] and sha(copy)==sha(original)==row['sha256']
 def read(name):return json.loads((directory/name).read_text())
 consumed=read('consumed.json');assert consumed['id']=='341087f6d3d44905b7447199e9713de1' and consumed['state']=='consumed'
 assert {k:consumed['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']}=={'command_rc':1,'monitor_rc':0,'runner_rc':1}
 review=read('root-failure-review.json');acceptance=read('acceptance.json')
 assert review['disposition']==acceptance['disposition']=='failed-investigated' and review['original_run_rc']==acceptance['expected_rc']==1 and review['no_remaining_host_children']
 config=read('config.json');assert config['audit_ui']['packet_seal']==BASE_SEAL and config['audit_ui']['candidate_es_commit']=='16dbac5211eea7e70db7394372033be2be7df829'
 controls=read('controls-review.json');assert controls['rc']==0 and controls['baseline_remains_failed']
 names=['baseline-explicit','candidate-explicit','candidate-atexit','candidate-complete'];assert [r['name'] for r in controls['originals']]==names
 for row in controls['originals']:
  expected=1 if row['name'].startswith('baseline-') else 0;result=read('control-'+row['name']+'.json')
  assert row['original_returncode']==row['expected_original_returncode']==result['final_returncode']==expected and not row['timed_out']
  binary='baseline' if expected else 'candidate';assert result['binary_sha256']==config['source']['audit-ui/drivers/'+binary]
  assert result['driver_original_returncode']==0 and result['survivors_after_cleanup']==[] and result['observation_errors']==[]
  if expected:assert result['status']=='FAIL' and result['owned_identities_still_present']
  else:assert result['status']=='PASS' and not result['forced_cleanup']
 for mode,expected in [('baseline',1),('candidate',0)]:
  result=read('wifi-'+mode+'-result.json');owner=read('wifi-'+mode+'-owner-result.json')
  assert result['final_returncode']==owner['original_returncode']==expected and not owner['timed_out']
  assert result['driver_original_returncode']==0 and result['survivors_after_cleanup']==[] and result['observation_errors']==[]
  if expected:assert result['known_bad'] and result['status']=='FAIL' and result['owned_identities_still_present']
  else:
   assert result['binary_sha256']==config['audit_ui']['candidate_es_sha256'] and result['status']=='PASS' and not result['forced_cleanup']
   assert result['join_logs']=={'stopping':1,'joined':1} and result['survivors_after_normal_exit']==[] and result['no_later_backend']
 timing=read('back-timing.json');assert timing['passed'] is False and timing['upper_bound_seconds']>timing['proposed_limit_seconds']==1
 assert read('selected-network-capture.json')['sha256']==timing['frame_sha256']==sha(directory/'wifi-candidate-network-return.png')
 return {'verified':True,'scope':'four original controls and full ES normal-exit lifecycle only','prior_outer_returncode':1,'consumed_id':consumed['id'],'originals_manifest_sha256':sha(directory/'originals.json'),'candidate_es_sha256':config['audit_ui']['candidate_es_sha256'],'candidate_es_commit':config['audit_ui']['candidate_es_commit'],'back_reopen_not_yet_qualified':True}
p=argparse.ArgumentParser()
for n in ['checkout','verification','author-owner','owner']:p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--vnc',type=int,required=True);a=p.parse_args();sealed(HERE,sha(HERE/'SHA256SUMS'));sealed(BASE,BASE_SEAL);prior=prior_evidence()
argv=[sys.executable,'-I','-S','-B',str(BASE/'prepare.py')]
for n in ['checkout','verification','author-owner','owner']:argv+=['--'+n,str(getattr(a,n.replace('-','_')))]
argv+=['--vnc',str(a.vnc)];subprocess.run(argv,check=True,timeout=150)
out=a.owner;target=out/'source/audit-ui'
for name in ['host-audit.py','capture-back.py']:shutil.copy2(HERE/name,out/name)
shutil.copy2(HERE/'guest-audit.py',target/'guest-audit.py');shutil.copytree(HERE/'evidence',target/'prior-originals');save(target/'prior-evidence.json',prior)
b=json.loads((target/'binding.json').read_text());assert b['candidate_es_sha256']==prior['candidate_es_sha256'];b['packet_files']={str(f.relative_to(target)):sha(f) for f in sorted(target.rglob('*')) if f.is_file() and f!=target/'binding.json'};save(target/'binding.json',b)
c=json.loads((out/'config.json').read_text())
for name in ['host-audit.py','capture-back.py']:c['code'][name]=sha(out/name)
c['source']={str(f.relative_to(out/'source')):sha(f) for f in sorted((out/'source').rglob('*')) if f.is_file()};c['work_seconds']=600
c['audit_ui'].update(packet_seal=sha(HERE/'SHA256SUMS'),base_packet_seal=BASE_SEAL,binding_sha256=sha(target/'binding.json'),scope='candidate Back/reopen only',imported_prerequisites=prior);save(out/'config.json',c)
ret=json.loads((out/'retention-plan.json').read_text());ret['protected']+=[str(HERE)];ret['builds'][0]['name']='m7-wifi-back-reopen';ret['builds'][0]['basis']='Candidate-only actual Back/reopen. Original four controls and full ES baseline/candidate lifecycle receipts bound, not replayed; prior outer failure retained. Real key-send to exact complete reference-frame upper bound<=1s; same blocked group after reopen.600s work+120s cleanup; unchanged no-NIC lifecycle/resource/output bounds.'
ret['builds'][0]['evidence']=[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','vm-lifecycle.py','source/guest.py','source/audit-ui/guest-audit.py','host-audit.py','capture-back.py']];save(out/'retention-plan.json',ret)
adm=json.loads((out/'admission-plan.json').read_text());adm['stage']='m7-wifi-back-reopen';adm['outputs'][0]['release_when']='Four reviewed candidate Back/reopen frames, exact timing and blocked-group originals, normal restoration and custody exported; original owners gone and admission consumed before retirement.';save(out/'admission-plan.json',adm)
save(out/'records/back-reopen-preparation.json',{'status':'PREPARED_UNRUN','packet_seal':sha(HERE/'SHA256SUMS'),'base_prepare_argv':argv,'imported_prerequisites':prior})
print(json.dumps({'owner':str(out),'status':'PREPARED_UNRUN','work_seconds':600,'cleanup_seconds':120,'panel':[640,480],'operator':str(out/'host-audit.py')}))

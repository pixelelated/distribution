#!/usr/bin/env python3
"""UNRUN additive actions inside a fresh accepted native no-NIC guest owner."""
import argparse,ctypes,hashlib,json,os,re,shlex,shutil,signal,stat,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE.parent))
from guest import R as NATIVE,api,identity,natives,run,save,sha
R=NATIVE.parent/'audit-ui';B=json.loads((HERE/'binding.json').read_text())
PRIVATE=Path('/run/pix-audit-ui');SYSTEM=Path('/storage/.config/system/configs/system.cfg');SETTINGS=Path('/storage/.config/emulationstation/es_settings.cfg')
def require_guest():
 assert os.getuid()==0 and sorted(x.name for x in Path('/sys/class/net').iterdir())==['lo']
 v=json.loads((HERE.parent.parent/'final-image-result.json').read_text());assert v['source']==B['guest_build_commit'] and v['status']=='PASS'
 assert 'BUILD_ID="'+B['guest_build_commit']+'"' in Path('/etc/os-release').read_text()
 assert NATIVE.is_dir() and not natives()
 for name,h in B['packet_files'].items():assert sha(HERE/name)==h,name
 assert re.fullmatch('[0-9a-f]{64}',B['candidate_es_sha256'])
def es_pids():
 rows=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   if (p/'comm').read_text().strip() in ['emulationstation','emulationstatio']:
    row=identity(int(p.name));row['exe_sha256']=sha(p/'exe');assert row['exe_sha256'] in [B['installed_inputs']['/usr/bin/emulationstation'],B['candidate_es_sha256']];rows.append(row)
  except (FileNotFoundError,ProcessLookupError):pass
 return rows
def mounts():
 return [line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()]
def bind(source,target):
 target=Path(target);assert str(target) not in mounts(),'pre-existing target bind refuses fixture'
 before={'path':str(target),'sha256':sha(target) if target.is_file() else None}
 run('audit-bind',['mount','--bind',source,target],5);run('audit-private',['mount','--make-private',target],5)
 assert target.stat().st_ino==Path(source).stat().st_ino and target.stat().st_dev==Path(source).stat().st_dev
 rows=json.loads((R/'mounts.json').read_text());rows.append(dict(before,source=str(source)));save(R/'mounts.json',rows)
def unbind_all():
 rows=json.loads((R/'mounts.json').read_text())
 for row in reversed(rows):
  target=Path(row['path']);source=Path(row['source']);assert mounts().count(str(target))==1
  assert target.stat().st_ino==source.stat().st_ino and target.stat().st_dev==source.stat().st_dev
  run('audit-unbind',['umount',target],5)
  if row['sha256']:assert sha(target)==row['sha256']
 save(R/'mounts.json',[])
def settings(language,wifi=False):
 values=[('system.language',language),('global.retroachievements','0'),('global.retroachievements.offlineproxy','0')]
 if wifi:values += [('wifi.enabled','1'),('wifi.adhoc.enabled','0')]
 run('audit-settings',['bash','-ec','. /etc/profile; '+ '; '.join('set_setting '+shlex.quote(k)+' '+shlex.quote(v) for k,v in values)],10)
 tree=ET.parse(SETTINGS);root=tree.getroot();assert root.tag=='config'
 for key,value in [('LogLevel','information'),('StartupSystem','wii')]:
  matches=root.findall("string[@name='"+key+"']");assert len(matches)<=1
  node=matches[0] if matches else ET.SubElement(root,'string',{'name':key});node.set('value',value)
 tree.write(SETTINGS,encoding='utf-8',xml_declaration=True)
def stop_es():
 assert not natives();run('audit-stop-es',['systemctl','stop','essway.service'],30);assert not es_pids()
def start_es():
 run('audit-start-es',['systemctl','start','essway.service'],40)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':return
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
def wifi_route():
 # Exact installed fresh-image hostname adds GuiMenu.cpp9910's NETWORK NAME row.
 # Read only these public fixture settings; never retain the whole live config.
 values={}
 for key in ['system.hostname','wifi.enabled','wifi.adhoc.enabled']:
  rows=[line.split('=',1)[1] for line in SYSTEM.read_text().splitlines() if line.startswith(key+'=')]
  assert len(rows)==1,(key,'missing or duplicate fixture setting');values[key]=rows[0]
 assert values=={'system.hostname':'GENERIC_X64','wifi.enabled':'1','wifi.adhoc.enabled':'0'},values
 return {'settings':values,'clean_network_name':'GENERIC-X64','conditional_network_name_row':True,'down_steps_to_wifi_network':6}
def wifi_start(mode):
 assert mode=='candidate'
 prior=json.loads((HERE/'prior-evidence.json').read_text())
 assert prior['scope']=='four original controls and full ES normal-exit lifecycle only' and prior['prior_outer_returncode']==1 and prior['verified']
 assert prior['candidate_es_sha256']==B['candidate_es_sha256'] and prior['candidate_es_commit']==B['candidate_es_commit']
 save(R/'imported-prerequisites.json',prior)
 if (R/'wifi-current.json').exists():assert json.loads((R/'wifi-current.json').read_text())['closed']
 stop_es();unbind_all();settings('en_US',True);route=wifi_route()
 if mode=='candidate':bind(HERE/'emulationstation','/usr/bin/emulationstation')
 bind(PRIVATE/'wifictl','/usr/bin/wifictl')
 expected=B['candidate_es_sha256'] if mode=='candidate' else B['installed_inputs']['/usr/bin/emulationstation']
 label='wifi-'+mode;argv=['python3','-I','-S','-B',str(HERE/'wifi-owner.py'),'--output',str(R/label),'--binary-sha256',expected]
 if mode=='baseline':argv+=['--known-bad']
 with (R/(label+'.owner.stdout')).open('xb') as out,(R/(label+'.owner.stderr')).open('xb') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True)
 row={'closed':False,'mode':mode,'output':str(R/label),'owner':identity(child.pid),'binary_sha256':expected,'menu_route':route};save(R/'wifi-current.json',row)
 deadline=time.monotonic()+45
 while not (R/label/'frontend-ready.json').exists():
  assert child.poll() is None and time.monotonic()<deadline;time.sleep(.1)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':break
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
 return row
def wifi_state():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output'])
 assert not row['closed'] and not (case/'owner-result.json').exists()
 owner_now=identity(row['owner']['pid']);assert owner_now['start_ticks']==row['owner']['start_ticks'] and owner_now['state']!='Z'
 frontend=json.loads((case/'frontend-ready.json').read_text())['identity'];frontend_now=identity(frontend['pid']);assert frontend_now['start_ticks']==frontend['start_ticks'] and frontend_now['state']!='Z'
 assert wifi_route()==row['menu_route']
 result={'case':row,'blocked':json.loads((case/'blocked-ready.json').read_text()) if (case/'blocked-ready.json').exists() else None,'calls':(case/'invocations').read_text().splitlines() if (case/'invocations').exists() else []}
 if result['blocked']:
  for item in result['blocked']['group']:
   actual=identity(item['pid']);assert actual['start_ticks']==item['start_ticks'] and actual['state']!='Z'
 return result
def wifi_exit():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output']);assert (case/'blocked-ready.json').exists()
 with (case/'continue-exit').open('x') as f:f.write('normal SIGINT after reviewed Back/reopen flow\n')
 deadline=time.monotonic()+20
 while not (case/'owner-result.json').exists():assert time.monotonic()<deadline;time.sleep(.05)
 owner=json.loads((case/'owner-result.json').read_text());result=json.loads((case/'result.json').read_text());expected=1 if row['mode']=='baseline' else 0
 assert owner['original_returncode']==expected and not owner['timed_out'] and result['final_returncode']==expected
 assert not result['survivors_after_cleanup']
 if expected:assert result['driver_original_returncode']==0 and result['owned_identities_still_present']
 else:assert result['driver_original_returncode']==0 and not result['forced_cleanup']
 while Path('/proc',str(row['owner']['pid'])).exists():assert time.monotonic()<deadline;time.sleep(.05)
 assert not es_pids();row['closed']=True;save(R/'wifi-current.json',row);return {'rc':0,'observation_original_returncode':expected,'result':result}


def cleanup():
 if (R/'wifi-current.json').exists():
  row=json.loads((R/'wifi-current.json').read_text());assert row['closed'],'observer still owned; wait finite observer or abort guest, do not unbind live code'
 stop_es();unbind_all()
 for src,dst in [('system.cfg',SYSTEM),('es_settings.cfg',SETTINGS)]:shutil.copy2(R/'originals'/src,dst);assert sha(dst)==sha(R/'originals'/src)
 for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
 start_es();save(R/'restored.json',{'rc':0,'original_input_hashes_restored':True,'mounts':json.loads((R/'mounts.json').read_text())});return {'rc':0}
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['init','wifi-start','wifi-state','wifi-exit','cleanup']);p.add_argument('--mode',choices=['candidate']);p.add_argument('--language',choices=['en_US','fr_FR']);a=p.parse_args();require_guest()
 if a.action=='init':
  assert not R.exists() and not PRIVATE.exists();R.mkdir();PRIVATE.mkdir();(R/'originals').mkdir();save(R/'mounts.json',[])
  for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
  for src,name in [(SYSTEM,'system.cfg'),(SETTINGS,'es_settings.cfg')]:shutil.copy2(src,R/'originals'/name)
  shutil.copy2(HERE/'source/wifictl',PRIVATE/'wifictl');os.chmod(PRIVATE/'wifictl',0o755)
  save(R/'bindings.json',B);result={'rc':0}
 else:
  assert R.is_dir()
  result={'wifi-state':wifi_state,'wifi-exit':wifi_exit,'cleanup':cleanup}.get(a.action,lambda: wifi_start(a.mode))()
 print('PIX_AUDIT_JSON='+json.dumps(result))
if __name__=='__main__':main()

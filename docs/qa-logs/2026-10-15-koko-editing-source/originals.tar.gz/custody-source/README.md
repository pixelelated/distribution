# Koko editing-source custody — #528, source-only successor

**UNRUN.** This packet prepares one offline immutable-copy run. No owner/admission was prepared, object copied or hashed anew, archive decoded, program invoked, network request made, or product/shared record changed in this preparation. Only completed metadata, existing notice text and source scripts were read. Compact safe originals are retained under `originals/`; raw source bodies and raw HTTP/list streams are excluded.

The actual prerequisite acquisition completed at run `20261015T142837Z-8b38993b`, ordinary consumption `5dc846f8a12f4fd5bc53863f8e763790`, with all original channels0. Its five Git blob/size checks and four list-only operations are accepted originals; the15.539-second execution and ten successful synthetic controls remain their own evidence. The successor does not replay them. The accepted additive custody/run is separately hash-bound, and its three Slang component rows remain immutable.

## Exact next custody

Fresh owner: `/workspace/tmp/pix-m7-koko-editing-custody-20261015-01`.

Fresh sibling destination: `/workspace/artifacts/pixelelated-release-sources/m7-koko-editing-source-20261015-01`.

Both paths must be absent. The copier writes five complete exact objects totaling **47,056,031 bytes**, plus the separately read87-byte monitor technical export note. Each object is independently copied into a new inode, checked by SHA256/size before and after copying, and its original accepted stat identity/hash is rechecked. The original Git blob SHA1 proof remains explicitly distinct from the flat SHA256 of the unchanged copied object; it is carried through accepted acquisition identity, not recomputed or relabeled as a flat digest. All original inputs stay held.

| Object | Bytes | Accepted flat SHA256 |
| --- | ---: | --- |
| monitor_body_source.7z | 22,816,420 | f341e1c64549c1cf3f90c616e8a5af4365223891c60ff461f8a82349d1294ff7 |
| gamegear_overlay.7z | 9,384,079 | 8412df4e6da9bb07bd194a9a72aba593319834d31875e7eec07ec10af8d7b1a6 |
| gba_overlay.7z | 10,133,553 | e355568b1c4cc422caaa1ec4435e4a099d9e4904b42e87c2b9b058f7d9420b05 |
| gbm_overlay.7z | 1,655,331 | 7a052ea6081aa2c7ff01a3202d35a8fc393c1d9ba52cbede9626d7fccecd909d |
| gbc_overlay.png | 3,066,648 | cb403d01d106c2fc2e206162ec3eeede60fc9c18253a76efab40443bfc0dce0e |

The13 expected custody files are five objects, the87-byte notice and seven compact mapping/manifest files. Final files become0444 and directories0555. No compression, decode, archive-member extraction, image regeneration, source/cache scan, download, target program or external child tool exists in the copier. Failure preserves partial owner/destination and original failures; no overwrite, automatic deletion, cap increase or automatic retry occurs.

## Source, member and notice mapping

`object-member-index.json` binds the five retained bodies and original Git identities. `metadata/member-index.json` projects only exact declared member names/sizes/CRC/attributes from the already successful technical listings. The four archives name XCF projects; individual XCF bytes/hashes are not newly read or claimed. The whole archive is retained intact. No loose Game Gear XCF is added or assumed equivalent.

`metadata/asset-selection.json` and the three-row `component-member-index.json` explicitly associate the Game Gear/GBA/GBC/GBM editing objects with their four exact selected Slang JPEG paths, source IDs, Git blobs, flat hashes and sizes. The monitor project is additionally associated with the two exact selected straight/curved monitor PNG source members. These are source associations supported by the retained upstream referral and member metadata, not evidence of regenerating the selected images or a new installed/runtime check. GENERIC_X64, H700 AArch64 and SM8550 AArch64 retain their original full Slang archive source references; no ARM component is invented.

`notice-index.json` references the existing complete supplied Koko GPL3 text, pinned Slang docs-ng source referral and misc repository README by exact original path/hash/size. They are not recollected or silently relabeled. The87-byte `monitor_body_source/warning.read.me.txt` was subsequently read by root at `20261015T143318Z-7b83c059`, original reader0 and watch0/0/0, archive unchanged. Its exact SHA256 is `f36738f0793eb47f476f2604175104dbb1214ca871ed1f85ee4ebb52c76537ae`. That held text is copied unchanged to `notices/monitor-export-warning.txt`; it is a16-bit-source to RGBA8bpc PNG export note. No additional licence restriction was observed in that named text. This successor performs no second decode or export.

Raw curl headers, raw HTTP stdout/stderr and raw technical-list stdout/stderr remain private outside Git. The custody contains safe fixed upstream blob URLs, exact digest/reference projections and original success dispositions only. The acquisition collection-result and original raw files remain referenced by hash, never copied wholesale. Compact originals in this proposal contain no raw stream bytes or source object payloads; actual notices are preserved verbatim, not filtered or reworded.

## Qualified pattern reused and bounds

This is the small derivative of accepted Tailscale copy/hash source packet, whose actual runtime `20261015T130342Z-3e1075ab` and consumption `226cf34d4af24c09aa6aa54bf2bb0723` established the immutable-copy pattern. All common copier functions/Writer class and every supervisor lifecycle helper remain AST-identical; process-identity and outer runner bytes remain unchanged. The selected-map implementation, exact prerequisites/counts/scope and resource amounts are the necessary delta. Existing accepted copy/budget and lifecycle controls are referenced; no repeated control or runtime PASS is claimed for this successor.

The new custody ceiling is64MiB for47,056,118 payload bytes plus small metadata. Owner ceiling remains64MiB,48MiB normal collector share,16MiB supervisor reserve and1MiB bounded failure receipt. Per-file bound32MiB exceeds the largest22,816,420-byte source. Limits allow32 output files,8 directories,4KiB paths,1GiB accounted reads and256MiB retention reservation including filesystem margin. The existing two CPU affinity slots/2GiB address space/270s soft,300s supervisor,330s outer and15s kill allowance stay unchanged. No extraction scratch is allocated. The accepted supervisor retains original waits, bounded pipe draining, signal masking, pidfd identity custody, cleanup and actual-channel separation.

## Root execution after source review

Use the frozen GENERIC control checkout and its own ordinary tool hashes; no coordinator-tool substitution or reporting-failure recovery. Each step is separate:

```bash
bash /tmp/pix-m7-koko-editing-source-custody-20261015/commands.sh prepare
bash /tmp/pix-m7-koko-editing-source-custody-20261015/commands.sh preflight
bash /tmp/pix-m7-koko-editing-source-custody-20261015/commands.sh report
# Root reads actual preflight/retention/preparation results before admission.
bash /tmp/pix-m7-koko-editing-source-custody-20261015/commands.sh admit
bash /tmp/pix-m7-koko-editing-source-custody-20261015/commands.sh launch
# Only after actual successful originals and exact output readback:
bash /tmp/pix-m7-koko-editing-source-custody-20261015/commands.sh consume
```

Preparation/runtime require the actual host namespace and no competing unconsumed job (runtime permits only its own). Submission is not completion; root supervises at most60seconds apart. Original body acquisition, monitor notice read, additive custody and this later copy each retain their distinct statuses. Success requires all new original channels0, exact13 copied/generated custody files with expected modes/hashes/independent inodes, three original component rows, six source-asset associations, no errors/signals/survivors and ordinary consumption. A failed successor cannot change a prior accepted result.

This satisfies a narrow local editing-source custody step. Complete bundle materialization, independent retrieval, off-host custody, remaining specific component questions and publication remain the existing #528 work. No universal regeneration, image approval gate, legal clearance or RC designation is introduced. The separate MAME adaptation question is unchanged.

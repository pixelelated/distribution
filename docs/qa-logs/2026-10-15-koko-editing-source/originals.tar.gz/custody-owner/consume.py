#!/usr/bin/env python3
"""Consume exact original success channels only; retention does not clear publication."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent;B=runpy.run_path(str(O/'bindings.py'));plan=B['verify'](O)
assert Path.cwd()==B['VM_TREE'];load,sha=B['load'],B['sha'];run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs';B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert p.read_text().strip()=='0',p
result,cleanup=load(O/'result.json'),load(O/'cleanup.json');assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established']is False
assert result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0
assert child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit'])is int and report['original_collector_exit']==0
assert report['objects']==5 and report['object_bytes']==47056031 and report['listing_count']==4 and report['component_rows']==3
assert report['selected_assets']==6 and report['notice_references']==3 and report['notice_copies']==1 and report['notice_copy_bytes']==87
assert report['source_execution']is False and report['archive_decode']is False and report['regeneration_performed']is False
assert report['publication_clearance']is False and report['publication_bundle_complete']is False and report['network_used']is False and report['target_execution']is False
assert not (O/'collection-failure.json').exists();D=Path(load(O/'destination.json')['path']);assert report['custody_path']==str(D)
assert len(report['files'])==13 and len({r['path'] for r in report['files']})==len(report['files'])
for r in report['files']:
 p=Path(r['path']);assert p.is_relative_to(D) and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert {r['path'] for r in report['files']}=={str(p) for p in D.rglob('*') if p.is_file()}
assert sum(r['bytes'] for r in report['files'])<=64*1024**2 and sha(D/'manifest.json')==report['manifest_sha256']
manifest=load(D/'manifest.json');assert manifest['publication_bundle_complete']is False and manifest['binding_refs']==plan['binding_refs'] and manifest['unresolved']==plan['unresolved']
assert manifest['object_count']==5 and manifest['object_bytes']==47056031 and manifest['listing_count']==4 and manifest['component_rows']==3
assert manifest['selected_asset_count']==6 and manifest['selected_jpeg_count']==4 and manifest['notice_reference_count']==3 and manifest['notice_copy_count']==1 and manifest['notice_copy_bytes']==87
for name,key in [('component-member-index.json','component_index_sha256'),('object-member-index.json','object_index_sha256'),('metadata/member-index.json','member_index_sha256'),('metadata/asset-selection.json','asset_index_sha256'),('notice-index.json','notice_index_sha256')]:assert sha(D/name)==manifest[key]
objects=load(D/'object-member-index.json');components=load(D/'component-member-index.json');notices=load(D/'notice-index.json');members=load(D/'metadata/member-index.json');assets=load(D/'metadata/asset-selection.json')
assert len(objects)==5 and len(components)==3 and len(members)==4 and assets['assets']==plan['selected_assets']
assert notices['references']==plan['notices'] and notices['existing_reference_texts_copied']is False
assert notices['monitor_notice']==manifest['monitor_notice']==plan['monitor_notice'] and assets['monitor_notice']==plan['monitor_notice']
for spec,obj in zip(plan['objects'],objects):
 selected=spec['selection'];assert obj['name']==selected['name'] and obj['member']=='objects/'+selected['name']
 assert obj['source_path']==selected['source_path'] and obj['canonical_blob_url']==selected['immutable_blob_api_url']
 assert obj['actual_git_blob_sha1']==obj['expected_git_blob_sha1']==spec['actual_git_blob_sha1']==selected['expected_git_blob_sha1']
 assert obj['source_identity']==spec['body']['held_identity'] and obj['independent_copy']is True
 assert obj['bytes']==spec['body']['bytes'] and obj['sha256']==obj['flat_sha256']==spec['body']['sha256']
 assert sha(D/obj['member'])==obj['sha256'] and (D/obj['member']).stat().st_size==obj['bytes']
 st=(D/obj['member']).stat();assert (st.st_dev,st.st_ino)!=(obj['source_identity']['device'],obj['source_identity']['inode'])
 assert obj['selected_assets']==[a for a in plan['selected_assets'] if a['editing_object']==selected['name']]
for spec,m in zip([s for s in plan['objects'] if s['listing']],members):
 assert m['listed_members']==spec['listed_members'] and m['original_listing_receipt']==spec['listing']['source_receipt']
 assert m['member_payloads_decoded_in_this_run']is False and m['individual_member_sha256_from_listing']is False
warning=notices['monitor_notice_copy'];assert warning['member']=='notices/monitor-export-warning.txt' and warning['bytes']==87
assert warning['sha256']=='f36738f0793eb47f476f2604175104dbb1214ca871ed1f85ee4ebb52c76537ae' and warning['independent_copy']is True
assert sha(D/warning['member'])==warning['sha256'] and warning['source_identity']['path']==plan['monitor_notice']['retained_text']['path']
st=(D/warning['member']).stat();assert (st.st_dev,st.st_ino)!=(warning['source_identity']['device'],warning['source_identity']['inode'])
assert {c['original_component']['profile'] for c in components}==set(plan['component_profiles'])
assert all(c['selected_source_assets']==plan['selected_assets'] and len(c['editing_source_members'])==5 for c in components)
expected={'manifest.json','object-member-index.json','notice-index.json','component-member-index.json','metadata/asset-selection.json','metadata/member-index.json','metadata/original-status.json','notices/monitor-export-warning.txt'}
expected.update('objects/'+s['selection']['name'] for s in plan['objects'])
assert len(expected)==13 and {str(Path(r['path']).relative_to(D)) for r in report['files']}==expected
import stat
assert all(stat.S_IMODE(p.lstat().st_mode)==(0o555 if p.is_dir() else 0o444) and not p.is_symlink() for p in [D,*D.rglob('*')])
assert cleanup['all_recorded_identities_absent']is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped']is False
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']();keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']};supervisor=cleanup['supervisor_identity'];assert supervisor is not None;keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in keys];parents={r['pid'] for r in matching};descendants=[]
while parents:
 children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants];descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[p for p in O.rglob('*') if p.is_file()]+[run/'runner-result.json',run/'build.rc']+[Path(r['path']) for r in report['files']]
assert len(files)<=1024 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=64*1024**2
out=O/'admission-completion-evidence.json';evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Exact five Koko editing-source bodies and87-byte export notice local custody only; original Git blob proof and separate flat hashes, selected Slang source asset associations and existing full notice references retained. No acquisition/decode/regeneration, full bundle completion, legal/publication clearance, independent retrieval or offhost proof. Previous runs unchanged.')
raw=(json.dumps(evidence,indent=2)+'\n').encode();assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=64*1024**2
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed Koko editing-source custody; explicit publication gaps retained')

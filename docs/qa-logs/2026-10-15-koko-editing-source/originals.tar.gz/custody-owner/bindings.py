"""Exact source/host bindings; no collection at import."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def prerequisites(plan):
 for spec in plan['prerequisites']:
  owner,run=Path(spec['owner']),Path(spec['run']);c=load(run/'admission-consumed.json');result=load(owner/'result.json');cleanup=load(owner/'cleanup.json')
  assert c['id']==spec['admission_id'] and c['state']=='consumed' and c['submission_owner']==str(owner) and c['run']==str(run)
  assert c['source']['head']==COMMIT and c['pid_namespace']==4026531836
  assert c['original_result']==load(run/'runner-result.json')
  assert all(type(c['original_result'][k])is int and c['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
  assert sha(owner/'admission-completion-evidence.json')==c['evidence_sha256']
  launch=load(owner/'launcher-result.json');assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
  for f in [owner/'inner.rc',owner/'outer.rc',owner/'tool-wrapper.rc',owner/'stage/association.exit',run/'build.rc']:assert f.read_text().strip()=='0'
  child=load(owner/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0 and child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
  assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False and result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
  assert cleanup['all_recorded_identities_absent']is True and cleanup['direct_child_unreaped']is False and not any(cleanup[k] for k in ['errors','receipt_errors','signals_sent','recorded_identities_still_present','survivors_after_cleanup'])
 acquisition=load(Path(plan['acquisition_owner'])/'collection-result.json')
 assert acquisition['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(acquisition['original_collector_exit'])is int and acquisition['original_collector_exit']==0
 assert len(acquisition['rows'])==len(acquisition['requests'])==5 and len(acquisition['listings'])==4
 assert sum(r['body']['bytes'] for r in acquisition['rows'])==47056031
 assert all(r['wait']['wait_observed']is True and type(r['wait']['original_returncode'])is int and r['wait']['original_returncode']==0 and not r['wait']['timeout'] and not r['wait']['cleanup_signals'] for r in acquisition['requests']+acquisition['listings'])
 assert all(acquisition[k]is False for k in ['extraction_performed','regeneration_performed','source_execution','source_rebuild','target_execution','publication_clearance'])
 assert acquisition['network_used']is True
 assert [(r['selection'],r['body'],r['actual_git_blob_sha1']) for r in acquisition['rows']]==[(r['selection'],r['body']['held_identity'],r['actual_git_blob_sha1']) for r in plan['objects']]
 notice=plan['monitor_notice'];read=load(notice['receipt']['path']);run=Path(notice['read_run'])
 assert notice['content_read']is True and notice['bytes']==87 and read['bytes']==87
 assert type(read['original_exit'])is int and read['original_exit']==0 and read['timeout']is False and read['archive_changed']is False and read['source_execution']is False
 assert read['sha256']==notice['retained_text']['sha256']=='f36738f0793eb47f476f2604175104dbb1214ca871ed1f85ee4ebb52c76537ae'
 assert read['archive_member']==notice['member']=='monitor_body_source/warning.read.me.txt'
 assert read['archive_sha256']==plan['objects'][0]['body']['sha256']=='f341e1c64549c1cf3f90c616e8a5af4365223891c60ff461f8a82349d1294ff7'
 original=load(run/'runner-result.json');assert all(type(original[k])is int and original[k]==0 for k in ['command_rc','monitor_rc','runner_rc']) and (run/'build.rc').read_text().strip()=='0'
 additive=load(Path(plan['additive_custody'])/'manifest.json');assert additive['component_rows']==2366 and additive['publication_bundle_complete']is False
 assert sha(Path(plan['additive_custody'])/'component-member-index.json')==additive['component_index_sha256']
 return acquisition

def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 plan=load(O/'collection-plan.json');assert len(plan['binding_refs'])==54
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 assert len(plan['objects'])==5 and plan['object_bytes']==47056031 and len(plan['selected_assets'])==6 and len(plan['notices'])==3
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-koko-editing-source-'+O.name.removeprefix('pix-m7-koko-editing-custody-')
 prerequisites(plan)
 return plan

#!/usr/bin/env python3
"""Offline immutable-copy custody; execution requires root's separate admission."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,sys,time
from urllib.parse import urlsplit
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path'])
START=time.monotonic();READ=0;WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1
def tick(n=0):
 global READ
 assert n>=0;READ+=n
 assert READ<=R['total_read_bytes'] and time.monotonic()-START<R['soft_seconds'],'read/time ceiling'
def safe(name):
 assert isinstance(name,str) and name and len(os.fsencode(name))<=R['path_bytes'] and '\0' not in name and '\\' not in name
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p)==name and '.git' not in p.parts,name
 return name

def ident(p,regular=True):
 p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.resolve(strict=True)==p,p
 s=p.stat();assert not regular or stat.S_ISREG(s.st_mode),p
 return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def digest(p,cap=268435456):
 before=ident(p);assert before['bytes']<=cap
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));h.update(b)
 assert ident(p)==before,'input changed while hashing'
 return dict(before,sha256=h.hexdigest())
def root_for(p):
 for root in [O,D]:
  if p.is_relative_to(root):return root
 raise AssertionError('write outside owned roots')
def mkdir(p):
 root=root_for(p);assert len(DIRS)<R['output_directories'];assert not p.exists() and not p.is_symlink()
 assert p.parent.resolve(strict=True)==p.parent and not p.parent.is_symlink();p.mkdir(mode=0o700);DIRS.add(str(p))
def reserve(p,n,failure=False):
 tick();root=root_for(p);cap=R['custody_output_ceiling_bytes'] if root==D else R['owner_output_ceiling_bytes']-R['supervisor_reserve_bytes']
 if failure:assert root==O and n<=R['failure_receipt_budget_bytes'];cap+=R['failure_receipt_budget_bytes']
 assert n>=0 and OUTPUT[str(root)]+n<=cap,'aggregate before-write ceiling'
 assert WRITES[str(p)]+n<=R['per_file_bytes'],'individual before-write ceiling'
 OUTPUT[str(root)]+=n;WRITES[str(p)]+=n
class Writer:
 def __init__(self,p,failure=False):
  self.p=Path(p);root_for(self.p);safe(str(self.p.relative_to(root_for(self.p))))
  assert len(WRITES)<R['output_files'] and str(self.p) not in WRITES
  assert self.p.parent.resolve(strict=True)==self.p.parent and not self.p.exists() and not self.p.is_symlink()
  WRITES[str(self.p)]=0;self.failure=failure;self.f=self.p.open('xb')
 def write(self,b):reserve(self.p,len(b),self.failure);return self.f.write(b)
 def flush(self):self.f.flush()
 def tell(self):return self.f.tell()
 def close(self):self.f.close()
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
def put(p,obj,failure=False):
 raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
 if failure:assert len(raw)<=R['failure_receipt_budget_bytes']
 with Writer(p,failure) as f:f.write(raw)
def rawput(p,b):
 with Writer(p) as f:f.write(b)
def load(p):
 before=ident(p);assert before['bytes']<16*1024**2
 raw=Path(p).read_bytes();tick(len(raw));assert ident(p)==before;return json.loads(raw)

def copy_file(spec,member):
 safe(member);p=Path(spec['path']);before=digest(p,R['per_file_bytes'])
 assert before['bytes']==spec['bytes'] and before['sha256']==spec['sha256']
 if 'held_identity' in spec:assert before==spec['held_identity']
 target=D/member
 with p.open('rb') as f,Writer(target) as out:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));out.write(b)
 after=digest(target,R['per_file_bytes']);assert after['sha256']==before['sha256'] and after['bytes']==before['bytes']
 assert (after['device'],after['inode'])!=(before['device'],before['inode']) and digest(p,R['per_file_bytes'])==before
 return dict(member=member,bytes=after['bytes'],sha256=after['sha256'],source_identity=before,independent_copy=True)

def selected_maps(acquisition):
 rows=acquisition['rows'];assert len(rows)==5
 byname={r['selection']['name']:r for r in rows};assert len(byname)==5
 base=load(Path(PLAN['additive_custody'])/'component-member-index.json');components=[r for r in base if r['component']=='slang-shaders']
 assert len(components)==3 and {r['profile'] for r in components}==set(PLAN['component_profiles'])
 mapped=[];member_rows=[];total=0
 for spec in PLAN['objects']:
  selected=spec['selection'];name=safe(selected['name']);assert '/' not in name
  actual=byname[name];assert actual['selection']==selected and actual['body']==spec['body']['held_identity']
  assert actual['actual_git_blob_sha1']==spec['actual_git_blob_sha1']==selected['expected_git_blob_sha1']
  assert actual['source_status']=='EXACT_GIT_BLOB_AND_SIZE_VERIFIED' and actual['publication_clearance']is False
  assert spec['body']['bytes']==selected['expected_bytes']
  assert Path(spec['body']['path'])==Path(PLAN['acquisition_owner'])/'objects'/name
  u=urlsplit(selected['immutable_blob_api_url']);assert u.scheme=='https' and u.netloc=='api.github.com' and not u.query and not u.fragment and not u.username and not u.password
  out=copy_file(spec['body'],'objects/'+name);total+=out['bytes']
  listing=spec['listing']
  if selected['format']=='7z':
   old=[r for r in acquisition['listings'] if r['selection']==selected];assert len(old)==1
   assert old[0]['body']==actual['body'] and old[0]['wait']==listing['original_wait']
   assert old[0]['stdout']==listing['stdout_ref'] and old[0]['stderr']==listing['stderr_ref']
   assert old[0]['wait']['wait_observed']is True and type(old[0]['wait']['original_returncode'])is int and old[0]['wait']['original_returncode']==0
   assert not old[0]['wait']['timeout'] and not old[0]['wait']['cleanup_signals']
   # Original technical-list text remains private. Only exact declared member metadata is projected.
   member_rows.append(dict(object_member=out['member'],object_sha256=out['sha256'],git_blob_sha1=spec['actual_git_blob_sha1'],
    original_listing_receipt=listing['source_receipt'],private_listing_stdout_sha256=listing['stdout_ref']['sha256'],
    listed_members=spec['listed_members'],member_payloads_decoded_in_this_run=False,individual_member_sha256_from_listing=False))
  else:assert listing is None and spec['listed_members']==[] and selected['format']=='png'
  mapped.append(dict(name=name,source_path=selected['source_path'],source_git_mode=selected['source_git_mode'],
   repository=selected['repository'],canonical_blob_url=selected['immutable_blob_api_url'],
   expected_git_blob_sha1=selected['expected_git_blob_sha1'],actual_git_blob_sha1=actual['actual_git_blob_sha1'],
   git_proof='Accepted original acquisition; exact copied body SHA256 and size bind that Git-blob proof. No decoding or Git rehash replay.',
   flat_sha256=out['sha256'],**out,acquisition_verified_receipt=spec['acquisition_verified_receipt'],
   selected_assets=[a for a in PLAN['selected_assets'] if a['editing_object']==name]))
 assert len(mapped)==5 and total==47056031 and len(member_rows)==4
 assert len(PLAN['selected_assets'])==6 and len({a['relative'] for a in PLAN['selected_assets']})==6
 assert sum(a['relative'].endswith('.jpg') for a in PLAN['selected_assets'])==4
 put(D/'metadata/member-index.json',member_rows)
 put(D/'metadata/asset-selection.json',dict(assets=PLAN['selected_assets'],scope='Accepted selected Slang source assets and named editing-source associations only; no image regeneration or new installed-byte claim',monitor_notice=PLAN['monitor_notice']))
 put(D/'object-member-index.json',mapped)
 notice=PLAN['monitor_notice'];warning=copy_file(notice['retained_text'],notice['custody_member'])
 assert warning['bytes']==87 and warning['sha256']=='f36738f0793eb47f476f2604175104dbb1214ca871ed1f85ee4ebb52c76537ae'
 put(D/'notice-index.json',dict(references=PLAN['notices'],existing_reference_texts_copied=False,monitor_notice=notice,monitor_notice_copy=warning,scope='Existing complete supplied GPL/referral texts remain exact references. Exact separately read87-byte technical export note copied unchanged; no archive decoding in this run.'))
 put(D/'component-member-index.json',[dict(original_component=c,original_index_path=PLAN['additive_custody']+'/component-member-index.json',original_index_sha256=PLAN['binding_refs'][PLAN['additive_custody']+'/component-member-index.json'],editing_source_members=[dict(member=m['member'],bytes=m['bytes'],sha256=m['sha256'],git_blob_sha1=m['actual_git_blob_sha1']) for m in mapped],selected_source_assets=PLAN['selected_assets'],notice_index='notice-index.json',source_scope='Additive source custody; all existing original component source remains referenced; no new installed/runtime proof') for c in components])
 return mapped,member_rows

try:
 assert D.parent==Path('/workspace/artifacts/pixelelated-release-sources') and D.name=='m7-koko-editing-source-'+O.name.removeprefix('pix-m7-koko-editing-custody-') and not D.exists() and not D.is_symlink()
 for p in O.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():OUTPUT[str(O)]+=p.stat().st_size
 assert OUTPUT[str(O)]<8*1024**2
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 mkdir(D)
 for n in ['objects','metadata','notices']:mkdir(D/n)
 acquisition=load(Path(PLAN['acquisition_owner'])/'collection-result.json');mapped,members=selected_maps(acquisition)
 statuses=[]
 for p in PLAN['prerequisites']:
  consumed=load(Path(p['run'])/'admission-consumed.json')
  statuses.append(dict(label=p['label'],run=p['run'],owner=p['owner'],admission_id=p['admission_id'],original_result=consumed['original_result'],consumed_state=consumed['state'],consumed_evidence_sha256=consumed['evidence_sha256'],consumed_receipt_sha256=PLAN['binding_refs'][p['run']+'/admission-consumed.json']))
 put(D/'metadata/original-status.json',statuses)
 manifest=dict(schema=1,scope=PLAN['scope'],binding_refs=PLAN['binding_refs'],prior_producers=statuses,object_count=5,object_bytes=47056031,listing_count=4,component_rows=3,selected_asset_count=6,selected_jpeg_count=4,notice_reference_count=3,notice_copy_count=1,notice_copy_bytes=87,
  object_index_sha256=digest(D/'object-member-index.json')['sha256'],member_index_sha256=digest(D/'metadata/member-index.json')['sha256'],asset_index_sha256=digest(D/'metadata/asset-selection.json')['sha256'],notice_index_sha256=digest(D/'notice-index.json')['sha256'],component_index_sha256=digest(D/'component-member-index.json')['sha256'],original_additive_custody=PLAN['additive_custody'],publication_bundle_complete=False,monitor_notice=PLAN['monitor_notice'],unresolved=PLAN['unresolved'])
 put(D/'manifest.json',manifest)
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 files=[dict(path=p,bytes=n,sha256=digest(p,R['per_file_bytes'])['sha256']) for p,n in WRITES.items() if Path(p).is_relative_to(D)]
 assert len(files)==13
 for item in files:Path(item['path']).chmod(0o444)
 for p in sorted([Path(p) for p in DIRS if Path(p).is_relative_to(D)],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
 put(O/'collection-result.json',dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,custody_path=str(D),manifest_sha256=digest(D/'manifest.json')['sha256'],files=files,objects=5,object_bytes=47056031,listing_count=4,component_rows=3,selected_assets=6,notice_references=3,notice_copies=1,notice_copy_bytes=87,network_used=False,target_execution=False,source_execution=False,source_rebuild=False,archive_decode=False,regeneration_performed=False,publication_clearance=False,publication_bundle_complete=False,outputs_held=True,deleted_bytes=0,accounted_output_bytes=OUTPUT,read_bytes=READ,elapsed_seconds=time.monotonic()-START,unresolved=PLAN['unresolved']))
 rc=0
except BaseException as exc:
 try:put(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(exc).__name__+': '+str(exc)[:4096],accounted_output_bytes=OUTPUT,written_files=len(WRITES),publication_bundle_complete=False,outputs_held=True,deleted_bytes=0),failure=True)
 except BaseException as receipt_error:print('Failure receipt refused: '+type(receipt_error).__name__,file=sys.stderr)
sys.exit(rc)

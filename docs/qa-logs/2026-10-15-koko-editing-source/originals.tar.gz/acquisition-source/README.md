# Koko five-object source acquisition — #528

**SOURCE ONLY / UNRUN.** This is the narrow executable derivative of reviewed proposal `c36a6296d356ec228cd77916d9994371c0e90846a72b8ce88ca16f7f23d59d62`. No preparer, collector, consumer, host download/archive CLI, source or target program was executed during preparation. No source body or archive was read, no network request made, no product/shared file changed. The root-owned FEX family remains the only allocated runtime until root consumes it and allocates this work.

The five immutable blob GETs total47,056,031 expected bytes: monitor_body_source.7z, gamegear_overlay.7z, gba_overlay.7z, gbm_overlay.7z and gbc_overlay.png. `collection-plan.json` preserves exact repository paths, Git blob SHA1s and sizes from the sealed prior metadata. The misc tree ID is not mislabeled as a commit. Flat SHA256 and custody paths remain unset in the selection; the actual successful body receipt supplies those observations. No sixth loose Game Gear XCF or source-tree recollection is included.

The held-manifest result remains scoped: no explicit matching object/path/size in the five reviewed manifests; the three current Slang component rows map only the already-held Slang archive. This does not assert that every nested archive/host location was searched. If root finds an exact held object before launch, a separately reviewed reuse binding should avoid refetching it; this candidate intentionally has exactly five fixed GETs and no hidden fallback.

## Runtime behavior and unchanged custody mechanics

`templates/run.py` retains every accepted Tailscale supervisor helper unchanged, including direct Popen original-wait ownership, blocked termination signals during child spawn, subreaper behavior, exact PID/start/pidfd descendant handling and bounded cleanup. Only its selected job label, bound interpreter, result assertions and scope text change. `templates/process-identity.py` is byte-identical. `source-provenance.json` and `changes.diff` identify the exact parent files and changes.

The collector runs five sequential fixed `/git/blobs/<SHA>` GETs using anonymous HTTPS and `curl -q` with an explicit clean subprocess environment containing only PATH and LC_ALL. It does not set or repurpose HOME; credentials, proxy variables and curl configuration are not inherited. No redirects, retries, mutable refs, alternative downloads or base64 expansion are allowed. Each exact-size body is independently checked against Git SHA1 including `blob <length>\0`; flat SHA256, host metadata and format signature are recorded separately. Any HTTP, size, object or signature mismatch retains the original response and fails.

Only after all five body checks succeed, four `7zz/7z l -slt -bd -- <exact body>` children list the archives. All host tools are resolved/hash-bound at root preparation, not predicted here. A script wrapper is refused in place of an actual resolved host ELF. Listings have closed stdin,20-second waits and1MiB per stdout/stderr. The collector does no member extraction or editing, no extra XCF download, regeneration or target execution. Actual member interpretation remains pending in its result. Successful listing is data acquisition, not a claim that a preferred editable project was semantically reviewed.

Each child preserves original wait/exit, command, clean environment, PID/start identity, timeouts and any exact pidfd cleanup. A timed-out child is killed through the qualified direct-child helper and waited; its known original signal exit is retained separately from timeout. Unknown waits remain null/failed. A parent interruption keeps partial outputs and the supervisor owns descendant cleanup. Any timeout, cleanup signal, unknown outcome, output-cap refusal or failed original prevents successful consumption; partial/failed originals are never overwritten or discarded.

## Bounds — actual file capacities reserved before writes

Every active curl **body, header, stdout and stderr** reserves the full common child RLIMIT_FSIZE capacity, equal to that object's exact expected length. There is no promised64KiB header/stream cap. For the largest first object that is4 ×22,816,420 =91,265,680 reserved bytes. Reservations are released to actual sizes only after the original child wait is observed. The HTTP metadata16KiB check is explicitly a later parse condition; it is not represented as an output-size enforcement limit.

Each list child reserves two full1MiB streams. Existing owner files are counted before collection; all JSON writes are counted before creation; all named output paths refuse overwrite. Active reservations remain charged on interruption. The owner ceiling is128MiB, normal collector ceiling120MiB. The8MiB reserve splits into at most1MiB original failure receipt plus7MiB supervisor/consumer margin. Collector and supervisor soft RLIMIT_FSIZE is1MiB with hard32MiB; only a child receives its separately reserved raised cap. This covers the collector's own stage stdout/stderr at their real1MiB soft limits, plus compact supervisor/completion receipts. Huge successful response logs can make a later reservation refuse safely; no silent cap increase or success guarantee is implied.

The family uses650 seconds collector /680 seconds outer /15 seconds outer cleanup, two CPU affinity slots,1GiB address space,1GiB aggregate named-read limit and256MiB retention reservation. Extraction budget is zero. No full source/cache scan or deletion credit is requested. Curl itself has10-second connect and90-second request bounds; its wait allowance is95 seconds. List waits are20 seconds. All partial bodies, raw headers and stdout/stderr remain **private outside Git**. Later compact custody should use structured digests and sanitized receipts, not bundle those raw files automatically.

## Root command handoff

All commands are separate cases in `commands.sh`; there is no auto-admission/launch chain. Root must bind the actual resolved executable paths and hashes using `TASK_CURL_PATH`/`TASK_CURL_SHA256`, `TASK_SEVENZIP_PATH`/`TASK_SEVENZIP_SHA256` and `TASK_PYTHON_PATH`/`TASK_PYTHON_SHA256`. These task-specific names never replace HOME. Preparation verifies the Python executable actually running the preparer matches that declared identity. If the host has only a script wrapper at a familiar7z path, resolve the actual native CLI explicitly; do not bypass the identity guard.

1. Finish and consume the current FEX owner; no second runtime is allocated by this packet.
2. `bash /tmp/pix-m7-koko-editing-source-20261015/commands.sh prepare`
3. `bash /tmp/pix-m7-koko-editing-source-20261015/commands.sh preflight`
4. `bash /tmp/pix-m7-koko-editing-source-20261015/commands.sh report`
5. Root reads the actual preflight/retention reports and prepared seal before `.../commands.sh admit`.
6. `.../commands.sh launch`; actively supervise at most60seconds apart and retain the actual original terminal channels. Never pre-create `tool-wrapper.rc` or `launcher-result.json`.
7. Read the original collection result and four raw technical listings. The success-only `.../commands.sh consume` independently rehashes every body/raw output, recomputes each Git blob SHA1, compares exact command vectors, verifies all original channels/absence and consumes only a successful ordinary admission. Failed runs require root's ordinary failed-investigated disposition with originals held; do not call the success consumer or retry the same owner.

The frozen control checkout remains `m7-p5-build-20261015-02` at `f8636de1d105275dbf9420bbabbbc26f79abb10f`. Its exact ordinary admission/watch digests are preserved in `frozen-tools.json`; do not substitute the coordinator's later tool or invoke reporting-failure recovery. Fresh owner defaults to `/workspace/tmp/pix-m7-koko-editing-source-20261015-01` and refuses any existing path. Preparation and runtime both require the actual host namespace and zero competing unconsumed admissions (runtime allows only its own).

## Acceptance scope

Qualified execution means five exact Git blobs/size with separate flat SHA256, four original successful bounded listing exits, intact originals and no unknown/forced lifecycle outcome. It does not mark archive-member review, complete publication, off-host custody or image regeneration complete. Root may subsequently select exact member reads from the actual listings and integrate the held bodies/notices into existing source custody. The already-settled conservative Koko image inclusion is unchanged; no four-image approval gate or new engineering image is introduced. The separate MAME-adaptation question remains untouched.

Static syntax/AST identity and source-bound consistency are recorded separately. No runtime results or focused test successes are predicted by this packet.

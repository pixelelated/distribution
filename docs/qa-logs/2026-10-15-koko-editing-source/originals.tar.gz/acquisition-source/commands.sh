#!/bin/bash
# SOURCE ONLY / UNRUN. Root reviews and allocates each separate stage.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-koko-editing-source-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-koko-editing-source-20261015-01}
cd "$TASK_TREE"
case "${1:?prepare, preflight, report, admit, launch, or consume}" in
 prepare)
  tools/watch-build --record-only -- "${TASK_PYTHON_PATH:?root-resolved Python ELF}" -I -S -B "$TASK_PACKET/prepare-owner.py" --owner "$TASK_OWNER" \
    --curl-path "${TASK_CURL_PATH:?root-resolved curl ELF}" --curl-sha256 "${TASK_CURL_SHA256:?actual curl SHA256}" \
    --sevenzip-path "${TASK_SEVENZIP_PATH:?root-resolved 7zz or 7z ELF}" --sevenzip-sha256 "${TASK_SEVENZIP_SHA256:?actual 7zip SHA256}" \
    --python-path "$TASK_PYTHON_PATH" --python-sha256 "${TASK_PYTHON_SHA256:?actual Python SHA256}"
  ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- "${TASK_PYTHON_PATH:?bound Python}" -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json" ;;
 admit) "${TASK_PYTHON_PATH:?bound Python}" -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json" ;;
 launch) env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh" ;;
 consume) "${TASK_PYTHON_PATH:?bound Python}" -I "$TASK_OWNER/consume.py" ;;
 *) exit 2 ;;
esac
# Inspect preflight and retention reports before admission; submission is not completion.
# Root supervises <=60seconds apart. Never pre-create launcher-owned receipt files.
# Failure: retain all private partial outputs and originals; ordinary investigated failure
# consumption is root-owned. Never call this success consumer or reuse a failed owner.

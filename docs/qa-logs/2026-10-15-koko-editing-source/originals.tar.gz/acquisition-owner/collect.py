#!/usr/bin/env python3
"""Five fixed public Git blobs; data verification and four list-only operations."""
from pathlib import Path
import datetime,hashlib,json,os,resource,runpy,signal,stat,subprocess,sys,time
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text())
LIMITS=json.loads((O/'resources.json').read_text())
POLICY=PLAN['owner_output_enforcement']
INITIAL=sum(p.stat().st_size for p in O.rglob('*') if p.is_file())
OUTPUT=INITIAL
START=time.monotonic();READ=0
requests=[];listings=[];rows=[];reservations=[];active=None;rc=1
I=runpy.run_path(str(O/'process-identity.py'))
ENV={'PATH':'/usr/bin:/bin','LC_ALL':'C'}  # Deliberately no HOME, auth or proxy variables.

def account(n,failure=False):
    global OUTPUT
    assert type(n)is int and n>=0
    if failure:assert n<=POLICY['failure_receipt_budget_bytes']
    ceiling=POLICY['owner_ceiling_bytes']-(POLICY['supervisor_receipt_margin_bytes'] if failure else POLICY['supervisor_receipt_reserve_bytes'])
    assert OUTPUT+n<=ceiling,'owner-output reservation refused before write'
    OUTPUT+=n

def write(path,value,failure=False):
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    assert len(raw)<=LIMITS['max_json_bytes']
    assert not path.exists() and not path.is_symlink(),'refuse output overwrite'
    account(len(raw),failure)
    with path.open('xb') as f:f.write(raw)

def identity(path):
    assert path.is_absolute() and path.resolve(strict=True)==path and not path.is_symlink()
    s=path.stat();assert stat.S_ISREG(s.st_mode)
    return dict(path=str(path),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)

def budget(n=0):
    global READ
    READ+=n
    assert READ<=LIMITS['named_read_ceiling_bytes'] and time.monotonic()-START<LIMITS['collector_seconds']-20,'named-read/time ceiling'

def digest(path,cap):
    before=identity(path);assert before['bytes']<=cap
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):budget(len(b));h.update(b)
    assert identity(path)==before,'input identity changed'
    return dict(before,sha256=h.hexdigest())

def reserve(key,paths,cap):
    assert all(not p.exists() and not p.is_symlink() for p in paths)
    # Each file can grow to the common child RLIMIT, including headers/raw streams.
    total=len(paths)*cap;account(total)
    r=dict(key=key,paths=[str(p) for p in paths],per_file_limit=cap,reserved_bytes=total,
           actual_bytes=None,released_bytes=0,original_wait_observed=False)
    reservations.append(r)
    return r

def release(r,records):
    global OUTPUT
    assert not r['original_wait_observed'] and len(records)==len(r['paths'])
    assert [v['path'] for v in records]==r['paths']
    assert all(0<=v['bytes']<=r['per_file_limit'] for v in records)
    used=sum(v['bytes'] for v in records);unused=r['reserved_bytes']-used
    assert OUTPUT>=unused;OUTPUT-=unused
    r.update(actual_bytes=used,released_bytes=unused,original_wait_observed=True)

def child(key,argv,cap,wait_seconds,stdout,stderr):
    global active
    tool=TOOLS['curl' if key.startswith('get-') else 'sevenzip']
    assert digest(Path(tool['path']),16*1024**2)==tool['identity']
    row=dict(key=key,argv=argv,environment=ENV,original_returncode=None,wait_observed=False,
             timeout=False,cleanup_signals=[],identity=None,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    active=row
    with stdout.open('xb') as so,stderr.open('xb') as se:
        # Same direct-child pidfd helper as the accepted supervisor; no numeric-group signal.
        proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=so,stderr=se,
            cwd=O,env=ENV,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(cap,cap)))
        row['identity']=I['identity'](proc.pid)
        assert row['identity'] is not None and row['identity']['ppid']==os.getpid()
        try:
            proc.wait(timeout=wait_seconds)
        except subprocess.TimeoutExpired:
            row['timeout']=True
            row['cleanup_signals'].append(I['signal_child'](row['identity'],os.getpid(),signal.SIGKILL))
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:pass
        finally:
            if proc.returncode is not None:
                row.update(original_returncode=proc.returncode,wait_observed=True)
        row['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(O/'receipts'/(key+'.wait.json'),row)
    active=None
    assert row['wait_observed'],'original child wait unavailable; supervisor retains remaining custody'
    assert digest(Path(tool['path']),16*1024**2)==tool['identity'],'host CLI changed'
    return row

def object_identity(selection,path):
    before=identity(path);assert before['bytes']==selection['expected_bytes'],'exact body length mismatch'
    git=hashlib.sha1(b'blob '+str(before['bytes']).encode('ascii')+b'\0');flat=hashlib.sha256();header=b''
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1024**2),b''):
            budget(len(data));git.update(data);flat.update(data)
            if not header:header=data[:32]
    assert identity(path)==before
    assert git.hexdigest()==selection['expected_git_blob_sha1'],'Git blob identity mismatch'
    magic=b'7z\xbc\xaf\x27\x1c' if selection['format']=='7z' else b'\x89PNG\r\n\x1a\n'
    assert header.startswith(magic),'format signature mismatch'
    return dict(selection=selection,body=dict(before,sha256=flat.hexdigest()),
        actual_git_blob_sha1=git.hexdigest(),header_hex=header.hex(),
        git_hash_includes_blob_header=True,flat_sha256_includes_git_header=False,
        source_status='EXACT_GIT_BLOB_AND_SIZE_VERIFIED',archive_members_reviewed=False,
        preferred_editing_source_confirmed=False,generated_image_equivalence_claim=False,publication_clearance=False)

def fetch(selection):
    key='get-'+selection['name'];cap=selection['expected_bytes']
    body=O/'objects'/selection['name'];headers=O/'requests'/(key+'.headers')
    stdout=O/'requests'/(key+'.stdout');stderr=O/'requests'/(key+'.stderr')
    paths=[body,headers,stdout,stderr];reservation=reserve(key,paths,cap)
    # Reserve and exclusively create curl's own two outputs before curl may write them.
    for p in [body,headers]:
        with p.open('xb'):pass
    url=selection['immutable_blob_api_url']
    assert url=='https://api.github.com/repos/kokoko3k/koko-aio-slang-misc/git/blobs/'+selection['expected_git_blob_sha1']
    argv=[TOOLS['curl']['path'],'-q','--fail','--proto','=https','--connect-timeout',str(LIMITS['connect_seconds']),
          '--max-time',str(LIMITS['request_seconds']),'--max-filesize',str(cap),'--retry','0',
          '--silent','--show-error','--header','Accept: application/vnd.github.raw+json',
          '--dump-header',str(headers),'--output',str(body),'--write-out','%{http_code}\n%{url_effective}\n%{redirect_url}\n',url]
    wait=child(key,argv,cap,LIMITS['request_wait_seconds'],stdout,stderr)
    records=[digest(p,cap) for p in paths];release(reservation,records)
    row=dict(key=key,selection=selection,wait=wait,body=records[0],headers=records[1],stdout=records[2],stderr=records[3],reservation=reservation)
    requests.append(row);write(O/'receipts'/(key+'.result.json'),row)
    assert wait['original_returncode']==0 and not wait['timeout'] and not wait['cleanup_signals'],'original curl failure'
    # Parsing limit is a post-read condition, not a falsely advertised file-size cap.
    assert records[2]['bytes']<=16384,'HTTP metadata parse bound'
    fields=stdout.read_text().splitlines()
    assert fields==['200',url,''],'HTTP status/effective URL/redirect differs'
    verified=object_identity(selection,body)
    assert verified['body']==records[0]
    rows.append(verified);write(O/'verified'/(selection['name']+'.json'),verified)

def list_archive(row):
    selection=row['selection'];key='list-'+selection['name'];cap=LIMITS['list_stream_limit_bytes']
    body=Path(row['body']['path']);assert digest(body,selection['expected_bytes'])==row['body']
    stdout=O/'lists'/(key+'.stdout');stderr=O/'lists'/(key+'.stderr')
    reservation=reserve(key,[stdout,stderr],cap)
    argv=[TOOLS['sevenzip']['path'],'l','-slt','-bd','--',str(body)]
    wait=child(key,argv,cap,LIMITS['list_seconds'],stdout,stderr)
    records=[digest(p,cap) for p in [stdout,stderr]];release(reservation,records)
    after=digest(body,selection['expected_bytes']);assert after==row['body'],'archive changed while listing'
    result=dict(key=key,selection=selection,body=after,wait=wait,stdout=records[0],stderr=records[1],reservation=reservation,
                member_review_pending=True,extraction_performed=False)
    listings.append(result);write(O/'receipts'/(key+'.result.json'),result)
    assert wait['original_returncode']==0 and not wait['timeout'] and not wait['cleanup_signals'],'original archive listing failed'
    assert records[0]['bytes']>0,'empty technical listing'

try:
    assert INITIAL<=LIMITS['initial_owner_maximum_bytes'];account(0)
    TOOLS=json.loads((O/'host-tools.json').read_text())
    assert set(TOOLS)=={'curl','sevenzip','python'}
    assert len(PLAN['selected_objects'])==5 and sum(r['expected_bytes'] for r in PLAN['selected_objects'])==47056031
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    for name in ['objects','requests','receipts','verified','lists']:(O/name).mkdir(mode=0o700)
    for selection in PLAN['selected_objects']:fetch(selection)
    assert len(rows)==5
    for row in rows:
        if row['selection']['format']=='7z':list_archive(row)
    assert len(requests)==5 and len(listings)==4
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    report=dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,rows=rows,requests=requests,listings=listings,
        reservations=reservations,owner_output_enforcement=POLICY,initial_owner_bytes=INITIAL,
        accounted_owner_bytes_before_report=OUTPUT,named_bytes_read=READ,elapsed_seconds=time.monotonic()-START,
        network_used=True,source_rebuild=False,source_execution=False,target_execution=False,
        extraction_performed=False,regeneration_performed=False,independent_SYSTEM_relation_established=False,
        publication_clearance=False,archive_member_review_pending=True,outputs_held=True,deleted_bytes=0)
    write(O/'collection-result.json',report);rc=0
except BaseException as error:
    # Keep all partial/private outputs. Unknown waits and active reservations remain explicit.
    write(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,
        error=type(error).__name__+': '+str(error)[:4096],completed_objects=len(rows),completed_listings=len(listings),
        active_child=active,reservations=reservations,requests=requests,listings=listings,
        initial_owner_bytes=INITIAL,accounted_owner_bytes_before_failure=OUTPUT,named_bytes_read=READ,
        publication_clearance=False,outputs_held=True,deleted_bytes=0),failure=True)
sys.exit(rc)

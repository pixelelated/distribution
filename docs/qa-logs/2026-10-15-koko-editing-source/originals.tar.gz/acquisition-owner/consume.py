#!/usr/bin/env python3
"""Consume only original successful collection channels; gaps never become clearance."""
from pathlib import Path
import hashlib,json,runpy,subprocess,stat
O=Path(__file__).resolve().parent
B=runpy.run_path(str(O/'bindings.py'));B['verify'](O)
assert Path.cwd()==B['VM_TREE']
load,sha=B['load'],B['sha']
run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs'
B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
for f in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert f.read_text().strip()=='0',f
result,cleanup=load(O/'result.json'),load(O/'cleanup.json')
assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete'] is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established'] is False
assert result['execution_error'] is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json')
assert child['wait_observed'] is True and type(child['original_child_returncode']) is int and child['original_child_returncode']==0
assert child['qualification'] is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json')
assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit']) is int and report['original_collector_exit']==0
assert report['publication_clearance'] is False and report['independent_SYSTEM_relation_established'] is False
assert not (O/'collection-failure.json').exists()
plan=load(O/'collection-plan.json');policy=plan['owner_output_enforcement'];limits=load(O/'resources.json')
assert report['owner_output_enforcement']==policy and policy['owner_ceiling_bytes']==128*1024**2
assert type(report['initial_owner_bytes'])is int and 0<report['initial_owner_bytes']<=limits['initial_owner_maximum_bytes']
assert report['accounted_owner_bytes_before_report']<=policy['normal_collector_write_ceiling_bytes']
assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=128*1024**2
assert len(report['rows'])==len(report['requests'])==5 and len(report['listings'])==4 and len(report['reservations'])==9
assert [r['selection'] for r in report['rows']]==plan['selected_objects']
assert report['source_rebuild']is False and report['source_execution']is False and report['target_execution']is False
assert report['extraction_performed']is False and report['regeneration_performed']is False and report['network_used']is True
assert report['archive_member_review_pending']is True and report['outputs_held']is True and report['deleted_bytes']==0
TOOLS=load(O/'host-tools.json')
def check_file(record,parent):
    p=Path(record['path']);assert p.parent==parent and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size==record['bytes'] and sha(p)==record['sha256']
    assert all(record[k]==v for k,v in dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns).items())
    return p

def check_child(record):
    w=record['wait'];key=record['key']
    assert type(w['original_returncode'])is int and w['original_returncode']==0 and w['wait_observed']is True
    assert not w['timeout'] and not w['cleanup_signals'] and w['identity'] is not None
    assert w['environment']=={'PATH':'/usr/bin:/bin','LC_ALL':'C'}
    assert w==load(O/'receipts'/(key+'.wait.json'))
    assert record==load(O/'receipts'/(key+'.result.json'))

def check_reservation(record,files,cap):
    r=record['reservation'];assert r in report['reservations'] and r['key']==record['key']
    assert r['paths']==[f['path'] for f in files] and r['per_file_limit']==cap
    assert r['reserved_bytes']==len(files)*cap and all(0<=f['bytes']<=cap for f in files)
    assert r['actual_bytes']==sum(f['bytes'] for f in files)
    assert r['released_bytes']==r['reserved_bytes']-r['actual_bytes'] and r['original_wait_observed']is True

for selected,row,request in zip(plan['selected_objects'],report['rows'],report['requests']):
    assert request['selection']==selected and request['key']=='get-'+selected['name']
    check_child(request)
    key=request['key'];body=check_file(request['body'],O/'objects')
    headers=check_file(request['headers'],O/'requests');stdout=check_file(request['stdout'],O/'requests');stderr=check_file(request['stderr'],O/'requests')
    assert body.name==selected['name'] and headers.name==key+'.headers' and stdout.name==key+'.stdout' and stderr.name==key+'.stderr'
    url=selected['immutable_blob_api_url'];cap=selected['expected_bytes']
    expected=[TOOLS['curl']['path'],'-q','--fail','--proto','=https','--connect-timeout',str(limits['connect_seconds']),
        '--max-time',str(limits['request_seconds']),'--max-filesize',str(cap),'--retry','0','--silent','--show-error',
        '--header','Accept: application/vnd.github.raw+json','--dump-header',str(headers),'--output',str(body),
        '--write-out','%{http_code}\n%{url_effective}\n%{redirect_url}\n',url]
    assert request['wait']['argv']==expected
    assert request['stdout']['bytes']<=16384 and stdout.read_text().splitlines()==['200',url,'']
    check_reservation(request,[request[k] for k in ['body','headers','stdout','stderr']],cap)
    assert row==load(O/'verified'/(selected['name']+'.json')) and row['body']==request['body']
    assert row['body']['bytes']==cap and row['source_status']=='EXACT_GIT_BLOB_AND_SIZE_VERIFIED'
    git=hashlib.sha1(b'blob '+str(cap).encode('ascii')+b'\0')
    with body.open('rb') as f:
        header=f.read(32);f.seek(0)
        for data in iter(lambda:f.read(1024**2),b''):git.update(data)
    assert git.hexdigest()==selected['expected_git_blob_sha1']==row['actual_git_blob_sha1']
    magic=b'7z\xbc\xaf\x27\x1c' if selected['format']=='7z' else b'\x89PNG\r\n\x1a\n'
    assert header.startswith(magic) and row['header_hex']==header.hex()
    assert row['git_hash_includes_blob_header']is True and row['flat_sha256_includes_git_header']is False
    assert row['archive_members_reviewed']is False and row['preferred_editing_source_confirmed']is False
    assert row['generated_image_equivalence_claim']is False and row['publication_clearance']is False
archive_rows=[r for r in report['rows'] if r['selection']['format']=='7z']
for row,listing in zip(archive_rows,report['listings']):
    assert listing['selection']==row['selection'] and listing['body']==row['body']
    assert listing['key']=='list-'+row['selection']['name']
    check_child(listing);body=check_file(listing['body'],O/'objects')
    stdout=check_file(listing['stdout'],O/'lists');stderr=check_file(listing['stderr'],O/'lists')
    assert stdout.name==listing['key']+'.stdout' and stderr.name==listing['key']+'.stderr'
    assert listing['wait']['argv']==[TOOLS['sevenzip']['path'],'l','-slt','-bd','--',str(body)]
    assert listing['stdout']['bytes']>0
    check_reservation(listing,[listing['stdout'],listing['stderr']],limits['list_stream_limit_bytes'])
    assert listing['member_review_pending']is True and listing['extraction_performed']is False
assert [r['key'] for r in report['reservations']]==[r['key'] for r in report['requests']+report['listings']]
assert cleanup['all_recorded_identities_absent'] is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped'] is False
# Same qualified final-inventory strict census and PID/start identity custody.
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']()
owned_keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']}
supervisor=cleanup['supervisor_identity'];assert supervisor is not None
owned_keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in owned_keys]
parents={r['pid'] for r in matching};descendants=[]
while parents:
    children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants]
    descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants,'recorded identity or owned descendant still present'
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[O/n for n in ['result.json','cleanup.json','collection-result.json','collection-plan.json','preparation.json','host-tools.json','seal.json','inner.rc','outer.rc','launcher-result.json','tool-wrapper.rc']]+[run/'runner-result.json',run/'build.rc']
files+=sorted(p for d in ['stage','requests','receipts','verified','lists'] for p in (O/d).rglob('*') if p.is_file())
files+=sorted(p for p in (O/'objects').iterdir() if p.is_file())
assert len(files)<=256 and sum(p.stat().st_size for p in files)<=128*1024**2
out=O/'admission-completion-evidence.json'
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Five fixed Koko editing-source objects match exact Git blob SHA1 and size; flat SHA256 retained separately. Four list-only child exits0, archive member review pending. No extraction, regeneration, target/source execution or publication clearance. Raw bodies, headers and streams stay private outside Git; all prior producer dispositions unchanged.')
raw=(json.dumps(evidence,indent=2)+'\n').encode()
assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=128*1024**2,'completion receipt would exceed owner ceiling'
with out.open('xb') as f:f.write(raw)
subprocess.run([TOOLS['python']['path'],'-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed five exact Koko blobs and four listings; member review/publication remain explicit')

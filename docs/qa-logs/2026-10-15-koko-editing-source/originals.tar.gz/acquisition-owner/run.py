"""Serialized inventory with identity-bound custody and retained original child waits."""
from pathlib import Path
import ctypes
import datetime
import hashlib
import json
import os
import runpy
import signal
import subprocess
import sys
import time
import traceback

O = Path(__file__).resolve().parent
def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()
def write(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write('\n')
def write_once(p, obj):
    # A completed original is immutable; partial or different receipts refuse.
    if p.exists():
        assert json.loads(p.read_text()) == obj, 'receipt differs: '+str(p)
    else:
        write(p, obj)
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

run = Path.cwd()/os.environ['RASTERATOPS_BUILD_RUN']
with (O/'run.path').open('x') as f:
    f.write(str(run)+'\n')
rc = 1
rows = []
active = None
current_row = None
I = None
B = None
profiles = []
supervisor = None
identities = {}
reaped = []
signals_sent = []
interrupted_signals = []
cleanup_errors = []
receipt_errors = []
execution_error = None
finalizing = False

def observed():
    owned = I['tree'](os.getpid())
    for row in owned:
        identities[(row['pid'], row['start_ticks'])] = row
    return owned

def capture_wait():
    if active is not None and active['proc'].returncode is not None:
        value = active['proc'].returncode
        assert type(value) is int
        if active['wait_observed']:
            assert active['original_rc'] == value, 'Popen wait result changed'
            return
        active['original_rc'] = value
        active['row'][active['key']+'_rc'] = value
        active['wait_observed'] = True

def reap_adopted():
    # Target only verified direct/adopted children. Popen exclusively owns its wait.
    for row in I['children'](os.getpid()):
        identities[(row['pid'], row['start_ticks'])] = row
        if active is not None and row['pid'] == active['proc'].pid:
            continue
        if not I['same'](row):
            continue
        try:
            pid, status = os.waitpid(row['pid'], os.WNOHANG)
        except ChildProcessError:
            assert not I['same'](row), 'known child wait unavailable'
            continue
        if pid:
            reaped.append(dict(identity=row, wait_status=status, exit_code=os.waitstatus_to_exitcode(status)))

def cleanup_active():
    """At most the existing 5+5+3-second allowance; signal no numeric group."""
    deadline = time.monotonic()+13
    if active is not None:
        deadline = active.setdefault('cleanup_deadline', deadline)
    observed()
    if active is not None:
        proc = active['proc']
        capture_wait()
        for signum in [signal.SIGTERM, signal.SIGKILL]:
            if proc.returncode is not None:
                break
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                break
            row = I['identity'](proc.pid)
            assert row is not None and active['identity'] is not None
            assert row['start_ticks'] == active['identity']['start_ticks'] and row['ppid'] == os.getpid(), 'direct child custody changed'
            if row['state'] != 'Z':
                signals_sent.append(I['signal_child'](row, os.getpid(), signum))
            try:
                proc.wait(timeout=min(5, remaining))
            except subprocess.TimeoutExpired:
                pass
            finally:
                capture_wait()
    while time.monotonic() < deadline:
        observed()
        reap_adopted()
        owned = observed()
        if not owned:
            break
        for row in I['children'](os.getpid()):
            identities[(row['pid'], row['start_ticks'])] = row
            if active is not None and row['pid'] == active['proc'].pid:
                continue
            if row['state'] != 'Z':
                signals_sent.append(I['signal_child'](row, os.getpid()))
        if active is not None and active['proc'].returncode is None:
            try:
                active['proc'].wait(timeout=min(.05, max(0, deadline-time.monotonic())))
            except subprocess.TimeoutExpired:
                pass
            finally:
                capture_wait()
        time.sleep(.01)
    capture_wait()
    reap_adopted()
    survivors = observed()
    if active is not None:
        active['survivors_after_cleanup'] = survivors
        active['cleanup_done'] = not survivors and active['wait_observed']
        assert active['wait_observed'], 'direct child wait outcome unknown'
    assert not survivors, 'owned descendants survived bounded cleanup'

def publish_active():
    if active is None or active['published']:
        return
    capture_wait()
    d, key = active['directory'], active['key']
    value = active['original_rc']
    # Freeze the original receipt payload before any write; interrupted publication
    # can finish identical bytes without rewriting a completed original.
    if active['payload'] is None:
        active['payload'] = dict(profile=active['row']['profile'], command_key=key,
            command=active['command'], identity=active['identity'],
            original_child_returncode=value, wait_observed=active['wait_observed'],
            interrupted=active['interrupted'], timeout=active['timeout'],
            disposition='interrupted' if active['interrupted'] else 'timeout' if active['timeout'] else 'completed',
            qualification=bool(active['wait_observed'] and value == 0 and not active['interrupted']
                and not active['timeout'] and active.get('cleanup_done') and not cleanup_errors
                and len(signals_sent) == active['signal_start']),
            cleanup_signals=signals_sent[active['signal_start']:],
            stdout=str(d/(key+'.stdout')), stderr=str(d/(key+'.stderr')))
    if active['wait_observed']:
        path = d/(key+'.exit');text = str(value)+'\n'
        if path.exists():
            assert path.read_text() == text, 'original child exit differs'
        else:
            with path.open('x') as f:
                f.write(text)
    write_once(d/(key+'.result.json'), active['payload'])
    if active['timeout']:
        write_once(d/(key+'.timeout.json'), dict(timeout=True, original_child_returncode=value,
            wait_observed=active['wait_observed'], qualification=False))
    if active['interrupted']:
        write_once(d/(key+'.interrupted.json'), dict(interrupted=True, signals=interrupted_signals[:],
            original_child_returncode=value, wait_observed=active['wait_observed'], qualification=False))
    active['published'] = True

def stopped(signum, frame):
    global rc
    rc = 1
    interrupted_signals.append(signum)
    if active is not None and not active['published']:
        active['interrupted'] = True
    if not finalizing:
        raise RuntimeError('inventory received signal '+str(signum))

signal.signal(signal.SIGTERM, stopped)
signal.signal(signal.SIGINT, stopped)
try:
    for name, h in json.loads((O/'seal.json').read_text()).items():
        assert sha(name) == h, name
    I = runpy.run_path(str(O/'process-identity.py'))
    assert hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal'), 'pidfd support required'
    libc = ctypes.CDLL(None, use_errno=True)
    assert libc.prctl(36, 1, 0, 0, 0) == 0  # PR_SET_CHILD_SUBREAPER
    supervisor = I['identity'](os.getpid())
    assert supervisor is not None
    B = runpy.run_path(str(O/'bindings.py'))
    assert Path.cwd() == B['VM_TREE']
    B['host_and_serialization'](run);B['verify'](O)
    limits = B['load'](O/'resources.json')
    d=O/'stage';key='association';row={'profile':'koko-five-editing-source-objects-and-four-listings','association_rc':None,'timeout':False,'interrupted':False,'started_utc':utc()}
    rows.append(row);current_row=row
    cmd=[B['load'](O/'host-tools.json')['python']['path'],'-I','-S','-B',str(O/'collect.py')]
    left=limits['collector_seconds']
    with (d/(key+'.stdout')).open('xb') as stdout, (d/(key+'.stderr')).open('xb') as stderr:
        # Pending termination cannot strand a spawned Popen before custody exists.
        # This runner creates no threads. Enforce that invariant before
        # using a child-only preexec callback; it only restores the mask.
        assert sorted(t.name for t in Path('/proc/self/task').iterdir()) == [str(os.getpid())], 'single-threaded spawn required'
        previous_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGTERM, signal.SIGINT})
        try:
            assert not previous_mask.intersection({signal.SIGTERM, signal.SIGINT}), 'inherited termination mask is blocked'
            proc = subprocess.Popen(cmd, stdout=stdout, stderr=stderr, start_new_session=True,
                preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask))
            active = dict(proc=proc, row=row, key=key, directory=d, command=cmd,
                identity=None, original_rc=None, wait_observed=False, published=False,
                interrupted=False, timeout=False, payload=None, signal_start=len(signals_sent))
            active['identity'] = I['identity'](proc.pid)
            assert active['identity'] is not None and active['identity']['ppid'] == os.getpid()
            identities[(proc.pid, active['identity']['start_ticks'])] = active['identity']
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)
        write(d/(key+'.process.json'), dict(identity=active['identity'], supervisor_identity=supervisor, command=cmd))
        try:
            proc.wait(timeout=left)
        except subprocess.TimeoutExpired:
            row['timeout'] = True;active['timeout'] = True
        finally:
            capture_wait()
        cleanup_active()
        publish_active()
        original_rc = active['original_rc']
        active = None
    row['finished_utc']=utc();write(d/'result.json',row);current_row=None
    assert original_rc==0 and not row['timeout'],'collector failed; preserve original stage receipt'
    report=B['load'](O/'collection-result.json')
    assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and report['original_collector_exit']==0
    assert len(report['rows'])==5 and len(report['requests'])==5 and len(report['listings'])==4 and report['publication_clearance'] is False
    assert all(r['source_status']=='EXACT_GIT_BLOB_AND_SIZE_VERIFIED' for r in report['rows'])
    assert all(r['wait']['original_returncode']==0 and r['wait']['wait_observed'] and not r['wait']['timeout'] and not r['wait']['cleanup_signals'] for r in report['requests']+report['listings'])
    assert report['target_execution'] is False and report['network_used'] is True
    B['verify'](O);B['host_and_serialization'](run)
    assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=limits['owner_output_ceiling_bytes']
    rc=0

except BaseException as error:
    rc = 1
    execution_error = type(error).__name__+': '+str(error)
    traceback.print_exc()
finally:
    finalizing = True
    if current_row is not None:
        current_row['interrupted'] = bool(interrupted_signals)
    survivors = None
    try:
        if I is not None and supervisor is not None:
            cleanup_active()
        else:
            raise RuntimeError('custody setup incomplete; owned census unavailable')
    except BaseException as error:
        cleanup_errors.append(type(error).__name__+': '+str(error));rc = 1
    try:
        publish_active()
    except BaseException as error:
        receipt_errors.append('child receipt: '+type(error).__name__+': '+str(error));rc = 1
    try:
        if I is not None and supervisor is not None:
            survivors = observed()
            assert not survivors, 'owned descendant census not empty'
    except BaseException as error:
        cleanup_errors.append('final census: '+type(error).__name__+': '+str(error));rc = 1
    if current_row is not None:
        current_row['finished_utc'] = utc()
        current_row['incomplete'] = True
        try:
            write_once(O/'stage'/'result.json', current_row)
        except BaseException as error:
            receipt_errors.append('profile receipt: '+type(error).__name__+': '+str(error));rc = 1
    if interrupted_signals or signals_sent or cleanup_errors or receipt_errors or survivors != []:
        rc = 1
    cleanup = dict(supervisor_identity=supervisor, recorded_identities=list(identities.values()),
        survivors_after_cleanup=survivors, all_recorded_identities_absent=False,
        signals_sent=signals_sent, reaped=reaped, errors=cleanup_errors,
        receipt_errors=receipt_errors, direct_child_unreaped=bool(active and not active['wait_observed']))
    try:
        assert I is not None
        cleanup['recorded_identities_still_present'] = [r for r in identities.values() if I['same'](r)]
        cleanup['all_recorded_identities_absent'] = not cleanup['recorded_identities_still_present']
        if not cleanup['all_recorded_identities_absent']:
            rc = 1
    except BaseException as error:
        cleanup['errors'].append('identity readback: '+type(error).__name__+': '+str(error));rc = 1
    try:
        write(O/'cleanup.json', cleanup)
    except BaseException as error:
        receipt_errors.append('cleanup receipt: '+type(error).__name__+': '+str(error));rc = 1
    result = dict(utc=utc(), result='PASS_SOURCE_COLLECTION_WITH_GAPS' if rc==0 else 'SOURCE_COLLECTION_INCOMPLETE',
        runtime_control_source=B['COMMIT'] if B is not None else None, stages=rows,
        execution_error=execution_error, interrupted_signals=interrupted_signals,
        cleanup_errors=cleanup_errors, receipt_errors=receipt_errors,
        publication_bundle_complete=False, independent_SYSTEM_relation_established=False,
        scope='Five immutable Koko editing-source blobs verified by Git blob SHA1 and exact size with separate flat SHA256; four bounded technical listings. Archive-member review remains pending. No extraction, source or target execution, regeneration, independent SYSTEM, legal or publication clearance; prior producer dispositions unchanged.')
    try:
        write(O/'result.json', result)
    except BaseException as error:
        rc = 1
        print(json.dumps(dict(result=result, receipt_error=type(error).__name__+': '+str(error))), flush=True)
    with (O/'inner.rc').open('x') as f:
        f.write(str(rc)+'\n')
sys.exit(rc)

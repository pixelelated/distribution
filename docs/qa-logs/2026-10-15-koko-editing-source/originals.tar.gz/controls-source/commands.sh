#!/bin/bash
# UNRUN. Root allocates this finite synthetic control operation separately.
set -euo pipefail
set -C
umask 077
TASK_PACKET=/tmp/pix-m7-koko-root-controls-20261015
TASK_RESULT=${TASK_RESULT:-/tmp/pix-m7-koko-root-controls-observation-20261015-01}
: "${TASK_PYTHON_PATH:?root-resolved host Python executable}"
mkdir -m 700 -- "$TASK_RESULT"
set +e
prlimit --as=268435456 --fsize=1048576 --cpu=20 -- timeout --signal=TERM --kill-after=2s 25s "$TASK_PYTHON_PATH" -I -S -B "$TASK_PACKET/controls.py" --output "$TASK_RESULT/result.json" > "$TASK_RESULT/stdout" 2> "$TASK_RESULT/stderr"
task_rc=$?
set -e
printf '%s\n' "$task_rc" > "$TASK_RESULT/original-command.rc"
exit "$task_rc"

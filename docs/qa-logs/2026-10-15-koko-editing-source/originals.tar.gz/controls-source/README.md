# Ten Koko guard controls — source-only, unrun

This small fixture binds immutable source packet `d64f5872157344dc62784e3ab309bb28f448bc9898cbe49aff936b3c9263ce0f`. It does not modify that packet. No test, collector, preparer, consumer, downloader, archive tool or lifecycle was run while preparing these files.

The fixture reads only seven named source/metadata files, verifies their exact hashes, and AST-extracts the actual `account`, `write`, `identity`, `budget`, `reserve`, `release` and `object_identity` definitions. It also extracts the exact HTTP tuple assertion from `fetch` and the exact five-request/four-list assertion from the collector's main block, placing those unchanged assertion nodes in tiny callable wrappers. It never imports the candidate module, executes its module-level setup or entrypoint, or compiles the fetch/child/list functions. Network calls, subprocess creation and archive-tool invocation are absent from the extracted module.

The ten cases are:

1. A tiny synthetic7z-signature blob passes with independently fixed Git blob SHA1 and distinct flat SHA256 expectations.
2. Same-size changed content refuses the expected Git blob.
3. Wrong expected size refuses before content acceptance.
4. Invalid magic with a deliberately matching Git hash isolates the format guard.
5. The exact HTTP200/effective-URL/empty-redirect tuple passes.
6. A redirect response, a nonempty redirect on HTTP200, and a changed effective URL each refuse the exact source assertion.
7. The real four-output largest-request reservation reaches the normal ceiling exactly; one byte over refuses without changing accounting or appending a reservation.
8. Release rejects an over-cap member, then accounts the exact unused bytes once and refuses a duplicate release.
9. The1MiB failure receipt leaves the required7MiB margin; one byte beyond either bound refuses. Existing output paths/bytes remain unchanged when reserve/write refuse them.
10. The exact source count guard accepts five requests/four lists and rejects three or five lists.

Only three tiny fake data files are written; they are not real archives and no archive decoder is used. Private scratch is below1KiB and removed even on a case failure. Expected fixture identities are stored independently in `bindings.json`; the tested function does not supply its own expected result. Bound source text reads are below5MiB and actually much smaller. The result is below64KiB. The shell retains both raw streams with1MiB per-file RLIMIT and the original command exit, so all new data stays below5MiB. Host Python needs ordinary interpreter memory: address space is bounded to256MiB, CPU to20seconds, wall time to25seconds plus2seconds forced-stop allowance; this is not a5MiB process-memory claim.

The accepted supervisor's unchanged helper functions and exact process-identity bytes are bound by reference through the source packet. This fixture does not replay lifecycle/process/signal behavior or claim to qualify the later network run.

## Root execution, when separately allocated

From the frozen control checkout, with `TASK_PYTHON_PATH` already resolved by root:

```bash
tools/watch-build --record-only -- bash /tmp/pix-m7-koko-root-controls-20261015/commands.sh
```

The default fresh output directory is `/tmp/pix-m7-koko-root-controls-observation-20261015-01`; `TASK_RESULT` may select another fresh root-owned result path. `mkdir` and noclobber output refuse reuse. `TASK_PYTHON_PATH` is required; no HOME override is used. Read `original-command.rc`, `stdout`, `stderr` and `result.json`, together with the watch originals. Success requires original exit0, exactly ten actual PASS cases, removed scratch and the exact source seal. A timeout/failed/unknown result remains its original failure; do not fabricate a PASS or overwrite outputs. This source packet has no runtime result yet.

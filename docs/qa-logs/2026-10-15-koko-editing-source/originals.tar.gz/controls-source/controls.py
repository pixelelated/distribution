#!/usr/bin/env python3
"""Ten tiny offline controls; extract only named pure/data-reading guards by AST."""
import argparse,ast,copy,datetime,hashlib,json,stat,tempfile,time
from pathlib import Path
P=Path(__file__).resolve().parent
NAMES=['account','write','identity','budget','reserve','release','object_identity']

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    out=args.output;assert out.is_absolute() and out.parent.resolve(strict=True)==out.parent
    assert P not in out.parents, 'never write into the sealed control packet'
    assert not out.exists() and not out.is_symlink(),'fresh result required'
    b=json.loads((P/'bindings.json').read_text());started=time.monotonic();read_bytes=0
    # Named source-text reads only. No candidate module import or module-level code.
    raw={}
    for name,ref in b['files'].items():
        p=Path(ref['path']);assert p.resolve(strict=True)==p and not p.is_symlink()
        data=p.read_bytes();read_bytes+=len(data)
        assert len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256']
        raw[name]=data
    assert hashlib.sha256(raw['SHA256SUMS']).hexdigest()==b['source_seal']
    tree=ast.parse(raw['templates/collect.py'],filename='bound-collector.py')
    fns=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in NAMES]
    assert sorted(n.name for n in fns)==sorted(NAMES)
    fetch=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fetch')
    http=[n for n in fetch.body if isinstance(n,ast.Assert) and isinstance(n.msg,ast.Constant) and n.msg.value=='HTTP status/effective URL/redirect differs']
    assert len(http)==1
    top_try=next(n for n in tree.body if isinstance(n,ast.Try))
    counts=[n for n in top_try.body if isinstance(n,ast.Assert) and ast.unparse(n.test)=='len(requests) == 5 and len(listings) == 4']
    assert len(counts)==1
    def wrapper(name,parameters,node):
        return ast.FunctionDef(name=name,args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=x,annotation=None,type_comment=None) for x in parameters],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]),body=[copy.deepcopy(node)],decorator_list=[],returns=None,type_comment=None)
    module=ast.Module(body=copy.deepcopy(fns)+[wrapper('http_guard',['fields','url'],http[0]),wrapper('count_guard',['requests','listings'],counts[0])],type_ignores=[])
    ast.fix_missing_locations(module)
    ns=dict(Path=Path,stat=stat,hashlib=hashlib,json=json,time=time)
    # Only selected actual function definitions and exact two actual Assert nodes execute.
    exec(compile(module,'AST-extracted-exact-Koko-guards','exec'),ns)
    limits=json.loads(raw['resources.json']);policy=json.loads(raw['collection-plan.json'])['owner_output_enforcement']
    ns.update(LIMITS=limits,POLICY=policy,START=time.monotonic(),READ=0,OUTPUT=0,reservations=[])
    results=[];peak_scratch_bytes=0
    def case(name,fn):
        before=time.monotonic()
        try:
            fn();results.append(dict(name=name,result='PASS',seconds=time.monotonic()-before))
        except BaseException as e:
            results.append(dict(name=name,result='FAIL',error=type(e).__name__+': '+str(e)[:1024],seconds=time.monotonic()-before))
    def refuses(fn,message=None):
        try:fn()
        except AssertionError as error:
            if message is not None:assert str(error)==message
        else:raise AssertionError('expected actual guard refusal')
    with tempfile.TemporaryDirectory(prefix='koko-controls-',dir=out.parent) as directory:
        scratch=Path(directory).resolve();fx=b['fixtures'];good=bytes.fromhex(fx['good_hex']);bad=bytes.fromhex(fx['bad_magic_hex'])
        valid=scratch/'valid.data';valid.write_bytes(good)
        changed=scratch/'changed.data';changed.write_bytes(good[:-1]+b'!')
        wrong_magic=scratch/'magic.data';wrong_magic.write_bytes(bad)
        selection=dict(expected_bytes=fx['good_bytes'],expected_git_blob_sha1=fx['good_git_blob_sha1'],format='7z')
        def valid_blob():
            r=ns['object_identity'](selection,valid)
            assert r['actual_git_blob_sha1']==fx['good_git_blob_sha1'] and r['body']['sha256']==fx['good_flat_sha256']
            assert r['git_hash_includes_blob_header'] is True and r['flat_sha256_includes_git_header'] is False
            assert r['publication_clearance'] is False
        case('01_valid_blob_separate_flat_identity',valid_blob)
        case('02_same_size_changed_blob_refused',lambda:refuses(lambda:ns['object_identity'](selection,changed),'Git blob identity mismatch'))
        case('03_changed_size_refused',lambda:refuses(lambda:ns['object_identity'](dict(selection,expected_bytes=fx['good_bytes']+1),valid),'exact body length mismatch'))
        case('04_changed_magic_with_matching_git_refused',lambda:refuses(lambda:ns['object_identity'](dict(selection,expected_git_blob_sha1=fx['bad_magic_git_blob_sha1']),wrong_magic),'format signature mismatch'))
        url='https://api.github.com/repos/kokoko3k/koko-aio-slang-misc/git/blobs/'+fx['good_git_blob_sha1']
        case('05_exact_http_tuple_accepted',lambda:ns['http_guard'](['200',url,''],url))
        def http_refusals():
            for fields in [['302',url,'https://example.invalid/elsewhere'],['200',url,'https://example.invalid/elsewhere'],['200',url+'/changed','']]:
                refuses(lambda fields=fields:ns['http_guard'](fields,url),'HTTP status/effective URL/redirect differs')
        case('06_redirect_status_and_effective_url_refused',http_refusals)
        paths=[scratch/('reserved-'+str(i)) for i in range(4)]
        cap=22816420;total=4*cap;normal=policy['normal_collector_write_ceiling_bytes']
        def boundary():
            ns.update(OUTPUT=normal-total,reservations=[])
            r=ns['reserve']('full-four-output-capacity',paths,cap)
            assert ns['OUTPUT']==normal and r['reserved_bytes']==91265680 and r['per_file_limit']==cap
            ns.update(OUTPUT=normal-total+1,reservations=[])
            before=ns['OUTPUT'];refuses(lambda:ns['reserve']('one-byte-over',paths,cap),'owner-output reservation refused before write')
            assert ns['OUTPUT']==before and ns['reservations']==[]
        case('07_four_output_reservation_exact_and_one_over',boundary)
        def release_bounds():
            ns.update(OUTPUT=100,reservations=[])
            r=ns['reserve']('release',paths,cap);before=ns['OUTPUT']
            records=[dict(path=str(p),bytes=v) for p,v in zip(paths,[17,23,31,7])]
            invalid=copy.deepcopy(records);invalid[0]['bytes']=cap+1
            refuses(lambda:ns['release'](r,invalid));assert ns['OUTPUT']==before and r['original_wait_observed']is False
            ns['release'](r,records)
            assert ns['OUTPUT']==178 and r['actual_bytes']==78 and r['released_bytes']==total-78 and r['original_wait_observed']is True
            refuses(lambda:ns['release'](r,records));assert ns['OUTPUT']==178
        case('08_release_actual_bytes_overcap_and_duplicate',release_bounds)
        def failure_and_overwrite():
            ns.update(OUTPUT=normal,reservations=[])
            ns['account'](policy['failure_receipt_budget_bytes'],failure=True)
            assert ns['OUTPUT']==policy['owner_ceiling_bytes']-policy['supervisor_receipt_margin_bytes']
            before=ns['OUTPUT'];refuses(lambda:ns['account'](1,failure=True),'owner-output reservation refused before write');assert ns['OUTPUT']==before
            ns['OUTPUT']=normal
            refuses(lambda:ns['account'](policy['failure_receipt_budget_bytes']+1,failure=True));assert ns['OUTPUT']==normal
            old=valid.read_bytes();before=ns['OUTPUT']
            refuses(lambda:ns['reserve']('old-path',[valid],cap));assert ns['OUTPUT']==before and valid.read_bytes()==old
            refuses(lambda:ns['write'](valid,dict(unwanted=True)),'refuse output overwrite');assert ns['OUTPUT']==before and valid.read_bytes()==old
        case('09_failure_margin_and_existing_output_preserved',failure_and_overwrite)
        def four_lists():
            ns['count_guard']([None]*5,[None]*4)
            for n in [3,5]:refuses(lambda n=n:ns['count_guard']([None]*5,[None]*n))
        case('10_exact_four_list_count',four_lists)
        peak_scratch_bytes=sum(p.stat().st_size for p in scratch.iterdir() if p.is_file())
        assert peak_scratch_bytes<1024
    assert not scratch.exists(),'private synthetic scratch remains'
    assert len(results)==10 and time.monotonic()-started<25 and read_bytes<5*1024**2
    ok=all(r['result']=='PASS' for r in results)
    report=dict(result='PASS' if ok else 'FAIL',source_packet_seal=b['source_seal'],case_count=10,cases=results,source_text_bytes_read=read_bytes,
        peak_synthetic_scratch_bytes=peak_scratch_bytes,scratch_removed=True,elapsed_seconds=time.monotonic()-started,
        extracted_functions=NAMES,http_assert_ast_sha256=hashlib.sha256(ast.dump(http[0],include_attributes=False).encode()).hexdigest(),
        count_assert_ast_sha256=hashlib.sha256(ast.dump(counts[0],include_attributes=False).encode()).hexdigest(),
        candidate_module_imported=False,candidate_module_main_executed=False,lifecycle_replayed=False,
        network_used=False,archive_tools_executed=False,archive_payloads_read=False,source_cache_access=False)
    raw_report=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode();assert len(raw_report)<65536
    with out.open('xb') as stream:stream.write(raw_report)
    print(json.dumps(dict(result=report['result'],cases=10,seconds=report['elapsed_seconds'],scratch_removed=True)))
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())

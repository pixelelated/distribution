#!/usr/bin/env python3
"""Read completed compact evidence only; write this review packet, never run a payload."""
import hashlib,json,pathlib,tarfile,subprocess,datetime
P=pathlib.Path(__file__).resolve().parent
Q=pathlib.Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs')
C=Q.parent.parent
E=pathlib.Path('/workspace/tmp/pix-m7-native-states-evidence-20261015-02')
R=pathlib.Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T044138Z-77958d6d')
(P/'originals').mkdir(exist_ok=True)
rows=[]; verification=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def keep(rel,b,source):
 dst=P/'originals'/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 assert not dst.exists()
 dst.write_bytes(b);rows.append({'copy':'originals/'+rel,'source':source,'bytes':len(b),'sha256':sha(b)})
def file(rel,src):keep(rel,src.read_bytes(),str(src))
def archive(src,manifest,extracts):
 data=json.loads(manifest.read_text());ms=data['members'] if isinstance(data,dict) else data
 expected={(r.get('member') or r['path']):r for r in ms}
 with tarfile.open(src) as t:
  actual={m.name:m for m in t.getmembers() if m.isfile()}
  assert set(expected)==set(actual),(str(src),set(expected)^set(actual))
  for n,m in actual.items():
   b=t.extractfile(m).read();r=expected[n];assert len(b)==r['bytes'] and sha(b)==r['sha256'],n
   if n in extracts:keep(extracts[n],b,str(src)+'::'+n)
 verification.append({'archive':str(src),'sha256':sha(src.read_bytes()),'manifest':str(manifest),'manifest_sha256':sha(manifest.read_bytes()),'members_rehashed':len(actual),'exact_member_set':True,'bytes_and_hashes_equal':True})
for n in ['config.json','root-review.json','export-result.json','vm-result.json','consumption.json','host-exits.json']:
 file('native02/'+n,E/n)
file('native02/admission-consumed.json',R/'admission-consumed.json')
for n in ['installed-inputs.json','finish.json','profile-readback-216776cbfceb49c294b50da4673ff97f.json','profile-readback-e84cad0a7697413091ad3b35d702dc68.json','state-readback-03b5fad7dedc450789768f5e37b79d31.json','state-readback-06ecfc7c14b146caa4b6851de55fbf11.json','state-readback-bc7435ffd1ff468c9557512abb684a4e.json','state-readback-641c246991ff402bbc0091d54b2a1b2a.json','state-readback-5dde22d44e424714928e265f343962da.json','state-readback-38c0f43b43bb4f819fae68612a3d2e10.json','state-readback-92d9f68d45e34fdd82995b3c4e1f406e.json']:
 source=E/'guest/gameplay'/n;b=source.read_bytes();r=next(x for x in json.loads((E/'guest-manifest.json').read_text()) if x['path']=='gameplay/'+n)
 assert sha(b)==r['sha256'] and len(b)==r['bytes'];keep('native02/guest/'+n,b,str(source))
archive(E/'original-records.tar.gz',E/'original-records.json',{'owner/records/final-image-result.json':'final-image-result.json','owner/records/final-image-inputs.json':'final-image-inputs.json','owner/records/source-continuity.json':'source-continuity.json','owner/frames/dc-auto-cold-first-interactive-review.json':'native02/cold-first-review.json'})
D=Q/'2026-10-15-engineering-image-result/dolphin-installed'
for n in ['case-result.json','admission-consumed.json','coordinator-review.json']:
 file('installed-dolphin/'+n,D/n)
archive(D/'original-records.tar.gz',D/'original-records.json',{f'export/guest/native-owner/case/{case}/stderr':f'installed-dolphin/{case}.stderr' for case in ['installed-enabled','installed-disabled','installed-failed-boot']})
G=Q/'2026-10-15-native-gameplay-result'
for n in ['acceptance.json','coordinator-native03-review.json','admission-consumed.json']:
 file('ordinary-save/'+n,G/n)
archive(G/'supplemental-readback.tar.gz',G/'supplemental-readback.tar.gz.members.json',{n:'ordinary-save/'+n for n in ['inspection-result.json','wii-save-interpretation.json','vmu-interpretation.json','wii-extraction.json','source-bindings.json']})
for scope in ['clean','retained']:
 for n in ['review.json','admission-consumed.json','config.json']:
  file('final-'+scope+'/'+n,Q/'2026-10-15-final-engineering-result'/scope/n)
B=Q/'2026-10-15-qualification-followups/baseline02'
with tarfile.open(B/'original-records.tar.gz') as t:
 for m in t.getmembers():
  if m.name.endswith('/exit.log') or m.name.endswith('/report.md'):
   b=t.extractfile(m).read();r=next(x for x in json.loads((B/'original-records.json').read_text()) if x['path']==m.name);assert sha(b)==r['sha256'];keep('retroarch/'+pathlib.Path(m.name).name,b,str(B/'original-records.tar.gz')+'::'+m.name)
file('retroarch/scripts.log',Q/'2026-10-15-baseline-continuation/webdav/scripts.log')
# Exact frozen source delta: no installed engine/library or ordinary-save-path change.
for name,args in [
 ('d4af-to-f863-native-source.diff',['diff','d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a','f8636de1d105275dbf9420bbabbbc26f79abb10f','--','projects/ROCKNIX/packages/emulators/standalone/dolphin-sa','projects/ROCKNIX/packages/emulators/standalone/flycast-sa']),
 ('d6a-to-f863-proxy-source.diff',['diff','d6a87f05','f8636de1d105275dbf9420bbabbbc26f79abb10f','--','projects/ROCKNIX/packages/network/raofflineproxy']),
 ('fac-to-f863-retroarch-source.diff',['diff','fac608ff8994','f8636de1d105275dbf9420bbabbbc26f79abb10f','--','projects/ROCKNIX/packages/emulators/libretro/retroarch','projects/ROCKNIX/packages/rocknix/sources/scripts/runemu.sh','projects/ROCKNIX/packages/emulators/libretro/retroarch/scripts/setsettings.sh'])]:
 r=subprocess.run(['git','-C',str(C),*args],capture_output=True,check=True);assert not r.stderr;keep(name,r.stdout,'read-only git '+' '.join(args))
frames=[]
for f in sorted((P/'review-frames').glob('*.png')):
 frames.append({'path':str(f.relative_to(P)),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size,'review':'Independent view_image readback; original pixels unchanged'})
(P/'evidence-readback.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'read-only original evidence and source comparison; no test/payload/runtime replay','copies':rows,'archive_verification':verification,'frames_viewed':frames,'limits':['No full guest payload/media/disk/cache read or hash','Previous accepted results retain their original source/date/scope','No production registry, GitHub, shared document, stage or commit mutation']},indent=2)+'\n')
print(json.dumps({'copied_originals':len(rows),'archive_checks':verification,'viewed_frames':len(frames)},indent=2))

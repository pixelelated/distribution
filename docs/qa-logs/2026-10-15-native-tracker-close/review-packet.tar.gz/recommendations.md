# Tracker reconciliation — read-only recommendation, 2026-10-15

Recommend **close #574, #575 and #584 as completed**, and **keep #583 closed**. There is no additional runtime/test requirement identified for these scoped issues. Root owns final tracker/shared-document actions. This packet made none.

## One concrete documentation action

`docs/es-menu-map.md`, “Offline achievements → Dolphin routing (#584)”, still says final installed-image smoke and normal gameplay/save proof remain open. Replace the paragraph beginning “The [NoGUI lifecycle repair]” with `proposed-menu-map-paragraph.md`, then publish the corresponding bodies/comments. This closes the documentation criterion; do not re-run any accepted test to remove stale wording. The save-state guidance section is already updated by root. #590/#596 are outside this assignment.

## Why the criteria now resolve

- #574: exact source/installed standalone support, independent RVZ/frontend/MD5 and proxy hash evidence, controlled defect regressions and explicit unmatched/unsupported/absent-set distinctions. The only old independent-Dolphin remainder is now covered by installed startup and identical final executable, without claiming a real award.
- #575: actual selected Wii/Dreamcast runtime/settings, separately accepted ordinary saves, completed manual-state and Flycast automatic/cold-load observations, accepted RetroArch native history plus current baseline section-v and exit originals, reviewed EN/FR/both-size capability help and final clean/retained preservation. Criterion4 uses the explicit limitation route; no new standalone manager/automatic integration was proposed. The original Nova selection remains unknown and is not inferred from system name.
- #583: was already closed when read. Its five criteria remain complete; only the historical downstream #584 status could receive a dated clarification. No title/state change or repeated proxy test.
- #584:126 routing controls plus installed proxy lifecycle and actual Dolphin HostUrl/startup proof; identical final engine, six Sys resources and separate final installed session controls. The original real-account/offline-award boundary remains explicit.

## Independent evidence readback

`evidence-readback.json` records48 exact compact originals and their original paths/hashes,1363 native02 archive members rehashed against the exact manifest,188 installed-Dolphin members rehashed and45 ordinary-save supplement members rehashed. Thirteen exact native02 PNGs were viewed; manual restored frames are beyond the decompression overlay, and automatic scene C/cold-first frame bytes are equal. Native02 receipt `d739030019bc445bae908b3ca6dd6b48` is consumed, original command/monitor/runner0. The copied `root-review.json` is coordinator evidence, distinct from this readback.

Final installed Dolphin SHA `5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5` matches the accepted installed-startup binary. Final SYSTEM is `2c69f6533629244edef4ec2405bfaaf438f507451733ae955be7eefe7ffeb1cf`. Final artifact original is PASS for109 products, sourcef863/ES16dbac, explicitly `runtime_qualified:false`; booted runs supply their own runtime claims. Clean/retained seals from earlier independent retention are `9234c8c78494c2d036f493102528adf33b87da07e1b53f5f51843586b66530f0` and `7a8a8ed041c200b94096605600a6dddc77652a59caa772367e9a7a828509330f`.

Source continuity was read, not executed: d6a→f863 proxy source diff is empty; fac608→f863 RetroArch/runemu source diff is empty. d4af→f863 Dolphin/Flycast diff is only Dolphin session publication/launcher status handling; ordinary save-path helper, engine recipe/lifecycle patch and Flycast are unchanged. Final installed source mappings and the native guest bind the emitted bytes; no whole-image/cache hash was repeated.

## Limits retained

- No owner ROM/account mutation, physical handheld, real-provider award, commercial-disc corpus, GC card/NAND extension or abrupt-power proof. These are not silently added as closure gates.
- Native03 ordinary-save acceptance keeps its failed export wrapper1 and partial state results. Native-state01 fails before game; native02 supplies separate state results. Historical source-era UNRUN fields remain historical.
- #597's observed launcher-report failure and unknown original launcher wait stay distinct from original build runner0 and later successful readback/VM channels. No recovered launcher success is invented.
- Native ES/systemd-owned emulator wait statuses remain unknown where no original waiter existed; normal UI return/process absence are evidence, not invented exit codes. The installed three-case startup tool did own and retain its original native0/0/1.
- Flycast exit4 legitimately rewrites its automatic state after the accepted pre-input cold-restore comparison. Its final file is not falsely required to equal launch3's state.
- Existing accepted baseline/RetroArch rows retain their original fac608/history source scope. This review is not a new full-suite result on f863.
- `proposed-583-body.md` is optional additive status clarification; its dated history remains verbatim. The recommended minimum is no body/state mutation for that already-closed issue, optionally the short follow-up comment.

## Deliverables and application

`proposed-N-body.md` and `proposed-N-comment.md` are concrete reviewable GitHub text. They use the coordinator feature branch for current evidence links; root should publish the referenced native02/canonical records first or replace those links with the chosen published commit. Bodies preserve the owner quotes exactly and each current acceptance-criterion sentence exactly, marking the now-supported criteria complete. `criteria.json` maps the captured states and actions. `issues/` preserves exact current bodies and all comments from the read-only GitHub capture; an initial connection failure is retained separately.

No GitHub mutation command was run. No preparer, test payload, compiler, VM, service, admission or registry operation was run. No shared files, source code, git index or commits were changed. The only executable local operations were data-only archive/JSON/hash reads and packet writing under this assigned temporary directory.

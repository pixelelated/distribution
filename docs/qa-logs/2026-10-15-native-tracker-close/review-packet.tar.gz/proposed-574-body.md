## Completed scope — October 15

The confirmed frontend RVZ recognition defect is repaired and qualified. The independent proxy and Dolphin startup gaps are also dispositioned through #583 and #584. This does not assert that every game/variant has a RetroAchievements set or that the reported owner's account/game was authenticated.

Final composition is distribution `f8636de1d105275dbf9420bbabbbc26f79abb10f` / ES `16dbac5211eea7e70db7394372033be2be7df829`. [final engineering artifacts and clean/retained qualification](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-15-final-engineering-result/README.md) binds the actual assembled products and the clean/retained runs. The build's #597 launcher-report collision remains a reporting failure with unknown original launcher wait status; successful artifact/VM results do not rewrite it.

## Owner report — October 13

> I'm curious how that metadata could have gotten there. Thanks for exploring this. The other item that I want to track that's come up is that no RetroAchievements are showing up for GameCube. Maybe that's by design or just the state of the union is now, but I did think that Dolphin supported GameCube RetroAchievements. It's again something to look into.

## Delivered behavior and evidence

- The original read-only installation had nine RVZ entries with failed hash sentinels/no achievement ID and matching extraction errors. The ES wrapper lacked an RVZ reader. Exact source, repaired MD5, bounded reader and independent Dolphin NONE/Zstandard format results are recorded in [independent RVZ format proof](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-independent-format-runtime/README.md); malformed/unsupported inputs remain explicit failures. No owner ROM conversion is required.
- ES/offline recognition is separate from the emulator. [126-case routing and RVZ/scanner controls](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-rvz-proxy-components/README.md) records proxy padding/scanner controls; [native proxy protocol proof](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-proxy-native-runtime/README.md) records hash/cache/account/error/signed-queue/reconnect behavior with synthetic data. [installed native hash proof](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-installed-native-result/README.md) closes the earlier native-library provenance limit: installed Python/native ISO/NONE/Zstandard RVZ return the same GameCube hash `118545082f24fc195a446d1ee7bbf816`. [installed proxy startup/reconnect proof](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-proxy-installed-startup-result/README.md) supplies the installed service lifecycle/reconnect proof. #583 remains completed.
- The actual standalone Dolphin package enables RA, while libretro compatibility remains separate. The default NoGUI process originally omitted AchievementManager initialization/shutdown. [installed Dolphin startup originals](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-15-engineering-image-result/dolphin-installed/README.md) verifies the repaired shipped executable: enabled initialization/request/shutdown, disabled no-request, and failed-boot cleanup. The final f863 artifact and native02 guest retain exact executable SHA256 `5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5` and six pinned Sys resources. #584 records the guarded HostUrl contract; configuration alone is not treated as a successful login.
- [canonical flow and support guidance](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/es-menu-map.md) records unchanged recognition/game-launch navigation and the distinct configuration/runtime scopes. An absent set, a valid unmatched hash, an unreadable/unsupported ROM and unsupported emulator runtime are not interchangeable diagnoses. The original owner's nine files/account were not replayed; their successful matching or awards are not asserted.

Already written: existing gamelists can contain the all-zero failed-RVZ hash sentinel. The explicit scanner can retry that exact failure; it preserves valid unmatched hashes, unrelated indexed roots, exclusions and existing automatic policy. The fix does not erase metadata, convert owner ROMs or mutate credentials/saves. Final retained upgrade preserves the selected existing state.

Can this be done on the VM? Yes. Accepted proofs used synthetic format/account/cache fixtures and the actual installed executables in disposable guests; no physical fact or owner-account action is required for these criteria.

## Acceptance criteria

- [x] Record source and installed-artifact evidence for standalone/core selection, RA compile support, launch configuration and relevant runtime gates without credentials.
- [x] Trace GameCube recognition through ES/offline indexing separately from Dolphin in-game support, including the reported format and a supported test fixture.
- [x] Reproduce any confirmed defect in a disposable VM; repair it with source-bound regression evidence, or document a verified upstream/format limitation with accurate player guidance.
- [x] Record the disposition and any necessary flow/screenshot documentation; distinguish absent sets, unmatched ROMs and unsupported runtime instead of silently presenting them as equivalent.

## Limits and preserved history

The original sanitizer, format-container and helper-fixture failures remain failed in their packets; subsequent corrected runs have distinct originals. Synthetic loopback login deliberately fails authentication. Native Wii/Dreamcast gameplay and saves are separate accepted evidence, not GameCube achievement-award proof. No real-provider award, commercial-disc corpus, handheld or universal-format claim is made. Upstream contribution destinations remain under #585/D-WORKFLOW-165 and do not require replaying accepted tests.

The October 14/early October 15 comments saying installed Dolphin startup was uncompiled/unverified describe their original phase. The evidence above supersedes that outstanding work, without changing those original records. Close as completed after the #584 canonical-flow status paragraph is updated.

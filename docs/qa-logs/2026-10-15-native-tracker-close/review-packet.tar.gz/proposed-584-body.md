## Completed scope — October 15

The launcher now routes enabled, non-hardcore Dolphin sessions to the available local offline service, and the shipped NoGUI process initializes/shuts down achievements. Installed service, native HostUrl interpretation and final composition are verified separately. This is not a claim of a successful real-account Dolphin award.

Final composition is distribution `f8636de1d105275dbf9420bbabbbc26f79abb10f` / ES `16dbac5211eea7e70db7394372033be2be7df829`. [final engineering artifacts and clean/retained qualification](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-15-final-engineering-result/README.md) binds the actual assembled products and the clean/retained runs. The build's #597 launcher-report collision remains a reporting failure with unknown original launcher wait status; successful artifact/VM results do not rewrite it.

## Owner context — October 14

> With the RVZ files, there's something we also need to adapt in RA offline proxy. We should look at that.

## Source contract and delivered proof

The old helper read only customhost, while packaged `run-service` bypassed upstream's emulator configuration patcher. The correction preserves customhost unless the saved proxy toggle is exactly1, raw hardcore exactly0 and a read-only IPv4-capable listener predicate succeeds. It never changes saved credentials/customhost/hardcore. Listener presence is a routing predicate, not proof of listener identity or readiness.

[126-case routing and RVZ/scanner controls](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-rvz-proxy-components/README.md) records126 full-script controls for toggle/hardcore/customhost/listener/missing-account/disabled cases and unchanged input settings. Upstream ROCKNIX PR3038 and proxy PR50 were compared; the distro service/toggle contract is the distinct gap. Contribution disposition remains under #585.

[native proxy protocol proof](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-proxy-native-runtime/README.md) verifies synthetic hashing, cache/account separation, signed offline queue, errors and reconnect; [installed native hash proof](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-installed-native-result/README.md) binds current shipped native hash inputs; [installed proxy startup/reconnect proof](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-14-proxy-installed-startup-result/README.md) verifies actual installed service startup/stop/reconnect/queue preservation and worker shutdown. Their original scope limits remain, including the earlier old-image native provenance limit subsequently supplied by the installed result.

The independent NoGUI defect and repair have actual installed process evidence in [installed Dolphin startup originals](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-15-engineering-image-result/dolphin-installed/README.md): enabled live CPU/init1/request1/shutdown1; disabled live CPU/init0/request0; absent boot file original native exit1 with init/shutdown1. The request is a synthetic invalid-login POST to `127.0.0.1:8080/dorequest.php`. No private executable substitution was used in the installed proof. The final f863 artifact and native02 guest carry the identical shipped binary `5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5`, pinned six-resource Sys mapping and unchanged engine lifecycle patch. All four prior badge-load errors were absent.

Final clean/retained tests run the installed helper and exact launcher block for four enabled/disabled/logged-out transitions, using an explicit engine marker. They prove session publication/refusal and preservation, not a live emulator login. The separately accepted native03 ordinary saves and native02 manual/automatic states use actual engines with achievements off; they do not stand in for RA routing. [canonical flow and support guidance](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/es-menu-map.md) names these independent flows and limits.

Already written: an earlier active generated Dolphin INI could survive disabled/missing-account launches. #594 now atomically publishes an inactive session and clears generated credentials, preserving saved global account settings; publication failure refuses launch instead of reusing old active settings. Final installed clean/retained controls and EN/FR refusal/return frames are accepted independently. Existing save-path protection remains intact.

Can this be done on the VM? Yes. Full-script controls, installed service and emulator lifecycle use synthetic settings/loopback fixtures in disposable no-NIC guests. No owner account/provider action or physical gameplay is required for this integration scope.

## Acceptance criteria

- [x] Exact source/current-upstream comparison and raw-setting/listener contract are recorded, including explicit contribution disposition.
- [x] A minimal launcher change routes only the enabled, non-hardcore, verified-listener case and preserves fallback customhost behavior.
- [x] Synthetic VM full-script controls cover toggle0/1, hardcore0/1/empty/unknown, customhost empty/nonempty, IPv4/mapped IPv6/IPv6-only/unreadable tables, missing token and disabled achievements; receipt verifies generated INI and unchanged input settings.
- [x] Installed dependency/service and Dolphin host interpretation are verified; distinguish configuration proof from full offline login/cache/award/reconnect behavior.
- [x] Canonical flow/limitations and combined #574/#583 qualification reflect the tested behavior before the next candidate.

## Limits and historical results

The routing fixture's original missing `/proc/.../children` failure, original installed NoGUI defect and later unrelated fixture failures remain preserved. The expected failed-boot native exit1 remains1. Earlier comments describing the repair as uncompiled or installed proof pending are superseded by the accepted installed run and final image binding. No production authentication/award, generic libretro support, sudden-power safety or handheld result is inferred. Close as completed after publishing the canonical-flow status correction alongside this body and #574's combined disposition.

## Owner report — October 13

> I'm curious how that metadata could have gotten there. Thanks for exploring this. The other item that I want to track that's come up is that no RetroAchievements are showing up for GameCube. Maybe that's by design or just the state of the union is now, but I did think that Dolphin supported GameCube RetroAchievements. It's again something to look into.

## Current understanding

Official Dolphin and RetroAchievements documentation confirms GameCube support in standalone Dolphin; the libretro core is a separate compatibility case. The fork recipe pins Dolphin 2606, enables USE_RETRO_ACHIEVEMENTS, and installs cheevos_dolphin.sh to derive launch configuration from the global account. That source intent is not installed-runtime proof. Establish whether the report concerns ES achievement metadata/offline preparation, in-game achievements, or both. Do not assume all games/ROM variants are recognized.

Sources: https://dolphin-emu.org/blog/2024/07/15/unlocked-retroachievements-come-dolphin/ and https://docs.retroachievements.org/general/emulator-support-and-issues.html and https://docs.retroachievements.org/developer-docs/unsupported-emulators-and-cores.html

Can this be done on the VM? Yes for exact package/runtime configuration, ES system/format hashing and index behavior, synthetic account routing and display gating. Use existing read-only device evidence only for the reported installation; no owner gameplay, award submission or account mutation is implied.

## Acceptance criteria

- [ ] Record source and installed-artifact evidence for standalone/core selection, RA compile support, launch configuration and relevant runtime gates without credentials.
- [ ] Trace GameCube recognition through ES/offline indexing separately from Dolphin in-game support, including the reported format and a supported test fixture.
- [ ] Reproduce any confirmed defect in a disposable VM; repair it with source-bound regression evidence, or document a verified upstream/format limitation with accurate player guidance.
- [ ] Record the disposition and any necessary flow/screenshot documentation; distinguish absent sets, unmatched ROMs and unsupported runtime instead of silently presenting them as equivalent.

Confirmed frontend recognition failure is M7.P5 pre-candidate work, after #571 and before foundation/image qualification. In-game Dolphin behavior remains unverified. Related #565 (separate metadata provenance), #567/#568 (achievement preparation feedback).

## Installed/source diagnosis

Read-only installed evidence:9GameCube RVZ files; all9 gamelist entries have a cheevosHash field but no cheevosId; retained ES logs contain9GameCube "Unable to extract hash" events. No raw filenames or credential values retained in public evidence. Dolphin achievement configuration exists and is enabled, with an account/token present; no live sign-in validation or game launch performed.

Accepted ES c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78 maps NINTENDO_GAMECUBE to RC_CONSOLE_GAMECUBE. Its getCheevosHashFromFile returns the all-zero failure sentinel when generateHashFromFile fails. The wrapper external/libcheevos/cheevos.cpp:156 registers a custom CD reader only; GameCube's hash_disc.c:512 opens the file directly and expects the uncompressed-disc magic at0x1c. No RVZ reader is registered on this path. This is a strong source/runtime match for the missing frontend recognition; it does not prove a failure in standalone Dolphin's in-game achievement support.

Upstream research lead: RetroArch#18316 reports RVZ hashing and current RetroArch has a dedicated cheevos_rvz reader; inspect exact upstream fix/licensing/test coverage before selecting an implementation. https://github.com/libretro/RetroArch/issues/18316 . Source freshness remains required; do not work around this by asking the owner to bulk-convert their library.

Next: synthetic ISO/RVZ equivalence and invalid/truncated controls in the VM, with a bounded reader or an appropriate existing upstream integration; verify frontend/offline indexing and independent Dolphin behavior. Track this confirmed recognition failure within M7 before the next candidate, after current owner-ordered browser/account/copy tasks.

## Related RVZ proxy and upstream work

#583 owns RAOfflineProxy discovery/hash/cache tracing and any minimal adaptation, plus the explicit upstream-contribution rule. Complete that synthetic integration proof alongside the frontend format tests. Keep RVZ reader integration, libretro-common MD5 alignment, and Dolphin distro save-path handling as independently reviewable upstream candidates.


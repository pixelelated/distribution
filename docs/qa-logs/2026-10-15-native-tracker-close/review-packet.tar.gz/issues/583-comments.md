2026-10-14T02:43:46Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6159712467

The instruction is now explicit in local coordinator commit d029982dd30b28711f3cb6cf774fc9d052675d6c: `.claude/rules/engineering-practices.md` requires considering upstream contributions for applicable fixes, comparing current upstream, recording the component/ROCKNIX target, and preparing minimal independent changes with public regression evidence. D-WORKFLOW-164 records the direction; rules-check, register-check, work-log-index and ceremony gate pass. D-RA-016 and D-WORKFLOW-138 already required proxy contributions and are linked explicitly. This local record has not been pushed.

The existing pix-memory lane is tracing the exact proxy RVZ path and preparing a source-bound candidate/test packet. A preliminary padding-offset rounding finding is not yet runtime-verified or attributed to the owner's missing achievements. No proxy runtime/account/award or production pin was changed. Actual frontend+proxy qualification remains open.


2026-10-14T02:59:25Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6159888263

Source review corrections are now in additive packet22cfb2385a, imported locally beside immutable819d: the padding conversion uses a memoryview to avoid an extra full-size bytearray, and a failed RVZ admits only its containing indexed roots to traversal. A synthetic no-walk control covers an unrelated indexed PSX root. These are source corrections, not measured memory savings. The revised first VM probe is UNRUN and the runtime criterion stays open. #584 routing is separately in preparation. No product pin/script promoted.


2026-10-14T03:05:59Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6159963578

Can this be done on the VM? Yes. The next serialized allocation uses a fresh no-NIC GENERIC_X64 guest (standard8GiB/4CPU,640x480),30-minute hard stop, new owner `/workspace/tmp/pix-m7-rvz-vm-20261014`. Revised proxy22cf source probe runs once with its failing baseline controls and512MiB/30CPU/40s bounds. Separately run Steam b09 offline hash/CRC/layout/ELF inspection under768MiB noexec scratch/90s+10s cleanup. MD5 target artifacts are staged read-only but remain held until the exact cleanup-report recovery adapter is accepted. No owner ROMs, credentials, accounts, awards, device/cloud action or native emulator execution. Fresh retention/admission and active watcher supervision required; compact receipts kept, finished disks retired.


2026-10-14T03:39:18Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6160343852

Completed component proof, October14. RAOfflineProxy already supports RVZ; this investigation identified two specific candidates rather than a missing extension allowlist.

In a fresh no-NIC GENERIC_X64 guest, the original padding reader mismatches all126 unaligned comparisons; revised22cf matches all126, with72 aligned and6 malformed controls per version. A synthetic NONE packed-RVZ record matches the format oracle after correction. All44 listing controls pass: only exact zero-hash RVZ failures retry in explicit mode; automatic scans, valid unmatched hashes, unrelated indexed roots and synthetic queue bytes are preserved.

The first probe failed on ElementTree's lazy ASCII codec import under its strict file guard. Its original1 remains; a one-line preload before the hook passes without widening file/network permissions. This is source-component proof, not full ctl/native hashing, installed service, gameplay, account/cache/award/reconnect or the established cause of the owner's Nova symptom. Independent compiled Dolphin parity and native ISO/RVZ hash equivalence remain next; broader acceptance stays open.

Local durable evidence: `docs/qa-logs/2026-10-14-rvz-proxy-components/` and the adjacent immutable source packets. Upstream targets remain RAOfflineProxy for padding, fork distribution integration for the deliberate-scan exception, and separate #584 for Dolphin routing. Current upstream decoder matches our pin; Linux RVZ support#51 is already included. D-WORKFLOW-164 is recorded and checked locally. No product pin/script or upstream posting/push occurred. All ten original owners consumed, guest stopped, admission consumed and2.63GB scratch retired.

2026-10-14T05:46:40Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6161820265

Native integration fixture a7b0ae1429ee85467d2106c483da7a1d00d2c484 is committed and coordinator source-reviewed; runtime remains UNRUN. It binds the current proxy pin+16 patches and corrected reader, native ELF hashes, independent Dolphin encode/roundtrip receipts, scanner/cache/account isolation, signed offline award retention and reconnect. Readiness must identify the owned proxy endpoint and expected cached login/game responses; an unrelated HTTP200 endpoint is a negative control. This fixture does not change the product routing guard or claim full service/emulator qualification.

Can this be done on the VM? Yes for native integration/protocol behavior; use a fresh no-NIC guest after the independent converter inputs exist. Source-only preparation is on the host using the available GNU patch, not a guest package install: original45-second alarm,5-second per-patch limit,10MiB extracted source/32MiB output, exact pinned archive and all source hashes. It imports no proxy, starts no listener and accesses no device/account/cloud data. The source preparer will run once with original watched results; source preparation alone is not native/protocol PASS.


2026-10-14T15:25:15Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6171865857

Independent Dolphin input qualification is now PASS in fresh VM20: five corrected synthetic decodes, independent NONE/Zstd encodes, both whole-data roundtrips and both actual candidate hashes agree with unchanged expected GameCube MD5. Original failed attempt01 remains; attempt02 is exported, consumed and retired. Inputs originate in `2026-10-14-independent-format-runtime/attempt02`, worker generator052b36080f with unchanged d92 driver/oracle/native binaries.

Can this be done on the VM? Yes. Next is the already prepared, immutable `2026-10-14-proxy-native-integration-source` experiment, using the accepted small prepared tree from `/workspace/tmp/pix583-native-prepared-20261014-02`. No re-preparation or native build. Fresh coordinator owner `/workspace/tmp/pix583-native-vm-20261014-01`: accepted no-NIC VM20, only loopback, 8 GiB/4 CPU, synthetic local peer on exclusive127.0.0.1 ports8080/18081. Public inputs <=32 MiB, private64MiB tmpfs; child512MiB AS/120CPU seconds/8MiB file,180s work +10s cleanup, outer200s +5s forced cleanup,900s host alarm. No occupied proxy is stopped. All source/ELF/input hashes and original failures are retained.

The first stage records installed native-library hashes without loading them; the coordinator reviews that concrete admission before releasing the single test child (120-second bounded review window). `source_pins_verified:false` remains: this older accepted image's installed native bytes are not newly built from the current recipe. Expected evidence is exact-byte native ISO/RVZ hash/cache/account separation, real local HTTP readiness, signed awards/dedup/hardcore refusal, SQLite reopen, failed auth/patch/award retention and reconnect flushing. Existing reference suites are not replayed.

This is ProxyRuntimeServer plus explicit cache/flush, with documented dependency-discovery and loopback interface substitutions. It does not qualify full main/systemd/periodic workers, new native-build provenance, physical memory savings, browser-owned stop/restart, provider acceptance or Dolphin gameplay. Those limits remain explicit. Export originals, verify actual owned processes exited, consume admission and retire VM after the run; no owner data/account/cloud action.


2026-10-14T15:30:47Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6171979460

## October14 independent format and native-proxy qualification

Fresh no-NIC VM20 independent oracle PASS: five corrected synthetic RVZ decodes, two independent Dolphin encodes, two complete data roundtrips, two target candidate hashes. Original native commands all0, no timeout/stderr; unchanged GameCube MD5118545082f24fc195a446d1ee7bbf816. The original decode failure is preserved; worker052b36080f corrects only a missing empty-partition SHA1 in the synthetic generator, with explicit rebinding and unchanged raw data/oracle/binaries.

Separate fresh native-proxy fixture PASS,11.46seconds: actual installed native ISO/NONE-RVZ/Zstd-RVZ parity, real scanner handoff, account/cache isolation, identified local listener and false-readiness rejection, signed award dedup/hardcore refusal, SQLite reopen/integrity, failed auth/patch/award preservation, reconnect applies two synthetic awards exactly once. No external network/account/gameplay. Exact installed library hashes and source manifests are retained.

Both successful runs have original child/owner/lifecycle/launcher/runner0 and monitor0, clean descendants/listeners/threads, actual host exits, consumed admissions and removed VM disks (4,647,079,936bytes). Earlier failed Dolphin attempt remainsFAIL1/retired. No owner-device action, product pin, firmware or RC designation.

**Remaining:** older installed native bytes have `source_pins_verified:false`; this is not current-native-build provenance. Full main/systemd/periodic-service lifecycle, production scanner locking, Dolphin gameplay/integration, CHD/native parity, final frontend/UI and assembled-image clean/retained proof remain. Source-only prepared controls were not silently counted as executed. Evidence: local `docs/qa-logs/2026-10-14-independent-format-runtime/` and `2026-10-14-proxy-native-runtime/`; immutable source packets retained. Future browser stop/restart experiment#587 stays outside M7's gates.


2026-10-14T16:31:18Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6173193344

Next bounded proof from immutable57a138: can this be done on the VM? Yes. Allocate fresh no-NIC VM20 with exact112-file prepared Python tree (no re-preparation), old installed ELF identities and synthetic SQLite/account/key; no owner/provider data. Real packaged main/run-service and readiness under a temporary PID1 unit. Original condition, graceful stop, explicit restart, one idle SIGKILL/on-failure restart, natural15s reconnect and two natural60s queue polls with real bulk lock; hourly refresh timer not shortened or claimed exercised.

Fresh owner /workspace/tmp/pix583-service-vm-20261014-01, sole serialized VM. Dedicated64MiB state tmpfs,<=8MiB stagedpublicinputs (actual2073677B),16MiB resultcap. Driver240s+30scleanup, service512MiB/64tasks, systemd owner280s+20s, outer command310s+10s and lifecycle900s. Existing watch-build/admission, actual host/PID1 ownership and independent lifecycle shutdown; collect original command/systemd exits, traces/SQLite/protectedfiles and retire disk. No prior tests replayed. Installed-current-native source provenance remainsfalse and final image/toggle/profile/frontend/Dolphin integration stays separate. No firmware build or #587 policy change.


2026-10-14T16:38:19Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6173328095

Actual copied-unit service attempt01 ended before any systemctl command or proxy startup: prerequisite cgroup v2 required for this bounded packet failed. Original driver/owner/systemd/lifecycle/launcher exits1; no timeout, cleanup intervention or surviving owner. Lossless evidence: docs/qa-logs/2026-10-14-proxy-service-runtime/attempt01. Admission5aa413 consumed; actual host PIDs exited;2,279,911,424B VM/media retired. This is a fixture/image compatibility failure, not evidence of product service failure. Source-only review is checking actual hierarchy and enforced limits before a fresh allocation. Can this be done on the VM? Yes; the next already planned #582 VM will record read-only mount/cgroup/systemd facts, no proxy start.


2026-10-14T16:55:11Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6173653949

Source718e7d7d8cbd86492d0e759b63ab7119fbfa207c preserves the failed57a138 proof and original lifecycle/award/worker assertions. Actual kernel config has MEMCG enabled but MEMCG_V1 disabled; systemd255.8 boots hybrid. New source retains full-v2 prerequisite and checks actual memory.max/pids.max/PID membership before main and at each ready incarnation.

Can this be done on the VM? Yes. Fresh no-NIC VM20 owner02; prepare exact private Syslinux text, apply only to this disposable clone, sync/read-only remount and one planned reboot with systemd.unified_cgroup_hierarchy=1. Record both boot IDs, original/applied bytes and full-v2 topology. Existing900s outer deadline includes provisioning/reboot/proof, no extension. Same8GiB/4CPU VM; owner1GiB/128tasks,service512MiB/64tasks, original worker timers and bounded commands. No default image policy change or hybrid-limit acceptance. All synthetic, no account/provider/device. Active watcher, original result consumption and disk retirement; no retry of failed owner01.


2026-10-14T17:05:01Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6173848693

Proxy attempt02 verified one planned private unified boot and actual kernel memory/PID limits, then original service start failed203/EXEC at ExecStartPost: staged controller mode0664 was not executable. Production package installs0755 (package.mk128-129). Original mainTERM after readiness failure and all original exits1 remain; no lifecycle acceptance. Cleanup0, actual owners exited, admission consumed;2,282,663,936B VM/media retired.

Can this be done on the VM? Yes. Fresh owner03 retains exact718e7d7 source/boot seam/bounds, stages identical controller SHA47391a3b at packaged0755 and checks mode/executable bit in guest. No shell substitution or changed readiness logic. Same synthetic no-NIC context and actual worker timers, one planned private reboot within900s, no limit extension. Active original-result supervision, consume then retire. Queued after current CHD closure; no owner/device/provider or product edit.


2026-10-14T17:17:24Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6174083661

Attempt03 reached actual-main readiness, queued the signed fixture award, and stopped all five workers before SQLite close. Its original exit remains FAIL: the next systemctl query returned reset execution metadata (ExecMainCode0, empty invocation). Original observer and journal show graceful process exit. Admission consumed; actual host owners exited;2,282,688,512B VM/media retired.

Can this be done on the VM? Yes. Fresh owner04 uses the same private unified boot, real kernel bounds, exact prepared Python, packaged controller bytes/mode0755, unchanged service/worker timers. Additive fixture packet docs/qa-logs/2026-10-14-proxy-unit-reference-source (manifest SHA80faba8ed181dfc5d378f72939fac97ecfeaeddb7c5b6bdbec80a91e4622ca69) retains one live D-Bus RefUnit connection so inactive-unit GC cannot erase the exit properties. Cached systemd255.8 source confirms tracked bus references prevent collection. Exact VM20 libsystemd bytes checked before use. Original CLD_EXITED1/status0 assertion retained, no RemainAfterExit or relaxed success.

Only fresh no-NIC VM system AF_UNIX bus; synthetic accounts/storage/local peer. No product or owner-device/cloud change. Same900s host deadline including planned reboot, same240s work and cleanup/owner bounds. Supervise original runner/lifecycle/payload receipts, consume, retire completed disk. Current-source native provenance and final-image qualification remain open.


2026-10-14T17:22:07Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6174174404

Attempt04 RefUnit correction confirmed: original graceful ExecMainCode1/status0 retained. Actual main/systemd graceful stop, manual start/restart and idle SIGKILL with Restart=on-failure all preserved the exact signed row and owned listener. Original full case still FAIL: no flush within25s after peer opened. No thread/cleanup error; online_state true and queue remained. All original receipts preserved; admission consumed;2,282,876,928B VM/media retired.

Source review finds ConnectivityMonitor sets was_online from its own initial forced probe after startup's separate probe/flush. The fixture currently opens the peer before proving that monitor probe finished. This may initialize true and miss the reconnect edge. Keep the possible product startup-window race OPEN here; do not treat fixture sequencing as proof there is no bug. Next controlled startup-window case and potential upstream fix must follow normal lifecycle qualification.

Can this be done on the VM? Yes. Fresh owner05 after the CHD run uses additive docs/qa-logs/2026-10-14-proxy-reconnect-observation-source: observes actual refresh_reachability return, waits at most6s for background false before opening peer; no timer/body override. Same exact source/unit/native binding, private unified boot, real15s/60s workers,240s work/owner900s. Peer calls now preserved on failure. This tests steady offline→online only. All synthetic no-NIC and no owner-device/provider action. Original results actively supervised, consumed and disk retired.


2026-10-14T17:28:01Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6174284660

Fresh owner05 actual main/systemd lifecycle PASS139.59s, original payload/owner/outer/runner/launcher0, monitor0, no forced cleanup or survivors. Actual kernel bounds enforced in disposable VM20 with explicit private unified boot. Exact signed award survives graceful stop, manual start/restart and idle SIGKILL recovery; observed steady offline→online flush applies once. Natural15s connectivity and two60s cache polls run unchanged; bulk lock holds then releases queued work. Empty folder polling and consent-disabled usage pass observed; five workers join before SQLite close. Hourly refresh is observed waiting, not artificially accelerated.

Original records: docs/qa-logs/2026-10-14-proxy-service-runtime/attempt05, run20261014T172312Z-ecf5adaf, admission8d7729dd746048028e88aa5643ae34e7. Actual host exits verified; admission consumed and2,282,893,312B completed VM/media retired. Source/run/code timers retained. Prior failed attempts are preserved.

Limits remain: older installed native ELF source provenance false; private unified boot differs from default hybrid configuration; final installed composition and the newly tracked startup-connectivity window are not covered by this PASS. No product pin, owner device or provider action.


2026-10-14T17:55:08Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6174800573

Continuing #583/#584 under the owner's current M7 authorization. Can this be done on the VM? Yes for runtime/loader/native and service qualification. The cross-compilation itself needs the already pinned host builder and frozen target SDK; it runs without a network and produces a small native library from the recipe's three exact cached source pins. It does not execute the target library on the host.

A source-only worker is preparing the exact current make_target build invocation and admission plan, with no product/native patch selected merely to erase the provenance limitation. Root will inspect and execute it as one actively supervised, serialized allocation. Planned bounds: 4GiB container memory, 2CPU, one compiler driver, 1GiB sampled scratch and a 600-second family deadline. Export original statuses, source/compiler/command/output hashes and closure evidence before retiring temporary sources. Runtime proof remains a separate no-NIC disposable VM stage. A successful build alone will not mark installed/native service qualification complete.


2026-10-14T22:19:37Z https://github.com/pixelelated/distribution/issues/583#issuecomment-6179767068

Installed-image native continuation PASS on frozen d6a87f05 / ES3178, SYSTEM `cca91bec2513aa32cfb713a81042acee720f12619bb66431019c7a76dc3eb6a0`.

Actual installed Python bytecode and shipped native library returned the expected equal GameCube hash `118545082f24fc195a446d1ee7bbf816` for ISO, uncompressed RVZ and Zstd RVZ; tiny Saturn CHD returned `4cd9c8e41cd8d137be15bbe6a93ae1d8`. Module origins, loaded library mappings and final image bytes match the completed verifier. This does not prove gameplay/saves, Wii AES data or full offline-service behavior.

Original writer/converter/preparation/installed case/guest owner/lifecycle/runner/monitor/launcher all0; no timeout, forced cleanup, leftover children or export errors. Actual lifecycle41.0s; run `20261014T221755Z-eab0bf3c`, owner `/workspace/tmp/pix-m7-installed-native-20261014-01`. Original evidence exported to `/workspace/tmp/pix-m7-installed-native-evidence-20261014-01`; coordinator carries compact records under `docs/qa-logs/2026-10-14-installed-native-result`. Exact admission consumed; only2.387GB disposable VM media retired.

The #588 installed startup service proof remains separate and is next after its clean-checker correction; this result does not check that remaining criterion.


## Source finding from #583 — October 14

Owner context:

> With the RVZ files, there's something we also need to adapt in RA offline proxy. We should look at that.

The current `cheevos_dolphin.sh` reads only `global.retroachievements.customhost` and writes that value to Dolphin `HostUrl`. It does not read the offline-proxy toggle. The packaged proxy service uses `run-service`, which bypasses upstream's emulator-configuration patcher. With the default empty custom host, merely enabling the service does not route Dolphin through it. This is source evidence of an integration gap, not proof about the owner's game session or offline award behavior.

PPSSPP already has a guarded routing pattern: exact toggle1, raw hardcore0, read-only IPv4-capable listener predicate; no saved setting/account mutation. Reuse the policy and test its applicability to Dolphin. Preserve configured customhost for toggle-off, hardcore/unknown or unavailable-listener cases. Never write credentials, saved customhost or global hardcore to arrange routing.

Upstream checks: ROCKNIX PR3038's custom-host support is already included; upstream RAOfflineProxy PR50 covers its Dolphin setup. Neither proves this packaged service/toggle integration. Compare current upstream integration before proposing a minimal distro patch; do not report this as a Dolphin RVZ decoder defect. #581's independent save-path preservation work must remain intact.

Can this be done on the VM? Yes: execute the full configuration script against synthetic settings/listener tables and verify generated INI bytes, then separately exercise an isolated emulator/proxy contract where feasible. No owner game/account/award action is needed for the first proof.

## Acceptance criteria

- [x] Exact source/current-upstream comparison and raw-setting/listener contract are recorded, including explicit contribution disposition.
- [x] A minimal launcher change routes only the enabled, non-hardcore, verified-listener case and preserves fallback customhost behavior.
- [x] Synthetic VM full-script controls cover toggle0/1, hardcore0/1/empty/unknown, customhost empty/nonempty, IPv4/mapped IPv6/IPv6-only/unreadable tables, missing token and disabled achievements; receipt verifies generated INI and unchanged input settings.
- [ ] Installed dependency/service and Dolphin host interpretation are verified; distinguish configuration proof from full offline login/cache/award/reconnect behavior.
- [ ] Canonical flow/limitations and combined #574/#583 qualification reflect the tested behavior before the next candidate.

Related #574, #583 and #581. No physical gameplay, account mutation or external submission is authorized by this issue.

Local candidate configuration proof: https://github.com/pixelelated/distribution/issues/584#issuecomment-6160344016 Production integration and installed/combined acceptance remain separate.


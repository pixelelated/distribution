2026-10-14T03:13:24Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6160047360

Can this be done on the VM? Yes. Source packetc22554a4c0966d48ba405ef1640938d2a417817b was reviewed and hash-verified. The coordinator adds its small readonly media to the already admitted fresh no-NIC guest owned at /workspace/tmp/pix-m7-rvz-vm-20261014, within its original30-minute deadline and resource allowance. Run the126 full-script synthetic controls once, serialized after the proxy fixture. Private64MiB /run mount;60s fixture work with75s outer bound and recorded original exits. Exact guest Bash/cat dependencies, synthetic settings/listener/queue only; no emulator/proxy/listener/account/device/provider or real saves. Installed-image/native protocol behavior remains separate.


2026-10-14T03:39:19Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6160344016

Configuration component qualification completed October14; native integration remains open.

Candidatec22554a4 with additive fixture3a65a2d4 passes126 full-script before/after cases using actual guest Bash/cat in isolated roots. Exact toggle1 + raw hardcore0 + an IPv4-capable listener selects127.0.0.1:8080. Off, hardcore, unknown/missing setting, unavailable/unreadable listener preserve configured customhost; disabled achievements and missing token preserve early exits. All generated INIs match expectations, protected synthetic settings/queue bytes remain unchanged, and there are no signals, remaining children or observation errors.

The original fixture failed because this kernel lacks task/children. The revised proc-stat PPID/start-identity census preserves unknown/failure distinctions and uses pidfd-only cleanup; original failure remains. No cleanup/error-injection qualification is inferred.

Exact source/current-upstream comparison and Dolphin2606/rcheevos HostUrl interpretation are in the source packet. Upstream ROCKNIX contribution is conditional on equivalent service/toggle integration; this is not a Dolphin RVZ decoder fix. Listener presence does not prove proxy identity/readiness. Installed service/native Dolphin/login/cache/award/reconnect remain unqualified.

Local evidence: `docs/qa-logs/2026-10-14-rvz-proxy-components/`; canonical menu reference records the candidate and unchanged presentation. No ES UI change/new frame proof, production integration, pin promotion or upstream posting. The first three checkboxes are supported for the local candidate only; installed/combined gates remain open.

2026-10-14T15:25:17Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6171866515

Independent Dolphin input qualification is now PASS in fresh VM20: five corrected synthetic decodes, independent NONE/Zstd encodes, both whole-data roundtrips and both actual candidate hashes agree with unchanged expected GameCube MD5. Original failed attempt01 remains; attempt02 is exported, consumed and retired. Inputs originate in `2026-10-14-independent-format-runtime/attempt02`, worker generator052b36080f with unchanged d92 driver/oracle/native binaries.

Can this be done on the VM? Yes. Next is the already prepared, immutable `2026-10-14-proxy-native-integration-source` experiment, using the accepted small prepared tree from `/workspace/tmp/pix583-native-prepared-20261014-02`. No re-preparation or native build. Fresh coordinator owner `/workspace/tmp/pix583-native-vm-20261014-01`: accepted no-NIC VM20, only loopback, 8 GiB/4 CPU, synthetic local peer on exclusive127.0.0.1 ports8080/18081. Public inputs <=32 MiB, private64MiB tmpfs; child512MiB AS/120CPU seconds/8MiB file,180s work +10s cleanup, outer200s +5s forced cleanup,900s host alarm. No occupied proxy is stopped. All source/ELF/input hashes and original failures are retained.

The first stage records installed native-library hashes without loading them; the coordinator reviews that concrete admission before releasing the single test child (120-second bounded review window). `source_pins_verified:false` remains: this older accepted image's installed native bytes are not newly built from the current recipe. Expected evidence is exact-byte native ISO/RVZ hash/cache/account separation, real local HTTP readiness, signed awards/dedup/hardcore refusal, SQLite reopen, failed auth/patch/award retention and reconnect flushing. Existing reference suites are not replayed.

This is ProxyRuntimeServer plus explicit cache/flush, with documented dependency-discovery and loopback interface substitutions. It does not qualify full main/systemd/periodic workers, new native-build provenance, physical memory savings, browser-owned stop/restart, provider acceptance or Dolphin gameplay. Those limits remain explicit. Export originals, verify actual owned processes exited, consume admission and retire VM after the run; no owner data/account/cloud action.


2026-10-14T15:30:48Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6171979953

## October14 independent format and native-proxy qualification

Fresh no-NIC VM20 independent oracle PASS: five corrected synthetic RVZ decodes, two independent Dolphin encodes, two complete data roundtrips, two target candidate hashes. Original native commands all0, no timeout/stderr; unchanged GameCube MD5118545082f24fc195a446d1ee7bbf816. The original decode failure is preserved; worker052b36080f corrects only a missing empty-partition SHA1 in the synthetic generator, with explicit rebinding and unchanged raw data/oracle/binaries.

Separate fresh native-proxy fixture PASS,11.46seconds: actual installed native ISO/NONE-RVZ/Zstd-RVZ parity, real scanner handoff, account/cache isolation, identified local listener and false-readiness rejection, signed award dedup/hardcore refusal, SQLite reopen/integrity, failed auth/patch/award preservation, reconnect applies two synthetic awards exactly once. No external network/account/gameplay. Exact installed library hashes and source manifests are retained.

Both successful runs have original child/owner/lifecycle/launcher/runner0 and monitor0, clean descendants/listeners/threads, actual host exits, consumed admissions and removed VM disks (4,647,079,936bytes). Earlier failed Dolphin attempt remainsFAIL1/retired. No owner-device action, product pin, firmware or RC designation.

**Remaining:** older installed native bytes have `source_pins_verified:false`; this is not current-native-build provenance. Full main/systemd/periodic-service lifecycle, production scanner locking, Dolphin gameplay/integration, CHD/native parity, final frontend/UI and assembled-image clean/retained proof remain. Source-only prepared controls were not silently counted as executed. Evidence: local `docs/qa-logs/2026-10-14-independent-format-runtime/` and `2026-10-14-proxy-native-runtime/`; immutable source packets retained. Future browser stop/restart experiment#587 stays outside M7's gates.


2026-10-14T22:16:21Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6179706904

Can this be done on the VM? Yes. Final-image native hash/codec calls require no physical-device fact. Allocating the source-reviewed installed-native lifecycle f10d5ba9 against completed frozen d6a87f05 / ES3178, image SHA655ce3dc8b375cb2f30dbad2783e314a6882149727ef98b30f2147f0fe347509, verified SYSTEM cca91bec2513aa32cfb713a81042acee720f12619bb66431019c7a76dc3eb6a0.

One fresh 8GiB/4CPU/no-NIC guest, VNC130, owner `/workspace/tmp/pix-m7-installed-native-20261014-01`; 1200s work +120s cleanup, original native case180s and guest owner210s. Executes unchanged installed ISO/NONE-RVZ/Zstd-RVZ/CHD hash calls and recreates only the retired tiny CHD with existing accepted public tools. No native library/product overlay, no gameplay claim, no physical device or provider. Original exits, module origins/native maps, final-image identity, descendant cleanup and disposable-media retirement are retained. Watched launcher supervises; coordinator actively consumes actual results. No other runtime allocation active.

The separate clean/#588 owner ended before the proxy fixture: no-NIC startup log inspection was misclassified as cloud activity. Original failure preserved and consumed, VM media retired; narrow checker repair underway. This independent installed-native case does not claim that separate check passed.


2026-10-15T00:11:22Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6181313175

Source reconciliation found a functional gap in the default player path. The frozen6094cfcf+current patches NoGUI main initializes UICommon and controllers but never calls `AchievementManager::Init()`; Qt calls it from MainWindow.cpp. Core's Init creates the rcheevos client, applies HostUrl, starts worker queues and token login. Merely writing RetroAchievements.ini does not activate that lifecycle. The recipe comment claiming frontend independence was inaccurate.

This keeps the actual installed Dolphin→configured-endpoint criterion open. Prior ROM/RVZ hashes, shell configuration controls and proxy protocol proofs remain valid for their scope but do not prove this missing path. A minimal guarded NoGUI Init/Shutdown patch and bounded synthetic-loopback VM proof are being prepared. Can this be done on the VM? **Yes:** actual built NoGUI startup with fixture-only account/token and an isolated endpoint can show request routing and normal teardown without personal credentials or a real award.

Current upstream Dolphin and ROCKNIX source checks also retain the gap; the prepared source packet will bind exact current hashes/query receipts. A version bump alone is not a demonstrated remedy. This is an upstream contribution candidate under#585 after our initial qualified build; no upstream submission yet. No product patch or runtime acceptance is claimed in this note.


2026-10-15T00:40:58Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6181689074

Can this be done on the VM? Yes. Client initialization, actual loopback login routing and process cleanup require no physical-device fact. Before that guest proof, allocate one bounded compile of the reviewed NoGUI lifecycle fix at coordinator d3e684dd4b; production patch018 is source-only until this qualification completes.

Owner /workspace/tmp/pix-m7-dolphin-ra-relink-20261015-01; reviewed packet seal ffc221eacd52c5add66b6f6ae533f0121277c5ba161ae97d6b19b9b637814e90. Compile only MainNoGUI.cpp and relink from103 hashed frozen inputs mounted read-only. Pinned builder, network none,2CPU4GiB/no swap/256PIDs,900-second work deadline,1GiB sampled scratch threshold. Existing Docker ownership/watchdog keeps per-operation cleanup deadlines and300-second final guard wait;600 seconds is forecast, not a new hard enclosing timer. No cache copy or frozen stamp mutation.

The subsequent separately admitted normal8GiB/4CPU/no-NIC VM compares installed known-defect baseline with private candidate: enabled synthetic failed login, disabled RA, and early BootCore failure. Tiny self-authored DOL enters a live CPU loop; no gameplay, account login, award or real service is claimed. Candidate is not installed-image proof; the next image still needs its installed smoke. Original failures and exit channels will remain unchanged.


2026-10-15T00:43:01Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6181713955

The bounded relink completed successfully: compile, link, strip, readelf, container, watchdog and watcher original exits0; exact container removed and observed owners absent. Candidate SHA2565cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5,8,593,792 bytes. Peak cgroup memory1,290,883,072 bytes, scratch20.7MB. Original LTO type warnings are retained for source review, not dismissed as harmless. Admission aea323d1 consumed.

Can this be done on the VM? Yes, as described in the prior four-row contract. Allocate /workspace/tmp/pix-m7-dolphin-ra-startup-20261015-01, normal8GiB4CPU/no NIC/VNC135,1200s host work plus120s cleanup,180s case/210s guest owner. Actual installed baseline stays unchanged; candidate runs from private executable tmpfs. Synthetic failed-login loopback only, no real account, award, game, device or cloud action. Current coordinator d3e684dd4b is bound independently of frozen fac608ff image. No other runtime/compiler allocation is active.


2026-10-15T00:57:05Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6181891276

Dolphin NoGUI startup fix is now runtime-qualified in the private candidate. Local commit956f9481872d retains docs/qa-logs/2026-10-15-dolphin-startup-result/ with original build/VM records, request and process identities, dependencies and warning comparison.

Original installed baseline e6c6207d runs a live CPU thread with no achievements initialization or request: the diagnosed defect is reproduced. Candidate5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5 initializes once, makes one synthetic login POST to127.0.0.1:8080/dorequest.php, and shuts down once. Disabled achievements makes no lifecycle/request; absent boot file returns original1 with exactly one initialization/shutdown. Normal rows exit0 after ordinary SIGTERM. No forced cleanup, surviving child or endpoint error.

Compile/relink original channels0; startup run20261015T004309Z-7bfdcf48 original outer channels0; both owners exited and admissions consumed. Existing20 linker warning messages/counts exactly match the original engineering NoGUI link. This is no assertion of ABI safety or harmlessness.

Remaining: package/install the patch in the next engineering image, verify the new installed binary and run pending native gameplay/save proof there once. The synthetic endpoint rejects fixture credentials; no successful login, award, real provider or owner device claim. Existing settings and game-launch presentation remain unchanged, with canonical nonvisual-flow reference updated. Upstream candidate remains queued under#585.


2026-10-15T01:15:11Z https://github.com/pixelelated/distribution/issues/584#issuecomment-6182110159

Next engineering allocation is prepared at published distribution d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a / ES3178b832b8d134198b2b4eede4f725d4ed283f8c. Primary forward/reverse source review is settled with three repaired findings; full #590 audit continues. Product delta from fac608 is only Dolphin lifecycle patch, immutable Sys-resource recipe repair (#592), and Steam metadata bounds (#580/#582).

Can this be done on the VM? Installed resource/startup, native gameplay/save, clean-install and retained-upgrade proof will use GENERIC_X64. Compilation uses the canonical cross-build container. No device/account/cloud operation.

Clean frozen checkout: m7-p5-build-20261015-01, build/m7-p5-build-20261015-01. The completed warm cache moved atomically after a fresh scoped dependency review and explicit consumer closure; device/inode identical, no cache copy. Transfer original channels0 and admission5b6ac98a consumed. Protected-service FD limits are retained in the receipt; this is not a deletion permission.

Prepared build owner /workspace/tmp/pix-m7-engineering-build-20261015-01. Stages: scoped Dolphin clean, canonical Dolphin package build, canonical image assembly. Unchanged qualified resource/lifecycle helpers. Dolphin 4CPU/24GiB; image24CPU/40GiB; no container swap; 2048PIDs; 7200s family bound; host8GiB available and volume64GiB floors. Current retention forecast170.7GB fits against2.78TB available. Identity timestamp20261015T011500Z, qualifierdev. Root supervises actual watcher/owner/container/resource results; no off-session notifier claim.

Build success will precede artifact readback and installed/native/final-composition proof. This is engineering firmware, not a designated release candidate or a completed audit. H700 then SM8550 remain after applicable qualification/audit.


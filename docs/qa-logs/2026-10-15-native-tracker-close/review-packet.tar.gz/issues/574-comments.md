2026-10-13T04:22:34Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6138176415

Read-only installed evidence:9GameCube RVZ files; all9 gamelist entries have a cheevosHash field but no cheevosId; retained ES logs contain9GameCube "Unable to extract hash" events. No raw filenames or credential values retained in public evidence. Dolphin achievement configuration exists and is enabled, with an account/token present; no live sign-in validation or game launch performed.

Accepted ES c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78 maps NINTENDO_GAMECUBE to RC_CONSOLE_GAMECUBE. Its getCheevosHashFromFile returns the all-zero failure sentinel when generateHashFromFile fails. The wrapper external/libcheevos/cheevos.cpp:156 registers a custom CD reader only; GameCube's hash_disc.c:512 opens the file directly and expects the uncompressed-disc magic at0x1c. No RVZ reader is registered on this path. This is a strong source/runtime match for the missing frontend recognition; it does not prove a failure in standalone Dolphin's in-game achievement support.

Upstream research lead: RetroArch#18316 reports RVZ hashing and current RetroArch has a dedicated cheevos_rvz reader; inspect exact upstream fix/licensing/test coverage before selecting an implementation. https://github.com/libretro/RetroArch/issues/18316 . Source freshness remains required; do not work around this by asking the owner to bulk-convert their library.

Next: synthetic ISO/RVZ equivalence and invalid/truncated controls in the VM, with a bounded reader or an appropriate existing upstream integration; verify frontend/offline indexing and independent Dolphin behavior. Track this confirmed recognition failure within M7 before the next candidate, after current owner-ordered browser/account/copy tasks.


2026-10-13T23:03:48Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6157053859

Compiled ES composition bb9e2785f88c2b9de979022a2a9ded2cbce2f954 PASS: five ES syntax units, full CMake345task rebuild/link, EN/FR catalogs, actual target baseline/candidate hash and27case retry harnesses;64extracted save-capability ASan/UBSan controls PASS.221s wall,3,413,467,136byte container peak,noOOM; frozen cache unchanged, original owners0/exited, build cache retired. No target decoder/runtime claim yet.

Can this be done on the VM? Yes. Next allocation is one fresh standardVM20,8GiB4vCPU,640/1280serial profiles,90min bound. Generate only non-bootable synthetic ISO/RVZ/NES fixtures; run actual baseline and candidate hash binaries,27retry cases, then new capability/hint screen branches. Preserve original failures; no owner ROM/account/device/provider access. Prepared Steam/Dolphin controls may run serially in this same private guest once exact source packets are sealed and reviewed; no worker runtime allocation. Separate no-NIC achievement-index fixture remains separate. Full firmware and physical memory proof still due.

2026-10-14T01:57:40Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6159175863

The newly instrumented runtime checks are underway; compile success alone is not counted as qualification.

The first format run stopped on an existing baseline UBSan alignment error in libretro-common MD5 (`MD5_SET`, `md5.c:110`) while hashing the official synthetic GameCube input. Original wrapper exit1 is preserved. The baseline and frozen candidate carry the same word-load implementation. The upstream libretro-common source at39eae6ac1c4e4dd809f27cec210ace8d62a5c0a5 retains the same x86/VAX unaligned cast optimization; no matching upstream alignment issue was found in the scoped search. This is C alignment undefined behavior seen under instrumentation, not evidence of an observed handheld crash or a new RVZ regression.

An isolated local ES branch `feature/m7-md5-alignment`, commit314da58d6, replaces that word dereference with memcpy while preserving byte order, plus264 offset/length/split-update checks for independent MD5 comparison. It is source-only: target compile, sanitizer runtime, combined-wrapper regressions and pin promotion remain pending. Frozenbb9e and productionc8dc72 are unchanged. Do not disable alignment sanitization to count the interrupted run as passed.

A separate independent subset passed with the original instrumented candidate: four concurrent RVZ readers, eight open/close rounds each, repeated full/range reads and descriptor-balance assertions; all five byte-for-byte padding vectors agree with the pinned Dolphin implementation. All original processes0/exited, empty sanitizer stderr. This does not supply CHD/DolphinTool format proof or Wii catalog compatibility. Records: current offline VM owner, `sanitizer-subset-host`, `sanitizer-diagnosis-host`, and `sanitizer-reader02-host`.

Can the repair and remaining proof be done on the VM? Yes. Next: finite admitted target compile, 264 independent digest comparisons and exact repaired wrapper regression cases in a disposable guest; keep old failing baseline evidence separate from a repaired-baseline comparison. Independent format tool preparation1c0e93 is ready but not built.


2026-10-14T02:18:59Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6159426278

## Upstream disposition requested — 2026-10-14

> With the work we're doing around Dolphin, is this an upstream issue we need to submit a fix for with this specific file type, or is it something unique on our end in the parsing? Also, if this is a candidate for a smaller patch, we can upstream to ROCKNIX. Let's make a note of that.

Keep three scopes separate:

1. **RVZ frontend recognition/hashing:** the confirmed defect is the EmulationStation/libcheevos reader integration described in this issue, not an established defect in Dolphin's own RVZ decoder or in-game achievement support. Prepare a focused ROCKNIX/EmulationStation contribution after the independent format and sanitizer gates pass. Reuse the appropriate existing upstream reader work and preserve license/credits; do not submit our full fork overlay or unrelated UI/cloud changes.
2. **MD5 alignment:** full-library UBSan caught an unaligned `uint32_t` load in the bundled MD5 fast path, also present at inspected libretro-common file revision 39eae6ac1c4e4dd809f27cec210ace8d62a5c0a5. A separate memcpy-based candidate is committed locally as 314da58d68820a79b26f99a5b6c12f9bb37054d5. Its target compilation and digest/alignment runtime controls remain UNRUN. If those pass, offer the minimal fix to libretro-common first, then carry the reviewed dependency patch where needed. This is not evidence of a Dolphin RVZ defect.
3. **Dolphin save-path preservation/recovery:** #581 concerns distro launch/storage integration. Compare the small fix with ROCKNIX's current scripts and propose it there if their equivalent flow is affected. The current path-layout change only inserts a display newline; it does not change any path on disk.

Follow-up acceptance: [ ] exact target repository/current upstream comparison; [ ] minimal content-only patch and attribution; [ ] relevant synthetic/format/sanitizer evidence; [ ] upstream issue/PR link or explicit duplicate/already-fixed disposition. No upstream submission has been made. No owner ROM, save or credential data is needed.

Correction: the original routing note called the MD5 source rcheevos. The inspected file is libretro/libretro-common `utils/md5.c`; that is the first upstream target. Proxy RVZ tracing and the explicit contribution rule are tracked in #583.


2026-10-14T03:18:02Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6160100334

Can this be done on the VM? Yes. Target compilation produced all nine artifacts with both sanitizer contracts PASS and zero OOM. Original wrapper remains FAIL1 because its Docker not-found predicate was case-sensitive. Fresh exact-container/process absence is recorded and the failed admission consumed. Explicit recovery packet8568a71b88965cce7765a30de9521554358668f0 rechecked source snapshots, original failure, exact artifact/contract hashes and later absence evidence; new export preparation0, no rebuild. The current fresh no-NIC8GiB/4CPU guest now receives that32MiB export read-only. Run43 recovery refusal controls then264 digest comparisons per repaired composition and blocked wrapper/Wii-helper checks under the unchanged300s runner/512MiB scratch bounds. Preserve old FAIL1 and new original exits separately. No sanitizer suppression, native emulator, account or owner device operation.


2026-10-14T03:39:20Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6160344183

MD5 target subset now passes; original failures remain preserved. Candidate314da58d and baseline with only that same MD5 repair each match264 independent hashlib rows (528 comparisons), plus GameCube ISO/Saturn ISO+CUE repeated wrappers, two Wii helpers and expected truncated-input exit2. All ten target commands are accepted with empty sanitizer stderr.43 positive/negative cleanup-recovery controls pass.

Compilation's Docker child and four stages exited0, but the original outer runner/watcher/launcher remain1 because exact-container absence text used different capitalization. Source8568 binds the known failed records, exact container/host absence and all original source/artifact identities; the separately recovered target VM run passes. No sanitizer was disabled and no failed result rewritten.

Minimal current-upstream libretro-common contributiona58b2313 is prepared locally: utils/md5.c only, original license preserved, public264-row reproducer and draft PR. Upstream owner is libretro/libretro-common, not rcheevos. Current-upstream standalone before/after compilation is UNRUN and required before submission. No upstream message/push.

Durable local evidence: `docs/qa-logs/2026-10-14-rvz-proxy-components/` and `2026-10-14-md5-upstream-source/`. Full formats/CHD, independent DolphinTool, whole Wii images, ARM/big-endian, native proxy and final frontend/image qualification remain open. Fresh independent format plan1c0e93 is next; prior VM and compile scratch are retired, no runtime active.

2026-10-14T05:38:37Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6161722996

Can this be done on the VM? Converter behavior and independent ISO/RVZ comparisons will be verified in a disposable GENERIC_X64 VM. The next two stages prepare that target tool on the build host: export exact read-only cached source and configure it using the retained target toolchain. Host Docker/PID/cgroup/admission and cleanup behavior are host facts; a guest cannot establish them. No device or owner data is used.

Coordinator reviewed source-only runner eb70be990b394be9cece9a7e05ca842c8a3be256 against sealed plan1c0e93. Next:48 finite synthetic runner controls (no Docker/compiler), then separately admitted export and configure. Each container is network-disabled/read-only except fresh scratch,4GiB/no-swap/2CPU/256PIDs;6GiB scratch stop threshold,60-minute family clock including gaps. Original failures stay failed; exact container and host exits are required. Configure only includes compiler probes, not DolphinTool compilation. Generated flags and source immutability must be reviewed before a separately prepared build. Host preflight READY:51GB available RAM,2.8TB disk. No firmware build or upstream submission.


2026-10-14T06:20:41Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6162247740

Dolphin preparation update: exact source export passes13,424 files. Original configure03/04 remain FAIL1; CMake itself returned0 both times. The private wrapper restores intended release flags. A separate read-only recovery under b65f782e20 passes all75 bound generated files and806 commands (701ordinary O1,96pinned MbedTLS O2,9pinned cpp-ipc C++ O2);88 runner controls PASS. The overly broad C++ exception was the final configuration guard defect. Recovery original channels0, cleanup PASS, host exits verified and admission consumed.

One-job DolphinTool compilation is now active under a fresh watched admission,4GiB/no swap and the original07:00:54UTC family deadline. No converter/format PASS claimed. Coordinator owns runtime; the existing source lane prepares ELF closure without changing the active runner. Compact original evidence: docs/qa-logs/2026-10-14-dolphin-tool-preparation/.


2026-10-14T07:04:01Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6162852211

M7 checkpoint 4960aaa760: DolphinTool compilation and static library closure are accepted for the next VM experiment.

All 831 compiler/link steps returned 0 in 703.295 seconds. The original wrapper failure remains recorded: it rejected two expected upstream-generated placeholder files. Separate output recovery verified those exact files, the unchanged remainder, and all 13,424 source files. A subsequent SDK-versus-image loader-path correction passed 14 focused controls and the actual static inspection.

The resulting bundle is 50,726,779 bytes: 19 ELF objects, 38 version-provider checks, and 2,629 pinned Sys resources. Manifest: `49b06305f103df552a9d6c7a145627a66b8cd5e240d34ddceb1df3592175ec0d`. No target binary or loader has executed yet; actual VM loading, independent RVZ conversion and native hash parity remain open. CHD preparation is separate and unbuilt.

All original stage owners exited, cleanup passed, and admissions were consumed. No compiler or test remains active. Exact evidence is locally committed at `4960aaa760d76a5a16c2b109e5058bcffc09ce3b`, `docs/qa-logs/2026-10-14-dolphin-tool-preparation/`; not pushed or promoted. The next allocation is a fresh no-network VM using the accepted bundle. This remains a partial result for #574.


2026-10-14T15:04:05Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6171440567

Can this be done on the VM? **Yes.** Run the exact prepared Dolphin loader/conversion experiment in one fresh accepted VM20 without a network device, using source packet `d92e127fa5e04bb0e9403dfe5e51e15288e5da4c` and the already qualified 50.7 MB static bundle.

The run compares installed/private loader identities and actual loading, then uses the unchanged independent oracle for five synthetic RVZ decodes, independent NONE and Zstandard encoding, full ISO roundtrips, and candidate achievement hashes. Inputs are self-created nonbootable data; no owner ROM, game, account or provider is involved. It cannot establish all Sys resource lookup or gameplay behavior.

Coordinator owner: `/workspace/tmp/pix574-format-vm-20261014-01`. Private executable tmpfs is 2 GiB; guest work and cleanup share the existing 240-second total budget, with the oracle's original per-command limits unchanged. VM is 8 GiB/4 CPU; host work alarm is 900 seconds with bounded cleanup. Exact public inputs are read-only and hash-bound; the standard watcher and active coordinator supervision deliver the result.

Keep original child/loader/oracle/driver and host exits, including failures. After stopped-VM export and process verification, consume the admission and remove the disposable disk/media. Retain only the small independently encoded fixtures needed by #583/#584. All expired owner04 build/closure stages remain consumed and are not replayed. This plan does not claim a passing conversion or authorize native proxy execution yet.


2026-10-14T15:21:18Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6171783546

Attempt01 preserved FAIL1: the actual Dolphin binary loaded, both installed/private loader lists and help commands exited 0, but the first decode rejected the synthetic RVZ. No conversion/hash PASS was claimed. All owners exited, admission was consumed and 2,362,396,672 disposable bytes retired; original evidence is in `docs/qa-logs/2026-10-14-independent-format-runtime/attempt01/`.

Source diagnosis at worker `052b36080fe8c9f0f8c9ef6307175bc6786cf9ff`: the generator left the empty partition-table SHA1 at zero instead of SHA1(empty). Pinned and current official Dolphin reject that field. The additive correction changes one assignment plus comment; raw ISO, expected GameCube MD5, Dolphin/hash binaries, oracle and runtime driver stay unchanged. Bindings visibly select the new generator; historical fixtures and failed run remain unchanged.

Can this be done on the VM? Yes. Fresh owner `/workspace/tmp/pix574-format-vm-20261014-02` will run the same independent native oracle with the corrected generator on accepted VM20, no NIC, public/synthetic inputs, 8 GiB/4 CPU, executable private 2 GiB tmpfs, 240-second guest total (235 work/5 cleanup), original 60-second conversion/15-second hash bounds and 900-second host alarm. The coordinator actively supervises original watcher/launcher/VM results, exports receipts, then consumes the admission and retires disks. Acceptance requires five original decodes, two independent encodes, two complete roundtrips and two actual candidate hashes with unchanged expected MD5. Any failure remains failed. Native proxy, CHD, gameplay and observed Sys lookup remain separate.


2026-10-14T15:30:45Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6171978790

## October14 independent format and native-proxy qualification

Fresh no-NIC VM20 independent oracle PASS: five corrected synthetic RVZ decodes, two independent Dolphin encodes, two complete data roundtrips, two target candidate hashes. Original native commands all0, no timeout/stderr; unchanged GameCube MD5118545082f24fc195a446d1ee7bbf816. The original decode failure is preserved; worker052b36080f corrects only a missing empty-partition SHA1 in the synthetic generator, with explicit rebinding and unchanged raw data/oracle/binaries.

Separate fresh native-proxy fixture PASS,11.46seconds: actual installed native ISO/NONE-RVZ/Zstd-RVZ parity, real scanner handoff, account/cache isolation, identified local listener and false-readiness rejection, signed award dedup/hardcore refusal, SQLite reopen/integrity, failed auth/patch/award preservation, reconnect applies two synthetic awards exactly once. No external network/account/gameplay. Exact installed library hashes and source manifests are retained.

Both successful runs have original child/owner/lifecycle/launcher/runner0 and monitor0, clean descendants/listeners/threads, actual host exits, consumed admissions and removed VM disks (4,647,079,936bytes). Earlier failed Dolphin attempt remainsFAIL1/retired. No owner-device action, product pin, firmware or RC designation.

**Remaining:** older installed native bytes have `source_pins_verified:false`; this is not current-native-build provenance. Full main/systemd/periodic-service lifecycle, production scanner locking, Dolphin gameplay/integration, CHD/native parity, final frontend/UI and assembled-image clean/retained proof remain. Source-only prepared controls were not silently counted as executed. Evidence: local `docs/qa-logs/2026-10-14-independent-format-runtime/` and `2026-10-14-proxy-native-runtime/`; immutable source packets retained. Future browser stop/restart experiment#587 stays outside M7's gates.


2026-10-14T16:16:54Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6172910914

M7 continuation: exact source-only CHD runner7d4366 and guest selection76f44e have been copied/verified in coordinator checkout. Can this be done on the VM? CHD loader/conversion/hash qualification will run in the disposable no-network VM. Tool preparation uses the already selected offline pinned builder and retained target SDK; native GENie is the necessary host generator. No target converter executes on host.

Now allocate fresh family /workspace/tmp/pix574-chdman-build-20261014-01, one shared1800s clock covering export/bootstrap/configure/build and review; stages individually admitted, inspected and consumed. One job,4GiB RAM/no swap,2CPU,6GiB sampled scratch ceiling. Exact MAME archive4867bee5/source24cffe, unchanged sealed1c0e93 build-stage/shared-C++ patch, read-only accepted cache at original prefix. Independent existing watchdog, actual host PID/cgroup handshake and original Docker/child/launcher channels required. First stage is export only; no automatic four-stage loop. Existing MD5/Dolphin/proxy components are not rerun.


2026-10-14T16:22:44Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6173026469

First CHD export owner01 original FAIL1 before any extraction/compiler. Exact archive has two symbolic aliases under3rdparty/zstd/tests/cli-tests/bin (unzstd,zstdcat→zstd), omitted by the prior special_members category. Adapter refused them. No cache mutation; all original host/container/launcher owners exited, watchdog0 and cleanupPASS; admission consumed failed-investigated, empty12288B work retired. Source lane prepares exact, narrow alias handling; no general link acceptance or old result rewriting. Packet docs/qa-logs/2026-10-14-chdman-build-runtime/attempt01-export-failure.


2026-10-14T16:23:50Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6173049196

Narrow source correction26a527 copied/verified: only two exact Zstd CLI test aliases are explicitly omitted and recorded; all897821359 regular source bytes/hashes and original build/patch/lifecycle/limits unchanged. Prior7d4366/source/FAIL retained. Fresh family02 now proposed for original4 individually admitted stages under a new1800s clock; failedowner01 remains consumed. Same VM-first format proof boundary and no host target execution. No general links accepted.


2026-10-14T16:40:06Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6173362111

Owner02 export and native GENie bootstrap passed; configure failed before target compilation: GENie rejected NO_USE_XINPUT. Source-after remained exact; original selected make2/container+attach+launcher1/watchdog0 and normal cleanup are preserved under docs/qa-logs/2026-10-14-chdman-build-runtime/attempt02-configure-failure. Admissions consumed;993,542,144B failed private tree retired.

Exact source review found a libretro Lua block overwriting requested SDL OSD, not obsolete XInput arguments. Additive source2608923ba0ab80752e555adb393d7a029baeaf8c guards only three retro-specific assignments, preserves all43 make assignments/37 emitted options, and permits exactly two patched source files (existing shared-C++ patch plus OSD correction). Historical originals remain.

Can this be done on the VM? Native loader/CHD/Saturn/CUE parity: yes, after producing this tool. This host cross-build uses exact cached archive/SDK and pinned offline normal-UID container; no target execution. Fresh owner03 recreates retired inputs and selects export→bootstrap→configure→build individually, consuming every original stage result. Unchanged one1800s family clock,1job,4GiB/no swap,2CPU,6GiB sampled scratch. No limit reset or failed-stage promotion. Active watcher and exact-CID/PID cleanup remain. Closure/target VM proof follow only after actual build success. No firmware or package pin promotion.


2026-10-14T16:56:43Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6173683406

Owner03 now completes export/bootstrap/configure and compiles through final link. Original final link fails: shared libstdc++ requires libgcc_s.so.1 while command forces-static-libgcc (17 versioned unresolved symbols, not all GCC3.0). Original make2/container+attach+launcher1/watchdog0 and normal cleanup preserved, all4 admissions consumed.380 files exported losslessly; failed work retired1,011,810,304B.

Additive1015ccf0f4918a07d3875e746dd3b42b730b5218 explicitly selects-shared-libgcc with shared libstdc++, binds existing SDK runtime bytes and updates exact generated-link assertions. All other flags, codecs, OSD patch, source pin and bounds unchanged. It is a private QA-converter correction, no product/pin change or compiler defect claim.

Can this be done on the VM? Native loading/formats: yes after producing the converter. Fresh host cross-build owner04 uses exact cached source/SDK, offline pinned normal-UID container,1job/4GiB/no swap/2CPU/6GiB sampled scratch, one1800s family. Each stage selected and original results consumed separately. It will start after the current serialized proxy VM ends. No host target execution. Real shared-runtime closure and CHD/Saturn/CUE VM parity still follow any successful link.


2026-10-14T17:04:59Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6173848038

Actual owner04 CHD build PASS: original export/bootstrap/configure/build, all child/container/attach/launcher0 and monitor/watchdog0, exact cleanup without force;4 admissions consumed and actual host owners exited. Target chdman5,993,144B SHA766640dfccf2239503fbead2f172098b784d1bbec3f113ffa51264f7f5e1b129, not executed. Original383 files retained losslessly under chdman-build-runtime/attempt04-build-pass.

Next readelf-only closure uses coordinator packet chdman-closure-owner04: all10 executable Python files byte-identical to c24a32, only explicit source/plan/build-owner bindings updated to1015ccf0; original failed build can never satisfy prerequisites. The Herdr follow-up hit auth failure, so coordinator performed this narrow handoff. Fresh closure owner04,180s/4GiB/no swap/2CPU/1GiB sampled scratch, readonly original work/SDK/receipts; target hash derived from successful consumed original receipt. No target execution. Can this be done on the VM? Actual loader/CHD formats yes, separately after closure. The host step reads ELF metadata and copies only its required libraries. Preserve original result and exact cleanup before consuming/advancing.


2026-10-14T17:19:45Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6174126682

Owner04 converter build and subsequent static ELF/library closure both PASS, original child/container/runner/launcher0, actual owners exited, both admissions consumed. Real chdman SHA766640dfccf2239503fbead2f172098b784d1bbec3f113ffa51264f7f5e1b129 (5,993,144B); closure manifest b5f8642027dc1aeaae7fd04d402c8ee11b27510fd21b6b06445fd4f44c45a49b (7files/27,533,560B). No native converter execution yet. Compact receipts retain all original records; duplicate ELF bytes omitted from git with exact manifest, live bundle retained for immediate proof.

Can this be done on the VM? Yes. Fresh no-NIC VM20 owner /workspace/tmp/pix574-chd-native-vm-20261014-01, serialized after proxy owner04. Exact unchanged76f44e case packet and nine retained sanitizer artifacts/corrected generator, newly built actual converter and qualified closure. New outer adapter docs/qa-logs/2026-10-14-chd-native-guest manifest4567d6eb44666560c146241ee60f56faa231ad7775ace61475e8efa8422500cf reuses qualified descendant owner, single240s total/235s work/5s cleanup and2GiB aggregate scratch. Four loader/help probes first; then only remaining8case children/234ordered hashes (CHD/CUE/ISO, repeated resets, CHD→RVZ→NES→CUE). Original exits and sanitizer stderr retained. No accepted Dolphin/MD5/proxy suite replay. All synthetic, no accounts/provider/owner hardware.

This advances component proof, not installed integration/native proxy source provenance/final-image acceptance. Active result supervision, original receipt consumption, and VM retirement follow. No candidate/build publication or product pin promotion.


2026-10-14T17:25:24Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6174235996

Fresh native attempt01 reached both installed/private loader --list (original0) and executed actual chdman help, which printed exact MAME0.289 header but returned1. The outer fixture incorrectly expected0. Exact source print_help returns1; main's help branch returns that value. No format case ran. Original failure0.72s, cleanup PASS/no force, admission consumed and2,338,017,280B VM/media retired.

Can this be done on the VM? Yes. Fresh native02 uses additive docs/qa-logs/2026-10-14-chd-native-help-source (manifest ebd487f44b4d8d2d5667a9846747ca9f9edd55ded527bfc703e19b08943ccd19). Only two help probes now require exact original1 and recognizable help output. All loader lists, generator and format/hash children still require0; converter/closure/case runner/sanitizer source and240s/2GiB bounds unchanged. Serial allocation after proxy05, same no-NIC/synthetic context. Actively consume original results and retire the completed VM.


2026-10-14T17:30:03Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6174323849

Actual CHD native proof PASS. Fresh native02 owner1.786s, selected cases0.946s; all8 original case children0, all234 ordered hashes match. Includes real converter-created Saturn CHD, CUE/ISO/CHD parity on repaired baseline and candidate, repeated hash resets, and64 CHD→RVZ→NES→CUE transitions. Sanitizer stderr empty where required; converter progress retained. Both installed/private loader lists0 and both exact-source help exits1 qualify actual chdman766640df. Outer cleanup PASS/no forced signals/survivors; lifecycle/runner/launcher0, monitor0.

Evidence docs/qa-logs/2026-10-14-chd-native-runtime/attempt02; run20261014T172737Z-3010941d, admissione10ef94addf04b59aacada864b4456ca consumed after actual host exits.2,338,144,256B VM/media retired. Successful compiler work also retired after preserving original records and verified small successor closure bundle. Initial help-exit fixture failure remains intact. No completed suite replay, no product pin/image/device change.

CHD component parity is now accepted. Current proxy native source provenance, installed service/default-boot composition, Dolphin gameplay and final image/UI qualification remain. #588 separately tracks the startup reconnect window found in service proof; normal main/systemd lifecycle passed139.59s under #583.


2026-10-15T00:16:03Z https://github.com/pixelelated/distribution/issues/574#issuecomment-6181373963

#583's RVZ/proxy scope is qualified. The original component result under
`docs/qa-logs/2026-10-14-rvz-proxy-components/results/proxy-corrected.json` records
126 original unaligned mismatches and zero candidate mismatches,72 aligned
controls,6 malformed controls, and44 scanner cases preserving automatic policy,
exclusions and pending bytes. The original native-runtime payload under
`2026-10-14-proxy-native-runtime/attempt01/guest/run01/payload/result.json`
records ISO/NONE-RVZ/Zstd parity, actual scanner/native handoff, account/cache
isolation, signed queue/dedup, error preservation and exactly-once reconnect;
its older-native provenance limit remains unchanged. The later actual installed
`2026-10-14-installed-native-result/installed-result.json` binds final image
bytecode/native mappings and expected ISO/NONE-RVZ/Zstd hash
118545082f24fc195a446d1ee7bbf816 plus tiny Saturn CHD
4cd9c8e41cd8d137be15bbe6a93ae1d8. Actual service lifecycle and installed startup
reconnect are separately retained under2026-10-14-proxy-service-runtime/attempt05
and2026-10-14-proxy-installed-startup-result. Original failed attempts remain
failed; no owner account, award or provider acceptance is inferred.

The remaining Dolphin-specific qualification stays in#584. Source inspection
found that the default NoGUI frontend never initializes AchievementManager,
although its launcher writes HostUrl and RA is compiled in. The minimal lifecycle patch is now integrated in the editable coordinator;
compilation and installed-process proof remain UNRUN. The ordinary Wii/Dreamcast native-gameplay packet has RA
disabled and cannot establish Dolphin HostUrl, login or offline award behavior.
#574 remains open for that independent Dolphin path;#583 need not retain the
same completed RVZ/proxy checklist. Upstream contributions remain queued in#585
underD-WORKFLOW-165 and are not a product qualification gate.


2026-10-13T04:41:09Z https://github.com/pixelelated/distribution/issues/575#issuecomment-6138380456

Source follow-up: accepted ES `c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78`, `es-app/src/SaveStateRepository.cpp` around line 211, explicitly returns false for manager support when the selected emulator is not `retroarch`. The shipped `es_savestates.cfg` likewise declares only RetroArch. Standalone Dolphin/Flycast launchers do not wire the global auto-save setting to equivalent exit/restore behavior. This explains a likely capability/expectation mismatch, not loss of ordinary game saves.

The attempted read-only Nova emulator/core-selection read timed out, so the actual selected core for the reported games is still unverified. Do not infer standalone selection merely from the platform. Next: establish selected emulator, verify per-emulator automatic-state/manual-state/manager behavior with disposable VM fixtures, and make any setting/support explanation accurately reflect that capability. A broad standalone integration is not silently promised by this diagnosis.


2026-10-14T02:37:53Z https://github.com/pixelelated/distribution/issues/575#issuecomment-6159645579

French catalog09afa is compiled and its three replacement save-capability descriptions now pass reviewed global/per-game frames at640×480 and1280×800 against ESbb9e. All four visual runners0, no game launch; final1280 settings byte-identical. Global640 changed only the documented legacy incremental0→2 normalization (D-UI-083; both consumer values mean off), while the selected auto-save preferences remained unchanged. The original raw-file cmp failure and follow-up source/readback evidence are retained.

The old rejected wrapping frames remain historical evidence. Canonical menu map now links the new reviewed frame index in local docs/qa-logs/2026-10-14-offline-components/. Source-staged UI qualification does not promote the production pin or qualify a new full image. The VM is complete and its media retired.


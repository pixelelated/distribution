## October 15 follow-up — scope remains completed

#583 is already CLOSED; retain that state and its five completed criteria. The earlier final-disposition sentence describing #584 as uncompiled is historical: installed Dolphin startup and final-image/native continuation now have separate accepted originals. This supersedes only that downstream status, not the proxy scope or any original failure.

[installed Dolphin startup originals](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-15-engineering-image-result/dolphin-installed/README.md); [final engineering artifacts and clean/retained qualification](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-15-final-engineering-result/README.md); [accepted ordinary-save evidence](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/qa-logs/2026-10-15-native-gameplay-result/README.md); [final native-state readback](https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/audits/2026_10_14-milestone-m7-next-candidate/native-state02-readback.md). No real-account award or hardware claim is added. Upstream submissions remain queued under #585.

## Owner request — October 14

> With the RVZ files, there's something we also need to adapt in RA offline proxy. We should look at that. In addition, this should already be an instruction file: we want to make sure that we're always looking for where we have a chance to submit upstream fixes.

## Current scope

#574 establishes an EmulationStation RVZ recognition/hash-reader gap. That does not establish whether RAOfflineProxy independently reads/hashes the same files, consumes ES metadata, filters RVZ or GameCube entries, or supports the resulting offline path. Trace the pinned proxy plus every local patch and current upstream before selecting an adaptation. Preserve existing offline functionality. Do not treat Dolphin's in-game achievements as proxy qualification.

D-WORKFLOW-162 already requires early upstream issue/release/fix research. Extend the existing engineering rule to require an explicit contribution disposition for fixes: component owner, minimal independent patch, existing upstream match, and public reproducible evidence. Preparing a contribution is distinct from submitting it.

Can this be done on the VM? Yes: synthetic ROM/metadata/cache fixtures can test discovery, hash handoff and preparation without owner ROMs, accounts or award submissions. Source-only investigation first; runtime needs a bounded allocation.

## Acceptance criteria

- [x] Source report binds the exact proxy pin/local patches and current upstream comparison; identifies the RVZ discovery/hash/cache path and any actual missing adaptation.
- [x] Minimal RVZ padding/scanner repairs have synthetic VM regression proof for recognized RVZ and malformed/unsupported cases while preserving existing offline behavior; original component/native/installed evidence is linked in #574 comment6181373963.
- [x] #574's combined qualification note explicitly references the completed proxy evidence and retains the separate Dolphin NoGUI initialization/gameplay limitation: https://github.com/pixelelated/distribution/issues/574#issuecomment-6181373963 .
- [x] Canonical engineering instructions require consideration of upstream contributions; decision and rule checks pass.
- [x] Each independently useful fix records its upstream target and minimal patch/test requirements, with #585 owning post-build submission follow-up or an explicit duplicate/already-fixed/fork-specific disposition. Submission itself is deferred under D-WORKFLOW-165 and is not a product qualification gate.

Related #574, #573, #570 and #581. This precedes combined M7 candidate qualification; it grants no device/cloud/account actions or upstream publication.

## Source disposition — verified local handoff

Source packet819d1c30ec6bc4d7354babecec1b84ceed960189 is imported and hash-verified locally at docs/qa-logs/2026-10-14-proxy-rvz-source/. Its exact-pin/current-main comparison confirms existing RVZ support, an unaligned-padding reader candidate, and the fork scanner’s all-zero ES hash suppression. Both minimal candidates and synthetic probe are prepared, runtime UNRUN. The current upstream reader is byte-identical at2d19684e0800f6da33ff1841d27e083c1e467142; the old Linux RVZ port#51 is already included and is not a missing fix. Padding goes to RAOfflineProxy upstream after proof; scanner policy is presently fork integration, preserving D-RA-013.

A separate source-confirmed Dolphin service/toggle routing gap is now #584. No native hashing, gameplay, award or reconnect acceptance is inferred from this report. Production source/pins remain unchanged. The instruction checkbox is backed by local coordinator commitd029982dd30b28711f3cb6cf774fc9d052675d6c and passing rules/register checks; not pushed.

## Final disposition — 2026-10-15

Root reverified original artifact hashes/results and published the combined #574 note. RVZ/proxy scope is complete; source-era UNRUN statements above remain historical. #584 owns the separately confirmed Dolphin NoGUI lifecycle defect; its integrated source repair is uncompiled and remains open. No owner award/provider acceptance or universal emulator support is inferred. Upstream submissions stay queued under#585.

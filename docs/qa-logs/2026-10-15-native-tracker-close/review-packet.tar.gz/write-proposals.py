#!/usr/bin/env python3
import pathlib,json,re,hashlib,datetime
P=pathlib.Path(__file__).resolve().parent
D='https://github.com/pixelelated/distribution/blob/feature/m7-final-qualification/docs/'
def link(title,path):return f'[{title}]({D}{path})'
installed=link('installed Dolphin startup originals','qa-logs/2026-10-15-engineering-image-result/dolphin-installed/README.md')
ordinary=link('accepted ordinary-save evidence','qa-logs/2026-10-15-native-gameplay-result/README.md')
native=link('final native-state readback','audits/2026_10_14-milestone-m7-next-candidate/native-state02-readback.md')
frames=link('native02 exact-source frame index','audits/2026_10_14-milestone-m7-next-candidate/supplements/native-state02-result/frame-index.json')
final=link('final engineering artifacts and clean/retained qualification','qa-logs/2026-10-15-final-engineering-result/README.md')
menu=link('canonical flow and support guidance','es-menu-map.md')
fmt=link('independent RVZ format proof','qa-logs/2026-10-14-independent-format-runtime/README.md')
proxy=link('native proxy protocol proof','qa-logs/2026-10-14-proxy-native-runtime/README.md')
installed_native=link('installed native hash proof','qa-logs/2026-10-14-installed-native-result/README.md')
startup=link('installed proxy startup/reconnect proof','qa-logs/2026-10-14-proxy-installed-startup-result/README.md')
routing=link('126-case routing and RVZ/scanner controls','qa-logs/2026-10-14-rvz-proxy-components/README.md')
ui=link('EN/FR capability frames at both sizes','qa-logs/2026-10-13-library-vm/README.md')
fr=link('accepted French replacement frames','qa-logs/2026-10-14-offline-components/README.md')
base=link('accepted baseline continuation','qa-logs/2026-10-15-baseline-continuation/README.md')
issues={n:json.loads((P/f'issues/{n}.json').read_text()) for n in [574,575,583,584]}
criteria={n:re.findall(r'^- \[[ x]\] (.+)$',j['body'],re.M) for n,j in issues.items()}
quotes={n:'\n'.join(x for x in j['body'].splitlines() if x.startswith('> ')) for n,j in issues.items()}
def checks(n):return '\n'.join('- [x] '+x for x in criteria[n])
common=f'''Final composition is distribution `f8636de1d105275dbf9420bbabbbc26f79abb10f` / ES `16dbac5211eea7e70db7394372033be2be7df829`. {final} binds the actual assembled products and the clean/retained runs. The build's #597 launcher-report collision remains a reporting failure with unknown original launcher wait status; successful artifact/VM results do not rewrite it.'''
body574=f'''## Completed scope — October 15

The confirmed frontend RVZ recognition defect is repaired and qualified. The independent proxy and Dolphin startup gaps are also dispositioned through #583 and #584. This does not assert that every game/variant has a RetroAchievements set or that the reported owner's account/game was authenticated.

{common}

## Owner report — October 13

{quotes[574]}

## Delivered behavior and evidence

- The original read-only installation had nine RVZ entries with failed hash sentinels/no achievement ID and matching extraction errors. The ES wrapper lacked an RVZ reader. Exact source, repaired MD5, bounded reader and independent Dolphin NONE/Zstandard format results are recorded in {fmt}; malformed/unsupported inputs remain explicit failures. No owner ROM conversion is required.
- ES/offline recognition is separate from the emulator. {routing} records proxy padding/scanner controls; {proxy} records hash/cache/account/error/signed-queue/reconnect behavior with synthetic data. {installed_native} closes the earlier native-library provenance limit: installed Python/native ISO/NONE/Zstandard RVZ return the same GameCube hash `118545082f24fc195a446d1ee7bbf816`. {startup} supplies the installed service lifecycle/reconnect proof. #583 remains completed.
- The actual standalone Dolphin package enables RA, while libretro compatibility remains separate. The default NoGUI process originally omitted AchievementManager initialization/shutdown. {installed} verifies the repaired shipped executable: enabled initialization/request/shutdown, disabled no-request, and failed-boot cleanup. The final f863 artifact and native02 guest retain exact executable SHA256 `5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5` and six pinned Sys resources. #584 records the guarded HostUrl contract; configuration alone is not treated as a successful login.
- {menu} records unchanged recognition/game-launch navigation and the distinct configuration/runtime scopes. An absent set, a valid unmatched hash, an unreadable/unsupported ROM and unsupported emulator runtime are not interchangeable diagnoses. The original owner's nine files/account were not replayed; their successful matching or awards are not asserted.

Already written: existing gamelists can contain the all-zero failed-RVZ hash sentinel. The explicit scanner can retry that exact failure; it preserves valid unmatched hashes, unrelated indexed roots, exclusions and existing automatic policy. The fix does not erase metadata, convert owner ROMs or mutate credentials/saves. Final retained upgrade preserves the selected existing state.

Can this be done on the VM? Yes. Accepted proofs used synthetic format/account/cache fixtures and the actual installed executables in disposable guests; no physical fact or owner-account action is required for these criteria.

## Acceptance criteria

{checks(574)}

## Limits and preserved history

The original sanitizer, format-container and helper-fixture failures remain failed in their packets; subsequent corrected runs have distinct originals. Synthetic loopback login deliberately fails authentication. Native Wii/Dreamcast gameplay and saves are separate accepted evidence, not GameCube achievement-award proof. No real-provider award, commercial-disc corpus, handheld or universal-format claim is made. Upstream contribution destinations remain under #585/D-WORKFLOW-165 and do not require replaying accepted tests.

The October 14/early October 15 comments saying installed Dolphin startup was uncompiled/unverified describe their original phase. The evidence above supersedes that outstanding work, without changing those original records. Close as completed after the #584 canonical-flow status paragraph is updated.
'''
body575=f'''## Completed scope — October 15

The UI now explains the supported distinction: the global AUTO SAVE/LOAD setting and frontend save-state manager apply to supported emulators/RetroArch; standalone Dolphin and Flycast use their own state facilities. Ordinary game saves remain separate. This issue delivers accurate guidance and verified existing behavior, not new standalone frontend-manager integration.

{common}

## Owner report — October 13

{quotes[575]}

## Observed behavior and exact scope

| Runtime | Ordinary game save | Manual and automatic states | Frontend manager/global preference |
| --- | --- | --- | --- |
| RetroArch | Accepted baseline exit originals show actual battery RAM written/flushed (`.srm` first byte55) on normal/debounced exit. | Existing #196 native slot-load/exit-auto evidence remains accepted; the unchanged baseline section-v launcher controls pass numbered slot, AUTO SAVE, START NEW GAME and preferences. No new RetroArch run is claimed. | Existing supported-core manager contract preserved; capability UI resolves AUTO and explicit RetroArch separately. |
| Standalone Dolphin (Wii SuDokuL) | Accepted native03 Save and Quit → cold launch/Continue preserves entered row1/column2 value4 in the same415-byte ordinary SD save. | Final native02 saves slot1, changes to a later paused scene, then visibly restores the earlier unpaused timer/board and continues; `.s01` is distinct from the ordinary save. The global setting is not wired to Dolphin's native states. | Actual installed per-game selection is Dolphin/dolphin-sa-wii; reviewed support dialog explicitly says global auto-state/manager do not apply. |
| Standalone Flycast (Dreamcast Tetris2) | Accepted native03 earns/saves score164 into the VMU and shows it after cold launch. | Final native02 verifies manual save/load. With global On/native auto Off, normal exit preserves the manual file/hash/time. With global Off/native save+load On, normal exit saves a different scene; cold launch4 restores exactly that scene before any pad/manual-Load input. | Actual selected Flycast/flycast-sa and native settings are recorded; native automatic states do not become ES global integration or a frontend-manager tile. |

Evidence: {ordinary}; {native}; {frames}; {base}; {ui}; {fr}; {menu}. Native02 run `20261015T044138Z-77958d6d`, admission `d739030019bc445bae908b3ca6dd6b48`, is consumed with original command/monitor/runner0. The131KB VMU and Wii SD content witnesses are the earlier ordinary-save proof; native02 is the focused state continuation, not a repeated ordinary-save test.

The first native-state attempt remains an original fixture failure before gameplay. Native03's export-wrapper1 and partial manual-state observations remain unchanged; its independently verified ordinary-save acceptance is separate. Native02 provides the previously missing completed state observations. Child exit wait status is not invented where ES/systemd owned the process; normal UI return, process absence and the original runtime/export channels are the recorded evidence.

Already written: existing automatic-state preferences, game saves, memory cards/VMUs and native state files remain preserved. Capability help is informational and does not silently change a preference. The final clean/retained runs verify installed composition and selected storage preservation; the earlier640 legacy incremental0→2 equivalent-Off normalization is explicitly retained, not presented as byte identity.

Can this be done on the VM? Yes. Existing accepted RetroArch proofs plus licensed homebrew/native states and exact-source EN/FR640×480/1280×800 UI frames provide the required observations without owner games/accounts. The failed original read of the Nova selected core remains unknown; the VM's actual selection/settings are bound and no owner configuration is inferred.

## Acceptance criteria

{checks(575)}

Criterion4 takes its explicit limitation route: no new standalone automatic/manager integration is proposed. Any future integration would need its own slot/path/preservation/hardcore acceptance. No extra GC memory-card/NAND, physical handheld, sudden-power or account-award matrix is added to this issue. Source continuity and final installed evidence retain the accepted prior results; close as completed.
'''
body584=f'''## Completed scope — October 15

The launcher now routes enabled, non-hardcore Dolphin sessions to the available local offline service, and the shipped NoGUI process initializes/shuts down achievements. Installed service, native HostUrl interpretation and final composition are verified separately. This is not a claim of a successful real-account Dolphin award.

{common}

## Owner context — October 14

{quotes[584]}

## Source contract and delivered proof

The old helper read only customhost, while packaged `run-service` bypassed upstream's emulator configuration patcher. The correction preserves customhost unless the saved proxy toggle is exactly1, raw hardcore exactly0 and a read-only IPv4-capable listener predicate succeeds. It never changes saved credentials/customhost/hardcore. Listener presence is a routing predicate, not proof of listener identity or readiness.

{routing} records126 full-script controls for toggle/hardcore/customhost/listener/missing-account/disabled cases and unchanged input settings. Upstream ROCKNIX PR3038 and proxy PR50 were compared; the distro service/toggle contract is the distinct gap. Contribution disposition remains under #585.

{proxy} verifies synthetic hashing, cache/account separation, signed offline queue, errors and reconnect; {installed_native} binds current shipped native hash inputs; {startup} verifies actual installed service startup/stop/reconnect/queue preservation and worker shutdown. Their original scope limits remain, including the earlier old-image native provenance limit subsequently supplied by the installed result.

The independent NoGUI defect and repair have actual installed process evidence in {installed}: enabled live CPU/init1/request1/shutdown1; disabled live CPU/init0/request0; absent boot file original native exit1 with init/shutdown1. The request is a synthetic invalid-login POST to `127.0.0.1:8080/dorequest.php`. No private executable substitution was used in the installed proof. The final f863 artifact and native02 guest carry the identical shipped binary `5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5`, pinned six-resource Sys mapping and unchanged engine lifecycle patch. All four prior badge-load errors were absent.

Final clean/retained tests run the installed helper and exact launcher block for four enabled/disabled/logged-out transitions, using an explicit engine marker. They prove session publication/refusal and preservation, not a live emulator login. The separately accepted native03 ordinary saves and native02 manual/automatic states use actual engines with achievements off; they do not stand in for RA routing. {menu} names these independent flows and limits.

Already written: an earlier active generated Dolphin INI could survive disabled/missing-account launches. #594 now atomically publishes an inactive session and clears generated credentials, preserving saved global account settings; publication failure refuses launch instead of reusing old active settings. Final installed clean/retained controls and EN/FR refusal/return frames are accepted independently. Existing save-path protection remains intact.

Can this be done on the VM? Yes. Full-script controls, installed service and emulator lifecycle use synthetic settings/loopback fixtures in disposable no-NIC guests. No owner account/provider action or physical gameplay is required for this integration scope.

## Acceptance criteria

{checks(584)}

## Limits and historical results

The routing fixture's original missing `/proc/.../children` failure, original installed NoGUI defect and later unrelated fixture failures remain preserved. The expected failed-boot native exit1 remains1. Earlier comments describing the repair as uncompiled or installed proof pending are superseded by the accepted installed run and final image binding. No production authentication/award, generic libretro support, sudden-power safety or handheld result is inferred. Close as completed after publishing the canonical-flow status correction alongside this body and #574's combined disposition.
'''
# Preserve the already completed issue and original dated history. No reopen/change of title.
body583='''## October 15 follow-up — scope remains completed

#583 is already CLOSED; retain that state and its five completed criteria. The earlier final-disposition sentence describing #584 as uncompiled is historical: installed Dolphin startup and final-image/native continuation now have separate accepted originals. This supersedes only that downstream status, not the proxy scope or any original failure.

'''+f'{installed}; {final}; {ordinary}; {native}. No real-account award or hardware claim is added. Upstream submissions remain queued under #585.\n\n'+issues[583]['body']
for n,b in [(574,body574),(575,body575),(583,body583),(584,body584)]:
 (P/f'proposed-{n}-body.md').write_text(b)
# Exact replacement text for the stale paragraph, root owns shared edit.
paragraph=f'''The [NoGUI lifecycle repair](qa-logs/2026-10-15-dolphin-nogui-lifecycle/README.md)
adds the missing AchievementManager initialization/shutdown. The
[compiled candidate and actual-process proof](qa-logs/2026-10-15-dolphin-startup-result/README.md)
reproduced the installed baseline defect. The later
[actual installed startup proof](qa-logs/2026-10-15-engineering-image-result/dolphin-installed/README.md)
passed enabled, disabled and early boot-failure branches with the shipped executable
and all six pinned Sys resources. One synthetic failed-login request reaches the
configured loopback endpoint in each enabled case; the disabled case sends none.
The final f863 image and native-state guest retain that exact executable
`5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5`.
No ES copy/layout changed in the lifecycle repair; the exercised nonvisual flow
is NoGUI startup/configuration and shutdown, with existing launch frames as its
presentation reference. [Ordinary native saves](qa-logs/2026-10-15-native-gameplay-result/README.md)
and [final manual/automatic-state observations](audits/2026_10_14-milestone-m7-next-candidate/native-state02-readback.md)
are separately accepted with achievements off. Final clean/retained helper
controls prove session publication and preservation with an explicit engine marker.
Listener presence alone does not establish proxy identity/readiness, and the
synthetic login is not successful real-account authentication or an award.
'''
(P/'proposed-menu-map-paragraph.md').write_text(paragraph)
comments={
574:f'''Completed the combined recognition disposition on f8636de1 / ES16dbac. Independent RVZ/frontend and installed native/proxy evidence qualify the repaired recognition path; #583 stays completed. {installed} closes the separate missing NoGUI startup lifecycle, with the exact binary retained in the final image. {final} and {native} bind final composition without re-running accepted format/proxy cases. No owner-library matching, real-account award or hardware claim is made; historical failures retain their original status. The updated body and canonical flow distinguish those scopes. Closing as completed; upstream follow-up remains #585.''',
575:f'''Completed the remaining native-state observations on actual installed f8636de1 / ES16dbac. {native} / {frames}: Dolphin manual restore, Flycast manual restore, global-On/native-Off preserved manual state and global-Off/native-On automatic save/cold restore before input. Earlier {ordinary} remains accepted and was not repeated. Existing RetroArch evidence and {base} remain their original scope. No standalone manager integration is promised; explicit support guidance, existing preferences and clean/retained preservation are recorded. Closing as completed; original Nova core selection remains unknown, not inferred.''',
584:f'''Completed the installed/runtime remainder: {installed} shows enabled/disabled/failed-boot lifecycle and exact loopback HostUrl use by the shipped Dolphin NoGUI executable. Final f863 retains the same binary/resources; {final} adds installed clean/retained helper publication/preservation. Earlier proxy service/cache/queue/reconnect proof is accepted separately. The canonical flow now removes the stale pending-startup sentence and retains the failed synthetic-login/no-real-award limit. Closing as completed; #583 stays completed and #585 owns upstream follow-up.''',
583:f'''Status clarification only; this issue stays closed. Its RVZ/scanner/proxy criteria remain accepted. The older closing note's “#584 repair uncompiled” sentence is historical: {installed} and {final} now provide the separate installed Dolphin/final-image evidence. No proxy replay or real-account award claim is added. #585 remains the upstream contribution follow-up.'''}
for n,b in comments.items():(P/f'proposed-{n}-comment.md').write_text(b+'\n')
criteria_result={str(n):{'captured_state':issues[n]['state'],'captured_updated_at':issues[n]['updatedAt'],'recommendation':'keep_closed' if n==583 else 'close_completed','criteria':[{'number':i+1,'exact_current_text':s,'disposition':'supported within recorded scope'} for i,s in enumerate(criteria[n])],'remaining_action':('No issue-state action; optional dated supersession note only.' if n==583 else 'Publish updated body/comment; no new runtime test.'),'not_claimed':['owner account or game success','physical-device acceptance','new standalone frontend manager integration']} for n in issues}
criteria_result['574']['remaining_action']='Root updates stale #584 canonical flow status and publishes combined disposition; then close completed.'
criteria_result['584']['remaining_action']='Root replaces stale canonical paragraph with supplied text, publishes combined disposition; then close completed.'
(P/'criteria.json').write_text(json.dumps(criteria_result,indent=2)+'\n')
(P/'recommendations.md').write_text(f'''# Tracker reconciliation — read-only recommendation, 2026-10-15

Recommend **close #574, #575 and #584 as completed**, and **keep #583 closed**. There is no additional runtime/test requirement identified for these scoped issues. Root owns final tracker/shared-document actions. This packet made none.

## One concrete documentation action

`docs/es-menu-map.md`, “Offline achievements → Dolphin routing (#584)”, still says final installed-image smoke and normal gameplay/save proof remain open. Replace the paragraph beginning “The [NoGUI lifecycle repair]” with `proposed-menu-map-paragraph.md`, then publish the corresponding bodies/comments. This closes the documentation criterion; do not re-run any accepted test to remove stale wording. The save-state guidance section is already updated by root. #590/#596 are outside this assignment.

## Why the criteria now resolve

- #574: exact source/installed standalone support, independent RVZ/frontend/MD5 and proxy hash evidence, controlled defect regressions and explicit unmatched/unsupported/absent-set distinctions. The only old independent-Dolphin remainder is now covered by installed startup and identical final executable, without claiming a real award.
- #575: actual selected Wii/Dreamcast runtime/settings, separately accepted ordinary saves, completed manual-state and Flycast automatic/cold-load observations, accepted RetroArch native history plus current baseline section-v and exit originals, reviewed EN/FR/both-size capability help and final clean/retained preservation. Criterion4 uses the explicit limitation route; no new standalone manager/automatic integration was proposed. The original Nova selection remains unknown and is not inferred from system name.
- #583: was already closed when read. Its five criteria remain complete; only the historical downstream #584 status could receive a dated clarification. No title/state change or repeated proxy test.
- #584:126 routing controls plus installed proxy lifecycle and actual Dolphin HostUrl/startup proof; identical final engine, six Sys resources and separate final installed session controls. The original real-account/offline-award boundary remains explicit.

## Independent evidence readback

`evidence-readback.json` records48 exact compact originals and their original paths/hashes,1363 native02 archive members rehashed against the exact manifest,188 installed-Dolphin members rehashed and45 ordinary-save supplement members rehashed. Thirteen exact native02 PNGs were viewed; manual restored frames are beyond the decompression overlay, and automatic scene C/cold-first frame bytes are equal. Native02 receipt `d739030019bc445bae908b3ca6dd6b48` is consumed, original command/monitor/runner0. The copied `root-review.json` is coordinator evidence, distinct from this readback.

Final installed Dolphin SHA `5cb5dacafbcd2227627ef687a65318e61890ef343e5c6553f07c0fb11231fea5` matches the accepted installed-startup binary. Final SYSTEM is `2c69f6533629244edef4ec2405bfaaf438f507451733ae955be7eefe7ffeb1cf`. Final artifact original is PASS for109 products, sourcef863/ES16dbac, explicitly `runtime_qualified:false`; booted runs supply their own runtime claims. Clean/retained seals from earlier independent retention are `9234c8c78494c2d036f493102528adf33b87da07e1b53f5f51843586b66530f0` and `7a8a8ed041c200b94096605600a6dddc77652a59caa772367e9a7a828509330f`.

Source continuity was read, not executed: d6a→f863 proxy source diff is empty; fac608→f863 RetroArch/runemu source diff is empty. d4af→f863 Dolphin/Flycast diff is only Dolphin session publication/launcher status handling; ordinary save-path helper, engine recipe/lifecycle patch and Flycast are unchanged. Final installed source mappings and the native guest bind the emitted bytes; no whole-image/cache hash was repeated.

## Limits retained

- No owner ROM/account mutation, physical handheld, real-provider award, commercial-disc corpus, GC card/NAND extension or abrupt-power proof. These are not silently added as closure gates.
- Native03 ordinary-save acceptance keeps its failed export wrapper1 and partial state results. Native-state01 fails before game; native02 supplies separate state results. Historical source-era UNRUN fields remain historical.
- #597's observed launcher-report failure and unknown original launcher wait stay distinct from original build runner0 and later successful readback/VM channels. No recovered launcher success is invented.
- Native ES/systemd-owned emulator wait statuses remain unknown where no original waiter existed; normal UI return/process absence are evidence, not invented exit codes. The installed three-case startup tool did own and retain its original native0/0/1.
- Flycast exit4 legitimately rewrites its automatic state after the accepted pre-input cold-restore comparison. Its final file is not falsely required to equal launch3's state.
- Existing accepted baseline/RetroArch rows retain their original fac608/history source scope. This review is not a new full-suite result on f863.
- `proposed-583-body.md` is optional additive status clarification; its dated history remains verbatim. The recommended minimum is no body/state mutation for that already-closed issue, optionally the short follow-up comment.

## Deliverables and application

`proposed-N-body.md` and `proposed-N-comment.md` are concrete reviewable GitHub text. They use the coordinator feature branch for current evidence links; root should publish the referenced native02/canonical records first or replace those links with the chosen published commit. Bodies preserve the owner quotes exactly and each current acceptance-criterion sentence exactly, marking the now-supported criteria complete. `criteria.json` maps the captured states and actions. `issues/` preserves exact current bodies and all comments from the read-only GitHub capture; an initial connection failure is retained separately.

No GitHub mutation command was run. No preparer, test payload, compiler, VM, service, admission or registry operation was run. No shared files, source code, git index or commits were changed. The only executable local operations were data-only archive/JSON/hash reads and packet writing under this assigned temporary directory.
''')
# Bind exact current published/read docs, without copying their large payloads.
refs=['docs/es-menu-map.md','docs/qa-logs/2026-10-14-independent-format-runtime/README.md','docs/qa-logs/2026-10-14-chd-native-runtime/README.md','docs/qa-logs/2026-10-14-rvz-proxy-components/README.md','docs/qa-logs/2026-10-14-proxy-native-runtime/README.md','docs/qa-logs/2026-10-14-installed-native-result/README.md','docs/qa-logs/2026-10-14-proxy-installed-startup-result/README.md','docs/qa-logs/2026-10-15-engineering-image-result/dolphin-installed/README.md','docs/qa-logs/2026-10-15-native-gameplay-result/README.md','docs/qa-logs/2026-10-15-baseline-continuation/README.md','docs/qa-logs/2026-10-13-library-vm/README.md','docs/qa-logs/2026-10-14-offline-components/README.md','docs/vm-qa-log.md','docs/audits/2026_10_14-milestone-m7-next-candidate/native-state02-readback.md']
C=pathlib.Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
(P/'reference-identities.json').write_text(json.dumps([{'path':str(C/r),'sha256':hashlib.sha256((C/r).read_bytes()).hexdigest(),'bytes':(C/r).stat().st_size} for r in refs],indent=2)+'\n')
# Static text contract only: no fixture/test invocation.
for n in issues:
 b=(P/f'proposed-{n}-body.md').read_text()
 assert all(q in b for q in quotes[n].splitlines())
 assert all('- [x] '+c in b for c in criteria[n])
 assert len(re.findall(r'^- \[x\]',b,re.M))==len(criteria[n])
print(json.dumps({'written_bodies':list(issues),'exact_owner_quotes_and_criteria_preserved':True,'runtime_executed':False}))

#!/usr/bin/env python3
"""One observed native/ES action under the lifecycle's exact shared serial lock."""
import argparse,fcntl,hashlib,json,os,re,shlex,signal,struct,subprocess,time,uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('operation',choices=['status','launch','pad','key','capture','review','snapshot','global-auto','native-auto','score-start','score-end','finish','abort'])
p.add_argument('--owner',type=Path,required=True);p.add_argument('--game',choices=['wii','tetris2']);p.add_argument('--buttons');p.add_argument('--milliseconds',type=int,default=120);p.add_argument('--key');p.add_argument('--label');p.add_argument('--copy-sd',action='store_true');p.add_argument('--value',choices=['0','1']);p.add_argument('--review');p.add_argument('--first-frame',action='store_true');a=p.parse_args()
R=a.owner.resolve(strict=True);C=json.loads((R/'config.json').read_text());TREE=Path(C['checkout']);ready=json.loads((R/'visual-ready.json').read_text());pending=None
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):
 q=p.with_suffix('.pending');q.write_text(json.dumps(v,indent=2)+'\n');os.replace(q,p)
assert time.monotonic()<ready['deadline_monotonic'] and not (R/'visual-result.json').exists()
for name,digest in C['code'].items():assert sha(R/name)==digest
for name,digest in C['tools'].items():assert sha(Path(name))==digest
with (R/'serial.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 inv=R/'frames'/(time.strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]);inv.mkdir()
 def execute(label,argv,seconds=30):
  row={'argv':list(map(str,argv)),'original_returncode':None,'timed_out':False}
  with (inv/(label+'.stdout')).open('xb') as out,(inv/(label+'.stderr')).open('xb') as err:
   child=subprocess.Popen(row['argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
   try:row['original_returncode']=child.wait(timeout=seconds)
   except subprocess.TimeoutExpired:row['timed_out']=True;os.killpg(child.pid,signal.SIGKILL);row['original_returncode']=child.wait(timeout=5)
  save(inv/(label+'.json'),row);assert row['original_returncode']==0 and not row['timed_out'],'stop; preserve ambiguous original action'
  return (inv/(label+'.stdout')).read_text()
 def guest(words,seconds=30):
  tag='PIX_GAMEPLAY_EXIT_'+uuid.uuid4().hex;command=shlex.join(['python3','-I','-S','-B','/tmp/pix-input/gameplay/packet/guest.py',*words])+'; pxrc=$?; printf "\\n'+tag+'=%s\\n" "$pxrc"'
  text=execute('guest',[TREE/'tools/vm-serial','--socket',R/'vm/serial.sock','--timeout',str(seconds),'sh',command],seconds+7)
  assert re.findall(r'^'+tag+r'=([0-9]+)\r?$',text,re.M)==['0']
  values=re.findall(r'^PIX_GAMEPLAY_JSON=(.*)\r?$',text,re.M);assert len(values)==1;return json.loads(values[0])
 if a.operation=='launch':
  assert a.game;claim={'game':a.game,'host_monotonic_before':time.monotonic(),'time':time.time()};save(inv/'launch-claim.json',claim)
  result=guest(['launch','--game',a.game]);claim['guest']=result;save(R/'last-launch.json',claim);print(json.dumps(claim))
 elif a.operation=='pad':
  assert a.buttons;print(json.dumps(guest(['pad','--buttons',a.buttons,'--milliseconds',str(a.milliseconds)])))
 elif a.operation=='key':
  # Keyboard is for the installed ES UI only; native game actions use pad.
  state=guest(['status']);assert not state['native_processes']
  lines=re.findall(r'^PIX_GAMEPLAY_JSON=(.*)\r?$',(R/'qa-serial.txt').read_text(),re.M);assert len(lines)==1;provision=json.loads(lines[0]);key=provision['input_keys'][a.key]
  save(inv/'key-claim.json',{'action':a.key,'qemu_key':key});execute('key',[TREE/'tools/vm-visual-qa','--monitor',R/'vm/monitor.sock','key',key])
 elif a.operation=='capture':
  assert a.label and re.fullmatch('[a-z0-9-]{1,60}',a.label)
  frame=inv/(a.label+'.png');execute('shot',[TREE/'tools/vm-visual-qa','--monitor',R/'vm/monitor.sock','shot',frame])
  raw=frame.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('!II',raw[16:24])==(640,480)
  row={'path':str(frame),'sha256':sha(frame),'label':a.label,'captured_host_monotonic':time.monotonic(),'time':time.time(),'observation':'unreviewed'}
  if a.first_frame:
   launch=json.loads((R/'last-launch.json').read_text());row['launch']=launch;row['first_observed_frame_upper_bound_seconds']=row['captured_host_monotonic']-launch['host_monotonic_before'];assert row['first_observed_frame_upper_bound_seconds']<=120;row['guest_capture_ack']=guest(['first-frame','--label',a.label])
  save(R/'frames'/(a.label+'-capture.json'),row);print(str(frame))
 elif a.operation=='review':
  assert a.label and a.review and len(a.review)<=3000
  row=json.loads((R/'frames'/(a.label+'-capture.json')).read_text());assert sha(Path(row['path']))==row['sha256'];row['review']=a.review;row['observation']='personally reviewed';save(R/'frames'/(a.label+'-review.json'),row)
 elif a.operation=='finish':
  result=guest(['finish'],seconds=40);assert result['rc']==0 and not result['forced_cleanup'] and not result['native_processes_at_end']
  reviews=[json.loads(f.read_text()) for f in sorted((R/'frames').glob('*-review.json'))]
  for row in reviews:assert sha(Path(row['path']))==row['sha256']
  pending={'guest':result,'reviews':reviews,'acceptance':'root reviews gameplay and native-save claims separately; no automatic criterion completion'}
 elif a.operation=='abort':
  try:print(json.dumps(guest(['abort','--label',a.label or 'operator-abort'])))
  finally:(R/'abort').write_text((a.label or 'operator-abort')+'\n')
 else:
  words=[a.operation]
  if a.label:words+=['--label',a.label]
  if a.value is not None:words+=['--value',a.value]
  if a.copy_sd:words+=['--copy-sd']
  print(json.dumps(guest(words),indent=2))
# Existing successful ownership handoff: publish complete bytes only after lock release.
if pending is not None:save(R/'visual-result.json',pending)

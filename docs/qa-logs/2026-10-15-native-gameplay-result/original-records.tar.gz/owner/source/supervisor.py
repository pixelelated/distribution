#!/usr/bin/env python3
"""Own the reused guest pad; preserve original exit, observe existing native owners."""
import json,os,signal,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from guest import R,identity,natives,pad,save
remaining=int(sys.argv[1]);assert 60<remaining<=1800
result={'rc':1,'pad_original_returncode':None,'forced_cleanup':False,'native_exit_status':'unknown; existing ES/systemd owns native children'};child=None;deadline=time.monotonic()+remaining
def expired(*_):raise TimeoutError('original gameplay allocation deadline or interruption')
signal.signal(signal.SIGTERM,expired);signal.signal(signal.SIGALRM,expired);signal.alarm(remaining)
try:
 with (R/'pad.stdout').open('xb') as out,(R/'pad.stderr').open('xb') as err:
  child=subprocess.Popen(['python3','-I','-S','-B',str(HERE/'pad.py')],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);result['pad']=identity(child.pid)
  while not (R/'finish.json').exists():
   assert child.poll() is None,'pad exited early';assert time.monotonic()<deadline;assert not (R/'abort.json').exists(),'operator abort'
   if (R/'active-launch.json').exists():
    launch=json.loads((R/'active-launch.json').read_text());assert (R/('first-frame-'+launch['id']+'.json')).exists() or time.monotonic()-launch['before_monotonic']<=120,'first observed game frame exceeded120s'
   sizes=[(f,f.stat().st_size) for f in R.rglob('*') if f.is_file()];assert sum(s for _,s in sizes)<=448*1024**2,'448MiB guest evidence bound (plus64MiB host =512MiB)'
   assert all(s<=16*1024**2 for f,s in sizes if f.suffix in ('.stdout','.stderr','.log','.jsonl')),'named log bound'
   with (R/'process-observations.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'native_processes':natives()})+'\n')
   time.sleep(1)
  assert not natives();pad(quit=True);result['pad_original_returncode']=child.wait(timeout=5);assert child.returncode==0
  assert json.loads((R/'pad-result.json').read_text())['rc']==0;result['rc']=0
except BaseException as exc:result['error']=type(exc).__name__+': '+str(exc)
finally:
 signal.alarm(15)
 if child is not None and child.poll() is None:
  result['forced_cleanup']=True;os.killpg(child.pid,signal.SIGTERM)
  try:result['pad_original_returncode']=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);result['pad_original_returncode']=child.wait(timeout=2)
 result['native_processes_at_end']=natives();result['ended']=time.time();signal.alarm(0);save(R/'supervisor-result.json',result)
raise SystemExit(result['rc'])

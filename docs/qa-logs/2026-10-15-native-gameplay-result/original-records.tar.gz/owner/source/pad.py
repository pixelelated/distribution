#!/usr/bin/env python3
"""UNRUN derivative of qualified QA521 guest Xbox constructor; bounded actions."""
import fcntl,json,os,pathlib,select,signal,struct,time
base=pathlib.Path('/tmp/pix-output/gameplay');fifo=base/'pad.commands';log=base/'pad.events.jsonl'
fd=os.open('/dev/uinput',os.O_WRONLY|os.O_NONBLOCK)
def ioctl(n,v):fcntl.ioctl(fd,n,v)
for event in (1,3):ioctl(0x40045564,event)
keys=[304,305,307,308,310,311,314,315,316,317,318]
for key in keys:ioctl(0x40045565,key)
axes=[0,1,2,3,4,5,16,17]
for axis in axes:ioctl(0x40045567,axis)
hi=[0]*64;lo=[0]*64;fuzz=[0]*64;flat=[0]*64
for axis in axes:
 hi[axis]=1 if axis in (16,17) else 255 if axis in (2,5) else 32767
 lo[axis]=-1 if axis in (16,17) else 0 if axis in (2,5) else -32768
 flat[axis]=0
raw=struct.pack('80sHHHHI',b'QA521 Synthetic Xbox 360 Controller',3,0x045e,0x028e,0x0114,0)+struct.pack('256i',*(hi+lo+fuzz+flat));assert len(raw)==1116
os.write(fd,raw);ioctl(0x5501,0)
def event(kind,code,value):
 now=time.time();seconds=int(now);os.write(fd,struct.pack('llHHi',seconds,int((now-seconds)*1e6),kind,code,value))
def sync():event(0,0,0)
def save(path,value):
 tmp=path.with_suffix('.pending');tmp.write_text(json.dumps(value,indent=2)+'\n');os.replace(tmp,path)
def record(x):
 with log.open('a') as f:f.write(json.dumps({'time':time.time(),**x})+'\n')
def stop(*_):raise TimeoutError('pad interrupted; original failure retained')
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGALRM,stop);signal.alarm(1800)
mapping={'a':(1,304,1),'b':(1,305,1),'x':(1,307,1),'y':(1,308,1),'lb':(1,310,1),'rb':(1,311,1),'back':(1,314,1),'start':(1,315,1),'guide':(1,316,1),'lt':(3,2,255),'rt':(3,5,255),'up':(3,17,-1),'down':(3,17,1),'left':(3,16,-1),'right':(3,16,1)}
result={'rc':1,'created':time.time(),'constructor':'unchanged QA521 Xbox360 045e:028e:0114'};pipe=None;seen=set()
try:
 for axis in axes:event(3,axis,0)
 sync();os.mkfifo(fifo,0o600);pipe=os.open(fifo,os.O_RDWR|os.O_NONBLOCK)
 save(base/'pad-ready.json',{'pid':os.getpid(),'mapping':mapping,'name':'QA521 Synthetic Xbox 360 Controller'})
 record({'state':'created','vendor':'045e','product':'028e'})
 pending=b'';done=False
 while not done:
  if not select.select([pipe],[],[],1)[0]:continue
  pending+=os.read(pipe,4096);assert len(pending)<8192
  while b'\n' in pending:
   line,pending=pending.split(b'\n',1);q=json.loads(line);ident=q['id'];assert len(ident)==32 and ident.isalnum() and ident not in seen;seen.add(ident)
   if q['operation']=='quit':done=True;record(q);break
   assert q['operation']=='press' and 40<=q['milliseconds']<=1000 and 1<=len(q['buttons'])<=3
   assert len(q['buttons'])<3 or q['buttons']==['lb','back','start'];events=[mapping[n] for n in q['buttons']];assert len({(e[0],e[1]) for e in events})==len(events)
   for kind,code,value in events:event(kind,code,value);sync()
   time.sleep(q['milliseconds']/1000)
   for kind,code,value in reversed(events):event(kind,code,0);sync()
   time.sleep(.1);record(q);save(base/('pad-ack-'+ident+'.json'),{'rc':0,**q,'released':True})
 result['rc']=0
except BaseException as exc:result['error']=type(exc).__name__+': '+str(exc)
finally:
 signal.alarm(0)
 try:
  for key in keys:event(1,key,0)
  for axis in axes:event(3,axis,0)
  sync();ioctl(0x5502,0);record({'state':'destroyed'})
 finally:
  os.close(fd)
  if pipe is not None:os.close(pipe)
  if fifo.exists():fifo.unlink()
  result['ended']=time.time();save(base/'pad-result.json',result)
raise SystemExit(result['rc'])

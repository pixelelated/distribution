#!/usr/bin/env python3
"""Static byte inspection only: never execute or emit the decoded SH-4 binary."""
import hashlib
import json
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(data).hexdigest() == '065db55aab9b166f2a690654e906d62d9c839805cb7fd57fd3ffe900580f16b8'
out = bytearray(len(data))
seed = len(data) & 65535
remaining, pos, chunk = len(data), 0, 2 * 1024 * 1024
# Read-only permutation from KOS utils/scramble/scramble.c load_file/load_chunk.
while chunk >= 32:
    while remaining >= chunk:
        indices = list(range(chunk // 32))
        offset = 0
        for i in range(len(indices) - 1, -1, -1):
            seed = (seed * 2109 + 9273) & 0x7fff
            replacement = (((seed + 0xc000) & 65535) * i) >> 16
            indices[i], indices[replacement] = indices[replacement], indices[i]
            dest = pos + 32 * indices[i]
            out[dest:dest + 32] = data[pos + offset:pos + offset + 32]
            offset += 32
        pos += chunk
        remaining -= chunk
    chunk //= 2
out[pos:] = data[pos:]
assert out[:10].hex() == '2dd0020112202bd00e40'
assert hashlib.sha256(out).hexdigest() == '0bb92fd62cb77c32e7c7efa16b7591886b62aae25b534748b4f884246e6c3f31'
print(json.dumps({
    'input_sha256': hashlib.sha256(data).hexdigest(),
    'decoded_sha256': hashlib.sha256(out).hexdigest(),
    'decoded_first_five_instructions': [
        'd02d: mov.l @(disp=0xb4,pc),r0; target binary+0xb8 (old_sr address)',
        '0102: stc sr,r1', '2012: mov.l r1,@r0',
        'd02b: mov.l @(disp=0xac,pc),r0; target binary+0xb4 (initial SR)',
        '400e: ldc r0,sr'],
    'old_sr_address_literal': hex(int.from_bytes(out[0xb8:0xbc], 'little')),
    'initial_sr_literal': hex(int.from_bytes(out[0xb4:0xb8], 'little')),
    'finding': 'Author BIN is scrambled; retain exact original and pass mkdcdisc -B',
    'runtime': 'UNRUN; decoded bytes discarded, not staged'
}, indent=2))

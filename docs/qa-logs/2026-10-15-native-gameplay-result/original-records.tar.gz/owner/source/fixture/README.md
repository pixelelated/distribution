# Minimal native save fixture handoff

Source-only preparation for existing #581/#575 installed-image qualification.
No emulator, VM, service, compiler, input injection, SD image creation or disc
authoring has run. The accepted #566 exports are unchanged. This adds no build
or release gate. Can this be done on the VM? **Yes**: the eventual admitted
GENERIC_X64 guest with disposable storage, no NIC/accounts and one engine at a
time. The coordinator owns the live issue declaration and runtime allocation.

This narrows the canonical `2026-10-14-native-homebrew-fixtures` and
`2026-10-14-native-homebrew-save-lookup` packets to two ordinary game-save cases:

| Case | Native route | Ordinary save | Required observation |
|---|---|---|---|
| Wii SuDokuL v1.5 | dolphin / dolphin-sa-wii | SD `/apps/SuDokuL/save.bin` in the selected 128 MiB image | Earn one visible editable-cell change, save from pause, cold launch/Continue restores the same puzzle and cell; extracted save bytes changed |
| Dreamcast Tetris 2 | flycast / flycast-sa | VMU `tetris2.sys`, port A1 | Earn a score above the initial tenth-place 100, game over, explicit VMU Save, cold relaunch restores that score; VMU bytes changed |

The Wii save is SD storage, not NAND or a GC memory card. No GC ordinary-save
claim is made from unsupported SDGecko. Native manual states, native automatic
states and ES manager availability remain distinct existing #575 observations;
reuse these same game launches where practical rather than adding games/suites.
Recording-engine #581 preservation remains its original evidence, not gameplay.

## Prepared bytes and licenses

`inputs.json` binds 60 prepared files, 11,917,194 bytes, currently at
`/tmp/m7-native-save-fixture-20261014/payload`. The only new game downloads were
the 54 Tetris assets, 5,084,090 bytes, each verified against its pinned Git blob
and now SHA256-bound in `tetris2-assets.json`. Wii and both boot binaries reuse
the previously downloaded exact author artifacts. No commercial disc/BIOS was
downloaded. `licenses/` travels with the fixture bundle.

- [SuDokuL v1.5](https://github.com/Mode8fx/SuDokuL/releases/tag/v1.5), source
  `f5993339c0e245c3cf52a26ac614309b199eb8c6`, original code MIT with embedded
  music credits retained. Wii DOL SHA256
  `e4fc81977b527538d7fa8d6427099c21c0f2502d18b81a58134f8f07416a8455`.
- [Tetris 2 author tree](https://github.com/vg132/dreamcast-tetris-2/tree/1390da9766a835c3ee62aabba770acee9f2e68fa),
  BSD-3-Clause, precompiled `1ST_READ.BIN` SHA256
  `065db55aab9b166f2a690654e906d62d9c839805cb7fd57fd3ffe900580f16b8`,
  author `IP.BIN` SHA256
  `ed98b488a9f139b804e99387e25508432c7f9dd27208c1cb33ad5b8c5f8ef019`.
  The original binary remains unchanged; no reproducible rebuild equivalence
  is claimed. The game BSD license accompanies its author-distributed binary;
  the separate common-library source is inspected, not rebuilt or redistributed.

Data-only staging (fresh output required):

```sh
python3 -I -S -B materialize.py --out /tmp/m7-native-save-staged-01
```

This verifies every source byte before copying. Keep the source payload and
licenses until the installed proof is consumed. It stages no Dreamcast disc.

## Precise remaining Dreamcast preparation

There is no author GitHub release/disc in the inspected release list/tree, and
no admitted `mkdcdisc` executable has been located. No tool installation or
compilation was attempted while the engineering build owns runtime. The needed
tool is [mkdcdisc source 2b98b0d9](https://gitlab.com/simulant/mkdcdisc/-/tree/2b98b0d9480e364e3517355648fbc3b49fb19882),
MIT tool plus its documented linked-library licenses. A later small, admitted
host-native tool build is the precise remaining preparation task; it does not
depend on changing/rebuilding Tetris or the firmware.

The old packet's unresolved scrambling choice is now resolved statically.
`inspect-tetris-boot.py` applies the pinned KOS/Flycast data permutation in
memory; decoded first instructions save SR then install initial SR, matching
the KOS startup sequence. Its fixed decoded hash is in `boot-static-result.json`.
The decoded binary is neither written nor executed. Select **`-B`**, preserving
the exact scrambled author binary. Renaming raw BIN to ELF is not a loader route:
the pinned Flycast selects NAOMI for `.bin`, while the game needs `/cd` assets.

After an admitted tool build has a recorded executable hash and original exit,
the exact future packaging command is:

```sh
"$MKDCDISC" -B /tmp/m7-native-save-staged-01/1ST_READ.BIN \
  -D /tmp/m7-native-save-staged-01/tetris2-disc \
  -p /tmp/m7-native-save-staged-01/IP.BIN \
  -o /tmp/m7-native-save-staged-01/Tetris2-M7.cdi
(cd /tmp/m7-native-save-staged-01 && sha256sum Tetris2-M7.cdi > Tetris2-M7.cdi.sha256)
```

The pinned CLI documents `-B` scrambled, `-D` contents, `-p` author bootstrap.
Use normal CDI padding, at most 1 GiB authoring scratch, one 120-second authoring
stage, 1 CPU/1 GiB bound, original status retained. Stop on a failure; no flag
guessing or retry loop. Capture tool/source/command identities, resulting disc
size/hash and public license bundle before transfer. **CDI is currently UNPREPARED.**

## Wii preparation and full launcher

The cached host `mtools` exists under replacement20's actual
`build.pixelelated-GENERIC_X64.x86_64/toolchain/bin`, not `build.ROCKNIX-*`.
`inputs.json` binds SHA256 `2050c806...`; its ELF needs only libc and the normal
host loader. It has not been executed in this task. After allocation:

```sh
bash prepare-wii-sd.sh /tmp/m7-sudokul-sd-01.raw
```

Transfer DOL to `/storage/roms/wii/SuDokuL-Wii.dol`, the exact fresh SD image to
`/storage/qa-m7-homebrew/sd.raw`, and this packet/licensing through the existing
offline guest media route. Engines must be stopped. In that disposable guest:

```sh
bash prepare-wii-guest.sh /storage/qa-m7-homebrew/wii-preparation
bash native-launch.sh wii
```

This uses the full installed `runemu.sh` → `start_dolphin_wii.sh` →
`dolphin-emu-nogui` route. It does not skip the preservation helper. The config
preparer seeds the normal installed config if absent, retains exact originals,
then writes only the fixture game setting
`wii["SuDokuL-Wii.dol"].write_protect_configs=false` and OpenGL selection.
`get_setting` must actually return the literal **false**. The full launcher at
lines 100–105 replaces both INIs for every other value, including `1` and empty.
`001-functions:125–141` gives the per-game key precedence. Product defaults and
launchers remain unchanged. The original config/settings are retained in the
receipt; retire the disposable guest after evidence consumption rather than
carrying these fixture settings into later retained-state testing.

The unchanged canonical `configure-wii-sd.py` backs up the exact INI and sets
General/WiiSDCardPath plus Core/WiiSDCard, WiiSDCardAllowWrites, and disabled
folder sync. The created `/apps/SuDokuL` directory is essential: `savePuzzle()`
silently skips a failed open. Capture effective INI and canonical StateSaves
link after the real launcher, not just the prepared file.

Fresh SuDokuL maps GC-pad A confirm, B back, D-pad movement, Start pause, Z
Save and Quit (config.cpp:295–311; menu_logic.cpp:131–137). In the actual grid,
choose an observed editable cell and enter a legal visible value through the
game's UI. Record row/column/value and puzzle before save; do not seed a save.
Start, observe pause, Z, observe menu. Exit, retain the quiescent SD copy, then
cold relaunch without a native state and choose Play/Continue. Require the same
puzzle/cell. Extract the real save from the stopped SD copy with the same mtools:

```sh
TOOLBIN=/workspace/repos/rocknix.worktrees/m7-pixelelated-replacement20/build.pixelelated-GENERIC_X64.x86_64/toolchain/bin
"$TOOLBIN/mdir" -i /tmp/m7-sudokul-sd-after.raw ::/apps/SuDokuL
"$TOOLBIN/mcopy" -i /tmp/m7-sudokul-sd-after.raw ::/apps/SuDokuL/save.bin /tmp/m7-sudokul-save-after.bin
sha256sum /tmp/m7-sudokul-save-after.bin
```

## Tetris full launcher and bounded earned-score route

Transfer the authored CDI to `/storage/roms/dreamcast/Tetris2-M7.cdi` and its
hash receipt to `/storage/qa-m7-homebrew/Tetris2-M7.cdi.sha256`. On fresh guest
storage, seed `/storage/.config/flycast` from `/usr/config/flycast` if absent.
Retain `system.cfg`, set the existing game graphics setting to `opengl`, and
verify the effective result. With the engine stopped:

```sh
. /etc/profile
set_setting 'dreamcast["Tetris2-M7.cdi"].graphics_backend' opengl
get_setting graphics_backend dreamcast Tetris2-M7.cdi
digest=$(sha256sum /storage/.config/flycast/emu.cfg)
python3 -I -S -B configure-flycast.py --expected-ini-sha256 "${digest%% *}"
bash native-launch.sh tetris2
```

The preparer uses normal native options: automatic state load/save off, ordinary
shared VMU naming (`PerGameVmu=no`) and controller + VMU port A1. It keeps the
exact INI backup and refuses an unexpected retained VMU override. Built-in HLE
BIOS is used with the fresh image; do not acquire proprietary BIOS files.

The installed `000-conf-dir.patch:24–31` chooses
`/storage/roms/dreamcast/data/`; the full launcher links that to
`/storage/roms/bios/dc`. With the declared settings, the actual ordinary card is
`/storage/roms/dreamcast/data/vmu_save_A1.bin` (resolve and record the real path).
The game's inner file is `tetris2.sys`. Flycast oslib.cpp:50–87 and
maple_devs.cpp:427–456 own this filename/open/write chain. An emulator `.state`
file is not this card. Record before/after VMU bytes, not merely directory mtime.

Use observed menu actions: choose the game's Save menu, select actual A1 and
confirm with A to establish the active card **before** a game-over auto-save.
Start 1 Player / Normal. Hold/release Down in short observed intervals to soft
drop; distribute pieces with Left/Right and rotate with A as necessary. Down
awards one point per successful cell (control.cpp:200–206); each landed block
adds ten (tetris.cpp:80). The table is descending, limited to ten entries, seeded
1000…100 (game.cpp:12–25, highscore.cpp:54–108). Therefore a merely nonzero score,
or a tie at 100, does not prove a new saved table entry. Earn and frame **at least
110**, then allow game over and frame the new score/name in Highscore. Explicit
Save → A1 → A invokes game.cpp:174–242, then orderly engine exit and cold relaunch
with AutoLoadState still off. The game's normal startup calls its own VMU Load
(tetris.cpp:221–234); require the same earned entry. If scoring is not achieved
within 6 minutes, retain that limitation and any real VMU create/reopen result
separately. Do not fabricate a score, modify the game, or lengthen the clock.

## Shared observation limits and remaining runtime facts

Use one admitted 8 GiB/4 CPU no-NIC guest, one native engine at a time, a fixed
30-minute family, first interactive-frame bound 120 seconds/launch, at most
512 MiB state/save evidence plus the bounded CDI payload. Source-only preparation
does not arm those clocks. Bind installed image, native engine, launcher/helper,
effective emulator/core and renderer hashes before execution. Actual installed
display readiness and controller mapping are still runtime facts. The VM's
QMP keyboard is not automatically a mapped GC pad: use the coordinator's actual
guest input route and record generated controller profiles; no blind replay or
claim from a synthetic engine. No physical controller/device action is proposed.

Use the same visible game to save/load native slot 1, deliberately change the
scene, and observe restoration. Dolphin StateSaves resolves to
`/storage/roms/savestates/wii`; record its actual DOL fallback state name.
Flycast native state files end in `.state` under its data path unless a real
native override is selected. Frame the ES game page with standalone selected:
native state existence does not add the RetroArch-only ES manager.

Observe ES global auto-state off/on independently of native auto-state options.
Do not infer automatic native writes from the ES switch. The full launchers
register SIGKILL in `set_kill`; that route is distinct from orderly emulator
stop/unload and must keep its original exit status. The outer owner must retain
actual engine exit as well as shell/launcher exit, since launcher cleanup can
be the shell's last command. Original failure/timeout is preserved, never
normalized. Main-menu return and next first frame need a real ES launch/return
observation; a direct `native-launch.sh` call alone proves only launcher/engine.

Remaining preparation is the admitted mkdcdisc build/authoring, then actual
installed guest/controller binding. All save, state, gameplay, exit and timing
results remain **UNRUN**. This packet supplies inputs and exact source-backed
observations; it does not close #575/#581 or label an engineering image an RC.

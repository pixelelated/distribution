#!/bin/bash
# Foreground full installed launcher; outer admitted owner captures original exits.
set -eo pipefail
case "${1:-}" in
  wii)
    . /etc/profile
    [[ $(get_setting write_protect_configs wii SuDokuL-Wii.dol) == false ]]
    rom=/storage/roms/wii/SuDokuL-Wii.dol
    printf '%s  %s\n' e4fc81977b527538d7fa8d6427099c21c0f2502d18b81a58134f8f07416a8455 "$rom" | sha256sum --check --status
    system=wii; emulator=dolphin; core=dolphin-sa-wii ;;
  tetris2)
    rom=/storage/roms/dreamcast/Tetris2-M7.cdi
    # This receipt can only be supplied after the missing authoring allocation.
    [[ -f /storage/qa-m7-homebrew/Tetris2-M7.cdi.sha256 ]]
    (cd /storage/roms/dreamcast && sha256sum --check --status /storage/qa-m7-homebrew/Tetris2-M7.cdi.sha256)
    system=dreamcast; emulator=flycast; core=flycast-sa ;;
  *) echo 'usage: native-launch.sh wii|tetris2' >&2; exit 2 ;;
esac
exec /usr/bin/runemu.sh "$rom" "-P$system" "--core=$core" \
  "--emulator=$emulator" "--controllers=${CONTROLLERSCONFIG:-}"

#!/bin/bash
# Only in the admitted disposable guest, with all native engines stopped.
# Full guest/config retirement is the cleanup; exact originals are retained.
set -eo pipefail
[[ $# == 1 ]] || { echo 'usage: prepare-wii-guest.sh NEW_RECEIPT_DIR' >&2; exit 2; }
record=$1
mkdir "$record"
. /etc/profile
[[ -f "$J_CONF" && ! -L "$J_CONF" ]]
cp -p "$J_CONF" "$record/system.cfg.before"
if [[ ! -d /storage/.config/dolphin-emu ]]; then
  cp -a /usr/config/dolphin-emu /storage/.config/
fi
cp -p /storage/.config/dolphin-emu/Dolphin.ini "$record/Dolphin.ini.before"
cp -p /storage/.config/dolphin-emu/GFX.ini "$record/GFX.ini.before"
# Literal false is required by start_dolphin_wii.sh:103. 1 does NOT preserve it.
set_setting 'wii["SuDokuL-Wii.dol"].write_protect_configs' false
set_setting 'wii["SuDokuL-Wii.dol"].graphics_backend' opengl
get_setting write_protect_configs wii SuDokuL-Wii.dol > "$record/write-protect-readback.txt"
[[ $(cat "$record/write-protect-readback.txt") == false ]]
get_setting graphics_backend wii SuDokuL-Wii.dol > "$record/renderer-readback.txt"
[[ $(cat "$record/renderer-readback.txt") == opengl ]]
digest=$(sha256sum /storage/.config/dolphin-emu/Dolphin.ini)
python3 -I -S -B "$(dirname "$0")/configure-wii-sd.py" \
  /storage/.config/dolphin-emu/Dolphin.ini /storage/qa-m7-homebrew/sd.raw \
  --expected-ini-sha256 "${digest%% *}" > "$record/configure-sd.stdout" 2> "$record/configure-sd.stderr"
sha256sum /storage/.config/dolphin-emu/Dolphin.ini /storage/qa-m7-homebrew/sd.raw > "$record/prelaunch.sha256"

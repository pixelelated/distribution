#!/bin/bash
# Future admitted data preparation only; never run on a live engine's SD image.
set -euo pipefail
[[ $# == 1 ]] || { echo 'usage: prepare-wii-sd.sh NEW_IMAGE' >&2; exit 2; }
toolbin=/workspace/repos/rocknix.worktrees/m7-pixelelated-replacement20/build.pixelelated-GENERIC_X64.x86_64/toolchain/bin
printf '%s  %s\n' 2050c806846eedb33308d2f6626985e36bbffe3a82d1292741e55d7e002f265d "$toolbin/mtools" | sha256sum --check --status
for name in mformat mmd mdir; do
  [[ $(readlink -f "$toolbin/$name") == "$toolbin/mtools" ]]
done
image=$1
[[ ! -e $image && ! -L $image ]] || { echo 'refusing existing image' >&2; exit 2; }
"$toolbin/mformat" -C -i "$image" -T 262144 -v PIXM7QA ::
[[ $(stat -c %s "$image") == 134217728 ]]
"$toolbin/mmd" -i "$image" ::/apps
"$toolbin/mmd" -i "$image" ::/apps/SuDokuL
"$toolbin/mdir" -i "$image" ::/apps/SuDokuL
sha256sum "$image"

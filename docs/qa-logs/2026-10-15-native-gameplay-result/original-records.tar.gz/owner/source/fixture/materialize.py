#!/usr/bin/env python3
"""Verify prepared data and copy only the two selected fixtures; never execute content."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--cache', type=Path, default=Path('/tmp/m7-native-save-fixture-20261014/payload'))
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
m = json.loads(Path(__file__).with_name('inputs.json').read_text())
staged = []
for row in m['files']:
    path = Path(row['path'])
    if path.is_absolute() or '..' in path.parts:
        p.error('invalid manifest member')
    source = a.cache / path
    if source.is_symlink() or not source.is_file():
        p.error('missing regular payload: ' + str(source))
    with source.open('rb') as f:
        data = f.read(row['bytes'] + 1)
    if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
        p.error('payload changed: ' + str(source))
    staged.append((path, data))
a.out.mkdir(exist_ok=False)
for path, data in staged:
    dest = a.out / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
(a.out / 'SHA256SUMS').write_text(''.join(
    r['sha256'] + '  ' + r['path'] + '\n' for r in m['files']))
print('Prepared', len(staged), 'data files; Tetris CDI authoring remains UNRUN')

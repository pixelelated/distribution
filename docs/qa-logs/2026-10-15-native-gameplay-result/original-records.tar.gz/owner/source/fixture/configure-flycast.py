#!/usr/bin/env python3
"""Future disposable-guest preparation, engines stopped; no emulator invocation."""
import argparse
import configparser
import hashlib
import io
import os
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--expected-ini-sha256', required=True)
a = p.parse_args()
ini = Path('/storage/.config/flycast/emu.cfg')
if ini.is_symlink() or not ini.is_file():
    p.error('expected existing disposable Flycast INI')
raw = ini.read_bytes()
if hashlib.sha256(raw).hexdigest() != a.expected_ini_sha256:
    p.error('INI changed')
c = configparser.ConfigParser(interpolation=None, strict=True)
c.optionxform = str
c.read_string(raw.decode())
if c.has_option('config', 'Dreamcast.VMUPath') and c['config']['Dreamcast.VMUPath']:
    p.error('unexpected retained VMU override; use a fresh fixture guest')
values = {
    'config': {'Dreamcast.AutoLoadState': 'no', 'Dreamcast.AutoSaveState': 'no',
               'PerGameVmu': 'no', 'pvr.rend': '0'},
    'input': {'device1': '0', 'device1.1': '1'},
}
for section, items in values.items():
    if not c.has_section(section):
        c.add_section(section)
    for key, value in items.items():
        c.set(section, key, value)
backup = ini.with_name('emu.cfg.before-m7-homebrew')
with backup.open('xb') as f:
    f.write(raw)
os.chmod(backup, 0o600)
out = io.StringIO()
c.write(out)
ini.write_text(out.getvalue())
print('Native automatic states disabled; normal VMU port A1, shared filename; original retained')

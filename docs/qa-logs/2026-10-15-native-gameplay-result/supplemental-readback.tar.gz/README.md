# Native gameplay 03 supplemental offline readback

Allocated by root after the sole guest completed on 2026-10-15 at 02:13:20 UTC.
This packet does not replace or edit the original failed export, rerun the VM,
consume admission, or grant runtime acceptance. Root owns final acceptance.

Original owner: `/workspace/tmp/pix-m7-native-gameplay-20261015-03`.
Original export: `/workspace/tmp/pix-m7-native-gameplay-evidence-20261015-03`.
Source: `d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a`.

## Export count failure and byte verification

`manifest-verification.json` independently hashes every exported guest file.
The original guest manifest is 2,284,698 bytes, SHA256
`6e3e308f6dccb4d9aa58a69182d4f6893e2cfc50a551611aa4b340e0c8d1db94`.
Its 10,954 unique payload rows exactly equal actual sorted path/size/SHA256 rows,
excluding the manifest itself. There are 10,955 actual files / 310,803,035 bytes,
no symlinks, and no unsafe, missing, extra, or mismatched paths.

Original `close.py:35` applies a 4,096-file ceiling before producing rows.
The 513 MiB export byte bound passes; the 448 MiB guest payload bound also passes.
Four packaged GameSettings copies account for 7,480 files / 4,586,052 bytes;
without them the count is 3,475. The original wrapper exit 1 and its false
manifest flag remain intact. The guest's original manifest, rather than the
failed export's empty top-level guest-manifest.json, is authoritative here.

## Ordinary saves

Four original mtools commands (two `mdir`, two `mcopy`) exited 0. Each had a
30-second wall/CPU limit and 2 MiB file limit. Exact argv, exits, stdout/stderr,
tool hash and unchanged source-image identities are retained. Existing new-build
mtools SHA256 is `2050c806846eedb33308d2f6626985e36bbffe3a82d1292741e55d7e002f265d`.
No emulator, service, or network operation ran.

Both quiescent and final 128 MiB SD images have SHA256
`1c673d6bfebca8e5fe3056d60854c674b069af866bc56794afd5048ab0b47cb7`.
Both contain the same ordinary `/apps/SuDokuL/save.bin`: 415 bytes, SHA256
`93c59b358920c1d4c4ccabdc54b4b745c89347adb55b6f8d762d4e9c7ea340ce`.
The saved grid differs from the original grid only at row 1, column 2: 0 → 4.
The solution value there is 6, so this is an entered-cell persistence witness,
not a solved-puzzle claim. Original fresh-image mdir has only dot directories
and 0 file bytes; the initial SD hash differs. The source field-order and the
limited inference about missing type declarations are explicit in the JSON.
Root's original cold frame `wii-cold-slot1` is bound separately.

Actual `vmu_save_A1.bin` contains the `tetris2.sys` directory entry, its complete
three-block FAT chain [196,195,194], and a validated package CRC16 (12016).
The 424-byte bzip2 payload decodes to 564 bytes. Ten parsed high scores reproduce
the nine initial defaults and rank 10: Player 1, 2026-10-14, 164. Both parsed bytes
and original root cold-frame review are retained/bound. This identifies actual
A1 despite the game's overprinted VMU menu labels. On-disk structure validation
and limits of the retained game declaration subset are explicit in the receipt.
New extracted save data totals only 2,458 bytes.

## Native-state limits in this run

One Wii native `.s01` is retained twice, unchanged: 6,380,469 bytes, SHA256
`b94681ea311a1f9162136f1ae6883517f9f0c0e4bb99234ed3b39bf40ef377b5`.
The original frame review confirms the save notification, then a changed paused
scene. The later frame says **Decompressing State**, so completed manual restore
is not established by that frame. Native original engine exit status remains
unknown under the existing ES-owned process lifecycle; wrapper success is not
substituted for an engine wait status.

No Flycast native state is in the exported file inventory. Recorded Flycast
AutoLoadState and AutoSaveState remain `no`; native-menu originals show Slot 1
Empty. Flycast manual save/change/load and enabled native automatic
save/restore were not completed in this run. No `global-auto-before-*` or
`native-auto-before-*` snapshot exists; initial global.autosave was set to 0.
Thus this run adds no global off/on comparison or native automatic-state proof.
These are limits of this run only, not claims about all earlier milestone evidence.

`original-coordinator-frame-reviews.json` preserves root's existing review text
and rechecks the referenced frame hashes. It is not a new visual acceptance.

## Custody

`verify-and-extract.py` and `inspect-saves.py` are the exact executed source.
Their command receipts preserve original exits. Source excerpts were retained as
whole small original files with an index. `SHA256SUMS` seals every packet file
except itself; original large SD, VMU, state, and manifest files remain in the
original export and are bound by exact hashes. No original file was overwritten.

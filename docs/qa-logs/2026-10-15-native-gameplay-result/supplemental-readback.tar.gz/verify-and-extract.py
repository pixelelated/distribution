#!/usr/bin/env python3
"""Allocated data-only post-run inspection; original evidence remains read-only."""
import collections, hashlib, json, os, resource, subprocess, time
from pathlib import Path

OUT=Path(__file__).resolve().parent
EXPORT=Path('/workspace/tmp/pix-m7-native-gameplay-evidence-20261015-03')
GUEST=EXPORT/'guest'
TOOLS=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01/build.pixelelated-GENERIC_X64.x86_64/toolchain/bin')
def sha(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def row(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(name,obj):
    with (OUT/name).open('x') as stream:json.dump(obj,stream,indent=2);stream.write('\n')

start=time.time()
manifest=GUEST/'guest-export-manifest.json'
original=json.loads(manifest.read_text())
files=sorted(p for p in GUEST.rglob('*') if p.is_file())
links=[str(p.relative_to(GUEST)) for p in GUEST.rglob('*') if p.is_symlink()]
actual=[{'path':str(p.relative_to(GUEST)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
payload=[r for r in actual if r['path']!='guest-export-manifest.json']
groups=collections.defaultdict(lambda:{'files':0,'bytes':0})
for r in actual:
    parts=Path(r['path']).parts
    if 'GameSettings' in parts:
        g=groups['/'.join(parts[:parts.index('GameSettings')+1])]
        g['files']+=1;g['bytes']+=r['bytes']
assert not links and len({r['path'] for r in original})==len(original)
assert all(not Path(r['path']).is_absolute() and '..' not in Path(r['path']).parts for r in original)
assert original==payload
write('manifest-verification.json',{'start_epoch':start,'end_epoch':time.time(),'original_manifest':row(manifest),'actual_files':len(files),'actual_bytes':sum(r['bytes'] for r in actual),'payload_files':len(payload),'payload_bytes':sum(r['bytes'] for r in payload),'exact_list_path_size_sha256_equal':True,'symlinks':links,'gamesettings':groups,'original_export':row(EXPORT/'export-result.json'),'original_export_unchanged':True,'original_export_count_ceiling':4096,'original_export_byte_ceiling':513*1024**2,'count_ceiling_pass':len(files)<=4096,'byte_ceiling_pass':sum(r['bytes'] for r in actual)<=513*1024**2,'guest_448MiB_payload_bound_pass':sum(r['bytes'] for r in payload)<=448*1024**2,'scope':'Independent supplemental byte verification. Does not replace original wrapper exit 1 or establish runtime acceptance.'})

tool=TOOLS/'mtools'
assert sha(tool)=='2050c806846eedb33308d2f6626985e36bbffe3a82d1292741e55d7e002f265d'
assert all((TOOLS/n).resolve()==tool for n in ['mdir','mcopy'])
write('tool-binding.json',{'mtools':row(tool),'aliases':{n:str((TOOLS/n).resolve()) for n in ['mdir','mcopy']}})

def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30))
    resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**2,2*1024**2))
commands=[]; saves=[]
for label in ['wii-saved-quiescent','final']:
    sd=GUEST/'gameplay/snapshots'/label/'sd.raw'
    before=row(sd)
    assert before['bytes']==134217728 and before['sha256']=='1c673d6bfebca8e5fe3056d60854c674b069af866bc56794afd5048ab0b47cb7'
    save=OUT/(label+'-save.bin')
    for action,argv in [('mdir',[str(TOOLS/'mdir'),'-i',str(sd),'::/apps/SuDokuL']),('mcopy',[str(TOOLS/'mcopy'),'-n','-i',str(sd),'::/apps/SuDokuL/save.bin',str(save)])]:
        prefix=label+'-'+action
        started=time.time()
        result=subprocess.run(argv,capture_output=True,timeout=30,preexec_fn=limits,env={**os.environ,'MTOOLSRC':'/dev/null'})
        (OUT/(prefix+'.stdout')).write_bytes(result.stdout)
        (OUT/(prefix+'.stderr')).write_bytes(result.stderr)
        commands.append({'argv':argv,'environment_override':{'MTOOLSRC':'/dev/null'},'timeout_seconds':30,'cpu_limit_seconds':30,'file_size_limit_bytes':2*1024**2,'start_epoch':started,'end_epoch':time.time(),'original_returncode':result.returncode,'stdout':row(OUT/(prefix+'.stdout')),'stderr':row(OUT/(prefix+'.stderr'))})
        write(prefix+'-command.json',commands[-1])
        assert result.returncode==0
    assert row(sd)==before
    saves.append({'label':label,'sd':before,'sd_unchanged':True,'save':row(save)})
assert sum(r['save']['bytes'] for r in saves)<=2*1024**2
write('wii-extraction.json',{'saves':saves,'save_bytes_equal':saves[0]['save']['sha256']==saves[1]['save']['sha256'],'new_extracted_bytes':sum(r['save']['bytes'] for r in saves),'original_returncodes':[c['original_returncode'] for c in commands],'no_emulation_service_network':True})
states=[r for r in payload if Path(r['path']).suffix in ['.s01','.state','.sav'] or '/savestates/' in r['path']]
write('state-inventory.json',{'original_manifest_sha256':sha(manifest),'selected_exported_records':states,'selection':'suffix .s01/.state/.sav or path /savestates/; no state files opened by emulator','claim_limit':'Presence/hash proves retained bytes only; loading/automatic save behavior needs original frames and action/config records.'})
write('result.json',{'original_returncode':0,'scope':'post-run data-only manifest verification and two ordinary Wii save extractions','commands':len(commands),'emulation_executed':False,'original_export_mutated':False,'runtime_acceptance':'root review pending'})
print(json.dumps({'manifest_verified':True,'actual_files':len(files),'actual_bytes':sum(r['bytes'] for r in actual),'save_bytes':[r['save']['bytes'] for r in saves],'returncodes':[c['original_returncode'] for c in commands]}))

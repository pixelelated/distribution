#!/usr/bin/env python3
"""Bounded offline interpretation of the exact allocated save files; no emulation."""
import binascii,bz2,hashlib,json,struct,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
GUEST=Path('/workspace/tmp/pix-m7-native-gameplay-evidence-20261015-03/guest')
OWNER=Path('/workspace/tmp/pix-m7-native-gameplay-20261015-03')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def row(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(name,value):
    with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')

source_paths=[Path('/tmp/pix-m7-native-homebrew-20261014/upstream')/s for s in ['shared.cpp','shared.h','main.cpp']]+[Path('/tmp/pix-m7-native-homebrew-20261014/tetris2')/s for s in ['src-game.cpp','src-highscore.hpp','common-src-vmu.cpp']]
source_paths+=[OWNER/'source/fixture/prepare-wii-sd.sh',OWNER/'records/002-fresh-wii-sd.stdout',OWNER/'records/002-fresh-wii-sd.exit.json',GUEST/'gameplay/wii-preparation/prelaunch.sha256']
write('source-bindings.json',[row(p) for p in source_paths])

wii=(OUT/'final-save.bin').read_bytes()
assert len(wii)==415 and hashlib.sha256(wii).hexdigest()=='93c59b358920c1d4c4ccabdc54b4b745c89347adb55b6f8d762d4e9c7ea340ce'
grid=list(wii[1:82]);original=list(wii[82:163]);solution=list(wii[163:244])
assert wii[0]==0 and all(0<=v<=9 for v in grid+original+solution)
changes=[{'row':i//9+1,'column':i%9+1,'original':a,'saved':b} for i,(a,b) in enumerate(zip(original,grid)) if a!=b]
assert changes==[{'row':1,'column':2,'original':0,'saved':4}]
write('wii-save-interpretation.json',{'save':row(OUT/'final-save.bin'),'matching_quiescent_save':row(OUT/'wii-saved-quiescent-save.bin'),'source_order':'shared.cpp:182-191 writes gameCompleted, grid, originalGrid, solutionGrid, miniGrid, timer_game.now, menuCursorIndex_play in that order; Wii directory selected at shared.cpp:67.','layout_limit':'Retained source subset lacks sudokuGen.h declarations. First three 81-byte grids are inferred from exact 415-byte layout and independently match the observed 9x9 puzzle. No claim of a compiled struct-schema check.','game_completed_byte':wii[0],'grid':grid,'original_grid':original,'solution_grid':solution,'changes':changes,'entered_value':4,'solution_value_same_cell':solution[1],'saved_empty_cells':grid.count(0),'original_empty_cells':original.count(0),'initial_sd_sha256':'f99b8bc6468865378f0e491e21e93101a51aed41882a52116ea8d07649316f60','final_sd_sha256':'1c673d6bfebca8e5fe3056d60854c674b069af866bc56794afd5048ab0b47cb7','fresh_directory_original':row(OWNER/'records/002-fresh-wii-sd.stdout'),'claim':'Ordinary save exists and contains entered r1c2=4, distinct from native .s01. Cold persistence remains coupled to root-reviewed original cold frame.'})

card=GUEST/'gameplay/snapshots/final/storage/roms/bios/dc/vmu_save_A1.bin'
raw=card.read_bytes();assert len(raw)==131072 and sha(card)=='5f72f36f9a91a381064a078516b2b8d87eafb6804e09306e537f0679c0fe0040'
u16=lambda b,o:struct.unpack_from('<H',b,o)[0]
root=raw[255*512:];assert root[:16]==b'\x55'*16
fat_block,fat_blocks,dir_block,dir_blocks,user_blocks=(u16(root,o) for o in [0x46,0x48,0x4a,0x4c,0x50])
assert (fat_block,fat_blocks,dir_block,dir_blocks,user_blocks)==(254,1,253,13,200)
fat=struct.unpack('<256H',raw[fat_block*512:(fat_block+1)*512])
entries=[]
for block in range(dir_block,dir_block-dir_blocks,-1):
    for offset in range(block*512,(block+1)*512,32):
        d=raw[offset:offset+32]
        if d[0]==0:continue
        entries.append({'offset':offset,'type':d[0],'name':d[4:16].split(b'\0')[0].decode('ascii'),'first_block':u16(d,2),'blocks':u16(d,24),'header_offset_blocks':u16(d,26),'raw_hex':d.hex()})
matches=[e for e in entries if e['name']=='tetris2.sys'];assert len(matches)==1
e=matches[0];assert e['type']==0x33 and e['blocks']==3 and e['header_offset_blocks']==0
chain=[];block=e['first_block']
for _ in range(e['blocks']):
    assert 0<=block<user_blocks and block not in chain
    chain.append(block);block=fat[block]
assert block==0xfffa
pkg=b''.join(raw[b*512:(b+1)*512] for b in chain)
icon_count=u16(pkg,0x40);eyecatch=u16(pkg,0x44);stored_crc=u16(pkg,0x46);data_size=struct.unpack_from('<I',pkg,0x48)[0]
assert icon_count==1 and eyecatch==0 and data_size==424
data_offset=128+icon_count*512;end=data_offset+data_size;assert end<=len(pkg)
crcdata=bytearray(pkg[:end]);crcdata[0x46:0x48]=b'\0\0';computed_crc=binascii.crc_hqx(crcdata,0);assert stored_crc==computed_crc
compressed=pkg[data_offset:end];decoder=bz2.BZ2Decompressor();decoded=decoder.decompress(compressed,max_length=65537)
assert decoder.eof and not decoder.unused_data and len(decoded)==564
scores=[]
for i in range(10):
    d=decoded[i*28:(i+1)*28]
    scores.append({'rank':i+1,'name':d[:11].split(b'\0')[0].decode('ascii'),'date':d[11:22].split(b'\0')[0].decode('ascii'),'score':struct.unpack_from('<i',d,24)[0]})
assert [r['score'] for r in scores]==[1000,900,800,700,600,500,400,300,200,164]
assert scores[-1]=={'rank':10,'name':'Player 1','date':'2026-10-14','score':164}
(OUT/'tetris2.sys').write_bytes(pkg[:end]);(OUT/'tetris2-decoded.bin').write_bytes(decoded)
write('vmu-interpretation.json',{'card':row(card),'filesystem':{'root_block':255,'fat_block':fat_block,'directory_block':dir_block,'directory_blocks':dir_blocks,'user_blocks':user_blocks,'entries':entries,'tetris_fat_chain':chain,'chain_terminator':block},'package':{'description':pkg[:16].decode('ascii').rstrip(),'application_id':pkg[48:64].split(b'\0')[0].decode('ascii'),'icons':icon_count,'eyecatch_type':eyecatch,'compressed_bytes':data_size,'crc16_stored':stored_crc,'crc16_computed':computed_crc,'extracted':row(OUT/'tetris2.sys'),'decoded':row(OUT/'tetris2-decoded.bin')},'scores':scores,'layout_evidence':'Read-only VMU root/directory/FAT structural validation and package CRC; src-game.cpp:174-240 serializes ten high-score records before options, compresses bzip2, packages tetris2.sys. src-highscore.hpp has char name[11], char date[11], int score; little-endian SH4 records at 28-byte stride also independently reproduce all nine fixed initial scores. Retained subset lacks the st_high_score declaration, so equivalent on-disk stride is corroborated rather than claimed compiler-verified.','ordinary_save':True,'native_state_used_for_this_parse':False,'source_card_unchanged':sha(card)=='5f72f36f9a91a381064a078516b2b8d87eafb6804e09306e537f0679c0fe0040'})
write('inspection-result.json',{'original_returncode':0,'wii_ordinary_save_entered_r1c2':4,'tetris_A1_tenth_score':164,'new_extracted_data_bytes':sum((OUT/n).stat().st_size for n in ['final-save.bin','wii-saved-quiescent-save.bin','tetris2.sys','tetris2-decoded.bin']),'no_emulation_service_network':True,'root_acceptance_pending':True,'time':time.time()})
print(json.dumps({'wii_r1c2':4,'VMU_A1_tetris2_score':164,'CRC16_verified':True,'extracted_data_bytes':2458}))

from device import act,shot
import sys,time
name=sys.argv[1];keys=sys.argv[2:]
assert 1<=len(keys)<=15 and all(x in ['enter','esc','up','down','left','right','x','z'] for x in keys)
code="""import time,sys
sys.path.insert(0,'/usr/bin')
n={'__name__':'smoke_keyboard','__file__':'/usr/bin/cloud_oauth'}
exec(compile(Path('/usr/bin/cloud_oauth').read_text(),'/usr/bin/cloud_oauth','exec'),n)
n['log']=lambda message:None
k=n['RemoteKeyboard']()
try:
 for key in KEYS:
  if key in ['x','z']:assert k.type_text(key)==1
  else:assert k.press(key)
  time.sleep(.18)
finally:k.close()
print('Synthetic keys sent; temporary keyboard destroyed')
""".replace('KEYS',repr(keys))
print(act(code,name).splitlines()[0]);time.sleep(2);shot(name+'-frame')

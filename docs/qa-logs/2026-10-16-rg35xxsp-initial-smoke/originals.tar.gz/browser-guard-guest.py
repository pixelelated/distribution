from pathlib import Path
import os,sys,time,json,signal
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='067a27f1-143d-4fe8-83cd-937560a5c87b'
assert '077197e6cd3ea31f33b28aaf3882a694b3423b53' in Path('/etc/os-release').read_text()
assert hasattr(os,'pidfd_open') and hasattr(signal,'pidfd_send_signal')
def census():
 out=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   exe=os.readlink(p/'exe'); stat=(p/'stat').read_text().rpartition(') ')[2].split()
   if Path(exe).name not in ['emulationstation','cloud-signin-window','WebKitWebProcess','WebKitNetworkProcess','sway','python3.13','python3.12','python3.11','rclone']:continue
   sm={k:int(v.split()[0]) for l in (p/'smaps_rollup').read_text().splitlines() if ':' in l for k,v in [l.split(':',1)]}
   out.append({'pid':int(p.name),'exe':exe,'start_ticks':stat[19],'pss_kib':sm.get('Pss',0),'rss_kib':sm.get('Rss',0)})
  except (OSError,ValueError,IndexError):pass
 return out
def sample():
 m={k:int(v.split()[0]) for l in Path('/proc/meminfo').read_text().splitlines() for k,v in [l.split(':',1)]}
 pressure=Path('/proc/pressure/memory').read_text()
 avg=max(float(l.split('avg10=',1)[1].split()[0]) for l in pressure.splitlines())
 return {'elapsed':round(time.monotonic()-start,3),'available_kib':m['MemAvailable'],'memory_psi':pressure,'psi_avg10':avg,'processes':census()}
start=time.monotonic();first=sample()
assert first['available_kib']>400*1024
assert not any(Path(p['exe']).name in ['cloud-signin-window','WebKitWebProcess','WebKitNetworkProcess','rclone'] for p in first['processes'])
# No preexisting OAuth session may be disturbed by the normal add flow.
for p in Path('/proc').glob('[0-9]*'):
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  assert not (b'/usr/bin/cloud_oauth' in args and b'serve' in args),'existing OAuth owner'
 except (FileNotFoundError,ProcessLookupError):pass
print(json.dumps({'event':'armed','guard_pid':os.getpid(),'sample':first}),flush=True)
owned=None;fd=None;opened=None;gone=None;reason=None
try:
 while time.monotonic()-start<300:
  s=sample();windows=[p for p in s['processes'] if Path(p['exe']).name=='cloud-signin-window']
  assert len(windows)<=1
  if windows and owned is None:
   owned=windows[0];fd=os.pidfd_open(owned['pid']);opened=time.monotonic()
   assert any(p['pid']==owned['pid'] and p['start_ticks']==owned['start_ticks'] for p in census())
   print(json.dumps({'event':'browser_observed','process':owned}),flush=True)
  print(json.dumps({'event':'sample',**s}),flush=True)
  if opened is not None and not windows:
   if gone is None:gone=time.monotonic()
   if time.monotonic()-gone>=8:reason='browser_exited';break
  if windows and (s['available_kib']<160*1024 or (s['psi_avg10']>5 and s['available_kib']<256*1024)):
   reason='memory_guard';break
  if opened is not None and time.monotonic()-opened>=90:
   reason='browser_time_limit';break
  time.sleep(2)
 if reason is None:reason='launch_deadline'
finally:
 if fd is not None:
  live=[p for p in census() if p['pid']==owned['pid'] and p['start_ticks']==owned['start_ticks'] and p['exe']==owned['exe']]
  if live:
   signal.pidfd_send_signal(fd,signal.SIGTERM)
   print(json.dumps({'event':'guard_sent_term','reason':reason,'pid':owned['pid']}),flush=True)
  os.close(fd)
 print(json.dumps({'event':'finished','reason':reason,'sample':sample()}),flush=True)
assert reason=='browser_exited',reason

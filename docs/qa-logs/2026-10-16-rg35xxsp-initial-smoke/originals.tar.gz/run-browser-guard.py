from device import P,TREE,OPTS
import os,subprocess,base64,shlex,json,time
code=(P/'browser-guard-guest.py').read_bytes()
command='python3 -B -I -c '+shlex.quote('import base64;exec(base64.b64decode('+repr(base64.b64encode(code).decode())+'))')
env=dict(os.environ,DEVICE_ACT_SSH_OPTS=OPTS,DEVICE_ACT_TIMEOUT='325',DEVICE_ACTIONS_LOG=str(P/'device-actions.log'))
t=time.monotonic()
with (P/'browser-guard.stdout').open('x') as out,(P/'browser-guard.stderr').open('x') as err:
 r=subprocess.run([str(TREE/'tools/device-act'),'rg35xxsp','#344 authorized initial browser smoke memory guard','--',command],env=env,stdout=out,stderr=err,timeout=350)
(P/'browser-guard.rc').write_text(str(r.returncode)+'\n')
print(json.dumps({'returncode':r.returncode,'elapsed_seconds':round(time.monotonic()-t,3)}))
raise SystemExit(r.returncode)

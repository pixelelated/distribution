from device import act,shot
import time
code="""import sys
sys.path.insert(0,'/usr/bin')
n={'__name__':'smoke_keyboard','__file__':'/usr/bin/cloud_oauth'}
exec(compile(Path('/usr/bin/cloud_oauth').read_text(),'/usr/bin/cloud_oauth','exec'),n)
n['log']=lambda message:None
k=n['RemoteKeyboard']()
try:assert k.press('escape')
finally:k.close()
print('Escape sent; temporary keyboard destroyed')
"""
print(act(code,'browser-close02').splitlines()[0]);time.sleep(2);shot('browser-close02-frame')

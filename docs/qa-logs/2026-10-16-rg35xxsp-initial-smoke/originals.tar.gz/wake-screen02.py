from device import act,shot
import time
code="""import time,sys
sys.path.insert(0,'/usr/bin')
n={'__name__':'smoke_keyboard','__file__':'/usr/bin/cloud_oauth'}
exec(compile(Path('/usr/bin/cloud_oauth').read_text(),'/usr/bin/cloud_oauth','exec'),n)
n['log']=lambda message:None
k=n['RemoteKeyboard']()
try:
 assert k.press('right'),'input refused'
finally:k.close()
print('One synthetic Right press; temporary keyboard destroyed')
"""
print(act(code,'wake-right02').splitlines()[0]);time.sleep(3);shot('awake-frame')

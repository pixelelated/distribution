from device import act,shot
import time
code="""import subprocess,os
p=Path('/proc/31023')
assert os.readlink(p/'exe')=='/usr/bin/cloud-signin-window'
assert (p/'stat').read_text().rpartition(') ')[2].split()[19]=='429594'
r=subprocess.run(['/usr/bin/cloud_oauth','close'],capture_output=True,text=True,timeout=20)
print('Installed cloud_oauth close returned',r.returncode)
assert r.returncode==0
"""
print(act(code,'browser-normal-close',30).splitlines()[0]);time.sleep(2);shot('browser-return-frame')

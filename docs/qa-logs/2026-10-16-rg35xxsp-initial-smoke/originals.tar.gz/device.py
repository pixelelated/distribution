from pathlib import Path
import subprocess,os,shlex,json,base64,datetime
P=Path(__file__).resolve().parent
TREE=Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
OPTS='-o Hostname=100.74.205.40 -o HostKeyAlias=192.168.1.81 -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/home/max/.ssh/known_hosts -o HostKeyAlgorithms=ssh-ed25519'
SSH=['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=8']+shlex.split(OPTS)+['rg35xxsp']
def read(code,name,timeout=40):
 r=subprocess.run(SSH+['python3 -B -I -'],input=code,capture_output=True,text=True,timeout=timeout)
 (P/(name+'.stdout')).write_text(r.stdout);(P/(name+'.stderr')).write_text(r.stderr);(P/(name+'.rc')).write_text(str(r.returncode)+'\n');assert r.returncode==0,name;return r.stdout
def act(code,name,timeout=45):
 assert not (P/(name+'.stdout')).exists()
 guard="from pathlib import Path\nassert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='067a27f1-143d-4fe8-83cd-937560a5c87b'\nassert '077197e6cd3ea31f33b28aaf3882a694b3423b53' in Path('/etc/os-release').read_text()\n"
 command='python3 -B -I -c '+shlex.quote('import base64;exec(base64.b64decode('+repr(base64.b64encode((guard+code).encode()).decode())+'))')
 env=dict(os.environ,DEVICE_ACT_SSH_OPTS=OPTS,DEVICE_ACT_TIMEOUT=str(timeout),DEVICE_ACTIONS_LOG=str(P/'device-actions.log'))
 r=subprocess.run([str(TREE/'tools/device-act'),'rg35xxsp','#344 authorized initial smoke '+name,'--',command],env=env,capture_output=True,text=True,timeout=timeout+35)
 (P/(name+'.stdout')).write_text(r.stdout);(P/(name+'.stderr')).write_text(r.stderr);(P/(name+'.rc')).write_text(str(r.returncode)+'\n');assert r.returncode==0,name;return r.stdout
FRAME="""import os,subprocess,base64
p=next(p for p in Path('/run').glob('**/wayland-*') if p.is_socket())
e=dict(os.environ,XDG_RUNTIME_DIR=str(p.parent),WAYLAND_DISPLAY=p.name)
r=subprocess.run(['grim','-'],env=e,capture_output=True,timeout=10)
assert r.returncode==0,r.stderr.decode(errors='replace')
assert r.stdout.startswith(b'\\x89PNG\\r\\n\\x1a\\n')
print('FRAME_BASE64='+base64.b64encode(r.stdout).decode())
"""
def shot(name):
 out=act(FRAME,name)
 b=base64.b64decode(next(l.split('=',1)[1] for l in out.splitlines() if l.startswith('FRAME_BASE64=')))
 (P/(name+'.png')).write_bytes(b);print('Captured',name,len(b),'bytes')
if __name__=='__main__':
 import sys
 shot(sys.argv[1])

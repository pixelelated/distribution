from device import act,shot
import time
code="""import time
n={'__name__':'smoke_keyboard'}
exec(compile(Path('/usr/bin/cloud_oauth').read_text(),'/usr/bin/cloud_oauth','exec'),n)
n['log']=lambda message:None
k=n['RemoteKeyboard']()
try:
 assert k.press('right'),'input refused'
finally:k.close()
print('One synthetic Right press; temporary keyboard destroyed')
"""
print(act(code,'wake-right').splitlines()[0]);time.sleep(3);shot('awake-frame')

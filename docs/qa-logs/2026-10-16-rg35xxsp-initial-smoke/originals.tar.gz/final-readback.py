from device import read,P
import json
code="""from pathlib import Path
import os,json,subprocess,re
p=Path('/proc');busy=[]
for d in p.glob('[0-9]*'):
 try:
  exe=os.readlink(d/'exe');args=(d/'cmdline').read_bytes().split(b'\\0')
  if any(x in exe for x in ['WebKit','cloud-signin']) or b'/usr/bin/cloud_oauth' in args or Path(exe).name=='rclone':busy.append({'pid':int(d.name),'exe':exe})
 except OSError:pass
print(json.dumps({'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'transient_processes':busy,'guard_pid_absent':not Path('/proc/30246').exists(),'tested_browser_pid_absent':not Path('/proc/31023').exists(),'test_oauth_pid_absent':not Path('/proc/30478').exists(),'oauth_status':subprocess.check_output(['/usr/bin/cloud_oauth','status'],text=True).strip(),'temporary_input_devices':sum('pixelelated cloud sign-in' in p.read_text(errors='replace').lower() for p in Path('/sys/class/input').glob('input*/name')),'selected_logs':{n:'\\n'.join(l for l in Path(n).read_text(errors='replace').splitlines()[-160:] if not re.search('key|pass|token|user|psk|http|pin|remote',l,re.I)) for n in ['/var/run/cloud_oauth/window.log','/var/log/cloud_oauth.log'] if Path(n).exists()}},indent=2))
"""
print(read(code,'final-readback'))

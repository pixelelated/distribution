from pathlib import Path
import os,json,subprocess,time,hashlib,shutil,re
P=Path
def read(p):
 try:return P(p).read_text().strip()
 except OSError:return ''
def run(a):
 q=subprocess.run(a,capture_output=True,text=True,timeout=15);return {'rc':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
def snap():
 mem={k:int(v.split()[0]) for l in read('/proc/meminfo').splitlines() for k,v in [l.split(':',1)]}
 procs=[]
 for p in P('/proc').glob('[0-9]*'):
  try:
   name=(p/'exe').resolve().name;st=(p/'stat').read_text().rpartition(') ')[2].split();pss={k:int(v.split()[0]) for l in (p/'smaps_rollup').read_text().splitlines() if ':' in l for k,v in [l.split(':',1)]}
   procs.append({'pid':int(p.name),'exe':name,'start_ticks':st[19],'pss_kib':pss.get('Pss',0),'rss_kib':pss.get('Rss',0),'threads':int(st[17])})
  except (OSError,IndexError,ValueError):pass
 return {'monotonic':time.monotonic(),'meminfo':mem,'pressure':{n:read('/proc/pressure/'+n) for n in ['cpu','memory','io']},'processes':procs,'thermal':[{'zone':p.name,'type':read(p/'type'),'millidegrees':read(p/'temp')} for p in P('/sys/class/thermal').glob('thermal_zone*')]}
r={'boot_id':read('/proc/sys/kernel/random/boot_id'),'model':read('/proc/device-tree/model').replace('\x00',''),'build':dict(l.split('=',1) for l in read('/etc/os-release').splitlines() if '=' in l).get('BUILD_ID'),'units':{},'samples':[]}
assert r['model']=='Anbernic RG35XX SP' and '077197e6cd3ea31f33b28aaf3882a694b3423b53' in r['build']
for n in ['essway.service','sway.service','raofflineproxy.service','tailscaled.service','iwd.service','pipewire.service','pipewire-pulse.service']:
 r['units'][n]=run(['systemctl','show',n,'-p','ActiveState','-p','SubState','-p','NRestarts','-p','MainPID','-p','ExecMainStatus'])
r['failed_units']=run(['systemctl','list-units','--state=failed','--no-legend','--no-pager'])
r['idle']=run(['curl','-fsS','--max-time','3','http://127.0.0.1:1234/isIdle'])
r['tools']={x:shutil.which(x) for x in ['grim','swaymsg','wtype','ydotool','cloud-signin-window','cloud_oauth','curl','timeout']}
r['wayland']=[str(p) for p in P('/run').glob('**/wayland-*') if p.is_socket()]
r['sway_sockets']=[str(p) for p in P('/run').glob('**/sway-ipc*.sock') if p.is_socket()]
r['drm']=[{'connector':p.name,'status':read(p/'status'),'enabled':read(p/'enabled'),'modes':read(p/'modes'),'dpms':read(p/'dpms')} for p in P('/sys/class/drm').glob('card*-*') if (p/'status').exists()]
r['gpu']=[{'device':p.name,'driver':(p/'device/driver').resolve().name,'freq':read(p/'cur_freq'),'governor':read(p/'governor')} for p in P('/sys/class/devfreq').glob('*')]
for i in range(3):
 r['samples'].append(snap())
 if i<2:time.sleep(5)
r['kernel_errors']=run(['journalctl','-k','-b','--no-pager','-p','err','-n','80'])
r['oom_events']=run(['journalctl','-k','-b','--no-pager','--grep','Out of memory|oom-kill|Killed process|GPU fault|panfrost.*fault'])
for k in ['kernel_errors','oom_events','failed_units']:
 for stream in ['stdout','stderr']:r[k][stream]='\n'.join(l for l in r[k][stream].splitlines() if not re.search('key|pass|token|user|psk',l,re.I))
assert r['boot_id']==read('/proc/sys/kernel/random/boot_id')
print(json.dumps(r,indent=2))

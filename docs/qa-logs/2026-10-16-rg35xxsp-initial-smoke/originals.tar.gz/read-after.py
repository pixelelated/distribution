from pathlib import Path
import json,subprocess
from device import P,SSH
for source,name in [(Path('/tmp/pix-m7-h700-rg35xxsp-deploy-20261016-01/inspect.py'),'binding-after-private'),(P/'health.py','health-after')]:
 assert not (P/(name+'.json')).exists()
 q=subprocess.run(SSH+['python3 -B -I -'],input=source.read_text(),capture_output=True,text=True,timeout=90)
 (P/(name+'.json')).write_text(q.stdout);(P/(name+'.stderr')).write_text(q.stderr);(P/(name+'.rc')).write_text(str(q.returncode)+'\n');assert q.returncode==0
j=json.loads((P/'health-after.json').read_text())
print(json.dumps({k:j[k] for k in ['boot_id','units','failed_units','idle','kernel_errors','oom_events']},indent=2))
print('available_memory_kib',[x['meminfo']['MemAvailable'] for x in j['samples']])
a=json.loads((P/'binding-before-private.json').read_text());b=json.loads((P/'binding-after-private.json').read_text())
print('changed_top_level_fields',[k for k in a if a[k]!=b[k]])
print('changed_selected_files',[k for k in a['files'] if a['files'][k]!=b['files'][k]])
print('payload_unchanged',a['safe_payload']==b['safe_payload'],'recovery_unchanged',a['local_recovery']==b['local_recovery'],'settings_unchanged',a['settings']==b['settings'],'busy_count',len(b['busy_cloud_processes']))

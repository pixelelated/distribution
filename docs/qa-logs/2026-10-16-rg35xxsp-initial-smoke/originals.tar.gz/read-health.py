from pathlib import Path
import subprocess,json
P=Path(__file__).resolve().parent
ssh=['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=8','-o','Hostname=100.74.205.40','-o','HostKeyAlias=192.168.1.81','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/home/max/.ssh/known_hosts','-o','HostKeyAlgorithms=ssh-ed25519','rg35xxsp','python3 -B -I -']
for source,name in [(Path('/tmp/pix-m7-h700-rg35xxsp-deploy-20261016-01/inspect.py'),'binding-before-private'),(P/'health.py','health-before')]:
 q=subprocess.run(ssh,input=source.read_text(),capture_output=True,text=True,timeout=90)
 (P/(name+'.json')).write_text(q.stdout);(P/(name+'.stderr')).write_text(q.stderr);(P/(name+'.rc')).write_text(str(q.returncode)+'\n');assert q.returncode==0
j=json.loads((P/'health-before.json').read_text())
print(json.dumps({k:j[k] for k in ['boot_id','model','build','units','failed_units','idle','tools','wayland','sway_sockets','drm','gpu','kernel_errors','oom_events']},indent=2))
print('available_memory_kib',[x['meminfo']['MemAvailable'] for x in j['samples']]);print('memory_pressure',[x['pressure']['memory'] for x in j['samples']]);print('largest_processes',sorted(j['samples'][-1]['processes'],key=lambda x:x['pss_kib'],reverse=True)[:8])

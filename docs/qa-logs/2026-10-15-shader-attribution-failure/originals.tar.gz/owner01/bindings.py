"""Bound accepted inventory metadata only; no cache walks or product mutation."""
from pathlib import Path
import hashlib,json,os
COMMIT = 'f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    p = Path(path)
    assert p.is_file() and not p.is_symlink() and p.stat().st_size < 20 * 1024**2, p
    return json.loads(p.read_text())

def host_and_serialization(own_run=None):
    assert (os.getuid(), os.getgid()) == (1000, 1000)
    assert os.readlink('/proc/self/ns/pid') == 'pid:[4026531836]'
    registry = load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')
    active = [j for j in registry['jobs'].values() if j['state'] != 'consumed']
    assert all(own_run is not None and j['run'] == str(own_run) for j in active), 'another unconsumed owner remains'
    if own_run is not None:
        assert len(active) == 1 and active[0]['source']['head'] == COMMIT

def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<20*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    p=load(O/'attribution-plan.json')
    for r in p['binding_refs']:
        f=Path(r['path']);assert f.is_absolute() and f.resolve(strict=True)==f and not f.is_symlink() and f.stat().st_size==r['bytes'] and r['bytes']<16*1024**2
        assert sha(f)==r['sha256'],f
    marker=p['generated_marker_provenance']
    assert Path(marker['path']).read_text().splitlines()[marker['line']-1]==marker['literal']
    base=Path(p['text_owner']);result=load(base/'result.json');report=load(base/'collection-result.json')
    assert result['result']=='PASS_NOTICE_COLLECTION_WITH_OPEN_DISPOSITIONS' and result['execution_error'] is None
    assert not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
    assert report['original_collector_exit']==0 and report['occurrences']==43 and report['reused_occurrences']==38 and report['new_occurrences']==5
    assert report['publication_clearance'] is False and report['target_execution'] is False and report['network_used'] is False
    consumed=load(p['accepted_notice_consumed']['path'])
    assert consumed['id']==p['accepted_notice_admission'] and consumed['state']=='consumed'
    assert all(type(consumed['original_result'][k]) is int and consumed['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert len(p['records'])==8 and len({(x['component'],x['profile']) for x in p['records']})==8
    historical=load(base/'resume.json')
    assert historical['original_collector_exit']==1 and historical['prior_owner_exceeded_256MiB_bound'] is True
    completed={(r['path'],r['sha256'],r['bytes']) for r in historical['completed']}
    for r in p['records']:assert (r['path'],r['sha256'],r['bytes']) in completed
    assert p['publication_clearance'] is False
    return p

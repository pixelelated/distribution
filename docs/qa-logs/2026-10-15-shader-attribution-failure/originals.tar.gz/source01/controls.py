#!/usr/bin/env python3
"""UNRUN pure candidate/ancestry controls; only this packet's pure source is loaded."""
from pathlib import Path
import hashlib,json,runpy
S=runpy.run_path(str(Path(__file__).resolve().parent/'templates/scope.py'))
R,C,D=S['relation'],S['candidates'],S['disposition'];checked=[]
def check(name,condition):assert condition,name;checked.append(name)
check('ancestor-directory',R('crt/a.slang','crt/LICENSE')=='ANCESTOR_CANDIDATE')
check('not-lexical-prefix',R('crt2/a.slang','crt/LICENSE')=='UNRELATED_CANDIDATE')
check('self-notice',R('README.md','README.md')=='SELF')
check('root-is-candidate-only',R('crt/a.slang','LICENSE')=='ANCESTOR_CANDIDATE')
try:R('../escape','LICENSE')
except AssertionError:checked.append('parent-traversal-refused')
else:raise AssertionError('traversal accepted')
raw=b'/* Copyright A\nPermission is hereby granted to use.\n*/\nvoid main() {}\n';cs=C(raw)
check('whole-comment-reference',any(c['start_byte']==0 and c['end_byte_exclusive']==raw.index(b'*/')+2 for c in cs))
check('exact-byte-hashes',all(c['sha256']==hashlib.sha256(raw[c['start_byte']:c['end_byte_exclusive']]).hexdigest() for c in cs))
check('no-candidate-clearance',all(c['permission_determined'] is False for c in cs))
check('copyright-only-not-permission',D(True,['copyright'],[])=='ATTRIBUTION_WITHOUT_RECOGNIZED_PERMISSION_CANDIDATE')
check('filename-does-not-grant',D(True,[],[])=='NO_RECOGNIZED_PERMISSION_CANDIDATE_REVIEW_RETAINED_TEXT')
check('ancestor-not-automatic',D(True,[],['licence_reference'])=='ANCESTOR_PERMISSION_OR_LICENCE_CANDIDATE_SCOPE_OPEN')
check('asset-stays-specific-open',D(False,[],['permission_clause'])=='ASSET_OR_UNRETAINED_TEXT_SCOPE_OPEN')
mixed=C(b'/* GPL license. Portion under MIT license. Non-commercial use only. */')
check('mixed-restriction-retained',any('restriction_candidate' in c['tags'] and 'licence_reference' in c['tags'] for c in mixed))
raw=b'// Copyright Ren\xe9\n// Licensed under MIT license\n';cs=C(raw)
check('nonutf8-byte-custody',len(cs)==1 and cs[0]['sha256']==hashlib.sha256(raw).hexdigest())
doc=b'Copyright A\n\nPermission is hereby granted.\n\nOther details.\n';cs=C(doc,document=True)
check('complete-document-reference',len(cs)==1 and cs[0]['start_byte']==0 and cs[0]['end_byte_exclusive']==len(doc))
print(json.dumps(dict(result='PASS_PURE_SOURCE_CANDIDATE_CONTROLS',cases=checked,production_inputs_read=False,collector_imported=False,target_execution=False),sort_keys=True))

# ZeroTier selected `one` compile without nonfree — UNRUN

This is one isolated candidate compile under #528. It does not change a product
recipe, pin, cached source, installed binary, firmware, or shared record. No
preparer, extraction helper, compiler, container, or target binary has run.
The only completed work is passive source/archive metadata reading, hashing 35
named inputs, source authoring, and AST/bash syntax parsing.

The candidate is the already reviewed one-file change in
`/tmp/pix-m7-zerotier-header-resolution-20261015`, seal
`770f89c532532e7c87f0237fb7003752ace19d83ad44f8739c2ce99e6581d235`.
Its patch SHA256 is
`5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5`;
`OneService.cpp` is
`b546cf4e77dc15175cca16c4143b5f615808e5d30a0ceafdf802881425b812e8`.
It guards the three named nonfree includes and corresponding pointer lifetime
sites using the existing controller macros, with explicit standard headers.
The previous packet holds the upstream/history applicability analysis. This
packet includes no complete nonfree header or license-source copies.

## Exact inputs and ordinary recipe

Frozen distribution:
`/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02`, commit
`f8636de1d105275dbf9420bbabbbc26f79abb10f`. The selected recipe SHA256 is
`8ff699da5820673e17264a160ac4a84c734ce3496a38022fbb8248b0d513b431`.
The retained source is
`/workspace/cache/rocknix-sources/zerotier-one/zerotier-one-1.16.0.tar.gz`,
12,023,748 bytes, SHA256
`aa9de313d365bf0efb3871aaa56f2d323a08f46df47b627c4eff4f4203fa7fc5`.
Passive TAR inspection found 3,764 members and 59,336,122 declared regular-file
bytes. The 21 `nonfree` entries contain 278,164 bytes. Extraction is still pending.
The future helper will validate the exact member index and omit those entries
before any body is written. The original archive remains immutable and held.

Use the qualified cached builder, without pulling:
`ghcr.io/pixelelated/build@sha256:988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39`.
Mount the frozen GENERIC GCC15.2.0 toolchain read-only at its generated prefix
`/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain`.
Only the listed configuration/package files, two existing package indexes,
selected stamp, toolchain and source archive are mounted. The cached unpacked
ZeroTier tree and the original diagnostic packet are not mounted. The build
source path `/work/source/nonfree` must never exist. The compiler has no unpacked
nonfree header tree available through these mounts.

`build-plan.json` binds 35 explicit files, 132,312,774 bytes, including both
compiler wrappers, actual GCC/G++/cc1/cc1plus/collect2, make, assembler, linker,
readelf, nlohmann header and the source archive. This is an explicit input basis,
not a pretense that every implicit sysroot dependency is known before compiling.
`plan.py` records actual host inode/mode/uid/gid/nsmtime plus PID/user namespace
and maps during future root preparation. Sandbox-projected ownership is not
used as actual host ownership.

Inside the container, `compile.sh` sources the actual frozen `config/options
zerotier-one` and calls the normal `setup_toolchain target manual`. Existing
read-only package indexes prevent index regeneration; the existing read-only
CMake toolchain file prevents generation. No install/build/unpack entrypoint,
stamp manipulation, cache copy, or dependency installation is used. All source
files except the exact reviewed OneService replacement are byte-rechecked after
compilation. The baseline service body must first equal
`f7bf80806777e802f23164b086021aa6fae638ce198eeeda3eef07159e4de552`.

The normal effective public flags are recorded and checked before compilation:
C/C++ use x86-64-v3, generic tuning, Wall/pipe, O2, omit-frame-pointer and NDEBUG;
link uses the normal architecture/as-needed/BFD selection. Ccache is disabled.
The exact two recipe commands are bundled libnatpmp's default make, then
`make -f make-linux.mk ZT_SSO_SUPPORTED=0 one`, with the recipe's libnatpmp include
and library search additions. No controller/nonfree/official feature is enabled.
Both normal host-header auto-detection probes are recorded without overriding
upstream's selection.

The only flag additions are diagnostic: `-MD -MP` for actual C/C++ dependencies,
and GNU ld `--dependency-file` for the final `one` link. This does not claim
byte reproducibility. The resulting dependency inventory requires every built
C/C++ object to have a `.d`, includes direct assembly sources and the actual link
list, hashes the consumed files, and refuses any path containing `nonfree` or
resolving outside the private source/frozen toolchain. It retains raw `.d` files.
The final target must be x86-64 ELF and the two normal CLI links must point at it.
Readelf is a host tool; no new target executable, including libnatpmp's generated
utilities, is executed. Ordinary target `one` builds these utilities as the
unchanged recipe does; it does not run them.

## Lifecycle, resources, and commands

The source derivative reuses the completed Wi-Fi compiler owner pattern from
`/tmp/pix-m7-wifi-compile-20261015`. Its original result PASS/attach0/container0/
watchdog0 is retained by exact copy. `docker_owner.py` and `watchdog.py` are byte
identical; the original six files are retained byte-losslessly in
`qualified-lifecycle-originals.tar.gz` (archive modes normalized0644, not original
metadata). `lifecycle.diff` exposes the new source/bind/one-stage adaptations.
No new process/container framework is introduced.

One 900-second work clock includes input checking, extraction, compile, source/
dependency readback and readelf. Docker has no network, read-only root, no added
capabilities, no-new-privileges, normal uid/gid, 2 CPUs, 4 GiB RAM/no swap, 256 PIDs
and a 64 MiB `/tmp`. The source helper rejects >4,000 TAR members, >64 MiB decoded
content, duplicate/unsafe names, special files and unsafe symlinks. Whole-owner
scratch is sampled at 1 GiB with a 512 MiB host-free floor; this is a sampled
ceiling, not a filesystem quota. Inner children inherit a 256 MiB per-file limit
and no core dumps. Reserve another 600 seconds for the existing bounded cleanup
operations and watchdog wait; that reserve is a forecast, not a new universal
outer cleanup deadline. Root supervises at most60-second intervals.

After root's exclusive allocation, use one fresh owner. These commands are
separate so root can inspect each original result before the next action:

```bash
bash /tmp/pix-m7-zerotier-compile-plan-20261015/commands.sh prepare
bash /tmp/pix-m7-zerotier-compile-plan-20261015/commands.sh preflight
bash /tmp/pix-m7-zerotier-compile-plan-20261015/commands.sh report
bash /tmp/pix-m7-zerotier-compile-plan-20261015/commands.sh admit
bash /tmp/pix-m7-zerotier-compile-plan-20261015/commands.sh launch
# Actively supervise; wait for actual runner, launcher, container and watchdog closure.
bash /tmp/pix-m7-zerotier-compile-plan-20261015/commands.sh completion
bash /tmp/pix-m7-zerotier-compile-plan-20261015/commands.sh consume
```

Default fresh owner:
`/workspace/tmp/pix-m7-zerotier-compile-20261015-01`.
The live stage is `stages/zerotier-compile`, with its own admission/output roots.
The canonical host tuple is explicitly ROCKNIX/GENERIC_X64/x86_64. The host must
be in the actual PID namespace with the cached builder and frozen inputs present.
A missing/changed input or tool stops this proof; no download/fallback/rebuild.
No runtime preparation or owner-existence assertion is claimed by this packet.

The qualified owner machinery retains original child/attach/container/watchdog
statuses, checks the actual host/container PID handshake and cgroup limits,
retires only its exact owned CID, and rejects forced cleanup, OOM or survivors.
The completion helper additionally requires the original runner/command/monitor
and launcher/wrapper all0 plus a successful fresh container-ID absence census;
ordinary `build-admission consume` performs its existing process/result checks.
No result file is prefilled. A failed compile or guard stays failed; root retains
its originals and uses ordinary failed-investigated consumption. Do not reuse an
owner or relabel a forced cleanup as a pass.

## Interpretation and release

A future PASS establishes that this candidate's ordinary selected GENERIC_X64
`one` target compiles/links while its source tree excludes nonfree, with the
actual dependency inventory retained. It does not establish controller-build
compatibility, native ARM compilation, device behavior, packaged firmware identity,
license clearance or publication clearance. No extra matrix is proposed here.
Product adoption/source delivery remains a separate root-owned decision after
this finite result; no universal rebuild gate is added.

Retain compact original receipts, source/patch identities and consumed dependency
lists. After their immediate verification use, root can release the private
extracted/object scratch through the established owned-output disposition. Hold
the original source archive and any separately selected corresponding-source
artifact; no automatic deletion or public source release happens in this proof.

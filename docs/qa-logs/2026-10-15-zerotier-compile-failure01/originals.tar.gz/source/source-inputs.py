#!/usr/bin/env python3
"""Future container-only bounded extraction/readback. No source body is executed here."""
import hashlib,json,os,posixpath,shlex,stat,tarfile
from pathlib import Path,PurePosixPath

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def put(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def base():return json.loads(Path('/plan/build-plan.json').read_text())
def source_path(name):
 p=PurePosixPath(name);need(p.parts and p.parts[0]=='ZeroTierOne-1.16.0' and not p.is_absolute() and all(x not in ('','.','..') for x in p.parts) and '\\' not in name and str(p)==name,'unsafe archive path')
 return Path(*p.parts[1:])
def extract():
 b=base();archive=Path('/inputs/source.tar.gz');need(digest(archive)==b['archive_sha256'],'archive differs')
 expected=json.loads(Path('/plan/archive-index.json').read_text());need(len(expected)==3764,'unexpected archive index')
 root=Path('/work/source');root.mkdir();rows=[];seen=set();total=0;excluded=[];pending_links=[]
 with tarfile.open(archive,'r:gz') as t:
  for i,m in enumerate(t):
   need(i<4000 and m.name not in seen,'archive count/duplicate');seen.add(m.name);rel=source_path(m.name)
   row={'name':m.name,'type':'file' if m.isfile() else 'directory' if m.isdir() else 'symlink' if m.issym() else 'REJECT','bytes':m.size,'mode':m.mode,'linkname':m.linkname,'excluded':bool(rel.parts and rel.parts[0]=='nonfree')}
   need(i<len(expected) and row==expected[i],'archive member identity differs');total+=m.size;need(total<=64*1024**2,'archive decoded bound')
   need(row['type']!='REJECT' and not(m.mode&0o7000),'special archive member')
   if row['excluded']:excluded.append(row);continue
   p=root/rel
   if m.isdir():p.mkdir(parents=True,exist_ok=True);continue
   p.parent.mkdir(parents=True,exist_ok=True)
   if m.issym():
    target=posixpath.normpath(str(rel.parent)+'/'+m.linkname)
    need(not m.linkname.startswith('/') and target!='..' and not target.startswith('../') and target.split('/')[0]!='nonfree','unsafe symlink')
    pending_links.append((p,m.linkname));continue
   need(not p.exists() and not p.is_symlink(),'extraction collision');h=hashlib.sha256();count=0
   with t.extractfile(m) as src,p.open('xb') as dst:
    for chunk in iter(lambda:src.read(1048576),b''):
     count+=len(chunk);need(count<=m.size,'member expanded beyond header');dst.write(chunk);h.update(chunk)
   need(count==m.size,'short member');p.chmod(m.mode&0o777)
   rows.append({'path':str(rel),'bytes':m.size,'sha256':h.hexdigest(),'mode':m.mode&0o777})
 need(len(seen)==len(expected) and total==59336122 and len(excluded)==21,'archive totals differ')
 for p,target in pending_links:p.symlink_to(target)
 p=root/'service/OneService.cpp';need(digest(p)==b['baseline_sha256'],'original source differs')
 candidate=Path('/plan/OneService.cpp');need(digest(candidate)==b['candidate_sha256'],'candidate differs')
 p.write_bytes(candidate.read_bytes())
 for row in rows:
  if row['path']=='service/OneService.cpp':row.update(bytes=p.stat().st_size,sha256=digest(p),modified_by_patch=b['patch_sha256'])
 need(not (root/'nonfree').exists() and not (root/'nonfree').is_symlink(),'nonfree tree exposed')
 put('/receipts/source-before.json',{'files':rows,'links':[{'path':str(p.relative_to(root)),'target':t} for p,t in pending_links],'excluded':excluded,'archive_sha256':b['archive_sha256'],'candidate_sha256':b['candidate_sha256'],'extracted_regular_bytes':sum(x['bytes'] for x in rows)})
 return rows

def depnames(path,cwd):
 text=path.read_text();need(len(text)<=4*1024**2,'dependency text too large')
 logical=text.replace('\\\n','').splitlines()[0];need(':' in logical,'dependency rule absent')
 # All selected filenames are without whitespace; shlex handles GCC backslash escaping.
 names=shlex.split(logical.split(':',1)[1]);need(names,'empty dependency rule')
 return [(Path(x) if Path(x).is_absolute() else cwd/x) for x in names]
def verify():
 b=base();root=Path('/work/source');before=json.loads(Path('/receipts/source-before.json').read_text());need(not (root/'nonfree').exists() and not (root/'nonfree').is_symlink(),'nonfree appeared')
 for r in before['files']:
  p=root/r['path'];need(p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and digest(p)==r['sha256'] and stat.S_IMODE(p.stat().st_mode)==r['mode'],'source changed: '+r['path'])
 for r in before['links']:need(os.readlink(root/r['path'])==r['target'],'source link changed')
 dependency_files=sorted(root.rglob('*.d'));need(10<len(dependency_files)<300,'missing/excess dependency files')
 names=[];units=[]
 for path in dependency_files:
  if path.suffix=='.d':names+=depnames(path,path.parent if path.parent==root/'ext/libnatpmp' else root)
 # Every newly compiled C/C++ object has an actual -MD output. Assembly units are direct source dependencies.
 for obj in root.rglob('*.o'):
  sources=[obj.with_suffix(s) for s in ('.cpp','.cc','.c','.S','.s') if obj.with_suffix(s).is_file()]
  need(len(sources)==1,'object source unclear: '+str(obj));src=sources[0]
  if src.suffix not in ('.s','.S'):need(obj.with_suffix('.d').is_file(),'C/C++ dependency list absent: '+str(obj))
  names.append(src);units.append({'object':str(obj.relative_to(root)),'source':str(src.relative_to(root)),'object_sha256':digest(obj)})
 need(any(x['source']=='service/OneService.cpp' for x in units),'candidate object not built')
 link=Path('/receipts/link.d');need(link.is_file(),'actual link dependency list absent');names+=depnames(link,root)
 toolroot=Path(b['container_root'])/b['build_relative']/'toolchain';unique={}
 for p in names:
  resolved=p.resolve();need('nonfree' not in p.parts and 'nonfree' not in resolved.parts,'nonfree dependency consumed')
  need(resolved.is_relative_to(root) or resolved.is_relative_to(toolroot),'dependency outside private source/frozen toolchain: '+str(p))
  need(resolved.is_file(),'dependency missing: '+str(p))
  unique[str(p)]={'path':str(p),'resolved':str(resolved),'bytes':resolved.stat().st_size,'sha256':digest(resolved)}
 need(len(unique)<10000 and sum(x['bytes'] for x in unique.values())<1024**3,'dependency inventory bound')
 artifact=root/'zerotier-one'
 with artifact.open('rb') as f:head=f.read(20)
 need(head[:6]==b'\x7fELF\x02\x01' and int.from_bytes(head[18:20],'little')==62,'not target x86-64 ELF')
 for n in ['zerotier-cli','zerotier-idtool']:need(os.readlink(root/n)=='zerotier-one','one target link absent')
 for row in unique.values():need(digest(row['resolved'])==row['sha256'],'dependency changed during readback')
 put('/receipts/consumed-dependencies.json',{'units':units,'dependency_files':[str(p.relative_to(root)) for p in dependency_files]+['/receipts/link.d'],'files':list(unique.values()),'nonfree_dependencies':[]})
 put('/receipts/target-artifact.json',{'path':str(artifact),'bytes':artifact.stat().st_size,'sha256':digest(artifact),'source_archive_sha256':b['archive_sha256'],'candidate_sha256':b['candidate_sha256'],'patch_sha256':b['patch_sha256'],'distribution_commit':b['distribution_commit'],'nonfree_present':False,'nonfree_dependencies':[],'scope':'Isolated GENERIC_X64 one target compile/link only. Target NOT EXECUTED; no firmware or legal/publication qualification.'})
if __name__=='__main__':
 import sys
 need(len(sys.argv)==2 and sys.argv[1] in ('extract','verify'),'phase required')
 extract() if sys.argv[1]=='extract' else verify()

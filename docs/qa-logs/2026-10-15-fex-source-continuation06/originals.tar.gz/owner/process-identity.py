"""Exact qualified numeric-proc and pidfd custody helpers; no work at import."""
from pathlib import Path
import os
import signal


def identity(pid):
    """A disappeared PID is benign; an unreadable existing PID is unknown, never absent."""
    directory = Path('/proc') / str(pid)
    try:
        with (directory / 'stat').open('rb') as stream:
            raw = stream.read(65537)
    except (FileNotFoundError, ProcessLookupError):
        try:
            directory.stat()
        except (FileNotFoundError, ProcessLookupError):
            return None
        raise RuntimeError('stat unavailable for a still-present proc PID ' + str(pid))
    assert len(raw) <= 65536, 'oversized proc stat'
    prefix, separator, tail = raw.rpartition(b')')
    assert separator and prefix.split(b' (', 1)[0] == str(pid).encode(), 'malformed proc stat'
    fields = tail.split()
    assert len(fields) >= 20, 'short proc stat'
    return dict(pid=pid, ppid=int(fields[1]), pgid=int(fields[2]),
                state=fields[0].decode('ascii'), start_ticks=int(fields[19]))


def census():
    rows = []
    for count, entry in enumerate(Path('/proc').iterdir(), 1):
        assert count <= 131072, 'bounded proc census exceeded'
        if not entry.name.isascii() or not entry.name.isdigit():
            continue
        row = identity(int(entry.name))
        if row is not None:
            rows.append(row)
    return sorted(rows, key=lambda row: row['pid'])


def children(pid):
    assert identity(pid) is not None, 'cannot observe fixture parent'
    return [row for row in census() if row['ppid'] == pid]


def tree(pid):
    assert identity(pid) is not None, 'cannot observe fixture tree root'
    rows = census()
    answer, parents, seen = [], [pid], {pid}
    while parents:
        parent = parents.pop()
        for row in rows:
            if row['ppid'] == parent:
                assert row['pid'] not in seen, 'cyclic proc ancestry'
                seen.add(row['pid']); answer.append(row); parents.append(row['pid'])
    return answer


def same(row):
    now = identity(row['pid'])
    return now is not None and now['start_ticks'] == row['start_ticks']


def signal_child(row, parent, signum=signal.SIGKILL):
    """Only direct/adopted children through identity-checked pidfds may be signaled."""
    assert row['ppid'] == parent, 'refusing a non-child signal'
    def stable(now):
        return all(now[key] == row[key] for key in ['pid', 'ppid', 'pgid', 'start_ticks'])
    now = identity(row['pid'])
    if now is None:
        return dict(identity=row, signal=signum, outcome='already-gone')
    assert stable(now), 'child identity changed before pidfd acquisition'
    try:
        fd = os.pidfd_open(row['pid'], 0)
    except ProcessLookupError:
        return dict(identity=row, signal=signum, outcome='gone-before-pidfd')
    try:
        now = identity(row['pid'])
        if now is None:
            return dict(identity=row, signal=signum, outcome='gone-after-pidfd')
        assert stable(now), 'child identity changed after pidfd acquisition'
        try:
            signal.pidfd_send_signal(fd, signum, None, 0)
        except ProcessLookupError:
            return dict(identity=row, signal=signum, outcome='gone-before-signal')
        return dict(identity=row, signal=signum, outcome='pidfd-signal')
    finally:
        os.close(fd)

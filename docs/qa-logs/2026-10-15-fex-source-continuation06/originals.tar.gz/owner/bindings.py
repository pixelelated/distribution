"""Exact prior source/provenance only; no product/cache traversal."""
from pathlib import Path
import hashlib,json,os,stat,urllib.parse
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
INTENDED_ORDER=['06-libX11-1.8.12.tar.xz', '07-xorgproto-2024.1.tar.xz', '08-libXrandr-1.5.4.tar.xz', '02-libdrm-2.4.129.tar.xz']
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    return h.hexdigest()
def load(path):
    p=Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size<20*1024**2,p
    return json.loads(p.read_text())
def host_and_serialization(own_run=None):
    assert (os.getuid(),os.getgid())==(1000,1000)
    assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]'
    assert os.readlink('/proc/self/ns/user')=='user:[4026531837]'
    jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values()
    active=[j for j in jobs if j['state']!='consumed']
    assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
    if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def curl_identity(path):
    p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<16*1024**2 and os.access(p,os.X_OK)
    h=sha(p);after=p.stat();assert all(getattr(after,k)==getattr(s,k) for k in ['st_dev','st_ino','st_size','st_mode','st_uid','st_gid','st_mtime_ns']),'curl identity changed'
    with p.open('rb') as f:header=f.read(64)
    assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==62,'host AMD64 ELF required'
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,sha256=h)
def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<20*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    plan=load(O/'collection-plan.json')
    for name,h in plan['binding_refs'].items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2
        assert sha(p)==h,name
    assert len(plan['selected_archives'])==4 and plan['logical_downloads']==4
    assert plan['publication_clearance']is False and plan['source_bundle_complete']is False
    proposal=load('/tmp/pix-m7-fex-dependency-disposition-20261015/acquisition-proposal.json')
    selected=plan['selected_archives'];prior=plan['reused_prior_archives'];custody=plan['prior_archive_custody']
    assert len(prior)==len(custody)==4
    combined=selected+[r['selection'] for r in prior]
    assert len({r['sha256'] for r in combined})==8
    assert {(r.get('provenance_url',r['canonical_url']),r['sha256']) for r in combined}=={(r['urls'][0],r['hash']) for r in proposal['phase_A']['files']}
    assert [r['key'] for r in selected]==plan['intended_order']==INTENDED_ORDER
    assert [r.get('provenance_url',r['canonical_url']) for r in selected]==[proposal['phase_A']['files'][i]['urls'][0] for i in [5,6,7,1]]
    assert [r['selection']['sha256'] for r in prior]==[proposal['phase_A']['files'][i]['hash'] for i in [0,2,3,4]]
    assert plan['reused_historical_archives']==proposal['reused_archive_sources'] and len(plan['reused_historical_archives'])==3
    failures=plan['prior_failures'];assert len(failures)==5
    assert [r['owner'] for r in failures]==['/workspace/tmp/pix-m7-fex-source-acquisition-20261015-01','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-02','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-03','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-05']
    assert [r['response_body_bytes'] for r in failures]==[152673392,166,113965324,242664,324]
    accepted_by_owner={}
    for original in failures:
        accepted=load(original['acceptance']);failure=load(original['failure_receipt'])
        assert accepted['run']==original['run'] and accepted['disposition']=='failed-investigated' and accepted['expected_rc']==1
        code=load(original['consume_exit'])[original['consume_exit_field']];assert type(code)is int and code==0
        assert failure['original_collector_exit']==1 and failure['completed_archives']==original['completed_archives']
        assert sum(r['actual_bytes'] for r in failure['payload_reservations'])==original['response_body_bytes']
        accepted_by_owner[original['owner']]=accepted
    consumed=load(failures[-1]['consumed'])
    assert consumed['state']=='consumed' and consumed['id']=='7fe199c7e316404ea997a15d30f9a667'
    assert consumed['run']==failures[-1]['run'] and consumed['submission_owner']==failures[-1]['owner']
    assert consumed['evidence_sha256']==sha(failures[-1]['acceptance']) and consumed['outputs_held'] is True and consumed['deleted_bytes']==0
    assert [consumed['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[1,0,1]
    for archive,record in zip(prior,custody):
        assert archive==load(record['archive_receipt']) and archive['exact_flat_sha256_verified']is True
        assert Path(archive['archive']['path']).parent==Path(record['owner'])/'archives'
        assert Path(record['archive_receipt']).parent==Path(record['owner'])/'collection'
        wait=load(record['wait_receipt']);http=load(record['http_receipt'])
        assert type(wait['original_curl_returncode'])is int and wait['original_curl_returncode']==0 and wait['wait_observed']is True
        assert http['http_status']==200 and http['body']==archive['archive'] and not http['redirect_url']
        assert archive['archive']['sha256']==archive['selection']['sha256']
        assert any(e['path']==archive['archive']['path'] and e['sha256']==archive['archive']['sha256'] for e in accepted_by_owner[record['owner']]['evidence'])
    assert sum(r['archive']['bytes'] for r in prior)==266879580
    assert plan['phase_A_response_body_accounting']==dict(original_aggregate_cap_bytes=402653184,prior_response_body_bytes=266881870,held_verified_archive_bytes=266879580,prior_redirect_body_bytes=2290,continuation_response_body_cap_bytes=135771314)
    limits=load(O/'resources.json');assert limits['compressed_archive_aggregate_bytes']==135771314 and limits['max_http_requests_including_redirects']==20
    route=plan['wayland_route_revision'];http=load(route['observed_http_receipt'])
    assert sha(route['observed_http_receipt'])==route['observed_http_receipt_sha256']
    assert http['original_curl_returncode']==0 and http['http_status']==302
    assert http['redirect_url']==route['observed_redirect_origin']=='https://fsn1.your-objectstorage.com/[redacted]'
    assert http['redirect_url_sha256']==route['observed_redirect_url_sha256']
    assert prior[3]['selection']['allowed_redirect_hosts']==route['allowed_redirect_hosts']==['fsn1.your-objectstorage.com','gitlab.freedesktop.org']
    origin=urllib.parse.urlsplit(http['redirect_url'])
    assert origin.scheme=='https' and origin.hostname=='fsn1.your-objectstorage.com' and origin.netloc==origin.hostname
    assert origin.username is None and origin.password is None and not origin.query and not origin.fragment
    assert all('fsn1.your-objectstorage.com' not in r['allowed_redirect_hosts'] for r in selected)
    assert plan['status']=='SOURCE_ONLY_SEALED_UNRUN', 'route evidence must be finalized before allocation'
    route=plan['mirror_route_revision'];diagnostic=load(route['diagnostic_result']);accepted=load(route['diagnostic_acceptance'])
    assert diagnostic['head_only'] is True and diagnostic['redirects_followed'] is False and diagnostic['source_bodies_downloaded'] is False
    assert accepted['original_tool_exit']==0 and all(type(accepted['runner'][k])is int and accepted['runner'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert accepted['head_only'] is True and accepted['redirects_followed'] is False and accepted['archives_downloaded'] is False
    rows={r['name']:r for r in diagnostic['rows']};locations={r['probe']:r for r in load(route['observed_redirects'])}
    assert len(rows)==4 and len(locations)==3 and diagnostic['requests']==4
    official=json.dumps(load(route['official_page_readback']))
    assert 'https://yehkri.com/mirror/xorg/' in official and 'ftp.osuosl.org/pub/blfs/' in official
    assert 'https://ftp2.osuosl.org/pub/blfs/' in json.dumps(load(route['osuosl_root_readback']))
    assert 'libdrm-2.4.129.tar.xz' in json.dumps(load(route['libdrm_directory_readback']))
    # Preserve the observed OSUOSL 200 route; the three Xorg mirror routes below are superseded.
    selection=selected[3];row=rows['osuosl-drm']
    assert selection['canonical_url']==row['url']=='https://ftp2.osuosl.org/pub/blfs/conglomeration/libdrm/libdrm-2.4.129.tar.xz'
    assert selection['route_head_probe']=='osuosl-drm'
    assert type(row['original_curl_exit'])is int and row['original_curl_exit']==0 and row['wait_observed'] is True
    assert '--head' in row['argv'] and '--location' not in row['argv'] and row['argv'][row['argv'].index('--retry')+1]=='0'
    assert row['summary'].split()[0]=='200' and selection['allowed_redirect_hosts']==['ftp2.osuosl.org'] and selection['allowed_redirect_urls']==[]
    mac=plan['macports_route_revision'];directory=load(mac['result']);accepted_mac=load(mac['acceptance'])
    assert directory['archive_bodies'] is False and directory['redirects_followed'] is False
    assert accepted_mac['archive_bodies_requested'] is False and accepted_mac['original_tool_exit']==0
    assert all(type(accepted_mac['runner'][k])is int and accepted_mac['runner'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert len(directory['rows'])==len(accepted_mac['exact_links'])==3
    links={r['filename']:r for r in accepted_mac['exact_links']};indexes={r['filename']:r for r in directory['rows']}
    expected=['https://distfiles.macports.org/xorg-libX11/libX11-1.8.12.tar.xz','https://distfiles.macports.org/xorg-xorgproto/xorgproto-2024.1.tar.xz','https://distfiles.macports.org/xorg-libXrandr/libXrandr-1.5.4.tar.xz']
    for selection,url in zip(selected[:3],expected):
        link=links[selection['filename']];index=indexes[selection['filename']]
        assert selection['canonical_url']==link['url']==url and index['url']+index['filename']==url
        assert index['original_curl_exit']==0 and index['filename_present'] is True
        assert sha(selection['route_directory_index'])==index['sha256']==link['index_sha256']
        assert Path(selection['route_directory_index']).stat().st_size==index['bytes']
        assert selection['allowed_redirect_hosts']==['distfiles.macports.org'] and selection['allowed_redirect_urls']==[]
    reuse=plan['guard_reuse']
    assert reuse['cases']==52 and reuse['collector_sha256']==sha(O/'collect.py')
    assert reuse['report_sha256']==sha(reuse['report'])==sha(O/'guard-report.json')
    assert plan['guard_run']==reuse['run']=='/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T143931Z-0ffabc43'
    guard=load(O/'guard-report.json');assert guard['result']=='PASS_SYNTHETIC_SOURCE_ACQUISITION_GUARDS'
    assert guard['collector_sha256']==sha(O/'collect.py') and guard['filesystem_writes_except_requested_receipt']is False and guard['network_used']is False
    assert len(guard['cases'])>=30 and len({r['case'] for r in guard['cases']})==len(guard['cases']) and all(r['result'].startswith('PASS') for r in guard['cases'])
    guard_run=Path(plan['guard_run']);assert guard_run.parent==VM_TREE/'.build-runs'
    original=load(guard_run/'runner-result.json');assert all(type(original[k])is int and original[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert (guard_run/'build.rc').read_text().strip()=='0'
    tools=load(O/'host-tools.json');assert set(tools)=={'curl'}
    assert curl_identity(tools['curl']['path'])==tools['curl']['identity']
    return plan

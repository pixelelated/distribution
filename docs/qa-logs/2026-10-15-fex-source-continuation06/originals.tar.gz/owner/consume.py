#!/usr/bin/env python3
"""Consume only original successful collection channels; gaps never become clearance."""
from pathlib import Path
import hashlib,json,runpy,subprocess,stat,urllib.parse
O=Path(__file__).resolve().parent
B=runpy.run_path(str(O/'bindings.py'));B['verify'](O)
assert Path.cwd()==B['VM_TREE']
load,sha=B['load'],B['sha']
run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs'
B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
for f in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert f.read_text().strip()=='0',f
result,cleanup=load(O/'result.json'),load(O/'cleanup.json')
assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete'] is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established'] is False
assert result['execution_error'] is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json')
assert child['wait_observed'] is True and type(child['original_child_returncode']) is int and child['original_child_returncode']==0
assert child['qualification'] is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json')
assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit']) is int and report['original_collector_exit']==0
assert report['publication_clearance'] is False and report['independent_SYSTEM_relation_established'] is False
assert not (O/'collection-failure.json').exists()
policy=load(O/'collection-plan.json')['owner_output_enforcement']
assert report['owner_output_enforcement']==policy and policy['owner_ceiling_bytes']==1024**3
limits=load(O/'resources.json')
assert type(report['initial_owner_bytes'])is int and 0<report['initial_owner_bytes']<=limits['initial_owner_maximum_bytes']
assert report['accounted_owner_bytes_before_report']<=policy['normal_collector_write_ceiling_bytes']
assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=1024**3
assert len(report['rows'])==4 and report['logical_downloads']==4 and 4<=len(report['downloads'])<=20 and report['actual_http_requests']==len(report['downloads'])
assert report['source_rebuild']is False and report['source_execution']is False and report['target_execution']is False and report['archive_extraction']is False and report['network_used']is True
plan=load(O/'collection-plan.json')
assert [r['selection'] for r in report['rows']]==plan['selected_archives']
assert report['reused_historical_archives']==plan['reused_historical_archives'] and report['historical_archive_payloads_rehashed']is False
assert report['phase_B_unperformed']==plan['phase_B'] and report['source_bundle_complete']is False
assert len(report['payload_reservations'])==len(report['log_reservations'])==len(report['downloads'])
request_by_key={r['key']:r for r in report['downloads']};assert len(request_by_key)==len(report['downloads'])
def check_file(record,parent):
    p=Path(record['path']);assert p.parent==parent and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size==record['bytes'] and sha(p)==record['sha256']
    actual=dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
    assert all(record[k]==v for k,v in actual.items()),'retained file identity changed'
assert report['reused_prior_archives']==plan['reused_prior_archives'] and report['prior_archive_payload_revalidated']is True
assert report['phase_A_response_body_accounting']==plan['phase_A_response_body_accounting']
for prior,custody in zip(plan['reused_prior_archives'],plan['prior_archive_custody']):
    check_file(prior['archive'],Path(custody['owner'])/'archives')
assert report['compressed_bytes']+266881870<=402653184
for payload,log,download in zip(report['payload_reservations'],report['log_reservations'],report['downloads']):
    assert type(download['original_curl_returncode'])is int and download['original_curl_returncode']==0 and download['wait_observed']is True
    wait=load(O/'collection'/(download['key']+'.curl.wait.json'))
    assert wait['original_curl_returncode']==0 and type(wait['original_curl_returncode'])is int and wait['wait_observed']is True
    assert wait['argv']==download['argv'] and wait['url']==download['url'] and wait['url_sha256']==download['url_sha256'] and wait['key']==download['key']
    assert download==load(O/'collection'/(download['key']+'.http.json'))
    assert payload['original_wait_observed']is True and log['original_wait_observed']is True
    assert 0<payload['reserved_bytes']==log['per_stream_limit']==download['effective_body_and_stream_cap']<=limits['compressed_archive_per_file_bytes']
    assert payload['actual_bytes']==download['body']['bytes'] and payload['path']==download['body']['path']
    assert payload['released_bytes']==payload['reserved_bytes']-payload['actual_bytes']
    assert log['actual_bytes']==download['stdout']['bytes']+download['stderr']['bytes']
    assert log['reserved_bytes']==2*log['per_stream_limit'] and log['released_bytes']==log['reserved_bytes']-log['actual_bytes']
    assert dict(payload=payload,logs=log)==load(O/'collection'/(download['key']+'.reservations.json'))
    for key in ['stdout','stderr']:check_file(download[key],O/'collection')
    check_file(download['body'],O/'archives')
assert sum(r['actual_bytes'] for r in report['payload_reservations'])==report['compressed_bytes']<=limits['compressed_archive_aggregate_bytes']
for row in report['rows']:
    selection=row['selection'];key=selection['key']
    assert row==load(O/'collection'/(key+'.archive.json'))
    assert row['exact_flat_sha256_verified']is True and row['source_archive_extracted']is False and row['license_clearance']is False
    chosen=request_by_key[row['original_request_key']]
    assert chosen['asset']==key and chosen['http_status']==200 and not chosen['redirect_url']
    assert row['archive']==chosen['body'] and row['archive']['sha256']==selection['sha256']
    own=[r for r in report['downloads'] if r['asset']==key]
    assert 1<=len(own)<=5 and [r['hop'] for r in own]==list(range(len(own)))
    url=selection['canonical_url'];seen=set()
    for i,request in enumerate(own):
        assert url not in seen;seen.add(url)
        u=urllib.parse.urlsplit(url)
        assert u.scheme=='https' and u.hostname in selection['allowed_redirect_hosts'] and u.netloc==u.hostname
        assert not u.fragment and u.username is None and u.password is None and len(url.encode())<=8192
        assert not any(ord(c)<33 or ord(c)==127 for c in url)
        if i and 'allowed_redirect_urls' in selection:assert url in selection['allowed_redirect_urls'],'unobserved redirect route'
        assert request['url_sha256']==hashlib.sha256(url.encode()).hexdigest()
        assert request['argv_url_redacted']==(i!=0)
        assert request['url']==(selection['canonical_url'] if i==0 else 'https://'+u.hostname+'/[redacted]')
        raw=Path(request['stdout']['path']);assert raw.stat().st_size<=16384
        fields=raw.read_text().splitlines();assert len(fields)==2 and int(fields[0])==request['http_status']
        assert request['redirect_url_sha256']==(hashlib.sha256(fields[1].encode()).hexdigest() if fields[1] else None)
        if i+1<len(own):
            assert request['http_status'] in [301,302,303,307,308] and fields[1]
            url=fields[1]
        else:assert request['http_status']==200 and not fields[1]
assert cleanup['all_recorded_identities_absent'] is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped'] is False
# Same qualified final-inventory strict census and PID/start identity custody.
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']()
owned_keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']}
supervisor=cleanup['supervisor_identity'];assert supervisor is not None
owned_keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in owned_keys]
parents={r['pid'] for r in matching};descendants=[]
while parents:
    children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants]
    descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants,'recorded identity or owned descendant still present'
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[O/n for n in ['result.json','cleanup.json','collection-result.json','collection-plan.json','preparation.json','host-tools.json','seal.json','inner.rc','outer.rc','launcher-result.json','tool-wrapper.rc']]+[run/'runner-result.json',run/'build.rc']
files+=sorted(p for d in ['stage','collection'] for p in (O/d).rglob('*') if p.is_file())
files+=sorted(p for p in (O/'archives').iterdir() if p.is_file())
files += [Path(r['archive']['path']) for r in plan['reused_prior_archives']]
files += [Path(r[k]) for r in plan['prior_failures'] for k in ['acceptance','investigation','consume_exit','failure_receipt']]
files += [Path(r[k]) for r in plan['prior_archive_custody'] for k in ['archive_receipt','wait_receipt','http_receipt']]
assert len(files)<=512 and sum(p.stat().st_size for p in files)<=1024**3
out=O/'admission-completion-evidence.json'
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Four missing exact flat source archives acquired and verified; held prior Linux/glibc/GCC/Wayland reverified and three historical archives referenced. Raw curl streams remain private. PhaseB Nixpkgs/libglvnd/patches, notices, independent retrieval, offhost and publication remain separate; no source execution or extraction.')
raw=(json.dumps(evidence,indent=2)+'\n').encode()
assert len(raw)<=4*1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=1024**3,'completion receipt would exceed owner ceiling'
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed four new exact FEX source archives with held Linux/glibc/GCC/Wayland references; phaseB and publication disposition remain explicit')

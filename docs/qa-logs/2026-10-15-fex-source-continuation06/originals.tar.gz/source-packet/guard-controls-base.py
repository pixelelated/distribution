#!/usr/bin/env python3
"""Pure in-memory controls: exact reused write guards plus reservation release."""
from pathlib import Path, PurePosixPath
import ast,hashlib,io,json,fnmatch
P=Path(__file__).resolve().parent
source=(P/'templates/collect.py').read_bytes()
expected=json.loads((P/'guard-controls-binding.json').read_text())
assert hashlib.sha256(source).hexdigest()==expected['collector_sha256']
tree=ast.parse(source);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['account_output','write','release_log_reservation']]
assert {n.name for n in nodes}=={'account_output','write','release_log_reservation'}
# Only the reviewed write guards and reservation-release definition execute in memory.
assert hashlib.sha256(ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False).encode()).hexdigest()==expected['guard_ast_sha256']
ns={'json':json};exec(compile(ast.Module(body=nodes,type_ignores=[]),'selected-guard-definitions','exec'),ns)
class MemoryPath:
    def __init__(self,name='member.json',data=None,link=False):self.name=name;self.data=data;self.link=link
    def __str__(self):return 'memory-only:'+self.name
    def exists(self):return self.data is not None
    def is_symlink(self):return self.link
    def open(self,mode):
        assert mode=='xb'
        if self.exists() or self.link:raise FileExistsError(self.name)
        p=self
        class Sink(io.BytesIO):
            def __exit__(self,*args):p.data=self.getvalue();self.close()
        return Sink()
rows=[]
def setup(initial,ceiling,per_file=64,reserve=16):
    ns.update(OUTPUT_BYTES=initial,RESOURCES={'per_file_bytes':per_file,'owner_output_ceiling_bytes':ceiling},PLAN={'owner_output_enforcement':{'supervisor_receipt_reserve_bytes':reserve,'failure_receipt_budget_bytes':12,'supervisor_receipt_margin_bytes':4}})
def check(name,path,value,initial,ceiling,expected_error=False,per_file=64):
    setup(initial,ceiling,per_file);before=path.data
    try:ns['write'](path,value)
    except AssertionError:
        assert expected_error;assert path.data==before and ns['OUTPUT_BYTES']==initial
        rows.append({'case':name,'result':'PASS_EXPECTED_REFUSAL','output_bytes':ns['OUTPUT_BYTES']})
    else:
        assert not expected_error
        raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
        assert path.data==raw and ns['OUTPUT_BYTES']==initial+len(raw)
        rows.append({'case':name,'result':'PASS','output_bytes':ns['OUTPUT_BYTES']})
value={'x':1};size=len((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode())
check('normal-exact-reserved-boundary',MemoryPath(),value,7,7+size+16)
check('normal-one-byte-over',MemoryPath(),value,8,7+size+16,True)
check('initial-existing-file-byte-counts',MemoryPath(),value,5+7,5+7+size+16)
check('existing-output-refused-no-overwrite',MemoryPath(data=b'existing'),value,8,64,True)
check('dangling-output-link-refused',MemoryPath(link=True),value,0,64,True)
check('failure-receipt-exact-full-boundary',MemoryPath('collection-failure.json'),value,7,7+size+4)
check('failure-receipt-one-byte-over',MemoryPath('collection-failure.json'),value,8,7+size+4,True)
check('existing-per-file-bound-refusal',MemoryPath(),value,0,64,True,per_file=size-1)
# Normal write cannot consume the reserve; a subsequent bounded failure receipt can.
setup(0,size+16);normal=MemoryPath();ns['write'](normal,value)
failure=MemoryPath('collection-failure.json');ns['write'](failure,{})
assert ns['OUTPUT_BYTES']==size+3 and ns['OUTPUT_BYTES']<=size+16-4
rows.append({'case':'failure-uses-only-bounded-remaining-reserve','result':'PASS','output_bytes':ns['OUTPUT_BYTES']})
check('failure-receipt-share-refusal',MemoryPath('collection-failure.json'),{'x':'0123456789'},0,64,True)
# Four reservation controls; only integer counters/dicts change in memory.
setup(7,500,per_file=200)
ns['account_output'](100);ns['account_output'](110)  # both archive payloads
ns['account_output'](100);ns['account_output'](100)  # current stdout/stderr bounds
r=dict(per_stream_limit=100,reserved_bytes=200,released_bytes=0,original_wait_observed=False)
ns['release_log_reservation'](r,3,7,True)
assert ns['OUTPUT_BYTES']==7+100+110+10 and r['released_bytes']==190 and r['actual_bytes']==10
rows.append(dict(case='two-payloads-two-log-reservations-and-observed-release',result='PASS',output_bytes=ns['OUTPUT_BYTES']))
for name,wait,stdout,stderr,already in [
    ('no-release-without-original-wait',False,3,7,False),
    ('no-second-release',True,3,7,True),
    ('no-release-over-stream-bound',True,3,101,False)]:
    setup(400,600,per_file=200)
    r=dict(per_stream_limit=100,reserved_bytes=200,released_bytes=190 if already else 0,original_wait_observed=already)
    before=r.copy()
    try:ns['release_log_reservation'](r,stdout,stderr,wait)
    except AssertionError:
        assert r==before and ns['OUTPUT_BYTES']==400
        rows.append(dict(case=name,result='PASS_EXPECTED_REFUSAL',output_bytes=ns['OUTPUT_BYTES']))
    else:raise AssertionError('expected reservation refusal')
assert len(rows)==14
print(json.dumps(dict(result='PASS_SYNTHETIC_OUTPUT_GUARD_CONTROLS',collector_sha256=expected['collector_sha256'],cases=rows,candidate_module_imported_or_main_run=False,filesystem_writes=False,production_paths_accessed=False,scope='Three extracted definitions; fake paths and counters only. No curl, collector, preparer, owner census, archive read or runtime qualification.'),sort_keys=True))

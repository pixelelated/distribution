#!/usr/bin/env python3
"""Finite source/metadata readback only; no candidate imports or runtime helpers."""
from pathlib import Path
import ast,hashlib,json,stat
P=Path(__file__).resolve().parent;B=Path('/tmp/pix-m7-fex-source-acquisition-continuation05-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
unchanged=['templates/collect.py','templates/run.py','templates/run.sh','templates/process-identity.py','guard-controls.py','guard-controls-base.py','guard-controls-binding.json','frozen-tools.json']
for n in unchanged:assert (P/n).read_bytes()==(B/n).read_bytes(),n
assert (P/'templates/consume.py').read_text().replace('266881870','266881546')==(B/'templates/consume.py').read_text()
parsed=[]
for p in sorted(P.rglob('*.py')):ast.parse(p.read_text());parsed.append(str(p.relative_to(P)))
for p in P.rglob('*.json'):json.loads(p.read_text())
plan=json.loads((P/'collection-plan.json').read_text());oldplan=json.loads((B/'collection-plan.json').read_text())
assert plan['phase_A_response_body_accounting']['continuation_response_body_cap_bytes']+266879580+2290==384*1024**2
assert plan['reused_prior_archives']==oldplan['reused_prior_archives']
for a,b in zip(plan['selected_archives'],oldplan['selected_archives']):
 for k in ['sha256','provenance_url','fetch_refs','key','filename','hash_mode','packages']:assert a[k]==b[k],k
 assert a['allowed_redirect_urls']==[]
assert plan['selected_archives'][3]==oldplan['selected_archives'][3]
refs=json.loads((P/'new-originals.json').read_text())
for r in refs:
 source=Path(r['path']);copy=P/r['copy'];assert sha(source)==sha(copy)==r['sha256']
 for key,actual in [('bytes',copy.stat().st_size),('mode',stat.S_IMODE(copy.stat().st_mode)),('uid',copy.stat().st_uid),('gid',copy.stat().st_gid),('mtime_ns',copy.stat().st_mtime_ns)]:assert r[key]==actual,(r['path'],key)
guard=json.loads(Path(plan['guard_reuse']['report']).read_text())
assert len(guard['cases'])==52 and all(r['result'].startswith('PASS') for r in guard['cases'])
assert guard['collector_sha256']==sha(P/'templates/collect.py') and guard['guard_controls_sha256']==sha(P/'guard-controls.py')
actual=json.loads(Path(plan['guard_reuse']['run'],'runner-result.json').read_text())
assert all(actual[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
a=functions(B/'templates/bindings.py');b=functions(P/'templates/bindings.py');assert a.keys()==b.keys()
for k in a:
 if k!='verify':assert a[k]==b[k],k
record=dict(status='PASS_STATIC_SOURCE_READBACK_ONLY',candidate_modules_imported=False,guards_executed=False,preparer_executed=False,network_used=False,archive_bodies_read=False,python_syntax_files=parsed,unchanged_bytes={n:sha(P/n) for n in unchanged},consumer_delta='Only 266881546 to 266881870 cumulative accounting constant',unchanged_binding_helpers=sorted(k for k in a if k!='verify'),guard_cases_reused=52,new_original_refs_verified=len(refs),base_seal=sha(B/'SHA256SUMS'),operational_diff_sha256=sha(P/'changes.diff'))
(P/'static-review.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,indent=2))

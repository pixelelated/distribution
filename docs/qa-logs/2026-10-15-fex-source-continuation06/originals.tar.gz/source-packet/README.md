# FEX source acquisition continuation06 — #528

SOURCE ONLY, UNRUN. Root owns preparation, serialized allocation, supervision, readback and consumption. This is a narrow derivative of sealed continuation05 (`cb563dba738fc797d3b692bc4c41d42e26130d1b5242dd05a7059812dce19c6a`), preserving all five failed owners and their original outcomes.

Source05 run `20261015T144121Z-fcadb010` ended command/monitor/runner `1/0/1`, launcher `1`: libX11's mirrored target returned HTTP404/curl22 after one 324-byte redirect body; zero new archives. Ordinary failed-investigated consumption `7fe199c7e316404ea997a15d30f9a667` retained all outputs. `new-originals.json` binds its exact investigation, acceptance, consumed record and failure receipt. No prior archive body was opened or copied during this preparation.

Only the three Xorg transport routes change, in unchanged order:

| Source | Direct route |
| --- | --- |
| libX11 1.8.12 | https://distfiles.macports.org/xorg-libX11/libX11-1.8.12.tar.xz |
| xorgproto 2024.1 | https://distfiles.macports.org/xorg-xorgproto/xorgproto-2024.1.tar.xz |
| libXrandr 1.5.4 | https://distfiles.macports.org/xorg-libXrandr/libXrandr-1.5.4.tar.xz |
| libdrm 2.4.129 | https://ftp2.osuosl.org/pub/blfs/conglomeration/libdrm/libdrm-2.4.129.tar.xz |

Each selection has an empty permitted redirect URL list. The unchanged transport guard refuses any redirect before requesting its target. No retries, alternate fallback or protocol downgrade. Original upstream URLs, Nix flat SHA256 values and fetch derivation references remain unchanged. MacPorts' held directory HTML and root acceptance establish the exact file anchors, not the identity or availability of any unrequested archive body. The original libdrm HEAD200 receipt remains bound. Historical mirror metadata remains historical evidence only.

The four held Linux/glibc/GCC/Wayland archives remain in owners01/03/04 and are revalidated by the unchanged collector; preparation only reads named small metadata. Three older ALSA/libxcb/libXrender references remain unchanged. Four new plus four held selections retain the original eight distinct URL/digest identities.

The original cumulative phase-A body cap stays **402,653,184 bytes (384 MiB)**: 266,879,580 held archive bytes + 2,290 prior redirect-body bytes + **135,771,314** new bytes. The consumer changes only the cumulative prior-byte constant from 266,881,546 to 266,881,870. Per-body 192 MiB is further limited by remaining aggregate and owner capacity. Four new logical requests, at most20 total requests, no permitted redirects on these exact current routes;1 GiB owner /2 GiB retention; full body and both stream reservations;16 MiB normal receipt reserve,1 MiB failure and8 MiB supervisor margin;580/600/630+15 seconds;2 CPUs,2 GiB AS,4 GiB named streamed reads,512 files/16 directories remain unchanged.

`templates/collect.py`, `templates/run.py`, `templates/run.sh`, `templates/process-identity.py`, both guard files, guard binding and frozen-tool identities are byte-identical to05. The existing52 controls passed in `20261015T143931Z-0ffabc43`, original command/monitor/runner0/0/0 and tool0. Exact report `/workspace/tmp/pix-m7-fex-source-acquisition-guards-20261015-05.json` SHA `0b394659b3fa775ba0ff46cd0f37d7044c96c7e473fd39effcbd6bf1e455de21` and original `guards.stderr` locator are retained. Reuse is restricted to these unchanged guard/collector bytes. No controls were rerun, candidate imported, preparer invoked or runtime allocated for06.

`changes.diff` is the complete delta of the six existing operational files: collection plan, resources, preparer, binding verifier, success consumer and command handoff. The old source-generation scripts are omitted; their immutable source05 packet remains bound. `derive-source.py` records source construction only and is not a runtime command. `static-review.json` records syntax/AST and byte identity readback, not execution qualification.

Root's next steps, separately, after current serialized owner is consumed:

```bash
TASK_PACKET=/tmp/pix-m7-fex-source-acquisition-continuation06-20261015
# Set TASK_CURL_PATH and TASK_CURL_SHA256 to the actual resolved reviewed host curl.
bash "$TASK_PACKET/commands.sh" prepare
bash "$TASK_PACKET/commands.sh" preflight
bash "$TASK_PACKET/commands.sh" report
# Inspect actual preparation, preflight and retention report before admission.
bash "$TASK_PACKET/commands.sh" admit
bash "$TASK_PACKET/commands.sh" launch
# Actively supervise <=60-second intervals; original completion is required.
bash "$TASK_PACKET/commands.sh" consume
```

The fresh default owner is `/workspace/tmp/pix-m7-fex-source-acquisition-20261015-06`; refuse overwrite. The exact previously passed guard report/run is fixed in commands; there is no guard rerun step. Use the frozen `m7-p5-build-20261015-02` ordinary admission/watch tools. Submission is not completion; never precreate launcher-owned receipts. Failure preserves partials/original waits and requires a separate ordinary investigated consumption, without rerunning this owner or using the success consumer.

No extraction, build/compiler/Nix/source execution, target execution, VM, listener, source-cache traversal or deletion. Raw HTTP streams remain private. PhaseB Nixpkgs/libglvnd/patches, notices, independent retrieval/offhost custody and publication disposition remain separate; this packet confers no blanket source or license clearance.

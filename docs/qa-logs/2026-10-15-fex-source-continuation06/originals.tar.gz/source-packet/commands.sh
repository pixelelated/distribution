#!/bin/bash
# UNRUN. Root reviews/allocates; each named step is separate and preserves originals.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-fex-source-acquisition-continuation06-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-fex-source-acquisition-20261015-06}
TASK_GUARD_REPORT=/workspace/tmp/pix-m7-fex-source-acquisition-guards-20261015-05.json
TASK_GUARD_RUN=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T143931Z-0ffabc43
cd "$TASK_TREE"
case "${1:?prepare, preflight, report, admit, launch, or consume}" in
 prepare)
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-owner.py" --owner "$TASK_OWNER" --curl-path "${TASK_CURL_PATH:?root-resolved host curl path}" --curl-sha256 "${TASK_CURL_SHA256:?actual host curl SHA256}" --guard-report "$TASK_GUARD_REPORT" --guard-run "${TASK_GUARD_RUN:?original watched guard run with all channels zero}"
  ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json" ;;
 admit) python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json" ;;
 launch) env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh" ;;
 consume) python3 -I "$TASK_OWNER/consume.py" ;;
 *) exit 2 ;;
esac
# Submission is not completion. Root actively supervises <=60s and reads all originals.
# Never pre-create launcher-owned tool-wrapper.rc/launcher-result.json. On failure,
# preserve outputs and use ordinary failed-investigation consumption; do not call this
# success-only consumer or rerun any output owner.

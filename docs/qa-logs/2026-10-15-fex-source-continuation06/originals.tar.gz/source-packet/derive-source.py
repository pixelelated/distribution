#!/usr/bin/env python3
"""Source preparation only; never executes any candidate helper or reads archive bodies."""
from pathlib import Path
import ast,hashlib,json,shutil,difflib
P=Path(__file__).resolve().parent
OLD=Path('/tmp/pix-m7-fex-source-acquisition-continuation05-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def put(n,v):(P/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def replace(n,a,b):
 p=P/n;s=p.read_text();assert a in s,(n,a);p.write_text(s.replace(a,b))
for line in (OLD/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(OLD/n)==h
skip={'SHA256SUMS','packet-manifest.json','changed-lines.json','changes.diff','source-provenance.json','static-review.json','README.md','prepare-continuation-source.py','finalize-source.py'}
for f in OLD.rglob('*'):
 if f.is_file() and str(f.relative_to(OLD)) not in skip:
  d=P/f.relative_to(OLD);d.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(f,d)
plan=load(P/'collection-plan.json')
oldguard=Path('/workspace/tmp/pix-m7-fex-source-acquisition-guards-20261015-05.json')
guardrun=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T143931Z-0ffabc43')
failedrun=guardrun.parent/'20261015T144121Z-fcadb010'
failed=Path('/workspace/tmp/pix-m7-fex-source-acquisition-20261015-05')
review=Path('/tmp/pix-m7-fex-continuation05-failure-review-20261015')
route=Path('/tmp/pix-m7-macports-route-20261015')
refs=[OLD/'SHA256SUMS',review/'investigation.json',review/'acceptance.json',review/'consume-exit.json',failed/'collection-failure.json',failed/'launcher-result.json',failedrun/'admission-consumed.json',failedrun/'runner-result.json',failedrun/'build.rc',oldguard,guardrun/'runner-result.json',guardrun/'build.rc',Path('/tmp/pix-m7-fex05-coordinator-20261015/guards.stderr'),Path('/tmp/pix-m7-fex05-coordinator-20261015/guards.exit.json'),route/'result.json',route/'root-acceptance.json',route/'xorg-libX11.html',route/'xorg-libXrandr.html',route/'xorg-xorgproto.html']
newrefs=[]
(P/'originals06').mkdir(exist_ok=True)
for i,f in enumerate(refs):
 assert f.is_file() and not f.is_symlink() and f.stat().st_size<2*1024**2
 h=sha(f);plan['binding_refs'][str(f)]=h;d=P/'originals06'/(str(i).zfill(2)+'-'+h+'-'+f.name)
 if not d.exists():shutil.copy2(f,d)
 s=f.stat();newrefs.append(dict(path=str(f),sha256=h,copy=str(d.relative_to(P)),bytes=s.st_size,mode=s.st_mode&0o7777,uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns))
newfailure=dict(acceptance=str(review/'acceptance.json'),completed_archives=0,consume_exit=str(review/'consume-exit.json'),consume_exit_field='original_tool_exit',disposition='failed-investigated',failure_receipt=str(failed/'collection-failure.json'),investigation=str(review/'investigation.json'),owner=str(failed),response_body_bytes=324,run=str(failedrun),consumed=str(failedrun/'admission-consumed.json'))
plan['prior_failures'].append(newfailure)
plan['phase_A_response_body_accounting'].update(prior_response_body_bytes=266881870,prior_redirect_body_bytes=2290,continuation_response_body_cap_bytes=135771314)
accepted=load(route/'root-acceptance.json');links={r['filename']:r for r in accepted['exact_links']}
for selection in plan['selected_archives'][:3]:
 row=links[selection['filename']];selection['canonical_url']=row['url'];selection['allowed_redirect_hosts']=['distfiles.macports.org'];selection['allowed_redirect_urls']=[]
 del selection['route_head_probe']
 selection['route_directory_index']=str(route/(row['url'].split('/')[-2]+'.html'))
 selection['route_disposition']='Exact filename anchor in held official MacPorts directory; route metadata only, archive body not requested. Original pinned flat digest remains mandatory. No redirects, retry or fallback authorized.'
plan['macports_route_revision']=dict(result=str(route/'result.json'),acceptance=str(route/'root-acceptance.json'),archive_bodies_requested=False,redirects_allowed=False)
plan['guard_reuse']=dict(report=str(oldguard),run=str(guardrun),report_sha256=sha(oldguard),collector_sha256=sha(P/'templates/collect.py'),guard_controls_sha256=sha(P/'guard-controls.py'),cases=52,reason='Identical collector and synthetic guard bytes; only route/prior-failure bindings and cumulative accounting change. No guard rerun requested.')
put('collection-plan.json',plan)
res=load(P/'resources.json');res['compressed_archive_aggregate_bytes']=135771314;res['limits_basis']=res['limits_basis'].replace('135,771,638','135,771,314').replace('1,966','2,290')+' All four current exact routes have empty permitted redirect URL lists.';put('resources.json',res)
replace('templates/consume.py','report[\'compressed_bytes\']+266881546','report[\'compressed_bytes\']+266881870')
replace('templates/bindings.py','len(failures)==4','len(failures)==5')
replace('templates/bindings.py',"'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04']","'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-05']")
replace('templates/bindings.py','[152673392,166,113965324,242664]','[152673392,166,113965324,242664,324]')
for n in ['templates/bindings.py','prepare-owner.py']:
 for a,b in [('266881546','266881870'),('135771638','135771314'),('1966','2290')]:
  s=(P/n).read_text();(P/n).write_text(s.replace(a,b))
replace('templates/bindings.py',"    for archive,record in zip(prior,custody):", """    consumed=load(failures[-1]['consumed'])
    assert consumed['state']=='consumed' and consumed['id']=='7fe199c7e316404ea997a15d30f9a667'
    assert consumed['run']==failures[-1]['run'] and consumed['submission_owner']==failures[-1]['owner']
    assert consumed['evidence_sha256']==sha(failures[-1]['acceptance']) and consumed['outputs_held'] is True and consumed['deleted_bytes']==0
    assert [consumed['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[1,0,1]
    for archive,record in zip(prior,custody):""")
s=(P/'templates/bindings.py').read_text();start=s.index("    expected=[('yehkri-x11'");end=s.index("    guard=load(O/'guard-report.json')",start)
s=s[:start]+'''    # Preserve the observed OSUOSL 200 route; the three Xorg mirror routes below are superseded.
    selection=selected[3];row=rows['osuosl-drm']
    assert selection['canonical_url']==row['url']=='https://ftp2.osuosl.org/pub/blfs/conglomeration/libdrm/libdrm-2.4.129.tar.xz'
    assert selection['route_head_probe']=='osuosl-drm'
    assert type(row['original_curl_exit'])is int and row['original_curl_exit']==0 and row['wait_observed'] is True
    assert '--head' in row['argv'] and '--location' not in row['argv'] and row['argv'][row['argv'].index('--retry')+1]=='0'
    assert row['summary'].split()[0]=='200' and selection['allowed_redirect_hosts']==['ftp2.osuosl.org'] and selection['allowed_redirect_urls']==[]
    mac=plan['macports_route_revision'];directory=load(mac['result']);accepted_mac=load(mac['acceptance'])
    assert directory['archive_bodies'] is False and directory['redirects_followed'] is False
    assert accepted_mac['archive_bodies_requested'] is False and accepted_mac['original_tool_exit']==0
    assert all(type(accepted_mac['runner'][k])is int and accepted_mac['runner'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert len(directory['rows'])==len(accepted_mac['exact_links'])==3
    links={r['filename']:r for r in accepted_mac['exact_links']};indexes={r['filename']:r for r in directory['rows']}
    expected=['https://distfiles.macports.org/xorg-libX11/libX11-1.8.12.tar.xz','https://distfiles.macports.org/xorg-xorgproto/xorgproto-2024.1.tar.xz','https://distfiles.macports.org/xorg-libXrandr/libXrandr-1.5.4.tar.xz']
    for selection,url in zip(selected[:3],expected):
        link=links[selection['filename']];index=indexes[selection['filename']]
        assert selection['canonical_url']==link['url']==url and index['url']+index['filename']==url
        assert index['original_curl_exit']==0 and index['filename_present'] is True
        assert sha(selection['route_directory_index'])==index['sha256']==link['index_sha256']
        assert Path(selection['route_directory_index']).stat().st_size==index['bytes']
        assert selection['allowed_redirect_hosts']==['distfiles.macports.org'] and selection['allowed_redirect_urls']==[]
    reuse=plan['guard_reuse']
    assert reuse['cases']==52 and reuse['collector_sha256']==sha(O/'collect.py')
    assert reuse['report_sha256']==sha(reuse['report'])==sha(O/'guard-report.json')
    assert plan['guard_run']==reuse['run']=='/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T143931Z-0ffabc43'
''' +s[end:]
(P/'templates/bindings.py').write_text(s)
replace('prepare-owner.py',"    plan['guard_run']=str(a.guard_run)","""    reuse=plan['guard_reuse']
    assert str(a.guard_report)==reuse['report'] and str(a.guard_run)==reuse['run']
    assert sha(a.guard_report)==reuse['report_sha256'] and len(guard['cases'])==reuse['cases']==52
    assert guard['guard_controls_sha256']==reuse['guard_controls_sha256']==sha(P/'guard-controls.py')
    plan['guard_run']=str(a.guard_run)""")
replace('prepare-owner.py',"'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04'],candidates", "'/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-05'],candidates")
s=(P/'commands.sh').read_text().replace('continuation05-20261015','continuation06-20261015').replace('TASK_OWNER:-/workspace/tmp/pix-m7-fex-source-acquisition-20261015-05','TASK_OWNER:-/workspace/tmp/pix-m7-fex-source-acquisition-20261015-06')
s=s.replace('TASK_GUARD_REPORT=${TASK_GUARD_REPORT:-/workspace/tmp/pix-m7-fex-source-acquisition-guards-20261015-05.json}',"TASK_GUARD_REPORT=/workspace/tmp/pix-m7-fex-source-acquisition-guards-20261015-05.json\nTASK_GUARD_RUN=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T143931Z-0ffabc43")
s=s.replace('guards, prepare, preflight, report, admit, launch, or consume','prepare, preflight, report, admit, launch, or consume')
s='\n'.join(line for line in s.splitlines() if not line.startswith(' guards)'))+'\n';(P/'commands.sh').write_text(s)
put('new-originals.json',newrefs)
put('source-provenance.json',dict(base_packet=str(OLD),base_sha256sums=sha(OLD/'SHA256SUMS'),status='SOURCE_ONLY_UNRUN',guard_execution='REUSED_EXACT_PASSED_SOURCE05_RUN_NO_RERUN',guard_reuse=plan['guard_reuse'],transport_logic_unchanged=True,consumer_only_change='Cumulative prior response-body accounting constant +324',changed_bindings='Five prior failures, exact consumed05 and direct MacPorts metadata; fresh06 owner paths',new_originals='new-originals.json'))
files=['collection-plan.json','resources.json','prepare-owner.py','templates/bindings.py','templates/consume.py','commands.sh']
diff=''
for n in files:diff+=''.join(difflib.unified_diff((OLD/n).read_text().splitlines(True),(P/n).read_text().splitlines(True),fromfile='source05/'+n,tofile='source06/'+n))
(P/'changes.diff').write_text(diff)

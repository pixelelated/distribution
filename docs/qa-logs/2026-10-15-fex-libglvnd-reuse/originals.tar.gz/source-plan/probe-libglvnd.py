#!/usr/bin/env python3
"""UNRUN: bounded data-only NAR comparison of one exact historical source archive."""
from pathlib import Path
import argparse,gzip,hashlib,io,json,os,re,stat,struct,sys,tarfile,time
ARCHIVE=Path('/workspace/artifacts/pixelelated-release-sources/m7-archives-a7022b76da76a9f6771bb7693d6f6e25854c6731db0750bb46dde29f14d49fce/archives/073e7292788d4d3eeb45ea6c7bdcce9bfdb3b3eef8d7dbd47f2f30dce046ef98')
ARCHIVE_SHA='073e7292788d4d3eeb45ea6c7bdcce9bfdb3b3eef8d7dbd47f2f30dce046ef98'
EXPECTED_NAR_SHA='d94f49b691b23f895bc6d54978fe465208795ed865a0fbc5230dbcfa795d631f'
LIMITS=dict(compressed_bytes=4*1024**2,decoded_tar_bytes=64*1024**2,nar_bytes=64*1024**2,member_bytes=16*1024**2,members=8192,path_bytes=4096,depth=64,receipt_bytes=1024**2,soft_seconds=50)
def identity(p):
    assert p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode)
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();out=args.output
    assert out.parent==Path('/workspace/tmp') and out.parent.resolve(strict=True)==out.parent
    assert re.fullmatch(r'pix-m7-fex-libglvnd-nar-probe-20261015-[0-9]{2}\.json',out.name)
    assert not out.exists() and not out.is_symlink()
    started=time.monotonic();rc=1;receipt=dict(scope='One exact historical archive as data only',network_used=False,source_execution=False,archive_extracted_to_filesystem=False,limits=LIMITS)
    def tick():assert time.monotonic()-started<LIMITS['soft_seconds'],'soft deadline'
    try:
        host_file=Path(__file__).resolve().parent/'host-tool-identities.json';assert host_file.stat().st_size<=65536
        host=json.loads(host_file.read_text());record=next(r for r in host['files'] if r.get('path')=='/usr/bin/python3.14')
        executable=Path(sys.executable).resolve(strict=True);assert executable==Path(record['path'])
        assert (os.getuid(),os.getgid())==(1000,1000)
        assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
        actual=identity(executable);assert all(actual[k]==record[k] for k in ['path','bytes','device','inode','mode','mtime_ns'])
        assert actual['bytes']<=8*1024**2
        with executable.open('rb') as stream:program_bytes=stream.read(8*1024**2+1)
        assert len(program_bytes)==actual['bytes'] and hashlib.sha256(program_bytes).hexdigest()==record['sha256']
        assert identity(executable)==actual
        receipt.update(host_python_identity=record,host_identity_receipt_sha256=hashlib.sha256(host_file.read_bytes()).hexdigest())
        before=identity(ARCHIVE);assert before['bytes']==839809<=LIMITS['compressed_bytes']
        with ARCHIVE.open('rb') as stream:raw=stream.read(LIMITS['compressed_bytes']+1)
        assert len(raw)==before['bytes'] and hashlib.sha256(raw).hexdigest()==ARCHIVE_SHA
        assert identity(ARCHIVE)==before
        chunks=[];decoded=0
        with gzip.GzipFile(fileobj=io.BytesIO(raw),mode='rb') as gz:
            while True:
                tick();block=gz.read(min(1024**2,LIMITS['decoded_tar_bytes']-decoded+1))
                if not block:break
                assert decoded+len(block)<=LIMITS['decoded_tar_bytes'];decoded+=len(block);chunks.append(block)
        payload=b''.join(chunks);nodes={};root=None;count=0
        with tarfile.open(fileobj=io.BytesIO(payload),mode='r:',encoding='utf-8',errors='surrogateescape') as tar:
            for member in tar:
                tick();count+=1;assert count<=LIMITS['members']
                name=member.name.encode('utf-8','surrogateescape');assert 0<len(name)<=LIMITS['path_bytes'] and b'\x00' not in name
                assert not name.startswith(b'/');parts=name.rstrip(b'/').split(b'/')
                assert all(part not in [b'',b'.',b'..'] and len(part)<=255 for part in parts)
                assert len(parts)<=LIMITS['depth']
                if root is None:root=parts[0]
                assert parts[0]==root,'not a single archive root'
                key=tuple(parts[1:]);assert key not in nodes,'duplicate archive member'
                if member.isdir():value=dict(kind='directory')
                elif member.isfile():
                    assert not member.sparse and 0<=member.size<=LIMITS['member_bytes']
                    stream=tar.extractfile(member);assert stream is not None
                    data=stream.read(member.size+1);assert len(data)==member.size
                    value=dict(kind='regular',executable=bool(member.mode & 0o100),data=data)
                elif member.issym():
                    target=member.linkname.encode('utf-8','surrogateescape');assert len(target)<=LIMITS['path_bytes'] and b'\x00' not in target
                    value=dict(kind='symlink',target=target)
                else:raise AssertionError('unsupported hardlink, device, FIFO or special archive member')
                nodes[key]=value
        assert root is not None and nodes and nodes.get((),{}).get('kind','directory')=='directory'
        # Missing directory records can be implicit in tar; no source path is opened.
        for key in list(nodes):
            for length in range(len(key)):
                ancestor=key[:length]
                if ancestor in nodes:assert nodes[ancestor]['kind']=='directory'
                else:nodes[ancestor]=dict(kind='directory')
                assert len(nodes)<=LIMITS['members']
        nodes.setdefault((),dict(kind='directory'));children={}
        for key in nodes:
            if key:children.setdefault(key[:-1],[]).append(key[-1])
        h=hashlib.sha256();nar_bytes=0
        def emit(data):
            nonlocal nar_bytes
            tick();assert nar_bytes+len(data)<=LIMITS['nar_bytes'];h.update(data);nar_bytes+=len(data)
        def string(data):
            emit(struct.pack('<Q',len(data)));emit(data);emit(b'\x00'*((-len(data))%8))
        def node(key):
            tick();value=nodes[key];string(b'(');string(b'type');string(value['kind'].encode())
            if value['kind']=='regular':
                if value['executable']:string(b'executable');string(b'')
                string(b'contents');string(value['data'])
            elif value['kind']=='symlink':string(b'target');string(value['target'])
            else:
                for name in sorted(children.get(key,[])):
                    string(b'entry');string(b'(');string(b'name');string(name);string(b'node');node(key+(name,));string(b')')
            string(b')')
        string(b'nix-archive-1');node(())
        actual=h.hexdigest();assert identity(ARCHIVE)==before
        rc=0 if actual==EXPECTED_NAR_SHA else 2
        receipt.update(result='EXACT_RECURSIVE_SOURCE_REUSE' if rc==0 else 'HISTORICAL_ARCHIVE_NOT_PROVEN_EQUIVALENT',archive=dict(before,sha256=ARCHIVE_SHA),decoded_tar_bytes=decoded,tar_members=count,NAR_nodes=len(nodes),nar_bytes=nar_bytes,computed_nar_sha256=actual,expected_nar_sha256=EXPECTED_NAR_SHA,source_bundle_complete=False,publication_clearance=False)
    except BaseException as error:
        receipt.update(result='REFUSED_BOUNDED_PROBE',error_type=type(error).__name__,source_bundle_complete=False,publication_clearance=False);rc=1
    receipt.update(original_exit=rc,elapsed_seconds=time.monotonic()-started)
    raw=(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<=LIMITS['receipt_bytes']
    with out.open('xb') as f:f.write(raw)
    print(json.dumps(dict(result=receipt['result'],original_exit=rc,receipt=str(out))))
    return rc
if __name__=='__main__':sys.exit(main())

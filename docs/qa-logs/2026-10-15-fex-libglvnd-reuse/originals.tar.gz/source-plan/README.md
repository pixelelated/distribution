# FEX phase B — exact input and transformation disposition

The smallest supported next step is a **bounded offline comparison of the already held libglvnd archive**, followed by custody of the held Nixpkgs tree and twenty patch files. Two selected patch outputs are absent and require normalization-aware acquisition. No broader compiler closure is added.

This packet is source preparation only. It contains exact source/metadata observations, the three original fetch derivations, passive host program identities, a precise remaining-work plan and one **unrun** data-only probe. It does not contain a parallel collector/supervisor framework. No network, Nix command, source execution, product change or archive payload read occurred here.

## Already held

| Input | Exact evidence | Remaining custody action |
| --- | --- | --- |
| Nixpkgs source selected with pin `b6018f87da91d19d0ab4cf979885689b469cdd41` | The exact physical source root exists. The frozen read-only Nix database records NAR size **195,961,000 bytes**, SHA-256 **`b705cf16a16caeb639af6f1987b1e89a0729da050c06043a5834bdf10ff7c452`**. | Retain that complete tree as canonical NAR, checking the recorded size/hash. No Nixpkgs download is proposed. The tree has not yet been walked or independently NAR-hashed. |
| Twenty selected patch outputs | All twenty named regular files were read as source text with stable identity; total **1,959,776 bytes**. Exact paths, modes, lengths and flat digests are in `held-source-evidence.json`. | Copy and reverify these exact files under reviewed custody. Payloads were not copied into this source-preparation packet. |
| Historical libglvnd 1.7.0 archive | Existing custody manifest binds **839,809 bytes**, flat SHA-256 **`073e7292788d4d3eeb45ea6c7bdcce9bfdb3b3eef8d7dbd47f2f30dce046ef98`**; its exact held archive path is present. | First test recursive equivalence with the selected Nix source. Matching version labels alone do not establish equivalence. |

The Nixpkgs database was opened immutable and read-only for four exact path queries; its original 2,551,808-byte hash `84743ddfcf3de95a346030235e2b72966532f249a34a2bbeddbfc9474c1fc1d6` matched before and after. The libglvnd source root and both missing patch outputs had no ValidPaths rows and their exact filesystem paths were absent. This is bounded named-path evidence, not a claim about every cache on the host.

The largest held patch, glibc's `2.40-master.patch`, is **1,925,063 bytes**. The previous proposed 1 MiB per-patch limit would refuse it. The reviewed next collector should use an explicit 4 MiB per-patch / 8 MiB aggregate cap for these twenty known files. This packet has not run that collector or widened any acquisition already underway.

## Three absent selected store outputs and their hash meanings

| Selected output | Supported upstream URL | Expected output SHA-256 |
| --- | --- | --- |
| libglvnd 1.7.0 source tree | `https://gitlab.freedesktop.org/api/v4/projects/glvnd%2Flibglvnd/repository/archive.tar.gz?sha=v1.7.0` | Recursive/NAR: `d94f49b691b23f895bc6d54978fe465208795ed865a0fbc5230dbcfa795d631f` |
| libglvnd `large-file.patch` | `https://gitlab.freedesktop.org/glvnd/libglvnd/-/commit/956d2d3f531841cabfeddd940be4c48b00c226b4.patch` | Flat **normalized patch**: `63a602cddfe36755593fd6c59479078f34b04a15de03b88959dc9fc69813da5d` |
| xorgproto `meson.patch` | `https://aur.archlinux.org/cgit/aur.git/plain/meson.patch?h=mingw-w64-xorgproto&id=7b817efc3144a50e6766817c4ca7242f8ce49307` | Flat **normalized patch**: `233cf3f489f9dd6ec20befa4d5b2ebefc892ae6c69166d5c1fca9c4a9a6da144` |

`missing-fetch-descriptors.json` and retained original `.drv` text are authoritative for exact URL spelling, output paths and transformations. **None of these three expected hashes is established as a flat hash of the raw HTTP response.** The scripts in the derivations are retained as text and have not been executed.

For libglvnd, the recorded fetchzip transformation unpacks one single root entry, strips that root, preserves member contents and executable flags, and normalizes the root directory permissions. Canonical NAR identity records regular-file bytes, the executable marker, raw symlink targets and byte-sorted directory entries; directory permission bits, timestamps and HTTP compression are not the source identity. No NAR hash may be compared directly to a `.tar.gz` response hash.

For both patches, the recorded patchutils **0.3.3** pipeline first decodes with `cat`, then obtains names using `lsdiff`, sorts unique names, escapes wildcard `*`/`?` characters, and emits each file through `filterdiff --include=<name> --strip=0 --clean`. A final `filterdiff -p1` applies the recorded selection step. Empty input, intermediate or output refuses. There are no additional recorded include/exclude patterns. The exact `postFetch` text is retained; future work should reproduce its output rather than treating `-p1` as an instruction to strip stored patch paths.

Raw patch responses can contain mail headers or other framing removed by normalization. Retain raw bytes and their observed HTTP digest separately, then require the **known normalized digest** before calling the applied patch source acquired. A response download alone does not close that requirement.

## Existing host tools and the normalizer gap

`host-tool-identities.json` records stable file identity and SHA-256 for the existing host's `/usr/bin/python3.14`, `/usr/bin/curl`, `/usr/bin/tar` and `/usr/bin/xz`. These ELF programs were read as data only; no version or compatibility probe ran. UID/GID observations belong to the source reader namespace; the runtime probe binds the approved host namespace and portable byte/device/inode/size/mode/mtime fields. Curl matches the accepted owner-03 runtime identity on those fields and its SHA-256. Both `/usr/bin/filterdiff` and `/usr/bin/lsdiff` are absent. The exact recorded Nix patchutils-0.3.3 executable paths are also absent.

Existing tar/xz tools do not substitute for patch normalization. A separately reviewed trusted normalizer or narrow equivalent must produce the two known output digests. No package installation, acquired-tool execution or replacement normalizer has been authorized or performed here. Matching known output bytes can establish identity without imposing a whole historical compiler/tool closure requirement.

## First executable proposal: reuse probe, unrun

`probe-libglvnd.py` opens only the exact historical archive, verifies its flat digest and stable identity, decompresses it in bounded memory, strips one root virtually and hashes canonical NAR records. It follows no source symlink, extracts no file to the filesystem, invokes no subprocess and makes no network request. Unsupported special/hardlink members or ambiguous paths refuse. Its only output is a fresh bounded JSON receipt containing original exit and elapsed time.

The probe verifies the exact recorded `/usr/bin/python3.14` identity. It limits compressed source input to 4 MiB (observed 839,809 bytes), program identity input to 8 MiB, all named input to 16 MiB, decoded tar and virtual NAR each to 64 MiB, members to 8,192, individual member data to 16 MiB, paths to 4,096 bytes and depth to 64. Receipt output is at most 1 MiB; soft time is 50 seconds, outer timeout 60 seconds plus 5 seconds to kill, two CPUs and 2 GiB address space. No large source snapshot is written.

After root review and explicit allocation, the prepared command is:

```bash
bash /tmp/pix-m7-fex-source-phaseb-20261015/probe-command.sh
```

The default fresh receipt is `/workspace/tmp/pix-m7-fex-libglvnd-nar-probe-20261015-01.json`; it is uncreated. The command uses the frozen control tree's watched record-only path. Exit 0 requires the exact expected recursive digest. Exit 2 means this archive did not establish equivalence; exit 1 is a bounded refusal. Neither failure triggers a download or fallback. The receipt and original watched result must be reviewed before using any conclusion.

If the NAR matches, retain the existing historical archive reference plus this proof and omit a libglvnd download. Otherwise, the exact GitLab source URL remains a separate acquisition proposal with the same recursive verification requirement. The two normalized patches remain separate in either case.

`phase-b-plan.json` gives finite follow-on budgets for a single Nixpkgs tree, the twenty named patches and, if needed, the three missing inputs. Those follow-on collectors are **not implemented or allocated**. Their source will reuse the accepted admission/lifecycle and before-write controls once this precise scope is accepted. Full notices, independent retrieval, offhost custody and publication clearance remain separate.

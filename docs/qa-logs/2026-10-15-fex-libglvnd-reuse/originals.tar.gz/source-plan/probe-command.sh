#!/bin/bash
# SOURCE ONLY, UNRUN. Root must allocate this bounded data-only probe explicitly.
set -euo pipefail
TASK_PHASEB_PACKET=/tmp/pix-m7-fex-source-phaseb-20261015
TASK_PHASEB_RESULT=${TASK_PHASEB_RESULT:-/workspace/tmp/pix-m7-fex-libglvnd-nar-probe-20261015-01.json}
cd /workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
tools/watch-build --record-only -- taskset -c 0,1 prlimit --as=2147483648 --fsize=1048576 -- timeout --signal=TERM --kill-after=5s 60s /usr/bin/python3.14 -I -S -B "$TASK_PHASEB_PACKET/probe-libglvnd.py" --output "$TASK_PHASEB_RESULT"

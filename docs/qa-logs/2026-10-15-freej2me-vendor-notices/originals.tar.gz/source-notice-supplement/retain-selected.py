#!/usr/bin/env python3
"""One bounded, named FreeJ2ME source/notice custody operation; no build/execution."""
from pathlib import Path
import hashlib, json, shutil, stat, tarfile, zipfile

OUT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/build.pixelelated-GENERIC_X64.x86_64/build/freej2me-lr-1.52')
ARCHIVE = Path('/workspace/cache/rocknix-sources/freej2me-lr/freej2me-lr-1.52.tar.gz')
ARCHIVE_SHA = '509c3590827c8556cc0f8ff42c22693dd40e99e01e15f8f5c0e2e00bdbd8c130'
PREFIX = 'freej2me-plus-1.52/'
LIMIT_FILES, LIMIT_BYTES = 256, 8 * 1024 * 1024

def sha(b): return hashlib.sha256(b).hexdigest()
def write(name, data):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
def meta(p, data):
    s = p.lstat()
    assert stat.S_ISREG(s.st_mode), p
    return dict(path=str(p), sha256=sha(data), bytes=len(data), mode=stat.S_IMODE(s.st_mode), uid=s.st_uid, gid=s.st_gid, mtime_ns=s.st_mtime_ns)

# Only the three named vendor subtrees identified by build.xml/Makefile.common.
# Ignore existing compiler outputs; every retained source file must match the pinned archive.
selected = []
for sub in ['src/javazoom/jl', 'src/org/objectweb/asm', 'src/libretro/deps/libretro-common']:
    selected += [p for p in (SOURCE/sub).rglob('*') if p.is_file() and p.suffix not in ('.o', '.so')]
selected += [SOURCE/p for p in ['LICENSE','README.md','build.xml','src/libretro/Makefile','src/libretro/Makefile.common','src/libretro/libretro.h','src/libretro/freej2me_libretro.c','src/libretro/freej2me_libretro.h','src/org/recompile/freej2me/Libretro.java','src/org/recompile/freej2me/FreeJ2ME.java']]
selected = sorted(set(selected))
supplements = [Path('/usr/share/common-licenses/LGPL-2'), Path('/usr/share/common-licenses/LGPL-2.1')]
recipe = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/projects/ROCKNIX/packages/emulators/libretro/freej2me-lr/package.mk')
assert len(selected) + len(supplements) + 1 <= LIMIT_FILES
assert sum(p.stat().st_size for p in selected + supplements + [recipe]) <= LIMIT_BYTES

archive_bytes = ARCHIVE.read_bytes()
assert sha(archive_bytes) == ARCHIVE_SHA
rows = []
with tarfile.open(ARCHIVE) as t:
    members = t.getmembers()
    member_by_name = {m.name: m for m in members}
    assert len(member_by_name) == len(members)
    # Complete names/metadata of ONE identified archive; no payload tree/cache census.
    archive_index = [dict(name=m.name, kind='file' if m.isfile() else 'directory' if m.isdir() else 'other', bytes=m.size, mode=m.mode, uid=m.uid, gid=m.gid, mtime=m.mtime, linkname=m.linkname) for m in members]
    for p in selected:
        rel = str(p.relative_to(SOURCE)); m = member_by_name[PREFIX+rel]
        assert m.isfile() and not p.is_symlink(), rel
        data = p.read_bytes(); original_archive_data = t.extractfile(m).read()
        assert data == original_archive_data, rel
        data.decode('utf-8')
        dest = OUT/'source'/rel; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p,dest)
        rows.append(dict(relative=rel, retained='source/'+rel, original=meta(p,data), archive_member=m.name, archive_member_sha256=sha(original_archive_data), archive_matches_unpacked=True))
    archive_binding = dict(original=meta(ARCHIVE,archive_bytes), tag='1.52', archive_embedded_git_commit=t.pax_headers.get('comment'), embedded_commit_scope='Git archive PAX metadata only; no remote tag lookup performed', selected_source_members=len(rows), all_archive_members=len(members), sdl_name_matches=[m.name for m in members if 'sdl' in m.name.lower()], license_named_members=[m.name for m in members if any(s in m.name.lower() for s in ('license','copying','copyright','notice'))])
write('archive-binding.json',archive_binding)
write('archive-member-metadata.json',archive_index)

supp = []
for p in supplements:
    data=p.read_bytes(); data.decode('utf-8')
    dest=OUT/'supplemental-license-texts'/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    supp.append(dict(retained=str(dest.relative_to(OUT)), original=meta(p,data), role='Complete local host common-license text; NOT a member of the FreeJ2ME archive and NOT evidence of upstream delivery'))
data=recipe.read_bytes(); assert sha(data)=='683c6f1bd0d5b26bbea2f96a4f64d67eaa9c1a1db22f1a21201f286a0015d4cd'
shutil.copy2(recipe,OUT/'package.mk')
write('selected-source-members.json',rows)
write('supplemental-license-provenance.json',supp)

profiles=[]
for profile in ['generic-x64-x86_64','h700-aarch64','sm8550-aarch64']:
    rp=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-03/collection')/(profile+'--freej2me-lr.json')
    raw=rp.read_bytes();r=json.loads(raw)
    dest=OUT/'accepted-records'/rp.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(rp,dest)
    output=next(x for x in r['selected_files'] if x['path'].endswith('.jar'))
    j=Path(output['package']['path']);rawjar=j.read_bytes()
    assert sha(rawjar)==output['package']['sha256'] and output['package_matches_staged']
    with zipfile.ZipFile(j) as z:
        members=[dict(name=i.filename,bytes=i.file_size,compressed_bytes=i.compress_size,crc32=i.CRC,method=i.compress_type,external_attr=i.external_attr,date_time=list(i.date_time)) for i in z.infolist()]
    names=[m['name'] for m in members]
    write('jar-member-metadata/'+profile+'.json',members)
    profiles.append(dict(profile=profile, record_original=meta(rp,raw), retained_record=str(dest.relative_to(OUT)), distribution_commit=r['accepted_input']['source_commit'], source_archive=r['accepted_input']['component_row']['unpacked_source']['cache'], recipe_sha256=r['accepted_input']['component_row']['recipe_sha256'], original_jar=meta(j,rawjar), accepted_output=output, jar_member_count=len(names), jlayer_classes=sum(n.startswith('javazoom/jl/') and n.endswith('.class') for n in names), asm_classes=sum(n.startswith('org/objectweb/asm/') and n.endswith('.class') for n in names), sdl_member_names=[n for n in names if 'sdl' in n.lower()], nested_jars=[n for n in names if n.lower().endswith(('.jar','.zip'))], jar_members_retained='jar-member-metadata/'+profile+'.json'))
    assert r['accepted_input']['component_row']['recipe_sha256']==sha(data)
    assert len(profiles[-1]['source_archive'])==1 and profiles[-1]['source_archive'][0]['sha256']==ARCHIVE_SHA
write('profile-bindings.json',profiles)
write('recipe-binding.json',dict(original=meta(recipe,data),retained='package.mk',distribution_commit=profiles[0]['distribution_commit']))
write('readback.json',dict(status='BOUNDED_SELECTED_SOURCE_AND_NOTICE_CUSTODY_COMPLETE',selected_source_files=len(rows)+len(supp)+1, selected_text_bytes=sum(x['original']['bytes'] for x in rows)+sum(x['original']['bytes'] for x in supp)+len(data), limits=dict(selected_source_files=LIMIT_FILES,retained_text_bytes=LIMIT_BYTES), archive_members_verified_equal=len(rows), jar_metadata_profiles=len(profiles), source_commit=archive_binding['archive_embedded_git_commit'], collector=False, build_or_jar_execution=False, network=False, shared_records_edited=False, publication_clearance=False))
print(json.dumps(json.loads((OUT/'readback.json').read_text()),sort_keys=True))

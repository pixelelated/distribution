"""Preserve the scoped FreeJ2ME source/notice supplement; no runtime or collection."""
from pathlib import Path
import hashlib,json,stat,tarfile,gzip,decimal,datetime,shutil
S=Path('/tmp/pix-m7-freej2me-vendor-notices-20261015')
D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-freej2me-vendor-notices')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for row in load(S/'selected-source-members.json')+load(S/'supplemental-license-provenance.json')+[load(S/'recipe-binding.json')]:
 p=S/row['retained'];r=row['original'];s=p.stat()
 assert sha(p)==r['sha256'] and s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==r['mode'] and s.st_mtime_ns==r['mtime_ns']
for r in load(S/'profile-bindings.json'):
 assert sha(S/r['retained_record'])==r['record_original']['sha256']
for r in load(S/'notice-block-index.json'):
 b=(S/'source'/r['relative']).read_bytes()
 assert hashlib.sha256(b).hexdigest()==r['source_sha256']
 assert hashlib.sha256(b[r['start_byte']:r['end_byte_exclusive']]).hexdigest()==r['block_sha256']
assert load(S/'readback.json')['selected_source_files']==113
assert sum(p.stat().st_size for p in S.rglob('*') if p.is_file()) < 8*1024*1024
assert not (S/'SHA256SUMS').exists()
files=sorted(p for p in S.rglob('*') if p.is_file());(S/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(S))+'\n' for p in files))
for line in (S/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(S/n)==h
assert not D.exists();D.mkdir(parents=True)
rows=[];pairs=[]
for p in [S,*sorted(S.rglob('*'))]:
 assert not p.is_symlink() and (p.is_file() or p.is_dir());s=p.stat();name='source-notice-supplement'+('/'+str(p.relative_to(S)) if p!=S else '')
 row=dict(member=name,original_path=str(p),kind='directory' if p.is_dir() else 'file',mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,bytes=s.st_size if p.is_file() else 0,sha256=sha(p) if p.is_file() else None);rows.append(row);pairs.append((p,name,row))
archive=D/'originals.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for p,name,row in pairs:
    m=t.gettarinfo(str(p),arcname=name);m.pax_headers={'mtime':str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(10**9))};row['uname']=m.uname;row['gname']=m.gname
    if p.is_file():
     with p.open('rb') as src:t.addfile(m,src)
    else:t.addfile(m)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  assert m.name.rstrip('/')==r['member'] and m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'] and m.uname==r['uname'] and m.gname==r['gname']
  assert int(decimal.Decimal(m.pax_headers['mtime'])*decimal.Decimal(10**9))==r['mtime_ns']
  if r['kind']=='file':assert m.isfile() and m.size==r['bytes'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']==sha(Path(r['original_path']))
  else:assert m.isdir()
dump(D/'members.json',dict(archive_sha256=sha(archive),members=rows,files=sum(r['kind']=='file' for r in rows),directories=sum(r['kind']=='directory' for r in rows),original_file_bytes=sum(r['bytes'] for r in rows)))
for n in ['README.md','NOTICE-TEXTS.txt','shader-next-operation.md']:shutil.copy2(S/n,D/n);assert sha(S/n)==sha(D/n)
dump(D/'custody-verification.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS_EXACT_CUSTODY_SOURCE_NOTICE_SUPPLEMENT',source_seal=sha(S/'SHA256SUMS'),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=len(rows),files=sum(r['kind']=='file' for r in rows),original_file_bytes=sum(r['bytes'] for r in rows),selected_source_files=113,selected_source_text_bytes=1707188,source_members_equal_archive=110,original_custody_readback_exit=0,new_runtime_or_tests=False,publication_clearance=False,original_metadata_scope='Archive exactly preserves the private packet; internal source indices separately preserve original source/host-licence ownership and timestamps. Copy2 retained files preserve original bytes/modes/mtime; local copied-file ownership is that of the source worker.'))
files=sorted(p for p in D.iterdir() if p.is_file());(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
for line in (D/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(D/n)==h
print(json.dumps(dict(directory=str(D),seal=sha(D/'SHA256SUMS'),source_seal=sha(S/'SHA256SUMS'),archive=sha(archive),archive_bytes=archive.stat().st_size,members=len(rows),files=sum(r['kind']=='file' for r in rows),original_file_bytes=sum(r['bytes'] for r in rows),readme_sha256=sha(S/'README.md')),indent=2))

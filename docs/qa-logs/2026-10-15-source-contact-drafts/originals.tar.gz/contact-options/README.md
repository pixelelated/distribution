# #528: ABL and one MAME adaptation — decision-ready source/contact options

No message was sent, upstream issue opened, public lookup repeated, source downloaded, target run or shared record changed. This packet uses only the named retained evidence in `evidence-references.json`; the two messages are drafts. Root owns any authorized external communication and subsequent work allocation.

| Item | Exact remaining fact | Work that can proceed locally | Smallest external or product option |
| --- | --- | --- | --- |
| Current SM8550 ABL1.2 | Implementation source/notices for LinuxLoader e9d37131 and the exact 8c27a709 ELF remain unavailable in the held source evidence. Packaging source and the accepted five-file identity are already retained. | Keep exact archive→ELF→accepted SM mapping and existing support-source/notices; prepare the source request below. Do not count the public packaging repository as implementation. | Ask the identified upstream integration author for the existing legacy source/maintainer route. If unavailable, evaluate the already located OpenABL replacement under #601 as a separate product decision, not a retrospective source substitution. |
| One MAME-derived Slang member | Original d13f34cd bytes/1ad00986 blob contain an explicitly uncertain licence statement for the UltraMoogleMan→Slang adaptation. | Preserve complete exact source, all credits and the dated history; prepare the narrow clarification below. Current MAME's distinct BSD text remains useful evidence, not an automatic grant over this port. | Ask the verified Slang port author for the original declaration or appropriate author. If unresolved, a narrowly scoped implementation from clearly declared source is a possible separate feature-preserving change, not an automatic removal or chosen migration. |

## Recipients and channel confidence

- **ABL:** @spycat88 is verified in retained official commit metadata as author of ROCKNIX's OpenABL transition. The same metadata supplies `https://api.github.com/repos/ROCKNIX/distribution/commits/71d8932b3374d2a9e04fbc200b5779394a57dae2/comments`. Use that existing commit discussion for routing the legacy-source question if contact is instructed. Release author `github-actions[bot]` is not a human source contact. The earlier unauthenticated LinuxLoader404 does not by itself prove permanent unavailability or a refusal.
- **MAME port:** @hunterk is verified as author/committer of exact introduction `0f247809e2eb83271ce4c6787a9d123a0f3193f8`. Its metadata supplies `https://api.github.com/repos/libretro/slang-shaders/commits/0f247809e2eb83271ce4c6787a9d123a0f3193f8/comments`. This is the direct provenance route. UltraMoogleMan is named in the actual header, but no usable contact account/mailbox was established; do not guess one.
- These are retained, dated primary routes, not freshly verified posting permissions, responsiveness or rights ownership. No new network request was necessary for drafting them.

## What is already settled; what remains a decision

D-WORKFLOW-084/097/131 settle the project's independent, for-fun, nonmonetized release scope. D-INFRA-016 concerns future observability, not an OS-wide artwork restriction. Do not ask the owner to re-decide noncommercial shader inclusion. The accepted 68-member CC inclusion and Koko supplied-GPL treatment remain in place; later Koko acquisition/custody is separate completed evidence and is not reopened by the historical follow-up's old wording.

No new legal guarantee or release gate is proposed. These are the two existing precise #528 questions. There is no local source or engineering decision that can manufacture the missing third-party declaration. Drafting, indexing and keeping other source/notices moving need no new permission. Sending these messages has not been instructed in this task; if the root wants external contact it needs the existing explicit instruction for that action, rather than an invented approval ceremony. This packet makes no user-facing permission request.

The genuine product choice arises only if the exact source/declaration cannot be obtained: select a replacement under #601 for legacy ABL, or a narrowly scoped alternative shader implementation, with the existing source/notice and affected validation duties. Neither choice is made here. Until then, no feature removal, broad replay, physical flash or new universal reproduction requirement is warranted.

## Bounded fallback already available

OpenABL v1.0 has a named 102,272,376-byte source archive and an explicit SM8550 revision `78b81b585f0f82882e9272cead99e1d395622de5`. The retained fetch script pins Qualcomm edk2 `aef4e86045bd151a54d33bab8ae5e8e62462a8f4`, microui `0850aba860959c3e75fb3e97120ca92957f9d057` and qtestsign `f3df53a5f0e37ccee076541f30f9d5b8340fc2d3`; its notice map and linking/source exception are retained. These are concrete future intake inputs, not an assertion that the archive contains that distinct SM revision or that it matches legacy ABL. Source-archive member association and updater/backup compatibility can be planned locally from existing code; actual acquisition or hardware work is outside this source-only packet.

The OpenABL repository's retained metadata reports issues enabled, offering `https://github.com/OpenHandheldCollective/OpenABL/issues` for a genuinely OpenABL-specific source-archive question if later necessary. Do not route the legacy ABL request there as if OpenABL maintainers had established ownership of the older implementation.

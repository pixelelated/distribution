"""Exact metadata and host bindings; no payload reads or collection at import."""
from pathlib import Path
import hashlib,json,os,re
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
SOURCE='077197e6cd3ea31f33b28aaf3882a694b3423b53'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def zero_run(run):
 r=load(Path(run)/'runner-result.json');assert all(type(r[k])is int and r[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
 assert (Path(run)/'build.rc').read_text().strip()=='0'
def prerequisites(plan):
 assert plan['source']==SOURCE and plan['publication_bundle_complete']is False
 m=load(plan['current_map']);assert m['source']==SOURCE and m['component_rows']==2366 and m['publication_bundle_complete']is False and m['new_package_inventory_claim']is False
 result=load(plan['map_result']);assert result['status']=='PASS_METADATA_ONLY' and result['source']==SOURCE and result['zerotier_replacements']==3
 zero_run(plan['map_run'])
 c=load(Path(plan['prior_copier_run'])/'admission-consumed.json')
 assert c['id']==plan['prior_copier_admission'] and c['state']=='consumed' and c['run']==plan['prior_copier_run'] and c['source']['head']==COMMIT
 assert all(type(c['original_result'][k])is int and c['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
 for run in plan['notice_runs']:zero_run(run)
 for owner in plan['notice_launchers']:
  l=load(Path(owner)/'launcher-result.json');assert type(l['runner_returncode'])is int and l['runner_returncode']==0
  assert (Path(owner)/'tool-wrapper.rc').read_text().strip()=='0'
 for spec in result['metadata_refs']:
  assert plan['binding_refs'][spec['path']]==spec['sha256']
 return m

def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 plan=load(O/'collection-plan.json');assert 1<=len(plan['binding_refs'])<=128
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 selection=load(O/'selected-members.json');assert sha(O/'selected-members.json')==plan['selection_sha256']
 assert len(selection['files'])==plan['expected_members']==1869 and len(selection['components'])==2366
 assert sum(r['bytes'] for r in selection['files'])==plan['expected_object_bytes']==12516737444
 assert len({r['sha256'] for r in selection['files']})==len(selection['files'])
 for r in selection['files']:
  assert re.fullmatch('[0-9a-f]{64}',r['sha256']) and r['member']=='objects/'+r['sha256'] and type(r['bytes'])is int and 0<=r['bytes']<=2*1024**3
  assert r['source_paths'] and all(Path(p).is_absolute() and '/build.' not in p and '/nix/store/' not in p and '/cache/' not in p for p in r['source_paths'])
 assert 'aa9de313d365bf0efb3871aaa56f2d323a08f46df47b627c4eff4f4203fa7fc5' not in {r['sha256'] for r in selection['files']}
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-delivery-source-'+O.name.removeprefix('pix-m7-delivery-assembly-')
 prerequisites(plan)
 return plan

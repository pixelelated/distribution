#!/bin/bash
set -eu
TASK_OWNER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
set +e
taskset -c 0,1 prlimit --as=2147483648 --fsize=2147483648 -- timeout --signal=TERM --kill-after=15s 930s python3 -I -S -B "$TASK_OWNER/run.py"
task_rc=$?
set -e
(set -C; printf '%s\n' "$task_rc" > "$TASK_OWNER/outer.rc")
exit "$task_rc"

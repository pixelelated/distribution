#!/bin/bash
# SOURCE ONLY / UNRUN. Root reviews exact seal, allocates, and supervises each action.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-delivery-assembly-plan-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-delivery-assembly-20261015-01}
cd "$TASK_TREE"
case "${1:?prepare, preflight, report, admit, launch, or consume}" in
 prepare) tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-owner.py" --owner "$TASK_OWNER" ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json" ;;
 admit) python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json" ;;
 launch) env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh" ;;
 consume) taskset -c 0,1 prlimit --as=2147483648 --fsize=67108864 -- timeout --signal=TERM --kill-after=15s 1230s python3 -I -S -B "$TASK_OWNER/consume.py" ;;
 *) exit 2 ;;
esac
# Submission is not completion. Root checks originals and host PID/start identities
# at most60seconds apart; no disconnected notification is armed by this packet.
# Failures require ordinary failed-investigated consumption, never this success consumer.

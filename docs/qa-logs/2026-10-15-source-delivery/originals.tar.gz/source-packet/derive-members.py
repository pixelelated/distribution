#!/usr/bin/env python3
"""Source preparation: read explicit held JSON manifests only; never read a payload."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
BASE=Path('/workspace/artifacts/pixelelated-release-sources')
REFS={};FILES={};COMPONENTS={};GIT_OWNERS={};read_bytes=0
STAT_ROWS={r['expected_sha256']:r for r in json.loads((P/'exact-size-metadata.json').read_text())['rows']}

def load(path):
 global read_bytes
 path=Path(path);body=path.read_bytes();assert len(body)<=8*1024**2
 read_bytes+=len(body);assert read_bytes<=32*1024**2
 REFS[str(path)]={'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
 return json.loads(body)
def add(path,h,n,label,component=None):
 path=str(path)
 if n is None and h in STAT_ROWS:
  observed=STAT_ROWS[h];assert observed['path']==path;n=observed['bytes']
 assert path.startswith(('/workspace/artifacts/','/workspace/tmp/','/tmp/','/workspace/repos/')) and '/build.' not in path and '/nix/store/' not in path and '/cache/' not in path
 assert len(h)==64 and (n is None or type(n)is int and n>=0)
 if h in FILES:
  r=FILES[h];assert r['bytes'] is None or n is None or r['bytes']==n
  if r['bytes'] is None:r['bytes']=n
  if path not in r['source_paths']:r['source_paths'].append(path)
  if label not in r['roles']:r['roles'].append(label)
 else:FILES[h]={'sha256':h,'bytes':n,'source_paths':[path],'roles':[label],'member':'objects/'+h}
 if component:COMPONENTS.setdefault(component,set()).add(h)
 return h
map_path=Path('/workspace/tmp/pix-m7-final-profile-map-20261015-01/current-profile-source-map.json')
m=load(map_path);assert m['source']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and m['component_rows']==2366
map_result=load(map_path.parent/'result.json');assert map_result['status']=='PASS_METADATA_ONLY'
map_runner=load('/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T172629Z-6c2483f3/runner-result.json');assert all(map_runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
a_root=BASE/'m7-archives-a7022b76da76a9f6771bb7693d6f6e25854c6731db0750bb46dde29f14d49fce'
g_root=BASE/'m7-git-266c8393884189dec9419628b3e7e527b965598d7b9b31e4ea31fd9af2204dc9'
d_root=BASE/'m7-additive-source-20261015-01'
a=load(a_root/'manifest.json');g=load(g_root/'manifest.json');d=load(d_root/'manifest.json')
archive_info={h:dict(path=str(a_root/'archives'/h),bytes=r['bytes']) for h,r in a['archives'].items()}
archive_info.update({r['sha256']:dict(path=str(d_root/r['member']),bytes=r['bytes']) for r in d['archives']})
archive_info[d['reused_doom']['sha256']]={k:d['reused_doom'][k] for k in ['path','bytes']}
selected_git=set();selected_old_archives=set()
def gitmember(root,s,key):
 h=s.get('archive_sha256',s.get('sha256'));n=s.get('archive_bytes',s.get('bytes'))
 add(root/s['archive_member'],h,n,'tracked-git-source',key)
 add(root/s['metadata_member'],s['metadata_sha256'],None,'git-blob-metadata',key)
 selected_git.add(s['commit']);GIT_OWNERS.setdefault(s['commit'],set()).add(key)
for row in m['components']:
 key=row['profile']+':'+row['component'];COMPONENTS.setdefault(key,set())
 for r in row['selected_members']:
  kind=r['kind']
  if kind=='historical-git-root':
   for s in r['snapshots']:gitmember(Path(r['custody']),s,key)
  elif kind=='new-git-root':
   gitmember(d_root,r['snapshot'],key)
   for sub in r['submodule_references']:gitmember(g_root,dict(commit=sub['commit'],**sub['historical_snapshot']),key)
  else:
   h=r['sha256'];meta=archive_info.get(h,r);add(r['path'],h,meta['bytes'],'selected-input:'+row['component'],key)
   if kind=='historical-archive':selected_old_archives.add(h)
 for r in row['additional_corresponding_source_refs']:
  add(r['path'],r['sha256'],archive_info[r['sha256']]['bytes'],'additional-corresponding-source',key)
# Current fork build source/patches, never old distribution snapshots.
snapshot=m['current_distribution_snapshot'];s=snapshot['member'];root=Path(snapshot['manifest']['path']).parent
add(root/s['archive_member'],s['sha256'],s['bytes'],'current-distribution-source')
add(root/s['metadata_member'],s['metadata_sha256'],snapshot['metadata']['bytes'],'current-distribution-metadata')
load(root/'manifest.json')
# Retain separately held historical cache extras only for selected commits, never blend them into exact Git snapshots.
for r in g['extra_source_cache_content']:
 if r['tracked_commit'] in selected_git:
  for key in GIT_OWNERS[r['tracked_commit']]:add(g_root/r['archive_member'],r['sha256'],None,'historical-selected-cache-extra',key)
# Exact39 already replaces transient FEX acquisition locations.
for r in m['held_supplement_members']:
 add(r['path'],r['sha256'],r['bytes'],r['kind'],'sm8550-aarch64:fex-emu' if r['member'].startswith('fex/') else None)
fex=next(r for r in m['components'] if r['component']=='fex-emu')['carried_source_additions']['fex_sources']
for r in fex['historical_reuse']:
 c=r['custody'];add(a_root/c['member'],c['sha256'],c['bytes'],'FEX-reused-source','sm8550-aarch64:fex-emu')
r=fex['libglvnd']['archive'];add(r['path'],r['sha256'],r['bytes'],'FEX-reused-source','sm8550-aarch64:fex-emu')
f_root=BASE/'m7-fex-held-source-20261015-01';f=load(f_root/'manifest.json')
r=f['nixpkgs']['custody'];add(r['path'],r['sha256'],r['bytes'],'selected-Nixpkgs-source','sm8550-aarch64:fex-emu')
for r in f['patches']:
 c=r['custody'];add(c['path'],c['sha256'],c['bytes'],'selected-Nix-patch','sm8550-aarch64:fex-emu')
p_root=BASE/'m7-fex-normalized-patches-20261015-01';patches=load(p_root/'manifest.json')
for r in patches['inputs']:add(p_root/r['member'],r['output_sha256'],r['output_bytes'],'normalized-selected-Nix-patch','sm8550-aarch64:fex-emu')
# Current Tailscale dependency ZIPs, their indexes and full retained notices.
t_root=BASE/'m7-tailscale-source-20261015-01';t=load(t_root/'manifest.json');modules=load(t_root/'module-member-index.json')
assert len(modules)==t['module_count']==89
for r in modules:
 for item in [r['archive'],r['member_index'],*r['notices']]:
  for profile in ['generic-x64-x86_64','h700-aarch64','sm8550-aarch64']:
   add(t_root/item['member'],item['sha256'],item['bytes'],'tailscale-module-source-or-notice',profile+':tailscale')
# Main Tailscale source. Old rclone source and old ABL packaging stay historical, not current delivery members.
pb_root=BASE/'m7-prebuilt-aeef83ae3a4de7ebaca3816508e804bf935e87285efdcff6226cb52bd2fc4827';pb=load(pb_root/'manifest.json')
for r in pb['components']:
 if r['component']!='tailscale':continue
 add(pb_root/r['archive_member'],r['archive_sha256'],r['archive_bytes'],'prebuilt-main-source' if r['component']=='tailscale' else 'ABL-packaging-only-not-implementation')
 add(pb_root/r['tree_metadata_member'],r['tree_metadata_sha256'],None,'prebuilt-tree-metadata')
 for n in r['notices']:add(pb_root/n['member'],n['sha256'],None,'prebuilt-retained-notice')
# Koko editing source and already selected unmodified notice/referral texts.
k_root=BASE/'m7-koko-editing-source-20261015-01';load(k_root/'manifest.json');objects=load(k_root/'object-member-index.json');notices=load(k_root/'notice-index.json')
for r in objects:
 for profile in ['generic-x64-x86_64','h700-aarch64','sm8550-aarch64']:add(k_root/r['member'],r['sha256'],r['bytes'],'koko-editing-source',profile+':slang-shaders')
r=notices['monitor_notice_copy'];add(k_root/r['member'],r['sha256'],r['bytes'],'koko-export-note')
for r in notices['references']:add(r['path'],r['sha256'],r['bytes'],'koko-notice-or-source-referral')
# Full FEX notice texts, retaining actual discovery gaps until the separate assessment arrives.
n_root=Path('/workspace/tmp/pix-m7-fex-full-notices-20261015-01');nr=load(n_root/'result.json');ni=load(n_root/'notice-members.json')
assert nr['original_exit']==0 and nr['status']=='COLLECTED_FOR_REVIEW' and len(ni['texts'])==76
for r in ni['texts']:add(n_root/r['member'],r['sha256'],r['bytes'],'full-selected-FEX-notice','sm8550-aarch64:fex-emu')
for name in ['gap-disposition.json','notice-map.json','review-observation.json']:
 load(Path('/tmp/pix-m7-fex-full-notices-review-20261015')/name)
# Supplementary protocol notice context keeps its version-only source association.
proto_root=Path('/workspace/tmp/pix-m7-fex-xcb-protocol-notices-20261015-01')
proto=load(proto_root/'notice-members.json');proto_result=load(proto_root/'result.json')
proto_map=load('/tmp/pix-m7-fex-protocol-notices-review-20261015/notice-map.json')
proto_review=load('/tmp/pix-m7-fex-protocol-notices-review-20261015/review-observation.json')
assert proto_result['original_exit']==0 and len(proto['texts'])==2 and proto_map['union_counts']['distinct_texts']==77
for r in proto['texts']:add(proto_root/r['member'],r['sha256'],r['bytes'],'supplementary-protocol-notice-version-association-only','sm8550-aarch64:fex-emu')
for r in map_result['metadata_refs']:
 actual=load(r['path']);assert REFS[r['path']]['sha256']==r['sha256'] and REFS[r['path']]['bytes']==r['bytes']
for path in [
 '/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03/.build-runs/20261015T172157Z-ad2c8624/runner-result.json',
 '/workspace/tmp/pix-m7-fex-full-notices-launcher-20261015-01/launcher-result.json',
 '/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03/.build-runs/20261015T173444Z-e82050c5/runner-result.json',
 '/workspace/tmp/pix-m7-fex-xcb-protocol-notices-launcher-20261015-01/launcher-result.json',
 '/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T144912Z-00b3e226/admission-consumed.json']:
 load(path)
# Historical notice copies are explicit evidence only. Never include old ZeroTier/nonfree diagnostics as current delivery.
legacy=load('/workspace/tmp/pix-m7-current-notice-supplement-20261015-04/retained-notice-index.json')
excluded_notice=[]
for r in legacy['retained_notice_members_rehashed']:
 if r['component']=='zerotier-one' or 'nonfree' in r.get('source_scope',''):
  excluded_notice.append(r);continue
 add(r['path'],r['sha256'],r['bytes'],'historical-notice-evidence-not-new-clearance')
load(P/'exact-size-metadata.json')
# Include small exact input manifests/current image mapping as metadata; no raw HTTP, credentials or cached trees.
for r in list(REFS.values()):add(r['path'],r['sha256'],r['bytes'],'assembly-provenance-metadata')
excluded_zt='aa9de313d365bf0efb3871aaa56f2d323a08f46df47b627c4eff4f4203fa7fc5'
assert excluded_zt not in FILES
# Every current-row reference to a delivered digest becomes a portable edge, while
# preserved absolute names remain provenance only. No arbitrary path is followed.
def hashes(value):
 if isinstance(value,str):return {value} if value in FILES else set()
 if isinstance(value,list):return set().union(*(hashes(v) for v in value))
 if isinstance(value,dict):return set().union(*(hashes(v) for v in value.values()))
 return set()
for row in m['components']:
 COMPONENTS[row['profile']+':'+row['component']].update(hashes(row))
for key in COMPONENTS:
 if key.endswith(':tailscale'):
  for r in pb['components']:
   if r['component']=='tailscale':COMPONENTS[key].update(hashes(r))
 if key.endswith(':slang-shaders'):COMPONENTS[key].update(hashes(notices))
for r in legacy['retained_notice_members_rehashed']:
 if r['sha256'] in FILES:
  for key in COMPONENTS:
   if key.endswith(':'+r['component']):COMPONENTS[key].add(r['sha256'])
assert len(COMPONENTS)==2366
rows=sorted(FILES.values(),key=lambda r:r['sha256'])
known=[r for r in rows if r['bytes'] is not None];unknown=[r for r in rows if r['bytes'] is None]
summary=dict(status='SOURCE_ONLY_MEMBER_SELECTION_NOT_COPIED',current_map=REFS[str(map_path)],members=len(rows),known_size_members=len(known),known_payload_and_metadata_bytes=sum(r['bytes'] for r in known),missing_size_members=len(unknown),largest_known_file_bytes=max(r['bytes'] for r in known),selected_historical_archive_count=len(selected_old_archives),selected_git_snapshot_count=len(selected_git),historical_archive_members_not_selected=len(set(a['archives'])-selected_old_archives),
 excluded_old_zerotier_archive=excluded_zt,excluded_zerotier_notice_diagnostics=excluded_notice,metadata_bytes_read=read_bytes,archive_payloads_read=0,cache_reads=0,publication_bundle_complete=False,off_host_destination=None,original_full_notice_gaps=nr['explicit_gaps'],supplementary_protocol_notice_union=proto_map['union_counts'],historical_archives_not_selected=[dict(sha256=h,bytes=a['archives'][h]['bytes']) for h in sorted(set(a['archives'])-selected_old_archives)])
def write(n,x):(P/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
write('selected-members.json',dict(schema=1,files=rows,components={k:sorted(v) for k,v in COMPONENTS.items()},common_members=[snapshot['member']['sha256'],snapshot['member']['metadata_sha256'],REFS[str(map_path)]['sha256']],shared_component_edges={r['profile']+':'+r['component']:r['carried_source_additions'].get('shared_source_components',[]) for r in m['components'] if r['carried_source_additions'].get('shared_source_components')},arm_companion_edges={r['profile']+':'+r['component']:r['carried_source_additions']['companion_profile'] for r in m['components'] if 'companion_profile' in r['carried_source_additions']},summary=summary))
write('metadata-inputs.json',REFS)
write('selection-summary.json',summary)
write('missing-size-members.json',unknown)
print(json.dumps({k:v for k,v in summary.items() if k not in ['excluded_zerotier_notice_diagnostics','original_full_notice_gaps','current_map']}))

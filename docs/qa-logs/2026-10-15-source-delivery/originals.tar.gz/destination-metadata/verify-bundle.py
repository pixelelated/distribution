#!/usr/bin/env python3
"""Verify only a supplied local/retrieved bundle and an externally retained manifest hash.
Absolute original paths in provenance are never opened, including on a missing member.
This establishes local bytes/mapping, not off-host retrieval or publication readiness.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,stat,time

def verify(root,expected_manifest_sha256):
 root=Path(root);assert root.is_absolute() and root.resolve(strict=True)==root and not root.is_symlink() and root.is_dir()
 assert re.fullmatch('[0-9a-f]{64}',expected_manifest_sha256)
 start=time.monotonic();read_bytes=0;verified={}
 def member(name):
  assert isinstance(name,str) and 0<len(name)<=4096 and '\\' not in name and '\0' not in name
  p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and '.git' not in p.parts and str(p)==name
  target=root/name;assert target.is_file() and not target.is_symlink() and target.resolve(strict=True)==target and target.is_relative_to(root)
  return target
 def read(name,expected=None,body=False):
  nonlocal read_bytes
  p=member(name);before=p.stat();assert stat.S_ISREG(before.st_mode) and before.st_size<=2*1024**3 and before.st_nlink==1
  if body:assert before.st_size<16*1024**2
  h=hashlib.sha256();parts=[]
  with p.open('rb') as f:
   while True:
    block=f.read(1024**2)
    if not block:break
    read_bytes+=len(block);assert read_bytes<=20*1024**3 and time.monotonic()-start<600
    h.update(block)
    if body:parts.append(block)
  after=p.stat();assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
  row=dict(member=name,bytes=before.st_size,sha256=h.hexdigest())
  if expected:assert row==expected
  verified[name]=row
  return (row,b''.join(parts)) if body else row
 mref,body=read('manifest.json',body=True);assert mref['sha256']==expected_manifest_sha256
 m=json.loads(body);assert m['schema']==1 and m['source']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and m['publication_bundle_complete']is False and m['off_host_destination']is None
 assert m['object_count']==1869 and m['object_bytes']==12516737444 and m['component_rows']==2366
 rows=m['objects']+m['metadata'];assert len(rows)==1874 and len({r['member'] for r in rows})==len(rows)
 assert sum(r['bytes'] for r in rows)+mref['bytes']<=16*1024**3
 catalog={r['sha256']:r for r in m['objects']};assert len(catalog)==1869
 assert all(r['member']=='objects/'+r['sha256'] and re.fullmatch('[0-9a-f]{64}',r['sha256']) for r in m['objects'])
 assert 'aa9de313d365bf0efb3871aaa56f2d323a08f46df47b627c4eff4f4203fa7fc5' not in catalog
 assert sum(r['bytes'] for r in m['objects'])==m['object_bytes']
 bodies={}
 for r in rows:
  if r['member'] in ['component-member-index.json','object-member-index.json','delivery-status.json']:
   actual,body=read(r['member'],r,body=True);bodies[r['member']]=json.loads(body)
  else:read(r['member'],r)
 actual=set();directories=0
 # Exactly the root and one objects directory; no recursive path fallback or cache scan.
 for p in root.iterdir():
  assert not p.is_symlink()
  if p.is_dir():
   directories+=1;assert p.name=='objects' and p.resolve(strict=True)==p
   for child in p.iterdir():
    assert len(actual)<2048 and child.is_file() and not child.is_symlink();actual.add(str(child.relative_to(root)))
  else:assert p.is_file();actual.add(p.name)
 assert directories==1 and len(actual)==m['expected_file_count']==1875 and actual==set(verified)
 objects=bodies['object-member-index.json'];assert len(objects)==1869
 assert [{k:r[k] for k in ['member','sha256','bytes']} for r in objects]==m['objects']
 for r in objects:
  assert r['independent_copy']is True
 index=bodies['component-member-index.json'];components=index['components'];assert len(components)==2366 and index['source']==m['source'] and index['absolute_provenance_is_not_payload_fallback']is True
 keys={r['key'] for r in components};assert len(keys)==2366
 profiles={r['profile'] for r in components};assert profiles=={'generic-x64-x86_64','h700-aarch64','h700-arm','sm8550-aarch64','sm8550-arm'}
 for r in index['common_members']:assert catalog[r['sha256']]==r
 assert len(index['common_members'])==3
 for c in components:
  assert c['key']==c['profile']+':'+c['component'] and c['membership_newly_measured']is False and c['common_members']=='common_members'
  assert len({r['sha256'] for r in c['members']})==len(c['members'])
  for r in c['members']:assert catalog[r['sha256']]==r
  assert all(key in keys for key in c['shared_components'])
  assert c['companion_profile']is None or c['companion_profile'] in profiles
 assert sum(len(c['shared_components']) for c in components)==16 and sum(c['companion_profile']is not None for c in components)==2
 status=bodies['delivery-status.json'];assert status['publication_bundle_complete']is False and status['off_host_destination']is None and status['independent_off_host_retrieval']is False and status['unresolved']==m['unresolved']
 for p in [root,root/'objects',*[root/n for n in actual]]:assert stat.S_IMODE(p.stat().st_mode)==(0o555 if p.is_dir() else 0o444)
 return dict(status='PASS_LOCAL_BYTES_AND_PORTABLE_MAP_WITH_EXPLICIT_GAPS',manifest_sha256=expected_manifest_sha256,objects=1869,object_bytes=12516737444,component_rows=2366,files=list(verified.values()),read_bytes=read_bytes,elapsed_seconds=time.monotonic()-start,original_paths_opened=0,network_used=False,independent_off_host_retrieval=False,publication_bundle_complete=False)

def main():
 q=argparse.ArgumentParser(description=__doc__);q.add_argument('--root',type=Path,required=True);q.add_argument('--expected-manifest-sha256',required=True);a=q.parse_args();r=verify(a.root,a.expected_manifest_sha256);print(json.dumps(r,sort_keys=True))
if __name__=='__main__':main()

# #528 retained strip loader closure — fresh02, UNRUN

This is a narrow source-only continuation of sealed packet ccd767d8 and failed owner01/run103607Z-bfddf11d. The original first strip returned127 before transforming its private copy: libbfd-2.47.20260726.so was not found. Original command/monitor/runner1/0/1, launcher1 and ordinary failed-investigation consumption5f00775e remain unchanged. The85,659,810-byte old private copy is excluded from this packet, is not reread here and is not a cleanup target.

All three original strip executables embed RUNPATHs using the historical canonical container mount names. Their retained host paths now have different checkout names. Frozen config/path:95 unsets LD_LIBRARY_PATH; the binutils recipe installs shared libbfd and libsframe. Thus merely invoking the exact retained strip from the host does not reproduce the container's path mapping. This continuation supplies an explicit current host reader closure; it does not claim the historical compiler environment or substitute a generic host strip.

## Exact correction

`dynamic-closure.json` binds each unchanged strip and its own retained libbfd, libzstd and libsframe, plus the actual host libc and loader. Only those14 unique named ELF files were read as data. All are ELF64LE/EM_X86_64; recursive DT_NEEDED and GNU symbol-version requirements are satisfied by the selected objects. libopcodes is not in this dependency closure. Full bytes/hash/device/inode/mode/uid/gid/nsmtime and lookup symlink targets are bound. Retained zstd copies have distinct hashes and are kept per profile. No target program or host ELF was executed during preparation.

The future collector first invokes each exact host loader under a10+5-second timeout with `--inhibit-cache`, an empty `--glibc-hwcaps-mask`, and `--library-path` containing the exact current BFD directory, retained toolchain/lib and host libc directory. Its sanitized environment contains only PATH and LC_ALL; /etc/ld.so.preload must be absent. Three original `--list` waits/stdout/stderr are retained before any private copy exists. Success requires all original waits0, blank stderr and precisely the five expected resolved shared-library identities (plus the kernel vDSO). Any unexpected library, alias, duplicate or incomplete listing fails.

Each existing30+5-second strip invocation then uses that bound loader and identical options. The libraries and symlink resolutions are rechecked before/after each transform and before success cleanup. The original nine strict private-copy→package→staged-byte comparisons, four retained Tailscale text inputs and exact inode-bound success cleanup remain. Failed checks preserve remaining scratch. The failed owner01's payload is never referenced as an input or deletion target.

The qualified pidfd/subreaper supervisor, run.sh and process-identity.py are byte-identical to the predecessor. Same600-second stage,630+15-second outer timeout, two CPUs,2GiB address-space/reservation,6GiB named hashing ceiling,128MiB per transformed file and512MiB scratch/output limit. Loader listings use≤2MiB files. The successful consumer additionally requires all three exact loader receipts; original stage/outer/launcher/watch statuses, absence and removal guards remain separate.

## Root-operated fresh continuation

Default owner `/workspace/tmp/pix-m7-prebuilt-strip-20261015-02`; owner01 is explicitly rejected. Preparation requires the original accepted association/final inventory, failed01's exact consumed receipt and immutable failure originals, the source seal and all current host closure identities. No future receipt is invented. Root allocates only after all other runtime has completed and been consumed.

```bash
bash /tmp/pix-m7-prebuilt-strip-20261015-02/commands.sh prepare
bash /tmp/pix-m7-prebuilt-strip-20261015-02/commands.sh preflight
bash /tmp/pix-m7-prebuilt-strip-20261015-02/commands.sh report
bash /tmp/pix-m7-prebuilt-strip-20261015-02/commands.sh admit
bash /tmp/pix-m7-prebuilt-strip-20261015-02/commands.sh launch
# After root supervision and original completion readback:
bash /tmp/pix-m7-prebuilt-strip-20261015-02/commands.sh consume
```

Preparation, helper imports, loader listings, strip transformations and tests have NOT run. Source checks are AST/bash-n, exact predecessor comparisons and bounded named ELF metadata reads only. `changes.diff` contains the full executable delta. Ordinary failed-investigation consumption remains root-owned if any stage fails.

A passing future result would establish only the selected strip transformation from known release bytes to existing package/staged bytes. It cannot establish source reproducibility, exact historical tool use, independent SYSTEM extraction, rclone's modified-source correspondence, Tailscale's absent VCS revision, full Go dependency notices, or legal/publication/off-host clearance. Those #528 gaps remain.

# #528 host namespace identity correction — source03, UNRUN

Source03 changes only metadata/provenance and the packet caller path from sealed source02 (69975355). All preparer, collector, closure helper, consumer, process ownership and lifecycle code bytes remain identical. Fresh runtime owner02 is still absent and remains the default. The original source02 packet is unchanged.

Root's watched preparation105149Z-2d61b959 ended command/monitor/runner1/0/1 before owner creation or any loader execution. Source02 had recorded host libc and ld-linux ownership as65534/65534 inside a restricted user namespace. Root's actual host observation records0/0. All14 exact objects' hashes, bytes, device, inode, permission modes and nanosecond mtimes match; no library changed. Source03 replaces only those two objects' UID/GID pairs (repeated in the three profile closures), retaining every strict identity check.

The actual original binding is `/tmp/pix-m7-strip02-root-review-20261015/actual-host-object-bindings.json`, SHA75190954a1047a5e47d6ff03bb92046bfe621b98d8e33ebe09c0d47cd90cf170. It records host PID namespace4026531836, user namespace4026531837, real UID/GID1000 and full identity maps. The exact binding and original failure report are copied in `originals/` and hash-bound through the ordinary existing reference guard. Original watch result/log references are also bound. Failed strip01 remains original127 with command/monitor/runner1/0/1 and consumed5f00775e; its85.7MB private copy is untouched.

`source-namespace-observation.json` records the current preparation sandbox's PID/user namespaces, UID/GID maps and observed IDs. The original source02 discovery namespace ID was not captured; it is explicitly unknown, not reconstructed from this later process. Original source02's65534 ownership observations and root's0 observations remain separately attributable. Future host binding discovery must retain these namespace/map fields alongside stat metadata and use an independently observed runtime-host binding; never normalize IDs silently or weaken equality.

Root may use the unchanged default owner02 after review and serialized allocation:

```bash
bash /tmp/pix-m7-prebuilt-strip-20261015-03/commands.sh prepare
bash /tmp/pix-m7-prebuilt-strip-20261015-03/commands.sh preflight
bash /tmp/pix-m7-prebuilt-strip-20261015-03/commands.sh report
bash /tmp/pix-m7-prebuilt-strip-20261015-03/commands.sh admit
bash /tmp/pix-m7-prebuilt-strip-20261015-03/commands.sh launch
# After original completion readback:
bash /tmp/pix-m7-prebuilt-strip-20261015-03/commands.sh consume
```

Three bound loader listings, nine strict byte derivations and exact success-only scratch retirement remain unchanged. Limits remain600s stage/630+15s outer, two CPUs/2GiB address space,2GiB reservation; no generic strip, historical compiler-environment or source/publication clearance claim. See `originals/source02-README.md` for the full unchanged stage scope.

Source-only metadata comparisons and AST/bash-n checks passed. No candidate imports, preparer, loader, strip, collector or tests ran during source03 preparation. The preparer's inherited terse docstring says no cache reads; its precise scope, unchanged from source02, includes bounded reads of the14 named host tool/library objects and no cache traversal. No future successful receipt is predicted.

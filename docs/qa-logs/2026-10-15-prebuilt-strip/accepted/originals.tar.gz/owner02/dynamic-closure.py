"""Exact host-reader closure checks; no executable is run by this module."""
from pathlib import Path
import hashlib,os,re,stat

IDENTITY_KEYS=('path','bytes','sha256','device','inode','mode','uid','gid','mtime_ns')

def read_identity(path):
    p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink()
    before=p.stat();assert stat.S_ISREG(before.st_mode) and before.st_size<=16*1024**2
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    after=p.stat();assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_mode)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_mode)
    return dict(path=str(p),bytes=before.st_size,sha256=h.hexdigest(),device=before.st_dev,inode=before.st_ino,mode=stat.S_IMODE(before.st_mode),uid=before.st_uid,gid=before.st_gid,mtime_ns=before.st_mtime_ns)

def verify(profile,digest=read_identity):
    # A system-wide preload could inject code even with an empty inherited LD environment.
    preload=Path('/etc/ld.so.preload');assert not preload.exists() and not preload.is_symlink(),'system preload must be absent'
    assert len(profile['objects'])==6 and profile['symbol_version_requirements_satisfied_by_bound_objects'] is True
    names={n:r for r in profile['objects'] for n in r['soname']}
    assert set(names)=={'libbfd-2.47.20260726.so','libzstd.so.1','libsframe.so.3','libc.so.6','ld-linux-x86-64.so.2'}
    for row in profile['objects']:
        p=Path(row['lookup_path']);assert str(p.resolve(strict=True))==row['path']
        assert (str(p.readlink()) if p.is_symlink() else None)==row['lookup_symlink']
        actual=digest(Path(row['path']))
        assert all(actual[k]==row[k] for k in IDENTITY_KEYS),'bound host closure changed'
        assert row['elf_machine']==62 and row['rpath']==[] and set(row['needed'])<=set(names)
        for name,versions in row['required_symbol_versions'].items():
            assert set(versions)<=set(names[name]['provided_symbol_versions'])
    assert profile['loader']==names['ld-linux-x86-64.so.2']['path'] and os.access(profile['loader'],os.X_OK)
    assert profile['loader_options']==['--inhibit-cache','--glibc-hwcaps-mask','','--library-path',':'.join(profile['library_path'])]
    return {n:r['path'] for n,r in names.items()}

def command(profile,strip):
    assert strip==profile['objects'][0]['path']
    return [profile['loader'],*profile['loader_options'],strip]

def resolved_list(text,profile):
    expected={n:r['path'] for r in profile['objects'] for n in r['soname']};observed={};vdso=0
    for line in text.splitlines():
        if re.fullmatch(r'\s*linux-vdso\.so\.1 \(0x[0-9a-f]+\)\s*',line):vdso+=1;continue
        m=re.fullmatch(r'\s*(\S+) => (\S+) \(0x[0-9a-f]+\)\s*',line)
        if m:name,path=m.groups()
        else:
            m=re.fullmatch(r'\s*(/\S+) \(0x[0-9a-f]+\)\s*',line)
            assert m,'unrecognized loader listing'
            name,path='ld-linux-x86-64.so.2',m.group(1)
        if Path(name).is_absolute():
            assert str(Path(name).resolve(strict=True))==expected['ld-linux-x86-64.so.2'],'unexpected absolute loader alias'
            name='ld-linux-x86-64.so.2'
        assert name in expected and name not in observed,'unexpected or duplicate host dependency'
        resolved=str(Path(path).resolve(strict=True));assert resolved==expected[name],'unexpected host dependency resolution'
        observed[name]=resolved
    assert vdso==1 and observed==expected,'incomplete exact host dependency listing'
    return observed

#!/usr/bin/env python3
"""Private-copy selected strip derivation and four retained text inputs; no target runs."""
from pathlib import Path
import datetime,hashlib,json,os,resource,runpy,stat,subprocess,sys,time
O=Path(__file__).resolve().parent;started=time.monotonic();total=0;rows=[];loader_rows=[];notices=[];removals=[];rc=1;error=None

def put(p,j):
    with p.open('x') as f:json.dump(j,f,indent=2,sort_keys=True);f.write('\n')

def ident(p):
    assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),p
    s=p.stat();assert stat.S_ISREG(s.st_mode),p
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)

def digest(p,limit=256*1024**2):
    global total
    before=ident(p);assert before['bytes']<=limit,p;h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):
            total+=len(b);assert total<=6*1024**3 and time.monotonic()-started<580
            h.update(b)
    assert ident(p)==before,'input changed';return dict(before,sha256=h.hexdigest())

try:
    plan=json.loads((O/'association-plan.json').read_text());tools=json.loads((O/'host-tools.json').read_text())
    assert len(plan['binaries'])==9 and len(plan['retained_notice_inputs'])==4
    for path,h in plan['binding_refs'].items():assert digest(Path(path),8*1024**2)['sha256']==h,path
    for item in tools.values():assert digest(Path(item['path']),16*1024**2)['sha256']==item['sha256'] and os.access(item['path'],os.X_OK)
    closure=json.loads((O/'dynamic-closure.json').read_text());D=runpy.run_path(str(O/'dynamic-closure.py'))
    assert set(closure)==set(tools)-{'timeout'}
    out=O/'collection';out.mkdir(mode=0o700)
    # Only the bound host loader is exercised here; no strip transformation or target starts.
    for profile,bound in closure.items():
        assert bound['objects'][0]['path']==tools[profile]['path'] and bound['objects'][0]['sha256']==tools[profile]['sha256']
        D['verify'](bound,digest)
        base=D['command'](bound,tools[profile]['path']);argv=[tools['timeout']['path'],'--signal=TERM','--kill-after=5s','10s',*base[:-1],'--list',base[-1]]
        stdout,stderr=out/(profile+'.loader.stdout'),out/(profile+'.loader.stderr')
        with stdout.open('xb') as so,stderr.open('xb') as se:
            proc=subprocess.run(argv,stdout=so,stderr=se,cwd=O,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},
                preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**2,2*1024**2)))
        loader=dict(profile=profile,argv=argv,original_loader_returncode=proc.returncode)
        put(out/(profile+'.loader.wait.json'),loader)
        loader_rows.append(loader);loader.update(stdout=digest(stdout,2*1024**2),stderr=digest(stderr,2*1024**2))
        assert type(proc.returncode) is int and proc.returncode==0,'original host loader listing failed'
        assert stderr.stat().st_size==0,'host loader reported a diagnostic'
        loader['resolved']=D['resolved_list'](stdout.read_text(),bound)
        D['verify'](bound,digest);put(out/(profile+'.loader.verified.json'),loader)
    scratch=O/'private-copies';scratch.mkdir(mode=0o700)
    for index,item in enumerate(plan['binaries'],1):
        original={}
        for role in ['source_root','package_file','image_file']:
            original[role]=digest(Path(item[role]));assert original[role]==item['observed_files'][role],'observed original changed'
        assert original['package_file']['sha256']==original['image_file']['sha256']
        name=f'{index:02d}-{item["profile"]}-{item["binary"]}';copy=scratch/name
        # Exclusive independent inode, no hardlink or symlink to an input; mode0600 prevents target execution.
        with Path(item['source_root']).open('rb') as source,copy.open('xb') as target:
            os.fchmod(target.fileno(),0o600)
            for block in iter(lambda:source.read(1024**2),b''):target.write(block)
        copied=digest(copy);assert copied['sha256']==original['source_root']['sha256']
        assert (copied['device'],copied['inode'])!=(original['source_root']['device'],original['source_root']['inode'])
        tool=tools[item['profile']];bound=closure[item['profile']];D['verify'](bound,digest)
        argv=[tools['timeout']['path'],'--signal=TERM','--kill-after=5s','30s',*D['command'](bound,tool['path']),str(copy)]
        stdout,stderr=out/(name+'.stdout'),out/(name+'.stderr')
        with stdout.open('xb') as so,stderr.open('xb') as se:
            proc=subprocess.run(argv,stdout=so,stderr=se,cwd=O,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},
                preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(128*1024**2,128*1024**2)))
        put(out/(name+'.wait.json'),dict(argv=argv,original_reader_returncode=proc.returncode))
        row=dict(selection=item,argv=argv,original_reader_returncode=proc.returncode,source_before=original,private_before=copied,
            stdout=digest(stdout,2*1024**2),stderr=digest(stderr,2*1024**2),private_after=digest(copy))
        rows.append(row);put(out/(name+'.original.json'),row)
        assert type(proc.returncode) is int and proc.returncode==0,'original strip/timeout failed'
        assert row['private_after']['mode']==0o600 and row['private_after']['sha256']==original['package_file']['sha256'],'private strip output differs from exact package'
        for role in original:assert digest(Path(item[role]))==original[role],'protected original changed'
        assert digest(Path(tool['path']),2*1024**2)['sha256']==tool['sha256'],'selected host strip changed'
        D['verify'](bound,digest)
        row['strip_equals_package_and_staged_image']=True
        row['protected_inputs_unchanged']=True
        put(out/(name+'.derivation.json'),row)
        assert sum(p.stat().st_size for p in scratch.iterdir())<=512*1024**2
    textdir=out/'retained-texts';textdir.mkdir()
    for item in plan['retained_notice_inputs']:
        original=digest(Path(item['path']),2*1024**2);assert original['sha256']==item['sha256']
        dest=textdir/item['sha256']
        with Path(item['path']).open('rb') as source,dest.open('xb') as target:target.write(source.read(2*1024**2+1))
        copied=digest(dest,2*1024**2);assert copied['sha256']==item['sha256']
        assert digest(Path(item['path']),2*1024**2)==original
        notices.append(dict(selection=item,original=original,retained=copied))
    for path,h in plan['binding_refs'].items():assert digest(Path(path),8*1024**2)['sha256']==h,path
    for bound in closure.values():D['verify'](bound,digest)
    # Immediate-use scratch retirement: only after all original waits, exact equality,
    # retained texts and protected inputs/refs have passed. No failure-path deletion.
    expected={Path(r['private_after']['path']).name:r for r in rows}
    assert len(expected)==9 and set(p.name for p in scratch.iterdir())==set(expected)
    for row in rows:
        for role in row['source_before']:assert digest(Path(row['selection'][role]))==row['source_before'][role]
        artifact=Path(row['private_after']['path']);assert artifact.parent==scratch
        assert digest(artifact)==row['private_after']
    put(out/'cleanup-ready.json',dict(status='ALL_NINE_DERIVATIONS_AND_ORIGINAL_RECHECKS_PASSED',files=[r['private_after'] for r in rows]))
    fd=os.open(scratch,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        for name,row in expected.items():
            p=scratch/name;meta=row['private_after'];s=os.stat(name,dir_fd=fd,follow_symlinks=False)
            assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
            assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,stat.S_IMODE(s.st_mode))==(meta['device'],meta['inode'],meta['bytes'],meta['mtime_ns'],meta['mode'])
            os.unlink(name,dir_fd=fd)
            try:os.stat(name,dir_fd=fd,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise RuntimeError('owned private file remains after unlink')
            receipt=dict(path=str(p),original_private_identity=meta,removed=True,absent_after=True)
            removals.append(receipt);put(out/(name+'.removed.json'),receipt)
        assert list(scratch.iterdir())==[]
    finally:os.close(fd)
    put(out/'scratch-cleanup.json',dict(status='PASS',removed=removals,remaining=[],protected_originals_removed=0))
    rc=0
except BaseException as exc:error=type(exc).__name__+': '+str(exc)
finally:
    put(O/'collection-result.json',dict(result='COLLECTED_WITH_EXPLICIT_GAPS' if rc==0 else 'STRIP_DERIVATION_FAILED',original_collector_exit=rc,error=error,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,loader_rows=loader_rows,notices=notices,historical_compiler_environment_reproduced=False,named_bytes_hashed=total,elapsed_seconds=time.monotonic()-started,target_execution=False,network_used=False,publication_clearance=False,independent_SYSTEM_relation_established=False,source_reproducibility=False,outputs_held=True,private_scratch_removals=removals,private_scratch_removed_bytes=sum(r['original_private_identity']['bytes'] for r in removals),protected_original_deleted_bytes=0,scope='Nine exact private strip transformations plus four retained Tailscale source/notice texts; no source rebuild, target execution or independent SYSTEM read. rclone modified source and embedded dependency notices remain unresolved.'))
sys.exit(rc)

"""Bound accepted inventory metadata only; no cache walks or product mutation."""
from pathlib import Path
import hashlib,json,os
COMMIT = 'f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    p = Path(path)
    assert p.is_file() and not p.is_symlink() and p.stat().st_size < 20 * 1024**2, p
    return json.loads(p.read_text())

def host_and_serialization(own_run=None):
    assert (os.getuid(), os.getgid()) == (1000, 1000)
    assert os.readlink('/proc/self/ns/pid') == 'pid:[4026531836]'
    registry = load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')
    active = [j for j in registry['jobs'].values() if j['state'] != 'consumed']
    assert all(own_run is not None and j['run'] == str(own_run) for j in active), 'another unconsumed owner remains'
    if own_run is not None:
        assert len(active) == 1 and active[0]['source']['head'] == COMMIT

def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<20*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    p=load(O/'association-plan.json')
    for name,h in p['binding_refs'].items():
        f=Path(name);assert f.is_absolute() and f.resolve(strict=True)==f and not f.is_symlink() and f.stat().st_size<8*1024**2
        assert sha(f)==h,name
    base=Path('/workspace/tmp/pix-m7-final-inventory-20261015-01')
    result=load(base/'result.json')
    assert result['result']=='PASS_INVENTORY_WITH_PUBLICATION_GAPS' and result['publication_bundle_complete'] is False
    consumed=load('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T093346Z-ed162eab/admission-consumed.json')
    assert consumed['id']=='e73b73b3325f41c392a8eb6e7ddeb105' and consumed['state']=='consumed'
    assert all(type(consumed['original_result'][k]) is int and consumed['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert len(p['binaries'])==9 and len({(r['profile'],r['binary']) for r in p['binaries']})==9
    previous=load(p['previous_collection']['path'])
    assert previous['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and len(previous['rows'])==9
    prior=load('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T101845Z-84e4a2bc/admission-consumed.json')
    assert prior['id']=='09ce2e41eb24424da74af4c91f0d0fe4' and prior['state']=='consumed'
    assert all(type(prior['original_result'][k]) is int and prior['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert all(r['archive_to_unpacked_equal'] is True and r['package_to_staged_image_equal'] is True and r['unpacked_to_package_equal'] is False for r in previous['rows'])
    failed=p['failed_first_strip'];first=Path(failed['owner']);first_run=Path(failed['run'])
    assert first==Path('/workspace/tmp/pix-m7-prebuilt-strip-20261015-01') and O!=first
    consumed_failure=load(first_run/'admission-consumed.json')
    assert consumed_failure['id']==failed['consumed_id']=='5f00775e8ca64b008151c0a1d99bc538' and consumed_failure['state']=='consumed'
    assert consumed_failure['submission_owner']==str(first) and consumed_failure['source']['head']==COMMIT
    assert all(type(consumed_failure['original_result'][k]) is int and consumed_failure['original_result'][k]==v for k,v in failed['original_channels'].items())
    assert consumed_failure['outputs_held'] is True and consumed_failure['deleted_bytes']==0
    ev=load(first/'failure-completion-evidence.json')
    assert ev['disposition']=='failed-investigated' and ev['expected_rc']==1 and ev['run']==str(first_run)
    assert consumed_failure['evidence_sha256']==sha(first/'failure-completion-evidence.json')
    previous_failure=load(first/'collection-result.json');assert previous_failure['original_collector_exit']==1 and len(previous_failure['rows'])==1
    first_row=previous_failure['rows'][0]
    assert type(first_row['original_reader_returncode']) is int and first_row['original_reader_returncode']==127
    assert first_row['private_before']['sha256']==first_row['private_after']['sha256']==first_row['source_before']['source_root']['sha256']
    assert previous_failure['private_scratch_removals']==[] and previous_failure['private_scratch_removed_bytes']==0
    assert load(first/'cleanup.json')['signals_sent']==[] and load(first/'cleanup.json')['survivors_after_cleanup']==[]
    return p

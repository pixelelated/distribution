The first private-copy strip check failed at host library loading before transformation; its failure remains recorded. The reviewed continuation now selects the matching retained build-tool libraries explicitly and checks their resolved identities before transforming private copies. Original package and image files remain read-only.

Can this be done on the VM? No: this tests the host build-tool transformation from retained upstream release bytes to packaged bytes. It does not execute the target binaries or test device behavior. A watched, bounded host run will record the original results; a pass establishes only byte derivation, not complete corresponding source or publication clearance.

The separate notice collector stopped at its configured database path-count limit. Its partial records and original failure were preserved, and its processes have exited. Source review of a narrower continuation proceeds independently; no automatic limit increase or firmware change is implied.

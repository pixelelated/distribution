# #528 selected strip derivation and retained texts — UNRUN

This is one small continuation after original association run101845Z-84e4a2bc/consumed09ce2e41. All four release archives and nine archive→unpacked and package→staged relations passed there; all nine unpacked→package relations differed. This packet tests only whether the exact retained target strip tools reproduce those observed package bytes on private copies. No assumption of success, source reproducibility or publication clearance is made.

The frozen `scripts/build:599–611` strips executable package files with `${STRIP}` and no additional flags. `config/functions:452` sets `${TARGET_PREFIX}strip`; `config/path:17,35` supplies the target name/prefix and line95 unsets LD_LIBRARY_PATH. Exact recipe/script hashes are bound for the three current trees. Three named retained strip tools were read as data (about2.84MiB total), identified as ELF64LE EM_X86_64 and hash-bound; no strip executable ran. They inspect target-format bytes, not execute target programs. Actual tool records are in `host-tools.json`; the successful original timeout identity is uutils, preserved explicitly.

## What the future stage does

1. Rehash original association result/consumed and final inventory references. Recheck the27 exact source/package/staged input identities and hashes from the completed collector. No archive is reread, no cache tree enumerated, and no source is fetched.
2. For each of nine selected binaries, create an exclusive independent inode in the new owner's private directory with mode0600. Require its hash equals the unpacked original. Execute only the bound host strip tool on this private copy, through the bound30+5-second timeout. Capture original wait/stdout/stderr before asserting success. Require exact resulting bytes equal the previously recorded package and staged-image hashes; rehash all protected originals and the selected tool. Any discrepancy fails and retains the original evidence/copies.
3. Copy only four already retained Tailscale source/notice objects by exact hashes: LICENSE, PATENTS, go.mod and go.sum at source05a91829. The prior source archive/member comparison qualifies these input identities. They remain version/tag source evidence, not a reproducible source-to-binary relationship or complete embedded dependency notice coverage. rclone1.75.2's be8d6044 revision and modified=true remain unresolved; old1.75.1 source is not substituted.
4. After every derivation, retained-text copy, bound reference and protected-input recheck succeeds, retire only the nine exact private inode identities through an opened private directory FD. Require regular files with one link, exact device/inode/size/nsmtime/mode, retain individual removal receipts and recheck absence. Final success requires all nine removed and private directory empty. No failure-path cleanup exists: before cleanup nothing is deleted; a later removal/receipt failure retains remaining scratch and fails, without pretending removed bytes still exist. Shared originals are never deletion targets.

The unchanged qualified pidfd/subreaper supervisor owns the stage and its descendants. Original strip/timeout statuses, collector wait, supervisor/outer/launcher/watch outcomes and strict absence checks all remain distinct. A successful consumer requires all originals0, no forced cleanup/errors/survivors, nine exact equality/removal receipts and the four bound texts. Ordinary failed-investigation consumption remains root-owned on failure. Existing producer failures and source-family differences stay unchanged.

## Bounds and preparation

Same600-second collector/630+15-second outer and13-second bounded descendant cleanup as the qualified predecessor; two CPUs/2GiB address space. Each strip gets30+5seconds.128MiB per process-created file supports the largest85.7MB selected input; stdout/stderr must each be≤2MiB for acceptance. Private source copies total at most452,032,170observed bytes; expected transformed total387,715,376bytes.512MiB successful owner-output ceiling and2GiB reservation cover bounded scratch plus failure/margin. All success scratch is removed immediately after proof; compact metadata/text remains. No firmware/build/cache copying or deletion credit.

Fresh default owner `/workspace/tmp/pix-m7-prebuilt-strip-20261015-01`. All tool paths/hashes and original input hashes are now concrete. After source review and root allocation, run separate steps:

```bash
bash /tmp/pix-m7-prebuilt-strip-20261015/commands.sh prepare
bash /tmp/pix-m7-prebuilt-strip-20261015/commands.sh preflight
bash /tmp/pix-m7-prebuilt-strip-20261015/commands.sh report
bash /tmp/pix-m7-prebuilt-strip-20261015/commands.sh admit
bash /tmp/pix-m7-prebuilt-strip-20261015/commands.sh launch
# Root actively supervises, reads all original completions, then:
bash /tmp/pix-m7-prebuilt-strip-20261015/commands.sh consume
```

Only `TASK_OWNER` may optionally select a fresh02/etc owner. No future Go/strip tool digest or successful receipt is predicted. No preparer, collector, strip command, target, test, container or runtime ran during source preparation; static checks are AST/bash-n and small retained-source/metadata comparisons only. Current sealed predecessors remain immutable.

## Limits after a passing result

A successful private strip equality establishes a concrete transformation from the observed upstream release bytes to existing package/staged bytes using the selected retained host tool. It does not reconstruct original compilation or prove which tool inode ran historically. It does not independently extract accepted SYSTEM, resolve rclone's modified source, prove Tailscale's absent VCS revision, cover all Go dependency notices, or clear source/legal/publication/retrieval/off-host requirements. These remain explicit #528 gaps. The existing shader/vendor/ZeroTier notice plan follows later without rerunning this association inventory.

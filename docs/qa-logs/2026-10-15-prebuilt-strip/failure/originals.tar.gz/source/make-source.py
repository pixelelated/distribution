from pathlib import Path
import json,hashlib,shutil,stat
P=Path('/tmp/pix-m7-prebuilt-strip-20261015');old=Path('/tmp/pix-m7-prebuilt-association-20261015');O=Path('/workspace/tmp/pix-m7-prebuilt-association-20261015-01')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,j):p.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
for name in ['run.py','run.sh','bindings.py','consume.py','process-identity.py','collect.py']:
 shutil.copy2(old/'templates'/name,P/'originals'/name)
 if name in ['run.py','run.sh','bindings.py','process-identity.py']:shutil.copy2(old/'templates'/name,P/'templates'/name)
shutil.copy2(old/'prepare-owner.py',P/'originals/prepare-owner.py');shutil.copy2(old/'commands.sh',P/'originals/commands.sh');shutil.copy2(old/'frozen-tools.json',P/'frozen-tools.json')
j=json.loads((O/'collection-result.json').read_text());plan=json.loads((O/'association-plan.json').read_text());run=Path((O/'run.path').read_text().strip())
plan['previous_collection']=dict(path=str(O/'collection-result.json'),sha256=sha(O/'collection-result.json'))
for f in [O/'collection-result.json',O/'admission-completion-evidence.json',run/'admission-consumed.json',O/'host-tools.json',old/'SHA256SUMS']:
 plan['binding_refs'][str(f)]=sha(f)
plan['binaries']=[dict(r['selection'],observed_files=r['files']) for r in j['rows']]
tools={'timeout':json.loads((O/'host-tools.json').read_text())['timeout']};sources={}
for row in plan['binaries']:
 profile=row['profile'];build=Path(row['package_file']).parents[4]
 # package_file ends install_pkg/pkg/usr/{bin,sbin}/name: parent4 is buildroot.
 tool=build/'toolchain/bin'/('x86_64-rocknix-linux-gnu-strip' if row['architecture']=='amd64' else 'aarch64-rocknix-linux-gnu-strip')
 if profile not in tools:
  before=tool.stat();data=tool.read_bytes();after=tool.stat();assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
  assert data[:6]==b'\x7fELF\x02\x01' and int.from_bytes(data[18:20],'little')==62 and len(data)<2*1024**2
  tools[profile]=dict(path=str(tool),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),mode=stat.S_IMODE(before.st_mode),uid=before.st_uid,gid=before.st_gid,mtime_ns=before.st_mtime_ns,elf_machine=62)
  tree=build.parent
  for rel in ['scripts/build','config/functions','config/path','projects/ROCKNIX/packages/network/rclone/package.mk','projects/ROCKNIX/packages/network/tailscale/package.mk']:
   f=tree/rel;sources[str(f)]=sha(f);plan['binding_refs'][str(f)]=sha(f)
row=json.loads((O/'historical-source-identities.json').read_text())['tailscale'];base=Path('/workspace/artifacts/pixelelated-release-sources/m7-prebuilt-aeef83ae3a4de7ebaca3816508e804bf935e87285efdcff6226cb52bd2fc4827')
plan['retained_notice_inputs']=[dict(path=str(base/r['member']),sha256=r['sha256'],source_member=r['path'],component='tailscale',source_commit=row['commit'],scope='Retained version/tag source identity only; not proof of source-to-binary reproducibility or complete embedded notices') for r in row['notices'] if r['path'] in ['LICENSE','PATENTS','go.mod','go.sum']]
plan['scope']='Nine private copies transformed by exact retained target strip tools, byte-equal to previously observed package/staged files; four retained Tailscale source/notice texts. No target execution, download, full source rebuild or independent SYSTEM extraction.'
put(P/'association-plan.json',plan);put(P/'host-tools.json',tools);put(P/'recipe-references.json',sources)
resources=dict(cpu_affinity=[0,1],address_space_bytes=2147483648,per_file_bytes=134217728,owner_output_ceiling_bytes=536870912,collector_seconds=600,outer_seconds=630,cleanup_seconds=15,retention_budget_bytes=2147483648,scope='One private-copy strip derivation stage. Observed source bytes452032170; expected retained transformed bytes387715376;512MiB output ceiling plus reserve. No existing inputs or caches mutated/deleted.')
put(P/'resources.json',resources)
s=(P/'templates/run.sh').read_text().replace('--fsize=67108864','--fsize=134217728');(P/'templates/run.sh').write_text(s)
s=(P/'templates/run.py').read_text().replace('selected-prebuilt-association','selected-prebuilt-strip-derivation').replace('PASS_ASSOCIATION_COLLECTION_WITH_GAPS','PASS_STRIP_DERIVATION_WITH_GAPS').replace('ASSOCIATION_INCOMPLETE','STRIP_DERIVATION_INCOMPLETE').replace('Bounded offline association collection only; no source/notice, independent SYSTEM, reproducibility or publication clearance; prior producer dispositions unchanged.','Nine private strip transformations plus four retained texts only; no target execution, source reproducibility, independent SYSTEM or publication clearance; prior producer dispositions unchanged.')
(P/'templates/run.py').write_text(s)
s=(P/'templates/bindings.py').read_text();s=s.replace('    return p\n', '''    previous=load(p['previous_collection']['path'])
    assert previous['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and len(previous['rows'])==9
    prior=load('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T101845Z-84e4a2bc/admission-consumed.json')
    assert prior['id']=='09ce2e41eb24424da74af4c91f0d0fe4' and prior['state']=='consumed'
    assert all(type(prior['original_result'][k]) is int and prior['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert all(r['archive_to_unpacked_equal'] is True and r['package_to_staged_image_equal'] is True and r['unpacked_to_package_equal'] is False for r in previous['rows'])
    return p
''');(P/'templates/bindings.py').write_text(s)

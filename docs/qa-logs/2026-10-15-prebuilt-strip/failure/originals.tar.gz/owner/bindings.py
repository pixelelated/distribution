"""Bound accepted inventory metadata only; no cache walks or product mutation."""
from pathlib import Path
import hashlib,json,os
COMMIT = 'f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    p = Path(path)
    assert p.is_file() and not p.is_symlink() and p.stat().st_size < 20 * 1024**2, p
    return json.loads(p.read_text())

def host_and_serialization(own_run=None):
    assert (os.getuid(), os.getgid()) == (1000, 1000)
    assert os.readlink('/proc/self/ns/pid') == 'pid:[4026531836]'
    registry = load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')
    active = [j for j in registry['jobs'].values() if j['state'] != 'consumed']
    assert all(own_run is not None and j['run'] == str(own_run) for j in active), 'another unconsumed owner remains'
    if own_run is not None:
        assert len(active) == 1 and active[0]['source']['head'] == COMMIT

def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<20*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    p=load(O/'association-plan.json')
    for name,h in p['binding_refs'].items():
        f=Path(name);assert f.is_absolute() and f.resolve(strict=True)==f and not f.is_symlink() and f.stat().st_size<8*1024**2
        assert sha(f)==h,name
    base=Path('/workspace/tmp/pix-m7-final-inventory-20261015-01')
    result=load(base/'result.json')
    assert result['result']=='PASS_INVENTORY_WITH_PUBLICATION_GAPS' and result['publication_bundle_complete'] is False
    consumed=load('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T093346Z-ed162eab/admission-consumed.json')
    assert consumed['id']=='e73b73b3325f41c392a8eb6e7ddeb105' and consumed['state']=='consumed'
    assert all(type(consumed['original_result'][k]) is int and consumed['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert len(p['binaries'])==9 and len({(r['profile'],r['binary']) for r in p['binaries']})==9
    previous=load(p['previous_collection']['path'])
    assert previous['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and len(previous['rows'])==9
    prior=load('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T101845Z-84e4a2bc/admission-consumed.json')
    assert prior['id']=='09ce2e41eb24424da74af4c91f0d0fe4' and prior['state']=='consumed'
    assert all(type(prior['original_result'][k]) is int and prior['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert all(r['archive_to_unpacked_equal'] is True and r['package_to_staged_image_equal'] is True and r['unpacked_to_package_equal'] is False for r in previous['rows'])
    return p

#!/usr/bin/env python3
"""Release only this reader's exact SYSTEM after consumption and root acceptance."""
from pathlib import Path
import argparse,json,runpy,stat
O=Path(__file__).resolve().parent
q=argparse.ArgumentParser(description=__doc__);q.add_argument('--acceptance',type=Path,required=True);a=q.parse_args()
B=runpy.run_path(str(O/'bindings.py'));plan=B['verify'](O);B['host_and_serialization']()
run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs'
c=B['load'](run/'admission-consumed.json');assert c['state']=='consumed' and c['run']==str(run) and c['submission_owner']==str(O)
assert c['evidence_sha256']==B['sha'](O/'admission-completion-evidence.json')
accepted=B['load'](a.acceptance);assert accepted['decision']=='ACCEPT_H700_PACKAGE_APPLICABILITY' and accepted['release_system']is True
assert accepted['run']==str(run) and accepted['after_results_sha256']==B['sha'](O/'after-results.json') and accepted['system_sha256']==plan['system_sha256']
after=B['load'](O/'after-results.json');independent=B['load'](O/'independent-readback.json')
assert after['result']=='PASS_H700_PACKAGE_APPLICABILITY' and independent['result']=='PASS_SMALL_INDEPENDENT_READBACK'
assert independent['after_results_sha256']==accepted['after_results_sha256'] and independent['system_identity']==after['system_identity']
system=O/'SYSTEM';s=system.lstat();assert stat.S_ISREG(s.st_mode) and not system.is_symlink() and system.resolve(strict=True)==system
identity=dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,mode=stat.S_IMODE(s.st_mode));assert identity==after['system_identity']
assert not (O/'system-retirement.json').exists()
system.unlink();assert not system.exists() and not system.is_symlink()
with (O/'system-retirement.json').open('x') as f:
 json.dump(dict(result='RETIRED_EXACT_ACCEPTED_SYSTEM',path=str(system),identity=identity,system_sha256=plan['system_sha256'],root_acceptance=str(a.acceptance),root_acceptance_sha256=B['sha'](a.acceptance),consumed_admission=c['id'],deleted_logical_bytes=identity['bytes'],other_outputs_retained=True),f,indent=2);f.write('\n')
print('PASS retired exact accepted scratch SYSTEM only; all small originals retained')

#!/bin/bash
set -eu
TASK_OWNER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
set +e
taskset -c 0 prlimit --as=1073741824 --fsize=1610612736 -- timeout --signal=TERM --kill-after=15s 315s python3 -I -S -B "$TASK_OWNER/run.py"
task_rc=$?
set -e
(set -C; printf '%s\n' "$task_rc" > "$TASK_OWNER/outer.rc")
exit "$task_rc"

#!/usr/bin/env python3
"""Verify original success and small output readback, then consume; retain SYSTEM."""
from pathlib import Path
import json,runpy,subprocess,stat
O=Path(__file__).resolve().parent;B=runpy.run_path(str(O/'bindings.py'));plan=B['verify'](O)
assert Path.cwd()==B['VM_TREE'];load,sha=B['load'],B['sha'];run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs';B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/applicability.exit']:assert p.read_text().strip()=='0',p
result,cleanup=load(O/'result.json'),load(O/'cleanup.json');assert result['result']=='PASS_H700_PACKAGE_APPLICABILITY'
assert result['runtime_control_source']==B['COMMIT'] and result['publication_bundle_complete']is False
assert result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['applicability_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/applicability.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0
assert child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');assert report['result']=='PASS_H700_PACKAGE_APPLICABILITY' and type(report['original_collector_exit'])is int and report['original_collector_exit']==0
assert report['elapsed_seconds']<270 and report['system_retained'] is True and not (O/'collection-failure.json').exists()
assert sha(O/'after-results.json')==report['after_results_sha256'];after=load(O/'after-results.json')
assert after['source']==plan['source'] and after['update_sha256']==plan['update_sha256'] and after['system_sha256']==plan['system_sha256']
assert after['all_command_waits_observed'] and after['remaining_children']==[] and after['command_identities_absent']
assert after['original_step_exits']=={'system-listing':0,'es-systems':0,'os-release':0}
for name in after['original_step_exits']:
 step=load(O/'artifacts'/(name+'.result.json'))
 assert step['wait_observed'] and type(step['original_returncode'])is int and step['original_returncode']==0 and step['qualification'] and not step['timeout'] and not step['signals'] and step['error']is None
 assert (O/'artifacts'/(name+'.stderr')).stat().st_size==0,'unexpected unsquashfs diagnostic requires review'
for obj in [report,after]:
 for key in ['target_execution','device_contact','publication_clearance']:assert obj[key]is False
system=O/'SYSTEM';s=system.lstat();assert stat.S_ISREG(s.st_mode) and not system.is_symlink()
actual=dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,mode=stat.S_IMODE(s.st_mode));assert actual==after['system_identity']
extraction=load(O/'artifacts/extraction.json');assert extraction['completed'] and extraction['original_returncode']is None and extraction['system_identity']==actual and extraction['sha256']==plan['system_sha256']
observed=runpy.run_path(str(O/'analyse.py'))['analyse'](O,plan);assert observed==load(O/'artifacts/applicability.json') and observed['status']=='PASS_EXACT_PACKAGE_AND_MENU_ABSENCE'
assert sha(O/'artifacts/applicability.json')==after['applicability_sha256']
assert cleanup['all_recorded_identities_absent']is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped']is False
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']();keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']};supervisor=cleanup['supervisor_identity'];assert supervisor is not None;keys.add((supervisor['pid'],supervisor['start_ticks']))
launcher=load(O/'launcher-start.json');keys.add((launcher['pid'],int(launcher['start_ticks'])))
for name in after['original_step_exits']:
 row=load(O/'artifacts'/(name+'.process.json'));keys.add((row['pid'],row['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in keys];assert not matching,'recorded process identity remains'
verification=dict(result='PASS_SMALL_INDEPENDENT_READBACK',run=str(run),after_results_sha256=sha(O/'after-results.json'),applicability_sha256=sha(O/'artifacts/applicability.json'),files=observed['files'],system_identity=actual,system_body_reread=False,system_retained=True,recorded_process_identities_absent=True)
with (O/'independent-readback.json').open('x') as f:json.dump(verification,f,indent=2);f.write('\n')
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O) and admission['run']==str(run)
files=[p for p in O.rglob('*') if p.is_file() and p!=system]+[run/'runner-result.json',run/'build.rc'];assert len(files)<=128 and sum(p.stat().st_size for p in files)<=64*1024**2
out=O/'admission-completion-evidence.json';evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Current H700 exact SYSTEM package/menu applicability and independent small-output readback only. No target execution or device action. Extracted SYSTEM remains held pending root acceptance; original prior results unchanged.')
with out.open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True,timeout=120)
print('PASS consumed exact H700 applicability; SYSTEM remains held until explicit root acceptance')

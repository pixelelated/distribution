"""Pure bounded listing/XML readback; no firmware reads or work at import."""
from pathlib import Path,PurePosixPath
import hashlib,re,xml.etree.ElementTree as ET
ABSENT=['usr/bin/dolphin-emu','usr/bin/dolphin-emu-nogui','usr/bin/start_dolphin_gc.sh','usr/bin/start_dolphin_wii.sh','usr/lib/libretro/dolphin_libretro.so','usr/config/dolphin-emu','usr/share/dolphin-emu','usr/config/modules/Start Dolphin.sh','usr/bin/steam','usr/bin/start_steam.sh','usr/bin/start_steam_arm64.sh','usr/bin/start_steam_x86.sh','usr/lib/steam','usr/share/steam','usr/config/modules/Install Steam.sh','usr/config/modules/Uninstall Steam.sh']
SYSTEMS={'gamecube','gc','wii','wiiware','triforce','steam'}
def content(path,limit):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size<=limit
 data=p.read_bytes();assert len(data)<=limit
 return data
def analyse(owner,plan):
 owner=Path(owner);listing=content(owner/'artifacts/system-listing.stdout',32*1024**2)
 xml=content(owner/'artifacts/es-systems.stdout',2*1024**2);release=content(owner/'artifacts/os-release.stdout',2*1024**2)
 entries={};pattern=re.compile(r'^([dlcbps-][rwxStTs-]{9})\s+([0-9]+)/([0-9]+)\s+([0-9]+(?:,\s*[0-9]+)?)\s+([0-9]{4}-[0-9]{2}-[0-9]{2})\s+([0-9]{2}:[0-9]{2})\s+(squashfs-root(?:/.*)?)$')
 for line in listing.decode('utf-8','strict').splitlines():
  if not line.strip():continue
  m=pattern.fullmatch(line);assert m,'unrecognized complete-listing line: '+line[:200]
  mode=m.group(1);raw=m.group(7);link=None
  if mode[0]=='l':
   assert ' -> ' in raw,'symlink target missing';raw,link=raw.split(' -> ',1)
  else:assert ' -> ' not in raw,'ambiguous listing name'
  assert raw=='squashfs-root' or raw.startswith('squashfs-root/')
  name=raw.removeprefix('squashfs-root').lstrip('/')
  assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
  assert name not in entries and len(entries)<200000,'duplicate or oversized listing'
  entries[name]=dict(mode=mode,symlink_target=link)
 assert entries['']['mode'][0]=='d'
 for name in ['usr/bin/emulationstation','usr/bin/retroarch','usr/config/emulationstation/es_systems.cfg','etc/os-release']:
  assert name in entries,'positive listing anchor missing: '+name
 assert entries['usr/config/emulationstation/es_systems.cfg']['mode'][0]=='-','XML must be regular'
 assert b'<!DOCTYPE' not in xml.upper() and b'<!ENTITY' not in xml.upper()
 root=ET.fromstring(xml);assert root.tag=='systemList','unexpected XML root'
 records=[];seen=set()
 for node in root:
  assert node.tag=='system','unexpected top-level XML element'
  name=(node.findtext('name') or '').strip();assert name and name not in seen;seen.add(name)
  emulators=[]
  for element in node.iter():
   if element.tag in ['emulator','core','command']:
    emulators.append(dict(tag=element.tag,attributes=dict(element.attrib),text=(element.text or '').strip()))
  records.append(dict(name=name,associations=emulators));assert len(records)<=4096
 assert {'nes','psx','dreamcast'}<=seen,'positive system anchors missing'
 forbidden_systems=sorted(name for name in seen if name.lower() in SYSTEMS)
 forbidden_associations=[]
 for row in records:
  for a in row['associations']:
   value=' '.join([a['text'],*a['attributes'].values()])
   if re.search(r'(?i)(?:^|[^a-z0-9])(dolphin|steam)(?:$|[^a-z0-9])',value):forbidden_associations.append(dict(system=row['name'],association=a))
 checks=[dict(path=p,present=sorted(n for n in entries if n==p or n.startswith(p+'/'))) for p in ABSENT]
 other=sorted(n for n in entries if re.search(r'(?i)dolphin|steam|gamecube',n))
 values={}
 for line in release.decode('utf-8','strict').splitlines():
  if not line or line.startswith('#'):continue
  key,value=line.split('=',1);assert key not in values;values[key]=value.strip('"')
 expected=dict(BUILD_ID=plan['source'],BUILD_TIMESTAMP=plan['timestamp'],HW_DEVICE='H700',HW_ARCH='aarch64',OS_BUILD='dev',BUILD_DIRTY='no')
 assert all(values.get(k)==v for k,v in expected.items()),'unexpected actual SYSTEM identity'
 files={n:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for n,data in [('system-listing.stdout',listing),('es-systems.stdout',xml),('os-release.stdout',release)]}
 return dict(status='PASS_EXACT_PACKAGE_AND_MENU_ABSENCE' if not forbidden_systems and not forbidden_associations and all(not c['present'] for c in checks) else 'UNEXPECTED_PACKAGE_OR_MENU_PRESENT',listing_entries=len(entries),files=files,selected_path_checks=checks,system_names=sorted(seen),system_records=records,forbidden_systems=forbidden_systems,forbidden_associations=forbidden_associations,other_name_matches=other,identity={k:values[k] for k in expected},scope='Exact shipped launchable package paths and ES mappings only; generic metadata, format hashing and retained storage are outside this absence claim.',target_execution=False,device_contact=False)

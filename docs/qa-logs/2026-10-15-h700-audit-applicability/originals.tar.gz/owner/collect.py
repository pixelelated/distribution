"""One bound SYSTEM extraction and three read-only SquashFS commands."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,runpy,selectors,signal,stat,subprocess,time,tarfile
O=Path(__file__).resolve().parent
B=runpy.run_path(str(O/'bindings.py'));I=runpy.run_path(str(O/'process-identity.py'))
plan=B['verify'](O);limits=B['load'](O/'resources.json');started=time.monotonic();deadline=started+limits['soft_seconds']
steps=[];records=[]
def checktime():assert time.monotonic()<deadline,'reader soft deadline exceeded'
def write(path,value):
 raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<=2*1024**2
 with path.open('xb') as f:f.write(raw)
def identity(path):
 s=path.lstat();assert stat.S_ISREG(s.st_mode) and path.resolve(strict=True)==path,'regular exact file required'
 return dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,mode=stat.S_IMODE(s.st_mode))
def step(name,argv,cap):
 checktime();row=dict(name=name,argv=argv,original_returncode=None,wait_observed=False,timeout=False,signals=[],error=None)
 proc=None;selector=None;streams=[];error=None
 try:
  proc=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  row['identity']=I['identity'](proc.pid);assert row['identity'] is not None
  records.append(row['identity']);write(O/'artifacts'/(name+'.process.json'),row['identity'])
  selector=selectors.DefaultSelector()
  for label,pipe,bound in [('stdout',proc.stdout,cap),('stderr',proc.stderr,limits['stderr_ceiling_bytes'])]:
   stream=(O/'artifacts'/(name+'.'+label)).open('xb');streams.append(stream);selector.register(pipe,selectors.EVENT_READ,[stream,0,bound])
  until=min(deadline,time.monotonic()+60)
  while selector.get_map():
   if time.monotonic()>=until:row['timeout']=True;raise TimeoutError(name+' deadline')
   for event,_ in selector.select(.1):
    data=os.read(event.fileobj.fileno(),65536)
    if not data:selector.unregister(event.fileobj);continue
    state=event.data;assert state[1]+len(data)<=state[2],name+' output ceiling'
    state[0].write(data);state[1]+=len(data)
  proc.wait(timeout=max(.01,until-time.monotonic()))
 except BaseException as e:error=e;row['error']=type(e).__name__+': '+str(e)[:2048]
 finally:
  if selector is not None:selector.close()
  if proc is not None:
   for signum in [signal.SIGTERM,signal.SIGKILL]:
    if proc.poll() is not None:break
    current=I['identity'](proc.pid);assert current is not None and current['start_ticks']==row['identity']['start_ticks']
    row['signals'].append(I['signal_child'](current,os.getpid(),signum))
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
   row['original_returncode']=proc.poll();row['wait_observed']=type(row['original_returncode'])is int
   proc.stdout.close();proc.stderr.close()
  for stream in streams:stream.close()
  row['qualification']=row['wait_observed'] and row['original_returncode']==0 and not row['timeout'] and not row['signals'] and error is None
  write(O/'artifacts'/(name+'.result.json'),row);steps.append(row)
 if error is not None:raise error
 assert row['qualification'],'read-only command failed: '+name
 return row

try:
 archive=Path(plan['update']);before=identity(archive);assert before['bytes']==plan['update_bytes']
 digest=hashlib.sha256();read_bytes=0
 fd=os.open(archive,os.O_RDONLY|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as source:
  assert (os.fstat(source.fileno()).st_dev,os.fstat(source.fileno()).st_ino)==(before['device'],before['inode'])
  while block:=source.read(4*1024**2):checktime();read_bytes+=len(block);digest.update(block)
 assert read_bytes==plan['update_bytes'] and digest.hexdigest()==plan['update_sha256']
 assert identity(archive)==before
 write(O/'artifacts/archive-hash.json',dict(path=str(archive),identity=before,sha256=digest.hexdigest(),bytes_read=read_bytes,result='PASS'))
 extraction=dict(original_returncode=None,completed=False,member=None,bytes=0,sha256=None)
 try:
  with tarfile.open(archive,'r:') as tf:
   members=[]
   for member in tf:
    checktime();assert len(members)<4096 and len(os.fsencode(member.name))<=4096
    name=PurePosixPath(member.name);assert not name.is_absolute() and '..' not in name.parts
    members.append(member)
   selected=[m for m in members if m.name.endswith('/target/SYSTEM')]
   assert len(selected)==1 and selected[0].isfile() and not selected[0].issparse()
   member=selected[0];assert 0<member.size<=limits['system_ceiling_bytes'];extraction['member']=member.name
   system=O/'SYSTEM';digest=hashlib.sha256();source=tf.extractfile(member);assert source is not None
   with source,system.open('xb') as output:
    while block:=source.read(4*1024**2):
     checktime();extraction['bytes']+=len(block);assert extraction['bytes']<=member.size
     output.write(block);digest.update(block)
    output.flush();os.fsync(output.fileno())
   extraction['sha256']=digest.hexdigest();assert extraction['bytes']==member.size and extraction['sha256']==plan['system_sha256']
  assert identity(archive)==before
  extraction.update(completed=True,system_identity=identity(system),tar_members=len(members))
 finally:write(O/'artifacts/extraction.json',extraction)
 # Extraction is in-process; no subprocess exit is invented for it.
 tool=plan['unsquashfs']['path'];assert B['sha'](tool)==plan['unsquashfs']['sha256']
 step('system-listing',[tool,'-processors','1','-lln',str(system)],limits['listing_ceiling_bytes'])
 step('es-systems',[tool,'-processors','1','-cat',str(system),'usr/config/emulationstation/es_systems.cfg'],limits['text_ceiling_bytes'])
 step('os-release',[tool,'-processors','1','-cat',str(system),'etc/os-release'],limits['text_ceiling_bytes'])
 checktime();analysis=runpy.run_path(str(O/'analyse.py'))['analyse'](O,plan)
 write(O/'artifacts/applicability.json',analysis)
 assert analysis['status']=='PASS_EXACT_PACKAGE_AND_MENU_ABSENCE','unexpected shipped package/menu; retain observed facts'
 assert identity(system)==extraction['system_identity'] and identity(archive)==before
 remaining=I['tree'](os.getpid());assert remaining==[],'collector descendants remain'
 assert all(not I['same'](r) for r in records),'recorded command identity remains'
 after=dict(result='PASS_H700_PACKAGE_APPLICABILITY',source=plan['source'],update_sha256=plan['update_sha256'],system_sha256=plan['system_sha256'],system_identity=extraction['system_identity'],system_retained=True,archive_identity_after=identity(archive),original_step_exits={r['name']:r['original_returncode'] for r in steps},all_command_waits_observed=all(r['wait_observed'] for r in steps),remaining_children=remaining,command_identities_absent=True,applicability_sha256=B['sha'](O/'artifacts/applicability.json'),elapsed_seconds=time.monotonic()-started,target_execution=False,device_contact=False,publication_clearance=False)
 write(O/'after-results.json',after)
 write(O/'collection-result.json',dict(result='PASS_H700_PACKAGE_APPLICABILITY',original_collector_exit=0,after_results_sha256=B['sha'](O/'after-results.json'),elapsed_seconds=time.monotonic()-started,system_retained=True,target_execution=False,device_contact=False,publication_clearance=False))
except BaseException as error:
 write(O/'collection-failure.json',dict(result='INCOMPLETE',error=type(error).__name__+': '+str(error)[:4096],elapsed_seconds=time.monotonic()-started,steps=steps,system_retained=(O/'SYSTEM').exists(),success=False))
 raise

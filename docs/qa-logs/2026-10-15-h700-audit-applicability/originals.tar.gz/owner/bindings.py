"""Frozen H700 reader inputs; no work at import."""
from pathlib import Path
import hashlib,json,os,subprocess
COMMIT='077197e6cd3ea31f33b28aaf3882a694b3423b53'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT
def prerequisites(plan):
 assert plan['source']==COMMIT and plan['publication_clearance'] is False and plan['device_authority'] is False
 run=Path(plan['previous_run']);c=load(run/'admission-consumed.json');r=load(run/'runner-result.json')
 assert c['state']=='consumed' and c['id']==plan['previous_admission'] and c['run']==str(run) and c['submission_owner']==plan['previous_owner'] and c['source']['head']==COMMIT and c['original_result']==r
 assert all(type(r[k])is int and r[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
 old=Path(plan['previous_owner']);a=load(old/'artifacts/acceptance.json')
 assert sha(old/'artifacts/acceptance.json')==plan['previous_acceptance_sha256'] and a['result']=='PASS' and a['distribution_commit']==COMMIT
 assert a['reader_run']==str(run) and a['bundle_manifest_sha256']==plan['bundle_manifest_sha256']
 assert len(a['variants'])==2 and all(v['system_sha256']==plan['system_sha256'] for v in a['variants'])
 assert load(old/'launcher-result.json')['runner_returncode']==0 and (old/'tool-wrapper.rc').read_text().strip()=='0'
 archive=Path(plan['update']);manifest=load(archive.parent/'manifest.json')
 assert sha(archive.parent/'manifest.json')==plan['bundle_manifest_sha256']
 assert manifest['inputs']['distribution_commit']==COMMIT and manifest['inputs']['build_timestamp']==plan['timestamp']
 assert manifest['files'][archive.name]==dict(bytes=plan['update_bytes'],sha256=plan['update_sha256'])
 assert archive.resolve(strict=True)==archive and not archive.is_symlink() and archive.is_file() and archive.stat().st_size==plan['update_bytes']
 # Metadata only: payload hash is performed exactly once by the reader.
 return a
def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 assert subprocess.check_output(['git','-C',str(VM_TREE),'rev-parse','HEAD'],text=True).strip()==COMMIT
 assert subprocess.check_output(['git','-C',str(VM_TREE),'branch','--show-current'],text=True).strip()=='build/m7-pixelelated-h700-05'
 assert not subprocess.check_output(['git','-C',str(VM_TREE),'status','--porcelain'],text=True).strip()
 plan=load(O/'reader-plan.json');assert len(plan['binding_refs'])<=32
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 tool=plan['unsquashfs'];assert tool['path']=='/usr/bin/unsquashfs' and sha(tool['path'])==tool['sha256']
 prerequisites(plan)
 return plan

# H700 applicability reader — independent source review

No concrete source blocker found in released packet
`/tmp/pix-m7-h700-applicability-reader-plan-20261015-01`, seal
`3ad7089240be1be29479e4a74a9e6fd95b426092310b1d8e5787258696bb6eac`.
All17 source members/107,503bytes match the seal and exact membership. Nine
named small accepted-metadata bindings match their full hashes and join to
source077197, timestamp161744Z, consumed reader170844Z-0f52627d,
bundlea808df3d, updatee68f5c21 and SYSTEM233c1880. Firmware bytes were not read,
hashed or decoded. No packet module was imported or executed; no preparer,
preflight, fixture, runtime, service or device operation was run.

Reviewed preparer, bindings, collector, analyser, consumer, retirement, resource
commands and inherited-supervisor diff. `source-readback.json` records the exact
source/metadata hashes and independent comparisons.

- **Negative predicates:** `collect.py:82–89` requires successful complete host
  listing and XML/os-release reads; `analyse.py:13–29` refuses unknown listing
  syntax, duplicate entries, excess entries, absent positive anchors and a
  nonregular XML path. XML must parse with the expected root and positive
  NES/PSX/Dreamcast systems. Lines40–56 check the16 named paths and descendants,
  six system names and actual Dolphin/Steam emulator/core/command associations.
  Missing/failed `-cat` output cannot prove absence. Other matching filenames
  remain observations; retained `/storage`, generic metadata and other aliases
  are outside the stated narrow claim.
- **Bounded work/output:** one exact update hash and one streamed SYSTEM copy;
  at most4096 tar members and1.5GiB SYSTEM. Three host decoder subprocesses have
 60second step limits,32MiB listing/2MiB text/256KiB stderr caps checked before
  writes. Fixed-path metadata writes are individually capped; their finite count
  plus SYSTEM/log ceilings stays below2GiB owner and3GiB reservation. Supervisor
  reserves8MiB before receipt writes and caps child streams at256KiB each.1CPU,
  1GiB address-space,270s soft/285s collector/315s outer deadlines and15s final
  fallback are explicit. A cap, timeout, signal or missing wait cannot qualify.
- **Lifecycle:** all10 inherited supervisor function ASTs are identical and
  process-identity.py bytes are identical to the accepted notice-delivery
  source. Collector step receipts retain argv/identity/original wait and signal
  history; supervisor preserves its original collector wait independently.
  Consumer requires all original zero channels, no forced cleanup, no recorded
  identity or descendants remaining, and recomputes small-output analysis. It
  does not rehash SYSTEM or infer an in-process extraction exit.
- **Retention:** successful consumption keeps SYSTEM. `retire-system.py:8–19`
  requires the exact consumed run/evidence hash, independent success, explicit
  root acceptance bound to after-results and SYSTEM digest, and exact regular
  file stat identity before unlinking only this owner's SYSTEM. Small originals
  remain held. Root's acceptance is a review step, not inferred device authority.

Actual listing compatibility, generated XML, absence results and resource use
remain unknown until root executes and inspects originals. An unexpected match
or decoder-format refusal must retain a failed original, not be relabelled as
absence. This source review establishes no full-image, physical-device,
publication or #603 completion claim. No additional controls or runtime replay
are requested by this review.

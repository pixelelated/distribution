#!/bin/bash
# SOURCE ONLY / UNRUN. Root reviews, runs serialized, and supervises originals.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-h700-applicability-reader-plan-20261015-01
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-h700-applicability-20261015-01}
cd "$TASK_TREE"
case "${1:?prepare, preflight, report, admit, launch, consume, or retire-system}" in
 prepare) tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-owner.py" --owner "$TASK_OWNER" ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json" ;;
 admit) python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json" ;;
 launch) env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh" ;;
 consume) taskset -c 0 prlimit --as=1073741824 --fsize=67108864 -- timeout --signal=TERM --kill-after=15s 180s python3 -I -S -B "$TASK_OWNER/consume.py" ;;
 retire-system) taskset -c 0 prlimit --as=1073741824 --fsize=67108864 -- timeout --signal=TERM --kill-after=15s 60s python3 -I -S -B "$TASK_OWNER/retire-system.py" --acceptance "${2:?exact root acceptance JSON}" ;;
 *) exit 2 ;;
esac
# Root actively checks original completion at most60seconds apart. Submission
# is not completion. No off-session notification is armed. A failure requires
# ordinary failed-investigated closeout; the success consumer refuses it.

#!/usr/bin/env python3
"""Prepare one new immutable H700 reader owner; no payload read or launch."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 q=argparse.ArgumentParser(description=__doc__);q.add_argument('--owner',type=Path,required=True);a=q.parse_args()
 names=[]
 for line in (P/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);p=P/n;assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h;names.append(n)
 assert len(names)<=64 and sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
 B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']();assert Path.cwd()==B['VM_TREE']
 O=a.owner;assert O.parent==Path('/workspace/tmp') and O.parent.resolve(strict=True)==O.parent and re.fullmatch('pix-m7-h700-applicability-20261015-[0-9]{2}',O.name)
 assert not O.exists() and not O.is_symlink()
 plan=json.loads((P/'reader-plan.json').read_text())
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h
 B['prerequisites'](plan)
 O.mkdir(mode=0o700)
 for name in ['stage','artifacts','empty-retention-scan']:(O/name).mkdir(mode=0o700)
 written=0;count=0
 def raw(n,data):
  nonlocal written,count
  assert len(data)<=4*1024**2 and written+len(data)<=8*1024**2 and count<64 and not (O/n).exists();written+=len(data);count+=1
  with (O/n).open('xb') as f:f.write(data)
 def put(n,value):raw(n,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
 for p in sorted((P/'templates').iterdir()):raw(p.name,p.read_bytes())
 for n in ['resources.json','frozen-tools.json','reader-plan.json']:raw(n,(P/n).read_bytes())
 put('preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),pid_namespace=os.readlink('/proc/self/ns/pid'),user_namespace=os.readlink('/proc/self/ns/user'),uid_map=Path('/proc/self/uid_map').read_text(),gid_map=Path('/proc/self/gid_map').read_text(),reader_executed=False,device_authority=False,publication_clearance=False))
 put('retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=[str(B['VM_TREE']),plan['previous_owner'],str(Path(plan['update']).parent)],candidates=[],builds=[dict(name='m7-h700-package-applicability',terms_bytes={'one_system_and_bounded_reader_scratch':3*1024**3},basis='One exact SYSTEM capped1.5GiB plus bounded metadata under2GiB owner;3GiB reservation. No firmware bundle/cache copy or deletion credit. Extracted SYSTEM held until explicit root acceptance.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])]))
 put('admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-h700-package-applicability',profiles=[dict(PROJECT='ROCKNIX',DEVICE='H700',ARCH='aarch64')],outputs=[dict(path=str(O),kind='qa-scratch',issue=344,release_when='Original reader consumed and independently reviewed; only exact extracted SYSTEM may be released after explicit root acceptance. Small originals and failures remain held.')]))
 put('seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()});B['verify'](O)
 print(json.dumps(dict(owner=str(O),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),payload_read=False,publication_clearance=False)))
if __name__=='__main__':main()

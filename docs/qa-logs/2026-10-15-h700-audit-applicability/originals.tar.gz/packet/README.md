# H700 package applicability reader: SOURCE ONLY / UNRUN

This minimal derivative uses the accepted notice-delivery process supervisor,
pidfd/subreaper custody, preparer/admission route and success-consumption pattern.
Only the collector, exact H700 bindings and output analysis change. It checks the
current `077197` H700 firmware without a build, VM, device contact, target execution,
candidate-store copy or whole-image acceptance replay. Root owns #603/#344 ordering
and runs this serially before #606 VM. Applicable audit fixes that change these
product bytes require a newly bound derivative, not a relabelled current result.

Input: the accepted candidate bundle
`/workspace/artifacts/pixelelated-candidates/sha256/a808df3dbffc6281b0bf698fbbbd97a526f16211d1195bcf13ebd5fccb7e3e5f`,
update `pixelelated-H700.aarch64-0.0.1-dev+20261015T161744Z.g077197e6cd3e-from-ROCKNIX.tar`,
1,321,697,280 bytes, SHA256
`e68f5c21b38b298e307fa1f00f87762a9aaeb2348aa91a9d43d940ce11da35dd`.
Extract exactly one regular `/target/SYSTEM` member and verify SHA256
`233c1880d371e5fa7b59b47072906e2ed2e125020e6aab1368fd117b2dc99ef6`.
Original consumed reader `20261015T170844Z-0f52627d` remains accepted separately;
the selected-positive installed receipt did not prove these missing absences.

The reader hashes the update once, extracts/hashes SYSTEM while streaming, and
runs the pinned host `unsquashfs` for a complete numeric listing plus the actual
generated `usr/config/emulationstation/es_systems.cfg` and `etc/os-release`.
Each subprocess retains its argv, PID/start, original wait status and bounded
stdout/stderr. In-process extraction explicitly has no invented subprocess exit.
Unknown listing formats, truncation/caps, missing anchors, malformed XML,
unexpected payload/menu matches and failed reads refuse success. No negative
`unsquashfs -cat` return is used as absence evidence.

Absence is limited to the 16 exact package paths and descendants in `analyse.py`,
and the named Steam/Dolphin/GameCube/Wii/Triforce menu/emulator associations.
Other matching filenames remain observations. Generic core-info, art, help,
GameCube format hashing, retained `/storage` overrides and user-installed software
are not declared absent or inapplicable. No physical handoff is authorized here.

Bounds: 3 GiB reservation; one1.5GiB maximum SYSTEM plus metadata under a2GiB
owner ceiling; 1CPU and1GiB address space. Collector soft deadline270seconds,
parent child deadline285seconds, up to300seconds work envelope,15seconds cleanup,
outer315seconds with15second emergency kill fallback. The inherited normal
cleanup is bounded13seconds. A fallback/forced signal cannot pass. Full listing
is capped32MiB, XML/os-release2MiB each, stderr256KiB each; logs256KiB/stream;
small analysis/receipt files2MiB each. No output/body scan beyond this exact owner.
The independent consumer reads small outputs only and stats retained SYSTEM;
it does not hash or decode the firmware again.

Run each command only after reviewing the preceding original result:

```bash
bash /tmp/pix-m7-h700-applicability-reader-plan-20261015-01/commands.sh prepare
bash /tmp/pix-m7-h700-applicability-reader-plan-20261015-01/commands.sh preflight
bash /tmp/pix-m7-h700-applicability-reader-plan-20261015-01/commands.sh report
bash /tmp/pix-m7-h700-applicability-reader-plan-20261015-01/commands.sh admit
bash /tmp/pix-m7-h700-applicability-reader-plan-20261015-01/commands.sh launch
# Supervise actual completion; inspect original exits and cleanup, then:
bash /tmp/pix-m7-h700-applicability-reader-plan-20261015-01/commands.sh consume
```

Default owner `/workspace/tmp/pix-m7-h700-applicability-20261015-01` is absent
until root runs the preparer. An alternate fresh two-digit suffix is supported.
No preparer, import, firmware hash, decoder, runtime or admission was executed
while assembling this source packet. Existing host namespace/UID serialization
guards stay exact; frozen build source is `077197` on H70005, and an active
unconsumed audit/VM owner will correctly refuse this reader's preparation.

`after-results.json` is the small final artifact fact record. `result.json`,
`cleanup.json`, original child results and the independent consumption readback
remain separate. Failed attempts retain every available original, including
unknown/missing waits; use ordinary failed-investigated closeout. Do not replay
the owner or overwrite an original. Success consumption also leaves SYSTEM held.

After root reviews and accepts the result, create an explicit small acceptance
record using actual values, never the placeholders below:

```json
{"decision":"ACCEPT_H700_PACKAGE_APPLICABILITY","release_system":true,"run":"<actual original run path>","after_results_sha256":"<actual hash>","system_sha256":"233c1880d371e5fa7b59b47072906e2ed2e125020e6aab1368fd117b2dc99ef6"}
```

Then `bash commands.sh retire-system /absolute/path/to/root-acceptance.json`
checks the consumed receipt and exact original SYSTEM stat identity before
unlinking only that file. It retains all small evidence and writes an explicit
retirement receipt. Root acceptance is the coordinator's result review, not a
new request for user permission. No automatic deletion or cloud/source-publication
gate is added; D-WORKFLOW-168's private handoff boundary remains unchanged.

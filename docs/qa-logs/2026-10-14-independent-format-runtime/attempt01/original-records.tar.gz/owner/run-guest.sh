#!/bin/sh
set -eu
mkdir /run/pix574-scratch
mount -t tmpfs -o size=2G,mode=700,nosuid,nodev tmpfs /run/pix574-scratch
set +e
timeout --signal=TERM --kill-after=5s 240s python3 -I -S -B /tmp/pix-input/pix574-format/packet/guest-run.py --run-id format01 > /tmp/pix-output/driver.stdout 2> /tmp/pix-output/driver.stderr
pxrc=$?
printf '%s\n' "$pxrc" > /tmp/pix-output/driver.rc
set -e
sync
umount /run/pix574-scratch
printf 'PIX574_FORMAT_RC:%s\n' "$pxrc"
test "$pxrc" -eq 0

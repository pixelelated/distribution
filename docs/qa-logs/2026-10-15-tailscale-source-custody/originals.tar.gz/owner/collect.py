#!/usr/bin/env python3
"""Offline immutable-copy custody; execution requires root's separate admission."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,sys,time
from urllib.parse import urlsplit
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path'])
START=time.monotonic();READ=0;WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1
def tick(n=0):
 global READ
 assert n>=0;READ+=n
 assert READ<=R['total_read_bytes'] and time.monotonic()-START<R['soft_seconds'],'read/time ceiling'
def safe(name):
 assert isinstance(name,str) and name and len(os.fsencode(name))<=R['path_bytes'] and '\0' not in name and '\\' not in name
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p)==name and '.git' not in p.parts,name
 return name

def ident(p,regular=True):
 p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.resolve(strict=True)==p,p
 s=p.stat();assert not regular or stat.S_ISREG(s.st_mode),p
 return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def digest(p,cap=268435456):
 before=ident(p);assert before['bytes']<=cap
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));h.update(b)
 assert ident(p)==before,'input changed while hashing'
 return dict(before,sha256=h.hexdigest())
def root_for(p):
 for root in [O,D]:
  if p.is_relative_to(root):return root
 raise AssertionError('write outside owned roots')
def mkdir(p):
 root=root_for(p);assert len(DIRS)<R['output_directories'];assert not p.exists() and not p.is_symlink()
 assert p.parent.resolve(strict=True)==p.parent and not p.parent.is_symlink();p.mkdir(mode=0o700);DIRS.add(str(p))
def reserve(p,n,failure=False):
 tick();root=root_for(p);cap=R['custody_output_ceiling_bytes'] if root==D else R['owner_output_ceiling_bytes']-R['supervisor_reserve_bytes']
 if failure:assert root==O and n<=R['failure_receipt_budget_bytes'];cap+=R['failure_receipt_budget_bytes']
 assert n>=0 and OUTPUT[str(root)]+n<=cap,'aggregate before-write ceiling'
 assert WRITES[str(p)]+n<=R['per_file_bytes'],'individual before-write ceiling'
 OUTPUT[str(root)]+=n;WRITES[str(p)]+=n
class Writer:
 def __init__(self,p,failure=False):
  self.p=Path(p);root_for(self.p);safe(str(self.p.relative_to(root_for(self.p))))
  assert len(WRITES)<R['output_files'] and str(self.p) not in WRITES
  assert self.p.parent.resolve(strict=True)==self.p.parent and not self.p.exists() and not self.p.is_symlink()
  WRITES[str(self.p)]=0;self.failure=failure;self.f=self.p.open('xb')
 def write(self,b):reserve(self.p,len(b),self.failure);return self.f.write(b)
 def flush(self):self.f.flush()
 def tell(self):return self.f.tell()
 def close(self):self.f.close()
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
def put(p,obj,failure=False):
 raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
 if failure:assert len(raw)<=R['failure_receipt_budget_bytes']
 with Writer(p,failure) as f:f.write(raw)
def rawput(p,b):
 with Writer(p) as f:f.write(b)
def load(p):
 before=ident(p);assert before['bytes']<16*1024**2
 raw=Path(p).read_bytes();tick(len(raw));assert ident(p)==before;return json.loads(raw)

def copy_file(spec,member):
 safe(member);p=Path(spec['path']);before=digest(p,R['per_file_bytes'])
 assert before['bytes']==spec['bytes'] and before['sha256']==spec['sha256']
 if 'held_identity' in spec:assert before==spec['held_identity']
 target=D/member
 with p.open('rb') as f,Writer(target) as out:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));out.write(b)
 after=digest(target,R['per_file_bytes']);assert after['sha256']==before['sha256'] and after['bytes']==before['bytes']
 assert (after['device'],after['inode'])!=(before['device'],before['inode']) and digest(p,R['per_file_bytes'])==before
 return dict(member=member,bytes=after['bytes'],sha256=after['sha256'],source_identity=before,independent_copy=True)

def selected_maps(acquisition):
 rows=acquisition['rows'];assert len(rows)==89
 bykey={r['selection']['key']:r for r in rows};assert len(bykey)==89
 inventory=load(PLAN['module_inventory']);groups={k:v for k,v in inventory['groups'].items() if any(s['binary'] in ['tailscale','tailscaled'] for s in v['selections'])};assert len(groups)==2
 binary_rows=[r for r in inventory['profiles'] if r['binary'] in ['tailscale','tailscaled']]
 assert {(r['profile'],r['binary']) for r in binary_rows}=={(p,b) for p in PLAN['component_profiles'] for b in ['tailscale','tailscaled']} and len(binary_rows)==6
 union=set()
 for r in binary_rows:
  assert r['archive_to_unpacked_equal']is True and r['package_to_staged_image_equal']is True and r['inventory_id'] in groups
 for g in groups.values():
  assert all(s['profile'] in PLAN['component_profiles'] and s['binary'] in ['tailscale','tailscaled'] for s in g['selections'])
  deps=[tuple(r[1:]) for r in g['module_records'] if r[0]=='dep'];assert all(len(r)==3 for r in deps) and len(set(deps))==len(deps);union.update(deps)
 expected={(r['module'],r['version'],r['expected_go_h1']) for r in PLAN['modules']};assert len(expected)==89 and union==expected
 base=load(Path(PLAN['additive_custody'])/'component-member-index.json');components=[r for r in base if r['component']=='tailscale']
 assert len(components)==3 and {r['profile'] for r in components}==set(PLAN['component_profiles'])
 # Explicit projection prevents raw HTTP/download metadata or signed URLs entering custody.
 selection=dict(component='tailscale',module_inventory_sha256=PLAN['binding_refs'][PLAN['module_inventory']],groups=groups,binaries=[{k:r[k] for k in ['profile','binary','inventory_id','settings','original_stdout']} for r in binary_rows],claim='Original accepted binary-module reader metadata; not re-executed here')
 put(D/'metadata/module-selection.json',selection)
 mapped=[];notices=[];zip_bytes=index_bytes=0
 for spec in PLAN['modules']:
  actual=bykey[spec['key']];s=actual['selection'];assert all(spec[k]==s[k] for k in ['key','module','version','expected_go_h1','canonical_proxy_zip_url'])
  assert actual['source_h1_verified']is True and actual['source_status']=='EXACT_EMBEDDED_H1_VERIFIED' and actual['actual_go_h1']==spec['actual_go_h1']==spec['expected_go_h1']
  assert actual['archive']==spec['archive']['held_identity'] and actual['member_index']=={k:spec['member_index'][k] for k in ['path','sha256']} and actual['notice_candidates']==spec['notice_candidates']
  assert actual['member_count']==spec['member_count'] and actual['decoded_bytes']==spec['decoded_bytes'] and actual['original_request_key']==spec['original_request_key']
  request=[r for r in acquisition['downloads'] if r['key']==spec['original_request_key']];assert len(request)==1 and request[0]['http_status']==200 and request[0]['body']==actual['archive']
  u=urlsplit(spec['canonical_proxy_zip_url']);assert u.scheme=='https' and u.netloc=='proxy.golang.org' and not u.query and not u.fragment and not u.username and not u.password
  key=safe(spec['key']);assert '/' not in key
  assert Path(spec['archive']['path']).parent==Path(PLAN['acquisition_owner'])/'archives'
  assert Path(spec['member_index']['path']).parent==Path(PLAN['acquisition_owner'])/'collection'
  archive=copy_file(spec['archive'],'archives/'+key+'.zip');index=copy_file(spec['member_index'],'metadata/'+key+'.index.json');zip_bytes+=archive['bytes'];index_bytes+=index['bytes']
  entries=load(D/index['member']);assert len(entries)==spec['member_count'] and len({r['name'] for r in entries})==len(entries)
  lookup={r['name']:r for r in entries};current=[]
  for n in spec['notice_candidates']:
   assert n['module']==spec['module'] and n['version']==spec['version'] and n['name'] in lookup and not n['directory']
   assert all(lookup[n['name']][k]==n[k] for k in ['sha256','bytes','relative_path','directory'])
   p=Path(n['retained_path']);assert p.parent==Path(PLAN['acquisition_owner'])/'collection/texts' and p.suffix=='.txt'
   out=copy_file(dict(path=str(p),bytes=n['bytes'],sha256=n['sha256']),'notices/'+p.name)
   notice=dict(module=spec['module'],version=spec['version'],archive_member_path=n['name'],relative_path=n['relative_path'],**out);notices.append(notice);current.append(notice)
  selections=[dict(profile=r['profile'],binary=r['binary'],inventory_id=r['inventory_id']) for r in binary_rows if ('dep',spec['module'],spec['version'],spec['expected_go_h1']) in {tuple(x) for x in groups[r['inventory_id']]['module_records']}]
  assert selections
  mapped.append(dict(module=spec['module'],version=spec['version'],expected_go_h1=spec['expected_go_h1'],actual_go_h1=spec['actual_go_h1'],h1_proof='Accepted original acquisition; full copied ZIP SHA256 binds that result; no decoding replay',canonical_proxy_zip_url=spec['canonical_proxy_zip_url'],original_curl_returncode=request[0]['original_curl_returncode'],original_wait_observed=request[0]['wait_observed'],archive=archive,member_index=index,member_count=spec['member_count'],decoded_bytes=spec['decoded_bytes'],notices=current,selections=selections))
 assert len(mapped)==89 and len(notices)==130 and sum(n['bytes'] for n in notices)==528430 and zip_bytes==163585749 and index_bytes==4718158
 put(D/'module-member-index.json',mapped);put(D/'notice-index.json',notices)
 members_by_profile={p:[dict(module=m['module'],version=m['version'],go_h1=m['actual_go_h1'],source_member=m['archive']['member'],source_sha256=m['archive']['sha256'],member_index=m['member_index']['member'],notice_members=[n['member'] for n in m['notices']],selected_binaries=sorted({s['binary'] for s in m['selections'] if s['profile']==p})) for m in mapped if any(s['profile']==p for s in m['selections'])] for p in PLAN['component_profiles']}
 put(D/'component-member-index.json',[dict(original_component=c,original_index_path=PLAN['additive_custody']+'/component-member-index.json',original_index_sha256=PLAN['binding_refs'][PLAN['additive_custody']+'/component-member-index.json'],dependency_sources=members_by_profile[c['profile']],main_source='Previously retained source stays referenced in original evidence; this supplement does not recollect it') for c in components])
 return mapped,notices

try:
 assert D.parent==Path('/workspace/artifacts/pixelelated-release-sources') and D.name=='m7-tailscale-source-'+O.name.removeprefix('pix-m7-tailscale-custody-') and not D.exists() and not D.is_symlink()
 for p in O.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():OUTPUT[str(O)]+=p.stat().st_size
 assert OUTPUT[str(O)]<8*1024**2
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 mkdir(D)
 for n in ['archives','metadata','notices']:mkdir(D/n)
 acquisition=load(Path(PLAN['acquisition_owner'])/'collection-result.json');mapped,notices=selected_maps(acquisition)
 # Preserve only safe status/provenance fields, not raw curl streams or response URLs.
 statuses=[]
 for p in PLAN['prerequisites']:
  consumed=load(Path(p['run'])/'admission-consumed.json')
  statuses.append(dict(label=p['label'],run=p['run'],owner=p['owner'],admission_id=p['admission_id'],original_result=consumed['original_result'],consumed_state=consumed['state'],consumed_evidence_sha256=consumed['evidence_sha256'],consumed_receipt_sha256=PLAN['binding_refs'][p['run']+'/admission-consumed.json']))
 put(D/'metadata/original-status.json',statuses)
 manifest=dict(schema=1,scope=PLAN['scope'],binding_refs=PLAN['binding_refs'],prior_producers=statuses,module_count=89,notice_count=130,archive_bytes=163585749,notice_bytes=528430,component_rows=3,binary_rows=6,module_index_sha256=digest(D/'module-member-index.json')['sha256'],notice_index_sha256=digest(D/'notice-index.json')['sha256'],component_index_sha256=digest(D/'component-member-index.json')['sha256'],original_additive_custody=PLAN['additive_custody'],publication_bundle_complete=False,unresolved=PLAN['unresolved'])
 put(D/'manifest.json',manifest)
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 files=[dict(path=p,bytes=n,sha256=digest(p,R['per_file_bytes'])['sha256']) for p,n in WRITES.items() if Path(p).is_relative_to(D)]
 for item in files:Path(item['path']).chmod(0o444)
 for p in sorted([Path(p) for p in DIRS if Path(p).is_relative_to(D)],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
 put(O/'collection-result.json',dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,custody_path=str(D),manifest_sha256=digest(D/'manifest.json')['sha256'],files=files,archives=89,notice_count=130,component_rows=3,binary_rows=6,network_used=False,target_execution=False,source_execution=False,source_rebuild=False,go_execution=False,publication_clearance=False,publication_bundle_complete=False,outputs_held=True,deleted_bytes=0,accounted_output_bytes=OUTPUT,read_bytes=READ,elapsed_seconds=time.monotonic()-START,unresolved=PLAN['unresolved']))
 rc=0
except BaseException as exc:
 try:put(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(exc).__name__+': '+str(exc)[:4096],accounted_output_bytes=OUTPUT,written_files=len(WRITES),publication_bundle_complete=False,outputs_held=True,deleted_bytes=0),failure=True)
 except BaseException as receipt_error:print('Failure receipt refused: '+type(receipt_error).__name__,file=sys.stderr)
sys.exit(rc)

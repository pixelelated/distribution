#!/usr/bin/env python3
"""Consume exact original success channels only; retention does not clear publication."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent;B=runpy.run_path(str(O/'bindings.py'));plan=B['verify'](O)
assert Path.cwd()==B['VM_TREE'];load,sha=B['load'],B['sha'];run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs';B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert p.read_text().strip()=='0',p
result,cleanup=load(O/'result.json'),load(O/'cleanup.json');assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established']is False
assert result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0
assert child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit'])is int and report['original_collector_exit']==0
assert report['archives']==89 and report['notice_count']==130 and report['component_rows']==3 and report['binary_rows']==6
assert report['source_execution']is False and report['go_execution']is False and report['publication_clearance']is False and report['publication_bundle_complete']is False and report['network_used']is False and report['target_execution']is False
assert not (O/'collection-failure.json').exists();D=Path(load(O/'destination.json')['path']);assert report['custody_path']==str(D)
assert len(report['files'])==314 and len({r['path'] for r in report['files']})==len(report['files'])
for r in report['files']:
 p=Path(r['path']);assert p.is_relative_to(D) and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert {r['path'] for r in report['files']}=={str(p) for p in D.rglob('*') if p.is_file()}
assert sum(r['bytes'] for r in report['files'])<=256*1024**2 and sha(D/'manifest.json')==report['manifest_sha256']
manifest=load(D/'manifest.json');assert manifest['publication_bundle_complete']is False and manifest['binding_refs']==plan['binding_refs'] and manifest['unresolved']==plan['unresolved']
assert sha(D/'component-member-index.json')==manifest['component_index_sha256']
assert manifest['module_count']==89 and manifest['notice_count']==130 and manifest['component_rows']==3 and manifest['binary_rows']==6
assert manifest['archive_bytes']==163585749 and manifest['notice_bytes']==528430
assert sha(D/'module-member-index.json')==manifest['module_index_sha256'] and sha(D/'notice-index.json')==manifest['notice_index_sha256']
modules=load(D/'module-member-index.json');notices=load(D/'notice-index.json');components=load(D/'component-member-index.json')
assert len(modules)==89 and len(notices)==130 and len(components)==3
assert {(m['module'],m['version'],m['actual_go_h1']) for m in modules}=={(m['module'],m['version'],m['expected_go_h1']) for m in plan['modules']}
assert all(m['expected_go_h1']==m['actual_go_h1'] and m['original_wait_observed']is True and type(m['original_curl_returncode'])is int and m['original_curl_returncode']==0 for m in modules)
expected={'manifest.json','module-member-index.json','notice-index.json','component-member-index.json','metadata/module-selection.json','metadata/original-status.json'}
expected.update('archives/'+m['key']+'.zip' for m in plan['modules']);expected.update('metadata/'+m['key']+'.index.json' for m in plan['modules']);expected.update('notices/'+Path(n['retained_path']).name for m in plan['modules'] for n in m['notice_candidates'])
assert len(expected)==314 and {str(Path(r['path']).relative_to(D)) for r in report['files']}==expected
import stat
assert all(stat.S_IMODE(p.lstat().st_mode)==(0o555 if p.is_dir() else 0o444) and not p.is_symlink() for p in [D,*D.rglob('*')])
assert cleanup['all_recorded_identities_absent']is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped']is False
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']();keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']};supervisor=cleanup['supervisor_identity'];assert supervisor is not None;keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in keys];parents={r['pid'] for r in matching};descendants=[]
while parents:
 children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants];descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[p for p in O.rglob('*') if p.is_file()]+[run/'runner-result.json',run/'build.rc']+[Path(r['path']) for r in report['files']]
assert len(files)<=1024 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=64*1024**2
out=O/'admission-completion-evidence.json';evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Exact 89 dependency ZIP and 130 notice local custody only; original h1 and selected binary/component associations retained. No new source acquisition, full bundle completion, legal/publication clearance, independent retrieval or offhost proof. Previous runs unchanged.')
raw=(json.dumps(evidence,indent=2)+'\n').encode();assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=64*1024**2
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed Tailscale dependency source custody; explicit publication gaps retained')

"""Exact source/host bindings; no collection at import."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def prerequisites(plan):
 for spec in plan['prerequisites']:
  owner,run=Path(spec['owner']),Path(spec['run']);c=load(run/'admission-consumed.json');result=load(owner/'result.json');cleanup=load(owner/'cleanup.json')
  assert c['id']==spec['admission_id'] and c['state']=='consumed' and c['submission_owner']==str(owner) and c['run']==str(run)
  assert c['source']['head']==COMMIT and c['pid_namespace']==4026531836
  assert c['original_result']==load(run/'runner-result.json')
  assert all(type(c['original_result'][k])is int and c['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
  assert sha(owner/'admission-completion-evidence.json')==c['evidence_sha256']
  launch=load(owner/'launcher-result.json');assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
  for f in [owner/'inner.rc',owner/'outer.rc',owner/'tool-wrapper.rc',owner/'stage/association.exit',run/'build.rc']:assert f.read_text().strip()=='0'
  child=load(owner/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0 and child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
  assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False and result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
  assert cleanup['all_recorded_identities_absent']is True and cleanup['direct_child_unreaped']is False and not any(cleanup[k] for k in ['errors','receipt_errors','signals_sent','recorded_identities_still_present','survivors_after_cleanup'])
 acquisition=load(Path(plan['acquisition_owner'])/'collection-result.json')
 assert acquisition['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(acquisition['original_collector_exit'])is int and acquisition['original_collector_exit']==0
 assert acquisition['gaps']==[] and len(acquisition['rows'])==89 and acquisition['retained_member_bytes']==528430
 assert len(acquisition['downloads'])==92 and all(r['wait_observed']is True and type(r['original_curl_returncode'])is int and r['original_curl_returncode']==0 for r in acquisition['downloads'])
 assert all(acquisition[k]is False for k in ['go_execution','source_execution','source_rebuild','target_execution','publication_clearance'])
 additive=load(Path(plan['additive_custody'])/'manifest.json');assert additive['component_rows']==2366 and additive['publication_bundle_complete']is False
 assert sha(Path(plan['additive_custody'])/'component-member-index.json')==additive['component_index_sha256']
 return acquisition

def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 plan=load(O/'collection-plan.json');assert len(plan['binding_refs'])==31
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 assert len(plan['modules'])==89 and plan['archive_bytes']==163585749 and plan['index_bytes']==4718158 and plan['notice_count']==130 and plan['notice_bytes']==528430
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-tailscale-source-'+O.name.removeprefix('pix-m7-tailscale-custody-')
 prerequisites(plan)
 return plan

from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;Q=Path('/tmp/pix-m7-additive-source-custody-20261015-03');A=Path('/workspace/tmp/pix-m7-tailscale-source-acquisition-20261015-01');AD=Path('/workspace/tmp/pix-m7-additive-source-custody-20261015-01');D=Path('/workspace/artifacts/pixelelated-release-sources/m7-additive-source-20261015-01')
T=P/'templates';T.mkdir();(P/'originals').mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
for n in ['collect.py','run.py','run.sh','consume.py','bindings.py','process-identity.py']:
 shutil.copy2(Q/'templates'/n,P/'originals'/('additive03-'+n));shutil.copy2(Q/'templates'/n,T/n)
for n in ['prepare-owner.py','commands.sh','resources.json','SHA256SUMS']:
 shutil.copy2(Q/n,P/'originals'/('additive03-'+n))
shutil.copy2(Q/'frozen-tools.json',P/'frozen-tools.json')
refs={};prereqs=[]
for label,owner in [('acquisition',A),('additive',AD)]:
 run=Path((owner/'run.path').read_text().strip());consumed=json.loads((run/'admission-consumed.json').read_text())
 for f in [owner/'collection-result.json',owner/'result.json',owner/'cleanup.json',owner/'launcher-result.json',owner/'inner.rc',owner/'outer.rc',owner/'tool-wrapper.rc',owner/'stage/association.result.json',owner/'stage/association.exit',run/'runner-result.json',run/'build.rc',run/'admission-consumed.json',owner/'admission-completion-evidence.json']:
  refs[str(f)]=sha(f)
 prereqs.append({'label':label,'owner':str(owner),'run':str(run),'admission_id':consumed['id']})
for f in [A/'collection-plan.json',D/'manifest.json',D/'component-member-index.json',Path('/tmp/pix-m7-prebuilt-source-disposition-20261015/module-inventory.json'),Path('/tmp/pix-m7-528-current-20261015-1249.json')]:refs[str(f)]=sha(f)
r=json.loads((A/'collection-result.json').read_text());rows=r['rows'];assert len(rows)==89
spec=[]
for row in rows:
 sel=row['selection'];ar=row['archive'];idx=row['member_index'];notes=row['notice_candidates']
 spec.append({'key':sel['key'],'module':sel['module'],'version':sel['version'],'expected_go_h1':sel['expected_go_h1'],'actual_go_h1':row['actual_go_h1'],'canonical_proxy_zip_url':sel['canonical_proxy_zip_url'],'archive':{'path':ar['path'],'bytes':ar['bytes'],'sha256':ar['sha256'],'held_identity':ar},'member_index':dict(idx,bytes=Path(idx['path']).stat().st_size),'member_count':row['member_count'],'decoded_bytes':row['decoded_bytes'],'notice_candidates':notes,'original_request_key':row['original_request_key']})
put(P/'collection-plan.json',{'schema':1,'issue':528,'status':'UNRUN','scope':'Additive local custody of exactly89 previously h1-verified Tailscale dependency ZIPs, their89 indexes and130 notice candidates; exact three-component/six-binary mappings. No recollection, download, source execution, independent retrieval or publication claim.','binding_refs':refs,'prerequisites':prereqs,'acquisition_owner':str(A),'additive_custody':str(D),'module_inventory':'/tmp/pix-m7-prebuilt-source-disposition-20261015/module-inventory.json','modules':spec,'archive_bytes':sum(x['archive']['bytes'] for x in spec),'index_bytes':sum(x['member_index']['bytes'] for x in spec),'notice_bytes':528430,'notice_count':130,'component_profiles':['generic-x64-x86_64','h700-aarch64','sm8550-aarch64'],'unresolved':['Component/source licence disposition, full release bundle integration, independent retrieval, off-host backup and publication remain separate existing #528 criteria.','Only dependency modules are copied; previously retained main Tailscale source and earlier producers remain separate, unchanged evidence.','h1 was verified by the accepted acquisition; this copy stage checks complete ZIP SHA256 equality and preserves that original assertion, without rerunning decoding or Go.']})
r=json.loads((Q/'resources.json').read_text())
for k in ['archive_decoded_bytes','extra_bytes','extra_entries','extra_file_bytes','git_commands','git_seconds','git_stderr_bytes','git_stdout_metadata_bytes','tar_entries','tree_entries']:r.pop(k)
r.update(custody_output_ceiling_bytes=256*1024**2,per_file_bytes=64*1024**2,retention_budget_bytes=512*1024**2,total_read_bytes=2*1024**3,soft_seconds=270,collector_seconds=300,outer_seconds=330,output_directories=16)
put(P/'resources.json',r)
# Keep the qualified common Writer/reserve/hash code exactly; no command/archive parser remains.
s=(T/'collect.py').read_text();common=s[s.index('def tick'):s.index('def command')]
(T/'collect.py').write_text('''#!/usr/bin/env python3
"""Offline immutable-copy custody; execution requires root's separate admission."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,sys,time
from urllib.parse import urlsplit
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path'])
START=time.monotonic();READ=0;WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1
'''+common)
# Preserve source03 process lifecycle; only scope-specific assertions/labels and outer time change.
s=(T/'run.py').read_text().replace("'profile':'additive-source-custody'","'profile':'tailscale-source-custody'")
s=s.replace("assert report['archives']==4 and report['new_git_roots']==1 and report['new_distribution_snapshots']==2 and report['component_rows']==2366 and report['publication_clearance'] is False","assert report['archives']==89 and report['notice_count']==130 and report['component_rows']==3 and report['binary_rows']==6 and report['publication_clearance'] is False")
s=s.replace('Additive exact source custody only;606archive/43Git-root current memberships reference preserved historical custody; generated/FEX/Nix/Tailscale/licence/retrieval/offhost/publication gaps remain; prior producer dispositions unchanged.','Exact local custody of89 previously accepted Tailscale dependency ZIPs and notices; h1/source mapping retained; full bundle, licence, independent retrieval, offhost and publication remain separate; prior producers unchanged.')
(T/'run.py').write_text(s);(T/'run.sh').write_text((T/'run.sh').read_text().replace('--fsize=268435456','--fsize=67108864').replace('930s','330s'))
s=(T/'bindings.py').read_text();(T/'bindings.py').write_text(s[:s.index('def git_identity')])
print(json.dumps({'module_rows':len(spec),'zip_bytes':sum(x['archive']['bytes'] for x in spec),'binding_refs':len(refs),'payloads_read':False}))

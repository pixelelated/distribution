#!/usr/bin/env python3
"""Prepare fresh immutable source bindings only; root allocates collection separately."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 q=argparse.ArgumentParser(description=__doc__);q.add_argument('--owner',type=Path,required=True);a=q.parse_args()
 names=[]
 for line in (P/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);p=P/n;assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h;names.append(n)
 assert len(names)<=128 and sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
 B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']();assert Path.cwd()==B['VM_TREE']
 O=a.owner;assert O.parent==Path('/workspace/tmp') and O.parent.resolve(strict=True)==O.parent and re.fullmatch('pix-m7-tailscale-custody-20261015-[0-9]{2}',O.name)
 assert not O.exists() and not O.is_symlink()
 D=Path('/workspace/artifacts/pixelelated-release-sources')/('m7-tailscale-source-'+O.name.removeprefix('pix-m7-tailscale-custody-'));assert D.parent.resolve(strict=True)==D.parent and not D.exists() and not D.is_symlink()
 plan=json.loads((P/'collection-plan.json').read_text())
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h
 B['prerequisites'](plan)
 O.mkdir(mode=0o700);(O/'stage').mkdir(mode=0o700);(O/'empty-retention-scan').mkdir(mode=0o700)
 written=0;count=0
 def raw(n,b):
  nonlocal written,count
  assert len(b)<=4*1024**2 and written+len(b)<=8*1024**2 and count<64 and not (O/n).exists();written+=len(b);count+=1
  with (O/n).open('xb') as f:f.write(b)
 def put(n,obj):raw(n,(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode())
 for p in sorted((P/'templates').iterdir()):raw(p.name,p.read_bytes())
 for n in ['resources.json','frozen-tools.json']:raw(n,(P/n).read_bytes())
 put('collection-plan.json',plan);put('destination.json',dict(path=str(D)))
 put('preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),pid_namespace=os.readlink('/proc/self/ns/pid'),user_namespace=os.readlink('/proc/self/ns/user'),uid_map=Path('/proc/self/uid_map').read_text(),gid_map=Path('/proc/self/gid_map').read_text(),collector_executed=False,publication_clearance=False))
 put('retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=['/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources','/workspace/artifacts/pixelelated-build-inputs','/workspace/tmp/pix-m7-tailscale-source-acquisition-20261015-01'],candidates=[],builds=[dict(name='m7-tailscale-source-custody',terms_bytes={'exact_tailscale_custody_and_margin':536870912},basis='256MiB new dependency source custody plus64MiB owner ceiling, under512MiB reserved including filesystem overhead; only exact held source objects, no cache scan/deletion.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])]))
 put('admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-tailscale-source-custody',profiles=[dict(PROJECT='ROCKNIX',DEVICE='GENERIC_X64',ARCH='x86_64')],outputs=[dict(path=str(path),kind='qa-scratch',issue=528,release_when='Only after original run consumption and explicit independent custody/retrieval disposition; never delete corresponding-source originals automatically.') for path in [O,D]]))
 put('seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()});B['verify'](O)
 print(json.dumps(dict(owner=str(O),custody=str(D),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),publication_clearance=False)))
if __name__=='__main__':main()

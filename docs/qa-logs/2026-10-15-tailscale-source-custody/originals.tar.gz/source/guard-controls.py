#!/usr/bin/env python3
"""UNRUN synthetic controls; extracts exact copy/budget functions without importing collector."""
from pathlib import Path,PurePosixPath
import ast,hashlib,json,os,signal,stat,tempfile,time
P=Path(__file__).resolve().parent
names={'tick','safe','ident','digest','root_for','reserve','Writer','copy_file'}
tree=ast.parse((P/'templates/collect.py').read_bytes());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names];assert {n.name for n in nodes}==names
code=compile(ast.Module(body=nodes,type_ignores=[]),'exact-collector-functions','exec');signal.alarm(20)
passed=[]
with tempfile.TemporaryDirectory(prefix='pix-tailscale-custody-controls-') as tmp:
 base=Path(tmp)
 def setup(label):
  root=base/label;root.mkdir();owner=root/'owner';owner.mkdir();dest=root/'custody';dest.mkdir();src=root/'source';src.write_bytes(b'public synthetic source\n'*8)
  ns=dict(Path=Path,PurePosixPath=PurePosixPath,hashlib=hashlib,os=os,stat=stat,time=time,O=owner,D=dest,START=time.monotonic(),READ=0,WRITES={},OUTPUT={str(owner):0,str(dest):0},R=dict(total_read_bytes=65536,soft_seconds=10,path_bytes=4096,custody_output_ceiling_bytes=4096,owner_output_ceiling_bytes=4096,supervisor_reserve_bytes=1024,failure_receipt_budget_bytes=128,per_file_bytes=2048,output_files=8))
  exec(code,ns);spec=ns['digest'](src);return ns,src,dict(path=str(src),bytes=spec['bytes'],sha256=spec['sha256'],held_identity=spec)
 def reject(label,alter):
  ns,src,spec=setup(label);alter(ns,src,spec)
  try:ns['copy_file'](spec,'copy.zip')
  except (AssertionError,FileExistsError):passed.append(label)
  else:raise AssertionError('guard accepted '+label)
 ns,src,spec=setup('positive');result=ns['copy_file'](spec,'copy.zip');assert (ns['D']/'copy.zip').read_bytes()==src.read_bytes() and result['independent_copy'] is True and ns['digest'](src)==spec['held_identity'];passed.append('positive-independent-copy-and-unchanged-original')
 reject('wrong-hash',lambda ns,p,s:s.update(sha256='0'*64))
 reject('wrong-size',lambda ns,p,s:s.update(bytes=s['bytes']+1))
 reject('wrong-held-inode',lambda ns,p,s:s['held_identity'].update(inode=s['held_identity']['inode']+1))
 def symlink(ns,p,s):
  link=p.parent/'link';link.symlink_to(p);s['path']=str(link)
 reject('symlink-input',symlink)
 reject('existing-output',lambda ns,p,s:(ns['D']/'copy.zip').write_bytes(b'prior'))
 reject('aggregate-before-write',lambda ns,p,s:ns['R'].update(custody_output_ceiling_bytes=1))
 def mutate(ns,p,s):
  old=ns['Writer'].write
  def write(self,b):
   value=old(self,b);p.write_bytes(b'changed private fixture');return value
  ns['Writer'].write=write
 reject('original-changed-during-copy',mutate)
 assert sum(p.stat().st_size for p in base.rglob('*') if p.is_file())<1024**2
print(json.dumps({'result':'PASS','controls':len(passed),'names':passed,'network':False,'processes_spawned':0,'product_inputs':False,'scratch_removed':True}))

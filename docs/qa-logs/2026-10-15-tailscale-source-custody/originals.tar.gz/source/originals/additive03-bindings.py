"""Exact source/host bindings; no collection at import."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def git_identity(path):
 p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink()
 s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<16*1024**2 and os.access(p,os.X_OK)
 h=sha(p);after=p.stat();assert all(getattr(after,k)==getattr(s,k) for k in ['st_dev','st_ino','st_size','st_mode','st_uid','st_gid','st_mtime_ns'])
 with p.open('rb') as f:header=f.read(64)
 assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==62
 return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,sha256=h)
def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 plan=load(O/'collection-plan.json');assert len(plan['binding_refs'])==16
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 assert len(plan['archives'])==4 and sum(r['bytes'] for r in plan['archives'])==39691947
 assert plan['current_unique_archive_count']==606 and plan['current_unique_git_root_count']==43
 assert plan['host_git']['identity']==git_identity(plan['host_git']['path'])
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-additive-source-'+O.name.removeprefix('pix-m7-additive-source-custody-')
 return plan

#!/usr/bin/env python3
"""Offline additive source custody; import/execution requires a separately admitted owner."""
from pathlib import Path,PurePosixPath
import base64,datetime,gzip,hashlib,io,json,os,selectors,stat,subprocess,sys,tarfile,time
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path'])
START=time.monotonic();READ=0;CALLS=[];WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1

def tick(n=0):
 global READ
 assert n>=0;READ+=n
 assert READ<=R['total_read_bytes'] and time.monotonic()-START<R['soft_seconds'],'read/time ceiling'
def safe(name):
 assert isinstance(name,str) and name and len(os.fsencode(name))<=R['path_bytes'] and '\0' not in name and '\\' not in name
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p)==name and '.git' not in p.parts,name
 return name

def ident(p,regular=True):
 p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.resolve(strict=True)==p,p
 s=p.stat();assert not regular or stat.S_ISREG(s.st_mode),p
 return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def digest(p,cap=268435456):
 before=ident(p);assert before['bytes']<=cap
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));h.update(b)
 assert ident(p)==before,'input changed while hashing'
 return dict(before,sha256=h.hexdigest())
def root_for(p):
 for root in [O,D]:
  if p.is_relative_to(root):return root
 raise AssertionError('write outside owned roots')
def mkdir(p):
 root=root_for(p);assert len(DIRS)<R['output_directories'];assert not p.exists() and not p.is_symlink()
 assert p.parent.resolve(strict=True)==p.parent and not p.parent.is_symlink();p.mkdir(mode=0o700);DIRS.add(str(p))
def reserve(p,n,failure=False):
 tick();root=root_for(p);cap=R['custody_output_ceiling_bytes'] if root==D else R['owner_output_ceiling_bytes']-R['supervisor_reserve_bytes']
 if failure:assert root==O and n<=R['failure_receipt_budget_bytes'];cap+=R['failure_receipt_budget_bytes']
 assert n>=0 and OUTPUT[str(root)]+n<=cap,'aggregate before-write ceiling'
 assert WRITES[str(p)]+n<=R['per_file_bytes'],'individual before-write ceiling'
 OUTPUT[str(root)]+=n;WRITES[str(p)]+=n
class Writer:
 def __init__(self,p,failure=False):
  self.p=Path(p);root_for(self.p);safe(str(self.p.relative_to(root_for(self.p))))
  assert len(WRITES)<R['output_files'] and str(self.p) not in WRITES
  assert self.p.parent.resolve(strict=True)==self.p.parent and not self.p.exists() and not self.p.is_symlink()
  WRITES[str(self.p)]=0;self.failure=failure;self.f=self.p.open('xb')
 def write(self,b):reserve(self.p,len(b),self.failure);return self.f.write(b)
 def flush(self):self.f.flush()
 def tell(self):return self.f.tell()
 def close(self):self.f.close()
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
def put(p,obj,failure=False):
 raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
 if failure:assert len(raw)<=R['failure_receipt_budget_bytes']
 with Writer(p,failure) as f:f.write(raw)
def rawput(p,b):
 with Writer(p) as f:f.write(b)
def load(p):
 before=ident(p);assert before['bytes']<16*1024**2
 raw=Path(p).read_bytes();tick(len(raw));assert ident(p)==before;return json.loads(raw)

def command(argv,cap,sink=None):
 assert len(CALLS)<R['git_commands'] and argv[0]==PLAN['host_git']['path']
 row=dict(argv=argv,original_returncode=None,wait_observed=False,stdout_bytes=0,stderr_bytes=0);CALLS.append(row)
 env={'PATH':'/usr/bin:/bin','HOME':str(O/'empty-home'),'LC_ALL':'C','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_ATTR_NOSYSTEM':'1','GIT_CONFIG_COUNT':'5','GIT_CONFIG_KEY_0':'core.hooksPath','GIT_CONFIG_VALUE_0':'/dev/null','GIT_CONFIG_KEY_1':'protocol.allow','GIT_CONFIG_VALUE_1':'never','GIT_CONFIG_KEY_2':'core.attributesFile','GIT_CONFIG_VALUE_2':'/dev/null','GIT_CONFIG_KEY_3':'core.fsmonitor','GIT_CONFIG_VALUE_3':'false','GIT_CONFIG_KEY_4':'core.untrackedCache','GIT_CONFIG_VALUE_4':'false'}
 p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=O)
 # The outer qualified subreaper owns interruption cleanup and adopted waits.
 # Never signal a numeric group or invent an original child wait on early refusal.
 sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ,'stdout');sel.register(p.stderr,selectors.EVENT_READ,'stderr');buf={'stdout':bytearray(),'stderr':bytearray()};deadline=time.monotonic()+R['git_seconds']
 try:
  while sel.get_map():
   tick();assert time.monotonic()<deadline,'Git command deadline'
   for key,_ in sel.select(.2):
    b=os.read(key.fileobj.fileno(),65536)
    if not b:sel.unregister(key.fileobj);continue
    which=key.data;row[which+'_bytes']+=len(b);tick(len(b))
    assert row[which+'_bytes']<=(cap if which=='stdout' else R['git_stderr_bytes']),'Git output ceiling'
    if which=='stdout' and sink is not None:sink.write(b)
    else:buf[which].extend(b)
  p.wait(timeout=max(.01,deadline-time.monotonic()));row.update(original_returncode=p.returncode,wait_observed=True,stderr=buf['stderr'].decode('utf-8','backslashreplace'))
  assert p.returncode==0,'Git original exit '+str(p.returncode)
  return bytes(buf['stdout'])
 finally:
  sel.close();p.stdout.close();p.stderr.close()
def git(repo,*args,cap=None):return command([PLAN['host_git']['path'],'-C',str(repo),*args],R['git_stdout_metadata_bytes'] if cap is None else cap)
def private_view(spec,seq):
 v=O/'scratch'/('view-'+str(seq)+'.git');mkdir(v)
 for rel in ['objects','objects/info','refs','info']:mkdir(v/rel)
 rawput(v/'HEAD',b'ref: refs/heads/unused\n');rawput(v/'config',b'[core]\n\trepositoryformatversion = 0\n\tbare = true\n[tar]\n\tumask = 0022\n')
 objects=Path(spec['objects']);assert objects.is_absolute() and objects.resolve(strict=True)==objects and not objects.is_symlink()
 rawput(v/'objects/info/alternates',(str(objects)+'\n').encode())
 rawput(v/'info/attributes',b'* -export-ignore -export-subst -text -eol -ident -filter -working-tree-encoding\n')
 return v
class Decoded:
 def __init__(self,f):self.f=f;self.n=0
 def read(self,n=-1):
  assert n>=0;b=self.f.read(n);self.n+=len(b);tick(len(b));assert self.n<=R['archive_decoded_bytes'],'decoded archive ceiling';return b

def snapshot(spec,seq,distribution=False):
 commit=spec['commit'];assert len(commit)==40
 commit_raw=git(spec['source_repository'],'cat-file','commit',commit,cap=65536)
 assert hashlib.sha1(b'commit '+str(len(commit_raw)).encode()+b'\0'+commit_raw).hexdigest()==commit
 roots=spec.get('roots',[]);raw=git(spec['source_repository'],'ls-tree','-r','-z',commit,'--',*roots)
 entries={};edges=[]
 for record in raw.split(b'\0'):
  if not record:continue
  meta,name=record.split(b'\t',1);mode,kind,oid=meta.decode().split();name=safe(os.fsdecode(name));assert name not in entries
  if mode=='160000':assert kind=='commit';edges.append(dict(path=name,commit=oid));continue
  assert kind=='blob' and mode in ['100644','100755','120000'];entries[name]=dict(mode=mode,git_blob=oid)
  assert len(entries)<=R['tree_entries']
 assert entries, 'empty Git source tree'
 inputs=load(spec['input_manifest']) if distribution else None
 if distribution:
  assert not edges and set(entries)==set(inputs['source_files'])|set(inputs['source_symlinks']),'distribution map differs from exact tree'
 else:assert edges==[dict(path=s['path'],commit=s['commit']) for s in spec['submodules']]
 view=private_view(spec,seq);member=('distribution/' if distribution else 'trees/')+commit+'.tar.gz';target=D/member
 with Writer(target) as out:
  with gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0,compresslevel=6) as z:
   command([PLAN['host_git']['path'],'--git-dir',str(view),'archive','--format=tar',commit,'--',*roots],R['archive_decoded_bytes'],z)
 witnessed=set();seen=set();lfs=[];declared=0
 with target.open('rb') as f,gzip.GzipFile(fileobj=f,mode='rb') as gz:
  dec=Decoded(gz)
  with tarfile.open(fileobj=dec,mode='r|',encoding='utf-8',errors='surrogateescape') as tar:
   for m in tar:
    name=safe(m.name.rstrip('/'));assert name not in seen;seen.add(name);assert len(seen)<=R['tar_entries']
    if m.isdir():continue
    assert name in entries;expected=entries[name];assert m.size>=0;declared+=m.size;assert declared<=R['archive_decoded_bytes']
    if m.issym():
     assert expected['mode']=='120000';data=os.fsencode(m.linkname);h=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data);sh=hashlib.sha256(data)
     if distribution:assert data==os.fsencode(inputs['source_symlinks'][name]),name
    else:
     assert m.isfile() and not m.issparse() and expected['mode'] in ['100644','100755'] and (m.mode&0o777)==(0o755 if expected['mode']=='100755' else 0o644)
     h=hashlib.sha1(b'blob '+str(m.size).encode()+b'\0');sh=hashlib.sha256();stream=tar.extractfile(m);got=0
     while True:
      b=stream.read(1024**2)
      if not b:break
      if got==0 and b.startswith(b'version https://git-lfs.github.com/spec/v1\n'):lfs.append(name)
      got+=len(b);tick(len(b));h.update(b);sh.update(b)
     assert got==m.size
     if distribution:assert sh.hexdigest()==inputs['source_files'][name],name
    assert h.hexdigest()==expected['git_blob'],name
    expected['sha256']=sh.hexdigest();expected['bytes']=len(data) if m.issym() else m.size;witnessed.add(name)
  while dec.read(1024**2):pass
 assert witnessed==set(entries)
 archive=digest(target);meta=dict(commit=commit,commit_object_base64=base64.b64encode(commit_raw).decode('ascii'),entries=entries,submodules=edges,lfs_pointer_paths=lfs,archive_member=member,archive_sha256=archive['sha256'],archive_bytes=archive['bytes'],verified_blob_entries=len(entries),source_input=spec.get('input_manifest'),claim='Exact Git blob bytes, executable modes and raw symlink targets; export-ignore/substitution disabled in private view; distribution maps match accepted source_files/source_symlinks')
 put(D/'metadata'/(commit+'.json'),meta)
 return dict(commit=commit,archive_member=member,sha256=archive['sha256'],bytes=archive['bytes'],metadata_member='metadata/'+commit+'.json',metadata_sha256=digest(D/'metadata'/(commit+'.json'))['sha256'],tracked_blobs=len(entries),submodules=edges,lfs_pointer_paths=lfs)

def copy_archive(spec):
 p=Path(spec['path']);before=digest(p);assert before['bytes']==spec['bytes'] and before['sha256']==spec['sha256']
 if 'held_identity' in spec:
  assert all(before[k]==spec['held_identity'][k] for k in ['path','bytes','device','inode','mode','uid','gid','mtime_ns','sha256'])
 target=D/'archives'/spec['sha256']
 with p.open('rb') as f,Writer(target) as out:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));out.write(b)
 after=digest(target);assert after['sha256']==spec['sha256'] and after['bytes']==spec['bytes'] and (after['device'],after['inode'])!=(before['device'],before['inode'])
 assert digest(p)==before
 return dict(spec,member='archives/'+spec['sha256'],source_identity=before,custody_sha256=after['sha256'],independent_copy=True)

def extras(repo,commit,index):
 # Named current ES root/submodule only; Git provides a finite file list, no cache walk.
 assert git(repo,'rev-parse','HEAD').decode().strip()==commit
 assert not git(repo,'diff','--no-ext-diff','--name-only','HEAD','--ignore-submodules=all').strip(),'tracked cache differs'
 raw=git(repo,'ls-files','--others','-z');names=[safe(os.fsdecode(n)) for n in raw.split(b'\0') if n]
 assert len(names)<=R['extra_entries'] and len(set(names))==len(names)
 if not names:
  assert git(repo,'rev-parse','HEAD').decode().strip()==commit and not git(repo,'diff','--no-ext-diff','--name-only','HEAD','--ignore-submodules=all').strip()
  return dict(source_cache=str(repo),tracked_commit=commit,members={},archive_member=None,disposition='No untracked/ignored cache files observed in named root')
 members={};total=0;name='extra-cache-content/'+str(index)+'.tar.gz';path=D/name
 with Writer(path) as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0,compresslevel=6) as z,tarfile.open(fileobj=z,mode='w|',encoding='utf-8',errors='surrogateescape') as tar:
  for n in sorted(names):
   p=Path(repo)/n;assert p.parent.resolve(strict=True)==p.parent
   s=p.lstat();t=tarfile.TarInfo(n);t.mtime=0;t.uid=t.gid=0
   if stat.S_ISLNK(s.st_mode):
    value=os.readlink(p);b=os.fsencode(value);assert len(b)<=R['path_bytes'];t.type=tarfile.SYMTYPE;t.linkname=value;t.mode=0o777;tar.addfile(t);assert os.readlink(p)==value;after=p.lstat();assert all(getattr(after,k)==getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']);members[n]=dict(symlink=value,sha256=hashlib.sha256(b).hexdigest())
   else:
    assert stat.S_ISREG(s.st_mode) and s.st_size<=R['extra_file_bytes'];total+=s.st_size;assert total<=R['extra_bytes']
    before=digest(p,R['extra_file_bytes']);data=p.read_bytes();tick(len(data));assert len(data)==s.st_size and hashlib.sha256(data).hexdigest()==before['sha256'];assert digest(p,R['extra_file_bytes'])==before
    t.size=len(data);t.mode=stat.S_IMODE(s.st_mode);tar.addfile(t,io.BytesIO(data));members[n]=dict(bytes=len(data),sha256=before['sha256'],mode=t.mode)
 # Independent archive readback retains cache extras separately from the pinned tree.
 with path.open('rb') as f,gzip.GzipFile(fileobj=f,mode='rb') as gz:
  dec=Decoded(gz);got=set()
  with tarfile.open(fileobj=dec,mode='r|',encoding='utf-8',errors='surrogateescape') as tar:
   for m in tar:
    assert m.name in members and m.name not in got;got.add(m.name);x=members[m.name]
    if 'symlink' in x:assert m.issym() and os.fsencode(m.linkname)==os.fsencode(x['symlink'])
    else:assert m.isfile() and m.mode==x['mode'] and m.size==x['bytes'];data=tar.extractfile(m).read(R['extra_file_bytes']+1);assert hashlib.sha256(data).hexdigest()==x['sha256']
  while dec.read(1024**2):pass
 assert got==set(members) and git(repo,'ls-files','--others','-z')==raw
 assert git(repo,'rev-parse','HEAD').decode().strip()==commit and not git(repo,'diff','--no-ext-diff','--name-only','HEAD','--ignore-submodules=all').strip()
 return dict(source_cache=str(repo),tracked_commit=commit,members=members,archive_member=name,sha256=digest(path)['sha256'],disposition='Untracked/ignored cache content preserved separately; inclusion/use/licence unresolved')

try:
 assert D.parent==Path('/workspace/artifacts/pixelelated-release-sources') and D.name=='m7-additive-source-'+O.name.removeprefix('pix-m7-additive-source-custody-') and not D.exists() and not D.is_symlink()
 for p in O.rglob('*'):
  assert not p.is_symlink();
  if p.is_file():OUTPUT[str(O)]+=p.stat().st_size
 assert OUTPUT[str(O)]<8*1024**2
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 assert digest(PLAN['host_git']['path'],16*1024**2)==PLAN['host_git']['identity']
 mkdir(D)
 for n in ['archives','distribution','trees','metadata','extra-cache-content']:mkdir(D/n)
 mkdir(O/'scratch');mkdir(O/'empty-home')
 copied=[copy_archive(s) for s in PLAN['archives']];assert len(copied)==4
 snapshots=[snapshot(s,i,True) for i,s in enumerate(PLAN['distribution'])]
 es=snapshot(PLAN['git_root'],2);snapshots.append(es)
 base=PLAN['custodies']['git'];historic=load(base['manifest']);archive_base=load(PLAN['custodies']['archives']['manifest'])
 s=PLAN['git_root']['submodules'][0];ref=s['historical_snapshot'];assert historic['snapshots'][s['commit']]==ref
 assert digest(Path(base['path'])/ref['archive_member'])['sha256']==ref['archive_sha256']
 assert digest(Path(base['path'])/ref['metadata_member'],16*1024**2)['sha256']==ref['metadata_sha256']
 metadata=load(Path(base['path'])/ref['metadata_member']);assert metadata['commit']==s['commit'] and not metadata['submodules']
 doom=PLAN['doom_reuse'];doom_actual=digest(doom['path']);assert doom_actual['sha256']==doom['sha256'] and doom_actual['bytes']==doom['bytes']
 extra=[extras(PLAN['git_root']['source_repository'],PLAN['git_root']['commit'],0),extras(s['source_repository'],s['commit'],1)]
 # Derive all current profile memberships from the exact accepted worklists.
 current_archives=set();current_git=set();mapping=[];new={r['sha256']:r for r in copied};dist={r['commit']:r for r in snapshots[:2]}
 for profile in PLAN['profiles']:
  w=load(profile['worklist']);inputs=load(profile['inputs']);assert len(w['components'])==profile['components'] and w['distribution_commit']==inputs['distribution_commit'];assert set(inputs['source_files'])|set(inputs['source_symlinks'])
  for c in w['components']:
   assert inputs['source_files'][c['recipe']]==c['recipe_sha256']
   assert all(inputs['source_files'][r['path']]==r['sha256'] for r in c.get('recipe_inheritance',[]))
   members=[]
   for cache in (c.get('unpacked_source') or {}).get('cache',[]):
    if 'sha256' in cache:
     h=cache['sha256'];current_archives.add(h)
     if h in new:members.append(dict(kind='new-archive',path=str(D/new[h]['member']),sha256=h))
     elif h==doom['sha256']:members.append(dict(kind='historical-supplement',path=doom['path'],sha256=h,rehash_in_this_run=True))
     else:
      assert archive_base['archives'][h]['bytes']==cache['bytes'];members.append(dict(kind='historical-archive',path=PLAN['custodies']['archives']['path']+'/archives/'+h,sha256=h,rehash_in_this_run=False))
    else:
     commit=cache['git_head'];current_git.add(commit)
     if commit==es['commit']:members.append(dict(kind='new-git-root',snapshot=es,submodule_references=[s]))
     else:
      assert commit in historic['snapshots'];todo=[commit];closure=[];seen=set()
      while todo:
       cur=todo.pop()
       if cur in seen:continue
       seen.add(cur);assert len(seen)<=2048;closure.append(dict(commit=cur,**historic['snapshots'][cur]));todo.extend(e['commit'] for e in historic['submodule_edges'] if e['parent_commit']==cur)
      members.append(dict(kind='historical-git-root',root_commit=commit,custody=base['path'],snapshots=closure,rehash_in_this_run=False))
   mapping.append(dict(profile=profile['profile'],component=c['component'],recipe=c['recipe'],recipe_sha256=c['recipe_sha256'],recipe_inheritance=c.get('recipe_inheritance',[]),distribution_snapshot=dist[w['distribution_commit']]['archive_member'],members=members,source_disposition=c['source_disposition'],additional_corresponding_source_refs=[dict(path=str(D/r['member']),sha256=r['sha256'],source_kind=r['kind']) for r in copied if c['component']=='rclone' and r['kind']=='held-rclone-source']))
 assert len(current_archives)==606 and len(current_git)==43 and len(mapping)==2366
 put(D/'component-member-index.json',mapping)
 manifest=dict(schema=1,scope=PLAN['scope'],binding_refs=PLAN['binding_refs'],archives=copied,snapshots=snapshots,reused_doom=doom,reused_git_submodule=s,current_archive_count=606,current_git_root_count=43,component_rows=len(mapping),component_index_sha256=digest(D/'component-member-index.json')['sha256'],historical_custodies=PLAN['custodies'],historical_cache_extras=historic['extra_source_cache_content'],current_cache_extras=extra,publication_bundle_complete=False,unresolved=PLAN['unresolved'])
 put(D/'manifest.json',manifest)
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 assert digest(PLAN['host_git']['path'],16*1024**2)==PLAN['host_git']['identity']
 put(O/'git-command-waits.json',CALLS)
 files=[dict(path=p,bytes=n,sha256=digest(p)['sha256']) for p,n in WRITES.items() if Path(p).is_relative_to(D)]
 for item in files:Path(item['path']).chmod(0o444)
 for p in sorted([Path(p) for p in DIRS if Path(p).is_relative_to(D)],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
 put(O/'collection-result.json',dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,custody_path=str(D),manifest_sha256=digest(D/'manifest.json')['sha256'],files=files,archives=4,new_cache_archives=2,new_git_roots=1,new_distribution_snapshots=2,component_rows=2366,current_archive_count=606,current_git_root_count=43,network_used=False,target_execution=False,source_rebuild=False,publication_clearance=False,publication_bundle_complete=False,outputs_held=True,deleted_bytes=0,accounted_output_bytes=OUTPUT,read_bytes=READ,elapsed_seconds=time.monotonic()-START,git_commands=len(CALLS),unresolved=PLAN['unresolved']))
 rc=0
except BaseException as exc:
 # One finite reserved failure receipt; never replay a refused large manifest.
 try:put(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(exc).__name__+': '+str(exc)[:4096],accounted_output_bytes=OUTPUT,written_files=len(WRITES),git_command_statuses=[dict(argv=r['argv'],original_returncode=r['original_returncode'],wait_observed=r['wait_observed'],stdout_bytes=r['stdout_bytes'],stderr_bytes=r['stderr_bytes']) for r in CALLS],publication_bundle_complete=False,outputs_held=True,deleted_bytes=0),failure=True)
 except BaseException as receipt_error:print('Failure receipt refused: '+type(receipt_error).__name__,file=sys.stderr)
sys.exit(rc)

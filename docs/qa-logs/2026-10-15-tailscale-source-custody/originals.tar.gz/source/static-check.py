#!/usr/bin/env python3
"""Source parsing/metadata comparisons only; never import/execute candidates or read payloads."""
from pathlib import Path
import ast,difflib,hashlib,json,re
P=Path(__file__).resolve().parent
checks=[]
for p in sorted(P.rglob('*.py')):ast.parse(p.read_bytes(),filename=str(p));checks.append('AST '+str(p.relative_to(P)))
plan=json.loads((P/'collection-plan.json').read_text());total=0
for n,h in plan['binding_refs'].items():
 p=Path(n);assert not p.is_symlink() and p.stat().st_size<16*1024**2;raw=p.read_bytes();total+=len(raw);assert total<32*1024**2;assert hashlib.sha256(raw).hexdigest()==h
checks.append('31 exact small prerequisite/accepted-metadata hashes')
for s in plan['prerequisites']:
 run=Path(s['run']);c=json.loads((run/'admission-consumed.json').read_text());r=json.loads((run/'runner-result.json').read_text());assert c['original_result']==r and c['state']=='consumed' and c['id']==s['admission_id'];assert all(type(r[k])is int and r[k]==0 for k in ['command_rc','monitor_rc','runner_rc']);checks.append('actual consumed/original numeric-zero schema: '+s['label'])
assert len(plan['modules'])==89 and sum(m['archive']['bytes'] for m in plan['modules'])==163585749 and sum(m['member_index']['bytes'] for m in plan['modules'])==4718158
notices=[n for m in plan['modules'] for n in m['notice_candidates']];assert len(notices)==130 and len({n['retained_path'] for n in notices})==130 and sum(n['bytes'] for n in notices)==528430
checks.append('exact89 ZIP/index plus130 unique notice declared totals')
def defs(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a=defs(P/'originals/additive03-collect.py');b=defs(P/'templates/collect.py');assert all(a[n]==b[n] for n in ['tick','safe','ident','digest','root_for','mkdir','reserve','Writer','put','rawput','load']);checks.append('11 common collector helpers/classes AST-identical')
assert defs(P/'originals/additive03-run.py')==defs(P/'templates/run.py');checks.append('all qualified supervisor functions AST-identical')
assert (P/'templates/process-identity.py').read_bytes()==(P/'originals/additive03-process-identity.py').read_bytes();checks.append('identity helper byte-identical')
commands=(P/'commands.sh').read_text();assert 'TASK_PACKET='+str(P)+'\n' in commands and 'TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-tailscale-custody-20261015-01}' in commands
assert re.fullmatch('pix-m7-tailscale-custody-20261015-[0-9]{2}','pix-m7-tailscale-custody-20261015-01');checks.append('explicit valid command packet/owner locators')
changes=[]
for old,new in [('originals/additive03-'+n,'templates/'+n) for n in ['collect.py','run.py','run.sh','consume.py','bindings.py','process-identity.py']]+[('originals/additive03-'+n,n) for n in ['prepare-owner.py','commands.sh','resources.json']]:changes.extend(difflib.unified_diff((P/old).read_text().splitlines(True),(P/new).read_text().splitlines(True),fromfile=old,tofile=new))
assert ''.join(changes)==(P/'changes.diff').read_text();checks.append('full executable/resource diff exact')
print(json.dumps({'result':'PASS_STATIC_ONLY','checks':checks,'metadata_bytes_read':total,'payloads_read':False,'candidate_import_or_execution':False,'guard_controls_executed':False},indent=2))

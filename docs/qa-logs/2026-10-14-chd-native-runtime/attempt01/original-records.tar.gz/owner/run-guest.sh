#!/bin/sh
set -eu
mkdir /run/pix574-chd
mount -t tmpfs -o size=2G,mode=700,nosuid,nodev tmpfs /run/pix574-chd
set +e
python3 -I -S -B /tmp/pix-input/pix574-chd/owner/guest-run.py --run-id native01 > /tmp/pix-output/chd-owner.stdout 2> /tmp/pix-output/chd-owner.stderr
pxrc=$?
printf '%s\n' "$pxrc" > /tmp/pix-output/chd-owner.rc
set -e
sync
umount /run/pix574-chd
printf 'PIX574_CHD_NATIVE_RC:%s\n' "$pxrc"
test "$pxrc" -eq 0

#!/usr/bin/env python3
"""UNRUN compact receipt archive after original host channels close; no retirement."""
import argparse,hashlib,json,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--owner',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
R=a.owner.resolve(strict=True);run=a.run.resolve(strict=True);out=a.output.absolute();C=json.loads((R/'config.json').read_text())
def sha(f):
    with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(f,value):f.write_text(json.dumps(value,indent=2)+'\n')
assert run.parent==Path(C['checkout'])/'.build-runs' and not out.exists()
launcher=json.loads((R/'lifecycle-owner/launcher-result.json').read_text());runner=json.loads((run/'runner-result.json').read_text());owner=json.loads((R/'owner-result.json').read_text())
rc=launcher['runner_returncode'];assert rc in (0,1) and runner['command_rc']==runner['runner_rc']==rc and runner['monitor_rc']==0
assert (R/'lifecycle-owner/tool-wrapper.rc').read_text().strip()==(run/'build.rc').read_text().strip()==str(rc)
pids=[launcher['pid']]+[int((run/n).read_text()) for n in ['build.pid','command.pid','watcher.pid']]
if owner.get('scope_client_identity'):pids.append(owner['scope_client_identity']['pid'])
if (R/'records/scope-start.json').exists():
    s=json.loads((R/'records/scope-start.json').read_text());pids.append(s['identity']['pid']);cg=Path(s['path']);assert cg.name==C['scope_unit']
    assert not cg.exists() or not (cg/'cgroup.procs').read_text().split()
assert all(not Path('/proc',str(pid)).exists() for pid in pids)
if rc==0:
    assert owner['status']=='PASS' and owner['original_scope_returncode']==0 and not owner['cleanup'] and not owner.get('cleanup_error')
    w=json.loads((R/'work-result.json').read_text());assert w['status']=='PASS'
    for name,row in w['artifacts'].items():assert (R/'artifacts'/name).stat().st_size==row['bytes'] and sha(R/'artifacts'/name)==row['sha256']
out.mkdir(mode=0o700);sources=[]
for base,label in [(R,'owner'),(run,'run')]:
    for f in sorted(base.rglob('*')):
        if f.is_symlink() or not f.is_file() or (base==R and (f.is_relative_to(R/'scratch') or f.is_relative_to(R/'artifacts'))):continue
        sources.append((f,label+'/'+str(f.relative_to(base))))
# Retain original configure/build logs and Ninja command history without copying compiler products.
for rel in ['logs/configure.stdout','logs/configure.stderr','logs/build.stdout','logs/build.stderr','logs/libisofs-version.txt','build/meson-logs/meson-log.txt','build/.ninja_log','build/compile_commands.json','mkdcdisc.sha256']:
    f=R/'scratch/work'/rel
    if f.is_file():sources.append((f,'build-work/'+rel))
rows=[{'path':name,'bytes':f.stat().st_size,'sha256':sha(f)} for f,name in sources]
with tarfile.open(out/'original-records.tar.gz','x:gz') as tar:
    for f,name in sources:tar.add(f,arcname=name,recursive=False)
with tarfile.open(out/'original-records.tar.gz') as tar:
    assert {m.name for m in tar.getmembers()}=={r['path'] for r in rows}
    for row in rows:
        raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(out/'original-records.json',rows);write(out/'host-exits.json',{'original_exit':rc,'pids_absent':pids})
write(out/'export-result.json',{'original_exit':rc,'archive_verified':True,'artifacts_retained_at':str(R/'artifacts'),'accepted':False,'next':'Root reviews originals and hashes, consumes admission, and retires scratch only; keep tool/CDI/licenses for installed gameplay/save fixture.'})
print(str(out))

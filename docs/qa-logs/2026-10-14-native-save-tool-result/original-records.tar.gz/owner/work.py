#!/usr/bin/env python3
"""UNRUN: two fixed native stages inside the existing user's bounded scope."""
import ctypes,hashlib,json,os,resource,shutil,signal,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parent;C=json.loads((R/'config.json').read_text());B=json.loads((R/'inputs.json').read_text())
sys.path.insert(0,str(R))
from census import direct_children,proc_identity,signal_child
def require(ok,message):
    if not ok:raise AssertionError(message)
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def snapshot():
    result={}
    for path,row in B['files'].items():
        f=Path(path);require(f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],'input changed: '+path);result[path]=row
    game=Path(B['game_root'])
    require(sha(game/'SHA256SUMS')==B['game_manifest_sha256'],'game manifest changed')
    for name,row in B['game_files'].items():
        f=game/name;require(not f.is_symlink() and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],'game input changed: '+name);result[str(f)]=row
    for row in B['host_inputs']:
        f=Path(row['path']);require(str(f.resolve())==row['resolved'] and f.stat().st_size==row['bytes'] and sha(f)==row['sha256'],'host input changed: '+str(f));result[str(f)]=row
    return result
def cg_read():
    keys=['memory.max','memory.swap.max','memory.oom.group','memory.current','memory.peak','memory.events','cpu.max','cpu.stat','pids.max','pids.current']
    return {key:(CG/key).read_text().strip() for key in keys}
def observe():
    total=0;count=0
    for root in [R/'scratch',R/'artifacts']:
        for f in root.rglob('*'):
            if f.is_symlink() or not f.is_file():continue
            count+=1;require(count<=20000,'private file-count bound');total+=f.stat().st_size
    require(total<=2*1024**3,'private scratch logical bytes exceed2GiB')
    logs=list((R/'logs').glob('*'))+list((R/'scratch/work/logs').glob('*'))+list((R/'scratch/work/build/meson-logs').glob('*'))
    for f in logs:
        if f.is_file():require(f.stat().st_size<=16*1024**2,'named log exceeds16MiB: '+str(f))
    state=cg_read();events=dict(x.split() for x in state['memory.events'].splitlines())
    require(int(events.get('oom',0))==int(events.get('oom_kill',0))==0,'scope OOM observed')
    return {'monotonic':time.monotonic(),'logical_private_bytes':total,'files':count,'cgroup':state}
def cleanup(report):
    deadline=time.monotonic()+5
    while True:
        while True:
            try:pid,status=os.waitpid(-1,os.WNOHANG)
            except ChildProcessError:break
            if not pid:break
            report['reaped'].append({'pid':pid,'wait_status':status})
        rows=direct_children(os.getpid())
        if not rows:break
        require(time.monotonic()<deadline,'descendant cleanup deadline')
        for row in rows:report['signals'].append(signal_child(row,os.getpid()))
        time.sleep(.02)
    report['remaining_children']=direct_children(os.getpid())
def stage(name,argv,seconds,file_limit,env):
    row={'name':name,'argv':[str(x) for x in argv],'original_returncode':None,'timed_out':False,'signals':[],'reaped':[],'cleanup_errors':[],'timeout_seconds':seconds,'file_limit_bytes':file_limit}
    child=None;started=time.monotonic()
    def setup():
        resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(file_limit,file_limit))
        if LIBC.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=PARENT:os._exit(125)
    try:
        with (R/'logs'/(name+'.stdout')).open('xb') as out,(R/'logs'/(name+'.stderr')).open('xb') as err:
            child=subprocess.Popen(row['argv'],cwd=R/'scratch',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,preexec_fn=setup)
            row['identity']=proc_identity(child.pid)
            while child.poll() is None:
                if time.monotonic()-started>=seconds:row['timed_out']=True;raise TimeoutError(name+' deadline')
                sample=observe()
                with (R/'records/resources.jsonl').open('a') as stream:stream.write(json.dumps({'stage':name,**sample})+'\n')
                try:child.wait(timeout=min(1,seconds-(time.monotonic()-started)))
                except subprocess.TimeoutExpired:pass
            row['original_returncode']=child.returncode;observe()
            require(child.returncode==0,'original '+name+' failed')
    except BaseException as exc:row['error']=type(exc).__name__+': '+str(exc)
    finally:
        if child is not None:
            try:
                if child.poll() is None:
                    identity=proc_identity(child.pid);require(identity is not None,'live stage identity unavailable')
                    row['signals'].append(signal_child(identity,PARENT));child.wait(timeout=2)
                row['original_returncode']=child.returncode
                cleanup(row)
            except BaseException as exc:row['cleanup_errors'].append(str(exc))
        row['elapsed_seconds']=time.monotonic()-started;write(R/'records'/(name+'-result.json'),row)
    require(row['original_returncode']==0 and not row['timed_out'] and not row.get('error') and not row['signals'] and not row['reaped'] and not row['cleanup_errors'] and row.get('remaining_children')==[],name+' original/cleanup failure')
    return row
PARENT=os.getpid();LIBC=ctypes.CDLL(None,use_errno=True);LIBC.prctl.restype=ctypes.c_int
report={'status':'FAIL','pid':PARENT,'stages':[],'cleanup_errors':[]};started=time.monotonic();CG=None
def interrupted(*_):raise TimeoutError('native tool family deadline or termination')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGALRM,interrupted);signal.alarm(780)
try:
    require(os.getuid()==1000 and os.geteuid()!=0,'normal host user required')
    require(LIBC.prctl(36,1,0,0,0)==0,'subreaper unavailable')
    paths=[line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::')];require(len(paths)==1,'unified cgroup required')
    CG=Path('/sys/fs/cgroup')/paths[0].lstrip('/');require(CG.name==C['scope_unit'],'not in exact allocated scope')
    state=cg_read();quota,period=state['cpu.max'].split()
    require(state['memory.max']==str(4*1024**3) and state['memory.swap.max']=='0' and state['memory.oom.group']=='1','scope memory contract absent')
    require(quota==period and state['pids.max']=='128','scope CPU/task contract absent')
    cpu=min(os.sched_getaffinity(0));os.sched_setaffinity(0,{cpu})
    write(R/'records/scope-start.json',{'path':str(CG),'identity':proc_identity(PARENT),'limits':state,'affinity':sorted(os.sched_getaffinity(0))})
    for name,digest in C['code'].items():require(sha(R/name)==digest,'source changed: '+name)
    before=snapshot();write(R/'records/inputs-before.json',before)
    require(sha(R/'source/build-tool.sh')==B['files'][B['tool_plan']+'/build-tool.sh']['sha256'],'copied build script differs')
    scratch=R/'scratch';require(not any(scratch.iterdir()),'fresh scratch required')
    for name in ['home','author-tmp','game']:(scratch/name).mkdir()
    for name in B['game_files']:
        source=Path(B['game_root'])/name;dest=scratch/'game'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    env={'PATH':'/usr/bin:/bin','HOME':str(scratch/'home'),'TMPDIR':str(scratch/'author-tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
    old=Path(B['tool_plan'])
    report['stages'].append(stage('build',['/bin/bash',R/'source/build-tool.sh',old/'mkdcdisc-2b98b0d9.tar.gz',old/'libisofs-dev_1.5.6.pl01-1.1ubuntu3_amd64.deb',scratch/'work'],600,256*1024**2,env))
    tool=scratch/'work/build/mkdcdisc';require(tool.is_file() and tool.read_bytes()[:4]==b'\x7fELF','native tool ELF missing')
    report['tool']={'path':str(tool),'bytes':tool.stat().st_size,'sha256':sha(tool)}
    disc=scratch/'Tetris2-M7.cdi'
    report['stages'].append(stage('author',[tool,'-B',scratch/'game/1ST_READ.BIN','-D',scratch/'game/tetris2-disc','-p',scratch/'game/IP.BIN','-o',disc],120,1024**3,env))
    require(disc.is_file() and 0<disc.stat().st_size<=1024**3,'authored disc missing/oversized')
    report['disc']={'path':str(disc),'bytes':disc.stat().st_size,'sha256':sha(disc)}
    after=snapshot();require(after==before,'immutable original inputs changed');write(R/'records/inputs-after.json',after)
    for name,row in B['game_files'].items():require(sha(scratch/'game'/name)==row['sha256'],'private game input modified: '+name)
    shutil.copy2(tool,R/'artifacts/mkdcdisc');shutil.move(disc,R/'artifacts/Tetris2-M7.cdi')
    for name in ['LICENSE','THIRD-PARTY-NOTICES.md']:shutil.copy2(old/name,R/'artifacts'/name)
    shutil.copy2(Path(B['game_root'])/'licenses/Tetris2-BSD-3-Clause.txt',R/'artifacts/Tetris2-BSD-3-Clause.txt')
    report['artifacts']={str(f.relative_to(R/'artifacts')):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted((R/'artifacts').iterdir()) if f.is_file()}
    report['final_resources']=observe();report['status']='PASS'
except BaseException as exc:report['error']=type(exc).__name__+': '+str(exc)
finally:
    signal.alarm(15)
    try:
        tail={'signals':[],'reaped':[]};cleanup(tail);report['final_census']=tail
        if tail['signals'] or tail['reaped'] or tail.get('remaining_children')!=[]:report['status']='FAIL'
        if CG is not None:report['final_cgroup']=cg_read()
    except BaseException as exc:report['status']='FAIL';report['cleanup_errors'].append(str(exc))
    signal.alarm(0);report['elapsed_seconds']=time.monotonic()-started;write(R/'work-result.json',report)
raise SystemExit(0 if report['status']=='PASS' else 1)

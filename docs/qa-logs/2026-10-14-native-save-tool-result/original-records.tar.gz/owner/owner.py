#!/usr/bin/env python3
"""UNRUN watched host owner for one fixed, kernel-bounded native tool scope."""
import hashlib,json,os,signal,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parent;C=json.loads((R/'config.json').read_text());TREE=Path(C['checkout']);unit=C['scope_unit']
def sha(f):
    with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(f,value):f.write_text(json.dumps(value,indent=2)+'\n')
def identity(pid):
    p=Path('/proc',str(pid));raw=(p/'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'start_ticks':int(raw[19])}
env=dict(os.environ,XDG_RUNTIME_DIR='/run/user/1000');report={'status':'FAIL','original_scope_returncode':None,'timed_out':False,'cleanup':[]};child=None;started=time.monotonic()
def control(name,argv):
    r=subprocess.run(argv,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=10)
    (R/'logs'/(name+'.stdout')).write_bytes(r.stdout);(R/'logs'/(name+'.stderr')).write_bytes(r.stderr)
    write(R/'records'/(name+'.json'),{'argv':argv,'original_returncode':r.returncode});return r
def interrupted(*_):raise TimeoutError('outer scope owner interrupted or timed out')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGALRM,interrupted);signal.alarm(830)
try:
    assert os.getuid()==1000 and os.geteuid()!=0 and os.readlink('/proc/self/ns/pid')=='pid:[4026531836]'
    for name,digest in C['code'].items():assert sha(R/name)==digest
    run=Path(os.environ['RASTERATOPS_BUILD_RUN']);run=run if run.is_absolute() else TREE/run;assert run.parent==TREE/'.build-runs'
    watcher=identity(int((run/'watcher.pid').read_text()));write(R/'records/owner-start.json',{'owner':identity(os.getpid()),'watcher':watcher,'run':str(run),'scope_unit':unit})
    check=control('scope-before',['systemctl','--user','show','--property=LoadState','--property=ActiveState','--no-pager','--',unit])
    assert check.returncode in (0,4) and b'LoadState=not-found\n' in check.stdout,'refuse existing/unknown unit'
    argv=['systemd-run','--user','--scope','--unit='+unit,'--property=MemoryMax=4294967296','--property=MemorySwapMax=0',
          '--property=CPUQuota=100%','--property=TasksMax=128','--property=OOMPolicy=kill','--property=RuntimeMaxSec=800',
          '/usr/bin/python3','-I','-S','-B',str(R/'work.py')]
    report['argv']=argv
    with (R/'logs/scope.stdout').open('xb') as stdout,(R/'logs/scope.stderr').open('xb') as stderr:
        child=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
        report['scope_client_identity']=identity(child.pid)
        try:report['original_scope_returncode']=child.wait(timeout=800)
        except subprocess.TimeoutExpired:report['timed_out']=True;raise
    assert child.returncode==0,'scope original failed'
    work=json.loads((R/'work-result.json').read_text());assert work['status']=='PASS' and len(work['stages'])==2
    assert [r['name'] for r in work['stages']]==['build','author'] and all(r['original_returncode']==0 and not r['timed_out'] for r in work['stages'])
    assert not work['cleanup_errors'] and work['final_census']['remaining_children']==[] and not work['final_census']['signals'] and not work['final_census']['reaped']
    for name,row in work['artifacts'].items():assert (R/'artifacts'/name).stat().st_size==row['bytes'] and sha(R/'artifacts'/name)==row['sha256']
    report['status']='PASS'
except BaseException as exc:
    report['error']=type(exc).__name__+': '+str(exc)
    if isinstance(exc,(TimeoutError,subprocess.TimeoutExpired)):report['timed_out']=True
finally:
    signal.alarm(30)
    try:
        info=R/'records/scope-start.json';scope_members=[]
        if info.exists():
            scope_row=json.loads(info.read_text());scope_path=Path(scope_row['path']);assert scope_path.name==unit and scope_path.is_relative_to('/sys/fs/cgroup')
            scope_members=(scope_path/'cgroup.procs').read_text().split() if scope_path.exists() else []
        if (child is not None and child.poll() is None) or scope_members:
            report['status']='FAIL'
            for name,argv in [('scope-kill',['systemctl','--user','kill','--kill-whom=all','--signal=KILL','--',unit]),('scope-stop',['systemctl','--user','stop','--',unit])]:
                r=control(name,argv);report['cleanup'].append({'operation':name,'original_returncode':r.returncode})
            try:
                if child is not None:report['original_scope_returncode']=child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                # This is the identity-owned systemd-run client only; scope kill
                # above owns native descendants through its exact fresh unit.
                os.killpg(child.pid,signal.SIGKILL);report['original_scope_returncode']=child.wait(timeout=2)
        if info.exists():
            row=json.loads(info.read_text());cg=Path(row['path']);assert cg.name==unit and cg.is_relative_to('/sys/fs/cgroup')
            members=(cg/'cgroup.procs').read_text().split() if cg.exists() else []
            report['remaining_scope_pids']=members;assert not members,'scope still populated'
            assert not Path('/proc',str(row['identity']['pid'])).exists(),'native scope owner remains'
        elif report['status']=='PASS':raise AssertionError('actual scope readback missing')
        if child is not None:assert child.poll() is not None
    except BaseException as exc:report['status']='FAIL';report['cleanup_error']=str(exc)
    signal.alarm(0);report['elapsed_seconds']=time.monotonic()-started;write(R/'owner-result.json',report)
raise SystemExit(0 if report['status']=='PASS' else 1)

#!/bin/bash
# FUTURE admitted host build only. No installer, container, SDK cross compiler or tests.
set -euo pipefail
[[ $# == 3 ]] || { echo 'usage: build-tool.sh SOURCE_TAR LIBISOFS_DEV_DEB NEW_WORK' >&2; exit 2; }
source_tar=$(realpath "$1")
dev_deb=$(realpath "$2")
work=$(realpath -m "$3")
[[ ! -e $work && ! -L $work ]]
printf '%s  %s\n' 92215196a70dd8e31e0641c1698c20978fbeab23eb70498dbad709c1848ef632 "$source_tar" | sha256sum --check --status
printf '%s  %s\n' 31b95aa3c65d384fbe73001eb697c3e5219dd4f46930fe6d1cf9281b75b0aaea "$dev_deb" | sha256sum --check --status
printf '%s  %s\n' 603edaf2c97c8f8199ed37845e8ef419eea150a583e083b17fa344cbfaa0c972 /usr/lib/x86_64-linux-gnu/libisofs.so.6.92.0 | sha256sum --check --status
sdk=/workspace/repos/rocknix.worktrees/m7-pixelelated-replacement20/build.pixelelated-GENERIC_X64.x86_64/toolchain
printf '%s  %s\n' 01e064593347ea344c5acbe9a19cc512fb1f447c02d89b3c14fc02d160175c0d "$sdk/bin/ninja" | sha256sum --check --status
mkdir -p "$work/src" "$work/sysroot" "$work/bin" "$work/python" "$work/cache" "$work/tmp" "$work/logs"
tar -xzf "$source_tar" --strip-components=1 -C "$work/src"
printf '%s  %s\n' 0de4affef3c4fe287efa820f58324d0ca2e66c52225d540d73e44850234fe975 "$work/src/meson.build" | sha256sum --check --status
dpkg-deb -x "$dev_deb" "$work/sysroot"
# Development package's libisofs.so symlink needs the matching already-installed runtime.
[[ -L $work/sysroot/usr/lib/x86_64-linux-gnu/libisofs.so ]]
[[ $(readlink "$work/sysroot/usr/lib/x86_64-linux-gnu/libisofs.so") == libisofs.so.6.92.0 ]]
ln -s /usr/lib/x86_64-linux-gnu/libisofs.so.6.92.0 "$work/sysroot/usr/lib/x86_64-linux-gnu/libisofs.so.6.92.0"
cp -a "$sdk/lib/python3.14/site-packages/mesonbuild" "$work/python/mesonbuild"
cp "$sdk/bin/ninja" "$work/bin/ninja"
cat > "$work/run-meson.py" <<'PY'
import pathlib
import sys
sys.path.insert(0, str(pathlib.Path(__file__).parent / 'python'))
from mesonbuild.mesonmain import main
raise SystemExit(main())
PY
export PATH="$work/bin:/usr/bin:/bin"
export CC=/usr/bin/gcc CXX=/usr/bin/g++ CCACHE_DISABLE=1
export PYTHONDONTWRITEBYTECODE=1 XDG_CACHE_HOME="$work/cache" TMPDIR="$work/tmp"
export PKG_CONFIG=/usr/bin/pkg-config PKG_CONFIG_SYSROOT_DIR="$work/sysroot"
export PKG_CONFIG_LIBDIR="$work/sysroot/usr/lib/x86_64-linux-gnu/pkgconfig"
unset PKG_CONFIG_PATH CFLAGS CXXFLAGS CPPFLAGS LDFLAGS LD_LIBRARY_PATH LIBRARY_PATH CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH
/usr/bin/pkg-config --modversion libisofs-1 > "$work/logs/libisofs-version.txt"
/usr/bin/python3 -I "$work/run-meson.py" setup "$work/build" "$work/src" \
  --buildtype=release --wrap-mode=nodownload -Dpng=disabled -Dslow_tests=false \
  > "$work/logs/configure.stdout" 2> "$work/logs/configure.stderr"
"$work/bin/ninja" -C "$work/build" -j1 mkdcdisc \
  > "$work/logs/build.stdout" 2> "$work/logs/build.stderr"
sha256sum "$work/build/mkdcdisc" > "$work/mkdcdisc.sha256"
echo 'Tool built only; no test suite or game execution, disc authoring is next admitted stage'

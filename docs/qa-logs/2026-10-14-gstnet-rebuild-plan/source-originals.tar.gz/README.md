# #572 libgstnet source correction and incremental assembly

SOURCE ONLY. The retained original diagnostic at /workspace/tmp/pix-m7-retained-loader-20261014-01/records/guest-loader.json reported exactly four missing-libgstnet scanner warnings: libgstadaptivedemux2.so, libgstrtpmanager.so, libgstrtsp.so and libgstudp.so. The two ldd commands and gst-inspect opengl returned0; the unchanged warning-free acceptance predicate failed. Preserve that original failure.

The final d6a root contains those four plugins through the new full Dolphin -> Qt6 -> gst-plugins-good dependency. All four directly need libgstnet-1.0.so.0. The core GStreamer build and toolchain sysroot already contain that library; projects/ROCKNIX/packages/multimedia/gstreamer/gstreamer/package.mk:53 deletes it from package installation. The old replacement20 image lacks those four plugins. This explains why the earlier scanner/controller-only package proof did not encounter the composed image failure. It is a package cleanup omission, not evidence that the default scanner path failed.

retain-gstnet.patch removes that deletion and updates the local comment. No dependency, version, plugin selection, or architecture change. The corrected package matches current upstream ROCKNIX project-override cleanup behavior: only /usr/share is removed. Upstream already fixed its effective override in commit6103571f67238c3521a3a19e59f32248e7956167 (PR3470). The generic recipe still deletes net/controller but is overridden. No new upstream PR for this deletion is needed.

Primary source references, with exact API/source copies under upstream/:

- https://github.com/ROCKNIX/distribution/blob/1e5d62ed5fc8f3309d4a9e2d0d6dd201d8bc1d49/projects/ROCKNIX/packages/multimedia/gstreamer/gstreamer/package.mk
- https://github.com/ROCKNIX/distribution/pull/3470
- https://github.com/ROCKNIX/distribution/commit/6103571f67238c3521a3a19e59f32248e7956167
- https://github.com/pixelelated/distribution/commit/2292e9a2983227a62aaf7846a5b739c41b0841a7
- https://github.com/pixelelated/distribution/issues/572

Static checks: original patch apply --check0 against frozen d6a; bash -n0; actual tools/pkgcheck gstreamer0 against isolated lint copy. No package shell was sourced, runtime plugin executed, or product source edited by this lane. Root applied and committed the correction separately as fac608ff89940ce358ea9b8a95e9a08a6fe26568, product diff exactly one override. The new complete source-only executable engineering derivative, original helper bytes, full diff, static checks, and exact commands are in engineering/. No cache transfer/build launched here. New assembled dependency/loader/UI checks remain required.

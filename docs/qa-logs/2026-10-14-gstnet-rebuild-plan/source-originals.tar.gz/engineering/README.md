# #572 atomic cache custody and narrow engineering rebuild

Source-only derivative, UNRUN. Exact frozen input is fac608ff89940ce358ea9b8a95e9a08a6fe26568 at /workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02, branch build/m7-p5-20261014-02. The only product delta from d6a87f05c1935516115b2cca1af22151a0209224 is the GStreamer project override retaining libgstnet. ES remains 3178b832b8d134198b2b4eede4f725d4ed283f8c. No version/dependency bump or frontend change.

Root explicitly authorized atomic transfer after dependency review. This supersedes the earlier independent-copy recipe for this one completed cache. No cache duplication, hardlinking, symlink alias, old branch advance, or old target replacement. Linux renameat2(RENAME_NOREPLACE) transfers the directory atomically and refuses an existing destination or cross-filesystem fallback. The receipt records the unchanged directory inode/device and old/new custody; it makes no checksum-copy claim. Original tracked checkout, target, image readback, completed build/payload receipts remain. The prior prepared final-baseline owner is retired before transfer; its replacement must bind the new image after readback.

The source lane did not scan or mutate the cache. capacity-measurement.json extracts the original owner's final quiescent 21:55:44 allocation sample: build root 125592436736 bytes, shared sources 68200853504, old target 4245250048. Its complete original allocation log is hash-bound. Admission refreshes current free space. The transfer budget is 65 GiB (1 GiB metadata plus 64 GiB margin), with no copied-cache allowance or reclamation credit. The rebuild budget is max(one-third old cache,32 GiB)+8 GiB downloads+16 GiB firmware+32 GiB immediate QA+64 GiB margin. It omits the already completed Qt/Dolphin cold allowances.

The bounded 120-second transfer owner requires the coordinator's fresh <=900-second assessed dependency receipt. Its explicitly scoped readable-process/Docker inventory and excluded protected session services are retained verbatim; no privileged whole-host FD census is claimed. No active admission, matching process, overlapping Docker mount, or remaining cache consumer is allowed in that pre-submission receipt. Original build completion evidence hashes are rechecked. A post-rename failure leaves its exact intent/result and current custody intact for review: do not retry or silently roll back.

## Concrete commands, coordinator execution only

The new worktree already exists. If recreating this preparation from scratch, use only the following named branch command when the destination and branch are both absent; never sync or reset the old worktree:

```bash
git -C /workspace/repos/rocknix worktree add -b build/m7-p5-20261014-02 /workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02 fac608ff89940ce358ea9b8a95e9a08a6fe26568
```

Use the packet in place or an unchanged sealed copy. These commands prepare and submit one transfer; wait for original results and consume its admission before preparing the build.

```bash
TASK_PACKET=/tmp/pix572-gstnet-source-plan-20261014/engineering
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02
TASK_COMMIT=fac608ff89940ce358ea9b8a95e9a08a6fe26568
TASK_ES=3178b832b8d134198b2b4eede4f725d4ed283f8c
TASK_TRANSFER=/workspace/tmp/pix-m7-gstnet-transfer-20261014-01
TASK_BUILD=/workspace/tmp/pix-m7-engineering-build-20261014-02
TASK_DEPENDENCY=/tmp/pix572-cache-dependencies-assessed.json
TASK_DEPENDENCY_SHA=ee7d33253aef657d00f93a9b35613a0cb2fc1e4776edd101c7e9cba02b4929ee
mkdir -m 700 "$TASK_TRANSFER" "$TASK_BUILD"
cd "$TASK_TREE"
tools/build-preflight
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" --expected-es "$TASK_ES" --measurement "$TASK_PACKET/capacity-measurement.json" --owner "$TASK_TRANSFER" --stage transfer
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_TRANSFER/retention-plan.json" --output "$TASK_TRANSFER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_TRANSFER/admission-plan.json" --output "$TASK_TRANSFER/admission.json"
tools/watch-build-submit --owner "$TASK_TRANSFER" -- --admission "$TASK_TRANSFER/admission.json" --activity-dir "$TASK_TRANSFER" -- python3 -I "$TASK_PACKET/transfer-cache.py" --owner "$TASK_TRANSFER" --dependency-readback "$TASK_DEPENDENCY" --dependency-sha256 "$TASK_DEPENDENCY_SHA"
```

The dependency receipt's timestamp expires; if delayed, root must repeat the same scoped readback and review, use its fresh path/hash, and preserve the original. Do not alter its timestamp or weaken the check. Consume transfer only after actual launcher/runner/command/monitor exits, original inner.rc0, transfer-result PASS, cache-ready PASS, same inode/device, old path absent, new custody present, and no surviving watched processes. Preserve the original transfer owner, intent, dependency readback/hash, and both result files in the usual consumption evidence with exactly the admission's outputs. Then `build-admission consume --run <exact run.path> --evidence <reviewed consumption-evidence.json>` from the host PID namespace. This is the existing coordinator result review, not a synthesized success receipt.

```bash
tools/build-preflight
TASK_TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)
python3 -I "$TASK_PACKET/prepare-owner.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" --expected-es "$TASK_ES" --owner "$TASK_BUILD" --cache-ready "$TASK_TRANSFER/cache-ready.json" --timestamp "$TASK_TIMESTAMP" --family-seconds 7200
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" --expected-es "$TASK_ES" --measurement "$TASK_PACKET/capacity-measurement.json" --owner "$TASK_BUILD" --stage build
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_BUILD/retention-plan.json" --output "$TASK_BUILD/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_BUILD/admission-plan.json" --output "$TASK_BUILD/admission.json"
tools/watch-build-submit --owner "$TASK_BUILD" -- --admission "$TASK_BUILD/admission.json" -- python3 -I "$TASK_BUILD/build-owner.py"
```

Only three stages run: canonical docker-package-clean gstreamer; docker-package gstreamer; docker-GENERIC_X64. The normal engine owns dependencies and image installation reset. The image stamp is invalidated only in the transferred destination. No forced Qt6/Dolphin/WebKit rebuild or manually injected ELF. Full original stage, inner make, host make, watcher, resource and cleanup results remain required.

host-resources.py and inner-build.py are byte-identical to the successful revision03 owner. Container logical path stays /workspace/repos/rocknix.worktrees/m7-pixelelated, preserving cached toolchain paths. Digest remains ghcr.io/pixelelated/build@sha256:988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39. GStreamer uses CPUs0–3/24 GiB; image CPUs0–23/40 GiB; no container swap; PIDs2048. Existing memory/swap/disk floors and original observation handshake are unchanged. Proposed family deadline7200s (maximum accepted input21600s, no greater than old); no extension during execution. Bounds are operating ceilings, not predicted needs.

Build0 is not installed qualification. Rebind new image/SYSTEM/KERNEL, installed libgstnet symlinks and four DT_NEEDED consumers, scanner/controller/GL and original warning-free fresh-registry probe. Preserve failed d6a loader originals. Refresh final image/source receipt consumers, clean and retained boot paths, pending UI/baseline owners. Existing accepted component results remain their original source scope. No new gate or upstream submission is introduced.

# Root commands after source review — unrun

Use one owner at a time. The suggested VNC ports below are proposals; root's
allocation and existing lifecycle must establish that the chosen port is free.
The preparers create owners themselves; do not precreate or reuse an owner.

```bash
TASK_PACKET=/tmp/pix-m7-zerotier-vm-proof-20261015-02
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03
TASK_COORD=/workspace/repos/rocknix.worktrees/m7-player-setup
TASK_VERIFY=/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-02/artifacts/result.json
TASK_OWNER=/workspace/tmp/pix-m7-zt-clean-20261015-01
TASK_EXPORT=/workspace/tmp/pix-m7-zt-clean-evidence-20261015-01
python3 -I -B "$TASK_PACKET/fresh/prepare.py" \
  --checkout "$TASK_TREE" --clean-checkout "$TASK_COORD" \
  --verification "$TASK_VERIFY" --owner "$TASK_OWNER" --vnc 151
```

Then, using that owner/export pair:

```bash
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
# Review original retention/watcher outcome and capacity first.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --admission "$TASK_OWNER/admission.json" --activity-dir "$TASK_OWNER" --recursive-activity -- \
  python3 -I -B "$TASK_OWNER/vm-lifecycle.py"
# Active supervision within60s; wait for actual launcher/runner completion.
TASK_RUN=$(cat "$TASK_OWNER/run.path")
python3 -I -B "$TASK_OWNER/close.py" \
  --owner "$TASK_OWNER" --run "$TASK_RUN" --output "$TASK_EXPORT"
# Review every original channel, guest report and closure before consumption.
python3 -I tools/host-maintenance/build-admission consume --run "$TASK_RUN" \
  --evidence "$TASK_EXPORT/consumption-draft.json"
```

Only after closure/consumption, prepare the distinct retained owner and repeat
the same retention/admission/submit/export/review/consume sequence:

```bash
TASK_OWNER=/workspace/tmp/pix-m7-zt-retained-20261015-01
TASK_EXPORT=/workspace/tmp/pix-m7-zt-retained-evidence-20261015-01
python3 -I -B "$TASK_PACKET/retained/prepare.py" \
  --checkout "$TASK_TREE" --verification "$TASK_VERIFY" \
  --retained-owner /workspace/tmp/pix-m7-retained20-20261014-02 \
  --retained-evidence /workspace/tmp/pix-m7-retained20-evidence-20261014-02 \
  --state-checker "$TASK_COORD/tools/pixelelated-state-check" \
  --state-checker-sha256 65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6 \
  --owner "$TASK_OWNER" --vnc 152
```

Require clean/report.json for fresh; zerotier-fresh or zerotier-before/after
reports and separate exit markers; retained state-before/after and base-before/
after equality; exact installed/executing identities; ordinary update boot/hash
chain; seven original host channels plus guest success and absent owned
processes. The exporter preserves failed results and never consumes itself.
Do not publish raw ZeroTier transport/CLI files listed by private-originals-held.

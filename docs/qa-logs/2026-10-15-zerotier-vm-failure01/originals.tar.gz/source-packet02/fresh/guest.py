#!/usr/bin/python3
"""Bound installed ZeroTier local lifecycle; CONFIG and PHASE supplied inline."""
import base64,hashlib,json,os,resource,selectors,signal,stat,subprocess,time
from pathlib import Path
UNIT='zerotier-one.service';ZT_HOME=Path('/storage/.config/zerotier');NET=Path('/storage/.config/zerotier-networks')
PRIVATE=Path('/storage/.cache/'+CONFIG['zerotier_snapshot'])
STABLE=[ZT_HOME/n for n in ['identity.secret','identity.public','authtoken.secret','metricstoken.secret','local.conf']]+[NET]
SELECTED=['/storage/.config/system/configs/system.cfg','/storage/.config/emulationstation/es_settings.cfg','/storage/.config/cloud_sync.conf','/storage/roms/gb/pixelelated-installed-state.gb','/storage/roms/gb/gamelist.xml','/storage/.config/ppsspp/PSP/SYSTEM/ppsspp_retroachievements.dat','/storage/.cache/cloud_sync/last-backup','/storage/.cache/cloud_sync/last-restore']
result={'status':'FAIL','phase':PHASE,'commands':[],'cleanup_errors':[],'service_observations':[]};raw_commands=[];output_bytes=0;service_owned=False;known=[];before=None
def require(ok,code):
    if not ok:raise RuntimeError(code)
def data(p,maximum=1024**2,optional=False):
    p=Path(p)
    if not p.exists():
        require(not p.is_symlink(),'dangling-selected-link')
        if optional:return None
        raise RuntimeError('missing-selected-file')
    require(not p.is_symlink(),'selected-symlink');s=p.stat()
    require(stat.S_ISREG(s.st_mode) and s.st_size<=maximum,'selected-shape')
    b=p.read_bytes();a=p.stat()
    require((s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_mode,a.st_size,a.st_mtime_ns,a.st_ctime_ns) and len(b)==s.st_size,'selected-changed')
    return {'bytes_b64':base64.b64encode(b).decode(),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid}
def selected():return {p:data(p,optional=True) for p in SELECTED}
def stable():
    rows={str(p):data(p,65536) for p in STABLE}
    require(sum(len(v['bytes_b64']) for v in rows.values())<=1024**2,'private-snapshot-bound')
    require(NET.read_bytes()==b'' and (ZT_HOME/'local.conf').read_bytes()==b'{}\n','named-fixture-changed')
    networks=ZT_HOME/'networks.d';require(networks.is_dir() and not networks.is_symlink() and not any(networks.iterdir()),'network-membership-present')
    return rows
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def members():
    rows={};mounts=[x.split()[4] for x in Path('/proc/self/mountinfo').read_text().splitlines()]
    require('/usr' not in mounts,'usr-overlay')
    for rel,want in CONFIG['zerotier_members'].items():
        p=Path('/')/rel;require(p.is_file() and 0<p.stat().st_size<=16*1024**2,'installed-member-shape')
        actual={'bytes':p.stat().st_size,'sha256':digest(p),'mode':stat.filemode(p.stat().st_mode),'resolved':str(p.resolve())}
        require(not any(str(p)==m or str(p.resolve())==m or m.startswith('/usr/') and str(p).startswith(m+'/') for m in mounts),'product-overlay')
        require(actual['mode']==want['mode'] and actual['resolved']==want['link_chain']['resolved'],'installed-mode-or-link')
        for link in want['link_chain']['links']:require(os.readlink(link['path'])==link['target'],'installed-link-target')
        # Before update the accepted old image/source is bound; capture its actual
        # old executable rather than inventing a hash from source equality.
        if PHASE!='before' or rel not in ['usr/sbin/zerotier-one','usr/sbin/zerotier-cli','usr/sbin/zerotier-idtool']:
            require(actual['bytes']==want['bytes'] and actual['sha256']==want['sha256'],'installed-member-hash')
        rows[rel]=actual
    return rows
def identity(pid):
    try:
        p=Path('/proc',str(pid));f=(p/'stat').read_text().rsplit(')',1)[1].split()
        if f[0]=='Z':return None
        return {'pid':pid,'start_ticks':int(f[19]),'executable':os.readlink(p/'exe'),'sha256':digest(p/'exe'),'argv':(p/'cmdline').read_bytes().split(b'\0')[:-1]}
    except FileNotFoundError:return None
def same(row):
    now=identity(row['pid']);return bool(now and now['start_ticks']==row['start_ticks'])
def command(argv,seconds=10,readiness=False):
    global output_bytes
    require(len(raw_commands)<32,'command-count-bound')
    row={'argv':argv,'timeout_seconds':seconds,'original_returncode':None,'timed_out':False,'output_limit':False,'readiness':readiness};child=None;parts={'stdout':bytearray(),'stderr':bytearray()}
    try:
        child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        end=time.monotonic()+seconds
        with selectors.DefaultSelector() as mux:
            for key,stream in [('stdout',child.stdout),('stderr',child.stderr)]:os.set_blocking(stream.fileno(),False);mux.register(stream,selectors.EVENT_READ,key)
            while mux.get_map():
                if time.monotonic()>=end:row['timed_out']=True;raise TimeoutError('child-timeout')
                for event,_ in mux.select(min(.1,max(0,end-time.monotonic()))):
                    b=os.read(event.fd,8192)
                    if not b:mux.unregister(event.fileobj);continue
                    if len(parts[event.data])+len(b)>65536 or output_bytes+len(b)>256*1024:
                        row['output_limit']=True;raise RuntimeError('child-output-bound')
                    parts[event.data].extend(b);output_bytes+=len(b)
            row['original_returncode']=child.wait(timeout=max(.01,end-time.monotonic()))
        if not readiness:require(row['original_returncode']==0,'child-exit-nonzero')
        return bytes(parts['stdout'])
    finally:
        if child:
            try:
                if child.poll() is None:
                    os.killpg(child.pid,signal.SIGKILL);row['forced_cleanup']=True
                row['original_returncode']=child.wait(timeout=5)
            except BaseException as exc:
                row['cleanup_error']=type(exc).__name__+': '+str(exc)
                result['cleanup_errors'].append('child-original-wait-incomplete')
            finally:child.stdout.close();child.stderr.close()
        original=dict(row,stdout_b64=base64.b64encode(parts['stdout']).decode(),stderr_b64=base64.b64encode(parts['stderr']).decode())
        raw_commands.append(original);result['commands'].append(row)
def service():
    b=command(['systemctl','show',UNIT,'--property=MainPID,ActiveState,SubState,Result,ExecMainCode,ExecMainStatus,NRestarts,ExecStart,ExecStartPost'])
    fields=dict(x.split('=',1) for x in b.decode().splitlines() if '=' in x)
    result['service_observations'].append(fields);return fields
def no_network():require(sorted(p.name for p in Path('/sys/class/net').iterdir())==['lo'],'no-NIC')
def active():
    s=service();require(s['ActiveState']=='active' and s['SubState']=='running' and int(s['NRestarts'])==0,'service-not-stable')
    require('/usr/sbin/zerotier-one /storage/.config/zerotier/' in s['ExecStart'] and '/usr/sbin/zerotier-join.sh' in s['ExecStartPost'],'service-command')
    row=identity(int(s['MainPID']));require(row and row['executable']=='/usr/sbin/zerotier-one','daemon-identity')
    require(row['sha256']==result['members_before']['usr/sbin/zerotier-one']['sha256'],'executing-bytes')
    require(row['argv']==[b'/usr/sbin/zerotier-one',b'/storage/.config/zerotier/'],'daemon-argv')
    public={k:v for k,v in row.items() if k!='argv'};known.append(public);result.setdefault('daemon_identities',[]).append(public)
    return public
def ready(identity_row):
    # ExecStartPost is not a readiness barrier: its shell always exits zero.
    # Preserve each actual CLI exit; only the exact upstream startup failures
    # below may precede the required successful loopback status response.
    deadline=time.monotonic()+30
    for attempt in range(8):
        require(same(identity_row),'daemon-left-during-readiness')
        remaining=deadline-time.monotonic();require(remaining>0,'local-api-readiness-deadline')
        stdout=command(['/usr/sbin/zerotier-cli','-D/storage/.config/zerotier/','-j','info'],min(3,remaining),readiness=True)
        row=result['commands'][-1];original=raw_commands[-1]
        if row['original_returncode']==0:
            value=json.loads(stdout)
            require(value['version']=='1.16.0' and value['online'] is False,'local-api-status')
            result.setdefault('readiness_checks',[]).append({'attempts':attempt+1,'successful_original_returncode':0,'deadline_seconds':30})
            return value
        stderr=base64.b64decode(original['stderr_b64'])
        missing_port=b'missing port and zerotier-one.port not found in /storage/.config/zerotier/'
        missing_token=b'authtoken.secret not found or readable in /storage/.config/zerotier/'
        expected=(row['original_returncode']==2 and stdout==b'' and (missing_port in stderr or missing_token in stderr)) or (row['original_returncode']==1 and stderr==b'' and stdout.startswith(b'Error connecting to the ZeroTier service: '))
        require(expected,'unexpected-cli-readiness-failure')
        row['accepted_starting_state']=True;original['accepted_starting_state']=True
        require(same(identity_row),'daemon-left-during-readiness')
        time.sleep(min(.25,max(0,deadline-time.monotonic())))
    raise RuntimeError('local-api-not-ready-within-eight-attempts')
def queries(info):
    require(command(['/usr/sbin/zerotier-cli','-v']).decode().strip()=='1.16.0','cli-version')
    nets=json.loads(command(['/usr/sbin/zerotier-cli','-D/storage/.config/zerotier/','-j','listnetworks']))
    require(info['version']=='1.16.0' and info['online'] is False and nets==[],'offline-local-cli')
    no_network();result.setdefault('cli_checks',[]).append({'version':info['version'],'online':info['online'],'network_count':len(nets)})
def stop_service():
    global service_owned
    command(['systemctl','stop',UNIT],30);s=service()
    require(s['MainPID']=='0' and s['ActiveState']=='inactive' and s['Result']=='success','service-stop-state')
    require(all(not same(r) for r in known),'daemon-survived-stop');service_owned=False
    # Exact daemon identities are gone. No unrelated socket scan is needed.
    result['daemon_stopped']=True
def expire(_sig,_frame):raise TimeoutError('guest-phase-deadline')
signal.signal(signal.SIGALRM,expire);signal.signal(signal.SIGTERM,expire);signal.signal(signal.SIGINT,expire)
signal.alarm(140)
try:
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(1024**2,1024**2))
    require(PHASE in ['fresh','before','after'],'phase')
    no_network();result['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    commit=CONFIG['previous_commit'] if PHASE=='before' else CONFIG['commit']
    require('BUILD_ID="'+commit+'"' in Path('/etc/os-release').read_text(),'installed-build')
    require(not any(Path('/storage/.update').iterdir()),'update-queue')
    before=selected();result['members_before']=members();initial=service()
    require(initial['MainPID']=='0' and initial['ActiveState']=='inactive','pre-existing-service')
    if PHASE in ['fresh','before']:
        require(not PRIVATE.exists() and not PRIVATE.is_symlink(),'existing-private-snapshot')
        require(not NET.exists() and not NET.is_symlink(),'existing-network-list')
        require(not ZT_HOME.is_symlink() and (not ZT_HOME.exists() or ZT_HOME.is_dir() and not any(ZT_HOME.iterdir())),'existing-zerotier-state')
        ZT_HOME.mkdir(mode=0o700,exist_ok=True)
        with (ZT_HOME/'local.conf').open('xb') as f:os.fchmod(f.fileno(),0o600);f.write(b'{}\n')
        with NET.open('xb') as f:os.fchmod(f.fileno(),0o600)
    else:
        original=json.loads(base64.b64decode(data(PRIVATE/'before.json')['bytes_b64']))
        require(original['boot_id']!=result['boot_id'] and original['stable']==stable(),'retained-state-before-start')
        result['retained_before_start_equal']=True
    service_owned=True;command(['systemctl','start',UNIT],30);first=active();queries(ready(first));snapshot=stable()
    if PHASE=='after':require(snapshot==original['stable'],'retained-state-after-start')
    if PHASE in ['fresh','after']:
        command(['systemctl','restart',UNIT],30);second=active()
        require((first['pid'],first['start_ticks'])!=(second['pid'],second['start_ticks']) and not same(first),'restart-identity')
        queries(ready(second));require(stable()==snapshot,'restart-state-changed');result['restart_pass']=True
    stop_service();require(stable()==snapshot,'stop-state-changed')
    if PHASE=='before':
        PRIVATE.mkdir(mode=0o700);raw=json.dumps({'boot_id':result['boot_id'],'stable':snapshot}).encode()
        require(len(raw)<=1024**2,'snapshot-write-bound')
        with (PRIVATE/'before.json').open('xb') as f:os.fchmod(f.fileno(),0o600);f.write(raw)
        result['retained_snapshot_created']=True
    elif PHASE=='after':
        (PRIVATE/'before.json').unlink();PRIVATE.rmdir();result['retained_snapshot_removed']=True
    require(selected()==before,'unrelated-selected-state-changed');result['selected_state_equal']=True
    require(members()==result['members_before'],'installed-members-changed');result['stable_state_equal']=True
    result['status']='PASS'
except BaseException as exc:result['error']=type(exc).__name__+': '+str(exc)
finally:
    signal.alarm(25)
    if service_owned:
        try:stop_service()
        except BaseException as exc:result['cleanup_errors'].append(type(exc).__name__+': '+str(exc));result['status']='FAIL'
    signal.alarm(0)
    if any(same(r) for r in known):result['cleanup_errors'].append('owned-daemon-survivor');result['status']='FAIL'
    result['remaining_daemon_identities']=[r for r in known if same(r)]
    if any(r.get('timed_out') or r.get('output_limit') or r.get('forced_cleanup') or r['original_returncode']!=0 and not r.get('accepted_starting_state') for r in result['commands']):result['status']='FAIL'
    original=json.dumps(raw_commands,separators=(',',':')).encode();report=json.dumps(result,separators=(',',':')).encode()
    require(len(original)<=512*1024 and len(report)<=128*1024,'final-record-bound')
    require(4*((len(original)+2)//3)+4*((len(report)+2)//3)+64<=1024**2,'emitted-record-bound')
    print('PIX_ZT_PRIVATE='+base64.b64encode(original).decode(),flush=True)
    print('PIX_ZT_REPORT='+base64.b64encode(report).decode(),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)

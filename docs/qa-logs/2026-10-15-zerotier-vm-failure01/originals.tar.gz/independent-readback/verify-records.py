from pathlib import Path,PurePosixPath
import datetime,hashlib,json,tarfile
O=Path(__file__).parent;E=Path('/workspace/tmp/pix-m7-zt-clean-evidence-20261015-01');P=Path('/tmp/pix-m7-zerotier-vm-proof-20261015-02');R=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03/.build-runs/20261015T165025Z-aed92d8e')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
assert h(P/'SHA256SUMS')=='fb970d76a9ad429ee9fe0b4e4c88181f6b14602193318a3acc6635a516108736'
for line in (P/'SHA256SUMS').read_text().splitlines():
 sha,name=line.split('  ',1);assert h(P/name)==sha
rows=j(E/'original-records.json');exp=j(E/'export-result.json');private=j(E/'private-originals-held.json');rr=j(R/'runner-result.json');cons=j(R/'admission-consumed.json');draft=j(E/'consumption-draft.json');vm=j(E/'vm-result.json');host=j(E/'host-exits.json')
assert exp['original_channels']=={'launcher':1,'tool_wrapper':1,'build':1,'command':1,'monitor':0,'runner':1,'vm':1}
assert exp['files']==len(rows)==79 and exp['bytes']==sum(x['bytes'] for x in rows)==397415 and exp['private_settings_or_account_values_exported'] is False and exp['acceptance_claimed'] is False
assert (rr['command_rc'],rr['monitor_rc'],rr['runner_rc'])==(1,0,1) and cons['original_result']==rr and cons['state']=='consumed' and cons['id']=='5a8da1a9fe9f4c23acd0b5d928801513'
assert cons['evidence_sha256']==h(E/'consumption-draft.json') and cons['pid_namespace']==4026531836
assert draft['disposition']=='failed-investigated' and draft['expected_rc']==1 and draft['run']==str(R)
for e in draft['evidence']:assert Path(e['path']).parent==E and h(e['path'])==e['sha256']
assert len(private['files'])==3
for x in private['files']:
 p=PurePosixPath(x['path']);assert 'private' in p.parts or ('-zerotier-' in p.name and p.suffix in ['.stdout','.stderr'])
assert host['status']=='OWNERS_GONE' and host['channels_coherent'] and host['host_pid_namespace']==4026531836 and host['original_channels']==exp['original_channels']
assert vm['rc']==1 and not vm['cleanup_errors'] and not vm['forced_host_cleanup'] and not vm['remaining_host_children'] and not vm['surviving_host_processes'] and not vm['qemu_still_live']
nested=[]
with tarfile.open(E/'original-records.tar.gz') as tf:
 members=tf.getmembers();assert len(members)==79 and len({m.name for m in members})==79 and {m.name for m in members}=={x['path'] for x in rows}
 for row in rows:
  m=tf.getmember(row['path']);p=PurePosixPath(m.name)
  assert m.isfile() and not p.is_absolute() and '..' not in p.parts and 'private' not in p.parts
  assert not ('-zerotier-' in p.name and p.suffix in ['.stdout','.stderr'])
  data=tf.extractfile(m).read();assert len(data)==row['bytes']==m.size and hashlib.sha256(data).hexdigest()==row['sha256']
  nested.append({'member':m.name,'sha256':row['sha256'],'bytes':m.size,'mode':m.mode,'uid':m.uid,'gid':m.gid,'pax_headers':m.pax_headers,'header_mtime':m.mtime})
  if m.name.startswith('run/'):
   actual=R/p.relative_to('run');assert h(actual)==row['sha256']
 probe=json.loads(tf.extractfile('owner/records/zerotier-fresh.json').read());guest_exit=json.loads(tf.extractfile('owner/records/zerotier-fresh-exit.json').read());clean=json.loads(tf.extractfile('owner/clean/report.json').read());launcher=json.loads(tf.extractfile('owner/lifecycle-owner/launcher-result.json').read())
 assert launcher['runner_returncode']==1 and probe['status']=='FAIL' and probe['error']=='RuntimeError: network-membership-present'
 assert guest_exit['reported_statuses']==['1'] and guest_exit['transport_returncode']==0
 assert clean['status']=='pass' and clean['mode']=='first-boot' and clean['blocked_count']==clean['error_count']==0
 assert any(x.get('category')=='boot-ready' and x.get('status')=='clear' and x.get('present') is True for x in clean['checks'])
 assert probe['daemon_stopped'] and not probe['cleanup_errors'] and not probe['remaining_daemon_identities']
 assert probe['cli_checks']==[{'version':'1.16.0','online':False,'network_count':0}]
 assert len(probe['commands'])==10 and all(not x['timed_out'] and not x['output_limit'] for x in probe['commands'])
 assert sum(x['original_returncode']==2 and x.get('accepted_starting_state') for x in probe['commands'])==2
 assert all(x['original_returncode']==0 or x.get('accepted_starting_state') for x in probe['commands'])
 assert (P/'fresh/guest.py').read_bytes()==tf.extractfile('owner/guest.py').read()
 rootobs=Path('/tmp/pix-m7-zt-clean-coordinator-20261015')
 for stage in ['prepare','preflight','report','admit','launch','close','consume']:assert j(rootobs/(stage+'.exit.json'))['original_tool_exit']==0
 rep=Path((rootobs/'report.stderr').read_text().strip().removeprefix('watch-build: recording in '));represult=j(rep/'runner-result.json');assert (represult['command_rc'],represult['monitor_rc'],represult['runner_rc'])==(0,0,0)
receipt={'status':'PASS_SANITIZED_EXPORT_AND_ORIGINAL_FAILURE_READBACK','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_seal':h(P/'SHA256SUMS'),'original_result':rr,'consumed_sha256':h(R/'admission-consumed.json'),'consumed_id':cons['id'],'sanitized_export_tar_sha256':h(E/'original-records.tar.gz'),'nested_members':nested,'private_original_bodies_read':0,'private_original_hash_rows':len(private['files']),'guest_original_status':guest_exit,'clean_status':{k:clean[k] for k in ['status','mode','blocked_count','error_count']},'probe_status':probe['status'],'probe_error':probe['error'],'cli_checks':probe['cli_checks'],'guest_service_stopped':True,'host_cleanup_original_clean':True,'new_process_census':False,'retention_report_run':str(rep),'retention_report_original_result':represult,'acceptance_claimed':False,'limitation':'Sanitized originals only. No private command/serial bodies, guest disk, identity/account/configuration values or source payloads opened. Directory-existence diagnosis is root interpretation of the original combined assertion, not extra guest observation.'}
(O/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'nested_members':79,'private_bodies_read':0,'receipt_sha256':h(O/'record-readback.json')}))

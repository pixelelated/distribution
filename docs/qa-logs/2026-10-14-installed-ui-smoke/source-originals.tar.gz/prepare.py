#!/usr/bin/env python3
"""Bind a fresh source-only derivative to the completed final SYSTEM receipt."""
import argparse,ast,hashlib,json,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
MEMBERS=['usr/bin/emulationstation','usr/bin/cloud_oauth','usr/bin/cloud-signin-window','usr/bin/rclone','usr/bin/wifictl','usr/bin/gst-inspect-1.0','usr/lib/gstreamer-1.0/gst-plugin-scanner','usr/lib/gstreamer-1.0/libgstopengl.so','usr/lib/libgstcontroller-1.0.so.0','usr/lib/libgstreamer-1.0.so.0','usr/config/locale/fr/LC_MESSAGES/emulationstation2.mo','usr/config/locale/en_GB/LC_MESSAGES/emulationstation2.mo']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--image-verification',type=Path,required=True);p.add_argument('--ssh-command',type=Path,required=True);p.add_argument('--monitor',type=Path,required=True);p.add_argument('--playwright-python',type=Path,required=True);p.add_argument('--chromium',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 report=json.loads(a.image_verification.read_text());assert report['status']=='PASS' and report['source']=='d6a87f05c1935516115b2cca1af22151a0209224' and report['es_commit']=='3178b832b8d134198b2b4eede4f725d4ed283f8c'
 members={x:report['products'][x] for x in MEMBERS}
 ssh=json.loads(a.ssh_command.read_text());assert isinstance(ssh,list) and ssh[0]=='ssh' and ssh[-1]=='root@127.0.0.1'
 assert a.playwright_python.is_file() and a.chromium.is_file();assert not a.out.exists()
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert digest(HERE/n)==h,n
 for name,h in json.loads((HERE/'dependencies.json').read_text()).items():assert digest(Path(name))==h,name
 a.out.mkdir(mode=0o700);(a.out/'vm').mkdir();(a.out/'vm/monitor.sock').symlink_to(a.monitor.resolve());(a.out/'ssh-command.json').write_text(json.dumps(ssh)+'\n')
 for x in ['ui.py','run.py','guest-preflight.py','config-custody.py','phone-smoke.py','phone-installed-client04.py','fake-rclone-phone03','wifi-initial.py','wifi-smoke.py','recent-smoke.py']:
  shutil.copyfile(HERE/x,a.out/x)
 (a.out/'binding.json').write_text(json.dumps({'status':'PREPARED_UNRUN','source':report['source'],'es_source':report['es_commit'],'members':members,'verification':{'path':str(a.image_verification.resolve()),'sha256':digest(a.image_verification)},'playwright_python':str(a.playwright_python.absolute()),'chromium':str(a.chromium.resolve()),'chromium_sha256':digest(a.chromium),'seams':['synthetic rclone authorize/lsd; actual installed config/listremotes/version delegation','synthetic wifictl enumeration; no radio claim']},indent=2)+'\n')
 print(str(a.out/'run.py'))
if __name__=='__main__':main()

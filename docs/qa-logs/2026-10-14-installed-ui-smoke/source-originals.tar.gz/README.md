# Installed final-image UI continuation — UNRUN

This is a narrow derivative of accepted actual setup flows, not a new UI matrix.
Canonical originals are `2026-10-13-setup-qualification/installed` (completed
October13) and the October14 bb9e French Wi-Fi follow-up in `2026-10-13-library-vm`.
Preserve their source-bound reviewed frames and original exits. All four relevant
bb9e frontend source files match final ES3178 byte-for-byte. Current cloud_oauth
matches the accepted installed95c626f8 source. The French catalog delta is three
separately accepted save descriptions plus separately accepted #566 rejection
copy, not the browser/phone/Wi-Fi/Recent strings. See applicability.json and
catalog-delta.txt. No full old frame matrix, sanitizer, constrained-memory
comparison, ScreenScraper fixture, #349 archive control or provider login repeats.

New composed-image smoke, once at standard EN640, is:

1. Before seams: exact final installed member/mode readback, active catalog
   equality, actual browser/scanner `ldd`, controller/core/opengl RTLD_NOW load,
   fresh default GStreamer registry plus installed `gst-inspect-1.0 opengl`.
   No GST_PLUGIN_SCANNER or library overlay. This proves loader/registry closure;
   it does not claim a separately traced scanner child execution.
2. Normal frontend→real browser→phone first571 input→real WebKit navigation→
   second571 input→clean frontend return, same ES PID/start/boot, connected stable
   phone geometry, actual browser log. Accepted loopback synthetic authorize/lsd
   seam only; config/listremotes/version delegate to exact installed rclone copy,
   with explicit read-only delegation controls and hash receipts. No authenticated
   provider claim. ES, catalogs, cloud_oauth and browser are never replaced.
3. Existing synthetic Wi-Fi initial/search, refresh and failure-retains-rows;
   three original scan results0,0,2, same frontend/boot. No radio claim, and this
   enumeration seam does not itself exercise installed wifictl's nmcli backend.
4. Three actual installed Recent/API cases: default ROM-only, default synthetic
   history, retained Favorites-only. Existing fixture bytes; no game launched.

The only allowed transient file binds are `/usr/bin/rclone` (synthetic transport)
and `/usr/bin/wifictl` (synthetic enumeration). Both are restored and exact product
bytes/modes rechecked; original configuration bytes/types/modes restored from a
private guest tar before restarting ES. No proxy action. Original config archive
and synthetic data remain only on the disposable guest until its owner retires it;
retain receipts rather than exporting private raw configuration. Prior owner
results and protected image/build inputs are unchanged.

Source preparation requires the coordinator's completed final artifact receipt,
with `status=PASS`, `source=d6a87...`, `es_commit=3178...` and `products` entries
(bytes/hash/mode/link chain) for every path in prepare.py MEMBERS. Add those
selected members to the existing verifier's final install→SYSTEM equality pass;
do not extract a second full root. Shipped catalogs are `/usr/config/locale/...`;
`/usr/share/locale` points into storage, and the active storage copies must agree.
The known host Playwright interpreter/browser paths below exist; no import,
version probe or browser launch was performed during preparation.

```bash
PACKET=/tmp/pix-m7-installed-ui-smoke-20261014
python3 "$PACKET/prepare.py" \
  --image-verification "$VERIFY/result.json" \
  --ssh-command "$VM_OWNER/ssh-command.json" \
  --monitor "$VM_OWNER/vm/monitor.sock" \
  --playwright-python /tmp/pixelelated-import-qa-venv/bin/python \
  --chromium /home/max/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome \
  --out "$OWNER/smoke"
```

Coordinator binds those variables to fresh owned paths, the verified new image,
and an already admitted default-boot8GiB/4CPU640×480 guest. Run untouched clean
proof first. Provision only its QA SSH key; do not use the old provision.py, which
installs an ES/catalog overlay. This smoke requires the default user-mode guest
address10.0.2.15 and its host→guest SSH channel. The phone SSH tunnel uses owned
loopback18080; authorization pages/listeners are guest loopback53682. Assert those
ports are free before allocation. The GB directory must be empty: run this before
baseline game/time-to-play fixtures, or use a fresh disposable clean guest. A
retained user's library is not an input. This script does not create/stop a VM.

Under that existing VM admission and900-second outer work owner (+60seconds
cleanup), use the usual noncompiling watched child after the build has ended:

```bash
cd /workspace/repos/rocknix.worktrees/m7-p5-build-20261014-01
tools/watch-build-submit --owner "$OWNER" -- \
  --record-only --activity-dir "$OWNER/smoke" --recursive-activity -- \
  python3 "$OWNER/smoke/run.py"
```

`--record-only` records the child under an already admitted VM lifecycle; it does
not replace admission or authorize another VM. Preserve child original statuses
and separate timeout/output-guard indications. Stages are bounded60/210/90/90/210s;
128MiB/1024 host output-file guard samples every250ms while each stage runs. Existing
outer VM/process/host-memory guard and final process census remain the owner.
The runner restores config and product mounts in finally and stops at first
failure. A hard kill or lost SSH is not successful cleanup: retire only after
actual VM/child closure. This is source-only; commands above remain UNRUN.

Keep binding.json, result.json, original stage stdout/stderr, loader-result,
configuration-restored, phone/Recent/Wi-Fi case JSON and compact reviewed new
first-frame/return captures. These are composition readbacks, not replacement
baselines for the previously accepted complete frame sets.

Generic installed baseline and time-to-play need no new fixture. In the admitted
networked generic baseline owner with normal `VM_PAIR_DIR`, `VM_QEMU_RUNTIME_DIR`,
`ROCKNIX_ARTIFACTS` and local backend environment:

```bash
# Existing standard baseline; needs both admitted guests for pair-identity.
tools/vm-qa --skip-up "$IMAGE"
# If standard already covers round-trip/exit/time-to-play, do not repeat them.
# Existing single retained-guest follow-through after actual update:
tools/vm-qa --skip-up --only fresh,round-trip,exit,time-to-play --backend webdav "$IMAGE"
# Time-to-play alone only when its same-image row is missing:
tools/vm-qa --skip-up --only time-to-play --backend webdav "$IMAGE"
```

vm-qa's time-to-play invocation uses `--quick --vm`: one launch/exit/game-to-game
repeat, no reboot/host-fixture campaign. It seeds the owned local remote when needed
and preserves original timing JSON/Markdown/frames. Reuse `qa-plan/run.py` and
retained original run.py ownership/finally structure from replacement19; do not
execute their old frozen paths/image variables verbatim. The new source/build
root supplies ES_SRC/RETROARCH_SRC/QA_SYSTEM_ROOT; final installed output and owner
exits are authoritative. Existing backend/VM stop, process census and original
aggregate handling remain mandatory; no new full-suite requirement is introduced.

Cached local MinIO resolved by read-only host `docker image inspect`:

```bash
export CLOUD_QA_IMAGE=sha256:14cea493d9a34af32f524e538b8346cf79f3321eff8e708c1e2960462bd8936e
# Equivalent RepoDigest:
# quay.io/minio/minio@sha256:14cea493d9a34af32f524e538b8346cf79f3321eff8e708c1e2960462bd8936e
```

Image created2025-09-07T18:42:37.017942402Z. cloud-test-backend line118 reads this
override and both S3 branches pass it directly to Docker. Use a fresh owned
CLOUD_QA_NAME: an existing running name is reused without image revalidation.
No pull, run, backend/service start, VM, compiler or product/shared edit occurred.

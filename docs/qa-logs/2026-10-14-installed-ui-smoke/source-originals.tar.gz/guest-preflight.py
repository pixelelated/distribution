#!/usr/bin/python3
"""Installed loader/readback before synthetic transport/enumeration binds."""
import ctypes,hashlib,json,os,subprocess,sys,stat
from pathlib import Path
binding=json.loads(Path('/storage/qa570flows/binding.json').read_text());rows={}
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
for rel,expected in binding['members'].items():
 p=Path('/')/rel;assert p.is_file() and sha(p)==expected['sha256'] and stat.filemode(p.stat().st_mode)==expected['mode'],rel
 rows[rel]={'sha256':sha(p),'realpath':str(p.resolve()),'mode':oct(p.stat().st_mode&0o777)}
for target in ['/usr/bin/emulationstation','/usr/bin/cloud_oauth','/usr/bin/cloud-signin-window','/usr/bin/rclone','/usr/bin/wifictl', '/usr/lib/gstreamer-1.0/gst-plugin-scanner','/usr/lib/libgstcontroller-1.0.so.0']:
 assert not any(line.split()[4]==target for line in Path('/proc/self/mountinfo').read_text().splitlines()),'pre-existing bind: '+target
for lang in ['fr','en_GB']:
 rel='usr/config/locale/'+lang+'/LC_MESSAGES/emulationstation2.mo'
 assert sha(Path('/storage/.config/locale')/lang/'LC_MESSAGES/emulationstation2.mo')==binding['members'][rel]['sha256'],'active catalog mismatch'
# Direct RTLD_NOW loading exercises actual installed dependency resolution.
for lib in ['libgstcontroller-1.0.so.0','libgstreamer-1.0.so.0','/usr/lib/gstreamer-1.0/libgstopengl.so']:ctypes.CDLL(lib,mode=os.RTLD_NOW)
checks=[]
for target in ['/usr/bin/cloud-signin-window','/usr/lib/gstreamer-1.0/gst-plugin-scanner']:
 p=subprocess.run(['ldd',target],capture_output=True,text=True,timeout=15);checks.append({'argv':['ldd',target],'original_returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0 and 'not found' not in p.stdout+p.stderr,target
registry=Path('/storage/qa570flows/gst-registry.bin');assert not registry.exists()
env=dict(os.environ,GST_REGISTRY=str(registry))
for key in ['GST_PLUGIN_SCANNER','GST_PLUGIN_PATH','GST_PLUGIN_SYSTEM_PATH','GST_REGISTRY_FORK']:env.pop(key,None)
p=subprocess.run(['/usr/bin/gst-inspect-1.0','opengl'],env=env,capture_output=True,text=True,timeout=30);checks.append({'argv':['gst-inspect-1.0','opengl'],'original_returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0 and registry.is_file();assert 'Failed to load plugin' not in p.stderr and 'External plugin loader failed' not in p.stderr
Path('/storage/qa570flows/loader-result.json').write_text(json.dumps({'status':'PASS','members':rows,'checks':checks,'scanner_scope':'installed executable/default registry and ldd closure; no separate scanner child-exec trace claimed'},indent=2)+'\n')
print('PASS installed loader, controller/opengl and default GStreamer registry')

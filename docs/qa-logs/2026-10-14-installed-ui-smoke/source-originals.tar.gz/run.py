#!/usr/bin/env python3
"""One admitted final-image smoke; no VM launch and no installed product overlay."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time,traceback
from ui import remote,out
R=Path(__file__).resolve().parent;B=json.loads((R/'binding.json').read_text());rows=[];prepared=False;backup_ready=False;seams_allowed=False
result={'status':'FAIL','started':time.time(),'stages':rows,'binding_sha256':hashlib.sha256((R/'binding.json').read_bytes()).hexdigest()}
def write(): (R/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def stage(name,argv,bound):
 row={'name':name,'argv':argv,'started':time.time(),'timed_out':False};rows.append(row);write()
 with (R/(name+'.stdout')).open('wb') as f,(R/(name+'.stderr')).open('wb') as e:
  child=subprocess.Popen(argv,stdout=f,stderr=e,start_new_session=True)
  end=time.monotonic()+bound
  try:
   while child.poll() is None:
    files=[p for p in R.rglob('*') if p.is_file() and not p.is_symlink()]
    total=sum(p.stat().st_size for p in files)
    if time.monotonic()>end or total>128*1024**2 or len(files)>1024:
     row['timed_out']=time.monotonic()>end;row['output_guard']=total>128*1024**2 or len(files)>1024;break
    time.sleep(.25)
  except BaseException as error:row['observer_error']=str(error)
  finally:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3)
   rc=child.wait()
 row.update(original_returncode=rc,ended=time.time());write();assert rc==0 and not row['timed_out'] and not row.get('output_guard',False) and not row.get('observer_error'),name

def idle():
 end=time.monotonic()+45
 while time.monotonic()<end:
  if out('curl -fsS http://127.0.0.1:1234/isIdle 2>/dev/null || true').replace(' ','').strip()=='[true]':return
  time.sleep(.5)
 raise RuntimeError('frontend readiness')
def verify_products():
 data=out("python3 - <<'P'\nimport hashlib,json,stat\nfrom pathlib import Path\nb=json.loads(Path('/storage/qa570flows/binding.json').read_text());print(json.dumps({n:{'sha256':hashlib.file_digest((Path('/')/n).open('rb'),'sha256').hexdigest(),'mode':stat.filemode((Path('/')/n).stat().st_mode)} for n in b['members']}))\nP")
 facts=json.loads(data);assert all(facts[n]['sha256']==v['sha256'] and facts[n]['mode']==v['mode'] for n,v in B['members'].items());return facts
assert not (R/'result.json').exists(),'fresh owner required'
try:
 assert out('cloud_oauth status').strip()=='idle'
 assert out('test ! -e /storage/qa570flows && test ! -e /storage/qa-wifi-577-setup && test ! -e /storage/qa-library-578 && echo fresh').strip()=='fresh'
 assert not out('find /storage/roms/gb -type f').strip(),'requires empty disposable GB library'
 remote('mkdir -m700 /storage/qa570flows',capture_output=True);prepared=True
 for name in ['binding.json','guest-preflight.py','config-custody.py']:
  with (R/name).open('rb') as f:remote('cat > /storage/qa570flows/'+name,stdin=f,capture_output=True)
 remote('python3 /storage/qa570flows/config-custody.py snapshot',capture_output=True);backup_ready=True
 stage('loader',json.loads((R/'ssh-command.json').read_text())+['. /etc/profile >/dev/null 2>&1; python3 /storage/qa570flows/guest-preflight.py'],60)
 (R/'loader-result.json').write_text(out('cat /storage/qa570flows/loader-result.json'))
 result['before']=verify_products();seams_allowed=True;result['boot_id']=out('cat /proc/sys/kernel/random/boot_id').strip()
 remote('cp /usr/bin/rclone /storage/qa570flows/rclone-original; chmod 755 /storage/qa570flows/rclone-original',capture_output=True)
 assert out('sha256sum /storage/qa570flows/rclone-original').split()[0]==B['members']['usr/bin/rclone']['sha256']
 # Normal real browser handoff, real bridge input across navigation, clean return.
 # The only authority is this fresh disposable synthetic guest; reset only private test remotes.
 remote('rm -f /storage/.config/rclone/rclone.conf /storage/.config/rclone/active-connection',capture_output=True)
 stage('phone',['python3',str(R/'phone-smoke.py'),'phone-final-en640','phone','en_US'],210)
 result['after_phone']=verify_products()
 remote('systemctl stop essway.service; . /etc/profile >/dev/null 2>&1; set_setting system.language en_US; systemctl start essway.service',capture_output=True);idle()
 stage('wifi-initial',['python3',str(R/'wifi-initial.py')],90)
 stage('wifi-refresh-failure',['python3',str(R/'wifi-smoke.py')],90)
 remote('umount /usr/bin/wifictl',capture_output=True);result['after_wifi']=verify_products()
 stage('recent',['python3',str(R/'recent-smoke.py')],210)
 assert out('cat /proc/sys/kernel/random/boot_id').strip()==result['boot_id'];result['status']='PASS'
except BaseException as error:result['error']=str(error);traceback.print_exc()
finally:
 if prepared:
  try:
   remote('cloud_oauth cancel >/dev/null 2>&1; systemctl stop essway.service',capture_output=True)
   cleanup="""import json,subprocess,shutil,tarfile
from pathlib import Path
for target in (['/usr/bin/rclone','/usr/bin/wifictl'] if ALLOW_OWNED_SEAMS else []):
 matches=[x for x in Path('/proc/self/mountinfo').read_text().splitlines() if x.split()[4]==target]
 if matches:
  assert len(matches)==1,target
  subprocess.run(['umount',target],check=True)
for p in Path('/storage/roms/gb').rglob('*'):
 if p.is_file():
  assert p.name in ['pixelelated-library-setup.gb','gamelist.xml','gamelist.xml.bak','gamelist.xml.tmp'],str(p)
  p.unlink()
assert not subprocess.run(['pidof','cloud-signin-window'],capture_output=True).stdout.strip()
if ALLOW_OWNED_SEAMS:assert not any(x.split()[4] in ['/usr/bin/rclone','/usr/bin/wifictl'] for x in Path('/proc/self/mountinfo').read_text().splitlines())
print('PASS owned seam mounts absent; browser absent')
"""
   (R/'cleanup.stdout').write_text(out("python3 - <<'P'\n"+'ALLOW_OWNED_SEAMS='+repr(seams_allowed)+'\n'+cleanup+"\nP"));result['restored_products']=verify_products()
   if backup_ready:
    remote('python3 /storage/qa570flows/config-custody.py restore',capture_output=True)
    (R/'configuration-restored.json').write_text(out('cat /storage/qa570flows/configuration-restored.json'))
   remote('systemctl start essway.service',capture_output=True);idle();result['cleanup']='PASS'
  except BaseException as error:result['cleanup_error']=str(error);result['status']='FAIL';traceback.print_exc()
 result['ended']=time.time();write()
raise SystemExit(0 if result['status']=='PASS' else 1)

#!/bin/bash
set -euo pipefail
python3 -I /build-owner/container-ready.py
./scripts/checkdeps
make H700

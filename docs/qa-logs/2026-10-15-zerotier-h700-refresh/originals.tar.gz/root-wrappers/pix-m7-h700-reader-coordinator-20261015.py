from pathlib import Path
import hashlib,json,subprocess,sys,os
R=Path('/tmp/pix-m7-h700-reader-coordinator-20261015');R.mkdir(exist_ok=True)
P=Path('/tmp/pix-m7-zerotier-h700-refresh-20261015/readback');T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05');O=Path('/workspace/tmp/pix-m7-zerotier-h700-readback-20261015-01')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(P/'SHA256SUMS')=='f76aaedb49b74e332bc34abcd1c3f8df8ea73da6cd24575f79d64d1fa3b1e818'
for ln in (P/'SHA256SUMS').read_text().splitlines():h,n=ln.split('  ',1);assert sha(P/n)==h,n
stage=sys.argv[1]
if stage=='prepare':O.mkdir(mode=0o700);cmd=['python3','-I',str(P/'prepare-readback.py'),'--owner',str(O)]
elif stage=='preflight':cmd=['tools/build-preflight']
elif stage=='report':cmd=['tools/watch-build','--record-only','--','python3','-I','tools/host-maintenance/retention-report','--plan',str(O/'retention-plan.json'),'--output',str(O/'retention-report.json')]
elif stage=='admit':cmd=['python3','-I','tools/host-maintenance/build-admission','prepare','--plan',str(O/'admission-plan.json'),'--output',str(O/'admission.json')]
elif stage=='launch':cmd=['tools/watch-build-submit','--owner',str(O),'--','--admission',str(O/'admission.json'),'--','bash',str(O/'run.sh')]
elif stage=='consume':cmd=['python3','-I',str(P/'consume-readback.py'),'--owner',str(O)]
else:raise ValueError(stage)
env=os.environ.copy();env.update(PROJECT='ROCKNIX',DEVICE='H700',ARCH='aarch64')
with (R/(stage+'.stdout')).open('xb') as out,(R/(stage+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=T,env=env,stdout=out,stderr=err)
with (R/(stage+'.exit.json')).open('x') as f:json.dump({'original_tool_exit':p.returncode,'argv':cmd},f)
print(json.dumps({'stage':stage,'original_tool_exit':p.returncode,'stdout':str(R/(stage+'.stdout'))}));sys.exit(p.returncode)

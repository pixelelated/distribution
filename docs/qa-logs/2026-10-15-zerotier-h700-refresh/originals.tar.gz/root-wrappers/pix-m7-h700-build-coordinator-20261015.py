from pathlib import Path
import hashlib,json,subprocess,sys,os
R=Path('/tmp/pix-m7-h700-build-coordinator-20261015');R.mkdir(exist_ok=True)
P=Path('/tmp/pix-m7-zerotier-h700-refresh-20261015/build');T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05');O=Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(P/'SHA256SUMS')=='ffb8e3e328292a18eb4437e21f8c0bdc1962d04d69f51ef6227004e3b89d0246'
for ln in (P/'SHA256SUMS').read_text().splitlines():h,n=ln.split('  ',1);assert sha(P/n)==h,n
stage=sys.argv[1]
base=['--checkout',str(T),'--commit','077197e6cd3ea31f33b28aaf3882a694b3423b53','--es-recipe-sha256','1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719','--expected-es','16dbac5211eea7e70db7394372033be2be7df829','--owner',str(O)]
if stage=='prepare':
 O.mkdir(mode=0o700);cmd=['python3','-I',str(P/'prepare-owner.py'),*base,'--cache-ready','/workspace/tmp/pix-m7-zerotier-h700-transfer-aarch64-20261015-01/cache-ready.json','--arm-cache-ready','/workspace/tmp/pix-m7-zerotier-h700-transfer-arm-20261015-01/cache-ready.json','--timestamp','20261015T161744Z','--family-seconds','7200']
elif stage=='plan':cmd=['python3','-I',str(P/'prepare-plan.py'),'--owner',str(O)]
elif stage=='preflight':cmd=['tools/build-preflight']
elif stage=='report':cmd=['tools/watch-build','--record-only','--','python3','-I','tools/host-maintenance/retention-report','--plan',str(O/'retention-plan.json'),'--output',str(O/'retention-report.json')]
elif stage=='admit':cmd=['python3','-I','tools/host-maintenance/build-admission','prepare','--plan',str(O/'admission-plan.json'),'--output',str(O/'admission.json')]
elif stage=='launch':cmd=['tools/watch-build-submit','--owner',str(O),'--','--admission',str(O/'admission.json'),'--','python3','-I',str(O/'build-owner.py')]
elif stage=='consume':cmd=['python3','-I',str(P/'consume-stage.py'),'--owner',str(O),'--stage','build']
else:raise ValueError(stage)
env=os.environ.copy();env.update(PROJECT='ROCKNIX',DEVICE='H700',ARCH='aarch64')
with (R/(stage+'.stdout')).open('xb') as out,(R/(stage+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=T,env=env,stdout=out,stderr=err)
with (R/(stage+'.exit.json')).open('x') as f:json.dump({'original_tool_exit':p.returncode,'argv':cmd},f)
print(json.dumps({'stage':stage,'original_tool_exit':p.returncode,'stdout':str(R/(stage+'.stdout'))}));sys.exit(p.returncode)

from pathlib import Path
import datetime,hashlib,json
OUT=Path(__file__).parent;P=Path('/tmp/pix-m7-zerotier-h700-refresh-20261015');BR=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05/.build-runs')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
seals=[]
for stage,seal in [('build','ffb8e3e328292a18eb4437e21f8c0bdc1962d04d69f51ef6227004e3b89d0246'),('readback','f76aaedb49b74e332bc34abcd1c3f8df8ea73da6cd24575f79d64d1fa3b1e818')]:
 p=P/stage;assert h(p/'SHA256SUMS')==seal;count=0
 for line in (p/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1);assert h(p/name)==expected;count+=1
 seals.append({'path':str(p),'seal':seal,'payloads':count})
rows=[]
for stage,runid,aid in [('build','20261015T170220Z-c0ac7fa6','86b33823b75a4db183c155af08821192'),('readback','20261015T170844Z-0f52627d','25b35fe5ba8c4a79a5a49e7cf53e5279')]:
 o=Path('/workspace/tmp/pix-m7-zerotier-h700-'+stage+'-20261015-01');r=BR/runid;runner=j(r/'runner-result.json');cons=j(r/'admission-consumed.json');ev=j(o/'consumption-evidence.json')
 assert (runner['command_rc'],runner['monitor_rc'],runner['runner_rc'])==(0,0,0) and cons['original_result']==runner and cons['state']=='consumed' and cons['id']==aid
 assert cons['pid_namespace']==4026531836 and cons['source']['head']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and cons['run']==str(r) and cons['submission_owner']==str(o)
 assert (o/'run.path').read_text().strip()==str(r) and cons['evidence_sha256']==h(o/'consumption-evidence.json') and ev['disposition']=='qualified' and ev['expected_rc']==0
 assert j(o/'launcher-result.json')['runner_returncode']==0
 for f in [o/'inner.rc',o/'tool-wrapper.rc',r/'build.rc']+([o/'outer.rc'] if stage=='readback' else []):assert f.read_text()=='0\n'
 for e in ev['evidence']:
  p=Path(e['path']);assert (p.is_relative_to(o) or p.is_relative_to(r)) and p.stat().st_size<2*1024**2 and h(p)==e['sha256']
 co=Path('/tmp/pix-m7-h700-'+('reader' if stage=='readback' else stage)+'-coordinator-20261015');rs=Path((co/'report.stderr').read_text().strip().removeprefix('watch-build: recording in '));rr=j(rs/'runner-result.json')
 assert (rr['command_rc'],rr['monitor_rc'],rr['runner_rc'])==(0,0,0)
 for step in ['prepare','report','admit','launch','consume']+(['plan'] if stage=='build' else ['preflight']):assert j(co/(step+'.exit.json'))['original_tool_exit']==0
 rows.append({'stage':stage,'run':str(r),'original_result':runner,'launcher_returncode':0,'consumed_id':aid,'consumed_utc':cons['consumed'],'consumed_sha256':h(r/'admission-consumed.json'),'evidence_sha256':h(o/'consumption-evidence.json'),'verified_compact_evidence_count':len(ev['evidence']),'retention_report_run':str(rs),'retention_report_result':rr})
b=Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01');r=Path('/workspace/tmp/pix-m7-zerotier-h700-readback-20261015-01');owner=j(b/'owner-result.json');resources=j(b/'resource-result.json')
assert owner['status']==resources['status']=='PASS' and all(not owner[k] for k in ['cleanup','signals']) and all(not x for x in owner['surviving_host_command_groups'].values()) and resources['errors']==[] and resources['all_threads_exited']
assert len(owner['stages'])==3 and {x['stage'] for x in owner['stages']}=={'clean-zerotier-one','build-zerotier-one','image'}
for s in owner['stages']:
 assert s['original_host_make_rc']==0 and s['container_observed'] and s['observation_handshake']
 x=j(b/'stages'/s['stage']/'inner-result.json');assert x['original_command_rc']==x['wrapper_rc']==0 and x['signals']==[]
for n in ['build-owner.py','inner-build.py','host-resources.py','container-ready.py','inside-build.sh']:assert h(b/n)==h(P/'build'/n)
a=r/'artifacts';accept=j(a/'acceptance.json');affected=j(a/'affected-products.json');staged=j(a/'affected-products-staged.json');installed=j(a/'installed-inclusion.json');state=j(a/'selected-state.stdout')
assert accept['result']==affected['result']==staged['result']==installed['result']=='PASS'
assert accept['distribution_commit']==affected['source']=='077197e6cd3ea31f33b28aaf3882a694b3423b53'
assert accept['producer_combined_run_returncode']==0 and accept['producer_consumed_sha256']==h(BR/'20261015T170220Z-c0ac7fa6/admission-consumed.json')
assert accept['producer_run']==str(BR/'20261015T170220Z-c0ac7fa6') and accept['reader_run']==str(BR/'20261015T170844Z-0f52627d')
assert accept['scratch_removed'] and accept['source_unchanged'] and accept['independent_bundle_inodes']
assert accept['bundle_manifest_sha256']=='a808df3dbffc6281b0bf698fbbbd97a526f16211d1195bcf13ebd5fccb7e3e5f' and (r/'candidate-bundle.path').read_text().strip()==accept['bundle']
assert accept['variants']==j(a/'payload-equality.json') and {x['variant'] for x in accept['variants']}=={'DDR3','DDR4'}
assert len({x['system_sha256'] for x in accept['variants']})==len({x['kernel_sha256'] for x in accept['variants']})==1
assert len(j(a/'arm-handoff.json'))==accept['arm_handoff_files']==186 and len(affected['products'])==19
assert state['status']=='pass' and state['mode']=='clean-image' and state['blocked_count']==state['error_count']==0 and (a/'selected-state.exit').read_text()=='0\n'
assert affected['special']['zerotier']['nonfree_absent'] and affected['special']['zerotier']['dependency_completeness_claim'] is False and affected['special']['zerotier']['dependency_file_count']==0 and affected['special']['zerotier']['target_execution'] is False
assert affected['special']['gstreamer_profile']['gst_plugins_good_selected'] is False and affected['special']['kernel']['recipe_version']=='7.2'
assert accept['host_checker']['sha256']==h(r/'host-checker/pixelelated-state-check')=='65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6'
co=Path('/tmp/pix-m7-h700-build-coordinator-20261015');assert j(co/'preflight.exit.json')['original_tool_exit']==1 and j(co/'reclaim-swap.exit.json')['original_tool_exit']==j(co/'preflight-after-reclaim.exit.json')['original_tool_exit']==0
assert 'READY: /swap.img active, priority -1, 8388604 KiB free' in (co/'reclaim-swap.stdout').read_text()
receipt={'status':'PASS_COMPACT_H700_BUILD_AND_ARTIFACT_RECORDS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_seals':seals,'runs':rows,'build_elapsed_seconds':owner['elapsed_seconds'],'resource_status':resources['status'],'acceptance_sha256':h(a/'acceptance.json'),'acceptance':accept,'affected_products':len(affected['products']),'installed_hash_rows':len(installed['sha256']),'arm_handoff_files':186,'selected_state':{k:state[k] for k in ['status','mode','blocked_count','error_count']},'initial_preflight_rc':1,'guarded_reclaim_rc':0,'fresh_preflight_rc':0,'cache_raw_firmware_candidate_bodies_read':False,'live_process_census':False,'scope':'Original compact records only; accepted artifact scope is not physical boot, target runtime, RC or publication qualification.'}
(OUT/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'receipt_sha256':h(OUT/'record-readback.json'),'original_runs':len(rows)}))

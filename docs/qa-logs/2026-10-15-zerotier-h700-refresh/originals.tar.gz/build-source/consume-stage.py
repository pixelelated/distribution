#!/usr/bin/env python3
"""Narrow derivative of the existing consume-stage: check originals, then normal admission consume."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

TREE = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05')
COMMIT = '077197e6cd3ea31f33b28aaf3882a694b3423b53'
OWNERS = {'build': Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01')}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def gone(receipt):
    path = Path('/proc') / str(receipt['pid']) / 'stat'
    try:
        fields = path.read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        return True
    return fields[0] == 'Z' or fields[19] != str(receipt['start_ticks'])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--owner', type=Path, required=True)
    p.add_argument('--stage', choices=list(OWNERS), required=True)
    a = p.parse_args()
    owner = a.owner.resolve(strict=True)
    assert Path.cwd().resolve() == TREE and owner == OWNERS[a.stage]
    run = Path((owner / 'run.path').read_text().strip())
    admission = json.loads((run / 'admission.json').read_text())
    assert admission['checkout'] == str(TREE) and admission['source']['head'] == COMMIT
    assert admission['submission_owner'] == str(owner) and admission['run'] == str(run)
    launcher = json.loads((owner / 'launcher-result.json').read_text())
    runner = json.loads((run / 'runner-result.json').read_text())
    assert launcher['runner_returncode'] == 0 and all(runner[k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
    assert (owner / 'tool-wrapper.rc').read_text().strip() == (run / 'build.rc').read_text().strip() == '0'
    assert gone(json.loads((owner / 'launcher-start.json').read_text()))
    files = [owner / 'launcher-result.json', owner / 'tool-wrapper.rc', run / 'runner-result.json', run / 'build.rc']
    if a.stage == 'transfer':
        result = json.loads((owner / 'transfer-result.json').read_text())
        ready = json.loads((owner / 'cache-ready.json').read_text())
        assert result == ready and result['status'] == 'PASS' and result['destination_head'] == COMMIT
        assert result['renamed'] and not result['copy_performed']
        assert result['before_identity'] == result['after_identity']
        assert not Path(result['old']).exists()
        st = Path(result['new']).stat()
        assert result['after_identity'] == {'device': st.st_dev, 'inode': st.st_ino}
        assert (owner / 'inner.rc').read_text().strip() == '0'
        files += [owner / name for name in ['transfer-result.json', 'cache-ready.json', 'inner.rc']]
    elif a.stage == 'build':
        result = json.loads((owner / 'owner-result.json').read_text())
        assert result['status'] == 'PASS' and not result['signals']
        assert not any(result['surviving_host_command_groups'].values())
        assert [r['stage'] for r in result['stages']] == ['clean-zerotier-one', 'build-zerotier-one', 'image']
        assert json.loads((owner / 'resource-result.json').read_text())['status'] == 'PASS'
        assert (owner / 'inner.rc').read_text().strip() == '0'
        assert gone(json.loads((owner / 'owner-start.json').read_text()))
        for row in result['stages']:
            assert row['original_host_make_rc'] == 0 and row['container_observed'] and row['observation_handshake']
            stage = owner / 'stages' / row['stage']
            inner = json.loads((stage / 'inner-result.json').read_text())
            assert inner['original_command_rc'] == inner['wrapper_rc'] == 0
            cid = (stage / 'container.cid').read_text().strip()
            check = subprocess.run(['docker', 'inspect', cid], capture_output=True, text=True, timeout=15)
            assert check.returncode != 0 and 'no such' in check.stderr.casefold()
            files += [stage / name for name in ['host-result.json', 'inner-result.json', 'container.cid']]
        groups = {int(g) for g in result['surviving_host_command_groups']}
        for path in Path('/proc').glob('[0-9]*/stat'):
            try:
                fields = path.read_text().rsplit(')', 1)[1].split()
                assert int(fields[2]) not in groups or fields[0] == 'Z', 'recorded host command group still live'
            except FileNotFoundError:
                continue
        files += [owner / name for name in ['owner-result.json', 'resource-result.json', 'inner.rc', 'build-inputs.json']]
    else:
        result = json.loads((owner / 'artifacts/result.json').read_text())
        assert result['status'] == 'PASS' and result['source'] == COMMIT and result['runtime_qualified'] is False
        assert result['zerotier']['nonfree_absent'] and result['zerotier']['target_execution'] is False
        files += [owner / 'artifacts/result.json', owner / 'artifacts/inputs.json', owner / 'inputs.json']
    proof = {'run': str(run), 'disposition': 'qualified', 'expected_rc': 0,
        'evidence': [{'path': str(f), 'sha256': sha(f)} for f in files], 'outputs': admission['outputs'],
        'scope': 'Successful original ' + a.stage + ' channels only; no runtime, ARM, RC or publication claim'}
    output = owner / 'consumption-evidence.json'
    with output.open('x') as f:
        json.dump(proof, f, indent=2); f.write('\n')
    subprocess.run(['python3', '-I', str(TREE / 'tools/host-maintenance/build-admission'), 'consume', '--run', str(run), '--evidence', str(output)], check=True)
    print('PASS consumed original ' + a.stage + '; outputs held')


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Materialize one reviewed build owner. Writes only small config/helpers; no launch."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

TEMPLATE_COMMIT = '2426f88aba0eaa51e448c42917ca80fde2972a16'
PRODUCT_PATHS = ['projects/ROCKNIX/packages/network/zerotier-one/package.mk', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch', 'projects/ROCKNIX/packages/tools/rocknix-abl/package.mk']
PRODUCT_SHA256 = {'projects/ROCKNIX/packages/network/zerotier-one/package.mk': 'b876990db897995a230330a78704e16ad881e5424f6ff172fee9d7f2203a1aba', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch': '5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5', 'projects/ROCKNIX/packages/tools/rocknix-abl/package.mk': '6b07c262b11e8cc3fd45e8097b7fdb06a1f612cb31008daafdc3ecf68f892b3c', 'projects/ROCKNIX/packages/ui/emulationstation/package.mk': '1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk': 'cc4e7458e99329518b30b7f78aa38e149d083427f3c8b7e22d7f5e1090d2479b'}
PRODUCT_ROOTS = ['packages', 'projects', 'config', 'scripts', 'distributions', 'Makefile']


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkout', required=True, type=Path)
    p.add_argument('--commit', required=True)
    p.add_argument('--es-recipe-sha256', required=True, help='Reviewed unchanged ES recipe SHA256; ZeroTier recipe and patch hashes are sealed in this packet')
    p.add_argument('--expected-es', required=True, help='Exact reviewed ES commit required in the frozen distribution recipe')
    p.add_argument('--owner', required=True, type=Path)
    p.add_argument('--cache-ready', required=True, type=Path, help='Consumed AArch64 cache-ready')
    p.add_argument('--arm-cache-ready', required=True, type=Path)
    p.add_argument('--timestamp', required=True)
    p.add_argument('--family-seconds', type=int, default=7200)
    a = p.parse_args()
    tree, owner, cache = a.checkout.resolve(strict=True), a.owner.resolve(strict=True), a.cache_ready.resolve(strict=True)
    assert re.fullmatch('[0-9a-f]{40}', a.commit)
    assert a.commit == '077197e6cd3ea31f33b28aaf3882a694b3423b53', 'exact reviewed published source required'
    assert re.fullmatch('[0-9a-f]{64}', a.es_recipe_sha256)
    product_sha256 = dict(PRODUCT_SHA256)
    assert a.es_recipe_sha256 == PRODUCT_SHA256['projects/ROCKNIX/packages/ui/emulationstation/package.mk']
    assert a.expected_es == '16dbac5211eea7e70db7394372033be2be7df829', 'reviewed #593 ES source required'
    assert re.fullmatch('[0-9]{8}T[0-9]{6}Z', a.timestamp)
    datetime.datetime.strptime(a.timestamp, '%Y%m%dT%H%M%SZ')
    assert a.family_seconds == 7200
    assert not re.search(r'\s|[\x00\n`$]', str(owner) + str(tree))
    assert subprocess.check_output(['git', '-C', str(tree), 'rev-parse', 'HEAD'], text=True).strip() == a.commit
    assert subprocess.check_output(['git', '-C', str(tree), 'branch', '--show-current'], text=True).strip() == 'build/m7-pixelelated-h700-05'
    assert not subprocess.check_output(['git', '-C', str(tree), 'status', '--porcelain'], text=True).strip()
    recipe = tree / 'projects/ROCKNIX/packages/ui/emulationstation/package.mk'
    recipe_bytes = recipe.read_bytes()
    assert re.findall(r'^\s*PKG_VERSION=(.*)$', recipe_bytes.decode(), re.M) == ['"' + a.expected_es + '"'], 'expected exact ES pin missing or ambiguous'
    es_recipe_sha256 = hashlib.sha256(recipe_bytes).hexdigest()
    assert owner == Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01')
    assert sha(Path('/home/max/.ROCKNIX/options')) == '2cf98cb38836f56f7a6d42ca1c1a5327bb743c98adb42b41831128d475922e7d'
    assert not (owner / 'build-inputs.json').exists()
    assert not (owner / 'launcher-submission.json').exists()
    cpus = sorted(os.sched_getaffinity(0))
    # Never exceed the completed predecessor's admitted 24-CPU image budget.
    assert set(range(24)).issubset(cpus)
    cpus = list(range(24))
    assert str(tree) == '/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05'
    assert set(subprocess.check_output(['git', '-C', str(tree), 'diff', '--name-only', TEMPLATE_COMMIT, a.commit, '--', *PRODUCT_ROOTS], text=True).splitlines()) <= {'projects/ROCKNIX/packages/network/zerotier-one/package.mk', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch'}, 'additional product inputs changed: review/reseal first'
    assert all(sha(tree / path) == digest for path, digest in product_sha256.items())
    assert subprocess.check_output(['git', '-C', str(tree), 'diff', '--name-only', 'f8636de1d105275dbf9420bbabbbc26f79abb10f', a.commit, '--', *PRODUCT_ROOTS], text=True).splitlines() == PRODUCT_PATHS
    subprocess.run(['git', '-C', str(tree), 'merge-base', '--is-ancestor', a.commit, 'origin/next'], check=True)
    transfers = []
    for arch, ready in [('arm', a.arm_cache_ready.resolve(strict=True)), ('aarch64', cache)]:
        assert ready.name == 'cache-ready.json' and ready.parent.parent == Path('/workspace/tmp')
        assert ready.parent.name.startswith('pix-m7-zerotier-h700-transfer-' + arch + '-20261015-')
        transfer = json.loads(ready.read_text())
        assert transfer['schema'] == 'pix572-atomic-cache-transfer-v1' and transfer['status'] == 'PASS'
        expected = tree / ('build.pixelelated-H700.' + arch)
        assert transfer['new'] == str(expected) and transfer['destination_head'] == a.commit
        assert transfer['product_sha256'] == product_sha256 and not Path(transfer['old']).exists()
        st = expected.stat(); assert transfer['before_identity'] == transfer['after_identity'] == {'device': st.st_dev, 'inode': st.st_ino}
        run = Path(transfer['watched_run']); consumed_path = run / 'admission-consumed.json'
        consumed = json.loads(consumed_path.read_text())
        assert consumed['state'] == 'consumed' and consumed['source']['head'] == a.commit
        assert consumed['run'] == str(run) and consumed['submission_owner'] == str(ready.parent)
        assert all(consumed['original_result'][k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
        proof = ready.parent / 'consumption-evidence.json'
        assert consumed['evidence_sha256'] == sha(proof)
        assert all(sha(Path(row['path'])) == row['sha256'] for row in json.loads(proof.read_text())['evidence'])
        transfers.append({'arch': arch, 'root': expected.name, 'cache_ready': str(ready), 'cache_ready_sha256': sha(ready),
                          'transfer_consumed': str(consumed_path), 'transfer_consumed_sha256': sha(consumed_path)})
    helpers = ['build-owner.py', 'host-resources.py', 'inner-build.py', 'inside-build.sh', 'container-ready.py']
    for name in helpers:
        target = owner / name
        assert not target.exists()
        shutil.copyfile(Path(__file__).with_name(name), target)
        target.chmod(0o400)
    config = {'schema': 1, 'checkout': str(tree), 'commit': a.commit,
        'container_checkout': '/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-01',
        'build_root': 'build.pixelelated-H700.aarch64',
        'host_options_path': '/home/max/.ROCKNIX/options', 'host_options_sha256': '2cf98cb38836f56f7a6d42ca1c1a5327bb743c98adb42b41831128d475922e7d',
        'es_commit': a.expected_es, 'es_recipe_sha256': es_recipe_sha256,
        'product_sha256': product_sha256, 'template_commit': TEMPLATE_COMMIT,
        'generated_doc_candidate_sha256': 'e574a017b83e0da4d9360017ed14d1edcab86eb979efcad1b15fd4bc76407baa',
        'builder_image': 'ghcr.io/pixelelated/build@sha256:988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39',
        'owner_label': 'pix-m7-' + a.timestamp.lower(), 'build_timestamp': a.timestamp,
        'host_pid_namespace': os.readlink('/proc/self/ns/pid'),
        'cache_transfers': transfers, 'cache_roots': [row['root'] for row in transfers],
        'helper_sha256': {name: sha(owner / name) for name in helpers},
        'cold_cpu_ids': cpus[:4], 'image_cpu_ids': cpus,
        'cold_memory_bytes': 24 * 1024 ** 3, 'image_memory_bytes': 40 * 1024 ** 3,
        'container_pids_limit': 2048, 'family_timeout_seconds': a.family_seconds,
        'minimum_host_available_bytes': 8 * 1024 ** 3,
        'minimum_volume_available_bytes': 64 * 1024 ** 3,
        'disk_sample_interval_seconds': 600, 'disk_scan_timeout_seconds': 180,
        'limits_are_proposed_operating_bounds_not_measured_requirements': True}
    (owner / 'artifacts').mkdir()
    with (owner / 'build-inputs.json').open('x') as f:
        json.dump(config, f, indent=2); f.write('\n')
    (owner / 'build-inputs.json').chmod(0o400)
    print(json.dumps({'owner': str(owner), 'input_sha256': sha(owner / 'build-inputs.json'),
                      'cold_cpu_ids': cpus[:4], 'image_cpu_ids': cpus, 'launched': False}))


if __name__ == '__main__':
    main()

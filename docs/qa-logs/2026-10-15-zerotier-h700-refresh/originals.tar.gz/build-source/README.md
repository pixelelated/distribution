# H700 bounded ZeroTier build — source only, unrun

Exact published source077197e6cd3ea31f33b28aaf3882a694b3423b53, new checkout `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05`, branch `build/m7-pixelelated-h700-05`. This worker has not created it or run preparers, admissions, resource scans, builds or tests. Independent artifact readback is a separate sibling packet and is not claimed by this build result.

This narrow derivative reuses the proven GENERIC bounded stage owner, unchanged `inner-build.py` and `host-resources.py`, with H700's accepted canonical `inside-build.sh`: actual container temporary write/read gate, `scripts/checkdeps`, then `make H700` (ARM then AArch64). The existing outer nonce/CID/identity handshake now grants the same H700 container gate after its actual TMPDIR proof. There is no second unbounded observer or earlier initial gateway argument failure. PROJECT=ROCKNIX/DEVICE=H700/ARCH=aarch64 is explicit before Docker; canonical make H700 selects ARM and AArch64 itself.

Only explicit stages are AArch64 `zerotier-one` clean, AArch64 `zerotier-one` build, and canonical image. Standard non-DIRTY image housekeeping remains. No ARM ZeroTier, old8-package clean list, kernel clean, installed-ELF injection or retained-state test replay. The sole explicit image invalidation is the new AArch64 `.stamps/image/build_target`.

`prepare-owner.py` refuses unless both passed ARM/AArch64 cache-ready files have actual consumed original-zero receipts, exact destination roots, unchanged inode/device and absent old roots. It binds each ready/consumed SHA separately; no successful-pair summary can substitute. The transfers separately enforce the consumed GENERIC build/artifact dependency, so a failed GENERIC reader must be preserved and a new accepted reader binding released before transfer execution. Do not use the old transfer packet's failed reader01 binding after root releases its successor.

Stable container checkout remains `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-01`; both moved caches are mounted through that same prefix. Pinned builder988c0ba5, shared source cache/main `.git`, exact existing host-options SHA, actual nonroot identity, inherited CPU/memory/PID/no-swap and7200s family limits remain. Host allocations now observe both ABI roots. New build operating reservation retains H700's existing300GiB allowance; this is not a cache-copy reservation or a newly measured forecast. No fresh du occurs in preparation; existing live resource monitoring remains part of later admitted build execution.

Root commands, only after reviewed transfers are complete and independently consumed (substitute the actual retry owner paths if a transfer required one):

```bash
TASK_PACKET=/tmp/pix-m7-zerotier-h700-refresh-20261015/build
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05
TASK_BUILD=/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01
TASK_ARM=/workspace/tmp/pix-m7-zerotier-h700-transfer-arm-20261015-01/cache-ready.json
TASK_AARCH64=/workspace/tmp/pix-m7-zerotier-h700-transfer-aarch64-20261015-01/cache-ready.json
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
mkdir -m 700 "$TASK_BUILD"
cd "$TASK_TREE"
tools/build-preflight
TASK_TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)
python3 -I "$TASK_PACKET/prepare-owner.py" --checkout "$TASK_TREE" --commit 077197e6cd3ea31f33b28aaf3882a694b3423b53 --es-recipe-sha256 1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719 --expected-es 16dbac5211eea7e70db7394372033be2be7df829 --owner "$TASK_BUILD" --cache-ready "$TASK_AARCH64" --arm-cache-ready "$TASK_ARM" --timestamp "$TASK_TIMESTAMP" --family-seconds 7200
python3 -I "$TASK_PACKET/prepare-plan.py" --owner "$TASK_BUILD"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_BUILD/retention-plan.json" --output "$TASK_BUILD/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_BUILD/admission-plan.json" --output "$TASK_BUILD/admission.json"
tools/watch-build-submit --owner "$TASK_BUILD" -- --admission "$TASK_BUILD/admission.json" -- python3 -I "$TASK_BUILD/build-owner.py"
# After original watcher and launcher completion:
python3 -I "$TASK_PACKET/consume-stage.py" --owner "$TASK_BUILD" --stage build
```

Normal consumption checks original stages/resource results, container retirement, recorded process groups, actual owner/launcher completion and normal admission closure. Failure stops this route; it does not trigger a build rerun or rewrite an original. Leave producer-owned receipts alone. A successful build does not mean artifact acceptance, physical boot, runtime-on-device, RC or publication.

Both ABI caches remain only for the immediately queued image/readback/corresponding-source consumers. Prior source/firmware/receipts are unchanged; superseded large payloads retire through the existing D-INFRA-022 retention workflow once their immediate dependencies close. No duplicate caches or speculative deletion credit.

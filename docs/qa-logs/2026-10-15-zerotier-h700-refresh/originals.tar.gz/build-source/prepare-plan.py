#!/usr/bin/env python3
"""Materialize only H700 build retention/admission plans after both actual transfers."""
from pathlib import Path
import argparse,hashlib,json,subprocess
T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05');O=Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01');COMMIT='077197e6cd3ea31f33b28aaf3882a694b3423b53'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,j):
 with p.open('x') as f:json.dump(j,f,indent=2);f.write('\n')
q=argparse.ArgumentParser();q.add_argument('--owner',type=Path,required=True);a=q.parse_args();assert a.owner.resolve(strict=True)==O and Path.cwd().resolve()==T
j=json.loads((O/'build-inputs.json').read_text());assert j['commit']==COMMIT and j['checkout']==str(T)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==COMMIT and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for row in j['cache_transfers']:
 assert sha(Path(row['cache_ready']))==row['cache_ready_sha256'] and sha(Path(row['transfer_consumed']))==row['transfer_consumed_sha256']
scan=O/'empty-retention-scan';scan.mkdir()
retention=dict(volume='/workspace',scan_roots=[str(scan)],reference_stores=[],protected=[str(T/n) for n in j['cache_roots']]+['/workspace/cache/rocknix-sources','/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04/target'],candidates=[],builds=[dict(name='m7-zerotier-h700-build',terms_bytes=dict(normal_package_image_operating_allowance=300*1024**3),basis='Existing H700300GiB build operating bound, not a new measured requirement. Atomic cache custody already consumed; no duplicate caches, du preparation or reclamation credit.',evidence=[dict(path=str(O/'build-inputs.json'),sha256=sha(O/'build-inputs.json'))])])
outputs=[dict(path=str(T/n),issue=555,kind='build-cache',release_when='Immediately queued image/readback and corresponding-source dependency closed; retain compact originals') for n in j['cache_roots']]
outputs += [dict(path=str(T/n),issue=555,kind='firmware',release_when='Independent artifact acceptance and immediate named next consumer completed') for n in ['target','release']]
outputs += [dict(path=str(T/n),issue=555,kind='qa-scratch',release_when='Original channels consumed and compact records retained') for n in ['.doc_cache','.es_cache','.build-runs']]
outputs.append(dict(path=str(O),issue=555,kind='qa-scratch',release_when='Original channels consumed and compact records/corresponding-source inputs retained'))
ad=dict(checkout=str(T),container_checkout=j['container_checkout'],retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-zerotier-h700-build',profiles=[dict(PROJECT='ROCKNIX',DEVICE='H700',ARCH=arch) for arch in ['arm','aarch64']],outputs=outputs)
put(O/'retention-plan.json',retention);put(O/'admission-plan.json',ad)
print('PREPARED H700 build plans only; no admission/build launched')

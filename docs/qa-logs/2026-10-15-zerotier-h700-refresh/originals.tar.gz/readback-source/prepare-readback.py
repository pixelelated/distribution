#!/usr/bin/env python3
"""Materialize the existing H700 readers after actual build consumption; no launch."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

TREE=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05')
BUILD=Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01')
OWNER=Path('/workspace/tmp/pix-m7-zerotier-h700-readback-20261015-01')
COMMIT='077197e6cd3ea31f33b28aaf3882a694b3423b53'

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--owner',type=Path,required=True);a=p.parse_args()
    owner=a.owner.resolve(strict=True);packet=Path(__file__).resolve().parent
    assert owner==OWNER and owner.is_dir() and not any(owner.iterdir()) and Path.cwd().resolve()==TREE
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==COMMIT
    assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='build/m7-pixelelated-h700-05'
    assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
    cfg=json.loads((BUILD/'build-inputs.json').read_text());assert cfg['commit']==COMMIT and cfg['checkout']==str(TREE)
    run=Path((BUILD/'run.path').read_text().strip());assert run.parent==TREE/'.build-runs'
    consumed_path=run/'admission-consumed.json';c=json.loads(consumed_path.read_text())
    assert c['state']=='consumed' and c['source']['head']==COMMIT and c['submission_owner']==str(BUILD) and c['run']==str(run)
    assert all(c['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    proof=BUILD/'consumption-evidence.json';assert sha(proof)==c['evidence_sha256']
    assert all(sha(Path(row['path']))==row['sha256'] for row in json.loads(proof.read_text())['evidence'])
    assert json.loads((BUILD/'launcher-result.json').read_text())['runner_returncode']==0
    assert (BUILD/'tool-wrapper.rc').read_text().strip()=='0'
    assert json.loads((BUILD/'owner-result.json').read_text())['status']=='PASS'
    assert json.loads((BUILD/'resource-result.json').read_text())['status']=='PASS'
    names=['run.py','run.sh','verify-installed.py','verify-additions.py','verify-source.py','verify-prerequisites.py','verify-firmware.py','proxy-source-proof.json','dolphin-sys-source-manifest.json','host-checker/pixelelated-state-check']
    (owner/'host-checker').mkdir()
    for name in names:
        shutil.copyfile(packet/name,owner/name);(owner/name).chmod(0o400)
    (owner/'artifacts').mkdir();(owner/'empty-scan').mkdir()
    j=json.loads((packet/'inputs.template.json').read_text())
    j.update(build_timestamp=cfg['build_timestamp'],compiled_owner=str(BUILD),compiled_run=str(run),compiled_inputs_sha256=sha(BUILD/'build-inputs.json'),compiled_consumed_sha256=sha(consumed_path),
        source_files={str(TREE/n):h for n,h in cfg['product_sha256'].items()},
        qa_source_files={str(TREE/'tools/pixelelated-state-check'):'65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6'},source_symlinks={},
        scope='New H700 ZeroTier package and canonical firmware artifact readback; no target execution, physical boot, RC or publication.',
        work_seconds=1500,cleanup_seconds=15,host_cpu_affinity=[0],per_process_virtual_memory_bytes=8*1024**3,
        status='MATERIALIZED_AFTER_CONSUMED_BUILD_NO_READER_EXECUTED')
    assert j['container']==cfg['builder_image'] and j['host_options_sha256']==cfg['host_options_sha256']
    assert sha(Path(j['prior_arm_manifest']))==j['prior_arm_manifest_sha256']
    write(owner/'inputs.json',j);write(owner/'bindings.json',json.loads((packet/'bindings.template.json').read_text()))
    files=[owner/n for n in names]+[owner/'inputs.json',owner/'bindings.json']
    write(owner/'seal.json',{str(f):sha(f) for f in files});files.append(owner/'seal.json')
    retention={'volume':'/workspace','scan_roots':[str(owner/'empty-scan')],'reference_stores':[],
        'protected':[str(TREE),str(BUILD),str(consumed_path),j['prior_arm_manifest'],'/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01','/workspace/artifacts/pixelelated-candidates/sha256/32f7a6523dfae61b5142cf803876bf4e09f9a21a3a6784a69ca74b9d9b587833'],
        'candidates':[],'builds':[{'name':'m7-zerotier-h700-image-readback','terms_bytes':{'independent_firmware_bundle_and_bounded_scratch':64*1024**3},
            'basis':'Reuse accepted H700 firmware reader operating allowance. One immutable firmware bundle and serialized raw DDR3/DDR4 scratch; no build-cache copy, fresh size claim or deletion credit. Original consumed build held.',
            'evidence':[{'path':str(f),'sha256':sha(f)} for f in files]}]}
    admission={'checkout':str(TREE),'container_checkout':j['container_worktree'],'retention_plan':str(owner/'retention-plan.json'),'retention_report':str(owner/'retention-report.json'),
        'stage':'m7-zerotier-h700-image-readback','profiles':[{'PROJECT':'ROCKNIX','DEVICE':'H700','ARCH':arch} for arch in ['arm','aarch64']],
        'outputs':[{'path':str(owner),'issue':555,'kind':'qa-scratch','release_when':'Original reader channels consumed and compact evidence retained; successful serialized raw scratch removed by the reader.'},
                   {'path':'/workspace/artifacts/pixelelated-candidates','issue':555,'kind':'firmware','release_when':'Only immediate accepted firmware and corresponding-source consumers complete; scoped retention review protects other bundles.'}]}
    write(owner/'retention-plan.json',retention);write(owner/'admission-plan.json',admission)
    print(json.dumps({'owner':str(owner),'inputs_sha256':sha(owner/'inputs.json'),'launched':False}))

if __name__=='__main__':main()

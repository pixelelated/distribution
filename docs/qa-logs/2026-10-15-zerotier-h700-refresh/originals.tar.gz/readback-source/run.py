#!/usr/bin/env python3
"""Existing H700 installed/firmware acceptance readers under one bounded outer command."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent;j=json.loads((O/'inputs.json').read_text());T=Path(j['host_worktree'])
with (O/'run.path').open('x') as f:f.write(str(T/os.environ['RASTERATOPS_BUILD_RUN'])+'\n')
rc=1
try:
 for n,h in json.loads((O/'seal.json').read_text()).items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
 subprocess.run(['python3','-I',str(O/'verify-prerequisites.py')],check=True)
 subprocess.run(['python3','-I',str(O/'verify-source.py')],check=True)
 assert hashlib.sha256(Path(j['prior_arm_manifest']).read_bytes()).hexdigest()==j['prior_arm_manifest_sha256']
 subprocess.run(['python3','-I',str(O/'verify-installed.py')],check=True)
 outputs={}
 for p in sorted((T/'target').iterdir()):
  if p.is_file() and p.name.startswith('pixelelated-H700.aarch64-'):
   with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
   outputs[p.name]=dict(path=str(p),bytes=p.stat().st_size,sha256=h)
 assert len(outputs)==7 and len([n for n in outputs if n.endswith('.img.gz')])==2 and len([n for n in outputs if n.endswith('.tar')])==1
 (O/'artifacts/output-manifest.json').write_text(json.dumps(dict(result='READ_VALIDATED_REQUIRES_ARTIFACT_ACCEPTANCE',distribution_commit=j['distribution_commit'],files=outputs),indent=2)+'\n')
 subprocess.run(['python3','-I',str(O/'verify-firmware.py')],check=True)
 subprocess.run(['python3','-I',str(O/'verify-source.py')],check=True);rc=0
except subprocess.CalledProcessError as e:rc=e.returncode if e.returncode>0 else 128-e.returncode
finally:
 for name in ['inner.rc','outer.rc']:
  with (O/name).open('x') as f:f.write(str(rc)+'\n')
sys.exit(rc)

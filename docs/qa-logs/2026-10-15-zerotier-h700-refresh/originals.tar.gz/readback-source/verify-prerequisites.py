#!/usr/bin/env python3
"""Read exact new consumed H700 producer originals; no rerun or retrospective success."""
from pathlib import Path
import hashlib,json,subprocess
O=Path(__file__).resolve().parent;j=json.loads((O/'inputs.json').read_text());B=Path(j['compiled_owner']);R=Path(j['compiled_run'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'build-inputs.json')==j['compiled_inputs_sha256']
assert sha(R/'admission-consumed.json')==j['compiled_consumed_sha256']
c=json.loads((R/'admission-consumed.json').read_text());assert c['state']=='consumed' and c['source']['head']==j['distribution_commit'] and c['submission_owner']==str(B)
assert all(c['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
p=B/'consumption-evidence.json';assert sha(p)==c['evidence_sha256']
for row in json.loads(p.read_text())['evidence']:assert sha(Path(row['path']))==row['sha256']
r=json.loads((B/'owner-result.json').read_text());assert r['status']=='PASS' and not r['signals'] and not any(r['surviving_host_command_groups'].values())
assert [x['stage'] for x in r['stages']]==['clean-zerotier-one','build-zerotier-one','image']
assert json.loads((B/'resource-result.json').read_text())['status']=='PASS'
assert json.loads((B/'launcher-result.json').read_text())['runner_returncode']==0 and (B/'tool-wrapper.rc').read_text().strip()=='0'
for row in r['stages']:
 stage=B/'stages'/row['stage'];inner=json.loads((stage/'inner-result.json').read_text())
 assert inner['original_command_rc']==inner['wrapper_rc']==0
 q=subprocess.run(['docker','inspect',(stage/'container.cid').read_text().strip()],capture_output=True,text=True,timeout=15)
 assert q.returncode!=0 and 'no such' in q.stderr.casefold()
assert json.loads((B/'artifacts/container-gate.json').read_text())['result']=='PASS'
binding=json.loads((O/'bindings.json').read_text())
assert sha(O/'host-checker/pixelelated-state-check')==binding['host_checker_sha256']
assert sha(Path(binding['controls_stdout']))==binding['controls_stdout_sha256']
suite=json.loads(Path(binding['controls_stdout']).read_text());assert suite['status']=='pass' and suite['control_count']==binding['controls_count']==212
assert len(suite['controls'])==212 and all(row['status']=='pass' for row in suite['controls'])
control=Path(binding['controls_run']);assert all(json.loads((control/'runner-result.json').read_text())[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert (control/'build.rc').read_text().strip()=='0'
print('PASS exact new H700 canonical build originals consumed0; independent artifact scope follows')

# H700 ZeroTier artifact readback — source packet, unrun

This separate reader binds the new successful canonical H700 build at published source `077197e6cd3ea31f33b28aaf3882a694b3423b53`, frozen checkout `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05`. Preparation only materializes small sealed helpers after the real build has completed and its original command, monitor, runner, launcher, resource and stage channels have been consumed successfully. It does not allocate a container or start a build.

The actual accepted H700 installed-file and DDR3/DDR4 firmware readers are retained: exact helper/native/catalog mappings, both raw images and update payload equality, both bootloaders, AArch64 architecture, ARM32 handoff and selected-state reader `65ab515e`. The existing 212-control result is referenced by its original path and hash, not rerun. New firmware is kept once through the existing immutable candidate store with independent inodes. Serialized raw image scratch is removed after successful verification; failed scratch is left as failed evidence. No build cache is copied.

ZeroTier checks reuse the successful GENERIC reader02 logic: exact filtered OneService source, absent nonfree directory, one actual compiler command from the bounded producer console, the AArch64 compiler and resulting object, no controller defines or nonfree arguments, and package/install/packaged SYSTEM bytes, modes and links. Canonical make does not request dependency records. Empty `.d` inventory is explicitly reported as `not-requested-by-canonical-build`, after checking the actual compiler argv has no dependency-generation flags; no dependency-completeness claim is made. Any observed `.d` records remain bounded and checked. The separate earlier 113-unit instrumented proof remains independent.

Only H70005 cache paths are read. The old accepted ARM manifest and prior receipts are immutable evidence files, not old cache consumers. The old combined H700 producer1 and earlier failed readers remain failed. A new build0 or reader0 never rewrites those outcomes. GENERIC reader01's `.d` assertion failure also remains unchanged; its corrected reader02 passed independently before the reviewed transfers.

Run only after both transfer02 owners and the new H700 build owner have been independently consumed. Root commands:

```bash
TASK_PACKET=/tmp/pix-m7-zerotier-h700-refresh-20261015/readback
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05
TASK_READER=/workspace/tmp/pix-m7-zerotier-h700-readback-20261015-01
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
mkdir -m 700 "$TASK_READER"
cd "$TASK_TREE"
python3 -I "$TASK_PACKET/prepare-readback.py" --owner "$TASK_READER"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_READER/retention-plan.json" --output "$TASK_READER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_READER/admission-plan.json" --output "$TASK_READER/admission.json"
tools/watch-build-submit --owner "$TASK_READER" -- --admission "$TASK_READER/admission.json" -- bash "$TASK_READER/run.sh"
# After actual watcher and launcher completion, without rewriting original statuses:
python3 -I "$TASK_PACKET/consume-readback.py" --owner "$TASK_READER"
```

The reader uses CPU0, an 8GiB per-process address-space limit, a 16GiB per-file limit, a 1500-second command limit and 15-second forced-stop grace. The retention plan retains the accepted H700 64GiB firmware/scratch operating allowance; it is not a fresh measured requirement or deletion credit. Normal watch-build/launcher originals and process retirement are required for consumption. On failure, stop and investigate the actual original; do not replay the successful build or transfers.

This packet provides host artifact acceptance only: no target execution, physical boot or smoke, provider join, runtime qualification, RC or publication claim. Retain large outputs only for immediate firmware/corresponding-source consumers, then use the existing scoped retention process. The source worker ran only AST and shell-syntax checks and did not execute this preparer, reader, admission or consumer.

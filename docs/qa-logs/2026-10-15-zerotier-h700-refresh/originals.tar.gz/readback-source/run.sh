#!/bin/bash
set -euo pipefail
TASK_READER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec taskset -c 0 prlimit --as=8589934592 --fsize=17179869184 -- timeout --signal=TERM --kill-after=15s 1500s python3 -I "$TASK_READER/run.py"

# FEX phase-A continuation — source only, unrun

This fresh packet continues the seven missing archives after the consumed failed run `20261015T132811Z-4942e582`. It preserves owner 01 and its original command/monitor/runner result **1/0/1**. Linux 6.16.7 completed with **152,673,392 bytes** and SHA-256 `5be3daa1f9427b1bdb34c4894d9c1adfac38cff674376fe0611a3065729a1a81`. The following libdrm request returned curl 35, HTTP 0 and an empty response body. The root's failure review records a connection reset, clean process custody and successful failed-investigation consumption.

No continuation guard, preparation or acquisition has run. This source preparation read only exact small receipts, source and metadata. It did not reread the Linux payload, contact a server or change the prior source packet/owner. The source-only phase-B work is paused at `/tmp/pix-m7-fex-source-phaseb-20261015`.

## Exact work and order

The seven URL/SHA-256 tuples are bound as a set to the accepted eight-file proposal after removing Linux, with a separate explicit order enforced by `bindings.py`:

1. glibc 2.40
2. GCC 14.3.0
3. Wayland 1.24.0
4. libX11 1.8.12
5. xorgproto 2024.1
6. libXrandr 1.5.4
7. libdrm 2.4.129

The held official Nixpkgs `pkgs/by-name/li/libdrm/package.nix` and exact fetch derivation both specify `https://dri.freedesktop.org/libdrm/libdrm-2.4.129.tar.xz`, with SHA-256 `5978183f978d697e26a50ba066174964efb0ab97caa1ecaa1b861fbe5ddf77dc`. They supply no alternate source archive URL. The exact recorded Nix-store archive path is absent. This continuation therefore makes one explicitly reviewed new attempt on the supported HTTPS route, placed last. There is no alternate transport, weaker TLS, guessed fallback URL, automatic retry or per-source exception suppression. Any failure stops and retains the original outcome.

The Linux archive is referenced in its existing owner, never recopied or downloaded again. The preparer binds its exact archive and HTTP/wait receipts, the overall failure and its accepted failed-investigation evidence. The collector will rehash the Linux body and verify its recorded identity before requests and after completion; the success consumer will independently rehash it again. Changed or missing Linux bytes stop qualification. The overall prior run remains failed; its successful per-archive receipt supplies the reuse evidence.

Three historical ALSA/libxcb/libXrender references remain unchanged. Phase B, notices, independent retrieval, offhost custody and publication disposition remain separate. No compiler closure or guest-runtime-rootfs acquisition is added.

## Bounds and lifecycle

The original resource limits are preserved or tightened:

- **Seven** logical downloads, at most four explicit redirects each: **35 actual HTTP requests**, no retries. The same anonymous HTTPS host allowlists apply, with initial URLs exact and signed redirect paths/queries private.
- **192 MiB per response body**. The new aggregate body allowance is **249,979,792 bytes**. Added to the held Linux response's 152,673,392 bytes, this remains the original **402,653,184-byte / 384 MiB phase-A cap**. All new redirect bodies and failed partials count.
- **1 GiB fresh owner**, **2 GiB retention reservation**, **16 MiB normal receipt reserve**, 1 MiB collector failure receipt and 8 MiB supervisor margin. Each request reserves its full actual body allowance plus both raw curl-stream allowances before writing; the effective RLIMIT_FSIZE shrinks with remaining archive and owner capacity. Unused reservations release only after the original wait and stable retained-file readback.
- Soft collector deadline **580 seconds**, supervisor deadline **600 seconds**, outer **630 seconds plus 15 seconds** to kill; the unchanged identity-bound cleanup takes at most 13 seconds. Each logical download shares 120 seconds across its redirects, with 10-second connection bounds. Two CPUs, 2 GiB address space, 4 GiB streamed named-read limit.
- The same bounded exclusive preparation/JSON/log/completion writes apply. Maximum 35 fixed six-file request groups plus seven archive receipts and finite lifecycle files stay below 512 files / 16 directories. No remote pathname controls local output locations. Source archives are neither extracted nor executed.

`changes.diff` compares this packet to the exact first acquisition source seal `854ce16045c5b590e18432ff81800d1c3ec4b17d72015be714e0b6286eb21772`. `process-identity.py`, `run.sh`, the 14 base write guards and transport/reservation function definitions are unchanged. The focused guard source only tightens the actual-request boundary from 40 to 35; its prior 48-case pass does not claim this source has run. `static-review.json` records AST/JSON and Bash syntax parsing only.

Raw `.curl.stdout` and `.curl.stderr` remain **private, owner-held, excluded from Git**. Preserve partial bodies and every original receipt on failure. Do not rerun an owner, replay completed downloads, reinterpret the prior failure as success or widen limits automatically.

## Ready coordinator commands

The default fresh owner is `/workspace/tmp/pix-m7-fex-source-acquisition-20261015-02`; it is uncreated. The default new guard report uses suffix 02. Set different fresh two-digit suffixes if either exists. Each step remains separately allocated and inspected:

```bash
bash /tmp/pix-m7-fex-source-acquisition-continuation-20261015/commands.sh guards
# Export TASK_GUARD_RUN for the original successful watched guard run.
# Export TASK_CURL_PATH and TASK_CURL_SHA256 for the resolved host curl ELF.
bash /tmp/pix-m7-fex-source-acquisition-continuation-20261015/commands.sh prepare
bash /tmp/pix-m7-fex-source-acquisition-continuation-20261015/commands.sh preflight
bash /tmp/pix-m7-fex-source-acquisition-continuation-20261015/commands.sh report
bash /tmp/pix-m7-fex-source-acquisition-continuation-20261015/commands.sh admit
bash /tmp/pix-m7-fex-source-acquisition-continuation-20261015/commands.sh launch
# Root actively supervises the original run, at intervals no longer than 60 seconds.
# Only after all original channels, exact source hashes and custody qualify:
bash /tmp/pix-m7-fex-source-acquisition-continuation-20261015/commands.sh consume
```

Failure uses the ordinary failed-investigation consumer, not the success-only helper. Submission is not completion. The runtime control checkout remains frozen at `f8636de1d105275dbf9420bbabbbc26f79abb10f`; serialization refuses another unconsumed owner. Successful acquisition still reports explicit source/publication gaps.

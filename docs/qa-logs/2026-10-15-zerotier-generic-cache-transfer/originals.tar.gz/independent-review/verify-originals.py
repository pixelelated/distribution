from pathlib import Path
import datetime,hashlib,json
OUT=Path('/tmp/pix-m7-generic-transfer-custody-20261015')
OWNER=Path('/workspace/tmp/pix-m7-zerotier-generic-transfer-20261015-01')
PACKET=Path('/tmp/pix-m7-zerotier-generic-refresh-20261015/transfer')
ROOT=Path('/tmp/pix-m7-generic-transfer-coordinator-20261015')
PUB=Path('/tmp/pix-m7-077-publication-20261015')
RUN=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03/.build-runs/20261015T161403Z-91c45da4')
RPT=RUN.parent/'20261015T161144Z-f9437d63'
DEP=RUN.parent/'20261015T161152Z-03197c52'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
refs=[]
def bind(p):
 refs.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
 return read(p)
assert sha(PACKET/'SHA256SUMS')=='24587f39a81d92a93d8606c3e3c4a02edf854a17b1d182837cf804aa97b438f8'
sealed=[]
for line in (PACKET/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);p=PACKET/n;assert sha(p)==h;sealed.append(n)
assert len(sealed)==7
assert {p.name for p in PACKET.iterdir()}==set(sealed)|{'SHA256SUMS'}
result=bind(OWNER/'transfer-result.json');intent=bind(OWNER/'transfer-intent.json')
assert result['status']=='PASS' and result['renamed'] is True and result['copy_performed'] is False
assert result['method']=='same-filesystem-rename'
assert result['watched_run']==str(RUN)
assert result['source_head']=='f8636de1d105275dbf9420bbabbbc26f79abb10f'
assert result['destination_head']=='077197e6cd3ea31f33b28aaf3882a694b3423b53'
ident={'device':66304,'inode':111174037}
assert result['before_identity']==result['after_identity']==intent['before_identity']==ident
assert intent['status']=='FAIL' and intent['renamed'] is False
for key in ('old','new','source_head','destination_head','product_sha256','utc_start_epoch','old_target_identity','original_build_consumption','accepted_artifact','dependency_readback'):
 assert result[key]==intent[key],key
assert result['old_target_identity']=={'device':66304,'inode':142521209}
assert (OWNER/'cache-ready.json').read_bytes()==(OWNER/'transfer-result.json').read_bytes()
assert 0 < result['utc_finish_epoch']-result['utc_start_epoch'] < 120
census=bind(OWNER/'dependency-readback.json');assessed=bind(OWNER/'dependency-assessed.json');excluded=bind(OWNER/'excluded-process-observations.json')
assert assessed==result['dependency_readback']['readback']
assert sha(OWNER/'dependency-assessed.json')==result['dependency_readback']['sha256']
assert assessed['original_readback_sha256']==sha(OWNER/'dependency-readback.json')
assert result['utc_start_epoch']-census['utc_epoch'] < 900
assert assessed['utc_epoch']==census['utc_epoch']
assert census['identity']['device']==ident['device'] and census['identity']['inode']==ident['inode']
assert assessed['root_identity']==ident
assert assessed['status']=='CLEAR_WITH_STATED_SCOPE'
assert assessed['host_pid_namespace']==census['host_pid_namespace']==4026531836
assert not census['matches'] and not census['container_references'] and not census['active_admissions']
assert not assessed['process_matches'] and not assessed['active_admissions'] and not assessed['remaining_consumers']
assert assessed['prepared_consumers_resolved'] is True
assert assessed['process_errors']==census['errors']
pids=[2325,2342,564119,2590490,2739866,3133343]
assert [x['pid'] for x in census['errors']]==pids
assert [x['pid'] for x in excluded]==pids
assert [{k:v for k,v in x.items() if k!='assessment'} for x in assessed['excluded_from_fd_scope']]==excluded
assert [x['state'] for x in excluded]==['S','S','S','Z','Z','S']
for r in (RPT,DEP,RUN):
 j=bind(r/'runner-result.json')
 assert [j[k] for k in ('command_rc','monitor_rc','runner_rc')]==[0,0,0]
 assert (r/'build.rc').read_text()=='0\n'
assert (OWNER/'run.path').read_text().strip()==str(RUN)
launcher=bind(OWNER/'launcher-result.json');assert launcher['runner_returncode']==0
for n in ('inner.rc','tool-wrapper.rc'):assert (OWNER/n).read_text()=='0\n'
evidence=bind(OWNER/'consumption-evidence.json')
assert evidence['run']==str(RUN) and evidence['expected_rc']==0 and evidence['disposition']=='qualified'
for row in evidence['evidence']:assert sha(Path(row['path']))==row['sha256']
consumed=bind(RUN/'admission-consumed.json')
assert consumed['state']=='consumed' and consumed['id']=='ca5afc3cd3184396a56e9bcae9990cf0'
assert consumed['original_result']==read(RUN/'runner-result.json')
assert consumed['pid_namespace']==4026531836 and consumed['source']['head']==result['destination_head']
assert consumed['evidence_sha256']==sha(OWNER/'consumption-evidence.json')
assert consumed['outputs']==evidence['outputs'] and consumed['deleted_bytes']==0 and consumed['outputs_held'] is True
admission=bind(OWNER/'admission.json')
assert admission['id']==consumed['id']
assert admission['state']['source']==consumed['source']
assert admission['state']['retention_plan_sha256']==sha(OWNER/'retention-plan.json')
assert admission['state']['retention_report_sha256']==sha(OWNER/'retention-report.json')
for p in sorted(ROOT.glob('*.exit.json')):assert bind(p)['original_tool_exit']==0
for p in sorted(PUB.glob('*.exit.json')):assert bind(p)['original_exit']==0
remote=(PUB/'remote.stdout').read_text().splitlines()
assert remote==[result['destination_head']+'\trefs/heads/feature/m7-final-qualification-02',result['destination_head']+'\trefs/heads/next']
ci=bind(PUB/'ci.stdout');assert [(r['databaseId'],r['conclusion']) for r in ci]==[(38766203570,'failure'),(38766203822,'success'),(38766131970,'success')]
record=bind(PUB/'record.stdout');assert record['conclusion']=='failure'
assert [x['name'] for x in record['jobs'][0]['steps'] if x['conclusion']=='failure']==['ceremonies are not overdue']
prior=result['original_build_consumption']
assert prior['completion_disposition']=='failed-investigated/reporting-failure' and prior['qualification'] is False and prior['original_launcher_returncode'] is None
assert sha(Path(prior['path']))==prior['sha256']
accepted=result['accepted_artifact']
assert accepted['admission_id']=='8a98fa7142a045539d3755338c1da2ed'
assert accepted['binding_sha256']==sha(PACKET/'predecessor-binding.json')
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_RECORDED_TRANSFER_AND_CHANNELS','source_packet_seal':sha(PACKET/'SHA256SUMS'),'run':str(RUN),'original_exit_channels':{'command':0,'monitor':0,'runner':0,'launcher':0,'inner':0,'tool_wrapper':0,'retention_record_run':0,'dependency_record_run':0},'consumption_id':consumed['id'],'consumed_utc':consumed['consumed'],'recorded_pid_namespace':4026531836,'recorded_before_after_identity':ident,'recorded_old_target_identity':result['old_target_identity'],'recorded_transfer_seconds':result['utc_finish_epoch']-result['utc_start_epoch'],'explicit_excluded_pids':pids,'raw_census_scope':census['scope'],'assessed_census_scope':assessed['scope'],'raw_other_uid_processes_without_fd_census':census['other_uid_processes_without_fd_census'],'historical_intent_status':'FAIL/renamed=false is the immutable pre-mutation intent, not the final result','previous_producer':prior,'independent_artifact':accepted,'publication':{'head':result['destination_head'],'record_workflow_conclusion':'failure','failed_step':'ceremonies are not overdue','wordlist_workflows':'success'},'original_inputs':refs,'limits':['Record and exact-byte inspection only; no new process census, cache traversal, runtime or target action.','No current whole-host/root-FD absence, deletion clearance, rebuilt firmware, runtime qualification, RC or overall CI PASS claim.']}
(OUT/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'references':len(refs),'recorded_transfer_seconds':summary['recorded_transfer_seconds'],'seal':summary['source_packet_seal']}))

# Building mkdcdisc

mkdcdisc is cross-platform and builds on Linux, macOS, and Windows. Requirements include
a C++17 compiler, `git`, `meson`, `ninja`, `libisofs`, and `libpng`.

`libpng` is the only optional dependency. It enables `-i/--bootstrap-mr-image` to accept
the bootstrap (`IP.BIN`) license-screen logo in PNG format and convert it to MR format.
If `libpng` is detected at configure time, Meson enables PNG support automatically.
Builds without PNG support remain fully functional: they accept pre-converted `.mr` logo
files while gracefully rejecting PNG inputs. The `--help` output for `-i` reflects whether
PNG input is supported in your binary.

To control PNG support explicitly in CI or automated pipelines, pass `-Dpng=`:

| `meson setup builddir …` | Behavior |
|:---|:---|
| *(omitted)* or `-Dpng=auto` | Default behavior: enables PNG support if `libpng` is found, disables silently otherwise. |
| `-Dpng=enabled` | Fails configuration if `libpng` is missing (recommended for CI builds). |
| `-Dpng=disabled` | Disables PNG support completely without searching for `libpng`. |

## Linux

Fedora:

```bash
dnf install git meson gcc gcc-c++ libisofs-devel libpng-devel
```

Ubuntu / Debian:

```bash
sudo apt install git meson build-essential pkg-config libisofs-dev libpng-dev
```

## macOS

```bash
brew install git meson pkg-config libisofs libpng
```

## Windows

On Windows, mkdcdisc is built using MinGW-w64 in one of two configurations depending
on whether you need an MSYS2-dependent or standalone executable.

### MSYS2 Environment Variant (`MSYSTEM=MSYS`)

This builds against the MSYS2 POSIX runtime layer. The resulting executable runs strictly
within the MSYS2 bash environment and requires MSYS2 runtime DLLs.

`libisofs` and `libpng` must be compiled from source for this target, as the `msys` repository
does not provide native packages for them. (Skip `libpng` if building without PNG support).

Both packages must be regenerated (`./bootstrap`, `autoreconf -fi`) before compiling.
MSYS2 patches libtool to prefix shared library outputs with `msys-` (e.g. `msys-png16-16.dll`).
Using upstream pre-generated configure scripts would yield `cyg`-prefixed DLL names instead.

```bash
pacman -S --noconfirm git meson gcc autotools libtool make libiconv-devel zlib-devel

curl -LO https://files.libburnia-project.org/releases/libisofs-1.5.8.tar.gz
tar xf libisofs-1.5.8.tar.gz
cd libisofs-1.5.8
./bootstrap
./configure --prefix=/usr --disable-static
sed -i.bak -e "s/allow_undefined=yes/allow_undefined=no/" libtool
(make || (sed -i.bak -e "s/allow_undefined=yes/allow_undefined=no/" libtool && make))
make install
cd ..

curl -LO https://download.sourceforge.net/libpng/libpng-1.6.58.tar.gz
tar xf libpng-1.6.58.tar.gz
cd libpng-1.6.58
autoreconf -fi
./configure --prefix=/usr --disable-static
make
make install
cd ..
```

### Standalone Native MinGW-w64 Variant (`MSYSTEM=MINGW64`)

This produces a standalone native Windows binary (`mkdcdisc.exe`) that executes outside MSYS2
without third-party runtime dependencies. Because upstream `libisofs` lacks out-of-the-box
Windows support, this variant builds against the lightly patched copy bundled in this repository.

To ensure true standalone portability, dependencies (including `libpng` and `zlib`) are linked
statically via `meson.build`. The executable only imports standard Windows system DLLs:

```bash
objdump -p builddir/mkdcdisc.exe | grep 'DLL Name'
```

Required MSYS2 MinGW-w64 packages:

```bash
pacman --noconfirm -Syu git mingw-w64-x86_64-autotools mingw-w64-x86_64-gcc mingw-w64-x86_64-libtool mingw-w64-x86_64-make mingw-w64-x86_64-libiconv mingw-w64-x86_64-libpng mingw-w64-x86_64-git mingw-w64-x86_64-meson
```

## Downloading and Building

```bash
git clone https://gitlab.com/simulant/mkdcdisc
cd mkdcdisc

meson setup builddir
meson compile -C builddir

# Run CLI
./builddir/mkdcdisc -h
```

## Developer and Maintainer Notes

### Running Tests

```bash
meson test -C builddir --print-errorlogs
```

Use `--print-errorlogs` to display detailed output on test failures. Pass `--suite unit`
to run fast unit tests without executing longer end-to-end image generation suites.

### Slow Tests

Passing `-Dslow_tests=true` enables long-running test cases, such as generating a full-capacity
padded GD-ROM image (~2.1 GiB scratch space required). Disabled by default.

### Regenerating Embedded Binary Assets

mkdcdisc embeds several binary files directly into the compiled executable: the MIL-CD
and GD-ROM `IP.BIN` bootstraps and the default MR license logo. Raw binaries reside in
`assets/`, while their C-array counterparts are committed under `src/assets/*.include`.

When editing files in `assets/`, regenerate the header includes using the custom Meson target:

```bash
meson compile -C builddir regen-includes
```

This target maps assets to the following C include headers and symbols:

| Asset File | Include Header | C Symbol |
|---|---|---|
| `assets/ip/cd/IP.BIN` | `src/assets/ip_cd.include` | `IP_BIN_MILCD` |
| `assets/ip/gd/nearest/IP.BIN` | `src/assets/ip_gd.hda.nearest.include` | `IP_BIN_GDROM_HDA_NEAREST` |
| `assets/ip/gd/zero/IP.BIN` | `src/assets/ip_gd.hda.zero.include` | `IP_BIN_GDROM_HDA_ZERO` |
| `assets/iplogo/default-mr.mr` | `src/assets/iplogo.default.include` | `IP_BIN_DEFAULT_MR` |

The two GD-ROM bootstrap templates correspond to the `--gdi-fpu-rounding` options. They must
share identical 256-byte header metadata (from which low-density `IP0000.BIN` is derived).
The end-to-end test suite validates header consistency.

This target requires `xxd` (from Vim). Always commit updated `src/assets/*.include` headers
alongside any modified binary assets in `assets/`.

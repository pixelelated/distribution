# Small host-only mkdcdisc preparation

Source/presence review only. No compiler, Meson, Ninja, container, emulator,
fixture or service was executed. No package was installed and no shared build
cache was written. The firmware build retains the only active allocation.

The smallest route uses existing host GCC/G++ 15 and the exact installed
libisofs6t64 `1.5.6.pl01-1.1ubuntu3`, plus a private extraction of its matching
310,044-byte **development package**. Cached native Meson 1.11.2 and Ninja are
available under the accepted replacement20 SDK. Their presence/ELF dependencies
were read only; the old absolute Meson shebang is intentionally bypassed using
the host interpreter and a private copy of its pure Python package.

mkdcdisc `2b98b0d9480e364e3517355648fbc3b49fb19882` requires C99, C++17,
Meson/Ninja, pkg-config and libisofs. `meson.build:60–64` has no libisofs minimum
version. `-Dpng=disabled` removes the only optional dependency; this fixture uses
author IP.BIN and no PNG bootstrap-logo conversion. EDC/ECC and disc-image code
are already vendored. No SH4 SDK, libburn, xorriso, cdi4dc, CMake, downloaded game
toolchain, libpng-dev or new zlib development package is needed. Tests are declared
unconditionally in Meson, so build **only the `mkdcdisc` target**, not the default
all-target build. No test/asset-regeneration target is proposed.

The pinned builder Dockerfile lists GCC12/G++12/Python3 and general build tools,
but does not install libisofs-dev, Meson or Ninja. Its current filesystem was not
probed through a container. Host runtime libraries must not be injected into that
Jammy container: use the host-native route below, where the matching runtime is
actually present. `host-inputs.json` binds observed paths/hashes and versions.

## Inputs

1. Source archive is already fetched, **not extracted or executed**:
   `/tmp/m7-mkdcdisc-source-plan-20261014/mkdcdisc-2b98b0d9.tar.gz`, 12,492,260 bytes,
   SHA256 `92215196a70dd8e31e0641c1698c20978fbeab23eb70498dbad709c1848ef632`.
   [Exact author archive](https://gitlab.com/simulant/mkdcdisc/-/archive/2b98b0d9480e364e3517355648fbc3b49fb19882/mkdcdisc-2b98b0d9480e364e3517355648fbc3b49fb19882.tar.gz).
2. Needed package, **not downloaded or installed**:
   [libisofs-dev_1.5.6.pl01-1.1ubuntu3_amd64.deb](https://us.archive.ubuntu.com/ubuntu/pool/main/libi/libisofs/libisofs-dev_1.5.6.pl01-1.1ubuntu3_amd64.deb),
   310,044 bytes, SHA256
   `31b95aa3c65d384fbe73001eb697c3e5219dd4f46930fe6d1cf9281b75b0aaea`.
   The configured Ubuntu package index supplies this identity and exact runtime
   dependency; its original record is `libisofs-dev.apt-record.txt`. Fetch the URL
   with a 30-second/310,044-byte bound and verify before allocation. Refuse changed
   bytes; do not silently upgrade or apt-install it.
3. Existing host/runtime and accepted SDK paths are in `host-inputs.json`; no
   compiler/library existence is inferred from a package name alone. Runtime
   execution compatibility still needs the actual bounded build.

The pinned upstream [BUILDING.md](https://gitlab.com/simulant/mkdcdisc/-/blob/2b98b0d9480e364e3517355648fbc3b49fb19882/BUILDING.md),
[meson.build](https://gitlab.com/simulant/mkdcdisc/-/blob/2b98b0d9480e364e3517355648fbc3b49fb19882/meson.build)
and third-party notices are retained. Keep MIT tool, GPL libisofs and CDDL EDC
notices with the local tool/corresponding source if it is retained or distributed.

## Future allocation and exact commands

After firmware completion/consumption, use one fresh admitted watched **host**
owner: 600-second build bound plus 120-second authoring bound, 1 CPU, 4 GiB memory,
2 GiB private scratch, 16 MiB named-log ceiling, bounded cleanup. Build and
authoring run serially with separate original statuses. No network is needed
after the package has been fetched. Keep the watcher/output/process-group guard
from the established host-job wrapper; this source packet does not launch one.
The `build-tool.sh` script is unexecuted and writes only its new work directory.

Before allocation, fetch the one missing package into this private packet area
(download is data preparation, not package installation):

```sh
curl --fail --location --max-time 30 --max-filesize 310044 \
  --output /tmp/m7-mkdcdisc-source-plan-20261014/libisofs-dev_1.5.6.pl01-1.1ubuntu3_amd64.deb \
  https://us.archive.ubuntu.com/ubuntu/pool/main/libi/libisofs/libisofs-dev_1.5.6.pl01-1.1ubuntu3_amd64.deb
printf '%s  %s\n' \
  31b95aa3c65d384fbe73001eb697c3e5219dd4f46930fe6d1cf9281b75b0aaea \
  /tmp/m7-mkdcdisc-source-plan-20261014/libisofs-dev_1.5.6.pl01-1.1ubuntu3_amd64.deb \
  | sha256sum --check
```

Then the bounded tool-build stage uses:

```sh
bash /tmp/m7-mkdcdisc-source-plan-20261014/build-tool.sh \
  /tmp/m7-mkdcdisc-source-plan-20261014/mkdcdisc-2b98b0d9.tar.gz \
  /tmp/m7-mkdcdisc-source-plan-20261014/libisofs-dev_1.5.6.pl01-1.1ubuntu3_amd64.deb \
  /workspace/tmp/pix-m7-mkdcdisc-20261014-01/work
```

No `make install`: dpkg-deb only extracts into private work. The private linker
symlink points to the hash-checked matching host runtime. Pkg-config is scoped to
that private development prefix; PNG lookup and all Meson downloads are disabled.
The package's conventional relative `.so` symlink is asserted before linking it;
its archive contents have not yet been inspected because it is not downloaded.
The copied Ninja is native, not `x86_64-rocknix-linux-gnu-gcc`. No shared SDK file
is edited. Retain original configure/build statuses, logs and final ELF hash.

Then, within the separate authoring stage and its original 120-second clock:

```sh
/workspace/tmp/pix-m7-mkdcdisc-20261014-01/work/build/mkdcdisc \
  -B /tmp/m7-native-save-staged-01/1ST_READ.BIN \
  -D /tmp/m7-native-save-staged-01/tetris2-disc \
  -p /tmp/m7-native-save-staged-01/IP.BIN \
  -o /workspace/tmp/pix-m7-mkdcdisc-20261014-01/Tetris2-M7.cdi
(cd /workspace/tmp/pix-m7-mkdcdisc-20261014-01 && sha256sum Tetris2-M7.cdi > Tetris2-M7.cdi.sha256)
```

Use the previously reviewed exact source/licensed game inputs and normal CDI
padding. Freeze the actual disc hash before guest transfer. This only authors a
disc; native gameplay/VMU persistence remain the later installed-image case.
Stop/preserve any original failure. No arbitrary fallback compiler/library or
package-version change, silent retry, full extra suite or new release gate is
part of this proposal.

Coordinator follow-up at21:08UTC: the exact310,044-byte development archive was downloaded privately, its expected hash verified, and dpkg-deb --contents0 confirms the prospective libisofs.so link assertion. See deb-readback.json. No package installation, extraction into a build prefix, compiler or disc authoring ran. The earlier source-stage downloaded:false observation remains historical in host-inputs.json.

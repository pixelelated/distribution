#!/usr/bin/env python3
"""Draft source-linked background claims; does not run frame-diff or alter its inputs."""
import json
from pathlib import Path

out = Path('/tmp/pix-m7-frame-diff-review-20261015')
inventory = json.loads((out/'pixel-inventory.json').read_text())['frames']
lines = [
    '# PROPOSAL ONLY. Do not use with the current single-box matcher.',
    '# #578 / ES d242000a5957ad8de5288a02fb15b21d7ef04715, composed in 3178b832b.',
    '# Absent collection preferences now enable the intended empty Last Played.',
    '# Its wrapped carousel panel shifts Favorites/Tools behind these exact screens.',
    '# Existing masks/baseline/claims stay unchanged. A strict union-of-claimed-pixels',
    '# matcher is required so neighboring foreground changes do not require enlarging',
    '# these background rectangles. No comparison or acceptance has been run.',
    '# Modal strips exclude all displayed text/controls; max8px include plain rounded',
    '# panel borders. FBN logo band claims only currently changed background runs,',
    '# leaving every unchanged logo pixel checked. NES keeps its title untouched.',
]
entries=[]
for frame in inventory:
    if not frame.get('outside_existing_masks_and_claims'):
        continue
    screen=frame['screen']
    if screen=='manager-fbn/01-0-carousel.png':
        rects=[[0,0,552,350],[0,350,315,451],[0,451,552,708]]
        rects+=json.loads((out/'fbn-logo-background-rectangles.json').read_text())
    elif screen=='manager-nes/01-0-carousel.png':
        rects=[[0,0,40,382]]
    else:
        rects=[]
        for y,x0,x1,count in frame['row_spans']:
            width=552 if x1>300 else next(v for v in (104,112,120,128,144,152,240,248) if v>=x1)
            if rects and rects[-1][2]==width and rects[-1][3]==y:
                rects[-1][3]=y+1
            else:
                rects.append([0,y,width,y+1])
    lines.append('')
    lines.append('# '+screen)
    for x0,y0,x1,y1 in rects:
        lines.append(f'd72084ccad {screen} {x0} {y0} {x1} {y1} #578  # Last Played backdrop; ES d242000a5; final fac608ff/3178b832b')
    entries.append({'screen':screen,'rectangles':rects})
(out/'proposed-578-background-claims.txt').write_text('\n'.join(lines)+'\n')
(out/'proposed-578-background-regions.json').write_text(json.dumps({'status':'UNRUN_SOURCE_PROPOSAL','screens':entries},indent=2)+'\n')
print(f'Drafted {sum(len(x["rectangles"]) for x in entries)} background rectangles across {len(entries)} existing retained screens; no verdict issued.')

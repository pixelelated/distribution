#!/usr/bin/env python3
"""Read-only pixel inventory of retained frames. Not a suite verdict or baseline update."""
import collections
import hashlib
import json
from pathlib import Path

OUT = Path('/tmp/pix-m7-frame-diff-review-20261015')
TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02')
BASE = Path('/workspace/artifacts/rocknix-images/walk-baseline')
RUN = Path('/workspace/tmp/pix-m7-final-baseline-20261014-02/artifacts/webdav/rocknix-images/qa-fac608ff89-webdav-a-20261014-2320/walks')
source = TREE / 'tools/frame-diff'
ns = {'__name__': 'frame_diff_readonly_decoder', '__file__': str(source)}
exec(compile(source.read_text(), str(source), 'exec'), ns)
decode = ns['read_png']
masks = ns['read_rects'](str(TREE / 'tools/vm-walks/masks.txt'), with_head=False)
claims = ns['read_rects'](str(TREE / 'tools/vm-walks/claims.txt'), with_head=True)
claims = [c for c in claims if c['head'] in ('*', 'd72084ccad')]
carousel_old = decode(BASE / 'manager-fbn/01-0-carousel.png')[2]
carousel_new = decode(RUN / 'manager-fbn/01-0-carousel.png')[2]
cache = {}

def dim_fit(src_a, src_b, dst_a, dst_b):
    key = (src_a, src_b, dst_a, dst_b)
    if key in cache:
        return cache[key]
    # Same unknown gradient-overlay alpha. Its additive color cancels in
    # old/new channel differences. Permit two 8-bit rounding units in a delta.
    lo, hi = 0.0, 1.0
    for a, b, c, d in zip(src_a, src_b, dst_a, dst_b):
        s, delta = b-a, d-c
        if s:
            x, y = (delta-2)/s, (delta+2)/s
            lo, hi = max(lo, min(x,y)), min(hi, max(x,y))
        elif abs(delta) > 2:
            lo, hi = 2, 1
    result = lo <= hi
    cache[key] = result
    return result

report = []
for f in sorted(BASE.glob('*/*.png')):
    screen = f.relative_to(BASE).as_posix()
    other = RUN / screen
    if not other.exists():
        report.append({'screen': screen, 'missing': True})
        continue
    w, h, ar = decode(f)
    w2, h2, br = decode(other)
    assert (w, h) == (w2, h2) == (1280, 800)
    covered = [bytearray(w) for _ in range(h)]
    relevant = ns['rects_for'](screen, masks) + ns['rects_for'](screen, claims)
    for rect in relevant:
        x0, y0, x1, y1 = rect['rect']
        for y in range(max(0,y0), min(h,y1)):
            covered[y][max(0,x0):min(w,x1)] = b'\1' * (min(w,x1)-max(0,x0))
    residual, not_carousel, not_dim = [], [], []
    changed = 0
    row_spans = []
    for y, (a, b) in enumerate(zip(ar, br)):
        if a == b:
            continue
        row_x = []
        for x in range(w):
            i = x*3
            if a[i:i+3] == b[i:i+3]:
                continue
            changed += 1
            if covered[y][x]:
                continue
            residual.append((x,y)); row_x.append(x)
            # FBNeo backdrop coordinates are shared by all non-manager frames.
            # NES's tiny wrapped sliver is inspected visually, not fitted here.
            if screen == 'manager-nes/01-0-carousel.png':
                continue
            if x >= 552 or y >= 708 or carousel_old[y][i:i+3] == carousel_new[y][i:i+3]:
                not_carousel.append((x,y))
            elif not dim_fit(carousel_old[y][i:i+3], carousel_new[y][i:i+3], a[i:i+3], b[i:i+3]):
                not_dim.append((x,y))
        if row_x:
            row_spans.append([y, min(row_x), max(row_x)+1, len(row_x)])
    def box(points):
        if not points:
            return None
        xs,ys=zip(*points)
        return [min(xs),min(ys),max(xs)+1,max(ys)+1]
    report.append({'screen':screen,'baseline_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
                   'current_sha256':hashlib.sha256(other.read_bytes()).hexdigest(),
                   'changed_pixels':changed, 'outside_existing_masks_and_claims':len(residual),
                   'residual_bounds':box(residual), 'outside_carousel_change_support':len(not_carousel),
                   'outside_carousel_support_bounds':box(not_carousel),
                   'common_overlay_alpha_nonfit':len(not_dim), 'nonfit_bounds':box(not_dim),
                   'nonfit_examples':not_dim[:12], 'row_spans':row_spans})
OUT.mkdir(exist_ok=True)
(OUT/'pixel-inventory.json').write_text(json.dumps({'analysis':'static diagnosis only; original FAIL unchanged', 'frames':report},indent=2)+'\n')
for r in report:
    if r.get('outside_existing_masks_and_claims'):
        print(r['screen'],r['outside_existing_masks_and_claims'],r['residual_bounds'],
              'outside-support',r['outside_carousel_change_support'],'alpha-nonfit',r['common_overlay_alpha_nonfit'])
print('frames',len(report),'residual',sum(r.get('outside_existing_masks_and_claims',0) for r in report),
      'outside-support',sum(r.get('outside_carousel_change_support',0) for r in report),
      'alpha-nonfit',sum(r.get('common_overlay_alpha_nonfit',0) for r in report))

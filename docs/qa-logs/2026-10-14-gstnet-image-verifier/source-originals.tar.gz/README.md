# GStreamer network dependency image readback — UNRUN

Derivative of accepted9e1ff0ef verifier. Adds libgstnet and all four linked
plugins to exact install/SYSTEM byte, mode and symlink-chain checks. Binds
current6d061af8 host state reader; Squash is unchanged. Local.read adds optional with_mtime=False and returns
the same bytes by default; the verifier uses that default. The separately
qualified log checker correction is now part of the frozen source. No product execution.
Normal original build/custody/GPT/raw-update checks and resource bounds remain.

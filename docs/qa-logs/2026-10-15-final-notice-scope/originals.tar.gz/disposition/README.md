# Final scoped notice disposition: FreeJ2ME/JLayer, ZeroTier and Doom

Use the existing retained source and notice material for FreeJ2ME/JLayer and the
unmodified Doom shareware data under the stated no-charge release scope. Preserve
their exact original wording. The specific unresolved question is ZeroTier's
included nonfree headers and whole-source redistribution, whose own definition
expressly includes incorporation into an unpaid distribution. That question does
not establish that the runtime controller implementation was selected.

This is a finite source/notice disposition under #528, not a legal guarantee or
release authorization. No product change, removal, new test, source execution,
upstream message or blanket permission gate is proposed. Previously accepted
Tailscale/additive custody and unrelated licence work are not reopened.

## Governing scope and exact selection

Root supplied the current noncommercial, no-charge release scope. The retained
canonical D-WORKFLOW-084/097/131 rows, with D-WORKFLOW-081's no-sponsorship history,
are consistent with that intent; they do not override another author's terms or
establish permission for a future paid distribution. Record head is
`2426f88aba0eaa51e448c42917ca80fde2972a16`. See `evidence/decisions.txt` and
`references.json` for the exact lines and source blob identity.

The three selected recipes were read from both actual distribution commits
`f8636de1d105275dbf9420bbabbbc26f79abb10f` and
`9aa7affee9d4ad5e69725cab20b6d7ad84d93dea`; each recipe is byte-identical between
those commits. They select FreeJ2ME1.52/source509c3590, ZeroTier1.16.0/sourceaa9de313,
and Doom inputff35cde0 at immutable ROCKNIX/packages4cb65b68. Recipe SPDX labels
apply to the recipe/script scope and do not replace bundled-work terms.

## Concrete disposition table

| Selected material | Exact evidence and meaning | Inclusion action | Genuine remaining limit |
| --- | --- | --- | --- |
| FreeJ2ME1.52 / JLayer | `HuffcodeTable.java` lines2,6–8,11–15,24–35 retain the 2004 move to LGPL, 1997 adaptation of public C source, older1991 pre-approval wording and an express Library GPL2-or-later redistribution grant together. Ant selects JLayer; retained bindings identify42 JLayer classes in each of the three accepted JARs. | Include the exact FreeJ2ME source archive, complete JLayer source/attribution headers and applicable complete LGPL text using the accepted vendor-notice packet. Preserve the historical wording verbatim; identify LGPL2-or-later from the files, not only README's LGPL2.1 shorthand or FreeJ2ME's primary GPL3 label. | The historical committee-approval record is not retained. The later explicit grant and published-source history provide a source-supported inclusion basis; this review does not invent a new requirement to obtain a1991 committee certificate or drop JLayer. The inherited line is publication-status wording, not a statement that a current patent licence must be purchased. No patent-validity or global freedom-to-operate conclusion is made. |
| ZeroTier agent/core and ext material | Root `LICENSE.txt` assigns MPL2 to agent/core and excludes ext/nonfree. MPL2 sections2.1,3.1,3.2,3.4 supply source/executable distribution conditions. The recipe runs `make -f make-linux.mk ZT_SSO_SUPPORTED=0 one`. `ZT_NONFREE`/`ZT_CONTROLLER` are not enabled by that declared default route; seven controller implementation objects and their macro are gated. | Include exact MPL-covered source, MPL2 text, source-access information and original notices; preserve separately applicable ext notices. Existing http-parser, miniupnpc and libnatpmp texts can be carried conservatively, with exact source/member associations, rather than requiring a new runtime exclusion test. | Do not describe all ZeroTier source as MPL. The accepted source route explains runtime implementation selection; it is not a binary disassembly, and source inclusion must be assessed separately. No rerun or demand for every lost historical expanded command is introduced. |
| ZeroTier included nonfree headers / complete source archive | `OneService.cpp` lines126–128 include EmbeddedNetworkController.hpp, PostgreSQL.hpp and Redis.hpp. Their copyright headers point into nonfree. Controller construction/registration remain macro-gated; PostgreSQL's body is also guarded. Current `nonfree/LICENSE.md` lines7–21,25–36 defines the covered source and includes unpaid distribution incorporation in Commercial Use, despite the Non-Commercial redistribution grant. | Preserve the complete2025 text, original header notices and source mappings in held custody. Keep this portion explicitly classified when assembling the source/notice bundle. Do not substitute stale Debian BSL/2026-change-date text or silently relabel the headers as MPL. | Exact narrow question: does the author provide a permission/exception or other applicable grant for these agent-required header declarations and verbatim selected-source delivery with this unpaid distro? The retained text does not answer that specific incorporation/source-publication question affirmatively. A current authoritative exception covering these files would settle it; absent one, root must choose the scoped disposition. This is not a demand to license an enabled runtime controller, buy a blanket ZeroTier licence, remove the package now or rebuild unrelated components. |
| ZeroTier patent paragraph | `nonfree/LICENSE.md` lines58–60 expressly provides no patent licence. MPL2's separate core grant has its own patent provisions. | Retain both texts in their actual scopes without combining their labels. | A no-patent-grant paragraph is distinct from source-publication permission. It is not itself proof of an infringed or valid patent or a newly required universal patent-clearance gate. |
| Doom1.9 shareware data | Selected WAD is4,196,020B/SHA1d7d43be; exact ENDOOM lines20–22 expressly permits free distribution and separately refers disk vendors to vendor.doc. Preserved mirror Git-blob/size matches the WAD; that mirror is not authenticated original id Software delivery. | Carry the exact unmodifiedff35 archive/WAD identity, ENDOOM raw+text, source/version association and original shareware README in the data notice/component index. Label it id Software shareware data with its own permission, separately from launcher/engine GPL. | vendor.doc was absent from the selected one-member archive and associated retained mirror tree. Under the stated no-charge, non-vending scope this is a conditional vendor/charged-bundle document limit, not a blanket stop on free distribution. Revisit only if the actual release becomes a disk-vending/charged-bundle use or other changed use. No registered-game assets, modified shareware levels or open-source licence for game data are inferred. |

## Smallest concrete next action

1. Add the existing accepted FreeJ2ME source/vendor-notice members and scoped
   Doom data notice records to the existing release source/notice member map.
   `inclusion-actions.json` names the exact source packets and retained inputs.
   This is a bundle assembly action; it needs no recollection, rebuild or test.
2. Keep ZeroTier's MPL/core and ext notice mapping ready for that same assembly.
   Record one explicit unresolved disposition for the included nonfree headers
   and delivery of the whole selected source archive. The desired evidence is
   a grant/exception covering those named files and source delivery, rather than
   a runtime-controller test or another broad licence inventory. No contact is
   authorized or performed here. The stopped historical-header/source question
   should not be widened to every component or to settled personal use.
3. Preserve conditional limits in release source notes: historical JLayer
   wording retained, Doom vendor terms outside current no-charge scope, and
   ZeroTier's split terms. Do not claim complete publication clearance from
   this disposition alone.

## Evidence and bounds

`references.json` binds46 retained supporting files to exact original archive
members or frozen Git blobs. These are selected texts/metadata, not copied source
archives, JARs, game payloads or caches. All retained member bytes were rehashed;
archived mode/ownership/time metadata are recorded as archive metadata, not as a
new host-filesystem ownership claim. Existing accepted broader source/notice
packets remain authoritative for their complete inventories.

One optional public request to the historical JavaZOOM JLayer page failed DNS
before any HTTP response: zero response bytes. Its exact URL, error and15-second/
512KiB bounds are in `public-text/01.request.json`; the local command exited0
because it preserved that failed request as data. This is not evidence the source
or permission is globally absent. No retries or further requests were made;
allocation was at most3 requests/2MiB aggregate. The selected retained source
already establishes the textual distinctions above.

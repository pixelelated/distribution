quit() { exit "$1"; }; log() { :; }
DOLPHIN_LAUNCH=true
ret_error=250
EXIT_HOTKEY_PRESSED=false
# Dolphin preparation uses the existing ES custom-error channel. Require its
# fresh message as well as its status; a native emulator's numeric exit alone
# is not a preparation refusal. This precedes the hotkey's clean-exit mapping.
if [ "${DOLPHIN_LAUNCH}" = true ] && [ "${ret_error}" = 250 ] &&
   [ -f /tmp/pix581-followup-messages/fr-message-2/launch_error.log ] && [ ! -L /tmp/pix581-followup-messages/fr-message-2/launch_error.log ]; then
        IFS= read -r DOLPHIN_ERROR_TITLE < /tmp/pix581-followup-messages/fr-message-2/launch_error.log
        if [ "${DOLPHIN_ERROR_TITLE}" = "DOLPHIN DID NOT START" ]; then
                # Remove the fixed ownership line before ES displays localized text.
                DOLPHIN_VISIBLE_ERROR=$(mktemp /tmp/pix581-followup-messages/fr-message-2/visible.XXXXXX) || quit 1
                if ! sed '1d' /tmp/pix581-followup-messages/fr-message-2/launch_error.log > "${DOLPHIN_VISIBLE_ERROR}" ||
                   ! mv -f "${DOLPHIN_VISIBLE_ERROR}" /tmp/pix581-followup-messages/fr-message-2/launch_error.log; then
                        rm -f "${DOLPHIN_VISIBLE_ERROR}"
                        quit 1
                fi
                quit 250
        fi
fi
case "${ret_error}" in
  0)
        quit 0
  ;;
  137|143)
        log $0 "emulator ended by signal (${ret_error}, the exit hotkey); a clean exit"
        quit 0
  ;;
  *)
        if [ "${EXIT_HOTKEY_PRESSED}" = true ]
        then
                log $0 "emulator exited ${ret_error} after the exit hotkey was pressed (marker consumed); a clean exit"
                quit 0
        fi
        log $0 "exiting with ${ret_error}"
        quit 1
  ;;
esac

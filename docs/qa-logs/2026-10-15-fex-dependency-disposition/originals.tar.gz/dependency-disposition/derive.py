from pathlib import Path
import ast
import base64
import hashlib
import json
import re

P = Path(__file__).resolve().parent
L = json.loads((P / 'read-ledger.json').read_text())


def record(suffix):
    return next(r for r in L if r['status'] == 'EXACT_TEXT' and r['path'].endswith(suffix))


def text(suffix):
    return (P / record(suffix)['member']).read_text()


def data(suffix):
    return json.loads(text(suffix))


def ref(suffix):
    r = record(suffix)
    return {k: r[k] for k in ['path', 'member', 'sha256', 'bytes']}


def put(name, value):
    (P / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


issue = data('/pix-m7-528-current-20261015-1249.json')
criteria = [line for line in issue['body'].splitlines() if line.startswith('- [ ]')]
assert len(criteria) == 5
summary = data('/dependency-summary.json')
assert summary['all_accepted_hashes_match'] and len(summary['rows']) == 13
inventories = {profile: data('/' + profile + '/publication-worklist.json')
               for profile in ['sm8550-aarch64', 'sm8550-arm']}
inputs = data('/sm8550-aarch64/inventory-inputs.json')
assert inputs['distribution_commit'] == '9aa7affee9d4ad5e69725cab20b6d7ad84d93dea'
for r in L:
    prefix = inputs['host_worktree'] + '/'
    if r['path'].startswith(prefix):
        relative = r['path'][len(prefix):]
        if relative in inputs['source_files']:
            assert r['sha256'] == inputs['source_files'][relative]
gitmeta = data('/e869aa644a16e4332cdc15c1ea0b4d13d482385d.json')
assert record('/e869aa644a16e4332cdc15c1ea0b4d13d482385d.json')['sha256'] == '3d2263949b6c14210b028e3e8c50b13819e9426021df73eae2ec81057c1f851a'
for suffix in ['Source/Common/Config.cpp', 'Source/Tools/LinuxEmulation/LinuxSyscalls/FileManagement.cpp',
               'Source/Tools/FEXRootFSFetcher/Main.cpp']:
    payload = (P / record('/' + suffix)['member']).read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
    assert blob == gitmeta['entries'][suffix]['git_blob']

config = data('/compat/fex-emu/config/fex-emu/Config.json')
assert config['Config']['RootFS'] == 'ArchLinux' and config['ThunksDB']['GL'] == 0
providers = []
for soname in ['libstdc++.so.6', 'libX11.so.6', 'libGL.so.1']:
    consumers = [r for r in summary['rows'] if soname in r['DT_NEEDED']]
    candidates = [r for r in summary['rows'] if soname == r['DT_SONAME']]
    providers.append(dict(needed=soname, consumers=consumers, accepted_shipped_soname_candidates=candidates,
                          provider_status='Shipped FEX GL thunk candidate for both guest classes; configured overlay is disabled by default; actual runtime provider not observed' if candidates else 'Concrete guest-rootfs provider path/version/hash not established by these accepted receipts',
                          native_SM_packages_are_guest_providers=False,
                          actual_loader_resolution_observed=False))
native = {profile: [r for r in inventory['components'] if r['component'] in
                   ['gcc', 'glibc', 'libX11', 'libglvnd', 'libdrm', 'fex-emu']]
          for profile, inventory in inventories.items()}
put('provider-disposition.json', dict(distribution_commit=inputs['distribution_commit'],
    accepted_elf_readback=ref('/dependency-summary.json'), providers=providers,
    guest_runtime_config=dict(rootfs='ArchLinux', rootfs_artifact_identity=None,
        default_GL_overlay_enabled=False, evidence=ref('/compat/fex-emu/config/fex-emu/Config.json')),
    resolver_source=[ref('/FileManagement.cpp'), ref('/FEXRootFSFetcher/Main.cpp')],
    native_profile_component_rows=native,
    inventory_refs={p: ref('/' + p + '/publication-worklist.json') for p in inventories},
    distinction='Nix fex-dev-rootfs is the compilation sysroot. Configured ArchLinux is a separate guest runtime rootfs. Native aarch64 and ARM compatibility package rows cannot identify x86/x86-64 guest runtime providers.',
    limits='No guest rootfs inventory or loader execution was collected. Absence of an ArchLinux component row alone is not an exhaustive proof of absence from every payload.'))

sources = data('/source-acquisition-candidates.json')
fetches = json.loads((P / 'fetch-descriptors.json').read_text())
byname = {Path(x['derivation_path']).name: x for x in fetches}
historical = data('/manifest.json')
assert record('/manifest.json')['sha256'] == 'a7022b76da76a9f6771bb7693d6f6e25854c6731db0750bb46dde29f14d49fce'
mirrors = text('/mirrors.nix')
mirror_bases = {}
for key in ['alsa', 'gcc', 'gnu', 'kernel', 'xorg']:
    block = re.search(r'(?m)^\s*' + key + r'\s*=\s*\[(.*?)\];', mirrors, re.S)
    assert block
    mirror_bases[key] = next(x for x in re.findall(r'"([^"\n]+)"', block.group(1)) if x.startswith('https://'))


def urls(fields):
    result = []
    for value in fields.get('urls', fields.get('url', '')).split():
        if value.startswith('mirror://'):
            mirror, rest = value[len('mirror://'):].split('/', 1)
            value = mirror_bases[mirror].rstrip('/') + '/' + rest
        if value.startswith('https://') and value not in result:
            result.append(value)
    return result


primary = {'gcc', 'i686-unknown-linux-gnu-gcc', 'glibc', 'linux-headers', 'alsa-lib',
           'libdrm', 'wayland', 'libglvnd', 'libx11', 'libxcb', 'libxrandr', 'libxrender', 'xorgproto'}
selected = [x for x in sources['candidate_derivations'] if x['package'] in primary]
patches = sorted({p for x in selected for p in x['patch_store_paths']})
groups = {}
for row in selected:
    group = groups.setdefault(row['source_store_path'], dict(source_store_path=row['source_store_path'],
                              packages=[], derivations=[], fetch_refs=[], urls=[], hash=None,
                              hash_mode=None))
    group['packages'].append(dict(name=row['package'], version=row['version']))
    group['derivations'].append(dict(path=row['derivation_path'], sha256=row['derivation_sha256']))
    for fetch in row['fetch_derivations']:
        descriptor = byname[Path(fetch['path']).name]
        f = descriptor['fetch_fields']
        group['fetch_refs'].append(dict(path=descriptor['derivation_path'], sha256=descriptor['derivation_sha256']))
        for url in urls(f):
            if url not in group['urls']:
                group['urls'].append(url)
        if f.get('outputHash'):
            digest = base64.b64decode(f['outputHash'].removeprefix('sha256-')).hex()
            assert group['hash'] in (None, digest)
            group['hash'] = digest
            group['hash_mode'] = f['outputHashMode']
    digest = group['hash']
    if group['hash_mode'] == 'flat' and digest in historical['archives']:
        group['disposition'] = 'REUSE_EXACT_HISTORICAL_ARCHIVE'
        group['custody'] = dict(manifest=ref('/manifest.json'), member='archives/' + digest,
                                bytes=historical['archives'][digest]['bytes'], sha256=digest)
    elif group['hash_mode'] == 'flat':
        group['disposition'] = 'ACQUIRE_ONE_FLAT_HASHED_ARCHIVE'
    else:
        group['disposition'] = 'SEPARATE_RECURSIVE_SOURCE_TREE_CUSTODY'
        group['warning'] = 'Recursive/NAR digest is not the compressed HTTP response SHA-256; do not compare it as a flat download hash.'
new = [g for g in groups.values() if g['disposition'] == 'ACQUIRE_ONE_FLAT_HASHED_ARCHIVE']
reuse = [g for g in groups.values() if g['disposition'] == 'REUSE_EXACT_HISTORICAL_ARCHIVE']
recursive = [g for g in groups.values() if g['disposition'] == 'SEPARATE_RECURSIVE_SOURCE_TREE_CUSTODY']
assert len(new) == 8 and len(reuse) == 3 and len(recursive) == 1 and len(patches) == 22
put('acquisition-proposal.json', dict(status='PROPOSAL_ONLY_NO_DOWNLOADS_OR_SOURCE_TREE_COPY',
    rationale='Preserve selected API, C/C++, and UAPI header source plus patches. This is not a gate on all 81 Nix development-closure rows.',
    phase_A=dict(description='Eight exact flat source archives; bind accepted fetch descriptors and hash each retained response',
                 files=new, count=8, proposed_limits=dict(per_response_bytes=201326592,
                 aggregate_retained_archive_bytes=402653184, process_seconds=600,
                 network_request_count=8, retries=0),
                 lifecycle='Root must review a concrete collector, fresh owner, before-write bounds, failure receipts, admission and supervisor before execution.'),
    reused_archive_sources=reuse,
    phase_B=dict(nixpkgs=sources['nixpkgs'], recursive_libglvnd_source=recursive,
                 selected_patch_store_paths=patches, patch_count=22,
                 proposed_patch_read_limits=dict(per_file_bytes=1048576, aggregate_bytes=8388608),
                 notes='Exact Nixpkgs commit source and the one libglvnd recursive source need custody. Patch payload bytes/hashes are not read here; preserve all 22 selected applied patches or prove their member identities in the retained pin. Do not substitute the existing GitHub libglvnd archive for the Nix GitLab tree solely because both say 1.7.0.'),
    not_added_as_automatic_gates=dict(packages=['Clang compiler binary', 'LLVM development closure', 'compiler-rt source split derivations', 'libXext', 'libXau', 'libXdmcp', 'other transitive build tools'],
        reason='No selected source/header contribution or shipped guest provider is established here merely from these closure rows. libXau and libXdmcp source hashes already exist historically if later needed. Compiler runtime source should be added only for identified linked/incorporated code.'),
    mirror_resolution_evidence=ref('/mirrors.nix'), downloads_executed=False))

notices = []
specs = [
    ('GNU C++ 14.3 headers', '/functional', 'GPL-3.0-or-later with GCC Runtime Library Exception 3.1; additional Silicon Graphics notice also present', 'Preserve COPYING3, COPYING.RUNTIME, full per-file notices and exact selected headers/source. The exception must travel with the GPL text; this is not a claim that the GCC compiler itself is shipped.'),
    ('GNU C++ 14.3 unordered_map', '/unordered_map', 'GPL-3.0-or-later with GCC Runtime Library Exception 3.1', 'Preserve the exact marked header and associated texts.'),
    ('glibc 2.40-224 headers', '39l6rhxg9qb07q3862p4zcr2s4146p1r-glibc-2.40-224-dev/include/features.h', 'LGPL-2.1-or-later marking', 'Retain glibc source plus the selected 11 patches and full applicable license/copyright texts; do not substitute native glibc 2.41 metadata.'),
    ('ALSA 1.2.14 headers', '/asoundlib.h', 'LGPL-2.1-or-later marking', 'Reuse the exact historical ALSA source archive; preserve header notices and full library license text, plus two selected Nix patches.'),
    ('libdrm 2.4.129 headers', 'libdrm-2.4.129-dev/include/xf86drm.h', 'Precision Insight and VA Linux permissive notice', 'Preserve full copyright, permission and disclaimer, with the selected Nix source and native target-sysroot DRM source already in distribution custody.'),
    ('Linux 6.16.7 UAPI headers', '/9a975kwlj5hyfq8y6hsapfaj5pj7g090-linux-headers-6.16.7/include/linux/types.h', 'GPL-2.0 WITH Linux-syscall-note', 'Preserve the syscall exception and applicable GPL text with exact exported header source and selected patch; do not treat a UAPI header as shipping a second kernel.'),
    ('libglvnd 1.7.0 GLX header', '/glx.h', 'Mesa/Brian Paul permissive notice', 'Preserve exact full notice and source; the distribution recipe PKG_LICENSE=GPL is not a replacement for this third-party header notice.'),
    ('Wayland 1.24.0 headers', '/wayland-client.h', 'Kristian Hogsberg permissive notice', 'Preserve complete header/source notices, including generated protocol headers, and the selected Nix patch.'),
    ('libX11 1.8.12 headers', '/Xlib.h', 'The Open Group permission, supporting-documentation and name-use clauses', 'Preserve complete per-file notices and source COPYING; native libX11 1.8.13 is not the same source input.'),
    ('libxcb 1.17.0 headers', '/xcb.h', 'Massey, Sharp and Triplett permissive notice including name-use clause', 'Reuse exact historical source and preserve its full notices; include generated protocol-header sources from that package.'),
    ('libXrandr 1.5.4 headers', '/Xrandr.h', 'Compaq, HP, Intel and Red Hat permission/name-use notice', 'Retain exact source and full notice; it includes Xrender and xorgproto headers.'),
    ('libXrender 0.9.12 headers', '/Xrender.h', 'SuSE permission/supporting-documentation/name-use notice', 'Reuse exact historical source and preserve complete notice.'),
    ('xorgproto 2024.1 headers', '/Xproto.h', 'The Open Group and Digital notices', 'Retain exact source and full compound notices; a generic MIT label would lose terms.'),
]
for component, suffix, marking, action in specs:
    notices.append(dict(component=component, evidence=ref(suffix), observed_marking=marking, required_packet_action=action))
put('header-notice-disposition.json', dict(scope='Exact selected development-header markings and packet inclusion actions; not a blanket license clearance',
    notices=notices, prior_FEX_Vulkan_Khronos_CUDA_notices=ref('/notice-disposition.json'),
    selected_header_provenance_limit='Retained headers are from the exact derivation-named development outputs. Source include paths and interfaces support relevance; no new compiler dependency trace or full preprocessing was run.',
    all_license_texts_complete=False, copyright_notices_preserved_in_retained_headers=True))
put('criteria-disposition.json', dict(issue=dict(number=issue['number'], url=issue['url'], evidence=ref('/pix-m7-528-current-20261015-1249.json')),
    current_open_criteria=criteria, no_criterion_closed=True,
    contribution='Narrows FEX component/notice/source mapping for criteria 1-3. Independent retrieval, off-host custody and final cross-links in criteria 4-5 remain outside this lane. No whole compiler closure or missing historic installer/log gate is added.'))
print(json.dumps(dict(new_flat_archives=len(new), reused_exact_archives=len(reuse),
    recursive_source_trees=len(recursive), selected_patch_paths=len(patches), header_notice_records=len(notices))))

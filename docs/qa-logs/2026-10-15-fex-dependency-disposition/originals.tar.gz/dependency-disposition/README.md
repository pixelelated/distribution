# FEX guest dependency and source disposition

This packet resolves what the existing evidence establishes about the three dynamic names in the 13 accepted guest thunks. It reads the current #528 criteria and preserves all five as open. No released packet, shared record, source cache, or product artifact was changed.

## Runtime providers

| Name | Accepted consumers | Provider established by current evidence |
| --- | --- | --- |
| `libstdc++.so.6` | All 13 guest thunks | An x86 or x86-64 guest runtime provider is required. Its concrete guest-rootfs path, version and hash are not identified by the accepted receipts. |
| `libX11.so.6` | Both GL guest thunks | Concrete guest-rootfs provider remains unidentified. The link-time placeholder has no install rule; it is not a demonstrated shipped provider. |
| `libGL.so.1` | Both EGL guest thunks | Both accepted GL guest thunks have this SONAME and matching guest architecture. They are shipped provider candidates; actual selection depends on the guest namespace and enabled overlay. |

The frozen distribution Config.json selects **`ArchLinux`** as the runtime rootfs and sets **GL thunk enablement to zero by default**. The retained exact FEX `FileManagement.cpp` confirms that disabled thunk entries are skipped, enabled overlays redirect guest rootfs paths to the installed thunk files, and 32-bit mode selects `GuestThunks_32`. `ThunksDB.json` maps GL library paths to `libGL-guest.so`.

This does not establish a runtime failure. No guest rootfs or loader ran in this lane. The accepted inventory does not name an immutable ArchLinux guest-rootfs artifact or its library providers; that is a precise evidence limit, not an exhaustive claim that no nested rootfs exists anywhere. The FEX fetcher source supports separate rootfs selection/download into its data directory. If the release redistributes a guest rootfs, its exact artifact/package inventory must identify those providers. Do not create a source-acquisition requirement for an unspecified, separately selected guest rootfs merely because the default configuration names ArchLinux.

The Nix **`fex-dev-rootfs` is a compilation sysroot**, distinct from this runtime rootfs. SM8550 aarch64 and ARM compatibility component rows describe native-profile GCC 15.2.0, glibc 2.41, X11 1.8.13 and other libraries. Their names are not evidence that they satisfy an x86 guest dependency. Nix GCC 14.3.0 and its development outputs also do not identify the user's runtime provider.

`provider-disposition.json` retains the exact 13 consumer rows, both shipped GL candidates, the native package rows, configuration hash and source references. No universal compiler-closure or historical-log requirement has been added.

## Exact header/source notices

Thunks contain generated C++ and are built from API and language headers. Their source/notice treatment cannot be limited to the three DT_NEEDED names. The retained interface enables Vulkan XLIB, XRANDR, XCB and Wayland declarations; GLX includes Xlib; Xrandr includes Xrender; DRM includes Linux UAPI types. The target-sysroot DRM include directory is explicit in the recorded generator command, so both native and Nix header provenance remain visible.

`header-notice-disposition.json` binds 13 exact header records to their complete retained bytes and inclusion actions:

- GCC 14.3 headers mark GPL-3.0-or-later **with GCC Runtime Library Exception 3.1**, point to `COPYING3` and `COPYING.RUNTIME`, and include an additional Silicon Graphics notice in `functional`.
- glibc and ALSA headers mark LGPL-2.1-or-later. Preserve the full applicable texts and selected source/patches, not the native recipes' abbreviated declarations.
- Linux UAPI `linux/types.h` marks **GPL-2.0 WITH Linux-syscall-note**. Keep the exception with the source; this is not a second shipped kernel.
- DRM, GLX, Wayland and Xorg headers carry specific copyright, permission, disclaimer, supporting-documentation and/or name-use clauses. Preserve each full notice. For example, the actual GLX header carries Mesa/Brian Paul terms; the distribution libglvnd recipe's `PKG_LICENSE=GPL` is not a replacement.
- Existing exact FEX MIT, Vulkan-Headers, bundled Khronos GL and FEX CUDA notices remain referenced from the immutable prior packet.

These retained headers establish specific notice text and source relevance. They are not a complete preprocessing trace or a full delivered notice bundle. Full licence/exception texts and complete component notices still need materialization from the selected source. Clang resource headers or runtime code actually incorporated would need their own source-specific treatment; the presence of the compiler or compiler-rt in a development closure alone does not establish such incorporation.

## Smallest supported next acquisition batch

The 20 named fetch derivations were read as text and parsed without Nix. Their original hash modes are retained. Duplicate 32/64-bit source fetches collapse to one archive.

**Reuse three exact historical archives**: ALSA 1.2.14, libxcb 1.17.0 and libXrender 0.9.12. Their flat SHA-256 values match the retained historical source manifest. No archive payload was reread here. Historical libXau and libXdmcp sources also match if later needed; neither is added to the selected-header batch merely through a library dependency.

**Eight new flat archives have supported URLs and SHA-256 values**, recorded in `acquisition-proposal.json`:

| Source | Version |
| --- | --- |
| GCC source, shared by both C++ header configurations | 14.3.0 |
| glibc base source, plus selected patches for 2.40-224 | 2.40 |
| Linux source for selected UAPI headers | 6.16.7 |
| libdrm | 2.4.129 |
| Wayland | 1.24.0 |
| libX11 | 1.8.12 |
| libXrandr | 1.5.4 |
| xorgproto | 2024.1 |

HTTPS mirror expansion is grounded in the exact frozen Nixpkgs `mirrors.nix`, not guessed from current websites. The proposed first allocation has eight requests, no retries, 192 MiB per response, 384 MiB total retained archives and 600 seconds. Root must first review a concrete collector with before-write bounds, admission, supervision and failure receipts. This packet performs no downloads.

Separately, preserve the exact frozen **Nixpkgs commit `b6018f87da91d19d0ab4cf979885689b469cdd41`**, the **one libglvnd 1.7.0 recursive source tree**, and **22 selected patch paths**. Their exact existing references are in the proposal. The Nixpkgs archive has no pre-established flat digest in this evidence. The libglvnd digest is recursive/NAR metadata and must not be checked as the downloaded tarball's flat SHA-256. The existing GitHub libglvnd 1.7.0 archive cannot automatically stand in for the Nix GitLab tree solely by version label. Patch payloads were not read here; the proposed named-path retention cap is 1 MiB each / 8 MiB total.

This is a focused source-input batch, not the entire 81-row compiler/development closure. It reuses the retained FEX Git/submodule source, generated source readback, and frozen distribution recipe/patch custody. Additional compiler resources or transitive sources are added only for an identified contribution, rather than as a blanket gate. The batch does not claim that all remaining source/notice questions are already closed.

## Evidence and limits

The current #528 issue receipt is `/tmp/pix-m7-528-current-20261015-1249.json`; its five literal criteria and this packet's contribution are retained in `criteria-disposition.json`. This work advances component, notice and source mapping for criteria 1-3. Independent retrieval, off-host custody, final cross-links and publication clearance remain separate.

All new reads were exact named text files. The read ledger contains 66 files and 5,794,660 bytes, under the chosen 128-file / 16 MiB source-only bound. There was no directory/cache walk, binary read or execution, Nix invocation, network, service, VM, build, or source archive extraction. The three FEX resolver/fetcher sources match their exact historical Git blob identities, and frozen recipe/config hashes match accepted input maps. Selected header hashes, complete text receipts and fetch descriptors are retained under `originals/`.

Static processing checks parsed receipts, source bindings, archive hash reuse, acquisition counts and Python syntax. An initial derived-document pass had an incorrect retained-path suffix and was corrected; it did not run product code or change original evidence. `SHA256SUMS` seals this packet. The prior disposition, generated-source readback and additive custody packets remain unchanged.

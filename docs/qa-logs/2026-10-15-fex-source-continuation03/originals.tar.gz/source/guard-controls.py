#!/usr/bin/env python3
"""Focused synthetic definitions only; optional fresh bounded receipt, no collector run."""
from pathlib import Path
import argparse,ast,contextlib,hashlib,io,json,re,runpy,time,urllib.parse
P=Path(__file__).resolve().parent
source=(P/'templates/collect.py').read_bytes()
binding=json.loads((P/'guard-controls-binding.json').read_text())
assert hashlib.sha256(source).hexdigest()==binding['collector_sha256']
base=P/'guard-controls-base.py'
assert hashlib.sha256(base.read_bytes()).hexdigest()==binding['base_guard_sha256']
with contextlib.redirect_stdout(io.StringIO()) as capture:
    runpy.run_path(str(base),run_name='guard_controls_base_only')
base_result=json.loads(capture.getvalue())
assert base_result['result']=='PASS_SYNTHETIC_OUTPUT_GUARD_CONTROLS' and len(base_result['cases'])==14
rows=base_result['cases']
names={'account_output','effective_request_cap','reserve_payload','release_payload','validate_request_url','public_url','curl_argv','check_request_count','download'}
tree=ast.parse(source);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert {n.name for n in nodes}==names
selected=ast.Module(body=nodes,type_ignores=[])
assert hashlib.sha256(ast.dump(selected,include_attributes=False).encode()).hexdigest()==binding['extended_guard_ast_sha256']
ns={'time':time,'urllib':urllib,'hashlib':hashlib}
exec(compile(selected,'selected-source-acquisition-guard-definitions','exec'),ns)
def setup(output=100,compressed=100):
    ns.update(OUTPUT_BYTES=output,compressed_bytes=compressed,payload_reservations=[],downloads=[],start=time.monotonic(),
        PLAN={'owner_output_enforcement':{'supervisor_receipt_reserve_bytes':64,'failure_receipt_budget_bytes':12,'supervisor_receipt_margin_bytes':4}},
        RESOURCES={'per_file_bytes':128,'owner_output_ceiling_bytes':1000,'compressed_archive_aggregate_bytes':384,
            'compressed_archive_per_file_bytes':128,'request_metadata_reserve_bytes':16,'request_connect_seconds':10,
            'logical_download_seconds':120,'max_http_requests_including_redirects':35,'max_redirects_per_download':4,'collector_soft_seconds':580})
def case(name,action,refuse=False):
    try:action()
    except (AssertionError,ValueError):
        assert refuse,name+' unexpectedly refused';rows.append(dict(case=name,result='PASS_EXPECTED_REFUSAL'))
    else:
        assert not refuse,name+' unexpectedly accepted';rows.append(dict(case=name,result='PASS'))
def equal(left,right):assert left==right,(left,right)
setup(compressed=300)
case('aggregate-remainder-shrinks-actual-three-stream-cap',lambda:equal(ns['effective_request_cap'](),84))
setup(output=900,compressed=0)
case('owner-remainder-shrinks-actual-three-stream-cap',lambda:equal(ns['effective_request_cap'](),6))
setup(compressed=384);case('zero-aggregate-remainder-refuses',lambda:ns['effective_request_cap'](),True)
setup(output=921);case('insufficient-owner-three-stream-reserve-refuses',lambda:ns['effective_request_cap'](),True)
setup();r=ns['reserve_payload']('memory-only:body',100)
assert ns['OUTPUT_BYTES']==200 and ns['compressed_bytes']==200
ns['release_payload'](r,30,True)
case('payload-reserved-before-write-and-release-after-wait',lambda:equal((ns['OUTPUT_BYTES'],ns['compressed_bytes'],r['released_bytes']),(130,130,70)))
for name,actual,wait,already in [('payload-without-wait-refuses',30,False,False),('payload-duplicate-release-refuses',30,True,True),('payload-over-cap-refuses',101,True,False)]:
    setup(output=400,compressed=200)
    r=dict(reserved_bytes=100,actual_bytes=30 if already else None,released_bytes=70 if already else 0,original_wait_observed=already)
    before=r.copy();case(name,lambda:ns['release_payload'](r,actual,wait),True)
    assert r==before and ns['OUTPUT_BYTES']==400 and ns['compressed_bytes']==200
setup(compressed=300);case('aggregate-reservation-over-limit-refuses-before-counter-change',lambda:ns['reserve_payload']('memory-only:body',85),True)
assert ns['OUTPUT_BYTES']==100 and ns['compressed_bytes']==300
selection=dict(key='one',canonical_url='https://upstream.example/source.tar.xz',allowed_redirect_hosts=['upstream.example','mirror.example'],sha256='a'*64)
case('exact-canonical-request-accepted',lambda:ns['validate_request_url'](selection['canonical_url'],selection,0))
case('explicit-mirror-signed-query-accepted',lambda:ns['validate_request_url']('https://mirror.example/private/source?signature=private',selection,1))
for name,url,hop in [
    ('changed-initial-url-refuses','https://upstream.example/other.tar.xz',0),
    ('http-downgrade-refuses','http://mirror.example/source',1),
    ('unlisted-host-refuses','https://other.example/source',1),
    ('userinfo-refuses','https://user:secret@mirror.example/source',1),
    ('explicit-port-refuses','https://mirror.example:443/source',1),
    ('fragment-refuses','https://mirror.example/source#fragment',1),
    ('control-character-refuses','https://mirror.example/source\n',1),
    ('oversize-url-refuses','https://mirror.example/'+('a'*8192),1)]:
    case(name,lambda:ns['validate_request_url'](url,selection,hop),True)
case('public-redirect-redacts-path-and-query',lambda:equal(ns['public_url']('https://mirror.example/private/secret?token=secret'),'https://mirror.example/[redacted]'))
case('public-invalid-authority-redacts-entire-url',lambda:equal(ns['public_url']('https://user:secret@mirror.example/private?token=secret'),'[invalid-or-redacted-url]'))
setup();argv=ns['curl_argv']('/host/curl',selection['canonical_url'],'memory-only:body',84,29)
def argv_check():
    assert argv[1]=='-q' and '--location' not in argv and '--location-trusted' not in argv
    assert argv[argv.index('--retry')+1]=='0' and argv[argv.index('--max-filesize')+1]=='84'
    assert argv[argv.index('--max-time')+1]=='29' and argv[argv.index('--proto')+1]=='=https'
case('curl-explicit-protocol-no-config-no-retry-no-auto-redirect-actual-cap',argv_check)
case('expired-logical-deadline-refuses-before-curl',lambda:ns['curl_argv']('/host/curl',selection['canonical_url'],'memory-only:body',84,0),True)
setup();ns['downloads']=[{}]*35;case('actual-http-request-thirty-six-refuses',lambda:ns['check_request_count'](0),True)
setup();ns['downloads']=[{}]*34;case('actual-http-request-thirty-five-allowed',lambda:ns['check_request_count'](4))
case('redirect-hop-five-refuses',lambda:ns['check_request_count'](5),True)
def exercise(responses,expected_calls,refuse=False):
    setup();calls=[]
    def fake_request(s,url,hop,curl,deadline):
        ns['check_request_count'](hop);ns['validate_request_url'](url,s,hop)
        calls.append(url);ns['downloads'].append(dict(url=url,hop=hop))
        assert len(calls)<=len(responses),'unexpected extra request'
        code,http,redirect,sha=responses[len(calls)-1]
        return dict(original_curl_returncode=code,http_status=http,body={'sha256':sha}),redirect
    ns['request']=fake_request
    try:ns['download'](selection,{'path':'memory-only:curl'})
    except AssertionError:
        assert refuse
    else:assert not refuse
    assert len(calls)==expected_calls
case('single-request-exact-flat-hash-success',lambda:exercise([(0,200,'','a'*64)],1))
redirects=[(0,302,'https://mirror.example/hop'+str(i),'b'*64) for i in range(1,5)]
case('four-explicit-redirects-five-actual-requests-allowed',lambda:exercise(redirects+[(0,200,'','a'*64)],5))
case('fifth-redirect-stops-without-sixth-request',lambda:exercise(redirects+[(0,302,'https://mirror.example/hop5','b'*64)],5,True))
case('redirect-loop-stops-before-repeat-request',lambda:exercise([(0,302,selection['canonical_url'],'b'*64)],1,True))
case('curl-http-failure-stops-without-retry',lambda:exercise([(22,404,'','b'*64)],1,True))
case('curl-timeout-stops-without-retry',lambda:exercise([(28,0,'','b'*64)],1,True))
case('wrong-flat-sha256-stops-without-retry',lambda:exercise([(0,200,'','b'*64)],1,True))
case('unexpected-mirror-host-stops-before-contact',lambda:exercise([(0,302,'https://other.example/source','b'*64)],1,True))
assert len(rows)>=30 and len(rows)==len({r['case'] for r in rows})
report=dict(result='PASS_SYNTHETIC_SOURCE_ACQUISITION_GUARDS',collector_sha256=binding['collector_sha256'],
    guard_controls_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=rows,
    candidate_module_imported_or_main_run=False,network_used=False,filesystem_writes_except_requested_receipt=False,
    scope='Extracted sealed function definitions with memory paths, counters and fake requests only. No curl, subprocess, collector, preparer, production owner census, source archive read or runtime qualification.')
raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<=256*1024
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path);args=parser.parse_args()
if args.output is not None:
    p=args.output
    assert p.parent==Path('/workspace/tmp') and p.parent.resolve(strict=True)==p.parent
    assert re.fullmatch(r'pix-m7-fex-source-acquisition-guards-20261015-[0-9]{2}\.json',p.name)
    assert not p.exists() and not p.is_symlink()
    with p.open('xb') as f:f.write(raw)
print(raw.decode(),end='')

# FEX phase-A continuation 03 — source only, unrun

This packet preserves both consumed original failures and the verified Linux archive. Seven archives remain missing, in the same order: glibc, GCC, Wayland, libX11, xorgproto, libXrandr, then libdrm. Only the glibc route changes.

| Source | Next exact request | Expected flat SHA-256 |
| --- | --- | --- |
| glibc 2.40 | `https://ftp.gnu.org/pub/gnu/glibc/glibc-2.40.tar.xz` | `19a890175e9263d748f627993de6f4b1af9cd21e03f080e4bfb3a1fac10205a2` |
| GCC 14.3.0 | `https://mirror.koddos.net/gcc/releases/gcc-14.3.0/gcc-14.3.0.tar.xz` | `e0dc77297625631ac8e50fa92fffefe899a4eb702592da5c32ef04e2293aca3a` |

The exact held `mirrors.nix` names `https://ftp.gnu.org/pub/gnu/` as GNU's master repository. Appending the accepted glibc fetch's unchanged `glibc/glibc-2.40.tar.xz` suffix yields the direct route above. The glibc redirect allowlist **shrinks to `ftp.gnu.org` alone**. No contact with the rejected `mirror.team-cymru.com` is proposed. The old ftpmirror URL remains as a provenance field; tuple identity and intended ordering are checked separately from this one explicit route revision.

For GCC, the frozen `gcc` mirror list supports HTTPS koddos and bigsearcher; its official `gcc.gnu.org` endpoint is FTP. This packet keeps the already supported HTTPS URL and existing two-host route. It does not invent a direct HTTPS archive path or downgrade TLS. All other selected URLs, flat hashes and host routes are unchanged. Any failed request stops the collector; no automatic retry, exception suppression or fallback is added.

## Preserved evidence and cumulative bounds

- Owner 01: original run `20261015T132811Z-4942e582` ended 1/0/1 after Linux completed and libdrm had curl 35 / HTTP 0 / zero body. Linux's exact 152,673,392-byte body remains referenced and is rehashed in place by the existing before/after collection and success-consumption path. It is not recopied or requested again.
- Owner 02: original run `20261015T134634Z-fc71de07` ended 1/0/1 after glibc returned curl 0 / HTTP 302 / **166 body bytes**, pointing outside the allowlist. The new mirror was not contacted. No new archive completed. The investigation, acceptance, consumption exit, failure receipt and original HTTP receipt are bound by hash.
- The new response-body allowance is **249,979,626 bytes**. Prior Linux 152,673,392 + prior redirect 166 + new allowance equals the unchanged **402,653,184-byte / 384 MiB** total. Every new redirect body and failed partial continues to count.
- Still seven logical downloads, **at most 35 actual requests**, four explicit redirects each, no retries, **192 MiB per body**, 1 GiB fresh owner, 2 GiB retention reservation and 16 MiB normal receipt reserve. The actual body and both stream limits are reserved before write; no limit widens.
- The unchanged 580-second soft deadline, 600-second collector supervisor, 630+15-second outer timeout, 120-second logical request budget, 10-second connection budget, two CPUs, 2 GiB address space, fixed file counts and bounded failure/lifecycle receipts remain in force.

Raw curl stdout/stderr remain private and excluded from Git. This packet retains only safe structured receipts and source metadata. The prior failures stay failed-investigated; their original outcomes are never replaced. Phase B remains paused, and no notice/retrieval/offhost/publication clearance is asserted.

## Source delta and checks

`changes.diff` is the exact delta from sealed continuation 02 (`31fb9a8b69288abb9ae155d3203cc937e9fbe662ff54bb956ec08afd973db3ce`). `changed-lines.json` names changed executable-source line numbers. `source-provenance.json` records every compared digest. **Collector, transport/reservation definitions, both guard scripts, supervisor, process-identity helper and run.sh are byte-identical to continuation 02.** Binding checks add the one explicit route revision, the second original failure and the tightened aggregate; the consumer accounts for 166 additional prior body bytes. Preparation protects both prior owners and uses the new budget.

`static-review.json` records AST/JSON and Bash syntax parsing, exact route/tuple/order checks and unchanged-guard comparisons. It does not claim a guard or collector pass. No archive body was read here and no network, preparation or collection ran.

## Ready coordinator commands

The fresh default owner is `/workspace/tmp/pix-m7-fex-source-acquisition-20261015-03`; the new default guard report uses suffix 03. Neither is created by this packet. Each step is separately allocated and reviewed:

```bash
bash /tmp/pix-m7-fex-source-acquisition-continuation03-20261015/commands.sh guards
# Export TASK_GUARD_RUN, TASK_CURL_PATH and TASK_CURL_SHA256 from the original watched guards and resolved host curl.
bash /tmp/pix-m7-fex-source-acquisition-continuation03-20261015/commands.sh prepare
bash /tmp/pix-m7-fex-source-acquisition-continuation03-20261015/commands.sh preflight
bash /tmp/pix-m7-fex-source-acquisition-continuation03-20261015/commands.sh report
bash /tmp/pix-m7-fex-source-acquisition-continuation03-20261015/commands.sh admit
bash /tmp/pix-m7-fex-source-acquisition-continuation03-20261015/commands.sh launch
# Root actively supervises the original run, at intervals no longer than 60 seconds.
# After original channels, source identities and process custody qualify:
bash /tmp/pix-m7-fex-source-acquisition-continuation03-20261015/commands.sh consume
```

Failure requires normal failed-investigation consumption. Do not rerun a used owner, replay completed sources, widen limits or publish private streams. The frozen runtime control checkout and serialized admission checks are unchanged.

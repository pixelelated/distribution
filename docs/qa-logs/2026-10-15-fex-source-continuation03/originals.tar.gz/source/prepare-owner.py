#!/usr/bin/env python3
"""Prepare fresh sealed owner only. Root separately allocates all collection."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    q=argparse.ArgumentParser(description=__doc__)
    q.add_argument('--owner',type=Path,required=True)
    q.add_argument('--curl-path',type=Path,required=True)
    q.add_argument('--curl-sha256',required=True)
    q.add_argument('--guard-report',type=Path,required=True)
    q.add_argument('--guard-run',type=Path,required=True)
    a=q.parse_args();names=[]
    for line in (P/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);p=P/n
        assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h
        names.append(n)
    assert len(names)<=128 and sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
    B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']();assert Path.cwd()==B['VM_TREE']
    O=a.owner
    assert O.parent==Path('/workspace/tmp') and O.parent.resolve(strict=True)==O.parent and re.fullmatch('pix-m7-fex-source-acquisition-20261015-[0-9]{2}',O.name)
    assert not O.exists() and not O.is_symlink()
    plan=json.loads((P/'collection-plan.json').read_text())
    for name,h in plan['binding_refs'].items():
        p=Path(name);assert p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2 and sha(p)==h
    actual=B['curl_identity'](a.curl_path)
    assert re.fullmatch('[0-9a-f]{64}',a.curl_sha256) and actual['sha256']==a.curl_sha256
    assert a.guard_report.parent==Path('/workspace/tmp') and a.guard_report.resolve(strict=True)==a.guard_report
    assert re.fullmatch(r'pix-m7-fex-source-acquisition-guards-20261015-[0-9]{2}\.json',a.guard_report.name)
    guard=B['load'](a.guard_report)
    assert guard['result']=='PASS_SYNTHETIC_SOURCE_ACQUISITION_GUARDS' and guard['collector_sha256']==sha(P/'templates/collect.py')
    assert guard['guard_controls_sha256']==sha(P/'guard-controls.py')
    assert len(guard['cases'])>=30 and all(r['result'].startswith('PASS') for r in guard['cases'])
    assert a.guard_run.parent==B['VM_TREE']/'.build-runs' and a.guard_run.resolve(strict=True)==a.guard_run
    original=B['load'](a.guard_run/'runner-result.json')
    assert all(type(original[k])is int and original[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert (a.guard_run/'build.rc').read_text().strip()=='0'
    plan['guard_run']=str(a.guard_run)
    for p in [a.guard_report,a.guard_run/'runner-result.json',a.guard_run/'build.rc']:plan['binding_refs'][str(p)]=sha(p)
    os.umask(0o077);O.mkdir(mode=0o700);(O/'stage').mkdir(mode=0o700);(O/'empty-retention-scan').mkdir(mode=0o700)
    written=0;count=0
    def raw(name,payload):
        nonlocal written,count
        assert len(payload)<=4*1024**2 and written+len(payload)<=8*1024**2 and count<64
        assert not (O/name).exists() and not (O/name).is_symlink()
        written+=len(payload);count+=1
        with (O/name).open('xb') as f:f.write(payload)
    def put(name,value):raw(name,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
    for p in sorted((P/'templates').iterdir()):raw(p.name,p.read_bytes())
    for name in ['resources.json','frozen-tools.json']:raw(name,(P/name).read_bytes())
    raw('guard-report.json',a.guard_report.read_bytes());put('collection-plan.json',plan)
    put('host-tools.json',dict(curl=dict(path=str(a.curl_path),identity=actual)))
    put('preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),curl_cli_sha256=a.curl_sha256,guard_report=str(a.guard_report),guard_run=str(a.guard_run),pid_namespace=os.readlink('/proc/self/ns/pid'),user_namespace=os.readlink('/proc/self/ns/user'),collector_executed=False,publication_clearance=False))
    put('retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=['/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources','/workspace/tmp/pix-m7-tailscale-source-acquisition-20261015-01','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-01','/workspace/tmp/pix-m7-fex-source-acquisition-20261015-02'],candidates=[],builds=[dict(name='m7-fex-source-acquisition',terms_bytes={'archive_bodies_private_logs_metadata_and_margin':2147483648},basis='1GiB fresh owner ceiling,249979626B new body cap; prior152673392B Linux and166B redirect remain separately protected and totalphaseA stays384MiB.2GiB reservation covers filesystem overhead. No extraction or cache scan/deletion.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])]))
    put('admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-fex-source-acquisition',profiles=[dict(PROJECT='ROCKNIX',DEVICE='GENERIC_X64',ARCH='x86_64')],outputs=[dict(path=str(O),kind='qa-scratch',issue=528,release_when='Only after original successful/failure consumption and required source custody disposition. Preserve partial and verified sources; raw curl streams stay private. No automatic deletion or publication clearance.')]))
    put('seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()})
    B['verify'](O)
    print(json.dumps(dict(owner=str(O),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),publication_clearance=False)))
if __name__=='__main__':main()

"""Exact prior source/provenance only; no product/cache traversal."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
INTENDED_ORDER=['03-glibc-2.40.tar.xz', '04-gcc-14.3.0.tar.xz', '05-wayland-1.24.0.tar.xz', '06-libX11-1.8.12.tar.xz', '07-xorgproto-2024.1.tar.xz', '08-libXrandr-1.5.4.tar.xz', '02-libdrm-2.4.129.tar.xz']
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    return h.hexdigest()
def load(path):
    p=Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size<20*1024**2,p
    return json.loads(p.read_text())
def host_and_serialization(own_run=None):
    assert (os.getuid(),os.getgid())==(1000,1000)
    assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]'
    assert os.readlink('/proc/self/ns/user')=='user:[4026531837]'
    jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values()
    active=[j for j in jobs if j['state']!='consumed']
    assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
    if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def curl_identity(path):
    p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<16*1024**2 and os.access(p,os.X_OK)
    h=sha(p);after=p.stat();assert all(getattr(after,k)==getattr(s,k) for k in ['st_dev','st_ino','st_size','st_mode','st_uid','st_gid','st_mtime_ns']),'curl identity changed'
    with p.open('rb') as f:header=f.read(64)
    assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==62,'host AMD64 ELF required'
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,sha256=h)
def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<20*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    plan=load(O/'collection-plan.json')
    for name,h in plan['binding_refs'].items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2
        assert sha(p)==h,name
    assert len(plan['selected_archives'])==7 and plan['publication_clearance']is False and plan['source_bundle_complete']is False
    proposal=load('/tmp/pix-m7-fex-dependency-disposition-20261015/acquisition-proposal.json')
    assert {(r.get('provenance_url',r['canonical_url']),r['sha256']) for r in plan['selected_archives']}=={(r['urls'][0],r['hash']) for r in proposal['phase_A']['files'][1:]}
    assert [r['key'] for r in plan['selected_archives']]==plan['intended_order']==INTENDED_ORDER
    assert [r.get('provenance_url',r['canonical_url']) for r in plan['selected_archives']]==[proposal['phase_A']['files'][i]['urls'][0] for i in [2,3,4,5,6,7,1]]
    changed=[r for r in plan['selected_archives'] if 'provenance_url' in r]
    assert len(changed)==1 and changed[0]['filename']=='glibc-2.40.tar.xz'
    assert changed[0]['canonical_url']=='https://ftp.gnu.org/pub/gnu/glibc/glibc-2.40.tar.xz' and changed[0]['allowed_redirect_hosts']==['ftp.gnu.org']
    assert all(r['canonical_url']==r.get('provenance_url',r['canonical_url']) for r in plan['selected_archives'][1:])
    assert plan['reused_historical_archives']==proposal['reused_archive_sources'] and len(plan['reused_historical_archives'])==3
    assert plan['logical_downloads']==7 and len(plan['reused_prior_archives'])==1
    prior=plan['reused_prior_archives'][0];f=proposal['phase_A']['files'][0]
    assert prior['selection']['canonical_url']==f['urls'][0] and prior['archive']['sha256']==prior['selection']['sha256']==f['hash']
    assert prior['archive']['bytes']==152673392 and prior['exact_flat_sha256_verified']is True
    expected_owner=Path('/workspace/tmp/pix-m7-fex-source-acquisition-20261015-01')
    assert prior['archive']['path']==str(expected_owner/'archives/01-linux-6.16.7.tar.xz-0.body')
    assert prior==load(expected_owner/'collection/01-linux-6.16.7.tar.xz.archive.json')
    wait=load(expected_owner/'collection/01-linux-6.16.7.tar.xz-0.curl.wait.json')
    assert type(wait['original_curl_returncode'])is int and wait['original_curl_returncode']==0 and wait['wait_observed']is True
    http=load(expected_owner/'collection/01-linux-6.16.7.tar.xz-0.http.json')
    assert http['http_status']==200 and http['body']==prior['archive'] and not http['redirect_url']
    custody=plan['prior_failure_custody'];accepted=load(custody['acceptance'])
    assert custody['owner']==str(expected_owner) and accepted['run']==custody['run']
    assert accepted['disposition']=='failed-investigated' and accepted['expected_rc']==1
    assert any(e['path']==prior['archive']['path'] and e['sha256']==prior['archive']['sha256'] for e in accepted['evidence'])
    assert load(custody['consume_exit'])['original_exit']==0
    assert plan['phase_A_response_body_accounting']==dict(original_aggregate_cap_bytes=402653184,prior_response_body_bytes=152673558,held_linux_bytes=152673392,prior_redirect_body_bytes=166,continuation_response_body_cap_bytes=249979626)
    assert load(O/'resources.json')['compressed_archive_aggregate_bytes']==249979626
    assert len(plan['additional_prior_failures'])==1
    previous=plan['additional_prior_failures'][0]
    assert previous['owner']=='/workspace/tmp/pix-m7-fex-source-acquisition-20261015-02'
    accepted=load(previous['acceptance']);failure=load(previous['failure_receipt'])
    assert accepted['run']==previous['run'] and accepted['disposition']=='failed-investigated' and accepted['expected_rc']==1
    assert load(previous['consume_exit'])['original_tool_exit']==0
    assert failure['completed_archives']==0 and failure['original_collector_exit']==1
    assert sum(r['actual_bytes'] for r in failure['payload_reservations'])==previous['response_body_bytes']==166
    guard=load(O/'guard-report.json');assert guard['result']=='PASS_SYNTHETIC_SOURCE_ACQUISITION_GUARDS'
    assert guard['collector_sha256']==sha(O/'collect.py') and guard['filesystem_writes_except_requested_receipt']is False and guard['network_used']is False
    assert len(guard['cases'])>=30 and len({r['case'] for r in guard['cases']})==len(guard['cases']) and all(r['result'].startswith('PASS') for r in guard['cases'])
    guard_run=Path(plan['guard_run']);assert guard_run.parent==VM_TREE/'.build-runs'
    original=load(guard_run/'runner-result.json');assert all(type(original[k])is int and original[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert (guard_run/'build.rc').read_text().strip()=='0'
    tools=load(O/'host-tools.json');assert set(tools)=={'curl'}
    assert curl_identity(tools['curl']['path'])==tools['curl']['identity']
    return plan

set -eu
test ! -e /run/pix583-native-inputs
test ! -e /run/pix583-native-packet
cp -a /tmp/pix-input/pix583/inputs /run/pix583-native-inputs
cp -a /tmp/pix-input/pix583/packet /run/pix583-native-packet
mkdir /run/pix583-native-owner
mount -t tmpfs -o size=64M,mode=700,nosuid,nodev tmpfs /run/pix583-native-owner
cd /run/pix583-native-packet
sha256sum -c SHA256SUMS > /tmp/pix-output/packet-check.stdout
python3 -I -S -B /run/pix583-native-packet/fixtures/admit.py --image-sha256 1a23cf5740dbb69cdca76d753a0f6121c35e6e12f27649e792aeebc71e8cc490 --dolphin-sha256 f36a2c5f2f31e961ce605cc1c762f1e839f1880a0b1feeba4e09a1fccaa90d5b --rchash /usr/lib/libraproxy_rchash.so --zstd /usr/lib/libzstd.so.1 --crypto /usr/lib/libcrypto.so.3 > /tmp/pix-output/admit.stdout 2> /tmp/pix-output/admit.stderr
cp /run/pix583-native-inputs/admission.json /tmp/pix-output/admission.json
printf 'PIX583_ADMISSION_BASE64:'
base64 -w 0 /run/pix583-native-inputs/admission.json
printf '\n'

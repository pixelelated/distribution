set -eu
test -n "${PIX583_ADMISSION_SHA:?}"
set +e
timeout --signal=TERM --kill-after=5s 200s python3 -I -S -B /run/pix583-native-packet/fixtures/owner.py --admission /run/pix583-native-inputs/admission.json --admission-sha256 "$PIX583_ADMISSION_SHA" --output /run/pix583-native-owner/run01 > /tmp/pix-output/owner.stdout 2> /tmp/pix-output/owner.stderr
pxrc=$?
printf '%s\n' "$pxrc" > /tmp/pix-output/owner.rc
set -e
cp -a /run/pix583-native-owner/run01 /tmp/pix-output/run01
sync
umount /run/pix583-native-owner
printf 'PIX583_NATIVE_RC:%s\n' "$pxrc"
test "$pxrc" -eq 0

# #602: exact ABL format and retained SM reader continuation — UNRUN

The failure is in the QA reader's architecture rule. The exact SM8550 signed
ABL1.2 release member is ELF32, little-endian, EM_ARM40,258048bytes, mode0644,
SHA `8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c`.
`payload-header-readback.json` records all64 header bytes and the independently
equal unpacked/package/staged copies. The existing root archive readback binds
the same member hash to archive64034fb0 and its companion checksum. No archive
was downloaded, opened or unpacked for this source diagnosis, and no ELF ran.

The old reader applied ELF64/AArch64183 to every selected ELF except usr/bin/steam,
including this bootloader. The minimal change introduces one exact named ABL
branch: required SM8550, full known digest/size, ELF32 little-endian and machine40.
All other selected userland ELFs retain the original ELF64/AArch64 rule. The
five-file source/package/staged and independent SYSTEM/update/raw comparisons,
modes/link chains, kernel, Dolphin, FEX and direct dependency checks remain.
The additional format observation is labelled bootloader data, not native boot
qualification. `verify-additions.py.diff` shows this sole reader-policy change.

The public release workflow at pinned
[0e755e154874f7e874919ab7e080935c1444df68](https://github.com/ROCKNIX/abl/blob/0e755e154874f7e874919ab7e080935c1444df68/.github/workflows/release-abl.yaml)
packages LinuxLoader's signed ELF outputs and companion checksums. The
[v1.2 release](https://github.com/ROCKNIX/abl/releases/tag/v1.2) metadata retained
at07:27 names LinuxLoader e9d37131. The package's manual install copies the
selected ELF unchanged into usr/share/bootloader and adds four support files;
it does not compile or classify it as AArch64 userland. Upstream's existing
[15123b29 checksum correction](https://github.com/ROCKNIX/distribution/commit/15123b29517ad92be1f6cbcc3924a92705887d12)
is already in current source9aa7. This new error is in the private QA reader;
no new upstream product repair or duplicate checksum submission is indicated.
The public metadata does not expose the complete LinuxLoader implementation;
existing #528/#601 source/notice scope is not cleared by an ELF header.

## Original failure and exact retained output custody

Original SM05 source `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea`, run
`20261015T081827Z-07dceee9`, remains command/monitor/runner1/0/1 and launcher1.
It is ordinarily consumed failed-investigated, receipt SHA
`f820b116c70bd2dbbc67b873bb11d881222fb8b1c15af15505aa6a710dc0049b`.
The compiler/image command returned through its check=True call to the failing
post-build reader; that control flow and737/737 log do not manufacture a
separate successful combined producer receipt. The original owner, build seal,
failed receipts and missing output-manifest/build-consumption remain unchanged.
The root investigation retains its initial lowercase Docker-message assertion
failure separately from actual producer results.

The root's watched immutable assembled-output manifest SHA
`b456c92519db11b30b24b5ac14fb2ca9f2fd9e9cd39305223f3dd8429757da41`
names the five retained files, including image a33abff8 and update54947b25,
and says ASSEMBLED_UNACCEPTED_AFTER_FAILED_VERIFIER/qualification=false.
Its own watched run20261015T090643Z-2726aa32 finished0/0/0. This source packet
binds those existing metadata originals; it has not rehashed the large firmware.
The fresh reader will rehash exactly those five outputs before acceptance.

## Fresh reader and independent acceptance, no rebuild

The continuation reuses the qualified H700 reader-only lifecycle at
`/tmp/pix-m7-h700-reader-review-20261015`. The new owner is
`/workspace/tmp/pix-m7-sm8550-reader-20261015-01`; frozen SM05 stays unchanged.
`changes.diff` compares each executable with its exact SM or H700 predecessor.
No compiler, package clean, image regeneration, cache copy, downloader, target
execution or new cleanup framework is present.

Root invokes one explicit step at a time after review:

```bash
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh prepare
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh reader-preflight
# Root inspects the original resource/retention report before admission.
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh reader-admit
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh reader-launch
# Supervise actual completion, then consume only the new reader's original zero.
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh consume-reader
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh acceptance-preflight
# Root again inspects fresh resources/owners/retention before admission.
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh acceptance-admit
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh acceptance-launch
# Supervise actual completion, then consume independent firmware acceptance only.
bash /tmp/pix-m7-sm8550-abl-format-20261015/commands.sh consume-acceptance
```

Preparation verifies old original statuses/seals, exact failed consumption,
manifest, recorded PID absence and container removal. It copies only small
source/proof inputs to the fresh owner. It rebinds the ARM output manifest and
unchanged checker65ab's destination, and records validation_continuation with
original combined producer1. It carries original fex-package.json byte-for-byte;
this is original compiler evidence, not a new compiler success.

The new reader repeats the established source/staged inclusion checks in its
own output directory, applies the named ABL rule and validates the exact five
retained firmware hashes. Its result says READ_VALIDATED_REQUIRES_ARTIFACT_ACCEPTANCE
and carries original producer1 plus the new ARM manifest SHA. Its ordinary
consumer requires fresh original launcher/wrapper/command/monitor/runner0,
recorded owner absence and exact sealed inputs before consumption.

Independent acceptance requires that consumed reader0. It retains all original
raw/update GPT/SYSTEM/KERNEL/ABL equality, installed mappings, ARM handoff,14 FEX
ELF/package hashes, selected-state checker65ab on the bound update TAR,
candidate-store byte/inode custody and scratch removal checks. Its PASS applies
only to this fresh artifact acceptance; producer_combined_run_returncode stays1.
No physical boot, device runtime, Steam VM behavior, common RC or publication
clearance follows. Failed new stages retain their own original statuses.

Each allocation uses SM05's own current ordinary admission/watch tools, fresh
build-preflight/retention report and the existing64GiB scratch/bundle allowance.
No #597 reporting recovery or frozen f863 admission tool is used. Protected
originals/outputs remain held with zero deletion credit. Root supervises at
most60s apart and owns later retention. No preparer, reader, acceptance,
admission or runtime command has executed while preparing this packet.

`format-controls.py` executes only the exact AST format branch with bounded
byte inputs:12 controls pass, including the preserved old refusal, exact named
member acceptance and negative class/endian/machine/hash/size/device/other-path
checks. Synthetic inconsistent digest/header rows isolate the format assertions
and are explicitly not artifact evidence. Original control/syntax exits0 and
stdout/stderr are retained. AST parsing and61 source/metadata reference hashes
also pass; no full reader was imported or executed.

`downstream-bindings.md` lists the precise later Steam/inventory input changes.
Their existing sealed packets are untouched. All new reader/acceptance outcome
hashes remain unavailable until actual execution.

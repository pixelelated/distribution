"""Consume only the new reader/acceptance's original zero; producer failure stays separate."""
from pathlib import Path
import argparse,hashlib,json,subprocess
q=argparse.ArgumentParser();q.add_argument('--stage',choices=['reader','acceptance'],required=True);a=q.parse_args();O=Path(__file__).resolve().parent;B=json.loads((O/'bindings.json').read_text());T=Path(B['tree']);assert Path.cwd()==T
base=O if a.stage=='reader' else O/'acceptance';run=Path((base/'run.path').read_text().strip())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
subprocess.run(['python3','-I',str(O/'verify-prerequisites.py')],check=True)
for n,h in json.loads((base/'seal.json').read_text()).items():assert sha(Path(n))==h,n
if a.stage=='reader':
 proof=O/'artifacts/reader-validation.json';jp=json.loads(proof.read_text());assert jp['result']=='PASS' and jp['original_combined_run_returncode']==1
 files=[proof,O/'artifacts/output-manifest.json',O/'artifacts/installed-inclusion.json',O/'artifacts/affected-products-staged.json',O/'artifacts/arm-output-manifest.json']
 assert sha(O/'artifacts/output-manifest.json')==jp['output_manifest_sha256']
 assert sha(O/'artifacts/installed-inclusion.json')==jp['installed_inclusion_sha256'] and sha(O/'artifacts/affected-products-staged.json')==jp['affected_products_sha256']
else:
 proof=base/'artifacts/acceptance.json';jp=json.loads(proof.read_text());assert jp['result']=='PASS' and jp['scratch_removed'] and jp['source_unchanged'] and jp['producer_combined_run_returncode']==1
 files=[proof,base/'artifacts/affected-products.json',base/'artifacts/selected-state.stdout',base/'artifacts/selected-state.exit',O/'reader-consumption.json']
 assert (base/'artifacts/selected-state.exit').read_text().strip()=='0' and json.loads((base/'artifacts/selected-state.stdout').read_text())['status']=='pass'
launch=json.loads((base/'launcher-result.json').read_text());runner=json.loads((run/'runner-result.json').read_text())
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
assert all(type(runner[n]) is int and runner[n]==0 for n in ['command_rc','monitor_rc','runner_rc'])
for p in [base/'inner.rc',base/'outer.rc',base/'tool-wrapper.rc',run/'build.rc']:assert p.read_text().strip()=='0';files.append(p)
pids={launch['pid']}
for p in [run/n for n in ['build.pid','command.pid','watcher.pid','build.status.pid']]:
 if p.exists():pids.add(int(p.read_text().strip()))
assert all(not Path('/proc',str(pid)).exists() for pid in pids)
files += [base/'launcher-result.json',run/'runner-result.json',O/'bindings.json',Path(B['failure_evidence']),Path(B['failed_run'])/'admission-consumed.json']
admission=json.loads((run/'admission.json').read_text());assert admission['source']['head']==B['source_commit'] and admission['submission_owner']==str(base)
evidence={'run':str(run),'disposition':'qualified','expected_rc':0,'evidence':[{'path':str(p),'sha256':sha(p)} for p in files],'outputs':admission['outputs'],'original_combined_producer_returncode':1,'scope':'New '+a.stage+' original zero only. Failed producer1 remains failed-investigated; no physical boot, target runtime, RC or publication claim.'}
out=base/'admission-completion-evidence.json'
with out.open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
subprocess.run(['python3','-I',str(T/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
receipt=run/'admission-consumed.json';c=json.loads(receipt.read_text());assert c['state']=='consumed' and c['original_result']==runner
record={'result':'PASS','stage':a.stage,'run':str(run),'original_result':runner,'consumed_receipt_sha256':sha(receipt),'completion_evidence_sha256':sha(out),'original_combined_producer_returncode':1,'output_manifest_sha256':sha(O/'artifacts/output-manifest.json'),'scope':evidence['scope']}
with (O/(a.stage+'-consumption.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('PASS consumed fresh '+a.stage+' zero; original combined producer1 unchanged')

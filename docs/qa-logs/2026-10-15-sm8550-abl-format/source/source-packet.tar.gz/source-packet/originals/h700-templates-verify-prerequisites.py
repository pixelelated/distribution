"""Read-only binding of one consumed failed producer; never relabel it successful."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess
q=argparse.ArgumentParser();q.add_argument('--bindings',type=Path);a=q.parse_args()
O=Path(__file__).resolve().parent;B=json.loads((a.bindings or O/'bindings.json').read_text());old=Path(B['old_owner']);run=Path(B['failed_run']);T=Path(B['tree'])
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
for row in B['files']:assert sha(row['path'])==row['sha256'],row['path']
rc=load(run/'runner-result.json');expected={'command_rc':1,'monitor_rc':0,'runner_rc':1}
assert all(type(rc[n]) is int and rc[n]==v for n,v in expected.items())
c=load(run/'admission-consumed.json');assert c['state']=='consumed' and c['id']==B['failed_admission'] and c['original_result']==rc
assert c['run']==str(run) and c['submission_owner']==str(old) and c['source']['head']==B['source_commit'] and c['pid_namespace']==4026531836
assert c['outputs_held'] is True and c['deleted_bytes']==0
proof=load(B['failure_evidence']);assert sha(B['failure_evidence'])==c['evidence_sha256']
assert proof['run']==str(run) and proof['disposition']=='failed-investigated' and type(proof['expected_rc']) is int and proof['expected_rc']==1
for row in proof['evidence']:assert sha(row['path'])==row['sha256'],row['path']
launch=load(old/'launcher-result.json');assert type(launch['runner_returncode']) is int and launch['runner_returncode']==1
for f in [old/'tool-wrapper.rc',old/'inner.rc',old/'outer.rc',run/'build.rc']:assert f.read_text().strip()=='1',f
assert not (old/'build-consumption.json').exists() and not (old/'artifacts/output-manifest.json').exists()
for n,h in load(old/'build-seal.json').items():assert sha(n)==h,n
manifest=load(B['output_manifest']);assert sha(B['output_manifest'])==B['output_manifest_sha256']
assert manifest['result']=='ASSEMBLED_OUTPUTS_HELD_AFTER_FAILED_POSTBUILD_READER' and manifest['original_combined_run_returncode']==1 and manifest['distribution_commit']==B['source_commit']
assert len(manifest['files'])==7
for name,row in manifest['files'].items():assert Path(row['path']).parent==T/'target' and Path(row['path']).name==name
assert len([n for n in manifest['files'] if n.endswith('.img.gz')])==2 and len([n for n in manifest['files'] if n.endswith('.tar')])==1
# PID/container visibility is required at actual allocation, never inferred from source readback.
assert os.getuid()==1000 and os.getgid()==1000 and os.stat('/proc/self/ns/pid').st_ino==4026531836
inv=load(Path(B['failure_evidence']).parent/'investigation.json')
assert all(not Path('/proc',str(pid)).exists() for pid in inv['actual_recorded_pids_exited'])
cid=(old/'build.cid').read_text().strip();assert cid==inv['actual_container_removed']
r=subprocess.run(['docker','inspect',cid],capture_output=True,text=True,timeout=30)
assert r.returncode==1 and ('no such object' in r.stderr.lower() or 'no such container' in r.stderr.lower()),r.stderr
print('PASS exact failed producer1 remains consumed and held; independent reader may proceed')

#!/usr/bin/env python3
"""Close one successful device stage using original channels and the frozen admission tool."""
from pathlib import Path
import argparse,hashlib,json,subprocess
q=argparse.ArgumentParser();q.add_argument('--owner',type=Path,required=True);q.add_argument('--stage',choices=['cache','build','acceptance'],required=True);a=q.parse_args();O=a.owner.resolve(strict=True);j=json.loads((O/'inputs.json').read_text());T=Path(j['host_worktree']);assert Path.cwd()==T
if a.stage=='cache':
 subprocess.run(['python3','-I',str(O/'consume-cache.py')],check=True);base=O/'cache-launch';run=Path((O/'copy.run').read_text().strip());proof=O/'cache-consumption.json';files=[proof,O/'cache-ready.json',O/'copy.rc',O/'copy.outer.rc']
elif a.stage=='build':
 subprocess.run(['python3','-I',str(O/'consume-build.py')],check=True);base=O;run=Path((O/'run.path').read_text().strip());proof=O/'build-consumption.json';files=[proof,O/'artifacts/output-manifest.json',O/'artifacts/installed-inclusion.json',O/'artifacts/affected-products-staged.json']
else:
 base=O/'acceptance';run=Path((base/'run.path').read_text().strip());proof=base/'artifacts/acceptance.json';jproof=json.loads(proof.read_text());assert jproof['result']=='PASS' and jproof['scratch_removed'] and jproof['source_unchanged']
 files=[proof,base/'artifacts/affected-products.json',base/'artifacts/selected-state.stdout',base/'artifacts/selected-state.exit']
 assert int((base/'artifacts/selected-state.exit').read_text())==0 and json.loads((base/'artifacts/selected-state.stdout').read_text())['status']=='pass'
 for n in ['inner.rc','outer.rc']:assert int((base/n).read_text())==0;files.append(base/n)
launch=json.loads((base/'launcher-result.json').read_text());runner=json.loads((run/'runner-result.json').read_text());assert launch['runner_returncode']==0 and all(runner[n]==0 for n in ['command_rc','monitor_rc','runner_rc'])
assert int((base/'tool-wrapper.rc').read_text())==0 and int((run/'build.rc').read_text())==0
files += [base/'launcher-result.json',base/'tool-wrapper.rc',run/'runner-result.json',run/'build.rc']
admission=json.loads((run/'admission.json').read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
evidence={'run':str(run),'disposition':'qualified','expected_rc':0,'evidence':[{'path':str(p),'sha256':sha(p)} for p in files],'outputs':admission['outputs'],'scope':'Successful '+a.stage+' original channels only; '+('independent firmware artifact acceptance remains required' if a.stage!='acceptance' else 'no physical boot, runtime-on-device, RC or publication claim')}
out=base/'admission-completion-evidence.json'
with out.open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
subprocess.run(['python3','-I',str(T/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed original '+a.stage+' result; outputs remain held')

from pathlib import Path
import hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent;B=O.parent
(O/'run.path').write_text(str(Path.cwd()/os.environ['RASTERATOPS_BUILD_RUN'])+'\n');rc=1
try:
 for n,h in json.loads((O/'seal.json').read_text()).items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
 prior=json.loads((B/'reader-consumption.json').read_text());assert prior['result']=='PASS' and prior['stage']=='reader' and prior['original_combined_producer_returncode']==1
 receipt=Path(prior['run'])/'admission-consumed.json';assert hashlib.sha256(receipt.read_bytes()).hexdigest()==prior['consumed_receipt_sha256']
 consumed=json.loads(receipt.read_text());assert consumed['state']=='consumed' and all(type(consumed['original_result'][n]) is int and consumed['original_result'][n]==0 for n in ['command_rc','monitor_rc','runner_rc'])
 assert hashlib.sha256((B/'artifacts/output-manifest.json').read_bytes()).hexdigest()==prior['output_manifest_sha256']
 subprocess.run(['python3','-I',str(B/'verify-prerequisites.py')],check=True)
 subprocess.run(['python3','-I',str(O/'verify-firmware.py')],check=True);rc=0
except subprocess.CalledProcessError as e:
 rc=e.returncode if e.returncode>0 else 128-e.returncode
finally:
 (O/'inner.rc').write_text(str(rc)+'\n');(O/'outer.rc').write_text(str(rc)+'\n')
sys.exit(rc)

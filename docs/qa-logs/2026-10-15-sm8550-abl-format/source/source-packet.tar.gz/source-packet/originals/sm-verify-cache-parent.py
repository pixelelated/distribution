"""Read only: exact consumed copy0 -> partial build2 parent, never accepted firmware."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess
q=argparse.ArgumentParser();q.add_argument('--baseline',type=Path,required=True);a=q.parse_args()
b=json.loads(a.baseline.read_text());T=Path(b['parent']);O=Path(b['old_owner'])
assert T==Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-04') and T.resolve(strict=True)==T
assert O==Path('/workspace/tmp/pix-m7-sm8550-refresh-20261015-01')
assert os.getuid()==1000 and os.getgid()==1000 and os.readlink('/proc/self/ns/pid')=='pid:[4026531836]'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(T),*args])
def load(p):return json.loads(Path(p).read_text())
assert git('rev-parse','HEAD').decode().strip()==b['head']=='f8636de1d105275dbf9420bbabbbc26f79abb10f'
assert git('branch','--show-current').decode().strip()=='build/'+T.name
assert git('status','--porcelain=v1','-z').hex()==b['status_hex']==''
refs=b['originals']
for name,row in refs.items():
 p=Path(row['path']);assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],name
def record(name):return load(refs[name]['path'])
for prefix,expected,disposition in [('cache',0,'qualified'),('failed',2,'failed-investigated')]:
 run=Path(b['cache_run'] if prefix=='cache' else b['old_run'])
 consumed=record(prefix+'_consumed');runner=record(prefix+'_runner');completion=record(prefix+'_completion');launch=record(prefix+'_launcher')
 assert consumed['state']=='consumed' and consumed['source']['head']==b['head'] and consumed['run']==str(run)
 assert consumed['original_result']==runner and consumed['evidence_sha256']==refs[prefix+'_completion']['sha256']
 assert [runner[k] for k in ['command_rc','monitor_rc','runner_rc']]==[expected,0,expected]
 assert type(launch['runner_returncode']) is int and launch['runner_returncode']==expected
 assert completion['run']==str(run) and completion['disposition']==disposition and completion['expected_rc']==expected
 for row in completion['evidence']:assert sha(row['path'])==row['sha256'],row['path']
 pids={launch['pid']}
 for n in ['build.pid','command.pid','watcher.pid','build.status.pid']:
  p=run/n
  if p.exists():pids.add(int(p.read_text().strip()))
 assert all(not Path('/proc',str(pid)).exists() for pid in pids),pids
assert record('failed_consumed')['id']=='d8ae8d1653ab46b48d296f20f1cb17d4'
assert record('cache_consumption')['result']=='PASS' and record('cache_ready')['result']=='PASS'
assert record('cache_consumption')['cache_ready']==record('cache_ready')
assert len(record('cache_ready')['roots'])==3 and all(r['checksum_equal'] for r in record('cache_ready')['roots'])
investigation=record('failed_investigation');cid=investigation['actual_container_removed']
assert cid==record('failed_container')['id']
active=subprocess.check_output(['docker','ps','-a','--no-trunc','--format','{{.ID}}'],text=True,timeout=15).splitlines()
assert cid not in active,'recorded failed container still exists'
assert record('abl_result')['result']=='PASS' and record('abl_result')['companion_checksum_matches'] is True
assert record('abl_result')['archive_sha256']=='64034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7'
assert record('abl_result')['SM8550_sha256']=='8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c'
assert all(record('abl_runner')[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert Path(refs['abl_build_rc']['path']).read_text().strip()=='0'
print('PASS stopped clean f863 parent: consumed independent copy0 then consumed partial build2; no accepted SM image inherited')

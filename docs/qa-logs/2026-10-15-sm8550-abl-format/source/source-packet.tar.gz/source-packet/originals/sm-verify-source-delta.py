"""Exact #600 product delta and new checkout tool identities; no inherited new image PASS."""
from pathlib import Path
import argparse,hashlib,json,subprocess
q=argparse.ArgumentParser();q.add_argument('--tree',type=Path,required=True);a=q.parse_args();T=a.tree
P=Path(__file__).resolve().parent
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(T),*args])
def load(p):return json.loads(Path(p).read_text())
d=load(P/'source-delta.json');old=d['accepted_source'];new=d['new_source'];path=d['changed_paths'][0]
assert old=='f8636de1d105275dbf9420bbabbbc26f79abb10f' and new=='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea'
assert T==Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05') and T.resolve(strict=True)==T
assert git('rev-parse','HEAD').decode().strip()==new and git('branch','--show-current').decode().strip()=='build/'+T.name
assert git('diff','--name-only',old,new,'--',*d['product_scope']).decode().splitlines()==d['changed_paths']==['projects/ROCKNIX/packages/tools/rocknix-abl/package.mk']
assert hashlib.sha256(git('diff','--binary',old,new,'--',*d['product_scope'])).hexdigest()==d['diff_sha256']
before=git('show',old+':'+path);after=git('show',new+':'+path)
assert before.replace(b'4fcf983aff6af152fb5d7d0ef1a31727d64ecb93b2d75e202efeea5c5d4b565d',b'64034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7')==after
assert hashlib.sha256(before).hexdigest()==d['old_recipe_sha256'] and hashlib.sha256(after).hexdigest()==d['new_recipe_sha256']==sha(T/path)
assert git('diff','--name-only',new,'--',*d['product_scope'],'tools')==b''
for name,h in load(P/'frozen-tools.json').items():assert sha(T/name)==h,name
refs=load(P/'accepted-vm-binding.json')
for name,row in refs.items():assert sha(row['path'])==row['sha256'],name
result=load(refs['vm_result']['path']);inputs=load(refs['vm_artifact_inputs']['path']);consumed=load(refs['vm_consumed']['path']);completion=load(refs['vm_completion']['path'])
assert result['status']=='PASS' and result['source']==inputs['source']==old
assert result['build_closeout']==inputs['build_closeout'] and result['build_closeout']['qualification'] is False and result['build_closeout']['original_launcher_returncode'] is None
assert consumed['state']=='consumed' and consumed['source']['head']==old and consumed['evidence_sha256']==refs['vm_completion']['sha256']
assert completion['disposition']=='qualified' and completion['expected_rc']==0 and completion['run']==consumed['run']
assert all(consumed['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
for row in completion['evidence']:assert sha(row['path'])==row['sha256']
print('PASS exact one-path #600 product delta; VM/H700 source stays f863; new SM tools/source bound independently')

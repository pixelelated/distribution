#!/bin/bash
# Root invokes one explicit serialized step; no compiler stage exists here.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-h700-reader-review-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04
TASK_OWNER=/workspace/tmp/pix-m7-h700-reader-20261015-01
TASK_STEP=${1:?prepare, reader, consume-reader, acceptance, or consume-acceptance}
cd "$TASK_TREE"
case "$TASK_STEP" in
 prepare)
  test ! -e "$TASK_OWNER"
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-reader.py"
  ;;
 reader|acceptance)
  if test "$TASK_STEP" = reader; then
   TASK_STAGE_OWNER="$TASK_OWNER"; TASK_CMD=(python3 -I "$TASK_OWNER/reader.py")
  else
   TASK_STAGE_OWNER="$TASK_OWNER/acceptance"; TASK_CMD=(python3 -I "$TASK_STAGE_OWNER/run.py")
  fi
  tools/build-preflight
  tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_STAGE_OWNER/retention-plan.json" --output "$TASK_STAGE_OWNER/retention-report.json"
  python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_STAGE_OWNER/admission-plan.json" --output "$TASK_STAGE_OWNER/admission.json"
  tools/watch-build-submit --owner "$TASK_STAGE_OWNER" -- --admission "$TASK_STAGE_OWNER/admission.json" -- "${TASK_CMD[@]}"
  # Root supervises original completion at <=60s cadence. Submission is not completion.
  ;;
 consume-reader|consume-acceptance)
  python3 -I "$TASK_OWNER/consume-reader-stage.py" --stage "${TASK_STEP#consume-}"
  ;;
 *) exit 2;;
esac

"""Validate retained staged outputs only; never compile, assemble, or alter the failed owner."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent;B=json.loads((O/'bindings.json').read_text());T=Path(B['tree']);assert Path.cwd()==T
(O/'run.path').write_text(str(T/os.environ['RASTERATOPS_BUILD_RUN'])+'\n');rc=1
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
try:
 for n,h in json.loads((O/'seal.json').read_text()).items():assert sha(Path(n))==h,n
 assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
 subprocess.run(['python3','-I',str(O/'verify-prerequisites.py')],check=True)
 subprocess.run(['python3','-I',str(O/'verify-source.py')],check=True)
 subprocess.run(['python3','-I',str(O/'verify-installed.py')],check=True)
 prior=json.loads(Path(B['output_manifest']).read_text());outputs={}
 actual={p.name for p in (T/'target').iterdir() if p.is_file() and p.name.startswith('pixelelated-H700.aarch64-')}
 assert actual==set(prior['files'])
 for name,row in prior['files'].items():
  p=Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],name;outputs[name]=row
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'READ_VALIDATED_REQUIRES_ARTIFACT_ACCEPTANCE','distribution_commit':B['source_commit'],'files':outputs,'original_combined_run_returncode':1,'failed_producer_run':B['failed_run'],'original_output_manifest_sha256':B['output_manifest_sha256'],'scope':'Fresh source/staged mapping and retained-output validation; no build rerun or relabelling'}
 (O/'artifacts/output-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
 (O/'artifacts/reader-validation.json').write_text(json.dumps({'result':'PASS','source':B['source_commit'],'original_combined_run_returncode':1,'failed_producer_run':B['failed_run'],'output_manifest_sha256':sha(O/'artifacts/output-manifest.json'),'installed_inclusion_sha256':sha(O/'artifacts/installed-inclusion.json'),'affected_products_sha256':sha(O/'artifacts/affected-products-staged.json'),'scope':'Source/staged inclusion and seven retained output hashes; independent firmware acceptance remains required'},indent=2)+'\n')
 print('PASS fresh H700 reader; original combined producer1 unchanged; independent artifact acceptance follows',flush=True);rc=0
except subprocess.CalledProcessError as e:
 rc=e.returncode if e.returncode>0 else 128-e.returncode
finally:
 (O/'inner.rc').write_text(str(rc)+'\n');(O/'outer.rc').write_text(str(rc)+'\n')
sys.exit(rc)

# Explicit later consumer binding changes — source only

Do not run the existing sealed Steam bridge or final inventory preparer with
guessed successful owner02 acceptance. Their named original packets remain
immutable. After the fresh reader and independent acceptance complete and are
ordinarily consumed, root can review narrow additive binding revisions.

The new accepted owner will be
`/workspace/tmp/pix-m7-sm8550-reader-20261015-01`, source9aa7 and original producer
owner02/source9aa7 unchanged. Its `inputs.json` is the exact original input object
with only the ARM manifest path, checker destination and explicit
validation_continuation record changed. The candidate bundle's full inputs
will match this object. There is no new product commit or firmware timestamp.

For Steam, change the owner locator and require the new acceptance's
producer_combined_run_returncode=1, exact failed producer/run/consumption,
reader-consumption.json and its actual ordinary consumed0, then actual fresh
acceptance consumed0. Preserve module SHA/size/mode/link-chain/source mapping,
source9aa7, final GENERIC f863 image/readback and all fixture/helper hashes.
The acceptance completion's explicit evidence set is the prior ten original
acceptance channels plus four continuity members:

- new-owner/reader-consumption.json;
- new-owner/bindings.json;
- `/tmp/pix-m7-sm8550-verifier-failure-20261015/completion-evidence.json`;
- original failed SM run/admission-consumed.json.

The new artifact acceptance retains all existing row fields and adds explicit
producer failure provenance. `affected-products.json` adds the ABL format fact
under special; the Steam module row is unchanged. A source-only binding update
must never replace failed producer1 with a successful build-consumption claim.

For final inventory, fill the seven final SM references from this actual fresh
reader/acceptance: inputs, acceptance, completion, actual consumed acceptance,
output manifest, ARM manifest and candidate bundle manifest. Bind original
compiler FEX proof through the copied exact fex-package.json and the independent
fex-installed.json equality; preserve their producer scope. The fresh output
manifest carries its exact ARM manifest hash and explicit original failure.
Keep VM/H700f863 versus SM9aa7's existing one-path ABL checksum delta and source/
notice holds. These are required actual path/hash/schema changes, not permission
to hardcode future outputs or treat inventory as already complete.

"""Prepare a fresh retained-artifact reader owner; no compiler/image/cache operation."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
P=Path(__file__).resolve().parent;B=json.loads((P/'bindings.json').read_text());old=Path(B['old_owner']);N=Path(B['new_owner']);T=Path(B['tree'])
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
assert Path.cwd()==T and N==Path('/workspace/tmp/pix-m7-sm8550-reader-20261015-01') and not N.exists()
assert os.getuid()==1000 and os.getgid()==1000 and os.stat('/proc/self/ns/pid').st_ino==4026531836
for line in (P/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(P/n)==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==B['source_commit']
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='build/m7-pixelelated-sm8550-05'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
subprocess.run(['python3','-I','-S','-B',str(P/'templates/verify-prerequisites.py'),'--bindings',str(P/'bindings.json')],check=True)
N.mkdir(mode=0o700);(N/'artifacts').mkdir();(N/'acceptance').mkdir();(N/'acceptance/artifacts').mkdir();(N/'prior-originals').mkdir()
for src in (P/'templates').rglob('*'):
 if src.is_file():
  dst=N/src.relative_to(P/'templates');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
shutil.copy2(P/'bindings.json',N/'bindings.json')
for row in B['files']:
 dst=N/'prior-originals'/Path(row['copy']).name;shutil.copy2(P/row['copy'],dst);assert sha(dst)==row['sha256']
j=json.loads((old/'inputs.json').read_text());j['arm_manifest']=str(N/'artifacts/arm-output-manifest.json');j['host_state_checker']['path']=str(N/'acceptance/pixelelated-state-check')
j['validation_continuation']={'failed_owner':str(old),'failed_run':B['failed_run'],'failed_admission':B['failed_admission'],'original_combined_run_returncode':1,'original_output_manifest_sha256':B['output_manifest_sha256'],'source_packet_sha256':sha(P/'SHA256SUMS'),'bindings_sha256':sha(P/'bindings.json'),'compiler_or_image_rerun':False,'scope':'Fresh source/staged reader and independent firmware acceptance of already assembled retained outputs.'}
put(N/'inputs.json',j)
shutil.copy2(old/'artifacts/fex-package.json',N/'artifacts/fex-package.json')
assert sha(N/'artifacts/fex-package.json')==sha(old/'artifacts/fex-package.json')
for stage,base in [('reader',N),('acceptance',N/'acceptance')]:
 scan=base/'empty-retention-scan';scan.mkdir()
 retention=json.loads((old/'acceptance/retention-plan.json').read_text());admission=json.loads((old/'acceptance/admission-plan.json').read_text())
 retention['scan_roots']=[str(scan)];retention['builds'][0]['name']='m7-sm8550-'+stage+'-after-reader-failure'
 retention['protected'] += [str(old),str(Path(B['failure_evidence']).parent),str(N/'bindings.json')]
 retention['builds'][0]['evidence'] += [{'path':str(N/'bindings.json'),'sha256':sha(N/'bindings.json')}]
 retention['builds'][0]['basis']+=' Reader-only continuation after consumed combined producer1. Already assembled firmware held; no compiler/cache copy/clean/image regeneration or deletion credit.'
 admission['retention_plan']=str(base/'retention-plan.json');admission['retention_report']=str(base/'retention-report.json');admission['stage']=retention['builds'][0]['name']
 for row in admission['outputs']:
  if row['path']==str(old):row['path']=str(N)
 if stage=='reader':admission['outputs']=[r for r in admission['outputs'] if r['path']!='/workspace/artifacts/pixelelated-candidates']
 assert admission['profiles']==[{'PROJECT':'ROCKNIX','DEVICE':'SM8550','ARCH':'arm'},{'PROJECT':'ROCKNIX','DEVICE':'SM8550','ARCH':'aarch64'}]
 assert retention['builds'][0]['terms_bytes']=={'independent_firmware_bundle_and_scratch':64*1024**3}
 put(base/'retention-plan.json',retention);put(base/'admission-plan.json',admission)
files=[f for f in N.iterdir() if f.is_file() and f.suffix in ['.py','.sh','.json'] and f.name!='seal.json']
put(N/'seal.json',{str(f):sha(f) for f in files})
files=[N/'acceptance/run.py',N/'acceptance/verify-firmware.py',N/'inputs.json',N/'bindings.json',N/'verify-additions.py',N/'verify-prerequisites.py',N/'verify-source.py',N/'consume-reader-stage.py',N/'acceptance/pixelelated-state-check',N/'artifacts/fex-package.json']
put(N/'acceptance/seal.json',{str(f):sha(f) for f in files})
put(N/'preparation.json',{'status':'PREPARED_UNRUN','source':B['source_commit'],'owner':str(N),'failed_producer_run':B['failed_run'],'original_combined_run_returncode':1,'source_packet_sha256':sha(P/'SHA256SUMS'),'compiler_or_image_rerun':False,'reader_executed':False,'admission_prepared':False})
print(json.dumps({'status':'PREPARED_UNRUN','owner':str(N),'source':B['source_commit'],'original_combined_run_returncode':1}))

#!/usr/bin/env python3
"""Pure byte/AST controls of the exact format branch; no reader or target execution."""
from pathlib import Path
import ast
import hashlib
import json

P = Path(__file__).resolve().parent
observed = json.loads((P / 'payload-header-readback.json').read_text())['rows'][0]
data = Path(observed['path']).read_bytes()
expected = '8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c'
assert len(data) == 258048 and hashlib.sha256(data).hexdigest() == observed['sha256'] == expected


def branch(path, selected):
    tree = ast.parse(path.read_text())
    matches = [n for n in ast.walk(tree) if isinstance(n, ast.If) and selected in ast.unparse(n.test)]
    assert len(matches) == 1
    node = matches[0]
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.With)) for n in ast.walk(node))
    return compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), str(path), 'exec')


old = branch(P / 'originals/sm-verify-additions.py', "n != 'usr/bin/steam'")
new = branch(P / 'templates/verify-additions.py', "n == 'usr/share/bootloader/rocknix_abl/abl_signed-SM8550.elf'")
named = 'usr/share/bootloader/rocknix_abl/abl_signed-SM8550.elf'
results = []


def check(label, code, raw, wanted, path=named, digest=expected, device='SM8550'):
    env = {'data': raw, 'n': path, 'row': {'sha256': digest}, 'j': {'device': device}, 'special': {}}
    try:
        exec(code, env)
        result = 'ACCEPT'
    except AssertionError:
        result = 'REJECT'
    assert result == wanted, label
    results.append({'case': label, 'observed': result, 'expected': wanted})


check('original branch rejects exact archive-bound ELF32 member', old, data, 'REJECT')
check('named branch accepts exact archive-bound member', new, data, 'ACCEPT')
check('named path rejects wrong full member digest', new, data, 'REJECT', digest='0' * 64)
check('named path rejects truncated member', new, data[:-1], 'REJECT')
check('named path rejects other device', new, data, 'REJECT', device='H700')
# Hold the already validated digest field fixed to isolate each header assertion.
# These synthetic inconsistent rows are controls only, never artifact receipts.
check('named header rejects ELF64', new, data[:4] + b'\x02' + data[5:], 'REJECT')
check('named header rejects big endian', new, data[:5] + b'\x02' + data[6:], 'REJECT')
check('named header rejects non-ELF', new, b'BAD!' + data[4:], 'REJECT')
check('named header rejects AArch64 machine', new, data[:18] + b'\xb7\x00' + data[20:], 'REJECT')
check('other bootloader path has no ELF32 exemption', new, data, 'REJECT', path='usr/share/bootloader/other.elf')
elf64 = bytearray(64); elf64[:6] = b'\x7fELF\x02\x01'; elf64[18:20] = b'\xb7\x00'
check('unchanged userland accepts ELF64 AArch64', new, bytes(elf64), 'ACCEPT', path='usr/bin/example')
check('unchanged userland rejects ELF32 ARM', new, data, 'REJECT', path='usr/bin/example')
with (P / 'format-controls-result.json').open('x') as f:
    json.dump({'status': 'PASS', 'scope': 'Exact AST branch, pure bytes; no project helper/reader/target invoked',
               'real_member': observed, 'synthetic_header_rows_are_not_artifacts': True, 'controls': results}, f, indent=2)
    f.write('\n')
print('PASS 12 pure format controls; original refusal preserved, no reader or target executed')

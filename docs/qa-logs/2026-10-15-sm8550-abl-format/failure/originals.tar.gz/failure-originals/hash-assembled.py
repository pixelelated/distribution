from pathlib import Path
import hashlib,json,datetime
T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05')
O=Path('/workspace/tmp/pix-m7-sm8550-refresh-20261015-02')
j=json.loads((O/'inputs.json').read_text()); rows={}
for p in sorted((T/'target').iterdir()):
 if p.is_file() and p.name.startswith('pixelelated-SM8550.aarch64-'):
  with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
  rows[p.name]={'path':str(p),'bytes':p.stat().st_size,'sha256':h}
assert len([n for n in rows if n.endswith('.img.gz')])==1 and len([n for n in rows if n.endswith('.tar')])==1
p=Path('/tmp/pix-m7-sm8550-verifier-failure-20261015/assembled-output-manifest.json')
with p.open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'ASSEMBLED_UNACCEPTED_AFTER_FAILED_VERIFIER','distribution_commit':j['distribution_commit'],'files':rows,'arm_manifest_sha256':hashlib.sha256((O/'artifacts/arm-output-manifest.json').read_bytes()).hexdigest(),'original_failed_run':str(T/'.build-runs/20261015T081827Z-07dceee9'),'qualification':False},f,indent=2);f.write('\n')
print('PASS immutable bytes inventoried; still UNACCEPTED',len(rows),hashlib.sha256(p.read_bytes()).hexdigest())

Parent #555 / #600, M7.P5. Found during the authorized continuation: “Please keep working.”

The canonical SM8550 build at source 9aa7affee9d4 completed 737/737 packages and image creation. Its post-build verifier then rejected `usr/share/bootloader/rocknix_abl/abl_signed-SM8550.elf` because a generic userland check requires every non-Steam ELF to be ELF64/AArch64. The exact upstream signed ABL is ELF32/little-endian/EM_ARM: 258,048 bytes, SHA256 8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c. Unpacked, package and staged bytes match the already retained archive member. This is a qualification-tool defect; it does not establish a broken firmware image.

Run 20261015T081827Z-07dceee9 finished 09:00:07 UTC with original command/monitor/runner 1/0/1 and launcher/inner/outer/wrapper 1. Actual launcher, runner, watcher and observer exited; the exact container is absent. Ordinary failed-investigated consumption retains the outputs. No original result or sealed owner will be edited. Compilation and cache copying need not be replayed for a reader-only correction.

Can this be done on the VM? Yes: this is a nonexecuting host artifact-reader defect, directly testable from synthetic ELF headers and exact built payloads. Native host verification and independent raw/update/SYSTEM readback are the correct environment; no device, account, cloud, native bootloader execution or physical exception is needed. Header characterization and checksums do not prove physical boot.

Scope/depth: bounded Local Issue review of the reader correction and fresh continuation. Keep the exact known ABL identity and all five-file/source/package/SYSTEM/raw equality checks; other executable payloads retain their existing architecture guard. Preserve failed originals and do not forge a successful combined producer receipt. The completed product audit remains unchanged.

Acceptance criteria:

- [x] Retain the original failed channels and ordinary consumption, actual owner/container exit evidence, and exact upstream-member/package/staged header/hash/size/mode characterization.
- [ ] Prepare a minimal named-ABL validation branch with fail-closed positive/negative header, digest and unexpected-path controls; preserve the generic userland architecture check and all existing equality checks.
- [ ] Review and run a fresh read-only installed/source reader against the already assembled SM05 artifacts with fresh resources and ordinary admission; retain the failed original producer and actual new result channels separately.
- [ ] Complete independent raw/update/GPT/five-ABL/FEX/selected-state acceptance and consume its actual original-zero result. Record exact firmware/source hashes and update #555/#600/#599/M7 before the single Steam VM bridge and #528 inventory.
- [ ] Retain the finite review, evidence and work/friction records. No recompilation, physical operation, new RC or publication clearance is inferred.

Upstream: the signed format is in the exact official ROCKNIX ABL 1.2 asset. This generic assertion is our qualification wrapper, so no upstream product patch is indicated by this finding. #601 remains the separate future OpenABL/source-intake task.

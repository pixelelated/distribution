#!/usr/bin/env python3
"""Read-only AST/metadata source checks; never import or run packet helpers."""
from pathlib import Path
import ast,hashlib,json,subprocess
P=Path(__file__).resolve().parent
checks=[]
def same_functions(a,b,names=None):
    aa={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(a).body if isinstance(n,ast.FunctionDef)}
    bb={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(b).body if isinstance(n,ast.FunctionDef)}
    for name in names or aa:
        assert aa[name]==bb[name],name;checks.append('AST-identical '+name)
for p in sorted(P.rglob('*.py')):ast.parse(p.read_bytes(),filename=str(p));checks.append('AST '+str(p.relative_to(P)))
for p in [P/'commands.sh',P/'templates/run.sh']:
    r=subprocess.run(['/bin/bash','-n',str(p)],capture_output=True);assert r.returncode==0 and not r.stdout and not r.stderr;checks.append('bash-n '+str(p.relative_to(P)))
same_functions((P/'originals/source02-run.py').read_text(),(P/'templates/run.py').read_text())
same_functions((P/'originals/source02-collect.py').read_text(),(P/'templates/collect.py').read_text(),['account_output','write','release_log_reservation','identity'])
assert (P/'templates/process-identity.py').read_bytes()==(P/'originals/source02-process-identity.py').read_bytes();checks.append('process-identity exact bytes')
plan=json.loads((P/'collection-plan.json').read_text());r=json.loads((P/'resources.json').read_text())
assert len(plan['selected_modules'])==89 and len({x['key'] for x in plan['selected_modules']})==89
assert sum(bool(x['reuse_notice_refs']) for x in plan['selected_modules'])==22
assert sum(any('durable_archive' in y for y in x['reuse_notice_refs']) for x in plan['selected_modules'])==6
assert r['owner_output_ceiling_bytes']==1024**3 and r['max_http_requests_including_redirects']==178 and r['retries']==0
assert r['max_decoded_module_bytes']==500*1024**2
assert r['compressed_archive_aggregate_bytes']+r['notice_text_aggregate_bytes']+r['max_retained_metadata_bytes']+r['initial_owner_maximum_bytes']+r['normal_output_reserved_bytes']+r['max_simultaneous_log_reservation_bytes']<=r['owner_output_ceiling_bytes']
checks.append('89/22/6 selection and1GiB allocation arithmetic')
for name,h in plan['binding_refs'].items():
    p=Path(name);assert p.is_file() and not p.is_symlink() and p.stat().st_size<8*1024**2 and hashlib.sha256(p.read_bytes()).hexdigest()==h;checks.append('named small original '+name)
for f in ['guard-controls-binding.json','fixtures/bindings.json']:
    b=json.loads((P/f).read_text());assert b['collector_sha256']==hashlib.sha256((P/'templates/collect.py').read_bytes()).hexdigest()
    assert b['status']=='UNRUN'
assert json.loads((P/'fixtures/bindings.json').read_text())['reader_sha256']==hashlib.sha256((P/'templates/module_zip.py').read_bytes()).hexdigest()
checks.append('UNRUN fixtures bind exact helper/collector bytes')
print(json.dumps(dict(status='SOURCE_STATIC_PASS',checks=len(checks),items=checks,candidate_imported=False,collector_or_preparer_executed=False,fixture_executed=False,network=False),indent=2))

#!/usr/bin/env python3
"""UNRUN synthetic in-memory controls. No network, target/Go code, or disk fixture."""
from pathlib import Path
import ast,base64,hashlib,io,json,stat,struct,warnings,zipfile
P=Path(__file__).resolve().parents[1]
source=(P/'templates/module_zip.py').read_bytes();binding=json.loads((P/'fixtures/bindings.json').read_text())
assert hashlib.sha256(source).hexdigest()==binding['reader_sha256']
tree=ast.parse(source)
assert all(isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Expr)) for n in tree.body)
ns={};exec(compile(tree,'bound-module-reader-pure-definitions','exec'),ns)
limits=json.loads((P/'resources.json').read_text())
selection=dict(module='example.com/fixture',version='v1.2.3',expected_zip_prefix='example.com/fixture@v1.2.3/',expected_go_h1=binding['positive_h1'])
prefix=selection['expected_zip_prefix'];passed=[]

def make(entries,compress=zipfile.ZIP_STORED):
    out=io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',UserWarning)
        with zipfile.ZipFile(out,'w',compression=compress) as z:
            for name,data,mode in entries:
                info=zipfile.ZipInfo(name,(2020,1,2,3,4,6));info.compress_type=compress
                info.external_attr=mode<<16;info.create_system=3;z.writestr(info,data)
    return out.getvalue()

base=[(prefix+'LICENSE',b'abc',stat.S_IFREG|0o644),(prefix+'src.go',b'',stat.S_IFREG|0o644)]

def case(name,raw=None,selection_override=None,limits_override=None,counts=None,fail=False):
    s=dict(selection);s.update(selection_override or {});l=dict(limits);l.update(limits_override or {})
    try:
        value=ns['hash_zip'](io.BytesIO(raw if raw is not None else make(base)),s,l,{} if counts is None else counts)
    except (AssertionError,ValueError,UnicodeError,zipfile.BadZipFile,RuntimeError,NotImplementedError):
        assert fail,name+' unexpected refusal'
    else:
        assert not fail,name+' unexpectedly accepted'
        assert value['actual_go_h1']==s['expected_go_h1']
    passed.append(name)

case('known-literal-Hash1-summary')
case('compression-order-mode-timestamp-irrelevant',make([(n,d,stat.S_IFREG|0o755) for n,d,m in reversed(base)],zipfile.ZIP_DEFLATED))
case('directory-entry-is-hashed',make([(prefix+'sub/',b'',stat.S_IFDIR|0o755)]+base),{'expected_go_h1':binding['directory_h1']})
case('content-tamper',make([(base[0][0],b'abd',base[0][2]),base[1]]),fail=True)
case('full-prefixed-name-is-hashed',make([(n.replace('/fixture@','/other@'),d,m) for n,d,m in base]),fail=True)
case('wrong-selected-checksum',selection_override={'expected_go_h1':'h1:'+'A'*43+'='},fail=True)
case('duplicate-entry',make(base+[base[0]]),fail=True)
case('case-collision',make(base+[(prefix+'license',b'abc',stat.S_IFREG|0o644)]),fail=True)
case('parent-case-collision',make(base+[(prefix+'D/a',b'',stat.S_IFREG|0o644),(prefix+'d/b',b'',stat.S_IFREG|0o644)]),fail=True)
for name in ['../escape','/absolute','a/../escape','a//b','a\\b','a\nb','a:b']:
    case('unsafe-name-'+repr(name),make(base+[(prefix+name,b'',stat.S_IFREG|0o644)]),fail=True)
case('absolute-full-name',make(base+[('/escape',b'',stat.S_IFREG|0o644)]),fail=True)
case('file-directory-conflict',make(base+[(prefix+'a',b'',stat.S_IFREG|0o644),(prefix+'a/b',b'',stat.S_IFREG|0o644)]),fail=True)
case('symlink',make(base+[(prefix+'link',b'target',stat.S_IFLNK|0o777)]),fail=True)
case('nested-go-mod',make(base+[(prefix+'sub/go.mod',b'',stat.S_IFREG|0o644)]),fail=True)
case('cased-go-mod',make(base+[(prefix+'Go.mod',b'',stat.S_IFREG|0o644)]),fail=True)
case('entry-bound',limits_override={'max_zip_entries_per_module':1},fail=True)
case('aggregate-entry-bound',counts={'entries':limits['max_zip_entries_aggregate']},fail=True)
case('member-decoded-bound',limits_override={'max_decoded_member_bytes':2},fail=True)
case('module-decoded-bound',limits_override={'max_decoded_module_bytes':2},fail=True)
case('aggregate-decoded-bound',counts={'decoded_bytes':limits['max_decoded_aggregate_bytes']},fail=True)
case('name-bound',limits_override={'max_name_utf8_bytes':3},fail=True)
case('notice-bytes-bound',limits_override={'notice_text_aggregate_bytes':2},fail=True)
case('notice-count-bound',limits_override={'max_notice_candidates':0},fail=True)
case('not-a-zip',b'not a zip',fail=True)
raw=bytearray(make(base));start=raw.index(b'abc');raw[start]=ord('d');case('CRC-mismatch',bytes(raw),fail=True)
raw=bytearray(make(base))
for signature,offset in [(b'PK\x03\x04',6),(b'PK\x01\x02',8)]:
    at=raw.index(signature);flags=struct.unpack_from('<H',raw,at+offset)[0];struct.pack_into('<H',raw,at+offset,flags|1)
case('encrypted-flag',bytes(raw),fail=True)
assert ns['proxy_url']('github.com/Some/Module','v1.2.3')=='https://proxy.golang.org/github.com/!some/!module/@v/v1.2.3.zip'
passed.append('official-uppercase-path-escape')
# Reuse collector definitions only; no top-level owner reads/spawns are evaluated.
csource=(P/'templates/collect.py').read_bytes();assert hashlib.sha256(csource).hexdigest()==binding['collector_sha256']
ctree=ast.parse(csource);defs=[n for n in ctree.body if isinstance(n,ast.FunctionDef) and n.name=='release_payload']
assert len(defs)==1;state={'OUTPUT_BYTES':100,'compressed_bytes':100};exec(compile(ast.Module(body=defs,type_ignores=[]),'payload-reservation-definition','exec'),state)
r=dict(reserved_bytes=100,released_bytes=0,original_wait_observed=False)
try:state['release_payload'](r,20,False)
except AssertionError:pass
else:raise AssertionError('unknown wait released reservation')
assert state['OUTPUT_BYTES']==state['compressed_bytes']==100
state['release_payload'](r,20,True);assert state['OUTPUT_BYTES']==state['compressed_bytes']==20
try:state['release_payload'](r,20,True)
except AssertionError:pass
else:raise AssertionError('double-release accepted')
passed+=['payload-unknown-wait-refused','payload-original-wait-release','payload-double-release-refused']
for name in passed:print('PASS '+name)
print(json.dumps(dict(result='PASS',controls=len(passed),network=False,target_or_go_execution=False,filesystem_fixture=False)))

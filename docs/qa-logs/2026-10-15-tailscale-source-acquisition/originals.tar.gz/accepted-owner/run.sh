#!/bin/bash
set -eu
TASK_OWNER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
set +e
taskset -c 0,1 prlimit --as=2147483648 --fsize=67108864 -- timeout --signal=TERM --kill-after=15s 1830s python3 -I "$TASK_OWNER/run.py"
task_rc=$?
set -e
(set -C; printf '%s\n' "$task_rc" > "$TASK_OWNER/outer.rc")
exit "$task_rc"

"""Data-only bounded Go HashZip/Hash1 reader. Import has no I/O or execution."""
import base64,hashlib,re,stat,zipfile
from pathlib import PurePosixPath


def escape(value):
    assert value.isascii(), 'selected module/version must be ASCII'
    return ''.join('!'+c.lower() if 'A'<=c<='Z' else c for c in value)


def proxy_url(module,version):
    assert module and version and not any(c in module+version for c in '\\?#\r\n\x00 ')
    return 'https://proxy.golang.org/'+escape(module)+'/@v/'+escape(version)+'.zip'


def notice(name):
    p=PurePosixPath(name)
    return bool(re.match(r'(?i)^(licen[cs]e|copying|notice|copyright|patents?|authors)(?:[._-].*)?$',p.name)) or any(x.lower() in ['licenses','licences'] for x in p.parts[:-1])


def add_count(counts,key,n,maximum):
    assert type(n)is int and n>=0 and counts.get(key,0)+n<=maximum,'bounded '+key+' exceeded'
    counts[key]=counts.get(key,0)+n


def hash_zip(stream,selection,limits,counts,on_decoded=lambda n:None):
    """Hash every entry exactly as Go HashZip; never extract, import or execute it.

    Additional conservative input restrictions fail closed. Returned text candidates
    are bytes from the same checksum-verified ZIP, not license classifications.
    """
    prefix=selection['module']+'@'+selection['version']+'/'
    assert prefix==selection['expected_zip_prefix']
    assert re.fullmatch(r'h1:[A-Za-z0-9+/]{43}=',selection['expected_go_h1'])
    index=[];texts=[];names=set();folds={};types={};declared=0;decoded=0
    with zipfile.ZipFile(stream,'r') as archive:
        members=archive.infolist()
        assert 0<len(members)<=limits['max_zip_entries_per_module']
        add_count(counts,'entries',len(members),limits['max_zip_entries_aggregate'])
        for m in members:
            name=m.filename;encoded=name.encode('utf-8',errors='strict')
            assert 0<len(encoded)<=limits['max_name_utf8_bytes'],'name byte bound'
            assert name==m.orig_filename and name.startswith(prefix),'wrong prefix or truncated name'
            assert not any(ord(c)<32 or ord(c)==127 or c in '\\:*?"<>|' for c in name),'unsafe member name'
            assert name not in names,'duplicate member';names.add(name)
            assert m.flag_bits&1==0,'encrypted member'
            # Python otherwise decodes legacy non-ASCII names as CP437, whereas Go
            # hashes raw name bytes. Refuse ambiguity rather than hash different bytes.
            assert name.isascii() or m.flag_bits&0x800,'non-UTF8 member encoding'
            assert m.compress_type in [zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED],'unsupported compression'
            relative=name[len(prefix):];isdir=m.is_dir()
            assert relative or isdir,'empty regular member'
            path=PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts and str(path)==name.rstrip('/'),'noncanonical path'
            mode=(m.external_attr>>16)&0xffff;kind=stat.S_IFMT(mode)
            assert kind in ([0,stat.S_IFDIR] if isdir else [0,stat.S_IFREG]),'nonregular member'
            assert not isdir or m.file_size==0,'nonempty directory'
            assert 0<=m.file_size<=limits['max_decoded_member_bytes'],'member decoded bound'
            if relative in ['go.mod','LICENSE']:assert m.file_size<=16*1024**2,'Go root text bound'
            assert PurePosixPath(relative).name.lower()!='go.mod' or relative=='go.mod','misplaced/cased go.mod'
            declared+=m.file_size;assert declared<=limits['max_decoded_module_bytes'],'module decoded bound'
            parts=name.rstrip('/').split('/')
            for n in range(1,len(parts)+1):
                current='/'.join(parts[:n]);fold=current.casefold();directory=n<len(parts) or isdir
                assert fold not in folds or folds[fold]==current,'case-fold collision'
                folds[fold]=current
                assert current not in types or types[current]==directory,'file/directory collision'
                types[current]=directory
        # Go sort.Strings is lexicographic UTF-8 bytes. Directory entries, if
        # present, participate too; do not silently drop them before Hash1.
        summary=hashlib.sha256()
        for m in sorted(members,key=lambda m:m.filename.encode('utf-8')):
            selected=not m.is_dir() and notice(m.filename[len(prefix):])
            if selected:
                assert m.file_size<=limits['notice_text_per_file_bytes'],'notice per-file bound'
                add_count(counts,'notice_candidates',1,limits['max_notice_candidates'])
                add_count(counts,'notice_bytes',m.file_size,limits['notice_text_aggregate_bytes'])
            h=hashlib.sha256();size=0;chunks=[]
            with archive.open(m,'r') as member:
                while True:
                    data=member.read(65536)
                    if not data:break
                    size+=len(data);decoded+=len(data)
                    assert size<=m.file_size and decoded<=limits['max_decoded_module_bytes'],'decoded size mismatch/bound'
                    add_count(counts,'decoded_bytes',len(data),limits['max_decoded_aggregate_bytes'])
                    on_decoded(len(data));h.update(data)
                    if selected:chunks.append(data)
            assert size==m.file_size,'declared/decoded size mismatch'
            digest=h.hexdigest()
            summary.update((digest+'  '+m.filename+'\n').encode('utf-8'))
            row=dict(name=m.filename,relative_path=m.filename[len(prefix):],bytes=size,sha256=digest,directory=m.is_dir(),compression=m.compress_type,crc32=m.CRC,external_attr=m.external_attr,flag_bits=m.flag_bits)
            index.append(row)
            if selected:texts.append((row,b''.join(chunks)))
    actual='h1:'+base64.b64encode(summary.digest()).decode('ascii')
    assert actual==selection['expected_go_h1'],'selected embedded h1 mismatch'
    return dict(actual_go_h1=actual,member_count=len(index),declared_bytes=declared,decoded_bytes=decoded,index=index,texts=texts)

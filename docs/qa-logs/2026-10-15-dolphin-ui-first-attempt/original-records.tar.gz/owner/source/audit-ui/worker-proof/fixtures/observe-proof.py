#!/usr/bin/env python3
"""UNRUN Linux/VM supervisor; record the original driver and descendant statuses.

The known-bad baseline returns 1 when children survive normal driver exit. That
failure is retained, then this supervisor cleans only its own child tree.
"""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def identity(pid):
    try:
        text = Path(f'/proc/{pid}/stat').read_text()
    except FileNotFoundError:
        return None
    fields = text[text.rfind(')') + 2:].split()
    return dict(pid=pid, ppid=int(fields[1]), pgid=int(fields[2]),
                state=fields[0], start_ticks=int(fields[19]))


def children(pid):
    try:
        return [int(x) for x in Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
    except FileNotFoundError:
        return []


def tree(pid):
    answer = []
    for child in children(pid):
        row = identity(child)
        if row:
            answer.append(row)
            answer.extend(tree(child))
    return answer


def same(row):
    now = identity(row['pid'])
    return now is not None and now['start_ticks'] == row['start_ticks']


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def reap(rows):
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            return
        if pid == 0:
            return
        rows.append(dict(pid=pid, wait_status=status, exit_code=os.waitstatus_to_exitcode(status)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--binary', type=Path, required=True)
    p.add_argument('--binary-sha256', required=True)
    p.add_argument('--backend-dir', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--mode', choices=['explicit', 'atexit', 'complete'], required=True)
    a = p.parse_args()
    binary = a.binary.resolve(strict=True)
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == a.binary_sha256
    backend = a.backend_dir.resolve(strict=True)
    assert (backend / 'wifictl').is_file()
    a.output.mkdir(mode=0o700, parents=False)  # Refuse a reused owner.
    root = a.output.resolve(strict=True)
    libc = ctypes.CDLL(None, use_errno=True)
    assert libc.prctl(36, 1, 0, 0, 0) == 0  # PR_SET_CHILD_SUBREAPER
    env = dict(os.environ, PATH=str(backend) + ':/usr/bin:/bin')
    result = dict(status='RUNNING', binary=str(binary), binary_sha256=a.binary_sha256,
                  mode=a.mode, started=time.monotonic(), observations=[], reaped=[], forced_cleanup=[])
    proc = None
    original = 2
    try:
        with (root / 'driver.stdout').open('wb') as stdout, (root / 'driver.stderr').open('wb') as stderr:
            proc = subprocess.Popen([str(binary), str(root), a.mode], stdout=stdout,
                                    stderr=stderr, env=env, start_new_session=True)
            result['driver_identity'] = identity(proc.pid)
            deadline = time.monotonic() + 5
            while not (root / 'driver-ready').exists():
                if proc.poll() is not None:
                    raise RuntimeError('driver exited before readiness')
                if time.monotonic() >= deadline:
                    raise RuntimeError('driver readiness exceeded 5 seconds')
                time.sleep(.01)
            observed = tree(proc.pid)
            result['observations'] = observed
            if a.mode != 'complete':
                ids = [int(x) for x in (root / 'backend-pids').read_text().split()]
                assert len(ids) == 2
                index = {r['pid']: r for r in observed}
                assert all(pid in index and index[pid]['state'] != 'Z' for pid in ids)
                assert index[ids[0]]['pgid'] == ids[0] == index[ids[1]]['pgid']
                result['blocked_group'] = dict(leader=index[ids[0]], descendant=index[ids[1]])
            result['exit_requested'] = time.monotonic()
            (root / 'continue-exit').write_text('normal exit\n')
            result['driver_original_returncode'] = proc.wait(timeout=5)
            result['driver_exited'] = time.monotonic()
            reap(result['reaped'])
            # Poll for normal init-equivalent reaping without killing anything.
            deadline = time.monotonic() + .5
            while children(os.getpid()) and time.monotonic() < deadline:
                reap(result['reaped'])
                time.sleep(.01)
            result['survivors_after_normal_exit'] = tree(os.getpid())
            result['owned_identities_still_present'] = [r for r in observed if same(r)]
            original = 0 if result['driver_original_returncode'] == 0 and not result['survivors_after_normal_exit'] and not result['owned_identities_still_present'] else 1
            result['original_observation_returncode'] = original
            result['status'] = 'PASS' if original == 0 else 'FAIL'
    except BaseException as error:
        result['status'] = 'FAIL'
        result['error'] = f'{type(error).__name__}: {error}'
        original = 2
    finally:
        # Record failure before cleanup. No PID-name matching or unrelated process is used.
        result['original_observation_returncode'] = original
        write(root / 'before-cleanup.json', result)
        if proc is not None and proc.poll() is None:
            row = identity(proc.pid)
            if row and result.get('driver_identity') and same(result['driver_identity']):
                os.kill(proc.pid, signal.SIGKILL)
                result['forced_cleanup'].append(row)
            try:
                result['driver_original_returncode'] = proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                result['driver_unreaped'] = True
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            reap(result['reaped'])
            owned = tree(os.getpid())
            if not owned:
                break
            for row in reversed(owned):
                if row['state'] != 'Z' and same(row):
                    try:
                        os.kill(row['pid'], signal.SIGKILL)
                        result['forced_cleanup'].append(row)
                    except ProcessLookupError:
                        pass
            time.sleep(.01)
        reap(result['reaped'])
        result['survivors_after_cleanup'] = tree(os.getpid())
        result['ended'] = time.monotonic()
        result['final_returncode'] = original if not result['survivors_after_cleanup'] and not (original == 0 and result['forced_cleanup']) else 2
        if result['final_returncode'] != 0:
            result['status'] = 'FAIL'
        write(root / 'result.json', result)
    return result['final_returncode']


if __name__ == '__main__':
    raise SystemExit(main())

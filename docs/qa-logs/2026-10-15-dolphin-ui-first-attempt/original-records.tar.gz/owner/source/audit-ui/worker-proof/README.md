# Wi-Fi scan normal-exit correction — source-only G-01 packet

Local ES commit **16dbac5211eea7e70db7394372033be2be7df829**, based exactly on
`3178b832b8d134198b2b4eede4f725d4ed283f8c`. Branch
`feature/m7-wifi-normal-exit-20261015`; isolated worktree
`/home/max/Development/emulationstation-next.worktrees/m7-wifi-normal-exit-20261015`.
The shared `qa-integration` checkout and all distribution pins are unchanged.
No compiler, preparer, test fixture, VM, service, signal or network action was
executed. The local commit passed its normal credential/word guards; no push or
integration was performed. Runtime qualification is pending.

The defect is a missing process-level owner during normal frontend teardown.
The old detached worker survives picker Back correctly, but normal main return
ends the thread without invoking its child-group cleanup. The correction changes
only `GuiWifi.cpp`, `GuiWifi.h`, `WifiScanProcess.h` and `main.cpp`:

- A process-owned joinable thread holds the active scan independently of its
  picker. Back drops only the GUI's result reference. Reopen attaches to the
  same pending scan; completed workers are joined before a fresh explicit job.
- Cancellation is checked before spawning and in both nonblocking read loops.
  Returning the existing failure answer invokes unchanged process-group cleanup.
  Saved/current stages are skipped after cancellation.
- Main-thread shutdown blocks new work, requests cancellation, joins and releases
  the result. It runs immediately after `AppWindow::closing()` and again,
  idempotently, from `onExit()` before log teardown. Its process owner follows
  the existing `SaveStateBookkeeper` lifetime pattern, avoiding static destruction
  of a joinable thread before the atexit hook.
- Signal handlers, service units and D-CLOUD-133 behavior remain unchanged.
  **This is not a universal parent-death or service-stop containment fix.**

`product.diff` is the exact four-file diff. `source/` retains baseline and candidate
bytes; `source-manifest.json` binds them. `static-review.json` records only checks
actually performed: diff whitespace, fixture Python AST/shell syntax, exact
existing picker-function/presentation-tail/player-string equality, unchanged
child cleanup and signal handlers, source ownership and hook review. Compilation
and runtime tests are explicitly unrun. No new frame or accepted behavior result
is claimed.

[flow-and-proof.md](flow-and-proof.md) contains the unchanged-presentation reference,
small negative/positive controls, actual-frontend proof, bounds and residuals.
`fixtures/` is a standalone unrun source fixture, not a new VM lifecycle framework.
The baseline observer must retain original 1/FAIL when the child survives; its
successful failure cleanup does not change that original status.

## Exact next commands, after coordinator allocation

Use the existing monitored compiler owner and current build cache. This is a
command handoff, not evidence that any command ran:

```bash
TASK_ES=/home/max/Development/emulationstation-next.worktrees/m7-wifi-normal-exit-20261015
TASK_COORD=/workspace/repos/rocknix.worktrees/m7-player-setup
TASK_BUILD=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01/build.pixelelated-GENERIC_X64.x86_64
TASK_PACKET=/tmp/pix-m7-wifi-normal-exit-20261015
# --tree is necessary because both GuiWifi and the process helper headers changed.
"$TASK_COORD/tools/es-syntax-check" --root "$TASK_BUILD" --tree "$TASK_ES" \
  "$TASK_ES/es-app/src/guis/GuiWifi.cpp" "$TASK_ES/es-app/src/main.cpp"
# TASK_COMPILE_OUT must be a new directory inside the allocated compiler owner.
bash "$TASK_PACKET/fixtures/build-fixtures.sh" \
  "$TASK_BUILD/toolchain/bin/x86_64-rocknix-linux-gnu-g++" "$TASK_COMPILE_OUT"
```

The target compiler path was located read-only; it was not executed. Preserve
compiler executable/flags/outputs and hashes through the existing watcher. Copy
the small source packet and resulting target binaries into the coordinator's
fresh no-NIC guest using its existing bounded lifecycle. For each control, the
record-directory argument must be new and the binary hash must equal the actual
compiled artifact (replace the angle-bracket placeholders before execution):

```bash
python3 -I -B /run/wifi-normal-exit/fixtures/observe-proof.py \
  --binary /run/wifi-normal-exit/bin/baseline \
  --binary-sha256 '<baseline-binary-sha256>' \
  --backend-dir /run/wifi-normal-exit/fixtures/bin \
  --output /run/wifi-normal-exit/results/baseline-explicit --mode explicit
# Preserve original 1 here; assess it as the expected negative observation.
python3 -I -B /run/wifi-normal-exit/fixtures/observe-proof.py \
  --binary /run/wifi-normal-exit/bin/candidate \
  --binary-sha256 '<candidate-binary-sha256>' \
  --backend-dir /run/wifi-normal-exit/fixtures/bin \
  --output /run/wifi-normal-exit/results/candidate-explicit --mode explicit
# Repeat the same candidate command with new output names and --mode atexit,
# then --mode complete. Preserve each original command/status independently.
```

Root must bind actual candidate bytes and the fresh owner before running the
installed frontend flow. No existing owner, image, accepted frame baseline,
mask, source pin or audit packet is modified by this preparation. G-01 stays
unqualified until its exact-source proof is reviewed; abrupt termination remains
explicitly separate.

// UNRUN. Exact worker excerpts and actual process helper, with a GUI-free class
// shell. Installed ES/UI/main hooks still require the separate VM flow proof.
#include "WifiText.h"
#include "WifiScanProcess.h"
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <exception>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>
#include <unistd.h>
#define LOG(level) std::cerr
#include "worker-declarations.h"
#include "worker-excerpt.inc"
using Clock = std::chrono::steady_clock;
static std::string root;
static void require(bool ok, const char* why) { if (!ok) throw std::runtime_error(why); }
static bool present(const std::string& name) { return bool(std::ifstream(root + "/" + name)); }
static void mark(const std::string& name) { std::ofstream(root + "/" + name) << "ready\n"; }
template<class Condition> static void waitFor(Condition condition)
{
    const auto end = Clock::now() + std::chrono::seconds(3);
    while (!condition()) {
        require(Clock::now() < end, "fixture readiness timeout");
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}
static size_t calls()
{
    std::ifstream input(root + "/invocations");
    size_t count = 0; std::string line;
    while (std::getline(input, line)) ++count;
    return count;
}
static long elapsed(Clock::time_point start)
{
    return std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - start).count();
}
int main(int argc, char** argv)
{
    try {
        require(argc == 3, "usage: worker-proof record-directory explicit|atexit|complete");
        root = argv[1]; const std::string mode = argv[2];
        require(mode == "explicit" || mode == "atexit" || mode == "complete", "unknown mode");
        require(setenv("WIFI_PROOF_ROOT", root.c_str(), 1) == 0, "set root");
        require(setenv("WIFI_PROOF_MODE", mode == "complete" ? "complete" : "blocked", 1) == 0, "set mode");
#if WIFI_SHUTDOWN_CANDIDATE
        require(std::atexit([] { GuiWifi::shutdownScans(); }) == 0, "atexit registration");
        // An already-cancelled actual runner must not execute a backend at all.
        std::atomic<bool> cancelled{true};
        auto refused = WifiScanProcess::read({"wifictl", "list"}, std::chrono::seconds(30), &cancelled);
        require(refused.code == -1 && refused.lines.empty() && calls() == 0, "cancel before spawn");
#endif
        auto picker = std::unique_ptr<GuiWifi>(new GuiWifi());
        picker->onRefresh(false);
        auto first = picker->mScan;
        require(first != nullptr, "scan not started");
        if (mode == "complete") {
            waitFor([&] { return first->ready.load(std::memory_order_acquire); });
            require(first->answer.inRangeKnown && first->answer.savedKnown && first->answer.currentKnown, "normal result changed");
            require(calls() == 3, "normal stage count");
            picker->mScan.reset(); // update() consumes this shared result in the real UI.
            picker->onRefresh(true);
            auto second = picker->mScan;
            require(second != nullptr && second != first, "completed scan was reused");
            waitFor([&] { return second->ready.load(std::memory_order_acquire); });
            require(calls() == 6, "refresh stage count");
        } else {
            waitFor([] { return present("backend-ready"); });
            const auto closeStart = Clock::now();
            picker.reset(); // Tests value ownership only; installed frames cover real Back.
            const auto closeMs = elapsed(closeStart);
            require(closeMs < 100, "view release blocked");
            const auto reopenStart = Clock::now();
            picker.reset(new GuiWifi()); picker->onRefresh(false);
            const auto reopenMs = elapsed(reopenStart);
            require(picker->mScan == first && calls() == 1, "reopen started a rival scan");
            std::ofstream(root + "/view-ownership.json") << "{\"release_ms\":" << closeMs
                << ",\"reopen_ms\":" << reopenMs << ",\"same_pending_scan\":true}\n";
        }
        mark("driver-ready");
        waitFor([] { return present("continue-exit"); });
#if WIFI_SHUTDOWN_CANDIDATE
        if (mode != "atexit") {
            const auto stopStart = Clock::now();
            GuiWifi::shutdownScans(); GuiWifi::shutdownScans();
            const auto stopMs = elapsed(stopStart);
            require(stopMs < 3000, "normal shutdown exceeded proof bound");
            GuiWifi after; after.onRefresh(false);
            require(after.mScan == nullptr, "new scan after shutdown");
            require(calls() == (mode == "complete" ? 6u : 1u), "follow-up backend spawned after cancel");
            std::ofstream(root + "/shutdown.json") << "{\"elapsed_ms\":" << stopMs
                << ",\"idempotent\":true,\"new_scan_refused\":true}\n";
        }
#endif
        std::cout << "driver normal return 0\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "fixture failure: " << e.what() << '\n';
        return 2;
    }
}

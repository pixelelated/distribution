#!/bin/bash
# UNRUN. The coordinator allocates and watches compilation before invoking this.
set -euo pipefail
[ "$#" -eq 2 ] || { echo 'usage: build-fixtures.sh absolute-target-cxx fresh-output-directory' >&2; exit 64; }
fixture_cxx=$1
fixture_out=$2
fixture_packet=$(cd "$(dirname "$0")/.." && pwd)
[ -x "$fixture_cxx" ] && [ ! -e "$fixture_out" ] || exit 65
mkdir -m 700 "$fixture_out"
for fixture_kind in baseline candidate; do
    fixture_define=0
    [ "$fixture_kind" != candidate ] || fixture_define=1
    "$fixture_cxx" -std=c++17 -O1 -g -pthread \
      -DWIFI_SHUTDOWN_CANDIDATE="$fixture_define" \
      -I"$fixture_packet/fixtures/$fixture_kind" \
      -I"$fixture_packet/source/$fixture_kind/es-app/src" \
      -I"$fixture_packet/source/$fixture_kind/es-app/src/guis" \
      "$fixture_packet/fixtures/worker-proof.cpp" \
      "$fixture_packet/source/$fixture_kind/es-app/src/WifiText.cpp" \
      -o "$fixture_out/$fixture_kind" \
      > "$fixture_out/$fixture_kind.compile.stdout" \
      2> "$fixture_out/$fixture_kind.compile.stderr"
done
sha256sum "$fixture_out/baseline" "$fixture_out/candidate" > "$fixture_out/binaries.sha256"

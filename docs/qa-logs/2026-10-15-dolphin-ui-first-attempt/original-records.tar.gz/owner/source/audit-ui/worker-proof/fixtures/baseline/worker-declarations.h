#pragma once
// Fixture-only class shell: real nested result/owner declarations; no GUI rendering.
class GuiWifi {
public:
	struct Answer
	{
		std::vector<std::string> inRange;
		bool inRangeKnown = false;
		std::vector<WifiText::SavedNetwork> saved;
		std::string current;
		// Whether `wifictl saved` and `wifictl current` answered at all: an
		// empty list and no list are different answers (#308 F-WF-03/06).
		bool savedKnown = false;
		bool currentKnown = false;
	};

	// The worker owns only this value. No GUI or Window pointer crosses into
	// it, and the UI consumes the answer only after the release/acquire pair.
	struct Scan
	{
		Answer answer;
		std::atomic<bool> ready{false};
	};

 std::shared_ptr<Scan> mScan;
 bool mWaitingLoad = false;
 void onRefresh(bool rescan = true);
};

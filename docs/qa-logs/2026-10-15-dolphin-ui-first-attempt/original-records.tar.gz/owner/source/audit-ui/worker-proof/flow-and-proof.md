# G-01 normal frontend exit: unchanged presentation and focused proof

Source-only, UNRUN. Can this be done on the VM? Yes: process ownership and
normal frontend teardown need no radio, real credentials or hardware fact.
The coordinator records this answer in the owning issue before allocating proof.

The canonical reference is `docs/es-menu-map.md`, Wi-Fi flow at lines 420–492.
Its Back branch is picker closure: the one bounded read continues, and reopening
attaches to it. That branch, all rows, labels, layout, input handlers and
presentation code remain unchanged. The new lifecycle edge is normal **whole
frontend exit**, which cancels and joins the pending read worker before frontend
teardown. This adds no screen, row, player string or navigation branch. No
canonical diagram edit is proposed. An accepted evidence link and a sentence
separating whole-frontend shutdown from picker closure should accompany final
qualification; shared references are coordinator-owned and were not edited here.

Prior accepted evidence: `2026-10-13-setup-qualification/installed` covers
Back/reopen at 640×480 and 1280×800; `2026-10-15-wifi-remaining-result` retains
24 reviewed branch frames and 27 completed backend calls. Those originals stay
accepted for their scope. They do not prove this new normal-exit behavior.
`2026-10-13-wifi-picker-source/README.md` explicitly excluded frontend termination
from the old runner's containment claim.

## Small source-level VM controls

`fixtures/worker-proof.cpp` includes actual worker excerpts and the actual
`WifiScanProcess.h`, with the real `WifiText.cpp`. The excerpt boundary removes
only the unchanged GUI presentation tail. The class shell exposes the actual
nested result/owner declarations for assertions. It supplies no GUI, renderer,
Window, singleton, fake deadline or replacement process runner. The compiled
baseline retains the actual detached worker; candidate uses the committed join.
The backend is a disposable `wifictl` stand-in that starts one 30-second sleep
holding stdout, or returns a small normal result. It writes only its private
proof directory. No provider, listener, settings or network access is used.

Run only these four controls in one allocated no-NIC guest:

| Binary/mode | Required original observation |
| --- | --- |
| baseline/explicit | Driver returns 0 normally while its captured backend group remains; observer returns 1 and records FAIL before cleanup. This is the expected negative control, never rewritten as PASS. |
| candidate/explicit | Already-cancelled read invokes no backend; releasing/reopening the result does not wait or start a rival; normal shutdown joins, repeated shutdown is safe, no new scan starts afterward, no saved/current child follows cancellation; observer 0 without forced cleanup. |
| candidate/atexit | Same blocked scan/reopen, then normal return through registered shutdown fallback; driver 0, group absent/reaped, observer 0 without forced cleanup. |
| candidate/complete | Normal three-stage result, then explicit refresh creates a fresh job and joins the completed predecessor; exactly six backend calls, driver/observer 0, no survivor or forced cleanup. |

The observer is a subreaper. It records each observed PID, start ticks and process
group before allowing the driver to exit, original driver return code, adopted
wait statuses, pre-cleanup survival and any forced cleanup. It only signals its
own identity-checked descendants during failure cleanup. The baseline remains a
failed observation even after those descendants are cleaned. A candidate needing
forced cleanup fails. Per-control ceilings: driver readiness 5 seconds, normal
exit 5 seconds, observation 0.5 seconds, exceptional direct-child wait 2 seconds,
cleanup 3 seconds; allocate a 20-second outer envelope per control and a 120-second
family budget plus 30-second owner cleanup reserve. The common VM owner must
retain its own deadline, original channels and exact-QEMU teardown. These are
proof budgets, not a claim that uninterruptible kernel work is interruptible.

## Focused actual-frontend flow

After source syntax and the small controls, use the existing qualified Wi-Fi
VM lifecycle/adapter, with a fresh owner and exact candidate binary/source hash.
Preserve the existing no-NIC, process, selected-config custody, exit and export
controls. Do not mutate any old owner or active script. This packet does not
provide or execute a new generic VM runner.

1. Bind a deliberately blocked read-only enumeration seam with a recorded
   leader/descendant PID, start tick and group. Retain actual ES executable hash,
   PID/start identity and original launcher exit channel. Use the current
   installed image for the known-bad normal-exit control; retain that failure.
2. On the candidate, open WI-FI NETWORKS through the normal input path. Capture
   `searching`, press Back, capture the returned NETWORK SETTINGS page, reopen,
   and capture `reopened-searching`. Assert the same pending backend identity
   and one enumeration call. Measure real input-to-return responsiveness
   (proposed ceiling 1 second); the extracted class-shell timings are not this
   UI measurement. Review these unchanged frames at 640×480 and 1280×800, retaining
   source/build/language/flow/hash/dimensions in the existing frame-index format.
3. While the read is still blocked, send SIGINT to the identity-bound ES PID.
   This deliberately exercises the existing normal main-loop exit; it is not
   a hardware-button or service-stop test. Retain scan-stop/join log lines,
   original ES exit, the process observations and adopted/reaped child status.
   Require current read group gone, no saved/current invocation afterward and
   no teardown error. Proposed observation ceilings: scan shutdown 3 seconds,
   whole ES exit 10 seconds. A timeout or forced cleanup prevents acceptance.
4. Normal completed enumeration/refresh and the atexit fallback are covered by
   the small controls; do not replay the full 24-frame Wi-Fi matrix or unrelated
   protocol, phone, cloud, native-gameplay and naming flows.

A private candidate binary can provide draft source/flow evidence only. Final
installed-image acceptance must bind the actual resulting artifact and source;
no product pin is promoted by this packet. Existing paired presentation frames
are historical comparisons, not newly reviewed candidate frames. The fixture's
synthetic enumeration proves ES lifecycle behavior, not physical radio behavior.

## Explicit residual

SIGTERM, fatal signals, SIGKILL, `_exit`, escaped process groups and uninterruptible
kernel tasks remain outside this normal-exit fix. D-CLOUD-133 intentionally keeps
SIGTERM out of normal post-game/frontend teardown. `emustation.service` remains
`KillMode=process`; no service-wide child ownership claim is made. A future
abrupt-termination correction requires its own narrow ownership design and proof.

#!/usr/bin/env python3
"""Finite parent for the GUI observer; retain the actual observer wait status."""
import argparse,json,os,signal,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--binary-sha256',required=True);p.add_argument('--known-bad',action='store_true');a=p.parse_args()
assert not a.output.exists() and a.output.parent==Path('/tmp/pix-output/audit-ui')
argv=[sys.executable,'-I','-S','-B',str(Path(__file__).with_name('guest-wifi-observer.py')),'--output',str(a.output),'--binary-sha256',a.binary_sha256]+(['--known-bad'] if a.known_bad else [])
row={'argv':argv,'original_returncode':None,'timed_out':False,'started':time.monotonic()};child=None
try:
 child=subprocess.Popen(argv,start_new_session=True);row['pid']=child.pid
 fd=os.pidfd_open(child.pid,0)  # Unreaped direct child; held handle prevents reuse.
 try:row['original_returncode']=child.wait(timeout=190)
 except subprocess.TimeoutExpired:
  row['timed_out']=True;signal.pidfd_send_signal(fd,signal.SIGTERM,None,0)
  try:row['original_returncode']=child.wait(timeout=8)
  except subprocess.TimeoutExpired:signal.pidfd_send_signal(fd,signal.SIGKILL,None,0);row['original_returncode']=child.wait(timeout=2)
finally:
 if 'fd' in locals():os.close(fd)
 row['ended']=time.monotonic()
 if a.output.is_dir():
  with (a.output/'owner-result.json').open('x') as stream:json.dump(row,stream,indent=2);stream.write('\n')
raise SystemExit(2 if row['timed_out'] else row['original_returncode'])

#!/usr/bin/env python3
"""UNRUN additive serial/HMP actions under the accepted native owner's one lock."""
import argparse,fcntl,hashlib,json,os,re,shlex,signal,struct,subprocess,time,uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--owner',type=Path,required=True);p.add_argument('action',choices=['init','controls','wifi-start','wifi-open','wifi-back-reopen','wifi-exit','refusal','dismiss','cleanup','finish']);p.add_argument('--mode',choices=['baseline','candidate']);p.add_argument('--language',choices=['en_US','fr_FR']);a=p.parse_args()
R=a.owner.resolve(strict=True);C=json.loads((R/'config.json').read_text());TREE=Path(C['checkout']);ready=json.loads((R/'visual-ready.json').read_text());pending=None
assert C['audit_ui']['packet_seal'] and time.monotonic()<ready['deadline_monotonic'] and not (R/'visual-result.json').exists()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):
 q=p.with_suffix('.pending');q.write_text(json.dumps(x,indent=2)+'\n');os.replace(q,p)
for n,h in C['code'].items():assert sha(R/n)==h
for n,h in C['tools'].items():assert sha(Path(n))==h
with (R/'serial.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 inv=R/'frames'/('audit-'+time.strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]);inv.mkdir()
 def execute(label,argv,seconds=30):
  row={'argv':list(map(str,argv)),'original_returncode':None,'timed_out':False,'started_monotonic':time.monotonic()}
  with (inv/(label+'.stdout')).open('xb') as out,(inv/(label+'.stderr')).open('xb') as err:
   child=subprocess.Popen(row['argv'],stdout=out,stderr=err,start_new_session=True)
   try:row['original_returncode']=child.wait(timeout=min(seconds,max(.1,ready['deadline_monotonic']-time.monotonic())))
   except subprocess.TimeoutExpired:row['timed_out']=True;os.killpg(child.pid,signal.SIGKILL);row['original_returncode']=child.wait(timeout=5)
  row['ended_monotonic']=time.monotonic();save(inv/(label+'.json'),row);assert row['original_returncode']==0 and not row['timed_out'],'preserve failed original action; no blind replay'
  return (inv/(label+'.stdout')).read_text()
 def code(script,seconds=30):
  tag='PIX_AUDIT_EXIT_'+uuid.uuid4().hex;command=script+'; pxrc=$?; printf "\\n'+tag+'=%s\\n" "$pxrc"'
  text=execute('serial-'+uuid.uuid4().hex[:8],[TREE/'tools/vm-serial','--socket',R/'vm/serial.sock','--timeout',str(seconds),'sh',command],seconds+7)
  assert re.findall(r'^'+tag+r'=([0-9]+)\r?$',text,re.M)==['0'];return text
 def guest(words,seconds=30):
  text=code(shlex.join(['python3','-I','-S','-B','/tmp/pix-input/gameplay/packet/audit-ui/guest-audit.py',*words]),seconds)
  rows=re.findall(r'^PIX_AUDIT_JSON=(.*)\r?$',text,re.M);assert len(rows)==1;return json.loads(rows[0])
 lines=re.findall(r'^PIX_GAMEPLAY_JSON=(.*)\r?$',(R/'qa-serial.txt').read_text(),re.M);assert len(lines)==1;keys=json.loads(lines[0])['input_keys']
 def key(name):execute('key-'+name+'-'+uuid.uuid4().hex[:8],[TREE/'tools/vm-visual-qa','--monitor',R/'vm/monitor.sock','key',keys[name]],3)
 def frame(label):
  path=inv/(label+'.png');execute('shot-'+label,[TREE/'tools/vm-visual-qa','--monitor',R/'vm/monitor.sock','shot',path],5)
  raw=path.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('!II',raw[16:24])==(640,480)
  row={'path':str(path),'sha256':sha(path),'label':label,'captured_host_monotonic':time.monotonic(),'time':time.time(),'observation':'unreviewed','source_binding':C['audit_ui']};save(R/'frames'/(label+'-capture.json'),row);return row
 if a.action=='wifi-open':
  # Reused accepted initial flow. The keyboard mapping comes from actual ES config.
  key('start');time.sleep(.3)
  for _ in range(6):key('up')
  key('a');time.sleep(.4)
  for _ in range(5):key('down')
  key('a');time.sleep(.4)
  state=guest(['wifi-state']);assert state['blocked'];frame('wifi-'+state['case']['mode']+'-searching');save(R/'audit-wifi-before.json',state)
 elif a.action=='wifi-back-reopen':
  before=json.loads((R/'audit-wifi-before.json').read_text());assert before['case']['mode']=='candidate'
  began=time.monotonic();key('b');time.sleep(.1);returned=frame('wifi-candidate-network-return');upper=returned['captured_host_monotonic']-began
  # Conservative input-to-captured-return upper bound; visible return must be reviewed.
  save(inv/'back-timing.json',{'upper_bound_seconds':upper,'proposed_limit_seconds':1,'passed':upper<=1,'frame_sha256':returned['sha256']});assert upper<=1
  key('a');time.sleep(.2);frame('wifi-candidate-reopened-searching');after=guest(['wifi-state'])
  assert after['blocked']==before['blocked'] and sum(row.split()[2] in ['list','scanlist'] for row in after['calls'])==1
 elif a.action=='refusal':
  assert a.language;result=guest(['refusal','--language',a.language],100);assert result['rc']==0;frame('dolphin-refusal-'+a.language.replace('_','-').lower());print(json.dumps(result))
 elif a.action=='dismiss':
  assert a.language;key('a');time.sleep(.3);frame('dolphin-return-'+a.language.replace('_','-').lower())
 elif a.action=='finish':
  assert json.loads((R/'audit-cleanup.json').read_text())['rc']==0
  # Normal pad finish without the unrelated native full-tree snapshot that
  # exceeded the earlier4096-file exporter. Preserve accepted owner fields.
  script="""import json,time,os,hashlib
from pathlib import Path
r=Path('/tmp/pix-output/gameplay');out=r.parent
(r/'finish.json').write_text(json.dumps({'time':time.time(),'scope':'audit UI complete'}))
limit=time.monotonic()+15
while not (r/'supervisor-result.json').exists():
 assert time.monotonic()<limit;time.sleep(.05)
v=json.loads((r/'supervisor-result.json').read_text());assert v['rc']==0 and v['pad_original_returncode']==0 and not v['forced_cleanup'] and not v['native_processes_at_end']
pid=json.loads((r/'supervisor.json').read_text())['pid']
while Path('/proc',str(pid)).exists():
 assert time.monotonic()<limit;time.sleep(.05)
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='guest-export-manifest.json');assert not any(p.is_symlink() for p in out.rglob('*'))
assert len(files)<=4095 and sum(p.stat().st_size for p in files)<=128*1024**2
rows=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()} for p in files]
(out/'guest-export-manifest.json').write_text(json.dumps(rows,indent=2)+'\\n');os.sync();print('PIX_AUDIT_FINISH='+json.dumps(v))
"""
  text=code('python3 -I -S -B -c '+shlex.quote(script),25);matches=re.findall(r'^PIX_AUDIT_FINISH=(.*)\r?$',text,re.M);assert len(matches)==1
  reviews=[json.loads(f.read_text()) for f in sorted((R/'frames').glob('*-review.json'))]
  required=['wifi-baseline-searching','wifi-candidate-searching','wifi-candidate-network-return','wifi-candidate-reopened-searching','dolphin-refusal-en-us','dolphin-return-en-us','dolphin-refusal-fr-fr','dolphin-return-fr-fr']
  assert all(any(r['label']==label for r in reviews) for label in required),'review all eight exact candidate/baseline frames before finish'
  for row in reviews:assert sha(Path(row['path']))==row['sha256']
  pending={'guest':json.loads(matches[0]),'reviews':reviews,'acceptance':'focused audit UI scope;640 only; original baseline failed; final installed image pending'}
 else:
  words=[a.action]
  if a.mode:words+=['--mode',a.mode]
  result=guest(words,120 if a.action=='controls' else 60);save(R/('audit-'+a.action+'.json'),result);print(json.dumps(result))
if pending is not None:save(R/'visual-result.json',pending)

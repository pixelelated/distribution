# #594 localized refusal at1280x800 — SOURCE ONLY, UNRUN

This separate continuation supplies the four English/French refusal and return
frames at1280x800 required alongside the640x480 frames by
`.claude/rules/generic-x64-vm-testing.md`215–222. It runs no Wi-Fi worker controls,
picker navigation or normal-exit proof. It launches no gameplay. No preparer,
VM, product helper, listener or runtime has executed from this packet.

The sealed640 packet `/tmp/pix-m7-audit-ui-plan-20261015`, seal
`61bab02371cd65a6b8bd0b22fa0d8a82fdba93dea54476e29355406b901c6958`, is the unchanged
preparation dependency. Its compiler/input/source assertions, final d4af image
readback, no-NIC helper, native guest setup, keyboard mapping, pad supervisor,
serial lock, process custody and stopped-owner export are retained. The wrapper
adds only the enclosed refusal-only action scripts and display-bound lifecycle
and exporter to a fresh, unadmitted owner. The existing640 owner and its source
are never edited. Inherited worker files remain unused provenance on input media;
neither action parser exposes the controls or Wi-Fi operations.

The lifecycle uses the existing `--res 1280x800` flag of qualified helper
5b058ed8a8b11135cd5997e3d925939baff30726033125acf1244863a756318d. It asserts the
generated `xres=1280,yres=800` device argument, retains actual QEMU argv equality,
and captures only PNGs whose dimensions are exactly1280x800. Generated/unmount
record names and the corresponding exporter expectation now say1280x800. These
changes and the frame-count/action restrictions have direct original-to-new
diffs. No alternate runner or graphics device is introduced.

The actual final-image base remains d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a /
ES3178 with explicit overlays: ES16dbac5211eea7e70db7394372033be2be7df829 binary
067defd8c760ae9085b1faba1ada643812be494be39e5690a472ab241258ab5d and #594 source
47dda767c7afc47020a3f21ab19a4493bfd5ff8a. The helper is exactly
01473794711dafd9607e1b6894ec482e34820807b81e1c45c352d5da9768c28a. The actual
installed Wii launcher retains packaging substitutions and receives only the
uniquely matched status gate. The same installed runemu/API/ES flow produces the
real250 refusal by failing publication into a directory in the private cloned
Dolphin config. The candidate helper, launcher bytes, original installed hashes,
log timestamps and exact frames remain bound. No synthetic error text is injected.
This is overlay composition evidence; rebuilt-image acceptance remains pending.

Can this be done on the VM? Yes. Both panel sizes and localized refusal/dismissal
need no physical fact. Root records this focused continuation on #594 before
allocation. These frames make no radio, provider or physical handheld claim.

Bound: one fresh no-NIC8GiB/4CPU/16GiB guest,900s whole family plus inherited120s
cleanup, no extension. The same individual100s refusal serial bound and60s
init/cleanup bound apply. Four frames only, reviewed using view_image before the
original review command: dolphin-refusal-en-us, dolphin-return-en-us,
dolphin-refusal-fr-fr, dolphin-return-fr-fr. Finish reserves one manifest slot
(<=4095payload files within unchanged4096 exporter ceiling),128MiB payload and
64MiB host frames. Normal cleanup verifies exact owned binds, restores original
system/ES settings and all installed hashes, then starts normal service. An
aborted guest is failed evidence and cannot claim normal restoration.

Root uses a fresh owner and observed-free VNC number. All commands below are
UNRUN. This runtime allocation follows consumption of the current640 owner; only
source preparation may overlap it.

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01
TASK_PACKET=/tmp/pix-m7-audit-ui-1280-plan-20261015
TASK_OWNER=/workspace/tmp/pix-m7-audit-ui-1280-20261015-01
python3 -I -S -B "$TASK_PACKET/prepare.py" --checkout "$TASK_TREE" \
  --verification /workspace/tmp/pix-m7-image-readback-20261015-01/artifacts \
  --author-owner /workspace/tmp/pix-m7-mkdcdisc-20261014-01 \
  --owner "$TASK_OWNER" --vnc 141
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
# Review original watch/report and exclusive allocation before admission.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

After the actual visual-ready receipt, perform these serialized actions:

```bash
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" init
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" cleanup
```

Review each exact PNG, then use unchanged
`host-action.py --owner "$TASK_OWNER" review --label LABEL --review TEXT`.
`host-audit.py --owner "$TASK_OWNER" finish` requires all four reviewed hashes,
restoration and normal pad completion. Await original lifecycle/launcher/watch
completion, then run `close.py --owner "$TASK_OWNER" --run ACTUAL_FROZEN_BUILD_RUN
--packet FRESH_EXPORT`. Root reviews originals, absence and custody, consumes the
exact admission, and alone owns guarded retirement. Original failures are never
rewritten as success. Source-only parsing cannot establish rendering or behavior.

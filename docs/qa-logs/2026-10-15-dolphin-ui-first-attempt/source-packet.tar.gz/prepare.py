#!/usr/bin/env python3
"""UNRUN additive1280 refusal-only derivative; original640 owner stays immutable."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=Path('/tmp/pix-m7-audit-ui-plan-20261015')
BASE_SEAL='61bab02371cd65a6b8bd0b22fa0d8a82fdba93dea54476e29355406b901c6958'
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sealed(p,seal):
 assert sha(p/'SHA256SUMS')==seal
 for line in (p/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert not Path(n).is_absolute() and '..' not in Path(n).parts and sha(p/n)==h,n
p=argparse.ArgumentParser()
for n in ['checkout','verification','author-owner','owner']:p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--vnc',type=int,required=True);a=p.parse_args()
sealed(HERE,sha(HERE/'SHA256SUMS'));sealed(BASE,BASE_SEAL)
argv=[sys.executable,'-I','-S','-B',str(BASE/'prepare.py')]
for n in ['checkout','verification','author-owner','owner']:argv+=['--'+n,str(getattr(a,n.replace('-','_')))]
argv+=['--vnc',str(a.vnc)];subprocess.run(argv,check=True,timeout=120)
# All changes occur in this new unadmitted owner before any runtime is possible.
out=a.owner;target=out/'source/audit-ui'
for n in ['vm-lifecycle.py','close.py','host-audit.py']:shutil.copy2(HERE/n,out/n)
shutil.copy2(HERE/'guest-audit.py',target/'guest-audit.py')
b=json.loads((target/'binding.json').read_text());b.update(panel=[1280,800],refusal_only=True,source_mode='explicit-overlay-on-d4af; refusal rendering1280 only; not new-image installed acceptance')
b['packet_files']={str(f.relative_to(target)):sha(f) for f in sorted(target.rglob('*')) if f.is_file() and f!=target/'binding.json'};save(target/'binding.json',b)
c=json.loads((out/'config.json').read_text());c['code'].update({n:sha(out/n) for n in ['vm-lifecycle.py','close.py','host-audit.py']});c['source']={str(f.relative_to(out/'source')):sha(f) for f in sorted((out/'source').rglob('*')) if f.is_file()}
c['audit_ui'].update(packet_seal=sha(HERE/'SHA256SUMS'),base_packet_seal=BASE_SEAL,binding_sha256=sha(target/'binding.json'),panel=[1280,800],refusal_only=True);c['work_seconds']=900;save(out/'config.json',c)
ret=json.loads((out/'retention-plan.json').read_text());ret['protected']+=[str(HERE)];ret['builds'][0]['name']='m7-dolphin-refusal-ui1280';ret['builds'][0]['basis']='Fresh no-NIC8GiB4CPU1280x800 guest using existing --res flag. Four EN/FR refusal/return frames only; no Wi-Fi controls or gameplay.900s whole family plus120s inherited cleanup. Original installed paths restored, bounded output128MiB/4096files and hostframes64MiB. Candidate overlays explicit; final image acceptance pending.'
ret['builds'][0]['evidence']=[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','vm-lifecycle.py','close.py','source/guest.py','source/audit-ui/guest-audit.py','host-audit.py']];save(out/'retention-plan.json',ret)
adm=json.loads((out/'admission-plan.json').read_text());adm['stage']='m7-dolphin-refusal-ui1280';adm['outputs'][0]['issue']=594;adm['outputs'][0]['release_when']='Four exact1280 EN/FR refusal/return frames plus restored custody and original exits exported/reviewed; exact admission consumed before guarded media retirement.';save(out/'admission-plan.json',adm)
save(out/'records/refusal1280-preparation.json',{'status':'PREPARED_UNRUN','packet_seal':sha(HERE/'SHA256SUMS'),'base_packet_seal':BASE_SEAL,'base_prepare_argv':argv,'scope':'Four EN/FR refusal/return frames at1280x800. No Wi-Fi action exposed or control execution. Inherited source-only control files remain unused provenance.'})
print(json.dumps({'owner':str(out),'status':'PREPARED_UNRUN','work_seconds':900,'cleanup_seconds':120,'panel':[1280,800],'operator':str(out/'host-audit.py')}))

# #565 no-adapter startup log correction — source only, UNRUN

The failed installed clean→588 owner is retained as failed. Its294-check report
has blocked_count1/error_count0: the sole refusal is the log-scrub marker; boot
readiness is clear and the approved shared developer identity is allowed count1.
Original serial SHA256 is281f48cb6476170e733ec4084ed204254bd3ed4979611ce492fc96d05c446247.
The marker reads cloud files1/lines0, ES files0/lines0, both epoch1792015744.

Root authorized a bounded read of its stopped storage partition. Read-only
debugfs found exactly one180-byte regular0644 cloud_sync.log line: the fixed
cloud_device_id INFO diagnostic saying no stored id or adapter exists and
--if-present does not seed machine-id. The persisted log's mtime/ctime/crtime
are22:09:03, one second before the scrub marker. Exact displayed combined
outputs, commands and available original exit information are under `originals/`.
The cat command's original exit is0. The stat call forwarded output only; its
exit was not retained and is explicitly unknown. The tool supplies combined
output; separate stdout/stderr were not recorded and are not reconstructed.
Root subsequently retired the stopped disk. No VM or service was started here.

Causal source chain on canonical next and frozen d6a87f:

- `network-base.service` runs the existing network-base-setup before network
  startup; rocknix-autostart runs after network.target.
- `network-base-setup:57` calls `cloud_device_id --if-present`. With no NIC,
  `cloud_device_id:374` logs the exact fixed diagnostic through its normal
  log_message writer at64–70, then returns without creating an identity.
  Commit9d71a829fead3769574c21530d9bfdc7e39f1cce/#151/D-NET-005 deliberately
  preserves this behavior to prevent boot timing from seeding the wrong identity.
- `102-cloud-saves:29` then invokes cloud_log_scrub before capture/ES startup.
  Its `family():170` increments FILES for every successfully inspected log,
  including one whose redaction changes zero lines. This has been the writer's
  meaning since19bf68c6f91. The scrub script's frozen/next SHA256 is
  5c156d8d43b39172fa71b80a3e47156f46bca0965dcae890ec70f02596f8f126.
- The #565 checker introduced by d0ced7b661 treated any inspected file as
  historical activity. The earlier accepted networked first boot had no such
  no-adapter diagnostic. This is a checker false refusal, not player history,
  credential activity or a new proxy/product defect.

The correction permits only first-boot marker cloud(files1,lines0),
ES(files0,lines0), with the existing ordered current-boot marker epochs, and
only when the exact fixed log is readable, regular and not a symlink. It must
contain exactly one canonical INFO line with a valid calendar timestamp and
no extra content. No rotated or partial cloud log sibling may exist. The
existing stable bounded read also returns its mtime: that epoch must be within
this boot and no later than the scrub's whole second. The log text has no
UTC-offset suffix; the checker does not borrow the host timezone to date an
offline root. It validates calendar syntax and uses file epoch metadata.
As before, timestamps establish consistency, not historical origin.

The exact recognized case reports `startup-no-adapter-log-scrub`, clear/count0.
Zero-file startup records keep their existing `startup-log-scrub` category.
Nonzero changed lines, ES files, multiple cloud files, other/extra log content,
rotations, stale/future metadata, malformed/unreadable/symlink inputs still
refuse. Every clean-image marker preseed still refuses. Retained-upgrade parsing
and permissive historical-marker behavior are unchanged. No product writer,
boot sequence, configuration or image needs modification.

`correction.patch` changes only the two tools. Complete paired candidate paths:

```text
/tmp/pix565-noadapter-scrub-correction-20261014/candidate/tools/pixelelated-state-check
/tmp/pix565-noadapter-scrub-correction-20261014/candidate/tools/pixelelated-state-check-test
```

Both original tools are retained in `originals/`; the source manifest records
old/new SHA256. Sixteen additive controls use the existing synthetic-root
harness. The old controls remain, including broad files-present refusal,
redactions, marker malformation, boot bounds, no value disclosure, unchanged
bytes/modes, clean-image preseed refusal and retained history. Added controls
cover the exact benign diagnostic, boot boundary, stale/post-scrub log mtime,
stale marker, cloud redaction, ES history, other/extra log data, rotation,
symlink, mode000, invalid calendar date, multiple files, clean-image and retained
behavior. AST parsing is the only code validation performed in this lane.

Can this be done on the VM? Yes: the actual clean no-NIC image already exposed
the branch. Root records and allocates the existing bounded host control owner,
then a fresh unchanged default-boot VM for actual clean→588 continuation. The
source-only tools can be tested under root's existing host-helper allocation:

```bash
python3 -I -B /tmp/pix565-noadapter-scrub-correction-20261014/candidate/tools/pixelelated-state-check-test --self-test
```

Retain actual stdout/stderr/wait status under that owner. Do not run unadmitted
or claim the proposed tests passed. After qualification, root content-applies
the patch to the coordinator tools, not the frozen d6a checkout. Use separate
installed588 lifecycle derivative `/tmp/pix588-installed-lifecycle-clean02-20261014`
with `--clean-checkout /workspace/repos/rocknix.worktrees/m7-player-setup`.
It binds helper/checker/test/serial bytes and invokes the original unchanged
helper from that explicit root. It preserves the original outer seal and the
failed first owner. Its own README identifies the same later UI caller needing
this binding; no UI fixture is changed here.

Already written: the legitimate product marker and log remain untouched; the
checker reads both existing zero-file startup records and this exact benign
one-file record. Retained histories keep their established policy. No migration
or rewrite is needed. Source archaeology used `tools/archaeology --no-gh --since
2026-10-13 'log.scrub|565'`, original commits and guards. These selected-state
and cloud identity tools are fork-only: neither path exists in the local
upstream/next tree; this correction targets pixelelated's checker. No live
upstream issue search or external posting occurred.

#!/bin/sh
set -eu
mkdir /tmp/pix-output/service
python3 -I -S -B -c 'from pathlib import Path; import hashlib,json; p=Path("/usr/lib/libraproxy_rchash.so"); assert not any(x.split()[4]==str(p) for x in Path("/proc/self/mountinfo").read_text().splitlines()); Path("/tmp/pix-output/service/native-before.json").write_text(json.dumps({"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size})+"\n")'
mount --bind /tmp/pix-input/native/libraproxy_rchash.so /usr/lib/libraproxy_rchash.so
mount --make-private /usr/lib/libraproxy_rchash.so
python3 -I -S -B -c 'from pathlib import Path; import hashlib,json; p=Path("/usr/lib/libraproxy_rchash.so"); proof=json.loads(Path("/tmp/pix-input/service-packet/native-provenance.json").read_text()); assert hashlib.sha256(p.read_bytes()).hexdigest()==proof["elf"]["sha256"]; assert p.stat().st_size==proof["elf"]["bytes"]; Path("/tmp/pix-output/service/native-overlay-mountinfo.txt").write_text(Path("/proc/self/mountinfo").read_text())'
/lib64/ld-linux-x86-64.so.2 --list /usr/lib/libraproxy_rchash.so > /tmp/pix-output/service/native-loader-list.txt 2>&1
mkdir /run/pix583-service-packet /run/pix583-service-inputs /run/pix583-service-owner
mkdir /run/pix583-service-inputs/prepared
mount --bind /tmp/pix-input/service-packet /run/pix583-service-packet
mount -o remount,bind,ro /run/pix583-service-packet
mount --bind /tmp/pix-input/service-prepared /run/pix583-service-inputs/prepared
mount -o remount,bind,ro /run/pix583-service-inputs/prepared
mount -t tmpfs -o size=64M,mode=700,nosuid,nodev,noexec tmpfs /run/pix583-service-owner
for unit in pix583-service-proof-owner.service pix583-service-proof.service; do
  set +e
  systemctl show "$unit" --property=LoadState --value > /tmp/pix-output/service/initial-"$unit".txt
  check_rc=$?
  set -e
  test "$check_rc" -eq 0 || test "$check_rc" -eq 1 || test "$check_rc" -eq 4
  test "$(cat /tmp/pix-output/service/initial-"$unit".txt)" = not-found
done
stat -c '%a %n' /run/pix583-service-packet/raofflineproxy-ctl > /tmp/pix-output/service/controller-mode.txt
test "$(stat -c '%a' /run/pix583-service-packet/raofflineproxy-ctl)" = 755
test -x /run/pix583-service-packet/raofflineproxy-ctl
set +e
timeout --signal=TERM --kill-after=10s 310s systemd-run --wait --unit=pix583-service-proof-owner --property=RuntimeMaxSec=280s --property=TimeoutStopSec=20s --property=KillMode=control-group --property=MemoryMax=1G --property=TasksMax=128 /usr/bin/python3 -I -S -B /run/pix583-service-packet/owner.py --output /run/pix583-service-owner/run588 > /tmp/pix-output/service/stdout 2> /tmp/pix-output/service/stderr
pxrc=$?
printf '%s\n' "$pxrc" > /tmp/pix-output/service/original.rc
cleanup=0
for unit in pix583-service-proof-owner.service pix583-service-proof.service; do
  systemctl show "$unit" --property=LoadState,ActiveState,SubState,MainPID,ControlGroup,Result,ExecMainCode,ExecMainStatus,InvocationID > /tmp/pix-output/service/final-"$unit".txt
  if ! grep -qx 'MainPID=0' /tmp/pix-output/service/final-"$unit".txt; then
    cleanup=1
    timeout --signal=TERM --kill-after=5s 25s systemctl stop "$unit" > /tmp/pix-output/service/stop-"$unit".txt 2>&1
  fi
  journalctl --no-pager -u "$unit" -n 250 -o json > /tmp/pix-output/service/journal-"$unit".jsonl 2>&1
done
printf '%s\n' "$cleanup" > /tmp/pix-output/service/cleanup-intervention.rc
set -e
tar -czf /tmp/pix-output/service/fixture-records.tar.gz -C /run/pix583-service-owner .
sync
umount /run/pix583-service-owner
umount /run/pix583-service-inputs/prepared
umount /run/pix583-service-packet
umount /usr/lib/libraproxy_rchash.so
python3 -I -S -B -c 'from pathlib import Path; import hashlib,json; b=json.loads(Path("/tmp/pix-output/service/native-before.json").read_text()); p=Path("/usr/lib/libraproxy_rchash.so"); assert hashlib.sha256(p.read_bytes()).hexdigest()==b["sha256"]; Path("/tmp/pix-output/service/native-restored.json").write_text(json.dumps(b)+"\n")'
printf 'PIX583_SERVICE_RC:%s CLEANUP:%s\n' "$pxrc" "$cleanup"
test "$pxrc" -eq 0
test "$cleanup" -eq 0

mkdir /run/pix588-components
mount -t tmpfs -o size=64M,mode=700,nosuid,nodev,noexec tmpfs /run/pix588-components
mkdir /tmp/pix-output/components
set +e
PIX588_ALLOCATED_VM=yes timeout --signal=TERM --kill-after=5s 245s python3 -I -B /tmp/pix-input/component-packet/component-fixture.py --source /tmp/pix-input/component-baseline --variant baseline --cases startup-window --output /run/pix588-components/baseline > /tmp/pix-output/components/baseline.stdout 2> /tmp/pix-output/components/baseline.stderr
brc=$?
printf '%s\n' "$brc" > /tmp/pix-output/components/baseline.rc
PIX588_ALLOCATED_VM=yes timeout --signal=TERM --kill-after=5s 245s python3 -I -B /tmp/pix-input/component-packet/component-fixture.py --source /tmp/pix-input/service-prepared --variant candidate --cases all --output /run/pix588-components/candidate > /tmp/pix-output/components/candidate.stdout 2> /tmp/pix-output/components/candidate.stderr
crc=$?
printf '%s\n' "$crc" > /tmp/pix-output/components/candidate.rc
python3 -I -B /tmp/pix-input/component-packet/check-results.py --kind component --baseline-result /run/pix588-components/baseline/result.json --baseline-rc /tmp/pix-output/components/baseline.rc --candidate-result /run/pix588-components/candidate/result.json --candidate-rc /tmp/pix-output/components/candidate.rc > /tmp/pix-output/components/check.stdout 2> /tmp/pix-output/components/check.stderr
checkrc=$?
printf '%s\n' "$checkrc" > /tmp/pix-output/components/check.rc
set -e
tar -czf /tmp/pix-output/components/fixture-records.tar.gz -C /run/pix588-components .
sync
umount /run/pix588-components
printf 'PIX588_COMPONENT_BASELINE_RC:%s CANDIDATE_RC:%s CHECK_RC:%s\n' "$brc" "$crc" "$checkrc"
test "$brc" -eq 1
test "$crc" -eq 0
test "$checkrc" -eq 0

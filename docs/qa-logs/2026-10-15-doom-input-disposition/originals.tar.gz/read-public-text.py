#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,sys,urllib.request,urllib.parse,urllib.error
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'public-text'; OUT.mkdir(exist_ok=True)
LEDGER=ROOT/'public-text-reads.json'
rows=json.loads(LEDGER.read_text()) if LEDGER.exists() else []
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args): return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
for url in sys.argv[1:]:
 assert len(rows)<16
 parsed=urllib.parse.urlsplit(url)
 assert parsed.scheme=='https' and parsed.hostname in {'api.github.com','raw.githubusercontent.com'} and not parsed.username and not parsed.password and not parsed.query
 remaining=1572864-sum(r.get('bytes',0) for r in rows)
 assert remaining>0
 cap=min(524288,remaining)
 row={'number':len(rows)+1,'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'max_bytes':cap,'timeout_seconds':15,'redirects_allowed':False}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'pixelelated-source-evidence','Accept':'application/vnd.github+json' if parsed.hostname=='api.github.com' else 'text/plain','Accept-Encoding':'identity'})
  with opener.open(req,timeout=15) as response:
   data=response.read(cap+1); assert len(data)<=cap
   row.update(status=response.status,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
   target=OUT/f'{len(rows)+1:02d}.txt'; target.write_bytes(data); row['file']=str(target.relative_to(ROOT))
 except Exception as e: row.update(error=type(e).__name__+': '+str(e))
 rows.append(row); LEDGER.write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row))

import decimal,gzip,hashlib,io,json,pathlib,stat,tarfile
P=pathlib.Path(__file__).resolve().parent
C=P/'custody';assert not C.exists();C.mkdir()
files=sorted(p for p in P.rglob('*') if p.is_file() and 'custody' not in p.relative_to(P).parts and p.name not in {'SHA256SUMS','MEMBER-MANIFEST.json'})
def item(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes()
 return {'name':str(p.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns}
rows=[item(p) for p in files]
(P/'MEMBER-MANIFEST.json').write_text(json.dumps({'payload_files':len(rows),'payload_bytes':sum(r['bytes'] for r in rows),'files':rows,'identity_scope':'Regular-file bytes, permissions, numeric owners and exact nanosecond mtime; no directory or atime stability claim'},indent=2)+'\n')
files.append(P/'MEMBER-MANIFEST.json');files.sort()
(P/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(P))+'\n' for p in files))
files.append(P/'SHA256SUMS');files.sort();archrows=[item(p) for p in files]
archive=C/'originals.tar.gz'
with archive.open('xb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for p,r in zip(files,archrows):
    b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
    ti=tarfile.TarInfo(r['name']);ti.size=r['bytes'];ti.mode=r['mode'];ti.uid=r['uid'];ti.gid=r['gid'];ti.mtime=r['mtime_ns']//1000000000
    ti.pax_headers={'mtime':str(decimal.Decimal(r['mtime_ns'])/decimal.Decimal(1000000000))}
    tf.addfile(ti,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert [m.name for m in members]==[r['name'] for r in archrows]
 for m,r,p in zip(members,archrows,files):
  b=tf.extractfile(m).read();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];assert m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'];assert int(decimal.Decimal(m.pax_headers['mtime'])*1000000000)==r['mtime_ns'];assert item(p)==r
(C/'originals-manifest.json').write_text(json.dumps({'source':str(P),'files':archrows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_members':len(archrows),'uncompressed_member_bytes':sum(r['bytes'] for r in archrows),'verification':'Exact member set/order, bytes, stat.S_IMODE permissions, uid/gid and decimal PAX ns mtime checked against unchanged source files'},indent=2)+'\n')
(C/'original-packet-SHA256SUMS').write_bytes((P/'SHA256SUMS').read_bytes())
(C/'README.md').write_text('''# Doom game-data provenance — #528\n\nThis compact packet retains the source/evidence-only Doom disposition and its original public text responses. The exact selected WAD contains affirmative free-distribution permission; its Git-blob identity matches the preserved Doom 1.9 shareware distribution. Engine/launcher GPL scope remains separate. The referenced vendor document was absent in both the packaged archive and the associated historical mirror; disk-vending or charged-bundle terms remain an explicit document question. No legal/publication clearance is asserted.\n\nRead `README.md` and `disposition.json` inside `originals.tar.gz`. The original held 1,689,157-byte Doom archive and 4,196,020-byte WAD are not duplicated here. Only the selected 4,000-byte ENDOOM notice lump, decoded text, passive member/index observations, exact recipe/scripts and bounded textual references are retained. Accepted final H700/SM inventory rows are referenced as original prior results, with their selected rows retained. No new runtime, compilation, VM, target execution or artifact acquisition occurred.\n\n`original-packet-SHA256SUMS` is the private packet's exact original seal; `originals-manifest.json` records each archived file's original SHA256, byte size, permission mode, uid/gid and exact nanosecond mtime. PAX decimal metadata avoids float truncation. Archive verification compared every member and source file; no directory or atime stability is claimed. Root owns final review, shared records and integration.\n''')
(C/'custody-result.json').write_text(json.dumps({'source_seal_sha256':hashlib.sha256((P/'SHA256SUMS').read_bytes()).hexdigest(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'archive_members':len(archrows),'payload_files':len(rows),'payload_bytes':sum(r['bytes'] for r in rows),'exact_members_bytes_modes_uid_gid_nsmtime_verified':True,'firmware_or_wad_archive_duplicated':False,'runtime_test_or_target_executed':False},indent=2)+'\n')
(C/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(C.iterdir()) if p.is_file()))
print((C/'custody-result.json').read_text());print('outer_seal',hashlib.sha256((C/'SHA256SUMS').read_bytes()).hexdigest())

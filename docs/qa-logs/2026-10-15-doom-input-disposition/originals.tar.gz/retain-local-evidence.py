import hashlib,json,pathlib,shutil,stat,struct,subprocess,tarfile
P=pathlib.Path(__file__).resolve().parent
R=pathlib.Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
E=P/'retained';E.mkdir(exist_ok=True)
rows=[]
def retain(src,dest):
 src=pathlib.Path(src);b=src.read_bytes();s=src.stat();out=E/dest;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 rows.append({'path':str(src),'retained':str(out.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns})
for name in ['README.md','doom-fetch.json','doom-commits.json']:
 retain(R/'docs/qa-logs/2026-10-11-component-inputs'/name,'oct11/'+name)
for name in ['README.md','evidence-index.json']:
 src=pathlib.Path('/tmp/pix-m7-remaining-notice-disposition-20261015')/name
 if src.exists():retain(src,'prior-disposition/'+name)
for profile in ['h700-aarch64','sm8550-aarch64']:
 src=pathlib.Path('/workspace/tmp/pix-m7-final-inventory-20261015-01/profiles')/profile/'publication-worklist.json'
 retain(src,profile+'-publication-worklist.json')
 data=json.loads(src.read_text()); selected=[r for r in data['components'] if r['component']=='idtech-lr'];assert len(selected)==1
 (P/(profile+'-doom-row.json')).write_text(json.dumps({'source_path':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'selected_row':selected[0]},indent=2)+'\n')
for suffix in ['package.mk','scripts/generate-idtech.sh','sources/idtech_dirs']:
 rel='projects/ROCKNIX/packages/emulators/libretro/idtech-lr/'+suffix
 b=subprocess.check_output(['git','-C',str(R),'show','f8636de1d105275dbf9420bbabbbc26f79abb10f:'+rel]);out=E/'f863'/suffix;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 rows.append({'git_commit':'f8636de1d105275dbf9420bbabbbc26f79abb10f','git_path':rel,'retained':str(out.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
a=json.loads((P/'archive-readback.json').read_text());archive=pathlib.Path(a['archive']['path']);s=archive.stat()
assert hashlib.sha256(archive.read_bytes()).hexdigest()==a['archive']['sha256']
with tarfile.open(archive,'r:gz') as tf:b=tf.extractfile('doom.wad').read()
assert hashlib.sha256(b).hexdigest()==a['members'][0]['sha256']
magic,n,offset=struct.unpack_from('<4sII',b);lumps=[struct.unpack_from('<II8s',b,offset+i*16) for i in range(n)];e=[(o,z) for o,z,name in lumps if name.rstrip(b'\0')==b'ENDOOM'];assert len(e)==1
o,z=e[0];raw=b[o:o+z];assert len(raw)==4000;(P/'wad-ENDOOM.bin').write_bytes(raw)
blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();tree=json.loads((P/'public-text/03.txt').read_text());entry=[r for r in tree['tree'] if r['path']=='doom1.wad'][0];assert entry['sha']==blob and entry['size']==len(b)
s2=archive.stat();assert (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns)==(s2.st_dev,s2.st_ino,s2.st_mode,s2.st_uid,s2.st_gid,s2.st_size,s2.st_mtime_ns)
(P/'wad-version-association.json').write_text(json.dumps({'local_wad_sha256':hashlib.sha256(b).hexdigest(),'local_git_blob_sha1':blob,'local_bytes':len(b),'preservation_tree_sha1':tree['sha'],'preservation_entry':entry,'matching_git_blob_and_size':True,'source_kind':'Third-party preservation mirror of id Software-authored distribution; no claim of authenticated original id Software delivery','original_endoom_raw_sha256':hashlib.sha256(raw).hexdigest(),'archive_unchanged_selected_identity':True},indent=2)+'\n')
(P/'local-evidence-index.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'retained_files':len(rows),'wad_association':True,'raw_endoom_bytes':len(raw),'retained_local_bytes':sum(x['bytes'] for x in rows)}))

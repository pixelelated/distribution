Completed the scoped preservation criteria with the original evidence linked in the reconciled body. Source is included in final f8636de1; later SM source9aa7 changes only the ABL checksum product path. Historical failures, expected negative installer statuses and the stated native/physical/publication limits remain unchanged.

Ordinary saves, native states and frontend manager eligibility retain their separate source/evidence scopes.

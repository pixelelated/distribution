## Completed scoped bootstrap-preservation qualification — 2026-10-15

The original partial-extraction failure and misleading deliberate retry remain preserved. Repaired exact-source full-caller controls now cover fresh, retained, allowed-alias, incomplete/ambiguous, failure/interruption and retry paths. The targeted nine cases plus the remaining14 continuation retain expected original exits, manifests and cleanup. The real55-member public archive CRC/layout/ELF inspection is separately preserved; its bytes were not executed. Independent audit grades the five criteria PASS within this declared scope.

Already written: older installers may have left partial steamrtarm64 and sibling files. Unknown or ambiguous contents are retained and refused before mutation; a directory alone is not installation evidence. Supported valid/self-updated client structure, selected channel, aliases, custom files and unrelated SDK/runtime/FEX/Proton/library/game/save entries remain protected. No whole-Steam-root replacement or deletion is introduced.

The VM uses installed interpreter/tools with synthetic profile/transport/payload boundaries and explicit native-client exec denial. GENERIC_X64 does not ship this ARM/FEX module. Actual selected SM8550 artifact identity remains #555/#563; portable packaged-script behavior remains the explicit #564/#579/#580 continuation. Native ARM64 execution, real Steam self-update/consumer quiescence and abrupt-power durability are unproved; synthetic SIGKILL and synthetic committed-update tests are not those claims. A successful wrapper never rewrites expected negative installer exits, unknown census state or historical failed attempts. No RC or publication approval follows.

Evidence: [old-source reproduction](https://github.com/pixelelated/distribution/blob/a57b0014917127c851d299b628f4f01e7043d8ce/docs/qa-logs/2026-10-14-offline-components/README.md), [targeted full-caller originals](https://github.com/pixelelated/distribution/blob/a57b0014917127c851d299b628f4f01e7043d8ce/docs/qa-logs/2026-10-14-steam-client-first-caller/README.md), [remaining14 and metadata originals](https://github.com/pixelelated/distribution/blob/a57b0014917127c851d299b628f4f01e7043d8ce/docs/qa-logs/2026-10-15-steam-remaining-result/README.md), [independent audit and explicit limits](https://github.com/pixelelated/distribution/blob/a57b0014917127c851d299b628f4f01e7043d8ce/docs/audits/2026_10_14-milestone-m7-next-candidate/04-analysis.md). Admission9351cef4 is consumed qualified; original pre-boot/fixture/acquisition failures remain failures.

## Historical intake and acceptance contract

Owner request:

> Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate.

During #563/#564/#579/#580 qualification, source review found that `install_steam_client_arm64` accepts any existing `CLIENT_DIR`, and extracts a new ZIP directly into retained Steam. A failed extraction can leave a directory that the next attempt reports as already installed. Manifest/download calls also lack an explicit installer-owned total deadline. This is source-confirmed; the prepared real BusyBox CRC-failure/retry reproduction has not run yet.

The client function is byte-identical in accepted bc9dfe8141, ROCKNIX 20261001 c445081a59, repaired composition c6240ed398, and current upstream next becc8cb2a9 (checked October 14 UTC). Bounded current upstream PR/issue searches found no matching repair. This is separate from the earlier runtime/FEX/Proton transactions and their completed tests.

Local immutable packet: commit317bf582d489c24ed2e5f80b9297e6f25f408bc1, `docs/qa-logs/2026-10-14-steam-client-retry-source/`. It contains exact source/history, upstream read receipts, proposed repair boundaries and two unrun disposable fixtures. Product installer remains unchanged at this point.

Can this be done on the VM? Yes. Use synthetic archives and recording transport within an isolated disposable GENERIC_X64 guest, actual installed decoder, and saved original function/decoder exits. No native client, device, personal library or provider account is needed for the initial reproduction. Real public archive format and installed tool dependencies require separate bounded intake before choosing activation and resource limits.

Already written: older installers may have left a partial `steamrtarm64` directory and files elsewhere under Steam after failed extraction. Preserve unknown or ambiguous existing contents and report a nonmutating refusal; do not treat a directory as complete or recursively erase it. Valid existing clients and their self-update state must stay intact.

Acceptance criteria:

- [x] Preserve old-source failed decoder/function exits, before/after manifests and the one deliberate retry showing incomplete state skipped as installed; separately prove valid existing-client preservation.
- [x] Missing/incomplete state cannot report installed. Exact-source controls preserve valid client/channel/aliases/custom files and refuse ambiguous existing layouts before writes.
- [x] Failure/interruption controls for acquisition, extraction, validation, activation and metadata preserve existing client/SDK and unrelated runtime/FEX/Proton/library/game/save entries. Fresh failure leaves no misleading installed state.
- [x] Establish real archive layout and owned paths; verify finite transport/decompression/space limits, owned staging cleanup and deterministic retry. Never replace or delete the whole Steam root.
- [x] Review repaired full-caller fresh, retained and allowed-alias VM receipts against exact source; record installed-image, native ARM64/self-update/quiescence and power-loss limits explicitly before closure.

Parent foundation #563. Execute alongside the remaining #564/#579/#580 caller qualification, before accepting the 20261001 foundation and assembling the next candidate. No RC or publication approval is implied.

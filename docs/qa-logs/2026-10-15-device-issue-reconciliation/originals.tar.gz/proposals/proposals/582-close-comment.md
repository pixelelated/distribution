Completed the scoped preservation criteria with the original evidence linked in the reconciled body. Source is included in final f8636de1; later SM source9aa7 changes only the ABL checksum product path. Historical failures, expected negative installer statuses and the stated native/physical/publication limits remain unchanged.

This closes bootstrap transaction/preservation behavior and its expressly recorded limits; it does not claim installed/native ARM Steam readiness or waive #564/#579/#580.

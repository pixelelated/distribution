# Six M7 issue reconciliation — source/record review only

Live bodies and all comments were read on 2026-10-15. `fetch-observation.json`
retains each actual read argv/UTC/exit/hash; `evidence-index.json` binds 54 selected
closed originals/source files and each issue's before-body SHA/updated_at. No
active SM output, build cache, firmware payload or provider was read. No runtime,
fixture, tracker operation or shared-file edit occurred.

**Ready for root's scoped closure review:** #581 and #582. Exact body and closing
comment proposals are under `proposals/`; #581 also has a narrow stale canonical
flow-text correction. **Still open:** #564/#579/#580 need the packaged-script
behavior bridge described below, after actual SM acceptance. #563 additionally
needs existing source/licence and physical-fact work. No anticipated SM success
is recorded, and none of these conclusions designates an RC.

The audit's `effective-scorecard.json` is a frozen historical score. Its PARTIAL,
FAIL and SKIP rows are not rewritten. Final reconciliation reports six resolved
findings and audit completion on f863/ES16dbac; that does not erase the explicit
pre-existing native ARM, provider, publication or physical exclusions.

## Exact acceptance-criterion map

Numbers below are the ordinal checkboxes in each captured live body. Evidence
IDs resolve to original absolute paths, current read hashes and exact copies in
`evidence-index.json`. A PASS here is limited to the stated observation.

| Issue / criterion | Current disposition and original evidence |
| --- | --- |
| #564.1 | Complete: `intake-control` records predecessor preserves/runtime-removal source loses synthetic old runtime on original download failure. Historical source/function hashes and original1 remain. |
| #564.2 | Complete within VM synthetic preservation contract: `steam-components.suites[component=runtime]`, 39 cases, suite0; download/decode/validation/rename/link/cleanup failures, success and first install; original per-case negatives retained. Parent combined result remains FAIL because its separate FEX fixture failed. |
| #564.3 | Complete within same contract: runtime kill/TERM/recovery/space/mount/lock cases plus `steam-caller` nine-step original0 and 12 protected roots. No abrupt-power or actual ARM execution inference. |
| #564.4 | **Open installed-artifact-to-VM behavior seam.** `steam595-readback` supplies actual installed-interpreter old1/corrected0 full synthetic runtime transaction; final module is not packaged by GENERIC. Actual accepted SM module identity plus one artifact-derived full caller can bridge packaged portable script to VM behavior. SM equality alone cannot tick it. No new player-copy change is selected by the remaining bridge. |
| #579.1 | Complete: `fex-corrected` preserves baseline-download/extract/overlay original1 and inventories; corrected FEX43 plus 39 guard controls pass. `steam-components` retains the initial unrelated fixture failure. |
| #579.2 | Complete within VM synthetic contract: FEX fetch/extract/overlay/activation errors, kill phases, held-state refusal and retries in `fex-corrected`; exact Python helper unchanged in f863/9aa7. |
| #579.3 | Complete within that contract: low-space/ENOSPC/time/guardian/owned cleanup, OtherRoot and game/save preservation, deliberate refresh in `fex-corrected` and `steam-caller`. This is not proof of native current FEXRootFSFetcher execution. |
| #579.4 | **Open same packaged portable-script VM seam.** Await actual SM `fex-package.json` and independent `fex-installed.json` for selected package architecture/identity, plus the single full caller for portable behavior. These do not establish actual ARM fetcher/overlay/native usability. |
| #580.1 | Complete: `steam-components.suites[component=proton]`, 56 controls, suite0, original failure and incomplete-existing cases/inventories. |
| #580.2 | Complete within VM synthetic contract: staged validation/activation/retirement and interruption/retry controls in the same Proton56 row; `steam-caller` completes both families with unrelated data unchanged. |
| #580.3 | Complete with later correction: original Proton bounds/space/family controls plus `steam14-export.metadata` actual installed curl63 oversized and curl28 after30.005878925s stalled, exact four requests, old_families_equal=true, no remaining listener/group. This resolves the historical audit AC-083 failure without changing the old FAIL score. |
| #580.4 | **Open same packaged portable-script VM seam.** Current source has accepted bounded metadata and isolated runtime invocation; one actual SM-module full caller is the minimal remaining integration observation. No native Wine/Proton/FEX/client claim. |
| #581.1 | Complete: `dolphin-old` has eight original launcher-fragment0/preservation-assertion1 controls, with both source hashes and lost/replaced synthetic paths; originals are never reclassified. |
| #581.2 | Complete: `dolphin-controls` 104 helper cases plus launcher/error controls, `dolphin-mounts` actual mount/rename/link behavior and six card writes. Real retained directories/cards are conservatively refused with250 and preserved; the fix does not infer ownership or automatically migrate ambiguous contents. |
| #581.3 | Complete: same case inventory covers fresh/current/relative/dangling/unexpected links, conflicts, unavailable/read-only/mounted roots, interruption, no follow-through mutation or engine marker after refusal. Prior complete callers and `dolphin-frame1280`/`dolphin-frame640` bind action/return and exact presentation. |
| #581.4 | Complete in selected installed/upgrade scope: `vm-reader.products` binds actual final helper and both packaged launchers (including recipe substitutions); `final-clean` and `final-retained` preserve their independent original0 channels and actual f863/16dbac source. `native-ordinary`/consumption bind d4af ordinary Wii/DC cold-save persistence; `native-state-review`, `native-state-consumption` and `audit-native` bind f863 four-launch manual/native-auto proof. Frontend capability/manager eligibility remains the separately accepted #575 scope. Do not describe whole arbitrary /storage preservation, native child wait0, account login, awards or hardware boot. Canonical #581 paragraph still says final/native unqualified; proposed documentary correction removes that stale present-tense claim without relabeling the historical frames. |
| #582.1 | Complete: `client-old-failure` retains decoder/function1 then deliberate retry0 skipping partial state; `client-valid-old` preserves valid existing client. |
| #582.2 | Complete: accepted targeted fresh/alias/existing callers and `steam14-exits`/`steam14-export` show five successes, four refusing partial/conflicting cases and five failure1→retry0 cases. Valid client/channel/custom/profile and aliases remain; early unsafe cases refuse before writes. |
| #582.3 | Complete within declared synthetic scope: `client-attempt05-detached-child`, `client-attempt06b-census-error`, `client-attempt07-transport-timeout`, `client-attempt08-interrupt-published`, `client-attempt09-committed-self-update`, `client-attempt11-crc-events` and remaining14 preserve exact original negatives/journals/manifests and unrelated roots. Census uncertainty is held; its independent fixture actor release is not product quiescence. |
| #582.4 | Complete: `client-public-layout` checks real55-member/339635561-byte archive CRC/layout/ELF structures without executing/installing payload; original bounded transport,180s timeout, staging/space/CRC/cleanup/retry receipts above retain all limits. No whole-Steam-root replacement/deletion. |
| #582.5 | Complete as written: full callers and reviewed originals cover fresh/retained/allowed alias; `steam14-consumed` is qualified9351. Explicit installed-image/native ARM64/self-update/quiescence/power-loss limitations are retained in current closure proposal. This checkbox requires recording those limits, not pretending native execution occurred. SM installed artifact identity remains #555/#563 and the separate #564/#579/#580 seam. |
| #563.1 | Complete as already checked: D-WORKFLOW-161, exact c445081a59518f37d9776e5412dd7b14910696f7, source-intake/canonical current references; dated old-base claims stay historical. |
| #563.2 | Complete as already checked: `intake-checks`/`intake-pkgchecks`, exact f370dc merge/one resolved DuckStation path, preserved newer fork pins; later f863/9aa7 source continuity is explicit. |
| #563.3 | **Open**: actual final five-profile inventory/source-custody run is UNRUN, with SM seven dynamic references unresolved. `custody-hold` preserves corrected collector preparation only. ABL LinuxLoader e9d37131 implementation/source-notice coverage and FEX-generated/vendor/static components remain the named #528/#601 holds. Neither5-file ABL equality nor14 FEX ELFs is source/licence completion. |
| #563.4 | Operational mechanism supported: actual accepted H700 independent receipt `h700-acceptance` and prior monitored/consumed GENERIC records establish current retention/admission usage. Preserve producer failures (#597 null launcher, H700 combined1) separately from subsequent qualified readers. Root must append actual new SM copy/build/readback/acceptance original channels and resource records after completion; no all-success prediction. |
| #563.5 | Current selected image/audit requirements supported by `vm-reader`, `final-clean`, `final-retained`, `native-state-review`, `audit-final`, `audit-reconciliation`; earlier unchanged protocols/scripts/restores carry only their explicit `final-carry-plan` scope. No new broad matrix is proposed. The live body is not changed here: full foundation closure remains blocked by .3/.6 and Steam seam, regardless of the completed scoped audit. |
| #563.6 | **Open**: accepted H700 DDR3/DDR4 artifacts e8107b4b/bundle32f7a652; actual new SM acceptance is still required as below. Physical boot/kernel/ABL/board DP-audio facts cannot follow from host readers. `device-facts` latest relevant H700/Nova deployment rows remain bc9dfe8141; new 7.2 common DP patch and ABL1.2 are not a proven #558 fix. Existing #528/#344 publication holds remain. No new physical test request is invented. |

## Already written traces

- #564 body already records accepted bc9 predecessor and isolated destructive intake.
  Current consequence: a previously removed runtime cannot be recreated from a
  preservation claim; future transactions preserve valid old bytes and journaled
  recovery. Existing games/saves/library paths remain outside cleanup ownership.
- #579/#580 bodies trace inherited bc9/stable behavior and link caller-disposition.
  Old FEX roots or Proton variants may already be absent/partial; the new helpers
  preserve complete known predecessors, validate requested trees, and hold/refuse
  ambiguous state. No claim that deleted historical bytes were restored.
- #581 original body traces rm-rf StateSaves and surrounding card relinks. Its
  October14 comment6176118872 already records the
  nested Wii profile directory: leave it intact; create only missing defaults at
  the correct location; retain custom profiles. The closure proposal has one
  explicit combined `Already written:` line rather than relying on implication.
- #582 body already states partial steamrtarm64 and files elsewhere may exist;
  preserve unknown/ambiguous state, refuse without mutation, and keep valid
  self-updated clients. Closure repeats that exact behavioral boundary.
- #563 is a foundation adoption task, not a claim to migrate existing device
  state. Previous images/evidence stay bound to their original commits. No
  device update, ABL flash or data migration is authorized by this packet.

## Exact awaited SM acceptance, never inferred

Source packet: `sm-retry-seal` a9eebe1c…, source9aa7, fresh SM05/owner02. Accepted
VM/H700 stay f863. `sm-retry-source-delta` permits exactly the ABL checksum product
change; host tools have their own9aa7 identities. The old SM04 build2 and consumed
failed-investigated d8ae8d16 remain failures.

All paths below start `/workspace/tmp/pix-m7-sm8550-refresh-20261015-02/` and are
**required future originals, not read or asserted to exist in this review**:

1. `artifacts/output-manifest.json`: `result=BUILT_REQUIRES_ARTIFACT_ACCEPTANCE`,
   `distribution_commit=9aa7…`, actual files/hashes and `arm_manifest_sha256`.
   `artifacts/arm-output-manifest.json`: PASS with the new actual ARM handoff.
2. `artifacts/installed-inclusion.json`: PASS, exact ES16dbac, source/installed
   mappings and unchanged packaged required components. `artifacts/fex-package.json`:
   PASS, current source/Nix inputs and14 architecture-tagged ELF entries.
3. `acceptance/artifacts/affected-products.json`: PASS/source9aa7/deviceSM8550,
   comparison=`staged and independently extracted SYSTEM bytes/modes/link chains`.
   Required product key `usr/config/modules/Install Steam.sh` must be124399bytes,
   SHA2561694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b,
   with actual mode/link_chain and exact source_mappings. The same report must
   bind four Dolphin scripts (Vulkan substitutions for launchers), six immutable
   Sys rows, patch018/current MainNoGUI, ABL five expected files/archive64034fb0,
   LinuxLoader revision, shared7.2 kernel stamp, and selected GStreamer direct
   dependency-presence checks. It does not execute any target ELF or loader.
4. `acceptance/artifacts/fex-installed.json`: PASS,14 SYSTEM bytes/architecture
   rows equal package proof, exact `package_proof_sha256`. No FEX native execution.
5. `acceptance/artifacts/payload-equality.json`, `arm-handoff.json`,
   `partition-table.json`, `selected-state.stdout/.stderr/.exit`: raw/update
   SYSTEM/KERNEL equality, bootloader/ARM architecture/handoff, selected-state
   checker65ab pass with original0. No predicted count copied from another profile.
6. `acceptance/artifacts/acceptance.json`: PASS,distribution_commit9aa7,
   actual bundle/bundle_manifest_sha256,architecture,arm_handoff_files,variants,
   scratch_removed=true,source_unchanged=true,independent_bundle_inodes=true,
   host_checker65ab. Verify its original producer/watcher/launcher channels,
   `acceptance/admission-completion-evidence.json` and actual frozen-run
   `admission-consumed.json` match that evidence and are ordinarily qualified.
   No #597 recovery route is relevant to this new owner.

The single portable-script VM follow-up is described in `steam-bridge-plan.md`.
It is not allocated or prepared here. Root will review its small derivative
before runtime. Closure proposals are intentionally absent for the four issues
whose full live criteria are not complete.

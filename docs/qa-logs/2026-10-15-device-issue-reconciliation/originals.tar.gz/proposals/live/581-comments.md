<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6157363356 2026-10-13T23:27:40Z updated 2026-10-13T23:27:40Z -->
The first disposable VM controls are complete against sealed Dolphin candidate b2868df82ed3199e628721ad6fb3f1fb95a3a04a. All 104 helper cases, six actual launcher-guard controls and 13 native-error mapping controls pass. Eight original preparation controls reproduce lost/replaced synthetic files: original fragments exit 0; their preservation assertion remains expected failure 1. These are component controls with injected mounts, not native engine or full-launcher proof. No owner data was used.

Can the next proof be done on the VM? Yes. The coordinator has prepared a separate bounded private mount/network namespace to execute the exact helper with actual mountinfo and rename APIs: clean GC, Wii/GC switching, six synthetic raw-card writes through links, retained real-state refusal, nested mount, read-only mount and unavailable mount. Inputs are newly created synthetic files on a 128 MiB tmpfs. This remains helper/file-I/O proof; it does not establish Dolphin engine compatibility or automatic states. The existing admitted VM owns this serialized experiment; no physical action, provider, game or account is involved.

Exact original results are retained under /workspace/tmp/pix-m7-library-vm-20261013/dolphin-results pending durable compact packet integration. The existing source lane is checking clean defaults and localized error copy separately; these results remain bound to b2868.

<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6158202814 2026-10-14T00:35:40Z updated 2026-10-14T00:35:40Z -->
Three complete staged-caller VM cases now PASS with product90cd5efad765 and fixture06b5b583d075: GameCube retained-state refusal (FR), Wii fresh setup (EN), and Wii memory-card conflict (FR), all1280x800. Actual ESbb9e consumes and renders the refusal, preserves all synthetic managed data, and returns to the selected library entry; fresh setup reaches the recording engine once with correct state/card links. Original ES/unshare/session/frontend exits0;8 reviewed frames in local docs/qa-logs/2026-10-13-library-vm/dolphin-frame-index.json. V2 missing-false and V3 trace-prefix failures retain1. Seven remaining minimum sessions,640frames,packaged/upgrade and native-engine qualification remain due. No owner device/save/cloud data touched. Allocation complete and retired.


<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6159645285 2026-10-14T02:37:52Z updated 2026-10-14T02:37:52Z -->
The remaining French640 GameCube retained-state and Wii card-conflict callers now pass with local display-only helper1a7714fd81 and fixture5a385f12e3. Six original frames reviewed: entry, recovery dialog and return for each. Controlled runemu250,engine0; exact retained synthetic trees unchanged, ES/session/unshare/frontend restore0, no remaining namespace tasks. The long card path now breaks at its final slash and keeps MemoryCardA.USA.raw intact.32selection/5entry/30path source controls also pass. New English640 layout proof remains due; no native-engine/final-image/upgrade qualification implied.

Correction: earlier French entry captures did contain the header, selected game and footer. The black/clock-only assessment was wrong. The original before-launch timeout is still a failure; the new completed run supplies its own proof. Originals and correction are retained in the canonical work/friction logs.

The temporary VM is stopped and retired. Source-bound reviewed frame index and canonical menu map are updated locally under docs/qa-logs/2026-10-14-offline-components/. #574/#583 record the request to consider focused upstream contributions, keeping the distro save-path fix separate from RVZ parsing/hashing.


<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6174800984 2026-10-14T17:55:09Z updated 2026-10-14T17:55:09Z -->
Continuing the one missing updated English 640px long-card-path presentation proof. Can this be done on the VM? Yes: reuse the accepted complete-launcher fixture, helper1a7714fd81, fixture5a385f12e3 and compiled ES bb9e2785 (SHA8752b539…), selecting only a fresh EN640 Wii/card-conflict layout case. Prior French640 and English1280 results are retained and will not be replayed simply to resume. The new allocation must retain original caller/refusal/cleanup statuses and reviewed entry, error and return frames, with the original finite case limits. This remains a synthetic refusal/layout proof, separate from native engine/gameplay and final image qualification. No owner-device or account data is involved.


<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6175148539 2026-10-14T18:13:42Z updated 2026-10-14T18:13:42Z -->
The remaining corrected English640 long-card refusal is now verified with actual ESbb9e (SHA8752b539) and helper1a7714. Three reviewed entry/error/return frames show complete filename, both paths, full recovery copy and normal return. Actual caller/launcher250, helper check1/prepare0/engine0; all assertions true and exact before/after inventory bytes equal. Session/frontend/unshare/ES0, no namespace survivors/forced cleanup; original batch/lifecycle/runner/launcher0. The exact canonical frame index is docs/qa-logs/2026-10-14-dolphin-english640-runtime/frame-index.json, now linked by docs/es-menu-map.md.

Original failed attempts remain: input-media directory modes were not propagated, then the review gate expired during unsupported hostPPM viewing. Fresh03 preserves directory modes and uses preprepared losslessPNG conversion; executable fixture/deadlines unchanged. All three original admissions consumed and VM disks retired. Native engines/gameplay and composed clean/retained image acceptance remain separate; no owner-device activity.


<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6176118872 2026-10-14T19:05:07Z updated 2026-10-14T19:05:07Z -->
Code trace — adjacent Wii controller-profile initialization defect found during final composition review.

The launcher sets CONF_DIR to the dolphin-emu directory, then copies missing WiiControllerProfiles into CONF_DIR/dolphin-emu even though subsequent reads expect CONF_DIR/WiiControllerProfiles. This predates our candidate: it originates in the September 2025 Dolphin update and remains in current ROCKNIX next (50097e80). The minimal local correction copies into CONF_DIR, matching the existing GameCube profile initialization. Existing custom-profile handling is unchanged.

Already written: a partially configured device may have an extra nested directory from the old path. The fix does not delete that directory or overwrite existing custom profiles; it creates missing defaults in the intended location. No owner device is changed now.

Can this be done on the VM? Yes. The next engineering image will exercise missing-profile initialization and existing custom-profile preservation, followed by the actual installed launcher/native checks already owed under this issue. A source-bound fixture is prepared; no new runtime pass or issue closure is claimed. Track the one-line ROCKNIX contribution in #585 after the initial build and qualification.


<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6182280710 2026-10-15T01:28:53Z updated 2026-10-15T01:28:53Z -->
Can this be done on the VM? Yes. The existing native gameplay/save continuation now binds the completed d4af5a255f / ES3178 engineering image (84b1552e4d0ed67d97b603230d1acb0b22a852217054854a9c3fe42731772ff2). Installed Dolphin startup/resource cases have passed and admission7571f590 is consumed.

Next owner `/workspace/tmp/pix-m7-native-gameplay-20261015-01`: one fresh no-NIC8GiB/4CPU guest, one native engine at a time,1800s whole family plus120s cleanup. Existing lawful SuDokuL Wii and Tetris2 Dreamcast fixtures only; normal installed ES/launchers and observed controller input. Root is sole operator. Observe actual first frame, ordinary save/cold reopen, separate manual states and existing global/native-auto distinctions. Original failures retained; no fabricated native exits, scores, auth or physical hardware claim. No device or cloud touched.


<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6182313803 2026-10-15T01:31:19Z updated 2026-10-15T01:31:19Z -->
The first native gameplay allocation stopped during fixture provisioning before any game launch. Its raw-name assertion expected `QA521 Synthetic Xbox 360 Controller` in the production control generator output, but the actual installed SDL-based producer wrote `Xbox 360 Controller` with GUID `030080a15e0400008e02000014010000`. The raw fixture receipt still identifies the QA521 controller. This is a fixture identity assumption, not demonstrated game/save failure.

Original run/launcher/command exit1 is preserved. Exceptional unmount also returned1 because the fixture controller supervisor still held the output mount; exact QEMU and host owners were then stopped and observed absent. Readback preserves recoverable files without claiming a completed guest manifest. Admission99ef54e0 is consumed failed-investigated; no automatic replay. Source-only correction will require positive raw sysfs and normalized SDL identity, and bounded controller teardown before failed-provision unmount. Existing installed Dolphin startup/resource cases remain accepted.


<!-- https://github.com/pixelelated/distribution/issues/581#issuecomment-6182461809 2026-10-15T01:43:49Z updated 2026-10-15T01:43:49Z -->
The original fixture failure remains failed/published, consumed99ef54e0. Source correction now requires exact observed SDL name/GUID plus unique raw sysfs event, VID/PID/version and live owned pad/uinput identity; exceptional cleanup requests the existing bounded abort/destruction before unmount. Root additionally caught missing live profile visibility before allocation and added only bounded allowlisted profile observations to the existing locked status response. No gameplay criteria/timers, pad constructor or input mappings changed. Source sealc9d6faa5bb47950f5c73f947bf03fa925ba2fbdebc8a4d0c5ffb3824ae02379d. Prepared intermediate owner02 remains unrun.

Can this be done on the VM? Yes, as previously scoped. Fresh owner `/workspace/tmp/pix-m7-native-gameplay-20261015-03` uses the same verifiedd4afimage and lawful Wii/DC fixtures, noNIC8GiB4CPU,1800s whole family+120s cleanup. Actual live mappings must be reviewed before input; original first-frame/score bounds still apply. Both final clean and genuine retained update now independently pass; no concurrent VM, physical device or cloud action.

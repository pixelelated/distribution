## Source finding during #575 retained-state review

Owner direction:
> Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate.

Both current Dolphin launchers unconditionally run `rm -rf ${CONF_DIR}/StateSaves` before linking the GameCube or Wii state directory. A retained real directory is therefore removed rather than preserved. The surrounding GC region and memory-card relinking also needs byte/type/conflict controls. This is an inherited source finding; no owner save was read, launched, changed or shown lost in this investigation.

The #575 handoff explicitly flagged this retained-path boundary. `tools/archaeology Dolphin StateSaves` and issue search found #575 but no separate repair. Current official ROCKNIX next, checked October13, still has the StateSaves removal: GC blob a0e1e453f72ecf5fa7ad63876f561fc80eba8c75 and Wii blob 505c6fac398bfac745c50d79f09f14fa36c61d57. Preserve the intended per-system link behavior on normal installations while eliminating destructive handling of retained real data. Do not infer that launcher removal caused the Nova's reported absence of automatic states.

Can this be done on the VM? **Yes.** Disposable directories, symlinks and synthetic save bytes can exercise actual launcher preparation with the emulator replaced by a recording stub. No owner storage, ROM, account or cloud operation is necessary. Actual engine behavior remains separately qualified under #575.

- [ ] Reproduce and preserve the original source's retained-directory failure in an allocated disposable fixture; bind both exact launcher sources and file/type/hash inventories.
- [ ] Repair preparation so retained real save/state data, existing canonical data, conflicting names and unrelated targets survive. Preserve valid current symlinks, including intentional GameCube/Wii state-link switching. Any ambiguous conversion fails without deleting data and gives an actionable outcome.
- [ ] Exercise fresh, retained, existing/dangling/unexpected links, conflicts, unavailable/unwritable destination and interrupted preparation; assertions cover original bytes/types, no follow-through deletion and no emulator launch after a refused preparation.
- [ ] Verify installed script/package identity, clean and retained upgrade paths, and any changed player-facing copy with canonical flow and exact-source frames before promotion. Keep ordinary saves, native states and frontend manager eligibility distinct.

M7.P5 alongside #575, before the next changed candidate's state-preservation acceptance. No device test or automated owner-data migration is authorized by this issue.

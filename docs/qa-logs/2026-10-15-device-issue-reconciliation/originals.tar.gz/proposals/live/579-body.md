Owner direction: "Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate."

Found during #564 / #563 source review. Existing behavior appears in accepted bc9dfe8141 and selected ROCKNIX20261001; it is not newly introduced by the runtime fix. Source evidence: docs/qa-logs/2026-10-13-steam-runtime-followup/caller-disposition.md at c41a16ad804245285914a6f5b3410f36f9abc26a. No installer or owner-device action has run.

Can this be done on the VM? Yes for replacement, failure/recovery and preservation, using synthetic roots/archives and failed transport. Native Steam usability is separate architecture-specific evidence; no account, games or saves are needed for destructive-failure controls.

`ensure_fex_rootfs` removes ArchLinux* before FEXRootFSFetcher succeeds, on the normal installer path before the runtime replacement. A failed fetch can remove the existing support environment. Installed config copying and overlay files also need an explicit preservation boundary.

Acceptance criteria:

- [ ] Exact-source synthetic failing control records original exits and before/after manifests for failed download/extraction or missing required overlay; distinguish source reasoning from executed reproduction.
- [ ] Staged validated replacement preserves the prior complete environment and required files on download, extraction, validation, activation and interruption failure; manifests and retry receipts prove it.
- [ ] Space/time bounds, owned cleanup and recovery are verified without touching Steam games/saves or unrelated FEX roots. Existing intended RootFS refresh remains supported.
- [ ] Candidate-source installed VM proof and review are linked before #563 acceptance; native execution limits are explicit.

Depends on source coordination with #564; same installer file has one writer. This is a separate transaction from the ARM64 Steam runtime, not covered by its component fixtures.
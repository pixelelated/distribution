<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6158946607 2026-10-14T01:38:14Z updated 2026-10-14T01:38:14Z -->
The bounded no-network GENERIC_X64 reproduction now confirms the partial-client retry defect in unchanged installer `c6240ed3984a` (fixture correction `71e66ba00cd8`).

Can this be done on the VM? Yes: synthetic storage and transport, actual installed BusyBox ZIP decoder, private namespaces, no account or native Steam execution.

The first native decode wrote the initial client member and failed on the intentionally corrupted second CRC (original decoder/function exit 1). A single deliberate retry returned original function exit 0 solely because the partial client directory existed. The executable remained absent, no new acquisition occurred, and unrelated existing state was preserved. Outer reproduction exit 0 means **defect reproduced**, not installer repaired. Duration 10.63 s, 413,534 retained bytes, no guard/intervention or remaining descendants.

The separately seeded valid-existing-client control passed: original function exit 0, no acquisition, identical bytes/modes/inodes/link targets and preserved beta choice; 0.50 s, no descendants. These are selected-function observations, not whole-installer retry or real Valve archive qualification.

Original first fixture failure 1 (incorrect local ZIP CRC offset) and two watcher prerequisite refusals 2 remain preserved; none ran the product probe. Current evidence owner `/workspace/tmp/pix-m7-offline-vm-20261014`, `steam-partial02-host` and `steam-existing01-host`; compact durable export follows VM retirement. Real archive layout/hash and safe existing-client classification remain prerequisites for the transactional repair. #582 remains open and precedes the next candidate build.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6159888517 2026-10-14T02:59:26Z updated 2026-10-14T02:59:26Z -->
The public archive is intact. Reviewed recovery source b09fcbb02b ran once under fresh watched ownership at02:56 UTC: new receipt PASS0, full-file SHA child0,110373661 bytes match the expected SHA, no intervention or remaining process group. Launcher/wrapper/build0 and all host owners exited. Original acquisition remains FAIL1 with its exact receipts unchanged; the bug was the optional curl counter name request_size instead of size_request. No re-download, host decoding or execution occurred. Compact evidence: docs/qa-logs/2026-10-14-steam-public-recovery/ (local, not pushed). Actual CRC/layout/ELF proof remains the next admitted offline VM operation before product repair.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6159963800 2026-10-14T03:06:00Z updated 2026-10-14T03:06:00Z -->
Can this be done on the VM? Yes. The next serialized allocation uses a fresh no-NIC GENERIC_X64 guest (standard8GiB/4CPU,640x480),30-minute hard stop, new owner `/workspace/tmp/pix-m7-rvz-vm-20261014`. Revised proxy22cf source probe runs once with its failing baseline controls and512MiB/30CPU/40s bounds. Separately run Steam b09 offline hash/CRC/layout/ELF inspection under768MiB noexec scratch/90s+10s cleanup. MD5 target artifacts are staged read-only but remain held until the exact cleanup-report recovery adapter is accepted. No owner ROMs, credentials, accounts, awards, device/cloud action or native emulator execution. Fresh retention/admission and active watcher supervision required; compact receipts kept, finished disks retired.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6160344369 2026-10-14T03:39:20Z updated 2026-10-14T03:39:20Z -->
Public archive integrity prerequisite completed without redownload or native payload execution. Explicit metadata/hash recovery passes while original acquisition1 remains. In the no-NIC VM, full SHA was checked before decoding; all55 member CRCs and339635561 decoded bytes pass, including five mixed-backslash names, three stored links and required AArch64 ELF structures. No archive files/links were installed and no payload executed. Signature authentication, external dependency resolution and native readiness remain unproven.

Source-only repair packet153f0663 now records the concrete remaining contract choices: recognizing legacy/self-updated clients without false success or rejecting working installations, and preserving post-profile STEAM_DOT overrides while describing exactly when refusal precedes mutations. A receipt alone is not readiness, and arbitrary old data must not be deleted. See local `docs/qa-logs/2026-10-14-steam-client-repair-source/contract-alternatives.md`.

The25 proposed full-script controls are specifications, UNRUN; an installer repair has not been implemented. This source decision is not a reason to repeat the accepted archive inspection. One verified archive remains for the next immediate qualification. VM/results are consumed and temporary disks retired. Compact evidence is in `docs/qa-logs/2026-10-14-rvz-proxy-components/`. No owner/device/cloud/native-client action.

<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6162049531 2026-10-14T06:05:24Z updated 2026-10-14T06:05:24Z -->
The client transaction candidate is locally committed as a057a2a7e9 (full hash in source handoff), with19 prepared full-caller cases. It preserves supported legacy/self-updated client structure without obsolete receipt-hash gating and preserves post-profile STEAM_DOT overrides. This is source/static evidence only. An independent existing Herdr lane is reviewing the exact new helper; no product integration or native readiness claim.

Can this be done on the VM? Yes. Next bounded experiment is only fresh-client-real-root in a fresh accepted GENERIC_X64 no-NIC guest. Stage exact sealed source read-only, provision3GiB disposable executable scratch for the unchanged Proton free-space predicate, and run the full-caller fixture once. Its original90s work/10s cleanup/64MiB retained-data/2MiB log limits remain; outer command120s plus10s kill cleanup. It must pass the inherited namespace/parent-death controls and new exec-denial controls first. Synthetic files/accounts/profile/transport only; ptrace denies the exact synthetic Steam bootstrap. PASS would prove this setup/preservation path, not ARM64 native Steam operation. No device, saves, account, remote fetch, or real payload execution.

Preserve original caller and guard exits, source hashes, before/after storage manifests and failure diagnostics. A failed fixture is not a product PASS; do not loop other cases or silently retry. Coordinator owns monitored VM lifecycle and subsequent stopped-disk export/retirement. Converter compilation is held while this serialized VM stage runs.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6162248091 2026-10-14T06:20:43Z updated 2026-10-14T06:20:43Z -->
First synthetic full-caller VM case against a057a2a7e94c372642fd66ff9795125487f1fa75 remains FAIL1: the ptrace exec boundary reached its deadline after89.6seconds during Proton-CachyOS setup, before an original installer exit returned. Polling overhead is a source-level lead, not yet measured attribution. No setup/native acceptance is claimed. Fixture supervision quiescent, lifecycle finally flush/unmount and owned QEMU stop passed; host PIDs absent, failed admission consumed,2,278,125,568 disposable bytes retired.

Independent source-only review8aec3a found two concrete client-helper defects: optional proc task/children is absent on the accepted kernel and breaks detached-child cleanup; lexical normpath can misresolve nested symlink/parent traversal for STEAM_DOT support metadata. Existing source lane is repairing both and the bounded fixture before a new runtime allocation. Original failure is retained. Packets: docs/qa-logs/2026-10-14-steam-client-first-caller/ and .../2026-10-14-steam-client-source-review/. No device/account/provider use or product promotion.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6162590986 2026-10-14T06:45:47Z updated 2026-10-14T06:45:47Z -->
Can this be done on the VM? Yes. Fresh no-NIC VM20 will run exactly fresh-client-real-root against03e130e4b3c244337f2e6d782b392a2c444c28e7, including mandatory busy/idle and exec-denial controls. Independent review485d6d83c7 finds both prior findings addressed in source and no new concrete defect in the scoped delta. Runtime remains to establish that disposition. Original90s fixture/80s tracing/120s outer command bounds retained, executable3GiB tmpfs and private synthetic storage. No downloaded client execution, account/provider/device access or deadline inflation. Export all original results, stop VM and retire its disks after consumption. Later alias/child/timeout cases remain separately allocated. Original attempt01 remains FAIL1.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6162646409 2026-10-14T06:49:49Z updated 2026-10-14T06:49:49Z -->
Corrected first caller03e130 passed original0 in15.47s; actual caller/trace driver0, busy guard8009 syscall stops, expected idle deadline2.01s original guard1 with caller null and no survivors. Execution denial remains active; no native Steam success. All owners/QEMU exited, admission consumed, disposable2,278,051,840bytes retired.

Can this next proof be done on the VM? Yes. Separately allocate fresh-profile-parent-alias with identical source, bounds and no-NIC accepted VM20. It must place aliases/registry only in the actual symlink/parent destination and preserve the independently seeded lexical decoy. No owner settings, cloud, account or native payload. Other existing-profile/child/census/timeout controls remain separately due.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6162852834 2026-10-14T07:04:04Z updated 2026-10-14T07:04:04Z -->
M7 checkpoint 4960aaa760: the corrected full-caller and fresh profile-parent-alias cases pass in separate disposable VMs.

Candidate `03e130e4b3c244337f2e6d782b392a2c444c28e7` addresses both source-review findings: child cleanup on kernels without task/children, and resolving nested symlink/parent components to the correct support directory. Independent review `485d6d83c7cee13129133b747db95ce6e0ebdbd0` found both addressed and no additional concrete defect in that scoped delta.

The complete synthetic caller passed in 15.47 seconds; the fresh profile-path case passed in 15.94 seconds while preserving the decoy and unrelated data. Original caller, trace, fixture and lifecycle exit channels are 0. Expected idle-deadline and denied-exec controls remain separate negative evidence. Real Steam payloads were not executed, so native readiness is not claimed.

The original first-run deadline failure remains recorded. All three VM owners exited, output was exported/unmounted, and 6,834,425,856 allocated disposable bytes were removed. No test remains active. Exact evidence is locally committed at `4960aaa760d76a5a16c2b109e5058bcffc09ce3b`, `docs/qa-logs/2026-10-14-steam-client-first-caller/` and the source-review packet; not pushed or integrated.

Remaining: existing-profile alias, detached child, process-census failure, real transport timeout, the broader recovery matrix, and native/installed qualification. #582 remains open.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6171113423 2026-10-14T14:47:54Z updated 2026-10-14T14:47:54Z -->
Can this be done on the VM? **Yes.** The next run uses a fresh accepted VM20 with no network device and the unchanged `03e130` fixture/installer for `existing-profile-parent-alias`. It checks preservation of the valid existing client, channel, aliases and unrelated profile data; no provider, personal data or real client executes.

The earlier fresh caller/profile cases remain accepted. This is a distinct case, not a repeat. Original fixture 90-second and trace 80-second bounds remain; coordinator command is bounded to 120 seconds plus cleanup, serial to 180 seconds, and host VM work to 900 seconds. Inputs are hash-bound read-only media; private executable scratch is a 3 GiB tmpfs. Exact caller/guard/lifecycle results will be exported before stopping and retiring the disposable disk.

Owner: `/workspace/tmp/pix582-client-vm-20261014-04`. The current capacity report has no errors and fits without reclamation. Runtime is serialized under the coordinator's watcher and active result supervision. This independent case uses the available runtime slot while the Dolphin VM driver is prepared; the remaining M7 integration order is unchanged. No test outcome or product promotion is claimed by this plan.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6171202517 2026-10-14T14:52:15Z updated 2026-10-14T14:52:15Z -->
The new `existing-profile-parent-alias` case passed with unchanged candidate `03e130e4b3c244337f2e6d782b392a2c444c28e7`.

- Complete caller, trace driver, fixture, VM lifecycle and watcher all returned 0. Fixture elapsed: 15.01 seconds.
- All 22 protected entries remained unchanged, including the existing client/channel, correct resolved profile, misleading lexical path and unrelated data.
- The synthetic client execution was denied as intended; this remains setup/preservation evidence, not native Steam readiness.
- Original output and guards were exported, actual host/QEMU/child exits verified, reservation consumed, and 2,277,924,864 allocated disposable bytes removed.

Evidence: `docs/qa-logs/2026-10-14-steam-client-first-caller/attempt04-existing-profile/` in the coordinator worktree; local and not yet pushed. Remaining targeted tests are detached transfer child, process-census failure and the existing real transport timeout, then broader recovery and native/installed qualification. No job remains active from this allocation.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6171237155 2026-10-14T14:53:57Z updated 2026-10-14T14:53:57Z -->
Can this be done on the VM? **Yes.** Continue the unchanged `03e130` recovery fixture in three sequential fresh no-network VM20 owners: `detached-transfer-child`, `proc-census-error`, then `transport-timeout`. Use separate inputs/output roots and admissions; stop and investigate any unexpected result before advancing.

The ordinary cases retain 90-second fixture / 80-second trace limits and a 120-second outer command. The timeout case retains its existing 240-second fixture / 230-second trace limits so the real 180-second product transport timeout can occur; its coordinator command is 270 seconds. Each VM has 8 GiB RAM, private 3 GiB executable scratch, read-only public fixture input, and a 900-second host work alarm plus bounded cleanup. No source limit is raised.

Expected evidence is distinct: product cleanup must reap the detached writer; a failed process census must preserve uncertain state and refuse the next attempt; the real transport timeout must stop its owned children without test-harness rescue. Expected negative caller exits remain negative in the original records even when the test itself passes. Synthetic client execution stays denied. No personal data, native Steam payload or provider account is involved.

The coordinator actively supervises the standard watcher, verifies original receipts and actual exits, and removes each disposable disk after export. A new batching harness is unnecessary for these three cases; source preparation does not hold their execution. First owner: `/workspace/tmp/pix582-client-vm-20261014-05`. These are partial setup/recovery criteria, not complete native or installed-image acceptance.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6171815833 2026-10-14T15:22:54Z updated 2026-10-14T15:22:54Z -->

## October14 remaining targeted caller checks

All four targeted cases passed on separate fresh no-network VM20 guests with the unchanged03e130 installer/fixture. These are synthetic caller/transaction proofs, not native Steam execution or complete installed-image qualification.

| Packet | Original observations | Scope/result |
| --- | --- | --- |
| attempt04-existing-profile | 15.010742164s; caller0;22 protected entries unchanged | Existing profile and parent alias preserved; native client denied |
| attempt05-detached-child | 15.365351534s; caller0;13 entries unchanged; child45 exit-9 | Product cleanup ends detached descriptor holder; no harness rescue |
| attempt06-admission-refusal | launcher/runner125 before command; no command.pid, VM or registry reservation | Checkpoint edit raced source fingerprint; retained original refusal, never admitted |
| attempt06b-census-error | 24.818389396s; intended callers1,1;13 entries unchanged | Unknown-live state stays held; second attempt refuses before install; independent fixture actor releases child77, not product quiescence |
| attempt07-transport-timeout | 196.987076506s; intended caller1;13 entries unchanged; child exit-9 | Real180s product timeout, original230s trace/240s fixture; no installed state or harness rescue |

Each admitted run has original fixture/namespace/lifecycle/watcher/launcher0, exported original traces, actual host/process exits, consumed admission and retirement receipt. The negative installer exits remain negative. Total four disposable VM allocations retired:9,112,907,776bytes. Broader19-case recovery/compatibility matrix and native/installed-image proof remain; the6bebc365 aggregate proposal is HELD/UNRUN and was not used. Prior a057 failure remains unchanged.

Local evidence: `docs/qa-logs/2026-10-14-steam-client-first-caller/`. No issue closure or product integration.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6172660526 2026-10-14T16:04:13Z updated 2026-10-14T16:04:13Z -->
M7 continuation: can this be done on the VM? Yes. While the CHD runner and proxy lifecycle fixtures are being prepared source-only, allocate one fresh no-NIC VM20 for unchanged candidate03e130 `interrupt-published-retry`. The real embedded helper receives SIGKILL after directory rename/parent fsync; required original callers are1 then0. Preserve the first failure and journal, verify the same published tree and all protected synthetic state, then bounded cleanup and disk retirement. Existing90-second fixture/80-second trace/10-second cleanup bounds remain; outer command120s. No owner device/account/network/native Steam execution. Coordinator uses established watch-build/admission and actively consumes original result channels. No repeated accepted case and no firmware build.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6172713952 2026-10-14T16:06:54Z updated 2026-10-14T16:06:54Z -->
Fresh owner08 interrupt-published-retry PASS26.67s on unchanged03e130: original callers1 then0, actual helper-9 after client rename/parent fsync, original first journal25451B retained,13 protected entries unchanged. No trace rescue/survivor; launcher/wrapper/guest0. Actual host owners exited; admission consumed and2278080512B disposable VM data retired. Packet: docs/qa-logs/2026-10-14-steam-client-first-caller/attempt08-interrupt-published.

Next test: can this be done on the VM? Yes. One new no-NIC VM20, unchanged03e130 `committed-self-update-retry`, original callers1 then0. SIGKILL after durable commit, then the synthetic independent actor modifies core bytes/channel; retry must retain those updates and remove only transaction scratch. Existing90s/80s/10s bounds, no provider or native payload execution. Fresh watched owner09 and admission; coordinator consumes original receipts before any further case. No power-loss/native self-update claim.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6172802405 2026-10-14T16:11:19Z updated 2026-10-14T16:11:19Z -->
Committed-self-update-retry now PASS27.26s on unchanged03e130: original callers1 then0, actual helper-9 after committed journal fsync; independent synthetic core/channel updates preserved,13 protected entries unchanged. Original owner09 exited; admission consumed and2278604800B retired. Packet attempt09-committed-self-update under the existing2026-10-14-steam-client-first-caller directory. No native/power-loss claim.

Next: can this be done on the VM? Yes. Fresh no-network VM20 runs unchanged03e130 crc-failure-retry: corrupt local/central CRC consistently while matching the deliberately changed archive whole-file hash, require the actual candidate CRC refusal and no partial publication, then independently recorded good retry. Expected original callers1 then0. Existing90s/80s/10s limits, synthetic data and native-exec denial unchanged; new owner10/admission, active watcher and original-result consumption/retirement. No repeated accepted case or provider/device action.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6173026073 2026-10-14T16:22:43Z updated 2026-10-14T16:22:43Z -->
CRC attempt10 original FAIL26.61s retained: callers1,1. First call reaches real CRC refusal and safely retires unpublished stage; second archive transfer boundary exits1. Exact lead: shared /qa/events.ndjson already10806B before retry archive child, whose product RLIMIT_FSIZE is10676B. Its fixture event append would exceed the inherited cap; EFBIG remains inferred until a bounded reproduction. Product and limits unchanged; source lane prepares per-transfer logging and control. All actual owners exited; admission consumed failed-investigated;2278035456B VM outputs retired. No further Steam cases dispatched. Packet docs/qa-logs/2026-10-14-steam-client-first-caller/attempt10-crc-failure.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6173327743 2026-10-14T16:38:17Z updated 2026-10-14T16:38:17Z -->
Continuing #582 after original CRC retry FAIL (caller1,1): additive fixture8f0eaf isolates boundary log files; product03e130, transport limits, corrupt bytes and expected1,0 are unchanged. Original attempt10 remains retained.

Can this be done on the VM? Yes. Fresh no-NIC VM20 owner11,8GiB RAM/4CPU,3GiB private tmpfs; existing90s fixture/80s trace/10s cleanup and120s outer budget. First run one5s bounded private-file control: inherited FSIZE10676 must reject append to10806B shared log with actual EFBIG27, but accept633B private log. Then run only the failed CRC case; retain original exits, collector hashes/events, CRC refusal, protected state and actual quiescence. Read-only cgroup/mount/systemd facts aid #583 compatibility diagnosis. No provider, owner state, native Steam execution or product edit. Active watch-build delivery; consume then retire VM.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6173478484 2026-10-14T16:45:57Z updated 2026-10-14T16:45:57Z -->
Corrected CRC fixture8f0eaf PASS in fresh VM attempt11: original caller/trace1,0, actual CRC refusal then clean retry,13 protected paths unchanged,26.60216966s. Original outer channels0, no intervention/survivor.65 collected events/13,897B bind24 original streams. Separate bounded-file control directly observed EFBIG27 for10806B append under10676B cap and accepted633B freshfile. Original attempt10 staysFAIL; its exception was not retained. Evidence docs/qa-logs/2026-10-14-steam-client-first-caller/attempt11-crc-events. Admission5fff76 consumed; actual host owners exited;2,278,100,992B VM/media retired. Product03e130 unchanged and no native Steam execution.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6181740385 2026-10-15T00:45:10Z updated 2026-10-15T00:45:10Z -->
Can this be done on the VM? Yes. Allocate the already reviewed metadata-plus14 continuation using installed guest curl/Bash and the unchanged source-chroot recovery fixtures. No physical ARM64/FEX or installed Steam claim.

Owner /workspace/tmp/pix582-metadata-remaining-vm-20261015-01, frozen fac608ff image, source packet seal ea5202e79edf186a4863ee2e73280c8874b7da351d0734e654ddde4407f9f146. One8GiB4CPU no-NIC guest/VNC132. Metadata runs first using unchanged helper68f298d4 and separate candidate installercefb22a5; exact request list remains enforced. Then only14 pending recovery cases, with the9 previously accepted cases excluded. Family3600s with90s fail-stop reserve; metadata110+10s helper/150s serial, original14 each180s. No later case starts after a failure or without its remaining budget. No passing row replay or host-test failure relabeling.

Prior host metadata attempts remain FAILED: unexpected listener probes violated isolation; private network namespace then refused before payload. The no-NIC guest supplies isolation without relaxing the assertion. Dolphin compile/startup allocations have finished with original outer exits0 and consumed admissions. Root actively supervises this sole runtime owner and will retain original stage, watcher, cleanup and stopped-media export results before consumption.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6181776276 2026-10-15T00:48:03Z updated 2026-10-15T00:48:03Z -->
The first metadata-plus14 allocation stopped before boot: qemu-args returned2 because the preparer selected the frozen VM helper, which lacks --no-network. No guest or case ran. Original aggregate1/monitor0, actual owners absent; failed admissionff041b06 consumed. Compact original export: /workspace/tmp/pix582-metadata-preboot-failure-20261015-01.

A fresh source derivative will bind the already qualified no-NIC helper used by the successful Dolphin run and preserve captured CLI stderr/stdout on future failures. The metadata function/helper and all14 recovery case bytes stay unchanged. This corrects preparation provenance; it does not waive a case or relabel the failed run.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6181815529 2026-10-15T00:51:18Z updated 2026-10-15T00:51:18Z -->
Can this be done on the VM? Yes. Allocate fresh owner /workspace/tmp/pix582-metadata-remaining-vm-20261015-02 after preserved/consumed pre-boot owner01. Source correction seal872f66abbe87bc1949800ef48814b239ec864acaa25f6e3c615162a0bff31c69 binds qualified no-NIC helper5b058ed8 and profile26c420ec, already used by successful Dolphin proof. Original captured CLI stdout/stderr will now survive CalledProcessError. No product/case/assertion changes.

The exact metadata helper, candidate/frozen installer, exporter and all14 case sources remain byte-identical. Same one8GiB4CPU/no-NIC/VNC132 guest,3600s family plus90s reserve; metadata110+10s/150s serial then14 pending cases with180s stage limits.9 accepted cases excluded. Original host and owner01 failures stay failed. Root actively supervises the sole runtime owner; source/audit work continues independently.


<!-- https://github.com/pixelelated/distribution/issues/582#issuecomment-6181962137 2026-10-15T01:02:58Z updated 2026-10-15T01:02:58Z -->
Steam continuation completed on October15 at00:57:28 UTC. Exact candidate metadata controls pass with installed curl/Bash: normal responses succeed, oversized response curl63, stalled response curl28 after30.006s, exactly four expected loopback requests, no surviving listener/process group. All14 remaining unchanged whole-caller source-chroot cases pass with original expected exits (five success0, four refusal1, five failure1→retry0), selected state restored. Existing nine accepted cases were not repeated.

Run20261015T005126Z-af985198, all original outer channels0, normal QEMU stop/unmount and actual owners absent; stopped-media exporter also0. Admission9351cef4 consumed qualified. Compact originals are in docs/qa-logs/2026-10-15-steam-remaining-result/. Owner01's pre-boot failure remains failed and retained.

Can this be done on the VM? Yes; this proof used the isolated no-NIC GENERIC_X64 guest. Metadata candidate and unchanged transaction caller scopes are recorded separately. Native client exec is intentionally denied in synthetic fixtures; no installed/native ARM64 Steam/FEX readiness claim. GENERIC_X64 does not package that installer. Those limits remain explicit before issue closure. Independent audit#590 continues; next engineering image includes the source repair.

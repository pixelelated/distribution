# Minimal remaining packaged portable-script VM procedure — UNRUN

No earlier record closes the exact installed-artifact execution seam in
#564.4/#579.4/#580.4. The accepted scope plan explicitly rules out treating a
source chroot as installed ARM Steam. The current GENERIC image intentionally
omits the installer. One selected portable-script execution can establish the
missing byte-bound behavior without pretending to execute FEX/Steam natively.
Root must decide that precise observation against the literal criterion; this
packet does not rewrite or waive it.

After successful actual SM acceptance, obtain **one file** through the existing
rooted SYSTEM reader: `/usr/config/modules/Install Steam.sh`. Preserve its actual
SYSTEM/update identity and readback row before staging. It must equal the accepted
SM `affected-products.json` row and current source SHA1694f7a9…512ad3b/124399bytes.
This is future data-only extraction, not done here; do not substitute a Git copy
while claiming it came from SYSTEM. Protect accepted firmware/source and never
copy ARM executables into host/guest execution paths.

Derive from the qualified
`docs/qa-logs/2026-10-15-steam-vm-helper-correction/remaining-source/` fixture:

- Retain fixture/namespace/ptrace/parent-death/census/event-stream/payload sources
  unchanged. Select only `existing-profile-dot`, which is already supported and
  seeds a valid retained client/channel, selected support path, old runtime/FEX,
  both Proton families and unrelated game/save/custom roots.
- Bind the complete current module SHA and its exact runtime shell-function SHA
 24c5feedf7c1addc616cbb261e12450d43a4288a356bc471262c6851e0a2b7d7.
  All five embedded helper hashes and their stdin hashes remain unchanged;
  root/FEX/Proton/client shell slices are identical to accepted03e130. Preserve
  `accepted-installer-to-current.diff`: precisely the bounded metadata argv and
  already accepted absolute isolated runtime invocation, nothing else.
- Narrow `boundary.py`'s two recognized provider metadata URL branch from
  `['-fsSL']` to exactly
  `['-q','-fsSL','--connect-timeout','10','--max-time','30','--max-filesize','1048576']`.
  Do not broaden arbitrary URL matching or change runtime/client curl contracts.
  The runtime Python boundary already supports `-I/-S/-B`; it needs no rewrite.
- Seal an additive source packet with exact old/new binding/diff; retain old
  fixture and failed attempts. Review actual final GENERIC tool identities
  against its completed verifier and the fixture's existing exact BusyBox guard.
  If a tool digest differs, review the actual dependency before any run; do not
  weaken the guard or overlay an older tool to manufacture compatibility.

Use one fresh admitted no-NIC8GiB/4CPU final GENERIC guest, existing qualified
single-guest lifecycle and source-input/output ext4 routes. No provider or host
service. Ordinary fresh retention/admission, exact frozen tools, one serialized
runtime owner, original channels, stopped-media export and actual cleanup remain.
No metadata timeout repeat, no14/23-case replay, and no accepted gameplay repeat.

The guest-only inner invocation (after reviewed preparation/allocation) is:

```sh
TMPDIR=/run/pix582-scratch timeout --signal=TERM --kill-after=10s 120s \
  python3 -I -S -B /tmp/pix-input/docs/qa-logs/2026-10-14-steam-remaining-source/fixture.py \
  --disposable-vm --case existing-profile-dot \
  --installer '/tmp/pix-input/accepted-sm/usr/config/modules/Install Steam.sh' \
  --output /run/pix582-scratch/existing-profile-dot-01
```

The command is held, not runnable without a fresh reviewed packet/owner and actual
SM bindings. Preserve existing90s fixture/80s trace/10s cleanup/120s+10s wrapper,
3GiB executable private tmpfs with2368MiB minimum free,64MiB case retained data,
2MiB/log,1MiB synthetic archives and4KiB/512-file event bounds. Reuse the qualified
lifecycle's single-stage budget and cleanup; do not lengthen limits for repetition.

Acceptance: original caller/trace/namespace/fixture0, exactly nine ordered calls,
exact retained client/channel/profile and protected game/save/unrelated-FEX
identities, deliberate new-FEX generation, both Proton variants validated,
actual runtime library links, and no owned transaction scratch. Exactly one
client exec denial must remain EACCES13, native_client_success=false. Retain
before/after and caller-observation, raw stdout/stderr, exec guards and original
event streams; all outer originals, normal QEMU teardown, owner absence and
qualified consumed receipt must agree. No helper/wrapper0 substitutes for an
unknown original status or rescued/forced cleanup.

This proves behavior of the actual packaged portable installer with installed
x86_64 interpreter/tools and explicit synthetic transport/profile/FEX/Proton
payloads. It does not prove native ARM FEXRootFSFetcher, actual overlay loader
closure, Wine/Proton games, native Steam login/launch/self-update, consumer
quiescence or power-loss durability. Native/physical/source-custody scope stays
on its existing tracker; no new such gate is introduced here.

# Independent finite closure review: #581 / #582

No concrete blocker found for the proposed scoped closures or menu-map correction. This is a retained-evidence and source review, not a new runtime qualification or release approval.

Reviewed packet: `/tmp/pix-m7-device-dependent-issues-20261015`, seal `55432b78159def81b5858e460cbd1d0d2781a9ccb83e28ad0694fc401480b3ee`. All 107 payloads and exact membership match; all 54 original locators match copied bytes, mode, uid/gid and nanosecond mtime. The four #581 and five #582 criterion texts are unchanged. All eight immutable evidence links resolve at the specified `a57b0014` Git object. Issue bodies/comments are the packet's observed snapshots; this review did not fetch or mutate live issues.

## #581: supported preservation closure

`originals/dolphin-old.json` retains eight real-directory/card/shared-data loss controls with original launcher fragment 0 and preservation assertion 1. `dolphin-controls.json` retains 104 PASS cases and launcher refusals before the engine; `dolphin-mounts.json` retains eight actual mount cases, six card writes, and unchanged before/after inventories on refusal. The EN/FR frame indices explicitly retain their earlier staged-caller and recording-engine scope.

`vm-reader.json` binds the final f863 helper and two recipe-transformed installed launchers. The helper hash independently matches its f863 Git source. Selected original records inside the small final clean/retained archives match their manifests; original runner outcomes agree with consumed admissions `4c52e6ff` / `6999b332` and all seven outer channels are 0. Retained state records have different boot IDs, unchanged selected paths and PASS byte/mode preservation checks. These later artifacts address the historical AC-088 PARTIAL without rewriting the frozen audit score.

The proposal correctly separates d4af ordinary Wii/Dreamcast game-save evidence from the later four-launch f863 native-state continuation. It preserves the old native fixture/export failures, unknown native-child wait status, and the engineering build's reporting failure (`qualification=false`, launcher wait null). It makes no arbitrary-storage, hardware, account/award or abrupt-power claim. Earlier deletion cannot be reconstructed; the stated nonmigration treatment of retained data is accurate.

## #582: supported bootstrap-preservation closure

The old reproduction preserves failed client extraction followed by misleading retry `[1,0]`, with the valid-existing control separate. The nine targeted originals preserve expected refusal/interruption exits and protected entries. Independently read all fourteen subsequent fixture `result.json` members inside their original archives: their hashes, stage/wrapper results, restored state and original caller exits agree with the reviewed-case projection (five `[0]`, four `[1]`, five `[1,0]`). Admission `9351cef4` is consumed with original command/monitor/runner 0. The four-request installed-curl metadata result preserves oversize 63 and stalled 28 at 30.006 seconds. The 55-member public archive record is explicitly a nonexecuting CRC/layout/ELF inspection.

Git readback confirms all five embedded transaction helpers match the accepted source at both f863 and 9aa7. The complete installer delta is exactly the retained diff: bounded metadata fetch plus the separately qualified isolated runtime-Python invocation. No claim that the original full caller exercised those later lines is needed or made.

Criterion five explicitly requires recording installed-image/native/self-update/quiescence/power-loss limits before closure. The proposal does so: source-chroot synthetic boundaries and native exec denial remain explicit; selected SM8550 artifact identity stays in #555/#563 and portable packaged-script continuation in #564/#579/#580. Synthetic committed-update/SIGKILL controls do not qualify real native Steam self-update or power loss. Those remaining scopes do not require replaying accepted #582 cases to close its stated contract.

## Menu-map and application boundary

`proposals/menu-map.diff` replaces only the stale final qualification sentence near line 398. It keeps the original staged-frame attribution and links later installed, ordinary-save and native-state evidence separately. Simulated replacement yields the guarded after hash `96826fda3fbe7e94585a9ba83df97ae3bf887990f7dfe48f970f0f543903bed8`. No menu navigation or product change is proposed. Root should apply only against the exact before/body guards and retain the stated scope limitations.

No runtime, VM/device/cloud action, cache/output traversal, project-helper import, test, source edit or tracker mutation occurred. This review inspected selected original archive members, not a repeated full native/archive audit; it did not re-view historical frames. Three reviewer-only schema lookup failures are retained in the accompanying readback records, followed by corrected read-only checks; none is a product/test outcome. No evidence was modified. Owned review scope is released.

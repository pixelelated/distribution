#!/usr/bin/env python3
"""Submit one reviewed action to the sole lifecycle operator; never opens serial/QMP."""
import argparse,fcntl,hashlib,json,re,time,uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('operation',choices=['status','launch','engine-key','ui-key','capture','review','snapshot','finish','abort']);p.add_argument('--owner',type=Path,required=True);p.add_argument('--label');p.add_argument('--key');p.add_argument('--review');a=p.parse_args()
r=a.owner.resolve(strict=True);c=json.loads((r/'config.json').read_text());ready=json.loads((r/'visual-ready.json').read_text())
assert time.monotonic()<ready['deadline_monotonic'] and not (r/'vm-result.json').exists()
for name,h in c['code'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h
request={'id':uuid.uuid4().hex,'operation':a.operation,'label':a.label,'key':a.key,'review':a.review,'submitted_host_monotonic':time.monotonic()}
if a.label:assert re.fullmatch('[a-z0-9-]{1,48}',a.label)
if a.review:assert 1<=len(a.review)<=3000
with (r/'action.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert len(list((r/'requests').glob('*.json')))<160
 pending=r/'requests'/(request['id']+'.pending');target=pending.with_suffix('.json')
 with pending.open('x') as f:json.dump(request,f);f.write('\n')
 pending.rename(target)
 response=r/'responses'/(request['id']+'.json');end=min(time.monotonic()+165,ready['deadline_monotonic']+10)
 while not response.exists():
  assert time.monotonic()<end,'ambiguous action: keep request; never replay automatically'
  assert not (r/'vm-result.json').exists(),'lifecycle ended; inspect retained request/originals'
  time.sleep(.2)
 value=json.loads(response.read_text());print(json.dumps(value,indent=2));assert value['status']=='PASS',value

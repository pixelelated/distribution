#!/usr/bin/env python3
"""Called inside the actual container immediately before the one recipe build."""
import json,os,sys
from pathlib import Path
keys=('PROJECT','DEVICE','ARCH','CC','CXX','CPP','LD','AS','AR','NM','RANLIB','CPPFLAGS','CFLAGS','CXXFLAGS','LDFLAGS','MAKEFLAGS','CCACHE_DISABLE','CCACHE_DIR','CCACHE_TEMPDIR','TMPDIR','PATH')
v={k:os.environ.get(k) for k in keys}
assert v['CCACHE_DISABLE']=='1' and v['MAKEFLAGS']=='-j2'
assert v['CFLAGS'].split()==['-march=x86-64-v3','-mtune=generic','-Wall','-pipe','-O2','-fomit-frame-pointer','-DNDEBUG']
assert v['CXXFLAGS'].split()==v['CFLAGS'].split()
assert v['CPPFLAGS']==''
assert v['LDFLAGS'].split()==['-march=x86-64-v3','-mtune=generic','-Wl,--as-needed','-fuse-ld=bfd']
assert not any(k.startswith('ZT_') for k in os.environ)
v['python_version']=sys.version
v['instrumentation']={'CFLAGS_CXXFLAGS_append':'-MD -MP','final_one_LDFLAGS_append':'-Wl,--dependency-file,/receipts/link.d'}
v['host_header_auto_detection']={str(p):p.exists() for p in [Path('/usr/include/natpmp.h'),Path('/usr/include/miniupnpc/miniupnpc.h')]}
with Path('/receipts/compile-environment.json').open('x') as f:json.dump(v,f,indent=2);f.write('\n')

# Root-only commands after review — unrun

Use the existing record-only host-source rationale under#528. Serialize with all
other allocated work and check the24MiB proposed output envelope. Both owners
must be fresh; the collector creates its own owner.

```bash
TASK_PACKET=/tmp/pix-m7-fex-xcb-protocol-notices-plan-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03
TASK_OWNER=/workspace/tmp/pix-m7-fex-xcb-protocol-notices-20261015-01
TASK_LAUNCHER=/workspace/tmp/pix-m7-fex-xcb-protocol-notices-launcher-20261015-01
mkdir -m 700 "$TASK_LAUNCHER"
cd "$TASK_TREE"
tools/watch-build-submit --owner "$TASK_LAUNCHER" -- \
  --record-only --activity-dir "$TASK_LAUNCHER" -- \
  taskset -c 0,1 prlimit --as=1073741824 --fsize=2097152 -- \
  timeout --signal=TERM --kill-after=5s 25s \
  /usr/bin/python3 -I -S -B "$TASK_PACKET/collect.py" --owner "$TASK_OWNER"
```

Preserve original launcher/tool-wrapper, command/monitor/runner outcomes and the
collector's elapsed time, result and member index. Submission success is not
collection success. Read both actual texts, their original archive member names,
hashes and any gaps before updating the source/notice mapping. No source equality
claim follows from the version association. Failure keeps partial output and
original exits; no automatic retry, acquisition or broader extraction follows.

#!/usr/bin/env python3
"""Bounded one-archive XCB protocol-notice read. Data only; root allocates."""
from pathlib import Path, PurePosixPath
import argparse, bz2, gzip, hashlib, json, lzma, os, re, resource
import signal, stat, sys, tarfile, time

PACKET = Path(__file__).resolve().parent
START = time.monotonic()
PLAN = json.loads((PACKET / 'collection-plan.json').read_bytes())
LIMIT = PLAN['limits']
OWNER = None
written = files_written = retained = physical = decoded_total = entries_total = 0
texts = {}
rows = []
archives = []
gaps = []

def need(ok, why):
    if not ok:
        raise RuntimeError(why)

def tick():
    need(time.monotonic() - START < LIMIT['soft_seconds'], 'soft-deadline')

def shape(s):
    return dict(bytes=s.st_size, device=s.st_dev, inode=s.st_ino,
                mode=stat.S_IMODE(s.st_mode), uid=s.st_uid, gid=s.st_gid,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)

def identity(path):
    need(path.is_absolute() and path.resolve(strict=True) == path,
         'input-path-not-canonical')
    s = path.lstat()
    need(stat.S_ISREG(s.st_mode), 'input-not-regular')
    return shape(s)

def read_chunk(stream, size):
    global physical
    tick()
    need(0 <= size <= 1024**2, 'read-chunk-bound')
    need(physical + size <= LIMIT['compressed_input_read_bytes'], 'input-read-bound')
    block = stream.read(size)
    physical += len(block)
    return block

def digest(spec, retain_bytes=False):
    path = Path(spec['path'])
    before = identity(path)
    need(before['bytes'] == spec['bytes'], 'input-size-mismatch')
    need(before['bytes'] <= 192*1024**2, 'input-file-bound')
    if retain_bytes:
        need(before['bytes'] <= LIMIT['selected_member_bytes'], 'context-file-bound')
    h = hashlib.sha256()
    parts = []
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as f:
        need(shape(os.fstat(f.fileno())) == before, 'input-open-race')
        total = 0
        while total < before['bytes']:
            b = read_chunk(f, min(1024**2, before['bytes'] - total))
            need(bool(b), 'input-truncated')
            total += len(b)
            h.update(b)
            if retain_bytes:
                parts.append(b)
        need(shape(os.fstat(f.fileno())) == before, 'input-changed-during-read')
    need(identity(path) == before, 'input-path-changed')
    need(h.hexdigest() == spec['sha256'], 'input-hash-mismatch')
    return dict(before, path=str(path), sha256=h.hexdigest()), b''.join(parts)

def write(relative, raw, failure=False):
    global written, files_written
    need(OWNER is not None and isinstance(raw, bytes), 'write-state')
    need(files_written < LIMIT['output_files'], 'output-file-count')
    ceiling = LIMIT['owner_ceiling_bytes'] if failure else LIMIT['normal_owner_bytes']
    per_file = LIMIT['failure_receipt_bytes'] if failure else LIMIT['metadata_bytes']
    need(len(raw) <= per_file and written + len(raw) <= ceiling, 'output-before-write-bound')
    path = OWNER / relative
    need(path.parent in [OWNER, OWNER/'texts'] and not path.exists()
         and not path.is_symlink(), 'output-path-or-overwrite')
    # Reserve the complete write before opening; failed partial writes retain it.
    written += len(raw)
    files_written += 1
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        need(f.write(raw) == len(raw), 'short-output-write')
    return str(path)

def put(relative, obj, failure=False):
    return write(relative, (json.dumps(obj, sort_keys=True, indent=2) + '\n').encode(), failure)

def retain(raw):
    global retained
    need(0 < len(raw) <= LIMIT['selected_member_bytes'], 'selected-text-size')
    need(b'\x00' not in raw, 'selected-text-contains-NUL')
    h = hashlib.sha256(raw).hexdigest()
    if h not in texts:
        need(retained + len(raw) <= LIMIT['retained_text_bytes'], 'retained-text-total')
        relative = 'texts/' + h + '.txt'
        write(relative, raw)
        texts[h] = dict(member=relative, bytes=len(raw), sha256=h)
        retained += len(raw)
    return texts[h]

def safe(name):
    p = PurePosixPath(name)
    need(bool(name) and len(name.encode('utf-8', 'surrogateescape')) <= LIMIT['path_bytes']
         and not p.is_absolute() and '..' not in p.parts and '\\' not in name
         and '\x00' not in name and str(p) == name.rstrip('/')
         and len(p.parts) <= LIMIT['path_depth'], 'unsafe-member-name')
    return name.rstrip('/')

def notice_name(name):
    return bool(re.fullmatch(r'(?i)(?:licen[cs]es?|copying\d*|notice|copyright|patents?|authors)(?:[._-].*)?', name))

def selected(spec, relative):
    # Only the two reviewed candidate paths; no broader root notice discovery.
    return relative in spec['exact_candidates']


class Compressed:
    """No unbounded reads; track physical bytes without changing decoder semantics."""
    def __init__(self, stream, maximum):
        self.stream, self.maximum, self.n = stream, maximum, 0
    def read(self, n=-1):
        need(0 <= n <= 1024**2, 'compressed-read-request-bound')
        b = read_chunk(self.stream, min(n, self.maximum - self.n))
        self.n += len(b)
        return b
    def readable(self):
        return True
    def seekable(self):
        return False

class Decoded:
    def __init__(self, stream, maximum):
        self.stream, self.maximum, self.n = stream, maximum, 0
    def read(self, n=-1):
        global decoded_total
        tick()
        need(0 <= n <= 1024**2, 'decoded-read-request-bound')
        # Reserve the requested chunk before decoding, including the EOF drain.
        need(self.n + n <= self.maximum and decoded_total + n <= LIMIT['decoded_total_bytes'],
             'decoded-archive-bound')
        b = self.stream.read(n)
        self.n += len(b)
        decoded_total += len(b)
        return b

def read_archive(spec):
    global entries_total
    before, _ = digest(spec)
    path = Path(spec['path'])
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    seen = set()
    selected_names = []
    root = None
    name_bytes = declared = count = 0
    with os.fdopen(fd, 'rb') as raw:
        need(shape(os.fstat(raw.fileno())) == {k:v for k,v in before.items() if k not in ['path','sha256']}, 'archive-open-race')
        compressed = Compressed(raw, spec['bytes'])
        codec = {'xz': lzma.LZMAFile, 'bz2': bz2.BZ2File, 'gzip': gzip.GzipFile}[spec['compression']]
        options = dict(fileobj=compressed, mode='rb') if spec['compression'] == 'gzip' else dict(filename=compressed, mode='rb')
        with codec(**options) as stream:
            decoded = Decoded(stream, spec['decoded_limit_bytes'])
            with tarfile.open(fileobj=decoded, mode='r|', encoding='utf-8', errors='surrogateescape') as tar:
                for m in tar:
                    tick()
                    name = safe(m.name)
                    need(name not in seen, 'duplicate-archive-member')
                    seen.add(name)
                    count += 1
                    entries_total += 1
                    name_bytes += len(name.encode('utf-8', 'surrogateescape'))
                    need(count <= LIMIT['member_entries_per_archive']
                         and entries_total <= LIMIT['member_entries_total']
                         and name_bytes <= LIMIT['member_name_bytes_per_archive'], 'archive-index-bound')
                    need(m.size >= 0, 'negative-member-size')
                    declared += m.size
                    need(declared <= spec['decoded_limit_bytes'], 'declared-member-byte-bound')
                    parts = PurePosixPath(name).parts
                    if root is None:
                        root = parts[0]
                    need(parts[0] == root, 'multiple-archive-roots')
                    relative = '/'.join(parts[1:])
                    wanted = relative and selected(spec, relative)
                    if wanted and not m.isdir():
                        need(len(rows) < LIMIT['selected_member_rows'], 'selected-row-bound')
                        entry = dict(component=spec['component'], archive_path=spec['path'],
                                     archive_sha256=spec['sha256'], member=name, relative=relative,
                                     bytes=m.size, mode=m.mode, uid=m.uid, gid=m.gid,
                                     mtime=str(m.pax_headers.get('mtime', m.mtime)),
                                     type=m.type.decode('ascii', 'backslashreplace'))
                        need(len(json.dumps(entry).encode()) <= 16384, 'selected-metadata-bound')
                        if not m.isfile() or m.issparse():
                            need(len(m.linkname.encode('utf-8', 'surrogateescape')) <= LIMIT['path_bytes'], 'selected-link-bound')
                            entry['linkname'] = m.linkname
                            entry['gap'] = 'selected member is not a nonsparse regular file; no link followed'
                            gaps.append(dict(component=spec['component'], member=name, gap=entry['gap']))
                        else:
                            need(0 < m.size <= LIMIT['selected_member_bytes'], 'selected-member-size-bound')
                            with tar.extractfile(m) as member:
                                b = member.read(m.size + 1)
                            need(len(b) == m.size, 'selected-member-short-read')
                            entry['retained'] = retain(b)
                            selected_names.append(relative)
                        rows.append(entry)
                    # Stream mode never resolves links; discard TarInfo cache after each row.
                    tar.members.clear()
            while decoded.read(65536):
                pass
        need(compressed.n == spec['bytes'], 'compressed-input-not-fully-consumed')
        need(shape(os.fstat(raw.fileno())) == {k:v for k,v in before.items() if k not in ['path','sha256']}, 'archive-descriptor-changed')
    after, _ = digest(spec)
    need(after == before, 'archive-changed-after-discovery')
    need(root is not None and count > 0, 'empty-archive')
    leaves = {PurePosixPath(n).name for n in selected_names}
    for wanted in spec['required_member_basenames']:
        if wanted not in leaves:
            gaps.append(dict(component=spec['component'], required_basename=wanted, gap='not observed in the bounded selected notice locations'))
    for wanted in spec['exact_candidates']:
        if wanted not in selected_names:
            gaps.append(dict(component=spec['component'], candidate=wanted, gap='candidate member not observed as retained regular text'))
    if not selected_names:
        gaps.append(dict(component=spec['component'], gap='no regular notice text observed in selected locations'))
    archives.append(dict(component=spec['component'], original=before, verified_after=after,
                         observed_archive_root=root, members=count, member_name_bytes=name_bytes,
                         declared_bytes=declared, decoded_bytes=decoded.n,
                         retained_members=selected_names))

def expired(_sig, _frame):
    raise TimeoutError('collector-deadline')

def main():
    global OWNER
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owner', type=Path, required=True)
    args = parser.parse_args()
    need(args.owner.parent == Path('/workspace/tmp') and args.owner.parent.resolve(strict=True) == args.owner.parent
         and re.fullmatch('pix-m7-fex-xcb-protocol-notices-20261015-[0-9]{2}', args.owner.name), 'owner-path')
    need(not args.owner.exists() and not args.owner.is_symlink(), 'owner-exists')
    need((os.getuid(), os.getgid()) == (1000, 1000), 'host-owner')
    need(os.readlink('/proc/self/ns/pid') == 'pid:[4026531836]'
         and os.readlink('/proc/self/ns/user') == 'user:[4026531837]', 'host-namespace')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_AS, (LIMIT['address_space_bytes'], LIMIT['address_space_bytes']))
    resource.setrlimit(resource.RLIMIT_FSIZE, (LIMIT['metadata_bytes'], LIMIT['metadata_bytes']))
    need(set(os.sched_getaffinity(0)) == set(LIMIT['cpu_affinity']), 'cpu-affinity')
    OWNER = args.owner
    OWNER.mkdir(mode=0o700)
    (OWNER/'texts').mkdir(mode=0o700)
    rc = 1
    result = dict(status='FAIL', original_exit=1, source_execution=False, network_used=False,
                  archive_source_tree_extracted=False, children_started=0,
                  all_license_texts_complete=False, publication_clearance=False)
    signal.signal(signal.SIGALRM, expired)
    signal.signal(signal.SIGTERM, expired)
    signal.signal(signal.SIGINT, expired)
    signal.alarm(LIMIT['soft_seconds'] + 1)
    try:
        seal = (PACKET/'SHA256SUMS').read_text()
        for line in seal.splitlines():
            h, n = line.split('  ', 1)
            need(n and not Path(n).is_absolute() and '..' not in Path(n).parts, 'packet-member')
            p = PACKET/n
            need(p.is_file() and not p.is_symlink() and p.stat().st_size <= 2*1024**2, 'packet-member-bound')
            need(hashlib.sha256(p.read_bytes()).hexdigest() == h, 'packet-seal-mismatch')
        need(len(PLAN['archives']) == 1 and len(PLAN['retained_context']) == 0, 'bound-input-set')
        host = dict(path='/usr/bin/python3.14', bytes=7477160,
                    sha256='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41')
        need(Path(sys.executable).resolve(strict=True) == Path(host['path']), 'host-interpreter-path')
        host_identity, _ = digest(host)
        for spec in PLAN['binding_refs']:
            digest(spec)
        put('plan.json', PLAN)
        for spec in PLAN['retained_context']:
            before, b = digest(spec, retain_bytes=True)
            need(len(rows) < LIMIT['selected_member_rows'], 'selected-row-bound')
            row = dict(component=spec['component'], role=spec['role'], original=before,
                       original_member=spec['original_member'], retained=retain(b))
            need(digest(spec)[0] == before, 'context-changed-after-copy')
            rows.append(row)
        for spec in PLAN['archives']:
            read_archive(spec)
        # Independent destination reread of every content-addressed file.
        for row in texts.values():
            digest(dict(path=str(OWNER/row['member']), bytes=row['bytes'], sha256=row['sha256']))
        put('notice-members.json', dict(rows=rows, archives=archives, gaps=gaps, texts=list(texts.values())))
        result.update(status='COLLECTED_FOR_REVIEW', original_exit=0,
                      selected_rows=len(rows), distinct_texts=len(texts), retained_text_bytes=retained,
                      archive_count=len(archives), explicit_gaps=gaps,
                      packet_sha256=hashlib.sha256(seal.encode()).hexdigest(),
                      host_python=host_identity,
                      next_action='Review only the observed protocol COPYING/XML notices and exact gaps; retain the stated version-only Nix association. No source equality or publication claim.')
        rc = 0
    except BaseException as error:
        # No automatic retry, alternate archive, external process, or widened bound.
        result.update(error_type=type(error).__name__, error=str(error)[:2048],
                      completed_archives=len(archives), selected_rows=len(rows),
                      retained_text_bytes=retained, partial_output_preserved=True)
    finally:
        signal.alarm(0)
        result.update(original_exit=rc, elapsed_seconds=time.monotonic()-START,
                      physical_input_bytes=physical, decoded_bytes=decoded_total,
                      observed_entries=entries_total, owner_bytes_before_result=written,
                      owner_files_before_result=files_written, limits=LIMIT)
        put('result.json', result, failure=True)
    print(json.dumps(dict(status=result['status'], original_exit=rc,
                          result=str(OWNER/'result.json'), elapsed_seconds=result['elapsed_seconds'])))
    return rc

if __name__ == '__main__':
    raise SystemExit(main())

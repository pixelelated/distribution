# XCB protocol notice follow-up — source only, unrun

This is the one small follow-up to the accepted FEX notice collection. The
existing libxcb1.17.0 COPYING and complete selected xcb.h are already retained;
their original notice/disposition does not change. xcb.h208–209 includes generated
xproto.h, which was absent from the source archive. The selected libxcb derivation
names xcb-proto1.17.0. Historical release-source custody already holds that version's
**151,748-byte archive**, flat SHA256
`2c1bacd2110f4799f74de6ebb714b94cf6f80fb112316b1219480fd22562148c`.

The executable reader opens only that exact held archive and retains only the
two relative candidates **COPYING** and **src/xproto.xml** beneath its actually
observed archive root. Their inner names are not claimed verified yet. Missing
or nonregular members remain explicit gaps; links are never followed. XML stays
data: no generator, XML entity expansion, compiler, acquired code, network or
download runs. No libdrm/libglvnd or successful full-notice collection is replayed.

This materializes protocol copyright/permission context. The historical archive
has an exact independent flat identity; its association with the selected Nix
input is version-based. No Nix fetch-source equality is inferred or required for
this conservative notice retention. Reconstructing other derivations or the81-row
compiler closure is outside scope. Existing permissive source dispositions remain
unchanged. Any actual XML notice is retained literally for root review.

`collect.py` reuses the accepted full-notice reader from run172157Z-ad2c8624.
`changes.diff` shows the entire executable change: exact two-path selection,
one archive/zero context inputs, a fresh owner name and scoped result wording.
All hashing, stream parsing, original metadata, before-write limits, destination
rereads, host identity and failure-receipt mechanisms remain unchanged. Limits
are supplied by the separately sealed plan. No duplicate supervisor is added.

Bounds: two CPUs/1GiB address space;20s soft deadline,25s outer timeout plus5s
forced-stop allowance, **30s total**. The archive is at most151,748 bytes, decoded
tar at most16MiB,2,048 entries,1,024-byte paths/depth64 and512KiB names. At most
four selected rows and2MiB aggregate retained text are allowed. Physical reads
are capped at32MiB, including the pinned7.5MB host Python identity, named metadata,
archive hashes/decode and destination reread. No other source archive is opened.

The fresh collector owner has at most16 files/two directories and an8MiB hard
ceiling:6MiB normal output plus2MiB reserved. Text and metadata files are at most
2MiB; the original result/failure receipt is at most1MiB. The separate existing
launcher uses the same16MiB receipt margin, making the proposed combined storage
envelope24MiB. No automatic retry, fallback source/member or enlarged bound exists.

The source packet has not run. `commands.md` uses the existing frozen record-only
watcher route; root alone allocates after the currently active job closes.
Original source/full-notice packets and the three original discovery gaps remain
immutable. Successful observation is `COLLECTED_FOR_REVIEW`, not blanket notice
completeness, source equivalence, final-image mapping or publication clearance.

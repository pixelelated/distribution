from pathlib import Path
import hashlib,json,subprocess,os
P=Path('/tmp/pix-m7-fex-xcb-protocol-notices-plan-20261015');R=Path('/tmp/pix-m7-xcb-notices-coordinator-20261015');R.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'SHA256SUMS')=='79552edf49620e426b2ba67c3a59fd4ad429894434df710099699e44f706a652'
for l in (P/'SHA256SUMS').read_text().splitlines():h,n=l.split('  ',1);assert sha(P/n)==h,n
assert (os.getuid(),os.getgid())==(1000,1000)
assert not [j for j in json.loads(Path('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json').read_text())['jobs'].values() if j['state']!='consumed']
O=Path('/workspace/tmp/pix-m7-fex-xcb-protocol-notices-20261015-01');L=Path('/workspace/tmp/pix-m7-fex-xcb-protocol-notices-launcher-20261015-01');assert not O.exists();L.mkdir(mode=0o700)
cmd=['tools/watch-build-submit','--owner',str(L),'--','--record-only','--activity-dir',str(L),'--','taskset','-c','0,1','prlimit','--as=1073741824','--fsize=2097152','--','timeout','--signal=TERM','--kill-after=5s','25s','/usr/bin/python3','-I','-S','-B',str(P/'collect.py'),'--owner',str(O)]
with (R/'launch.stdout').open('xb') as out,(R/'launch.stderr').open('xb') as err:p=subprocess.run(cmd,cwd='/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03',stdout=out,stderr=err)
(R/'launch.exit.json').write_text(json.dumps({'original_tool_exit':p.returncode,'argv':cmd})+'\n');print(json.dumps({'original_tool_exit':p.returncode,'stdout':str(R/'launch.stdout')}));raise SystemExit(p.returncode)

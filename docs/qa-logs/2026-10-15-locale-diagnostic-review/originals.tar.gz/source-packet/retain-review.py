from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,tarfile
p=Path('/tmp/pix-m7-locale-diagnostic-review-20261015');repo=Path('/workspace/repos/rocknix.worktrees/m7-player-setup');es=Path('/home/max/Development/emulationstation-next.worktrees/qa-integration')
sha=lambda b:hashlib.sha256(b).hexdigest()
refs=[]
def retain(name,b,source):
 q=p/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);refs.append({'retained':name,'source':source,'bytes':len(b),'sha256':sha(b)})
for n in ['excerpt.txt','observation.json']:
 f=Path('/tmp/pix-m7-locale-diagnostic-handoff-20261015')/n;retain('sm-prefix/'+n,f.read_bytes(),str(f))
commits=['bc9dfe8141d9561dc1d8502313d00a84c4566ee8','f8636de1d105275dbf9420bbabbbc26f79abb10f','9aa7affee9d4ad5e69725cab20b6d7ad84d93dea']
paths=['projects/ROCKNIX/packages/devel/glibc/package.mk','projects/ROCKNIX/packages/ui/emulationstation/package.mk','projects/ROCKNIX/packages/ui/emulationstation/sources/es_settings','config/functions','config/path']
source_hashes=[]
for path in paths:
 row={'path':path,'commits':{}}
 for c in commits:
  b=subprocess.check_output(['git','show',c+':'+path],cwd=repo);row['commits'][c]=sha(b)
  if c==commits[1]:
   if path=='config/functions':b='\n'.join(b.decode().splitlines()[780:820]+b.decode().splitlines()[1024:1091]).encode()+b'\n'
   retain('source/'+path.replace('/','__'),b,c+':'+path+(' (selected source ranges)' if path=='config/functions' else ''))
 source_hashes.append(row)
(p/'source-hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
b=subprocess.check_output(['git','show','16dbac5211eea7e70db7394372033be2be7df829:es-core/src/LocaleES.cpp'],cwd=es);retain('source/LocaleES.cpp',b,'ES16dbac:es-core/src/LocaleES.cpp')
b=subprocess.check_output(['git','show','96d387fffd1ff90a450fdada2b2ac5d3026b5d93','--',paths[1]],cwd=repo);retain('source/original-pregeneration-commit.diff',b,'git show 96d387fffd1ff90a450fdada2b2ac5d3026b5d93')
base=repo/'docs/qa-logs/2026-10-14-screenscraper-ui-runtime'
for rel,names in [('accepted-fr640/guest-originals.tar.gz',['guest/pix566/cases/fr_FR/localedef.stderr','guest/pix566/cases/fr_FR/localedef-analysis.json','guest/pix566/cases/fr_FR/locale-readback.stdout','guest/pix566/cases/fr_FR/locale-readback.exit.json']),('accepted-1280/guest-originals.tar.gz',['guest/pix566/cases/en_US/locale-readback.stdout','guest/pix566/cases/en_US/locale-readback.stderr','guest/pix566/cases/en_US/locale-readback.exit.json']),('source05.tar.gz',['source05/guest/guest-case.py'])]:
 a=base/rel
 with tarfile.open(a) as t:
  members=t.getmembers()
  if rel.startswith('accepted-1280'):
   assert not any('/en_US/localedef.' in m.name for m in members)
  for n in names:retain('566/'+rel.split('/')[0]+'/'+Path(n).name,t.extractfile(n).read(),str(a)+'::'+n)
refs.append({'source':str(base/'accepted-1280/guest-originals.tar.gz'),'observation':'No /en_US/localedef.* member in complete original guest archive; original guest source copies /usr/config/locale before checking LC_NAME.'})
(p/'evidence-references.json').write_text(json.dumps({'reviewed_utc':datetime.now(timezone.utc).isoformat(),'references':refs,'no_active_cache_or_artifact_reads':True,'no_target_or_probe_execution':True,'no_tracker_mutation':True},indent=2)+'\n')
print('Retained',len(refs),'references; source recipe and selected evidence only.')

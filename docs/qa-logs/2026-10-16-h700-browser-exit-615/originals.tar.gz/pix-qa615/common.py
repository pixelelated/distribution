import os,json,time,subprocess
from pathlib import Path
R=Path('/tmp/pix-qa615');ENV=dict(os.environ,SWAYSOCK='/run/0-runtime-dir/sway-ipc.0.sock',XDG_RUNTIME_DIR='/run/0-runtime-dir',WAYLAND_DISPLAY='wayland-1')
def record(name,v):
 with (R/name).open('a') as f:f.write(json.dumps(dict(at=time.monotonic(),**v))+'\n')
def procs():
 out=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   exe=(p/'exe').resolve().name;st=(p/'stat').read_text().rpartition(') ')[2].split();args=(p/'cmdline').read_bytes().split(b'\0')
   role=exe
   if b'/usr/bin/cloud_oauth' in args:role='cloud_oauth'
   if exe in ['emulationstation','cloud-signin-window','WebKitWebProcess','WebKitNetworkProcess','rclone','sway'] or role=='cloud_oauth':out.append({'pid':int(p.name),'start':int(st[19]),'role':role,'state':st[0]})
  except (OSError,ValueError,IndexError):pass
 return out
def focus():
 q=subprocess.run(['swaymsg','-r','-t','get_tree'],env=ENV,capture_output=True,text=True,timeout=3);q.check_returncode();out=[]
 def walk(n):
  if n.get('app_id'):out.append({k:n.get(k) for k in ['id','pid','app_id','focused']})
  for c in n.get('nodes',[])+n.get('floating_nodes',[]):walk(c)
 walk(json.loads(q.stdout));return out
def inputs():
 q=subprocess.run(['swaymsg','-r','-t','get_inputs'],env=ENV,capture_output=True,text=True,timeout=3);q.check_returncode()
 return [{k:d.get(k) for k in ['identifier','type','name']} for d in json.loads(q.stdout)]
def shot(name):
 env=dict(ENV);p=next(p for p in Path('/run').glob('**/wayland-*') if p.is_socket());env.update(XDG_RUNTIME_DIR=str(p.parent),WAYLAND_DISPLAY=p.name)
 q=subprocess.run(['grim',str(R/(name+'.png'))],env=env,capture_output=True,timeout=5);q.check_returncode()
def same(row):return any(p['pid']==row['pid'] and p['start']==row['start'] and p['role']==row['role'] for p in procs())

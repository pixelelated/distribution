import sys
sys.path.insert(0,'/tmp/pix-qa615')
from common import *
import signal,selectors,struct
sel=selectors.DefaultSelector();opened={};owners={};guards=[];error=None;start=time.monotonic();nxt=0
try:
 while time.monotonic()-start<240 and not (R/'stop').exists():
  now=time.monotonic()
  for p in Path('/dev/input').glob('event*'):
   if str(p) in opened:continue
   try:fd=os.open(p,os.O_RDONLY|os.O_NONBLOCK)
   except OSError:continue
   opened[str(p)]=fd;sel.register(fd,selectors.EVENT_READ,str(p));record('input.jsonl',{'opened':str(p),'name':Path('/sys/class/input',p.name,'device/name').read_text().strip()})
  for k,_ in sel.select(.05):
   try:data=os.read(k.fd,struct.calcsize('llHHi')*128)
   except OSError:
    sel.unregister(k.fd);os.close(k.fd);opened.pop(k.data,None);continue
   for sec,usec,typ,code,val in struct.iter_unpack('llHHi',data):
    if typ==1 or (typ==0 and code==3):record('input.jsonl',{'device':k.data,'type':typ,'code':code,'value':val})
  if now<nxt:continue
  nxt=now+1;rows=procs();mem={k:int(v.split()[0]) for l in Path('/proc/meminfo').read_text().splitlines() for k,v in [l.split(':',1)]}
  psi=Path('/proc/pressure/memory').read_text();avg=max(float(l.split('avg10=')[1].split()[0]) for l in psi.splitlines())
  record('samples.jsonl',{'processes':rows,'available_kib':mem['MemAvailable'],'memory_psi':psi,'focus':focus(),'inputs':inputs()})
  (R/'heartbeat.json').write_text(json.dumps({'at':time.monotonic(),'pid':os.getpid(),'guards':len(guards)}))
  for row in rows:
   if row['role']!='cloud-signin-window':continue
   ident=(row['pid'],row['start'])
   if ident not in owners:owners[ident]=(row,os.pidfd_open(row['pid']),now)
   reason='90s_deadline' if now-owners[ident][2]>=90 else 'low_memory' if mem['MemAvailable']<160*1024 or (avg>5 and mem['MemAvailable']<256*1024) else None
   if reason and same(row):
    signal.pidfd_send_signal(owners[ident][1],signal.SIGTERM);guards.append({'reason':reason,'pid':row['pid']});record('guard.jsonl',guards[-1])
 if not (R/'stop').exists():error='observer_deadline'
except BaseException as exc:error=repr(exc);raise
finally:
 # Fail-safe acts only on a browser identity this guard observed.
 for row,fd,_ in owners.values():
  if same(row):
   signal.pidfd_send_signal(fd,signal.SIGTERM);guards.append({'reason':'observer_cleanup','pid':row['pid']});record('guard.jsonl',guards[-1])
  os.close(fd)
 for k in list(sel.get_map().values()):sel.unregister(k.fd);os.close(k.fd)
 (R/'observer-result.json').write_text(json.dumps({'error':error,'guards':guards,'rc':int(bool(error or guards)),'elapsed':time.monotonic()-start}))
raise SystemExit(int(bool(error or guards)))

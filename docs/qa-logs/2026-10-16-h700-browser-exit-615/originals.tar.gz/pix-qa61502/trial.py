import sys
sys.path.insert(0,'/tmp/pix-qa61502')
from common import *
case=sys.argv[1];start=time.monotonic();row=None;result={'case':case,'actions':[]};error=None
sys.path.insert(0,'/usr/bin')
n={'__name__':'qa615_keyboard','__file__':'/usr/bin/cloud_oauth'};exec(compile(Path('/usr/bin/cloud_oauth').read_text(),'/usr/bin/cloud_oauth','exec'),n);n['log']=lambda message:None
try:
 while time.monotonic()-start<140:
  rows=[r for r in procs() if r['role']=='cloud-signin-window']
  assert len(rows)<=1
  if rows:row=rows[0];break
  time.sleep(.1)
 assert row,'launch_timeout';seen=time.monotonic();result['browser']=row;result['observed']=seen
 while time.monotonic()-seen<42:time.sleep(.1)
 assert same(row),'browser_closed_before_input'
 hb=json.loads((R/'heartbeat.json').read_text());assert time.monotonic()-hb['at']<3 and hb['guards']==0
 result['focus_before']=focus();shot(case+'-before')
 if case!='normal-close':
  assert any(w['pid']==row['pid'] and w['focused'] for w in result['focus_before']),'browser_not_focused'
  for mode in ['instant','settled']:
   if not same(row):break
   k=n['RemoteKeyboard']();t=time.monotonic()
   try:
    if mode=='settled':assert k.open();time.sleep(2)
    assert same(row)
    assert any(w['pid']==row['pid'] and w['focused'] for w in focus())
    if mode=='settled':record('actions.jsonl',{'case':case,'mode':mode,'inputs_before':inputs()})
    pressed=k.press('escape')
    if mode=='settled':time.sleep(1)
   finally:k.close()
   time.sleep(2);live=same(row);a={'mode':mode,'at':t,'pressed':pressed,'live_after':live,'elapsed':time.monotonic()-t};result['actions'].append(a);record('actions.jsonl',a);shot(case+'-'+mode+'-after')
 if same(row):
  t=time.monotonic();assert t-seen<65
  q=subprocess.run(['/usr/bin/cloud_oauth','close'],capture_output=True,timeout=18)
  result['actions'].append({'mode':'normal-close','at':t,'rc':q.returncode,'elapsed':time.monotonic()-t,'live_after':same(row)});record('actions.jsonl',result['actions'][-1])
 time.sleep(3);result.update(live_final=same(row),focus_final=focus(),processes_final=procs(),guards=(R/'guard.jsonl').exists());shot(case+'-final')
 assert not result['live_final'] and not result['guards']
except BaseException as exc:
 result['error']=repr(exc);raise
finally:
 result['elapsed']=time.monotonic()-start
 (R/(case+'-result.json')).write_text(json.dumps(result,indent=2))

"""UNRUN read-only installed-byte contract shared by driver and observer."""
import hashlib
import json
from pathlib import Path
import os
import re

BINDING=Path('/run/pix588-installed-inputs/binding.json')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify(expected_sha):
    assert re.fullmatch('[0-9a-f]{64}',expected_sha) and sha(BINDING)==expected_sha,'input binding changed'
    b=json.loads(BINDING.read_text());assert b['schema']==1
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==b['boot_id'],'wrong allocated clean boot'
    assert sha('/flash/syslinux.cfg')==b['boot_config_sha256'],'boot configuration changed'
    assert b['source_receipt']['clean_ready_report_verified'] is True
    assert b['safeguards'] in ('outer-vm','kernel-cgroups') and b['outer_receipt']['boot_id']==b['boot_id']
    root=Path(b['module_root']);assert root.is_absolute() and root.resolve(strict=True)==root
    assert str(root).startswith('/usr/lib/python') and str(root).endswith('/site-packages/raofflineproxy')
    children=list(root.rglob('*'));assert len(children)<2048 and not any(p.is_symlink() for p in children)
    actual={str(p) for p in root.rglob('*.pyc')}
    expected={p for p in b['files'] if p.endswith('.pyc')}
    assert actual==expected and not list(root.rglob('*.py')),'installed bytecode set differs'
    mounts=[line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()]
    for name,r in b['files'].items():
        path=Path(name);target=path.resolve(strict=True)
        assert name.startswith(('/usr/','/etc/')) and str(target)==r['resolved_path']
        assert path.stat().st_size==r['bytes'] and path.stat().st_mode & 0o7777==r['mode']
        assert sha(path)==r['sha256'],'installed bytes differ: '+name
        assert not any(m not in ('/','/usr','/etc') and (name==m or name.startswith(m+'/')) for m in mounts),'overlaid product path: '+name
    for forbidden in ('LD_LIBRARY_PATH','LD_PRELOAD','PYTHONHOME','PYTHONOPTIMIZE'):
        assert not os.environ.get(forbidden),'loader override '+forbidden
    return b

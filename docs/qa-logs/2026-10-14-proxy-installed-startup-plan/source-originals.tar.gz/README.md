# #588 installed startup follow-up — source only, UNRUN

One candidate-only continuation of the accepted actual-main startup proof. No VM,
service, controller, socket, import of product code, build, or fixture has run.
The accepted baseline02, candidate02 and ten component cases remain accepted;
this packet does not invoke them. It is separate from the retained-state fixture,
which intentionally leaves offlineproxy off and seeds no proxy queue.

The live #588 last criterion is installed composed-source service proof on normal
boot. This packet uses the real `/usr/lib/systemd/system/raofflineproxy.service`,
`/usr/bin/raofflineproxy-ctl`, `/etc/profile` helpers, installed `.pyc` and native
ELF. The unit ConditionPathExists, ExecStart, ExecStartPost, restart policy and
worker timers are unchanged. No product source, library, profile or controller is
copied over the image. No baseline rerun, component matrix or native codec matrix
is added. The latter remains separate #583/#584 work.

The runtime drop-in adds the existing observer, synthetic private `/storage` for
the service, an owner dependency, resource limits and an ExecStartPre kernel-limit
check. Its sole PYTHONPATH entry is this packet's bootstrap observer directory;
no product source path is present. The driver uses actual installed controller
commands in the guest's normal namespace. Its marker is therefore the original
unit condition's actual marker. The controller temporarily changes only its three
ordinary toggle/hardcore settings in the fresh guest, then disables and restores
their original presence/values. Queue/key/accounts stay in private scratch storage;
no existing proxy data is read. This verifies controller settings logically, not
whole system.cfg byte preservation. Default clean-state acceptance must precede
this fixture; root stops ES first so it cannot write those settings concurrently.

The accepted audit guard and synthetic peer remain; the explicit substitutions
are installed-library discovery (now final-image hashes), no-NIC loopback-interface
availability, and a bounded scheduling barrier at the actual first monitor probe.
No probe result, flush, queue, signing, timer or shutdown function is replaced.
The profiler selects the module's verified installed `__file__`, because `.pyc`
retains a source `co_filename`; no bytecode import shim or source loader is needed.
It explicitly loads the installed native bridge and records mappings/identity.
That proves loader closure only, not hash/codec correctness.

Sequence: reject an already running/overridden service or occupied port; observe
default off; prove absent marker skips startup; real controller enable; identified
cached login/readiness; queue one genuinely signed synthetic award through HTTP;
controller stop and exact-row preservation; arm gate and controller start while
still enabled; observe main false, hold first monitor probe, open local peer then
release; require one flush/one applied award, empty queue, and the next natural
15-second online probe without duplication; real clean stop, joins before SQLite
close, integrity check, no listener/thread/child leftovers; controller disable and
flag restoration. Every original command exit and systemd service exit is retained.
No historical negative receipt is relabelled.

## Bind final bytes, then admit one fresh default-boot guest

Can this be done on the VM? Yes. Root records the allocation before runtime. Use
one fresh engineering GENERIC_X64 no-NIC guest, 4 vCPU / 8 GiB / 16 GiB+ disk, with
untouched boot files. Run the existing ready first-boot clean checker first. Capture
its original passing JSON, boot ID and actual final source/build custody. Stop ES
under that same owner before this continuation. No guest or runtime is allocated
here. Existing first-boot command (from actual frozen checkout):

```sh
docs/qa-logs/2026-10-13-clean-state-565/run-first-boot.sh "$TASK_CLEAN_OWNER" "$TASK_SERIAL"
```

`bind-image.py` is an UNRUN read-only host preparer. It hashes only the listed final
SYSTEM files/module tree and supplied receipts. Supply a bounded extracted final
SYSTEM tree, never the SDK or a guest path. It resolves image-absolute symlinks
inside that tree. Bind the original image's extracted syslinux.cfg separately.

```sh
python3 -I -S -B "$TASK_PACKET/bind-image.py" \
  --root "$TASK_FINAL_SYSTEM_ROOT" --source-receipt "$TASK_SOURCE_RECEIPT" \
  --clean-report "$TASK_CLEAN_JSON" --boot-config "$TASK_BOOT_CONFIG" \
  --image-sha256 "$TASK_IMAGE_SHA" --distribution-commit "$TASK_COMMIT" \
  --boot-id "$TASK_BOOT_ID" --safeguards outer-vm \
  --outer-receipt "$TASK_OUTER_RECEIPT" --output "$TASK_INPUTS/binding.json"
```

The source receipt is a coordinator-reviewed custody summary of actual final build
receipts, not a tool-generated assertion of build success. Required schema is
`source-receipt.example.json`. It must bind all 112 prepared sources including
proxy_service SHA `432bb07a…`, actual bytecompile success, installed pyc path/hash
set, current native pins, final strip/output chain and original clean report.
List underlying evidence paths, bytes and SHA256; preserve those originals outside
this tiny packet. The final ELF need not equal unstripped component ELF
`6349b150…`; its transformation must be reviewed. The preparer cross-checks final
ELF, commit, source hash and clean report identity. Root must verify the underlying
receipts, not merely mark the review booleans true. The runtime validates final
image bytes, not the truth of a fabricated custody declaration. Reports retain
`source_pins_verified:false` to avoid conflating an identity check with rebuilding.

Stage this sealed packet read-only at `/run/pix588-installed-packet`, its binding
read-only at `/run/pix588-installed-inputs/binding.json`. Record SHA256SUMS and the
binding's independently retained SHA. No prepared Python or native overlay is an
input. Provision one empty dedicated 64 MiB tmpfs at
`/run/pix588-installed-owner` with at least 48 MiB free. Retain 16 MiB elsewhere
for export. Use the explicit `outer-vm` safeguard selection shown above for
known default hybrid topology: VM20 has v1 pids/systemd plus unified, but no
memory controller because MEMCG_V1 is disabled. This is a fixture safeguard
limitation, not a proxy failure. No boot argument is changed.

The reviewed outer receipt binds the same clean boot to the actual 4-vCPU/8-GiB
no-NIC QEMU PID/start identity, actual host cgroup cap or explicit null when absent, live watched
owner, 310-second command watchdog and 10-second cleanup grace. Record actual host
values, never select them only by filename. `outer-receipt.example.json` lists its
required schema; preserve original host observations in its evidence list. Root
must verify the host facts, since guest code cannot independently inspect the
host's proc/cgroup namespace. Owner and service have independently read-back hard
per-process AS/CPU/file/core limits; default cgroup process tracking supplies the
census, sampled every second during waits, and all owned children are reaped.
Guest RAM is bounded by the existing QEMU allocation. A host cgroup cap is recorded
only when actually present; this fixture does not invent one or require a new
allocation mechanism. Scratch is 64 MiB; individual files are capped at 4 MiB. Driver/owner/outer deadlines
are independent. This path expressly makes **no kernel per-service memory/task cap
claim**. It is selected in the immutable binding, never by automatic downgrade.

`--safeguards kernel-cgroups` is a separate explicit option if actual default-boot
memory+pids controller enforcement exists. It reads v2 memory.max/pids.max or v1
memory.limit_in_bytes/pids.max, actual PID membership and kernel event counters.
Use the same owner command with additional `--property=MemoryMax=1G` and
`--property=TasksMax=128`; service caps are then 512 MiB/64 tasks. Missing controllers
produce GuardLimitation before service startup; do not retry with a changed boot.

After root's watched VM lifecycle and outer deadline are established, the exact
inner owner command is:

```sh
systemd-run --unit=pix588-installed-owner.service --wait --pipe \
  --property=Type=exec --property=RuntimeMaxSec=280 --property=TimeoutStopSec=20 \
  --property=KillMode=control-group --property=LimitAS=1G --property=LimitCPU=150 \
  --property=LimitFSIZE=4M --property=LimitCORE=0 \
  /usr/bin/python3 -I -S -B /run/pix588-installed-packet/owner.py \
  --output /run/pix588-installed-owner/run01 --binding-sha256 "$TASK_BINDING_SHA"
```

Expected causal segment is about 30 seconds; work deadline remains 240 s, cleanup
30 s, owner child wait 272 s, unit lifetime 280 s + 20 s stop. Root's outer command
must retain original exit and enforce 310 s + 10 s cleanup, within its separately
admitted full VM lifecycle. Do not reuse an owner name/directory from a failed
attempt. The selected outer-vm path has service AS 512 MiB/CPU 120 s/file 4 MiB/core 0;
owner AS 1 GiB/CPU 150 s/file 4 MiB/core 0; driver AS 768 MiB/CPU 120 s/file 4 MiB.
Service 64/owner 128 tasks are observed limits here, not enforced kernel task caps.
A process or thread anomaly fails original receipts; the outer VM allocation/watchdog remains the
backstop; a host cgroup cap is not presumed. The optional cgroup path adds actual kernel memory/task caps.

Require payload result PASS, original child/owner/systemd-run/outer lifecycle exits
0, no cleanup errors/interventions, preserved before/after controller values,
exact signed-row preservation through initial stop, one synthetic application,
actual readiness/listener/PID identity and final SQLite integrity. Export original
payload/owner receipts, complete command exits, service logs, binding, bytecode
identity, native mappings and cgroup observations before unmount/retirement.
Root verifies actual owners are gone and consumes admission. No retry in place.

Remaining prerequisites are final built image/custody hashes, untouched clean
report/boot ID, verified actual default cgroup layout and exclusive runtime owner. The explicit outer-vm path is prepared for the known default lack of a memory
controller; it must receive its own actual reviewed owner receipt before allocation
is released. This is not a new product or release requirement.
The old installed/native runner is not reusable unchanged: historical image and
paths are hardcoded. The old service packet rejects .pyc and requires a staged
source PYTHONPATH and private v2 boot. This additive derivative changes those
boundaries explicitly and retains accepted peer/gate/owner/process controls.
This plan does not delay compilation or establish an RC PASS.

#!/usr/bin/env python3
"""UNRUN: bind final image bytes and coordinator-reviewed build/clean receipts; never launch."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import os
import re

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--root',type=Path,required=True,help='bounded extracted final SYSTEM root, not a guest or SDK')
p.add_argument('--source-receipt',type=Path,required=True,help='reviewed final source/bytecompile/native/post-strip custody receipt')
p.add_argument('--clean-report',type=Path,required=True,help='original passing untouched ready first-boot JSON for this boot')
p.add_argument('--boot-config',type=Path,required=True,help='exact final image syslinux.cfg, independently extracted')
p.add_argument('--image-sha256',required=True)
p.add_argument('--distribution-commit',required=True)
p.add_argument('--boot-id',required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--safeguards',choices=('outer-vm','kernel-cgroups'),required=True)
p.add_argument('--outer-receipt',type=Path,required=True,help='reviewed actual host VM/cgroup/watchdog receipt; schema in README')
a=p.parse_args()
assert re.fullmatch('[0-9a-f]{64}',a.image_sha256)
assert re.fullmatch('[0-9a-f]{40}',a.distribution_commit)
assert re.fullmatch('[0-9a-f-]{36}',a.boot_id)
root=a.root.resolve(strict=True);assert root != Path('/')
def sha(f): return hashlib.sha256(f.read_bytes()).hexdigest()
def resolve_image(name):
    # Resolve image-absolute links beneath root; never open a host /usr target.
    pending=list(PurePosixPath(name).parts[1:]); parts=[]; links=0
    while pending:
        item=pending.pop(0)
        if item in ('','.'):continue
        if item=='..':
            assert parts,'symlink escapes image';parts.pop();continue
        candidate=root.joinpath(*parts,item)
        if candidate.is_symlink():
            links+=1;assert links<=16
            target=os.readlink(candidate)
            if target.startswith('/'): parts=[]
            pending=list(PurePosixPath(target).parts)[int(target.startswith('/')):]+pending
        else:parts.append(item)
    result=root.joinpath(*parts);assert result.is_file()
    return result,'/'+str(result.relative_to(root))
def row(name):
    f,resolved=resolve_image(name)
    return {'path':name,'resolved_path':resolved,'sha256':sha(f),'bytes':f.stat().st_size,'mode':f.stat().st_mode & 0o7777}
roots=list((root/'usr/lib').glob('python*/site-packages/raofflineproxy'))
assert len(roots)==1 and roots[0].is_dir()
module=roots[0];children=list(module.rglob('*'))
assert len(children)<2048 and not any(f.is_symlink() for f in children)
assert not list(module.rglob('*.py'))
pycs=sorted(module.rglob('*.pyc'));assert 30<=len(pycs)<=112
names=['/'+str(f.relative_to(root)) for f in pycs]
names+=['/etc/os-release','/etc/profile','/etc/profile.d/001-functions','/usr/bin/python3',
        '/usr/bin/raofflineproxy-ctl','/usr/lib/systemd/system/raofflineproxy.service',
        '/usr/lib/autostart/daemons/006-raofflineproxy','/usr/bin/systemctl','/usr/lib/systemd/systemd']
libs={key:row(path) for key,path in {'rchash':'/usr/lib/libraproxy_rchash.so',
    'zstd':'/usr/lib/libzstd.so.1','crypto':'/usr/lib/libcrypto.so.3','systemd':'/usr/lib/libsystemd.so.0'}.items()}
for key,v in libs.items():v['soname']=Path(v['path']).name
names += [v['path'] for v in libs.values()]
receipt=json.loads(a.source_receipt.read_text())
# This file's schema is deliberately a coordinator review/custody assertion.
# It must identify real final package and strip receipts, not invent build success.
assert receipt['status']=='PASS' and receipt['distribution_commit']==a.distribution_commit
assert receipt['startup_source_sha256']=='432bb07ac6b0abcdcb38800d7c75a92c768b2b6bea583a1bab6834bb7f7b0d00'
assert receipt['prepared_python_files']==112
assert receipt['post_strip_rchash_sha256']==libs['rchash']['sha256']
assert receipt['package_build_original_exit']==0 and receipt['python_compile_original_exit']==0
assert receipt['pins']=={'raofflineproxy':'c7ebd1b6e777f3751ff0ecdf8aba54045844e00d','rcheevos':'1433173220a7eaede6a9ed7a18e94117be1821e0','libchdr':'607694ca0812edfc9cc2030c64634fc2393668de'}
assert receipt['reviewed_source_to_bytecode_and_strip_chain'] is True
assert isinstance(receipt['evidence'],list) and receipt['evidence']
for r in receipt['evidence']:
    assert re.fullmatch('[0-9a-f]{64}',r['sha256']) and r['bytes']>0 and r['path']
clean=json.loads(a.clean_report.read_text())
# Keep the checker's whole original report in this binding. Coordinator must
# supply its validated PASS JSON (not the serial wrapper's transport exit).
assert isinstance(clean,dict)
assert receipt['clean_report_sha256']==sha(a.clean_report) and receipt['clean_ready_report_verified'] is True
assert receipt['clean_boot_id']==a.boot_id
outer=json.loads(a.outer_receipt.read_text())
assert outer['status']=='PASS' and outer['boot_id']==a.boot_id
assert outer['vm_ram_bytes']==8589934592 and outer['vcpus']==4 and outer['no_nic'] is True
assert outer['host_cgroup_memory_max_bytes'] is None or isinstance(outer['host_cgroup_memory_max_bytes'], int) and outer['host_cgroup_memory_max_bytes'] > 0
assert outer['host_qemu_identity']['pid']>0 and outer['host_qemu_identity']['start_ticks']>0
assert outer['command_timeout_seconds']==310 and outer['cleanup_grace_seconds']==10
assert outer['watchdog_running'] is True and outer['evidence']
binding={'schema':1,'status':'BOUND_ONLY_RUNTIME_UNRUN','image_sha256':a.image_sha256,
 'distribution_commit':a.distribution_commit,'boot_id':a.boot_id,
 'safeguards':a.safeguards,'outer_receipt':outer,'outer_receipt_sha256':sha(a.outer_receipt),
 'module_root':'/'+str(module.relative_to(root)),'files':{name:row(name) for name in sorted(set(names))},
 'libraries':libs,'source_receipt':receipt,'source_receipt_sha256':sha(a.source_receipt),
 'clean_report':clean,'clean_report_sha256':sha(a.clean_report),'boot_config_sha256':sha(a.boot_config)}
assert not a.output.exists();a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(binding,indent=2)+'\n')
print(json.dumps({'binding_sha256':sha(a.output),'files':len(binding['files']),'bytecode_files':len(pycs),'runtime':False}))

#!/usr/bin/env python3
"""UNRUN, read-only cgroup enforcement admission for the disposable service proof."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

ROOT = Path('/sys/fs/cgroup')
SERVICE = 'raofflineproxy.service'
OWNER = 'pix588-installed-owner.service'


def need(value, reason):
    if not value:
        raise AssertionError(reason)


def read(path, cap=65536):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        need(stat.S_ISREG(os.fstat(fd).st_mode), 'nonregular kernel observation: ' + str(path))
        raw = bytearray()
        while True:
            chunk = os.read(fd, min(8192, cap + 1 - len(raw)))
            if not chunk:
                return raw.decode('ascii')
            raw.extend(chunk)
            need(len(raw) <= cap, 'kernel observation exceeds cap: ' + str(path))
    finally:
        os.close(fd)


class GuardLimitation(RuntimeError):
    """The default kernel cannot enforce this fixture's safeguards; not a proxy defect."""


def layout():
    need(os.geteuid() == 0 and 'QEMU' in read('/sys/class/dmi/id/sys_vendor'), 'disposable root QEMU only')
    need(read('/proc/1/comm').strip() == 'systemd', 'actual systemd PID1 required')
    need({p.name for p in Path('/sys/class/net').iterdir()} == {'lo'}, 'no-NIC guest required')
    args = read('/proc/cmdline').split()
    need(not any(a.startswith(('systemd.unified_cgroup_hierarchy=', 'systemd.legacy_systemd_cgroup_controller=', 'cgroup_no_v1=')) for a in args),
         'private cgroup boot overrides refused')
    mounts = []
    for line in read('/proc/self/mountinfo', 262144).splitlines():
        fields = line.split(); split = fields.index('-')
        if fields[split + 1] in ('cgroup', 'cgroup2'):
            mounts.append({'root': fields[3], 'path': fields[4], 'type': fields[split + 1],
                           'controllers': fields[split + 3].split(','), 'line': line})
    controllers = {}
    for mount in mounts:
        need(mount['root'] == '/', 'cgroup mount is a subtree')
        path = Path(mount['path']); need(path.resolve(strict=True) == path, 'cgroup mount alias')
        if mount['type'] == 'cgroup2':
            available = read(path / 'cgroup.controllers').split()
        else:
            available = mount['controllers']
        for key in ('memory', 'pids'):
            if key in available:
                need(key not in controllers, 'ambiguous kernel controller')
                controllers[key] = {'root': str(path), 'version': 2 if mount['type'] == 'cgroup2' else 1}
    return {'mounts': mounts, 'controllers': controllers, 'pid1_cgroup': read('/proc/1/cgroup').splitlines(),
            'cmdline': ' '.join(args), 'boot_id': read('/proc/sys/kernel/random/boot_id').strip()}


def controller_path(facts, controller, group):
    if controller not in facts['controllers']:
        raise GuardLimitation('default boot lacks ' + controller + ' enforcement for this fixture; proxy behavior untested')
    entry = facts['controllers'][controller]
    path = Path(entry['root']) / group.lstrip('/')
    return path, entry['version']


def tracking_path(facts, group):
    if 'pids' in facts['controllers']:
        return controller_path(facts, 'pids', group)[0]
    systemd = [m for m in facts['mounts'] if m['type'] == 'cgroup' and 'name=systemd' in m['controllers']]
    if not systemd:
        systemd = [m for m in facts['mounts'] if m['type'] == 'cgroup2']
    need(len(systemd) == 1, 'missing/ambiguous default process tracking hierarchy')
    return Path(systemd[0]['path']) / group.lstrip('/')


def members(group):
    need(group.startswith('/system.slice/') and group.endswith('/' + SERVICE), 'unexpected owned group')
    path = tracking_path(layout(), group)
    try: path.stat()
    except FileNotFoundError: return []
    found = set(); count = 0
    def fail(error): raise error
    for base, dirs, files in os.walk(path, onerror=fail):
        count += 1
        need(count <= 128 and 'cgroup.procs' in files, 'unreadable/unbounded owned group')
        found.update(int(v) for v in read(Path(base) / 'cgroup.procs').split())
    need(count > 0, 'cgroup observation empty')
    return sorted(found)


def identity(pid):
    text = read('/proc/' + str(pid) + '/stat')
    fields = text.rsplit(')', 1)[1].split()
    need(text.split(' ', 1)[0] == str(pid) and fields[0] != 'Z', 'PID absent/zombie/changed')
    return {'pid': pid, 'ppid': int(fields[1]), 'start_ticks': int(fields[19])}


def counters(path):
    pairs = [line.split() for line in read(path).splitlines()]
    need(all(len(p) == 2 and p[1].isdigit() for p in pairs), 'malformed cgroup counters')
    need(len({p[0] for p in pairs}) == len(pairs), 'duplicate cgroup counter')
    return {key: int(value) for key, value in pairs}


def observe(pid, unit, memory_bytes, tasks):
    need((unit, memory_bytes, tasks) in ((OWNER, 1073741824, 128), (SERVICE, 536870912, 64)),
         'unbound resource contract')
    facts = layout(); before = identity(pid); group = '/system.slice/' + unit
    membership = read('/proc/' + str(pid) + '/cgroup').splitlines()
    parsed = [line.split(':', 2) for line in membership]
    need(all(len(row) == 3 for row in parsed), 'malformed cgroup membership')
    binding = json.loads(read('/run/pix588-installed-inputs/binding.json', 1048576))
    need(binding['safeguards'] in ('outer-vm', 'kernel-cgroups'), 'no explicit safeguard selection')
    result = {'identity': before, 'group': group, 'membership': membership, 'layout': facts, 'limits': {},
              'safeguards': binding['safeguards'], 'kernel_per_service_memory_cap_claimed': binding['safeguards'] == 'kernel-cgroups'}
    if binding['safeguards'] == 'outer-vm':
        outer = binding['outer_receipt']
        need(outer['status'] == 'PASS' and outer['boot_id'] == facts['boot_id']
             and outer['vm_ram_bytes'] == 8589934592 and outer['vcpus'] == 4 and outer['no_nic'] is True
             and outer['watchdog_running'] is True and outer['command_timeout_seconds'] == 310
             and outer['cleanup_grace_seconds'] == 10, 'outer allocation receipt differs')
        limits = read('/proc/' + str(pid) + '/limits')
        for label, expected in [('Max address space', memory_bytes), ('Max cpu time', 150 if unit == OWNER else 120), ('Max file size', 4194304), ('Max core file size', 0)]:
            lines = [line[len(label):].split() for line in limits.splitlines() if line.startswith(label + ' ')]
            need(len(lines) == 1 and lines[0][:2] == [str(expected)] * 2, 'actual per-process limit differs: ' + label)
        tracking = tracking_path(facts, group)
        need(str(pid) in read(tracking / 'cgroup.procs').split(), 'PID absent from default tracking group')
        status = dict(line.split(':', 1) for line in read('/proc/' + str(pid) + '/status').splitlines() if ':' in line)
        need(int(status['Threads']) <= tasks, 'observed task bound exceeded')
        result['process_limits'] = limits
        result['observed_threads'] = int(status['Threads'])
        result['observed_rss'] = status.get('VmRSS', '').strip()
        result['outer_receipt_sha256'] = binding['outer_receipt_sha256']
        result['tracking_path'] = str(tracking)
        result['scope'] = '8GiB guest, process limits and watchdog; host cap recorded only if present; no kernel per-service cap'
        need(identity(pid) == before, 'PID identity changed')
        return result
    for key, expected in (('memory', memory_bytes), ('pids', tasks)):
        path, version = controller_path(facts, key, group)
        rows = [row for row in parsed if row[0] == '0' and row[1] == ''] if version == 2 else [row for row in parsed if key in row[1].split(',')]
        need(len(rows) == 1 and rows[0][2] == group, 'wrong ' + key + ' unit membership')
        need(path.resolve(strict=True) == path, 'unit controller alias')
        st = path.stat()
        need(str(pid) in read(path / 'cgroup.procs').split(), 'PID missing from kernel controller census')
        limit_name = 'memory.limit_in_bytes' if key == 'memory' and version == 1 else key + '.max'
        need(read(path / limit_name).strip() == str(expected), 'actual ' + key + ' limit not enforced')
        evidence = {'version': version, 'path': str(path), 'limit': expected, 'limit_file': limit_name}
        if key == 'memory' and version == 1:
            evidence['failcnt'] = int(read(path / 'memory.failcnt'))
            evidence['oom_control'] = counters(path / 'memory.oom_control')
            need(evidence['failcnt'] == 0 and evidence['oom_control'].get('under_oom') == 0
                 and evidence['oom_control'].get('oom_kill', 0) == 0, 'memory pressure/OOM in owned v1 group')
        else:
            evidence['events'] = counters(path / (key + '.events'))
            keys = ('oom', 'oom_kill', 'max') if key == 'memory' else ('max',)
            need(all(evidence['events'].get(k, 0) == 0 for k in keys), key + ' limit/OOM events')
        after = path.stat();need((st.st_dev, st.st_ino) == (after.st_dev, after.st_ino), 'controller group changed')
        result['limits'][key] = evidence
    need(identity(pid) == before and read('/proc/' + str(pid) + '/cgroup').splitlines() == membership, 'PID identity/membership changed')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--service-receipts', type=Path, required=True)
    args = parser.parse_args()
    out = args.service_receipts
    need(out.is_absolute() and out.resolve(strict=True) == out
         and out.name == 'payload' and out.parent.parent == Path('/run/pix588-installed-owner'),
         'receipt directory outside allocated payload')
    result = {'status': 'FAIL', 'role': 'ExecStartPre; main has not started', 'pid': os.getpid()}
    try:
        result['kernel'] = observe(os.getpid(), SERVICE, 536870912, 64)
        result['status'] = 'PASS'
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        with (out / ('cgroup-start-' + str(os.getpid()) + '.json')).open('x') as f:
            json.dump(result, f, indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())

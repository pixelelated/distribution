#!/usr/bin/env python3
"""UNRUN source preparer: fresh derivative only; preserves original sealed packet."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--original',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();source=a.original.resolve(strict=True);out=a.output.absolute()
assert not out.exists() and not out.is_symlink()
assert any(out.is_relative_to(root) for root in [Path('/tmp'),Path('/workspace/tmp')])
def sha(raw):return hashlib.sha256(raw).hexdigest()
binding=json.loads((HERE/'bindings.json').read_text())
manifest=(source/'SHA256SUMS').read_bytes()
assert sha(manifest)==binding['retained_manifest_sha256']
files={}
for line in manifest.decode().splitlines():
    digest,name=line.split('  ',1)
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    raw=(source/name).read_bytes();assert sha(raw)==digest
    files[name]=raw
assert {str(f.relative_to(source)) for f in source.rglob('*') if f.is_file()}==set(files)|{'SHA256SUMS'}
assert sha(files['guest-fixture.py'])==binding['guest_fixture_before_sha256']
patch=(HERE/'backup-timeout-receipt.patch').read_bytes();assert sha(patch)==binding['patch_sha256']
out.mkdir(parents=True,mode=0o700)
for name,raw in files.items():(out/name).write_bytes(raw)
(out/'original-SHA256SUMS').write_bytes(manifest)
r=subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(HERE/'backup-timeout-receipt.patch')],cwd=out,stdin=subprocess.DEVNULL,capture_output=True,timeout=10)
(out/'patch.stdout').write_bytes(r.stdout);(out/'patch.stderr').write_bytes(r.stderr)
(out/'patch.rc').write_text(str(r.returncode)+'\n')
assert r.returncode==0 and not r.stderr and b'offset' not in r.stdout and b'fuzz' not in r.stdout
assert sha((out/'guest-fixture.py').read_bytes())==binding['guest_fixture_after_sha256']
for name,raw in files.items():
    if name!='guest-fixture.py':assert (out/name).read_bytes()==raw
for f in out.glob('*.py'):ast.parse(f.read_bytes())
(out/'correction-provenance.json').write_text(json.dumps({'status':'PREPARED_ONLY_UNRUN','original_manifest_sha256':sha(manifest),'patch_sha256':sha(patch),'guest_before_sha256':binding['guest_fixture_before_sha256'],'guest_after_sha256':binding['guest_fixture_after_sha256'],'only_existing_file_changed':'guest-fixture.py','patch_original_exit':r.returncode},indent=2)+'\n')
new=''.join(sha(f.read_bytes())+'  '+str(f.relative_to(out))+'\n' for f in sorted(out.rglob('*')) if f.is_file())
(out/'SHA256SUMS').write_text(new)
print(json.dumps({'status':'PREPARED_ONLY_UNRUN','output':str(out),'manifest_sha256':sha(new.encode())}))

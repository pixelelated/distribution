#!/usr/bin/env python3
"""Materialize small plans only. Does not reserve, copy, compile, or submit work."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

PARENT = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01')
ROOT = 'build.pixelelated-GENERIC_X64.x86_64'
CONTAINER = '/workspace/repos/rocknix.worktrees/m7-pixelelated'
GIB = 1024 ** 3

TEMPLATE_COMMIT = '47dda767c7afc47020a3f21ab19a4493bfd5ff8a'
PRODUCT_PATHS = ['projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_gc.sh', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_wii.sh', 'projects/ROCKNIX/packages/ui/emulationstation/package.mk', 'projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh']
PRODUCT_SHA256 = {'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh': '01473794711dafd9607e1b6894ec482e34820807b81e1c45c352d5da9768c28a', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_gc.sh': 'b5e7afb8f3952f8082d4f39c70cffb9e5ccbd7a265cc6c28f1e96aefbb31c568', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_wii.sh': '8843d7358f948add1c53851cef2cfb2da2cd93141ad14784c46252bffbada3d7', 'projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh': '1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk': 'cc4e7458e99329518b30b7f78aa38e149d083427f3c8b7e22d7f5e1090d2479b'}
PRODUCT_ROOTS = ['packages', 'projects', 'config', 'scripts', 'distributions', 'Makefile']


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkout', type=Path, required=True)
    p.add_argument('--commit', required=True)
    p.add_argument('--es-recipe-sha256', required=True, help='Independently reviewed final ES recipe SHA256; only this product input may differ from the template')
    p.add_argument('--expected-es', required=True, help='Exact reviewed ES commit required in the frozen distribution recipe')
    p.add_argument('--measurement', type=Path, required=True)
    p.add_argument('--owner', type=Path, required=True)
    p.add_argument('--stage', choices=['transfer', 'build'], required=True)
    a = p.parse_args()
    tree = a.checkout.resolve(strict=True)
    owner = a.owner.resolve(strict=True)
    measurement = a.measurement.resolve(strict=True)
    assert str(tree) == '/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02'
    assert re.fullmatch('[0-9a-f]{40}', a.commit)
    assert re.fullmatch('[0-9a-f]{64}', a.es_recipe_sha256)
    product_sha256 = dict(PRODUCT_SHA256)
    product_sha256['projects/ROCKNIX/packages/ui/emulationstation/package.mk'] = a.es_recipe_sha256
    assert a.expected_es == '16dbac5211eea7e70db7394372033be2be7df829', 'reviewed #593 ES source required'
    assert git(tree, 'rev-parse', 'HEAD') == a.commit
    assert git(tree, 'branch', '--show-current') == 'build/m7-p5-20261015-02'
    assert not git(tree, 'status', '--porcelain'), 'freeze a clean source first'
    assert set(git(tree, 'diff', '--name-only', TEMPLATE_COMMIT, a.commit, '--', *PRODUCT_ROOTS).splitlines()) <= {'projects/ROCKNIX/packages/ui/emulationstation/package.mk'}, 'additional product inputs changed: review/reseal first'
    assert git(tree, 'diff', '--name-only', 'd4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a', a.commit, '--', *PRODUCT_ROOTS).splitlines() == PRODUCT_PATHS
    assert all(hashlib.sha256((tree / path).read_bytes()).hexdigest() == digest for path, digest in product_sha256.items())
    assert git(tree, 'merge-base', '--is-ancestor', a.commit, 'origin/next') == ''
    recipe = tree / 'projects/ROCKNIX/packages/ui/emulationstation/package.mk'
    recipe_bytes = recipe.read_bytes()
    assert re.findall(r'^\s*PKG_VERSION=(.*)$', recipe_bytes.decode(), re.M) == ['"' + a.expected_es + '"'], 'expected exact ES pin missing or ambiguous'
    es_recipe_sha256 = hashlib.sha256(recipe_bytes).hexdigest()
    for patch in ['020-rvz-padding-preserve-partial-word.patch', '021-flush-reconnect-during-startup.patch']:
        assert (tree / 'projects/ROCKNIX/packages/network/raofflineproxy/patches' / patch).is_file()
    assert owner.is_dir() and owner.stat().st_dev == tree.stat().st_dev
    m = json.loads(measurement.read_text())
    age = datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(m['utc_finish'])
    assert 0 <= age.total_seconds() <= 86400, 'refresh current allocation measurement'
    allocated = {r['path']: r['allocated_bytes'] for r in m['measurements']}
    base = allocated[str(PARENT / ROOT)]
    assert m['parent_head'] == 'd4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a'
    assert hashlib.sha256(Path(m['original_allocation_log']).read_bytes()).hexdigest() == m['original_allocation_log_sha256']
    assert base > 0 and str(PARENT / 'target') in allocated
    assert '/workspace/cache/rocknix-sources' in allocated
    scan = owner / 'empty-retention-scan'
    scan.mkdir()
    terms = ({'custody_receipts_and_metadata': 1 * GIB, 'operating_margin': 64 * GIB}
             if a.stage == 'transfer' else
             {'additional_warm_package_growth': max(base // 3, 32 * GIB),
              'source_download_growth': 8 * GIB, 'firmware_outputs': 16 * GIB,
              'immediate_clean_and_upgrade_qa': 32 * GIB, 'operating_margin': 64 * GIB})
    stage = 'm7-audit-corrections-' + a.stage
    retention = {'volume': '/workspace', 'scan_roots': [str(scan)], 'reference_stores': [],
                 'protected': [str(PARENT), str((PARENT if a.stage == 'transfer' else tree) / ROOT), str(PARENT / 'target'),
                               '/workspace/cache/rocknix-sources', str(measurement)],
                 'candidates': [], 'builds': [{'name': stage, 'terms_bytes': terms,
                     'basis': 'Completed predecessor final quiescent allocation sample plus explicit growth/QA/margin allowances. '
                              'Existing source cache and parent payloads already reduce f_bavail; no reclamation counted. '
                              'No deletion candidates; the empty explicit scan is not historical-volume classification.',
                     'evidence': [{'path': str(measurement), 'sha256': hashlib.sha256(measurement.read_bytes()).hexdigest()},
                                  {'path': m['original_allocation_log'], 'sha256': m['original_allocation_log_sha256']}]}]}
    outputs = [{'path': str(tree / ROOT), 'issue': 596, 'kind': 'build-cache',
                'release_when': 'Immediately queued assembled-image qualification and required corresponding-source custody accepted'}]
    if a.stage == 'build':
        outputs += [{'path': str(tree / n), 'issue': 596, 'kind': 'firmware',
                     'release_when': 'Clean and retained-storage engineering qualification and compact image/source record accepted; review next immediate consumer'}
                    for n in ['release', 'target']]
        outputs += [{'path': str(tree / n), 'issue': 493, 'kind': 'qa-scratch',
                     'release_when': 'Original results consumed and compact build records retained; generated staging no longer needed'}
                    for n in ['.doc_cache', '.es_cache', '.build-runs']]
    outputs += [{'path': str(owner), 'issue': 493, 'kind': 'qa-scratch',
                 'release_when': 'Original results consumed and compact evidence retained; preserve required corresponding-source inputs'}]
    admission = {'checkout': str(tree), 'container_checkout': CONTAINER,
                 'retention_plan': str(owner / 'retention-plan.json'),
                 'retention_report': str(owner / 'retention-report.json'), 'stage': stage,
                 'profiles': [{'PROJECT': 'ROCKNIX', 'DEVICE': 'GENERIC_X64', 'ARCH': 'x86_64'}],
                 'outputs': outputs}
    write(owner / 'retention-plan.json', retention)
    write(owner / 'admission-plan.json', admission)
    write(owner / 'planning-inputs.json', {'commit': a.commit, 'tree': git(tree, 'rev-parse', 'HEAD^{tree}'),
          'es_commit': a.expected_es, 'es_recipe_sha256': es_recipe_sha256, 'product_sha256': product_sha256,
          'warm_parent': str(PARENT), 'container_checkout': CONTAINER,
          'stage': stage, 'required_bytes': sum(terms.values()), 'admission_prepared': False})
    print(json.dumps({'owner': str(owner), 'required_bytes': sum(terms.values()),
                      'next': 'watched retention-report, then fresh admission prepare and submit'}))


if __name__ == '__main__':
    main()

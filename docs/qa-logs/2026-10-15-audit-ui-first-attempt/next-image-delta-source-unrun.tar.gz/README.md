# Next integrated engineering image — SOURCE ONLY, UNRUN

This is a narrow derivative of the accepted 2026-10-15 engineering build and artifact reader. Private owner: `/tmp/pix-m7-next-image-delta-20261015-02`. No preparer, dependency census, cache move, worktree creation, admission, compiler, VM, image reader, service, commit or shared-record edit occurred. Only source/original-receipt reads, this packet, Python AST checks and shell syntax checks were performed.

Final distribution commit and ES recipe hash remain null in `inputs.json`. At later execution root supplies the actual reviewed, committed, published source and final reviewed ES recipe SHA. This retains the predecessor's origin/next ancestor guard. The reviewed target ES pin is exactly `16dbac5211eea7e70db7394372033be2be7df829`; its frontend proof, source publication and pin integration must precede freezing. Current four script hashes come from actual committed d9054efc463387df3f0211481c5ae8c793dfadc8, not predicted future bytes. Any further product change beyond the five declared paths requires review and a new immutable packet.

Can this be proved on the VM? Installed behavior: yes. Cross-compilation uses the existing qualified nonroot Docker builder. Full audit closure is not a circular precondition for an engineering image required by remaining installed criteria; applicable completed audit remains required before H700/SM8550/RC progression.

## Exact invalidation and stage choice

| Item | Canonical handling |
|---|---|
| `dolphin-sa` three script changes | `clean-dolphin-sa` then `build-dolphin-sa`. Whole-package deep hash includes scripts. `scripts/build:49–64` invalidates build stamp; `scripts/unpack:35–59` compares unpack hash and calls `scripts/clean`. Clean removes owned Dolphin build/install trees and `.stamps/dolphin-sa/build_*`. Merely avoiding explicit clean does not preserve the engine. |
| ES pin3178→16dbac | One `build-emulationstation` package stage. Its new package hash/version makes normal unpack clean the old ES trees/stamp and build the exact new pin. No second explicit ES clean is needed. |
| `emulators` / Steam invocation | Standard non-DIRTY image `CLEAN_OS_BASE` regenerates this manual package and generated catalog. No separate Steam/FEX package compile. |
| `.stamps/image/build_target` | The accepted owner unlinks this one destination stamp immediately before its normal image stage. |
| `image/.stamps` and `image/system` | Recreated through standard build_distro/image/install; no piecemeal copy into a prior SYSTEM. |
| Qt, Flycast, proxy, GStreamer and unrelated libraries | No explicit clean/rebuild added. Normal matching caches and standard image housekeeping apply. |

Root explicitly accepted retaining the ordinary rebuild if no qualified install-only path existed. The scoped tools/Makefile/scripts search found no such path. **No stamp rewrite, manual ELF injection, install-only bypass or product change is proposed.** Unchanged Dolphin engine source does not defeat package invalidation.

The concrete existing Docker stage list is now:

1. `PACKAGE=dolphin-sa make docker-package-clean` (4 CPU /24 GiB)
2. `PACKAGE=dolphin-sa make docker-package` (4 CPU /24 GiB)
3. `PACKAGE=emulationstation make docker-package` (4 CPU /24 GiB)
4. `make docker-GENERIC_X64` (24 CPU /40 GiB), non-DIRTY

The derivative `build-owner.py` runs those canonical targets through unchanged `inner-build.py` and `host-resources.py`, retaining actual UID/GID, private TMPDIR/mktemp, affinity, memory/no-swap/2048 PID limits, nonce/CID handshakes, source/helper identities, current preflight, original subprocess/runner/container/resource outcomes and cleanup. Original7200s family remains; no extension in flight. The ES stage uses the already qualified narrow package resource profile. No new runner framework.

Predecessor original measurements (not a forecast): clean Dolphin1.002s; Dolphin build86.119s at4CPU with8,140,591,104B cgroup peak; image129.162s at24CPU with31,683,936,256B peak. Owner elapsed272.633s including overhead/resource readback. The future new-pin ES package cost is additional and not measured by those rows. Exact receipt paths/hashes are in `inputs.json`. Existing24/40GiB ceilings,8GiB host floor,64GiB volume floor and warm-growth allowances remain unchanged.

## Custody and final binding

Proposed new identities, not allocated or reserved:

- Frozen checkout `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02`, branch `build/m7-p5-20261015-02`.
- Source cache is the actual completed d4af checkout `m7-p5-build-20261015-01/build.pixelelated-GENERIC_X64.x86_64`.
- Transfer owner `/workspace/tmp/pix-m7-next-cache-transfer-20261015-02`.
- Build owner `/workspace/tmp/pix-m7-engineering-build-20261015-02`.
- Artifact owner `/workspace/tmp/pix-m7-image-readback-20261015-02`.

Every destination must still be absent; if used meanwhile, review/reseal identities. Transfer remains single same-filesystem `renameat2(RENAME_NOREPLACE)`, no cache clone/copy/hardlinks/symlink alias/overwrite/rollback. Old target/release, tracked source and originals stay. Old-cache consumers include current compiler/GUI/audit/native prepared readers; root resolves/rebinds them and obtains fresh actual-host dependency evidence before transfer. This packet makes no process-absence claim.

`capacity-measurement.json` is derived verbatim from actual predecessor final_after_producer timestamps/rows; the cache measured125,592,469,504B. It is not a new scan or unchanged-current-occupancy assertion. Original log SHA and24-hour age guard remain. Refresh through the existing measurement workflow if stale/materially changed. No reclamation credit; current preflight/retention/admission determine capacity.

The five exact changed product paths are the three Dolphin scripts, ES package.mk, and Install Steam.sh. Current four script hashes are fixed; the final ES recipe hash is an explicit input. Dolphin recipe cc4e7458 is additionally bound unchanged for readback. Current record baseline47dda767 may be followed only by ES recipe and nonproduct records. `prepare-plan.py` checks actual d4af→final changed paths, all reviewed hashes, exact16dbac pin, branch/clean/source/publication. `prepare-owner.py` and transfer recheck the same bindings. No final image filename/hash is guessed.

## Later root commands — not executed

The exact dependency-assessment schema and original consumption procedure remain in `parent/engineering-README.md`; those historical identities are superseded only by the values below. Its old Sys-fix hold and old gameplay instructions are historical, not current dependencies. Do not execute old scripts/plans in parent/.

```bash
: "${TASK_COMMIT:?Actual final reviewed committed published distribution40hex}"
: "${TASK_ES_RECIPE_SHA:?Actual independently reviewed final ES package.mk SHA256}"
TASK_PACKET=/tmp/pix-m7-next-image-delta-20261015-02
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_ES=16dbac5211eea7e70db7394372033be2be7df829
TASK_TRANSFER=/workspace/tmp/pix-m7-next-cache-transfer-20261015-02
TASK_BUILD=/workspace/tmp/pix-m7-engineering-build-20261015-02
TASK_MEASUREMENT=$TASK_PACKET/capacity-measurement.json
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
git -C /workspace/repos/rocknix fetch origin next
git -C /workspace/repos/rocknix ls-remote --exit-code origin refs/heads/next
git -C /workspace/repos/rocknix merge-base --is-ancestor "$TASK_COMMIT" origin/next
git -C /workspace/repos/rocknix worktree add -b build/m7-p5-20261015-02 "$TASK_TREE" "$TASK_COMMIT"
mkdir -m 700 "$TASK_TRANSFER" "$TASK_BUILD"
cd "$TASK_TREE"
tools/build-preflight
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" \
  --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" --expected-es "$TASK_ES" \
  --measurement "$TASK_MEASUREMENT" --owner "$TASK_TRANSFER" --stage transfer
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_TRANSFER/retention-plan.json" --output "$TASK_TRANSFER/retention-report.json"
tools/watch-build --record-only -- python3 -I "$TASK_PACKET/dependency-readback.py" \
  --output "$TASK_TRANSFER/dependency-readback.json"
```

Root reviews original report/census channels and writes a new `dependency-assessed.json` using the unchanged schema: raw root/device/inode/actual namespace/observation epoch, original readback path/SHA, all errors/exemptions, resolved prepared consumers, no unexplained matches/admissions/overlapping mounts, and explicit stated scope. Never refresh its observation time or infer empty process scope from PASS. Transfer rechecks≤900s and actual source/target identity.

```bash
TASK_DEPENDENCY=$TASK_TRANSFER/dependency-assessed.json
TASK_DEPENDENCY_SHA=$(sha256sum "$TASK_DEPENDENCY")
TASK_DEPENDENCY_SHA=${TASK_DEPENDENCY_SHA%% *}
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_TRANSFER/admission-plan.json" --output "$TASK_TRANSFER/admission.json"
tools/watch-build-submit --owner "$TASK_TRANSFER" -- --admission "$TASK_TRANSFER/admission.json" \
  --activity-dir "$TASK_TRANSFER" -- python3 -I "$TASK_PACKET/transfer-cache.py" \
  --owner "$TASK_TRANSFER" --commit "$TASK_COMMIT" --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" \
  --dependency-readback "$TASK_DEPENDENCY" --dependency-sha256 "$TASK_DEPENDENCY_SHA"
# After all original transfer channels and actual owners are reviewed:
TASK_TRANSFER_RUN=$(cat "$TASK_TRANSFER/run.path")
python3 -I tools/host-maintenance/build-admission consume --run "$TASK_TRANSFER_RUN" \
  --evidence "$TASK_TRANSFER/consumption-evidence.json"
```

Root creates that consumption evidence from actual originals; no synthetic success record is supplied. Transfer120s, original outcomes, same inode/device, old cache absent/new present, old target preserved, no owner survivor are all unchanged. After exact consumption and fresh preflight:

```bash
tools/build-preflight
TASK_TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)
python3 -I "$TASK_PACKET/prepare-owner.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" \
  --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" --expected-es "$TASK_ES" --owner "$TASK_BUILD" \
  --cache-ready "$TASK_TRANSFER/cache-ready.json" --timestamp "$TASK_TIMESTAMP" --family-seconds 7200
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit "$TASK_COMMIT" \
  --es-recipe-sha256 "$TASK_ES_RECIPE_SHA" --expected-es "$TASK_ES" \
  --measurement "$TASK_MEASUREMENT" --owner "$TASK_BUILD" --stage build
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_BUILD/retention-plan.json" --output "$TASK_BUILD/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_BUILD/admission-plan.json" --output "$TASK_BUILD/admission.json"
tools/watch-build-submit --owner "$TASK_BUILD" -- --admission "$TASK_BUILD/admission.json" -- \
  python3 -I "$TASK_BUILD/build-owner.py"
```

Actively supervise original results. Keep pinned builder digest988c0ba5 and canonical container prefix `/workspace/repos/rocknix.worktrees/m7-pixelelated` required by cached compiler wrappers. No new parallel VM/compiler family. Consume only after four actual stage originals, resource/owner/container cleanup, runner/monitor/launcher and source identity checks pass; failures remain original.

## Artifact readback and affected installed scope

`readback/verify-image.py` derives from the actual accepted owner01 verifier, not a summary. Changes are the next owner/checkout/branch, exact four-stage requirement, and an explicit x64 Steam-installer absence check. All readers, disk/CRC/bootloader checks, raw/update SYSTEM+KERNEL identity, source/build metadata, installed bytes/modes/link chains, ELF/script/library/catalog/profile coverage, six Sys pinned-source hashes and original completed-build/admission/container checks remain.

After actual completed consumed build, root uses the **existing** readback owner workflow: create a fresh owner with empty `artifacts/` and `empty-scan/`; copy the three sealed readback source files together; materialize `inputs.json` from `readback/inputs.template.json` with actual build run, commit, timestamp, build-inputs SHA. Retain its original template. Rebind the unchanged actual retention/admission formats copied in parent/ to new owners, actual consumed build run and actual helper/input hashes, issue596. Preserve24GiB readback payload/records+8GiB margin. No new preparer or reader is supplied.

```bash
# Only after root materializes and reviews the fresh actual readback inputs/plans:
TASK_READBACK=/workspace/tmp/pix-m7-image-readback-20261015-02
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_READBACK/retention-plan.json" --output "$TASK_READBACK/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_READBACK/admission-plan.json" --output "$TASK_READBACK/admission.json"
tools/watch-build-submit --owner "$TASK_READBACK" -- --admission "$TASK_READBACK/admission.json" -- \
  bash "$TASK_READBACK/run.sh"
```

Reader remains CPU0,8GiB virtual address-space,16GiB per-file,1500s+15s grace. Root reviews exact originals/result/product rows and consumes separately. Relevant output mappings already present:

- `usr/bin/emulationstation`: actual image-staging/extracted bytes and actual16dbac package/source/run binding; preserve locale/catalog mappings, no assumed old ELF equality.
- `usr/bin/cheevos_dolphin.sh`, `usr/bin/start_dolphin_gc.sh`, `usr/bin/start_dolphin_wii.sh`: source-to-staged-to-SYSTEM, executable modes; launchers use existing Wayland/OGL/Qt-Wayland substitutions.
- Both Dolphin engines, defaults/profiles, six pinned Sys resources and exact `../../config/dolphin-emu` alias: new actual readback identity, unchanged source scope. No requirement to equal a guessed relink ELF.
- Steam installer is **absent** on GENERIC_X64 by emulators/package.mk:754–767; script ships on SM4450/SM8250/SM8550/SM8650/SM8750. This x64 image cannot claim installed ARM/FEX Steam proof. Preserve the actual source-bound isolated invocation/control evidence; selected-device payload readback remains separate.

Keep existing normal clean-install/default-loader and retained-storage upgrade lifecycles, rebound to actual new image/source. Affected checks are: actual ES16dbac Wi-Fi scan Back/reopen/normal-exit cleanup and unchanged presentation; native per-game core selection; Dolphin clean-disabled and retained enabled→disabled/logged-out generated INI transition with unrelated input/save settings retained, actual EN/FR publication-failure refusal/return flow, and normal enabled routing. Preserve synthetic-account/no-award scope and prior actual source-bound control results; do not repeat the entire accepted routing/Wi-Fi/browser/Steam matrices merely for a new build ID. Root owns exact composition of already qualified small fixtures and their original per-case bounds; build/artifact PASS does not satisfy runtime criteria.

Then execute the prepared four-launch state-only continuation `/tmp/pix-m7-native-states-20261015`, binding its actual final commit/verifier. It leaves accepted d4af ordinary-save/cold evidence in its exact historical scope and does not replay ordinary saves. The state packet's19 fixed source rows must still agree; no overlay. Any changed source beyond those reviewed rows needs explicit source rebind/review. No RC, physical operation, audit waiver or upstream submission follows from this packet.

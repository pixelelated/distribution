#!/usr/bin/env python3
"""UNRUN additive preparation of the qualified no-NIC native owner for eight UI frames."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;NATIVE=Path('/tmp/m7-native-gameplay-lifecycle-20261015-03');BUILD=Path('/workspace/tmp/pix-m7-wifi-compile-20261015-01');PROOF=Path('/tmp/pix-m7-wifi-normal-exit-20261015')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sealed(p,seal):
 assert sha(p/'SHA256SUMS')==seal
 for line in (p/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert not Path(n).is_absolute() and '..' not in Path(n).parts and sha(p/n)==h,n
p=argparse.ArgumentParser()
for n in ['checkout','verification','author-owner','owner']:p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--vnc',type=int,required=True);a=p.parse_args()
sealed(HERE,sha(HERE/'SHA256SUMS'));sealed(NATIVE,'c9d6faa5bb47950f5c73f947bf03fa925ba2fbdebc8a4d0c5ffb3824ae02379d');sealed(PROOF,'84e0fdd157206d39f90eb8d02e2f657110e5c7589b67c6f1f6c30272851ebf3f')
stage=BUILD/'stages/wifi-compile';result=json.loads((stage/'result.json').read_text());assert result['status']=='PASS' and result['original_attach_exit']==result['original_container_exit']==result['watchdog_original_exit']==0
assert result['cleanup']['status']=='PASS' and not result['cleanup']['forced_stop'] and not result['cleanup']['survivors']
watch=Path(json.loads((stage/'watch-run.json').read_text())['run']);consumed=json.loads((watch/'admission-consumed.json').read_text());assert consumed['id']=='fb99a646934245098e993ad4d78c90ab' and consumed['state']=='consumed' and all(consumed['original_result'][key]==0 for key in ['command_rc','monitor_rc','runner_rc'])
artifact=json.loads((stage/'target-artifact.json').read_text());assert artifact['candidate_es_commit']=='16dbac5211eea7e70db7394372033be2be7df829'
for row in artifact['artifacts']:
 path=BUILD/'work'/Path(row['path']).relative_to('/work');assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
# Reuse the already qualified preparer unchanged. It creates only a new owner.
argv=[sys.executable,'-I','-S','-B',str(NATIVE/'prepare.py')]
for n in ['checkout','verification','author-owner','owner']:argv+=['--'+n,str(getattr(a,n.replace('-','_')))]
argv+=['--vnc',str(a.vnc)];subprocess.run(argv,check=True,timeout=90)
out=a.owner;target=out/'source/audit-ui';target.mkdir()
for n in ['guest-audit.py','guest-wifi-observer.py','worker-observer.py','wifi-owner.py']:shutil.copy2(HERE/n,target/n)
shutil.copytree(HERE/'source',target/'source');shutil.copytree(PROOF,target/'worker-proof')
shutil.copy2(BUILD/'work/emulationstation',target/'emulationstation');shutil.copytree(BUILD/'work/drivers',target/'drivers')
shutil.copy2(HERE/'host-audit.py',out/'host-audit.py')
b=json.loads((HERE/'binding-template.json').read_text());b['candidate_es_sha256']=artifact['artifacts'][0]['sha256'];b['status']='PREPARED_UNRUN';b['drivers']={Path(row['path']).name:row for row in artifact['artifacts'][1:]}
b['packet_files']={str(f.relative_to(target)):sha(f) for f in sorted(target.rglob('*')) if f.is_file()};save(target/'binding.json',b)
for n,src in [('wifi-compile-artifact.json',stage/'target-artifact.json'),('wifi-compile-result.json',stage/'result.json'),('wifi-compile-consumed.json',watch/'admission-consumed.json')]:shutil.copy2(src,out/'records'/n)
c=json.loads((out/'config.json').read_text());c['code']['host-audit.py']=sha(out/'host-audit.py');c['source']={str(f.relative_to(out/'source')):sha(f) for f in sorted((out/'source').rglob('*')) if f.is_file()}
c['audit_ui']={'packet_seal':sha(HERE/'SHA256SUMS'),'binding_sha256':sha(target/'binding.json'),'candidate_es_sha256':b['candidate_es_sha256'],'candidate_es_commit':b['candidate_es_commit'],'candidate_product_commit':b['candidate_product_commit'],'panel':[640,480],'new_image_installed_acceptance':False};c['work_seconds']=1200;save(out/'config.json',c)
ret=json.loads((out/'retention-plan.json').read_text());ret['protected'] += [str(HERE),str(BUILD),str(PROOF)];ret['builds'][0]['name']='m7-audit-ui-wifi-dolphin';ret['builds'][0]['basis']='One fresh no-NIC8GiB4CPU guest; accepted native setup only, no gameplay. Four worker controls first, two focused GUI Wi-Fi observations, EN/FR refusal/dismiss frames at640x480.1200s whole family plus120s inherited cleanup. All output bounded128MiB/4096files; hostframes64MiB. Source-bound overlays are explicit; final new-image acceptance remains pending.'
ret['builds'][0]['evidence']=[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','vm-lifecycle.py','source/guest.py','source/audit-ui/guest-audit.py','host-audit.py']];save(out/'retention-plan.json',ret)
adm=json.loads((out/'admission-plan.json').read_text());adm['stage']='m7-audit-ui-wifi-dolphin';adm['outputs'][0]['issue']=593;adm['outputs'][0]['release_when']='Four original controls, source-bound GUI observations, EN/FR refusal frames and restored custody exported/reviewed; original owners gone and admission consumed before guarded media retirement.';save(out/'admission-plan.json',adm)
save(out/'records/audit-ui-preparation.json',{'status':'PREPARED_UNRUN','packet_seal':sha(HERE/'SHA256SUMS'),'native_packet_seal':sha(NATIVE/'SHA256SUMS'),'compiler_consumption':consumed,'scope':'640x480 only; no gameplay; explicit candidate overlays','native_prepare_argv':argv})
print(json.dumps({'owner':str(out),'status':'PREPARED_UNRUN','work_seconds':1200,'cleanup_seconds':120,'operator':str(out/'host-audit.py')}))

# #593 / #594 focused no-NIC UI packet — UNRUN

Source-only preparation. No preparer, driver, compiler, VM, listener, product
helper or launch has executed from this packet. Root owns admission, allocation,
operation, frame review, integration and final source/image acceptance. The
previous sealed worker and compiler packets remain unchanged.

This is an additive derivative of the already accepted no-NIC native guest
packet `/tmp/m7-native-gameplay-lifecycle-20261015-03`, seal
`c9d6faa5bb47950f5c73f947bf03fa925ba2fbdebc8a4d0c5ffb3824ae02379d`.
Its preparer, VM lifecycle, census, guest/native provisioning, pad supervisor,
no-NIC helper, serial lock, actual input mapping, image binding and stopped-owner
exporter are reused unchanged. The new preparer invokes that source-bound
preparer and adds these small scripts/read-only input files before admission.
It does not mutate an old owner, execute a VM, or edit shared product files.
The accepted native setup stages the existing two homebrew files/controller and
configuration, but this packet launches no gameplay and reruns no native matrix.
The Wii file provides only the normal ES/runemu path for an intentional refusal.

## Inputs and scope

- Actual guest image: frozen d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a / ES3178,
  existing final readback `/workspace/tmp/pix-m7-image-readback-20261015-01/artifacts`.
- Consumed compiler owner `/workspace/tmp/pix-m7-wifi-compile-20261015-01`, admission
  fb99a646934245098e993ad4d78c90ab: actual candidate ES16dbac5211eea7e70db7394372033be2be7df829,
  binary067defd8c760ae9085b1faba1ada643812be494be39e5690a472ab241258ab5d.
  Baseline driver018cf4ff73f1d99bc5d8dfce2be31eb21a378d1c382ca018ad40fd79a75cd38b;
  candidate drivera726719e63cded40c2b6b465713472abbfdc243846ac4c2b78888ddacfb075d9.
- Worker source packet84e0fdd157206d39f90eb8d02e2f657110e5c7589b67c6f1f6c30272851ebf3f,
  copied unchanged into the new input media. Its backend and compiled drivers run
  all four original controls through the additive `worker-observer.py`, retaining
  baseline observer1/driver0 as a failed observation, followed by candidate
  explicit/atexit/complete0 without cleanup. The sealed observer remains present
  as original evidence and is not used: its optional task/children interface is
  absent on this guest kernel. Both additive observers reuse the qualified #594
  revision02 numeric /proc/stat census and pidfd discipline. Unknown reads or
  cleanup/receipt errors fail; they cannot become an empty custody result.
  `originals/qualified-census-probe.py` and both observer diffs retain provenance.
- #594 source comes from exact committed product47dda767c7afc47020a3f21ab19a4493bfd5ff8a;
  helper01473794711dafd9607e1b6894ec482e34820807b81e1c45c352d5da9768c28a.
  The installed Wii launcher preserves all packaging substitutions and gains only
  the exact already reviewed status gate through a unique old/new block replace.
  Its actual resulting bytes and installed baseline hash are retained. GC uses
  the identical gate and remains covered by the separate source controls; no new
  redundant GC refusal frame is proposed.

These are explicit candidate overlays on a known image, not a rebuilt image.
The actual installed-path ES executable hash is checked, and its original direct
child exit is collected. Final new-image installed acceptance remains pending.
All synthetic fixture data stays in the disposable guest; no hardware/radio,
real credentials, provider service, award, or cloud transaction is involved.

Can this be done on the VM? Yes: normal frontend teardown, child lifetime and
localized refusal rendering need no physical fact. Root records that answer on
#593/#594 before allocation.

## Small proof sequence

Four unchanged worker controls run first in this same guest. A baseline failure
is required and kept failed; the aggregate checks the expected original channel,
not a rewritten returncode. Three candidate controls must succeed normally.

For actual GUI lifetime, the idle essway service is stopped before creating a
scan. Its automatic restart and default cgroup cleanup would otherwise obscure
which owner stopped the backend. The observer starts the actual installed-path
ES with its normal `es_settings` setup and an explicit final exec. It is a
subreaper and retains the actual ES wait status. The process runner/helper and
UI remain the actual ES binary. This proves the normal main/SIGINT path, not
service stop, SIGTERM, a physical power button, or universal owner-death cleanup.
The source fixture's backend has one real30-second sleep holding stdout; product
30/45-second deadlines are never lengthened. A separate `current` exit1 supplies
the normal NETWORK SETTINGS read without a radio.

One installed-baseline blocked scan followed by SIGINT is retained as a failed
GUI observation with original ES0 and captured backend survivor identities before
owned cleanup. Candidate flow opens the picker, captures searching, goes Back,
captures NETWORK SETTINGS, reopens and captures searching again. Same ES and
same pending backend identities, one enumeration, actual source-backed join log
pair, <=3s stopped-group observation and <=10s whole normal exit are required.
Back's conservative input-to-captured-return upper bound is <=1s; it includes
host-tool overhead, so exceeding it is an original failed timing observation,
not automatically a product responsiveness diagnosis. The frame still requires
visual review of the returned page.

For #594, an independently copied private Dolphin config is mounted over its
normal guest path. A directory at RetroAchievements.ini causes the real helper's
`mv -T` publication to fail. The normal Wii launcher, installed runemu and actual
ES/API launch path produce the250 custom error. No fake message is injected.
The actual ES log's fresh exit250 observation, unchanged sentinel, no observed
native engine, full helper/gate/source bindings and reviewed frame are retained.
The helper's exact permission/publication statuses and no-engine gate remain
supported by the separate already allocated #594 source controls; this UI packet
adds rendering and normal launch-path composition.

At640x480 this produces exactly eight required frames:
baseline-searching; candidate-searching/network-return/reopened-searching;
EN refusal/return; FR refusal/return. Frames carry source binding and hashes and
must be personally reviewed through view_image before the existing review action.
No source strings, page rows, spacing, menu routing or saved picker result changes
are proposed in #593. Canonical references remain `docs/es-menu-map.md`420–492,
prior setup qualification Back/reopen frames, and24accepted #577 branch frames.
The #594 frames add the actual localized new error text and normal dismissal.

The accepted native harness fixes the display at640x480, and its capture parser
asserts that exact size. This packet does not alter QEMU modes or build a new
dual-boot framework. The earlier proposed1280x800 proof remains a named follow-up
requiring a separate display/profile binding. Do not label these frames as both
sizes. Final image and larger-profile evidence remain root's acceptance decisions.

## Bounds and restoration

Existing canonical no-NIC guest:8GiB/4CPU,16GiB disk, source-bound helper
5b058ed8a8b11135cd5997e3d925939baff30726033125acf1244863a756318d.
Whole family1200s plus inherited120s cleanup; no budget extension/resume/replay.
Each driver observer has20s outer plus6s TERM/2s KILL exceptional cleanup;
four together120s including serial margin. Direct Popen child pidfds are held
while the child remains unreaped. No numeric kill is used by additive observers
or their guest parents.
Each GUI observer has180s internal budget and a separate190s parent wait plus
8s TERM/2s KILL exceptional wait. The observer retains the baseline failure before
cleanup; candidate forced cleanup fails. Host serial/HMP actions have individual
bounds and hold the original nonblocking serial lock. No listener or SSH/NIC is
introduced. Output is capped128MiB/4096files, host frames retain64MiB ceiling.

The guest records only owned binds and verifies each target's device/inode against
its exact source before unmounting. Pre-existing binds refuse the fixture.
Original installed hashes, system.cfg and es_settings.cfg are restored before
normal service startup. The private Dolphin clone preserves original configs.
If a scan observer is still live or failed ambiguously, cleanup refuses to unbind
live code; preserve the original failure and let the existing guest lifecycle
stop its exact VM. An aborted guest is not a successful restoration claim.
The original native finish's unrelated full config-tree snapshots are not called:
that previously exceeded4096files. The additive finish preserves the same actual
pad-supervisor outcome, writes a bounded manifest, and hands the unchanged
lifecycle/exporter its expected shape. It reserves one manifest slot (at most4095payload files) within the unchanged
4096-file ceiling. It does not weaken the file ceiling.

## Root-only preparation and allocation

Use a fresh owner and observed-free VNC number. This invocation is UNRUN:

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01
TASK_PACKET=/tmp/pix-m7-audit-ui-plan-20261015
TASK_OWNER=/workspace/tmp/pix-m7-audit-ui-20261015-01
python3 -I -S -B "$TASK_PACKET/prepare.py" --checkout "$TASK_TREE" \
  --verification /workspace/tmp/pix-m7-image-readback-20261015-01/artifacts \
  --author-owner /workspace/tmp/pix-m7-mkdcdisc-20261014-01 \
  --owner "$TASK_OWNER" --vnc 140
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
# Review original report/watch results and current exclusive allocation first.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

Wait for actual visual-ready.json, then run one command at a time under its lock:

```bash
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" init
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" controls
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-start --mode baseline
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-open
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-exit
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-start --mode candidate
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-open
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-back-reopen
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-exit
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" cleanup
```

Do not pause between opening a blocked picker and wifi-exit: those actions must
fit the unchanged30-second product deadline. Review frames after the scan exits.
Root uses the unchanged `host-action.py --owner "$TASK_OWNER" review --label LABEL
--review TEXT` for each personally viewed frame. Then additive `host-audit.py
--owner "$TASK_OWNER" finish`, wait original lifecycle/launcher completion, and
use unchanged `close.py --owner ... --run ACTUAL_FROZEN_BUILD_RUN --packet FRESH_EXPORT`.
Review all original exits, watcher/owner absence, restored custody and manifests
before consuming. No approval, admission, deletion, commit or pin move is implied.

Original failed observations remain failed. SIGTERM/fatal/_exit/escaped-group
residuals remain explicit under D-CLOUD-133; no service KillMode change is made.

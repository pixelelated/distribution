#!/usr/bin/env python3
"""Parse/compare retained source only. Never import or execute fixture/runtime code."""
import ast,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(p):return ast.parse(p.read_text(),filename=str(p))
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in tree(p).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
parsed=[]
for f in sorted(P.rglob('*.py')):tree(f);parsed.append(str(f.relative_to(P)))
parent={n:h for h,n in (line.split('  ',1) for line in (P/'parent/SHA256SUMS').read_text().splitlines())}
unchanged=['vm-lifecycle.py','supervisor.py','pad.py','census.py','close.py','consumed-paths.txt','frozen-config-bindings.json']+[str(f.relative_to(P)) for f in sorted((P/'fixture').rglob('*')) if f.is_file()]
for n in unchanged:assert sha(P/n)==parent[n],n
old=functions(P/'parent/guest.py');new=functions(P/'guest.py')
stable_functions=['sha','save','identity','natives','run','api','pad','controller_identity','cleanup','provision']
for n in stable_functions:assert old[n]==new[n],n
s=(P/'guest.py').read_text();h=(P/'host-action.py').read_text();pre=(P/'prepare.py').read_text()
for text in ["order=['wii','tetris2','tetris2','tetris2']","len(list(R.glob('launch-*.json')))==4","assert len(rows)<=4095","assert not copy_sd","snapshot('final')"]:assert text in s,text
assert 'GameSettings' not in new['snapshot'] and 'sd.raw' not in new['snapshot']
assert "choices=range(0,11)" in h and "time.sleep(a.settle_seconds)" in h and "wait_is_not_restore_completion" in h and "LOCK_EX|fcntl.LOCK_NB" in h
assert "choices=[0,10]" in h and "range(a.observe_seconds+1)" in h and "not (a.first_frame and a.observe_seconds)" in h
assert 'commit==a.expected_commit' in pre and "continuity['reviewed_sources']" in pre
for field,value in [('work_seconds',1800),('cleanup_seconds',120),('first_frame_seconds',120),('score_seconds',360)]:assert "'%s':%d"%(field,value) in pre
shell=[]
for f in sorted((P/'fixture').rglob('*.sh')):
 c=subprocess.run(['bash','-n',str(f)],capture_output=True,text=True,timeout=10);assert c.returncode==0,(str(f),c.stderr);shell.append({'path':str(f.relative_to(P)),'original_returncode':c.returncode})
continuity=json.loads((P/'source-continuity.json').read_text());assert len(continuity['reviewed_sources'])==19
if (P/'SHA256SUMS').exists():
 for line in (P/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);assert sha(P/name)==digest,name
print(json.dumps({'status':'PASS_STATIC_ONLY','python_parsed':parsed,'shell_syntax':shell,'byte_identical_parent_members':unchanged,'ast_identical_guest_functions':stable_functions,'reviewed_source_rows':len(continuity['reviewed_sources']),'capture_observation':'shared lock; explicit 0–10s wait, optional 11 original frames over nominal10s; burst forbidden for first-interactive ack; no input replay','runtime':'UNRUN; no preparer/fixture imported, no VM/controller/service/compiler/admission','limits':'1800 family,120 cleanup,120 first frame,360 unused scoring,448MiB guest+64MiB host;4095 payload files plus manifest','scope':'syntax/source/identity assertions do not prove future runtime behavior'},indent=2))

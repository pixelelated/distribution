# frame-diff

baseline `/workspace/artifacts/rocknix-images/walk-baseline` (build d72084ccad) against `/workspace/tmp/pix-m7-final-baseline-20261014-02/artifacts/webdav/rocknix-images/qa-fac608ff89-webdav-a-20261014-2320/walks`: 78 screens in 8 s.
masks: /workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02/tools/vm-walks/masks.txt (7); claims: /workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02/tools/vm-walks/claims.txt (43 live, 0 stale against another baseline).

| screen | box | pixels | verdict |
| --- | --- | --- | --- |
| `back-up-page/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `back-up-page/02-back-up-page.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `confirm-cloud-folder/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `confirm-cloud-folder/02-hub-change-folder-row.png` | x 0..1039, y 0..707 | 358293 px | **UNCLAIMED** (claim as `0 0 1040 708`) |
| `confirm-cloud-folder/03-folder-editor.png` | x 0..1043, y 0..718 | 213517 px | **UNCLAIMED** (claim as `0 0 1044 719`) |
| `confirm-cloud-folder/03-folder-editor.png` | x 552..728, y 146..191 | 2566 px | claimed by 527 # SAVES FOLDER title and underlying CLOUD FOLDERS title replace CLOUD FOLDER/CLOUD |
| `confirm-cloud-folder/03-folder-editor.png` | x 183..413, y 226..267 | 4583 px | claimed by 409 # the editor now holds /pixelelated/Saves (D-CLOUD-174); measured lowercase text against the accepted ROCKNIX baseline, #415 |
| `confirm-cloud-folder/03-folder-editor.png` | x 856..934, y 584..602 | 1171 px | claimed by 544 # #538 CLEAR button replaces RESET; callback unchanged |
| `confirm-cloud-folder/03-folder-editor.png` | x 273..1007, y 743..765 | 6397 px | claimed by 544 # #538 CLEAR help caption replaces RESET and re-centers the same prompts |
| `confirm-cloud-folder/04-folder-result.png` | x 0..1043, y 0..718 | 465401 px | **UNCLAIMED** (claim as `0 0 1044 719`) |
| `confirm-cloud-folder/04-folder-result.png` | x 552..728, y 146..162 | 1877 px | claimed by 527 # CLOUD FOLDERS after unchanged submission, rather than old CLOUD hub |
| `confirm-cloud-folder/05-after-dismiss.png` | x 0..1142, y 0..718 | 651704 px | **UNCLAIMED** (claim as `0 0 1143 719`) |
| `confirm-cloud-folder/05-after-dismiss.png` | x 274..1005, y 743..765 | 7139 px | claimed by 527 # hub CLOSE/BACK/CHOOSE help replaces keyboard editing prompts |
| `continue-to-systems/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `continue-to-systems/02-back-up-page.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `continue-to-systems/03-roms-flipped.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `continue-to-systems/04-continue-focused.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `continue-to-systems/05-systems-page.png` | x 0..1043, y 0..707 | 281685 px | **UNCLAIMED** (claim as `0 0 1044 708`) |
| `manager-fbn/01-0-carousel.png` | x 0..551, y 0..707 | 355159 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `manager-fbn/01-0-carousel.png` | x 1249..1279, y 418..707 | 4579 px | claimed by 455 # narrow restored GB panel at the right edge |
| `manager-gb/01-0-carousel.png` | x 0..1279, y 0..707 | 814636 px | claimed by 455 # first verified Game Boy carousel, previously FBNeo |
| `manager-gb/02-1-list.png` | x 465..814, y 74..134 | 13701 px | claimed by 455 # first verified Game Boy game list |
| `manager-gb/02-1-list.png` | x 544..720, y 224..246 | 2299 px | claimed by 455 # first verified Game Boy game list |
| `manager-gb/03-2-game-options.png` | x 940..1089, y 25..41 | 1677 px | claimed by 455 # options for Ninoid, previously Ms. Pac-Man |
| `manager-gb/03-2-game-options.png` | x 465..746, y 74..134 | 11059 px | claimed by 455 # options for Ninoid, previously Ms. Pac-Man |
| `manager-gb/03-2-game-options.png` | x 544..720, y 224..246 | 2290 px | claimed by 455 # options for Ninoid, previously Ms. Pac-Man |
| `manager-gb/04-3-manager.png` | x 465..814, y 74..134 | 13620 px | claimed by 455 # actual Game Boy background and Ninoid title |
| `manager-gb/04-3-manager.png` | x 544..720, y 224..246 | 2290 px | claimed by 455 # actual Game Boy background and Ninoid title |
| `manager-gb/04-3-manager.png` | x 273..496, y 432..636 | 37455 px | claimed by 455 # unrotated Game Boy thumbnail and its date |
| `manager-gb/05-4-manager-next-tile.png` | x 465..814, y 74..134 | 13620 px | claimed by 455 # same actual system/game backdrop |
| `manager-gb/05-4-manager-next-tile.png` | x 544..720, y 224..246 | 2290 px | claimed by 455 # same actual system/game backdrop |
| `manager-gb/05-4-manager-next-tile.png` | x 273..496, y 432..636 | 37473 px | claimed by 455 # same Game Boy thumbnail, selected |
| `manager-nes/01-0-carousel.png` | x 0..39, y 0..381 | 7868 px | **UNCLAIMED** (claim as `0 0 40 382`) |
| `manager-nes/01-0-carousel.png` | x 737..1279, y 0..707 | 338149 px | claimed by 455 # restored GB neighbor and shifted next panel |
| `match-dialog/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `match-dialog/02-cloud-hub-match-row.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `match-dialog/03-match-confirm.png` | x 0..551, y 0..707 | 142280 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `match-dialog/04-match-done.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `restore-page/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `restore-page/02-restore-page.png` | x 0..680, y 0..707 | 235089 px | **UNCLAIMED** (claim as `0 0 681 708`) |
| `restore-page/02-restore-page.png` | x 971..1029, y 474..503 | 779 px | claimed by 349 # SETTINGS dimmed, its line NO SETTINGS BACKUP FROM THIS DEVICE YET and no switch: the QA cloud holds no settings backup from this device's label, so the scan offers none (D-CLOUD-162, D-CLOUD-164 string 3); since ES 551c5a762 the row keeps the rows' inset, where 1acdaf2cce..d9493fe339 drew it flush with the panel's edge |
| `run-transfer-frames/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/02-back-up-page.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/03-roms-flipped.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/04-continue-focused.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/05-systems-page.png` | x 0..1043, y 0..707 | 281685 px | **UNCLAIMED** (claim as `0 0 1044 708`) |
| `run-transfer-frames/06-selected-all.png` | x 0..1043, y 0..707 | 287061 px | **UNCLAIMED** (claim as `0 0 1044 708`) |
| `run-transfer-frames/07-t02.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/07-t02.png` | x 557..722, y 288..338 | 2778 px | claimed by 439 # first observed transfer frame may still say PREPARING... instead of SAVES / ITEM 1 OF 4; actual09 completes24files/640KB at elapsed0:04. The historical t02 name is not a two-second timing assertion; no baseline or general mask changed. |
| `run-transfer-frames/07-t02.png` | x 424..854, y 560..573 | 3893 px | claimed by 308 # the same footer, the frames walk |
| `run-transfer-frames/08-t05.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/08-t05.png` | x 565..714, y 288..338 | 2569 px | claimed by 308 # the run carries PICO-8's files too (26 files, 1.1 MB against 23, 640 KB) and still ends at ELAPSED 0:03 (t08: COMPLETED); the t05 sample can catch ITEM 5 OF 5 a moment before the end |
| `run-transfer-frames/08-t05.png` | x 415..865, y 412..426 | 3118 px | claimed by 406 # replacement134e89's fixed t05 sample still shows the live files/bytes/rate line; t08 is COMPLETED,24 files/640KB, elapsed0:04. Actual baseline/current frames retained; no renderer change or whole-screen mask. |
| `run-transfer-frames/08-t05.png` | x 499..782, y 560..573 | 2864 px | claimed by 308 # the same sample: the footer still THIS CAN TAKE A WHILE. |
| `run-transfer-frames/08-t05.png` | x 588..691, y 743..765 | 1210 px | claimed by 308 # the same sample: the help bar still CANCEL |
| `run-transfer-frames/09-t08.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/10-t11.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/11-t14.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/12-t17.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/13-t20.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/14-t23.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/15-t26.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/16-t29.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/17-t32.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/18-t36.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/19-t40.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/20-t45.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/21-t50.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer-frames/22-t60.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/02-back-up-page.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/03-roms-flipped.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/04-continue-focused.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/05-systems-page.png` | x 0..551, y 0..707 | 226071 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/06-selected-all.png` | x 0..551, y 0..707 | 226071 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/07-transfer-running.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `run-transfer/07-transfer-running.png` | x 424..854, y 560..573 | 3893 px | claimed by 308 # the transfer page's footer no longer names a console letter: THIS CAN TAKE A WHILE. (ES 5a7afc4ca, F-RA-14/F-CS-07; es-ui-style-guide Interaction rules) |
| `run-transfer/08-transfer-done.png` | x 0..551, y 0..707 | 171132 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-game-content/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-game-content/02-back-up-page.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-game-content/03-game-content-flipped.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-roms/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-roms/02-back-up-page.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-roms/03-roms-flipped.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-settings/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-settings/02-back-up-page.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `tick-settings/03-settings-flipped.png` | x 0..551, y 0..707 | 228838 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `to-change-cloud-folder/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `to-change-cloud-folder/02-hub-change-folder-row.png` | x 0..1039, y 0..707 | 358293 px | **UNCLAIMED** (claim as `0 0 1040 708`) |
| `to-change-cloud-folder/03-folder-editor.png` | x 0..1043, y 0..718 | 213517 px | **UNCLAIMED** (claim as `0 0 1044 719`) |
| `to-change-cloud-folder/03-folder-editor.png` | x 552..728, y 146..191 | 2566 px | claimed by 527 # SAVES FOLDER title and underlying CLOUD FOLDERS title replace CLOUD FOLDER/CLOUD |
| `to-change-cloud-folder/03-folder-editor.png` | x 183..415, y 226..267 | 4667 px | claimed by 409 # the same lowercase default on the other editor walk, #415 |
| `to-change-cloud-folder/03-folder-editor.png` | x 856..934, y 584..602 | 1171 px | claimed by 544 # #538 CLEAR button replaces RESET; callback unchanged |
| `to-change-cloud-folder/03-folder-editor.png` | x 273..1007, y 743..765 | 6397 px | claimed by 544 # #538 CLEAR help caption replaces RESET and re-centers the same prompts |
| `to-manage-cloud-storage/01-cloud-hub.png` | x 0..551, y 0..707 | 201035 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `ui-settings-toggle/01-ui-settings-last-row.png` | x 0..551, y 0..707 | 201042 px | **UNCLAIMED** (claim as `0 0 552 708`) |
| `ui-settings-toggle/02-toggled.png` | x 0..551, y 0..707 | 201042 px | **UNCLAIMED** (claim as `0 0 552 708`) |

**FAIL** -- 32 box(es) claimed, 65 unclaimed, 0 screen(s) missing.

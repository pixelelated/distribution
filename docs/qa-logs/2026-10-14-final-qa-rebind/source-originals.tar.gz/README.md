# Final baseline and remaining Steam source cases: fac608ff binding

SOURCE ONLY, UNRUN. Neither original executable hardcodes d6a or the old physical cache root: both derive source/image/runtime identities from their supplied checkout and completed verifier. Only the historical README examples need replacement. This additive packet supplies two small command wrappers; it does not copy, edit, reseal, or fork the existing lifecycle/guest/export sources. Both consume their exact original sealed packets from the new frozen fac608ff89940ce358ea9b8a95e9a08a6fe26568 checkout. Old owners and results remain immutable.

The prior baseline owner01 has PREPARED_UNRUN_SUPERSEDED_DO_NOT_LAUNCH in its superseded.json. No baseline runtime occurred. The new baseline owner02 uses tree02/image/system and the moved cached RetroArch bdba046f source. Source readback found its video_thread_wrapper.c unchanged at b578746ee1b053b5211961f6f56f08cd0b2568fef8bb8bfc84b374b307c76952. The new verifier and runtime independently bind actual final bytes; that readback is not a substitute for completed image verification.

No lifecycle logic or predicate changes are required. The selected tools, VM helper/profile and Steam installer are unchanged between d6a and fac608ff. Of tools/, only pixelelated-state-check and its test changed; neither is a dependency of these two launchers. Both preparers obtain their new full commit and actual image .img.gz path/hash/size from the existing verifier schema; runtime BUILD_ID and installed inputs are checked normally. The verification path is deliberately supplied after actual readback, never fabricated from a predicted target filename.

## Standard15, WebDAV then SFTP and local MinIO

After new image readback and the separately owned clean/retained proofs, set TASK_VERIFY to that actual completed directory containing result.json, inputs.json and candidate.img. Run the following only when root allocates. Preparation is small-file-only; submission is the allocation boundary.

```bash
TASK_PACKET=/tmp/pix-m7-final-qa-rebind-20261014
TASK_VERIFY=/actual/completed/new-image-verifier/artifacts
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02
TASK_OWNER=/workspace/tmp/pix-m7-final-baseline-20261014-02
bash "$TASK_PACKET/prepare-baseline.sh" "$TASK_VERIFY"
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- --admission "$TASK_OWNER/admission.json" --activity-dir "$TASK_OWNER" --recursive-activity -- python3 -I -B "$TASK_OWNER/run.py"
```

Unchanged bounds: two normal4CPU/8GiB guests;5700s work+180s cleanup;15 standard rows on WebDAV, one round-trip each on SFTP/S3; no additional cases. Standard names remain scripts,lifetime,wrapper,vocabulary,french,quoting,menumap,register,pair-identity,fresh,round-trip,exit,time-to-play,walks,frame-diff. All15 original PASS rows and both backend rows, original status channels, restoration, actual owner/guest/backend exit and frames remain required. No accepted component controls are repeated. Original packet README/close.py govern source scope, output limits and fail-stop handling unchanged.

After original owners exit:

```bash
TASK_RUN=$(cat "$TASK_OWNER/run.path")
TASK_EXPORT=/workspace/tmp/pix-m7-final-baseline-export-20261014-02
python3 -I -B "$TASK_OWNER/close.py" --owner "$TASK_OWNER" --run "$TASK_RUN" --output "$TASK_EXPORT"
# Review original channels/reports/frames/restoration and lossless export first.
python3 -I tools/host-maintenance/build-admission consume --run "$TASK_RUN" --evidence "$TASK_EXPORT/consumption-draft.json"
```

## Steam fourteen remaining source-chroot cases

Run serially after the preceding owner is complete/consumed and its guests/backends are gone. TASK_VNC is a currently free100..199 endpoint selected during root admission. The same completed verifier directory is used.

```bash
TASK_STEAM=/workspace/tmp/pix582-remaining-vm-20261014-02
TASK_STEAM_PACKET="$TASK_TREE/docs/qa-logs/2026-10-14-steam-one-guest-adapter"
# Set TASK_VNC to the reviewed free endpoint before preparation.
bash "$TASK_PACKET/prepare-steam14.sh" "$TASK_VERIFY" "$TASK_VNC"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_STEAM/retention-plan.json" --output "$TASK_STEAM/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_STEAM/admission-plan.json" --output "$TASK_STEAM/admission.json"
tools/watch-build-submit --owner "$TASK_STEAM/lifecycle-owner" -- --admission "$TASK_STEAM/admission.json" --activity-dir "$TASK_STEAM/logs" -- python3 -I -S -B "$TASK_STEAM/vm-lifecycle.py"
```

Exactly the unchanged fourteen labels in source-review.json: five normal0, four intended1 refusals and five1→0 retries. The nine accepted cases remain outside the allowlist. Source installer SHA remains fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d; original remaining-packet seal79dc1d57d8741b644e99cd8348c4c362fbef3a1c815c48f6fa23b84a6e201c34. One8GiB/4CPU no-NIC guest;3600s family+90s fail-stop;1280MiB output; each original fixture/stage/result/restoration/export bound unchanged. This proves source installer recovery in a private chroot using installed guest tools. It does not claim installed Steam on GENERIC_X64, ARM64 native launch, or SM8550 installed bytes. Those architecture-selected checks remain separate.

After actual lifecycle/watcher/QEMU exit, use the original printed watcher run and a fresh export owner:

```bash
TASK_STEAM_EXPORT=/workspace/tmp/pix582-remaining-export-20261014-02
# TASK_STEAM_RUN is the exact completed watcher path, never an example suffix.
python3 -I -S -B "$TASK_STEAM_PACKET/export.py" --owner "$TASK_STEAM" --checkout "$TASK_TREE" --run "$TASK_STEAM_RUN" --output "$TASK_STEAM_EXPORT"
```

Review qualification_pass and all original channels/restoration before existing admission consumption. --retain-failed remains preservation-only and never converts a failure to acceptance. Original packet README defines the unchanged stopped-media export and owner-scoped retirement. This packet invents no final-image criterion or native-success waiver.

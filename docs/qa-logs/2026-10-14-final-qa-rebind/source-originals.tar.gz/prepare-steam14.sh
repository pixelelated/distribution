#!/bin/bash
# Source-only command binding; preserves the original fourteen-case source scope.
set -euo pipefail
[[ $# == 2 ]] || { echo 'usage: prepare-steam14.sh COMPLETED_VERIFY_DIRECTORY FREE_VNC_100_TO_199' >&2; exit 2; }
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02
TASK_SOURCE="$TASK_TREE/docs/qa-logs/2026-10-14-steam-one-guest-adapter"
TASK_OWNER=/workspace/tmp/pix582-remaining-vm-20261014-02
[[ "$(git -C "$TASK_TREE" rev-parse HEAD)" == fac608ff89940ce358ea9b8a95e9a08a6fe26568 ]]
[[ "$(sha256sum "$TASK_SOURCE/SHA256SUMS" | cut -d' ' -f1)" == ad9d52626de90c02219acd2c33bd93ff064301305dcb64096b34b3610555752b ]]
exec python3 -I -S -B "$TASK_SOURCE/prepare.py" \
  --checkout "$TASK_TREE" --image-verification "$1" \
  --remaining-packet /tmp/pix582-remaining-source01 \
  --owner "$TASK_OWNER" --vnc "$2"

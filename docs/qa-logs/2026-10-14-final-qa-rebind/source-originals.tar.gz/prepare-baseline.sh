#!/bin/bash
# Source-only command binding; prepares small owner files, never launches a guest.
set -euo pipefail
[[ $# == 1 ]] || { echo 'usage: prepare-baseline.sh COMPLETED_VERIFY_DIRECTORY' >&2; exit 2; }
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02
TASK_SOURCE="$TASK_TREE/docs/qa-logs/2026-10-14-final-baseline-lifecycle"
TASK_OWNER=/workspace/tmp/pix-m7-final-baseline-20261014-02
TASK_BUILD="$TASK_TREE/build.pixelelated-GENERIC_X64.x86_64"
[[ "$(git -C "$TASK_TREE" rev-parse HEAD)" == fac608ff89940ce358ea9b8a95e9a08a6fe26568 ]]
[[ "$(sha256sum "$TASK_SOURCE/SHA256SUMS" | cut -d' ' -f1)" == 0776021f30c01c2a9aff49446f2ad056365be3c5884ac14d10e1d778e622d047 ]]
exec python3 -I -B "$TASK_SOURCE/prepare.py" \
  --checkout "$TASK_TREE" --verification "$1/result.json" \
  --system-root "$TASK_BUILD/image/system" \
  --es-source /home/max/Development/emulationstation-next.worktrees/qa-integration \
  --retroarch-source "$TASK_BUILD/build/retroarch-bdba046fa6766380bc2457532f38e589df769aaf" \
  --baseline /workspace/artifacts/rocknix-images/walk-baseline \
  --owner "$TASK_OWNER"

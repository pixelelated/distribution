# Website-status and GTK4 scheduling proposals

These are source-only tracker proposals. No tracker mutation or new runtime was executed.

For #511, `511-body-proposed.md` adds the actual live-site and PR #4 status, marks the old lane/access/404/non-live instructions historical, and updates the scope wording to maintain existing published preview guides. It retains all seven literal checkboxes and all owner quotations. Remaining QR destination binding, rendered/decoded EN/FR frames, offline controls, menu/localization consistency, design exploration and the linked #577 Wi-Fi guide follow-up stay explicit. The existing first guide criterion is not re-adjudicated by this narrow status correction.

For #576, `576-request-proposed.json` proposes the Backlog title, revised scheduling body and `milestone: null`, matching D-WORKFLOW-163 and the current M7 plan. The issue remains open; one completed source criterion and four unproved criteria remain unchanged. The completed source feasibility, pre-compilation failure and absence of GTK4 runtime proof are preserved. No re-parenting, production migration, experiment or acceptance waiver is proposed.

`application-guards.json` binds the fresh live issue reads and proposed hashes. Root must re-read before applying and retain actual responses/readback. The first sandboxed #511 GET failed to connect; its empty output/error are retained separately, followed by successful authenticated read-only GETs for both issues. `decision-evidence.json` retains the exact source row and current milestone excerpts.

Actual #349 completion and #563 partial reconciliation are separately durable under `docs/qa-logs/2026-10-15-restoration-completion/`, seal `dde546e06ce2c0985846a02eda06fbf4c81773ee2abe6d7d3707e4f7ec0edabf`. Its exact website-publication originals support the current #511 paragraph. No guide publication, DNS, source visibility, runtime, shared-record change or commit occurred in this status-proposal worker.

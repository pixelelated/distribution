## Current status — public preview and restore guide published, 2026-10-15

The website preview is live at [pixelelated.com](https://pixelelated.com/), with published [cloud](https://pixelelated.com/guides/cloud/), [ROM](https://pixelelated.com/guides/roms/) and [BIOS](https://pixelelated.com/guides/bios/) setup guides. The source repository remains private. Website PRs #1/#2, their retained build/prose/link/layout checks, initial publication and HTTPS enforcement are recorded in the October 11–12 comments. The October 12 readback verified 16 redirect/content cases; that is dated evidence, not a new claim that every route was tested today.

[Website PR #4](https://github.com/pixelelated/website/pull/4) adds the same-model settings-restore explanation for #349. PR head `435ebc956cbe39da69e83158008efe9956662e1f` passed checks `38717338495`; merge `6aac689c6feaa8d4afefbd5a8b2121e5206f14b9` passed main checks `38717686667` and deployment `38717686819`. The public cloud guide returned HTTP 200 at 2026-10-15 10:07:16 UTC; exact HTML SHA256 `4891f14feaf0bd78694fbca1cb27f123cdba0f670f16a7ccbe51107e6d7c9d18` contains the newest compatible model backup, model/date, foreign-model exclusion and visible disabled-state explanation. #349 is closed completed; no restore VM replay was needed. Exact source, frames, publication and issue-action originals are retained in `docs/qa-logs/2026-10-15-restoration-completion/`.

Remaining work here is the existing source-to-guide maintenance (including the linked #577 Wi-Fi follow-up below), the separate design exploration, and firmware **See instructions** integration: actual destination binding, EN/FR controller QR frames, decoded URLs, offline/missing-destination controls and matched menu/localization documentation. Published URLs alone do not satisfy those firmware behaviors. No firmware QR action was enabled by PR #4. The acceptance checklist below remains unchanged by this status-only reconciliation; this is not a closure of #511 or a new firmware RC gate.

The earlier lane trust prompt, repository-creation/access blockers, 404/certificate failures, missing Pages setup and “site not yet live” statements below are historical observations and superseded next steps. They must not be treated as current blockers or repeated without a new reason. The unrelated website design checkout and draft PR #3 remain separate from the published guide change.

## Historical lane creation — 2026-10-08

The following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.

> Sounds good, and we should trigger a new lane if you want, within Herdr, for website work. I want to keep us focused here in this lane on the critical path of getting the build completed. We were in the flow, trying to get everything done. Run the changes and adjustments for the release candidate to simplify the experience and expectations of what happens when connecting a new remote via rclone, and I don't want to lose that progress and momentum.

Created **pixelelated · Website**, workspace wG, pane wG:p1, agent pixelelated-web, using /workspace/repos/pixelelated-website. The lane is waiting at Codex's repository folder-trust prompt; the explicit confirmation question is pending. It is created, not yet a working website agent. Do not send duplicate prompts or describe work as started. Once trusted, this lane owns site source, guides and local build/link/layout verification within the private website repository. Root retains distribution records and M7 coordination; no shared firmware files are assigned to this lane.

Keep firmware work moving here: #510 → #508 → #507 → selected firmware qualification. Website publication and future QR destinations do not gate the local validator or release candidate. DNS evidence below remains the last observed state, not a current serving-site claim.

## Historical repository/DNS status — 2026-10-07, before publication

The following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.

The owner created **private** [pixelelated/website](https://github.com/pixelelated/website) and granted the authenticated `blitterbot` maintain/push access. Preserve that visibility. Starter commit8559ab3e3c0bc4454ae8e2722fce7b72d677c2dd is published on main, a normal fast-forward from the owner's initial62b33d31fef4860f46abcb756ca697cd88ff788e. Remote SHA/parent/files/permissions readback passed. README and AGENTS are present; zero workflows/Actions runs and no site deployment by this lane. The owner has now configured DNS; readback below verifies the routing records. The earlier creation blocker is resolved.

> I've made Plitterbot a maintainer on that new repository.

> The domain is pixelelated.com.

D-WORKFLOW-154: **pixelelated.com** is confirmed; no domain spelling question remains. The API identity is blitterbot, with maintain/push true and admin false. Reading Pages settings returns403 with this token, which does not establish whether hosting is enabled. Check hosting requirements for the private source repository during implementation; do not change visibility automatically.

Next: select current portable static build inputs, reuse reviewed licensed material, and prepare home/cloud/ROM/BIOS guide source for local build and layout/link verification. Hosting remains flexible. The website is a parallel lane; local validator guidance and the firmware RC do not depend on its publication. Current plan: docs/pixelelated/site-plan.md; local checkout /workspace/repos/pixelelated-website. Earlier requests and attempted creation below are history, not current blockers.

## Historical DNS verification — 2026-10-07 21:30 UTC

The following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.

> The domain should be all set now if you check.

All three authoritative iwantmyname nameservers and independent resolvers 1.1.1.1 and 8.8.8.8 return the four documented GitHub Pages apex A records and www CNAME to pixelelated.github.io. The GitHub ownership-verification TXT record is present; this alone does not prove that GitHub has completed ownership verification. Proton Mail MX records are unchanged. The host's default resolver still has no answer, consistent with cached earlier negative responses; the authoritative records are correct.

Direct requests to the configured GitHub Pages address, retaining the domain Host/SNI and normal certificate verification, return HTTP404 for both names and HTTPS certificate hostname mismatch. The site is not yet serving, independently of the host resolver cache. The token still gets403 reading Pages configuration, so repository custom-domain association and certificate provisioning remain unverified. No DNS, Pages or deployment settings were changed by the agent.

Readbacks: docs/qa-logs/2026-10-07-site-access/dns-after-owner-update-2130.json and http-after-dns-2129.json. Next: prepare the site source and confirm the repository Pages custom domain, then deploy and verify public HTTPS and redirects. This DNS check does not satisfy the guide-publication acceptance criteria.

## Maintainer request

> We also shouldn't have a link that is expected to be clickable. We could show a QR code, though.

> We need to build out our site, so this can be a future task we define now and tackle later. Once the site's live, we could have this on the wiki. It would take someone directly to the setup guide, and we could then have one for their ROMs and one for BIOS files. Instead of a fix button, it would say "See instructions" or something akin to that, and that would then show a QR code in a modal to take them to the page to fix it.

## Scope and order

Website work remains parallel, without a milestone or a new 0.0.1 release gate. The dated requests below show how scheduling evolved. #510 owns the cloud-validator contract and #508 its implementation. The site and guide destinations now exist as published previews; controller QR integration and the remaining guide follow-ups are still separate work. Existing on-device instructions and expected paths remain useful offline.

1. Maintain the existing published pixelelated site and documentation area. Reuse its source and retained validation; this reconciliation selects no replacement framework, host or deployment mechanism.
2. Keep the published cloud setup guide and distinct ROM and BIOS setup pages aligned with the qualified product. Show the actual supported folder layout, how to place files from a computer, and how to run the validator again. Explain missing content versus content outside the expected folder, without implying the handheld will reorganize a library. BIOS guidance must distinguish folder readiness from emulator-specific requirements and the existing local BIOS check.
3. After those pages are live and their destinations verified, connect each relevant validator finding to a **See instructions** action. It opens a controller-dismissable modal containing a QR code for the specific guide, a short explanation, and a readable address. ROM findings lead directly to the ROM guide; BIOS findings lead directly to the BIOS guide.

No clickable-link or handheld-browser expectation. No general homepage QR when the user needs a specific remedy, no account credentials or personal paths in QR URLs, and no transfer, folder change, or repair from opening help. Final paths are chosen with the site; do not ship speculative/dead destinations. Existing local guidance remains available offline.

## Existing work to reuse

- #345 owns the original name-only placeholder; this is a later expansion, not a rewrite of its historical scope or an immediate deployment.
- #323 owns documentation voice, release notes, screenshots, and the technical appendix. Reuse its developer-relations skill and source material, reconciling old ROCKNIX documentation with current pixelelated behavior.
- Existing EmulationStation cloud sign-in has an untinted QR row helper. Reuse the presentation after sizing/lifecycle review; static documentation help must not invoke OAuth, provider sign-in, or a browser.
- #510 records bounded read-only folder checks, explicit small-file actions, and manual ROM/BIOS placement. This issue adds future documentation/help, not a new relocation mechanism.

Can this be done on the VM? Yes: controller navigation, actual rendered QR frames, decoded destinations, and offline guidance are software facts. Published HTTPS/content checks run from the host. No handheld or personal cloud account is needed.

## Acceptance criteria

- [ ] A retained site build and public HTTPS readback show the pixelelated wiki with cloud, ROM, and BIOS setup pages; each guide agrees with the qualified product's paths and behavior and passes the existing prose review/check.
- [ ] A destination map and HTTP/content receipts bind each ROM and BIOS help action to its matching published guide; redirects retain the intended page and no dead or placeholder URL ships.
- [ ] VM frames at 640×480 and the supported larger panel, in English and French, show readable **See instructions** actions and controller-dismissable QR modals without clipping. Machine-decoded frame QR contents equal the destination map.
- [ ] VM offline and missing-destination controls retain useful local instructions and expected paths; opening/closing help preserves cloud configuration, credentials, and remote data and does not launch a browser or sign-in flow.
- [ ] Menu map, guide screenshots, localization, and product/help documentation describe the same flow; #510 and the current milestone retain this as future work until explicitly scheduled.

## Historical parallel-planning decision

The following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.

> We also already own the domain, and so we can pretty easily start a parallel path to define building out the website and getting that live, especially if we're going to use GitHub Pages for the first version.

D-WORKFLOW-152: start the independent site inventory/planning lane now, evaluating GitHub Pages for a static v1 at the owned domain. Establish the existing repository/branch, site assets/docs, Pages configuration and public DNS/HTTPS state, then prepare the concrete first-site change and deployment prerequisites. This updates the earlier deferred-only scheduling above: planning is active in parallel; full site/guide delivery still does not gate the firmware RC. No deployment or DNS change has occurred. Reuse the current site work rather than choosing a second host or framework without cause.

## Historical hosting and repository clarification

The following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.

> We're not bound to GitHub Pages. If there are other things we need the site to be able to do for us at some point, but if GitHub Pages are sufficient, I already own pixelated.com, so I would just need to point the records there.

> We should also likely create a repo for that as well, although I'm not sure how GitHub Pages work: if it's just a specific repo or lives within a different repo, more similar to how the wiki works.

D-WORKFLOW-153: choose hosting from requirements; GitHub Pages is the initial static-host candidate, not a binding platform choice. Inventory existing site repositories before creating one; keep source and static output portable. A dedicated ordinary site repository is preferred over mixing it into the distribution or using GitHub wiki storage. Pages can publish a normal repository's branch/folder or a built Actions artifact; the special org-root default URL uses pixelelated.github.io as the repository name, while a project repository can also use a custom domain.

Static landing/docs/guides and release links fit Pages. A future server-side service needs separate hosting or a different platform; no such runtime requirement has yet been established for these pages. Current GitHub references: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages and https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site .

Domain clarification requested: earlier record pixelelated.com versus latest pixelated.com. Do not infer an OS rename or apply DNS changes until the spelling is confirmed. Inventory and local planning can proceed meanwhile.

## Historical inventory and prepared repository — 2026-10-07

The following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.

- Existing reusable source: clean /home/max/Development/rocknix.org, docs/cloud-saves-native-wizard at4f6df54ca16121ff2cd0620407aea6434ee59147, MkDocs/Material. One local commit ahead of its fork;238 commits behind cached upstream. Import selected reviewed material with credit rather than reuse the entire old branch. Docs PR ROCKNIX/rocknix.org#188 is still open/unmerged.
- No dedicated site repository appeared in accessible pixelelated inventory; private Pages settings were403, so complete absence is not proven. Proposed repository: pixelelated/website. Both gh GraphQL and documented organization REST creation failed for the current token (REST403 Resource not accessible by personal access token); the bot is an active member. No remote repository was created.
- A separate local main branch is ready at /workspace/repos/pixelelated-website, commit8423480a166f3fe6a9673e21c79e806563b9eb49, containing README and agent instructions. Origin names the intended repository only; there has been no push. No publishing workflow is configured. An owner can create the empty public repository and give blitterbot write access, or provide the required creation/repository access.
- The first-version plan is docs/pixelelated/site-plan.md in distribution: portable static site, selected MkDocs/Material reuse, cloud/ROM/BIOS guides, approved LCD wordmark and release links. Guides follow qualified #510/#508 behavior. Pages is sufficient for these present static requirements; future runtime/preview needs can prompt another host.
- Earlier-domain pixelelated.com DNS has no A/AAAA, www NXDOMAIN, iwantmyname nameservers and Proton Mail MX. Historical Cloudflare/Hostinger assumptions are stale; exact domain confirmation still precedes any DNS plan. No DNS, site or mail changes were made.

Next site action: establish repository access, select current build inputs and prepare reviewed static source; keep firmware and local validator guidance progressing independently. Site build/guide publication is not claimed completed.

## Historical registrar DNS handoff — 2026-10-07

The following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.

> I need the DNS information. Sorry, that may have gotten lost in the shuffle, but I don't have those records yet. Please let me know what I need to populate with my registrar.

For GitHub Pages, add pixelelated.com in repository Settings → Pages → Custom domain before pointing DNS. The bot currently receives403 for Pages settings, so that setup is not claimed complete. Source repository privacy stays unchanged; check plan/host eligibility before activating hosting.

| Type | Host | Value |
| --- | --- | --- |
| A | @ | 185.199.108.153 |
| A | @ | 185.199.109.153 |
| A | @ | 185.199.110.153 |
| A | @ | 185.199.111.153 |
| CNAME | www | pixelelated.github.io |

Keep the default TTL or use3600 seconds. Preserve Proton Mail MX and mail-related TXT records; no nameserver change is required. Optional IPv6 and organization TXT-verification instructions are in docs/pixelelated/site-dns.md; a verification TXT value comes from GitHub, not from guessing the domain.

Official source checked2026-10-07: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site . Actual filtered API/DNS receipts are in docs/qa-logs/2026-10-07-site-access/. Instructions were given to the owner; no DNS changes, site build or deployment were run.

## Linked M7 Wi-Fi setup-guide follow-up — #577

This is the corresponding public setup-documentation follow-up for #577's final criterion. Its software proof is complete; guide delivery remains owned here in the existing website lane. Recording this task does not claim a published guide change or authorize deployment, an upstream submission, a new live URL, or physical-device testing. Website delivery remains parallel and does not add a firmware build/RC gate. Relevant upstream public documentation must still be prepared alongside its eventual feature submission under #585.

Use the existing setup-guide source or a linked Wi-Fi section; choose its actual destination in the website lane rather than inventing a route. Describe the qualified behavior:

- Open **Network Settings → Wi-Fi Network**. The network list keeps a stable viewport and scrolls for longer results. Initial searching appears inside the list area.
- **Refresh** keeps the last usable results visible while checking. A completed empty scan and a failed scan have distinct outcomes; on failure, retain the previous results and use **Refresh** to try again. Do not describe a failed enumeration as proof that no network exists.
- **Back** closes the picker during a scan. A bounded read can finish after the picker closes; reopening attaches to the pending read rather than starting a second scan. Do not promise immediate cancellation or universal service/fatal-exit containment.
- Preserve saved/connected marks and existing connection routes: confirmed open networks do not ask for a key, protected/unknown networks use the key editor, multiple saved profiles require an explicit choice, and **Forget** requires confirmation and affects the selected profile. Cancellation preserves it and sibling profiles remain.

Agent-verifiable delivery within this existing docs work:

- [ ] A retained guide-source commit/diff updates the setup instructions for the behaviors above, with a source-to-prose mapping to ES `16dbac5211eea7e70db7394372033be2be7df829` and the current canonical reference. Existing guide build/prose/link checks and reviewed chosen screenshots substantiate the change; no owner credential or live network is required.
- [ ] The website lane links that exact guide change and its existing validation receipts back to #577/#511. Any eventual public URL, publication status or upstream docs PR is recorded from its actual result; no placeholder destination or deployment claim is substituted.

Evidence: [canonical flow and frame reference](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/es-menu-map.md); [four locale/size setup matrix](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-13-setup-qualification/installed/README.md); [installed backend and missing-route proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-remaining-result/README.md); [Back/reopen and normal-exit proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-normal-exit-result/README.md); [final clean installed proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-final-engineering-result/clean/README.md); [final retained-update proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-final-engineering-result/retained/README.md). The product evidence uses synthetic enumeration/profile transport, not a physical radio or real credentials. The installed final image proof is f863/ES16dbac; older component and failed-original scopes remain explicitly retained.

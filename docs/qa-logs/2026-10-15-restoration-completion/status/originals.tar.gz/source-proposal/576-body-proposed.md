## Current disposition — deferred backlog, no milestone

D-WORKFLOW-163 retains GTK4 as a diagnostic alternative requiring a separately allocated dependency/API/native-keyboard spike before production consideration. The current M7 plan explicitly lists #576 as backlog, not an extra RC gate. Source-only feasibility is complete; the existing preflight/compile-wrapper exit 2 occurred before compilation. No GTK4 build, sign-in, renderer, memory or recovery result is claimed.

Keep this issue open outside M7 with title **Backlog: Evaluate GTK4 sign-in rendering for browser pressure** and no milestone. This is scheduling reconciliation, not permanent rejection or completed runtime acceptance. Future execution requires a new explicit allocation under the ordinary capacity/lifecycle rules. The four unproved criteria below remain open; the scheduling decision does not substitute for their required measured outcomes. The completed source evidence and historical failures remain unchanged.

## Owner request

> Should we try GTK4?

Context: #570 browser memory/latency investigation; earlier owner question: “Also, have we tried different GSK renderers?” All user-agent comparisons so far use WebKit2.54.1's GTK3 build, not different engines.

## What exists today

`cloud-signin-window` depends on gtk3 and links gtk+-3.0 / webkit2gtk-4.1. WebKit recipe explicitly sets USE_GTK4=OFF. No GTK4/Graphene recipe or ready host GTK4/WebKit6 development pair was found. GSK_RENDERER does not select a backend for this GTK3 application. Existing WebKit DMA-BUF/Panfrost trials remain relevant but inconclusive; changing GTK must not be represented as an already-proved fix.

Source migration work includes GTK containers/packing, draw callback, lifecycle/event controllers, on-screen keyboard's fabricated GDK events, style/display APIs, and related auth views. WebKit6 requires new construction/network-session APIs; preserve ephemeral sessions, related-view state, host restrictions and completion. Review process-swap and sandbox requirements in the exact target version. Current recipe disables the sampling profiler too, which must be considered when designing JS attribution tests.

Upstream check October13: https://github.com/WebKit/WebKit/blob/main/Source/WebKit/gtk/migrating-to-webkitgtk-6.0.md , https://docs.gtk.org/gtk4/migrating-3to4.html , https://www.webkitgtk.org/2026/09/16/webkitgtk-2.54-highlights.html . WebKit6 is the GTK4 API, not WebKit engine version6. GTK4 can alter toolkit rendering/frame integration, while WebKit/JavaScriptCore still runs provider code. No matching incident-specific GTK4 fix established.

## Ordered investigation

Related to #570 and retained as unscheduled backlog outside M7. CSS-width controls are complete and retired, and source-only GTK4 feasibility is complete. D-WORKFLOW-163 prioritizes actual-page CPU/script versus reclaim attribution; this issue holds no renderer/runtime allocation. Any later GTK4 trial must be separately scheduled and serialized under the coordinator. Keep engine version and non-GTK options matched where supported; document unavoidable changes instead of claiming a pure single-variable comparison. #493 lifecycle/capacity enforcement precedes any new full cache copy/build. Use an isolated feature/build checkout; accepted GTK3 cache/artifact stays immutable. Production GTK4 migration is deferred. Any later adoption proposal must establish its own evidence; this is not an unconditional distro-wide GTK migration.

## Agent-verifiable acceptance

Can this be done on the VM? **Yes** for dependency/compile/functional/memory experiments. H700-specific GPU buffers and hardware recovery require only the existing named browser-bench scope after VM success.

- [x] Dependency/API inventory binds exact GTK4 and WebKit source versions, patches, build flags, new runtime requirements and required source adaptations; includes the same-version GTK3 control direction and dated upstream check. Evidence: da0ecd8 packet, independently source-reviewed; no runtime control claimed.
- [ ] Isolated build proof (or concrete bounded feasibility failure) retains pkgcheck/build/installed dependency outputs, watcher completion channels and capacity/retention receipt; no accepted artifact overwritten.
- [ ] If runnable, benchmark actual supported GSK renderers with observed renderer/driver evidence, matched UA/CSS viewport/engine/content controls, PSS/CPU/reclaim/input latency and native frames. Record unsupported/guard-truncated outcomes honestly.
- [ ] VM synthetic auth flow verifies on-screen keyboard, phone input ordering, pad exit, page navigation, popup return, localhost callback and ephemeral-state disposal, with exact-source flow/frame index. No owner account needed.
- [ ] Written adopt/defer decision cites measured responsiveness/memory/recovery and compatibility outcomes. Any proposed production change completes ordinary clean/retained VM, code-audit and physical-fact gates before candidate promotion; an unsuccessful experiment does not force migration.

Completed worker: pix-gtk4, Herdr w4:p7, feature/m7-gtk4-576. Immutable da0ecd80473037708dab38e82ea458708cc8c1b6 +10f9b16cc5b61e5d3b53ac64cf28bb47cef73946 reviewed and integrated in the coordinator branch. No runtime allocation is held.

## Bounded feasibility outcome

D-WORKFLOW-163: defer a production GTK4 port; retain a separately allocated dependency/API/native-keyboard spike. Exact WebKit2.54.1 and GTK4.24.1 source inventory identifies Graphene/GTK4/WebKit6 absence, target sandbox staging requirements, and no direct public GTK4 replacement for the current fabricated native keyboard events. Existing preflight/compile-wrapper exit2 occurred before compilation; no build, sign-in, renderer, memory or recovery proof exists. The current script's process-group timeout correction has static review only; historical receipts keep their original bindings, and documented synthetic cleanup controls precede a compile allocation.

Evidence: docs/qa-logs/2026-10-13-gtk4-feasibility/README.md, port-map.md, build-direction.md, vm-acceptance.md and timeout-cleanup-correction.md. Remaining criteria stay open with these limits; no production dependency/recipe change or unconditional M7 toolkit migration is selected. The concurrent proxy candidate measured390KiB import savings in its separate VM test, not a reason to remove offline functions. Record published at `1a37cde40ab0893c9c21c0a383c59ac0c1403b06`; both exact-head hosted checks passed, all delivery03 channels0 and owners exited. The refused delivery02 remains preserved; no published history was rewritten.

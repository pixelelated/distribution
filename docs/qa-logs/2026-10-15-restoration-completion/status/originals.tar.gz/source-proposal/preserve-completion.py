from pathlib import Path
import hashlib,json,os,stat,tarfile,gzip,decimal,datetime
S=Path('/tmp/pix-m7-remaining-foundation-restore-20261015');A=Path('/tmp/pix-m7-restoration-issue-actions-20261015');D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-restoration-completion')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
assert not D.exists();D.mkdir()
assert sha(S/'SHA256SUMS')=='adbfdbecad0a4cea76ab08b8cbbe6fc132df6862d5446cf9e2ab58e213d3775f'
for l in (S/'SHA256SUMS').read_text().splitlines():h,n=l.split('  ',1);assert sha(S/n)==h
j349=load(A/'349-after.json');j563=load(A/'563-after.json');assert j349['state']=='closed' and j349['state_reason']=='completed' and j563['state']=='open'
assert j349['body']==(S/'349-body-proposed.md').read_text() and j563['body']==(S/'563-body-proposed.md').read_text()
assert load(A/'349-comment.json')['body']==(S/'349-close-proposed.md').read_text()
rows=[];pairs=[]
for root,prefix in [(S,'reconciliation'),(A,'issue-actions')]:
 for p in [root,*sorted(root.rglob('*'))]:
  assert not p.is_symlink() and (p.is_file() or p.is_dir());s=p.stat();n=prefix+('/'+str(p.relative_to(root)) if p!=root else '')
  row={'member':n,'original_path':str(p),'kind':'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None}
  rows.append(row);pairs.append((p,n,row))
archive=D/'originals.tar.gz'
with archive.open('xb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for p,n,row in pairs:
    ti=t.gettarinfo(str(p),arcname=n);ti.pax_headers={'mtime':str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(10**9))};row['uname']=ti.uname;row['gname']=ti.gname
    if p.is_file():
     with p.open('rb') as f:t.addfile(ti,f)
    else:t.addfile(ti)
with tarfile.open(archive,'r:gz') as t:
 ms=t.getmembers();assert len(ms)==len(rows)
 for m,r in zip(ms,rows):
  assert m.name.rstrip('/')==r['member'] and m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'] and m.uname==r['uname'] and m.gname==r['gname']
  assert int(decimal.Decimal(m.pax_headers['mtime'])*decimal.Decimal(10**9))==r['mtime_ns']
  if r['kind']=='file':
   assert m.isfile() and m.size==r['bytes'];b=t.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==r['sha256']==sha(Path(r['original_path']))
  else:assert m.isdir()
dump(D/'members.json',{'archive_sha256':sha(archive),'members':rows,'files':sum(r['kind']=='file' for r in rows),'directories':sum(r['kind']=='directory' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)})
dump(D/'outcomes.json',{'scope':'Actual #349 completed closure and #563 partial criterion update; source-only reconciliation, website publication originals and accepted prior source/frame/restore evidence.','source_packet_seal':sha(S/'SHA256SUMS'),'349':{'state':j349['state'],'state_reason':j349['state_reason'],'closed_at':j349['closed_at'],'updated_at':j349['updated_at'],'body_sha256':hashlib.sha256(j349['body'].encode()).hexdigest(),'url':j349['html_url']},'563':{'state':j563['state'],'updated_at':j563['updated_at'],'body_sha256':hashlib.sha256(j563['body'].encode()).hexdigest(),'newly_checked_criteria':[4,5],'remaining_open_criteria':[3,6],'url':j563['html_url']},'website':{'merge_commit':'6aac689c6feaa8d4afefbd5a8b2121e5206f14b9','public_page':'https://pixelelated.com/guides/cloud/','public_html_sha256':'4891f14feaf0bd78694fbca1cb27f123cdba0f670f16a7ccbe51107e6d7c9d18','readback_utc':'2026-10-15T10:07:16.363444+00:00'},'qualification_limits':['No new restore VM or firmware replay.','Earlier wrong-path fixture failure is retained separately from successful selection and later preservation proof.','Foundation source-custody/licence and existing required physical/native facts remain open.','No RC, firmware-publication or legal clearance.','Separate #511/#576 status proposals are not tracker actions.']})
(D/'README.md').write_text('''# Settings-restore documentation completion and foundation reconciliation

Issue #349 was closed completed at 10:15:53 UTC on 2026-10-15 after its remaining documentation criterion was delivered. Website PR #4 merged as `6aac689c6feaa8d4afefbd5a8b2121e5206f14b9`; exact-head PR/main checks and deployment succeeded. The public cloud guide returned HTTP 200 at 10:07:16 UTC with all five expected restore statements. The previously accepted installed restore proof, source applicability, archive/journal and offered/foreign-only frames remain bound to their original images. No restore VM replay was performed.

Issue #563 was updated at 10:15:56 UTC: criteria 4 and 5 now record delivered retention/resources, final clean/retained VM and completed audit evidence. Criteria 3 and 6 remain open for current source-custody/licence coverage and the existing required physical/native facts. Accepted H700/SM artifact integrity and the portable Steam bridge do not establish physical boot, the actual internal ABL chain or native ARM execution. Mixed engineering sources, original failures and publication boundaries remain explicit.

`originals.tar.gz` retains the exact sealed reconciliation packet and actual guarded issue-action requests/responses/readbacks. `members.json` maps every archive member to its original path, bytes/hash, mode, ownership and nanosecond timestamp. `custody-verification.json` records exact archive-to-original verification. `outcomes.json` summarizes actual issue states without replacing the originals.

The archive includes the small website patch and both pre-publication and actual published-page records. Historical missing-page evidence and the prior restore fixture's wrong-path failure retain their original meanings. Large firmware, caches and bulk native archives are excluded. Original stores remain intact; no deletion, runtime, shared-record change or commit occurred while making this custody packet. Separate #511/#576 status proposals remain unexecuted outside this archive. No RC, firmware-publication or legal clearance is claimed.
''')
dump(D/'custody-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_CUSTODY','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'checks':['Original source packet seal and all 114 payload hashes verified.','Actual issue bodies equal reviewed proposals and #349 actual comment equals reviewed close text.','All archive member names, types, bytes, hashes, modes, uid/gid, uname/gname and exact nanosecond mtime matched originals.','Original source/action stores preserved; no archive extraction or product execution.']})
files=sorted(p for p in D.iterdir() if p.is_file());(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
for l in (D/'SHA256SUMS').read_text().splitlines():h,n=l.split('  ',1);assert sha(D/n)==h
print(json.dumps({'destination':str(D),'seal_sha256':sha(D/'SHA256SUMS'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)},indent=2))

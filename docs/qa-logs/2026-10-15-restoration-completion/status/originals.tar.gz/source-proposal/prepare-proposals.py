from pathlib import Path
import json,hashlib,difflib,subprocess,datetime,shutil
D=Path('/tmp/pix-m7-restoration-status-reconcile-20261015');C=Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,sort_keys=True,indent=2)+'\n')
j511=load(D/'511-live.json');j576=load(D/'576-live.json');old=j511['body'];new=old
status='''## Current status — public preview and restore guide published, 2026-10-15

The website preview is live at [pixelelated.com](https://pixelelated.com/), with published [cloud](https://pixelelated.com/guides/cloud/), [ROM](https://pixelelated.com/guides/roms/) and [BIOS](https://pixelelated.com/guides/bios/) setup guides. The source repository remains private. Website PRs #1/#2, their retained build/prose/link/layout checks, initial publication and HTTPS enforcement are recorded in the October 11–12 comments. The October 12 readback verified 16 redirect/content cases; that is dated evidence, not a new claim that every route was tested today.

[Website PR #4](https://github.com/pixelelated/website/pull/4) adds the same-model settings-restore explanation for #349. PR head `435ebc956cbe39da69e83158008efe9956662e1f` passed checks `38717338495`; merge `6aac689c6feaa8d4afefbd5a8b2121e5206f14b9` passed main checks `38717686667` and deployment `38717686819`. The public cloud guide returned HTTP 200 at 2026-10-15 10:07:16 UTC; exact HTML SHA256 `4891f14feaf0bd78694fbca1cb27f123cdba0f670f16a7ccbe51107e6d7c9d18` contains the newest compatible model backup, model/date, foreign-model exclusion and visible disabled-state explanation. #349 is closed completed; no restore VM replay was needed. Exact source, frames, publication and issue-action originals are retained in `docs/qa-logs/2026-10-15-restoration-completion/`.

Remaining work here is the existing source-to-guide maintenance (including the linked #577 Wi-Fi follow-up below), the separate design exploration, and firmware **See instructions** integration: actual destination binding, EN/FR controller QR frames, decoded URLs, offline/missing-destination controls and matched menu/localization documentation. Published URLs alone do not satisfy those firmware behaviors. No firmware QR action was enabled by PR #4. The acceptance checklist below remains unchanged by this status-only reconciliation; this is not a closure of #511 or a new firmware RC gate.

The earlier lane trust prompt, repository-creation/access blockers, 404/certificate failures, missing Pages setup and “site not yet live” statements below are historical observations and superseded next steps. They must not be treated as current blockers or repeated without a new reason. The unrelated website design checkout and draft PR #3 remain separate from the published guide change.

'''
new=status+new
for a,b in {
'## Dedicated Herdr website lane — 2026-10-08':'## Historical lane creation — 2026-10-08',
'## Current status: repository ready, DNS verified; site not yet live':'## Historical repository/DNS status — 2026-10-07, before publication',
'## DNS verification — 2026-10-07 21:30 UTC':'## Historical DNS verification — 2026-10-07 21:30 UTC',
'## Parallel planning brought forward':'## Historical parallel-planning decision',
'## Hosting and repository clarification':'## Historical hosting and repository clarification',
'## Inventory and prepared repository — 2026-10-07':'## Historical inventory and prepared repository — 2026-10-07',
'## Registrar DNS handoff':'## Historical registrar DNS handoff — 2026-10-07',
}.items():assert new.count(a)==1;new=new.replace(a,b)
for heading in ['## Historical lane creation — 2026-10-08','## Historical repository/DNS status — 2026-10-07, before publication','## Historical DNS verification — 2026-10-07 21:30 UTC','## Historical parallel-planning decision','## Historical hosting and repository clarification','## Historical inventory and prepared repository — 2026-10-07','## Historical registrar DNS handoff — 2026-10-07']:
 new=new.replace(heading+'\n',heading+'\n\nThe following is the dated historical record; its unfinished-status and next-action statements are superseded by the current status above.\n',1)
oldscope="Planning is now active in parallel, without a milestone or a new 0.0.1 release gate. The dated requests below show how scheduling evolved. #510 owns the current cloud-validator contract and #508 its implementation. The full pixelelated site/wiki and these guide destinations are deferred; the planned validator must remain useful with on-device instructions and expected paths until the guides exist."
newscope="Website work remains parallel, without a milestone or a new 0.0.1 release gate. The dated requests below show how scheduling evolved. #510 owns the cloud-validator contract and #508 its implementation. The site and guide destinations now exist as published previews; controller QR integration and the remaining guide follow-ups are still separate work. Existing on-device instructions and expected paths remain useful offline."
assert oldscope in new;new=new.replace(oldscope,newscope)
new=new.replace('1. Build out the pixelelated site with a wiki/documentation area when scheduled. Reuse the existing site and documentation work after reviewing its current state; this issue does not select a new framework, host, or deployment today.','1. Maintain the existing published pixelelated site and documentation area. Reuse its source and retained validation; this reconciliation selects no replacement framework, host or deployment mechanism.')
new=new.replace('2. Publish a cloud setup guide and distinct ROM setup and BIOS setup pages. Show the actual supported folder layout, how to place files from a computer, and how to run the validator again.','2. Keep the published cloud setup guide and distinct ROM and BIOS setup pages aligned with the qualified product. Show the actual supported folder layout, how to place files from a computer, and how to run the validator again.')
# Existing historical quotes and literal criteria remain exactly intact.
assert [l for l in old.splitlines() if l.startswith('>')]==[l for l in new.splitlines() if l.startswith('>')]
assert [l for l in old.splitlines() if l.startswith('- [')]==[l for l in new.splitlines() if l.startswith('- [')]
(D/'511-body-proposed.md').write_text(new);dump(D/'511-request-proposed.json',{'body':new})
(D/'511-body.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='511-live-body.md',tofile='511-body-proposed.md')))
old=j576['body'];new=old
status='''## Current disposition — deferred backlog, no milestone

D-WORKFLOW-163 retains GTK4 as a diagnostic alternative requiring a separately allocated dependency/API/native-keyboard spike before production consideration. The current M7 plan explicitly lists #576 as backlog, not an extra RC gate. Source-only feasibility is complete; the existing preflight/compile-wrapper exit 2 occurred before compilation. No GTK4 build, sign-in, renderer, memory or recovery result is claimed.

Keep this issue open outside M7 with title **Backlog: Evaluate GTK4 sign-in rendering for browser pressure** and no milestone. This is scheduling reconciliation, not permanent rejection or completed runtime acceptance. Future execution requires a new explicit allocation under the ordinary capacity/lifecycle rules. The four unproved criteria below remain open; the scheduling decision does not substitute for their required measured outcomes. The completed source evidence and historical failures remain unchanged.

'''
new=status+new
start='Subtask of #570, within M7.P5: CSS-width controls are complete and retired. At the owner\'s invitation, source-only GTK4 feasibility is complete; script/CPU/reclaim attribution remains the coordinator\'s next priority. Actual renderer/runtime trials remain serialized under the coordinator.'
replacement='Related to #570 and retained as unscheduled backlog outside M7. CSS-width controls are complete and retired, and source-only GTK4 feasibility is complete. D-WORKFLOW-163 prioritizes actual-page CPU/script versus reclaim attribution; this issue holds no renderer/runtime allocation. Any later GTK4 trial must be separately scheduled and serialized under the coordinator.'
assert start in new;new=new.replace(start,replacement)
oldtail='A smaller successful #570 fix can make migration unnecessary for this RC; this is an evidence-based adopt/defer decision, not an unconditional distro-wide GTK migration.'
assert oldtail in new;new=new.replace(oldtail,'Production GTK4 migration is deferred. Any later adoption proposal must establish its own evidence; this is not an unconditional distro-wide GTK migration.')
assert [l for l in old.splitlines() if l.startswith('- [')]==[l for l in new.splitlines() if l.startswith('- [')]
assert [l for l in old.splitlines() if l.startswith('>')]==[l for l in new.splitlines() if l.startswith('>')]
(D/'576-body-proposed.md').write_text(new);dump(D/'576-request-proposed.json',{'title':'Backlog: Evaluate GTK4 sign-in rendering for browser pressure','body':new,'milestone':None})
(D/'576-body.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='576-live-body.md',tofile='576-body-proposed.md')))
(D/'576-scheduling-comment.md').write_text('''Reconciled scheduling with D-WORKFLOW-163 and the current M7 plan: #576 remains open as backlog with no milestone. The reviewed dependency/API/native-keyboard feasibility packet remains accepted in its source-only scope. The pre-compilation exit 2 and all unproved build/renderer/auth/measurement criteria retain their original status. No production GTK4 migration, runtime allocation, acceptance waiver or extra RC gate is introduced.\n''')
# Retain exact selected decision and current milestone observations, without touching shared records.
raw=subprocess.check_output(['git','-C',str(C),'show','next:docs/decision-register.md']);lines=raw.decode().splitlines();row=[(i,l) for i,l in enumerate(lines,1) if l.startswith('| D-WORKFLOW-163 |')];assert len(row)==1
milestone=j576['milestone'];matched=[l for l in milestone['description'].splitlines() if '#576' in l or 'GTK4' in l]
dump(D/'decision-evidence.json',{'decision_source':'git next:docs/decision-register.md','source_sha256':hashlib.sha256(raw).hexdigest(),'line':row[0][0],'verbatim_row':row[0][1],'current_milestone':{'number':milestone['number'],'title':milestone['title'],'description_sha256':hashlib.sha256(milestone['description'].encode()).hexdigest(),'verbatim_selected_lines':matched},'meaning':'Separate backlog scheduling follows the explicit current milestone plan and D-WORKFLOW-163; the decision alone does not supply any missing runtime result.'})
guards={}
for n,j in [(511,j511),(576,j576)]:
 guards[str(n)]={'state':j['state'],'title':j['title'],'updatedAt':j['updatedAt'],'milestone':None if j['milestone'] is None else {'number':j['milestone']['number'],'title':j['milestone']['title']},'body_sha256':hashlib.sha256(j['body'].encode()).hexdigest(),'comments_sha256':hashlib.sha256(json.dumps(j['comments'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'proposed_body_sha256':sha(D/f'{n}-body-proposed.md'),'proposed_request_sha256':sha(D/f'{n}-request-proposed.json')}
dump(D/'application-guards.json',{'issues':guards,'apply_rule':'Coordinator must re-read live body/title/state/updatedAt/milestone and compare these exact fields before any mutation. If changed, reconcile the intervening change explicitly. No mutation was executed by this worker.','511_scope':'Body/current-status only; preserve every checkbox, owner quote, title, labels, milestone and open state.','576_scope':'Body + Backlog title + milestone JSON null only; preserve every checkbox, owner quote, labels, relationship to #570 and open state. Post-readback must show null milestone; retain actual request/response and scheduling comment.'})
(D/'README.md').write_text('''# Website-status and GTK4 scheduling proposals

These are source-only tracker proposals. No tracker mutation or new runtime was executed.

For #511, `511-body-proposed.md` adds the actual live-site and PR #4 status, marks the old lane/access/404/non-live instructions historical, and updates the scope wording to maintain existing published preview guides. It retains all seven literal checkboxes and all owner quotations. Remaining QR destination binding, rendered/decoded EN/FR frames, offline controls, menu/localization consistency, design exploration and the linked #577 Wi-Fi guide follow-up stay explicit. The existing first guide criterion is not re-adjudicated by this narrow status correction.

For #576, `576-request-proposed.json` proposes the Backlog title, revised scheduling body and `milestone: null`, matching D-WORKFLOW-163 and the current M7 plan. The issue remains open; one completed source criterion and four unproved criteria remain unchanged. The completed source feasibility, pre-compilation failure and absence of GTK4 runtime proof are preserved. No re-parenting, production migration, experiment or acceptance waiver is proposed.

`application-guards.json` binds the fresh live issue reads and proposed hashes. Root must re-read before applying and retain actual responses/readback. The first sandboxed #511 GET failed to connect; its empty output/error are retained separately, followed by successful authenticated read-only GETs for both issues. `decision-evidence.json` retains the exact source row and current milestone excerpts.

Actual #349 completion and #563 partial reconciliation are separately durable under `docs/qa-logs/2026-10-15-restoration-completion/`, seal `dde546e06ce2c0985846a02eda06fbf4c81773ee2abe6d7d3707e4f7ec0edabf`. Its exact website-publication originals support the current #511 paragraph. No guide publication, DNS, source visibility, runtime, shared-record change or commit occurred in this status-proposal worker.
''')
print(json.dumps({'511_body_sha256':sha(D/'511-body-proposed.md'),'576_body_sha256':sha(D/'576-body-proposed.md'),'576_request_sha256':sha(D/'576-request-proposed.json'),'criteria_unchanged':True},indent=2))

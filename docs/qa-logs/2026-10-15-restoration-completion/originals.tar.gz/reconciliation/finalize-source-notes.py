from pathlib import Path
import hashlib,json,subprocess,difflib,datetime
D=Path('/tmp/pix-m7-remaining-foundation-restore-20261015')
def dump(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
# Preserve the initial assembler and its outputs' historical derivation; this pass is editorial plus selected tracked-source excerpts.
changes={'under#528':'under #528','priorbc9d':'prior bc9d','only4/5':'only 4/5',';3/6':'; 3/6','mixedf863/9aa7':'mixed f863/9aa7','exact640px':'exact 640 px','returned200':'returned 200','check0 with0fail/0warn':'check 0 with 0 failures and 0 warnings','all10':'all 10','old#349':'old #349','is#349':'is #349','fresh200':'fresh 200','close#349':'close #349','already-owned#528':'already-owned #528','October11/12':'October 11/12','ABL1.2 fixes#558':'ABL 1.2 fixes #558','at2026-10-15':'at 2026-10-15','replacement19':'replacement 19','paired640':'paired 640','unchanged19→20':'unchanged 19→20','broader#511':'broader #511','at8abd':'at 8abd','is071e':'is 071e','SHA9335':'SHA 9335','passes0,0fail/0warn':'passes with exit 0, 0 failures and 0 warnings','all#511':'all #511','in#349 and#511':'in #349 and #511','guarded#349':'guarded #349','rawreadback':'raw readback'}
for rel in ['README.md','349-close-after-docs.md','website/handoff.md']:
 p=D/rel;t=p.read_text()
 for a,b in changes.items():t=t.replace(a,b)
 p.write_text(t)
p=D/'563-body-proposed.md'; t=p.read_text(); old=json.loads((D/'live/563.json').read_text())['body'];head,tail=t.split('## Current criterion reconciliation — 2026-10-15',1)
for a,b in {'runs041900Z/042200Z':'runs 041900Z/042200Z','acceptancee8107b4b/bundle32f7a652':'acceptance e8107b4b / bundle 32f7a652','acceptanceb576f190/bundle09addac6':'acceptance b576f190 / bundle 09addac6','inventory093346Z-ed162eab':'inventory 093346Z-ed162eab','VM/H700f863 and SM9aa7':'VM/H700 f863 and SM 9aa7','for#528':'for #528','priorbc9d':'prior bc9d','Existing#528/#344':'Existing #528/#344'}.items():tail=tail.replace(a,b)
t=head+'## Current criterion reconciliation — 2026-10-15'+tail;p.write_text(t)
(D/'563-body.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),t.splitlines(True),fromfile='live/563-body.md',tofile='563-body-proposed.md')))
# Do not edit literal historical issue text when cleaning our assessments.
p=D/'criterion-map.json';o=json.loads(p.read_text())
for rows in o.values():
 for row in rows:
  t=row['assessment']
  for a,b in {'stablec445081a':'stable c445081a','bothf863 and9aa7':'both f863 and 9aa7','Linux7.2':'Linux 7.2','ABL1.2':'ABL 1.2','under#528':'under #528','alreadyPASS':'already PASS','as#597':'as #597','priorbc9d':'prior bc9d','and#528':'and #528','replacement18':'replacement 18','replacement19':'replacement 19','failed.19→20':'failed. 19→20','guideGET200 on2026':'guide GET 200 on 2026','websitecloud.md':'website cloud.md'}.items():t=t.replace(a,b)
  row['assessment']=t
dump(p,o)
# Exact frozen source supports the public explanation; no guest or source checkout mutation.
C='/workspace/repos/rocknix.worktrees/m7-player-setup';E='/home/max/Development/emulationstation-next';F='f8636de1d105275dbf9420bbabbbc26f79abb10f';ES='16dbac5211eea7e70db7394372033be2be7df829'
rows=[]
for repo,commit,path,start,end,claim in [
 (C,F,'projects/ROCKNIX/packages/network/rclone/sources/cloud_scan',319,344,'The scan uses the selected archive directory, filters the exact model label and recognised OS suffixes, and takes the last chronological archive for MINE.'),
 (C,F,'projects/ROCKNIX/packages/network/rclone/sources/cloud_restore',2077,2110,'Restore chooses the same-model newest archive when present; direct-script legacy fallback is separate from what the settings UI offers.'),
 (E,ES,'es-app/src/guis/GuiMenu.cpp',4886,4913,'The restore UI parses MINE, disables and unticks SETTINGS if absent/invalid, otherwise displays model and localised date.')]:
  cmd=['git','-C',repo,'show',commit+':'+path];r=subprocess.run(cmd,capture_output=True,check=True);b=r.stdout
  rows.append({'argv':cmd,'original_exit':r.returncode,'stderr':r.stderr.decode(),'commit':commit,'path':path,'source_sha256':sha(b),'source_bytes':len(b),'lines':[start,end],'verbatim_excerpt':'\n'.join(b.decode().splitlines()[start-1:end])+'\n','claim':claim})
# Explicitly verify the UI decision itself has not changed since the installed paired-frame source.
path='es-app/src/guis/GuiMenu.cpp'; oldes='c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78'
bs=[subprocess.check_output(['git','-C',E,'show',c+':'+path]) for c in [oldes,ES]]
def region(b):
 start=b.index(b'\t// On a restore the row is offered only when the cloud holds a settings')
 end=b.index(b'\n\t// Written on the way out,',start)
 return b[start:end]
a,b=map(region,bs);assert a==b
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only Git object extraction; no cache access, product execution or source mutation.','sources':rows,'ui_selection_region_continuity':{'old_es':oldes,'current_es':ES,'path':path,'identical':True,'bytes':len(a),'sha256':sha(a)}}
dump(D/'website/source-excerpts.json',out)
p=D/'website/content-review.json';o=json.loads(p.read_text());o['source_excerpts']='website/source-excerpts.json';o['source_continuity']+=' The precise offered/disabled UI region is also byte-identical c8dc72cf→16dbac, directly checked in source-excerpts.json.';o['assertions'][-1]['limit']=o['assertions'][-1]['limit'].replace('check0 with0fail/0warn','check 0 with 0 failures and 0 warnings');dump(p,o)
p=D/'README.md';t=p.read_text().replace('`source-readback.json` contains current read-only stable-ancestry and unchanged restore-script comparisons.','`source-readback.json` contains current read-only stable-ancestry and unchanged restore-script comparisons. `website/source-excerpts.json` binds the exact scan, restore and UI selection code; the offered/disabled UI region is byte-identical between the accepted frame source and current ES 16dbac.');p.write_text(t)
print(json.dumps({'source_excerpt_rows':len(rows),'ui_selection_region_bytes':len(a),'563_body_sha256':sha((D/'563-body-proposed.md').read_bytes()),'site_patch_sha256':sha((D/'website/cloud.md.diff').read_bytes())},indent=2))

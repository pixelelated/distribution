---
description: Add a cloud connection and check the folders used for saves, settings, and game files.
preview: true
---

# Cloud setup

Connect your cloud storage to back up and restore files from your handheld.
You'll need an internet connection and an account with your chosen provider.

## Add a connection

1. **Open cloud settings:** Press `START`, then select `GAME SETTINGS` →
   `CLOUD SETTINGS` → `MANAGE CLOUD STORAGE`.
2. **Open your connections:** Under `CLOUD STORAGE SETUP`, select
   `CLOUD CONNECTIONS`. This lists the connections saved on this device.
3. **Add your provider:** Select `ADD CONNECTION` and choose your provider.
   Follow the sign-in instructions on the screen.
4. **Choose the connection to use:** If the new connection is saved without
   becoming active, select it under `CLOUD CONNECTIONS`, then choose
   `USE THIS CONNECTION` and confirm. The active connection is marked `IN USE`.

Adding the same provider again creates a separate saved connection. It does
not replace your existing sign-in. A saved connection may still need you to
sign in again; select it and choose `CHECK CONNECTION` to see whether it answers.

Connecting does not create cloud folders or turn on automatic save sync.

## Choose your folders

From `MANAGE CLOUD STORAGE`, select `CHANGE CLOUD FOLDER`. You can change
each location separately:

| Setting | Default for a new setup | What goes there |
| --- | --- | --- |
| `SAVES FOLDER` | `/pixelelated/Saves` | Game saves, save states, and screenshots |
| `SETTINGS FOLDER` | `/pixelelated/Backups` | Settings backups |
| `ROMS, BIOS, AND GAME CONTENT FOLDER` | `/pixelelated/Content` | ROMs, BIOS files, and scraped game content |

An upgrade keeps your existing folder choices. Use the paths shown on your
device if they differ from these examples. Changing one path leaves the
others in place and does not move your files.

## Check or create folders

1. **Choose what to check:** Return to `MANAGE CLOUD STORAGE` and select
   `CHECK CLOUD FOLDERS`. Select the categories you want to check.
2. **Run the check:** Select `CHECK FOLDERS`. The results show what was found
   at the selected locations.
3. **Read the finding:** Select `SEE INSTRUCTIONS` for the expected path and
   the next step for that category.
4. **Create missing folders if needed:** Return to the category choices,
   select `CREATE FOLDERS`, and review the confirmation. This creates the
   selected folders and setup notes. It does not add your ROMs or BIOS files.

Checking reads the selected folders. It does not reorganize your files or
start a transfer. Category choices apply to checking and creating folders;
they do not enable automatic sync.

Use a computer to [add ROMs](roms.md) or [add BIOS files](bios.md), then run
`CHECK FOLDERS` again. A successful folder check does not verify every file's
contents or its compatibility with an emulator.

## Manage a saved connection

Select a connection under `CLOUD CONNECTIONS` to see its available actions.

| Action | What happens |
| --- | --- |
| `CHECK CONNECTION` | Checks whether that saved connection answers |
| `USE THIS CONNECTION` | Changes the active connection after confirmation and keeps your folder paths |
| `SIGN IN AGAIN` | Replaces that connection's sign-in after the new sign-in is verified |
| `EDIT CONNECTION` | Changes the settings supported by that provider |
| `REMOVE CONNECTION` | Removes local access to that connection, leaving cloud files in place |

Before changing a connection used by automatic save sync, turn automatic sync
off. After switching accounts, check your selected folders before the next
backup or restore. Removing the active connection leaves no connection in use.

## If sign-in does not finish

Choose `TRY AGAIN` to start a fresh sign-in, or `CANCEL SIGN-IN` to stop.
A failed sign-in is not always an expired code. Follow any explanation shown
on the screen. A failed or cancelled `SIGN IN AGAIN` keeps the existing sign-in.

Your connection should now be marked `IN USE`, with folder findings for the
categories you checked.

# Website agent instructions

This repository owns the pixelelated website and documentation source.
Product identity is **pixelelated**, lowercase. Use the approved Tiny5 Duo LCD
wordmark assets; preserve upstream attribution and licenses when reusing work.

Planning is tracked in pixelelated/distribution#511. Keep all work and decisions
findable there; the distribution milestone owns firmware priorities. Do not
make website delivery a firmware release gate.

Before writing player guides, read the canonical developer-relations skill and
player-language rules in pixelelated/distribution on next. Use the actual
qualified interface and paths, not old proposal copy. Cloud flow changes are
tracked in distribution#510/#508. Documentation QR destinations may be enabled
only after the relevant guide is published and verified.

The confirmed domain is `pixelelated.com`. The owner created this repository
as private; preserve its visibility.

GitHub Pages is a candidate, not a fixed hosting requirement. Keep source and
static output portable. Deployment runs only from `main`. Prepare and verify
concrete source/build changes before changing live hosting or DNS. Confirm the
domain configuration and read current DNS; never change unrelated mail records.

No device, personal-cloud or credential operations belong in website tests.
Use local/host rendering and synthetic inputs. Keep tokens, provider configs
and private inventories out of this repository. Website builds use hosted CI
runners, not the firmware build host.

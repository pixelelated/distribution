from pathlib import Path
import json,hashlib,shutil,stat,difflib,datetime
D=Path('/tmp/pix-m7-remaining-foundation-restore-20261015');S=Path('/tmp/pix-m7-website-restore-guide-20261015');P=D/'website/publication-originals';P.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
rows=[]
for p in sorted(S.iterdir()):
 assert p.is_file() and not p.is_symlink();s=p.stat();dst=P/p.name;shutil.copy2(p,dst);assert sha(dst)==sha(p)
 rows.append({'original_path':str(p),'copy':str(dst.relative_to(D)),'sha256':sha(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns})
read=load(P/'public-guide-readback.json');merge=load(P/'merge-response.json');pr=load(P/'pr-before.json');merge_sha='6aac689c6feaa8d4afefbd5a8b2121e5206f14b9'
assert merge['merged'] is True and merge['sha']==merge_sha==read['deployment_sha']
assert read['status']==200 and read['sha256']==sha(P/'public-cloud-guide.html') and all(read['checks'].values()) and len(read['checks'])==5
text=(P/'public-cloud-guide-text.txt').read_text();assert all(s in text for s in read['checks'])
for run,head in [('38717338495',pr['head']['sha']),('38717686667',merge_sha),('38717686819',merge_sha)]:
 j=load(P/f'run-{run}.json');assert j['head_sha']==head and j['status']=='completed' and j['conclusion']=='success'
dump(D/'website/publication-readback.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only independent comparison of coordinator-supplied exact publication originals; no website or tracker mutation by this worker.','members':rows,'merge_commit':merge_sha,'pr':'https://github.com/pixelelated/website/pull/4','actual_branch':'docs/m7-restore-guide-349','pr_head':pr['head']['sha'],'base':pr['base']['sha'],'public_page':read,'original_handoff_status':'Completed separately by root. Original proposed branch was not a requirement and the unrelated design checkout stayed untouched.'})
# Preserve the prior conditional handoff as explicitly historical, then add actual closure text.
p=D/'349-close-after-docs.md';p.write_text('HISTORICAL PRE-PUBLICATION HANDOFF: superseded by 349-close-proposed.md and website/publication-readback.json. Retained unchanged below.\n\n'+p.read_text())
comment='''All four literal criteria are now supported. The previously accepted replacement 18 controls and replacement 19 installed same-model writer/upload/scan/restore proof remain bound to their original image/source, archive inventory, selected download hash, journal and paired 640×480 offered/foreign-only frames. Source applicability is retained through the current image; the offered/disabled UI region is byte-identical between ES c8dc72cf and 16dbac. The original wrong-path fixture failure remains distinct from the later successful preservation proof.

The remaining documentation criterion is delivered by [website PR #4](https://github.com/pixelelated/website/pull/4), merged as `6aac689c6feaa8d4afefbd5a8b2121e5206f14b9`. PR checks, main checks and deployment completed successfully (runs `38717338495`, `38717686667`, `38717686819`). The [public cloud guide](https://pixelelated.com/guides/cloud/#restore-settings) was retrieved on 2026-10-15 at 10:07:16 UTC with HTTP 200; exact HTML SHA256 `4891f14feaf0bd78694fbca1cb27f123cdba0f670f16a7ccbe51107e6d7c9d18` contains all five reviewed points: newest compatible same-model backup, model/date, exclusion of other models, visible dimmed SETTINGS when unavailable, and the exact disabled reason.

Evidence: `docs/qa-logs/2026-10-11-installed-ui/` and `docs/qa-logs/2026-10-14-composed-cloud-baseline/`; current source excerpts and the exact publication originals are retained in the reconciliation packet. No new restore VM replay or firmware change was needed for this documentation completion. This closes #349 only; the remaining #511 site/QR/help work and #344 release gates are separate.
'''
(D/'349-close-proposed.md').write_text(comment)
j=load(D/'live/349.json');old=j['body'];line=[l for l in old.splitlines() if l.startswith('- [ ]')];assert len(line)==1 and 'Publish the same-model/newest/disabled-state explanation' in line[0]
new=old.replace(line[0],line[0].replace('- [ ]','- [x]',1))+'\n\n## Published documentation completion — 2026-10-15\n\n'+comment
(D/'349-body-proposed.md').write_text(new);(D/'349-body.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='live/349-body.md',tofile='349-body-proposed.md')))
p=D/'criterion-map.json';o=load(p);r=o['349'][3];r['status']='COMPLETE_NEW';r['assessment']='Website PR #4 merged as 6aac689c; exact-head PR and main checks plus deployment passed. Public guide HTTP 200 at 10:07:16 UTC contains all five expected statements. The earlier missing-page readback stays historical. No restore VM replay needed.';r['publication_evidence']='website/publication-readback.json';dump(p,o)
p=D/'application-guards.json';o=load(p);o['349_action']='Re-read live state, body hash and updatedAt before applying. If unchanged, tick only criterion 4 using 349-body-proposed.md and close with 349-close-proposed.md. Actual publication originals independently verified; do not replay restore tests.';o['349_proposed_body_sha256']=sha(D/'349-body-proposed.md');o['349_close_comment_sha256']=sha(D/'349-close-proposed.md');o['563_proposed_body_sha256']=sha(D/'563-body-proposed.md');dump(p,o)
p=D/'website/handoff.md';p.write_text('HISTORICAL PRE-PUBLICATION PLAN: root completed the separate docs lane via branch docs/m7-restore-guide-349 and PR #4. See publication-readback.json for actual merge, hosted checks and public page proof. The proposed branch name below was illustrative, not an executed action.\n\n'+p.read_text())
p=D/'website/identity.json';o=load(p);o['identity_scope']='Before-publication source preparation; actual completed publication identity is in publication-readback.json.';dump(p,o)
p=D/'README.md';t=p.read_text();start=t.index('#349 needs one documentation insertion');end=t.index("\n\n#576's",start)
t=t[:start]+'''#349 is ready for guarded closure. Its source/installed selection, downloaded hash/journal and two exact 640 px frames were already accepted. This worker prepared the one-section guide patch; root subsequently published it in website PR #4, merge `6aac689c6feaa8d4afefbd5a8b2121e5206f14b9`. Exact-head PR/main checks and deployment succeeded. The public guide returned HTTP 200 at 10:07:16 UTC with all five required statements present; exact originals and independent readback are retained under `website/`. `349-body-proposed.md` ticks only the fourth criterion, and `349-close-proposed.md` supplies the close comment. Earlier missing-page and conditional handoff records remain explicitly historical. The unrelated website design checkout was untouched.''' + t[end:]
t=t.replace('but the actual required settings paragraph is still absent.','and the required settings paragraph is now published with exact evidence.')
t=t.replace('Smallest remaining work: (1) land/publish the reviewed website paragraph through existing website checks and retain actual docs/page proof, then close #349;','Smallest remaining work: (1) re-read the guarded live issue fields and close #349 using the now-published guide evidence;')
t=t.replace('No VM, compiler, collector, product fixture, source-cache scan, tracker mutation, shared-document edit or commit occurred.','No VM, compiler, collector, product fixture, source-cache scan, tracker mutation, shared-document edit or commit occurred in this worker. Root’s separately authorized website publication is retained as actual evidence.')
p.write_text(t)
print(json.dumps({'publication_members':len(rows),'349_body_sha256':sha(D/'349-body-proposed.md'),'349_close_sha256':sha(D/'349-close-proposed.md'),'563_body_sha256':sha(D/'563-body-proposed.md')},indent=2))

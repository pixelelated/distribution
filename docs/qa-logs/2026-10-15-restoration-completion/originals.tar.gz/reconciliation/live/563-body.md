## Owner direction — 2026-10-12

> Is there anything we want to do with this 20261001 build, or do we feel that nothing is happening now? I feel like our foundation for this build, since it's coming in October, should be the ROCKNIX 20261001 build.

Adopt ROCKNIX stable20261001 at `c445081a59518f37d9776e5412dd7b14910696f7` as the upstream foundation for the next pixelelated0.0.1 candidate. This revises D-WORKFLOW-111's September29 freeze at the owner's request; D-WORKFLOW-161 records the exact new base. It does not select moving upstream/next or requalify existing binaries by renaming them.

## State before intake

Accepted engineering images remain `bc9dfe8141` (RG SP/Nova), usable for owner testing. Current published fork head is `0fc5a41e99`. Prior VM/audit/build/device evidence remains valid for its original bytes. Stable release delta from the old base:11commits including merges,12paths; DuckStation has an equivalent executable-mode fix already, while FEX build inputs, Steam runtime, ABL1.2 and Qualcomm changes need exact merge review. A common7.2 DP-audio patch may affect more than the Mangmi device-specific paths; scope must follow package patch selection, not commit titles.

## Execution order

1. Record D-WORKFLOW-161 and update active freeze wording, RC acceptance and M7 order; preserve historical records.
2. Merge the exact release on an isolated feature worktree. Review all imported code before execution, retain fork functionality and newer package pins, record conflicts/resolutions and package/cache invalidation. For this intake, declare a source-review budget of one work session and at most three manually resolved files; exceeding it triggers re-planning, never skipped review. This is an operational budget for this intake, not a replacement for D-WORKFLOW-117's repeated-cadence policy.
3. Repair #564 on the qualification branch before source promotion; run package lint and applicable source/fixture checks. Verify upstream ancestry, exact imported file set and preserved fork overlay. Keep full image/native/hardware claims pending until exercised.
4. Complete #493 mandatory build retention/capacity enforcement before copying full caches or starting an image; preserve accepted inputs and current container-path contracts. Record D-INFRA-023 resource measurements during the next build.
5. Build/qualify GENERIC_X64 on the new frozen source: clean plus retained upgrade, complete VM suites/local cloud protocols/time-to-play and changed-component proof. Conduct the required independent review, resolve findings, then H700/SM8550 build and platform/boot-chain qualification. Device writes retain named per-action consent. #528 source/licence/publication work includes changed inputs; ABL1.2 is not presumed to fix #558.

Can this be done on the VM? Yes for source checks, package/build qualification, Steam failure fixtures, frontend/cloud behavior and clean/retained-storage proofs. Qualcomm kernel/ABL boot and board-specific DP/audio behavior require targeted physical evidence after source/VM qualification. No personal-device or cloud action is implied by the base selection.

## Acceptance criteria

- [x] New decided row, active RC acceptance and M7 priority name the exact20261001commit; old freeze statements are superseded or explicitly historical, with sweep evidence.
- [x] Integration source has20261001 as ancestor and retains the existing fork features/newer pins; exact diff, conflict-resolution report and applicable pkgcheck/syntax results are recorded.
- [ ] Changed build inputs and transitive/native effects are mapped; source custody and licence inventory cover accepted new artifacts, including ABL and FEX dependencies.
- [ ] Retention/capacity enforcement is operational before any new full cache copy/build; original monitored result channels and disk/RAM/swap/PSI evidence are retained.
- [ ] New-source clean/upgrade VM qualification and independent audit pass with original artifacts; prior-image receipts are not relabelled.
- [ ] New H700/SM8550 artifacts pass exact component/native/boot-chain checks and required physical facts before release acceptance; publication remains subject to #528/#344 gates.

Parent M7/#344. Related #559 for reusable integration/backport procedure, #493 for build lifecycle, #528 for source/custody. No public RC allocated.

## Source intake completed — 2026-10-12

Isolated merge `f370dc87873fecb683c6af73d70a2f377715f47f` has exact stable as second parent. One DuckStation conflict preserves the newer fork recipe and equivalent executable permission fix. All11 final imported paths match stable; all other tracked paths remain unchanged. Three pkgchecks, four shell syntax checks and common kernel patch applicability on four isolated copies pass. Source review confirms the common patch affects Nova; ABL/FEX also need new artifact qualification. #564 is a reproduced Steam download-failure regression and must be repaired before promotion. No image/build/device action or new independent audit has run.

Evidence: [published source-intake packet](https://github.com/pixelelated/distribution/blob/03660cbfb8acabec039c5e4b2b43d49dc4112fc9/docs/qa-logs/2026-10-12-upstream-adoption/README.md). Active candidate references and canonical checkpoint name D-WORKFLOW-161/exact stable; scoped freeze-reference sweep is retained with the private intake receipts. The source branch remains isolated. This does not close image, custody or publication criteria.

## Published continuation — 2026-10-12 17:35 UTC

Decision/evidence/owner-feedback records are published on next `960b4d8c358b1e74b501ffdc329532be67cf7f6e`; isolated source branch `feature/m7-rocknix-20261001` is published at `62e9929fdce5d44ceb7f68150770475c568d1ac2`. Its product bytes remain exactly the reviewed f370dc8787 merge. Applicable exact-head hosted checks pass and delivery03/04 original channels and owners are consumed. Earlier failed delivery01/02 results remain failures. No new build, VM, independent model transfer, or device action is running. Next: #564 repair, then #493 lifecycle enforcement before full cache copy/build. Owner future feedback #565–#568 is recorded separately and does not change that order.

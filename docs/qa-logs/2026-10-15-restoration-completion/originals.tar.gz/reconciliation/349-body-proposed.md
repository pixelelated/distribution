## Qualification reconciliation — 2026-10-11

The installed-image criterion is complete on replacement19: actual writer/upload/scan/restore selects the newest compatible same-model archive despite a newer foreign archive; downloaded SHA and journal match. Paired offered/foreign-only640×480 frames, exact inventories and unchanged foreign-case settings hashes are in [installed UI/source evidence](https://github.com/pixelelated/distribution/tree/b990d32c935c557ba8808cfedb7344730eee60fe/docs/qa-logs/2026-10-11-installed-ui). This is replacement19 execution, with unchanged cloud/ES bytes proved in the19→20 comparison. The public explanation criterion remains OPEN under #511; this issue stays open.

The earlier remaining-work statements below are historical; the acceptance checklist is reconciled to the evidence above. No owner device/cloud action or publication occurred.

## Current scope — remaining settings-restore proof

D-CLOUD-162/164 remains: restore this **device model label's** newest compatible cloud settings archive. The row names `<DEVICE>, <DATE>` or is dimmed with `NO SETTINGS BACKUP FROM THIS DEVICE YET`. Local recovery has its own compatibility rules; no cross-model cloud choice is added.

Replacement18 scripts.log records all13 T24 writer→scan→restore, archive-layout and foreign-label controls passing. Its composed standard UI proof includes the dimmed row. This proves specific source/runtime predicates; it is not the exact offered/foreign fixture/frame pair required below. #381's writer-shaped discovery fix is already delivered.

## Acceptance criteria

- [x] Writer-shaped/current/legacy/flat/foreign archive controls pass: replacement18 scripts.log T24-production-backup-scan-restore through T24-foreign-renamed, 13 PASS/0 FAIL.
- [x] Canonical menu states and current dimmed settings presentation are retained in docs/es-menu-map.md and #527's composed standard frame proof.
- [x] On the next installed candidate, retain paired640×480 offered `<DEVICE>, <DATE>` and foreign-only disabled-row frames, with exact same-model/foreign fixture inventories, selected archive/journal and unchanged foreign-case settings hashes. Bind to the image/source manifest.
- [x] Publish the same-model/newest/disabled-state explanation with #344/#511 release/setup documentation; cite the retrieved page or docs change.

Opening scan text and its current failure/second-scan sequences belong to #350, not a stale proposed copy approval or automatic folder-discovery requirement.

Can this be done on the VM? Yes. Retained synthetic proof is reviewed here; any missing software assertion belongs on the next combined candidate. No personal cloud or owner-device action.

[Disposition and next-build plan](https://github.com/pixelelated/distribution/blob/next/docs/releases/next-candidate-scope.md); [replacement18 qualification](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-08-pixelelated-replacement-18/qualification.md).


## Original request and history

The complete original body and every comment are preserved in [the #533 snapshot](https://github.com/pixelelated/distribution/blob/next/docs/qa-logs/2026-10-11-candidate-scope/tracker-before.json), entry #349. Retired criteria there are historical, not an execution queue. Existing GitHub comments also remain intact.


## Published documentation completion — 2026-10-15

All four literal criteria are now supported. The previously accepted replacement 18 controls and replacement 19 installed same-model writer/upload/scan/restore proof remain bound to their original image/source, archive inventory, selected download hash, journal and paired 640×480 offered/foreign-only frames. Source applicability is retained through the current image; the offered/disabled UI region is byte-identical between ES c8dc72cf and 16dbac. The original wrong-path fixture failure remains distinct from the later successful preservation proof.

The remaining documentation criterion is delivered by [website PR #4](https://github.com/pixelelated/website/pull/4), merged as `6aac689c6feaa8d4afefbd5a8b2121e5206f14b9`. PR checks, main checks and deployment completed successfully (runs `38717338495`, `38717686667`, `38717686819`). The [public cloud guide](https://pixelelated.com/guides/cloud/#restore-settings) was retrieved on 2026-10-15 at 10:07:16 UTC with HTTP 200; exact HTML SHA256 `4891f14feaf0bd78694fbca1cb27f123cdba0f670f16a7ccbe51107e6d7c9d18` contains all five reviewed points: newest compatible same-model backup, model/date, exclusion of other models, visible dimmed SETTINGS when unavailable, and the exact disabled reason.

Evidence: `docs/qa-logs/2026-10-11-installed-ui/` and `docs/qa-logs/2026-10-14-composed-cloud-baseline/`; current source excerpts and the exact publication originals are retained in the reconciliation packet. No new restore VM replay or firmware change was needed for this documentation completion. This closes #349 only; the remaining #511 site/QR/help work and #344 release gates are separate.

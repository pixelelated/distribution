from pathlib import Path
import hashlib,json,stat,datetime
D=Path('/tmp/pix-m7-remaining-foundation-restore-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,o):p.write_text(json.dumps(o,sort_keys=True,indent=2)+'\n')
p=D/'README.md';p.write_text(p.read_text().replace('No RC/publication/legal clearance is inferred.','No RC, firmware-publication or legal clearance is inferred.'))
p=D/'576-tracking-discrepancy.json';o=load(p);o['smallest_next_action']=o['smallest_next_action'].replace('part of#563/#349','part of #563/#349');dump(p,o)
refs=load(D/'references.json');copied=0
for k,r in refs.items():
 if 'copy' in r:
  p=D/r['copy'];s=p.stat();assert s.st_size==r['bytes'] and sha(p)==r['sha256'] and stat.S_IMODE(s.st_mode)==r['mode'],k;copied+=1
for r in load(D/'website/publication-readback.json')['members']:
 p=D/r['copy'];s=p.stat();assert sha(p)==r['sha256'] and s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==r['mode'] and s.st_mtime_ns==r['mtime_ns'],p
for n,wanted in [(563,[1,2,4,5]),(349,[1,2,3,4])]:
 old=load(D/f'live/{n}.json')['body'];new=(D/f'{n}-body-proposed.md').read_text()
 before=[l for l in old.splitlines() if l.startswith('- [')];after=[l for l in new.splitlines() if l.startswith('- [')]
 assert len(before)==len(after)
 assert [i for i,l in enumerate(after,1) if l.startswith('- [x]')]==wanted
 assert all(a.replace('[x]','[ ]',1)==b.replace('[x]','[ ]',1) for a,b in zip(before,after))
 guards=load(D/'application-guards.json')['issues'][str(n)];assert guards['body_sha256']==hashlib.sha256(old.encode()).hexdigest()
w=D/'website';before=(w/'cloud.before.md').read_bytes();draft=(w/'cloud.md').read_bytes();section=(w/'restore-section.md').read_bytes();assert draft.count(section)==1 and draft.replace(section,b'',1)==before
prose=load(w/'prose-observation.json');assert prose['original_exit']==0 and prose['draft_sha256']==sha(w/'cloud.md')
read=load(w/'publication-originals/public-guide-readback.json');assert read['sha256']==sha(w/'publication-originals/public-cloud-guide.html') and all(read['checks'].values())
manifest=D/'manifest.json';seal=D/'SHA256SUMS';assert not manifest.exists() and not seal.exists()
rows=[]
for p in sorted(D.rglob('*')):
 assert not p.is_symlink()
 if p.is_file():
  s=p.stat();rows.append({'path':str(p.relative_to(D)),'sha256':sha(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns})
dump(manifest,{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only criterion/source/publication reconciliation. Source-only proposals; no tracker/shared-doc mutation or runtime by this worker.','verification':{'reference_count':len(refs),'copied_reference_hash_mode_checks':copied,'publication_originals':12,'literal_criteria':10,'349_all_four_supported':True,'563_only_criteria_4_and_5_newly_ticked':True,'website_one_insertion':True,'original_prose_exit':0,'raw_prose_status_retained':True,'public_page_hash_and_five_assertions':True},'members':rows,'total_original_payload_bytes':sum(r['bytes'] for r in rows)})
files=sorted(p for p in D.rglob('*') if p.is_file() and p!=seal);seal.write_text(''.join(sha(p)+'  '+str(p.relative_to(D))+'\n' for p in files))
for line in seal.read_text().splitlines():h,n=line.split('  ',1);assert sha(D/n)==h
assert len(files)==len(rows)+1
print(json.dumps({'seal_sha256':sha(seal),'sealed_payloads_including_manifest':len(files),'total_bytes_including_manifest':sum(p.stat().st_size for p in files),'references':len(refs),'copied_references':copied,'349_body_sha256':sha(D/'349-body-proposed.md'),'349_close_comment_sha256':sha(D/'349-close-proposed.md'),'563_body_sha256':sha(D/'563-body-proposed.md'),'website_patch_sha256':sha(w/'cloud.md.diff')},indent=2))

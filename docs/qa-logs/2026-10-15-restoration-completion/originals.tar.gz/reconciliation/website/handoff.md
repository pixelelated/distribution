HISTORICAL PRE-PUBLICATION PLAN: root completed the separate docs lane via branch docs/m7-restore-guide-349 and PR #4. See publication-readback.json for actual merge, hosted checks and public page proof. The proposed branch name below was illustrative, not an executed action.

# Minimal #349 site handoff

Target private repo `pixelelated/website`, only `content/guides/cloud.md`. Current working checkout is unrelated `website/design-language-draft` at 8abd05a87ab45749ab74f3353832e6d33bb3d0ec. Fresh remote main is 071eab6d0f2b22d65890c68968351a8be8d9b334. Both contain exact before SHA 9335a474c096cb048345c0da2388a69ddc60930991c7be2f2b01aeb05ed57adf. Keep the design branch untouched. Proposed separate branch: `docs/settings-restore-349`, created from actual main only when root allocates.

1. Refresh main identity and require the exact current cloud.md before hash. Review `cloud.md.diff` and source/frame assertions. If source differs, rebase this insertion explicitly; never overwrite unrelated work.
2. Apply only the one-section patch. Static prose check already passes with exit 0, 0 failures and 0 warnings against the whole proposed page. Run the website's existing hosted build/prose/link checks with this source; do not run firmware/restore matrices. No new graphics or dependency work is required.
3. Merge/publish through the existing main-only workflow once reviewed. Preserve private source visibility and hosting settings. Retain actual docs commit/deployment result and GET the public `/guides/cloud/` page with normal TLS; verify the same-model, newest compatible, model/date and disabled reason text. No need to complete all #511 QR/site work first.
4. Cite the actual docs change/retrieved page in #349 and #511, then apply guarded #349 closure. Current live page and raw readback are retained in the parent packet. No publication SHA or future success is predicted here.

The cloud guide did not explain which settings backup the restore screen offers. Document the newest backup for the same device model, the model/date label, and the dimmed Settings row when no compatible backup exists.

Refs pixelelated/distribution#349 and pixelelated/distribution#511. The behavior is already qualified in the distribution; this changes documentation only. The existing website design branch is outside this change.

Validation: canonical prose check passes with zero failures or warnings, and git diff checks pass. The hosted website workflow will build and check both URL layouts before merge.

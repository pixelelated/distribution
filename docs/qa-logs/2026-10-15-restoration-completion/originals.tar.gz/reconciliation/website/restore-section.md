## Restore settings

From `MANAGE CLOUD STORAGE`, select `BACKUP AND RESTORE` →
`RESTORE FROM THE CLOUD`. After the cloud scan, `SETTINGS` offers the newest
compatible settings backup for your device model. The row shows the model
name and backup date.

Backups from other device models are not offered, even if they are newer.
If there is no compatible backup for your model, `SETTINGS` stays visible
but dimmed, with `NO SETTINGS BACKUP FROM THIS DEVICE YET`.


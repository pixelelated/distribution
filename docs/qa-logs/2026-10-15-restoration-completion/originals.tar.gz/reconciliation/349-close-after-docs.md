HISTORICAL PRE-PUBLICATION HANDOFF: superseded by 349-close-proposed.md and website/publication-readback.json. Retained unchanged below.

# Conditional #349 closure handoff

Do not close yet: the exact public guide retrieved at 2026-10-15T09:54:36Z lacks the required explanation. After the reviewed one-section docs change is actually published, retain its commit/HTTP evidence and add the literal link to the close comment. Then tick only the fourth criterion; the first three remain their original accepted scopes.

Proposed close-comment text after adding the actual docs reference:

The public cloud setup guide now explains that SETTINGS offers the newest compatible backup for the device model, shows its model/date, ignores other models, and stays visible but dimmed with NO SETTINGS BACKUP FROM THIS DEVICE YET when no compatible backup exists. Cite the actual docs change and retrieved `/guides/cloud/` page here.

The original replacement 19 installed writer/upload/scan/restore, selected-archive hash/journal and paired 640×480 offered/foreign-only frames remain accepted, with unchanged 19→20 and later source applicability recorded. The original partial fixture-path failure and corrected foreign-only proof remain separate. No additional restore VM replay or firmware change was needed for this documentation completion. The broader #511 QR/help/site criteria remain separate.

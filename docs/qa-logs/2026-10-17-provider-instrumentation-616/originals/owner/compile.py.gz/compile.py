#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""One admitted CPU4 diagnostic compile; original inner/Docker/owner results."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def record(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def read_command(arguments):
    return subprocess.check_output(arguments, text=True, timeout=10).strip()


def group_members(group):
    result = []
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields = path.read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] != 'Z':
                result.append(int(path.parent.name))
        except FileNotFoundError:
            continue
    return result


def main():
    owner = Path(__file__).resolve().parent
    config = json.loads((owner / 'inputs.json').read_text())
    tree = Path(config['checkout'])
    assert Path.cwd().resolve() == tree and os.getuid() != 0
    assert os.readlink('/proc/self/ns/pid') == config['host_pid_namespace']
    assert 4 in os.sched_getaffinity(0), 'CPU4 unavailable to this owner'
    active = tree / os.environ['RASTERATOPS_BUILD_RUN']
    admission = json.loads((active / 'admission.json').read_text())
    assert admission['source']['head'] == config['commit']
    assert admission['submission_owner'] == str(owner / 'submit')
    assert admission['checkout'] == admission['container_checkout'] == str(tree)
    assert admission['required_bytes'] >= config['limits']['scratch_budget_bytes']
    for relative, expected in config['helper_sha256'].items():
        assert sha(owner / relative) == expected
    for row in config['trees']:
        assert sha(Path(row['host']) / 'toolchain/bin' / (row['triple'] + '-gcc')) == row['compiler_sha256']
    def source_state():
        return (read_command(['git', 'rev-parse', 'HEAD']),
                read_command(['git', 'status', '--porcelain', '--untracked-files=no']))
    assert source_state() == (config['commit'], '')
    image_id = read_command(['docker', 'image', 'inspect', '--format', '{{.Id}}', config['image']])
    (owner / 'run.path').write_text(str(active) + '\n')
    record(owner / 'owner-start.json', {'pid': os.getpid(), 'start_ticks': Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
        'pid_namespace': os.readlink('/proc/self/ns/pid'), 'source_commit': config['commit'],
        'builder_image_id': image_id, 'utc_epoch': time.time(), 'inputs_sha256': sha(owner / 'inputs.json')})
    spec = importlib.util.spec_from_file_location('host_resources', owner / 'host-resources.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    resources = module.Resources(owner, dict(config['host_observer'],
        maximum_incremental_allocated_bytes=admission['required_bytes']), [owner])
    signalled = []
    for number in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP]:
        signal.signal(number, lambda received, _frame: signalled.append(received))
    stage = owner / 'stages/compile'
    name = config['owner_label']
    container_id = None
    process = None
    launched = False
    observed = acknowledged = False
    result = {'status': 'FAIL', 'original_docker_rc': None, 'cleanup': [], 'signals': signalled}
    started = time.monotonic()

    def inspect(identifier):
        command = subprocess.run(['docker', 'inspect', identifier], capture_output=True, text=True, timeout=5)
        if command.returncode:
            if 'no such object' in command.stderr.casefold() or 'no such container' in command.stderr.casefold():
                return None
            raise RuntimeError('container inspection failed')
        return json.loads(command.stdout)[0]

    def identity(data):
        assert data['Config']['Labels'].get('pixelelated.build.owner') == name
        assert data['Config']['Labels'].get('pixelelated.build.stage') == 'compile'
        assert data['Config']['Image'] == config['image'] and data['Image'] == image_id

    def retire_container():
        if not launched:
            return
        data = inspect(container_id or name)
        if data is None:
            return
        identity(data)
        identifier = data['Id']
        if data['State']['Running']:
            command = subprocess.run(['docker', 'stop', '--time', '5', identifier],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
            result['cleanup'].append({'container_id': identifier, 'stop_rc': command.returncode})
        deadline = time.monotonic() + 10
        while inspect(identifier) is not None and time.monotonic() < deadline:
            time.sleep(.2)
        assert inspect(identifier) is None, 'owned container did not retire'

    try:
        assert inspect(name) is None, 'fresh owner container name already exists'
        resources.start()
        while not resources.ready.wait(.1):
            assert not signalled and time.monotonic() - started < 180
        assert not resources.failed.is_set(), 'host observer failed before launch'
        arguments = ['docker', 'run', '--rm', '--pull=never', '--network=none', '--read-only',
            '--cpus=1', '--cpuset-cpus=4', '--memory=1g', '--memory-swap=1g', '--pids-limit=128',
            '--cap-drop=ALL', '--security-opt=no-new-privileges', '--user', str(os.getuid()) + ':' + str(os.getgid()),
            '--tmpfs', '/tmp:rw,nosuid,size=128m', '--name', name, '--cidfile', str(stage / 'container.cid'),
            '--label', 'pixelelated.build.owner=' + name, '--label', 'pixelelated.build.stage=compile',
            '-e', 'TMPDIR=/tmp', '-e', 'LC_ALL=C', '-e', 'RASTERATOPS_BUILD_RUN=' + os.environ['RASTERATOPS_BUILD_RUN'],
            '-v', str(owner / 'inputs') + ':/inputs:ro', '-v', str(owner / 'out') + ':/work:rw',
            '-v', str(owner / 'stages') + ':/build-owner/stages:rw']
        for row in config['trees']:
            arguments += ['-v', row['host'] + '/toolchain:' + row['canonical'] + '/toolchain:ro']
        arguments += [config['image'], 'python3', '-I', '/inputs/inner-build.py', '--stage', 'compile',
            '--cpus', '1', '--memory-bytes', '1073741824', '--', '/bin/bash', '/inputs/compile.sh']
        # Pass no host environment variables into the container except the three
        # fixed values above. Docker CLI itself keeps its standard host socket environment.
        with (owner / 'compiler.log').open('xb') as log:
            process = subprocess.Popen(arguments, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            launched = True
            record(stage / 'host-command.json', {'pid': process.pid, 'process_group': process.pid,
                'cpu_ids': [4], 'memory_bytes': 1073741824, 'deadline_seconds': 180})
            while process.poll() is None:
                if not observed:
                    data = inspect(name)
                    if data is not None and data['State']['Running']:
                        identity(data)
                        container_id = data['Id']
                        host = data['HostConfig']
                        assert host['Memory'] == host['MemorySwap'] == 1073741824
                        assert host['NanoCpus'] == 1000000000 and host['CpusetCpus'] == '4'
                        assert host['PidsLimit'] == 128 and host['NetworkMode'] == 'none' and host['ReadonlyRootfs']
                        assert data['Config']['User'] == str(os.getuid()) + ':' + str(os.getgid())
                        mounts = [{key: item[key] for key in ['Source', 'Destination', 'RW']} for item in data['Mounts'] if item['Type'] == 'bind']
                        expected = [{'Source': str(owner / 'inputs'), 'Destination': '/inputs', 'RW': False},
                            {'Source': str(owner / 'out'), 'Destination': '/work', 'RW': True},
                            {'Source': str(owner / 'stages'), 'Destination': '/build-owner/stages', 'RW': True}]
                        expected += [{'Source': row['host'] + '/toolchain', 'Destination': row['canonical'] + '/toolchain', 'RW': False} for row in config['trees']]
                        assert sorted(mounts, key=lambda item: item['Destination']) == sorted(expected, key=lambda item: item['Destination'])
                        record(stage / 'container-observed.json', {'id': container_id, 'image_id': image_id,
                            'image_reference': config['image'], 'user': data['Config']['User'], 'mounts': mounts,
                            'cpuset': host['CpusetCpus'], 'nano_cpus': host['NanoCpus'],
                            'memory': host['Memory'], 'memory_swap': host['MemorySwap'],
                            'network': host['NetworkMode'], 'read_only_root': host['ReadonlyRootfs']})
                        observed = True
                if observed and not acknowledged and (stage / 'inner-ready.json').exists():
                    ready = json.loads((stage / 'inner-ready.json').read_text())
                    assert ready['stage'] == 'compile' and re.fullmatch('[0-9a-f]{32}', ready['nonce'])
                    temporary = stage / 'host-observed.tmp'
                    temporary.write_text(json.dumps({'stage': 'compile', 'nonce': ready['nonce'], 'container_id': container_id}) + '\n')
                    temporary.replace(stage / 'host-observed.json')
                    acknowledged = True
                assert not resources.failed.is_set(), 'host observer failed'
                assert not signalled, 'owner interrupted'
                assert time.monotonic() - started < 180, 'producer deadline reached'
                assert (owner / 'compiler.log').stat().st_size <= 2 * 1024**2, 'compiler log bound reached'
                time.sleep(.2)
            result['original_docker_rc'] = process.wait()
        record(stage / 'host-result.json', {'original_docker_rc': result['original_docker_rc'],
            'container_observed': observed, 'observation_handshake': acknowledged})
        assert result['original_docker_rc'] == 0 and observed and acknowledged
        inner = json.loads((stage / 'inner-result.json').read_text())
        assert inner['original_command_rc'] == inner['wrapper_rc'] == 0
        result['original_compile_shell_rc'] = inner['original_command_rc']
        cases = json.loads((owner / 'out/config-checks.json').read_text())
        assert cases['pass'] and len(cases['cases']) == 14 and all(row['pass'] for row in cases['cases'])
        result['parser_cases'] = 14
        assert source_state() == (config['commit'], '')
        for relative, expected in config['helper_sha256'].items():
            assert sha(owner / relative) == expected
        result['status'] = 'PASS'
    except BaseException as error:
        result['error_class'] = type(error).__name__
        # Only our fixed assertion messages are retained; no argv/env/headers.
        if isinstance(error, AssertionError):
            result['assertion'] = str(error)
    finally:
        try:
            retire_container()
            result['container_absent'] = True
        except BaseException as error:
            result['cleanup_error_class'] = type(error).__name__
            result['container_absent'] = False
            result['status'] = 'FAIL'
        if process is not None:
            if group_members(process.pid):
                os.killpg(process.pid, signal.SIGTERM)
            if process.poll() is None:
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
            cleanup_deadline = time.monotonic() + 5
            while group_members(process.pid) and time.monotonic() < cleanup_deadline:
                time.sleep(.1)
            if group_members(process.pid):
                os.killpg(process.pid, signal.SIGKILL)
                cleanup_deadline = time.monotonic() + 5
                while group_members(process.pid) and time.monotonic() < cleanup_deadline:
                    time.sleep(.1)
            result['original_docker_rc'] = process.returncode
            result['surviving_host_command_group'] = group_members(process.pid)
            if result['surviving_host_command_group']:
                result['status'] = 'FAIL'
            if not (stage / 'host-result.json').exists():
                record(stage / 'host-result.json', {'original_docker_rc': process.returncode,
                    'container_observed': observed, 'observation_handshake': acknowledged, 'interrupted_owner': True})
        if not result.get('container_absent') or result.get('surviving_host_command_group'):
            resources.fail(RuntimeError('producer remains; final scan refused'))
        try:
            if not resources.finish():
                result['status'] = 'FAIL'
        except BaseException as error:
            result['resource_error_class'] = type(error).__name__
            result['status'] = 'FAIL'
        result['seconds'] = time.monotonic() - started
        result['outputs'] = {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path)}
            for path in (owner / 'out').iterdir() if path.is_file()}
        if not all('cloud-signin-window-' + row['device'] in result['outputs'] for row in config['trees']):
            result['status'] = 'FAIL'
        record(owner / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    try:
        status = main()
    except Exception as error:
        record(Path(__file__).resolve().parent / 'owner-setup-failure.json',
               {'error_class': type(error).__name__, 'utc_epoch': time.time()})
        status = 1
    raise SystemExit(status)

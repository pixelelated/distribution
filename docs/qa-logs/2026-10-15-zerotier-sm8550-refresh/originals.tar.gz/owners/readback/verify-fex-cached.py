"""Read accepted cached FEX inputs and exact 14 payloads; do not execute FEX or Nix."""
from pathlib import Path
import datetime,hashlib,json,re
O=Path(__file__).resolve().parent;j=json.loads((O/'inputs.json').read_text());T=Path(j['host_worktree'])
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
prior_path=O/'fex-accepted.json';assert sha(prior_path)==j['accepted_fex_sha256']
prior=json.loads(prior_path.read_text());assert prior['result']=='PASS' and len(prior['files'])==14
root=T/j['build_root'];fex=root/'build'/('fex-emu-'+j['fex_commit']);build=fex/'.aarch64-rocknix-linux-gnu';installed=root/'install_pkg'/('fex-emu-'+j['fex_commit'])
recipe=T/'projects/ROCKNIX/packages/compat/fex-emu/package.mk'
assert sha(recipe)==prior['recipe_sha256']=='428430a76277b24fc5e4a69889da0045431d7c71caee35cc64a57fabf25db3ec'
assert 'export NIX_PATH="nixpkgs='+prior['nixpkgs_url']+'"' in recipe.read_text()
assert sha(build/'CMakeCache.txt')==prior['cmake_cache_sha256']
cache=(build/'CMakeCache.txt').read_text();observed=prior['generated_inputs']
nix=Path(j['nix_private_store']);st=nix.stat();assert {'device':st.st_dev,'inode':st.st_ino}==j['nix_identity']
def host_nix(path):
 p=Path(path);assert p.is_absolute() and p.is_relative_to('/nix/store') and '..' not in p.parts
 return nix/p.relative_to('/nix')
for key,suffix in [('rootfs','fex-dev-rootfs'),('toolchain32','toolchain_nix_x86_32.txt'),('toolchain64','toolchain_nix_x86_64.txt')]:
 paths=set(re.findall(r'/nix/store/[a-z0-9]{32}-'+re.escape(suffix),cache));assert paths=={observed[key]}
 assert host_nix(observed[key]).exists()
for path,h in observed['toolchain_hashes'].items():assert sha(host_nix(path))==h
snapshot=host_nix(observed['nixpkgs_resolved_path']);assert snapshot.is_dir()
for name,h in observed['nixpkgs_selected_source_sha256'].items():assert sha(snapshot/name)==h
assert sha(host_nix(prior['nix_binary_path']))==prior['nix_binary_sha256']
for name in ['Guest','Guest_32']:
 ninja=(build/name/'build.ninja').read_text();lines=[line for line in ninja.splitlines() if line.strip().startswith('INCLUDES =')];assert lines
 bad='-I'+str(Path(j['container_worktree'])/j['build_root']/'toolchain/aarch64-rocknix-linux-gnu/sysroot/usr/include');assert not any(bad in line.split() for line in lines)
records=[]
for row in prior['files']:
 p=installed/row['path'];data=p.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert data[:6]==b'\x7fELF'+bytes([1 if row['bits']==32 else 2,1]) and int.from_bytes(data[18:20],'little')==row['machine']
 records.append(dict(row))
for bits,names in [(32,j['guest_libraries32']),(64,j['guest_libraries64'])]:
 folder='GuestThunks_32' if bits==32 else 'GuestThunks';assert {p.name for p in (installed/'usr/share/fex-emu'/folder).glob('*.so')}==set(names)
assert len(records)==14 and (root/'.stamps/fex-emu/build_target').is_file()
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','files':records,'accepted_fex_proof_sha256':sha(prior_path),'recipe_sha256':sha(recipe),'cmake_cache_sha256':sha(build/'CMakeCache.txt'),'generated_inputs':observed,'nix_binary_sha256':prior['nix_binary_sha256'],'target_execution':False,'nix_execution':False,'scope':'Exact accepted cached native AArch64 FEX and x86/x86_64 thunks, existing generated input paths and held source bytes re-read. Original Nix version/resolution remains prior provenance; no resolver, compiler, target execution or whole-store completeness claim.'}
(O/'artifacts/fex-package.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS cached FEX package and accepted generated-input bytes; 14 architecture-checked payloads; no Nix/target execution',flush=True)

from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;H=Path('/tmp/pix-m7-zerotier-h700-refresh-20261015/transfer02');S=P/'transfer';S.mkdir()
OLD='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea';NEW='077197e6cd3ea31f33b28aaf3882a694b3423b53'
B=Path('/workspace/tmp/pix-m7-sm8550-refresh-20261015-02');R=Path('/workspace/tmp/pix-m7-sm8550-reader-20261015-01');A=R/'acceptance'
BR=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05/.build-runs/20261015T081827Z-07dceee9');AR=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05/.build-runs/20261015T092333Z-2bc44656')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def x(s):return s.replace('m7-pixelelated-h700-05','m7-pixelelated-sm8550-06').replace('m7-pixelelated-h700-04','m7-pixelelated-sm8550-05').replace('m7-pixelelated-h700-03','m7-pixelelated-sm8550-04').replace('h700','sm8550').replace('H700','SM8550').replace('f8636de1d105275dbf9420bbabbbc26f79abb10f',OLD)
files=[BR/'runner-result.json',BR/'admission-consumed.json',B/'launcher-result.json',B/'inner.rc',B/'outer.rc',B/'tool-wrapper.rc',Path('/tmp/pix-m7-sm8550-verifier-failure-20261015/completion-evidence.json'),A/'artifacts/acceptance.json',R/'acceptance-consumption.json',R/'reader-consumption.json',A/'admission-completion-evidence.json',AR/'admission-consumed.json',AR/'runner-result.json',A/'launcher-result.json',A/'artifacts/selected-state.stdout',A/'artifacts/selected-state.exit']
binding={'source':OLD,'producer_owner':str(B),'producer_run':str(BR),'producer_consumption_id':'ec3f813f3297497a82cb434bc7e02279','producer_original_result':{'command_rc':1,'monitor_rc':0,'runner_rc':1},'producer_failure_evidence':str(files[6]),'artifact_owner':str(A),'artifact_run':str(AR),'artifact_consumption_id':'40d2d16b1a4a42e0864bf5bf881a242f','acceptance_sha256':sha(A/'artifacts/acceptance.json'),'candidate_bundle_manifest_sha256':'09addac6d353e2a30e06610d87fa46b72a4bdfa82c711fd77a658b9e7f1d3ca0','files':[{'path':str(p),'sha256':sha(p)} for p in files]}
for arch in ['arm','aarch64']:
 D=S/arch;D.mkdir();hp=H/arch
 for name in ['dependency-readback.py','consume-transfer.py','prepare-plan.py','transfer-cache.py']:
  (D/name).write_text(x((hp/name).read_text()))
 (D/'predecessor-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
 shutil.copyfile(B/'capacity-measurement.json',D/'capacity-measurement.json')
 p=D/'transfer-cache.py';s=p.read_text()
 s=s.replace(", 'projects/ROCKNIX/packages/tools/rocknix-abl/package.mk']",']')
 oldline=next(line for line in s.splitlines() if line.startswith('PREDECESSOR_BINDING_SHA256 ='))
 s=s.replace(oldline,'PREDECESSOR_BINDING_SHA256 = '+repr(sha(D/'predecessor-binding.json')))
 s=s.replace("parser.add_argument('--dependency-sha256', required=True)","parser.add_argument('--dependency-sha256', required=True)\n    parser.add_argument('--h700-reader', type=Path, required=True)\n    parser.add_argument('--h700-consumed-sha256', required=True)\n    parser.add_argument('--h700-acceptance-sha256', required=True)")
 s=s.replace("len(accepted['variants']) == 2", "len(accepted['variants']) == 1")
 s=s.replace("accepted['producer_combined_run_returncode'] == accepted['failed_acceptance_returncode'] == 1", "accepted['producer_combined_run_returncode'] == 1\n        assert len(accepted['variants'][0]['bootloader_files']) == 5")
 start=s.index('        # GENERIC build and independent artifact proof')
 end=s.index("        target_before = identity(OLD / 'target')",start)
 s=s[:start]+'''        # Bind the actual new H700 acceptance only after it exists and is consumed.
        h700_build = Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01')
        h700_read = args.h700_reader.resolve(strict=True)
        assert h700_read.parent == Path('/workspace/tmp') and h700_read.name.startswith('pix-m7-zerotier-h700-readback-20261015-')
        h700_receipts = []
        for h700_owner in [h700_build, h700_read]:
            h700_run = Path((h700_owner / 'run.path').read_text().strip())
            assert h700_run.parent == Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05/.build-runs')
            consumed_file = h700_run / 'admission-consumed.json'
            consumed = json.loads(consumed_file.read_text())
            assert consumed['state'] == 'consumed' and consumed['source']['head'] == new_head
            assert consumed['submission_owner'] == str(h700_owner) and consumed['run'] == str(h700_run)
            proof_path = h700_owner / 'consumption-evidence.json'
            assert consumed['evidence_sha256'] == sha(proof_path)
            proof = json.loads(proof_path.read_text())
            assert proof['disposition'] == 'qualified' and proof['expected_rc'] == 0
            assert all(sha(Path(row['path'])) == row['sha256'] for row in proof['evidence'])
            assert all(consumed['original_result'][k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
            assert json.loads((h700_owner / 'launcher-result.json').read_text())['runner_returncode'] == 0
            h700_receipts.append({'path': str(consumed_file), 'sha256': sha(consumed_file), 'id': consumed['id']})
        assert h700_receipts[-1]['sha256'] == args.h700_consumed_sha256
        h700_result = h700_read / 'artifacts/acceptance.json'
        assert sha(h700_result) == args.h700_acceptance_sha256
        h700 = json.loads(h700_result.read_text())
        assert h700['result'] == 'PASS' and h700['distribution_commit'] == new_head
        assert h700['scratch_removed'] and h700['source_unchanged'] and len(h700['variants']) == 2
        assert h700['producer_combined_run_returncode'] == 0
        z = json.loads((h700_read / 'artifacts/affected-products.json').read_text())['special']['zerotier']
        assert z['nonfree_absent'] and z['target_execution'] is False and z['dependency_completeness_claim'] is False
        assert json.loads((h700_build / 'build-inputs.json').read_text())['build_timestamp'] == '20261015T161744Z'
        result['h700_dependency'] = {'receipts': h700_receipts, 'reader_owner': str(h700_read),
            'artifact_result_sha256': sha(h700_result), 'runtime_claim': False}
'''+s[end:]
 p.write_text(s)
 p=D/'prepare-plan.py';s=p.read_text().replace(", 'projects/ROCKNIX/packages/tools/rocknix-abl/package.mk']",']')
 start=s.index("    age = datetime.datetime.now")
 end=s.index("    scan = owner / 'empty-retention-scan'",start)
 s=s[:start]+'''    assert hashlib.sha256(measurement.read_bytes()).hexdigest() == '''+repr(sha(D/'capacity-measurement.json'))+'''
    age = datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(m['utc'])
    assert 0 <= age.total_seconds() <= 86400, 'review historical allocation age before preparation'
    allocated = {r['path']: r['allocated_bytes'] for r in m['rows']}
    base = allocated['/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-04/' + ROOT]
    assert base > 0 and '/workspace/cache/rocknix-sources' in allocated
'''+s[end:]
 s=s.replace("{'path': str(measurement), 'sha256': hashlib.sha256(measurement.read_bytes()).hexdigest()},\n                                  {'path': m['original_allocation_log'], 'sha256': m['original_allocation_log_sha256']}","{'path': str(measurement), 'sha256': hashlib.sha256(measurement.read_bytes()).hexdigest()}")
 s=s.replace('Historical SM855003 pre-refresh allocation, not current SM855004 measurement.','Historical SM8550-04 pre-refresh allocation, not current SM8550-05 measurement.')
 p.write_text(s)

# SM8550 stopped-cache ownership transfer

Source-only derivative of reviewed H700 transfer02, with the same atomic `renameat2(RENAME_NOREPLACE)` route and separately consumed ABI moves. Old checkout `/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05` stays frozen at `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea`; root creates new `/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06`, branch `build/m7-pixelelated-sm8550-06`, at published `077197e6cd3ea31f33b28aaf3882a694b3423b53`. The only product delta is the ZeroTier recipe and patch. ABL, FEX and the other product hashes are unchanged. The stable container prefix remains `m7-pixelelated-sm8550-01`.

Execution requires actual consumed new H700 build and accepted artifact results at source077197 and coordinated timestamp `20261015T161744Z`. `--h700-reader`, `--h700-consumed-sha256` and `--h700-acceptance-sha256` must be supplied from those real completed originals. No future result, run ID or hash is invented in this source packet. Both H700 consumption evidence inventories and original zero channels are re-read; H700 acceptance must contain both variants and the new ZeroTier proof. A failed reader is not an accepted dependency.

The predecessor is explicitly SM8550 combined producer `081827Z-07dceee9`, consumed `ec3f813f3297497a82cb434bc7e02279`, original1/0/1 and launcher1. Independent installed reader `092225Z-e7702372` and firmware acceptance `092333Z-2bc44656`, consumed `40d2d16b1a4a42e0864bf5bf881a242f`, remain separate. Acceptance `b576f190e56c01ed534bbec593dc669c5fc034317a69ccb68af14cb568787dd0` binds one GPT raw image/update pair, five ABL files and bundle `09addac6d353e2a30e06610d87fa46b72a4bdfa82c711fd77a658b9e7f1d3ca0`. No H700-specific failed state-reader field is assumed for SM8550.

This deliberately reuses the accepted GENERIC and H700 atomic ownership-transfer precedent instead of duplicating warm caches. It preserves old source, firmware and original receipts. Each root is a separate transaction, bounded at120 seconds with a fresh actual-host dependency assessment no older than900 seconds. Same device/inode, no overwrite/copy fallback, no rollback, fsync, unchanged old target identity and ordinary consumption remain required.

Run separately for `TASK_ABI=arm` and `TASK_ABI=aarch64`; consume the first before admitting the second. The commands below assume root has independently reviewed the actual successful H700 reader and set `TASK_H700_READER` to its owner. Derive hashes from those actual files:

```bash
TASK_H700_RUN=$(cat "$TASK_H700_READER/run.path")
TASK_H700_CONSUMED_SHA=$(sha256sum "$TASK_H700_RUN/admission-consumed.json")
TASK_H700_CONSUMED_SHA=${TASK_H700_CONSUMED_SHA%% *}
TASK_H700_ACCEPTANCE_SHA=$(sha256sum "$TASK_H700_READER/artifacts/acceptance.json")
TASK_H700_ACCEPTANCE_SHA=${TASK_H700_ACCEPTANCE_SHA%% *}
TASK_ABI=arm
TASK_PACKET=/tmp/pix-m7-zerotier-sm8550-refresh-20261015/transfer/$TASK_ABI
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06
TASK_OWNER=/workspace/tmp/pix-m7-zerotier-sm8550-transfer-$TASK_ABI-20261015-01
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
mkdir -m 700 "$TASK_OWNER"
cd "$TASK_TREE"
tools/build-preflight
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit 077197e6cd3ea31f33b28aaf3882a694b3423b53 --es-recipe-sha256 1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719 --expected-es 16dbac5211eea7e70db7394372033be2be7df829 --measurement "$TASK_PACKET/capacity-measurement.json" --owner "$TASK_OWNER" --stage transfer
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
tools/watch-build --record-only -- python3 -I "$TASK_PACKET/dependency-readback.py" --output "$TASK_OWNER/dependency-readback.json"
```

Root reviews the original census/error scope and closes or rebinds every prepared consumer of this ABI root before writing `dependency-assessed.json` using the established assessment schema. Preserve the observation timestamp and raw evidence/hash; do not copy an earlier CLEAR. The assessment names `root`, exact `root_identity`, actual host namespace, empty process/remaining-consumer/admission lists, all Docker mounts and `prepared_consumers_resolved=true`, with justified census limitations. The other ABI root needs its own fresh assessment.

```bash
TASK_DEPENDENCY_SHA=$(sha256sum "$TASK_OWNER/dependency-assessed.json")
TASK_DEPENDENCY_SHA=${TASK_DEPENDENCY_SHA%% *}
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" --activity-dir "$TASK_OWNER" -- python3 -I "$TASK_PACKET/transfer-cache.py" --owner "$TASK_OWNER" --commit 077197e6cd3ea31f33b28aaf3882a694b3423b53 --es-recipe-sha256 1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719 --dependency-readback "$TASK_OWNER/dependency-assessed.json" --dependency-sha256 "$TASK_DEPENDENCY_SHA" --h700-reader "$TASK_H700_READER" --h700-consumed-sha256 "$TASK_H700_CONSUMED_SHA" --h700-acceptance-sha256 "$TASK_H700_ACCEPTANCE_SHA"
# Only after original watcher and launcher completion:
python3 -I "$TASK_PACKET/consume-transfer.py" --owner "$TASK_OWNER"
```

If one root moves and the second fails, retain the completed transfer and retry only the untouched root with a fresh reviewed owner. No pair-PASS is implied and no automatic rollback occurs. Build preparation requires both exact consumed ready records. The existing Nix store is neither moved nor copied by these two transfers; build preparation separately requires its fresh exclusive-use assessment.

Capacity JSON is the original07:56 SM8550-04 measurement: ARM19,319,939,072B, AArch64147,234,422,784B and prior Nix2,680,090,624B. It is historical, not current05 occupancy. Its original bytes, SHA and24-hour age guard remain; only65GiB metadata/margin is reserved for each transfer. No600GiB copy allowance, new measurement or deletion credit is claimed. Preserve caches only for the immediate canonical image/readback/corresponding-source dependencies; retire superseded large outputs through the existing retention workflow after those dependencies close.

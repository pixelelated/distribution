#!/usr/bin/env python3
"""One explicitly admitted same-filesystem cache custody transfer; never copy/overwrite."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

OLD = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05')
NEW = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06')
OLD_HEAD = '9aa7affee9d4ad5e69725cab20b6d7ad84d93dea'

TEMPLATE_COMMIT = '2426f88aba0eaa51e448c42917ca80fde2972a16'
PRODUCT_PATHS = ['projects/ROCKNIX/packages/network/zerotier-one/package.mk', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch']
PRODUCT_SHA256 = {'projects/ROCKNIX/packages/network/zerotier-one/package.mk': 'b876990db897995a230330a78704e16ad881e5424f6ff172fee9d7f2203a1aba', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch': '5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5', 'projects/ROCKNIX/packages/tools/rocknix-abl/package.mk': '6b07c262b11e8cc3fd45e8097b7fdb06a1f612cb31008daafdc3ecf68f892b3c', 'projects/ROCKNIX/packages/ui/emulationstation/package.mk': '1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk': 'cc4e7458e99329518b30b7f78aa38e149d083427f3c8b7e22d7f5e1090d2479b'}
PRODUCT_ROOTS = ['packages', 'projects', 'config', 'scripts', 'distributions', 'Makefile']
ROOT = 'build.pixelelated-SM8550.aarch64'
OLD_OWNER = Path('/workspace/tmp/pix-m7-sm8550-refresh-20261015-02')
PREDECESSOR_BINDING_SHA256 = '6c5765021dda19082e76490b859162581d14af5cc4bbae69b76c3a8276400a84'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())


def identity(path):
    st = path.stat()
    return {'device': st.st_dev, 'inode': st.st_ino}


def git(tree, *args):
    return subprocess.check_output(['git', '-C', str(tree), *args], text=True, timeout=15).strip()


def within(path, parent):
    return path == parent or parent in path.parents


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owner', type=Path, required=True)
    parser.add_argument('--commit', required=True, help='Exact final reviewed, committed source; must preserve the reviewed template product inputs')
    parser.add_argument('--es-recipe-sha256', required=True, help='Independently reviewed final ES recipe SHA256')
    parser.add_argument('--dependency-readback', type=Path, required=True)
    parser.add_argument('--dependency-sha256', required=True)
    parser.add_argument('--h700-reader', type=Path, required=True)
    parser.add_argument('--h700-consumed-sha256', required=True)
    parser.add_argument('--h700-acceptance-sha256', required=True)
    args = parser.parse_args()
    assert len(args.commit) == 40 and all(c in '0123456789abcdef' for c in args.commit)
    assert args.commit == '077197e6cd3ea31f33b28aaf3882a694b3423b53', 'exact reviewed published source required'
    new_head = args.commit
    assert len(args.es_recipe_sha256) == 64 and all(c in '0123456789abcdef' for c in args.es_recipe_sha256)
    product_sha256 = dict(PRODUCT_SHA256)
    assert args.es_recipe_sha256 == PRODUCT_SHA256['projects/ROCKNIX/packages/ui/emulationstation/package.mk']
    owner = args.owner.resolve(strict=True)
    assert owner.is_dir() and owner.parent == Path('/workspace/tmp') and owner.name.startswith('pix-m7-zerotier-sm8550-transfer-aarch64-20261015-')
    assert not (owner / 'transfer-result.json').exists()
    result = {'schema': 'pix572-atomic-cache-transfer-v1', 'status': 'FAIL',
              'method': 'same-filesystem-rename', 'copy_performed': False,
              'old': str(OLD / ROOT), 'new': str(NEW / ROOT),
              'source_head': OLD_HEAD, 'destination_head': new_head, 'product_sha256': product_sha256,
              'renamed': False, 'utc_start_epoch': time.time()}
    def timeout(_number, _frame):
        raise TimeoutError('120-second transfer owner bound reached')
    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(120)
    try:
        assert os.getuid() != 0 and Path.cwd().resolve() == NEW
        assert git(OLD, 'rev-parse', 'HEAD') == OLD_HEAD
        assert git(NEW, 'rev-parse', 'HEAD') == new_head
        assert git(NEW, 'branch', '--show-current') == 'build/m7-pixelelated-sm8550-06'
        git(NEW, 'merge-base', '--is-ancestor', new_head, 'origin/next')
        assert git(OLD, 'status', '--porcelain') == git(NEW, 'status', '--porcelain') == ''
        changed = git(NEW, 'diff', '--name-only', OLD_HEAD, new_head, '--',
                      'packages', 'projects', 'config', 'scripts', 'distributions', 'Makefile').splitlines()
        assert changed == PRODUCT_PATHS
        assert set(git(NEW, 'diff', '--name-only', TEMPLATE_COMMIT, new_head, '--', *PRODUCT_ROOTS).splitlines()) <= {'projects/ROCKNIX/packages/network/zerotier-one/package.mk', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch'}, 'review/reseal additional changed product inputs'
        assert all(sha(NEW / path) == digest for path, digest in product_sha256.items())
        active = NEW / os.environ['RASTERATOPS_BUILD_RUN']
        admission = json.loads((active / 'admission.json').read_text())
        assert admission['source']['head'] == new_head and admission['submission_owner'] == str(owner)
        assert admission['container_checkout'] == '/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01'
        (owner / 'run.path').write_text(str(active) + '\n')
        result['watched_run'] = str(active)
        source, destination = OLD / ROOT, NEW / ROOT
        assert source.is_dir() and not source.is_symlink()
        assert not destination.exists() and not destination.is_symlink()
        assert identity(source)['device'] == NEW.stat().st_dev == OLD.stat().st_dev
        before = identity(source)
        result['before_identity'] = before
        dependency = args.dependency_readback.resolve(strict=True)
        assert sha(dependency) == args.dependency_sha256
        d = json.loads(dependency.read_text())
        assert d['status'] == 'CLEAR_WITH_STATED_SCOPE'
        assert d['host_pid_namespace'] == Path('/proc/self/ns/pid').stat().st_ino
        assert d['root'] == str(source) and d['root_identity'] == before
        assert 0 <= time.time() - d['utc_epoch'] <= 900
        assert not d['process_matches'] and not d['remaining_consumers'] and not d['active_admissions']
        assert d['prepared_consumers_resolved'] is True
        for mount in d['docker_all_mounts']:
            path = Path(mount.get('source', mount.get('Source', '')))
            assert path.is_absolute()
            assert not (within(path, source) or within(source, path))
        result['dependency_readback'] = {'path': str(dependency), 'sha256': sha(dependency),
                                         'readback': d}
        binding_path = Path(__file__).with_name('predecessor-binding.json')
        assert sha(binding_path) == PREDECESSOR_BINDING_SHA256
        binding = json.loads(binding_path.read_text())
        assert all(sha(Path(row['path'])) == row['sha256'] for row in binding['files'])
        failed_run = Path(binding['producer_run'])
        failed = json.loads((failed_run / 'admission-consumed.json').read_text())
        failure = json.loads(Path(binding['producer_failure_evidence']).read_text())
        assert failed['state'] == 'consumed' and failed['id'] == binding['producer_consumption_id']
        assert failed['source']['head'] == OLD_HEAD and failed['submission_owner'] == binding['producer_owner']
        assert failed['original_result'] == json.loads((failed_run / 'runner-result.json').read_text())
        assert all(failed['original_result'][k] == v for k, v in binding['producer_original_result'].items())
        assert failure['disposition'] == 'failed-investigated' and failure['expected_rc'] == 1
        assert failed['evidence_sha256'] == sha(Path(binding['producer_failure_evidence']))
        assert json.loads((OLD_OWNER / 'launcher-result.json').read_text())['runner_returncode'] == 1
        accepted_owner = Path(binding['artifact_owner']); accepted_run = Path(binding['artifact_run'])
        accepted = json.loads((accepted_owner / 'artifacts/acceptance.json').read_text())
        accepted_receipt = json.loads((accepted_run / 'admission-consumed.json').read_text())
        proof = json.loads((accepted_owner / 'admission-completion-evidence.json').read_text())
        assert accepted['result'] == 'PASS' and accepted['distribution_commit'] == OLD_HEAD
        assert accepted['scratch_removed'] and accepted['source_unchanged'] and len(accepted['variants']) == 1
        assert accepted['producer_combined_run_returncode'] == 1
        assert len(accepted['variants'][0]['bootloader_files']) == 5
        assert accepted['bundle_manifest_sha256'] == binding['candidate_bundle_manifest_sha256']
        assert accepted_receipt['state'] == 'consumed' and accepted_receipt['id'] == binding['artifact_consumption_id']
        assert accepted_receipt['source']['head'] == OLD_HEAD and accepted_receipt['submission_owner'] == str(accepted_owner)
        assert accepted_receipt['evidence_sha256'] == sha(accepted_owner / 'admission-completion-evidence.json')
        assert proof['disposition'] == 'qualified' and proof['expected_rc'] == 0
        assert all(sha(Path(row['path'])) == row['sha256'] for row in proof['evidence'])
        assert all(accepted_receipt['original_result'][k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
        result['original_build_consumption'] = {'path': str(failed_run / 'admission-consumed.json'),
            'sha256': sha(failed_run / 'admission-consumed.json'), 'original_result': failed['original_result'], 'failed_investigated': True}
        result['accepted_artifact'] = {'run': str(accepted_run), 'admission_id': accepted_receipt['id'],
            'acceptance_sha256': sha(accepted_owner / 'artifacts/acceptance.json'), 'binding_sha256': sha(binding_path)}
        # Bind the actual new H700 acceptance only after it exists and is consumed.
        h700_build = Path('/workspace/tmp/pix-m7-zerotier-h700-build-20261015-01')
        h700_read = args.h700_reader.resolve(strict=True)
        assert h700_read.parent == Path('/workspace/tmp') and h700_read.name.startswith('pix-m7-zerotier-h700-readback-20261015-')
        h700_receipts = []
        for h700_owner in [h700_build, h700_read]:
            h700_run = Path((h700_owner / 'run.path').read_text().strip())
            assert h700_run.parent == Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05/.build-runs')
            consumed_file = h700_run / 'admission-consumed.json'
            consumed = json.loads(consumed_file.read_text())
            assert consumed['state'] == 'consumed' and consumed['source']['head'] == new_head
            assert consumed['submission_owner'] == str(h700_owner) and consumed['run'] == str(h700_run)
            proof_path = h700_owner / 'consumption-evidence.json'
            assert consumed['evidence_sha256'] == sha(proof_path)
            proof = json.loads(proof_path.read_text())
            assert proof['disposition'] == 'qualified' and proof['expected_rc'] == 0
            assert all(sha(Path(row['path'])) == row['sha256'] for row in proof['evidence'])
            assert all(consumed['original_result'][k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
            assert json.loads((h700_owner / 'launcher-result.json').read_text())['runner_returncode'] == 0
            h700_receipts.append({'path': str(consumed_file), 'sha256': sha(consumed_file), 'id': consumed['id']})
        assert h700_receipts[-1]['sha256'] == args.h700_consumed_sha256
        h700_result = h700_read / 'artifacts/acceptance.json'
        assert sha(h700_result) == args.h700_acceptance_sha256
        h700 = json.loads(h700_result.read_text())
        assert h700['result'] == 'PASS' and h700['distribution_commit'] == new_head
        assert h700['scratch_removed'] and h700['source_unchanged'] and len(h700['variants']) == 2
        assert h700['producer_combined_run_returncode'] == 0
        z = json.loads((h700_read / 'artifacts/affected-products.json').read_text())['special']['zerotier']
        assert z['nonfree_absent'] and z['target_execution'] is False and z['dependency_completeness_claim'] is False
        assert json.loads((h700_build / 'build-inputs.json').read_text())['build_timestamp'] == '20261015T161744Z'
        result['h700_dependency'] = {'receipts': h700_receipts, 'reader_owner': str(h700_read),
            'artifact_result_sha256': sha(h700_result), 'runtime_claim': False}
        target_before = identity(OLD / 'target')
        result['old_target_identity'] = target_before
        write(owner / 'transfer-intent.json', result)
        # Linux renameat2(RENAME_NOREPLACE): one atomic operation, no EXDEV copy fallback.
        libc = ctypes.CDLL(None, use_errno=True)
        rename = libc.renameat2
        rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        rename.restype = ctypes.c_int
        rc = rename(-100, os.fsencode(source), -100, os.fsencode(destination), 1)
        if rc:
            number = ctypes.get_errno()
            raise OSError(number, os.strerror(number))
        result['renamed'] = True
        for directory in [OLD, NEW]:
            fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        result['after_identity'] = identity(destination)
        assert result['after_identity'] == before and not source.exists()
        assert identity(OLD / 'target') == target_before
        assert git(OLD, 'rev-parse', 'HEAD') == OLD_HEAD and git(OLD, 'status', '--porcelain') == ''
        assert git(NEW, 'rev-parse', 'HEAD') == new_head and git(NEW, 'status', '--porcelain') == ''
        result['status'] = 'PASS'
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        signal.alarm(0)
        result['utc_finish_epoch'] = time.time()
        write(owner / 'transfer-result.json', result)
        if result['status'] == 'PASS':
            write(owner / 'cache-ready.json', result)
        (owner / 'inner.rc').write_text('0\n' if result['status'] == 'PASS' else '1\n')
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env python3
"""Materialize small plans only. Does not reserve, copy, compile, or submit work."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

PARENT = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05')
ROOT = 'build.pixelelated-SM8550.arm'
CONTAINER = '/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01'
GIB = 1024 ** 3

TEMPLATE_COMMIT = '2426f88aba0eaa51e448c42917ca80fde2972a16'
PRODUCT_PATHS = ['projects/ROCKNIX/packages/network/zerotier-one/package.mk', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch']
PRODUCT_SHA256 = {'projects/ROCKNIX/packages/network/zerotier-one/package.mk': 'b876990db897995a230330a78704e16ad881e5424f6ff172fee9d7f2203a1aba', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch': '5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5', 'projects/ROCKNIX/packages/tools/rocknix-abl/package.mk': '6b07c262b11e8cc3fd45e8097b7fdb06a1f612cb31008daafdc3ecf68f892b3c', 'projects/ROCKNIX/packages/ui/emulationstation/package.mk': '1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719', 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk': 'cc4e7458e99329518b30b7f78aa38e149d083427f3c8b7e22d7f5e1090d2479b'}
PRODUCT_ROOTS = ['packages', 'projects', 'config', 'scripts', 'distributions', 'Makefile']


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkout', type=Path, required=True)
    p.add_argument('--commit', required=True)
    p.add_argument('--es-recipe-sha256', required=True, help='Reviewed unchanged ES recipe SHA256; ZeroTier recipe and patch hashes are sealed in this packet')
    p.add_argument('--expected-es', required=True, help='Exact reviewed ES commit required in the frozen distribution recipe')
    p.add_argument('--measurement', type=Path, required=True)
    p.add_argument('--owner', type=Path, required=True)
    p.add_argument('--stage', choices=['transfer'], required=True)
    a = p.parse_args()
    tree = a.checkout.resolve(strict=True)
    owner = a.owner.resolve(strict=True)
    measurement = a.measurement.resolve(strict=True)
    assert str(tree) == '/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06'
    assert re.fullmatch('[0-9a-f]{40}', a.commit)
    assert a.commit == '077197e6cd3ea31f33b28aaf3882a694b3423b53', 'exact reviewed published source required'
    assert re.fullmatch('[0-9a-f]{64}', a.es_recipe_sha256)
    product_sha256 = dict(PRODUCT_SHA256)
    assert a.es_recipe_sha256 == PRODUCT_SHA256['projects/ROCKNIX/packages/ui/emulationstation/package.mk']
    assert a.expected_es == '16dbac5211eea7e70db7394372033be2be7df829', 'reviewed #593 ES source required'
    assert git(tree, 'rev-parse', 'HEAD') == a.commit
    assert git(tree, 'branch', '--show-current') == 'build/m7-pixelelated-sm8550-06'
    assert not git(tree, 'status', '--porcelain'), 'freeze a clean source first'
    assert set(git(tree, 'diff', '--name-only', TEMPLATE_COMMIT, a.commit, '--', *PRODUCT_ROOTS).splitlines()) <= {'projects/ROCKNIX/packages/network/zerotier-one/package.mk', 'projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch'}, 'additional product inputs changed: review/reseal first'
    assert git(tree, 'diff', '--name-only', '9aa7affee9d4ad5e69725cab20b6d7ad84d93dea', a.commit, '--', *PRODUCT_ROOTS).splitlines() == PRODUCT_PATHS
    assert all(hashlib.sha256((tree / path).read_bytes()).hexdigest() == digest for path, digest in product_sha256.items())
    assert git(tree, 'merge-base', '--is-ancestor', a.commit, 'origin/next') == ''
    recipe = tree / 'projects/ROCKNIX/packages/ui/emulationstation/package.mk'
    recipe_bytes = recipe.read_bytes()
    assert re.findall(r'^\s*PKG_VERSION=(.*)$', recipe_bytes.decode(), re.M) == ['"' + a.expected_es + '"'], 'expected exact ES pin missing or ambiguous'
    es_recipe_sha256 = hashlib.sha256(recipe_bytes).hexdigest()
    for patch in ['020-rvz-padding-preserve-partial-word.patch', '021-flush-reconnect-during-startup.patch']:
        assert (tree / 'projects/ROCKNIX/packages/network/raofflineproxy/patches' / patch).is_file()
    assert owner.is_dir() and owner.stat().st_dev == tree.stat().st_dev
    m = json.loads(measurement.read_text())
    assert hashlib.sha256(measurement.read_bytes()).hexdigest() == '86193d71d6f3d472a2f4e3ce58d96ea59f22967525daf3f73f23b4ccbd439ce3'
    age = datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(m['utc'])
    assert 0 <= age.total_seconds() <= 86400, 'review historical allocation age before preparation'
    allocated = {r['path']: r['allocated_bytes'] for r in m['rows']}
    base = allocated['/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-04/' + ROOT]
    assert base > 0 and '/workspace/cache/rocknix-sources' in allocated
    scan = owner / 'empty-retention-scan'
    scan.mkdir()
    terms = ({'custody_receipts_and_metadata': 1 * GIB, 'operating_margin': 64 * GIB}
             if a.stage == 'transfer' else
             {'additional_warm_package_growth': max(base // 3, 32 * GIB),
              'source_download_growth': 8 * GIB, 'firmware_outputs': 16 * GIB,
              'immediate_clean_and_upgrade_qa': 32 * GIB, 'operating_margin': 64 * GIB})
    stage = 'm7-zerotier-sm8550-transfer-arm'
    retention = {'volume': '/workspace', 'scan_roots': [str(scan)], 'reference_stores': [],
                 'protected': [str(PARENT), str((PARENT if a.stage == 'transfer' else tree) / ROOT), str(PARENT / 'target'),
                               '/workspace/cache/rocknix-sources', str(measurement)],
                 'candidates': [], 'builds': [{'name': stage, 'terms_bytes': terms,
                     'basis': 'Historical SM8550-04 pre-refresh allocation, not current SM8550-05 measurement. Atomic transfer uses custody/margin allowance only. '
                              'Existing source cache and parent payloads already reduce f_bavail; no reclamation counted. '
                              'No deletion candidates; the empty explicit scan is not historical-volume classification.',
                     'evidence': [{'path': str(measurement), 'sha256': hashlib.sha256(measurement.read_bytes()).hexdigest()}]}]}
    outputs = [{'path': str(tree / ROOT), 'issue': 596, 'kind': 'build-cache',
                'release_when': 'Immediately queued assembled-image qualification and required corresponding-source custody accepted'}]
    if a.stage == 'build':
        outputs += [{'path': str(tree / n), 'issue': 596, 'kind': 'firmware',
                     'release_when': 'Clean and retained-storage engineering qualification and compact image/source record accepted; review next immediate consumer'}
                    for n in ['release', 'target']]
        outputs += [{'path': str(tree / n), 'issue': 493, 'kind': 'qa-scratch',
                     'release_when': 'Original results consumed and compact build records retained; generated staging no longer needed'}
                    for n in ['.doc_cache', '.es_cache', '.build-runs']]
    outputs += [{'path': str(owner), 'issue': 493, 'kind': 'qa-scratch',
                 'release_when': 'Original results consumed and compact evidence retained; preserve required corresponding-source inputs'}]
    admission = {'checkout': str(tree), 'container_checkout': CONTAINER,
                 'retention_plan': str(owner / 'retention-plan.json'),
                 'retention_report': str(owner / 'retention-report.json'), 'stage': stage,
                 'profiles': [{'PROJECT': 'ROCKNIX', 'DEVICE': 'SM8550', 'ARCH': 'arm'}],
                 'outputs': outputs}
    write(owner / 'retention-plan.json', retention)
    write(owner / 'admission-plan.json', admission)
    write(owner / 'planning-inputs.json', {'commit': a.commit, 'tree': git(tree, 'rev-parse', 'HEAD^{tree}'),
          'es_commit': a.expected_es, 'es_recipe_sha256': es_recipe_sha256, 'product_sha256': product_sha256,
          'warm_parent': str(PARENT), 'container_checkout': CONTAINER,
          'stage': stage, 'required_bytes': sum(terms.values()), 'admission_prepared': False})
    print(json.dumps({'owner': str(owner), 'required_bytes': sum(terms.values()),
                      'next': 'watched retention-report, then fresh admission prepare and submit'}))


if __name__ == '__main__':
    main()

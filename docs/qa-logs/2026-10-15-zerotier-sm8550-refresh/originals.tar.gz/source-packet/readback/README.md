# SM8550 ZeroTier artifact readback

Source-only packet for actual consumed SM8550-06 build at `077197e6cd3ea31f33b28aaf3882a694b3423b53`, timestamp `20261015T161744Z`. The bounded H700 reader lifecycle is reused, while SM8550's accepted installed and firmware checks remain device-specific: one GPT image and update tar, SYSTEM/KERNEL equality, all five exact ABL package/raw/update files, ARM handoff, Dolphin/Steam/gstreamer mappings, selected-state checker65ab515e and the14 native/guest FEX payloads. The signed ABL remains ELF32/EM_ARM40; it must never be passed to the generic AArch64-userland assertion. `verify-installed.py` is byte-identical to the accepted SM8550 reader.

The ZeroTier addition is the successful GENERIC reader02/H700 source logic with AArch64 machine183: filtered source hash, absent nonfree, actual OneService compiler argv/object, package/install/SYSTEM bytes/modes/links, and explicit `not-requested-by-canonical-build` when canonical make generated no `.d` files. It does not claim dependency completeness or execute a target binary.

`verify-fex-cached.py` retains the accepted payload/ABI and generated-input checks through host reads. It binds the exact original FEX receipt, current unchanged recipe and CMake cache, selected rootfs/toolchain paths, held toolchain/source/Nix binary hashes, and all14 current installed package payloads. The accepted original Nix version/resolution remains historical provenance. Neither Nix nor FEX is executed; no resolver, download, FEX build or whole-store/source-completeness claim is added. The firmware reader independently compares those exact14 payloads against packaged SYSTEM. The existing Nix store identity is inherited from the consumed new producer and protected through readback.

The original SM combined producer1/0/1 at081827 and its separately accepted reader/firmware result remain unchanged. New producer0 and reader0 are distinct records. Old SM04 parent guards and the old ABL-only source delta cannot be reused against the new checkout: exact new source, product hashes, two consumed atomic transfers and actual consumed producer originals supply the current bindings. Existing212 selected-state controls are hash-bound, not replayed.

Root commands after actual new build consumption:

```bash
TASK_PACKET=/tmp/pix-m7-zerotier-sm8550-refresh-20261015/readback
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06
TASK_READER=/workspace/tmp/pix-m7-zerotier-sm8550-readback-20261015-01
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
mkdir -m 700 "$TASK_READER"
cd "$TASK_TREE"
python3 -I "$TASK_PACKET/prepare-readback.py" --owner "$TASK_READER"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_READER/retention-plan.json" --output "$TASK_READER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_READER/admission-plan.json" --output "$TASK_READER/admission.json"
tools/watch-build-submit --owner "$TASK_READER" -- --admission "$TASK_READER/admission.json" -- bash "$TASK_READER/run.sh"
# After original watcher and launcher completion:
python3 -I "$TASK_PACKET/consume-readback.py" --owner "$TASK_READER"
```

Bounds are the same as the H700 reader: CPU0,8GiB per-process address space,16GiB per-file,1500 seconds plus15 seconds forced-stop grace. Retention uses the accepted64GiB firmware/scratch operating allowance. Existing candidate-store storage retains one immutable firmware bundle with independent inodes; serialized raw scratch is removed after successful verification. No cache or Nix duplication. A failed reader stays failed; investigate it without replaying successful package/image work. All cache paths bind06, while prior manifests/receipts are immutable evidence only.

No target execution, provider join, physical boot/smoke, runtime qualification, RC or publication claim. No preparer, admission or reader was run by this source worker. AST and shell syntax are the only executed source checks.

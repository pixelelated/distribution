#!/usr/bin/env python3
"""Consume original new SM8550 reader zeros; prior failed producers remain failed."""
from pathlib import Path
import argparse,hashlib,json,subprocess
TREE=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06')
OWNER=Path('/workspace/tmp/pix-m7-zerotier-sm8550-readback-20261015-01')
COMMIT='077197e6cd3ea31f33b28aaf3882a694b3423b53'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
def gone(record):
    try:fields=(Path('/proc')/str(record['pid'])/'stat').read_text().rsplit(')',1)[1].split()
    except FileNotFoundError:return True
    return fields[0]=='Z' or fields[19]!=str(record['start_ticks'])
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--owner',type=Path,required=True);a=p.parse_args();O=a.owner.resolve(strict=True)
    assert O==OWNER and Path.cwd().resolve()==TREE
    j=load(O/'inputs.json');binding=load(O/'bindings.json');run=Path((O/'run.path').read_text().strip());assert run.parent==TREE/'.build-runs'
    for n,h in load(O/'seal.json').items():assert sha(n)==h,n
    subprocess.run(['python3','-I',str(O/'verify-prerequisites.py')],check=True)
    subprocess.run(['python3','-I',str(O/'verify-source.py')],check=True)
    acceptance=load(O/'artifacts/acceptance.json')
    assert acceptance['result']=='PASS' and acceptance['distribution_commit']==COMMIT
    assert acceptance['scratch_removed'] and acceptance['source_unchanged'] and acceptance['independent_bundle_inodes']
    assert acceptance['producer_combined_run_returncode']==0 and acceptance['producer_run']==j['compiled_run']
    assert acceptance['producer_consumed_sha256']==j['compiled_consumed_sha256'] and acceptance['reader_run']==str(run)
    assert acceptance['host_checker']['host_checker_sha256']==binding['host_checker_sha256']
    assert (O/'artifacts/selected-state.exit').read_text().strip()=='0' and load(O/'artifacts/selected-state.stdout')['status']=='pass'
    affected=load(O/'artifacts/affected-products.json');assert affected['result']=='PASS' and affected['device']=='SM8550' and affected['source']==COMMIT
    assert affected['special']['abl_1_2_format']['class']=='ELF32' and affected['special']['abl_1_2_format']['e_machine']==40
    fex=load(O/'artifacts/fex-package.json');assert fex['result']=='PASS' and len(fex['files'])==14 and fex['target_execution'] is False and fex['nix_execution'] is False
    assert load(O/'artifacts/fex-installed.json')['files']==fex['files']
    z=affected['special']['zerotier'];assert z['nonfree_absent'] and z['target_execution'] is False and z['dependency_completeness_claim'] is False
    assert z['dependency_record_mode'] in ['not-requested-by-canonical-build','observed-compiler-records-no-completeness-claim']
    assert z['recipe_sha256']=='b876990db897995a230330a78704e16ad881e5424f6ff172fee9d7f2203a1aba' and z['patch_sha256']=='5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5'
    launch=load(O/'launcher-result.json');runner=load(run/'runner-result.json')
    assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
    assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    assert gone(load(O/'launcher-start.json'))
    for name in ['build.pid','command.pid','watcher.pid','build.status.pid']:
        path=run/name
        if path.exists():assert not Path('/proc',path.read_text().strip()).exists()
    files=[O/'artifacts'/name for name in ['acceptance.json','affected-products.json','affected-products-staged.json','installed-inclusion.json','output-manifest.json','payload-equality.json','arm-output-manifest.json','arm-handoff.json','selected-state.stdout','selected-state.stderr','selected-state.exit','fex-package.json','fex-installed.json','partition-table.json']]
    files += [O/name for name in ['inputs.json','bindings.json','seal.json','launcher-result.json','candidate-bundle.path']]+[run/'runner-result.json']
    for path in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc']:assert path.read_text().strip()=='0';files.append(path)
    ad=load(run/'admission.json');assert ad['source']['head']==COMMIT and ad['checkout']==str(TREE) and ad['submission_owner']==str(O) and ad['run']==str(run)
    proof={'run':str(run),'disposition':'qualified','expected_rc':0,'evidence':[{'path':str(p),'sha256':sha(p)} for p in files],'outputs':ad['outputs'],
        'scope':'New SM8550 artifact reader originals0 only after consumed canonical producer0. Earlier combined producer1 and reader failures unchanged. No target execution, physical boot/smoke, RC or publication claim.'}
    output=O/'consumption-evidence.json'
    with output.open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
    subprocess.run(['python3','-I',str(TREE/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(output)],check=True)
    c=load(run/'admission-consumed.json');assert c['state']=='consumed' and c['original_result']==runner
    print('PASS new SM8550 artifact readback consumed; original failures remain unchanged')
if __name__=='__main__':main()

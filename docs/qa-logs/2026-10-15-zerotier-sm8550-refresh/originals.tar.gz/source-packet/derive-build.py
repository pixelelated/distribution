from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;H=Path('/tmp/pix-m7-zerotier-h700-refresh-20261015/build');D=P/'build';D.mkdir()
NIX='/workspace/tmp/pix-m7-sm8550-refresh-20261015-02/nix'
def x(s):return s.replace('m7-pixelelated-h700-05','m7-pixelelated-sm8550-06').replace('m7-pixelelated-h700-04','m7-pixelelated-sm8550-05').replace('h700','sm8550').replace('H700','SM8550').replace('f8636de1d105275dbf9420bbabbbc26f79abb10f','9aa7affee9d4ad5e69725cab20b6d7ad84d93dea')
for name in ['prepare-owner.py','prepare-plan.py','build-owner.py','consume-stage.py','inside-build.sh','container-ready.py']:
 (D/name).write_text(x((H/name).read_text()))
for name in ['host-resources.py','inner-build.py']:shutil.copyfile(H/name,D/name)
s=(P/'transfer/arm/dependency-readback.py').read_text().replace('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05/build.pixelelated-SM8550.arm',NIX).replace('Atomic relocation of completed owned build cache, not deletion.','Exclusive reuse of existing Nix store; no relocation, copy or deletion.').replace('current SM8550 source/artifact readers and every prepared consumer of this exact ABI root','all Nix/source custody readers and the one immediate SM8550 image consumer')
(D/'nix-dependency-readback.py').write_text(s)
p=D/'prepare-owner.py';s=p.read_text().replace(", 'projects/ROCKNIX/packages/tools/rocknix-abl/package.mk']",']')
s=s.replace('import shutil\n','import shutil\nimport time\n')
s=s.replace("p.add_argument('--timestamp', required=True)","p.add_argument('--timestamp', required=True)\n    p.add_argument('--nix-dependency', required=True, type=Path)\n    p.add_argument('--nix-dependency-sha256', required=True)")
s=s.replace("datetime.datetime.strptime(a.timestamp, '%Y%m%dT%H%M%SZ')", "datetime.datetime.strptime(a.timestamp, '%Y%m%dT%H%M%SZ')\n    assert a.timestamp == '20261015T161744Z', 'coordinated published source set timestamp'")
needle="    helpers = ['build-owner.py', 'host-resources.py', 'inner-build.py', 'inside-build.sh', 'container-ready.py']"
new='''    nix_root = Path('''+repr(NIX)+''')
    dependency = a.nix_dependency.resolve(strict=True)
    assert sha(dependency) == a.nix_dependency_sha256
    d = json.loads(dependency.read_text());st=nix_root.stat()
    assert nix_root.is_dir() and not nix_root.is_symlink()
    assert d['status']=='CLEAR_WITH_STATED_SCOPE' and d['root']==str(nix_root)
    assert d['root_identity']=={'device':st.st_dev,'inode':st.st_ino}
    assert d['host_pid_namespace']==Path('/proc/self/ns/pid').stat().st_ino
    assert 0 <= time.time()-d['utc_epoch'] <= 900
    assert d['prepared_consumers_resolved'] and not d['process_matches'] and not d['remaining_consumers'] and not d['active_admissions']
    for mount in d['docker_all_mounts']:
        path=Path(mount.get('source',mount.get('Source','')));assert path.is_absolute()
        assert not (path==nix_root or path in nix_root.parents or nix_root in path.parents)
'''+needle
assert needle in s;s=s.replace(needle,new)
s=s.replace("'host_pid_namespace': os.readlink('/proc/self/ns/pid'),", "'host_pid_namespace': os.readlink('/proc/self/ns/pid'),\n        'nix_store': str(nix_root), 'nix_identity': d['root_identity'],\n        'nix_dependency': str(dependency), 'nix_dependency_sha256': sha(dependency),\n        'nix_policy': 'Exclusive reuse of existing consumed SM8550 Nix store; no duplicate, clean, resolver rerun or FEX rebuild requested',")
p.write_text(s)
p=D/'build-owner.py';s=p.read_text();needle="    for name, expected in config['helper_sha256'].items():"
new='''    nix_root=Path(config['nix_store']);nix_stat=nix_root.stat()
    assert str(nix_root)=='''+repr(NIX)+''' and not nix_root.is_symlink()
    assert config['nix_identity']=={'device':nix_stat.st_dev,'inode':nix_stat.st_ino}
    assert sha(Path(config['nix_dependency']))==config['nix_dependency_sha256']
    nix_dependency=json.loads(Path(config['nix_dependency']).read_text())
    assert nix_dependency['status']=='CLEAR_WITH_STATED_SCOPE' and nix_dependency['root']==str(nix_root)
    assert nix_dependency['root_identity']==config['nix_identity'] and 0 <= time.time()-nix_dependency['utc_epoch'] <= 900
'''+needle
s=s.replace(needle,new,1)
s=s.replace("'RELEASE_VERSION', 'OS_VERSION']", "'RELEASE_VERSION', 'OS_VERSION', 'NIX_PATH', 'NIX_CONFIG']")
s=s.replace("tree / 'release', owner])", "tree / 'release', owner, nix_root])")
s=s.replace("'-v', str(owner) + ':/build-owner', '-e', 'TMPDIR=/tmp',", "'-v', str(owner) + ':/build-owner', '-v', str(nix_root) + ':/nix', '-e', 'TMPDIR=/tmp',")
s=s.replace("assert any(m['Source'] == str(owner) and m['Destination'] == '/build-owner' and m['RW'] for m in mounts)","assert any(m['Source'] == str(owner) and m['Destination'] == '/build-owner' and m['RW'] for m in mounts)\n                        assert any(m['Source'] == str(nix_root) and m['Destination'] == '/nix' and m['RW'] for m in mounts)")
p.write_text(s)
p=D/'inside-build.sh';p.write_text('''#!/bin/bash
set -euo pipefail
python3 -I /build-owner/container-ready.py
./scripts/checkdeps
export NIX_INSTALLER_NO_CHANNEL_ADD=1
export NIX_INSTALLER_NO_MODIFY_PROFILE=1
export NIX_CONFIG=$'build-users-group =
sandbox = false
max-jobs = 2
cores = 2'
make SM8550
''')
p=D/'prepare-plan.py';s=p.read_text().replace("'/workspace/cache/rocknix-sources',", "'/workspace/cache/rocknix-sources',j['nix_store'],")
s=s.replace("outputs.append(dict(path=str(O),", "outputs.append(dict(path=j['nix_store'],issue=555,kind='build-cache',release_when='Immediate SM8550 image/readback and FEX corresponding-source consumers complete; no duplicate store'))\noutputs.append(dict(path=str(O),")
p.write_text(s)

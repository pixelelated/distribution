# Minimal SM8550 ZeroTier refresh source packet

All work is source-only under this directory. No checkout creation, cache/Nix access, allocation census, preparer, admission, compiler, reader, VM, network or shared-record mutation was performed. Python AST and shell syntax checks passed. Scope is source077197, newSM8550-06, common timestamp20261015T161744Z, old accepted9aa7 source and exact two ZeroTier product paths.

Run the separately reviewed stages in order; each README provides the existing concrete command route:

| Packet | SHA256 of its SHA256SUMS | Actual prerequisite |
| --- | --- | --- |
| transfer/ | 9efa6a1301c7a3cbfaefe3eed2fff7614ad807b0281e21ece1b837639ecb40bf | Actual new H700 build and independent artifact acceptance consumed0; their real hashes supplied at execution |
| build/ | 1013e9151fdbdc1dcf723a61bac754b29a15224cd2a23f8c9529e7fbda4411e1 | Both independently consumed SM ABI transfers and fresh exclusive Nix-use assessment |
| readback/ | 0ff1e7e1fb3d6b4c5ec01db20555e9fc5ba191b7f0e24532809b98bc2328c4a0 | Actual new SM canonical producer0 consumed, with its real timestamp/run/evidence |

`INHERITED-GUARDS.md` records device/lifecycle mismatches corrected before execution. Read it before root review. Source derivation scripts are retained for provenance; do not rerun them against these released immutable directories. A correction requires a separately named derivative and a new seal.

No pending result is fabricated. Failure originals, old firmware and old tracked checkouts remain distinct. The old cache roots move one at a time through the accepted atomic ownership-transfer route; no duplicate cache or Nix store is created. Only native ZeroTier is explicitly cleaned/rebuilt; ordinary ARM then AArch64 makeSM8550 handles image assembly. Independent readback preserves the accepted GPT, ABL, FEX, ARM handoff and selected-state scopes, with no target execution, physical/native, RC or publication claim.

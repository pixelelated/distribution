from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent;H=Path('/tmp/pix-m7-zerotier-h700-refresh-20261015/readback');D=P/'readback';D.mkdir();R=Path('/workspace/tmp/pix-m7-sm8550-reader-20261015-01');A=R/'acceptance'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def x(s):return s.replace('m7-pixelelated-h700-05','m7-pixelelated-sm8550-06').replace('m7-pixelelated-h700-04','m7-pixelelated-sm8550-05').replace('h700','sm8550').replace('H700','SM8550')
for name in ['prepare-readback.py','consume-readback.py','verify-prerequisites.py','verify-source.py','run.py','run.sh','bindings.template.json']:(D/name).write_text(x((H/name).read_text()))
(D/'host-checker').mkdir();shutil.copyfile(H/'host-checker/pixelelated-state-check',D/'host-checker/pixelelated-state-check')
for name in ['verify-installed.py','proxy-source-proof.json','dolphin-sys-source-manifest.json','abl-expected.json']:shutil.copyfile(R/name,D/name)
shutil.copyfile(R/'artifacts/fex-package.json',D/'fex-accepted.json')
s=(R/'verify-additions.py').read_text().replace('import argparse,datetime,hashlib','import argparse,datetime,shlex,struct,hashlib')
block=(H/'verify-additions.py').read_text();block=block[block.index('# Scope-limited ZeroTier package provenance'):block.index("result={'result':'PASS'")]
s=s.replace("result={'result':'PASS'",block+"result={'result':'PASS'")
s=s.replace("'scope':'Normal package clean/rebuild and canonical KERNEL assembly; no physical boot claim.'","'scope':'Reused accepted kernel stamp and canonical KERNEL assembly; this refresh explicitly cleans only ZeroTier. No physical boot claim.'")
(D/'verify-additions.py').write_text(s)
s=(A/'verify-firmware.py').read_text().replace("build_owner = Path('/workspace/tmp/pix-m7-sm8550-reader-20261015-01')",'build_owner = owner')
s=s.replace("checker=owner/'pixelelated-state-check'","checker=owner/'host-checker/pixelelated-state-check'")
s=s.replace("producer_combined_run_returncode=1, producer_failed_run='/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05/.build-runs/20261015T081827Z-07dceee9',", "producer_combined_run_returncode=0, producer_run=inputs['compiled_run'],\n               producer_consumed_sha256=inputs['compiled_consumed_sha256'], reader_run=(owner/'run.path').read_text().strip(),")
s=s.replace('Independent artifact acceptance after consumed original ABL format reader failure; no successful combined producer claim','New ZeroTier SM8550 artifact acceptance after consumed successful canonical build; original ABL format reader/combined producer failure remains unchanged')
(D/'verify-firmware.py').write_text(s)
j=json.loads((R/'inputs.json').read_text());template=json.loads((H/'inputs.template.json').read_text())
for k in list(template):
 if k in j:template[k]=j[k]
template.update(host_worktree='/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06',distribution_branch='build/m7-pixelelated-sm8550-06',distribution_commit='077197e6cd3ea31f33b28aaf3882a694b3423b53',prior_arm_manifest=str(R/'artifacts/arm-output-manifest.json'),prior_arm_manifest_sha256=sha(R/'artifacts/arm-output-manifest.json'))
for k in ['fex_commit','guest_libraries32','guest_libraries64','nix_private_store','abl_expected_sha256','host_state_checker']:template[k]=j[k]
template['host_state_checker']['path']='/workspace/tmp/pix-m7-zerotier-sm8550-readback-20261015-01/host-checker/pixelelated-state-check'
template['arm_manifest']='/workspace/tmp/pix-m7-zerotier-sm8550-readback-20261015-01/artifacts/arm-output-manifest.json'
template['accepted_fex_sha256']=sha(D/'fex-accepted.json')
(D/'inputs.template.json').write_text(json.dumps(template,indent=2)+'\n')
p=D/'prepare-readback.py';s=p.read_text().replace("'host-checker/pixelelated-state-check']", "'host-checker/pixelelated-state-check','verify-fex-cached.py','fex-accepted.json','abl-expected.json']")
s=s.replace("assert cfg['commit']==COMMIT and cfg['checkout']==str(TREE)","assert cfg['commit']==COMMIT and cfg['checkout']==str(TREE) and cfg['build_timestamp']=='20261015T161744Z'")
s=s.replace("'/workspace/tmp/pix-m7-sm8550-state-acceptance-20261015-01'","'/workspace/tmp/pix-m7-sm8550-reader-20261015-01'")
s=s.replace('32f7a6523dfae61b5142cf803876bf4e09f9a21a3a6784a69ca74b9d9b587833','09addac6d353e2a30e06610d87fa46b72a4bdfa82c711fd77a658b9e7f1d3ca0').replace('serialized raw DDR3/DDR4 scratch','one GPT raw image scratch')
s=s.replace("assert j['container']==cfg['builder_image'] and j['host_options_sha256']==cfg['host_options_sha256']", "assert j['container']==cfg['builder_image'] and j['host_options_sha256']==cfg['host_options_sha256']\n    assert j['nix_private_store']==cfg['nix_store']\n    j['nix_identity']=cfg['nix_identity']")
p.write_text(s)
p=D/'run.py';s=p.read_text().replace("subprocess.run(['python3','-I',str(O/'verify-installed.py')],check=True)","subprocess.run(['python3','-I',str(O/'verify-fex-cached.py')],check=True)\n subprocess.run(['python3','-I',str(O/'verify-installed.py')],check=True)")
s=s.replace("len(outputs)==7 and len([n for n in outputs if n.endswith('.img.gz')])==2", "len(outputs)==5 and len([n for n in outputs if n.endswith('.img.gz')])==1")
s=s.replace("distribution_commit=j['distribution_commit'],files=outputs)","distribution_commit=j['distribution_commit'],files=outputs,arm_manifest_sha256=hashlib.sha256((O/'artifacts/arm-output-manifest.json').read_bytes()).hexdigest())")
p.write_text(s)
p=D/'consume-readback.py';s=p.read_text().replace("acceptance['host_checker']['sha256']", "acceptance['host_checker']['host_checker_sha256']")
s=s.replace("z=affected['special']['zerotier'];", "assert affected['special']['abl_1_2_format']['class']=='ELF32' and affected['special']['abl_1_2_format']['e_machine']==40\n    fex=load(O/'artifacts/fex-package.json');assert fex['result']=='PASS' and len(fex['files'])==14 and fex['target_execution'] is False and fex['nix_execution'] is False\n    assert load(O/'artifacts/fex-installed.json')['files']==fex['files']\n    z=affected['special']['zerotier'];")
s=s.replace("'selected-state.stdout','selected-state.stderr','selected-state.exit']", "'selected-state.stdout','selected-state.stderr','selected-state.exit','fex-package.json','fex-installed.json','partition-table.json']")
p.write_text(s)

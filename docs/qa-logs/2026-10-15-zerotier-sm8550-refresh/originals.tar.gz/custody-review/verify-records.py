from pathlib import Path
import datetime,hashlib,json
OUT=Path(__file__).parent;P=Path('/tmp/pix-m7-zerotier-sm8550-refresh-20261015');BR=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06/.build-runs');HEAD='077197e6cd3ea31f33b28aaf3882a694b3423b53'
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
seals=[]
for stage,seal in [('', 'f815d5a9c20353e7cd9f46be43eaf6717f7ef42bb3c9ae6bab0a9236a9aec21a'),('transfer/arm','8de201cf841bde81d4f3188d7130b48b5e730a3660b7ed43a740e321af421b82'),('transfer/aarch64','3caaf83a00d33d377164d17eafc59aea0155016858bcea936a34954b24d1caeb'),('build','1013e9151fdbdc1dcf723a61bac754b29a15224cd2a23f8c9529e7fbda4411e1'),('readback','0ff1e7e1fb3d6b4c5ec01db20555e9fc5ba191b7f0e24532809b98bc2328c4a0')]:
 p=P/stage;assert h(p/'SHA256SUMS')==seal;count=0
 for line in (p/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1);f=p/name;assert f.is_relative_to(P) and f.stat().st_size<2*1024**2 and h(f)==expected;count+=1
 seals.append({'path':str(p),'seal':seal,'payloads':count})
rows=[];record_runs={}
for stage,runid,aid in [('transfer-arm','20261015T171056Z-c6cdfbe9','823834ddea5444d9862df4ed845528f1'),('transfer-aarch64','20261015T171205Z-1bea2865','4b6f0eb3eb3546298898aa5ba0d42112'),('build','20261015T171321Z-6ff35da3','f0c52475de364382aec5373eaa29daba'),('readback','20261015T172008Z-84c14305','4e78acebe887499a9a13f68a57e5262a')]:
 o=Path('/workspace/tmp/pix-m7-zerotier-sm8550-'+stage+'-20261015-01');r=BR/runid;runner=j(r/'runner-result.json');cons=j(r/'admission-consumed.json');ev=j(o/'consumption-evidence.json')
 assert (runner['command_rc'],runner['monitor_rc'],runner['runner_rc'])==(0,0,0) and cons['original_result']==runner and cons['state']=='consumed' and cons['id']==aid
 assert cons['pid_namespace']==4026531836 and cons['source']['head']==HEAD and cons['run']==str(r) and cons['submission_owner']==str(o)
 assert (o/'run.path').read_text().strip()==str(r) and cons['evidence_sha256']==h(o/'consumption-evidence.json') and ev['disposition']=='qualified' and ev['expected_rc']==0
 assert j(o/'launcher-result.json')['runner_returncode']==0
 for f in [o/'inner.rc',o/'tool-wrapper.rc',r/'build.rc']+([o/'outer.rc'] if stage=='readback' else []):assert f.read_text()=='0\n'
 for e in ev['evidence']:
  p=Path(e['path']);assert (p.is_relative_to(o) or p.is_relative_to(r)) and p.stat().st_size<2*1024**2 and h(p)==e['sha256']
 co=Path('/tmp/pix-m7-sm8550-'+('reader' if stage=='readback' else stage)+'-coordinator-20261015');exits=[]
 for f in sorted(co.glob('*.exit.json')):assert j(f)['original_tool_exit']==0;exits.append(f.name)
 assert {'prepare.exit.json','preflight.exit.json','report.exit.json','admit.exit.json','launch.exit.json','consume.exit.json'}<=set(exits)
 for f in sorted(co.glob('*.stderr')):
  for line in f.read_text().splitlines():
   if line.startswith('watch-build: recording in '):
    rp=Path(line.removeprefix('watch-build: recording in '));assert rp.parent==BR;rr=j(rp/'runner-result.json');assert (rr['command_rc'],rr['monitor_rc'],rr['runner_rc'])==(0,0,0);assert (rp/'build.rc').read_text()=='0\n';record_runs[str(rp)]={'original_result':rr,'source_locator':str(f)}
 rows.append({'stage':stage,'owner':str(o),'run':str(r),'original_result':runner,'launcher_returncode':0,'consumed_id':aid,'consumed_utc':cons['consumed'],'consumed_sha256':h(r/'admission-consumed.json'),'evidence_sha256':h(o/'consumption-evidence.json'),'verified_compact_evidence_count':len(ev['evidence']),'root_command_exit_receipts':exits})
deps=[];transfers=[]
for stage,stem,expected_inode in [('transfer-arm','dependency',149320479),('transfer-aarch64','dependency',149320487),('build','nix-dependency',193777809)]:
 o=Path('/workspace/tmp/pix-m7-zerotier-sm8550-'+stage+'-20261015-01');d=j(o/(stem+'-readback.json'));a=j(o/(stem+'-assessed.json'))
 assert d['status']=='REVIEW_REQUIRED' and a['status']=='CLEAR_WITH_STATED_SCOPE'
 assert a['original_readback']==str(o/(stem+'-readback.json')) and a['original_readback_sha256']==h(o/(stem+'-readback.json'))
 assert d['host_pid_namespace']==a['host_pid_namespace']==4026531836 and a['root_identity']=={k:d['identity'][k] for k in ['device','inode']}=={'device':66304,'inode':expected_inode}
 assert not d['matches'] and not d['container_references'] and not d['active_admissions'] and not a['remaining_consumers'] and a['prepared_consumers_resolved']
 assert a['process_errors']==d['errors'] and len(a['excluded_from_fd_scope'])==len(d['errors'])==6 and {x['pid'] for x in d['errors']}=={x['pid'] for x in a['excluded_from_fd_scope']}
 for m in a['docker_all_mounts']:
  path=Path(m['source']);root=Path(a['root']);assert path!=root and root not in path.parents and path not in root.parents
 deps.append({'stage':stage,'root':d['root'],'identity':a['root_identity'],'readback_sha256':h(o/(stem+'-readback.json')),'assessed_sha256':h(o/(stem+'-assessed.json')),'six_original_errors':d['errors'],'exclusions':a['excluded_from_fd_scope'],'other_uid_processes_without_fd_census':d['other_uid_processes_without_fd_census'],'unrelated_docker_mount_rows':len(a['docker_all_mounts']),'scope':a['scope']})
 if stage.startswith('transfer-'):
  t=j(o/'transfer-result.json');assert t==j(o/'cache-ready.json') and t['status']=='PASS' and t['method']=='same-filesystem-rename' and not t['copy_performed'] and t['renamed']
  assert t['before_identity']==t['after_identity']==a['root_identity'] and t['destination_head']==HEAD and t['source_head']=='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea'
  assert t['dependency_readback']['sha256']==h(o/(stem+'-assessed.json'))
  prior=t['original_build_consumption'];assert prior['failed_investigated'] and prior['sha256']=='f820b116c70bd2dbbc67b873bb11d881222fb8b1c15af15505aa6a710dc0049b' and h(prior['path'])==prior['sha256']
  original=j(prior['path']);assert original['original_result']==prior['original_result'] and [prior['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[1,0,1]
  transfers.append(t)
b=Path('/workspace/tmp/pix-m7-zerotier-sm8550-build-20261015-01');r=Path('/workspace/tmp/pix-m7-zerotier-sm8550-readback-20261015-01');owner=j(b/'owner-result.json');resources=j(b/'resource-result.json')
assert owner['status']==resources['status']=='PASS' and all(not owner[k] for k in ['cleanup','signals']) and all(not x for x in owner['surviving_host_command_groups'].values()) and resources['errors']==[] and resources['all_threads_exited']
assert len(owner['stages'])==3 and {x['stage'] for x in owner['stages']}=={'clean-zerotier-one','build-zerotier-one','image'}
for s in owner['stages']:
 assert s['original_host_make_rc']==0 and s['container_observed'] and s['observation_handshake']
 x=j(b/'stages'/s['stage']/'inner-result.json');assert x['original_command_rc']==x['wrapper_rc']==0 and x['signals']==[]
for n in ['build-owner.py','inner-build.py','host-resources.py','container-ready.py','inside-build.sh']:assert h(b/n)==h(P/'build'/n)
a=r/'artifacts';accept=j(a/'acceptance.json');affected=j(a/'affected-products.json');staged=j(a/'affected-products-staged.json');installed=j(a/'installed-inclusion.json');state=j(a/'selected-state.stdout');fex=j(a/'fex-installed.json')
assert accept['result']==affected['result']==staged['result']==installed['result']==fex['result']=='PASS'
assert accept['distribution_commit']==affected['source']==HEAD and affected['products']==staged['products'] and affected['source_mappings']==staged['source_mappings']
assert accept['producer_combined_run_returncode']==0 and accept['producer_consumed_sha256']==h(BR/'20261015T171321Z-6ff35da3/admission-consumed.json')
assert accept['producer_run']==str(BR/'20261015T171321Z-6ff35da3') and accept['reader_run']==str(BR/'20261015T172008Z-84c14305')
assert accept['scratch_removed'] and accept['source_unchanged'] and accept['independent_bundle_inodes']
assert accept['bundle_manifest_sha256']=='ee397da7e520534ce1a393909fc4a5b8d54ffecf3d6611b1ae5548b2f920dca4' and (r/'candidate-bundle.path').read_text().strip()==accept['bundle']
assert accept['variants']==j(a/'payload-equality.json') and {x['variant'] for x in accept['variants']}=={'SM8550'}
assert len(j(a/'arm-handoff.json'))==accept['arm_handoff_files']==188 and len(affected['products'])==53 and len(fex['files'])==14
assert state['status']=='pass' and state['mode']=='clean-image' and state['blocked_count']==state['error_count']==0 and (a/'selected-state.exit').read_text()=='0\n'
assert affected['special']['zerotier']['nonfree_absent'] and affected['special']['zerotier']['dependency_completeness_claim'] is False and affected['special']['zerotier']['dependency_file_count']==0 and affected['special']['zerotier']['target_execution'] is False
assert affected['special']['gstreamer_profile']['gst_plugins_good_selected'] is True and affected['special']['kernel']['recipe_version']=='7.2'
assert accept['host_checker']['host_checker_sha256']==h(r/'host-checker/pixelelated-state-check')=='65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6'
abl=affected['special']['abl_1_2_format'];assert abl['class']=='ELF32' and abl['encoding']=='little-endian' and abl['e_machine']==40 and len(affected['special']['abl_1_2'])==5
assert affected['special']['abl_1_2']['abl_signed-SM8550.elf']=='8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c'
receipt={'status':'PASS_COMPACT_SM8550_TRANSFER_BUILD_AND_ARTIFACT_RECORDS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_seals':seals,'runs':rows,'record_only_runs':record_runs,'transfers':transfers,'dependency_assessments':deps,'build_elapsed_seconds':owner['elapsed_seconds'],'resource_status':resources['status'],'resource_limit':resources['disk_peak_limit'],'acceptance_sha256':h(a/'acceptance.json'),'acceptance':accept,'affected_products':len(affected['products']),'installed_hash_rows':len(installed['sha256']),'arm_handoff_files':188,'fex_files':14,'abl_format':abl,'selected_state':{k:state[k] for k in ['status','mode','blocked_count','error_count']},'cache_raw_firmware_candidate_bodies_read':False,'live_process_census':False,'scope':'Original compact records only; accepted artifact scope is not physical boot, target runtime, RC or publication qualification. Original failed producer remains 1/0/1.'}
(OUT/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'receipt_sha256':h(OUT/'record-readback.json'),'original_runs':len(rows),'record_only_runs':len(record_runs)}))

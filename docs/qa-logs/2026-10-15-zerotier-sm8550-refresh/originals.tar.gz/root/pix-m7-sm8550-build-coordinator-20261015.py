from pathlib import Path
import hashlib,json,subprocess,sys,os
R=Path('/tmp/pix-m7-sm8550-build-coordinator-20261015');R.mkdir(exist_ok=True)
P=Path('/tmp/pix-m7-zerotier-sm8550-refresh-20261015/build');T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06');O=Path('/workspace/tmp/pix-m7-zerotier-sm8550-build-20261015-01')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(P/'SHA256SUMS')=='1013e9151fdbdc1dcf723a61bac754b29a15224cd2a23f8c9529e7fbda4411e1'
for ln in (P/'SHA256SUMS').read_text().splitlines():h,n=ln.split('  ',1);assert sha(P/n)==h,n
stage=sys.argv[1]
base=['--checkout',str(T),'--commit','077197e6cd3ea31f33b28aaf3882a694b3423b53','--es-recipe-sha256','1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719','--expected-es','16dbac5211eea7e70db7394372033be2be7df829','--owner',str(O)]
if stage=='init':
 O.mkdir(mode=0o700);print('Created fresh SM build owner');raise SystemExit(0)
if stage=='dependencies':cmd=['tools/watch-build','--record-only','--','python3','-I',str(P/'nix-dependency-readback.py'),'--output',str(O/'nix-dependency-readback.json')]
elif stage=='prepare':
 cmd=['python3','-I',str(P/'prepare-owner.py'),*base,'--cache-ready','/workspace/tmp/pix-m7-zerotier-sm8550-transfer-aarch64-20261015-01/cache-ready.json','--arm-cache-ready','/workspace/tmp/pix-m7-zerotier-sm8550-transfer-arm-20261015-01/cache-ready.json','--timestamp','20261015T161744Z','--family-seconds','7200','--nix-dependency',str(O/'nix-dependency-assessed.json'),'--nix-dependency-sha256',sha(O/'nix-dependency-assessed.json')]
elif stage=='plan':cmd=['python3','-I',str(P/'prepare-plan.py'),'--owner',str(O)]
elif stage=='preflight':cmd=['tools/build-preflight']
elif stage=='report':cmd=['tools/watch-build','--record-only','--','python3','-I','tools/host-maintenance/retention-report','--plan',str(O/'retention-plan.json'),'--output',str(O/'retention-report.json')]
elif stage=='admit':cmd=['python3','-I','tools/host-maintenance/build-admission','prepare','--plan',str(O/'admission-plan.json'),'--output',str(O/'admission.json')]
elif stage=='launch':cmd=['tools/watch-build-submit','--owner',str(O),'--','--admission',str(O/'admission.json'),'--','python3','-I',str(O/'build-owner.py')]
elif stage=='consume':cmd=['python3','-I',str(P/'consume-stage.py'),'--owner',str(O),'--stage','build']
else:raise ValueError(stage)
env=os.environ.copy();env.update(PROJECT='ROCKNIX',DEVICE='SM8550',ARCH='aarch64')
with (R/(stage+'.stdout')).open('xb') as out,(R/(stage+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=T,env=env,stdout=out,stderr=err)
with (R/(stage+'.exit.json')).open('x') as f:json.dump({'original_tool_exit':p.returncode,'argv':cmd},f)
print(json.dumps({'stage':stage,'original_tool_exit':p.returncode,'stdout':str(R/(stage+'.stdout'))}));sys.exit(p.returncode)

from pathlib import Path
import hashlib,json,subprocess,sys,os
arch,stage=sys.argv[1:];assert arch in ['arm','aarch64']
R=Path('/tmp/pix-m7-sm8550-transfer-'+arch+'-coordinator-20261015');R.mkdir(exist_ok=True)
P=Path('/tmp/pix-m7-zerotier-sm8550-refresh-20261015/transfer')/arch;T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-06');O=Path('/workspace/tmp/pix-m7-zerotier-sm8550-transfer-'+arch+'-20261015-01')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'SHA256SUMS')=={'arm':'8de201cf841bde81d4f3188d7130b48b5e730a3660b7ed43a740e321af421b82','aarch64':'3caaf83a00d33d377164d17eafc59aea0155016858bcea936a34954b24d1caeb'}[arch]
for ln in (P/'SHA256SUMS').read_text().splitlines():
 h,n=ln.split('  ',1);assert sha(P/n)==h,n
base=['--checkout',str(T),'--commit','077197e6cd3ea31f33b28aaf3882a694b3423b53','--es-recipe-sha256','1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719','--expected-es','16dbac5211eea7e70db7394372033be2be7df829','--measurement',str(P/'capacity-measurement.json'),'--owner',str(O),'--stage','transfer']
if stage=='prepare':
 O.mkdir(mode=0o700);cmd=['python3','-I',str(P/'prepare-plan.py'),*base]
elif stage=='preflight':cmd=['tools/build-preflight']
elif stage=='report':cmd=['tools/watch-build','--record-only','--','python3','-I','tools/host-maintenance/retention-report','--plan',str(O/'retention-plan.json'),'--output',str(O/'retention-report.json')]
elif stage=='dependencies':cmd=['tools/watch-build','--record-only','--','python3','-I',str(P/'dependency-readback.py'),'--output',str(O/'dependency-readback.json')]
elif stage=='admit':cmd=['python3','-I','tools/host-maintenance/build-admission','prepare','--plan',str(O/'admission-plan.json'),'--output',str(O/'admission.json')]
elif stage=='launch':
 H=Path('/workspace/tmp/pix-m7-zerotier-h700-readback-20261015-01');HR=Path((H/'run.path').read_text().strip())
 cmd=['tools/watch-build-submit','--owner',str(O),'--','--admission',str(O/'admission.json'),'--activity-dir',str(O),'--','python3','-I',str(P/'transfer-cache.py'),'--owner',str(O),'--commit',base[3],'--es-recipe-sha256',base[5],'--dependency-readback',str(O/'dependency-assessed.json'),'--dependency-sha256',sha(O/'dependency-assessed.json'),'--h700-reader',str(H),'--h700-consumed-sha256',sha(HR/'admission-consumed.json'),'--h700-acceptance-sha256',sha(H/'artifacts/acceptance.json')]
elif stage=='consume':cmd=['python3','-I',str(P/'consume-transfer.py'),'--owner',str(O)]
else:raise ValueError(stage)
env=os.environ.copy();env.update(PROJECT='ROCKNIX',DEVICE='SM8550',ARCH=arch)
with (R/(stage+'.stdout')).open('xb') as out,(R/(stage+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=T,env=env,stdout=out,stderr=err)
with (R/(stage+'.exit.json')).open('x') as f:json.dump({'original_tool_exit':p.returncode,'argv':cmd},f)
print(json.dumps({'stage':stage,'original_tool_exit':p.returncode,'stdout':str(R/(stage+'.stdout'))}));sys.exit(p.returncode)

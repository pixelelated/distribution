from pathlib import Path
import json,hashlib,os,subprocess,sys,time

O=Path('/workspace/tmp/pix-m7-zerotier-sm8550-build-20261015-01');P=O/'nix-dependency-readback.json';d=json.loads(P.read_text());r=json.loads(Path('/workspace/tmp/pix-m7-zerotier-sm8550-transfer-aarch64-20261015-01/retention-report.json').read_text());assert all(x['fits_now'] for x in r['builds']) and not d['matches'] and not d['container_references'] and not d['active_admissions']
assert 0<=time.time()-d['utc_epoch']<900 and d['host_pid_namespace']==Path('/proc/self/ns/pid').stat().st_ino
expected={2325:('systemd','795'),2342:('(sd-pam)','796'),564119:('ssh-agent','795045'),2590490:('exo-open','86921233'),2739866:('exo-open','87108365'),3957808:('sshd-session','117524768')}
assert {x['pid'] for x in d['errors']}==set(expected);ex=[]
for row in d['errors']:
 p=Path('/proc')/str(row['pid']);parts=(p/'stat').read_text().rsplit(')',1)[1].split();comm=(p/'comm').read_text().strip();assert (comm,parts[19])==expected[row['pid']]
 x=dict(row,comm=comm,state=parts[0],ppid=int(parts[1]),start_ticks=parts[19],uid=p.stat().st_uid,cgroup=(p/'cgroup').read_text().strip());assert x['uid']==os.getuid()
 for name in ['cwd','root','exe']:
  try:x[name]=os.readlink(p/name)
  except OSError as err:x[name+'_error']=type(err).__name__
 x['assessment']='Exited zombie; no live process address space/FDs.' if parts[0]=='Z' else 'Protected user-session/credential/SSH service; readable descendants covered. Explicit FD-scope exclusion for existing Nix store exclusive build use only, no whole-host root-FD or deletion clearance.'
 ex.append(x)
ids=subprocess.check_output(['docker','ps','-aq'],text=True,timeout=20).split();mounts=[]
if ids:
 v=json.loads(subprocess.check_output(['docker','inspect',*ids],text=True,timeout=30))
 for x in v:
  for m in x.get('Mounts',[]):mounts.append({'container':x['Id'][:12],'running':x['State']['Running'],'source':m['Source']})
root=Path(d['root']);st=root.stat();assert {'device':st.st_dev,'inode':st.st_ino}=={k:d['identity'][k] for k in ['device','inode']}
for m in mounts:
 p=Path(m['source']);assert p!=root and root not in p.parents and p not in root.parents
out={'status':'CLEAR_WITH_STATED_SCOPE','root':str(root),'root_identity':{'device':st.st_dev,'inode':st.st_ino},'host_pid_namespace':d['host_pid_namespace'],'utc_epoch':d['utc_epoch'],'process_matches':d['matches'],'process_errors':d['errors'],'docker_all_mounts':mounts,'active_admissions':d['active_admissions'],'remaining_consumers':[],'prepared_consumers_resolved':True,'consumer_assessment':[{'owner':'root','basis':'Earlier SM combined producer and independent artifact proof are consumed with original statuses preserved. New06 source has exact product delta; both current source workers explicitly confirmed no old05 cache or Nix consumer. New06 build/reader is the immediate owner. H700 custody worker reads completed small H700 originals only.'},{'owner':'m7_source_resume_review','basis':'Confirmed source-only mapping reads held metadata; old05 cache/Nix consumers closed or rebound to06.'},{'owner':'source_custody_delta','basis':'Confirmed full-notice collection reads held archives and copied contexts only; no old05 cache or Nix dependency.'}],'excluded_from_fd_scope':ex,'original_readback':str(P),'original_readback_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'scope':d['scope']+' Six protected services/zombies freshly identified and explicitly excluded; raw errors retained. No root-FD/deletion clearance.'}
with (O/'nix-dependency-assessed.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'status':out['status'],'root':str(root),'errors_preserved':len(ex),'prepared_consumers_resolved':True}))

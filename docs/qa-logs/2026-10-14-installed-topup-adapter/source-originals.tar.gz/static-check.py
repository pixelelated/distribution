#!/usr/bin/env python3
"""Parse and hash only. Does not import or execute any guest/source fixture."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parsed = []
    trees = {}
    for path in sorted(ROOT.rglob('*.py')):
        trees[str(path.relative_to(ROOT))] = ast.parse(path.read_text(), filename=str(path), feature_version=(3, 10))
        parsed.append(str(path.relative_to(ROOT)))
    derivation = json.loads((ROOT / 'derivation.json').read_text())
    for name, expected in derivation['unchanged_accepted_files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
    assert not (ROOT / 'raofflineproxy-ctl').exists()
    runner = (ROOT / 'run-fixture.py').read_text()
    assert '(HERE / "raofflineproxy-ctl", CTL)' not in runner
    assert "os.chdir('/storage')" in runner
    assert 'LIMIT = 240' in runner and 'signal.pidfd_send_signal' in runner
    assert 'locks.acquire(a.output)' in runner and 'locks.release(a.output)' in runner
    assert "api('/reloadgames')" in runner and 'api("/quit")' in runner
    assert 'simulated_prepared' not in runner and 'ctl-events' not in runner
    options = {}
    for node in ast.walk(trees['run-fixture.py']):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'add_argument' and node.args:
            name = ast.literal_eval(node.args[0])
            for kw in node.keywords:
                if kw.arg == 'choices':
                    options[name] = ast.literal_eval(kw.value)
    assert options['--case'] == ['success'] and options['--trigger'] == ['api'] and options['--language'] == ['en_US']
    bootstrap = trees['bootstrap/sitecustomize.py']
    mutations = [node for node in ast.walk(bootstrap) if isinstance(node, ast.Assign)
                 for target in node.targets if isinstance(target, ast.Attribute)
                 and isinstance(target.value, ast.Name) and target.value.id == 'network']
    assert len(mutations) == 1 and mutations[0].targets[0].attr == 'has_active_network_interface'
    assert isinstance(mutations[0].value, ast.Lambda) and ast.literal_eval(mutations[0].value.body) is True
    assert "name == '__main__'" in (ROOT / 'bootstrap/sitecustomize.py').read_text()
    assert 'os._exit(126)' in (ROOT / 'bootstrap/sitecustomize.py').read_text()
    backend = (ROOT / 'backend-state.py').read_text()
    assert "?mode=ro" in backend and 'PRAGMA integrity_check' in backend
    assert 'assert len(fields) == 10' in backend
    assert "before['old_rows_sha256']" in backend and "new_rows_absent" in backend
    assert 'post_strip_es_sha256' in (ROOT / 'bind-image.py').read_text()
    assert 'profile_library_path' in (ROOT / 'bootstrap/installed_contract.py').read_text()
    result = {'status': 'STATIC_PASS_RUNTIME_UNRUN', 'runtime_executed': False,
              'guest_or_proxy_modules_imported': False, 'python_ast_syntax_target': '3.10',
              'parsed_files': parsed, 'unchanged_accepted_files': len(derivation['unchanged_accepted_files']),
              'case_scope': 'one installed success/API/English case',
              'checks': ['accepted guard/fixture byte parity', 'no fake ctl', 'private cwd and lock custody',
                         'original namespace/pidfd cleanup retained', 'sole interface-presence seam',
                         'real SQLite/stamp assertions present', 'actual installed module and ES binding']}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

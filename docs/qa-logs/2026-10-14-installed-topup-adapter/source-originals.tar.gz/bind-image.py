#!/usr/bin/env python3
"""SOURCE-ONLY. Bind final extracted image bytes and reviewed source/strip custody."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--distribution', type=Path, required=True)
    p.add_argument('--source-receipt', type=Path, required=True)
    p.add_argument('--image-sha256', required=True)
    p.add_argument('--boot-id', required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert re.fullmatch('[0-9a-f]{64}', a.image_sha256)
    assert re.fullmatch('[0-9a-f-]{36}', a.boot_id)
    root = a.root.resolve(strict=True)
    assert root != Path('/')

    def sha(f):
        digest = hashlib.sha256()
        with f.open('rb') as stream:
            before = os.fstat(stream.fileno())
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
            after = os.fstat(stream.fileno())
            assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'image input changed while hashing'
        return digest.hexdigest()

    def git(*args):
        return subprocess.check_output(['git', '-C', str(a.distribution), *args], text=True, timeout=10).strip()

    commit = git('rev-parse', 'HEAD')
    package_paths = {'emulationstation': 'projects/ROCKNIX/packages/ui/emulationstation/package.mk',
                     'raofflineproxy': 'projects/ROCKNIX/packages/network/raofflineproxy/package.mk',
                     'rcheevos': 'projects/ROCKNIX/packages/network/raofflineproxy-rcheevos/package.mk',
                     'libchdr': 'projects/ROCKNIX/packages/network/raofflineproxy-libchdr/package.mk'}
    pins = {}
    for name, path in package_paths.items():
        committed = git('show', commit + ':' + path)
        assert (a.distribution / path).read_text().strip() == committed, 'dirty package source'
        pin = re.search(r'^PKG_VERSION="([0-9a-f]{40})"$', committed, re.M)
        assert pin, 'full package source pin required'
        pins[name] = pin.group(1)

    def resolve_image(name):
        pending = list(PurePosixPath(name).parts[1:])
        parts, links = [], 0
        while pending:
            item = pending.pop(0)
            if item in ('', '.'):
                continue
            if item == '..':
                assert parts, 'image link escapes root'
                parts.pop()
                continue
            candidate = root.joinpath(*parts, item)
            if candidate.is_symlink():
                links += 1
                assert links <= 16
                target = os.readlink(candidate)
                if target.startswith('/'):
                    parts = []
                pending = list(PurePosixPath(target).parts)[int(target.startswith('/')):] + pending
            else:
                parts.append(item)
        f = root.joinpath(*parts)
        assert f.is_file()
        return f, '/' + str(f.relative_to(root))

    def row(name):
        f, resolved = resolve_image(name)
        return {'resolved_path': resolved, 'sha256': sha(f), 'bytes': f.stat().st_size, 'mode': f.stat().st_mode & 0o7777}

    assert (root / 'usr/lib').resolve(strict=True).is_relative_to(root), 'module search escapes image'
    modules = list((root / 'usr/lib').glob('python*/site-packages/raofflineproxy'))
    assert len(modules) == 1
    module = modules[0]
    assert module.resolve(strict=True).is_relative_to(root) and not module.is_symlink()
    children = list(module.rglob('*'))
    assert len(children) < 2048 and not any(f.is_symlink() for f in children)
    assert not list(module.rglob('*.py'))
    pycs = sorted(module.rglob('*.pyc'))
    assert 30 <= len(pycs) <= 112
    names = ['/' + str(f.relative_to(root)) for f in pycs]
    names += ['/etc/os-release', '/etc/profile', '/etc/profile.d/001-functions', '/usr/bin/python3',
              '/usr/bin/emulationstation', '/usr/bin/raofflineproxy-ctl', '/usr/bin/raofflineproxy-cache-indexed',
              '/usr/bin/raofflineproxy-cache-images', '/usr/lib/libraproxy_rchash.so',
              '/usr/lib/libzstd.so.1', '/usr/lib/libcrypto.so.3']
    assert (root / 'etc/profile.d').resolve(strict=True).is_relative_to(root), 'profile search escapes image'
    profiles = sorted((root / 'etc/profile.d').iterdir())
    assert 1 <= len(profiles) <= 64 and all(f.is_file() and not f.is_symlink() for f in profiles)
    names += ['/' + str(f.relative_to(root)) for f in profiles]
    files = {name: row(name) for name in sorted(set(names))}
    profile_library_path = ''
    for installed, source in [
        ('/etc/profile.d/98-busybox.conf', 'packages/sysutils/busybox/profile.d/98-busybox.conf'),
        ('/etc/profile.d/99-pulseaudio.conf', 'packages/audio/pulseaudio/profile.d/99-pulseaudio.conf'),
    ]:
        if installed not in files:
            continue
        raw = subprocess.check_output(['git', '-C', str(a.distribution), 'show', commit + ':' + source], timeout=10)
        assert hashlib.sha256(raw).hexdigest() == files[installed]['sha256'], 'profile loader source differs'
        profile_library_path = profile_library_path + ':/usr/lib/pulseaudio' if 'pulseaudio' in installed else '/usr/lib'
    assert not any(re.search(r'^\s*(?:export\s+)?LD_LIBRARY_PATH=', f.read_text(), re.M) and f.name not in ('98-busybox.conf', '99-pulseaudio.conf') for f in profiles), 'unreviewed profile loader writer'
    for installed, source in {
        '/usr/bin/raofflineproxy-ctl': 'projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-ctl',
        '/usr/bin/raofflineproxy-cache-indexed': 'projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-cache-indexed',
        '/usr/bin/raofflineproxy-cache-images': 'projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-cache-images',
        '/etc/profile.d/001-functions': 'projects/ROCKNIX/packages/rocknix/profile.d/001-functions',
        '/etc/profile': 'projects/ROCKNIX/packages/sysutils/busybox/config/profile',
    }.items():
        raw = subprocess.check_output(['git', '-C', str(a.distribution), 'show', commit + ':' + source], timeout=10)
        assert hashlib.sha256(raw).hexdigest() == files[installed]['sha256'], 'installed script/source mismatch'
    receipt = json.loads(a.source_receipt.read_text())
    assert receipt['status'] == 'PASS' and receipt['distribution_commit'] == commit
    assert receipt['pins'] == {name: pins[name] for name in ('raofflineproxy', 'rcheevos', 'libchdr')}
    assert receipt['es_source_commit'] == pins['emulationstation']
    assert receipt['post_strip_es_sha256'] == files['/usr/bin/emulationstation']['sha256']
    assert receipt['prepared_python_files'] == 112
    assert receipt['package_build_original_exit'] == receipt['python_compile_original_exit'] == 0
    assert receipt['reviewed_source_to_bytecode_and_strip_chain'] is True
    assert receipt['post_strip_rchash_sha256'] == files['/usr/lib/libraproxy_rchash.so']['sha256']
    assert receipt['evidence'] and all(re.fullmatch('[0-9a-f]{64}', r['sha256']) and r['bytes'] > 0 and r['path'] for r in receipt['evidence'])
    release = dict(line.split('=', 1) for line in resolve_image('/etc/os-release')[0].read_text().splitlines() if '=' in line)
    binding = {'schema': 'pix567-installed-1', 'runtime_run': False, 'distribution_commit': commit,
               'image_sha256': a.image_sha256, 'boot_id': a.boot_id, 'build_id': release['BUILD_ID'].strip('"'),
               'pins': pins, 'module_root': '/' + str(module.relative_to(root)), 'files': files,
               'profile_library_path': profile_library_path,
               'source_receipt': receipt, 'source_receipt_sha256': sha(a.source_receipt)}
    with a.output.open('x') as stream:
        stream.write(json.dumps(binding, indent=2) + '\n')
    print(json.dumps({'binding_sha256': sha(a.output), 'files': len(files), 'bytecode_files': len(pycs), 'runtime_run': False}))


if __name__ == '__main__':
    main()

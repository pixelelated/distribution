#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""UNRUN disposable-guest fixture. Fixed ES indexing and installed proxy preparation URLs; no upstream client."""
import argparse
import json
import os
from pathlib import Path
import signal
import socket
import ssl
from http.server import BaseHTTPRequestHandler, HTTPServer
import time
from urllib.parse import urlsplit, parse_qsl
from fixture_data import USER, TOKEN, NEW, NEW_HASH, payloads


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("root", type=Path)
    a = p.parse_args()
    root = a.root.resolve(strict=True)
    config = json.loads((root / "case.json").read_text())
    if socket.if_nameindex() != [(1, "lo")]:
        raise RuntimeError("loopback namespace required")
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(root / "cert.pem", root / "key.pem")
    counts = {"hashlibrary": 0, "officialgameslist": 0, "denied": 0,
              "connections": 0, "tls_errors": 0, "head": 0, "patch": 0, "unlocks": 0, "achievementsets": 0}

    def record():
        tmp = root / "tls-counts.tmp"
        tmp.write_text(json.dumps(counts) + "\n")
        tmp.replace(root / "tls-counts.json")

    def sni(sock, name, unused):
        if name != "retroachievements.org":
            return ssl.ALERT_DESCRIPTION_UNRECOGNIZED_NAME
    context.set_servername_callback(sni)

    class Handler(BaseHTTPRequestHandler):
        # HTTP/1.0 closes each connection; no uploads, cookies, redirects or proxy.
        protocol_version = "HTTP/1.0"

        def log_message(self, *unused):
            pass

        def permitted_headers(self):
            return (self.headers.get_all("Host") == ["retroachievements.org"] and
                    self.headers.get("Content-Length", "0") == "0" and
                    not self.headers.get("Transfer-Encoding"))

        def do_HEAD(self):
            if not self.permitted_headers() or self.path != "/":
                self.reject()
                return
            counts["head"] += 1
            record()
            if counts["head"] > 4:
                self.reject()
                return
            self.send_response(200)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def do_GET(self):
            parsed = urlsplit(self.path)
            pairs = parse_qsl(parsed.query, keep_blank_values=True)
            query = dict(pairs)
            category = query.get("r")
            index = category in ("hashlibrary", "officialgameslist") and query == {"r": category}
            expected = {"r": category, "u": USER, "t": TOKEN}
            if category == "patch":
                expected["g"] = str(NEW)
            elif category == "unlocks":
                expected.update(g=str(NEW), h="0")
            elif category == "achievementsets":
                expected["m"] = NEW_HASH
            else:
                expected = None
            authenticated = expected is not None and query == expected
            if (not self.permitted_headers() or parsed.path != "/dorequest.php" or
                    parsed.scheme or parsed.netloc or parsed.fragment or
                    len(query) != len(pairs) or not (index or authenticated)):
                self.reject()
                return
            counts[category] += 1
            record()
            if counts[category] > 4:
                self.reject()
                return
            if category == "hashlibrary":
                body = {"MD5List": {NEW_HASH: NEW}}
            elif category == "officialgameslist":
                body = {"Response": {str(NEW): "Library setup fixture"}}
            else:
                body = payloads(NEW, NEW_HASH)[category]
            data = json.dumps(body).encode("ascii")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def reject(self):
            counts["denied"] += 1
            record()
            # Never echo a request target, header or body, even on refusal.
            self.send_response(403)
            self.send_header("Content-Length", "0")
            self.end_headers()

        do_POST = do_PUT = do_CONNECT = do_DELETE = do_OPTIONS = reject

        def send_error(self, code, message=None, explain=None):
            # Covers malformed/unsupported HTTP without reflecting input bytes.
            self.reject()

    class Server(HTTPServer):
        allow_reuse_address = False

        def get_request(self):
            raw, address = self.socket.accept()
            counts["connections"] += 1
            raw.settimeout(3)
            record()
            try:
                return context.wrap_socket(raw, server_side=True), address
            except (ssl.SSLError, OSError):
                raw.close()
                counts["tls_errors"] += 1
                record()
                raise OSError("fixture TLS handshake refused") from None

        def handle_error(self, request, client_address):
            counts["denied"] += 1
            record()

    stop = False

    def finish(signum, frame):
        nonlocal stop
        stop = True
    signal.signal(signal.SIGTERM, finish)
    signal.signal(signal.SIGINT, finish)
    server = Server(("127.0.0.1", 443), Handler)
    server.timeout = 0.2
    record()
    ready = root / "tls-ready.pending"
    ready.write_text(json.dumps({"pid": os.getpid(), "port": 443}) + "\n")
    ready.replace(root / "tls-ready.json")
    deadline = time.monotonic() + 230
    try:
        while not stop and time.monotonic() < deadline and counts["connections"] < 32:
            server.handle_request()
    finally:
        server.server_close()
        record()
    return 0 if stop else 124


if __name__ == "__main__":
    raise SystemExit(main())

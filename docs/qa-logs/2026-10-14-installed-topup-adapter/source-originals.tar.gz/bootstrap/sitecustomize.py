"""UNRUN. Only the accepted no-NIC interface-presence seam; installed code stays real."""
import atexit
import json
import os
from pathlib import Path
import sys


def refuse(error):
    # The real ctl intentionally redirects probe stderr. Retain a bounded,
    # value-free fixture refusal beside the observers as well as original 126.
    try:
        root = Path(os.environ['PIX567_ROOT'])
        if root.parent == Path('/run') and root.name.startswith('pix567-') and (root / 'observers').is_dir():
            target = root / 'observers' / ('refused-' + str(os.getpid()) + '.json')
            target.write_text(json.dumps({'pid': os.getpid(), 'event': 'refused',
                                         'error_type': type(error).__name__, 'reason': str(error)[:512]}) + '\n')
    except BaseException:
        pass
    os.write(2, ('pix567 bootstrap refused: ' + repr(error)[:512] + '\n').encode())
    os._exit(126)


def install():
    from installed_contract import verify
    assert sys.flags.optimize == 0
    binding = verify(os.environ['PIX567_BINDING'], os.environ['PIX567_BINDING_SHA256'], include_frontend=False)
    state = Path('/storage/.config/raofflineproxy')
    root = Path(os.environ['PIX567_ROOT'])
    assert root.parent == Path('/run') and root.name.startswith('pix567-')
    st = Path('/storage').stat()
    assert f'{st.st_dev}:{st.st_ino}' == os.environ['PIX567_STORAGE_ID'], 'private storage missing'
    assert {p.name for p in Path('/sys/class/net').iterdir()} == {'lo'}, 'no-NIC guest required'
    # probe-online deliberately supplies a fresh private /tmp config directory.
    config_dir = Path(os.environ.get('RAOFFLINEPROXY_CONFIG_DIR', str(state)))
    assert config_dir == state or (config_dir.parent == Path('/tmp') and config_dir.name.startswith('raofflineproxy-probe.'))
    from raofflineproxy import network
    network.has_active_network_interface = lambda: True
    records = root / 'observers'
    assert records.is_dir()
    target = records / (str(os.getpid()) + '.json')
    # A PID can exec another Python command; preserve both records without overwrite.
    number = 0
    while target.exists():
        number += 1
        assert number <= 16
        target = records / (str(os.getpid()) + '-' + str(number) + '.json')

    def record(event):
        modules = {}
        for name, module in list(sys.modules.items()):
            path = getattr(module, '__file__', None)
            if name == '__main__' and path == str(Path(binding['module_root']) / 'main.pyc'):
                name = 'raofflineproxy.main'
            elif name != 'raofflineproxy' and not name.startswith('raofflineproxy.'):
                continue
            assert path and path.endswith('.pyc') and path in binding['files'], 'unbound executing proxy module'
            assert Path(path).resolve(strict=True).is_relative_to(binding['module_root'])
            modules[name] = path
        row = {'pid': os.getpid(), 'parent_pid': os.getppid(), 'role': Path(sys.argv[0]).name,
               'event': event, 'module_files': modules,
               'substitutions': ['loopback-interface-only'], 'binding_sha256': os.environ['PIX567_BINDING_SHA256']}
        raw = json.dumps(row, sort_keys=True) + '\n'
        assert len(raw) < 32768
        pending = target.with_suffix('.pending')
        pending.write_text(raw)
        pending.replace(target)

    record('started')

    def finish():
        try:
            record('exited')
        except BaseException as error:
            refuse(error)
    atexit.register(finish)


try:
    install()
except BaseException as error:
    # Python otherwise swallows sitecustomize exceptions and continues.
    refuse(error)

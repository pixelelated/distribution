"""Read-only final-image identity contract; never installs or overlays code."""
import hashlib
import json
import os
from pathlib import Path
import re


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify(path, expected, include_frontend=True):
    path = Path(path)
    assert re.fullmatch('[0-9a-f]{64}', expected) and sha(path) == expected, 'binding changed'
    b = json.loads(path.read_text())
    assert b['schema'] == 'pix567-installed-1'
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == b['boot_id'], 'wrong allocated boot'
    root = Path(b['module_root'])
    assert root.resolve(strict=True) == root
    assert str(root).startswith('/usr/lib/python') and str(root).endswith('/site-packages/raofflineproxy')
    children = list(root.rglob('*'))
    assert len(children) < 2048 and not any(p.is_symlink() for p in children)
    assert not list(root.rglob('*.py')), 'installed source overlay'
    actual = {str(p) for p in root.rglob('*.pyc')}
    assert actual == {p for p in b['files'] if p.endswith('.pyc')}, 'bytecode set changed'
    assert {str(p) for p in Path('/etc/profile.d').iterdir()} == {name for name in b['files'] if name.startswith('/etc/profile.d/')}, 'profile source set changed'
    mounts = [line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()]
    for name, row in b['files'].items():
        if not include_frontend and name == '/usr/bin/emulationstation':
            continue  # Owner checks the large ES binary before/after; Python children bind proxy code.
        f = Path(name)
        assert name.startswith(('/usr/', '/etc/')) and str(f.resolve(strict=True)) == row['resolved_path']
        assert f.stat().st_size == row['bytes'] and f.stat().st_mode & 0o7777 == row['mode']
        assert sha(f) == row['sha256'], 'installed bytes differ: ' + name
        assert not any(m not in ('/', '/usr', '/etc') and (name == m or name.startswith(m + '/')) for m in mounts), 'overlaid product path: ' + name
    assert os.environ.get('LD_LIBRARY_PATH', '') in ('', b['profile_library_path']), 'unbound loader search path'
    for name in ('LD_PRELOAD', 'PYTHONHOME', 'PYTHONOPTIMIZE'):
        assert not os.environ.get(name), 'loader override: ' + name
    return b

#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""UNRUN. Separate finite ES memfd allowance from capped native log storage."""
import hashlib
import json
import os
from pathlib import Path
import resource
import stat

FILE_CAP = 8 * 1024 * 1024
ES_CAP = 64 * 1024 * 1024
INODE_CAP = 64
ALLOWED = {"es.stdout", "es.stderr", "logs/es_log.txt",
           *(f"logs/es_log.{n}.txt" for n in range(4))}


def worker_limits():
    # Keep worker writes at 8 MiB; reserve a finite ceiling for the ES child.
    # This avoids needing CAP_SYS_RESOURCE to raise an already lowered hard cap.
    resource.setrlimit(resource.RLIMIT_FSIZE, (FILE_CAP, ES_CAP))


def helper_limits():
    resource.setrlimit(resource.RLIMIT_FSIZE, (FILE_CAP, FILE_CAP))


def es_limits():
    resource.setrlimit(resource.RLIMIT_FSIZE, (ES_CAP, ES_CAP))


def save(path, data):
    pending = path.with_suffix(".pending")
    pending.write_text(json.dumps(data, indent=2) + "\n")
    pending.replace(path)


class OutputGuard:
    def __init__(self, root, view=None):
        self.root = root
        self.view = view if view is not None else root / "es-output"
        self.device = None
        previous = root / "output-guard.json"
        self.fault = json.loads(previous.read_text()).get("failure") if previous.exists() else None

    def mount(self, command):
        self.view.mkdir(mode=0o700)  # new private path only
        command(self.root, "es-output-mount",
                ["mount", "-t", "tmpfs", "-o",
                 f"size={FILE_CAP},nr_inodes={INODE_CAP},mode=0700,nosuid,nodev,noexec",
                 "pix567-es-output", str(self.view)])
        rows = [line.split() for line in Path("/proc/self/mountinfo").read_text().splitlines()]
        matching = [row for row in rows if row[4] == str(self.view)]
        if len(matching) != 1 or matching[0][matching[0].index("-") + 1] != "tmpfs":
            raise RuntimeError("output guard mount identity missing")
        if not {"nosuid", "nodev", "noexec"} <= set(matching[0][5].split(",")):
            raise RuntimeError("output guard mount flags missing")
        self.device = self.view.stat().st_dev
        if self.device == self.root.stat().st_dev:
            raise RuntimeError("output guard did not establish a separate filesystem")
        (self.view / "logs").mkdir(mode=0o700)
        self.geometry()
        save(self.root / "output-guard-binding.json",
             {"device": self.device, "fsize_worker": list(resource.getrlimit(resource.RLIMIT_FSIZE)),
              "fsize_es": [ES_CAP, ES_CAP], "data_bytes": FILE_CAP, "inodes": INODE_CAP,
              "mountinfo": " ".join(matching[0]), "log_source": str(self.view / "logs")})
        self.capture()

    def geometry(self):
        info = os.statvfs(self.view)
        if info.f_blocks * info.f_frsize != FILE_CAP or info.f_files != INODE_CAP:
            raise RuntimeError("output guard finite filesystem geometry mismatch")
        if self.device is None:
            self.device = json.loads((self.root / "output-guard-binding.json").read_text())["device"]
        if self.view.stat().st_dev != self.device:
            raise RuntimeError("output guard filesystem identity changed")
        return info

    def capture(self):
        # The live tmpfs has an 8 MiB allocation cap. Independently refuse a
        # sparse logical file/total >8 MiB; never copy unbounded or follow links.
        # Preserve bounded bytes before reporting quota exhaustion.
        report = {"passed": False, "files": [], "copied_bytes": 0}
        try:
            fs = self.geometry()
            report.update(allocated_bytes=(fs.f_blocks-fs.f_bfree)*fs.f_frsize,
                          available_bytes=fs.f_bavail*fs.f_frsize, free_inodes=fs.f_favail)
            paths = [self.view / n for n in ("es.stdout", "es.stderr")]
            logdir = self.view / "logs"
            if not stat.S_ISDIR(logdir.lstat().st_mode) or logdir.stat().st_dev != self.device:
                raise RuntimeError("output log directory changed")
            paths += sorted(logdir.iterdir())
            allowed_top = {"logs", "es.stdout", "es.stderr"}
            if any(f.name not in allowed_top for f in self.view.iterdir()):
                raise RuntimeError("unexpected output entry")
            total = 0
            captured = []
            for source in paths:
                if not os.path.lexists(source):
                    continue
                relative = str(source.relative_to(self.view))
                if relative not in ALLOWED:
                    raise RuntimeError("unexpected output log name")
                fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
                try:
                    before = os.fstat(fd)
                    if not stat.S_ISREG(before.st_mode) or before.st_dev != self.device:
                        raise RuntimeError("output file type/device changed")
                    if before.st_size > FILE_CAP-total:
                        raise RuntimeError("output logical-byte cap exceeded")
                    chunks, count = [], 0
                    while True:
                        data = os.read(fd, min(65536, FILE_CAP-total-count+1))
                        if not data:
                            break
                        if total+count+len(data) > FILE_CAP:
                            raise RuntimeError("output changed past logical-byte cap")
                        chunks.append(data)
                        count += len(data)
                    captured.append((relative, b"".join(chunks)))
                    total += count
                finally:
                    os.close(fd)
            # Only after collecting a complete bounded snapshot, retire the
            # exact mirror/temp names this guard owns. This keeps total mirror
            # bytes <=8 MiB even when native rotation changes file names/sizes.
            for relative in ALLOWED:
                target = self.root / relative
                for owned in (target, target.with_name(target.name + ".capture")):
                    if os.path.lexists(owned):
                        if not stat.S_ISREG(owned.lstat().st_mode):
                            raise RuntimeError("output mirror identity changed")
                        owned.unlink()
            for relative, data in captured:
                target = self.root / relative
                target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                pending = target.with_name(target.name + ".capture")
                pending.write_bytes(data)
                pending.replace(target)
                report["files"].append({"name": relative, "bytes": len(data),
                                        "sha256": hashlib.sha256(data).hexdigest()})
                report["copied_bytes"] += len(data)
            if fs.f_bavail == 0 or fs.f_favail == 0:
                raise RuntimeError("output storage quota exhausted")
            if self.fault is not None:
                raise RuntimeError(self.fault)
            report["passed"] = True
        except Exception as exc:
            self.fault = str(exc)
            report["failure"] = self.fault
            raise
        finally:
            save(self.root / "output-guard.json", report)


def retain_view(root, worker_pid):
    # A live directory FD retains this private tmpfs through group termination.
    # worker_pid is our unreaped Popen child, so it cannot be reused here.
    path = Path(f"/proc/{worker_pid}/root") / str(root / "es-output").lstrip("/")
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        OutputGuard(root, Path(f"/proc/self/fd/{fd}")).geometry()
    except BaseException:
        os.close(fd)
        raise
    return fd


def capture_retained(root, fd):
    try:
        OutputGuard(root, Path(f"/proc/self/fd/{fd}")).capture()
    finally:
        os.close(fd)

"""UNRUN custody for the installed ctl's two fixed /run lock files only."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat

PATHS = (Path('/var/run/raofflineproxy-scan.lock'), Path('/var/run/raofflineproxy-index-pending.lock'))
HELD = []


def state(path):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    assert stat.S_ISREG(info.st_mode) and info.st_size <= 4096, 'unexpected ctl lock target'
    return {'device': info.st_dev, 'inode': info.st_ino, 'mode': stat.S_IMODE(info.st_mode),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': info.st_size}


def census():
    return {str(path): state(path) for path in PATHS}


def acquire(root):
    assert not HELD
    before = census()
    try:
        for path in PATHS:
            assert path.parent.resolve(strict=True) == Path('/run'), 'unexpected /var/run mapping'
            created = False
            try:
                fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
                created = True
            except FileExistsError:
                fd = os.open(path, os.O_RDWR | os.O_CLOEXEC | os.O_NOFOLLOW)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                current = state(path)
                info = os.fstat(fd)
                assert (info.st_dev, info.st_ino) == (current['device'], current['inode'])
                assert created or current == before[str(path)], 'ctl lock changed before custody'
                HELD.append({'path': path, 'fd': fd, 'created': created, 'state': current})
            except BaseException:
                owned = os.fstat(fd)
                current = state(path)
                # A newly created target is removed only while its FD identity
                # still matches and no process has written a byte.
                if created and current is not None and (current['device'], current['inode'], current['bytes']) == (owned.st_dev, owned.st_ino, 0):
                    path.unlink()
                os.close(fd)
                raise
    except BaseException:
        release(root)
        raise
    (root / 'lock-custody-before.json').write_text(json.dumps(before, indent=2) + '\n')


def release(root):
    if not HELD:
        return
    checks = []
    errors = []
    for item in reversed(HELD):
        path, fd = item['path'], item['fd']
        try:
            same = state(path) == item['state']
            if not same:
                raise RuntimeError('ctl lock target changed; preserved: ' + str(path))
            if item['created']:
                path.unlink()
            checks.append({'path': str(path), 'original_unchanged': True, 'created_target_removed': item['created']})
        except BaseException as error:
            errors.append(str(error))
        finally:
            os.close(fd)
    HELD.clear()
    (root / 'lock-custody-result.json').write_text(json.dumps({'passed': not errors, 'checks': checks, 'errors': errors}, indent=2) + '\n')
    if errors:
        raise RuntimeError('; '.join(errors))

"""Synthetic local metadata, no real ROM, account or provider credential."""
USER = 'pix567-synthetic'
TOKEN = '<pix567-local-only-not-a-provider-token>'
OLD = 4242002
NEW = 4242001
OLD_HASH = '2' * 32
NEW_HASH = '1' * 32


def payloads(game, hash_value):
    return {
        'patch': {'Success': True, 'PatchData': {'ID': game, 'Title': 'Synthetic setup fixture', 'ConsoleID': 4, 'Achievements': [], 'Leaderboards': []}},
        'unlocks': {'Success': True, 'UserUnlocks': []},
        'achievementsets': {'Success': True, 'GameId': game, 'Title': 'Synthetic setup fixture', 'Sets': []},
        'gameid': {'GameID': game},
        'startsession': {'Success': True, 'ServerNow': 1, 'HardcoreUnlocks': [], 'Unlocks': []},
    }

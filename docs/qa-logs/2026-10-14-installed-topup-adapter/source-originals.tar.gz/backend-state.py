#!/usr/bin/env python3
"""UNRUN. Seed one old synthetic game or assert the installed top-up's actual state."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import time

from fixture_data import USER, TOKEN, OLD, NEW, OLD_HASH, NEW_HASH, payloads

STATE = Path('/storage/.config/raofflineproxy')


def rows():
    with sqlite3.connect('file:' + str(STATE / 'proxy.sqlite3') + '?mode=ro', uri=True, timeout=1) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert db.execute('SELECT count(*) FROM pending_awards').fetchone()[0] == 0
        return {key: {'body': json.loads(body), 'path': path} for key, body, path in
                db.execute('SELECT cacheKey,responseBody,sourceRomPath FROM api_cache')}


def keys(game, hash_value):
    return {'patch': f'patch:{game}:{USER}', 'unlocks': f'unlocks:{game}:{USER}:0',
            'achievementsets': f'achievementsets:{hash_value}:{USER}',
            'gameid': 'gameid:' + hash_value, 'startsession': f'startsession:{game}:{USER}:0'}


def old_digest(data):
    selected = {kind: data[key] for kind, key in keys(OLD, OLD_HASH).items()}
    return hashlib.sha256(json.dumps(selected, sort_keys=True).encode()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['seed', 'assert'])
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    seed = a.root / 'backend-before.json'
    if a.action == 'seed':
        assert not (STATE / 'proxy.sqlite3').exists() and not seed.exists()
        from raofflineproxy import cache_keys, es_export
        from raofflineproxy.storage import Storage
        from raofflineproxy.config import CONFIG_DIR, DATABASE_FILE
        assert CONFIG_DIR == STATE and DATABASE_FILE == STATE / 'proxy.sqlite3'
        store = Storage()
        try:
            assert store.backend == 'sqlite'
            values = payloads(OLD, OLD_HASH)
            expected = keys(OLD, OLD_HASH)
            assert expected == {'patch': cache_keys.patch(OLD, USER), 'unlocks': cache_keys.unlocks(OLD, USER),
                                'achievementsets': cache_keys.achievementsets(OLD_HASH, USER),
                                'gameid': cache_keys.game_id(OLD_HASH), 'startsession': cache_keys.start_session(OLD, USER)}
            for kind, key in expected.items():
                store.upsert_cache(key, json.dumps(values[kind], separators=(',', ':')),
                                   source_rom_path='/storage/roms/gb/existing.gb' if kind == 'patch' else None)
            store.upsert_cache(cache_keys.login(USER), json.dumps({'Success': True, 'User': USER, 'Token': TOKEN}))
            es_export.export_cached_game_ids(store)
        finally:
            store.close()
        data = rows()
        assert not any(key in data for key in keys(NEW, NEW_HASH).values())
        assert (STATE / 'cached_game_ids.txt').read_text() == str(OLD) + '\n'
        assert not (STATE / 'last-scan').exists()
        seed.write_text(json.dumps({'ready': 1, 'new_rows_absent': True, 'old_rows_sha256': old_digest(data), 'epoch': int(time.time())}, indent=2) + '\n')
        print('{"seeded_old_games":1,"new_game_rows":0}')
        return
    before = json.loads(seed.read_text())
    data = rows()
    assert old_digest(data) == before['old_rows_sha256'], 'existing game data changed'
    target = {kind: data[key] for kind, key in keys(NEW, NEW_HASH).items()}
    assert target['gameid']['body']['GameID'] == NEW
    assert target['patch']['body']['Success'] is True and target['patch']['body']['PatchData']['ID'] == NEW
    assert target['patch']['path'] == '/storage/roms/gb/new.gb'
    assert target['unlocks']['body']['Success'] is True and target['unlocks']['body']['UserUnlocks'] == []
    assert target['achievementsets']['body']['Success'] is True and target['achievementsets']['body']['GameId'] == NEW
    assert target['startsession']['body']['Success'] is True and target['startsession']['body']['Unlocks'] == []
    assert {int(x) for x in (STATE / 'cached_game_ids.txt').read_text().splitlines()} == {OLD, NEW}
    fields = (STATE / 'last-scan').read_text().split()
    assert len(fields) == 10 and before['epoch'] <= int(fields[0]) <= int(time.time())
    assert fields[1:3] == ['0', 'topup']
    expected = {'cached': '1', 'skipped': '0', 'ready': '2', 'limit': '0', 'indexed': '1', 'errors': '0', 'added': '1'}
    actual = dict(item.split('=', 1) for item in fields[3:])
    assert len(actual) == len(fields[3:]) and actual == expected, 'real stamp fields differ'
    assert not (STATE / 'running').exists() and not (STATE / 'index-pending').exists()
    scan = (STATE / 'scan.log').read_text()
    assert scan.count('hash reused, not hashed; asked patch,unlocks,achievementsets') == 1
    assert 'topup indexed pass: cached=1 indexed=1 skipped=0 errors=0 rc=0' in scan
    assert 'topup recently played: rc=0 cached=0 skipped=0 limit=0' in scan
    assert 'topup: image pass rc=0' in scan
    result = {'passed': True, 'sqlite_integrity': 'ok', 'new_cache_key_categories': sorted(target),
              'old_game_unchanged': True, 'ready_before': 1, 'ready_after': 2,
              'stamp': {'rc': 0, 'route': 'topup', **expected}, 'pending_awards': 0}
    (a.root / 'backend-after.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

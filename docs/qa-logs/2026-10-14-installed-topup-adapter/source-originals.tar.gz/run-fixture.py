#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""UNRUN. One bounded #567 case inside an already allocated disposable VM.

No service management, host launcher, installation or external network fallback.
The coordinator must stop the frontend and supply a live Wayland socket first.
"""
import argparse
import importlib.util
import errno
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import socket
import ssl
import stat
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ES = Path("/usr/bin/emulationstation")
CTL = Path("/usr/bin/raofflineproxy-ctl")
HOST_FILES = [Path(p) for p in ("/etc/hosts", "/etc/resolv.conf", "/etc/nsswitch.conf")]
CA = Path("/run/rocknix/cacert.pem")
STUB = "Synthetic metadata-only fixture. NOT A ROM. Never launch.\n"
LIMIT = 240

# Explicit sibling loading also works under the coordinator's python -I -S -B.
_guard_spec = importlib.util.spec_from_file_location("pix567_output_guard", HERE / "output_guard.py")
guard = importlib.util.module_from_spec(_guard_spec)
_guard_spec.loader.exec_module(guard)
OUTPUT_GUARD = None
LOCK_ROOT = None


def sibling(name, path):
    spec = importlib.util.spec_from_file_location(name, HERE / path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


locks = sibling("pix567_locks", "lock-custody.py")
contract = sibling("pix567_contract", "bootstrap/installed_contract.py")
data = sibling("pix567_data", "fixture_data.py")


def save(path, data):
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n")
    tmp.replace(path)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check(ok, message):
    if not ok:
        raise RuntimeError(message)


def census(binding):
    # Public hosts/trust, installed code and mount identity only; no user config.
    return {"files": {str(p): digest(p) for p in HOST_FILES + [CA, ES, CTL]},
            "storage": [os.stat("/storage").st_dev, os.stat("/storage").st_ino],
            "mountinfo": digest(Path("/proc/self/mountinfo")), "locks": locks.census(),
            "installed_files": {name: digest(Path(name)) for name in binding["files"]},
            "journal_scope": "bounded synthetic ctl messages are expected; no journal identity claim"}


def clean_env(a):
    # Allowlist, not a copy: no proxy variables, account data, preload or TLS keys.
    return {"PATH": "/usr/bin:/usr/sbin:/bin:/sbin", "HOME": "/storage",
            "LANG": a.language + ".UTF-8", "LC_ALL": a.language + ".UTF-8",
            "XDG_RUNTIME_DIR": a.xdg_runtime_dir,
            "WAYLAND_DISPLAY": a.wayland_display, "SDL_VIDEODRIVER": "wayland",
            "PIX567_ROOT": str(a.output), "PYTHONDONTWRITEBYTECODE": "1",
            "NO_PROXY": "*", "no_proxy": "*"}


def proxy_env(a):
    env = clean_env(a)
    st = Path('/storage').stat()
    env.update(PYTHONPATH=str(HERE / 'bootstrap'), PIX567_BINDING=str(a.installed_binding),
               PIX567_BINDING_SHA256=a.binding_sha256, PIX567_STORAGE_ID=f'{st.st_dev}:{st.st_ino}',
               RAOFFLINEPROXY_CONFIG_DIR='/storage/.config/raofflineproxy',
               RAOFFLINEPROXY_CA_FILE=str(a.output / 'cert.pem'))
    return env


def command(root, label, argv, env=None):
    with (root / (label + ".stdout")).open("wb") as out, (root / (label + ".stderr")).open("wb") as err:
        proc = subprocess.Popen(argv, env=env, stdout=out, stderr=err, preexec_fn=guard.helper_limits)
        try:
            code = proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
            code = proc.wait()
            save(root / (label + ".exit.json"), {"exit": code, "timeout": True})
            raise RuntimeError(label + " timed out") from None
    save(root / (label + ".exit.json"), {"exit": code, "timeout": False})
    check(code == 0, label + " failed; original exit retained")


def pidfile(root, name, proc):
    # /proc stat's comm can contain spaces; field 22 follows its closing ')'.
    start = Path(f"/proc/{proc.pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
    save(root / (name + ".pid.json"), {"pid": proc.pid, "start_ticks": start})


def backend_bounds(root):
    for folder, limit, count in [(root / 'storage/.config/raofflineproxy', 8 * 1024 * 1024, 512),
                                 (root / 'observers', 4 * 1024 * 1024, 128)]:
        if not folder.exists():
            continue
        files = list(folder.rglob('*'))
        check(len(files) <= count and not any(p.is_symlink() for p in files), 'synthetic backend output shape exceeded')
        sizes = []
        for path in files:
            try:
                info = path.stat()
            except FileNotFoundError:  # Atomic observer/stamp rename during sampling.
                continue
            if stat.S_ISREG(info.st_mode):
                sizes.append(info.st_size)
        check(sum(sizes) <= limit and all(size <= 4 * 1024 * 1024 for size in sizes), 'synthetic backend output bound exceeded')


def wait_for(predicate, seconds, description, children=()):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if OUTPUT_GUARD is not None:
            OUTPUT_GUARD.capture()
            backend_bounds(OUTPUT_GUARD.root)
        for proc in children:
            check(proc.poll() is None, description + ": child exited early")
        if predicate():
            return
        time.sleep(0.1)
    raise RuntimeError(description + " timed out")


def api(path):
    conn = http.client.HTTPConnection("127.0.0.1", 1234, timeout=2)
    try:
        conn.request("GET", path)
        response = conn.getresponse()
        body = response.read(65536)
        check(response.status == 200, "ES API refused " + path)
        return body
    finally:
        conn.close()


def idle():
    try:
        return json.loads(api("/isIdle")) == [True]
    except (OSError, http.client.HTTPException, ValueError):
        return False


def tls_controls(root):
    context = ssl.create_default_context(cafile=str(root / "cert.pem"))

    def request(path, host="retroachievements.org"):
        # Resolves through the actual private hosts bind; TLS checks the DNS name.
        conn = http.client.HTTPSConnection("retroachievements.org", 443, context=context, timeout=4)
        try:
            conn.request("GET", path, headers={"Host": host})
            reply = conn.getresponse()
            body = reply.read(8192)
            return reply.status, body
        finally:
            conn.close()

    status, body = request("/dorequest.php?r=officialgameslist")
    check(status == 200 and "4242001" in json.loads(body)["Response"], "local TLS readiness failed")
    check(request("/dorequest.php?r=login")[0] == 403, "unknown endpoint not refused")
    check(request("/dorequest.php?r=hashlibrary", "other.invalid")[0] == 403, "wrong Host not refused")
    try:
        with socket.create_connection(("127.0.0.1", 443), timeout=4) as raw:
            with context.wrap_socket(raw, server_hostname="other.invalid"):
                pass
    except ssl.SSLError:
        pass
    else:
        raise RuntimeError("wrong TLS name accepted")
    try:
        socket.getaddrinfo("other.invalid", 443)
    except socket.gaierror as error:
        dns_errno = error.errno
    else:
        raise RuntimeError("unknown DNS name unexpectedly resolved")
    # TEST-NET, only after loopback-only namespace verification. No public probe.
    with socket.socket() as probe:
        probe.settimeout(1)
        blocked = probe.connect_ex(("203.0.113.1", 443))
    check(blocked in (errno.ENETUNREACH, errno.EHOSTUNREACH), "non-loopback route exists")
    wait_for(lambda: json.loads((root / "tls-counts.json").read_text())["tls_errors"] == 1,
             4, "TLS refusal receipt")
    baseline = json.loads((root / "tls-counts.json").read_text())
    check(baseline == {"hashlibrary": 0, "officialgameslist": 1, "denied": 2,
                       "connections": 4, "tls_errors": 1, "head": 0, "patch": 0,
                       "unlocks": 0, "achievementsets": 0}, "TLS controls count mismatch")
    save(root / "tls-controls.json", {"baseline": baseline, "unknown_dns_errno": dns_errno,
                                       "non_loopback_connect_errno": blocked})
    return baseline


def prepare_storage(root, a):
    storage = root / "storage"
    es = storage / ".config/emulationstation"
    for p in [es, storage / ".config/system/configs", storage / ".config/raofflineproxy",
              storage / ".cache", storage / "roms/gb"]:
        p.mkdir(parents=True, exist_ok=True)
    (storage / ".emulationstation").symlink_to(".config/emulationstation")
    (storage / ".config/locale").symlink_to("/usr/config/locale")
    (es / "resources").symlink_to("/usr/config/emulationstation/resources")
    (es / "locale").symlink_to("/usr/config/locale")
    (es / "themes").symlink_to("/usr/share/themes")
    for name in ["es_systems.cfg", "es_features.cfg"]:
        shutil.copyfile(HERE / "fixtures" / name, es / name)
    (es / "es_settings.cfg").write_text(
        '<config>\n<bool name="CheevosCheckIndexesAtStart" value="true"/>\n'
        '<bool name="NetPlayCheckIndexesAtStart" value="false"/>\n'
        '<bool name="SaveGamelistsOnExit" value="true"/>\n'
        '<bool name="PublicWebAccess" value="false"/>\n'
        '<bool name="IgnoreGamelist" value="false"/>\n'
        '<bool name="ParseGamelistOnly" value="false"/>\n'
        '<string name="LogLevel" value="information"/>\n'
        '<string name="CheevosLookupOnlyLast" value="0"/>\n'
        '<string name="CollectionSystemsAuto" value=""/>\n'
        '<string name="ThemeSet" value="es-theme-art-book-next"/>\n'
        '<int name="ScreenSaverTime" value="0"/>\n'
        f'<string name="Language" value="{a.language}"/>\n</config>\n')
    (storage / ".config/system/configs/system.cfg").write_text(
        "global.retroachievements=0\nglobal.retroachievements.offlineproxy=1\n"
        "global.netplay=0\ncloudsaves.startup=0\ncloudsaves.gameexit=0\n"
        f"audio.bgmusic=0\nsystem.language={a.language}\n"
        f"global.retroachievements.username={data.USER}\nglobal.retroachievements.token={data.TOKEN}\n")
    # Real installed modules will create the old game's SQLite rows and export.
    (storage / '.config/raofflineproxy/config.json').write_text(json.dumps({
        'upstream_host': 'https://retroachievements.org',
        'retroarch_cfg': '/storage/.config/retroarch/retroarch.cfg',
        'rocknix_system_cfg': '/storage/.config/system/configs/system.cfg'}))
    (storage / '.config/retroarch').mkdir()
    (storage / '.config/retroarch/retroarch.cfg').write_text('content_history_path = "/storage/.config/retroarch/content_history.lpl"\n')
    (storage / '.config/retroarch/content_history.lpl').write_text('{"items":[]}\n')
    (storage / "roms/gb/existing.gb").write_text(STUB)
    shutil.copyfile(HERE / "fixtures/base.gamelist.xml", storage / "roms/gb/gamelist.xml")
    return storage


def observe(root):
    return json.loads((root / "tls-counts.json").read_text())


def observers(root):
    files = sorted((root / 'observers').glob('*.json'))
    check(4 <= len(files) <= 128, 'missing/unbounded installed Python receipts')
    records = [json.loads(path.read_text()) for path in files]
    check(all(row['event'] == 'exited' and row['substitutions'] == ['loopback-interface-only'] for row in records),
          'installed Python observer did not finish')
    modules = {name for row in records for name in row['module_files']}
    check({'raofflineproxy.main', 'raofflineproxy.rom_cache', 'raofflineproxy.storage'} <= modules,
          'required installed preparation modules not observed')
    roles = {row['role'] for row in records}
    check({'main.pyc', 'raofflineproxy-cache-indexed', 'raofflineproxy-cache-images'} <= roles,
          'actual installed helper execution receipts missing')
    return {'process_receipts': len(records), 'module_names': sorted(modules), 'roles': sorted(roles), 'all_exited': True}


def worker(a):
    global OUTPUT_GUARD
    root = a.output
    guard.worker_limits()
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    os.umask(0o077)
    os.unshare(os.CLONE_NEWNS | os.CLONE_NEWNET)
    save(root / "namespaces.json", {kind: os.readlink("/proc/self/ns/" + kind) for kind in ["mnt", "net"]})
    command(root, "private-mounts", ["mount", "--make-rprivate", "/"])
    command(root, "loopback-up", ["ip", "link", "set", "lo", "up"])
    check(socket.if_nameindex() == [(1, "lo")], "namespace is not loopback only")
    command(root, "ipv4-routes", ["ip", "-4", "route", "show", "table", "all"])
    command(root, "ipv6-routes", ["ip", "-6", "route", "show", "table", "all"])
    storage = prepare_storage(root, a)
    (root / "hosts").write_text("127.0.0.1 localhost retroachievements.org\n::1 localhost\n")
    (root / "resolv.conf").write_text("nameserver 127.0.0.1\noptions attempts:1 timeout:1\n")
    (root / "nsswitch.conf").write_text("passwd: files\ngroup: files\nhosts: files\n")
    bindings = [(storage, Path("/storage"))] + list(zip(
        [root / "hosts", root / "resolv.conf", root / "nsswitch.conf"], HOST_FILES))
    (root / 'locks').mkdir()
    for target in locks.PATHS:
        private = root / 'locks' / target.name
        private.write_text('')
        bindings.append((private, target))
    for i, (source, target) in enumerate(bindings):
        check(target.exists(), "missing bind target " + str(target))
        command(root, "bind-" + str(i), ["mount", "--bind", str(source), str(target)])
    # /proc mountinfo, never mountpoint -q for file mounts. Read-back hashes also
    # catch symlinks into /storage that a storage bind might otherwise hide.
    (root / "private-mountinfo.txt").write_text(Path("/proc/self/mountinfo").read_text())
    for source, target in bindings[1:]:
        check(digest(source) == digest(target), "bind content mismatch: " + str(target))
    os.chdir('/storage')  # Python -c and profile helpers must inherit the private cwd.
    command(root, 'private-scratch', ['mount', '-t', 'tmpfs', '-o',
            'size=16777216,nr_inodes=128,mode=1777,nosuid,nodev,noexec', 'pix567-scratch', '/tmp'])
    scratch = os.statvfs('/tmp')
    check(scratch.f_blocks * scratch.f_frsize == 16777216 and scratch.f_files == 128, 'private scratch geometry differs')
    (root / 'observers').mkdir()
    save(root / 'scratch-custody.json', {'private_tmp': True, 'bytes': 16777216, 'inodes': 128,
                                      'private_locks': [str(p) for p in locks.PATHS], 'original_locks_held_by_parent': True})
    command(root, 'seed-backend', [sys.executable, str(HERE / 'backend-state.py'), 'seed', '--root', str(root)], env=proxy_env(a))
    (root / "openssl.cnf").write_text(
        "[req]\nprompt=no\ndistinguished_name=dn\nx509_extensions=ext\n"
        "[dn]\nCN=retroachievements.org\n[ext]\nsubjectAltName=DNS:retroachievements.org\n"
        "basicConstraints=critical,CA:TRUE\nkeyUsage=critical,keyCertSign,digitalSignature,keyEncipherment\n"
        "subjectKeyIdentifier=hash\nauthorityKeyIdentifier=keyid:always\n")
    command(root, "certificate", ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
                                  "-config", str(root / "openssl.cnf"), "-keyout", str(root / "key.pem"),
                                  "-out", str(root / "cert.pem")])
    (root / "logs").mkdir()
    listener = es = None
    result = {"case": a.case, "trigger": a.trigger, "passed": False, "scope": "installed ES index to installed ctl/Python preparation; synthetic loopback provider"}
    try:
        OUTPUT_GUARD = guard.OutputGuard(root)
        OUTPUT_GUARD.mount(command)
        # Paths.cpp reads log= from this private INI, after ROCKNIX defaults.
        # Its executable-directory INI has priority; never silently use it.
        check(not os.path.lexists(ES.parent / "emulationstation.ini"),
              "executable-directory emulationstation.ini would shadow private log routing")
        log_ini = storage / ".config/emulationstation/emulationstation.ini"
        log_ini.write_text("log=" + str(OUTPUT_GUARD.view / "logs") + "\n")
        save(root / "log-config.json", {"ini": str(log_ini), "ini_sha256": digest(log_ini),
              "requested_directory": str(OUTPUT_GUARD.view / "logs"),
              "requested_level": "information", "executable_ini_absent": True})
        with (root / "tls.stdout").open("wb") as out, (root / "tls.stderr").open("wb") as err:
            listener = subprocess.Popen([sys.executable, str(HERE / "tls-endpoints.py"), str(root)], stdout=out, stderr=err, preexec_fn=guard.helper_limits)
        pidfile(root, "listener", listener)
        wait_for(lambda: (root / "tls-ready.json").exists(), 8, "listener readiness", [listener])
        baseline = tls_controls(root)
        with (OUTPUT_GUARD.view / "es.stdout").open("wb") as out, (OUTPUT_GUARD.view / "es.stderr").open("wb") as err:
            es = subprocess.Popen([str(ES), "--no-splash"],
                                  cwd="/storage", env=proxy_env(a), stdout=out, stderr=err, preexec_fn=guard.es_limits)
        pidfile(root, "es", es)
        check(resource.prlimit(es.pid, resource.RLIMIT_FSIZE) == (guard.ES_CAP, guard.ES_CAP),
              "ES finite FSIZE readback mismatch")
        log = root / "logs/es_log.txt"
        load_line = "Loading system config file /storage/.config/emulationstation/es_systems.cfg"
        # /isIdle does not flush the async logger; capture must also reach the
        # startup line within the original single 40-second readiness budget.
        wait_for(lambda: idle() and log.exists() and load_line in log.read_text(),
                 40, "ES API and captured startup log readiness", [es, listener])
        check(log.exists(), "missing ES log")
        initial_loads = log.read_text().count(load_line)
        check(initial_loads == 1, "unexpected initial library load count")
        check(observe(root) == baseline, "startup consumed the stimulus")
        (storage / "roms/gb/new.gb").write_text(STUB)
        shutil.copyfile(HERE / "fixtures/new.gamelist.xml", storage / "roms/gb/gamelist.xml")
        save(root / 'armed.json', {'ready': True, 'es_pid': es.pid, 'trigger': 'api', 'installed_ctl': True})
        api('/reloadgames')
        wait_for(lambda: log.read_text().count(load_line) >= initial_loads + 1, 40,
                 'actual library rescan', [es, listener])
        exit_pattern = r'OfflineAchievements: topup --after-index exited (\d+)'
        wait_for(lambda: bool(re.findall(exit_pattern, log.read_text())), 120,
                 'ES-observed installed top-up exit', [es, listener])
        check(re.findall(exit_pattern, log.read_text()) == ['0'], 'actual installed top-up failed or repeated')
        wait_for(idle, 15, 'ES idle after installed preparation', [es, listener])
        time.sleep(3)
        OUTPUT_GUARD.capture()
        tls = observe(root)
        delta = {key: tls[key] - baseline[key] for key in tls}
        check(delta == {'hashlibrary': 1, 'officialgameslist': 1, 'denied': 0, 'connections': 7,
                        'tls_errors': 0, 'head': 2, 'patch': 1, 'unlocks': 1, 'achievementsets': 1},
              'actual preparation endpoint counts differ')
        recovery = storage / '.config/emulationstation/recovery/gb/new.xml'
        check(recovery.exists() and ET.parse(recovery).findtext('.//cheevosId') == '4242001',
              'new game recovery ID differs')
        shutil.copyfile(recovery, root / 'indexed-new.xml')
        command(root, 'assert-backend', [sys.executable, str(HERE / 'backend-state.py'), 'assert', '--root', str(root)], env=proxy_env(a))
        backend = json.loads((root / 'backend-after.json').read_text())
        check(backend['passed'], 'real backend assertion missing')
        observer_result = {'pending_until_normal_ES_exit': True}
        backend_bounds(root)
        expected_loads = initial_loads + 1
        check(log.read_text().count(load_line) == expected_loads, 'extra/missing library reload')
        for game in (storage / 'roms/gb').glob('*.gb'):
            check(game.read_text() == STUB, 'synthetic game stub changed')
        result.update({'passed': True, 'endpoint_delta': delta, 'identified': 1,
                       'topup_exits': [0], 'actual_added_games': 1,
                       'library_loads': expected_loads, 'installed_observers': observer_result,
                       'backend': backend})
        save(root / 'observed.json', result)
    except Exception as error:
        result.update({"passed": False, "failure": str(error)})
    finally:
        if es is not None:
            forced = False
            if es.poll() is None:
                try:
                    api("/quit")
                    es.wait(timeout=12)
                except (OSError, RuntimeError, http.client.HTTPException, subprocess.TimeoutExpired):
                    forced = True
                    es.kill()
                    es.wait()
            result["es_exit"] = es.returncode
            result["es_forced"] = forced
            result["passed"] &= es.returncode == 0 and not forced
        if listener is not None:
            if listener.poll() is None:
                listener.terminate()
                try:
                    listener.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    listener.kill()
                    listener.wait()
            result["listener_exit"] = listener.returncode
            result["passed"] &= listener.returncode == 0
        try:
            if OUTPUT_GUARD is not None:
                OUTPUT_GUARD.capture()
            result["output_guard_passed"] = OUTPUT_GUARD is not None and OUTPUT_GUARD.fault is None
            result["passed"] &= result["output_guard_passed"]
        except Exception as error:
            result.update({"passed": False, "output_guard_passed": False, "output_guard_failure": str(error)})
        if result['passed']:
            try:
                result['passed'] &= observe(root) == tls
                result['passed'] &= re.findall(exit_pattern, log.read_text()) == ['0']
                result['installed_observers'] = observers(root)
                result['passed'] &= result['installed_observers']['all_exited']
                contract.verify(a.installed_binding, a.binding_sha256)
            except Exception as error:
                result.update(passed=False, final_identity_failure=str(error))
        # Ephemeral private key is never an evidence artifact.
        (root / "key.pem").unlink(missing_ok=True)
        save(root / "worker-result.json", result)
    return 0 if result["passed"] else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--case", choices=["success"], default="success")
    p.add_argument('--installed-binding', required=True, type=Path)
    p.add_argument('--binding-sha256', required=True)
    p.add_argument("--output", required=True, type=Path)
    p.add_argument("--expected-build")
    p.add_argument("--expected-es-sha256")
    p.add_argument("--es-source-commit")
    p.add_argument("--xdg-runtime-dir", required=True)
    p.add_argument("--wayland-display", required=True)
    p.add_argument("--language", choices=["en_US"], default="en_US")
    p.add_argument("--trigger", choices=["api"], default="api")
    p.add_argument("--disposable-guest", action="store_true", required=True)
    p.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    a = p.parse_args()
    check(os.geteuid() == 0, "disposable guest root required")
    check(a.output.parent.resolve() == Path('/run') and re.fullmatch(r'pix567-[a-zA-Z0-9_-]+', a.output.name),
          'output must be a new /run/pix567-NAME directory (private /tmp hides other outputs)')
    check(HERE == Path('/run/pix567-installed-packet'), 'stage sealed packet at /run/pix567-installed-packet')
    a.installed_binding = a.installed_binding.resolve(strict=True)
    check(a.installed_binding.is_relative_to('/run') and not a.installed_binding.is_relative_to(a.output), 'binding must be outside fresh output under /run')
    binding = contract.verify(a.installed_binding, a.binding_sha256)
    a.expected_build = a.expected_build or binding['build_id']
    a.expected_es_sha256 = a.expected_es_sha256 or binding['files']['/usr/bin/emulationstation']['sha256']
    a.es_source_commit = a.es_source_commit or binding['pins']['emulationstation']
    check(re.fullmatch(r'[0-9a-f]{64}', a.expected_es_sha256), 'exact binary SHA256 required')
    check(re.fullmatch(r'[0-9a-f]{40}', a.es_source_commit), 'full declared ES source commit required')
    check(binding['build_id'] == a.expected_build and binding['pins']['emulationstation'] == a.es_source_commit,
          'image/source arguments do not match bound final image')
    check(binding['files']['/usr/bin/emulationstation']['sha256'] == a.expected_es_sha256, 'bound ES hash differs')
    a.output = a.output.absolute()
    identity = dict(line.split("=", 1) for line in Path("/etc/os-release").read_text().splitlines() if "=" in line)
    check(identity.get("BUILD_ID", "").strip('"') == a.expected_build, "BUILD_ID mismatch")
    check(digest(ES) == a.expected_es_sha256, "installed ES hash mismatch")
    check(hasattr(os, "unshare") and hasattr(os, "CLONE_NEWNET") and hasattr(os, "CLONE_NEWNS"),
          "Python os.unshare with mount/network namespace support required")
    check(hasattr(os, "pidfd_open") and hasattr(signal, "pidfd_send_signal"), "pidfd cleanup support required")
    check(socket.if_nameindex() == [(1, "lo")], "allocate VM with no NIC; parent namespace must have only lo")
    if a.worker:
        return worker(a)
    # Also refuse a NIC in the guest's parent namespace. This closes escape via
    # an existing privileged broker (systemd/D-Bus), outside the child's netns.
    check(not a.output.exists(), "refusing reused output")
    for proc in Path("/proc").glob("[0-9]*"):
        try:
            executable = os.readlink(proc / "exe").removesuffix(" (deleted)")
            check(Path(executable).name != "emulationstation", "coordinator must stop the existing ES first")
            argv = (proc / 'cmdline').read_bytes().split(b'\0')
            check(not any(part in (b'raofflineproxy.main', b'/usr/bin/raofflineproxy-ctl',
                                   b'/usr/bin/raofflineproxy-cache-indexed', b'/usr/bin/raofflineproxy-cache-images') for part in argv),
                  'coordinator must finish other installed proxy work first')
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass
    for tool in ["mount", "ip", "openssl"]:
        check(shutil.which(tool, path=clean_env(a)["PATH"]) is not None, "missing installed prerequisite: " + tool)
    for tool in (CTL, Path('/usr/bin/raofflineproxy-cache-indexed'), Path('/usr/bin/raofflineproxy-cache-images')):
        check(os.access(tool, os.X_OK), 'installed helper is not executable: ' + str(tool))
    check(Path(a.xdg_runtime_dir).is_absolute() and "/" not in a.wayland_display,
          "explicit runtime directory and socket basename required")
    check(stat.S_ISSOCK((Path(a.xdg_runtime_dir) / a.wayland_display).stat().st_mode), "Wayland socket missing")
    for path in [Path("/usr/config/emulationstation/resources"), Path("/usr/share/themes/es-theme-art-book-next"),
                 Path("/usr/config/locale"), *HOST_FILES, CA, CTL]:
        check(path.exists(), "missing installed prerequisite: " + str(path))
    before = census(binding)
    a.output.mkdir(mode=0o700)
    save(a.output / "case.json", {"case": a.case})
    save(a.output / "before.json", before)
    save(a.output / "binding.json", {"build_id": a.expected_build, "es_sha256": a.expected_es_sha256,
                                     "declared_es_source": a.es_source_commit, "installed_binding_sha256": a.binding_sha256,
                                     "fixture_sha256": {str(f.relative_to(HERE)): digest(f) for f in sorted(HERE.rglob("*")) if f.is_file()}})
    global LOCK_ROOT
    LOCK_ROOT = a.output
    locks.acquire(a.output)
    with (a.output / "worker.stdout").open("wb") as out, (a.output / "worker.stderr").open("wb") as err:
        child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), *sys.argv[1:], "--worker"],
                                 env=clean_env(a), stdout=out, stderr=err, start_new_session=True)
    pidfile(a.output, "owner", child)
    forced = False
    interrupted = None
    terminal_capture = None

    def interrupt(signum, frame):
        raise InterruptedError(signum)
    signal.signal(signal.SIGTERM, interrupt)
    signal.signal(signal.SIGINT, interrupt)
    try:
        code = child.wait(timeout=LIMIT)
    except (subprocess.TimeoutExpired, InterruptedError) as error:
        forced = isinstance(error, subprocess.TimeoutExpired)
        interrupted = error.args[0] if isinstance(error, InterruptedError) else None
        held_view = None
        try:
            held_view = guard.retain_view(a.output, child.pid)
        except Exception as capture_error:
            terminal_capture = {"passed": False, "failure": str(capture_error)}
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        code = child.wait()
        if held_view is not None:
            try:
                guard.capture_retained(a.output, held_view)
                terminal_capture = {"passed": True}
            except Exception as capture_error:
                terminal_capture = {"passed": False, "failure": str(capture_error)}
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
    # Retire stragglers by unique namespace inode, not an argv pattern. Never
    # signal a process just because its PID was recorded earlier.
    ns_path = a.output / "namespaces.json"
    retired = []
    if ns_path.exists():
        namespaces = json.loads(ns_path.read_text())
        for proc in Path("/proc").glob("[0-9]*"):
            fd = None
            try:
                fd = os.pidfd_open(int(proc.name))
                if os.readlink(proc / "ns/mnt") == namespaces["mnt"] and os.readlink(proc / "ns/net") == namespaces["net"]:
                    signal.pidfd_send_signal(fd, signal.SIGKILL)
                    retired.append(int(proc.name))
            except (FileNotFoundError, ProcessLookupError):
                pass
            finally:
                if fd is not None:
                    os.close(fd)
    def still_in_namespace():
        if not ns_path.exists():
            return []
        remaining = []
        for proc in Path("/proc").glob("[0-9]*"):
            try:
                if os.readlink(proc / "ns/mnt") == namespaces["mnt"] and os.readlink(proc / "ns/net") == namespaces["net"]:
                    remaining.append(int(proc.name))
            except (FileNotFoundError, ProcessLookupError):
                pass
        return remaining
    end = time.monotonic() + 3
    remaining = still_in_namespace()
    while remaining and time.monotonic() < end:
        time.sleep(0.1)
        remaining = still_in_namespace()
    (a.output / "key.pem").unlink(missing_ok=True)
    locks.release(a.output)
    contract.verify(a.installed_binding, a.binding_sha256)
    after = census(binding)
    save(a.output / "after.json", after)
    result = {"worker_exit": code, "timeout": forced, "interrupted_signal": interrupted, "stragglers_killed": retired,
              "namespace_processes_remaining": remaining, "terminal_output_capture": terminal_capture,
              "parent_unchanged": before == after, "runtime_test_was_run": True}
    result["passed"] = code == 0 and not forced and interrupted is None and not retired and not remaining and before == after
    save(a.output / "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    finally:
        if LOCK_ROOT is not None:
            locks.release(LOCK_ROOT)

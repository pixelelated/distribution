# FEX phase-A allocation (#528)

Coordinator source review accepted packet854ce16045c5b590e18432ff81800d1c3ec4b17d72015be714e0b6286eb21772. Reviewed full collector, preparer, controls, binding and consumer; unchanged process-identity and reused bounded supervisor retain original waits and cleanup.

Allocate focused offline guards first: one watched command,30s plus5s cleanup, memory-only extracted functions and one fresh result. On successful original channels, prepare one fresh owner, read current host preflight and retention, acquire one normal admission, then one actively supervised source collection. Caps are eight logical archives,40 actual HTTP requests,192MiB/body,384MiB aggregate,1GiB owner,2GiB reservation,2CPUs/2GiB address space,580/600/630+15s. No retries, extraction, source execution, source changes or device/cloud use. Raw curl streams remain private. Failure preserves partial files and ordinary failed-investigated consumption; no silent continuation.

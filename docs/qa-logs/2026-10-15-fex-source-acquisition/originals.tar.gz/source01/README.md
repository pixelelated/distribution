# FEX phase-A source acquisition — SOURCE ONLY, UNRUN

This packet prepares eight exact full upstream source archives selected by the accepted FEX dependency disposition. No collector, preparer, guard, curl, Nix, build, archive extraction or source execution has run from this packet. The coordinator alone allocates the focused offline controls and subsequent serialized collection. Static Python AST and Bash syntax parsing are recorded in `static-review.json`; they are not guard or acquisition results.

`collection-plan.json` binds the accepted proposal, its seal, the frozen mirror definitions, eleven exact fetch derivations and the historical archive manifest. The eight files are Linux 6.16.7, libdrm 2.4.129, glibc 2.40, GCC 14.3.0, Wayland 1.24.0, libX11 1.8.12, xorgproto 2024.1 and libXrandr 1.5.4. Each retained successful response must match the known **flat SHA-256**. Bodies retain the `.body` name of their original HTTP request; the archive receipt maps the source filename and digest to those unchanged bytes.

ALSA 1.2.14, libxcb 1.17.0 and libXrender 0.9.12 reuse three exact historical archive references. This run revalidates their manifest binding and does not recopy or rehash those payloads. Nixpkgs commit `b6018f87da91d19d0ab4cf979885689b469cdd41`, the distinct recursive libglvnd source and 22 selected patches remain **phase B, unperformed**. Neither a whole 81-row compiler closure nor unidentified guest-rootfs runtime providers are added to this acquisition. Notice assembly, independent retrieval, offhost custody and publication clearance remain separate.

## Requests, privacy and finite bounds

- Exactly eight logical downloads. Each permits at most four explicit redirects: at most five requests each, **40 actual HTTP requests total**. Every hop counts, including redirect bodies and failed responses. No automatic retries, fallback mirror switching or enlarged limits.
- Initial URLs exactly match the frozen proposal. Every subsequent URL must use anonymous HTTPS on that source's explicit frozen-mirror host list, with no userinfo, explicit port, fragment or control characters. `curl -q`, a minimal environment, `--proto =https`, `--retry 0`, and no `--location` avoid implicit configuration and redirect following. An unlisted mirror route stops for review; the collector does not broaden the list.
- Each response body is at most **192 MiB**; all bodies together, including partials and redirect bodies, are at most **384 MiB**. The **1 GiB owner ceiling** includes retained logs, initial owner files and receipts. Retention admission reserves **2 GiB** for that owner and filesystem overhead; it scans only its prepared empty retention directory.
- Before any request writes, reserve its entire effective body allowance **and both raw stream allowances**. The actual `RLIMIT_FSIZE` applied to curl is the minimum of 192 MiB, remaining aggregate body allowance, and one third of owner capacity after the normal receipt reserve and a further 4 MiB request metadata margin. Each of the three streams is bounded by that exact value. Release unused reservations only after observing the original wait and verifying the stable retained stream/body identities and lengths. Previously retained bytes continue to count.
- Normal collector writes leave **16 MiB**. A collector failure receipt is capped at **1 MiB**, with an independent **8 MiB** supervisor margin. Collector JSON is capped at 1 MiB each / 16 MiB aggregate. Reused supervisor JSON is capped at 1 MiB each / 8 MiB aggregate, and each captured collector stream at 256 KiB. Completion evidence is capped at 4 MiB with an owner-total check before writing. Preparation has an 8 MiB aggregate / 64-file bound. At most 40 fixed six-file request groups plus eight archive receipts and the finite lifecycle/preparation files remain below 512 files / 16 directories; the plan contains no remote-controlled pathnames. All output creation is exclusive.
- Collector soft deadline **580 seconds**; supervisor collector deadline **600 seconds**, identity-bound cleanup within 13 seconds; outer timeout **630 seconds**, followed by at most 15 seconds to kill. Each logical download has one **120-second** budget shared across its redirects; each connection has a 10-second bound. One collector and one serial curl child at a time, two pinned CPUs and 2 GiB address-space limit. Streamed named reads are capped at 4 GiB; metadata has its own small-file limits.
- Raw `.curl.stdout` and `.curl.stderr` can contain signed redirect paths or queries and **must remain owner-held, excluded from Git or public packets**. The public receipts retain only initial canonical URLs, redirect origins, and hashes of full URLs. Failure receipts retain the error type, original return codes and private-artifact pointers, not raw exception text. Do not publish raw stream excerpts while diagnosing.

The bounds accommodate the two large full source archives plus six smaller archives without extraction. They are caps, not a claim of measured upstream sizes. Large logs or a slower/unexpected mirror can cause an intentional stop. A stopped owner is preserved, its original failure is consumed through the ordinary failed-investigation path, and any missing-source continuation needs a separately reviewed fresh owner; this helper never silently retries completed archives or reuses an output owner.

## Reused lifecycle and review

`source-provenance.json` names the exact qualified Tailscale and additive-03 seals. `originals/` retains the compared source bytes. `changes.diff` contains the complete source differences. The additive-03 `process-identity.py` is unchanged; its PID/start-time identity checks, pidfd signals, strict bounded census, subreaper custody, original wait preservation and cleanup remain intact. The supervisor changes only profile, scope, resource selection and eight-archive success assertions. Tailscale acquisition/output reservation and success-consumption patterns are adapted to explicit redirects and flat source archives; Go module zip decoding is absent.

`guard-controls.py` extracts only hash-bound reviewed function definitions into memory, reuses the 14 existing write/reservation controls and adds focused cases for aggregate/owner capacity, wait-bound release, URL/redirect policy, request counts, original failures and flat hash mismatch. Fake requests never invoke subprocesses or curl. It may write one fresh bounded result JSON when explicitly allocated. **These guard cases have not run.**

## Ready commands — coordinator allocation required

The helper defaults to fresh owner `/workspace/tmp/pix-m7-fex-source-acquisition-20261015-01`; no owner has been created. Set `TASK_OWNER` and `TASK_GUARD_REPORT` to another fresh two-digit suffix if either default exists. Run each step separately, inspect its original receipts, and stop on any failure:

```bash
bash /tmp/pix-m7-fex-source-acquisition-20261015/commands.sh guards
# Set TASK_GUARD_RUN to the original successful watched guard run directory.
# Set TASK_CURL_PATH to the resolved host curl ELF and TASK_CURL_SHA256 to its digest.
bash /tmp/pix-m7-fex-source-acquisition-20261015/commands.sh prepare
bash /tmp/pix-m7-fex-source-acquisition-20261015/commands.sh preflight
bash /tmp/pix-m7-fex-source-acquisition-20261015/commands.sh report
bash /tmp/pix-m7-fex-source-acquisition-20261015/commands.sh admit
bash /tmp/pix-m7-fex-source-acquisition-20261015/commands.sh launch
# Actively supervise the original launcher/run at intervals no longer than 60 seconds.
# After successful original command, monitor, wrapper and launcher channels and cleanup:
bash /tmp/pix-m7-fex-source-acquisition-20261015/commands.sh consume
```

The frozen control checkout is `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02` at `f8636de1d105275dbf9420bbabbbc26f79abb10f`; host UID/GID, namespaces, exact tools and shared admission serialization are checked. Submission is not completion. A source collection PASS remains `COLLECTED_WITH_EXPLICIT_GAPS`, with source execution, extraction, independent SYSTEM relation and publication clearance false.

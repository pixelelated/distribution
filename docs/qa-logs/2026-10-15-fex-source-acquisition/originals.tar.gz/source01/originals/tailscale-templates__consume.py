#!/usr/bin/env python3
"""Consume only original successful collection channels; gaps never become clearance."""
from pathlib import Path
import json,runpy,subprocess,stat
O=Path(__file__).resolve().parent
B=runpy.run_path(str(O/'bindings.py'));B['verify'](O)
assert Path.cwd()==B['VM_TREE']
load,sha=B['load'],B['sha']
run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs'
B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
for f in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert f.read_text().strip()=='0',f
result,cleanup=load(O/'result.json'),load(O/'cleanup.json')
assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete'] is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established'] is False
assert result['execution_error'] is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json')
assert child['wait_observed'] is True and type(child['original_child_returncode']) is int and child['original_child_returncode']==0
assert child['qualification'] is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json')
assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit']) is int and report['original_collector_exit']==0
assert report['publication_clearance'] is False and report['independent_SYSTEM_relation_established'] is False
assert not (O/'collection-failure.json').exists()
policy=load(O/'collection-plan.json')['owner_output_enforcement']
assert report['owner_output_enforcement']==policy and policy['owner_ceiling_bytes']==1024**3
limits=load(O/'resources.json')
assert type(report['initial_owner_bytes'])is int and 0<report['initial_owner_bytes']<=limits['initial_owner_maximum_bytes']
assert report['accounted_owner_bytes_before_report']<=policy['normal_collector_write_ceiling_bytes']
assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=1024**3
assert len(report['rows'])==89 and 89<=len(report['downloads'])<=178
assert report['source_rebuild']is False and report['source_execution']is False and report['go_execution']is False and report['target_execution']is False and report['network_used']is True
plan=load(O/'collection-plan.json')
assert [r['selection'] for r in report['rows']]==plan['selected_modules']
assert len(report['payload_reservations'])==len(report['log_reservations'])==len(report['downloads'])
request_by_key={r['key']:r for r in report['downloads']};assert len(request_by_key)==len(report['downloads'])
def check_file(record,parent):
    p=Path(record['path']);assert p.parent==parent and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size==record['bytes'] and sha(p)==record['sha256']
    actual=dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
    assert all(record[k]==v for k,v in actual.items()),'retained file identity changed'
for payload,log,download in zip(report['payload_reservations'],report['log_reservations'],report['downloads']):
    assert type(download['original_curl_returncode'])is int and download['original_curl_returncode']==0 and download['wait_observed']is True
    wait=load(O/'collection'/(download['key']+'.curl.wait.json'))
    assert wait['original_curl_returncode']==0 and type(wait['original_curl_returncode'])is int and wait['wait_observed']is True
    assert wait['argv']==download['argv'] and wait['url']==download['url'] and wait['url_sha256']==download['url_sha256'] and wait['key']==download['key']
    assert download==load(O/'collection'/(download['key']+'.http.json'))
    assert payload['original_wait_observed']is True and log['original_wait_observed']is True
    assert payload['reserved_bytes']==log['per_stream_limit']==limits['compressed_archive_per_file_bytes']
    assert payload['actual_bytes']==download['body']['bytes'] and payload['path']==download['body']['path']
    assert payload['released_bytes']==payload['reserved_bytes']-payload['actual_bytes']
    assert log['actual_bytes']==download['stdout']['bytes']+download['stderr']['bytes']
    assert log['reserved_bytes']==2*log['per_stream_limit'] and log['released_bytes']==log['reserved_bytes']-log['actual_bytes']
    assert dict(payload=payload,logs=log)==load(O/'collection'/(download['key']+'.reservations.json'))
    for key in ['stdout','stderr']:check_file(download[key],O/'collection')
    check_file(download['body'],O/'archives')
assert sum(r['actual_bytes'] for r in report['payload_reservations'])==report['compressed_bytes']<=limits['compressed_archive_aggregate_bytes']
for row in report['rows']:
    selection=row['selection'];key=selection['key']
    assert row==load(O/'collection'/(key+'.module.json'))
    assert row['source_h1_verified']is True and row['actual_go_h1']==selection['expected_go_h1']
    assert row['source_status']=='EXACT_EMBEDDED_H1_VERIFIED' and row['license_clearance']is False
    chosen=request_by_key[row['original_request_key']]
    assert chosen['module']==selection['module'] and chosen['version']==selection['version'] and chosen['http_status']==200 and not chosen['redirect_url']
    own=[r for r in report['downloads'] if r['module']==selection['module'] and r['version']==selection['version']]
    assert [r['hop'] for r in own] in [[0],[0,1]] and own[0]['url']==selection['canonical_proxy_zip_url']
    if len(own)==2:assert own[0]['http_status'] in [301,302,303,307,308] and own[0]['redirect_url']==own[1]['url'] and own[0]['redirect_url_sha256']==own[1]['url_sha256']
    assert row['archive']==chosen['body']
    p=Path(row['member_index']['path']);assert p==O/'collection'/(key+'.index.json') and sha(p)==row['member_index']['sha256']
selected=load(O/'collection/selected-members.json')
assert selected==[t for row in report['rows'] for t in row['notice_candidates']]
assert len(selected)<=limits['max_notice_candidates'] and sum(r['bytes'] for r in selected)<=limits['notice_text_aggregate_bytes']
for r in selected:
    p=Path(r['retained_path']);assert p.parent==O/'collection/texts' and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert cleanup['all_recorded_identities_absent'] is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped'] is False
# Same qualified final-inventory strict census and PID/start identity custody.
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']()
owned_keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']}
supervisor=cleanup['supervisor_identity'];assert supervisor is not None
owned_keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in owned_keys]
parents={r['pid'] for r in matching};descendants=[]
while parents:
    children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants]
    descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants,'recorded identity or owned descendant still present'
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[O/n for n in ['result.json','cleanup.json','collection-result.json','collection-plan.json','preparation.json','host-tools.json','seal.json','inner.rc','outer.rc','launcher-result.json','tool-wrapper.rc']]+[run/'runner-result.json',run/'build.rc']
files+=sorted(p for d in ['stage','collection'] for p in (O/d).rglob('*') if p.is_file())
files+=sorted(p for p in (O/'archives').iterdir() if p.is_file())
assert len(files)<=20000 and sum(p.stat().st_size for p in files)<=1024**3
out=O/'admission-completion-evidence.json'
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='All89 selected Tailscale dependency ZIPs match embedded h1; source/notice data only. Missing or unmatched notice candidates remain explicit; no source or target execution, rebuild, independent SYSTEM, legal or publication clearance. All prior producer dispositions unchanged.')
raw=(json.dumps(evidence,indent=2)+'\n').encode()
assert len(raw)<=4*1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=1024**3,'completion receipt would exceed owner ceiling'
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed exact89 module source collection; notice/publication disposition remains explicit')

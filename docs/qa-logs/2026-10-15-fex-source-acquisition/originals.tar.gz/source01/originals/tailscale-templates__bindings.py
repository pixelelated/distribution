"""Exact prior source/provenance only; no product/cache traversal."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    return h.hexdigest()
def load(path):
    p=Path(path);assert p.is_file() and not p.is_symlink() and p.stat().st_size<20*1024**2,p
    return json.loads(p.read_text())
def host_and_serialization(own_run=None):
    assert (os.getuid(),os.getgid())==(1000,1000)
    assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]'
    assert os.readlink('/proc/self/ns/user')=='user:[4026531837]'
    jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values()
    active=[j for j in jobs if j['state']!='consumed']
    assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
    if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def curl_identity(path):
    p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink()
    s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<16*1024**2 and os.access(p,os.X_OK)
    h=sha(p);after=p.stat();assert all(getattr(after,k)==getattr(s,k) for k in ['st_dev','st_ino','st_size','st_mode','st_uid','st_gid','st_mtime_ns']),'curl identity changed'
    with p.open('rb') as f:header=f.read(64)
    assert header[:6]==b'\x7fELF\x02\x01' and int.from_bytes(header[18:20],'little')==62,'host AMD64 ELF required'
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,sha256=h)
def verify(O):
    for name,h in load(O/'seal.json').items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<20*1024**2
        assert sha(p)==h,name
    for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
    plan=load(O/'collection-plan.json')
    for name,h in plan['binding_refs'].items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2
        assert sha(p)==h,name
    assert len(plan['selected_modules'])==89 and plan['publication_clearance']is False
    reconciliation=load('/tmp/pix-m7-tailscale-notice-reconciliation-20261015/reconciliation.json')
    assert [(r['module'],r['version'],r['expected_go_h1']) for r in plan['selected_modules']]==[(r['module'],r['version'],r['sum']) for r in reconciliation['rows']]
    consumed_source=load(VM_TREE/'.build-runs/20261015T113915Z-85697540/admission-consumed.json')
    assert consumed_source['id']=='26f1eaddbefc406ebed615ed774eee30' and consumed_source['state']=='consumed'
    assert all(type(consumed_source['original_result'][k])is int and consumed_source['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    consumed=load(VM_TREE/'.build-runs/20261015T105557Z-8aa7d0f7/admission-consumed.json')
    assert consumed['id']=='ed6fa1a7e7ef440599eca47e6790f978' and consumed['state']=='consumed'
    assert all(type(consumed['original_result'][k])is int and consumed['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
    prior=load('/workspace/tmp/pix-m7-prebuilt-strip-20261015-02/collection-result.json')
    assert prior['original_collector_exit']==0 and prior['publication_clearance']is False and len(prior['rows'])==9
    assert all(r['strip_equals_package_and_staged_image']is True and r['protected_inputs_unchanged']is True for r in prior['rows'])
    tools=load(O/'host-tools.json');assert set(tools)=={'curl'}
    assert curl_identity(tools['curl']['path'])==tools['curl']['identity']
    return plan

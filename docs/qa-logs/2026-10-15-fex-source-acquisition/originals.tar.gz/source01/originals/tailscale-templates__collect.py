#!/usr/bin/env python3
"""Acquire official selected module ZIP data; never run Go/source or target code."""
from pathlib import Path
import datetime,hashlib,json,os,resource,runpy,stat,subprocess,sys,time,urllib.parse
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());RESOURCES=json.loads((O/'resources.json').read_text())
INITIAL_OUTPUT_BYTES=sum(p.stat().st_size for p in O.rglob('*') if p.is_file())
OUTPUT_BYTES=INITIAL_OUTPUT_BYTES
start=time.monotonic();read_bytes=0;retained_bytes=0;metadata_bytes=0;compressed_bytes=0
rows=[];module_receipts=[];downloads=[];payload_reservations=[];log_reservations=[];gaps=[];selected=[];counts={};rc=1
def account_output(size, failure=False):
    global OUTPUT_BYTES
    assert size<=RESOURCES['per_file_bytes'], 'retained output exceeds existing per-file resource bound'
    policy=PLAN['owner_output_enforcement']
    if failure:assert size<=policy['failure_receipt_budget_bytes'], 'failure receipt exceeds its bounded reserve share'
    reserve=policy['supervisor_receipt_margin_bytes'] if failure else policy['supervisor_receipt_reserve_bytes']
    assert OUTPUT_BYTES+size<=RESOURCES['owner_output_ceiling_bytes']-reserve, 'retained owner-output budget exceeded before write'
    OUTPUT_BYTES+=size

def write(path, value):
    assert not path.exists() and not path.is_symlink(), 'refuse retained output overwrite: '+str(path)
    raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
    account_output(len(raw),failure=path.name=='collection-failure.json')
    with path.open('xb') as f:f.write(raw)

def identity(p):
    assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),p
    s=p.stat();assert stat.S_ISREG(s.st_mode),p
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)

def release_log_reservation(row,stdout_bytes,stderr_bytes,wait_observed):
    global OUTPUT_BYTES
    assert wait_observed is True and row['original_wait_observed'] is False
    assert row['released_bytes']==0 and row['reserved_bytes']==2*row['per_stream_limit']
    assert type(stdout_bytes)is int and type(stderr_bytes)is int
    assert 0<=stdout_bytes<=row['per_stream_limit'] and 0<=stderr_bytes<=row['per_stream_limit']
    used=stdout_bytes+stderr_bytes
    release=row['reserved_bytes']-used
    assert OUTPUT_BYTES>=release
    OUTPUT_BYTES-=release
    row.update(released_bytes=release,actual_bytes=used,original_wait_observed=True)


def budget(n):
    global read_bytes
    read_bytes+=n
    assert read_bytes<=RESOURCES['named_read_ceiling_bytes'] and time.monotonic()-start<RESOURCES['collector_seconds']-20,'named read/time bound'


def digest(path,cap):
    before=identity(path);assert before['bytes']<=cap
    h=hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1024**2),b''):budget(len(data));h.update(data)
    assert identity(path)==before,'input changed'
    return dict(before,sha256=h.hexdigest())


def put(path,value):
    global metadata_bytes
    size=len((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode())
    assert size<=RESOURCES['max_json_bytes'] and metadata_bytes+size<=RESOURCES['max_retained_metadata_bytes'],'metadata aggregate bound'
    metadata_bytes+=size
    write(path,value)


class NamedReader:
    def __init__(self,raw):self.raw=raw
    def read(self,n=-1):
        data=self.raw.read(n);budget(len(data));return data
    def __getattr__(self,name):return getattr(self.raw,name)


def reserve_payload(path):
    global compressed_bytes
    cap=RESOURCES['compressed_archive_per_file_bytes']
    assert compressed_bytes+cap<=RESOURCES['compressed_archive_aggregate_bytes'],'compressed source reservation bound'
    account_output(cap);compressed_bytes+=cap
    row=dict(path=str(path),reserved_bytes=cap,actual_bytes=None,released_bytes=0,original_wait_observed=False)
    payload_reservations.append(row)
    return row


def release_payload(row,actual,wait_observed):
    global OUTPUT_BYTES,compressed_bytes
    assert wait_observed is True and row['original_wait_observed']is False and row['released_bytes']==0
    assert type(actual)is int and 0<=actual<=row['reserved_bytes']
    unused=row['reserved_bytes']-actual
    assert OUTPUT_BYTES>=unused and compressed_bytes>=unused
    OUTPUT_BYTES-=unused;compressed_bytes-=unused
    row.update(actual_bytes=actual,released_bytes=unused,original_wait_observed=True)


def validate_request_url(url,initial):
    u=urllib.parse.urlsplit(url)
    assert u.scheme=='https' and u.hostname==('proxy.golang.org' if initial else 'storage.googleapis.com')
    assert u.netloc==u.hostname and u.username is None and u.password is None and not u.fragment
    assert len(url)<=8192 and not any(ord(c)<33 or ord(c)==127 for c in url)
    if initial:assert not u.query


def public_url(url):
    return urllib.parse.urlunsplit(urllib.parse.urlsplit(url)._replace(query=''))


def request(selection,url,hop,curl,deadline):
    assert len(downloads)<RESOURCES['max_http_requests_including_redirects']
    validate_request_url(url,hop==0)
    key=selection['key']+'-'+str(hop);cap=RESOURCES['compressed_archive_per_file_bytes']
    path=O/'archives'/(key+'.body');stdout=O/'collection'/(key+'.curl.stdout');stderr=O/'collection'/(key+'.curl.stderr')
    assert not path.exists() and not path.is_symlink()
    reservation=reserve_payload(path)
    with path.open('xb'):pass
    before=digest(Path(curl['path']),16*1024**2);assert before==curl['identity']
    remaining=deadline-time.monotonic();assert remaining>0,'logical download deadline'
    argv=[curl['path'],'-q','--fail','--proto','=https','--connect-timeout',str(RESOURCES['request_connect_seconds']),'--max-time',str(min(remaining,RESOURCES['logical_download_seconds'])),'--max-filesize',str(cap),'--retry','0','--silent','--show-error','--output',str(path),'--write-out','%{http_code}\n%{redirect_url}\n',url]
    # No --location: one explicitly checked redirect is a distinct counted request.
    log=dict(asset=key,per_stream_limit=cap,reserved_bytes=2*cap,released_bytes=0,original_wait_observed=False)
    account_output(cap);account_output(cap);log_reservations.append(log)
    row=dict(key=key,module=selection['module'],version=selection['version'],hop=hop,url=public_url(url),url_sha256=hashlib.sha256(url.encode()).hexdigest(),argv=argv[:-1]+[public_url(url)],argv_url_redacted=bool(urllib.parse.urlsplit(url).query),original_curl_returncode=None,wait_observed=False)
    downloads.append(row)
    with stdout.open('xb') as so,stderr.open('xb') as se:
        process=subprocess.run(argv,stdout=so,stderr=se,cwd=O/'archives',env={'PATH':'/usr/bin:/bin','HOME':str(O/'empty-home'),'LC_ALL':'C'},preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(cap,cap)))
    row.update(original_curl_returncode=process.returncode,wait_observed=True)
    # Preserve actual wait before parsing HTTP or checking content. Interruption
    # remains unknown here and failed in the unchanged independent supervisor.
    put(O/'collection'/(key+'.curl.wait.json'),row)
    row.update(stdout=digest(stdout,cap),stderr=digest(stderr,cap),body=digest(path,cap))
    release_log_reservation(log,row['stdout']['bytes'],row['stderr']['bytes'],True)
    release_payload(reservation,row['body']['bytes'],True)
    put(O/'collection'/(key+'.reservations.json'),dict(payload=reservation,logs=log))
    assert digest(Path(curl['path']),16*1024**2)==before,'curl changed'
    assert row['stdout']['bytes']<=RESOURCES['http_stdout_parse_bytes'],'HTTP metadata parse bound'
    fields=stdout.read_bytes().decode('utf-8',errors='strict').splitlines()
    assert len(fields)==2 and len(fields[0])==3 and fields[0].isdigit(),'invalid HTTP metadata'
    redirect=fields[1]
    row.update(http_status=int(fields[0]),redirect_url=public_url(redirect) if redirect else '',redirect_url_sha256=hashlib.sha256(redirect.encode()).hexdigest() if redirect else None)
    put(O/'collection'/(key+'.http.json'),row)
    return row,redirect


def download(selection,curl):
    assert selection['canonical_proxy_zip_url']==M['proxy_url'](selection['module'],selection['version'])
    deadline=time.monotonic()+RESOURCES['logical_download_seconds']
    row,redirect=request(selection,selection['canonical_proxy_zip_url'],0,curl,deadline)
    if row['http_status'] in [301,302,303,307,308]:
        assert type(row['original_curl_returncode'])is int and row['original_curl_returncode']==0
        validate_request_url(redirect,False)
        row,redirect=request(selection,redirect,1,curl,deadline)
    if row['http_status']==404 and row['original_curl_returncode']==22:
        assert not row['redirect_url']
        return None,row
    assert type(row['original_curl_returncode'])is int and row['original_curl_returncode']==0,'original download failed'
    assert row['http_status']==200 and not row['redirect_url'],'source response/redirect mismatch'
    return Path(row['body']['path']),row


try:
    M=runpy.run_path(str(O/'module_zip.py'))
    assert INITIAL_OUTPUT_BYTES<=RESOURCES['initial_owner_maximum_bytes'];account_output(0)
    tools=json.loads((O/'host-tools.json').read_text());assert len(PLAN['selected_modules'])==89
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    for name in ['archives','collection','collection/texts','empty-home']:(O/name).mkdir(mode=0o700)
    for selection in PLAN['selected_modules']:
        budget(0);path,http=download(selection,tools['curl'])
        if path is None:
            row=dict(selection=selection,source_h1_verified=False,source_status='UNAVAILABLE_HTTP404',original_request_key=http['key'],notice_candidates=[],license_clearance=False)
            rows.append(row);gaps.append(dict(module=selection['module'],gap='Selected source unavailable; original curl22 retained'))
            put(O/'collection'/(selection['key']+'.module.json'),row)
            module_receipts.append(dict(module=selection['module'],version=selection['version'],source_h1_verified=False,path=str(O/'collection'/(selection['key']+'.module.json')),sha256=hashlib.sha256((O/'collection'/(selection['key']+'.module.json')).read_bytes()).hexdigest()))
            continue
        before=digest(path,RESOURCES['compressed_archive_per_file_bytes'])
        with path.open('rb') as raw:parsed=M['hash_zip'](NamedReader(raw),selection,RESOURCES,counts,budget)
        assert digest(path,RESOURCES['compressed_archive_per_file_bytes'])==before,'archive changed'
        index_path=O/'collection'/(selection['key']+'.index.json');put(index_path,parsed['index'])
        texts=[]
        for member,data in parsed['texts']:
            assert retained_bytes+len(data)<=RESOURCES['notice_text_aggregate_bytes']
            key=selection['module']+'@'+selection['version']+':'+member['relative_path']
            dest=O/'collection/texts'/(hashlib.sha256(key.encode()).hexdigest()+'.txt')
            account_output(len(data))
            with dest.open('xb') as out:out.write(data)
            retained_bytes+=len(data)
            text=dict(member,retained_path=str(dest),module=selection['module'],version=selection['version'])
            selected.append(text);texts.append(text)
        # Old raw texts remain external protected evidence. Compare by exact bytes,
        # never infer one module's notice from an unrelated parent module/version.
        reuse=[]
        for ref in selection['reuse_notice_refs']:
            reuse.append(dict(original=ref,matching_zip_members=[t['relative_path'] for t in texts if t['sha256']==ref['sha256'] and t['bytes']==ref['bytes']]))
        row=dict(selection=selection,source_h1_verified=True,source_status='EXACT_EMBEDDED_H1_VERIFIED',archive=before,actual_go_h1=parsed['actual_go_h1'],member_count=parsed['member_count'],decoded_bytes=parsed['decoded_bytes'],member_index=dict(path=str(index_path),sha256=hashlib.sha256(index_path.read_bytes()).hexdigest()),original_request_key=http['key'],notice_candidates=texts,prior_notice_comparisons=reuse,license_clearance=False)
        if not texts:gaps.append(dict(module=selection['module'],gap='Full source present; no filename-selected notice candidate. Offline source disposition required.'))
        if any(not r['matching_zip_members'] for r in reuse):gaps.append(dict(module=selection['module'],gap='Prior notice bytes not found among ZIP filename-selected candidates; original source/text retained separately for disposition.'))
        rows.append(row);put(O/'collection'/(selection['key']+'.module.json'),row)
        module_receipts.append(dict(module=selection['module'],version=selection['version'],source_h1_verified=True,path=str(O/'collection'/(selection['key']+'.module.json')),sha256=hashlib.sha256((O/'collection'/(selection['key']+'.module.json')).read_bytes()).hexdigest()))
    put(O/'collection/selected-members.json',selected)
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    assert all(r['source_h1_verified']is True for r in rows),'one or more selected sources unavailable'
    report=dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,downloads=downloads,payload_reservations=payload_reservations,log_reservations=log_reservations,gaps=gaps,counts=counts,compressed_bytes=compressed_bytes,retained_member_bytes=retained_bytes,named_bytes_read=read_bytes,elapsed_seconds=time.monotonic()-start,initial_owner_bytes=INITIAL_OUTPUT_BYTES,accounted_owner_bytes_before_report=OUTPUT_BYTES,owner_output_enforcement=PLAN['owner_output_enforcement'],target_execution=False,source_execution=False,go_execution=False,network_used=True,source_rebuild=False,independent_SYSTEM_relation_established=False,publication_clearance=False,outputs_held=True,deleted_bytes=0)
    put(O/'collection-result.json',report);rc=0
except BaseException as error:
    # This bounded original failure is never replaced by success. Do not retry a
    # refused large index/result, nor delete partial ZIPs or unknown child output.
    write(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(error).__name__+': '+str(error)[:4096],completed_rows=len(rows),resume_scope=dict(collection_plan_sha256=hashlib.sha256((O/'collection-plan.json').read_bytes()).hexdigest(),completed_module_receipts=module_receipts,policy='No automatic retry. A separately reviewed fresh owner may bind these exact consumed originals and collect only missing sources; do not refetch successful modules.'),verified_sources=sum(r['source_h1_verified'] for r in rows),initial_owner_bytes=INITIAL_OUTPUT_BYTES,accounted_owner_bytes_before_failure=OUTPUT_BYTES,counts=counts,named_bytes_read=read_bytes,original_download_statuses=[dict(key=r['key'],original_curl_returncode=r['original_curl_returncode'],wait_observed=r['wait_observed']) for r in downloads],payload_reservations=payload_reservations,log_reservations=log_reservations,publication_clearance=False,outputs_held=True,deleted_bytes=0))
sys.exit(rc)

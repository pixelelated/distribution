# Installed native continuation — prepared, UNRUN

This is one small continuation of the accepted #574/#583/#584 component work.
It adds four calls through the final image's installed proxy bytecode and normal
native library discovery. It is not a service, queue, codec, sanitizer or gameplay
campaign. No runtime, allocation, product import or compiler was executed while
preparing this packet. The coordinator supplies the existing fresh no-NIC native
VM owner and records the allocation before executing it.

`installed-check.py` uses `/usr/bin/python3 -I -B` with ordinary site-packages
lookup. `-S` would disable that lookup and is intentionally absent. There is no
prepared Python tree, `sys.path` edit, `find_library` mock, `LD_LIBRARY_PATH` or
native-library override in the installed check. The final verifier's PASS receipt
is SHA-bound on entry; its exact `products` rows bind Python, all shipped proxy
bytecode, native hash library, Zstd, crypto and their complete symlink chains.
The receipt also binds final SYSTEM and distribution d6a87f05. Actual loaded
module origins must be installed `.pyc` files with `SourcelessFileLoader`;
actual process maps must contain the installed native, Zstd and crypto files.
Bare CDLL sonames are valid and are recorded rather than falsely required to be
absolute paths. No new root-verifier path requirement is needed for this check.

| One actual installed call | Exact expected answer |
| --- | --- |
| `synthetic.iso` (393216 bytes) | `118545082f24fc195a446d1ee7bbf816` |
| Independently encoded `dolphin-none.rvz` (159504 bytes) | same |
| Independently encoded `dolphin-zstd.rvz` (33268 bytes) | same; actual Zstd cache and mapping required |
| Accepted single-track `saturn.chd` recreated byte-for-byte | `4cd9c8e41cd8d137be15bbe6a93ae1d8` |

The crypto call only resolves/loads the same EVP entry points used by the accepted
proxy integration. It does not claim Wii encryption, full Wii RVZ, or gameplay.
The CHD case exercises the installed bridge/libchdr; this does not represent an
execution of ES's separate statically linked wrapper. Its accepted exact-source
component controls and the final ES source/build/SYSTEM binding remain evidence
for that implementation, without a fresh replay here.

## Existing input provenance

`inputs.json` gives every exact existing host source path, SHA256, byte count and
staging mode (13 files, 43,119,740 bytes). The three tiny GameCube inputs were
read back and hashed during this source preparation. No new disc download is
needed. `roundtrip-none.iso` is copied as `synthetic.iso`; the bytes are identical.
Their original accepted receipt is coordinator
`docs/qa-logs/2026-10-14-independent-format-runtime/attempt02/guest/pix574-format-format02/oracle/result.json`.
The accepted native proxy calls are in `2026-10-14-proxy-native-runtime/attempt01`.

The CHD itself was not exported before its old VM disk was retired. Recreate
only its input using the retained accepted writer ELF and chdman closure, not
the old owner's entrypoint. `prepare-inputs.py` preserves the two original child
receipts/stdout/stderr independently from installed runtime. It invokes:

```text
writer PRIVATE/writer-files
chdman-closure/ld-linux-x86-64.so.2 --library-path chdman-closure/lib
  chdman-closure/chdman createcd -i PRIVATE/writer-files/saturn.cue
  -o PRIVATE/saturn.chd -c none -np 1
```

Writer SHA `6a663a88b8eb2c573cf92ebb361f2d6c0dd20b2400e20f3c60ddd684eb7b6aed`;
converter SHA `766640dfccf2239503fbead2f172098b784d1bbec3f113ffa51264f7f5e1b129`.
The CHD must equal
`00c0dde6752938cf74d815fd5ca37df00a2da4b483284c003f0408f30fefe88b`.
Writer Saturn ISO/BIN/CUE hashes are checked first. The unchanged writer also
emits its original 32 MiB GameCube and tiny Wii helper inputs; they receive no
tests here and are disposable preparation output. Keeping that writer unchanged
avoids a new generator qualification. Its original 64 MiB file limit is retained;
no address-space limit is imposed on ASan's virtual shadow.

Original source and licensing: `m7-rvz-regressions-574/docs/qa-logs/2026-10-13-rvz-regression-source/fixture-writer.cpp`
uses official rcheevos `test/rhash/data.c` at
`40d916de00fe757bab40fb4db41a7912193a48e3` (MIT); notice copied under `licenses/`.
The nonbootable PX5740 generator is self-created, with its padding implementation
derived from bodgit/rvz (BSD-3-Clause notice also retained). No retail-game bytes
are present. chdman MAME pin `24cffe763621b164fc10be2ae3660f140be25182` and its
qualified seven-file closure remain bound in
`2026-10-14-chd-native-guest/stage-bindings.json` and
`2026-10-14-chd-native-runtime/attempt02`; this packet does not redistribute its
binary or replace its upstream license/source record.

## Concrete staging and command

After final image verification and exclusive native allocation, stage the packet
at `/tmp/pix-input/installed-native/packet`, the `inputs.json` files at
`/tmp/pix-input/installed-native/inputs/<manifest key>`, and the actual completed
verifier `result.json` as `final-image-result.json`. Use the existing read-only
ext4 input-media route, preserving manifest file modes; do not execute old
component owners. This small host staging command only copies the declared files:

```bash
# Set TASK_STAGE to a fresh private host directory for the existing input-media helper.
# Set TASK_VERIFIED to the actual completed verifier output directory.
python3 -I -S -B - "$TASK_STAGE" "$TASK_VERIFIED/result.json" <<'PY'
from pathlib import Path
import hashlib, json, shutil, sys
packet = Path('/tmp/m7-installed-native-smoke-20261014')
stage = Path(sys.argv[1]); stage.mkdir(mode=0o700)
shutil.copytree(packet, stage / 'packet')
for name, row in json.loads((packet / 'inputs.json').read_text())['staged'].items():
    src = Path(row['source']); data = src.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    dst = stage / 'inputs' / name; dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(data); dst.chmod(row['mode'])
receipt = Path(sys.argv[2]).read_bytes(); parsed = json.loads(receipt)
assert parsed['status'] == 'PASS' and parsed['source'] == 'd6a87f05c1935516115b2cca1af22151a0209224'
(stage / 'final-image-result.json').write_bytes(receipt)
print(hashlib.sha256(receipt).hexdigest())
PY
```

Use the SHA printed for the staged receipt as the sole argument below. Check the
packet's `SHA256SUMS` after copying. In the allocated guest, provision an empty
dedicated executable **256 MiB tmpfs**, mode0700, at `/run/pix-installed-native`.
Keep the existing no-NIC 8 GiB/4 CPU VM owner and descendant census/cleanup;
allocate **210 seconds for this case** within that owner's declared family.
This is a case command, not a new VM lifecycle:

```bash
timeout --signal=TERM --kill-after=10 180 \
  /bin/bash /tmp/pix-input/installed-native/packet/run-guest.sh ACTUAL_RECEIPT_SHA256 \
  >/run/pix-installed-native-case.stdout 2>/run/pix-installed-native-case.stderr
# The caller must save $? immediately as the original case exit.
```

The preparation children each have30s; preparation outer75s+5s cleanup; installed
work alarm60s and outer70s+5s. The installed child additionally has512MiB address
space,60CPU seconds,8MiB per file and no core dumps. Inputs are43MiB read-only;
the only writes are private scratch and evidence. Keep original outer statuses:
timeout/signal is failure, never a substitute zero. The existing descendant owner
must reap/census on failure because bounded.py starts each authoring child in a
new session. Do not start the installed phase after a preparation failure.

Expected success: writer0 with empty stderr, converter0 (normal progress stderr
retained), preparation0/PASS, four exact native answers with no errors,
installed0/PASS, outer case0 and no surviving case descendants. Preserve
`preparation.rc`, `installed.rc`, both wrapper streams, `preparation-result.json`,
both child JSON/stdout/stderr sets, installed `result.json`, `native-maps.txt`,
final verifier receipt/SHA and host owner originals. Export the recreated tiny
`saturn.chd` and its hash so it is not lost again; omit the unused writer32MiB
GameCube payload from compact evidence. Retire scratch only after export and
original owner consumption. No automatic retry.

## Dolphin and launcher scope

Frozen recipe `projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk`
sets `-DENABLE_CLI_TOOL=OFF` (line74) and copies only `Binaries/dolphin*`
(line95). There is no selected installed DolphinTool command to require.
Independent converter NONE/Zstd roundtrips already passed and are reused as
input provenance. Final `/usr/bin/dolphin-emu`, `dolphin-emu-nogui`, both real
launchers, `cheevos_dolphin.sh`, `dolphin-save-paths` and both profile trees are
already bound by the image verifier. Actual full-launch/Qt-Wayland/native first
frame/save/return remain the separate prepared official-homebrew route in
`2026-10-14-native-save-fixture-ready`; this packet neither bypasses those
launchers nor labels these format-only bytes playable. #588 owns installed
service lifecycle. No new unrelated criterion is introduced.

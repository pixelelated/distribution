#!/bin/bash
# UNRUN. Case command only; the allocated VM/descendant owner remains mandatory.
set -u
packet=/tmp/pix-input/installed-native/packet
inputs=/tmp/pix-input/installed-native/inputs
receipt=/tmp/pix-input/installed-native/final-image-result.json
scratch=/run/pix-installed-native
test "$#" -eq 1 || exit 64
receipt_sha=$1
test -d "$scratch" && test -z "$(ls -A "$scratch")" || exit 65
mkdir "$scratch/home" || exit 66
timeout --signal=TERM --kill-after=5 75 env -i PATH=/usr/bin:/bin HOME="$scratch/home" LANG=C LC_ALL=C \
  /usr/bin/python3 -I -S -B "$packet/prepare-inputs.py" --input "$inputs" --output "$scratch/preparation" \
  >"$scratch/preparation.stdout" 2>"$scratch/preparation.stderr"
rc=$?
printf '%s\n' "$rc" >"$scratch/preparation.rc"
if test "$rc" -ne 0; then exit "$rc"; fi
timeout --signal=TERM --kill-after=5 70 env -i PATH=/usr/bin:/bin HOME="$scratch/home" LANG=C LC_ALL=C \
  /usr/bin/python3 -I -B "$packet/installed-check.py" --verification "$receipt" \
  --verification-sha256 "$receipt_sha" --fixtures "$scratch/preparation" --output "$scratch/installed" \
  >"$scratch/installed.stdout" 2>"$scratch/installed.stderr"
rc=$?
printf '%s\n' "$rc" >"$scratch/installed.rc"
exit "$rc"

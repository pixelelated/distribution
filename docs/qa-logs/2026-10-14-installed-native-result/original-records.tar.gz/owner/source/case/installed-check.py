#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""UNRUN: four hashes through installed bytecode and normal installed native loading."""
import argparse
import hashlib
import importlib.machinery
import json
import os
from pathlib import Path, PurePosixPath
import resource
import signal
import stat
import sys
import time

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def link_chain(path):
    pending = list(PurePosixPath(path).parts[1:]); done = []; links = []
    while pending:
        part = pending.pop(0)
        if part in ('', '.'):
            continue
        if part == '..':
            require(done, 'link escapes image root'); done.pop(); continue
        candidate = '/' + '/'.join(done + [part])
        if os.path.islink(candidate):
            target = os.readlink(candidate)
            links.append({'path': candidate, 'target': target})
            require(len(links) <= 40, 'link loop')
            target_path = PurePosixPath(target)
            if target_path.is_absolute():
                done = []; pending = list(target_path.parts[1:]) + pending
            else:
                pending = list(target_path.parts) + pending
        else:
            done.append(part)
    return {'resolved': '/' + '/'.join(done), 'links': links}

p = argparse.ArgumentParser()
p.add_argument('--verification', type=Path, required=True)
p.add_argument('--verification-sha256', required=True)
p.add_argument('--fixtures', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
a.output.mkdir(mode=0o700)
started = time.monotonic()
result = {'status': 'FAIL', 'scope': 'installed bytecode/native ISO/NONE/Zstd/CHD continuation; no gameplay or Wii AES data proof', 'hashes': []}
try:
    require(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.no_site, 'use installed Python -I -B, not -S')
    require(os.uname().machine == 'x86_64' and os.geteuid() == 0, 'disposable x86_64 root guest required')
    require(sorted(x.name for x in Path('/sys/class/net').iterdir()) == ['lo'], 'no-NIC guest required')
    require(not any(k.startswith(('LD_', 'PYTHON', 'RAOFFLINEPROXY_')) for k in os.environ), 'no loader/Python/native override')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2, 8 * 1024**2))
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    signal.alarm(60)
    require(sha(a.verification) == a.verification_sha256, 'reviewed final receipt changed')
    verification = json.loads(a.verification.read_text())
    require(verification['status'] == 'PASS' and verification['source'] == 'd6a87f05c1935516115b2cca1af22151a0209224', 'wrong final source/receipt')
    products = verification['products']
    result.update(verification_sha256=a.verification_sha256, system=verification['payload']['SYSTEM'], source=verification['source'], es_commit=verification['es_commit'], boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(), pid=os.getpid())
    checked = {}
    def installed(name):
        if name in checked:
            return checked[name]
        row = products[name]; f = Path('/') / name
        observed = {'bytes': f.stat().st_size, 'sha256': sha(f), 'mode': stat.filemode(f.stat().st_mode), 'link_chain': link_chain(str(f))}
        require(observed == row, 'installed/SYSTEM mismatch: ' + name)
        checked[name] = observed
        return observed
    for name in ('etc/os-release', 'usr/bin/python3', 'usr/lib/libraproxy_rchash.so', 'usr/lib/libzstd.so.1', 'usr/lib/libcrypto.so.3'):
        installed(name)
    require(Path(sys.executable).resolve() == Path('/usr/bin/python3').resolve(), 'wrong interpreter')
    prefix = 'usr/lib/python3.14/site-packages/raofflineproxy/'
    expected = {n for n in products if n.startswith(prefix)}
    observed = {str(f).lstrip('/') for f in Path('/' + prefix).rglob('*') if f.is_file() and not f.is_symlink()}
    require(expected == observed and expected and all(n.endswith('.pyc') for n in expected), 'installed bytecode path-set differs')
    for name in sorted(expected):
        installed(name)
    # Ordinary site-packages lookup. No sys.path edit, prepared source or CDLL/find_library substitution.
    from raofflineproxy import rom_hashing, native_codecs
    binding = json.loads((Path(__file__).parent / 'inputs.json').read_text())
    preparation = json.loads((a.fixtures / 'preparation-result.json').read_text())
    require(preparation['status'] == 'PASS', 'input preparation did not pass')
    result['preparation_sha256'] = sha(a.fixtures / 'preparation-result.json')
    for name, row in binding['hash_inputs'].items():
        f = a.fixtures / name
        require(sha(f) == row['sha256'], 'fixture differs: ' + name)
        answer = rom_hashing.hash_rom_candidates_result(f)
        result['hashes'].append({'name': name, 'sha256': sha(f), 'candidates': answer.candidates, 'error': answer.error})
        require(answer.error is None and answer.candidates == [row['expected']], 'native hash failed: ' + name)
    require(rom_hashing._LIBRCHASH is not None and native_codecs._zstd_cache is not None, 'native hash/Zstd was not used')
    # Same limited crypto load/export probe as accepted native integration; no Wii data claim.
    native_codecs._crypto()
    maps = Path('/proc/self/maps').read_text()
    (a.output / 'native-maps.txt').write_text(maps)
    mapped = {line.split(None, 5)[5] for line in maps.splitlines() if len(line.split(None, 5)) == 6 and line.split(None, 5)[5].startswith('/')}
    for name in ('usr/lib/libraproxy_rchash.so', 'usr/lib/libzstd.so.1', 'usr/lib/libcrypto.so.3'):
        require(str((Path('/') / name).resolve()) in mapped, 'installed library absent from actual maps: ' + name)
    result['library_names'] = {'rchash': rom_hashing._LIBRCHASH._name, 'zstd': native_codecs._zstd_cache._name, 'crypto': native_codecs._crypto_cache._name}
    result['modules'] = {}
    for name, module in sorted(sys.modules.items()):
        if name == 'raofflineproxy' or name.startswith('raofflineproxy.'):
            origin = Path(module.__file__)
            require(isinstance(module.__loader__, importlib.machinery.SourcelessFileLoader), 'module did not load installed bytecode: ' + name)
            require(str(origin).lstrip('/') in expected, 'noninstalled module: ' + name)
            result['modules'][name] = {'path': str(origin), 'sha256': sha(origin)}
    result.update(status='PASS', installed=checked, native_maps_sha256=sha(a.output / 'native-maps.txt'))
except BaseException as exc:
    result['error'] = repr(exc)
    raise
finally:
    signal.alarm(0)
    result['elapsed'] = time.monotonic() - started
    (a.output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

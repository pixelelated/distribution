#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""UNRUN: recreate only the retired Saturn input with the accepted native tools."""
import argparse
import json
import os
from pathlib import Path
import resource
import shutil
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from bounded import run, sha, require

p = argparse.ArgumentParser()
p.add_argument('--input', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
require(os.uname().machine == 'x86_64', 'target x86_64 guest required')
require(sorted(x.name for x in Path('/sys/class/net').iterdir()) == ['lo'], 'no-NIC guest required')
require(os.statvfs(a.input).f_flag & os.ST_RDONLY, 'public input must be read-only')
a.output.mkdir(mode=0o700)
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024**2, 64 * 1024**2))
binding = json.loads((Path(__file__).parent / 'inputs.json').read_text())
result = {'status': 'FAIL', 'scope': 'deterministic fixture preparation only', 'calls': []}
try:
    for name, row in binding['staged'].items():
        f = a.input / name
        require(f.resolve() == f and f.is_file() and f.stat().st_size == row['bytes'] and sha(f) == row['sha256'], 'input changed: ' + name)
    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
           'HOME': str(a.output), 'TMPDIR': str(a.output),
           'LD_LIBRARY_PATH': str(a.input / 'sanitizers'),
           'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1:abort_on_error=1',
           'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
    # No RLIMIT_AS: the accepted writer uses ASan's large virtual shadow.
    receipt, stdout, stderr = run(a.output, 'writer', [a.input / 'writer', a.output / 'writer-files'], 30, env, a.output)
    result['calls'].append(receipt)
    require(receipt['returncode'] == 0 and not stderr, 'writer original failure/diagnostic')
    for name in ('saturn.iso', 'saturn.bin', 'saturn.cue'):
        require(sha(a.output / 'writer-files' / name) == binding['saturn_sources'][name], 'writer output differs: ' + name)
    # The converter is a QA input author, not an installed product under test.
    env = {k: v for k, v in env.items() if k not in ('LD_LIBRARY_PATH', 'ASAN_OPTIONS', 'UBSAN_OPTIONS')}
    bundle = a.input / 'chdman-closure'
    argv = [bundle / 'ld-linux-x86-64.so.2', '--library-path', bundle / 'lib', bundle / 'chdman',
            'createcd', '-i', a.output / 'writer-files/saturn.cue', '-o', a.output / 'saturn.chd', '-c', 'none', '-np', '1']
    receipt, stdout, stderr = run(a.output, 'chd-create', argv, 30, env, a.output)
    result['calls'].append(receipt)
    require(receipt['returncode'] == 0, 'converter original failure')
    # chdman progress on stderr is retained, as in the accepted experiment.
    for name in ('synthetic.iso', 'dolphin-none.rvz', 'dolphin-zstd.rvz'):
        shutil.copyfile(a.input / name, a.output / name)
    result['fixtures'] = {}
    for name, row in binding['hash_inputs'].items():
        f = a.output / name
        require(sha(f) == row['sha256'], 'final fixture differs: ' + name)
        result['fixtures'][name] = {'sha256': sha(f), 'bytes': f.stat().st_size}
    result['status'] = 'PASS'
except BaseException as exc:
    result['error'] = repr(exc)
    raise
finally:
    (a.output / 'preparation-result.json').write_text(json.dumps(result, indent=2) + '\n')

#!/bin/sh
set -eu
mkdir /tmp/pix-output/steam
mkdir /run/pix582-scratch
mount -t tmpfs -o size=3G,mode=700,nosuid,nodev tmpfs /run/pix582-scratch
set +e
TMPDIR=/run/pix582-scratch timeout --signal=TERM --kill-after=10s 120s python3 -I -S -B /tmp/pix-input/docs/qa-logs/2026-10-14-steam-client-corrections-source/fixture.py --disposable-vm --case fresh-client-real-root --installer '/tmp/pix-input/projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh' --output /run/pix582-scratch/fresh-client-02 > /tmp/pix-output/steam/stdout 2> /tmp/pix-output/steam/stderr
rc=$?
printf '%s\n' "$rc" > /tmp/pix-output/steam/original.rc
set -e
if test -d /run/pix582-scratch/fresh-client-02; then
 tar -czf /tmp/pix-output/steam/fixture-records.tar.gz --exclude='fresh-client-02/rootfs' --exclude='fresh-client-02/storage' --exclude='fresh-client-02/tmp' --exclude='fresh-client-02/qa/payloads' -C /run/pix582-scratch fresh-client-02
fi
sync
umount /run/pix582-scratch
printf 'PIX582_CALLER_RC:%s\n' "$rc"
test "$rc" -eq 0

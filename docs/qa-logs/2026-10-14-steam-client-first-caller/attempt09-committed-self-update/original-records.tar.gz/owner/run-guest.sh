#!/bin/sh
set -eu
mkdir /tmp/pix-output/steam
mkdir /run/pix582-scratch
mount -t tmpfs -o size=3G,mode=700,nosuid,nodev tmpfs /run/pix582-scratch
set +e
TMPDIR=/run/pix582-scratch timeout --signal=TERM --kill-after=10s 120s python3 -I -S -B /tmp/pix-input/docs/qa-logs/2026-10-14-steam-client-corrections-source/fixture.py --disposable-vm --case committed-self-update-retry --installer '/tmp/pix-input/projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh' --output /run/pix582-scratch/committed-self-update-retry-09 > /tmp/pix-output/steam/stdout 2> /tmp/pix-output/steam/stderr
pxrc=$?
printf '%s\n' "$pxrc" > /tmp/pix-output/steam/original.rc
set -e
if test -d /run/pix582-scratch/committed-self-update-retry-09; then
  tar -czf /tmp/pix-output/steam/fixture-records.tar.gz --exclude='committed-self-update-retry-09/rootfs' --exclude='committed-self-update-retry-09/storage' --exclude='committed-self-update-retry-09/tmp' --exclude='committed-self-update-retry-09/qa/payloads' -C /run/pix582-scratch committed-self-update-retry-09
fi
sync
umount /run/pix582-scratch
printf 'PIX582_CALLER_RC:%s\n' "$pxrc"
test "$pxrc" -eq 0

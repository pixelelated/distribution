#!/usr/bin/env python3
"""UNRUN source preparation only; no scope, compiler, author or allocation."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(f):
    with f.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def write(f,value):f.write_text(json.dumps(value,indent=2)+'\n')
p=argparse.ArgumentParser();p.add_argument('--checkout',type=Path,required=True);p.add_argument('--owner',type=Path,required=True);a=p.parse_args()
tree=a.checkout.resolve(strict=True);out=a.owner.absolute()
assert out.parent==Path('/workspace/tmp') and re.fullmatch('pix[a-z0-9-]{1,60}',out.name) and not out.exists()
for line in (HERE/'SHA256SUMS').read_text().splitlines():
    h,n=line.split('  ',1);assert sha(HERE/n)==h
commit=subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True).strip();assert commit=='d6a87f05c1935516115b2cca1af22151a0209224'
out.mkdir(mode=0o700)
for name in ['records','logs','scan','source','scratch','artifacts','lifecycle-owner']:(out/name).mkdir()
for name in ['owner.py','work.py','census.py','close.py','inputs.json']:shutil.copy2(HERE/name,out/name)
binding=json.loads((out/'inputs.json').read_text())
for path,row in binding['files'].items():assert Path(path).is_file() and Path(path).stat().st_size==row['bytes']
source=Path(binding['tool_plan'])/'build-tool.sh';shutil.copy2(source,out/'source/build-tool.sh')
config={'checkout':str(tree),'commit':commit,'scope_unit':out.name+'.scope','code':{n:sha(out/n) for n in ['owner.py','work.py','census.py','close.py','inputs.json','source/build-tool.sh']},'family_seconds':800,'cleanup_seconds':30,'memory_bytes':4*1024**3,'scratch_bytes':2*1024**3}
write(out/'config.json',config)
write(out/'retention-plan.json',{'volume':'/workspace','scan_roots':[str(out/'scan')],'reference_stores':[],'protected':[str(HERE),str(out/'records'),str(out/'source'),binding['tool_plan'],binding['game_root'],str(tree/'tools/host-maintenance')],'candidates':[],
 'builds':[{'name':'m7-native-save-tool','terms_bytes':{'private_work_and_disc':2*1024**3,'records':128*1024**2},'basis':'One native host tool build600s then CDI author120s, no tests/install. Existing user scope kernel4GiB memory/no swap/1CPU/128tasks; private2GiB scratch polled each second; compiler256MiB per-file, author1GiB per-file, named logs16MiB monitored. Full family800s+30s cleanup.',
 'evidence':[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','inputs.json','owner.py','work.py','census.py','close.py','source/build-tool.sh']]}]})
write(out/'admission-plan.json',{'checkout':str(tree),'retention_plan':str(out/'retention-plan.json'),'retention_report':str(out/'retention-report.json'),'stage':'m7-native-save-tool',
 'profiles':[{'PROJECT':'ROCKNIX','DEVICE':'GENERIC_X64','ARCH':'x86_64'}],
 'outputs':[{'path':str(out/'scratch'),'issue':575,'kind':'qa-scratch','release_when':'Original build/author/scope/watcher channels reviewed and consumed; retain tool/CDI/licenses/inputs hashes before retiring private compilation and temporary authoring state.'},{'path':str(out/'artifacts'),'issue':575,'kind':'qa-scratch','release_when':'Tool and authored CDI retained for the pending installed native save fixture, then retire after that owner is consumed.'}]})
print(json.dumps({'status':'PREPARED_UNRUN','owner':str(out),'scope_unit':config['scope_unit']}))

# #528 shader provenance follow-up — source only

This finite follow-up resolves exact source associations and preferred-source locators. It does **not** establish a new grant for the MAME/Shadertoy adaptation or add an explicit image-specific declaration for the four Koko JPEGs. It changes no product, original evidence, tracker or shared file. NC distribution policy remains a separate owner/scope decision.

The allocation was at most 12 primary public text/API reads, at most 2 MiB per body and 12 MiB total. Actual: **12 HTTP response bodies, 228,665 bytes total**, with 11 HTTP 200 responses and one retained HTTP 403 from the cited Shadertoy page. No archive, image, binary or other payload was downloaded; source-file text and Git object/directory/commit metadata only. Initial sandbox DNS failure is recorded separately from the successful actual-host reads. No collector, target, VM, container, service, test, upstream contact or product execution occurred.

`public-read-index.json` and the twelve original `.receipt.json` files preserve exact URLs, retrieval UTC timestamps, response status/headers, byte counts and SHA256. Full small response bodies are retained; three API blob responses are also decoded as text with their Git blob identities checked. Mutable branch reads remain dated observations bound to returned immutable tree/blob IDs; a tree ID is not mislabeled as a commit. `retained-inputs.json` binds the prior accepted disposition and selected exact retained texts by original metadata.

Read `findings.md` for the decision-ready result. The machine-readable joins are:

- `mame-applicability.json`: exact selected bytes → original introduction Git blob; current upstream BSD declaration is kept separate from that adaptation.
- `koko-image-identity.json`: four exact pinned Slang image objects → current Koko main → Koko backup; current Koko GPL text matches the already-retained full GPL3 bytes.
- `koko-preferred-source-locators.json`: six exact upstream objects for monitor and handheld editing sources, without acquisition/unpacking claims.

This packet does not search every held cache or claim those editing sources are absent everywhere. The accepted shader source record itself names the Slang archive, not these separate objects. No blanket licence, publication-completeness or legal-clearance claim is made. No feature removal or rebuild is selected.

# Findings and smallest remaining choices

## MAME-derived shader: exact history resolved; adaptation grant still unresolved

The shipped Slang member `ntsc/shaders/mame-ntsc/mame-ntsc.slang` has SHA256 `d13f34cdae1fc0c9a2aa3b28da1dd9125f56c984441740b69a9baea4a63fb373` and Git blob `1ad009865f6449153eee121b6d08c81b6ffa78a4`. The latter is calculated from the accepted complete source bytes and exactly equals the file added by hunterk on **2017-07-25**, commit `0f247809e2eb83271ce4c6787a9d123a0f3193f8`. The original introduction already included the uncertain “presumably” licence line. The exact-path upstream history response contains that one commit. [Original introduction](https://github.com/libretro/slang-shaders/commit/0f247809e2eb83271ce4c6787a9d123a0f3193f8).

Current official MAME `hlsl/ntsc.fx`, Git blob `89cf5880d5704f6469c3330584da6af9710e76a9`, explicitly states `BSD-3-Clause` and names Ryan Holtz and ImJezze. Its complete 7,312-byte text is retained as `08-mame-ntsc-source.txt`. This is useful current primary evidence, but it is not the exact selected Slang source and does not itself state a grant for the intervening Shadertoy adaptation. [Exact official MAME source object](https://api.github.com/repos/mamedev/mame/git/blobs/89cf5880d5704f6469c3330584da6af9710e76a9).

The selected shader expressly cites UltraMoogleMan's `Full MAME/MESS Shader Pipe`, [Shadertoy ldf3Rf](https://www.shadertoy.com/view/ldf3Rf). The direct public read returned HTTP 403; the exact response is retained. No Shadertoy default licence, authorship equivalence or permission is inferred from that refusal.

**Smallest remaining choice:** obtain an explicit applicable declaration for this exact port from already-held material or the named upstream authors/source. Contact has not been authorized or performed here. If that cannot settle the grant, the owner can choose a narrowly scoped replacement derived from clearly declared source while preserving the feature; that would be a separate product change with its own validation. Merely replacing the comment with current MAME's BSD label would not resolve the recorded adaptation question. This is one shader/port provenance item, not a new whole-MAME or whole-Slang audit.

## Koko four-image identity: resolved at exact Git object level

For `gamegear.jpg`, `gba.jpg`, `gbc.jpg` and `gbm.jpg`, the exact pinned Slang metadata at commit `4812a82f6c9a11cc8b5a7447040a98c9fc80c00e` matches both current Koko main `textures/overlays/` and Koko misc `misc/overlay_backup/` in **Git blob ID and size**. The accepted source/package/staged records supply the selected SHA256 values; this task did not fetch images again. [Exact pinned Slang directory](https://api.github.com/repos/libretro/slang-shaders/contents/bezel/koko-aio/textures/overlays?ref=4812a82f6c9a11cc8b5a7447040a98c9fc80c00e).

| Exact image | Git blob in all three primary metadata sets | Bytes | Accepted selected SHA256 |
| --- | --- | ---: | --- |
| gamegear.jpg | `3b719a9420d51b8269080d3a3207e6c7f6f8081c` | 506,987 | `88e0fc32e169bcff105982fa4a8f07f3476434b4f3abc056105f417b73df899d` |
| gba.jpg | `a157477232cb2841cc1c73cfceba2665333956ec` | 508,585 | `f87aef1702bfd9602dc1f73c0b606eae1c36e86fc567ada63be57cd31fb32032` |
| gbc.jpg | `5c5c0c130254bdc7478cf6ffea2a3c0aa093c8ec` | 499,717 | `af9e34e0cb34238c5b97705a3711b21e4dff4573f115f327fa91e2e1f6b2cd28` |
| gbm.jpg | `02f27782caff13d4b4df71ab4ced23025e2ba416` | 476,181 | `b1f5379a470c8d5846e002979c21c870dc06fb27d574976e43aa991fa00800a7` |

Koko's current main `LICENSE` Git blob `f288702d2fa16d3cdf0035b15a9fcbc552cd88e7` equals the already-retained complete GPL3 text (`3972dc97…`). There is a real supplied subproject licence; absence of four individual sidecars is not proof that the images are unlicensed. The current main README describes the shader and links additional artwork but supplies no new explicit four-image authorship/grant statement. The three previously retained PSP/Game Boy Pocket/Lynx sidecars remain distinct exceptions and are not reassigned to these images. [Koko current main tree metadata](https://api.github.com/repos/kokoko3k/koko-aio-slang/git/trees/e474fe53ad978f878524f808cbaa40a3c6dbbb9c).

**Smallest remaining scope choice:** retain these four as identified Koko subproject content, full source and supplied GPL/credits, if the owner accepts that documented project scope; or obtain a precise asset-scope clarification. This evidence finds no contrary four-image terms that require removal. It does not manufacture a new image-specific grant or silently turn absence of a sidecar into a release gate.

## Koko preferred editing sources: concrete objects located; not yet acquired by this task

The retained `docs-ng.md` explicitly points to Koko's misc repository for texture sources and the monitor-frame GIMP project. Its current complete README confirms that repository holds those source projects. The nontruncated current tree is `ae000e5079fc4d108314e33c89b49d38810accde`. Exact objects are below; these are metadata locators only. [Official misc tree](https://api.github.com/repos/kokoko3k/koko-aio-slang-misc/git/trees/ae000e5079fc4d108314e33c89b49d38810accde?recursive=1).

| Named object under `misc/texture_sources/` | Git blob | Bytes | Applicability |
| --- | --- | ---: | --- |
| monitor_body_source.7z | `628b4281e8e6e85392b59d1e6f0656097628e7d9` | 22,816,420 | Named monitor-frame editing-source candidate; retained docs identify the GIMP source, but archive contents were not opened here. |
| gamegear_overlay.7z | `5bec2b7ed6468a26b73183b95628473bfbcfd181` | 9,384,079 | Named handheld source project, also exactly the Git blob introduced in Koko main in 2023. |
| gamegear_overlay.xcf | `cacb9d76376ee3a49d609bc554be384863f1fa7f` | 17,528,707 | Loose GIMP source candidate; no assertion it duplicates the archive contents. |
| gba_overlay.7z | `cb67686878b97df38a0df12de13922111c2c895a` | 10,133,553 | Named GBA source project; contents and any embedded credits remain unread. |
| gbm_overlay.7z | `8aa1eb58552b0a1f32345f00e4f65b71a34a484b` | 1,655,331 | Named GBM source project; contents and any embedded credits remain unread. |
| gbc_overlay.png | `bf8b294937ef16e8222667605bfc7fac89dfae74` | 3,066,648 | Named GBC source image; no claim that it is the preferred editable original. |

The [2023 Game Gear introduction](https://github.com/kokoko3k/koko-aio-slang/commit/e9eae77644e47fe06adb5047ada9659866823069) directly added the gamegear source archive and a preset pointing to its overlay. It also moved the GBA/GBM image paths. The currently selected images are later black-level-adjusted blobs; the retained overlay history records those February 2025 adjustments. No reproduction of a JPEG from an editing project is claimed.

The misc tree has a README and no root LICENSE/COPYING/NOTICE member. That observation does not erase the main project's licence, but the misc README itself supplies no new permission wording. Current accepted shader source records bind the Slang source archive, not proof of these separate source-project holdings.

**Smallest next custody action:** first match these exact object identities against any already-held material using its existing manifest, without a new broad scan. Where genuinely absent, an owner-allocated allowlist acquisition can retain only the named source objects and inspect embedded source/attribution. The five-item set excluding the loose Game Gear XCF totals **47,056,031 bytes**; whether the XCF instead of or as well as its archive is needed follows the source contents, not a requirement to download both. Archive contents, source-to-JPEG derivation and embedded notices are intentionally unclaimed. This is the existing corresponding-source question, not a new universal reproducibility gate.

No product changes, functionality removal, upstream contact, legal clearance or #528 criterion closure are proposed by this source-only packet. The shared NC distribution-scope decision remains separate.

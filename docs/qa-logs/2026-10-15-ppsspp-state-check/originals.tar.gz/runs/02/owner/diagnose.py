import runpy,sys,json
from pathlib import Path
T=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/tools/pixelelated-state-check-test')
m=runpy.run_path(str(T),run_name='fixture_diagnostic')
def trace(frame,event,arg):
 if event=='exception' and frame.f_code.co_filename==str(T):
  row={'function':frame.f_code.co_name,'line':frame.f_lineno,'exception_type':arg[0].__name__}
  if frame.f_code.co_name=='case':row['fixture_case']=frame.f_locals.get('name')
  if frame.f_code.co_name=='invoke':
   row['expected_rc']=frame.f_locals.get('expected');p=frame.f_locals.get('p');row['actual_rc']=p.returncode if p else None
  print(json.dumps(row),flush=True)
 return trace
sys.argv=[str(T),'--payload-tests'];sys.settrace(trace)
try:rc=m['main']()
except Exception:rc=2
finally:sys.settrace(None)
sys.exit(rc)

# #599 PPSSPP selected-state reader correction — source handoff

Only coordinator `tools/pixelelated-state-check` and `tools/pixelelated-state-check-test` were changed. Both are released for root's bounded allocation. No frozen f863 checkout, package, product, original owner or receipt was changed. No gate or test was imported/executed; source checks were AST parsing and textual inventory only. Root separately retains and consumes original failed H700 acceptance21f58942.

## Cause and second relevant gap

The generic `pairs()` key regex disallowed whitespace inside keys. All 14 checked-in PPSSPP profile defaults use the valid key `Enable Logging` at line4; the observed H700 payload reached exactly that parser refusal. The complete default files were inspected as source: no second rejected key shape or conflicting duplicate was found. `shipped-default-source-inventory.json` records every file and its exact public source hash. This inventory is not a successful checker run.

PPSSPP also uses case-insensitive `[Achievements]` keys `AchievementsUserName` and `AchievementsToken`; the token normally lives in the already covered opaque `.dat` file, but PPSSPP supports manual INI token loading. The previous generic classifier missed both prefixed keys. The patch assigns PPSSPP its own existing-policy kind, permits internal spaces/tabs only for that kind, recognizes the two actual account keys in the exact section, and retains duplicate/include/recovery-sibling/privacy gates. It does not remove significant internal spaces from keys or section names. Single quotes remain literal for PPSSPP, as upstream only strips double quotes; an apparent `''` account cannot become falsely empty.

The parser remains an explicit, conservative subset. Escaped/comment-bearing keys and ambiguous double quotes refuse. It is not a general PPSSPP serializer or a whole-config secret scanner. Other config grammars and retained-upgrade policy remain unchanged. Account values, arbitrary keys and content hashes never enter the public policy report.

## Source and upstream comparison (2026-10-15)

Frozen package pin: afbc66a318b86432642b532c575241f3716642ef, recipe labelled v1.20.2. The pinned unpacked `Common/Data/Format/IniFile.cpp`, `Common/StringUtils.cpp`, and `Core/Config.cpp` are retained under pinned-source/ with original license headers. ParseLineKey trims outer whitespace and preserves internal whitespace; section/key lookup is case-insensitive, internal section spaces remain significant, and StripQuotes removes double quotes only. Config.cpp declares the spaced setting and exact account keys. Local H700 defaults trace to inherited upstream commit9f1fab30f6; the strict checker parser originated in fork-only d9f428e1a0.

The latest stable release observed is [v1.20.4](https://github.com/hrydgard/ppsspp/releases/tag/v1.20.4); its [release notes](https://www.ppsspp.org/news/release-1.20.4/) do not identify a matching fix for this fork reader. The [v1.20.4 INI parser](https://raw.githubusercontent.com/hrydgard/ppsspp/v1.20.4/Common/Data/Format/IniFile.cpp) already supports internal key whitespace, and [v1.20.4 configuration declarations](https://raw.githubusercontent.com/hrydgard/ppsspp/v1.20.4/Core/Config.cpp) retain the same spaced setting and account keys. Current [master parser](https://raw.githubusercontent.com/hrydgard/ppsspp/master/Common/Data/Format/IniFile.cpp) and [master configuration](https://github.com/hrydgard/ppsspp/blob/master/Core/Config.cpp) show the same relevant contract. This is a fork-owned policy-reader correction; a PPSSPP upgrade does not fix it, and no PPSSPP source contribution is indicated by this finding.

Bounded public searches checked PPSSPP issues/PRs for IniFile whitespace/spaces and ROCKNIX issues for PPSSPP INI symptoms. No matching reader fix was found; search results concerned different texture/storage/runtime issues. Direct GitHub API issue/history endpoints and one ROCKNIX raw-default request were inaccessible through the browsing tool. This is a recorded lookup limit, not a claim of exhaustive upstream clearance. ROCKNIX intent is additionally grounded in the locally retained inherited defaults and source history. No issue/comment/PR was submitted by this worker.

## Fixtures and allocation

The existing harness now copies every public `*/ppsspp.ini` default into a disposable fixture: all14 current profiles, including H700 and SM8550, with their full original contents. Synthetic controls cover BOM/CRLF, mixed case, tabs, significant spaces, both account keys in default/runtime locations, duplicate conflicts in both orders and repeated sections, identical repeats, quote semantics, malformed keys, include/reference refusal, dynamic recovery siblings, retained policy, privacy and unchanged strictness for another emulator. Existing opaque `.dat` and other controls remain.

Root may run the existing full suite once from coordinator, with a fresh private TMPDIR under its own fixture owner:

```bash
TMPDIR=<fresh-owned-scratch> tools/watch-build --record-only -- timeout --signal=TERM --kill-after=10s 300s python3 -I -B tools/pixelelated-state-check-test --payload-tests
```

Expected fixture scratch: `pix565-controls-*` beneath that TMPDIR. The harness removes it normally and each reader subprocess has its existing45s bound. A timeout or nonzero remains an original failure, and any scratch remainder needs root's scoped custody. This is a host-tool/synthetic filesystem proof, with no VM, compiler or target executable required. The actual H700 update TAR must then be read by the exact new checker SHA under a fresh root-owned watcher. No test outcome is claimed here.

Next H700 acceptance and SM source packets must bind this approved tool separately from frozen productf863. Keep the existing immutable product/source bindings and previous failure receipts; use an exact copied checker path/hash for the selected-state CLI, not an edit to the frozen tool or original owner. The Local/Squash helper implementation used by additional mappings is unchanged by this patch. Root owns integration, tracker, commit, test allocation and all acceptance.

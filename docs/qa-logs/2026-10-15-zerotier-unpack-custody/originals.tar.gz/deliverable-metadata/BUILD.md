This is ZeroTierOne 1.16.0 client source selected and modified for pixelelated.
It is not the original upstream archive. The separately licensed nonfree/
controller subtree is absent. The accompanying manifest binds every retained
file and raw symlink target, the original archive, and the applied patch.
All other upstream files, including LICENSE.txt, LICENSE-MPL.txt, and ext/
license and notice files, are retained unchanged. ext/ components have their
own terms; the core MPL-2.0 label is not an assertion about every bundled file.

Upstream: https://github.com/zerotier/ZeroTierOne/archive/refs/tags/1.16.0.tar.gz
Original archive SHA256:
aa9de313d365bf0efb3871aaa56f2d323a08f46df47b627c4eff4f4203fa7fc5
Applied patch SHA256:
5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5
The accompanying package.mk is the exact adopted distribution recipe.
Its normal source input remains the original upstream archive; its unpack()
hook omits nonfree/ and the distribution patch phase applies the patch once.
The filtered tar already contains the patch: do not apply it a second time.

For a local build from the extracted filtered tar, set the same target CC,
CXX, AR, AS, CFLAGS, CXXFLAGS, CPPFLAGS, LDFLAGS and LDLIBS as the distribution
toolchain. The package's two build steps are:

    make -C ext/libnatpmp CC="$CC"
    CPPFLAGS="$CPPFLAGS -I$PWD/ext/libnatpmp" \
      LDLIBS="$LDLIBS -L$PWD/ext/libnatpmp" \
      make -f make-linux.mk ZT_SSO_SUPPORTED=0 one

The distribution package also declares toolchain and nlohmann-json. The
accepted GENERIC_X64 proof compiled these exact source bytes with the pinned
distribution toolchain; its original command/dependency receipts are bound
by manifest.json. This custody step itself does not compile or run a target.
It does not provide a new image, public download, off-host copy, or a blanket
licensing determination. This source selection does not require retaining a
whole compiler closure as an additional gate.

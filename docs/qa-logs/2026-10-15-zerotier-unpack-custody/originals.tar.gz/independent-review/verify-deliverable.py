from pathlib import Path
import datetime,hashlib,json,stat,tarfile
out=Path('/tmp/pix-m7-zerotier-unpack-independent-20261015')
packet=Path('/tmp/pix-m7-zerotier-unpack-custody-plan-20261015-01')
owner=Path('/workspace/tmp/pix-m7-zerotier-source-custody-20261015-01')
stage=owner/'stages/zerotier-source-custody'
run=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T160042Z-e5dbbb7d')
deliverable=owner/'work/deliverable'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
r=read(stage/'result.json');inner=read(stage/'container-result.json');runner=read(run/'runner-result.json');consumed=read(run/'admission-consumed.json');launch=read(stage/'submit/launcher-result.json');completion=read(stage/'completion-evidence.json')
assert r['status']=='PASS' and all(type(r[k]) is int and r[k]==0 for k in ['original_attach_exit','original_container_exit','watchdog_original_exit'])
assert r['cleanup']['status']=='PASS' and not r['cleanup']['forced_stop'] and not r['cleanup']['survivors'] and r['cleanup']['exact_id_absent'] and not r.get('forced_client_stop')
assert inner['status']=='PASS' and not inner['monitor_errors'] and inner['sampler_exited']
assert [x['label'] for x in inner['children']]==['archive-precheck','package-unpack','source-custody']
assert all(type(x['original_exit']) is int and x['original_exit']==0 and x['reaped'] and not x.get('forced_group_stop') for x in inner['children'])
assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert launch['runner_returncode']==0 and (stage/'submit/tool-wrapper.rc').read_bytes()==b'0\n'
assert consumed['state']=='consumed' and consumed['id']=='73fc106aa55d48c69633210a84cc6bbe' and consumed['original_result']==runner and consumed['evidence_sha256']==sha(stage/'completion-evidence.json')
for e in completion['evidence']:assert sha(Path(e['path']))==e['sha256'],e['path']
for prefix in ['prepare','preflight','report','admit','launch','completion','consume']:
 x=read(Path('/tmp/pix-m7-zerotier-unpack-coordinator-20261015')/(prefix+'.exit.json'));assert list(x.values())==[0],(prefix,x)
for runid in ['20261015T155943Z-7c61c029','20261015T160005Z-0d34d258']:
 x=read(run.parent/runid/'runner-result.json');assert all(x[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
manifest=read(deliverable/'manifest.json');receipt=read(stage/'filtered-source.json');before=read(packet/'source-before.json');index=read(packet/'archive-index.json')
assert sha(deliverable/'manifest.json')==receipt['manifest_sha256']
archive=deliverable/manifest['archive']['name'];original_stat=archive.stat()
assert archive.stat().st_size==manifest['archive']['bytes']==14194934
assert sha(archive)==manifest['archive']['sha256']=='10273d138a6c3c4d74468550965e06886f0b094167a7a0e23be157453e8a762a'
assert manifest['upstream_archive']['sha256']=='aa9de313d365bf0efb3871aaa56f2d323a08f46df47b627c4eff4f4203fa7fc5'
expected={x['name'][len('ZeroTierOne-1.16.0'):].lstrip('/'):x for x in index if not x['excluded']}
files={x['path']:x for x in before['files']};links={x['path']:x['target'] for x in before['links']};members={x['path']:x for x in manifest['members']}
assert set(members)==set(expected)-{''}
seen=set();counts={'file':0,'directory':0,'symlink':0};total=0
with tarfile.open(archive,'r|gz') as tf:
 for m in tf:
  root='ZeroTierOne-1.16.0-pixelelated-client-source'
  assert m.name==root or m.name.startswith(root+'/')
  rel=m.name[len(root):].lstrip('/');assert rel in expected and rel not in seen;seen.add(rel);e=expected[rel]
  assert m.mode==e['mode'] and m.uid==m.gid==m.mtime==0 and m.uname==m.gname==''
  assert rel!='nonfree' and not rel.startswith('nonfree/')
  if e['type']=='file':
   assert m.isfile() and m.size==files[rel]['bytes']==members[rel]['bytes']
   h=hashlib.sha256()
   with tf.extractfile(m) as stream:
    for x in iter(lambda:stream.read(1048576),b''):h.update(x)
   assert h.hexdigest()==files[rel]['sha256']==members[rel]['sha256'];counts['file']+=1;total+=m.size
  elif e['type']=='symlink':
   assert m.issym() and m.linkname==links[rel]==members[rel]['target'];counts['symlink']+=1
  else:assert m.isdir();counts['directory']+=1
assert seen==set(expected) and counts=={'file':3208,'directory':529,'symlink':5} and total==59058504
for name,row in manifest['companions'].items():assert (deliverable/name).stat().st_size==row['bytes'] and sha(deliverable/name)==row['sha256']
assert (deliverable/'package.mk').read_bytes()==(packet/'product/package.mk').read_bytes()
assert (deliverable/'001-client-without-nonfree-headers.patch').read_bytes()==(packet/'product/001-client-without-nonfree-headers.patch').read_bytes()
assert set(x.name for x in deliverable.iterdir())=={'manifest.json','BUILD.md','package.mk','001-client-without-nonfree-headers.patch',archive.name}
final_stat=archive.stat();assert all(getattr(original_stat,k)==getattr(final_stat,k) for k in ['st_dev','st_ino','st_size','st_mode','st_uid','st_gid','st_mtime_ns','st_ctime_ns'])
report={'status':'PASS_INDEPENDENT_ORIGINALS_AND_FULL_ARCHIVE_READBACK','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':str(run),'consumed_id':consumed['id'],'original_result':runner,'launcher_returncode':launch['runner_returncode'],'children':[{k:x[k] for k in ['label','original_exit','reaped']} for x in inner['children']],'cleanup':{'status':r['cleanup']['status'],'forced_stop':r['cleanup']['forced_stop'],'survivors':r['cleanup']['survivors'],'exact_id_absent':r['cleanup']['exact_id_absent']},'archive':{'path':str(archive),'bytes':final_stat.st_size,'sha256':sha(archive),'original_metadata':{k:getattr(final_stat,k) for k in ['st_mode','st_uid','st_gid','st_mtime_ns','st_ctime_ns']},'unchanged_after_read':True},'members':counts,'regular_source_bytes':total,'manifest_sha256':sha(deliverable/'manifest.json'),'product_recipe_sha256':sha(deliverable/'package.mk'),'product_patch_sha256':sha(deliverable/'001-client-without-nonfree-headers.patch'),'source_seal':sha(packet/'SHA256SUMS'),'resource_observations':{'container_memory_peak':inner['final_cgroup']['memory.peak'],'container_memory_max':inner['final_cgroup']['memory.max'],'host_final_disk':r['final_disk'],'container_final_disk':inner['final_disk'],'inner_wall_seconds':inner['ended']-inner['started']},'limits':'Original archive semantics and full retained-member identities verified locally. No compiler, service, target, external retrieval, off-host transfer or new firmware acceptance. Prior failed runs unchanged; archive/source remain at original paths.'}
(out/'independent-readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'members':len(seen),'bytes':total,'consumed_id':consumed['id']}))

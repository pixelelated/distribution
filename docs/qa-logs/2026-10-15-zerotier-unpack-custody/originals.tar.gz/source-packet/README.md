Source-only proposal, not an execution result. The exact adopted package recipe
and common patch are copied under product/ and bound to their coordinator bytes.
The frozen execution-control checkout stays f8636de1d105275dbf9420bbabbbc26f79abb10f;
the modified product HEAD is not presented as committed or image-qualified.

This single stage performs three operations in the accepted pinned, networkless
container lifecycle: precheck the original archive against its accepted complete
index; execute the recipe's unpack() and scripts/unpack's normal text-patch
command; retain and fully re-read a separately named filtered source archive.
The ordinary engine chooses custom unpack() instead of generic extraction. This
proof stops before engine stamps and configtools maintenance. It does not invoke
scripts/unpack's fetch, cleanup, stamps, configtools replacement, or any compiler.

Acceptance requires every one of the accepted 3,208 regular source files to
match its size and SHA256, and all five raw symlink targets to match. There are
529 directories including the root and 59,058,504 regular source bytes. The only
excluded upstream subtree is nonfree/: 22 indexed nodes and 278,164 regular bytes.
The exact common patch changes service/OneService.cpp to the already compiled
candidate. All other upstream bytes, including notices and ext/ content, remain.
Original archive permission modes are retained in the output tar; ordinary
extracted rw bits can reflect native tar's umask, while executable bits must
match. Output tar uid/gid/mtime are zero and raw symlinks are preserved.

The retained deliverable is fresh-owner work/deliverable/, with five files:
zerotier-one-1.16.0-pixelelated-client-source.tar.gz, manifest.json, BUILD.md,
package.mk, and 001-client-without-nonfree-headers.patch. The tar already contains
the patch. Its identity is distinct from the unchanged original upstream source
archive. manifest.json records every retained file hash and link target, modes,
the original archive, recipe/patch pins, and the accepted compile/readback refs.
The original recipe compile exit was zero; its later reader error remains a
failure in the original receipt. Reader03 independently passed and was consumed
as 2210f6a47b6a4ca1a6b380d8f3b9ad1c (run 154224Z-03885bf5).

The accepted reader03 docker_owner.py and watchdog.py are byte-identical here.
run-stage.py changes only the scratch-bound message; common.py changes the one
stage name and disk ceiling. inner.py replaces its reader calls with the three
operations above and adjusts file/disk limits for extraction. plan.py,
completion-evidence.py, and commands.sh describe the fresh owner and outputs.
lifecycle-delta.diff contains those operative differences. build-plan.json is
the narrowed input binding, not another runtime framework. source-custody.py and
unpack.sh are the new small source operation; static-review.json records finite
source parsing and live verification of the 14 small bound input copies. No
candidate helper, shell, container, extraction, control test, or compiler ran
during preparation. The upstream archive is checked again during admission/run.

Resource proposal: one 60-second work deadline, 2 CPUs, 1 GiB memory, no swap,
256 PIDs, no network, read-only container root/plan/original archive, and 64 MiB
container /tmp. Existing exact-CID/process-identity retirement remains separate
from the work deadline and preserves any failure. The 256 MiB owner ceiling is
sampled, not a filesystem quota. Prechecked extraction is limited to 4,000 nodes
and 64 MiB declared regular bytes; accepted input is 59,336,122 bytes. The output
gzip stream refuses writes beyond 96 MiB, each manifest refuses writes beyond
2 MiB, companion files are at most 16 KiB, and child RLIMIT_FSIZE is 128 MiB.
These finite allowances cover the 59 MiB source, a conservative 96 MiB archive,
and receipts with more than 90 MiB spare under the owner ceiling. Existing
bounded telemetry and cleanup receipts are retained even on failure. The tar
uses compression level 1; this is source handling only, with no build work.

Root alone allocates and supervises. Use this packet's commands.sh with the
fresh default owner /workspace/tmp/pix-m7-zerotier-source-custody-20261015-01:

    bash commands.sh prepare
    bash commands.sh preflight
    bash commands.sh report
    bash commands.sh admit
    bash commands.sh launch

After the original submitted watcher and launcher have fully closed, root
reviews original exits, resource telemetry, cleanup and the source receipt:

    bash commands.sh completion
    bash commands.sh consume

Failure requires the normal separate investigation and consumption, without
turning it into success or automatically retrying. Preserve work/deliverable
until independent custody/retrieval acceptance; temporary work/source may be
released separately after result consumption and deliverable verification.

This proof does not rebuild an image or execute ZeroTier. The next product
step, after source commit, is bounded package rebuild/install plus exact image
refresh/readback for GENERIC_X64 x86_64, H700 aarch64, and SM8550 aarch64, which
are the three accepted native profiles shipping this package. The two accepted
ARM companion profiles have no ZeroTier package row. No whole compiler closure
is introduced as a gate. Notices, release source retrieval, off-host custody,
publication, and final firmware acceptance remain their own evidence.

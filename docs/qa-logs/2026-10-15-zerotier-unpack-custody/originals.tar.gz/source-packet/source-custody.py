#!/usr/bin/env python3
"""Admitted unpack precheck and filtered source retention. Never execute source."""
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import posixpath
import stat
import sys
import tarfile
import time

PLAN = Path('/plan')
SOURCE = Path('/work/source')
OUT = Path('/work/deliverable')
RECEIPTS = Path('/receipts')
ARCHIVE = Path('/inputs/zerotier-one/zerotier-one-1.16.0.tar.gz')
PREFIX = 'ZeroTierOne-1.16.0'
DEST_PREFIX = 'ZeroTierOne-1.16.0-pixelelated-client-source'
DEST_NAME = 'zerotier-one-1.16.0-pixelelated-client-source.tar.gz'
MAX_NODES = 4000
SOURCE_LIMIT = 64 * 1024**2
ARCHIVE_LIMIT = 96 * 1024**2
MANIFEST_LIMIT = 2 * 1024**2


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(path, limit=SOURCE_LIMIT):
    require(path.is_file() and not path.is_symlink(), 'regular input required: '+str(path))
    require(path.stat().st_size <= limit, 'input byte bound: '+str(path))
    h = hashlib.sha256()
    with path.open('rb') as stream:
        total = 0
        while chunk := stream.read(1024**2):
            total += len(chunk)
            require(total <= limit, 'input changed past byte bound')
            h.update(chunk)
    return h.hexdigest()


def write(path, value, limit):
    body = (json.dumps(value, indent=2)+'\n').encode()
    require(len(body) <= limit, 'receipt bound before write: '+str(path))
    with path.open('xb') as stream:
        stream.write(body)


def load_inputs():
    binding = json.loads((PLAN/'build-plan.json').read_text())
    for name, key in [('archive-index.json','archive_index_sha256'),
                      ('source-before.json','source_before_sha256')]:
        require(digest(PLAN/name, MANIFEST_LIMIT) == binding[key], 'metadata identity changed')
    index = json.loads((PLAN/'archive-index.json').read_text())
    before = json.loads((PLAN/'source-before.json').read_text())
    require(len(index) == 3764 and len(before['files']) == 3208 and len(before['links']) == 5,
            'wrong accepted input set')
    require(before['archive_sha256'] == binding['archive_sha256'] and
            before['candidate_sha256'] == binding['candidate_sha256'], 'accepted provenance mismatch')
    return binding, index, before


def relative(name):
    p = PurePosixPath(name)
    require(str(p) == name and not p.is_absolute() and '..' not in p.parts and
            p.parts[0] == PREFIX and '\x00' not in name, 'unsafe archive path')
    return '/'.join(p.parts[1:])


def row(member):
    kind = ('file' if member.isfile() else 'directory' if member.isdir()
            else 'symlink' if member.issym() else 'unsupported')
    name = member.name.rstrip('/')
    rel = relative(name)
    return {'name':name, 'type':kind, 'bytes':member.size, 'mode':member.mode,
            'linkname':member.linkname, 'excluded':rel == 'nonfree' or rel.startswith('nonfree/')}


def precheck():
    binding, index, before = load_inputs()
    require(ARCHIVE.stat().st_size == 12023748 and digest(ARCHIVE) == binding['archive_sha256'],
            'original archive identity changed')
    names = set()
    total = 0
    count = 0
    with tarfile.open(ARCHIVE, 'r|gz') as archive:
        for member in archive:
            require(count < len(index) and count < MAX_NODES, 'too many archive nodes')
            item = row(member)
            require(item == index[count], 'archive metadata differs from accepted index')
            require(item['name'] not in names and item['type'] != 'unsupported' and
                    not item['mode'] & 0o7000, 'duplicate, special, or privileged archive node')
            names.add(item['name'])
            total += item['bytes']
            require(total <= SOURCE_LIMIT and item['bytes'] >= 0, 'source byte ceiling')
            if item['type'] == 'symlink':
                target = item['linkname']
                resolved = posixpath.normpath(posixpath.join(posixpath.dirname(item['name']), target))
                require(not target.startswith('/') and resolved.startswith(PREFIX+'/') and
                        not resolved.startswith(PREFIX+'/nonfree/'), 'unsafe source symlink')
            count += 1
    require(count == 3764 and total == 59336122, 'incomplete archive index')
    excluded = [x for x in index if x['excluded']]
    require(excluded == before['excluded'] and len(excluded) == 22 and
            sum(x['bytes'] for x in excluded) == 278164, 'wrong excluded subtree')
    retained = [x for x in index if not x['excluded']]
    links = {x['name'] for x in retained if x['type'] == 'symlink'}
    require(all(not any(str(p) in links for p in PurePosixPath(x['name']).parents)
                for x in retained), 'archive path descends through a link')
    write(RECEIPTS/'archive-index-check.json', {'status':'PASS', 'archive_sha256':binding['archive_sha256'],
          'archive_bytes':12023748, 'nodes':count, 'declared_regular_bytes':total,
          'excluded_nodes':22, 'excluded_regular_bytes':278164,
          'scope':'Exact metadata verified before native tar writes.'}, 16384)


class BoundedWriter:
    def __init__(self, stream):
        self.stream = stream
        self.count = 0

    def write(self, body):
        require(self.count + len(body) <= ARCHIVE_LIMIT, 'compressed archive bound before write')
        n = self.stream.write(body)
        require(n == len(body), 'short archive write')
        self.count += n
        return n

    def flush(self):
        self.stream.flush()


def retain():
    binding, index, before = load_inputs()
    require(json.loads((RECEIPTS/'archive-index-check.json').read_text())['status'] == 'PASS',
            'archive precheck missing')
    require(SOURCE.is_dir() and not SOURCE.is_symlink() and not OUT.exists(), 'fresh source/output required')
    expected = {relative(x['name']):x for x in index if not x['excluded']}
    files = {x['path']:x for x in before['files']}
    links = {x['path']:x['target'] for x in before['links']}
    actual = {}
    total = 0
    for directory, dirs, names in os.walk(SOURCE, followlinks=False):
        for name in dirs + names:
            path = Path(directory)/name
            rel = path.relative_to(SOURCE).as_posix()
            require(len(actual) < MAX_NODES and rel not in actual and rel in expected, 'unexpected source node: '+rel)
            st = path.lstat()
            kind = ('file' if stat.S_ISREG(st.st_mode) else 'directory' if stat.S_ISDIR(st.st_mode)
                    else 'symlink' if stat.S_ISLNK(st.st_mode) else 'unsupported')
            require(kind == expected[rel]['type'] and not st.st_mode & 0o7000, 'source type/mode changed: '+rel)
            item = {'path':rel, 'type':kind, 'extracted_mode':stat.S_IMODE(st.st_mode),
                    'archive_mode':expected[rel]['mode']}
            if kind == 'file':
                require(rel in files and st.st_size == files[rel]['bytes'] and
                        (st.st_mode & 0o111) == (files[rel]['mode'] & 0o111), 'source size/execute mode changed: '+rel)
                total += st.st_size
                require(total <= SOURCE_LIMIT, 'source aggregate byte bound')
                item.update(bytes=st.st_size, sha256=digest(path))
                require(item['sha256'] == files[rel]['sha256'], 'source bytes differ from accepted candidate: '+rel)
            elif kind == 'symlink':
                item['target'] = os.readlink(path)
                require(item['target'] == links[rel], 'raw source link changed: '+rel)
            actual[rel] = item
    require(set(actual) == set(expected)-{''} and total == 59058504, 'source membership differs')
    require(sum(x['type']=='file' for x in actual.values()) == 3208 and
            sum(x['type']=='symlink' for x in actual.values()) == 5, 'source count differs')
    require(files['service/OneService.cpp']['sha256'] == binding['candidate_sha256'], 'candidate mismatch')
    OUT.mkdir(mode=0o700)
    archive_path = OUT/DEST_NAME
    with archive_path.open('xb') as raw:
        sink = BoundedWriter(raw)
        with gzip.GzipFile(filename='', fileobj=sink, mode='wb', compresslevel=1, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for rel, entry in expected.items():
                    info = tarfile.TarInfo(DEST_PREFIX+('/'+rel if rel else ''))
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    info.mode = entry['mode']
                    if entry['type'] == 'directory':
                        info.type = tarfile.DIRTYPE
                        archive.addfile(info)
                    elif entry['type'] == 'symlink':
                        info.type = tarfile.SYMTYPE
                        info.linkname = links[rel]
                        archive.addfile(info)
                    else:
                        info.size = files[rel]['bytes']
                        with (SOURCE/rel).open('rb') as body:
                            archive.addfile(info, body)
    # Re-read the retained archive as data, without extracting or executing it.
    seen = set()
    with tarfile.open(archive_path, 'r|gz') as archive:
        for member in archive:
            name = member.name.rstrip('/')
            require(name == DEST_PREFIX or name.startswith(DEST_PREFIX+'/'), 'wrong output prefix')
            rel = name[len(DEST_PREFIX):].lstrip('/')
            require(rel in expected and rel not in seen, 'wrong output member')
            seen.add(rel)
            entry = expected[rel]
            require(member.mode == entry['mode'] and member.uid == member.gid == member.mtime == 0,
                    'output metadata differs')
            if entry['type'] == 'directory':
                require(member.isdir(), 'output directory differs')
            elif entry['type'] == 'symlink':
                require(member.issym() and member.linkname == links[rel], 'output link differs')
            else:
                require(member.isfile() and member.size == files[rel]['bytes'], 'output file differs')
                body = archive.extractfile(member)
                h = hashlib.sha256()
                with body:
                    while chunk := body.read(1024**2):
                        h.update(chunk)
                require(h.hexdigest() == files[rel]['sha256'], 'retained file hash differs')
    require(seen == set(expected), 'incomplete retained archive')
    companion = {}
    for name, src in [('package.mk', PLAN/'product/package.mk'),
                      ('001-client-without-nonfree-headers.patch', PLAN/'product/001-client-without-nonfree-headers.patch'),
                      ('BUILD.md', PLAN/'BUILD.md')]:
        require(src.stat().st_size <= 16384, 'companion byte bound')
        data = src.read_bytes()
        with (OUT/name).open('xb') as stream:
            stream.write(data)
        companion[name] = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
    require(companion['package.mk']['sha256'] == binding['product_recipe_sha256'] and
            companion['001-client-without-nonfree-headers.patch']['sha256'] == binding['product_patch_sha256'],
            'product companions changed')
    output = {'name':DEST_NAME, 'bytes':archive_path.stat().st_size,
              'sha256':digest(archive_path, ARCHIVE_LIMIT)}
    manifest = {'schema':1, 'status':'PASS', 'scope':'Filtered and patched ZeroTierOne client source, separately identified from upstream.',
                'archive':output, 'upstream_archive':{'bytes':12023748, 'sha256':binding['archive_sha256'],
                'url':'https://github.com/zerotier/ZeroTierOne/archive/refs/tags/1.16.0.tar.gz'},
                'source_before_sha256':binding['source_before_sha256'],
                'archive_index_sha256':binding['archive_index_sha256'],
                'product_recipe_sha256':binding['product_recipe_sha256'],
                'product_patch_sha256':binding['product_patch_sha256'],
                'accepted_reader':binding['accepted_reader'], 'original_compile':{
                    key:binding['original_compile'][key] for key in ('run','recipe_exit','readback_exit','consumed_id')},
                'build_plan_sha256':digest(PLAN/'build-plan.json'), 'companions':companion,
                'source_files':3208, 'source_symlinks':5, 'source_directories_including_root':529,
                'source_regular_bytes':total, 'excluded':before['excluded'],
                'metadata':'Deliverable uses original archive permission modes and raw links; uid/gid/mtime normalized to zero. Extracted ordinary rw permissions may reflect native tar umask; executable bits and all bytes match accepted source.',
                'members':[actual[k] for k in sorted(actual)]}
    write(OUT/'manifest.json', manifest, MANIFEST_LIMIT)
    write(RECEIPTS/'filtered-source.json', {'status':'PASS', 'archive':output,
          'manifest_sha256':digest(OUT/'manifest.json', MANIFEST_LIMIT),
          'manifest_bytes':(OUT/'manifest.json').stat().st_size, 'source_files':3208,
          'source_symlinks':5, 'source_directories_including_root':529,
          'source_regular_bytes':total, 'source_before_sha256':binding['source_before_sha256'],
          'product_recipe_sha256':binding['product_recipe_sha256'],
          'product_patch_sha256':binding['product_patch_sha256'],
          'archive_verified_by_full_member_readback':True}, 16384)


if __name__ == '__main__':
    require(len(sys.argv) == 2 and sys.argv[1] in ('precheck','retain'), 'choose precheck or retain')
    started = time.monotonic()
    (precheck if sys.argv[1] == 'precheck' else retain)()
    print(json.dumps({'status':'PASS', 'step':sys.argv[1], 'elapsed_seconds':time.monotonic()-started}))

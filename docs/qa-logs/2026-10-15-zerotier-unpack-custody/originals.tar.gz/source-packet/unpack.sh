#!/bin/bash
# Execute the adopted recipe's hook and scripts/unpack's text-patch command.
# This ends before build-engine stamps/configtools; no compiler or source code runs.
set -euo pipefail
source /plan/product/package.mk
PKG_BUILD=/work/source
SOURCES=/inputs
PKG_DIR=/plan/product
test ! -e "$PKG_BUILD"
test ! -L "$PKG_BUILD"
unpack
patch -d "${PKG_BUILD}" -p1 < <(sed -e "s#@TARGET_CPU@#${TARGET_CPU}#g" -e "s#@DEVICE@#${DEVICE}#g" /plan/product/001-client-without-nonfree-headers.patch)
test ! -e "$PKG_BUILD/nonfree"
test ! -L "$PKG_BUILD/nonfree"

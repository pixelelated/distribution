#!/usr/bin/env python3
"""The Oct13 component payload, limited to #566 syntax/build/catalogs."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

r = Path('/work')
packet = Path('/packet')
b = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64')
es = b / 'build/emulationstation-c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78'
cwd = es / '.x86_64-rocknix-linux-gnu'
tc = b / 'toolchain'
deadline = time.monotonic() + 600
result = {'rc': 1, 'started': time.time(), 'stages': [], 'source_commit': '3178b832b8d134198b2b4eede4f725d4ed283f8c'}
env = dict(os.environ, TMPDIR='/work/tmp', CCACHE_DISABLE='1', CCACHE_DIR='/work/tmp/ccache', CCACHE_TEMPDIR='/work/tmp', PATH=str(tc / 'bin') + ':' + os.environ['PATH'])
# Public pair from the normal distribution recipe, never an account credential.
env.pop('SCREENSCRAPER_DEV_LOGIN', None)
env['SCREENSCRAPER_RUNTIME_DEV_LOGIN'] = '1'

def run(label, command):
    command = [str(x) for x in command]
    remaining = deadline - time.monotonic()
    assert remaining > 0, 'component deadline exceeded'
    start = time.time()
    with (r / (label + '.stdout')).open('xb') as out, (r / (label + '.stderr')).open('xb') as err:
        try:
            child = subprocess.run(command, cwd=cwd, env=env, timeout=remaining, stdout=out, stderr=err)
        except subprocess.TimeoutExpired:
            result['stages'].append({'stage': label, 'command': command, 'rc': 124, 'timeout': True, 'seconds': time.time() - start})
            raise
    result['stages'].append({'stage': label, 'command': command, 'rc': child.returncode, 'seconds': time.time() - start})
    assert child.returncode == 0, label

def selected_flags():
    rows = json.loads((cwd / 'compile_commands.json').read_text())
    row = next(x for x in rows if x['file'].endswith('/scrapers/ScreenScraper.cpp'))
    command = row.get('command', ' '.join(row.get('arguments', [])))
    return {'compiled_pair': '-DSCREENSCRAPER_DEV_LOGIN=' in command, 'runtime_pair': '-DSCREENSCRAPER_RUNTIME_DEV_LOGIN' in command}

try:
    files = json.loads((packet / 'candidate-files.json').read_text())
    for name, row in files.items():
        assert hashlib.sha256((es / name).read_bytes()).hexdigest() == row['sha256'], name
    syntax = ['bash', packet / 'es-syntax-check', '--root', b, '--tree', '/source', '/source/es-app/src/scrapers/ScreenScraper.cpp']
    result['cached_flags'] = selected_flags()
    assert result['cached_flags'] == {'compiled_pair': False, 'runtime_pair': True}
    run('syntax-runtime-only', syntax)
    env['SCREENSCRAPER_DEV_LOGIN'] = 'devid=jelos&devpassword=jelos'
    run('configure-compiled', [tc / 'bin/cmake', '-S', es, '-B', cwd, '-DENABLE_RVZ_HASH=ON', '-DSCREENSCRAPER_RUNTIME_DEV_LOGIN=1'])
    result['configured_flags'] = selected_flags()
    assert result['configured_flags'] == {'compiled_pair': True, 'runtime_pair': True}
    run('syntax-compiled', syntax)
    run('build', [tc / 'bin/ninja', '-j2', 'emulationstation'])
    shutil.copyfile(es / 'emulationstation', r / 'artifacts/emulationstation')
    run('strip', [tc / 'bin/x86_64-rocknix-linux-gnu-strip', r / 'artifacts/emulationstation'])
    (r / 'artifacts/emulationstation').chmod(0o755)
    for lang in ('fr', 'en_GB'):
        run('catalog-' + lang, [tc / 'bin/msgfmt', '--check', '-o', r / ('artifacts/' + lang + '.mo'), es / ('locale/lang/' + lang + '/LC_MESSAGES/emulationstation2.po')])
    result['artifacts'] = {p.name: {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in sorted((r / 'artifacts').iterdir())}
    result['rc'] = 0
finally:
    result['ended'] = time.time()
    result['runtime'] = 'UNRUN'
    (r / 'component-result.json').write_text(json.dumps(result, indent=2) + '\n')
raise SystemExit(result['rc'])

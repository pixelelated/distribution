#!/usr/bin/env python3
"""One source-bound #566 UI case; root owns VM, compositor, input and frames."""
import argparse
import hashlib
import http.client
import json
import os
from pathlib import Path
import resource
import shutil
import socket
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--disposable-guest', action='store_true', required=True)
p.add_argument('--artifacts', type=Path, required=True)
p.add_argument('--component-result', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--language', choices=['en_US', 'fr_FR'], required=True)
p.add_argument('--xdg-runtime-dir', required=True)
p.add_argument('--wayland-display', required=True)
a = p.parse_args()
assert a.output.is_absolute() and str(a.output).startswith('/tmp/')
assert set(x.name for x in Path('/sys/class/net').iterdir()) == {'lo'}, 'fresh no-NIC guest required'
assert Path(a.xdg_runtime_dir, a.wayland_display).is_socket()
for process in Path('/proc').iterdir():
    if process.name.isdigit():
        try:
            assert not (process / 'comm').read_text().strip().startswith('emulationstatio'), 'coordinator must stop original ES first'
        except FileNotFoundError:
            pass
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_FSIZE, (16 * 1024 * 1024, 16 * 1024 * 1024))
os.umask(0o077)
a.output.mkdir(exist_ok=False)
root = a.output
result = {'rc': 1, 'started': time.time(), 'language': a.language, 'source_commit': '3178b832b8d134198b2b4eede4f725d4ed283f8c', 'scope': 'compiled-pair rejection UI with simulated local responses; provider acceptance UNRUN'}
children = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (root / name).write_text(json.dumps(value, indent=2) + '\n')

def command(name, argv):
    with (root / (name + '.stdout')).open('xb') as out, (root / (name + '.stderr')).open('xb') as err:
        child = subprocess.run(argv, stdout=out, stderr=err, timeout=15)
    save(name + '.exit.json', {'argv': argv, 'original_exit': child.returncode})
    assert child.returncode == 0, name

def start(name, argv, env=None):
    with (root / (name + '.stdout')).open('xb') as out, (root / (name + '.stderr')).open('xb') as err:
        child = subprocess.Popen(argv, stdout=out, stderr=err, env=env)
    children.append((name, child))
    save(name + '.pid.json', {'pid': child.pid, 'start_ticks': Path('/proc', str(child.pid), 'stat').read_text().rsplit(')', 1)[1].split()[19]})
    return child

try:
    built = json.loads(a.component_result.read_text())
    assert built['rc'] == 0 and built['source_commit'] == result['source_commit']
    assert built['configured_flags'] == {'compiled_pair': True, 'runtime_pair': True}
    for name, row in built['artifacts'].items():
        assert sha(a.artifacts / name) == row['sha256'], name
    result['component_result_sha256'] = sha(a.component_result)
    result['artifacts'] = built['artifacts']
    original_input = Path('/storage/.config/emulationstation/es_input.cfg').read_bytes()
    os.unshare(os.CLONE_NEWNS | os.CLONE_NEWNET)
    command('private-mounts', ['mount', '--make-rprivate', '/'])
    command('loopback-up', ['ip', 'link', 'set', 'lo', 'up'])
    assert socket.if_nameindex() == [(1, 'lo')]
    storage = root / 'storage'
    config = storage / '.config/emulationstation'
    for path in [config, storage / '.config/system/configs', storage / '.cache', storage / 'roms/gb']:
        path.mkdir(parents=True, exist_ok=True)
    (storage / '.emulationstation').symlink_to('.config/emulationstation')
    (config / 'resources').symlink_to('/usr/config/emulationstation/resources')
    (config / 'themes').symlink_to('/usr/share/themes')
    (config / 'es_input.cfg').write_bytes(original_input)
    for name in ('es_systems.cfg', 'es_features.cfg'):
        shutil.copyfile(here / 'fixtures' / name, config / name)
    shutil.copytree('/usr/config/locale', storage / '.config/locale')
    for lang in ('fr', 'fr_FR', 'en_GB'):
        locale = storage / '.config/locale' / lang / 'LC_MESSAGES'
        locale.mkdir(parents=True, exist_ok=True)
        catalog = 'fr' if lang == 'fr_FR' else lang
        shutil.copyfile(a.artifacts / (catalog + '.mo'), locale / 'emulationstation2.mo')
    (config / 'locale').symlink_to('../locale')
    (config / 'es_settings.cfg').write_text('<config>\n'
        '<string name="Scraper" value="ScreenScraper"/>\n'
        '<string name="ScraperFilter" value="all"/>\n'
        '<string name="ScreenScraperDevId" value="pix566-conflicting-runtime-id"/>\n'
        '<string name="ScreenScraperDevPass" value="pix566-conflicting-runtime-password"/>\n'
        '<int name="RecentlyScrappedFilter" value="0"/>\n'
        '<bool name="CheevosCheckIndexesAtStart" value="false"/>\n'
        '<bool name="NetPlayCheckIndexesAtStart" value="false"/>\n'
        '<bool name="PublicWebAccess" value="false"/>\n'
        '<string name="ThemeSet" value="es-theme-art-book-next"/>\n'
        '<string name="CollectionSystemsAuto" value=""/>\n'
        '<int name="ScreenSaverTime" value="0"/>\n'
        f'<string name="Language" value="{a.language}"/>\n</config>\n')
    (storage / '.config/system/configs/system.cfg').write_text('global.retroachievements=0\nglobal.netplay=0\ncloudsaves.startup=0\ncloudsaves.gameexit=0\naudio.bgmusic=0\n' + f'system.language={a.language}\n')
    (storage / 'roms/gb/pix566-metadata-only.gb').write_text('Synthetic metadata-only fixture. NOT A ROM. Never launch.\n')
    (root / 'hosts').write_text('127.0.0.1 localhost api.screenscraper.fr\n::1 localhost\n')
    (root / 'resolv.conf').write_text('nameserver 127.0.0.1\noptions attempts:1 timeout:1\n')
    (root / 'nsswitch.conf').write_text('passwd: files\ngroup: files\nhosts: files\n')
    bindings = [(storage, Path('/storage')), (a.artifacts / 'emulationstation', Path('/usr/bin/emulationstation'))] + [(root / name, Path('/etc') / name) for name in ('hosts', 'resolv.conf', 'nsswitch.conf')]
    for index, (source, target) in enumerate(bindings):
        command('bind-' + str(index), ['mount', '--bind', str(source), str(target)])
        if target.is_file():
            assert sha(source) == sha(target)
    (root / 'private-mountinfo.txt').write_text(Path('/proc/self/mountinfo').read_text())
    command('certificate', ['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1', '-keyout', str(root / 'key.pem'), '-out', str(root / 'cert.pem'), '-subj', '/CN=api.screenscraper.fr', '-addext', 'subjectAltName=DNS:api.screenscraper.fr'])
    listener = start('peer', ['python3', '-I', '-S', '-B', str(here / 'rejection-peer.py'), '--disposable-no-nic-guest', '--cert', str(root / 'cert.pem'), '--key', str(root / 'key.pem'), '--output', str(root / 'peer')])
    until = time.monotonic() + 8
    while not (root / 'peer/ready').exists():
        assert listener.poll() is None and time.monotonic() < until
        time.sleep(.1)
    env = {'PATH': '/usr/bin:/usr/sbin:/bin:/sbin', 'HOME': '/storage', 'LANG': a.language + '.UTF-8', 'LC_ALL': a.language + '.UTF-8', 'XDG_RUNTIME_DIR': a.xdg_runtime_dir, 'WAYLAND_DISPLAY': a.wayland_display, 'SDL_VIDEODRIVER': 'wayland', 'NO_PROXY': '*', 'no_proxy': '*'}
    (root / 'logs').mkdir()
    frontend = start('es', ['/usr/bin/emulationstation', '--log-path', str(root / 'logs'), '--no-splash'], env)
    assert sha(Path('/proc', str(frontend.pid), 'exe')) == built['artifacts']['emulationstation']['sha256']
    save('armed.json', {'es_pid': frontend.pid, 'language': a.language, 'next': 'Capture entry, ACCOUNTS and OPTIONS; return to SCRAPE and select SCRAPE NOW, capture rejection, dismiss OK and capture return; then create ui-reviewed.done.'})
    until = time.monotonic() + 180
    while not (root / 'ui-reviewed.done').exists():
        assert frontend.poll() is None and time.monotonic() < until, 'ES exited or UI deadline elapsed'
        if listener.poll() is not None:
            assert listener.returncode == 0 and json.loads((root / 'peer/result.json').read_text())['rc'] == 0
        time.sleep(.2)
    assert listener.wait(timeout=5) == 0
    assert json.loads((root / 'peer/result.json').read_text())['rc'] == 0
    frontend.terminate()
    assert frontend.wait(timeout=15) == 0, 'original ES exit failed'
    result['rc'] = 0
finally:
    exits = []
    for name, child in reversed(children):
        forced = child.poll() is None
        if forced:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
            result['rc'] = 1
        exits.append({'name': name, 'pid': child.pid, 'original_exit': child.returncode, 'forced_cleanup': forced})
    result['exits'] = exits
    result['ended'] = time.time()
    save('result.json', result)
raise SystemExit(result['rc'])

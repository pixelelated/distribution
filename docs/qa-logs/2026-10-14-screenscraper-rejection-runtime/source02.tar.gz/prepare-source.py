#!/usr/bin/env python3
"""Source staging only; invoke inside a fresh admitted component owner."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

packet = Path(__file__).resolve().parent
args = argparse.ArgumentParser()
args.add_argument('--work', type=Path, required=True)
args.add_argument('--source', type=Path, default=Path('/home/max/Development/emulationstation-next.worktrees/m7-candidate-compose'))
args.add_argument('--cached', type=Path)
args.add_argument('--sealed-source', action='store_true')
a = args.parse_args()
binding = json.loads((packet / 'source-binding.json').read_text())
files = json.loads((packet / 'candidate-files.json').read_text())
assert a.work.is_dir()
assert not (a.work / 'es').exists() or not any((a.work / 'es').iterdir())
if not a.sealed_source:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=a.source, text=True).strip() == binding['commit']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=a.source, text=True).strip()

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(data)
    return digest.hexdigest()

for name, row in files.items():
    assert sha(a.source / name) == row['sha256'], name
cached = a.cached or Path(binding['cached_root'])
before = {}
for directory, dirs, names in os.walk(cached):
    if '.git' in dirs:
        dirs.remove('.git')
    for name in names:
        if name == '.git':
            continue
        path = Path(directory) / name
        before[str(path.relative_to(cached))] = {'link': os.readlink(path)} if path.is_symlink() else {'sha256': sha(path), 'mode': oct(path.stat().st_mode & 0o777)}
shutil.copytree(cached, a.work / 'es', symlinks=True, ignore=shutil.ignore_patterns('.git'), dirs_exist_ok=True)
for name, row in before.items():
    path = a.work / 'es' / name
    if 'link' in row:
        assert path.is_symlink() and os.readlink(path) == row['link'], name
    else:
        assert sha(path) == row['sha256'], name
# All tracked candidate bytes replace the cached source, not only the five-file
# fix; retained generated build files and dependency cache keep their old prefix.
for name, row in files.items():
    path = a.work / 'es' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        path.unlink()
    shutil.copyfile(a.source / name, path)
    path.chmod(0o755 if row['mode'] == '100755' else 0o644)
    assert sha(path) == row['sha256'], name
for name, row in before.items():
    path = cached / name
    assert (os.readlink(path) == row['link']) if 'link' in row else (sha(path) == row['sha256']), name
(a.work / 'tmp').mkdir(exist_ok=True)
(a.work / 'artifacts').mkdir()
(a.work / 'cached-before.json').write_text(json.dumps(before, sort_keys=True) + '\n')
(a.work / 'source-staging.json').write_text(json.dumps({'rc': 0, 'commit': binding['commit'], 'tracked_files': len(files), 'cached_source_unchanged': True, 'runtime': 'UNRUN'}, indent=2) + '\n')

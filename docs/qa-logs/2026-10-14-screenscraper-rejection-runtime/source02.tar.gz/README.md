# #566 compiled credential rejection — retry02 prepared, UNRUN

ES commit **3178b832b8d134198b2b4eede4f725d4ed283f8c**, parent
`a5c7ff998831c8215f135a42a6f695e75230451d`, is committed in
`/home/max/Development/emulationstation-next.worktrees/m7-candidate-compose`.
Only `ScreenScraper.cpp` is a changed translation unit. The other four files are
CMake comments, POT, English and French catalogs. The compiled-pair branch now
says that this system's access was rejected, and directs the player to check for
a system update or report the problem. Runtime-only builds retain the editable
developer-ID/password guidance. Request/classification/error routing is unchanged.
Both obsolete no-image-key comments are corrected. No product/shared record,
pin, compiler, service, VM, provider account or device action accompanies this
packet. The paused native Dolphin plan is separately owned.

`upstream.json` binds the October14 primary upstream check at
`40343cf6e55c57e6219cbc9f28ebb1b9d25951b6`: that source lacks this fork's
failure classifier and guidance, so there is no matching upstream fix to import.
`source.patch`, `source-binding.json`, `candidate-files.json` and `derivation.json`
bind actual bytes. Static checks cover source/PO structure, ASCII gettext-adjacent
comments and the retained alternate branch. They do not establish rendering fit.

## Fresh component allocation, ready commands

This is the accepted syntax02/proxy native runner family with one selected
`es-component` payload. `watchdog.py` remains byte-identical to syntax02/proxy. `docker_owner.py`
has the single memory-contract correction described in `retry02.md`: its expected
container limit is8GiB, matching the already-selected creator/inner limits.
`runner-adaptation.diff` exposes changes. PID/CID identity, host handshake,
resource samples, independent watchdog, original exits and cleanup remain.

The component recipe reuses the actual successful Oct13 library build:
`/workspace/tmp/pix-m7-library-build-20261013/{build.py,inner.py,compile-result.json}`.
Their hashes are in `derivation.json`; original compiler total was221.19s,
ES Ninja207.53s. Never rerun or rewrite those completed owners. The frozen cache
is `m7-pixelelated-replacement20`, mounted read-only at its original
`/workspace/repos/rocknix.worktrees/m7-pixelelated` prefix. Its cached ES tree is
`emulationstation-c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78`.

Within the admitted container, `prepare-source.py` independently copies that
cached ES directory, checks the copy and unchanged original, then overwrites all
1,113 tracked candidate files with exact3178 bytes/modes. The unchanged pugixml
gitlink61c94489 stays the cached source, separately identified in the derivation.
No hardlinks, dependency rebuild, source downloads, generated CMake replacement,
cache symlink rewrite or mutation of accepted objects occurs. Only the private
copy is mounted writable at its old ES prefix. The full source and SDK are ro.

The actual cached compile command has runtime developer credentials enabled and
no compiled pair. `component-inner.py` requires that fact, runs the existing
`es-syntax-check --tree /source` on ScreenScraper.cpp, then reconfigures the
existing CMake build with normal public `devid=jelos&devpassword=jelos` environment,
`-DSCREENSCRAPER_RUNTIME_DEV_LOGIN=1 -DENABLE_RVZ_HASH=ON`. It requires both macros
in the new command, runs the same syntax check again, then `ninja -j2
emulationstation`, strips only the copied output, and runs `msgfmt --check` for
FR and EN_GB. The global compiled-pair definition may rebuild all ES objects;
this is a full component build, not a one-TU object shortcut. Old accepted
hash/RVZ/ASan controls are not rerun merely for freshness.

Pinned builder:
`ghcr.io/pixelelated/build@sha256:988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39`.
No network, `--pull=never`, read-only container root, normal user, dropped
capabilities, no-new-privileges,8GiB memory/no swap,2CPUs,256PIDs. One900-second
family clock includes input verification/copy/build; the component child has a
600-second total bound within that clock.4GiB sampled aggregate scratch ceiling
(not a disk quota),512MiB host free-space floor. Private writable `/work/tmp`
holds compiler/header-farm temporaries. No target executable is launched.

After the current cache allocation is consumed, root records this #566 allocation
and VM-first boundary: compiler proof uses the offline target SDK; actual UI can
and will run on the fresh no-NIC guest. The following commands are prepared only.
The owner must be new; never reuse a consumed/failed owner or admission.

```sh
cd /workspace/repos/rocknix.worktrees/m7-player-setup
PIX566_REPO=$PWD
PIX566_PACKET=/tmp/m7-screenscraper-rejection-20261014-02
PIX566_OWNER=/workspace/tmp/pix566-es-component-20261014-02
PIX566_STAGE=es-component
python3 -I -S -B "$PIX566_PACKET/plan.py" \
  --checkout "$PIX566_REPO" --owner "$PIX566_OWNER" --stage "$PIX566_STAGE"
PIX566_STAGE_ROOT=$PIX566_OWNER/stages/$PIX566_STAGE
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$PIX566_STAGE_ROOT/retention-plan.json" \
  --output "$PIX566_STAGE_ROOT/retention-report.json"
# Consume original retention-report results before admitting.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$PIX566_STAGE_ROOT/admission-plan.json" \
  --output "$PIX566_STAGE_ROOT/admission.json"
tools/watch-build-submit --owner "$PIX566_STAGE_ROOT/submit" -- \
  --admission "$PIX566_STAGE_ROOT/admission.json" \
  --activity-dir "$PIX566_STAGE_ROOT/logs" -- \
  python3 -I -S -B "$PIX566_PACKET/run-stage.py" \
  --checkout "$PIX566_REPO" --owner "$PIX566_OWNER" --stage "$PIX566_STAGE"
```

Actively supervise. Consume original owner/container/child/watchdog results,
both syntax stdout PASS rows, compile diagnostics, admission watcher runner /
command / monitor channels, submit launcher/tool-wrapper channels and actual
host exits before using outputs. The successful output holder is
`OWNER/work/artifacts/{emulationstation,fr.mo,en_GB.mo}`; source/output hashes and
original stage exits are `OWNER/work/component-result.json`. Failed/timeout/
forced-cleanup receipts remain failures. Retain compact receipts and these small
outputs for immediately queued UI proof; retire the private source/object copy
after consumption. No pin promotion is performed by the wrapper.

## Fresh no-NIC guest route

Reuse the coordinator's existing VM lifecycle, compositor, verified input map,
short serial/HMP/QMP sockets and observed free loopback VNC port. No old VM/media
owner is resumed. Stage this sealed packet and the successful component receipt
read-only using that lifecycle. Copy the three artifact files from noexec input
media to a fresh executable guest directory `/tmp/pix566-artifacts`, with ES0755
and MO files0644, and rehash against `component-result.json`. Python sources are
invoked with interpreters and may remain0644. Keep the original image identity.

The coordinator stops the original frontend through the existing owned method
while keeping its Sway compositor/Wayland socket alive. `guest-case.py` refuses
an already running ES, a non-loopback guest, wrong binary/catalog hashes or
missing Wayland socket. It does not manage a service or alter installed files
outside its private mount namespace. It copies only the known input map and
public locale resources; all account settings start empty. Its small GB library
uses the byte-identical #567 platform/feature fixture with `/bin/false` command
and a clearly marked metadata-only text input. No emulator/game is launched.

The guest case creates its own mount/network namespaces, loopback only, private
storage and a private binary bind at `/usr/bin/emulationstation`. DNS uses a
private `/etc/hosts` entry `127.0.0.1 api.screenscraper.fr`, private files-only NSS
and nonrouting resolver. The original installed host files/storage remain in
the parent namespace. It generates a one-day local TLS certificate with
`DNS:api.screenscraper.fr`, starts the bounded loopback peer, then the exact ES.
HttpReq already disables CA-chain verification, but retains host verification;
this fixture makes no product TLS change. No proxy environment is inherited.
The exact new French MO is installed into both private `fr` and `fr_FR` catalog
paths, so an existing full-locale catalog cannot shadow the newly compiled text.

The real, unchanged production route is:

1. SCRAPER > ACCOUNTS/OPTIONS show the normal compiled-mode rows. The fixture
   seeds conflicting synthetic runtime developer settings, which must stay
   hidden and unused; personal username/password remain empty/editable.
2. SCRAPE > ScreenScraper, ALL, ignore-recent NO, included GB fixture > SCRAPE NOW.
3. Actual `ThreadedScraper::start` calls `getThreadCount`, requesting
   `/api2/ssuserInfos.php`; the peer returns403 with the usual user-login sentence.
4. Actual `screenScraperFailureMessage` performs its pair-only request to
   `/api2/systemesListe.php`; the peer returns200 with non-XML developer rejection.
   Both requests must carry exactly the recipe's public compiled pair and no
   personal account values. Only match booleans/path/status are recorded.
5. Actual `GuiMsgBox` shows the translated `AN ERROR OCCURRED` prefix plus the
   new compiled-mode guidance. Capture all text, OK and help bar; dismiss OK and
   capture the returned library. No replacement widget, test-only ES endpoint
   or fabricated error string is involved.

The peer allows precisely those two ordered requests and exits;120s is its
original wall limit. The UI case allows180s after frontend start and preserves
each child PID/start identity, original exit and cleanup result. Start only
after serial/visual ownership is available. If navigation runs out of time,
consume the original failure and prepare a fresh reviewed case; do not extend it.

Use this exact guest invocation, replacing only fresh case/language and the
observed Wayland values. Root's existing guest supervisor supplies the outer
240-second bound and owns parent PID/start identity. This example is EN640:

```sh
python3 -I -S -B /tmp/pix-input/pix566/guest-case.py \
  --disposable-guest --artifacts /tmp/pix566-artifacts \
  --component-result /tmp/pix-input/pix566-component-result.json \
  --output /tmp/pix566-en640-01 --language en_US \
  --xdg-runtime-dir /run/0-runtime-dir --wayland-display wayland-1
```

Launch under that existing supervisor in the background with stdout/stderr and
original exit receipt outside the private namespace. Keep exactly one serial
reader: use it briefly to inspect `armed.json`, then release it while HMP/VNC
performs the walk. Do not hold a foreground serial command waiting for the case
while another process polls the same serial socket. After the five reviewed
frames, that same reader creates `CASE/ui-reviewed.done`; then consume the case's
original process exit and `CASE/result.json`. A done marker is the coordinator's
handoff, not an automatic screenshot verdict. Guest teardown clears namespaces;
root separately confirms no frontend/peer process remains before the next case.

## Four exact-source visual cases — all UNRUN

Run EN_US640x480, FR_FR640x480, EN_US1280x800 and FR_FR1280x800 with the same
compiled output/catalog identities. Actual panel dimensions must be observed
from the VM/renderer and screenshot, not inferred from a filename. Each case
captures five meaningful frames: SCRAPE entry, ACCOUNTS, OPTIONS, complete
rejection, and return library. Include scrolled accounts/options frames only
when needed to establish all fields; use the existing navigation tool one
verified step at a time, not a new broad suite. The account rows are present;
developer rows are absent on both pages despite seeded runtime values.

```sh
# HMP socket, not QMP; actual key mapping comes from copied es_input.cfg.
tools/vm-visual-qa --monitor "$MONITOR_SOCKET" key "$OBSERVED_KEY"
tools/vm-visual-qa --monitor "$MONITOR_SOCKET" settle
tools/vm-visual-qa --monitor "$MONITOR_SOCKET" shot "$HOST_FRAMES/accounts.png"
```

Use the same commands for the other named frames. Serialize QMP media/control
with visual operations; finish all media attachment first. Root reviews line
wrapping, complete EN/FR copy, accents/apostrophes, prefix, button and help bar,
then records actual ES `/proc/PID/exe` hash, source commit, both catalog hashes,
theme/installed resources, locale, panel, peer transcript, exact frame paths/hashes
and the original case exits. Static line lengths are not visual acceptance.

Canonical menu-map/flow and reviewed frame index remain coordinator-owned. Apply
the narrow proposal in `flow-reference.md` and bind the four actual-source cases
before pin promotion. Existing accepted unrelated cases keep their original
scope/identity; this copy fix creates no extra native-gameplay or provider gate.
Runtime-only fallback presentation remains a separately identified build; the
two syntax passes do not claim a runtime-only screenshot was taken.

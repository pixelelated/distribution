# Coordinator-owned canonical reference amendment

At `docs/es-menu-map.md`, "ScreenScraper developer provisioning (#566)", retain
the current location and compiled-hidden/runtime-visible developer-row branches.
Replace the combined authentication-error edge with these distinct outcomes:

```mermaid
flowchart TD
  O{Authentication outcome} -->|Accepted| R[Existing scrape progress and result]
  O -->|Personal account missing/rejected| A[Existing account guidance under SCRAPER > ACCOUNTS]
  O -->|Developer pair rejected| C{Compiled developer pair?}
  C -->|Yes| U[Check for a system update or report the problem]
  C -->|No: runtime fallback| D[Check developer ID/password under SCRAPER > ACCOUNTS]
  O -->|Offline/service/probe unavailable| S[Existing connection or service guidance]
```

Source references: `GuiScraperStart.cpp:415` hides developer entries when the
compiled macro exists; line430 retains runtime-only missing-pair validation.
`ScreenScraper.cpp:1047` chooses actionable compiled versus runtime guidance.
`scrapers/ThreadedScraper.cpp:299` is the actual error-modal caller. The recipe
supplies the public interim pair, and CMake defines both macros; compiled wins.
This fixes existing #566 acceptance rather than adding another milestone gate.

Prepared source3178, source-binding/derivation, both original syntax outputs,
actual compiled ELF and catalogs precede the four EN/FR small/large reviewed
frame rows. Record accounts/options row visibility, rejected pair's complete
message and dismissal/return. No navigation row was moved or renamed.
All new screenshot rows are UNRUN until root supplies their actual artifacts.

# Attempt01 memory-contract failure; additive retry02

Attempt01 failed before any compiler or source-copy child ran. The copied
DockerOwner observer still required4GiB, inherited verbatim from the successful
4GiB syntax/proxy allocation. The component creator and inner telemetry had
already been deliberately set to8GiB for the full ES build. Keeping the observer
byte-identical was an incomplete adaptation: its identity check rejected the
correctly created8GiB container, and the same check then refused generic cleanup.

`original-attempt01/` contains compact original FAIL receipts, with exact source
paths/hashes in `limit-contract-static.json`. The outer and watchdog remain
original failures; the container receipt has an empty children list. Root owns
the exact-CID cleanup and original-result consumption. This packet performs no
cleanup or execution, and it does not normalize or rewrite attempt01.

The **only executable change** is `docker_owner.py:40`:

```diff
-        require(value['memory']==4*1024**3 and value['nano_cpus']==2000000000,'container limits differ')
+        require(value['memory']==8*1024**3 and value['nano_cpus']==2000000000,'container limits differ')
```

`limit-contract.diff` is the exact patch. The creator, inner runner, watchdog,
source stager, compiler commands, source3178, all guest/UI files, bindings and
sealed SDK/source plan are byte-identical to attempt01. Packet metadata and this
explanation are additive; README commands select new packet/owner02.

`limit-contract-static.json` records AST/hash comparisons, without importing or
running any runner: creator memory8g + memory-swap8g, observer8GiB, inner memory
max8GiB + swap max0, CPU2 across creator/observer/inner, PIDs256 across creator/
inner, networknone,900s family deadline and600s component sub-bound. The unchanged
watchdog imports the corrected DockerOwner and consumes the original absolute
family deadline. The4GiB scratch ceiling is a distinct disk limit and remains
unchanged. No guard is removed or weakened to accept arbitrary memory limits.

Use the exact README plan/report/admission/submit sequence only after root has
consumed attempt01 and confirmed exact-CID/process cleanup. The fresh proposed
owner is `/workspace/tmp/pix566-es-component-20261014-02`; it has not been created
by this preparation. No source, compiler, service, VM or test execution occurred.
Any further correction requires another additive packet/fresh allocation.

Capture for the coordinator work log: when adapting a bounded runner's resource
contract, compare creator, observer, inner telemetry and watchdog-imported
cleanup invariants together before sealing. This failure was in fixture
adaptation, not ES product source or the requested memory budget.

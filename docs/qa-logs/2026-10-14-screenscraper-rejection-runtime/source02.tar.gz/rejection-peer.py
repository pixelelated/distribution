#!/usr/bin/env python3
"""Two-response loopback TLS peer for the real #566 scrape-start path."""
import argparse
import http.server
import json
from pathlib import Path
import signal
import ssl
import time
import urllib.parse

p = argparse.ArgumentParser()
p.add_argument('--disposable-no-nic-guest', action='store_true', required=True)
p.add_argument('--cert', type=Path, required=True)
p.add_argument('--key', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert {x.name for x in Path('/sys/class/net').iterdir()} == {'lo'}, 'requires no-NIC guest'
assert Path('/storage').is_dir(), 'requires disposable distribution guest'
a.output.mkdir(exist_ok=False)
result = {'rc': 1, 'requests': [], 'started': time.time(), 'limit_seconds': 120}
sequence = [('/api2/ssuserInfos.php', 403, b'Verifier les identifiants utilisateurs'), ('/api2/systemesListe.php', 200, b'Verifier vos identifiants developpeur')]

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # Do not record credentials, raw URLs, or request headers.

    def do_GET(self):
        self.connection.settimeout(5)
        parsed = urllib.parse.urlsplit(self.path)
        query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        index = len(result['requests'])
        expected_path, status, body = sequence[index]
        valid = (parsed.path == expected_path and
                 self.headers.get('Host', '').split(':')[0] == 'api.screenscraper.fr' and
                 query.get('devid') == ['jelos'] and query.get('devpassword') == ['jelos'] and
                 not query.get('ssid', [''])[0] and not query.get('sspassword', [''])[0])
        result['requests'].append({'path': parsed.path, 'status': status if valid else 400, 'matches_public_compiled_pair': query.get('devid') == ['jelos'] and query.get('devpassword') == ['jelos'], 'has_account': bool(query.get('ssid', [''])[0]) or bool(query.get('sspassword', [''])[0]), 'expected': valid})
        if not valid:
            status, body = 400, b'unexpected fixture request'
        self.send_response(status)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

def expired(*unused):
    raise RuntimeError('120-second peer limit')

signal.signal(signal.SIGALRM, expired)
signal.alarm(120)
try:
    with http.server.HTTPServer(('127.0.0.1', 443), Handler) as server:
        server.timeout = 1
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(a.cert, a.key)
        server.socket = context.wrap_socket(server.socket, server_side=True)
        (a.output / 'ready').write_text('loopback TLS listening\n')
        while len(result['requests']) < 2:
            server.handle_request()
            if result['requests'] and not result['requests'][-1]['expected']:
                raise RuntimeError('unexpected request')
    result['rc'] = 0
finally:
    signal.alarm(0)
    result['ended'] = time.time()
    (a.output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
raise SystemExit(result['rc'])

#!/usr/bin/env python3
"""UNRUN affected installed-image actions under the composition owner's one lock."""
import argparse,fcntl,hashlib,json,os,re,shlex,signal,struct,subprocess,sys,time,uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--owner',type=Path,required=True);p.add_argument('action',choices=['dolphin','wifi-start','wifi-select','wifi-activate','wifi-back-reopen','wifi-exit','cleanup','review','finish']);p.add_argument('--label');p.add_argument('--review');a=p.parse_args()
R=a.owner.resolve(strict=True);C=json.loads((R/'config.json').read_text());TREE=Path(C['checkout']);ready=json.loads((R/'visual-ready.json').read_text());pending=None
assert C['affected']['packet_seal'] and time.monotonic()<ready['deadline_monotonic'] and not (R/'visual-result.json').exists()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):
 q=p.with_suffix('.pending');q.write_text(json.dumps(x,indent=2)+'\n');os.replace(q,p)
for n,h in C['code'].items():assert sha(R/n)==h
for n,h in C['tools'].items():assert sha(Path(n))==h
with (R/'serial.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 inv=R/'frames'/('audit-'+time.strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]);inv.mkdir()
 def identity(pid):
  f=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'start_ticks':int(f[19])}
 save(inv/'operator.json',identity(os.getpid()))
 def execute(label,argv,seconds=30):
  row={'argv':list(map(str,argv)),'original_returncode':None,'timed_out':False,'started_monotonic':time.monotonic()}
  with (inv/(label+'.stdout')).open('xb') as out,(inv/(label+'.stderr')).open('xb') as err:
   child=subprocess.Popen(row['argv'],stdout=out,stderr=err,start_new_session=True)
   row['child']=identity(child.pid)
   try:row['original_returncode']=child.wait(timeout=min(seconds,max(.1,ready['deadline_monotonic']-time.monotonic())))
   except subprocess.TimeoutExpired:row['timed_out']=True;os.killpg(child.pid,signal.SIGKILL);row['original_returncode']=child.wait(timeout=5)
  row['ended_monotonic']=time.monotonic();save(inv/(label+'.json'),row);assert row['original_returncode']==0 and not row['timed_out'],'preserve failed original action; no blind replay'
  return (inv/(label+'.stdout')).read_text()
 def code(script,seconds=30):
  tag='PIX_AUDIT_EXIT_'+uuid.uuid4().hex;command=script+'; pxrc=$?; printf "\\n'+tag+'=%s\\n" "$pxrc"'
  text=execute('serial-'+uuid.uuid4().hex[:8],[TREE/'tools/vm-serial','--socket',R/'vm/serial.sock','--timeout',str(seconds),'sh',command],seconds+7)
  assert re.findall(r'^'+tag+r'=([0-9]+)\r?$',text,re.M)==['0'];return text
 def guest(words,seconds=30):
  text=code(shlex.join(['python3','-I','-S','-B','/tmp/pix-affected-input/guest-affected.py',*words]),seconds)
  rows=re.findall(r'^PIX_AUDIT_JSON=(.*)\r?$',text,re.M);assert len(rows)==1;return json.loads(rows[0])
 keys=json.loads((R/'audit-init.json').read_text())['input_keys']
 def key(name):execute('key-'+name+'-'+uuid.uuid4().hex[:8],[TREE/'tools/vm-visual-qa','--monitor',R/'vm/monitor.sock','key',keys[name]],3)
 def frame(label):
  path=inv/(label+'.png');execute('shot-'+label,[TREE/'tools/vm-visual-qa','--monitor',R/'vm/monitor.sock','shot',path],5)
  raw=path.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('!II',raw[16:24])==(640,480)
  row={'path':str(path),'sha256':sha(path),'label':label,'captured_host_monotonic':time.monotonic(),'time':time.time(),'observation':'unreviewed','source_binding':C['affected']};save(R/'frames'/(label+'-capture.json'),row);return row
 def measured(action,reference=None):
  output=inv/('capture-'+action)
  argv=[sys.executable,'-I','-S','-B',R/'capture-back.py',action,'--tool',TREE/'tools/vm-visual-qa','--tool-sha256',C['tools'][str(TREE/'tools/vm-visual-qa')],'--monitor',R/'vm/monitor.sock','--vnc-port',str(C['vnc']+5900),'--output',output]
  if reference:argv+=['--reference',reference['path'],'--reference-sha256',reference['sha256'],'--key',keys['b']]
  execute('measure-'+action,argv,12)
  result=json.loads((output/'result.json').read_text());assert result['status']=='PASS' and result['original_returncode']==0
  return output,result
 def recorded(label,path):
  raw=path.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('!II',raw[16:24])==(640,480)
  row={'path':str(path),'sha256':sha(path),'label':label,'captured_host_monotonic':time.monotonic(),'time':time.time(),'observation':'unreviewed','source_binding':C['affected']};save(R/'frames'/(label+'-capture.json'),row);return row
 if a.action=='wifi-select':
  # Source-bound fresh hostname has a NETWORK NAME row before INTERNET STATUS.
  state=guest(['wifi-state']);assert not state['blocked']
  assert state['case']['menu_route']['down_steps_to_wifi_network']==6 and state['case']['menu_route']['conditional_network_name_row']
  key('start');time.sleep(.3)
  for _ in range(6):key('up')
  key('a');time.sleep(.4)
  for _ in range(6):key('down')
  directory,measurement=measured('reference')
  selected=recorded('wifi-candidate-selected-network',directory/'reference.png')
  save(R/'audit-wifi-selection.json',{'case':state['case'],'frame':selected,'reference':{'path':str(directory/'reference.ppm'),'sha256':sha(directory/'reference.ppm')}})
  print(json.dumps({'status':'REVIEW_REQUIRED_BEFORE_ACTIVATION','frame':selected,'required_review':'WI-FI NETWORK selected; ENABLE WI-FI ON; activate this bound picker.'}))
 elif a.action=='wifi-activate':
  selected=json.loads((R/'audit-wifi-selection.json').read_text());capture=selected['frame']
  review=json.loads((R/'frames'/(capture['label']+'-review.json')).read_text())
  assert review['observation']=='personally reviewed' and review['review']=='WI-FI NETWORK selected; ENABLE WI-FI ON; activate this bound picker.'
  assert review['sha256']==capture['sha256']==sha(Path(capture['path'])) and review['path']==capture['path'] and review['source_binding']==C['affected']
  before=guest(['wifi-state']);assert before['case']==selected['case'] and not before['blocked']
  assert all(row.split()[2] in ['current','has_ap_mode'] for row in before['calls'])
  key('a');time.sleep(.4)
  state=guest(['wifi-state']);assert state['blocked'];frame('wifi-'+state['case']['mode']+'-searching');save(R/'audit-wifi-before.json',state)
 elif a.action=='wifi-back-reopen':
  before=json.loads((R/'audit-wifi-before.json').read_text());assert before['case']['mode']=='candidate'
  current=guest(['wifi-state']);assert current['blocked']==before['blocked'] and sum(row.split()[2] in ['list','scanlist'] for row in current['calls'])==1
  selected=json.loads((R/'audit-wifi-selection.json').read_text());reference=selected['reference']
  assert selected['case']==before['case'] and sha(Path(reference['path']))==reference['sha256']
  directory,measurement=measured('back',reference)
  save(R/'audit-back-timing.json',measurement)
  returned=recorded('wifi-candidate-network-return',directory/('sample-%02d.png'%measurement['first_matching_sample']))
  assert measurement['upper_bound_seconds']<=1 and measurement['status']=='PASS'
  key('a');time.sleep(.2);frame('wifi-candidate-reopened-searching');after=guest(['wifi-state'])
  assert after['blocked']==before['blocked'] and sum(row.split()[2] in ['list','scanlist'] for row in after['calls'])==1
  save(R/'audit-reopen.json',{'rc':0,'before':before,'after':after,'same_blocked_group':True,'enumeration_calls':1,'return_frame':returned,'timing':measurement})
 elif a.action=='review':
  assert a.label and a.review and re.fullmatch('[a-z0-9-]{1,80}',a.label)
  capture=json.loads((R/'frames'/(a.label+'-capture.json')).read_text());assert capture['label']==a.label and sha(Path(capture['path']))==capture['sha256'] and capture['source_binding']==C['affected']
  path=R/'frames'/(a.label+'-review.json');assert not path.exists(),'do not replace an original review'
  save(path,dict(capture,observation='personally reviewed',review=a.review,reviewed_time=time.time()))
 elif a.action=='finish':
  cleanup=json.loads((R/'audit-cleanup.json').read_text());assert cleanup['rc']==0 and not cleanup['aborted'] and cleanup['selected_settings_restored_before_restart'] and cleanup['installed_inputs_restored'] and cleanup['normal_service_restarted']
  assert json.loads((R/'audit-dolphin.json').read_text())['rc']==0
  assert json.loads((R/'audit-wifi-exit.json').read_text())['rc']==0
  assert json.loads((R/'audit-reopen.json').read_text())['rc']==0
  assert json.loads((R/'audit-back-timing.json').read_text())['status']=='PASS'
  reviews=[json.loads(f.read_text()) for f in sorted((R/'frames').glob('*-review.json'))]
  required=['wifi-candidate-selected-network','wifi-candidate-searching','wifi-candidate-network-return','wifi-candidate-reopened-searching']
  assert all(any(r['label']==label for r in reviews) for label in required)
  for row in reviews:assert row['observation']=='personally reviewed' and row['source_binding']==C['affected'] and sha(Path(row['path']))==row['sha256']
  pending={'guest':cleanup,'reviews':reviews,'scope':'actual installed affected cases after composition gate; synthetic Wi-Fi backend and four helper-chroot transitions only','acceptance':'pending coordinator review of original runtime/export channels'}

 else:
  words=[a.action]
  result=guest(words,80 if a.action=='dolphin' else 60);save(R/('audit-'+a.action+'.json'),result);print(json.dumps(result))
if pending is not None:save(R/'visual-result.json',pending)

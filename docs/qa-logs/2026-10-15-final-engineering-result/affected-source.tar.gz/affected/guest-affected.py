#!/usr/bin/env python3
"""UNRUN affected installed-image actions after clean/retained composition gates."""
import argparse,ctypes,hashlib,json,os,re,shlex,shutil,signal,stat,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from guest_helpers import R,api,identity,natives,run,save,sha
B=json.loads((HERE/'binding.json').read_text())
PRIVATE=Path('/run/pix-audit-ui');SYSTEM=Path('/storage/.config/system/configs/system.cfg');SETTINGS=Path('/storage/.config/emulationstation/es_settings.cfg')
def require_guest():
 assert os.getuid()==0 and sorted(x.name for x in Path('/sys/class/net').iterdir())==['lo']
 assert 'BUILD_ID="'+B['guest_build_commit']+'"' in Path('/etc/os-release').read_text()
 assert not natives()
 for name,h in B['packet_files'].items():assert sha(HERE/name)==h,name
 for path,h in B['installed_inputs'].items():
  if path!='/usr/bin/wifictl' or path not in mounts():
   f=Path(path);facts=B['installed_facts'][path];assert sha(f)==h and f.stat().st_size==facts['bytes'] and stat.filemode(f.lstat().st_mode)==facts['mode'] and not f.is_symlink(),path
def es_pids():
 rows=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   if (p/'comm').read_text().strip() in ['emulationstation','emulationstatio']:
    row=identity(int(p.name));row['exe_sha256']=sha(p/'exe');assert row['exe_sha256'] in [B['installed_inputs']['/usr/bin/emulationstation']];rows.append(row)
  except (FileNotFoundError,ProcessLookupError):pass
 return rows
def mounts():
 return [line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()]
def bind(source,target):
 target=Path(target);assert str(target) not in mounts(),'pre-existing target bind refuses fixture'
 before={'path':str(target),'sha256':sha(target) if target.is_file() else None}
 run('audit-bind',['mount','--bind',source,target],5);run('audit-private',['mount','--make-private',target],5)
 assert target.stat().st_ino==Path(source).stat().st_ino and target.stat().st_dev==Path(source).stat().st_dev
 rows=json.loads((R/'mounts.json').read_text());rows.append(dict(before,source=str(source)));save(R/'mounts.json',rows)
def unbind_all():
 rows=json.loads((R/'mounts.json').read_text())
 for row in reversed(rows):
  target=Path(row['path']);source=Path(row['source']);assert mounts().count(str(target))==1
  assert target.stat().st_ino==source.stat().st_ino and target.stat().st_dev==source.stat().st_dev
  run('audit-unbind',['umount',target],5)
  if row['sha256']:assert sha(target)==row['sha256']
 save(R/'mounts.json',[])
def settings(language,wifi=False):
 values=[('system.language',language)]
 if wifi:values += [('system.hostname','GENERIC_X64'),('wifi.enabled','1'),('wifi.adhoc.enabled','0')]
 run('audit-settings',['bash','-ec','. /etc/profile; '+ '; '.join('set_setting '+shlex.quote(k)+' '+shlex.quote(v) for k,v in values)],10)
 tree=ET.parse(SETTINGS);root=tree.getroot();assert root.tag=='config'
 for key,value in [('LogLevel','information')]:
  matches=root.findall("string[@name='"+key+"']");assert len(matches)<=1
  node=matches[0] if matches else ET.SubElement(root,'string',{'name':key});node.set('value',value)
 tree.write(SETTINGS,encoding='utf-8',xml_declaration=True)
def stop_es():
 assert not natives();run('audit-stop-es',['systemctl','stop','essway.service'],30);assert not es_pids()
def start_es():
 run('audit-start-es',['systemctl','start','essway.service'],40)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':return
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
def wifi_route():
 # Exact installed fresh-image hostname adds GuiMenu.cpp9910's NETWORK NAME row.
 # Read only these public fixture settings; never retain the whole live config.
 values={}
 for key in ['system.hostname','wifi.enabled','wifi.adhoc.enabled']:
  rows=[line.split('=',1)[1] for line in SYSTEM.read_text().splitlines() if line.startswith(key+'=')]
  assert len(rows)==1,(key,'missing or duplicate fixture setting');values[key]=rows[0]
 assert values=={'system.hostname':'GENERIC_X64','wifi.enabled':'1','wifi.adhoc.enabled':'0'},values
 return {'settings':values,'clean_network_name':'GENERIC-X64','conditional_network_name_row':True,'down_steps_to_wifi_network':6}
def wifi_start(mode):
 assert mode=='candidate'
 if (R/'wifi-current.json').exists():assert json.loads((R/'wifi-current.json').read_text())['closed']
 stop_es();unbind_all();settings('en_US',True);route=wifi_route()
 bind(PRIVATE/'wifictl','/usr/bin/wifictl')
 expected=B['installed_inputs']['/usr/bin/emulationstation']
 label='wifi-'+mode;argv=['python3','-I','-S','-B',str(HERE/'wifi-owner.py'),'--output',str(R/label),'--binary-sha256',expected]
 with (R/(label+'.owner.stdout')).open('xb') as out,(R/(label+'.owner.stderr')).open('xb') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True)
 row={'closed':False,'mode':mode,'output':str(R/label),'owner':identity(child.pid),'binary_sha256':expected,'menu_route':route};save(R/'wifi-current.json',row)
 deadline=time.monotonic()+45
 while not (R/label/'frontend-ready.json').exists():
  assert child.poll() is None and time.monotonic()<deadline;time.sleep(.1)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':break
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
 return row
def wifi_state():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output'])
 assert not row['closed'] and not (case/'owner-result.json').exists()
 owner_now=identity(row['owner']['pid']);assert owner_now['start_ticks']==row['owner']['start_ticks'] and owner_now['state']!='Z'
 frontend=json.loads((case/'frontend-ready.json').read_text())['identity'];frontend_now=identity(frontend['pid']);assert frontend_now['start_ticks']==frontend['start_ticks'] and frontend_now['state']!='Z'
 assert wifi_route()==row['menu_route']
 result={'case':row,'blocked':json.loads((case/'blocked-ready.json').read_text()) if (case/'blocked-ready.json').exists() else None,'calls':(case/'invocations').read_text().splitlines() if (case/'invocations').exists() else []}
 if result['blocked']:
  for item in result['blocked']['group']:
   actual=identity(item['pid']);assert actual['start_ticks']==item['start_ticks'] and actual['state']!='Z'
 return result
def wifi_exit():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output']);assert (case/'blocked-ready.json').exists()
 with (case/'continue-exit').open('x') as f:f.write('normal SIGINT after reviewed Back/reopen flow\n')
 deadline=time.monotonic()+20
 while not (case/'owner-result.json').exists():assert time.monotonic()<deadline;time.sleep(.05)
 owner=json.loads((case/'owner-result.json').read_text());result=json.loads((case/'result.json').read_text());expected=1 if row['mode']=='baseline' else 0
 assert owner['original_returncode']==expected and not owner['timed_out'] and result['final_returncode']==expected
 assert not result['survivors_after_cleanup']
 if expected:assert result['driver_original_returncode']==0 and result['owned_identities_still_present']
 else:assert result['driver_original_returncode']==0 and not result['forced_cleanup']
 while Path('/proc',str(row['owner']['pid'])).exists():assert time.monotonic()<deadline;time.sleep(.05)
 assert not es_pids();row['closed']=True;save(R/'wifi-current.json',row);return {'rc':0,'observation_original_returncode':expected,'result':result}

# Only these two fixture-mutated settings files are restored. Last-good .backup
# files are outside the selected restoration claim, as in the qualified UI flow.
def selected(path):
 st=path.lstat();assert stat.S_ISREG(st.st_mode) and st.st_size<=2*1024**2
 return {'sha256':sha(path),'mode':stat.S_IMODE(st.st_mode),'uid':st.st_uid,'gid':st.st_gid}
def init():
 assert not R.exists() and not PRIVATE.exists();R.mkdir(parents=True);PRIVATE.mkdir();(R/'originals').mkdir();save(R/'mounts.json',[])
 stop_es()
 originals={}
 for path,name in [(SYSTEM,'system.cfg'),(SETTINGS,'es_settings.cfg')]:
  originals[name]=selected(path);shutil.copy2(path,R/'originals'/name);os.chown(R/'originals'/name,originals[name]['uid'],originals[name]['gid'])
 save(R/'originals/selected.json',originals)
 shutil.copy2(HERE/'source/wifictl',PRIVATE/'wifictl');os.chmod(PRIVATE/'wifictl',0o755)
 config=Path('/storage/.config/emulationstation/es_input.cfg');keyboard=ET.fromstring(config.read_bytes()).find("inputConfig[@type='keyboard']");assert keyboard is not None
 key_names={13:'ret',27:'esc',32:'spc',8:'backspace',1073741906:'up',1073741905:'down',1073741904:'left',1073741903:'right',1073742049:'shift',1073742053:'shift_r'}
 mapping={}
 for x in keyboard.findall('input'):
  if x.get('type')=='key':
   number=int(x.get('id'));key=key_names.get(number) or (chr(number) if 97<=number<=122 else None)
   if key:mapping[x.get('name')]=key
 assert all(name in mapping for name in ['start','up','down','a','b'])
 row={'rc':0,'input_keys':mapping,'input_cfg_sha256':sha(config),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'installed_inputs':B['installed_inputs'],'source':B['guest_build_commit'],'selected_settings_custody':'two private originals; no settings values/hashes exported'}
 save(R/'init.json',row);return row

def dolphin():
 assert not (R/'dolphin.json').exists()
 output=Path('/run/pix594-installed');assert not output.exists()
 # run() retains the transport's true wait status before an assertion; probe
 # retains all four helper/launcher original statuses even on ordinary failure.
 try:
  run('installed-dolphin',['python3','-I','-S','-B',HERE/'fixtures/probe.py','--output',output],70)
 finally:
  dest=R/'dolphin';dest.mkdir()
  if output.exists():
   for f in sorted(output.rglob('*')):
    if f.is_relative_to(output/'root'):continue
    assert not f.is_symlink()
    if f.is_file():
     assert f.stat().st_size<=2*1024**2;target=dest/f.relative_to(output);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
 result=json.loads((dest/'result.json').read_text());assert result['status']=='PASS' and result['remaining_children']==[] and not result['signals'] and not result['observation_errors']
 assert len(result['cases'])==4 and all(row['original_exit']==0 and row['status']=='PASS' for row in result['cases'])
 save(R/'dolphin.json',{'rc':0,'cases':4,'result_sha256':sha(dest/'result.json'),'scope':'installed full helper and exact installed launcher block; synthetic INI/settings/queue/saves; engine marker only'})
 return json.loads((R/'dolphin.json').read_text())

def cleanup():
 if not R.exists():return {'rc':0,'scope':'fixture never initialized'}
 if (R/'restored.json').exists():return json.loads((R/'restored.json').read_text())
 if (R/'wifi-current.json').exists():assert json.loads((R/'wifi-current.json').read_text())['closed']
 stop_es();unbind_all()
 saved=R/'originals/selected.json'
 if saved.exists():
  originals=json.loads(saved.read_text())
  for name,path in [('system.cfg',SYSTEM),('es_settings.cfg',SETTINGS)]:
   assert selected(R/'originals'/name)==originals[name];shutil.copy2(R/'originals'/name,path);os.chown(path,originals[name]['uid'],originals[name]['gid']);assert selected(path)==originals[name]
 for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
 # Record stopped restoration separately: normal startup may maintain .backup.
 save(R/'settings-restored-stopped.json',{'rc':0,'selected_bytes_modes_owners_equal':bool(saved.exists()),'selected_paths':[str(SYSTEM),str(SETTINGS)],'backup_scope':'last-good .backup files not in this restoration claim','mounts':json.loads((R/'mounts.json').read_text())})
 start_es();assert len(es_pids())==1 and not natives()
 row={'rc':0,'aborted':False,'selected_settings_restored_before_restart':bool(saved.exists()),'installed_inputs_restored':True,'normal_service_restarted':True,'native_processes':[]};save(R/'restored.json',row);return row

def export():
 import base64,io,tarfile
 assert R.is_dir()
 files=[f for f in sorted(R.rglob('*')) if f.is_file() and not f.is_relative_to(R/'originals')]
 assert not any(f.is_symlink() for f in R.rglob('*')) and len(files)<=1024
 assert sum(f.stat().st_size for f in files)<=6*1024**2
 rows=[{'path':str(f.relative_to(R)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]
 buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w:gz') as t:
  for f in files:t.add(f,arcname=str(f.relative_to(R)),recursive=False)
 raw=buf.getvalue();assert len(raw)<=4*1024**2
 print('PIX_AFFECTED_MANIFEST='+base64.b64encode(json.dumps(rows).encode()).decode())
 print('PIX_AFFECTED_ARCHIVE='+base64.b64encode(raw).decode())
 return {'rc':0,'files':len(rows),'uncompressed_bytes':sum(row['bytes'] for row in rows),'archive_sha256':hashlib.sha256(raw).hexdigest(),'private_original_settings_exported':False,'normal_restoration_receipt_present':(R/'restored.json').exists(),'live_failure_snapshot_possible':not (R/'restored.json').exists()}

def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['init','dolphin','wifi-start','wifi-state','wifi-exit','cleanup','export']);a=p.parse_args();require_guest()
 result={'init':init,'dolphin':dolphin,'wifi-start':lambda:wifi_start('candidate'),'wifi-state':wifi_state,'wifi-exit':wifi_exit,'cleanup':cleanup,'export':export}[a.action]()
 print('PIX_AUDIT_JSON='+json.dumps(result))
if __name__=='__main__':main()

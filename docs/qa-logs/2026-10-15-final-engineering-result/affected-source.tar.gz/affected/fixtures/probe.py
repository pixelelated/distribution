#!/usr/bin/env python3
"""UNRUN #594 transition fixture: full helper + exact launcher block, disposable guest chroot.

Requires Linux root in an allocated disposable GENERIC_X64 VM. No listener,
Dolphin/proxy process, account or external network. Reads installed helper/launcher bytes.
"""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import sqlite3
import struct
import subprocess
import sys
import time

PACKET = Path(__file__).resolve().parents[1]
BINDING = json.loads((PACKET/'binding.json').read_text())
SCRIPT = 'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh'
WORK_SECONDS = 60
MAX_STAGE = 24 * 1024 * 1024
MAX_SCRATCH = 32 * 1024 * 1024
PROFILE = '''# Entirely synthetic profile; do not source the guest profile.
get_setting() {
  local key value
  while IFS='=' read -r key value; do
    if [ "$key" = "$1" ]; then printf '%s\\n' "$value"; return 0; fi
  done < /fixture/settings
  return 0
}
set_setting() { printf '%s\\n' 'UNEXPECTED settings mutation' >&2; exit 96; }
'''
HEAD = '  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt uid timeout inode\n'
TABLES = {
    'ipv4': ('0100007F:1F90', '0A', 'tcp'),
    'wildcard4': ('00000000:1F90', '0A', 'tcp'),
    'mapped6': ('0000000000000000FFFF00000100007F:1F90', '0A', 'tcp6'),
    'loopback6': ('00000000000000000000000001000000:1F90', '0A', 'tcp6'),
    'wildcard6': ('00000000000000000000000000000000:1F90', '0A', 'tcp6'),
    'wrong-port': ('0100007F:1F91', '0A', 'tcp'),
    'established': ('0100007F:1F90', '01', 'tcp'),
    'other-address': ('0200007F:1F90', '0A', 'tcp'),
    'empty': None, 'missing': None, 'unreadable': None,
}
ELIGIBLE = {'ipv4', 'wildcard4', 'mapped6'}


def require(value, text):
    if not value:
        raise AssertionError(text)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def elf_dependencies(data):
    """Static ELF64 little-endian inspection; never invoke ldd or a loader."""
    require(data[:6] == b'\x7fELF\x02\x01', 'requires ELF64 little-endian guest runtime')
    require(struct.unpack_from('<H', data, 18)[0] == 62, 'requires GENERIC_X64 x86-64 binaries')
    offset = struct.unpack_from('<Q', data, 32)[0]
    size, count = struct.unpack_from('<HH', data, 54)
    require(size == 56 and count < 256, 'unsupported ELF program-header layout')
    ph = [struct.unpack_from('<IIQQQQQQ', data, offset+i*size) for i in range(count)]
    interp = [data[h[2]:h[2]+h[5]].rstrip(b'\0').decode() for h in ph if h[0] == 3]
    require(len(interp) <= 1, 'multiple ELF interpreters')
    dynamic = []
    for h in ph:
        if h[0] == 2:
            require(h[5] < 65536, 'excessive dynamic table')
            for i in range(h[2], h[2]+h[5], 16):
                tag, value = struct.unpack_from('<qQ', data, i)
                if not tag: break
                dynamic.append((tag, value))
    table = next((v for t,v in dynamic if t == 5), None)
    if table is None:
        return interp, []
    load = next(h for h in ph if h[0] == 1 and h[3] <= table < h[3]+h[5])
    start = table-load[3]+load[2]
    def string(index):
        end = data.index(b'\0', start+index, min(len(data), start+index+4096))
        return data[start+index:end].decode()
    # Exact image binaries normally use standard paths. Refuse exotic loader
    # search directives rather than claiming to have staged an equivalent tree.
    paths = [string(v) for t,v in dynamic if t in (15,29)]
    require(all(all(p in ('/lib','/lib64','/usr/lib','/usr/lib64') for p in s.split(':')) for s in paths),
            'nonstandard ELF RPATH/RUNPATH requires a separate staging review')
    return interp, [string(v) for t,v in dynamic if t == 1]


def stage_runtime(root):
    staged = {}; identities = []; total = 0
    searches = [Path(p) for p in ('/usr/lib','/lib','/lib64','/usr/lib64',
                '/lib/x86_64-linux-gnu','/usr/lib/x86_64-linux-gnu')]
    def copy(source, invocation):
        nonlocal total
        require(invocation.startswith('/') and '..' not in Path(invocation).parts, 'unsafe ELF destination')
        if invocation in staged: return
        requested = Path(source)
        resolved = requested.resolve(strict=True)
        require(resolved.is_file() and resolved.stat().st_size <= 16*1024*1024,
                'runtime source is not a regular file within16MiB')
        data = resolved.read_bytes()
        require(len(data) <= 16*1024*1024, 'one runtime file exceeds16MiB')
        interp, needed = elf_dependencies(data)
        total += len(data)
        require(total <= MAX_STAGE, 'runtime staging exceeds24MiB')
        dest = root/invocation.lstrip('/'); dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data); dest.chmod(0o755)
        require(resolved.stat().st_size == len(data) and sha(resolved.read_bytes()) == sha(data),
                'runtime source changed while copying')
        identities.append({'requested_path':str(requested), 'resolved_identity_path':str(resolved),
                           'guest_invocation_path':invocation, 'sha256':sha(data), 'bytes':len(data)})
        staged[invocation] = sha(data)
        for item in interp: copy(item, item)
        for name in needed:
            require('/' not in name, 'unexpected slash in DT_NEEDED')
            library = next((p/name for p in searches if (p/name).is_file()), None)
            require(library is not None, 'missing dependency: '+name)
            copy(library, str(library))
    for command in ('bash','cat','mktemp','mv','rm'):
        invocation = shutil.which(command)
        require(invocation is not None, 'guest lacks '+command)
        # Preserve argv[0] basename even when cat resolves to BusyBox bytes.
        copy(invocation, '/bin/'+command)
    return identities, total


ACTIVE = ('[Achievements]\nDiscordPresenceEnabled = False\nEnabled = True\n'
          'EncoreEnabled = True\nHardcoreEnabled = True\nProgressEnabled = False\n'
          'SpectatorEnabled = False\nUnofficialEnabled = True\nUsername = prior-synthetic-user\n'
          'ApiToken = prior-synthetic-token\nHostUrl = 127.0.0.1:8080\n').encode()
INACTIVE = ('[Achievements]\nDiscordPresenceEnabled = False\nEnabled = False\n'
            'EncoreEnabled = False\nHardcoreEnabled = False\nProgressEnabled = False\n'
            'SpectatorEnabled = False\nUnofficialEnabled = False\nUsername = \nApiToken = \nHostUrl = \n').encode()
INI = 'storage/.config/dolphin-emu/RetroAchievements.ini'
DIAGNOSTICS = {
    'en': 'DOLPHIN DID NOT START\nDOLPHIN DID NOT START\n\nAchievements settings could not be updated. Check the game storage and folder permissions, then try again.\n',
    'fr': 'DOLPHIN DID NOT START\nDOLPHIN N’A PAS DÉMARRÉ\n\nLes paramètres des succès n’ont pas pu être mis à jour. Vérifiez le stockage des jeux et les permissions des dossiers, puis réessayez.\n',
}


def cases():
    result=[dict(variant='after',state=state,platform=platform,language='en',destination='regular')
            for state,platform in [('disabled','gc'),('missing-token','wii'),('enabled-proxy','gc'),('enabled-hardcore','wii')]]
    for i,case in enumerate(result):case['name']=f'{i:02}-'+ '-'.join(case[k] for k in ['variant','state','destination','language','platform'])
    return result


def configure(root,case,packet):
    conf=root/'storage/.config/dolphin-emu';conf.chmod(0o777)
    ini=root/INI
    if ini.is_symlink() or ini.is_file():ini.unlink()
    elif ini.is_dir():shutil.rmtree(ini)
    for p in (root/'tmp').iterdir():
        require(p.is_file() and not p.is_symlink(),'unexpected case temporary object');p.unlink()
    for p in conf.glob('RetroAchievements.ini.*'):
        raise AssertionError('temporary credential file survived preceding case: '+p.name)
    values={
      'global.retroachievements.username':'synthetic-current-user',
      'global.retroachievements.password':'synthetic-password',
      'global.retroachievements.token':'synthetic-current-token',
      'global.retroachievements':'0' if case['state']=='disabled' else '1',
      'global.retroachievements.hardcore':'1' if case['state']=='enabled-hardcore' else '0',
      'global.retroachievements.offlineproxy':'1',
      'global.retroachievements.customhost':'https://custom.example.invalid',
      'global.retroachievements.encore':'1',
      'global.retroachievements.unofficial':'1',
      'global.retroachievements.testunofficial':'0'}
    if case['state']=='missing-token':values['global.retroachievements.token']=''
    settings=root/'fixture/settings';settings.write_text(''.join(k+'='+v+'\n' for k,v in values.items()));settings.chmod(0o444)
    (root/'etc/profile').write_text(PROFILE);(root/'etc/profile').chmod(0o444)
    for name in ['tcp','tcp6']:(root/'proc/net'/name).write_text(HEAD)
    if case['state']!='enabled-no-listener':
        (root/'proc/net/tcp').write_text(HEAD+'   0: 0100007F:1F90 00000000:0000 0A 00000000:00000000 00:00000000 00000000 0 0 123\n')
    for p in (root/'proc/net').iterdir():p.chmod(0o444)
    log=root/'var/log/cheevos.log';log.write_text('synthetic prior log\n');log.chmod(0o666)
    if case['destination']=='directory':
        ini.mkdir();(ini/'prior.ini').write_bytes(ACTIVE);(ini/'prior.ini').chmod(0o444)
    elif case['destination']=='symlink':
        ini.symlink_to('/fixture/symlink-target.ini')
    else:
        ini.write_bytes(ACTIVE);ini.chmod(0o666)
    if case['destination']=='create-denied':conf.chmod(0o555)
    elif case['destination']=='publish-denied':
        # Root-owned old destination in sticky directory: child can create and
        # remove its temporary, but actual mv cannot replace the old INI.
        conf.chmod(0o1777)
    actual=Path('/usr/bin/cheevos_dolphin.sh').read_bytes()
    require(sha(actual)==BINDING['installed_inputs']['/usr/bin/cheevos_dolphin.sh'],'installed helper changed')
    helper=root/'usr/bin/cheevos_dolphin.sh';helper.write_bytes(actual);helper.chmod(0o555)
    snippet=(packet/'source'/('launcher-'+case['platform']+'.after.snippet')).read_bytes()
    launcher=Path('/usr/bin/start_dolphin_'+case['platform']+'.sh').read_bytes()
    require(sha(launcher)==BINDING['installed_inputs']['/usr/bin/start_dolphin_'+case['platform']+'.sh'] and launcher.count(snippet)==1,'actual installed launcher block differs')
    wrapper=b'#!/bin/bash\n'+snippet+b'printf \'helper_status=%s\\n\' "${CHEEVOS_STATUS:-$?}" > /tmp/engine.started\n'
    (root/'fixture/actual.sh').write_bytes(wrapper);(root/'fixture/actual.sh').chmod(0o444)
    return values,actual,snippet,wrapper


def expected_enabled(values,case):
    flag=lambda key:'True' if values[key]=='1' else 'False'
    host='127.0.0.1:8080' if case['state']=='enabled-proxy' else values['global.retroachievements.customhost']
    return ('[Achievements]\nDiscordPresenceEnabled = False\nEnabled = True\n'
        f'EncoreEnabled = {flag("global.retroachievements.encore")}\n'
        f'HardcoreEnabled = {flag("global.retroachievements.hardcore")}\n'
        'ProgressEnabled = False\nSpectatorEnabled = False\n'
        f'UnofficialEnabled = {flag("global.retroachievements.unofficial")}\n'
        f'Username = {values["global.retroachievements.username"]}\n'
        f'ApiToken = {values["global.retroachievements.token"]}\nHostUrl = {host}\n').encode()


def snapshot(root):
    ignored={INI,'var/log/cheevos.log','tmp/engine.started','tmp/launch_error.log'}
    result={}
    for p in root.rglob('*'):
        name=str(p.relative_to(root))
        if name in ignored:continue
        if p.is_symlink():result[name]={'link':os.readlink(p)}
        elif p.is_file():result[name]={'sha256':sha(p.read_bytes()),'mode':p.stat().st_mode&0o7777}
    return result


def proc_identity(pid):
    """Read PID/PPID/start ticks only. A vanished directory is the sole benign read race."""
    directory=Path('/proc')/str(pid)
    try:
        with (directory/'stat').open('rb') as stream:
            raw=stream.read(65537)
    except (FileNotFoundError, ProcessLookupError):
        try: directory.stat()
        except (FileNotFoundError, ProcessLookupError): return None
        raise RuntimeError('stat unavailable for a still-present proc PID '+str(pid))
    require(len(raw)<=65536, 'oversized proc stat for PID '+str(pid))
    # comm may contain spaces, newlines and closing parentheses. It is never
    # matched or retained; numeric fields start after its final closing paren.
    prefix,separator,tail=raw.rpartition(b')')
    require(separator and prefix.split(b' (',1)[0]==str(pid).encode(),
            'malformed proc stat PID '+str(pid))
    fields=tail.split()
    require(len(fields)>=20, 'short proc stat PID '+str(pid))
    return {'pid':pid,'ppid':int(fields[1]),'start_ticks':int(fields[19])}


def direct_children(parent):
    """Census this subreaper's direct/adopted children; errors never mean empty."""
    require(proc_identity(parent) is not None, 'cannot observe fixture owner in proc')
    found=[]
    for entry in Path('/proc').iterdir():
        if not entry.name.isascii() or not entry.name.isdigit(): continue
        identity=proc_identity(int(entry.name))
        if identity is not None and identity['ppid']==parent:
            found.append(identity)
    return sorted(found,key=lambda item:item['pid'])


def signal_child(identity,parent):
    """Only an identity-checked child pidfd may receive a signal; never numeric kill."""
    require(identity['ppid']==parent, 'refusing a non-child signal')
    current=proc_identity(identity['pid'])
    if current is None: return {'identity':identity,'outcome':'already-gone'}
    require(current==identity, 'child identity changed before pidfd acquisition')
    try: fd=os.pidfd_open(identity['pid'],0)
    except ProcessLookupError: return {'identity':identity,'outcome':'gone-before-pidfd'}
    try:
        # Refuse reuse/reparenting between the census and the acquired handle.
        current=proc_identity(identity['pid'])
        if current is None: return {'identity':identity,'outcome':'gone-after-pidfd'}
        require(current==identity, 'child identity changed after pidfd acquisition')
        try: signal.pidfd_send_signal(fd,signal.SIGKILL,None,0)
        except ProcessLookupError: return {'identity':identity,'outcome':'gone-before-signal'}
        return {'identity':identity,'outcome':'pidfd-kill'}
    finally:
        os.close(fd)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();out=args.output.absolute()
    require(os.geteuid()==0,'allocated disposable VM root required')
    require(Path('/usr/bin/emulationstation').is_file() and Path('/usr/bin/dolphin-emu-nogui').is_file(),
            'installed gaming guest required; never run this fixture on the build host')
    require(out.parent==Path('/run') and out.name.startswith('pix594-') and not out.exists() and not out.is_symlink(),
            'fresh /run/pix594-* output required')
    require(sorted(p.name for p in Path('/sys/class/net').iterdir())==['lo'],'no-NIC guest required')
    require('BUILD_ID="'+BINDING['guest_build_commit']+'"' in Path('/etc/os-release').read_text(),'wrong installed image')
    bindbytes=(PACKET/'binding.json').read_bytes()
    for name,expected in BINDING['packet_files'].items():require(sha((PACKET/name).read_bytes())==expected,name+' changed')
    for name,expected in BINDING['installed_inputs'].items():require(sha(Path(name).read_bytes())==expected,name+' installed bytes changed')
    require(os.statvfs('/run').f_bavail*os.statvfs('/run').f_frsize>=MAX_SCRATCH+16*1024*1024,'need48MiB free/reserve')
    resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,256*1024*1024))
    resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024*1024,16*1024*1024))
    resource.setrlimit(resource.RLIMIT_CPU,(50,50))
    out.mkdir(mode=0o755);root=out/'root';root.mkdir(mode=0o755)
    started=time.monotonic();deadline=started+WORK_SECONDS
    report={'status':'FAIL','runtime':'UNRUN until actual allocated guest executes','scope':'Full helper, exact launcher RA block, synthetic engine-reached marker; no real engine launch',
            'bindings_sha256':sha(bindbytes),'cases':[],'python':sys.version}
    libc=ctypes.CDLL(None,use_errno=True);libc.prctl.restype=ctypes.c_int;libc.unshare.restype=ctypes.c_int
    require(libc.prctl(36,1,0,0,0)==0,'subreaper setup failed')
    parent=os.getpid();parent_net=os.readlink('/proc/self/ns/net');report['parent_net_namespace']=parent_net
    def timed_out(signum,frame):raise TimeoutError('whole fixture work deadline')
    signal.signal(signal.SIGALRM,timed_out);signal.alarm(WORK_SECONDS)
    active=None
    report['fixture_sha256']=sha(Path(__file__).read_bytes())
    report['original_fixture_sha256']=BINDING['qualified_probe_sha256']
    report['installed_inputs']=BINDING['installed_inputs']
    report['signals']=[]
    try:
        require(hasattr(os,'pidfd_open') and hasattr(signal,'pidfd_send_signal'),
                'identity-safe cleanup requires Python/Linux pidfd support')
        report['runtime_files'],report['runtime_bytes']=stage_runtime(root)
        for folder in ['etc','fixture','storage/.config/dolphin-emu','storage/.config/raofflineproxy',
                       'storage/roms/saves/wii','storage/roms/savestates/wii','var/log','proc/net','usr/bin','tmp']:
            (root/folder).mkdir(parents=True,exist_ok=True)
        (root/'tmp').chmod(0o1777);(root/'var/log').chmod(0o777)
        (root/'fixture/symlink-target.ini').write_bytes(ACTIVE);(root/'fixture/symlink-target.ini').chmod(0o444)
        for name in ['storage/roms/saves/wii/ordinary-save.bin','storage/roms/savestates/wii/manual.s01']:
            (root/name).write_bytes(b'protected synthetic save bytes\n');(root/name).chmod(0o444)
        db=sqlite3.connect(root/'storage/.config/raofflineproxy/proxy.sqlite3')
        try:
            db.execute('CREATE TABLE pending_awards (sentinel TEXT)');db.execute("INSERT INTO pending_awards VALUES ('synthetic queue must not change')");db.commit()
        finally:db.close()
        for name in ['Dolphin.ini','GCPadNew.ini','WiimoteNew.ini']:
            f=root/'storage/.config/dolphin-emu'/name;f.write_bytes(b'protected unrelated synthetic setting = true\n');f.chmod(0o444)
        for case in cases():
            require(time.monotonic()<deadline,'deadline before next case')
            values,actual,snippet,wrapper=configure(root,case,PACKET)
            protected=snapshot(root);receipt=out/case['name'];receipt.mkdir()
            record={'name':case['name'],'input':case,'helper_sha256':sha(actual),'launcher_snippet_sha256':sha(snippet),
                    'invocation_wrapper_sha256':sha(wrapper),'original_exit':None,'status':'FAIL'}
            destination=root/INI
            record['destination_before']={'parent_mode':destination.parent.stat().st_mode&0o7777,
                'parent_uid':destination.parent.stat().st_uid,'uid':destination.lstat().st_uid,
                'kind':'symlink' if destination.is_symlink() else 'directory' if destination.is_dir() else 'regular',
                'link':os.readlink(destination) if destination.is_symlink() else None,'seed_sha256':sha(ACTIVE)}
            report['cases'].append(record);(receipt/'invocation.sh').write_bytes(wrapper)
            rd,wr=os.pipe()
            def isolate():
                require(libc.prctl(1,signal.SIGKILL,0,0,0)==0,'initial parent-death signal failed')
                require(os.getppid()==parent,'owner exited before containment')
                require(libc.unshare(0x40000000)==0,'private network namespace unavailable')
                ns=os.readlink('/proc/self/ns/net');require(ns!=parent_net,'network namespace did not change')
                os.chroot(root);os.chdir('/')
                os.setgroups([]);os.setgid(65534);os.setuid(65534)
                require(libc.prctl(38,1,0,0,0)==0,'no-new-privileges failed')
                require(libc.prctl(1,signal.SIGKILL,0,0,0)==0,'post-setuid parent-death signal failed')
                chosen=ctypes.c_int()
                require(libc.prctl(2,ctypes.byref(chosen),0,0,0)==0 and chosen.value==signal.SIGKILL,'parent-death signal readback failed')
                require(os.getppid()==parent,'owner exited during containment')
                resource.setrlimit(resource.RLIMIT_CPU,(2,2));resource.setrlimit(resource.RLIMIT_FSIZE,(65536,65536));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
                os.write(wr,json.dumps({'net_namespace':ns,'uid':os.getuid(),'gid':os.getgid(),'parent_death_signal':chosen.value}).encode());os.close(wr)
            try:
                with (receipt/'stdout').open('wb') as stdout,(receipt/'stderr').open('wb') as stderr:
                    active=subprocess.Popen(['/bin/bash','--noprofile','--norc','/fixture/actual.sh'],stdin=subprocess.DEVNULL,
                        stdout=stdout,stderr=stderr,env={'PATH':'/bin','HOME':'/nonexistent','LC_ALL':'C','LANGUAGE':case['language']},
                        start_new_session=True,preexec_fn=isolate,pass_fds=(wr,))
                    os.close(wr);wr=-1;record['containment']=json.loads(os.read(rd,4096))
                    try:record['original_exit']=active.wait(timeout=min(3,max(.01,deadline-time.monotonic())))
                    except subprocess.TimeoutExpired:
                        record['timed_out']=True
                        for child in direct_children(parent):
                            report['signals'].append(signal_child(child,parent))
                        record['original_exit']=active.wait(timeout=2)
                        raise AssertionError(case['name']+': per-case deadline')
                    active=None
            finally:
                os.close(rd)
                if wr>=0:os.close(wr)
            children=[]
            while True:
                try:pid,status=os.waitpid(-1,os.WNOHANG)
                except ChildProcessError:break
                if pid==0:break
                children.append({'pid':pid,'wait_status':status})
            record['unexpected_descendants']=children
            require(not children,'unexpected adopted descendant')
            live=direct_children(parent)
            require(not live,'live descendants after case '+str(live))
            ini=root/INI;marker=root/'tmp/engine.started';error=root/'tmp/launch_error.log'
            record['engine_marker_present']=marker.exists()
            record['temporary_credentials_remaining']=[p.name for p in ini.parent.glob('RetroAchievements.ini.*')]
            (receipt/'settings').write_bytes((root/'fixture/settings').read_bytes())
            (receipt/'log').write_bytes((root/'var/log/cheevos.log').read_bytes())
            if marker.exists():(receipt/'engine.started').write_bytes(marker.read_bytes())
            if error.exists():(receipt/'launch_error.log').write_bytes(error.read_bytes())
            if ini.is_file() and not ini.is_symlink():(receipt/'generated.ini').write_bytes(ini.read_bytes())
            if ini.is_dir():(receipt/'old-directory-member.ini').write_bytes((ini/'prior.ini').read_bytes())
            require(protected==snapshot(root),'protected settings/queue/saves/runtime or unexpected path changed')
            require(not record['temporary_credentials_remaining'],'temporary credential file leaked')
            require((receipt/'stdout').read_bytes()==b'','unexpected stdout')
            failure=case['destination'] in ['create-denied','publish-denied','directory']
            if failure:
                require(record['original_exit']==250 and not marker.exists(),'publish failure did not refuse engine')
                require(error.read_text()==DIAGNOSTICS[case['language']],'exact localized launch-error protocol differs')
                require((ini/'prior.ini').read_bytes()==ACTIVE if ini.is_dir() else ini.read_bytes()==ACTIVE,'prior session bytes changed on failure')
                require((receipt/'stderr').stat().st_size>0,'missing actual mktemp/mv failure diagnostic')
                record['claim']='prior bytes preserved; engine gate refused; exact localized250 protocol; temporary removed'
            else:
                require(record['original_exit']==0 and marker.exists() and not error.exists(),'valid launcher gate did not continue')
                require(not ini.is_symlink(),'successful publication retained destination symlink')
                early=case['state'] in ['disabled','missing-token']
                expected=ACTIVE if early and case['variant']=='before' else INACTIVE if early else expected_enabled(values,case)
                require(ini.read_bytes()==expected,'complete generated session differs')
                require(marker.read_text()==f'helper_status={1 if early else 0}\n','helper original status differs')
                require((receipt/'stderr').read_bytes()==b'','unexpected stderr')
                if case['variant']=='after':require(ini.stat().st_mode&0o777==0o600,'published credentials mode not0600')
                record['claim']='old stale enabled session reproduced' if early and case['variant']=='before' else 'inactive session published before engine gate' if early else 'enabled routing bytes unchanged'
            record['protected_files_unchanged']=len(protected);record['status']='PASS'
            record['protected_selected']={key:protected[key] for key in [
                'fixture/settings','fixture/symlink-target.ini','storage/.config/dolphin-emu/Dolphin.ini','storage/.config/dolphin-emu/GCPadNew.ini','storage/.config/dolphin-emu/WiimoteNew.ini','storage/.config/raofflineproxy/proxy.sqlite3',
                'storage/roms/saves/wii/ordinary-save.bin','storage/roms/savestates/wii/manual.s01']}
            (receipt/'result.json').write_text(json.dumps(record,indent=2)+'\n')
        report['status']='PASS';report['runtime']='actual guest bash/cat/mktemp/mv/rm and statically staged ELF dependencies'
    except BaseException as error:
        report['error']=type(error).__name__+': '+str(error);raise
    finally:
        signal.alarm(0)
        report['remaining_children']=None  # unknown until observation succeeds
        report['cleanup_descendants']=[]
        report['observation_errors']=[]
        try:
            if active is not None:
                for child in direct_children(parent):
                    report['signals'].append(signal_child(child,parent))
                try:
                    exit_code=active.wait(timeout=3)
                    if report['cases'] and report['cases'][-1]['original_exit'] is None:
                        report['cases'][-1]['original_exit']=exit_code
                except subprocess.TimeoutExpired: report['cleanup_failed']=True
            # Kill/reap only our direct/adopted children within the original
            # two-second cleanup budget. Unexpected children always mean FAIL.
            cleanup_deadline=time.monotonic()+2
            while time.monotonic()<cleanup_deadline:
                owned=direct_children(parent)
                if not owned:break
                report['status']='FAIL'
                for child in owned:
                    report['signals'].append(signal_child(child,parent))
                while True:
                    try:pid,status=os.waitpid(-1,os.WNOHANG)
                    except ChildProcessError:break
                    if pid==0:break
                    report['cleanup_descendants'].append({'pid':pid,'wait_status':status})
                time.sleep(0.01)
        except BaseException as error:
            report['status']='FAIL'
            report['observation_errors'].append('cleanup: '+type(error).__name__+': '+str(error))
        # Each observation is independent of receipt publication. An error
        # cannot become an empty census or erase the original failure/exit.
        try:
            report['remaining_children']=direct_children(parent)
        except BaseException as error:
            report['status']='FAIL'
            report['observation_errors'].append('final census: '+type(error).__name__+': '+str(error))
        report['elapsed_seconds']=time.monotonic()-started
        try:
            report['retained_bytes']=sum(p.stat().st_size for p in out.rglob('*') if p.is_file())
            if report['retained_bytes']>MAX_SCRATCH:
                report['status']='FAIL';report['scratch_limit_exceeded']=True
        except BaseException as error:
            report['status']='FAIL'
            report['observation_errors'].append('scratch census: '+type(error).__name__+': '+str(error))
        if report['remaining_children'] is None or report['remaining_children'] or report.get('cleanup_failed'):
            report['status']='FAIL'
        try:
            (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
        except BaseException as error:
            report['status']='FAIL'
            report['receipt_error']=type(error).__name__+': '+str(error)
            # Keep a fallback receipt in the coordinator's captured owner stdout
            # if the output filesystem itself cannot accept the final JSON.
            print(json.dumps(report),flush=True)
            raise
        print(json.dumps({'status':report['status'],'result':str(out/'result.json')}),flush=True)
    require(report['status']=='PASS','fixture did not pass')


if __name__=='__main__':main()


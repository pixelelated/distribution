# Sole-operator actions and exact acceptance

After actual visual-ready.json, use only this owner's shared serial.lock route.
The original family deadline continues. The helper transition first must finish
before binding the Wi-Fi backend. No gamepad, ROM, account or engine is launched.

```bash
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" dolphin
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" wifi-start
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" wifi-select
```

View the returned actual wifi-candidate-selected-network PNG. It must show the
NETWORK SETTINGS page, WI-FI NETWORK highlighted, and ENABLE WI-FI ON. The
hostname fixture intentionally introduces NETWORK NAME, making WI-FI NETWORK
six downward steps from the top. Never compensate a wrong page by guessing keys.
Record only after personally viewing that bound image:

```bash
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" review \
  --label wifi-candidate-selected-network \
  --review 'WI-FI NETWORK selected; ENABLE WI-FI ON; activate this bound picker.'
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" wifi-activate
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" wifi-back-reopen
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" wifi-exit
```

Run those last three actions promptly in order; the product scan remains30s and
the observer's continue-exit handshake25s. Do not pause for frame reviews between
them. The selected-network pre-activation review is outside that30s scan window.
The original observer allows75s from frontend readiness to first backend scan;
if root cannot review in that bound, retain the failed original rather than
lengthening or replaying its timer.

Now inspect the three additional exact PNGs indexed by frames/*-capture.json,
the complete measured samples (including pre-key/nonmatches), and original
records, then record each personal review through the same tool:

| Label | Required observed content and associated original |
| --- | --- |
| wifi-candidate-searching | Picker shows searching; actual blocked-ready group has two PID/start identities; one list/scanlist call. |
| wifi-candidate-network-return | Network settings returned. capture-back original complete RGB equals the exact reviewed reference; actual key send to complete RGB <=1s, original adapter0. No mask/baseline replacement or subtraction of guest work. |
| wifi-candidate-reopened-searching | Reopened picker still searching. audit-reopen.json retains the identical blocked-ready group and exactly one enumeration call, not a second worker. |

```bash
# Replace each REVIEW_TEXT with a precise observation of the actual named frame.
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" review \
  --label wifi-candidate-searching --review "$REVIEW_TEXT"
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" review \
  --label wifi-candidate-network-return --review "$REVIEW_TEXT"
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" review \
  --label wifi-candidate-reopened-searching --review "$REVIEW_TEXT"
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" cleanup
python3 -I -S -B "$TASK_OWNER/host-affected.py" --owner "$TASK_OWNER" finish
```

Root must inspect audit-wifi-exit.json: actual frontend original0, observation0,
owner0, backend gone within3s, stop/join logs1/1, one scan, no forced cleanup,
observation errors or survivors. These are independent of visual timing. Confirm
installed executable hash and final commit/readback bindings, not earlier overlay
identity. The original failed timing run remains failed; it is not rewritten by
this continuation.

The four Dolphin per-case original result/stdout/stderr/invocation/generated INI
members are under the guest archive's dolphin/. Each seeded stale-enabled INI
must become the complete expected inactive or enabled INI, mode0600, with no
credential temporary. Both inactive wrappers still reach the synthetic marker
and retain helper_status=1; enabled wrappers retain helper_status=0. Compare
all original protected snapshots/sentinel results; no real engine/request claim.

Successful finish requires all four reviewed exact images, original helper and
Wi-Fi outcomes, two-file stopped restoration and normal service restart. It
publishes visual-result.json, allowing the sole lifecycle to verify/export every
guest archive member and stop normally. Root then awaits original launcher,
wrapper, command, monitor, runner, VM and close.py statuses and actual owner
absence. No root acceptance or admission consumption is performed by finish.

On any failed action, do not replay it. Preserve originals and end the existing
handoff with the explicit owner abort marker; the original finally/VM-stop path
owns teardown. A snapshot or cleanup success does not erase the failed action.
If the serial lock remains busy or receipt export times out, the missing channel
stays missing and the run cannot qualify.

#!/usr/bin/env python3
"""Preparation helpers only; called by the preserved composition preparers."""
import hashlib,json,re,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
ES='16dbac5211eea7e70db7394372033be2be7df829'
SCRIPTS={
 'cheevos_dolphin.sh':'01473794711dafd9607e1b6894ec482e34820807b81e1c45c352d5da9768c28a',
 'start_dolphin_gc.sh':'b5e7afb8f3952f8082d4f39c70cffb9e5ccbd7a265cc6c28f1e96aefbb31c568',
 'start_dolphin_wii.sh':'8843d7358f948add1c53851cef2cfb2da2cd93141ad14784c46252bffbada3d7'}
RECIPE_SHA256='cc4e7458e99329518b30b7f78aa38e149d083427f3c8b7e22d7f5e1090d2479b'
MEMBERS=['usr/bin/emulationstation','usr/bin/wifictl','etc/profile',*['usr/bin/'+n for n in SCRIPTS]]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def arguments(parser):
 for name in ['reviewed-final-commit','verification-sha256','inputs-sha256','gui-review-sha256']:parser.add_argument('--'+name,required=True)
 parser.add_argument('--gui-review',type=Path,required=True)
def validate(args,tree,verify):
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert sha(HERE/n)==h,n
 assert re.fullmatch('[0-9a-f]{40}',args.reviewed_final_commit)
 assert subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True,timeout=10).strip()==args.reviewed_final_commit
 for path,want in [(verify,args.verification_sha256),(verify.with_name('inputs.json'),args.inputs_sha256),(args.gui_review,args.gui_review_sha256)]:assert re.fullmatch('[0-9a-f]{64}',want) and sha(path)==want
 report=json.loads(verify.read_text());inputs=json.loads(verify.with_name('inputs.json').read_text())
 assert report['status']=='PASS' and report['source']==inputs['source']==args.reviewed_final_commit and report['es_commit']==inputs['es_commit']==ES
 pin=(tree/'projects/ROCKNIX/packages/ui/emulationstation/package.mk').read_text();assert re.findall(r'^PKG_VERSION="([0-9a-f]{40})"$',pin,re.M)==[ES]
 recipe=tree/'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk'
 assert sha(recipe)==RECIPE_SHA256,'reviewed GENERIC_X64 launcher installation recipe changed'
 for name,h in SCRIPTS.items():
  source=tree/'projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts'/name
  assert sha(source)==h,name+' raw source changed'
  expected=source.read_bytes()
  if name in ['start_dolphin_gc.sh','start_dolphin_wii.sh']:
   expected = expected.replace(b'@DOLPHIN_BACKEND@', b'wayland').replace(b'@GRENDERER@', b'OGL').replace(b'@EXPORTS@', b'export QT_QPA_PLATFORM=wayland')
  assert report['products']['usr/bin/'+name]['sha256']==hashlib.sha256(expected).hexdigest(),name+' installed transformation differs'
 for n in MEMBERS:
  row=report['products'][n];assert re.fullmatch('[0-9a-f]{64}',row['sha256']) and row['bytes']>0 and row['link_chain']=={'resolved':'/'+n,'links':[]}
 assert args.gui_review_sha256=='60b47d050be4d6071ed758092d7024cad25e15381e008418d6f789a48cf7663e'
 review=json.loads(args.gui_review.read_text());assert review['disposition']=='qualified' and review['original_run_rc']==0 and review['no_remaining_host_children']
 consumed=json.loads((HERE/'evidence/admission-consumed.json').read_text());assert consumed['state']=='consumed' and consumed['original_result']['runner_rc']==consumed['original_result']['command_rc']==consumed['original_result']['monitor_rc']==0
 return report

def configure(out,cfg,args,tree,verify,mode):
 report=validate(args,tree,verify)
 (out/'frames').mkdir(mode=0o700);shutil.copytree(HERE/'affected',out/'affected')
 for n in ['host-affected.py','capture-back.py','handoff.py']:shutil.copy2(HERE/n,out/n);cfg['code'][n]=sha(out/n)
 shutil.copy2(args.gui_review,out/'records/gui-review-original.json')
 binding={'guest_build_commit':cfg['commit'],'es_commit':ES,'verification_sha256':args.verification_sha256,'inputs_sha256':args.inputs_sha256,'gui_review_sha256':args.gui_review_sha256,'mode':mode,'packet_seal':sha(HERE/'SHA256SUMS'),'installed_inputs':{'/'+n:report['products'][n]['sha256'] for n in MEMBERS},'installed_facts':{'/'+n:report['products'][n] for n in MEMBERS},'qualified_probe_sha256':sha(HERE/'originals/probe.py'),'packet_files':{str(p.relative_to(out/'affected')):sha(p) for p in sorted((out/'affected').rglob('*')) if p.is_file()}}
 (out/'affected/binding.json').write_text(json.dumps(binding,indent=2)+'\n')
 cfg['affected']=binding
 for f in (out/'affected').rglob('*'):
  if f.is_file():cfg['code'][str(f.relative_to(out))]=sha(f)
 cfg['tools'][str(tree/'tools/vm-visual-qa')]=sha(tree/'tools/vm-visual-qa')
 cfg['affected_guest_limit_bytes']=6*1024**2
 return cfg

# Revision02: bind launcher installation bytes correctly

Original f665dcd087f778d64bac7c9ebf8254a6c7ffdf1c10ecc9a8711b72e04b92c4ef
remains unchanged at `/tmp/pix-m7-affected-installed-continuation-20261015`.
Its raw-source-equals-installed launcher assertion was incorrect before any
preparer or runtime executed. This additive packet changes only that preparation
guard and its binding documentation/provenance. `revision02.diff` is the narrow
revision diff; `changes.diff` remains the historical initial derivative diff.

`prepare_affected.py` still requires the exact three raw source hashes. It now
requires the unchanged Dolphin recipe SHA and applies the exact reviewed image
verifier byte replacement chain to only start_dolphin_gc.sh/start_dolphin_wii.sh:

- `@DOLPHIN_BACKEND@` → `wayland`
- `@GRENDERER@` → `OGL`
- `@EXPORTS@` → `export QT_QPA_PLATFORM=wayland`

The recipe's GENERIC_X64 branch forces OGL, while post_install selects Wayland
and performs these three substitutions. The helper has no substitution and
remains byte-identical. No source guard is relaxed and no installed result is
predicted: actual PASS verifier rows must equal the resulting expected bytes.

Raw recipe from actual committed f8636de1d105275dbf9420bbabbbc26f79abb10f,
qualified original verifier and reviewed next-image verifier are retained under
`evidence/launcher-install-transform/`, with locators, hashes and source-derived
expected rows. Final execution still binds root's actual completed commit/image,
result and inputs. These derived hashes are source expectations, not build or
runtime evidence.

All existing guest fixtures, Wi-Fi measurement/observer/owner, composition
lifecycles, cleanup, timing, frames, acceptance and admission commands are
byte-identical to revision01. AST and exact transformation AST comparison only;
no preparer, helper, fixture, VM, compiler, admission or cache operation ran.

#!/usr/bin/env python3
"""Post-gate adapter only; called by the accepted composition lifecycle."""
import base64,fcntl,hashlib,io,json,shlex,tarfile,time,zlib
from pathlib import Path

def lock_owned(root,seconds=8):
 stream=(root/'serial.lock').open('a');deadline=time.monotonic()+seconds
 while True:
  try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);return stream
  except BlockingIOError:
   if time.monotonic()>=deadline:stream.close();raise TimeoutError('sole operator serial lock remained held')
   time.sleep(.05)

def export(root,serial,write):
 text=serial('affected-export','python3 -I -S -B /tmp/pix-affected-input/guest-affected.py export',seconds=35)
 (root/'records/affected-export.serial').write_text(text)
 def only(prefix):
  rows=[s.split('=',1)[1] for s in text.splitlines() if s.startswith(prefix+'=')];assert len(rows)==1;return rows[0]
 rows=json.loads(base64.b64decode(only('PIX_AFFECTED_MANIFEST'),validate=True));raw=base64.b64decode(only('PIX_AFFECTED_ARCHIVE'),validate=True)
 receipt=json.loads(only('PIX_AUDIT_JSON'));assert len(raw)<=4*1024**2 and hashlib.sha256(raw).hexdigest()==receipt['archive_sha256']
 assert len(rows)<=1024 and sum(r['bytes'] for r in rows)<=6*1024**2
 (root/'records/affected-guest.tar.gz').write_bytes(raw);write(root/'records/affected-guest-members.json',rows);write(root/'records/affected-guest-export.json',receipt)
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
  members=archive.getmembers();assert len(members)==len(rows) and {m.name for m in members}=={r['path'] for r in rows}
  for row in rows:
   p=Path(row['path']);assert not p.is_absolute() and '..' not in p.parts and p.parts[0]!='originals'
   m=archive.getmember(row['path']);assert m.isfile() and m.size==row['bytes']
   data=archive.extractfile(m).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 write(root/'records/affected-guest-verified.json',{'rc':0,'files':len(rows),'archive_sha256':hashlib.sha256(raw).hexdigest(),'every_member_bytes_verified':True})
 return receipt

def run(root,config,deadline,serial,observe,alive,write):
 assert deadline-time.monotonic()>240,'composition used remaining affected-case budget'
 files={str(p.relative_to(root/'affected')):base64.b64encode(p.read_bytes()).decode() for p in sorted((root/'affected').rglob('*')) if p.is_file()}
 assert len(files)<=32 and sum(len(x) for x in files.values())<=512*1024
 code="import base64,json;from pathlib import Path;r=Path('/tmp/pix-affected-input');assert not r.exists();r.mkdir();files="+repr(files)+"\nfor name,data in files.items():\n p=r/name;assert p.is_relative_to(r);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(data,validate=True))\nprint('PIX_AFFECTED_PROVISIONED')"
 encoded=base64.b64encode(zlib.compress(code.encode(),9)).decode();invoke='import base64,zlib;exec(zlib.decompress(base64.b64decode('+repr(encoded)+')))'
 assert len(invoke.encode())<120*1024,'one physical serial argument bound'
 with lock_owned(root):
  serial('affected-stage','python3 -I -S -B -c '+shlex.quote(invoke),seconds=30)
  # Retain marker before init: partial initialization still owes bounded cleanup.
  (root/'affected-staged').write_text('private payload staged after accepted composition gates\n')
  text=serial('affected-init','python3 -I -S -B /tmp/pix-affected-input/guest-affected.py init',seconds=45)
  rows=[json.loads(s.split('=',1)[1]) for s in text.splitlines() if s.startswith('PIX_AUDIT_JSON=')];assert len(rows)==1 and rows[0]['rc']==0
  write(root/'audit-init.json',rows[0])
 write(root/'visual-ready.json',{'phase':'root sole serial/HMP/input operator under serial.lock','deadline_monotonic':deadline,'remaining_seconds':deadline-time.monotonic(),'original_family_budget_continues':True})
 print('AFFECTED INSTALLED CASES READY; root sole operator; original family deadline continues',flush=True)
 while not (root/'visual-result.json').exists():
  assert not (root/'abort').exists(),'operator aborted; preserve failed originals'
  assert time.monotonic()<deadline and alive(),'family deadline or QEMU identity changed'
  observe();time.sleep(.5)
 with lock_owned(root):
  result=json.loads((root/'visual-result.json').read_text());assert result['guest']['rc']==0 and not result['guest'].get('aborted')
  receipt=export(root,serial,write)
 return {'rc':0,'handoff':result,'export':receipt}

def cleanup(root,serial,write):
 if not (root/'affected-staged').exists() or (root/'records/affected-guest-export.json').exists():return
 # Failure-only best-effort snapshot; original VM stop tears down this disposable
 # guest, including the finite observer and private backend bind. A missing
 # restoration/observer exit remains unknown and prevents qualification. No
 # invented success, signal by process name, or new cleanup time budget.
 with lock_owned(root,seconds=1):
  command='python3 -I -S -B /tmp/pix-affected-input/guest-affected.py export && sync'
  text=serial('affected-failure-export',command,seconds=10)
  (root/'records/affected-failure-export.serial').write_text(text)

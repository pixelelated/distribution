# SM8550 ABL retry — finite independent source review

No concrete source blocker found in the author-frozen draft at
`/tmp/pix-m7-sm8550-abl-retry-20261015`. This is clearance of the reviewed
source delta for root's preparation/allocation review, not a successful retry,
cache-copy result or artifact acceptance. The draft was unsealed during this
review; `reviewed-identities.json` binds its 68 exact files. The author confirmed
no changes were in flight. Any executable change needs a corresponding review.

The finite review read the complete `changes.diff`, preparer, new guards,
five-file ABL expectations, affected reader, command dispatch, ordinary stage
consumer and relevant inherited cache/build/acceptance paths. Independent
read-only Git-object and small original-receipt comparisons completed with
110 assertions (tool observation `662d7d`, original exit 0). These are source
and evidence readbacks, not candidate tests. No preparer/helper was imported or
executed, and no cache, binary archive, process/container census, admission,
compiler, VM, network or shared record was operated.

## Source and ancestry

- `verify-source-delta.py:11–20` and `source-delta.json` bind new source
  `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea` against accepted VM/H700
  `f8636de1d105275dbf9420bbabbbc26f79abb10f`. Independent Git readback confirms
  exactly one changed product path, `projects/ROCKNIX/packages/tools/rocknix-abl/package.mk`,
  and precisely one checksum replacement, 4fcf983a… to 64034fb0…. The remaining
  package/project/config/script/distribution/Makefile/license scope is unchanged.
- The seven entries in `frozen-tools.json` match actual 9aa7 Git bytes. Ordinary
  build-admission is 8923610c… and the checker is 65ab515e…. Makefile, watch-build,
  watch-job, submit, build-preflight and retention-report are byte-identical
  across f863→9aa7. No recovery route or old admission hash is introduced.
- `verify-cache-parent.py:14–46` binds the actual stopped SM04 source and exact
  original evidence. Rehashed all 19 declared parent references; the actual
  cache admission ce9f85bb… is consumed with numeric 0/0/0, while build admission
  d8ae8d16… is consumed with numeric 2/0/2. Their completion dispositions are
  respectively qualified and failed-investigated. Completion evidence members
  were also rehashed. The old producer is never treated as accepted firmware.
- Rehashed all six VM and nine H700 references. The VM accepted artifact-reader
  result retains the producer's explicit `qualification: false` and unknown
  original launcher status. H700 e8107b4b… remains attributed to f863; its prior
  producer and selected-state failures remain represented. No new SM result is
  inherited from either artifact.

## Fresh owner, cache and canonical build

- `prepare-owner.py:20–51` requires fresh SM05/owner02 paths, exact clean source,
  actual-host UID/GID/PID namespace, reviewed parent, published-source ancestry,
  fresh timestamp, exact evidence hashes and completed H700 acceptance before
  deriving inputs. `:65–88` replaces stale cache/source identities, preserves
  the historical ARM manifest only as a comparison baseline, and binds the
  current host checker separately.
- The copied cache has the same logical container prefix expected by generated
  files. The unchanged copy helper independently copies the declared ARM and
  AArch64 roots and private Nix store, checks rsync checksums and cross-root
  inode separation, and does not import old target/release as new outputs.
  The old parent and its private Nix store remain protected inputs. Original
  source and failed receipts are read-only dependencies throughout.
- The inherited 12 normal package cleans, FEX reader/self-check, container
  observation, TMPDIR check and build helper are byte-identical to the reviewed
  parent. Explicit ROCKNIX/SM8550/aarch64 host gateway matches an admitted
  profile; the unchanged Makefile's inline ARM then AArch64 assignments override
  that gateway default for each canonical inner stage. No install-only route
  or handwritten stamp bypass was added.
- Preparation retains fresh measured copy demand plus reserve, 300 GiB build
  and 64 GiB acceptance reservations without deletion credit. Each runtime
  stage still uses fresh preflight, retention report, ordinary admission,
  watched submission and original-channel consumption. These guards are
  source-reviewed here; their actual current readbacks remain root's duty.

## Five ABL files and independent acceptance

- `verify-additions.py:68–85` requires exactly five package files: signed SM8550
  ELF, README, backup script, restore script and transformed flash script.
  The four support expectations match exact 9aa7 source bytes; the only flash
  transform is literal `%DEVICE%` to `SM8550`.
- The fifth expected file is bound to root's existing bounded archive reader:
  SHA-256 `8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c`,
  258,048 bytes and mode 0644, in archive 64034fb0…. The source guard hashes
  the exact root reader/result and checks its original 0/0/0 result. This
  review read only those existing metadata, not the archive or target ELF.
- Support-file mode expectations correctly use the actual frozen source
  permissions copied by `cp -a`; Git's executable-bit modes are not mistaken
  for complete filesystem permissions. The ELF mode uses the archive value.
  Package/unpacked/source/staged byte comparisons and staged-versus-SYSTEM
  bytes/mode/link comparisons remain; the unchanged firmware reader compares
  the exact five boot files in update TAR and raw image, as well as SYSTEM,
  KERNEL, GPT, generated ARM handoff and all affected products.
- The corrected checker remains bound both for imported filesystem reading and
  selected-state acceptance against the actual update TAR. The existing
  independent candidate bundle, source/identity checks, FEX mappings and owned
  scratch removal remain mandatory. Twenty inherited helper/proof files were
  independently checked byte-identical to parent packet 60a59605….

## Remaining execution and scope boundaries

Root must supply the actual reviewed audit/VM/publication inputs, allocate fresh
capacity and run the ordinary guarded stages. No successful SM8550 retry,
image, current ARM manifest or consumption receipt exists by virtue of this
review. Existing original failures stay failed. Numeric historical PID absence
checks can conservatively refuse a recycled live PID; they do not authorize
signalling or whole-host privileged visibility. Physical boot/gameplay, RC or
publication approval, OpenABL adoption, and LinuxLoader corresponding-source/
notice custody under #528 remain outside this packet.

Key reviewed identities:

| File | SHA-256 |
| --- | --- |
| changes.diff | 976bddaa099994d57dcbeb61d06cb34a3ac94fc5249dabc12cbaa1d368896bbd |
| prepare-owner.py | 3aef6c74ab61cff722d5c73b3201d7aef236fc3e30112095a36bddbd8c60b60c |
| verify-cache-parent.py | 82059f1d609c265e3aad209b273c59750af757f50b1a9339f12fe92bc95c5b06 |
| verify-source-delta.py | 3e348179cd8aebbf51c8ea4760b175fd85e5513b624a54883a2bab552008cfad |
| verify-additions.py | 1c6c2cd03149cff8d022079a9da22e0ebde105122444968a0dc823de3862b8eb |
| abl-expected.json | 047dbd66f4a483a42a3625e09942ad2d490ebd374ad6348131ab9431fe4a6e60 |

No source changes requested. Only this new private review directory was written.

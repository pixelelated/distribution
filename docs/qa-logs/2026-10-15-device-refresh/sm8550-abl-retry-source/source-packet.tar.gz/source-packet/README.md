# #600 SM8550 checksum retry — SOURCE ONLY / UNRUN

Fresh source: `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea`.
Fresh branch/checkout: `build/m7-pixelelated-sm8550-05` at
`/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05`.
Fresh owner: `/workspace/tmp/pix-m7-sm8550-refresh-20261015-02`.
The container retains logical prefix `m7-pixelelated-sm8550-01` because the
independently copied generated files embed that prefix.

This packet derives from sealed `60a59605` at
`/tmp/pix-m7-sm8550-parent-doc-20261015`. It has not created a worktree/owner,
measured or copied a cache, prepared admission, opened an archive, compiled,
executed a checker or run a VM. Root owns all those actions after source review.

## Exact provenance, source and tools

The parent is stopped SM04 at f863, with original independent cache copy
`20261015T065844Z-a2efce5f` consumed qualified after all zero channels, followed
by canonical partial build `20261015T072058Z-efba76e3`, original 2/0/2 and
launcher 2, consumed failed-investigated as `d8ae8d1653ab46b48d296f20f1cb17d4`.
The parent is not an accepted build or image. `cache-parent-baseline.json`
binds those exact inputs, channel/consumption records, investigation and the
original parent cache receipts. The new guard rechecks clean f863 tracked
source, original evidence bytes, exited recorded owners and absent exact CID.
No old receipt or payload is rewritten.

The new product diff against the accepted VM/H700 f863 is exactly one path:
`projects/ROCKNIX/packages/tools/rocknix-abl/package.mk`, changing only the
archive checksum from `4fcf983a…` to `64034fb0…`. `source-delta.json` and
`product-delta.diff` bind the full product scope and both recipe hashes.
The source gate requires that exact Git difference and unchanged remaining
product bytes. Accepted H700 e8107b4b and VM f863 records retain their original
identities and qualifications; no new SM acceptance is inherited from them.
The VM producer's #597 null launcher/nonqualification remains distinct from
its separately accepted artifact reader.

9aa7 also contains newer host tools. `frozen-tools.json` binds the exact seven
tools from that commit, including ordinary admission `8923610c…` and checker
`65ab515e…`. Every allocation uses the new checkout's own ordinary admission
and watcher; **no #597 recovery route is used**. The installed reader imports
that exact checker for its existing filesystem readers, and independent state
acceptance retains its separately copied, hash-bound 65ab checker/212-control
provenance. No source equality with old f863 host tools is claimed.

The historical ARM manifest remains only a hash-bound comparison baseline.
The new canonical ARM stage and installed reader must produce a new actual
ARM manifest; the new AArch64 handoff and immutable firmware bundle bind it.
The old owner never reached that final reader, so no current accepted ARM
manifest is invented. Fresh SM identity uses root's new actual timestamp;
the previous H700/VM timestamp is not forced onto this retry.

## Cache, build and artifact checks

Preparation measures only the declared parent ARM/AArch64 roots, shared source
cache and parent owner's private Nix store. The copy stage independently
copies both build roots and Nix to the fresh tree/owner, checks rsync content
equality and independent regular-file inodes, and preserves original status
channels. It never copies parent target/release as a new accepted image.
No deletion credit, hardlink sharing with the parent, install-only bypass or
handwritten stamp adjustment is introduced.

The existing 12 normal package cleans remain: alsa-ucm-conf, raofflineproxy,
rclone, rocknix, emulationstation, gstreamer, emulators, linux, dolphin-sa,
steam, fex-emu and rocknix-abl. The normal image stamp removal and canonical
`make docker-SM8550` gateway with ROCKNIX/SM8550/aarch64 remain, with inner
`make SM8550` building ARM then AArch64. Existing container/image/TMPDIR/
host-options/source/ES/account gates and actual original channels remain.

FEX is rebuilt from e869aa64 with the unchanged recipe-selected nixpkgs
b6018f87 URL. The existing actual-container streaming-hash self-check, current
generated rootfs/toolchain provenance and all 14 installed ELF checks remain;
old payload hashes or snapshot overrides are not accepted. The streamed Nix
installer-response and corresponding-source limitations remain explicit.

`abl-expected.json` binds root's actual data-only archive readback
`073255Z-7090925f`: archive SHA64034fb0, 1,411,543 bytes, SM8550 ELF
`8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c`,
258,048 bytes, mode0644, companion checksum matching. All five installed files
must match exact expected bytes and the archive/source-preserved modes (the
actual frozen source permissions for support files): that ELF, README, backup_abl.sh,
restore_backup_abl.sh, and the `%DEVICE%`→`SM8550` flash template. The existing
source/unpacked/staged/extracted SYSTEM and update/raw comparisons remain.
Root's archive receipt is evidence, not an ELF execution or source-notice
clearance. LinuxLoader e9d37131 implementation/source custody remains open.

All original raw/update SYSTEM and KERNEL, GPT, bootloader, source identity,
ELF, generated ARM handoff, selected installed-state and scratch-cleanup checks
remain. Independent firmware acceptance must succeed before consumption.
No physical boot/gameplay, RC, publication or #528 clearance follows from this
source packet or from a future successful engineering artifact check.

## Root commands after review

Root supplies current audit/VM evidence paths and hashes, completed publication
proof for 9aa7 and a fresh actual UTC timestamp less than 24 hours old. The
exact published-source ancestor guard is retained. Do not reuse the old pair's
timestamp merely to match its filename or identity.

```bash
export TASK_H700_ACCEPTANCE_SHA256=e8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db
# Set TASK_TIMESTAMP and TASK_{AUDIT,VM,PUBLICATION}_{EVIDENCE,SHA256}
# to actual reviewed current values before preparation.
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 create
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 prepare
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 cache
# Supervise originals, inspect copy equality/inodes and terminal channels.
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 consume-cache
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 build
# Supervise originals, inspect completed producer/installed results.
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 consume-build
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 acceptance
# Review independent raw/update originals and clean teardown before consuming.
bash /tmp/pix-m7-sm8550-abl-retry-20261015/commands.sh SM8550 consume-acceptance
```

Each stage retains fresh preflight, retention report, ordinary admission and
watch-build submission. Root allocates only one serialized runtime and actively
supervises at ≤60-second cadence; submission is not completion. Never precreate
launcher final receipts. Proposed inherited reservations are max(600GiB, fresh
copy bytes+300GiB) for cache, 300GiB for build and 64GiB for independent firmware
acceptance, without deletion credit. Canonical global24/WebKit4 concurrency is
unchanged. Fresh measurements, guards and original exits determine readiness.

`changes.diff` is the finite executable delta from the exact parent packet;
unchanged helper byte identities and original metadata hashes are in the
static review. Nothing from a source-only static PASS is a runtime PASS.

from pathlib import Path
import hashlib,json,tarfile
O=Path(__file__).resolve().parent
P=Path('/workspace/cache/rocknix-sources/rocknix-abl/rocknix-abl-1.2.tar.gz')
s=P.stat(); assert P.is_file() and not P.is_symlink() and s.st_size==1411543
h=hashlib.sha256(P.read_bytes()).hexdigest(); assert h=='64034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7'
rows=[];data={};total=0
with tarfile.open(P,'r:gz') as t:
 for m in t:
  assert len(rows)<100 and not m.name.startswith('/') and '..' not in Path(m.name).parts
  assert m.isfile() or m.isdir()
  total+=m.size;assert total<=64*1024*1024 and m.size<=16*1024*1024
  row={'name':m.name,'size':m.size,'mode':m.mode,'kind':'file' if m.isfile() else 'directory'}
  if m.isfile():
   b=t.extractfile(m).read();assert len(b)==m.size;row['sha256']=hashlib.sha256(b).hexdigest();data[m.name]=b
  rows.append(row)
member='rocknix-abl-v1.2/abl_signed-SM8550.elf';payload=data[member];assert payload[:4]==b'\x7fELF'
companion=data[member+'.sha256'].decode().strip().split();assert companion[0]==hashlib.sha256(payload).hexdigest();assert companion[-1].lstrip('*')==Path(member).name
assert P.stat().st_ino==s.st_ino and P.stat().st_size==s.st_size and P.stat().st_mtime_ns==s.st_mtime_ns
result={'result':'PASS','archive':str(P),'archive_sha256':h,'bytes':s.st_size,'member_count':len(rows),'uncompressed_bytes':total,'members':rows,'SM8550_member':member,'SM8550_sha256':hashlib.sha256(payload).hexdigest(),'companion_checksum_matches':True,'extraction_or_execution':False}
with (O/'result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))

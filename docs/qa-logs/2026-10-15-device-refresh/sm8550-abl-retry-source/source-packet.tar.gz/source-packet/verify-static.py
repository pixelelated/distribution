"""Source-only parsing/byte/schema review; never execute a candidate helper or inspect caches."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
P=Path(__file__).resolve().parent;S=Path('/tmp/pix-m7-sm8550-parent-doc-20261015')
T=Path('/workspace/repos/rocknix.worktrees/m7-player-setup');checks=[]
def sha(p):
 assert p.is_file() and not p.is_symlink() and p.stat().st_size<20*1024**2
 return hashlib.sha256(p.read_bytes()).hexdigest()
def check(name,value):assert value,name;checks.append(name)
def load(p):return json.loads(p.read_text())
for f in sorted(P.rglob('*.py')):
 ast.parse(f.read_text(),filename=str(f));checks.append('AST '+str(f.relative_to(P)))
for f in sorted(P.rglob('*.sh')):
 r=subprocess.run(['bash','-n',str(f)],capture_output=True,text=True)
 check('bash syntax '+str(f.relative_to(P)),r.returncode==0 and not r.stdout and not r.stderr)
for f in sorted((P/'templates/SM8550').rglob('*')):
 if f.is_file() and f.name!='verify-source.py':check('unchanged template '+str(f.relative_to(P)),f.read_bytes()==(S/f.relative_to(P)).read_bytes())
for name in ['verify-fex.py','verify-h700-acceptance.py','consume-stage.py','dolphin-sys-source-manifest.json','proxy-source-proof.json','host-checker-binding.json','actual-h700-binding.json','host-checker/pixelelated-state-check']:
 check('unchanged helper/proof '+name,(P/name).read_bytes()==(S/name).read_bytes())
check('prior sealed packet identity',sha(P/'originals/parent-packet-SHA256SUMS')==sha(S/'SHA256SUMS'))
parent=load(P/'cache-parent-baseline.json');refs=parent['originals']
for name,row in refs.items():check('exact original metadata '+name,sha(Path(row['path']))==row['sha256'] and Path(row['path']).stat().st_size==row['bytes'])
check('actual copied parent inputs',sha(P/'originals/SM8550/parent-inputs.json')==refs['parent_inputs']['sha256'])
for prefix,rc,disposition in [('cache',0,'qualified'),('failed',2,'failed-investigated')]:
 r=load(Path(refs[prefix+'_runner']['path']));c=load(Path(refs[prefix+'_consumed']['path']));e=load(Path(refs[prefix+'_completion']['path']))
 check(prefix+' original status binding',[r[k] for k in ['command_rc','monitor_rc','runner_rc']]==[rc,0,rc] and c['original_result']==r and e['expected_rc']==rc and e['disposition']==disposition)
 check(prefix+' consumed evidence identity',c['evidence_sha256']==refs[prefix+'_completion']['sha256'] and c['state']=='consumed')
check('parent source status capture is clean',parent['status_hex']=='')
new='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea';old='f8636de1d105275dbf9420bbabbbc26f79abb10f';d=load(P/'source-delta.json')
raw=subprocess.check_output(['git','-C',str(T),'diff','--binary',old,new,'--',*d['product_scope']])
check('exact Git product diff',raw==(P/'product-delta.diff').read_bytes() and hashlib.sha256(raw).hexdigest()==d['diff_sha256'])
names=subprocess.check_output(['git','-C',str(T),'diff','--name-only',old,new,'--',*d['product_scope']],text=True).splitlines()
check('one changed product path',names==d['changed_paths']==['projects/ROCKNIX/packages/tools/rocknix-abl/package.mk'])
for name,h in load(P/'frozen-tools.json').items():
 raw=subprocess.check_output(['git','-C',str(T),'show',new+':'+name]);check('new source tool '+name,hashlib.sha256(raw).hexdigest()==h)
check('ordinary new admission identity',load(P/'frozen-tools.json')['tools/host-maintenance/build-admission']=='8923610caf6a8a1b32775bc1a7e3f67d5e5d5b7468955b35fd40d07da2e2047d')
check('copied and tree checker same current identity',sha(P/'host-checker/pixelelated-state-check')==load(P/'frozen-tools.json')['tools/pixelelated-state-check']=='65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6')
check('no stale imported checker identity','6d061af89caba886bd3417ee96dc01e37675655aa1ed92f423b9db02164dff03' not in (P/'verify-additions.py').read_text())
expected=load(P/'abl-expected.json');archive=load(Path(refs['abl_result']['path']))
check('five expected ABL files',len(expected['files'])==5 and len({r['installed_path'] for r in expected['files']})==5)
elf=next(r for r in expected['files'] if r['installed_path'].endswith('.elf'))
check('actual root archive member binding',elf['expected_installed_sha256']==archive['SM8550_sha256']=='8c27a70961476b327071ada2fd9b9c55dd2dcdc913eff3d33f2576133d7e398c' and archive['companion_checksum_matches'] is True)
for r in expected['files']:
 if r.get('source_sha256'):
  data=subprocess.check_output(['git','-C',str(T),'show',new+':'+r['source']]);check('ABL source '+r['source'],hashlib.sha256(data).hexdigest()==r['source_sha256'])
  if r['source'].endswith('.template'):data=data.replace(b'%DEVICE%',b'SM8550')
  check('ABL expected byte transform '+r['installed_path'],hashlib.sha256(data).hexdigest()==r['expected_installed_sha256'] and len(data)==r['expected_installed_bytes'] and r['expected_installed_mode'] is None)
old_ast=ast.parse((S/'verify-additions.py').read_text());new_ast=ast.parse((P/'verify-additions.py').read_text())
for node in old_ast.body:
 if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
  other=next(x for x in new_ast.body if isinstance(x,type(node)) and x.name==node.name);check('unchanged additions function '+node.name,ast.dump(node)==ast.dump(other))
print(json.dumps({'result':'PASS_STATIC_ONLY','checks':checks,'count':len(checks),'candidate_helpers_executed':False,'cache_archive_or_runtime_inspected':False,'runtime_qualified':False},indent=2))

"""Read only: require the actual new consumed H700 acceptance before SM8550 preparation."""
from pathlib import Path
import argparse,hashlib,json,re
q=argparse.ArgumentParser();q.add_argument('--acceptance',type=Path,required=True);q.add_argument('--sha256',required=True);a=q.parse_args()
P=Path(__file__).resolve().parent
O=Path('/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01')
T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04')
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
actual=load(P/'actual-h700-binding.json')
assert actual['acceptance_sha256']==a.sha256=='e8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db'
for row in actual['files']:assert sha(row['path'])==row['sha256'],row['path']
assert a.acceptance==O/'artifacts/acceptance.json' and a.acceptance.resolve(strict=True)==a.acceptance
assert re.fullmatch('[0-9a-f]{64}',a.sha256) and sha(a.acceptance)==a.sha256
h=load(a.acceptance)
assert h['result']=='PASS' and h['distribution_commit']==COMMIT and h['scratch_removed'] is True and h['source_unchanged'] is True
assert len(h['variants'])==2 and {r['variant'] for r in h['variants']}=={'DDR3','DDR4'}
assert h['producer_combined_run_returncode']==1 and h['failed_acceptance_returncode']==1
hc=load(P/'host-checker-binding.json')
assert hc['host_checker_sha256']=='65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6'
assert sha(P/'host-checker/pixelelated-state-check')==hc['host_checker_sha256']==h['host_checker']['sha256']
assert h['host_checker']['tests_sha256']==hc['host_checker_tests_sha256'] and h['host_checker']['controls_run']==hc['controls_run']
assert h['host_checker']['controls_stdout_sha256']==hc['controls_stdout_sha256'] and h['host_checker']['controls_count']==212
prior=load(O/'acceptance-consumption.json');assert prior['result']=='PASS' and prior['stage']=='acceptance' and prior['acceptance_sha256']==a.sha256
run=Path(prior['run']);assert run.parent==T/'.build-runs' and run==Path((O/'run.path').read_text().strip())
result=load(run/'runner-result.json');assert prior['original_result']==result
assert all(type(result[n]) is int and result[n]==0 for n in ['command_rc','monitor_rc','runner_rc'])
c=load(run/'admission-consumed.json');assert sha(run/'admission-consumed.json')==prior['consumed_receipt_sha256']
assert c['id']==actual['admission'] and str(run)==actual['run']
assert c['state']=='consumed' and c['original_result']==result and c['run']==str(run) and c['submission_owner']==str(O)
assert c['source']['head']==COMMIT and c['outputs_held'] is True and c['deleted_bytes']==0
e=load(O/'admission-completion-evidence.json')
assert sha(O/'admission-completion-evidence.json')==prior['completion_evidence_sha256']==c['evidence_sha256']
assert e['disposition']=='qualified' and type(e['expected_rc']) is int and e['expected_rc']==0 and e['run']==str(run)
for row in e['evidence']:assert sha(row['path'])==row['sha256'],row['path']
assert load(O/'artifacts/selected-state.stdout')['status']=='pass'
launch=load(O/'launcher-result.json');assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',O/'artifacts/selected-state.exit',run/'build.rc']:assert p.read_text().strip()=='0',p
pids={launch['pid']}
for n in ['build.pid','command.pid','watcher.pid','build.status.pid']:
 p=run/n
 if p.exists():pids.add(int(p.read_text().strip()))
assert all(not Path('/proc',str(pid)).exists() for pid in pids)
print('PASS exact new H700 acceptance consumed original0; same corrected host checker bound')

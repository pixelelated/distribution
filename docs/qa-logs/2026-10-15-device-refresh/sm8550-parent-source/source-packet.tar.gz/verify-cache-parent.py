"""Read-only exact known generated-document delta; never ignore arbitrary dirty parents."""
from pathlib import Path
import argparse,json,hashlib,subprocess
q=argparse.ArgumentParser();q.add_argument('--baseline',type=Path,required=True);a=q.parse_args();b=json.loads(a.baseline.read_text());T=Path(b['parent'])
assert T==Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-03') and T.resolve(strict=True)==T
assert b['documentation_path']=='documentation/PER_DEVICE_DOCUMENTATION/SM8550/SUPPORTED_EMULATORS_AND_CORES.md'
def git(*args):return subprocess.check_output(['git','-C',str(T),*args])
assert git('rev-parse','HEAD').decode().strip()==b['head']=='bc9dfe8141d9561dc1d8502313d00a84c4566ee8'
assert git('status','--porcelain=v1','-z').hex()==b['status_hex']
p=T/b['documentation_path'];assert p.is_file() and not p.is_symlink()
assert hashlib.sha256(p.read_bytes()).hexdigest()==b['documentation_sha256']
assert hashlib.sha256(git('diff','--binary','HEAD','--',b['documentation_path'])).hexdigest()==b['diff_sha256']
assert git('diff','--name-only','HEAD').decode().strip()==b['documentation_path']
assert git('diff','--cached','--quiet')==b''
assert git('diff','--quiet','HEAD','--','packages','projects','config','scripts','distributions','Makefile','LICENSE.md','TRADEMARK.md','tools')==b''
print('PASS exact parent generated-document difference; product/tools unchanged')

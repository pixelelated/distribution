"""Static only: no importing/executing owner, gate, build, reader or checker."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
P=Path(__file__).resolve().parent;old=Path('/tmp/pix-m7-h700-reader-review-20261015/sm8550');checks=[]
def check(n,c):
 assert c,n;checks.append(n)
for p in sorted(P.rglob('*.py')):
 ast.parse(p.read_text());checks.append('AST '+str(p.relative_to(P)))
for p in [P/'commands.sh']:
 r=subprocess.run(['bash','-n',str(p)],capture_output=True,text=True);check('bash-n commands',r.returncode==0 and not r.stdout and not r.stderr)
changed=['prepare-owner.py','commands.sh','templates/SM8550/acceptance/verify-firmware.py']
for p in sorted(old.rglob('*')):
 if p.is_file() and (p.suffix in ['.py','.sh'] or p.name in ['verify-additions.py','verify-fex.py']):
  n=str(p.relative_to(old))
  if n not in changed:check('unchanged helper '+n,(P/n).read_bytes()==p.read_bytes())
oldreader=(old/changed[2]).read_text();newreader=(P/changed[2]).read_text()
check('entire firmware body before checker unchanged',oldreader[:oldreader.index('state=subprocess.run')]==newreader[:newreader.index("checker=owner/")])
check('no frozen checker invocation',"str(tree/'tools/pixelelated-state-check')" not in newreader)
check('copied exact checker',hashlib.sha256((P/'host-checker/pixelelated-state-check').read_bytes()).hexdigest()=='65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6')
check('checker included in acceptance seal',"acc/'pixelelated-state-check',owner/'inputs.json'" in (P/'prepare-owner.py').read_text())
check('separate checker bound in inputs',"j['host_state_checker']=dict(hc,path=str(owner/'acceptance/pixelelated-state-check'))" in (P/'prepare-owner.py').read_text())
check('explicit gateway retained',"env.update(PROJECT='ROCKNIX',DEVICE='SM8550',ARCH='aarch64'" in (P/'templates/SM8550/build.py').read_text())
check('new H700 receipt locator only','/workspace/tmp/pix-m7-h700-reader-20261015-01/acceptance/artifacts/acceptance.json' not in (P/'commands.sh').read_text())
check('new H700 ordinary consumed proof',"c['state']=='consumed'" in (P/'verify-h700-acceptance.py').read_text() and "e['disposition']=='qualified'" in (P/'verify-h700-acceptance.py').read_text())
check('H700 historical seal unchanged',hashlib.sha256((P.parent/'SHA256SUMS').read_bytes()).hexdigest()=='8231f538565241e7f92d35fef96cd6d2705cc34ed6f37dca02e4ac05ae9e26b2')
for line in (P.parent/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);check('H700 sealed payload '+n,hashlib.sha256((P.parent/n).read_bytes()).hexdigest()==h)
actual=json.loads((P/'actual-h700-binding.json').read_text())
for row in actual['files']:check('actual H700 original copy '+row['copy'],hashlib.sha256((P/row['copy']).read_bytes()).hexdigest()==row['sha256'])
check('exact actual H700 run',actual['run'].endswith('/20261015T064734Z-8868082e'))
check('exact actual H700 admission',actual['admission']=='4ebc249f9b7d4e9a8c61cff36cc23fea')
print(json.dumps({'status':'PASS','kind':'source-only AST/bash/byte checks; no owner/gate/checker/preparer/runtime execution','checks':checks,'count':len(checks)},indent=2))

# SM8550 handoff after corrected H700 state acceptance — UNRUN

This independently sealed additive subtree derives from `/tmp/pix-m7-h700-reader-review-20261015/sm8550`. It has not created the SM8550 checkout or owner, prepared admission, copied a cache, compiled, extracted firmware or run a target/helper. The earlier H700 seal and its payloads remain untouched.

Changes are limited to the actual new H700 acceptance dependency and an explicitly separate host checker. `commands.sh` creation and `prepare-owner.py` require `/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01/artifacts/acceptance.json` at the caller's exact SHA256. The new read-only gate checks original zero channels, ordinary consumed receipt, matching completion evidence and absent recorded owners. It preserves both H700 combined-producer1 and failed-state-acceptance1 in provenance. A mere PASS summary cannot substitute for consumed originals.

The preparer copies checker `65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6` into the fresh acceptance owner, seals its bytes and records its separate identity in `inputs.json`. That checker is the same one used by the newly accepted H700 result, with test source `6e0b2eb945b913ad0c176dd532586463493e6984240e128ff771ce6264fd3eec` and the original 212-control host suite. The SM8550 firmware reader verifies the copied checker before invoking it and retains its provenance in the acceptance result. Frozen firmware/source remains f863; the frozen tool in the image/checkout is not replaced.

Actual H700 acceptance is now bound: run `20261015T064734Z-8868082e`, consumed admission `4ebc249f9b7d4e9a8c61cff36cc23fea`, acceptance SHA256 `e8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db`. Compact original acceptance, consumption, channel and selected-state receipts are retained under `actual-h700/` and checked against their original paths. The pre-actual-binding draft seal is historical under `pre-actual-binding-draft/`; it was never released for allocation.

The prior host gateway PROJECT/DEVICE/ARCH correction, canonical ARM then AArch64 build, cache-copy custody, fresh measurements and admission, SM8550 Qt6/gst-plugins-good profile checks, FEX b6018f87 provenance/14 installed outputs, ABL1.2 package/update/raw equality and all other firmware checks are byte-identical. Ordinary success consumers are unchanged. No old FEX carry-forward claim is restored.

## Future root commands

Retain the existing audit/VM/publication evidence environment and the exact timestamp selected for the device pair; set `TASK_H700_ACCEPTANCE_SHA256` only from the actual new consumed acceptance. The inherited preparer requires that timestamp to be less than 24 hours old.

```bash
export TASK_H700_ACCEPTANCE_SHA256=e8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db
export TASK_TIMESTAMP=20261015T052134Z
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 create
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 prepare
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 cache
# Supervise and consume this stage before proceeding.
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 consume-cache
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 build
# Supervise and consume this stage before proceeding.
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 consume-build
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 acceptance
# Supervise actual independent firmware acceptance before success consumption.
bash /tmp/pix-m7-h700-state-resume-20261015/sm8550/commands.sh SM8550 consume-acceptance
```

Source review and preparation are not runtime qualification. The original prepared profile, capacity terms, protected roots and declared output scopes remain inherited; each allocation uses its fresh frozen ordinary admission. No concurrent runtime or physical-device action is authorized by this packet. Artifact acceptance does not establish physical boot, target gameplay, RC status, public source completeness or release permission.

`changes.diff` contains the three edited executables plus the new read-only gate. `source-static-review.json` records only AST/bash/byte validation. The inherited `prior-*` files, `REVIEW-STATUS.json`, `static-review.json`, template derivations and old static receipts are historical evidence from the prior packet; `CURRENT-SOURCE-REVIEW.json` and this subtree's new manifest/seal describe this derivative. No previous source files or receipts outside this new subtree were modified.

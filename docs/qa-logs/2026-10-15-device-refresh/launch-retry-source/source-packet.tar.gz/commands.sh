#!/bin/bash
# Root only: one explicit serialized step. Source packet, not an active allocation.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-h700-launch-review-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04
TASK_OWNER=/workspace/tmp/pix-m7-h700-refresh-20261015-02
TASK_STEP=${1:?prepare, build, consume-build, acceptance, or consume-acceptance}
cd "$TASK_TREE"
case "$TASK_STEP" in
 prepare)
  test ! -e "$TASK_OWNER"
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-continuation.py"
  ;;
 build|acceptance)
  if test "$TASK_STEP" = build; then
   TASK_STAGE_OWNER="$TASK_OWNER"; TASK_CMD=(python3 -I "$TASK_OWNER/build.py")
  else
   TASK_STAGE_OWNER="$TASK_OWNER/acceptance"; TASK_CMD=(python3 -I "$TASK_STAGE_OWNER/run.py")
  fi
  tools/build-preflight
  tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_STAGE_OWNER/retention-plan.json" --output "$TASK_STAGE_OWNER/retention-report.json"
  python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_STAGE_OWNER/admission-plan.json" --output "$TASK_STAGE_OWNER/admission.json"
  tools/watch-build-submit --owner "$TASK_STAGE_OWNER" -- --admission "$TASK_STAGE_OWNER/admission.json" -- "${TASK_CMD[@]}"
  # Submission is not completion. Root supervises actual original channels <=60s.
  ;;
 consume-build|consume-acceptance)
  python3 -I "$TASK_OWNER/consume-stage.py" --owner "$TASK_OWNER" --stage "${TASK_STEP#consume-}"
  ;;
 *) exit 2;;
esac

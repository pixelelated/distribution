#!/usr/bin/env python3
"""Prepare one fresh H700 build/acceptance owner from consumed originals; no cache copy or build."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
P=Path(__file__).resolve().parent;B=json.loads((P/'bindings.json').read_text())
O=Path(B['old_owner']);N=Path(B['new_owner']);T=Path(B['tree'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
assert Path.cwd()==T and not N.exists() and N.parent==Path('/workspace/tmp') and N.name=='pix-m7-h700-refresh-20261015-02'
assert os.getuid()==1000 and os.getgid()==1000 and os.stat('/proc/self/ns/pid').st_ino==4026531836
for line in (P/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(P/n)==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==B['source_commit']
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='build/m7-pixelelated-h700-04'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
subprocess.run(['python3','-I','-S','-B',str(P/'templates/verify-continuity.py'),'--bindings',str(P/'bindings.json')],check=True)
old=json.loads((O/'inputs.json').read_text());j=dict(old)
j['arm_manifest']=str(N/'artifacts/arm-output-manifest.json')
j['container_name']=old['container_name']+'-retry02';j['container_label']=old['container_label']+'-retry02'
j['continuation']={'failed_owner':str(O),'failed_run':B['failed_run'],'failed_admission':B['failed_admission'],'cache_copy_owner':str(O),'cache_admission':B['cache_admission'],'source_packet_sha256':sha(P/'SHA256SUMS'),'bindings_sha256':sha(P/'bindings.json'),'cache_copy_repeated':False,'normal_cleans_repeated':False,'original_inputs_sha256':sha(O/'inputs.json'),'reason':'Exact host gateway profile; same frozen tree and already cleaned independent cache roots.'}
# Original copy provenance stays old, not relabelled as a fresh copy.
assert j['cache_preparation_owner']==str(O)
N.mkdir(mode=0o700);(N/'artifacts').mkdir();(N/'acceptance').mkdir();(N/'acceptance/artifacts').mkdir();(N/'prior-originals').mkdir()
for source in (P/'templates').rglob('*'):
 if source.is_file():
  dst=N/source.relative_to(P/'templates');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dst)
shutil.copy2(P/'bindings.json',N/'continuity-bindings.json')
for row in B['files']:
 dst=N/'prior-originals'/Path(row['copy']).name;shutil.copy2(P/row['copy'],dst);assert sha(dst)==row['sha256']
for n in ['cache-ready.json','cache-consumption.json','capacity-measurement.json']:
 shutil.copy2(O/n,N/n);assert sha(N/n)==sha(O/n)
put(N/'inputs.json',j)
for stage,base,oldbase in [('build',N,O),('acceptance',N/'acceptance',O/'acceptance')]:
 scan=base/'empty-retention-scan';scan.mkdir()
 retention=json.loads((oldbase/'retention-plan.json').read_text());admission=json.loads((oldbase/'admission-plan.json').read_text())
 retention['scan_roots']=[str(scan)];retention['builds'][0]['name']='m7-h700-'+stage+'-retry02'
 retention['protected']+= [str(O),str(N/'continuity-bindings.json')]
 retention['builds'][0]['evidence']+=[{'path':str(N/'continuity-bindings.json'),'sha256':sha(N/'continuity-bindings.json')}]
 retention['builds'][0]['basis']+=' Same-tree continuation after consumed failure2 and eight normal cleans; no second cache copy or deletion credit.'
 admission['retention_plan']=str(base/'retention-plan.json');admission['retention_report']=str(base/'retention-report.json');admission['stage']=retention['builds'][0]['name']
 for row in admission['outputs']:
  if row['path']==str(O):row['path']=str(N)
 assert admission['profiles']==[{'PROJECT':'ROCKNIX','DEVICE':'H700','ARCH':'arm'},{'PROJECT':'ROCKNIX','DEVICE':'H700','ARCH':'aarch64'}]
 put(base/'retention-plan.json',retention);put(base/'admission-plan.json',admission)
files=[f for f in N.iterdir() if f.is_file() and f.suffix in ['.py','.sh','.json'] and f.name!='build-seal.json']
put(N/'build-seal.json',{str(f):sha(f) for f in files})
put(N/'acceptance/seal.json',{str(f):sha(f) for f in [N/'acceptance/run.py',N/'acceptance/verify-firmware.py',N/'inputs.json',N/'verify-additions.py']})
put(N/'preparation.json',{'status':'PREPARED_UNRUN','source':B['source_commit'],'owner':str(N),'original_failed_run':B['failed_run'],'cache_copy_executed':False,'normal_clean_executed':False,'build_executed':False,'admission_prepared':False,'packet_sha256':sha(P/'SHA256SUMS'),'new_container_name':j['container_name']})
print(json.dumps({'owner':str(N),'status':'PREPARED_UNRUN','source':B['source_commit'],'profiles':admission['profiles']}))

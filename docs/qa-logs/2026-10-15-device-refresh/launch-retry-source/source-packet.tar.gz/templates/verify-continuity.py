#!/usr/bin/env python3
"""Read only the exact consumed predecessor and cache transition; never copy/clean/build."""
from pathlib import Path
import argparse,hashlib,json,stat
q=argparse.ArgumentParser();q.add_argument('--bindings',type=Path,default=Path(__file__).resolve().parent/'continuity-bindings.json');a=q.parse_args()
j=json.loads(a.bindings.read_text());O=Path(j['old_owner']);T=Path(j['tree']);R=Path(j['failed_run']);CR=Path(j['cache_run'])
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in j['files']:
 p=Path(row['path']);assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
for p,h in load(O/'build-seal.json').items():assert sha(Path(p))==h,p
for p,h in load(O/'copy-seal.json').items():assert sha(O/p)==h,p
for root in j['cache_root_identities_after_normal_cleans']:
 p=Path(root['path']);assert p.resolve(strict=True)==p;s=p.stat()
 assert {k:root[k] for k in ['device','inode','mode','uid','mtime_ns','size']}==dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,mtime_ns=s.st_mtime_ns,size=s.st_size),str(p)
failed=load(R/'admission-consumed.json');cache=load(CR/'admission-consumed.json')
for row,identity,codes in [(failed,j['failed_admission'],[2,0,2]),(cache,j['cache_admission'],[0,0,0])]:
 assert row['id']==identity and row['state']=='consumed' and row['outputs_held'] is True and row['deleted_bytes']==0
 assert row['source']['head']==j['source_commit']
 assert all(type(row['original_result'][k]) is int and row['original_result'][k]==v for k,v in zip(['command_rc','monitor_rc','runner_rc'],codes))
assert failed['evidence_sha256']==sha(Path('/tmp/pix-m7-h700-launch-failure-20261015/completion-evidence.json'))
proof=load(Path('/tmp/pix-m7-h700-launch-failure-20261015/completion-evidence.json'))
assert proof['run']==str(R) and proof['expected_rc']==2 and proof['disposition']=='failed-investigated'
for row in proof['evidence']:assert sha(Path(row['path']))==row['sha256']
cacheproof=O/'cache-launch/admission-completion-evidence.json';assert cache['evidence_sha256']==sha(cacheproof)
assert load(cacheproof)['disposition']=='qualified' and load(cacheproof)['expected_rc']==0
for row in load(cacheproof)['evidence']:assert sha(Path(row['path']))==row['sha256']
assert load(O/'cache-consumption.json')['result']=='PASS' and load(O/'cache-ready.json')['result']=='PASS'
assert load(O/'launcher-result.json')['runner_returncode']==2
for n in ['inner.rc','outer.rc','tool-wrapper.rc']:assert (O/n).read_text()=='2\n'
assert not (O/'build.cid').exists() and not (O/'artifacts/container-gate.json').exists()
assert not (T/'build.pixelelated-H700.aarch64/.stamps/image/build_target').exists()
log=(R/'build.log').read_text()
for p in j['completed_normal_aarch64_cleans']:assert log.count('./scripts/clean '+p+'\n')==1
assert log.count('watch-build: nested profile is outside admission')==1
print('PASS exact consumed cache copy, eight completed normal cleans and failed main gateway; no cache equality rehash or result relabel')

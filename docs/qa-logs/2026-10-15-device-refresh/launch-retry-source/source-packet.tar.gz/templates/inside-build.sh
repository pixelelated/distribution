#!/bin/bash
set -euo pipefail
python3 -I /workspace/tmp/pix-m7-h700-refresh-20261015-02/container-ready.py
./scripts/checkdeps
make H700

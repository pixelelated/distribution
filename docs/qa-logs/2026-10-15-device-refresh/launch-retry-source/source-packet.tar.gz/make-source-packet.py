"""Source/data transformation only; never import or execute generated helpers."""
from pathlib import Path
import hashlib,json,stat,subprocess,difflib,shutil,ast
P=Path(__file__).resolve().parent
O=Path('/workspace/tmp/pix-m7-h700-refresh-20261015-01');N=Path('/workspace/tmp/pix-m7-h700-refresh-20261015-02')
T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04')
R=T/'.build-runs/20261015T054715Z-62e22248'
CR=T/'.build-runs/20261015T052516Z-5ab9f699'
F=Path('/tmp/pix-m7-h700-launch-failure-20261015')
OLD=Path('/tmp/pix-m7-device-refresh-20261015-04')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
assert sha(OLD/'SHA256SUMS')=='c1a0b3a749168c3b70e57904fcc0710f4a8a150971b5268bfcb2f63b5feeb22e'
for line in (OLD/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(OLD/n)==h
source_names=['build.py','inside-build.sh','verify-source.py','verify-installed.py','observe-container.py','container-ready.py','consume-build.py','consume-stage.py','progress.py','verify-additions.py','proxy-source-proof.json','dolphin-sys-source-manifest.json','acceptance/run.py','acceptance/verify-firmware.py']
files=[O/n for n in source_names]+[O/n for n in ['inputs.json','build-seal.json','copy-seal.json','cache-ready.json','cache-consumption.json','capacity-measurement.json','admission-plan.json','retention-plan.json','acceptance/admission-plan.json','acceptance/retention-plan.json','acceptance/seal.json','launcher-result.json','tool-wrapper.rc','inner.rc','outer.rc','console.log']]+[R/n for n in ['admission.json','admission-input.json','admission-plan.json','admission-consumed.json','runner-result.json','build.rc','build.status','build.log']]+[CR/'admission-consumed.json',F/'investigation.json',F/'completion-evidence.json',F/'originals.json',F/'container-query.exit',F/'container-query.stderr']+[T/n for n in ['Makefile','tools/watch-build','tools/host-maintenance/build-admission','scripts/build_distro']]
for n in json.loads((O/'build-seal.json').read_text()):files.append(Path(n))
files=sorted(set(files));bindings=[]
for i,f in enumerate(files):
 b=f.read_bytes();rel=f'originals/{i:03d}-{f.name}';(P/rel).write_bytes(b);st=f.stat();bindings.append({'path':str(f),'sha256':sha(f),'bytes':len(b),'copy':rel,'mode':stat.S_IMODE(st.st_mode)})
roots=[]
for name in ['build.pixelelated-H700.arm','build.pixelelated-H700.aarch64']:
 f=T/name;s=f.stat();roots.append({'path':str(f),'device':s.st_dev,'inode':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'mtime_ns':s.st_mtime_ns,'size':s.st_size})
assert not (O/'build.cid').exists() and not (O/'artifacts/container-gate.json').exists()
assert not (T/'build.pixelelated-H700.aarch64/.stamps/image/build_target').exists()
log=(R/'build.log').read_text();packages=['alsa-ucm-conf','raofflineproxy','rclone','rocknix','emulationstation','gstreamer','emulators','linux']
for pkg in packages:assert log.count('./scripts/clean '+pkg+'\n')==1,pkg
assert log.count('watch-build: nested profile is outside admission')==1
j=json.loads((R/'admission-consumed.json').read_text());assert j['id']=='9c961fb2910c46c4b476385054464a42' and j['state']=='consumed' and j['original_result']['runner_rc']==2
c=json.loads((CR/'admission-consumed.json').read_text());assert c['id']=='1d779b9f47d347cc87920857562cbe48' and c['state']=='consumed' and c['original_result']['runner_rc']==0
dump(P/'bindings.json',{'old_owner':str(O),'new_owner':str(N),'tree':str(T),'failed_run':str(R),'cache_run':str(CR),'source_commit':'f8636de1d105275dbf9420bbabbbc26f79abb10f','failed_admission':j['id'],'cache_admission':c['id'],'files':bindings,'cache_root_identities_after_normal_cleans':roots,'completed_normal_aarch64_cleans':packages,'limits':'Root identities and original serialized custody, not a new whole-cache equality hash. Cache-ready equality is historical before recorded cleans.'})
for name in source_names:
 s=(O/name).read_text().replace(str(O),str(N))
 if name=='build.py':
  mark=" env.update(DOCKER_WORK_DIR=j['container_worktree'],"
  assert s.count(mark)==1;s=s.replace(mark," env.update(PROJECT='ROCKNIX',DEVICE='H700',ARCH='aarch64',DOCKER_WORK_DIR=j['container_worktree'],")
  a=s.index(' for package in ');b=s.index(" env['DOCKER_EXTRA_OPTS']+=",a)
  s=s[:a]+" # The exact failed owner already completed these normal cleans and image invalidation.\n subprocess.run(['python3','-I','-S','-B',str(O/'verify-continuity.py')],check=True)\n"+s[b:]
 target=P/'templates'/name;target.parent.mkdir(exist_ok=True,parents=True);target.write_text(s)
 (P/(name.replace('/','-')+'.diff')).write_text(''.join(difflib.unified_diff((O/name).read_text().splitlines(True),s.splitlines(True),fromfile='old-owner/'+name,tofile='fresh-owner/'+name)))
# New unallocated SM packet retains the accepted package/acceptance controls.
SM=P/'sm8550';SM.mkdir()
for src in OLD.rglob('*'):
 if src.is_file():
  dst=SM/src.relative_to(OLD);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
(SM/'original-packet-SHA256SUMS').write_bytes((OLD/'SHA256SUMS').read_bytes())
s=(SM/'templates/SM8550/build.py').read_text();mark=" env.update(DOCKER_WORK_DIR=j['container_worktree'],";assert s.count(mark)==1;s=s.replace(mark," env.update(PROJECT='ROCKNIX',DEVICE='SM8550',ARCH='aarch64',DOCKER_WORK_DIR=j['container_worktree'],");(SM/'templates/SM8550/build.py').write_text(s)
# Keep source derivation synchronized for SM; original H700 template remains historical/unselected.
f=SM/'derive-templates.py';s=f.read_text();mark="   clean=['alsa-ucm-conf'";at=s.index(mark);s=s[:at]+"   if dev=='SM8550':\n    s=s.replace(\" env.update(DOCKER_WORK_DIR=j['container_worktree'],\",\" env.update(PROJECT='ROCKNIX',DEVICE='SM8550',ARCH='aarch64',DOCKER_WORK_DIR=j['container_worktree'],\")\n"+s[at:];f.write_text(s)
f=SM/'prepare-owner.py';s=f.read_text();assert "choices=['H700','SM8550']" in s;s=s.replace("choices=['H700','SM8550']","choices=['SM8550']");f.write_text(s)
f=SM/'commands.sh';s=f.read_text().replace('TASK_PACKET=/tmp/pix-m7-device-refresh-20261015-04','TASK_PACKET='+str(SM));s=s.replace('case "$TASK_DEVICE" in H700) TASK_TAG=h700;; SM8550) TASK_TAG=sm8550;; *) exit 2;; esac','case "$TASK_DEVICE" in SM8550) TASK_TAG=sm8550;; *) exit 2;; esac');s=s.replace('/workspace/tmp/pix-m7-h700-refresh-20261015-01/acceptance/artifacts/acceptance.json',str(N)+'/acceptance/artifacts/acceptance.json');f.write_text(s)
(SM/'README-original-packet.md').write_bytes((OLD/'README.md').read_bytes())
(SM/'README.md').write_text('''# SM8550 gateway-profile correction — source only, UNRUN\n\nThis additive copy of original packet04 binds that original seal and permits only fresh SM8550 preparation. The only build behavior change sets the Docker gateway profile explicitly to ROCKNIX/SM8550/aarch64 after clearing ambient build knobs. The existing admission retains both ARM and AArch64 profiles; inner make SM8550 still selects ARM then AArch64. Normal cache-copy,12 package cleans, kernel/FEX/ABL rebuild/readback, source/capacity/observer/consume/acceptance gates are unchanged.\n\ncommands.sh points at this packet and the successful future H700 owner02 acceptance. Root must finish and consume H700 before preparing SM. The shared timestamp is preserved for this coordinated engineering pair; no artifact exists from the failed H700 main launch. Original README, static observations, templates and preparation fields describe the earlier packet; only the new source review/seal qualifies this unrun derivative. H700 entry is rejected; use the sibling continuation adapter. No preparer/container/compiler has executed from this packet.\n''')
changes={}
for name in ['templates/SM8550/build.py','derive-templates.py','prepare-owner.py','commands.sh']:
 before=(OLD/name).read_text();after=(SM/name).read_text();out=P/('sm8550-'+name.replace('/','-')+'.diff');out.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='packet04/'+name,tofile='SM-derivative/'+name)));changes[name]={'original':sha(OLD/name),'candidate':sha(SM/name)}
dump(P/'sm8550-changes.json',changes)
print(json.dumps({'bound_originals':len(bindings),'old_failures_preserved':True,'prepared_runtime_owner':False,'main_gateway_profile_only':'ROCKNIX/H700/aarch64; ROCKNIX/SM8550/aarch64','normal_cleans_already_completed':packages}))

# H700 explicit gateway profile continuation — source only

Ready for root's serialized preparation and allocation. The preparer, build, acceptance, and SM8550 derivative remain UNRUN. The only executed helper was the explicitly authorized read-only continuity verifier; it returned original 0. Static AST/bash syntax checks also returned 0. These are not build or hardware results.

## Exact failure and correction

Frozen source is `f8636de1d105275dbf9420bbabbbc26f79abb10f` in `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04`. Later coordinator record-only commits do not change this binding. Failed owner01 reached `make docker-H700` after eight successful normal AArch64 package cleans and image-stamp invalidation, then failed `watch-build: nested profile is outside admission` before its named main container started. Clean containers had already executed. Run `20261015T054715Z-62e22248`, admission `9c961fb2910c46c4b476385054464a42`, retains command/monitor/runner 2/0/2 and launcher/inner/outer/wrapper 2. Root ordinarily consumed that failure, with outputs held and zero bytes deleted. No original is rewritten or relabelled.

The wrapper cleared PROJECT/DEVICE/ARCH. The canonical Docker target does not infer them from `docker-H700`; the nested guard therefore saw no exact allowed triple. The existing admission already correctly allows ROCKNIX/H700/arm and ROCKNIX/H700/aarch64. This continuation explicitly supplies ROCKNIX/H700/aarch64 at the host gateway. The unchanged Makefile H700 recipe then uses inline `PROJECT=ROCKNIX DEVICE=H700 ARCH=arm` and `PROJECT=ROCKNIX DEVICE=H700 ARCH=aarch64` for its two build_distro commands. Those inline assignments override the inherited gateway defaults. No marker bypass, guard relaxation, source change, or admission-profile expansion is involved.

## Cache and original custody

`bindings.json` binds 58 compact originals, old inputs and both old seals, the exact consumed successful copy, the exact consumed failed build, and both cache-root directory identities after the recorded cleans. Cache-ready's independent-copy checksum equality is historical, before those cleans. This packet makes no present whole-cache equality claim and performs no cache scan/copy/deletion. The completed cleans are alsa-ucm-conf, raofflineproxy, rclone, rocknix, emulationstation, gstreamer, emulators, and linux. Root's serialized custody, original log/source, absent main CID/container-gate, and absent image stamp establish the narrow continuation point.

`verify-continuity.py` rehashes the small bound originals, validates original statuses and consumed receipts, checks the retained root identities and failure transition, and fails closed on mismatch. It runs before preparing and before the new main build. Its post-clean identity/stamp assumptions are deliberately not an after-build acceptance condition. Original cache receipts remain attributed to owner01. Owner02 has fresh inputs, ARM manifest, container name/label, output files, plans, seals, launcher receipts, and acceptance directory. Old source/proof and cache receipts are preserved with their original identities; no launcher-owned file is pre-created.

## Root commands

Run one step at a time from the actual host after the preceding owner has completed and been consumed. Preparation requires the absent owner02, clean frozen branch at f863, UID/GID1000, and original PID namespace4026531836.

```bash
bash /tmp/pix-m7-h700-launch-review-20261015/commands.sh prepare
bash /tmp/pix-m7-h700-launch-review-20261015/commands.sh build
# Actively supervise original launcher/runner/command/monitor/container channels.
# Wait for original completion, then:
bash /tmp/pix-m7-h700-launch-review-20261015/commands.sh consume-build
bash /tmp/pix-m7-h700-launch-review-20261015/commands.sh acceptance
# Wait for original acceptance completion, then:
bash /tmp/pix-m7-h700-launch-review-20261015/commands.sh consume-acceptance
```

Owner is `/workspace/tmp/pix-m7-h700-refresh-20261015-02`. Each build/reader allocation obtains a fresh retention report and ordinary admission. The unchanged current resource/PID/container/source/dependency checks remain mandatory; this packet's earlier readback is not a reservation. Normal successful consumption is unchanged and refuses nonzero results. A failed new run must retain its own originals and be investigated, not forced through the success consumer.

The existing 24 global jobs, WebKit4, container observer, capacity checks, 300GiB build reserve, and 64GiB reader allowance remain. These are operating bounds, not predictions or a new compiler wall-clock deadline. Root supervises at most 60 seconds between observations. No cache preparation/clean step is exposed by this adapter; it does not execute a fresh copy or a second clean.

## Pending SM8550

`sm8550/` is an additive source-only derivative of sealed packet04. Its only build behavior correction is the same explicit ROCKNIX/SM8550/aarch64 gateway triple; normal copy, 12 cleans, kernel/FEX/ABL and firmware/source readers remain. Preparation is restricted to SM8550 and binds successful future H700 owner02 acceptance. Use `sm8550/commands.sh SM8550 <step>` with the existing exact audit/VM/publication evidence environment and pair timestamp, and the actual H700 acceptance02 SHA. H700 must finish acceptance and consumption first. The original H700 templates retained inside that subtree are historical and not an available entrypoint.

Original packet static/review/manifests are retained as historical records; `CURRENT-SOURCE-REVIEW.json` and the new subtree SHA256SUMS identify this derivative. The top SHA256SUMS binds the whole continuation and nested packet. Review found no new source blocker; runtime and device boot remain unqualified until root's original results.

# Additive erratum to sealed readback recovery packet51abff1b

The sealed /tmp/pix-m7-image-readback-recovery-20261015-01 README advised using
the new coordinator admission tool for the frozen reader's ordinary admission.
That advice was wrong. Frozen tools/watch-build requires its own matching
build-admission tool digest; the coordinator8923610c tool applies specifically
to the explicit consume-reporting-failure operation. Ordinary reader preparation
must use the exact frozen runner's admission tool. The first actual submission
therefore refused125 before admission/payload; root preserved it and prepared a
fresh matching frozen-tool admission/subowner. No original receipt was rewritten.

The verifier code and sealed packet remain unchanged. Independent AST/code
review had passed, but the execution advice contradicted the frozen-tool identity
contract and escaped that review. Future handoffs must bind the prepare and
runner tool provenance together; a narrowly authorized recovery-tool exception
must not be generalized into ordinary allocation instructions. Root/auditor own
the actual original failure, corrected reader PASS/consumption and durable learning.
This erratum is source documentation only and does not alter in-flight files.

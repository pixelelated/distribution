# Next H700 → SM8550 engineering build handoff (#555)

Source-only plan, UNRUN. No cache scan, container, compiler, preparer, admission,
VM, account/provider access or source/shared-record mutation was performed.
The existing October11 lifecycle is reusable; its prepared owners and immutable
receipts must not be replayed. Final device source/owners are not allocated here.

## Gates and source freeze

Finish the actual f863 affected clean/retained and native-state evidence, consume
all runtime owners, and complete the applicable #596/#590 audit before H700.
Root reported actual artifact and clean PASS and retained still running when
assigning this task; this plan does not declare the outstanding criteria passed.
#555's live body currently describes completed October11 firmware; root must
record this new source/build scope separately, preserving those accepted results.

Freeze a clean build/* checkout at the final reviewed, committed and published
source with exact remote/hosted-check readback. Compare every product input with
f8636de1d105275dbf9420bbabbbc26f79abb10f and its actual accepted VM image; later
record/tool-only commits may preserve those product bytes but must be explicitly
compared. Product changes require their applicable qualification. Bind final
HEAD/branch, full tracked source/symlink and QA-tool manifest, selected recipe and
patch hashes, builder image ID, host options metadata/hash and actual container
runtime settings. Use one fresh shared dev BUILD_TIMESTAMP for the coordinated
H700/SM8550 set; do not reuse the October11 or x64 timestamp. No RC is allocated.

Fixed f863 inputs are in product-scope.json: ES16dbac, Dolphin6094cfcf with
patch018 and immutable Sys alias, proxyc7ebd1b6 with current patches, rclone1.75.2,
Steam1.0.0.85, FEXe869aa64, ABL1.2, GStreamer1.29.2. Exact recipe hashes are bound.
The selected ScreenScraper shared developer identity is the recipe default only
when no explicit host override exists. Recheck effective selection privately;
record presence/provenance without values. The old host-options hash is a
historical dependency, not proof of current options. Inspect each actual output
using tools/pixelelated-state-check --payload: only the exact selected shared ES
ELF pair has #565/#566's exception; other developer pairs, RA credentials, player
accounts and seeded settings remain refused. This is selected-state inspection,
not an authentication/provider test or complete publication approval.

## Recorded caches and existing lifecycle

| Device | Recorded accepted host root | Required stable container prefix |
| --- | --- | --- |
| H700 | /workspace/repos/rocknix.worktrees/m7-pixelelated-h700-03 | /workspace/repos/rocknix.worktrees/m7-pixelelated-h700-01 |
| SM8550 | /workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-03 | /workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01 |

Both are recorded at bc9dfe8141d9561dc1d8502313d00a84c4566ee8, with separate
build.pixelelated-DEVICE.arm and .aarch64 roots. SM8550 also uses the separately
owned Nix store /workspace/tmp/pixelelated-m7-sm8550-refresh-04/nix. The October12
retirement packet explicitly protected these roots and proved their old absolute
prefix references through the stable container mounts without the removed old
physical trees. This is recorded provenance only, not fresh existence, inode,
quiescence or capacity evidence. Preserve those prefixes; do not rewrite links.

Qualified source templates:
- docs/qa-logs/2026-10-11-device-refresh/h70003/{build.py,inside-build.sh};
  complete named helpers/inputs remain /workspace/tmp/pixelelated-m7-h700-refresh-03.
- docs/qa-logs/2026-10-11-device-refresh/sm855005/prepared/ for compiler/helpers;
  sm855004/prepared and completed-cache for original cache custody.
- h70003/acceptance04 and sm855005/prepared/acceptance05 for independent firmware
  readers. Their original failed attempts are retained alongside successful runs.

Rebind these exact helpers into fresh uniquely named owners/checkouts and reseal
all absolute source/owner/tool paths, inputs, clean list and artifact assertions.
Do not execute the old owner scripts unchanged: they target old source, outputs,
proxy audit hashes and FEX generated toolchains. The existing qualified handheld
cache preparation uses independent checked copies with no cross-root hardlinks,
not a shared mutable cache. If root instead selects the later qualified atomic
cache-relocation mechanism, it needs an explicit reviewed handoff for both ABI
roots and the Nix store, fresh last-consumer proof, identity/absence checks and
consumption; that multi-root device handoff is not prepared by this plan.
No predecessor deletion or cache mutation is authorized by this source review.

Before any copy/transfer and again before compilation, use actual-host dependency
readback, current measured capacity/retention, RAM/swap preflight and current
process/container/admission checks. The old137.8GB H700/177.0GB SM8550 measurements
and old300GiB build reserve are historical, not new capacity proof. Preserve
pinned builder988c0ba5, actual UID/GID, private TMPDIR=/tmp read/write gate,
source-cache and common .git mounts, named container/CID observer and all original
exit/cleanup channels. Heavy package/resource bounds must cover new work below;
no timing estimate is inferred from the older warm builds. Supervise actively.

## Normal package work required

The source delta from accepted bc9d to f863 is33 product paths. Normal package
hashes include the entire package directory; another-device file can invalidate
a shared package. Common changed package directories are alsa-ucm-conf,
emulationstation, emulators, gstreamer, linux, raofflineproxy, rclone and rocknix.
Canonical dependency resolution determines their actual ABI work. Both targets
use Linux7.2, so the added shared7.2 MSM DP patch invalidates their linux package
input even though the code concerns Qualcomm. ALSA's changed SM8250 snippets also
change its common package hash. The device-specific SM8250 overlay/DTS changes do
not authorize inventing H700/SM8550-specific feature claims.

SM8550 additionally needs current dolphin-sa, steam, fex-emu and rocknix-abl.
H700 does not select Dolphin or Steam. Use the existing docker-package-clean
route for affected packages and ordinary build invalidation; clear only the
normal image build stamp when necessary to force image assembly. Never rewrite
package hashes/stamps or call an install-only bypass to retain an old binary.
Both complete canonical ARM→aarch64 targets remain required.

SM8550's concrete extra preparation dependency is FEX. The f863 recipe now
sets NIX_PATH to nixpkgs b6018f87da91d19d0ab4cf979885689b469cdd41 inside make_target,
overriding the old wrapper's7dd199b snapshot. Old verify-fex-cache and verify-fex
bind the previous Nix store/toolchain/rootfs and14 old payload hashes. Preserve
that evidence historically, but obtain/hash the actual new pinned inputs and
rebind the post-build FEX checks to the resulting native AArch64 runtime and
x86/x86_64 thunks. Do not claim the old carry-forward proof verifies this rebuild,
suppress normal invalidation, force the old snapshot or predict new store paths.
The current recipe still downloads the Nix installer at build time: actual fetched
bytes/version/source custody must be recorded; this plan makes no new network or
reproducibility claim. ABL1.2 similarly requires its actual recipe SHA and all
current staged/packaged ABL payload checks, not the old1.1.9 hashes.

## Exact existing command route after fresh owner preparation

The following names are bindings supplied by root's fresh reviewed preparation,
not allocated paths. Run from that actual frozen checkout. **Every ordinary
prepare/launch/consume below uses that checkout's matching tool bytes.** The newer
coordinator consume-reporting-failure tool was solely for #597; it is not an
ordinary admission-tool override. See readback-erratum.md.

```bash
cd "$TASK_TREE"
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- \
  python3 -I "$TASK_OWNER/build.py"
# After actual original channels, observer/CID exits and qualified evidence:
python3 -I tools/host-maintenance/build-admission consume \
  --run "$TASK_ACTUAL_RUN" --evidence "$TASK_OWNER/acceptance.json"
```

The build helper's existing production payload is `make docker-H700
"COMMAND=bash $TASK_OWNER/inside-build.sh"`; inside it executes
`./scripts/checkdeps` then `make H700`. Only after H700 build consumption and
independent firmware acceptance, refresh resource/retention/admission evidence
and execute the corresponding SM8550 payload `make docker-SM8550
"COMMAND=bash $TASK_OWNER/inside-build.sh"`, whose inner canonical command is
`make SM8550` after its rebound FEX/container checks. Both Makefile targets run
`PROJECT=ROCKNIX DEVICE=... ARCH=arm ./scripts/build_distro`, then aarch64.
Do not pre-set internal watch nesting markers. Both ABI profiles and every output
root, source input, cache-copy reserve, target/release and QA scratch belong in
the actual admission plan. Report/admission age and registry-generation checks
remain active. Cache preparation and artifact acceptance have their own owners,
original outcomes and admissions as required; do not label copy/compiler work
record-only or manufacture completion receipts.

Independent acceptance retains H700 DDR3/DDR4 raw/update SYSTEM+KERNEL and exact
variant bootloaders; SM8550 GPT/raw/update, current ABL and complete FEX outputs;
new per-run ARM output manifest/handoff; source/identity/native architecture;
current ES/catalogs, proxy native module, rclone/cloud/helpers and all existing
packaged checks. Rebind obsolete applied-proxy audit source expectations to the
current pin+patch source manifest. Add actual new affected installed mappings:
runemu/wifictl/cloud_oauth/proxyctl, GStreamer scanner/net/controller closure,
and on SM8550 Dolphin018/Sys six resources/relative alias, input/save profiles,
two recipe-transformed launchers, unchanged helper bytes, Steam installer and Python3 dependency.
Use SM8550's actual recipe renderer selection (Vulkan when enabled), not the VM's
OGL exception or raw source launcher hash. Compare staged and extracted bytes,
modes and link chains; preserve independent selected-state payload checks.

The next executable step is narrow owner/source/verifier rebinding, then fresh
host measurements and admission after audit closure. No fresh launch-ready device
owner exists in this packet. Remaining blockers are unfinished acceptance/audit,
final published source binding, current cache/dependency/capacity readback, and
SM8550's changed FEX input proof. Public release/source-custody gates and named
physical actions remain separate; no accepted ordinary-save or broad VM matrix
is replayed solely for this device build.

"""Source checks only. Never import a helper or inspect current cache payloads."""
from pathlib import Path
import ast,hashlib,json,subprocess
P=Path(__file__).resolve().parent
files=sorted(p for p in P.rglob('*') if p.is_file());assert not any(p.is_symlink() for p in P.rglob('*'))
py=[];shell=[]
for p in files:
 if p.suffix=='.py':ast.parse(p.read_bytes(),str(p));py.append(str(p.relative_to(P)))
 elif p.suffix=='.sh':
  r=subprocess.run(['bash','-n',str(p)],capture_output=True,text=True);assert r.returncode==0,(p,r.stderr);shell.append(str(p.relative_to(P)))
loc=json.loads((P/'original-locators.json').read_text())
for name,row in loc.items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==row['sha256'],name
checks=[]
for dev in ['H700','SM8550']:
 root=P/'templates'/dev
 build=(root/'build.py').read_text();inner=(root/'inside-build.sh').read_text();firmware=(root/'acceptance/verify-firmware.py').read_text()
 assert "subprocess.run(['make','docker-"+dev+"','COMMAND=bash '+str(O/'inside-build.sh')],env=env,check=True)" in build
 assert 'make '+dev+'\n' in inner and './scripts/checkdeps' in inner
 assert "'global_jobs':24,'webkit_jobs':4" in build and 'observer.wait()==0' in build
 assert "'.stamps/image/build_target').unlink(missing_ok=True)" in build
 assert "'alsa-ucm-conf', 'raofflineproxy', 'rclone', 'rocknix', 'emulationstation', 'gstreamer', 'emulators', 'linux'" in build
 assert 'NIX_PATH=' not in inner and 'verify-fex-cache' not in inner
 assert "'--payload',str(archive)" in firmware and "'--payload',str(system)" not in firmware
 assert 'archive = bundle / archives[0].name' in firmware
 assert "digest(extracted) == system_hash" in firmware and "digest(kernel_file) == kernel_hash" in firmware
 assert "scratch.rmdir()" in firmware and "candidate-store'), 'verify'" in firmware
 assert "'--system',str(system)" in firmware
 checks.append(dev+': canonical stages, normal invalidation, original observer, raw/update identity and cleanup retained')
 if dev=='H700':assert "{'DDR3', 'DDR4'}" in firmware and 'stream.seek(8192)' in firmware
 else:
  assert "table['label'] == 'gpt'" in firmware and 'boot_files==expected_abl' in firmware
  assert "len(expected_abl)==5" in firmware and 'fex_installed.append(entry)' in firmware
  assert "'dolphin-sa', 'steam', 'fex-emu', 'rocknix-abl'" in build
  assert inner.count('verify-fex.py')==2
  assert inner.index('verify-fex.py --self-check')<inner.index('make SM8550')<inner.rindex('verify-fex.py')
  assert not (root/'verify-fex-cache.py').exists()
 # Bounded source rendering for syntax only: no owner creation or helper call.
 for source in root.rglob('*.py'):
  text=source.read_text().replace('@OWNER@','/workspace/tmp/pix-m7-'+dev.lower()+'-refresh-20261015-01').replace('@TREE@','/workspace/repos/rocknix.worktrees/m7-pixelelated-'+dev.lower()+'-04')
  assert '@OWNER@' not in text and '@TREE@' not in text;ast.parse(text)
extra=(P/'verify-additions.py').read_text();assert "b'Vulkan'" in extra and "b'OGL'" not in extra
assert "'../../config/dolphin-emu'" in extra and 'len(sysrows)==6' in extra
assert 'right.read(path,limit=256*1024**2)==data' in extra and 'link_chain(right,path)==links' in extra
assert "right.nodes[right.resolve(path)][0]==mode" in extra
assert "--dry-run" in extra and 'readelf' in extra
fex=(P/'verify-fex.py').read_text();assert 'b6018f87da91d19d0ab4cf979885689b469cdd41' in fex and 'len(records)==14' in fex
assert "elf(installed/'usr/bin/FEX',64,183)" in fex and '3 if bits==32 else 62' in fex
assert 'old fourteen payload hashes' in fex
assert 'hashlib.file_digest' not in fex and 'while block:=f.read(1024*1024)' in fex
assert "sys.argv[1:]==['--self-check']" in fex and 'fex-helper-runtime.json' in fex
derive=(P/'derive-templates.py').read_text()
assert "'--payload',str(archive)" in derive and "'--payload',str(system)" not in derive
assert 'verify-fex.py --self-check' in derive and 'boot_files==expected_abl' in derive
cmd=(P/'commands.sh').read_text();assert 'consume-reporting-failure' not in cmd and 'tool-wrapper.rc' not in cmd
assert 'tools/watch-build-submit --owner "$TASK_STAGE_OWNER"' in cmd
prep=(P/'prepare-owner.py').read_text();assert "COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'" in prep
assert "'origin/next'" in prep and 'cache_copy_executed' in prep
result={'status':'PASS_STATIC_ONLY','python_AST_files':py,'bash_n_files':shell,'original_helpers_rehashed':len(loc),'checks':checks+['SM8550 exact Vulkan launcher transformation','six pinned Sys rows/link-chain equality','actual14 FEX architecture outputs/current recipe URL','ordinary frozen admission path and launcher-owned receipts'],'preparer_or_runtime_executed':False,'cache_payload_hash_scan_performed':False,'limitations':['Source syntax/guard review only; no current cache mutation or build/readback success.','One earlier ad hoc static-check command itself had a SyntaxError; no helper ran. This retained checker parsed all final source.']}
print(json.dumps(result,indent=2))

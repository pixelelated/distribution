"""Post-build FEX proof for the recipe-selected b6018f87 Nix input; no target execution."""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
O=Path(__file__).resolve().parent;j=json.loads((O/'inputs.json').read_text());T=Path.cwd()
assert T==Path(j['container_worktree'])
root=T/j['build_root'];fex=root/'build'/('fex-emu-'+j['fex_commit']);build=fex/'.aarch64-rocknix-linux-gnu';installed=root/'install_pkg'/('fex-emu-'+j['fex_commit'])
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
recipe=T/'projects/ROCKNIX/packages/compat/fex-emu/package.mk'
assert sha(recipe)=='428430a76277b24fc5e4a69889da0045431d7c71caee35cc64a57fabf25db3ec'
url='https://github.com/NixOS/nixpkgs/archive/b6018f87da91d19d0ab4cf979885689b469cdd41.tar.gz'
assert 'export NIX_PATH="nixpkgs='+url+'"' in recipe.read_text()
cache=(build/'CMakeCache.txt').read_text()
observed={}
for key,suffix in [('rootfs','fex-dev-rootfs'),('toolchain32','toolchain_nix_x86_32.txt'),('toolchain64','toolchain_nix_x86_64.txt')]:
 paths=set(re.findall(r'/nix/store/[a-z0-9]{32}-'+re.escape(suffix),cache));assert len(paths)==1,(key,paths)
 path=Path(paths.pop());assert path.exists(),path
 observed[key]=str(path)
observed['toolchain_hashes']={observed[k]:sha(Path(observed[k])) for k in ['toolchain32','toolchain64']}
for name in ['Guest','Guest_32']:
 ninja=(build/name/'build.ninja').read_text();lines=[line for line in ninja.splitlines() if line.strip().startswith('INCLUDES =')];assert lines,name
 bad='-I'+str(root/'toolchain/aarch64-rocknix-linux-gnu/sysroot/usr/include');assert not any(bad in line.split() for line in lines),name
nix=fex/'nix/.nix-profile/bin/nix';version=subprocess.check_output([str(nix),'--version'],text=True).strip();assert version.startswith('nix (Nix) ')
# This asks the same pinned URL resolver used by the unchanged recipe; it never
# substitutes an old snapshot, changes NIX_PATH inside production, or runs FEX.
resolver=nix.with_name('nix-instantiate');resolved=subprocess.check_output([str(resolver),'--find-file','nixpkgs'],env=dict(os.environ,NIX_PATH='nixpkgs='+url),text=True).strip();snapshot=Path(resolved);assert snapshot.is_dir()
observed['nixpkgs_resolved_path']=resolved
observed['nixpkgs_selected_source_sha256']={n:sha(snapshot/n) for n in ['default.nix','shell.nix','.version'] if (snapshot/n).is_file()};assert 'default.nix' in observed['nixpkgs_selected_source_sha256']
records=[]
def elf(path,bits,machine):
 data=path.read_bytes();assert data[:6]==b'\x7fELF'+bytes([1 if bits==32 else 2,1]) and int.from_bytes(data[18:20],'little')==machine,path
 records.append({'path':str(path.relative_to(installed)),'sha256':sha(path),'bytes':len(data),'bits':bits,'machine':machine})
elf(installed/'usr/bin/FEX',64,183)
for bits,names in [(32,j['guest_libraries32']),(64,j['guest_libraries64'])]:
 folder='GuestThunks_32' if bits==32 else 'GuestThunks'
 actual={x.name for x in (installed/'usr/share/fex-emu'/folder).glob('*.so')};assert actual==set(names),(folder,actual)
 for name in names:elf(installed/'usr/share/fex-emu'/folder/name,bits,3 if bits==32 else 62)
assert len(records)==14 and (root/'.stamps/fex-emu/build_target').is_file()
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','nix_version':version,'nix_binary_path':str(nix.resolve()),'nix_binary_sha256':sha(nix),'nixpkgs_url':url,'recipe_sha256':sha(recipe),'generated_inputs':observed,'cmake_cache_sha256':sha(build/'CMakeCache.txt'),'files':records,'scope':'Actual post-build native AArch64 FEX and complete x86/x86_64 thunks, generated rootfs/toolchains and current pinned Nix resolution. No target execution.','limitations':['The frozen recipe streams the Nix installer via curl|sh; original installer response bytes are not retained by that command.','Selected resolved Nix source hashes are provenance; no whole store reproducibility or corresponding-source-completeness claim.','Prior 2.35.2, old rootfs/toolchain paths and old fourteen payload hashes are historical and are not acceptance expectations.']}
(O/'artifacts/fex-package.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS actual FEX package and current recipe-selected Nix input; 14 architecture-checked payloads',flush=True)

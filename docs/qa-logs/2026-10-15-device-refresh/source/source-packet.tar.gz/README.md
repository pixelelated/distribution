# H700 then SM8550 refresh — SOURCE ONLY, UNRUN

This packet rebinds the qualified October11 device refresh lifecycle to published
`f8636de1d105275dbf9420bbabbbc26f79abb10f`. No checkout, runtime owner, admission,
cache copy, container, compiler, VM or device action has been created or run by
this preparation. Only bounded source copies, source derivation and syntax checks
ran. Historical build/cache/acceptance successes remain historical.

Can the VM prove this? Shared player behavior is qualified on the actual f863 VM
image; the remaining native-state continuation and applicable final audit must
finish before this device build. Cross-compilation, architecture and raw/update
artifact inspection require the build host. Physical boot, display, audio/radio
and player-device changes remain separately named actions. This is engineering
firmware, not an RC or publication decision.

Root reviews the completed applicable audit, accepted affected clean/retained
and native-state originals, their consumption, and fresh published-source
readback before running any command below. Their actual evidence paths/hashes
are required inputs, not supplied future PASS receipts. The preparer binds these
files; their semantic adequacy remains root's review, not a hash-equals-PASS rule.
For current `origin/next`, retain actual `git ls-remote origin refs/heads/next`
and hosted-check readback. f863 must be published and its accepted VM product
scope unchanged. The fixed f863 commit deliberately does not predict a later
record-only commit. To use another producer commit, review and reseal this source
packet; do not pass a silent source override.

## Exact roots and prior custody

| Device | Accepted predecessor | Proposed fresh checkout/branch | Stable container prefix |
|---|---|---|---|
| H700 | `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-03`, bc9dfe8141 | `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04`, `build/m7-pixelelated-h700-04` | `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-01` |
| SM8550 | `/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-03`, bc9dfe8141 | `/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-04`, `build/m7-pixelelated-sm8550-04` | `/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01` |

Each has distinct ARM and AArch64 roots. SM8550 additionally copies the accepted
private store `/workspace/tmp/pixelelated-m7-sm8550-refresh-04/nix` to the new
owner's `nix`. No predecessor is moved, edited or deleted. Independent rsync
copies preserve internal hardlinks but require checksum equality and different
parent/destination regular-file inodes. Existing generated absolute prefixes are
preserved by the canonical Docker mount, never rewritten.

The proposed runtime owners are `/workspace/tmp/pix-m7-h700-refresh-20261015-01`
and `/workspace/tmp/pix-m7-sm8550-refresh-20261015-01`. Neither is allocated by this
packet. The preparer refuses existing owners/checkouts with mutable source or
already populated target/cache roots. It records current allocated bytes using
bounded `du`, original stdout/stderr/exits, full tracked product/symlink and tool
hashes, host-options hash without values, actual host namespace and prior ARM
manifest. Fresh retention reports/admissions precede each cache, build and reader
stage. The report's empty scan root is explicit; no whole-volume classification,
root-FD census or deletion authority is claimed.

## Root command sequence

Choose one actual UTC build timestamp for the coordinated pair. Set the actual
reviewed evidence variables, without account values. These assignments are a
shape, not evidence or reserved values:

```bash
export TASK_TIMESTAMP=ACTUAL_FRESH_YYYYMMDDTHHMMSSZ
export TASK_AUDIT_EVIDENCE=/absolute/path/to/completed-applicable-audit-evidence
export TASK_AUDIT_SHA256=ACTUAL_SHA256
export TASK_VM_EVIDENCE=/absolute/path/to/reviewed-f863-affected-and-state-evidence
export TASK_VM_SHA256=ACTUAL_SHA256
export TASK_PUBLICATION_EVIDENCE=/absolute/path/to/fresh-published-source-readback
export TASK_PUBLICATION_SHA256=ACTUAL_SHA256
TASK_PACKET=/tmp/pix-m7-device-refresh-20261015-04
```

The actual selected host options must remain reviewed: recipe-default shared
ScreenScraper identity only when no explicit override selects another pair.
Do not print credential values. Final packaged state inspection admits only the
exact shared developer pair implemented in the pinned state checker; player
accounts, RA credentials and other developer pairs remain refused.

Run each step separately, under actual-host access, from an idle serialized
allocation. Before cache admission, inspect the fresh retention inventory for
live QEMU and mounts into either parent/new roots or shared source cache. Stop
on any unexpected owner or unreadable census. Review current `tools/build-preflight`
RAM/swap results; no old availability result is reused. No script pre-sets the
internal watch nesting marker.

```bash
bash "$TASK_PACKET/commands.sh" H700 create
bash "$TASK_PACKET/commands.sh" H700 prepare
bash "$TASK_PACKET/commands.sh" H700 cache
# Wait for actual original completion; inspect cache-ready and all channels.
bash "$TASK_PACKET/commands.sh" H700 consume-cache
bash "$TASK_PACKET/commands.sh" H700 build
# Supervise <=60s; original main container/observer and all build channels must end0.
bash "$TASK_PACKET/commands.sh" H700 consume-build
bash "$TASK_PACKET/commands.sh" H700 acceptance
# Inspect independent DDR3+DDR4 result, raw/update equality, packaged state and cleanup.
bash "$TASK_PACKET/commands.sh" H700 consume-acceptance
```

The existing ordinary frozen tools perform every retention/admission/submit/
consume. Do not substitute the coordinator's #597 reporting-failure tool. Never
precreate `tool-wrapper.rc`; launcher submission0 is not completion. A failed
stage keeps original channels and owner, requires investigation and a fresh retry
owner/packet if executable changes are needed. `consume-stage.py` accepts only
actual successful original channels; it cannot invent failed-stage recovery.

After H700 independent acceptance and consumption, keep the same timestamp,
retain/hash that exact acceptance JSON, refresh all host dependency/resource
observations, then:

```bash
export TASK_H700_ACCEPTANCE_SHA256=ACTUAL_SHA256_OF_H700_ACCEPTANCE_JSON
bash "$TASK_PACKET/commands.sh" SM8550 create
bash "$TASK_PACKET/commands.sh" SM8550 prepare
bash "$TASK_PACKET/commands.sh" SM8550 cache
# Review original completion and independent copy proof.
bash "$TASK_PACKET/commands.sh" SM8550 consume-cache
bash "$TASK_PACKET/commands.sh" SM8550 build
# Review actual current FEX generated-input proof and all original channels.
bash "$TASK_PACKET/commands.sh" SM8550 consume-build
bash "$TASK_PACKET/commands.sh" SM8550 acceptance
# Review GPT, raw/update, all five ABL1.2 files,14 FEX outputs, mappings and state.
bash "$TASK_PACKET/commands.sh" SM8550 consume-acceptance
```

The scripts expand the accepted canonical commands: `make docker-H700
"COMMAND=bash OWNER/inside-build.sh"`, then `make H700` inside the observed
pinned container; SM8550 substitutes its device target. Both targets execute ARM
then AArch64 `scripts/build_distro`. Builder988c0ba5, uid/gid1000,24 global jobs,
WebKit4, shared-source/common-git mounts, container name/CID/observer and effective
writable TMPDIR=/tmp gate are retained. Proposed reserve remains the old canonical
300GiB build bound, freshly measured copy bytes plus that bound (at least500GiB
H700/600GiB SM), and64GiB independent firmware-reader allowance. These are explicit
operating allowances, not measured future peaks or predicted completion times.
Root keeps the existing watcher actively supervised; no off-session delivery is
claimed. H700 must finish before SM8550; shared downloads are not concurrent.

## Changed input and artifact gates

`prior-plan/product-scope.json` binds33 changed product paths since bc9d and exact
f863 recipes. `h700-template.diff` and `sm8550-template.diff` show the old lifecycle
changes; `originals/` preserves original source and historical inputs. Live owner
inputs replace stale old qualification identities; no prior image hash becomes
an expected newly built binary hash.

Common explicit normal `docker-package-clean` scope is alsa-ucm-conf,
raofflineproxy,rclone,rocknix,emulationstation,gstreamer,emulators,linux; SM8550 adds
dolphin-sa,steam,fex-emu,rocknix-abl. Only the normal image build stamp is unlinked.
No package stamp/hash is rewritten, and no install-only bypass exists. ARM-side
normal dependency/stamp resolution still runs through the canonical target.
Linux7.2's new shared MSM DP patch invalidates both device package inputs; ALSA's
SM8250 file changes also invalidate its common package directory. These facts do
not establish a new H700/SM8550 audio/DP behavior claim.

Required original outputs and artifact criteria:

- Both full canonical ABI stages and original command/monitor/runner/launcher,
  container observer and source checks succeed. Each new ARM output manifest is
  generated from this run and independently checked through actual SYSTEM for
  RetroArch32, Box86, selected cores and every handed-off top-level ARM library.
- H700 has exactly two distinct DDR3/DDR4 compressed raw images, one update TAR,
  checksums and clean dev identity. Each raw partition's SYSTEM and KERNEL equal
  the update payload. Exact variant bootloader bytes at the original offset match
  the update archive; neither variant substitutes for the other.
- SM8550 has exactly one raw image and update TAR, two named GPT partitions and
  identical raw/update SYSTEM/KERNEL. ABL is1.2 with upstream archive SHA
  `4fcf983aff6af152fb5d7d0ef1a31727d64ecb93b2d75e202efeea5c5d4b565d` enforced by
  normal package retrieval. All five actual package/installed/update/raw ABL files
  must agree. Support scripts match source, including `%DEVICE%`→SM8550.
- Existing identity, native AArch64/ARM ELF, ES16dbac source/catalog, rclone1.75.2,
  helper/default/license/duckstation/no-retired-migration checks remain. Proxy
  source expectation is the exact reviewed112-file current pin+patch manifest,
  replacing the obsolete ten-file October11 expectation; applied020/021 source
  identities and recipe/patch custody remain bound.
- `verify-additions.py` compares affected source/staged mappings and independently
  extracted SYSTEM bytes, modes and link chains. It checks runemu,wifictl,
  cloud_oauth,proxyctl and selected GStreamer scanner/net/controller/plugins using
  ELF architecture and direct dependency-presence metadata without target execution
  or recursive/runtime loader qualification. SM adds actual Dolphin018
  reverse dry-run/source hash and RA CMake setting, six pinned Sys resources via
  exact `../../config/dolphin-emu`, all SM8550 controller/default inputs, helper
  and save-path bytes, both **wayland/Vulkan/QT-wayland** launcher transformations,
  Steam installer and native Python3. Raw source launcher hashes are not used as
  installed expectations. VM-specific OGL defaults are not imported.
- Both independent readers run the frozen `pixelelated-state-check --payload`
  against the hash-bound update TAR in the independent candidate bundle and retain
  stdout/stderr/original exit. The frozen checker accepts TAR or compressed raw
  images; extracted SYSTEM remains the input to the separate byte/mode/link checks.
  All candidate-store copies have independent inodes; originals, full input and
  output manifests and all cleanup channels remain. Successful reader scratch
  removal and later admission consumption are separate actual observations.

SM8550 FEX is a normal rebuild because the recipe changed. Its NIX_PATH now
selects b6018f87, overriding the historical7dd199b wrapper. The old prebuild
fourteen-output/toolchain hash equality check is historical only. The new
helper uses streaming SHA256 supported by the pinned container's Python3.10.
The existing container startup invokes its bounded `--self-check` before `make`,
retaining actual interpreter version and helper file-read/hash proof; this source
packet has not executed that check or qualified the container helper. The new
post-build check records actual Nix version/binary, exact recipe URL resolution,
generated rootfs and both toolchain paths/hashes, CMake cache identity, exclusion
of AArch64 headers from Guest/Guest_32 compile inputs, and all14 ELF payloads:
one native AArch64 FEX, five i386 and eight x86_64 thunks. The firmware reader then
compares every output against actual SYSTEM. No ARM FEX/Steam gameplay is claimed.
New Nix store paths/hashes are discovered from actual build output, never guessed.

The frozen recipe still streams `curl https://nixos.org/nix/install | sh` and
retains no original installer response. This packet cannot honestly claim those
bytes or a reproducible whole Nix store. It preserves this limit, observed binary/
version and selected resolved source hashes. Required corresponding-source and
publication custody remain separate gates; no old snapshot override or hidden
installer wrapper is added. Actual fetch/compile failure must retain originals;
no source-only success or timing estimate is asserted for this changed input.

All device/runtime work remains UNRUN. Remaining launch dependencies are the
actual final audit/VM/publication evidence, current host/cache/selected-option
readback and normal fresh retention/admission. The fixed source/code path is
ready for independent review, not a waiver of those checks.

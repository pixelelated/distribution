"""Source-only derivation. Never imports or executes a build helper."""
from pathlib import Path
import json,hashlib,difflib,ast
P=Path(__file__).resolve().parent
Q=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs')
proxy=json.loads((Q/'2026-10-14-proxy-product-composition/source.json').read_text())
(P/'proxy-source-proof.json').write_text(json.dumps(proxy,indent=2)+'\n')
for dev in ['H700','SM8550']:
 orig=P/'originals'/dev;out=P/'templates'/dev;out.mkdir(parents=True,exist_ok=False)
 old='/workspace/tmp/pixelelated-m7-'+dev.lower()+'-refresh-'+('03' if dev=='H700' else '05')
 names=[x for x in orig.rglob('*') if x.is_file() and x.suffix in ['.py','.sh'] and not (dev=='SM8550' and x.name in ['verify-fex.py','verify-fex-cache.py'])]
 for src in names:
  rel=src.relative_to(orig);s=src.read_text();s=s.replace(old,'@OWNER@')
  if rel.name in ['copy-cache.sh','copy-cache.py','consume-cache.py','progress.py']:
   s=s.replace('/workspace/tmp/pixelelated-m7-sm8550-refresh-04','@OWNER@')
  s=s.replace('/workspace/repos/rocknix.worktrees/m7-pixelelated-'+dev.lower()+'-03','@TREE@')
  if rel.name=='build.py':
   clean=['alsa-ucm-conf','raofflineproxy','rclone','rocknix','emulationstation','gstreamer','emulators','linux']
   if dev=='SM8550':clean+=['dolphin-sa','steam','fex-emu','rocknix-abl']
   s=s.replace("['cloud-signin-window','raofflineproxy','rclone','rocknix','emulationstation','sway']",repr(clean))
   s=s.replace("' --name pixelelated-m7-"+dev.lower()+"-refresh"+('03' if dev=='H700' else '05')+" --label pixelelated.m7.owner="+dev.lower()+"-refresh"+('03' if dev=='H700' else '05')+" --cidfile '","' --name '+j['container_name']+' --label pixelelated.m7.owner='+j['container_label']+' --cidfile '")
   s=s.replace("' -v '+j['nix_private_store']+':/nix -v '+j['nix_snapshot']+':'+j['nix_snapshot']+':ro -v '","' -v '+j['nix_private_store']+':/nix -v '")
   s=s.replace("assert json.loads((Path(j['cache_preparation_owner'])/'cache-consumption.json').read_text())['result']=='PASS'","assert json.loads((O/'cache-consumption.json').read_text())['result']=='PASS'")
   s=s.replace("assert json.loads((Path(j['cache_preparation_owner'])/'cache-ready.json').read_text())['result']=='PASS'","assert json.loads((O/'cache-ready.json').read_text())['result']=='PASS'")
  if rel.name=='observe-container.py':
   s=s.replace(repr('pixelelated-m7-'+dev.lower()+'-refresh'+('03' if dev=='H700' else '05')),"j['container_name']")
   s=s.replace(repr(dev.lower()+'-refresh'+('03' if dev=='H700' else '05')),"j['container_label']")
   s='\n'.join(l for l in s.splitlines() if "j['nix_snapshot']" not in l)+'\n'
  if rel.name=='inside-build.sh' and dev=='SM8550':
   s='\n'.join(l for l in s.splitlines() if not any(z in l for z in ['export NIX_PATH=', 'verify-fex-cache.py','cp @OWNER@/artifacts/fex-package.json']))+'\n'
   # The former prebuild payload check is replaced by the actual postbuild proof.
   first='python3 -I @OWNER@/verify-fex.py\n';assert s.count(first)==2;s=s.replace(first,'',1)
   s=s.replace('python3 -I @OWNER@/container-ready.py\n','python3 -I @OWNER@/container-ready.py\npython3 -I @OWNER@/verify-fex.py --self-check\n')
  if rel.name=='verify-installed.py':
   a=s.index("packet=json.loads((T/'docs/audits/");b=s.index("native=root/'usr/lib/libraproxy_rchash.so'",a)
   s=s[:a]+"packet=json.loads((O/'proxy-source-proof.json').read_text())\nproxy_sources={}\nassert packet['pin']==j['proxy_commit']\nfor rel,h in packet['files'].items():\n assert sha(proxy/rel)==h,rel;proxy_sources[rel]=h\nassert len(proxy_sources)>=112\n"+s[b:]
   s=s.replace("'/home/max/Development/emulationstation-next.worktrees/qa-integration'","j['es_repository']")
   if dev=='H700':s=s.replace("Path(j['arm_manifest'])","Path(j['prior_arm_manifest'])")
   else:s=s.replace("Path(j['cache_parent_provenance']['arm_manifest'])","Path(j['prior_arm_manifest'])")
   s += "\nsubprocess.run(['python3','-I',str(O/'verify-additions.py')],check=True)\n"
  if rel.name=='copy-cache.py':
   a=s.index("s=os.statvfs('/workspace')");b=s.index('preserved=0',a)
   s=s[:a]+"measurement=json.loads((O/'capacity-measurement.json').read_text());s=os.statvfs('/workspace');free=s.f_bavail*s.f_frsize\nassert free>=measurement['copy_required_bytes']\n(O/'capacity.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'available_bytes':free,'copy_required_bytes':measurement['copy_required_bytes'],'measurement_sha256':hashlib.sha256((O/'capacity-measurement.json').read_bytes()).hexdigest(),'result':'PASS'},indent=2)+'\\n')\n"+s[b:]
  if rel.name=='consume-build.py':
   s=s.replace("'No such object' in q.stderr or 'No such container' in q.stderr","'no such object' in q.stderr.lower() or 'no such container' in q.stderr.lower()")
  if str(rel)=='acceptance/verify-firmware.py':
   if dev=='SM8550':
    mark='system_hash = digest(system)'
    assert s.count(mark)==1
    s=s.replace(mark,"    staged_abl=root/'install_pkg/rocknix-abl-1.2/usr/share/bootloader/rocknix_abl'\n    expected_abl={'rocknix_abl/'+str(p.relative_to(staged_abl)):digest(p) for p in staged_abl.rglob('*') if p.is_file()}\n    assert len(expected_abl)==5 and 'rocknix_abl/abl_signed-SM8550.elf' in expected_abl\n    assert boot_files==expected_abl, 'update archive ABL differs from exact current1.2 package'\n"+mark)
   mark="system.unlink()\nassert not list(scratch.iterdir())"
   assert s.count(mark)==1
   s=s.replace(mark,"subprocess.run(['python3','-I',str(build_owner/'verify-additions.py'),'--system',str(system),'--output',str(owner/'artifacts/affected-products.json')],check=True)\nstate=subprocess.run([str(tree/'tools/pixelelated-state-check'),'--payload',str(archive)],capture_output=True,text=True)\n(owner/'artifacts/selected-state.stdout').write_text(state.stdout)\n(owner/'artifacts/selected-state.stderr').write_text(state.stderr)\n(owner/'artifacts/selected-state.exit').write_text(str(state.returncode)+'\\n')\nassert state.returncode==0\nassert json.loads(state.stdout)['status']=='pass'\n"+mark)
  target=out/rel;target.parent.mkdir(exist_ok=True);target.write_text(s)
  if target.suffix=='.py':ast.parse(s)
 diffs=[]
 for src in names:
  rel=src.relative_to(orig);diffs+=difflib.unified_diff(src.read_text().splitlines(True),(out/rel).read_text().splitlines(True),fromfile='originals/'+dev+'/'+str(rel),tofile='templates/'+dev+'/'+str(rel))
 (P/(dev.lower()+'-template.diff')).write_text(''.join(diffs))
print('Derived source templates only; helpers remain UNRUN.')

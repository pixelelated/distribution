#!/bin/bash
set -euo pipefail
python3 -I @OWNER@/container-ready.py
./scripts/checkdeps
make H700

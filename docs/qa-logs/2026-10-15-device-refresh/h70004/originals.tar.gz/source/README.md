# H700 acceptance continuation — source only, UNRUN

The fresh owner is `/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01`. Root alone prepares, admits, executes, supervises and consumes it. This packet has not created that owner or run a checker, reader, fixture, admission, compiler, firmware extraction, VM or target executable. Only source AST/byte checks and `bash -n` ran.

Frozen firmware and source remain `f8636de1d105275dbf9420bbabbbc26f79abb10f`. The accepted stopped reader is `/workspace/tmp/pix-m7-h700-reader-20261015-01`: original zero, consumed `ba91e8762b5340c0a20fb885d75c0d81`. Its prior combined producer1 is still failed-investigated. The subsequent selected-state acceptance1 is also preserved and consumed as failed-investigated, `21f58942d89f48fa8be1776d7e2a9c0f`; it is never relabelled or overwritten.

The narrow verifier diff reuses the existing candidate bundle and verifies it through the frozen candidate-store helper; it does not put another bundle. The original firmware identity, installed mappings, architecture, ARM handoff, DDR3/DDR4 raw/update SYSTEM/kernel/bootloader comparisons, source guards, byte/inode independence and successful fresh scratch removal remain. The selected-state invocation uses a separately copied, exact hash-bound **host** checker, `65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6`, without modifying or claiming that checker is installed in the firmware. Its test source is `6e0b2eb945b913ad0c176dd532586463493e6984240e128ff771ce6264fd3eec`.

Original host suite `20261015T063831Z-c75018f3` has 212 passing controls and original command/monitor/runner0. Exact stdout, stderr and recorded run files are copied/hash-bound. Stderr contains the single original watch-build locator, not an empty stream. The two earlier missing-mcopy pre-fixture failures are outside this successful receipt; root retains them separately. No redundant actual H700 TAR scan was run before this continuation.

## Root commands

```bash
bash /tmp/pix-m7-h700-state-resume-20261015/commands.sh prepare
bash /tmp/pix-m7-h700-state-resume-20261015/commands.sh acceptance
# Supervise original completion before invoking the success consumer.
bash /tmp/pix-m7-h700-state-resume-20261015/commands.sh consume-acceptance
```

The preparer checks the sealed source, original successful reader, original failed acceptance, successful host suite and prior producer custody before materializing the new owner. Allocation retains a fresh preflight/retention report, 64 GiB allowance, exact declared outputs and the frozen checkout's ordinary admission tool. No deletion credit is taken. The success consumer requires genuine launcher/inner/outer/wrapper/build/command/monitor/runner zeros, absent recorded owners and ordinary consumption. Submission is not completion. A new failure is retained and cannot pass that consumer. Root continues active supervision at at most 60-second intervals.

The old failed scratch remains explicitly held at `/workspace/tmp/pix-m7-h700-reader-20261015-01/acceptance/scratch/SYSTEM`, 1,285,365,760 bytes, SHA256 `69dafbfacc07a6f59a12d35dc35c1839027458d695ba2fb0493d800bac7b5e67`. It is not reused or deleted by this packet. After replacement acceptance is successfully consumed, an optional root-scoped removal can check that exact regular file identity/hash, sole `SYSTEM` membership and original failure custody, unlink only that file, then remove only the now-empty scratch directory and retain the removal receipt. All original receipts and failed owner remain. This optional retirement is not an acceptance dependency; no recursive cleanup command is provided.

`execution.diff` is the complete executable delta; `verify-firmware.py.diff` is its small firmware-reader portion. `original-bindings.json` retains source/evidence identities, including accepted manifest hashes, without copying firmware. `static-review.json` contains only source validation. The first static-only stderr assumption failure is retained in `static-attempt01-observation.json`; no executable reader change followed it.

The root `SHA256SUMS` seals this H700 checkpoint's listed files. A later additive `sm8550/` source subtree, if prepared, has its own independent manifest and seal; it does not change these H700 payloads or invalidate their historical seal. SM8550 cannot allocate from this H700 packet and must bind the actual new consumed acceptance plus the same corrected host checker. No physical boot, target runtime, public release, RC or new product-source claim follows from artifact acceptance.

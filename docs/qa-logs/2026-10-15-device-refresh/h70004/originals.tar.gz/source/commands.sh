#!/bin/bash
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-h700-state-resume-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04
TASK_OWNER=/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01
cd "$TASK_TREE"
case "${1:?prepare, acceptance, or consume-acceptance}" in
 prepare)
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-acceptance.py"
  ;;
 acceptance)
  tools/build-preflight
  tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
  python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
  tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- python3 -I -S -B "$TASK_OWNER/run.py"
  # Root supervises actual producer completion. Submission0 is not completion0.
  ;;
 consume-acceptance)
  python3 -I -S -B "$TASK_OWNER/consume-acceptance.py"
  ;;
 *) exit 2;;
esac

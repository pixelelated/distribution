"""Materialize one fresh acceptance owner; never admit or execute its reader."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
P=Path(__file__).resolve().parent
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,j):
 with p.open('x') as f:json.dump(j,f,indent=2);f.write('\n')
for line in (P/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(P/n)==h,n
J=json.loads((P/'bindings.json').read_text());O=Path(J['new_owner']);B=Path(J['reader_owner']);T=Path(J['tree'])
assert O==Path('/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01') and not O.exists()
assert O.parent.resolve(strict=True)==O.parent and T.resolve(strict=True)==T and Path.cwd()==T
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==J['source_commit']
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='build/m7-pixelelated-h700-04'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
subprocess.run(['python3','-I',str(P/'templates/verify-prerequisites.py'),'--bindings',str(P/'bindings.json')],check=True)
assert sha(P/'host-checker/pixelelated-state-check')==J['host_checker_sha256']
O.mkdir(mode=0o700);(O/'artifacts').mkdir();(O/'host-checker').mkdir();(O/'empty-retention-scan').mkdir()
for p in (P/'templates').iterdir():
 if p.is_file():shutil.copy2(p,O/p.name)
for n in ['bindings.json','host-checker/pixelelated-state-check']:
 shutil.copy2(P/n,O/n)
ret=json.loads((P/'originals/reader/acceptance/retention-plan.json').read_text())
ret['scan_roots']=[str(O/'empty-retention-scan')]
ret['protected'] += [str(B),str(B/'acceptance/scratch'),J['candidate_bundle'],str(P)]
ret['builds'][0]['name']='m7-h700-acceptance-corrected-host-state-check'
ret['builds'][0]['basis'] += ' Fresh acceptance owner with separate corrected host checker; existing candidate bundle reused and verified. Failed scratch held, no deletion credit.'
ret['builds'][0]['evidence'].append({'path':str(O/'bindings.json'),'sha256':sha(O/'bindings.json')})
assert ret['builds'][0]['terms_bytes']=={'independent_firmware_bundle_and_scratch':64*1024**3}
put(O/'retention-plan.json',ret)
ad=json.loads((P/'originals/reader/acceptance/admission-plan.json').read_text())
ad.update(retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-h700-acceptance-corrected-host-state-check')
ad['outputs'].append({'path':str(O),'kind':'qa-scratch','issue':599,'release_when':'Successful independent acceptance consumed and compact original evidence retained; selected old scratch removal is a separate reviewed action.'})
put(O/'admission-plan.json',ad)
files=[p for p in O.rglob('*') if p.is_file()]
put(O/'seal.json',{str(p):sha(p) for p in sorted(files)})
put(O/'preparation.json',dict(status='PREPARED_UNRUN',owner=str(O),source=J['source_commit'],packet_sha256=sha(P/'SHA256SUMS'),host_checker_sha256=J['host_checker_sha256'],firmware_changed=False,acceptance_executed=False,admission_prepared=False))
print('PREPARED_UNRUN '+str(O))

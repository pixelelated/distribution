"""Parse source and compare exact intended edits only. Never import/run a reader."""
from pathlib import Path
import ast,hashlib,json,subprocess,difflib
P=Path(__file__).resolve().parent
checks=[]
def check(n,c):
 assert c,n;checks.append(n)
for p in sorted(P.rglob('*.py')):
 ast.parse(p.read_text());checks.append('AST '+str(p.relative_to(P)))
for p in [P/'commands.sh']:
 r=subprocess.run(['bash','-n',str(p)],capture_output=True,text=True);check('bash-n '+p.name,r.returncode==0 and not r.stdout and not r.stderr)
for row in json.loads((P/'original-bindings.json').read_text()):
 p=P/row['copy'];check('original copy '+row['copy'],hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'])
src=(P/'originals/reader/acceptance/verify-firmware.py').read_text();new=(P/'templates/verify-firmware.py').read_text()
# The derivation constructs only bundle reuse, host checker invocation, and receipt provenance.
expected=(P/'derive.py').read_text()
check('exact verifier diff',''.join(difflib.unified_diff(src.splitlines(True),new.splitlines(True),fromfile='failed-acceptance/verify-firmware.py',tofile='fresh-acceptance/verify-firmware.py'))==(P/'verify-firmware.py.diff').read_text())
for marker,end in [('scratch = owner / \'scratch\'','state=subprocess.run'),('files = [Path','store = Path')]:
 if marker.startswith('scratch'):
  a=src[src.index(marker):src.index('state=subprocess.run')];b=new[new.index(marker):new.index("checker=owner/")]
 else:a=src[src.index(marker):src.index(end)];b=new[new.index(marker):new.index(end)]
 check('unchanged firmware body '+marker,a==b)
j=json.loads((P/'bindings.json').read_text())
check('checker fixed65ab',j['host_checker_sha256']=='65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6')
check('tests fixed6e0b',j['host_checker_tests_sha256']=='6e0b2eb945b913ad0c176dd532586463493e6984240e128ff771ce6264fd3eec')
suite=json.loads((P/'originals/controls/command.stdout').read_text())
check('212 original controls pass',suite['control_count']==len(suite['controls'])==212 and suite['status']=='pass' and all(x['status']=='pass' for x in suite['controls']))
check('original suite stderr is exact monitor locator',(P/'originals/controls/command.stderr').read_text()=='watch-build: recording in /workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T063831Z-c75018f3\n')
r=json.loads((P/'originals/control-run/runner-result.json').read_text());check('original control runner0',all(type(r[k]) is int and r[k]==0 for k in ['command_rc','monitor_rc','runner_rc']))
check('old acceptance failure1 retained',json.loads((P/'originals/failed-run/runner-result.json').read_text())['command_rc']==1)
check('new owner fixed',j['new_owner']=='/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01')
check('no old successful acceptance invented','build-consumption.json' not in (P/'templates/run.py').read_text())
check('ordinary consume only',"'consume','--run'" in (P/'templates/consume-acceptance.py').read_text() and 'consume-reporting-failure' not in (P/'templates/consume-acceptance.py').read_text())
check('64GiB unchanged',"64*1024**3" in (P/'prepare-acceptance.py').read_text())
check('no bundle put',"'put', '--store'" not in new)
check('separate checker',"owner/'host-checker/pixelelated-state-check'" in new and "str(tree/'tools/pixelelated-state-check')" not in new)
print(json.dumps({'status':'PASS','kind':'source-only AST/byte checks; no preparer/reader/checker/fixture/admission/runtime execution','checks':checks,'count':len(checks)},indent=2))

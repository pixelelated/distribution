"""Source construction only; never executes a preparer, reader, or checker."""
from pathlib import Path
import json,hashlib,difflib
P=Path(__file__).resolve().parent
O='/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01'
B='/workspace/tmp/pix-m7-h700-reader-20261015-01'
T='/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
rows=json.loads((P/'original-bindings.json').read_text())
bind=dict(schema=1,source_commit='f8636de1d105275dbf9420bbabbbc26f79abb10f',new_owner=O,reader_owner=B,tree=T,reader_run=T+'/.build-runs/20261015T062243Z-05af824d',reader_admission='ba91e8762b5340c0a20fb885d75c0d81',failed_run=T+'/.build-runs/20261015T062354Z-101c418b',failed_admission='21f58942d89f48fa8be1776d7e2a9c0f',failed_owner=B+'/acceptance',failure_evidence='/tmp/pix-m7-h700-state-failure-20261015/completion-evidence.json',candidate_bundle=(P/'originals/reader/acceptance/candidate-bundle.path').read_text().strip(),candidate_manifest_sha256=sha(P/'originals/bundle-manifest.json'),host_checker_sha256=sha(P/'host-checker/pixelelated-state-check'),host_checker_tests_sha256=sha(P/'host-checker/pixelelated-state-check-test'),controls_run='/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T063831Z-c75018f3',controls_stdout_sha256=sha(P/'originals/controls/command.stdout'),controls_count=212,originals=rows)
put(P/'bindings.json',bind)
src=(P/'originals/reader/acceptance/verify-firmware.py').read_text();s=src
old="""command = [str(tree / 'tools/rasteratops-candidate-store'), 'put', '--store', str(store), '--inputs', str(build_owner / 'inputs.json'), *map(str, files)]
log = subprocess.check_output(command, cwd=tree, text=True)
(owner / 'artifacts/candidate-store.log').write_text(log)
bundle = Path([line.removeprefix('PASS candidate bundle ') for line in log.splitlines() if line.startswith('PASS candidate bundle ')][-1])"""
new="""binding = json.loads((owner / 'bindings.json').read_text())
bundle = Path(binding['candidate_bundle'])
assert digest(bundle / 'manifest.json') == binding['candidate_manifest_sha256']
command = [str(tree / 'tools/rasteratops-candidate-store'), 'verify', str(bundle)]
log = subprocess.check_output(command, cwd=tree, text=True)
(owner / 'artifacts/candidate-store.log').write_text(log)"""
assert s.count(old)==1;s=s.replace(old,new)
old="state=subprocess.run([str(tree/'tools/pixelelated-state-check'),'--payload',str(archive)],capture_output=True,text=True)"
new="""checker=owner/'host-checker/pixelelated-state-check'
assert digest(checker)==binding['host_checker_sha256']
state=subprocess.run(['python3','-I','-S','-B',str(checker),'--payload',str(archive)],capture_output=True,text=True)"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("               qualification_scope='Independent artifact acceptance after consumed original post-build reader failure; no successful combined producer claim')", """               failed_acceptance_run=binding['failed_run'], failed_acceptance_returncode=1,
               reader_run=binding['reader_run'],
               host_checker=dict(path=str(checker), sha256=digest(checker), tests_sha256=binding['host_checker_tests_sha256'],
                                 controls_run=binding['controls_run'], controls_stdout_sha256=binding['controls_stdout_sha256'], controls_count=212),
               qualification_scope='Independent artifact acceptance with corrected host-only checker after consumed state-reader failure1; frozen firmware and prior failed results unchanged')""")
(P/'templates/verify-firmware.py').write_text(s)
(P/'verify-firmware.py.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),s.splitlines(True),fromfile='failed-acceptance/verify-firmware.py',tofile='fresh-acceptance/verify-firmware.py')))

from pathlib import Path
import hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent
with (O/'run.path').open('x') as f:f.write(str(Path.cwd()/os.environ['RASTERATOPS_BUILD_RUN'])+'\n')
rc=1
try:
 for n,h in json.loads((O/'seal.json').read_text()).items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
 subprocess.run(['python3','-I',str(O/'verify-prerequisites.py')],check=True)
 subprocess.run(['python3','-I',str(O/'verify-firmware.py')],check=True);rc=0
except subprocess.CalledProcessError as e:
 rc=e.returncode if e.returncode>0 else 128-e.returncode
finally:
 for name in ['inner.rc','outer.rc']:
  with (O/name).open('x') as f:f.write(str(rc)+'\n')
sys.exit(rc)

"""Consume only this fresh acceptance's original zeros through the ordinary frozen tool."""
from pathlib import Path
import hashlib,json,subprocess
O=Path(__file__).resolve().parent;J=json.loads((O/'bindings.json').read_text());T=Path(J['tree']);assert Path.cwd()==T
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
subprocess.run(['python3','-I',str(O/'verify-prerequisites.py')],check=True)
for n,h in load(O/'seal.json').items():assert sha(n)==h,n
proof=O/'artifacts/acceptance.json';jp=load(proof)
assert jp['result']=='PASS' and jp['scratch_removed'] is True and jp['source_unchanged'] is True and jp['producer_combined_run_returncode']==1
assert jp['failed_acceptance_returncode']==1 and jp['failed_acceptance_run']==J['failed_run'] and jp['distribution_commit']==J['source_commit']
assert jp['host_checker']['sha256']==J['host_checker_sha256'] and sha(O/'host-checker/pixelelated-state-check')==J['host_checker_sha256']
assert (O/'artifacts/selected-state.exit').read_text().strip()=='0' and load(O/'artifacts/selected-state.stdout')['status']=='pass'
run=Path((O/'run.path').read_text().strip());assert run.parent==T/'.build-runs'
launch=load(O/'launcher-result.json');runner=load(run/'runner-result.json')
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
assert all(type(runner[n]) is int and runner[n]==0 for n in ['command_rc','monitor_rc','runner_rc'])
files=[proof,O/'artifacts/affected-products.json',O/'artifacts/payload-equality.json',O/'artifacts/arm-handoff.json',O/'artifacts/selected-state.stdout',O/'artifacts/selected-state.stderr',O/'artifacts/selected-state.exit',O/'bindings.json',O/'host-checker/pixelelated-state-check',O/'seal.json',O/'launcher-result.json',run/'runner-result.json']
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc']:assert p.read_text().strip()=='0';files.append(p)
pids={launch['pid']}
for name in ['build.pid','command.pid','watcher.pid','build.status.pid']:
 p=run/name
 if p.exists():pids.add(int(p.read_text().strip()))
assert all(not Path('/proc',str(pid)).exists() for pid in pids)
ad=load(run/'admission.json');assert ad['source']['head']==J['source_commit'] and ad['submission_owner']==str(O)
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,evidence=[dict(path=str(p),sha256=sha(p)) for p in files],outputs=ad['outputs'],scope='New independent artifact acceptance0 only; prior combined producer1 and selected-state acceptance1 remain failed-investigated. No physical, runtime-on-device, RC or publication claim.')
out=O/'admission-completion-evidence.json'
with out.open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
subprocess.run(['python3','-I',str(T/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
receipt=run/'admission-consumed.json';c=load(receipt);assert c['state']=='consumed' and c['original_result']==runner
record=dict(result='PASS',stage='acceptance',run=str(run),original_result=runner,consumed_receipt_sha256=sha(receipt),completion_evidence_sha256=sha(out),acceptance_sha256=sha(proof),host_checker_sha256=J['host_checker_sha256'],original_combined_producer_returncode=1,original_failed_acceptance_returncode=1,scope=evidence['scope'])
with (O/'acceptance-consumption.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('PASS fresh independent acceptance consumed; earlier failures unchanged')

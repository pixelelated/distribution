"""Bind consumed reader0, failed acceptance1, and the corrected host checker's original suite0."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess
q=argparse.ArgumentParser();q.add_argument('--bindings',type=Path);a=q.parse_args()
O=Path(__file__).resolve().parent;J=json.loads((a.bindings or O/'bindings.json').read_text())
B=Path(J['reader_owner']);T=Path(J['tree']);F=Path(J['failed_run']);R=Path(J['reader_run'])
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
def codes(j,expected):
 assert all(type(j[n]) is int and j[n]==v for n,v in expected.items())
for row in J['originals']:assert sha(row['path'])==row['sha256'],row['path']
assert os.getuid()==1000 and os.getgid()==1000 and os.stat('/proc/self/ns/pid').st_ino==4026531836
for run,owner,aid,rc in [(R,B,J['reader_admission'],0),(F,Path(J['failed_owner']),J['failed_admission'],1)]:
 result=load(run/'runner-result.json');codes(result,dict(command_rc=rc,monitor_rc=0,runner_rc=rc))
 consumed=load(run/'admission-consumed.json')
 assert consumed['state']=='consumed' and consumed['id']==aid and consumed['original_result']==result
 assert consumed['run']==str(run) and consumed['submission_owner']==str(owner) and consumed['source']['head']==J['source_commit']
 assert consumed['outputs_held'] is True and consumed['deleted_bytes']==0 and consumed['pid_namespace']==4026531836
 launch=load(owner/'launcher-result.json');codes(launch,dict(runner_returncode=rc))
 for p in [owner/'inner.rc',owner/'outer.rc',owner/'tool-wrapper.rc',run/'build.rc']:assert p.read_text().strip()==str(rc),p
 pids={launch['pid']}
 for name in ['build.pid','command.pid','watcher.pid','build.status.pid']:
  p=run/name
  if p.exists():pids.add(int(p.read_text().strip()))
 assert all(not Path('/proc',str(pid)).exists() for pid in pids)
failure=load(J['failure_evidence']);assert sha(J['failure_evidence'])==load(F/'admission-consumed.json')['evidence_sha256']
assert failure['run']==str(F) and failure['disposition']=='failed-investigated' and type(failure['expected_rc']) is int and failure['expected_rc']==1
for row in failure['evidence']:assert sha(row['path'])==row['sha256'],row['path']
assert not (Path(J['failed_owner'])/'artifacts/acceptance.json').exists()
prior=load(B/'reader-consumption.json');assert prior['result']=='PASS' and prior['stage']=='reader' and prior['run']==str(R)
assert prior['original_combined_producer_returncode']==1 and sha(R/'admission-consumed.json')==prior['consumed_receipt_sha256']
assert sha(B/'artifacts/output-manifest.json')==prior['output_manifest_sha256']
manifest=load(B/'artifacts/output-manifest.json')
assert manifest['result']=='READ_VALIDATED_REQUIRES_ARTIFACT_ACCEPTANCE' and manifest['distribution_commit']==J['source_commit'] and len(manifest['files'])==7
assert sha(Path(J['candidate_bundle'])/'manifest.json')==J['candidate_manifest_sha256']
suite_rows=[r for r in J['originals'] if r['copy']=='originals/controls/command.stdout'];assert len(suite_rows)==1
suite=load(suite_rows[0]['path']);assert suite['status']=='pass' and suite['control_count']==J['controls_count']==212
assert len(suite['controls'])==212 and all(r['status']=='pass' for r in suite['controls'])
assert sha(suite_rows[0]['path'])==J['controls_stdout_sha256']
control_run=Path(J['controls_run']);codes(load(control_run/'runner-result.json'),dict(command_rc=0,monitor_rc=0,runner_rc=0))
assert (control_run/'build.rc').read_text().strip()=='0'
for name in ['build.pid','command.pid','watcher.pid','build.status.pid']:
 p=control_run/name
 if p.exists():assert not Path('/proc',p.read_text().strip()).exists()
# Preserve the earlier consumed producer1 custody and actual container absence guard.
subprocess.run(['python3','-I',str(B/'verify-prerequisites.py')],check=True)
print('PASS original reader0 and acceptance1 preserved; corrected host checker suite212 original0 bound')

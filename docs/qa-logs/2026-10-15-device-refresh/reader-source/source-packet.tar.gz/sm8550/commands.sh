#!/bin/bash
# Source-only command packet. Invoke ONE named step after the README gates.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-h700-reader-review-20261015/sm8550
TASK_COMMIT=f8636de1d105275dbf9420bbabbbc26f79abb10f
TASK_DEVICE=${1:?H700 or SM8550}
TASK_STEP=${2:?create, prepare, cache, consume-cache, build, consume-build, acceptance, or consume-acceptance}
case "$TASK_DEVICE" in SM8550) TASK_TAG=sm8550;; *) exit 2;; esac
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-${TASK_TAG}-04
TASK_OWNER=/workspace/tmp/pix-m7-${TASK_TAG}-refresh-20261015-01
case "$TASK_STEP" in
 create)
  # Root reviews completed audit/VM/publication originals before this source freeze.
  test -n "${TASK_AUDIT_EVIDENCE:?}"; test -n "${TASK_VM_EVIDENCE:?}"; test -n "${TASK_PUBLICATION_EVIDENCE:?}"
  test ! -e "$TASK_TREE"
  git -C /workspace/repos/rocknix worktree add -b "build/m7-pixelelated-${TASK_TAG}-04" "$TASK_TREE" "$TASK_COMMIT"
  ;;
 prepare)
  test ! -e "$TASK_OWNER"
  TASK_ARGS=(--device "$TASK_DEVICE" --owner "$TASK_OWNER" --timestamp "${TASK_TIMESTAMP:?one fresh shared UTC build timestamp}"
    --audit-evidence "${TASK_AUDIT_EVIDENCE:?}" --audit-sha256 "${TASK_AUDIT_SHA256:?}"
    --vm-evidence "${TASK_VM_EVIDENCE:?}" --vm-sha256 "${TASK_VM_SHA256:?}"
    --publication-evidence "${TASK_PUBLICATION_EVIDENCE:?}" --publication-sha256 "${TASK_PUBLICATION_SHA256:?}")
  if test "$TASK_DEVICE" = SM8550; then
    TASK_ARGS+=(--h700-acceptance /workspace/tmp/pix-m7-h700-reader-20261015-01/acceptance/artifacts/acceptance.json --h700-acceptance-sha256 "${TASK_H700_ACCEPTANCE_SHA256:?}")
  fi
  cd "$TASK_TREE"
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-owner.py" "${TASK_ARGS[@]}"
  ;;
 cache|build|acceptance)
  cd "$TASK_TREE"
  case "$TASK_STEP" in
   cache) TASK_STAGE_OWNER="$TASK_OWNER/cache-launch"; TASK_CMD=(bash "$TASK_OWNER/copy-cache.sh");;
   build) TASK_STAGE_OWNER="$TASK_OWNER"; TASK_CMD=(python3 -I "$TASK_OWNER/build.py");;
   acceptance) TASK_STAGE_OWNER="$TASK_OWNER/acceptance"; TASK_CMD=(python3 -I "$TASK_STAGE_OWNER/run.py");;
  esac
  tools/build-preflight
  tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_STAGE_OWNER/retention-plan.json" --output "$TASK_STAGE_OWNER/retention-report.json"
  python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_STAGE_OWNER/admission-plan.json" --output "$TASK_STAGE_OWNER/admission.json"
  tools/watch-build-submit --owner "$TASK_STAGE_OWNER" -- --admission "$TASK_STAGE_OWNER/admission.json" -- "${TASK_CMD[@]}"
  # Submission is NOT completion. Root actively supervises originals <=60s cadence.
  ;;
 consume-cache|consume-build|consume-acceptance)
  cd "$TASK_TREE"
  python3 -I "$TASK_OWNER/consume-stage.py" --owner "$TASK_OWNER" --stage "${TASK_STEP#consume-}"
  ;;
 *) exit 2;;
esac

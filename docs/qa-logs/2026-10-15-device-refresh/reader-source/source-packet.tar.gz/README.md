# H700 retained-output reader continuation — UNRUN

Ready for root's serialized preparation and allocation after source review. No preparer, reader, firmware extraction, target binary, compiler, Docker container, VM, or admission has executed from this packet. AST parsing and bash syntax checking are the only checks executed. The frozen product source remains f8636de1d105275dbf9420bbabbbc26f79abb10f.

## Diagnosis and explicit profile correction

Owner02's first additional-reader refusal was `/usr/lib/gstreamer-1.0/libgstadaptivedemux2.so`. The original shared fixed list also incorrectly required `libgstrtpmanager.so`, `libgstrtsp.so`, and `libgstudp.so` on H700. The actual H700 build/install/stamp sets have GStreamer core/base/bad and no gst-plugins-good or Qt6. Frozen `emulators/package.mk` selects Dolphin on SM8550 but not H700; Dolphin depends on Qt6, and Qt6 directly depends on gst-plugins-good. WebKit explicitly requires core/base/bad. GStreamer commit fac608 retains runtime libraries for plugins where installed; it does not add a gst-plugins-good dependency to H700. This is a verifier profile mismatch, not evidence of a product defect.

The corrected shared reader explicitly requires H700's gst-plugins-good package/stamp and four paths to be absent in staged and independently extracted SYSTEM. SM8550 still requires those four files, its good package/stamp and Qt6 stamp. No missing-path fallback is allowed. All prior core/base/GL, source mappings, architecture, modes, symlink chains, and direct ELF dependency checks remain. The WebKit-required bad-package mpegts library is now an explicit member of that same direct-dependency check. Source readback confirmed its actual staged symlink. No target ELF is executed.

## Original failure remains failed

Original run `20261015T060011Z-92b2fe8b`, admission61759727b2944475ba2544bd238337a0, remains command/monitor/runner 1/0/1 and launcher/inner/outer/wrapper1. Root ordinarily consumed it as failed-investigated with outputs held and no deletion. Canonical make returned through its check=True call to installed validation; that control flow is evidence, not a fabricated standalone child wait receipt. Original installed inclusion and ARM evidence remain unchanged. The old owner has no successful build-consumption or output-manifest receipt.

Root's `/tmp/pix-m7-h700-reader-failure-20261015/output-manifest.json` SHA cd41204c2267985bf843457aca3d1b65c6e652e46de7898e2cd9d2d33f9ef66e binds seven already assembled outputs. `bindings.json` binds original failure evidence, consumed admission, source/owner files and those exact expected output rows. Each new stage verifies original custody and current recorded PID/container absence. Root's record-only coordinator commits do not change the frozen product checkout.

## Fresh stages and commands

Fresh owner: `/workspace/tmp/pix-m7-h700-reader-20261015-01`.

```bash
bash /tmp/pix-m7-h700-reader-review-20261015/commands.sh prepare
bash /tmp/pix-m7-h700-reader-review-20261015/commands.sh reader
# Supervise original completion, then consume the new reader result only.
bash /tmp/pix-m7-h700-reader-review-20261015/commands.sh consume-reader
bash /tmp/pix-m7-h700-reader-review-20261015/commands.sh acceptance
# Supervise original completion, then consume independent acceptance only.
bash /tmp/pix-m7-h700-reader-review-20261015/commands.sh consume-acceptance
```

The new reader repeats the existing exact source and staged installed inclusion checks in its own output directory, invokes the corrected profile reader, and independently rehashes the exact seven retained artifacts against root's immutable failure-investigation manifest. Its fresh manifest says READ_VALIDATED_REQUIRES_ARTIFACT_ACCEPTANCE and explicitly carries original producer1. The new consumer requires its actual original zero channels and ordinary admission consumption before writing reader-consumption.json.

The independent firmware reader retains the original DDR3/DDR4 raw/update SYSTEM, kernel and bootloader equality, exact packaged mappings, ARM handoff, clean selected-state check, candidate-store byte/inode custody, source identity and scratch removal. Changes are owner paths and explicit original producer1 provenance. Its gate now requires the actual consumed fresh reader0 rather than a fictitious successful producer receipt. The old success consumer is not invoked. Only new reader and acceptance original zeros qualify those named scopes.

Each allocation still runs build-preflight, a fresh retention report and ordinary frozen build-admission under watch-build-submit. Both retain the existing 64GiB allowance, protected source/cache/output roots, empty explicit retention scan and zero deletion credit. Root actively supervises at <=60-second cadence; no new compiler deadline or timing prediction is claimed. The reader is bounded to original source/installed checks and seven artifacts; acceptance is bounded to two raw DDR variants and one update TAR. No compilation, package clean, cache copy, image regeneration, cache inventory, or target execution is present. Failed new stages preserve their own original results and do not pass the success consumer.

## Pending SM8550 and tracker scope

The additive `sm8550/` derivative preserves the previous gateway correction and original guard families. Only the shared profile-aware reader and future H700 acceptance locator change; its normal compile/copy/clean lifecycle is unchanged. Its preparation remains unavailable until H700 reader and acceptance complete and are consumed. Use `sm8550/commands.sh SM8550 <step>` with the same original pair timestamp and exact evidence environment, plus the actual new H700 acceptance SHA. Historical source/static/review records remain labelled historical; `CURRENT-SOURCE-REVIEW.json` and the new subtree seal qualify this unrun derivative.

`issue555-criterion-proposal.md` records the precise acceptance distinction for root's tracker update. An all-original-zero combined producer checkbox cannot be checked for owner02. Instead require the preserved/consumed failed producer plus successful original fresh reader and independent artifact acceptance. No physical-device boot, runtime, RC or publication claim follows from these readers. All new outcomes remain pending until root executes them.

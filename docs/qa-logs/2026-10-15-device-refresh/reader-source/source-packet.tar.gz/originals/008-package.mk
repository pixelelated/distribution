# SPDX-License-Identifier: GPL-2.0
# Copyright (C) 2023 JELOS (https://github.com/JustEnoughLinuxOS)
# Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)

PKG_NAME="emulators"
PKG_LICENSE="GPLv2"
PKG_SITE="https://rocknix.org"
PKG_SECTION="emulation" # Do not change to virtual or makeinstall_target will not execute.
PKG_LONGDESC="Emulation metapackage."
PKG_TOOLCHAIN="manual"

PKG_EMUS="amiberry duckstation-sa flycast-sa gzdoom-sa hatarisa hypseus-singe moonlight mupen64plus-sa openbor pico-8   \
          ppsspp-sa scummvm-sa touchhle-sa vice-sa wine yabasanshiro-sa"

EMUS_32BIT=""

PKG_RETROARCH="core-info libretro-database retroarch retroarch-assets retroarch-joypads retroarch-overlays retropie-shaders slang-shaders"

LIBRETRO_CORES="81-lr a5200-lr arduous-lr atari800-lr b2-lr beetle-gba-lr beetle-lynx-lr beetle-ngp-lr beetle-pce-lr beetle-pce-fast-lr \
                beetle-pcfx-lr bk-lr bsnes2014-accuracy-lr bsnes2014-balanced-lr bsnes2014-performance-lr bsnes-mercury-accuracy-lr     \
                bsnes-mercury-balanced-lr bsnes-mercury-performance-lr beetle-supafaust-lr beetle-supergrafx-lr beetle-vb-lr            \
                beetle-wswan-lr bluemsx-lr cap32-lr crocods-lr daphne-lr doublecherrygb-lr dosbox-core-lr dosbox-pure-lr                \
                easyrpg-lr emuscv-lr fake08-lr fbalpha2012-lr fbalpha2019-lr fbneo-lr fceumm-lr flycast-lr fmsx-lr                      \
                freechaf-lr freeintv-lr freej2me-lr fuse-lr gambatte-lr gearboy-lr gearcoleco-lr geargrafx-lr gearlynx-lr gearsystem-lr \
                geolith-lr genesis-plus-gx-lr genesis-plus-gx-wide-lr gw-lr handy-lr hatari-lr idtech-lr jaxe-lr mame-lr                \
                mame2003-plus-lr mame2010-lr mame2015-lr melonds-lr melonds-ds-lr mesen-lr mesen-s-lr mgba-lr minivmac-lr mojozork-lr   \
                mu-lr mupen64plus-lr mupen64plus-nx-lr neocd_lr nestopia-lr np2kai-lr o2em-lr opera-lr parallel-n64-lr pcsx_rearmed-lr  \
                picodrive-lr pokemini-lr potator-lr prboom-lr prosystem-lr puae-lr puae2021-lr px68k-lr quasi88-lr quicknes-lr race-lr  \
                same_cdi-lr sameboy-lr sameduck-lr scummvm-lr skyemu-lr smsplus-gx-lr snes9x-lr snes9x2002-lr snes9x2005_plus-lr        \
                snes9x2010-lr stella-lr supersnes9x-lr swanstation-lr tgbdual-lr theodore-lr tic80-lr uzem-lr vba-next-lr       \
                vbam-lr vecx-lr vice-lr vircon32-lr virtualjaguar-lr xmil-lr wasm4-lr yabasanshiro-lr"

### aarch64 libretro and sa cores
if [ "${ARCH}" = "aarch64" ]; then
  LIBRETRO_CORES+=" duckstation-lr flycast2021-lr ppsspp-lr"
  PKG_EMUS+=" box64 dsperate-sa portmaster"
fi

### Emulators or cores for specific devices
case "${DEVICE}" in
  H700|RK3326)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_DEPENDS_TARGET+=" common-shaders glsl-shaders"
    PKG_EMUS+=" drastic-sa mednafen"
    LIBRETRO_CORES+=" uae4arm-lr"
    ;;
  RK3399)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_EMUS+=" aethersx2-sa armsx2-sa dolphin-sa drastic-sa mednafen melonds-sa nanoboyadvance-sa"
    LIBRETRO_CORES+=" beetle-psx-lr bsnes-lr bsnes-hd-lr dolphin-lr uae4arm-lr"
    ;;
  RK3566|RK3576)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_DEPENDS_TARGET+=" common-shaders glsl-shaders"
    PKG_EMUS+=" aethersx2-sa armsx2-sa azahar-sa dolphin-sa drastic-sa mednafen melonds-sa vita3k-sa"
    LIBRETRO_CORES+=" dolphin-lr uae4arm-lr"
    ;;
  RK3588)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_EMUS+=" aethersx2-sa armsx2-sa azahar-sa dolphin-sa drastic-sa mednafen melonds-sa supermodel-sa vita3k-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr uae4arm-lr"
    ;;
  SM6115)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_EMUS+=" aethersx2-sa azahar-sa dolphin-sa drastic-sa mednafen melonds-sa supermodel-sa vita3k-sa armsx2-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr uae4arm-lr"
    ;;
  # TODO: cemu and xemu testing, drop if unplayable
  SM4450)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 daedalusx64-sa desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_EMUS+=" aethersx2-sa azahar-sa bigpemu-sa cemu-sa dolphin-sa heroic mednafen melonds-sa nanoboyadvance-sa supermodel-sa xemu-sa \
                skyemu-sa steam vita3k-sa armsx2-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr kronos-lr uae4arm-lr"
    ;;
  SM8250)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 daedalusx64-sa desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_EMUS+=" aethersx2-sa azahar-sa bigpemu-sa cemu-sa dolphin-sa heroic mednafen melonds-sa nanoboyadvance-sa rpcs3-sa supermodel-sa \
                xemu-sa skyemu-sa steam vita3k-sa armsx2-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr kronos-lr uae4arm-lr"
    ;;
  SM8550)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 daedalusx64-sa desmume-lr gpsp-lr pcsx_rearmed-lr"
    PKG_EMUS+=" aethersx2-sa ares-sa azahar-sa bigpemu-sa cemu-sa dolphin-sa drastic-sa gopher64-sa heroic mednafen melonds-sa nanoboyadvance-sa rpcs3-sa supermodel-sa \
                xemu-sa skyemu-sa steam vita3k-sa armsx2-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr kronos-lr uae4arm-lr"
    ;;
  SM8650|SM8750)
    PKG_EMUS+=" aethersx2-sa ares-sa azahar-sa bigpemu-sa cemu-sa dolphin-sa gopher64-sa heroic mednafen melonds-sa nanoboyadvance-sa rpcs3-sa supermodel-sa \
                xemu-sa skyemu-sa steam vita3k-sa armsx2-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr kronos-lr uae4arm-lr"
    ;;
  S922X)
    [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 pcsx_rearmed-lr"
    PKG_EMUS+=" aethersx2-sa azahar-sa bigpemu-sa dolphin-sa drastic-sa duckstation-sa melonds-sa vita3k-sa armsx2-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr uae4arm-lr"
    ;;
  GENERIC_X64)
    # Native standalone Dolphin supports the developer VM qualification path.
    PKG_EMUS+=" dolphin-sa"
    ;;
  AMD64)
    PKG_EMUS+=" ares-sa azahar-sa cemu-sa dolphin-sa gopher64-sa mednafen melonds-sa nanoboyadvance-sa \
                xemu-sa skyemu-sa vita3k-sa armsx2-sa"
    LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr"
esac

# GENERIC_X64 (x86_64): drop libretro cores that don't yet build for x86_64.
# These are tracked in issue #16 to fix/re-enable per-core later (e.g. parallel-n64-lr's
# x86 hacktarux dynarec defines fsqrt(), which collides with glibc's C23 fsqrt).
if [ "${DEVICE}" = "GENERIC_X64" ]; then
  X64_SKIP_CORES="parallel-n64-lr flycast2021-lr duckstation-lr idtech-lr"
  for _core in ${X64_SKIP_CORES}; do
    LIBRETRO_CORES="$(echo " ${LIBRETRO_CORES} " | sed "s/ ${_core} / /g")"
  done
fi

# Split building emulators into 2 stages, needed to fit the jobs into the 6 hour GH runner time limit.
case "${TARGET_TYPE}" in
  cores_only)
    PKG_DEPENDS_TARGET+=" ${LIBRETRO_CORES}"
    ;;
  emus_only)
    PKG_DEPENDS_TARGET+=" ${PKG_EMUS} ${EMUS_32BIT} ${PKG_RETROARCH}"
    ;;
  none)
    ;;
  *)
    PKG_DEPENDS_TARGET+=" ${PKG_EMUS} ${EMUS_32BIT} ${PKG_RETROARCH} ${LIBRETRO_CORES}"
    ;;
esac

install_script() {
  if [ ! -d "${INSTALL}/usr/config/modules" ]; then
    mkdir -p ${INSTALL}/usr/config/modules
  fi
  cp -rf ${PKG_DIR}/sources/"${1}" ${INSTALL}/usr/config/modules
  chmod 0755 ${INSTALL}/usr/config/modules/"${1}"
}

makeinstall_target() {
  ### README BEFORE EDITING
  ###
  ### When adding new emulators to this package, it is now necessary to add
  ### your emulator below for it to appear in EmulationStation as es_systems.cfg
  ### is now automatically generated when this package is built.
  ###
  ### Add your cores BEFORE calling the function to add a new system, when the
  ### system is generated and added to ES the cores need to already be defined.
  ###
  ### Only ONE core per system can be set as the default, setting multiple cores
  ### will result in a build failure.
  ###
  ### add_emu_core schema:
  ###
  ### System | Emulator | Core | Default
  ### 3do      retroarch  opera  true
  ###

  ### Flush cache from previous builds
  clean_es_cache
  clean_doc_cache

  ### Add bezels directory
  add_system_dir /storage/roms/bezels

  ### Add BIOS directory
  add_system_dir /storage/roms/bios

  ### Add music directory
  add_system_dir /storage/roms/music

  ### Add save states directory
  add_system_dir /storage/roms/savestates

  ### Add themes directory
  add_system_dir /storage/roms/themes

  ### Apply documentation header
  start_system_doc

  ### Acorn BBC Micro
  add_emu_core bbcmicro retroarch b2 true
  add_es_system bbcmicro

  ### Panasonic 3DO
  add_emu_core 3do retroarch opera true
  add_es_system 3do

  ### Nintendo 3DS
  case ${DEVICE} in
    RK3576|RK3566|SM8250|SM8550|SM8650|SM8750|S922X|RK3588|SM4450|SM6115|AMD64)
      add_emu_core 3ds azahar azahar-sa true
      add_es_system 3ds
      install_script "Start Azahar.sh"
    ;;
  esac

  ### Commodore Amiga
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750)
      add_emu_core amiga retroarch puae2021 true
      add_emu_core amiga retroarch puae false
       add_emu_core amiga retroarch uae4arm false
    ;;
    *)
      add_emu_core amiga retroarch puae true
      add_emu_core amiga retroarch puae2021 false
    ;;
  esac
  add_emu_core amiga amiberry amiberry false
  add_es_system amiga

  ### Commodore Amiga CD32
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750)
      add_emu_core amigacd32 retroarch puae2021 true
      add_emu_core amigacd32 retroarch puae false
      ;;
    *)
      add_emu_core amigacd32 retroarch puae true
      add_emu_core amigacd32 retroarch puae2021 false
      ;;
  esac
  add_emu_core amigacd32 retroarch uae4arm false
  add_es_system amigacd32

  ### Amstrad CPC
  add_emu_core amstradcpc retroarch crocods true
  add_emu_core amstradcpc retroarch cap32 false
  add_es_system amstradcpc

  ### Arcade
  add_emu_core arcade retroarch mame2003_plus true
  add_emu_core arcade retroarch mame2010 false
  add_emu_core arcade retroarch mame2015 false
  add_emu_core arcade retroarch fbneo false
  add_emu_core arcade retroarch fbalpha2012 false
  add_emu_core arcade retroarch fbalpha2019 false
  add_emu_core arcade retroarch mame false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core arcade ares ares-sa false
      ;;
  esac
  add_es_system arcade

  ### Arduboy
  add_emu_core arduboy retroarch arduous true
  add_es_system arduboy

  ### Atari 2600 Libretro
  add_emu_core atari2600 retroarch stella true
  add_es_system atari2600

  ### Atari 5200 Libretro
  add_emu_core atari5200 retroarch a5200 true
  add_emu_core atari5200 retroarch atari800 false
  add_es_system atari5200

  ### Atari 7800
  add_emu_core atari7800 retroarch prosystem true
  add_es_system atari7800

  ## Atari 800
  add_emu_core atari800 retroarch atari800 true
  add_es_system atari800

  ## Atari ST
  add_emu_core atarist retroarch hatari true
  add_emu_core atarist hatarisa hatarisa false
  add_es_system atarist
  install_script "Start HATARISA.sh"

  ## Sammy Atomiswave
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM6115)
      add_emu_core atomiswave retroarch flycast2021 true
      add_emu_core atomiswave retroarch flycast false
      add_emu_core atomiswave flycast flycast-sa false
      ;;
    SM4450|SM8250|SM8550|SM8650|SM8750|S922X)
      add_emu_core atomiswave flycast flycast-sa true
      add_emu_core atomiswave retroarch flycast false
      add_emu_core atomiswave retroarch flycast2021 false
      ;;
    AMD64)
      add_emu_core atomiswave flycast flycast-sa true
      add_emu_core atomiswave retroarch flycast false
      ;;
    *)
      add_emu_core atomiswave retroarch flycast true
      add_emu_core atomiswave flycast flycast-sa false
      ;;
  esac
  add_es_system atomiswave

  ### Fairchild Channel F
  add_emu_core channelf retroarch freechaf true
  add_es_system channelf

  ### ColecoVision
  add_emu_core colecovision retroarch gearcoleco true
  add_emu_core colecovision retroarch bluemsx false
  add_emu_core colecovision retroarch smsplus false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core colecovision ares ares-sa false
      ;;
  esac
  add_es_system colecovision

  ### Commodore 128
  add_emu_core c128 retroarch vice_x128 true
  add_emu_core c128 vicesa x128 false
  add_es_system c128

  ### Commodore 16
  add_emu_core c16 retroarch vice_xplus4 true
  add_emu_core c16 vicesa xplus4 false
  add_es_system c16

  ### Commodore 64
  add_emu_core c64 retroarch vice_x64 true
  add_emu_core c64 vicesa x64sc false
  add_es_system c64

  ### Commodore PET
  add_emu_core pet retroarch vice_xpet true
  add_es_system pet

  ### Commodore VIC-20
  add_emu_core vic20 retroarch vice_xvic true
  add_emu_core vic20 vicesa xvic false
  add_es_system vic20

  ### Capcom Playsystem 1
  add_emu_core cps1 retroarch fbneo true
  add_emu_core cps1 retroarch mame2003_plus false
  add_emu_core cps1 retroarch mame2010 false
  add_emu_core cps1 retroarch fbalpha2012 false
  add_emu_core cps1 AdvanceMame AdvanceMame false
  add_es_system cps1

  ### Capcom Playsystem 2
  add_emu_core cps2 retroarch fbneo true
  add_emu_core cps2 retroarch mame2003_plus false
  add_emu_core cps2 retroarch mame2010 false
  add_emu_core cps2 retroarch fbalpha2012 false
  add_emu_core cps2 AdvanceMame AdvanceMame false
  add_es_system cps2

  ### Capcom Playsystem 3
  add_emu_core cps3 retroarch fbneo true
  add_emu_core cps3 retroarch mame2003_plus false
  add_emu_core cps3 retroarch mame2010 false
  add_emu_core cps3 retroarch fbalpha2012 false
  add_emu_core cps3 AdvanceMame AdvanceMame false
  add_es_system cps3

  ### Daphne
  add_emu_core daphne hypseus-singe hypseus-singe true
  add_emu_core daphne retroarch daphne false
  add_es_system daphne

  ### Sega Dreamcast
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM6115)
      add_emu_core dreamcast retroarch flycast2021 true
      add_emu_core dreamcast retroarch flycast false
      add_emu_core dreamcast flycast flycast-sa false
      ;;
    SM4450|SM8250|SM8550|SM8650|SM8750|S922X)
      add_emu_core dreamcast flycast flycast-sa true
      add_emu_core dreamcast retroarch flycast false
      add_emu_core dreamcast retroarch flycast2021 false
      ;;
    AMD64)
      add_emu_core dreamcast flycast flycast-sa true
      add_emu_core dreamcast retroarch flycast false
      ;;
    *)
      add_emu_core dreamcast retroarch flycast true
      add_emu_core dreamcast flycast flycast-sa false
      ;;
  esac
  install_script "Start Flycast.sh"
  add_es_system dreamcast

  ### EasyRPG
  add_emu_core easyrpg retroarch easyrpg true
  add_es_system easyrpg

  ### Elektronika BK
  add_emu_core bk retroarch bk true
  add_es_system bk

  ### Nintendo Famicom
  add_emu_core famicom retroarch nestopia true
  add_emu_core famicom retroarch fceumm false
  add_emu_core famicom retroarch quicknes false
  add_emu_core famicom retroarch mesen false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core famicom mednafen nes false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core famicom ares ares-sa false
      ;;
  esac
  add_es_system famicom

  ### Nintendo Famicom Disk System
  add_emu_core fds retroarch nestopia true
  add_emu_core fds retroarch fceumm false
  add_emu_core fds retroarch quicknes false
  add_emu_core fds retroarch mesen false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core fds mednafen nes false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core fds ares ares-sa false
      ;;
  esac
  add_es_system fds

  ### Final Burn Neo
  add_emu_core fbn retroarch fbneo true
  add_emu_core fbn retroarch mame2003_plus false
  add_emu_core fbn retroarch mame2010 false
  add_emu_core fbn retroarch mame2015 false
  add_emu_core fbn retroarch mame false
  add_emu_core fbn retroarch fbalpha2012 false
  add_emu_core fbn retroarch fbalpha2019 false
  add_es_system fbn

  ### iD Software game engines
  add_emu_core idtech retroarch idtech true
  add_es_system idtech
  install_script "Scan id Tech Games.sh"

  ### Apple Macintosh Plus
  add_emu_core macintosh retroarch minivmac true
  add_es_system macintosh

  ### Nintendo Game and Watch
  add_emu_core gameandwatch retroarch gw true
  add_emu_core gameandwatch retroarch mame false
  add_es_system gameandwatch

  ### Nintendo GameBoy
  add_emu_core gb retroarch gambatte true
  add_emu_core gb retroarch sameboy false
  add_emu_core gb retroarch gearboy false
  add_emu_core gb retroarch tgbdual false
  add_emu_core gb retroarch mgba false
  add_emu_core gb retroarch vbam false
  add_emu_core gb retroarch DoubleCherryGB false
  add_emu_core gb retroarch skyemu false
  add_emu_core gb retroarch mesen-s false
  add_emu_core gb retroarch supersnes9x false
  case ${DEVICE} in
    RK3399|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core gb retroarch bsnes false
      ;;
  esac
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gb mednafen gb false
      ;;
  esac
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gb skyemu skyemu-sa false
      install_script "Start SkyEmu.sh"
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core gb ares ares-sa false
      ;;
  esac
  add_es_system gb

  ### Nintendo GameBoy Hacks
  add_emu_core gbh retroarch gambatte true
  add_emu_core gbh retroarch sameboy false
  add_emu_core gbh retroarch gearboy false
  add_emu_core gbh retroarch tgbdual false
  add_emu_core gbh retroarch mgba false
  add_emu_core gbh retroarch vbam false
  add_emu_core gbh retroarch DoubleCherryGB false
  add_emu_core gbh retroarch skyemu false
  add_emu_core gbh retroarch mesen-s false
  add_emu_core gbh retroarch supersnes9x false
  case ${DEVICE} in
    RK3399|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core gbh retroarch bsnes false
      ;;
  esac
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbh mednafen gb false
      ;;
  esac
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbh skyemu skyemu-sa false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbh ares ares-sa false
      ;;
  esac
  add_es_system gbh

  ### Nintendo GameBoy Advance
  add_emu_core gba retroarch mgba true
  add_emu_core gba retroarch vbam false
  add_emu_core gba retroarch vba_next false
  add_emu_core gba retroarch beetle_gba false
  add_emu_core gba retroarch skyemu false
  case ${DEVICE} in
    H700|RK3326|RK3576|RK3566|S922X)
      add_emu_core gba retroarch gpsp false
      ;;
    RK3399|RK3588|SM4450|SM6115|SM8250|SM8550)
      add_emu_core gba retroarch gpsp false
      add_emu_core gba nanoboyadvance nanoboyadvance-sa false
      ;;
    SM8650|SM8750|AMD64)
      add_emu_core gba nanoboyadvance nanoboyadvance-sa false
      ;;
  esac
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gba mednafen gba false
      ;;
  esac
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gba skyemu skyemu-sa false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core gba ares ares-sa false
      ;;
  esac
  add_es_system gba

  ### Nintendo GameBoy Advance Hacks
  add_emu_core gbah retroarch mgba true
  add_emu_core gbah retroarch vbam false
  add_emu_core gbah retroarch vba_next false
  add_emu_core gbah retroarch beetle_gba false
  add_emu_core gbah retroarch skyemu false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550)
      add_emu_core gbah retroarch gpsp false
      add_emu_core gbah mednafen gba false
      ;;
    SM8650|SM8750|AMD64)
      add_emu_core gbah mednafen gba false
      ;;
  esac
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbah skyemu skyemu-sa false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbah ares ares-sa false
      ;;
  esac
  add_es_system gbah

  ### Nintendo GameBoy Advance Video
  add_emu_core gbav retroarch mgba true
  add_emu_core gbav retroarch vbam false
  add_emu_core gbav retroarch vba_next false
  add_emu_core gbav retroarch beetle_gba false
  add_emu_core gbav retroarch skyemu false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550)
      add_emu_core gbav retroarch gpsp false
      add_emu_core gbav mednafen gba false
      ;;
    SM8650|SM8750|AMD64)
      add_emu_core gbav mednafen gba false
      ;;
  esac
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbav skyemu skyemu-sa false
      ;;
  esac
  add_es_system gbav

  ### Nintendo GameBoy Color
  add_emu_core gbc retroarch gambatte true
  add_emu_core gbc retroarch sameboy false
  add_emu_core gbc retroarch gearboy false
  add_emu_core gbc retroarch tgbdual false
  add_emu_core gbc retroarch mgba false
  add_emu_core gbc retroarch vbam false
  add_emu_core gbc retroarch DoubleCherryGB false
  add_emu_core gbc retroarch skyemu false
  add_emu_core gbc retroarch mesen-s false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbc mednafen gb false
      ;;
  esac
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbc skyemu skyemu-sa false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbc ares ares-sa false
      ;;
  esac
  add_es_system gbc

  ### Nintendo GameBoy Color Hacks
  add_emu_core gbch retroarch gambatte true
  add_emu_core gbch retroarch sameboy false
  add_emu_core gbch retroarch gearboy false
  add_emu_core gbch retroarch tgbdual false
  add_emu_core gbch retroarch mgba false
  add_emu_core gbch retroarch vbam false
  add_emu_core gbch retroarch DoubleCherryGB false
  add_emu_core gbch retroarch skyemu false
  add_emu_core gbch retroarch mesen-s false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbch mednafen gb false
      ;;
  esac
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbch skyemu skyemu-sa false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core gbch ares ares-sa false
      ;;
  esac
  add_es_system gbch

  ### Nintendo GameCube
  case ${DEVICE} in
    GENERIC_X64)
      add_emu_core gamecube dolphin dolphin-sa-gc true
      add_emu_core gamecube dolphin dolphin-qt-gc false
      install_script "Start Dolphin.sh"
      add_es_system gamecube
      ;;
    RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core gamecube dolphin dolphin-sa-gc true
      add_emu_core gamecube dolphin dolphin-qt-gc false
      add_emu_core gamecube retroarch dolphin false
      install_script "Start Dolphin.sh"
      add_es_system gamecube
      ;;
  esac

  ### Nintendo Triforce
  case ${DEVICE} in
    RK3399|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core triforce dolphin dolphin-sa-gc true
      add_emu_core triforce dolphin dolphin-qt-gc false
      install_script "Start Dolphin.sh"
      add_es_system triforce
      ;;
  esac

  ### Nintendo Wii/ware
  case ${DEVICE} in
    GENERIC_X64)
      add_emu_core wii dolphin dolphin-sa-wii true
      add_emu_core wii dolphin dolphin-qt-wii false
      add_es_system wii
      ;;
    RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core wii dolphin dolphin-sa-wii true
      add_emu_core wiiware dolphin dolphin-sa-wii true
      add_emu_core wii dolphin dolphin-qt-wii false
      add_emu_core wiiware dolphin dolphin-qt-wii false
      add_emu_core wii retroarch dolphin false
      add_emu_core wiiware retroarch dolphin false
      add_es_system wii
      add_es_system wiiware
      ;;
  esac

  ### Nintendo Wii U
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core wiiu cemu cemu-sa true
      add_es_system wiiu
      install_script "Start CEMU.sh"
      ;;
  esac

  ### Sega GameGear
  add_emu_core gamegear retroarch gearsystem true
  add_emu_core gamegear retroarch genesis_plus_gx false
  add_emu_core gamegear retroarch picodrive false
  add_emu_core gamegear retroarch smsplus false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core gamegear mednafen gg false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core gamegear ares ares-sa false
      ;;
  esac
  add_es_system gamegear

  ### Sega GameGear Hacks
  add_emu_core ggh retroarch gearsystem true
  add_emu_core ggh retroarch genesis_plus_gx false
  add_emu_core ggh retroarch picodrive false
  add_emu_core ggh retroarch smsplus false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core ggh mednafen gg false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core ggh ares ares-sa false
      ;;
  esac
  add_es_system ggh

  ### Apple iOS
  add_emu_core ios touchhle touchhle-sa true
  install_script "Start touchHLE.sh"
  add_es_system ios

  ## Steam & Heroic Games Launcher
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750)
      add_emu_core steam steam steam true
      install_script "Install Steam.sh"
      install_script "Uninstall Steam.sh"
      add_es_system steam
      add_emu_core heroic heroic heroic true
      install_script "Install Heroic Games Launcher.sh"
      install_script "Uninstall Heroic Games Launcher.sh"
      install_script "Scan Heroic Games.sh"
      add_es_system heroic
      ;;
  esac

  ### Intellivision
  add_emu_core intellivision retroarch freeintv true
  add_es_system intellivision

  ### Sun Microsystems J2ME
  add_emu_core j2me retroarch freej2me true
  add_es_system j2me

  ### Atari Jaguar
  add_emu_core atarijaguar retroarch virtualjaguar true
  case ${DEVICE} in
    S922X|SM4450|SM8250|SM8550|SM8650|SM8750)
      add_emu_core atarijaguar bigpemu bigpemu-sa false
      install_script "Start BigPEmu.sh"
      ;;
  esac
  add_es_system atarijaguar

  ### Atari Lynx
  add_emu_core atarilynx retroarch handy true
  add_emu_core atarilynx retroarch beetle_lynx false
  add_emu_core atarilynx retroarch gearlynx false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core atarilynx mednafen lynx false
      ;;
  esac
  add_es_system atarilynx

  ### Infocom Z-Machine
  add_emu_core zmachine retroarch mojozork true
  add_es_system zmachine

  ### Arcade (MAME)
  add_emu_core mame retroarch mame2003_plus true
  add_emu_core mame retroarch mame2010 false
  add_emu_core mame retroarch mame2015 false
  add_emu_core mame retroarch mame false
  add_emu_core mame retroarch fbneo false
  add_emu_core mame retroarch fbalpha2012 false
  add_emu_core mame retroarch fbalpha2019 false
  add_es_system mame

  ### Sega MegaDrive
  add_emu_core megadrive-japan retroarch genesis_plus_gx true
  add_emu_core megadrive-japan retroarch genesis_plus_gx_wide false
  add_emu_core megadrive-japan retroarch picodrive false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core megadrive-japan mednafen md false
      ;;
  esac
  add_es_system megadrive-japan

  ### Sega Model 3
  case ${DEVICE} in
    RK3588|SM4450|SM8250|SM8550|SM8650|SM8750)
      add_emu_core segamodel3 supermodel supermodel-sa true
      add_es_system segamodel3
      ;;
  esac

  ### Microsoft MS-DOS
  add_emu_core pc retroarch dosbox_pure true
  add_emu_core pc retroarch dosbox_core false
  add_es_system pc

  ### Nintendo MSU-1
  add_emu_core snesmsu1 retroarch snes9x true
  add_emu_core snesmsu1 retroarch supersnes9x false
  add_emu_core snesmsu1 retroarch beetle_supafaust false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core snesmsu1 mednafen snes_faust false
      ;;
  esac
  add_es_system snesmsu1

  ### Microsoft MSX
  add_emu_core msx retroarch bluemsx true
  add_emu_core msx retroarch fmsx false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core msx ares ares-sa false
      ;;
  esac
  add_es_system msx

  ### Microsoft MSX 2
  add_emu_core msx2 retroarch bluemsx true
  add_emu_core msx2 retroarch fmsx false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core msx ares ares-sa false
      ;;
  esac
  add_es_system msx2

  ### Sega Naomi
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM6115)
      add_emu_core naomi retroarch flycast2021 true
      add_emu_core naomi retroarch flycast false
      add_emu_core naomi flycast flycast-sa false
      ;;
    SM4450|SM8250|SM8550|SM8650|SM8750|S922X)
      add_emu_core naomi flycast flycast-sa true
      add_emu_core naomi retroarch flycast false
      add_emu_core naomi retroarch flycast2021 false
      ;;
    AMD64)
      add_emu_core naomi flycast flycast-sa true
      add_emu_core naomi retroarch flycast false
      ;;
    *)
      add_emu_core naomi retroarch flycast true
      add_emu_core naomi flycast flycast-sa false
      ;;
  esac
  add_es_system naomi

  ### SNK NeoGeo
  add_emu_core neogeo retroarch fbneo true
  add_emu_core neogeo retroarch mame2003_plus false
  add_emu_core neogeo retroarch fbalpha2012 false
  add_emu_core neogeo retroarch fbalpha2019 false
  add_emu_core neogeo retroarch mame2010 false
  add_emu_core neogeo retroarch mame2015 false
  add_emu_core neogeo retroarch mame false
  add_emu_core neogeo retroarch geolith false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core neogeo ares ares-sa false
      ;;
  esac

  add_es_system neogeo

  ### SNK NeoCD
  add_emu_core neocd retroarch neocd true
  add_emu_core neocd retroarch fbneo false
  add_emu_core neocd retroarch geolith false
  add_es_system neocd

  ### SNK NeoGeo Pocket
  add_emu_core ngp retroarch beetle_ngp true
  add_emu_core ngp retroarch race false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core ngp mednafen ngp false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core ngp ares ares-sa false
      ;;
  esac
  add_es_system ngp

  ### SNK NeoGeo Pocket Color
  add_emu_core ngpc retroarch beetle_ngp true
  add_emu_core ngpc retroarch race false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core ngpc mednafen ngp false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core ngpc ares ares-sa false
      ;;
  esac
  add_es_system ngpc

  ### Nintendo 64
  add_emu_core n64 retroarch mupen64plus_next true
  if [ "${PREFER_GLES}" = "yes" ]; then
    # This core only has gles renderer
    add_emu_core n64 retroarch mupen64plus false
  fi
  add_emu_core n64 retroarch parallel_n64 false
  add_emu_core n64 mupen64plus mupen64plus-sa false
  case ${DEVICE} in
    SM4450|SM8250)
      add_emu_core n64 daedalusx64 daedalusx64-sa false
      install_script "Start DaedalusX64.sh"
      ;;
    SM8550)
      add_emu_core n64 daedalusx64 daedalusx64-sa false
      add_emu_core n64 gopher64 gopher64-sa false
      add_emu_core n64 ares ares-sa false
      install_script "Start DaedalusX64.sh"
      ;;
    SM8650|SM8750|AMD64)
      add_emu_core n64 gopher64 gopher64-sa false
      add_emu_core n64 ares ares-sa false
      ;;
  esac
  add_es_system n64

  ### Nintendo 64 Disk Drive
  add_emu_core n64dd retroarch mupen64plus_next true
  add_emu_core n64dd retroarch parallel_n64 false
  add_emu_core n64dd mupen64plus mupen64plus-sa false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core n64dd ares ares-sa false
      ;;
  esac
  add_es_system n64dd

  ### Nintendo DS
  case ${DEVICE} in
    H700|RK3326)
      add_emu_core nds drastic drastic-sa true
      add_emu_core nds retroarch melonds false
      add_emu_core nds retroarch melondsds false
      add_emu_core nds retroarch desmume false
      add_emu_core nds retroarch skyemu false
      add_emu_core nds dsperate dsperate-sa false
      ;;
    RK3399|RK3566|RK3576|RK3588|SM6115)
      add_emu_core nds drastic drastic-sa true
      add_emu_core nds retroarch melonds false
      add_emu_core nds retroarch melondsds false
      add_emu_core nds melonds melonds-sa false
      add_emu_core nds retroarch desmume false
      add_emu_core nds retroarch skyemu false
      add_emu_core nds dsperate dsperate-sa false
      install_script "Start MelonDS.sh"
      ;;
    SM4450|SM8250|SM8550)
      add_emu_core nds melonds melonds-sa true
      add_emu_core nds drastic drastic-sa false
      add_emu_core nds skyemu skyemu-sa false
      add_emu_core nds retroarch melonds false
      add_emu_core nds retroarch melondsds false
      add_emu_core nds retroarch desmume false
      add_emu_core nds retroarch skyemu false
      add_emu_core nds dsperate dsperate-sa false
      install_script "Start MelonDS.sh"
      ;;
    SM8650|SM8750)
      add_emu_core nds melonds melonds-sa true
      add_emu_core nds skyemu skyemu-sa false
      add_emu_core nds retroarch melonds false
      add_emu_core nds retroarch melondsds false
      add_emu_core nds retroarch skyemu false
      add_emu_core nds dsperate dsperate-sa false
      install_script "Start MelonDS.sh"
      ;;
    AMD64)
      add_emu_core nds melonds melonds-sa true
      add_emu_core nds skyemu skyemu-sa false
      add_emu_core nds retroarch melonds false
      add_emu_core nds retroarch melondsds false
      add_emu_core nds retroarch skyemu false
      install_script "Start MelonDS.sh"
      ;;
    S922X)
      add_emu_core nds drastic drastic-sa true
      add_emu_core nds retroarch melonds false
      add_emu_core nds retroarch melondsds false
      add_emu_core nds melonds melonds-sa false
      add_emu_core nds retroarch skyemu false
      add_emu_core nds dsperate dsperate-sa false
      install_script "Start MelonDS.sh"
      ;;
    *)
      add_emu_core nds drastic drastic-sa true
      add_emu_core nds retroarch melonds false
      add_emu_core nds retroarch melondsds false
      add_emu_core nds retroarch skyemu false
      add_emu_core nds dsperate dsperate-sa false
      ;;
  esac
  add_es_system nds

  ### Nintendo DSiWare
  case ${DEVICE} in
    H700|RK3326)
      add_emu_core ndsiware retroarch melondsds true
      add_emu_core ndsiware dsperate dsperate-sa false
      ;;
    AMD64)
      add_emu_core ndsiware retroarch melondsds true
      add_emu_core ndsiware melonds melonds-sa false
      ;;
    *)
      add_emu_core ndsiware retroarch melondsds true
      add_emu_core ndsiware melonds melonds-sa false
      add_emu_core ndsiware dsperate dsperate-sa false
      ;;
  esac
  add_es_system ndsiware

  ### Nintendo NES
  add_emu_core nes retroarch nestopia true
  add_emu_core nes retroarch fceumm false
  add_emu_core nes retroarch quicknes false
  add_emu_core nes retroarch mesen false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core nes mednafen nes false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core nes ares ares-sa false
      ;;
  esac
  add_es_system nes

  ### Nintendo NES Hacks
  add_emu_core nesh retroarch nestopia true
  add_emu_core nesh retroarch fceumm false
  add_emu_core nesh retroarch quicknes false
  add_emu_core nesh retroarch mesen false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core nesh mednafen nesh false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core nesh ares ares-sa false
      ;;
  esac
  add_es_system nesh

  ### Magnavox Odyssey
  add_emu_core odyssey2 retroarch o2em true
  add_es_system odyssey2

  ### OpenBOR
  add_emu_core openbor OpenBOR OpenBOR true
  add_es_system openbor

  ### NEC PC-8800
  add_emu_core pc-8800 retroarch quasi88 true
  add_es_system pc-8800

  ### NEC PC-9800
  add_emu_core pc-9800 retroarch np2kai true
  add_es_system pc-9800

  ### NEC PC Engine
  add_emu_core pcengine retroarch beetle_pce_fast true
  add_emu_core pcengine retroarch beetle_pce false
  add_emu_core pcengine retroarch beetle_supergrafx false
  add_emu_core pcengine retroarch geargrafx false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core pcengine mednafen pce false
      add_emu_core pcengine mednafen pce_fast false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core pcengine ares ares-sa false
      ;;
  esac
  add_es_system pcengine

  ### NEC PC Engine CD
  add_emu_core pcenginecd retroarch beetle_pce_fast true
  add_emu_core pcenginecd retroarch beetle_pce false
  add_emu_core pcenginecd retroarch beetle_supergrafx false
  add_emu_core pcenginecd retroarch geargrafx false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core pcenginecd mednafen pce false
      add_emu_core pcenginecd mednafen pce_fast false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core pcenginecd ares ares-sa false
      ;;
  esac
  add_es_system pcenginecd

  ### NEC PC-FX
  add_emu_core pcfx retroarch beetle_pcfx true
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core pcfx mednafen pcfx false
      ;;
  esac
  add_es_system pcfx

  ### Lexaloffle PICO-8
  add_emu_core pico-8 pico-8 pico8 true
  add_emu_core pico-8 retroarch fake08 false
  add_es_system pico-8

  ### Sony Playstation
  case ${DEVICE} in
    H700|RK3326)
      add_emu_core psx retroarch pcsx_rearmed32 true
      add_emu_core psx retroarch pcsx_rearmed false
      add_emu_core psx retroarch duckstation false
      ;;
    RK3399|RK3588|SM6115)
      add_emu_core psx retroarch pcsx_rearmed true
      add_emu_core psx retroarch pcsx_rearmed32 false
      add_emu_core psx retroarch beetle_psx false
      add_emu_core psx mednafen psx false
      add_emu_core psx retroarch duckstation false
      ;;
    RK3576|RK3566)
      add_emu_core psx retroarch pcsx_rearmed32 true
      add_emu_core psx retroarch pcsx_rearmed false
      add_emu_core psx retroarch duckstation false
      ;;
    SM4450|SM8250|SM8550)
      add_emu_core psx retroarch pcsx_rearmed32 true
      add_emu_core psx retroarch pcsx_rearmed false
      add_emu_core psx retroarch beetle_psx false
      add_emu_core psx mednafen psx false
     add_emu_core psx retroarch duckstation false
      ;;
    SM8650|SM8750)
      add_emu_core psx retroarch pcsx_rearmed true
      add_emu_core psx retroarch beetle_psx false
      add_emu_core psx mednafen psx false
     add_emu_core psx retroarch duckstation false
      ;;
    S922X)
      add_emu_core psx retroarch pcsx_rearmed true
      add_emu_core psx retroarch beetle_psx false
      add_emu_core psx retroarch duckstation false
      ;;
    AMD64)
      add_emu_core psx retroarch pcsx_rearmed true
      add_emu_core psx retroarch beetle_psx false
      add_emu_core psx mednafen psx false
  esac
  add_emu_core psx duckstation duckstation-sa false
  add_emu_core psx retroarch swanstation false
  add_es_system psx

  ### Sony Playstation 2
  case ${DEVICE} in
  AMD64)
    add_emu_core ps2 armsx2 armsx2-sa true
    install_script "Start ARMSX2.sh"
    add_es_system ps2
    ;;
  RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X)
    add_emu_core ps2 armsx2 armsx2-sa true
    add_emu_core ps2 aethersx2 aethersx2-sa false
    add_es_system ps2
    install_script "Start ARMSX2.sh"
    install_script "Start AetherSX2.sh"
    ;;
  esac

  ### Sony Playstation 3
  case ${DEVICE} in
    SM8250|SM8550|SM8650|SM8750)
      add_emu_core ps3 rpcs3 rpcs3-sa true
      add_es_system ps3
      install_script "Start RPCS3.sh"
      ;;
  esac

  ### Sony Playstation Portable
  add_emu_core psp ppsspp ppsspp-sa true
  add_emu_core psp retroarch ppsspp false
  add_es_system psp
  install_script "Start PPSSPP.sh"

  ### Sony Playstation Portable Minis
  add_emu_core pspminis ppsspp ppsspp-sa true
  add_emu_core pspminis retroarch ppsspp false
  add_es_system pspminis

  ### Sony Playstation Vita
  case ${DEVICE} in
    RK3566|RK3576|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core psvita vita3k vita3k-sa true
      add_es_system psvita
      install_script "Start Vita3K.sh"
      ;;
  esac

  ### Nintendo Pokemon Mini
  add_emu_core pokemini retroarch pokemini true
  add_es_system pokemini

  ### ScummVM
  add_emu_core scummvm scummvm-sa scummvm true
  add_emu_core scummvm retroarch scummvm false
  add_es_system scummvm
  add_system_dir /storage/roms/scummvm
  install_script "Scan ScummVM Games.sh"
  install_script "Start ScummVM.sh"

  ### Joseph Weisbecker CHIP-8
  add_emu_core chip-8 retroarch jaxe true
  add_es_system chip-8

  ### Sega 32X
  add_emu_core sega32x retroarch picodrive true
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core sega32x ares ares-sa false
      ;;
  esac
  add_es_system sega32x

  ### Sega CD
  add_emu_core segacd retroarch genesis_plus_gx true
  add_emu_core segacd retroarch picodrive false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core segacd ares ares-sa false
      ;;
  esac
  add_es_system segacd

  ### Sega Mega-CD
  add_emu_core megacd retroarch genesis_plus_gx true
  add_emu_core megacd retroarch picodrive false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core megacd ares ares-sa false
      ;;
  esac
  add_es_system megacd

  ### Sega Genesis
  add_emu_core genesis retroarch genesis_plus_gx true
  add_emu_core genesis retroarch genesis_plus_gx_wide false
  add_emu_core genesis retroarch picodrive false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core genesis mednafen md false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core genesis ares ares-sa false
      ;;
  esac
  add_es_system genesis

  ### Sega Genesis Hacks
  add_emu_core genh retroarch genesis_plus_gx true
  add_emu_core genh retroarch genesis_plus_gx_wide false
  add_emu_core genh retroarch picodrive false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core genh mednafen md false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core genh ares ares-sa false
      ;;
  esac
  add_es_system genh

  ### Sega MasterSystem
  add_emu_core mastersystem retroarch gearsystem true
  add_emu_core mastersystem retroarch genesis_plus_gx false
  add_emu_core mastersystem retroarch picodrive false
  add_emu_core mastersystem retroarch smsplus false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core mastersystem mednafen sms false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core mastersystem ares ares-sa false
      ;;
  esac
  add_es_system mastersystem

  ### Sega MegaDrive
  add_emu_core megadrive retroarch genesis_plus_gx true
  add_emu_core megadrive retroarch genesis_plus_gx_wide false
  add_emu_core megadrive retroarch picodrive false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core megadrive mednafen md false
      ;;
  esac
  add_es_system megadrive

  ### Sega MegaDrive Hacks
  add_emu_core megadriveh retroarch genesis_plus_gx true
  add_emu_core megadriveh retroarch genesis_plus_gx_wide false
  add_emu_core megadriveh retroarch picodrive false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core megadriveh mednafen md false
      ;;
  esac
  add_es_system megadriveh

  ### Welback Holdings Mega Duck
  add_emu_core megaduck retroarch sameduck true
  add_es_system megaduck

  ### Sega Saturn
  add_emu_core saturn yabasanshiro yabasanshiro-sa true
  add_emu_core saturn retroarch yabasanshiro false
  case ${DEVICE} in
    RK3588|SM6115)
      add_emu_core saturn retroarch beetle_saturn false
      add_emu_core saturn mednafen ss false
      ;;
    SM4450|SM8250|SM8550|SM8650|SM8750)
      add_emu_core saturn retroarch beetle_saturn false
      add_emu_core saturn retroarch kronos false
      add_emu_core saturn mednafen ss false
      ;;
    S922X|AMD64)
      add_emu_core saturn retroarch beetle_saturn false
      ;;
  esac
  add_es_system saturn

  ### Sega ST-V
  case ${DEVICE} in
    RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core st-v mednafen ss true
      ;;
  esac
  add_es_system st-v

  ### Sega SG-1000
  add_emu_core sg-1000 retroarch gearsystem true
  add_emu_core sg-1000 retroarch genesis_plus_gx false
  add_emu_core sg-1000 retroarch picodrive false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core sg-1000 ares ares-sa false
      ;;
  esac
  add_es_system sg-1000

  ### Sharp X1
  add_emu_core x1 retroarch x1 true
  add_es_system x1

  ### Microsoft XBox
  case ${DEVICE} in
    SM4450|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core xbox xemu xemu-sa true
      add_es_system xbox
      install_script "Start Xemu.sh"
      ;;
  esac

  ### Sinclair ZX Spectrum
  add_emu_core zxspectrum retroarch fuse true
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core zxspectrum ares ares-sa false
      ;;
  esac
  add_es_system zxspectrum

  ### Sinclair ZX81
  add_emu_core zx81 retroarch 81 true
  add_es_system zx81

  ### NEC Super Grafx
  add_emu_core supergrafx retroarch beetle_supergrafx true
  add_emu_core supergrafx retroarch beetle_pce false
  add_emu_core supergrafx retroarch geargrafx false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core supergrafx mednafen pce false
      add_emu_core supergrafx mednafen pce_fast false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core supergrafx ares ares-sa false
      ;;
  esac
  add_es_system supergrafx

  ### Nintendo SNES
  add_emu_core snes retroarch snes9x true
  add_emu_core snes retroarch snes9x2010 false
  add_emu_core snes retroarch snes9x2002 false
  add_emu_core snes retroarch snes9x2005_plus false
  add_emu_core snes retroarch supersnes9x false
  add_emu_core snes retroarch beetle_supafaust false
  add_emu_core snes retroarch bsnes_mercury_accuracy false
  add_emu_core snes retroarch bsnes_mercury_balanced false
  add_emu_core snes retroarch bsnes_mercury_performance false
  add_emu_core snes retroarch bsnes2014_accuracy false
  add_emu_core snes retroarch bsnes2014_balanced false
  add_emu_core snes retroarch bsnes2014_performance false
  add_emu_core snes retroarch mesen-s false
  case ${DEVICE} in
    RK3399|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core snes retroarch bsnes false
      add_emu_core snes retroarch bsnes_hd_beta false
      ;;
  esac
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core snes mednafen snes_faust false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core snes ares ares-sa false
      ;;
  esac
  add_es_system snes

  ### Nintendo SNES Hacks
  add_emu_core snesh retroarch snes9x true
  add_emu_core snesh retroarch snes9x2010 false
  add_emu_core snesh retroarch snes9x2002 false
  add_emu_core snesh retroarch snes9x2005_plus false
  add_emu_core snesh retroarch supersnes9x false
  add_emu_core snesh retroarch beetle_supafaust false
  add_emu_core snesh retroarch bsnes_mercury_accuracy false
  add_emu_core snesh retroarch bsnes_mercury_balanced false
  add_emu_core snesh retroarch bsnes_mercury_performance false
  add_emu_core snesh retroarch bsnes2014_accuracy false
  add_emu_core snesh retroarch bsnes2014_balanced false
  add_emu_core snesh retroarch bsnes2014_performance false
  add_emu_core snesh retroarch mesen-s false
  case ${DEVICE} in
    RK3399|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core snesh retroarch bsnes false
      add_emu_core snesh retroarch bsnes_hd_beta false
      ;;
  esac
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core snesh mednafen snes_faust false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core snesh ares ares-sa false
      ;;
  esac
  add_es_system snesh

  ### Nintendo Super Famicom
  add_emu_core sfc retroarch snes9x true
  add_emu_core sfc retroarch snes9x2010 false
  add_emu_core sfc retroarch snes9x2002 false
  add_emu_core sfc retroarch snes9x2005_plus false
  add_emu_core sfc retroarch supersnes9x false
  add_emu_core sfc retroarch beetle_supafaust false
  add_emu_core sfc retroarch bsnes_mercury_accuracy false
  add_emu_core sfc retroarch bsnes_mercury_balanced false
  add_emu_core sfc retroarch bsnes_mercury_performance false
  add_emu_core sfc retroarch bsnes2014_accuracy false
  add_emu_core sfc retroarch bsnes2014_balanced false
  add_emu_core sfc retroarch bsnes2014_performance false
  add_emu_core sfc retroarch mesen-s false
  case ${DEVICE} in
    RK3399|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
      add_emu_core sfc retroarch bsnes false
      add_emu_core sfc retroarch bsnes_hd_beta false
      ;;
  esac
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core sfc mednafen snes_faust false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core sfc ares ares-sa false
      ;;
  esac
  add_es_system sfc

  ### Nintendo Stellaview
  add_emu_core satellaview retroarch snes9x true
  add_emu_core satellaview retroarch snes9x2010 false
  add_emu_core satellaview retroarch snes9x2002 false
  add_emu_core satellaview retroarch snes9x2005_plus false
  add_emu_core satellaview retroarch supersnes9x false
  add_emu_core satellaview retroarch mesen-s false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core satellaview ares ares-sa false
      ;;
  esac
  add_es_system satellaview

  ### Bandai SuFami Turbo
  add_emu_core sufami retroarch snes9x true
  add_emu_core sufami retroarch supersnes9x false
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core sufami ares ares-sa false
      ;;
  esac
  add_es_system sufami

  ### Watara Supervision
  add_emu_core supervision retroarch potator true
  add_es_system supervision

  ### Nesbox TIC-80
  add_emu_core tic-80 retroarch tic80 true
  add_es_system tic-80

  ### Various WASM-4
  add_emu_core wasm4 retroarch wasm4 true
  add_es_system wasm4

  ### NEC TurboGrafx 16
  add_emu_core tg16 retroarch beetle_pce_fast true
  add_emu_core tg16 retroarch beetle_pce false
  add_emu_core tg16 retroarch beetle_supergrafx false
  add_emu_core tg16 retroarch geargrafx false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core tg16 mednafen pce false
      add_emu_core tg16 mednafen pce_fast false
      ;;
  esac
  add_es_system tg16

  ### NEC TurboGrafx CD
  add_emu_core tg16cd retroarch beetle_pce_fast true
  add_emu_core tg16cd retroarch beetle_pce false
  add_emu_core tg16cd retroarch beetle_supergrafx false
  add_emu_core tg16cd retroarch geargrafx false
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core tg16cd mednafen pce false
      add_emu_core tg16cd mednafen pce_fast false
      ;;
  esac
  add_es_system tg16cd

  ### Belogic Uzebox
  add_emu_core uzebox retroarch uzem true
  add_es_system uzebox

  ### Milton Bradley Vectrex
  add_emu_core vectrex retroarch vecx true
  add_es_system vectrex

  ### Philips - CDi
  add_emu_core cdi retroarch same_cdi true
  add_es_system cdi

  ### Philips Videopac
  add_emu_core videopac retroarch o2em true
  add_es_system videopac

  ### Nintendo VirtualBoy
  add_emu_core virtualboy retroarch beetle_vb true
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core virtualboy mednafen vb false
      ;;
  esac
  add_es_system virtualboy

  ### Bandai Wonderswan
  add_emu_core wonderswan retroarch beetle_wswan true
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core wonderswan mednafen wswan false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core wonderswan ares ares-sa false
      ;;
  esac
  add_es_system wonderswan

  ### Bandai Wonderswan Color
  add_emu_core wonderswancolor retroarch beetle_wswan true
  case ${DEVICE} in
    H700|RK3326|RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|AMD64)
      add_emu_core wonderswancolor mednafen wswan false
      ;;
  esac
  case ${DEVICE} in
    SM8550|SM8650|SM8750|AMD64)
      add_emu_core wonderswancolor ares ares-sa false
      ;;
  esac
  add_es_system wonderswancolor

  ### Sharp x68000
  add_emu_core x68000 retroarch px68k true
  add_es_system x68000

  ### EPOCH/YENO Super Cassette Vision
  add_emu_core scv retroarch emuscv true
  add_es_system scv

  ### Vircon32
  add_emu_core vircon32 retroarch vircon32 true
  add_es_system vircon32

  ### MO/TO Family
  add_emu_core moto retroarch theodore true
  add_es_system moto

  ### Palm OS
  add_emu_core palm retroarch mu true
  add_es_system palm

  ### GamePark GP32
  add_emu_core gp32 retroarch mame true
  add_es_system gp32

  ### PC Ports
  add_emu_core ports portmaster portmaster true
  add_es_system ports

  ### Windows
  add_emu_core windows wine wine true
  add_es_system windows

  ### Doom
  add_emu_core doom gzdoom gzdoom-sa true
  add_emu_core doom retroarch prboom false
  add_es_system doom

  ### Media Player
  add_emu_core mplayer mplayer mplayer true
  # Note - there is actually no ffmpeg core, it is compiled into retroarch
  add_emu_core mplayer retroarch ffmpeg false
  add_es_system mplayer

  ### Music Player
  add_emu_core music gmu gmu true
  add_es_system music

  ### Moonlight
  add_emu_core moonlight moonlight moonlight true
  add_es_system moonlight

  ### Tools
  add_es_system tools

  ### Screenshots
  add_es_system imageviewer

  ### Create es_systems
  mk_es_systems

  ### Generate document
  mk_system_doc

  mkdir -p ${INSTALL}/usr/config/emulationstation
  cp -f ${ESTMP}/es_systems.cfg ${INSTALL}/usr/config/emulationstation

  if [ "${WINDOWMANAGER}" = "weston" ]; then
    sed -i 's~%RUNCOMMAND%~weston-terminal --command="%ROM%"~g' ${INSTALL}/usr/config/emulationstation/es_systems.cfg
  elif [ "${WINDOWMANAGER}" = "swaywm-env" ]; then
    sed -i 's~%RUNCOMMAND%~/usr/bin/foot %ROM%~g' ${INSTALL}/usr/config/emulationstation/es_systems.cfg
  else
    sed -i 's~%RUNCOMMAND%~/usr/bin/run %ROM%~g' ${INSTALL}/usr/config/emulationstation/es_systems.cfg
  fi

  ### Automount should handle this.
  cp -f ${ESTMP}/system-dirs.conf ${INSTALL}/usr/config

  mkdir -p ${INSTALL}/usr/bin
  cp ${PKG_DIR}/scripts/mkcontroller ${INSTALL}/usr/bin

  mkdir -p ${INSTALL}/usr/lib/autostart/common
  cp ${PKG_DIR}/autostart/* ${INSTALL}/usr/lib/autostart/common
  chmod 0755 ${INSTALL}/usr/lib/autostart/common/*

  ### Core version pins for the save manifest (fork #21, D-CLOUD-017).
  ### One line per emulator core package built into this image,
  ### "<package> <PKG_VERSION>". The capture step maps a core name to its
  ### package and records the version as the manifest's core_build -- the
  ### value two devices compare to know whether a save state will load
  ### (#19). Only the build knows every pin, so it is emitted here; a core
  ### the capture step cannot map records "unknown".
  ###
  ### Every list a core can arrive through: the libretro cores, the 32-bit
  ### set (desmume-lr/gpsp-lr on H700, RK3326, RK3399), the standalones
  ### (mupen64plus-sa writes the N64 .eep/.mpk row), and the cores idtech-lr
  ### pulls in for its per-game launcher, which carry no line of their own.
  ### The filter keeps box86/box64/portmaster and the retroarch assets out.
  ### Two standalones are named without the dash (hatarisa, scummvmsa) and
  ### are admitted by name, so a round-two unit row for either finds its pin
  ### rather than "unknown"; a new standalone spelled that way joins them here.
  IDTECH_CORES="boom3-lr ecwolf-lr prboom-lr tyrquake-lr vitaquake2-lr vitaquake3-lr"
  mkdir -p ${INSTALL}/usr/share/rocknix
  : > ${INSTALL}/usr/share/rocknix/core-pins
  for _core_pkg in ${LIBRETRO_CORES} ${EMUS_32BIT} ${PKG_EMUS} ${IDTECH_CORES}; do
    case "${_core_pkg}" in *-lr|*_lr|*-sa|hatarisa|scummvmsa) ;; *) continue ;; esac
    _core_ver="$(get_pkg_version "${_core_pkg}" 2>/dev/null)"
    [ -n "${_core_ver}" ] && echo "${_core_pkg} ${_core_ver}" >> ${INSTALL}/usr/share/rocknix/core-pins
  done
  sort -u -o ${INSTALL}/usr/share/rocknix/core-pins ${INSTALL}/usr/share/rocknix/core-pins
}

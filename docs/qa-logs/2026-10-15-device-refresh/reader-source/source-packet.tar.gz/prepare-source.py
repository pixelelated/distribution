"""Materialize source-only review files; not an owner preparer or runtime reader."""
from pathlib import Path
import difflib,hashlib,json,shutil,stat
P=Path(__file__).resolve().parent
O=Path('/workspace/tmp/pix-m7-h700-refresh-20261015-02')
N=Path('/workspace/tmp/pix-m7-h700-reader-20261015-01')
T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04')
F=Path('/tmp/pix-m7-h700-reader-failure-20261015')
RUN=T/'.build-runs/20261015T060011Z-92b2fe8b'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def put(f,j):f.write_text(json.dumps(j,indent=2)+'\n')
rows=json.loads((P/'source-originals.json').read_text());known={r['path'] for r in rows}
files=[F/n for n in ['output-manifest.json','completion-evidence.json','investigation.json','originals.json']]
files += [RUN/n for n in ['admission.json','admission-consumed.json','runner-result.json','build.rc','build.status']]
files += [O/n for n in ['inputs.json','build-seal.json','launcher-result.json','tool-wrapper.rc','inner.rc','outer.rc','build.cid','artifacts/arm-output-manifest.json','artifacts/container-gate.json','acceptance/retention-plan.json','acceptance/admission-plan.json','proxy-source-proof.json','dolphin-sys-source-manifest.json']]
for f in files:
 if str(f) in known:continue
 dst=P/'originals'/f'{len(rows):03d}-{f.name}';shutil.copy2(f,dst);s=f.stat();rows.append({'path':str(f),'copy':str(dst.relative_to(P)),'sha256':sha(f),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode)});known.add(str(f))
put(P/'source-originals.json',rows)
put(P/'bindings.json',{'source_commit':'f8636de1d105275dbf9420bbabbbc26f79abb10f','old_owner':str(O),'new_owner':str(N),'tree':str(T),'failed_run':str(RUN),'failed_admission':'61759727b2944475ba2544bd238337a0','failure_evidence':str(F/'completion-evidence.json'),'output_manifest':str(F/'output-manifest.json'),'output_manifest_sha256':'cd41204c2267985bf843457aca3d1b65c6e652e46de7898e2cd9d2d33f9ef66e','files':rows})
for name in ['verify-installed.py','verify-source.py','proxy-source-proof.json','dolphin-sys-source-manifest.json','acceptance/verify-firmware.py']:
 src=O/name;dst=P/'templates'/name;old=src.read_text();new=old.replace(str(O),str(N))
 if name=='acceptance/verify-firmware.py':
  needle="               source_unchanged=True, independent_bundle_inodes=True)"
  assert needle in new
  new=new.replace(needle,"               source_unchanged=True, independent_bundle_inodes=True,\n               producer_combined_run_returncode=1, producer_failed_run='/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04/.build-runs/20261015T060011Z-92b2fe8b',\n               qualification_scope='Independent artifact acceptance after consumed original post-build reader failure; no successful combined producer claim')")
 dst.write_text(new)
 if old!=new:(P/(name.replace('/','-')+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original-owner02/'+name,tofile='fresh-reader/'+name)))
# Additive pending SM packet: preserve prior generation in full; no executable mutation of its sealed source.
oldsm=Path('/tmp/pix-m7-h700-launch-review-20261015/sm8550');sm=P/'sm8550';shutil.copytree(oldsm,sm)
shutil.copy2(oldsm/'SHA256SUMS',sm/'previous-gateway-packet-SHA256SUMS')
shutil.copy2(oldsm/'CURRENT-SOURCE-REVIEW.json',sm/'previous-gateway-source-review.json')
shutil.copy2(oldsm/'README.md',sm/'README-gateway-derivative.md')
shutil.copy2(P/'templates/verify-additions.py',sm/'verify-additions.py')
text=(sm/'commands.sh').read_text().replace(str(oldsm),str(sm)).replace(str(O)+'/acceptance/artifacts/acceptance.json',str(N)+'/acceptance/artifacts/acceptance.json')
(sm/'commands.sh').write_text(text)
for name in ['verify-additions.py','commands.sh']:
 old=(oldsm/name).read_text();new=(sm/name).read_text();(P/('sm8550-'+name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='sealed-gateway-packet/'+name,tofile='fresh-profile-reader-packet/'+name)))

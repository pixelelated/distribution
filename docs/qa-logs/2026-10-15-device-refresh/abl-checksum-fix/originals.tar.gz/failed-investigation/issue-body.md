Parent #555 / #344, M7.P5. Found during the authorized continuation: “Please keep working.”

SM8550 run20261015T072058Z-efba76e3 stopped at07:23:39UTC with original command/monitor/runner2/0/2 and launcher2. ARM completed; AArch64 installation rejected rocknix-abl1.2 before assembling an accepted image. The source and fallback mirror both delivered1,411,543bytes with SHA25664034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7, while frozen f863 expects4fcf983aff6af152fb5d7d0ef1a31727d64ecb93b2d75e202efeea5c5d4b565d. The checksum guard correctly refused. Actual launcher/runner/watcher have exited and the exact container is absent.

Upstream already corrected this one field in [15123b29517ad92be1f6cbcc3924a92705887d12](https://github.com/ROCKNIX/distribution/commit/15123b29517ad92be1f6cbcc3924a92705887d12). Local Git bytes confirm the only change is the expected checksum, matching the observed downloads; version, URL and packaging stay unchanged. Current official asset metadata/history must be retained before applying it. No checksum bypass, unexplained version change or bootloader deployment is authorized by this issue.

Can this be done on the VM? The immediate defect is host download/recipe integrity and is directly verified with the exact upstream change, official asset digest, local archive bytes, pkgcheck and the normal SM8550 build/artifact reader. No target execution or physical action is needed to fix that gate. The resulting changed bootloader payload still needs its existing target-specific raw/update/ABL equality and later named physical boot/smoke; no VM result substitutes for those facts.

Scope/depth: bounded Local Issue review of the exact upstream checksum correction and its source provenance. The completed f863 cross-lab audit and accepted H700/VM results remain immutable, with their original source identities. Any new SM source freeze and inherited-proof scope must be explicitly compared before build. No new independent cross-lab audit is claimed.

Acceptance criteria:

- [ ] Preserve original failed channels, owner/container exit evidence and ordinary failed-investigated consumption; keep all prior cache results and no successful build claim.
- [ ] Retain official correction, release/asset metadata and exact local archive digest/member evidence; establish whether a replacement is evidenced and distinguish unrelated current upstream changes.
- [ ] Apply only the verified upstream checksum correction; pkgcheck and finite diff/source review pass with unchanged version, URL, packaged files and checksum enforcement.
- [ ] Publish the correction and freeze a new reviewed SM source/owner; explain the exact delta from accepted VM/H700, preserve original failed source/results and bind cache provenance/resources before retry.
- [ ] Complete normal SM8550 build and independent raw/update/GPT/five-ABL/FEX/selected-state acceptance with original results and consumed receipts; update #555/#528/M7 and readiness records.

Upstream contribution: this specific fix already exists upstream, so no duplicate submission is needed. Newly observed openabl work is a separate upstream-intake consideration, not automatically part of this recovery. Public RC, physical deployment and #528 publication holds remain separate.

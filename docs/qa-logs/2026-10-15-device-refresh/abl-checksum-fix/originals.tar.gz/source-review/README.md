# ABL 1.2 checksum failure: source-only investigation

The minimum fix is the existing upstream commit
[15123b29517ad92be1f6cbcc3924a92705887d12](https://github.com/ROCKNIX/distribution/commit/15123b29517ad92be1f6cbcc3924a92705887d12):
change only `PKG_SHA256` from
`4fcf983aff6af152fb5d7d0ef1a31727d64ecb93b2d75e202efeea5c5d4b565d`
to `64034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7`.
The retained upstream recipe is byte-identical to frozen f863 after exactly
that replacement. Version 1.2, URL and packaging remain the same. No product
file was edited; `upstream-fix.patch` retains the original upstream change.

The stopped SM8550 run `20261015T072058Z-efba76e3` has original command/monitor/
runner 2/0/2 and launcher 2. Its log records both primary and distribution-sources
mirror returning 1,411,543 bytes with the new hash. Original channel receipts,
full-log hash/locator and selected exact lines are retained. Nothing here
consumes or qualifies that failed run.

## Official metadata and history

The [v1.2 release](https://github.com/ROCKNIX/abl/releases/tag/v1.2) API read at
2026-10-15 07:27:27 UTC identifies asset 603983682, size 1,411,543 and digest
`sha256:64034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7`.
It reports asset creation/update at 2026-10-01 19:31:31/32 UTC and release
publication at 19:31:32. Release notes name LinuxLoader
`e9d37131c0c2273076468156fb0f87aa6834202b` and build 2026-10-01 19:31 UTC.

The old hash entered the recipe with b354bfe6 on September 30 at 23:20:18 UTC;
upstream corrected it on October 1 at 19:46:17 UTC. The correction is present
in local Git objects but is not an ancestor of frozen f863. This establishes
an omitted, already-existing checksum fix. Current API metadata cannot prove
whether an earlier asset was replaced or the first recipe hash was wrong;
there is no retained original 4fcf asset or its historical asset metadata.
There is no evidence here of a new replacement on October 15.

Current upstream has since [replaced rocknix-abl with OpenABL](https://github.com/ROCKNIX/distribution/commit/71d8932b3374d2a9e04fbc200b5779394a57dae2),
commit 71d8932b on October 14 at 21:48:39 UTC. The old path now returns 404;
the retained commit shows it removed with the corrected checksum. That change
touches device options, updater and bootloader assembly as well as package
paths. It is a separate integration decision, not part of the one-line repair.

## Exact five-file provenance and its limit

`five-file-provenance.json` contains the four support-file source hashes and
expected installed hashes: README, backup_abl.sh and restore_backup_abl.sh are
copied unchanged; flash_abl.sh substitutes `%DEVICE%` with `SM8550` in the
tracked template. The fifth member, abl_signed-SM8550.elf, is copied from the
release archive. Its individual bytes/hash have **not** been observed here.

The public [release workflow](https://github.com/ROCKNIX/abl/blob/0e755e154874f7e874919ab7e080935c1444df68/.github/workflows/release-abl.yaml)
checks out ROCKNIX/LinuxLoader using a deploy key, runs make_abl.sh and packages
signed ELF files with companion SHA256 files. The exact LinuxLoader commit
API lookup returned 404 on this unauthenticated read. The public packaging
repository and release notes do not supply that implementation's source,
dependencies or applicable notices. Existing #528 custody holds remain open.

The next root-allocated data-only check can bind the existing downloaded
archive against the official digest/size, inspect its bounded member list and
read only the SM8550 ELF plus companion checksum. Preserve member names/types/
modes and actual ELF hash; do not execute its code or scripts. Then retain the
existing five-file source→unpacked→staged→SYSTEM/update/raw equality checks.
No archive was fetched, opened or unpacked during this investigation.

## Upstream contribution and follow-up

No duplicate checksum PR is needed: upstream already fixed the exact defect.
Record this as reuse of the existing fix in the running contribution queue.
The current OpenABL replacement is a separate upstream integration/source
custody follow-up; this investigation neither requests a migration nor clears
its provenance. No upstream submission or issue mutation occurred.

Final-inventory packet 485b9937 remains immutable. Its exact f863 binding will
need a reviewed additive revision after any committed product-source change;
do not substitute a predicted commit or relabel prior accepted images.

## Custody and outcomes

`metadata/http-observations*.json` retain exact URLs, status codes, timestamps,
headers, byte counts and hashes for eleven bounded official metadata/source
requests. The initial sandboxed gh request failed before receiving metadata;
its empty output is preserved and distinguished in execution-observation.json.
Tracked Git source, stopped-run original records and public metadata alone were
read. No build, collector, cache scan, service, product edit or shared-record edit
was performed. Root owns implementation, retry and failed-run consumption.

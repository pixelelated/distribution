set(CMAKE_HOST_SYSTEM "Linux-7.0.0-38-generic")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.0.0-38-generic")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/etc/cmake-x86_64-rocknix-linux-gnu.conf")

set(CMAKE_SYSTEM "Linux-1")
set(CMAKE_SYSTEM_NAME "Linux")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "x86_64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)

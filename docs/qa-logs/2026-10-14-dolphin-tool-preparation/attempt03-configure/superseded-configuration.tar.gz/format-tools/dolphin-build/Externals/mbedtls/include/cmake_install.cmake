# Install script for directory: /work/format-tools/dolphin-src/Externals/mbedtls/include

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "TRUE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/bin/x86_64-rocknix-linux-gnu-objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/mbedtls" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/aes.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/aesni.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/arc4.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/aria.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/asn1.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/asn1write.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/base64.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/bignum.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/blowfish.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/bn_mul.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/camellia.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ccm.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/certs.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/chacha20.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/chachapoly.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/check_config.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/cipher.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/cipher_internal.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/cmac.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/compat-1.3.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/config.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/config_psa.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/constant_time.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ctr_drbg.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/debug.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/des.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/dhm.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ecdh.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ecdsa.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ecjpake.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ecp.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ecp_internal.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/entropy.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/entropy_poll.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/error.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/gcm.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/havege.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/hkdf.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/hmac_drbg.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/md.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/md2.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/md4.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/md5.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/md_internal.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/memory_buffer_alloc.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/net.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/net_sockets.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/nist_kw.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/oid.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/padlock.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/pem.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/pk.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/pk_internal.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/pkcs11.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/pkcs12.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/pkcs5.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/platform.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/platform_time.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/platform_util.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/poly1305.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/psa_util.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ripemd160.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/rsa.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/rsa_internal.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/sha1.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/sha256.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/sha512.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ssl.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ssl_cache.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ssl_ciphersuites.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ssl_cookie.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ssl_internal.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/ssl_ticket.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/threading.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/timing.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/version.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/x509.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/x509_crl.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/x509_crt.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/x509_csr.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/mbedtls/xtea.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/psa" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_builtin_composites.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_builtin_primitives.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_compat.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_config.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_driver_common.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_driver_contexts_composites.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_driver_contexts_primitives.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_extra.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_platform.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_se_driver.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_sizes.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_struct.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_types.h"
    "/work/format-tools/dolphin-src/Externals/mbedtls/include/psa/crypto_values.h"
    )
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/work/format-tools/dolphin-build/Externals/mbedtls/include/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()

# Exact077197 ZeroTier VM packet03 — source only, unrun

Two minimal derivatives of the accepted final-composition lifecycle. This
packet has not run a preparer, VM, guest probe, source interpreter, test or
process/disk census. Root reviews and serially allocates each owner. The released
planning packet remains unchanged.

The actual accepted reader02 is bound by four exact original receipts in
`artifact-bindings.json`, including consumed admission
`ee024372b00f4314afa9fc96495b83de`, original run `20261015T163127Z-5682551e`.
New source is `077197e6cd3ea31f33b28aaf3882a694b3423b53`; ES remains
`16dbac5211eea7e70db7394372033be2be7df829`. Install image SHA256
`c5de01b869c5bb28966ab5d654b95a8ed36581c38b380ed885a5946489009932`,
2,122,152,460 bytes; update SHA256
`f2acfc239fd072dddfef08bec8444d149128272ba3d5b5f2ae5d6ff84890b0b6`,
2,123,141,120 bytes. SYSTEM SHA256
`8054e2fcaeab0603a050a477f59931ad354f0269de93145dd447c1f0d34e9817`.
Installed ZeroTier is 1,790,424 bytes, SHA256
`dffd15beeaa3be13ea6f5a697b633922ddb7b9566e3130f0b9bf61f5d9cdfb8f`.
The result also binds both CLI aliases, unit and join script. Artifact bytes
were not reread during this source preparation.

Fresh uses the unchanged no-NIC boot and untouched selected-state gate before
creating synthetic ZeroTier state. Retained uses the existing independent d6a
disk, protected backing/OVMF, disposable overlay, read-only media, ordinary tar
update and eight-file retained-state comparator. Its old ZeroTier executable is
recorded from the actual accepted old guest, not guessed from source equality.
The entire old ZeroTier package subtree is identical between d6a and f863.
This is d6a→077197, not f863→077197; no backing-chain guard is weakened.

`guest.py` runs the actual installed unit and local CLI. Each phase refuses an
already active daemon; initial phases refuse pre-existing ZeroTier state except
an empty regular directory. The explicit synthetic fixture is `{}` local.conf
and an empty network list. No join/leave command is requested by the probe; no provider/account, network device,
product overlay or altered service executable is introduced. ExecStartPost is
the installed join script; empty membership makes it issue no join/leave target.
The service's actual executable hash, argv, PID/start identity, status and
restart count are checked. CLI version/info/listnetworks require1.16.0,
online=false and zero networks. Fresh/new service is restarted once and stopped;
old service is initialized, queried and stopped before the real update.

Six selected daemon files retain exact bytes, presence, modes and ownership:
identity.secret, identity.public, authtoken.secret, metricstoken.secret,
local.conf and zerotier-networks. networks.d may be absent or an empty real
directory; exact presence and, when present, mode/ownership are also retained
and compared across restart/stop and the ordinary update. Mutable port/cache
files are outside this comparison. The private before record survives the
ordinary update on storage, is compared before the new daemon starts and after
start/restart/stop, then removed. Secret bytes never leave the guest. The
existing eight unrelated selected files are also compared around every probe;
the original retained comparator/receipts remain unchanged.

Raw CLI outputs may contain the synthetic node address. They and the raw
ZeroTier serial streams stay under the private owner; `close.py` records their
hashes/locations but excludes their bytes from its compact archive. Sanitized
reports retain exact command argv/status/timeouts, public installed hashes,
service outcomes and state-equality booleans. Original service exit code/signal
are recorded as observed; transport zero is never substituted for guest zero.
On failure, original partial rows and private snapshots remain; no automatic
retry or successful-consumption claim follows.

Changes are limited to exact reader acceptance/pins, replacing the unrelated
loader phase with ZeroTier, adding the old-daemon phase before retained update,
and adapting export predicates/private exclusions. `census.py` in each variant
and retained `state.py` are byte-identical to their accepted sources. The
source references and unified diffs make the changes reviewable. A redundant
top-level guest.py is the exact source of both variant copies.

Existing full lifecycle bounds remain: one4CPU/8GiB/no-NIC guest,16GiB disk,
fresh1800s+90s cleanup and retained4200s+180s. Original owner observation caps
64MiB/4096 host files,8MiB per command stream; these are sampled output limits,
not a new cgroup/filesystem quota. Added guest work alarm140s, cleanup25s and at
most two final5s child waits fit the180s phase allowance; serial195s/host210s.
At most32 children per phase,30s service/10s other child deadlines,64KiB per
stream and256KiB total captured child bytes enforced before buffer append;
private encoded command record≤512KiB, public report≤128KiB, combined emitted
records≤1MiB. Private comparison write≤1MiB, each selected daemon file≤64KiB.
These limits accommodate the small local API/status replies and state files.
Any timeout or forced cleanup fails the phase. Only exact startup responses from readiness attempts may be nonzero before a required successful local API response; every original exit is preserved. All other nonzero child outcomes fail.

Capacity remains fresh32GiB raw+disk and128MiB records; retained16GiB overlay,
2,257,584,128-byte input medium and128MiB records/UEFI. Guest update free-space
floor5,320,024,064 bytes. Root checks live owner/reference/capacity/port facts
during preparation/admission; no such live fact is asserted here. Protected
base/OVMF are checked before and after actual execution. Stop remains the
qualified exact pidfile/disk and process-identity cleanup.

Can this be done on the VM? Yes; root records local lifecycle/retained-config
scope in #528 before execution. This does not qualify membership, routing,
controller/provider, hardware, other ABI runtime, source publication or an RC.
Unchanged component matrices retain their accepted evidence and final artifact
continuity; no full matrix or compiler replay is added.

## Narrow correction from immutable packet01

Packet01 remains sealed55320670 and UNRUN. Both current coordinator and frozen
077197 carry checker65ab515e and generator6e0b2eb9; packet01 inherited stale
6d061af8/ce309daf literals. Packet02 binds the accepted current bytes in both
variants. The #599 delta is limited to PPSSPP INI grammar and account keys; the
retained comparator's default pairs/xml/Check/Local usage remains compatible.
The generator's prepare_guest function is byte-identical, and the serial tool
and first-boot adapter are unchanged. No historical checker semantics are needed.

Exact upstream CLI source has no startup retry: missing port/token exits2; a
failed loopback connection exits1. The installed ExecStartPost always ends
exit0, so it does not establish readiness. Packet02 adds at most8 status attempts
over30s per daemon start/restart, each at most3s, with exact original outputs
and statuses retained privately. Only those named missing-port/token or local
connection-startup responses are accepted as transient; unexpected replies,
malformed success JSON, a changed/disappeared daemon, timeout or missing final
success fail. Original nonzero attempts are marked accepted_starting_state,
never rewritten to zero. Offline status is required; ONLINE is never awaited.
No additional cap, VM owner or product change is introduced. The guest state
path variable is ZT_HOME, leaving the HOME environment untouched.

## Narrow correction from consumed packet02 fresh failure

Packet02 remains sealed fb970d76. Its fresh run165025Z-aed92d8e failed1/0/1
only after the untouched clean gate, readiness and zero-membership CLI queries
passed. The original result stays failed and consumed5a8da1a9fe9f4c23acd0b5d928801513;
all original channels and clean closure remain bound by failure-bindings.json.
The failed owner's guest and raw/private originals are preserved.

The old predicate incorrectly required networks.d to exist. Exact OneService
startup lists this directory without creating it; OSUtils returns an empty list
when opendir fails. OneService creates the directory when it needs to persist a
network-config object. The empty no-join fixture therefore permits absence.
The correction accepts absence only when lstat raises FileNotFoundError, or a
real nonsymlink empty directory. Any other type, symlink, member, read error or
concurrent metadata change still fails. The stable snapshot now also records
presence and directory mode/uid/gid, so a creation/removal or metadata change
across restart/stop/update cannot be normalized away. Inode and timestamps are
checked only for coherence during the observation, not across an OS update.
A public boolean records observed presence; private comparison bytes stay guest.

Only the three identical guest.py copies change executable logic. All preparers,
lifecycles, exporters, census/state tools, current checker pins, child/time/space
bounds and cleanup policies are byte-identical to02. Source03 is unrun. Commands
use fresh owner02 and the still-unrun retained owner01. No resource envelope,
new guard framework, product patch or membership/provider claim is added.

from pathlib import Path
import hashlib,json,subprocess,sys,os
kind,stage=sys.argv[1:];assert kind in ['fresh','retained']
P=Path('/tmp/pix-m7-zerotier-vm-proof-20261015-03');T=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03');C=Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
name='clean' if kind=='fresh' else 'retained'
suffix='02' if kind=='fresh' else '01'
O=Path('/workspace/tmp/pix-m7-zt-'+name+'-20261015-'+suffix);E=Path('/workspace/tmp/pix-m7-zt-'+name+'-evidence-20261015-'+suffix)
R=Path('/tmp/pix-m7-zt-'+name+'-coordinator-20261015-03');R.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'SHA256SUMS')=='45965fa05b467d77a14b0375a9b5ee592b24b3d92d14718e04e6d63c3ce60e33'
for ln in (P/'SHA256SUMS').read_text().splitlines():h,n=ln.split('  ',1);assert sha(P/n)==h,n
if stage=='prepare':
 cmd=['python3','-I','-B',str(P/kind/'prepare.py'),'--checkout',str(T),'--verification','/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-02/artifacts/result.json','--owner',str(O),'--vnc','151' if kind=='fresh' else '152']
 if kind=='fresh':cmd+=['--clean-checkout',str(C)]
 else:cmd+=['--retained-owner','/workspace/tmp/pix-m7-retained20-20261014-02','--retained-evidence','/workspace/tmp/pix-m7-retained20-evidence-20261014-02','--state-checker',str(C/'tools/pixelelated-state-check'),'--state-checker-sha256','65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6']
elif stage=='preflight':cmd=['tools/build-preflight']
elif stage=='report':cmd=['tools/watch-build','--record-only','--','python3','-I','tools/host-maintenance/retention-report','--plan',str(O/'retention-plan.json'),'--output',str(O/'retention-report.json')]
elif stage=='admit':cmd=['python3','-I','tools/host-maintenance/build-admission','prepare','--plan',str(O/'admission-plan.json'),'--output',str(O/'admission.json')]
elif stage=='launch':cmd=['tools/watch-build-submit','--owner',str(O/'lifecycle-owner'),'--','--admission',str(O/'admission.json'),'--activity-dir',str(O),'--recursive-activity','--','python3','-I','-B',str(O/'vm-lifecycle.py')]
elif stage=='close':cmd=['python3','-I','-B',str(O/'close.py'),'--owner',str(O),'--run',(O/'run.path').read_text().strip(),'--output',str(E)]
elif stage=='consume':cmd=['python3','-I','tools/host-maintenance/build-admission','consume','--run',(O/'run.path').read_text().strip(),'--evidence',str(E/'consumption-draft.json')]
else:raise ValueError(stage)
env=os.environ.copy();env.update(PROJECT='ROCKNIX',DEVICE='GENERIC_X64',ARCH='x86_64')
with (R/(stage+'.stdout')).open('xb') as out,(R/(stage+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=T,env=env,stdout=out,stderr=err)
with (R/(stage+'.exit.json')).open('x') as f:json.dump({'original_tool_exit':p.returncode,'argv':cmd},f)
print(json.dumps({'stage':stage,'original_tool_exit':p.returncode,'stdout':str(R/(stage+'.stdout'))}));sys.exit(p.returncode)

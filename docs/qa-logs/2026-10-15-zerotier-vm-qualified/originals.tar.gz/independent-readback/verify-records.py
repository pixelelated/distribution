from pathlib import Path,PurePosixPath
import datetime,hashlib,json,tarfile
OUT=Path(__file__).parent;P=Path('/tmp/pix-m7-zerotier-vm-proof-20261015-03');BASE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03/.build-runs')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
assert h(P/'SHA256SUMS')=='45965fa05b467d77a14b0375a9b5ee592b24b3d92d14718e04e6d63c3ce60e33'
for line in (P/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1);assert h(P/name)==expected
summaries=[]
for kind,suffix,runid,admission,phases,count,bytecount,privatecount in [('clean','02','20261015T165555Z-01fa0035','ba8e501430e642dba2a20a32882cc51b',['fresh'],79,397119,3),('retained','01','20261015T165733Z-1a993904','41b09d12d60f423d98f6188a6538daab',['before','after'],136,672463,6)]:
 E=Path('/workspace/tmp/pix-m7-zt-'+kind+'-evidence-20261015-'+suffix);R=BASE/runid;co=Path('/tmp/pix-m7-zt-'+kind+'-coordinator-20261015-03')
 export=j(E/'export-result.json');rows=j(E/'original-records.json');private=j(E/'private-originals-held.json');draft=j(E/'consumption-draft.json');rr=j(R/'runner-result.json');cons=j(R/'admission-consumed.json');vm=j(E/'vm-result.json');host=j(E/'host-exits.json');cfg=j(E/'config.json')
 assert export['original_channels']=={k:0 for k in ['launcher','tool_wrapper','build','command','monitor','runner','vm']} and export['original_rc']==0
 assert export['files']==len(rows)==count and export['bytes']==sum(x['bytes'] for x in rows)==bytecount and export['private_originals_held']==len(private['files'])==privatecount
 assert export['private_settings_or_account_values_exported'] is False and export['acceptance_claimed'] is False
 assert (rr['command_rc'],rr['monitor_rc'],rr['runner_rc'])==(0,0,0) and cons['original_result']==rr and cons['state']=='consumed' and cons['id']==admission and cons['pid_namespace']==4026531836
 assert cons['evidence_sha256']==h(E/'consumption-draft.json') and draft['run']==str(R) and draft['disposition']=='qualified' and draft['expected_rc']==0
 assert cfg['commit']==cons['source']['head']=='077197e6cd3ea31f33b28aaf3882a694b3423b53'
 for e in draft['evidence']:assert Path(e['path']).parent==E and h(e['path'])==e['sha256']
 assert vm['rc']==0 and not vm.get('error') and all(not vm[k] for k in ['cleanup_errors','forced_host_cleanup','remaining_host_children','surviving_host_processes','qemu_still_live'])
 assert all(x['original_returncode']==0 and not x['timed_out'] for x in vm['commands'])
 assert host['status']=='OWNERS_GONE' and host['channels_coherent'] and host['host_pid_namespace']==4026531836 and host['original_channels']==export['original_channels']
 for x in private['files']:
  p=PurePosixPath(x['path']);assert 'private' in p.parts or ('-zerotier-' in p.name and p.suffix in ['.stdout','.stderr'])
 nested=[];phase_rows=[];additional={}
 with tarfile.open(E/'original-records.tar.gz') as tf:
  members=tf.getmembers();assert len(members)==count and len({m.name for m in members})==count and {m.name for m in members}=={x['path'] for x in rows}
  for row in rows:
   m=tf.getmember(row['path']);p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and 'private' not in p.parts
   assert not ('-zerotier-' in p.name and p.suffix in ['.stdout','.stderr'])
   data=tf.extractfile(m).read();assert len(data)==row['bytes']==m.size and hashlib.sha256(data).hexdigest()==row['sha256']
   nested.append({'member':m.name,'bytes':m.size,'sha256':row['sha256'],'mode':m.mode,'uid':m.uid,'gid':m.gid,'pax_headers':m.pax_headers,'header_mtime':m.mtime})
   if m.name.startswith('run/'):assert h(R/p.relative_to('run'))==row['sha256']
  assert tf.extractfile('owner/guest.py').read()==(P/('fresh' if kind=='clean' else 'retained')/'guest.py').read_bytes()
  for phase in phases:
   probe=json.loads(tf.extractfile('owner/records/zerotier-'+phase+'.json').read());ex=json.loads(tf.extractfile('owner/records/zerotier-'+phase+'-exit.json').read())
   assert probe['status']=='PASS' and probe['phase']==phase and ex['reported_statuses']==['0'] and ex['transport_returncode']==0
   assert probe['daemon_stopped'] and probe['stable_state_equal'] and probe['selected_state_equal'] and not probe['cleanup_errors'] and not probe['remaining_daemon_identities'] and probe['network_directory_present'] is False
   assert all(not x['timed_out'] and not x['output_limit'] and (x['original_returncode']==0 or x.get('accepted_starting_state')) for x in probe['commands'])
   cli_count=1 if phase=='before' else 2
   assert probe['cli_checks']==[{'version':'1.16.0','online':False,'network_count':0}]*cli_count
   if phase in ['fresh','after']:assert probe['restart_pass']
   if phase=='before':assert probe['retained_snapshot_created']
   if phase=='after':assert probe['retained_before_start_equal'] and probe['retained_snapshot_removed']
   phase_rows.append({k:v for k,v in probe.items() if k not in ['commands','service_observations','members_before','daemon_identities']})
  if kind=='clean':
   clean=json.loads(tf.extractfile('owner/clean/report.json').read());assert clean['status']=='pass' and clean['mode']=='first-boot' and clean['blocked_count']==clean['error_count']==0
   assert any(x.get('category')=='boot-ready' and x.get('status')=='clear' and x.get('present') is True for x in clean['checks'])
   additional={'clean':{k:clean[k] for k in ['status','mode','blocked_count','error_count']}}
  else:
   before=json.loads(tf.extractfile('owner/records/base-before.json').read());after=json.loads(tf.extractfile('owner/records/base-after.json').read());state0=json.loads(tf.extractfile('owner/records/state-before.json').read());state1=json.loads(tf.extractfile('owner/records/state-after.json').read())
   assert before==after and vm['base_unchanged'] and before['sha256']=='cfa55b79c36dd6b7fa1186c2e32cacc8b5e253f749f64effb4ec61ff273e488d'
   assert cfg['previous_commit']=='d6a87f05c1935516115b2cca1af22151a0209224'
   assert state0['status']==state1['status']=='PASS' and state1['changed_selected_paths']==[] and all(state1['checks'].values())
   assert state0['boot_id']==state1['previous_boot_id'] and state0['boot_id']!=state1['boot_id']
   for phase in ['before','after']:
    x=json.loads(tf.extractfile('owner/records/state-'+phase+'-exit.json').read());assert x['reported_statuses']==['0'] and x['transport_returncode']==0
   additional={'base_original_before_and_after':before,'state_after':state1,'previous_commit':cfg['previous_commit']}
 for stage in ['prepare','preflight','report','admit','launch','close','consume']:assert j(co/(stage+'.exit.json'))['original_tool_exit']==0
 report=Path((co/'report.stderr').read_text().strip().removeprefix('watch-build: recording in '));rresult=j(report/'runner-result.json');assert (rresult['command_rc'],rresult['monitor_rc'],rresult['runner_rc'])==(0,0,0)
 summaries.append({'kind':kind,'run':str(R),'original_result':rr,'consumed_id':admission,'consumed_utc':cons['consumed'],'consumed_sha256':h(R/'admission-consumed.json'),'nested_export_sha256':h(E/'original-records.tar.gz'),'nested_members':nested,'private_originals_hash_only':privatecount,'phases':phase_rows,'additional_original_scope':additional,'retention_report_run':str(report),'retention_report_result':rresult})
receipt={'status':'PASS_SANITIZED_CLEAN_AND_RETAINED_ORIGINALS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_seal':h(P/'SHA256SUMS'),'runs':summaries,'nested_members_verified':215,'private_original_bodies_read':0,'image_or_disk_bodies_read':0,'new_runtime_or_process_census':False,'scope':'Original accepted isolated GENERIC fresh and retained state/service/CLI scope only; no join, external network, physical/ARM or publication claim.'}
(OUT/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'nested_members_verified':215,'private_original_bodies_read':0,'receipt_sha256':h(OUT/'record-readback.json')}))

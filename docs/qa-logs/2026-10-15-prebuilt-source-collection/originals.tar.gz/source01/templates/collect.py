#!/usr/bin/env python3
"""Read two exact public rclone release archives as data; never extract or execute."""
from pathlib import Path,PurePosixPath
import datetime,gzip,hashlib,json,os,re,resource,stat,subprocess,sys,tarfile,time
O=Path(__file__).resolve().parent
start=time.monotonic();read_bytes=0;retained_bytes=0
rows=[];archives=[];downloads=[];gaps=[];selected={};rc=1;error=None

def put(p,obj):
    with p.open('x') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
def identity(p):
    assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),p
    s=p.stat();assert stat.S_ISREG(s.st_mode),p
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def budget(n):
    global read_bytes
    read_bytes+=n
    assert read_bytes<=2*1024**3 and time.monotonic()-start<580,'named read/time bound'
def digest(p,cap):
    before=identity(p);assert before['bytes']<=cap
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):budget(len(b));h.update(b)
    assert identity(p)==before,'input changed'
    return dict(before,sha256=h.hexdigest())
def safe(name):
    p=PurePosixPath(name)
    assert name and len(name)<=4096 and not p.is_absolute() and '..' not in p.parts and '\\' not in name and '\0' not in name
    assert str(p)==name.rstrip('/'),'noncanonical member'
    return name.rstrip('/')
class Decoded:
    def __init__(self,f):self.f=f;self.n=0
    def read(self,n=-1):
        assert n>=0,'bounded read required'
        b=self.f.read(n);self.n+=len(b);budget(len(b))
        assert self.n<=512*1024**2,'decoded archive bound'
        return b

def read_archive(spec,want,retain,index_name):
    global retained_bytes
    path=O/'archives'/spec['name'];before=digest(path,40*1024**2)
    assert before['bytes']==spec['bytes'] and before['sha256']==spec['sha256']
    seen=set();index=[];got={};declared=0
    with path.open('rb') as raw,gzip.GzipFile(fileobj=raw,mode='rb') as gz:
        decoded=Decoded(gz)
        with tarfile.open(fileobj=decoded,mode='r|') as tar:
            for m in tar:
                n=safe(m.name);assert n not in seen,'duplicate archive member';seen.add(n)
                assert len(seen)<=65536 and m.size>=0
                declared+=m.size;assert declared<=512*1024**2
                budget(0)
                index.append(dict(name=n,bytes=m.size,mode=m.mode,type=m.type.decode('ascii','backslashreplace'),linkname=m.linkname))
                if not want(n):continue
                if not m.isfile() or m.issparse():
                    gaps.append(dict(archive=spec['name'],member=n,gap='selected member not a nonsparse regular file'));continue
                if m.size>2*1024**2:
                    gaps.append(dict(archive=spec['name'],member=n,bytes=m.size,gap='selected text exceeds fixed2MiB ceiling'));continue
                f=tar.extractfile(m);data=f.read(m.size+1);assert len(data)==m.size;budget(len(data))
                entry=dict(archive=spec['name'],member=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob_sha1=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),mode=m.mode,uid=m.uid,gid=m.gid,mtime=str(m.pax_headers.get('mtime',m.mtime)))
                if retain:
                    key=spec['name']+':'+n
                    if key not in selected:
                        assert len(selected)<4096
                        retained_bytes+=len(data);assert retained_bytes<=32*1024**2
                        dest=O/'collection/texts'/(hashlib.sha256(key.encode()).hexdigest()+'.txt')
                        with dest.open('xb') as out:out.write(data)
                        entry['retained_path']=str(dest);selected[key]=entry
                got[n]=(entry,data)
        # Read remainder so truncated/trailing gzip data is detected inside the bound.
        while decoded.read(1024**2):pass
    assert digest(path,40*1024**2)==before,'archive changed while read'
    if index_name:put(O/'collection'/index_name,index)
    return got,dict(archive=before,member_count=len(seen),declared_bytes=declared,decoded_bytes=decoded.n)

def download(spec,curl):
    path=O/'archives'/spec['name'];assert not path.exists()
    before=digest(Path(curl['path']),16*1024**2);assert before==curl['identity']
    argv=[curl['path'],'-q','--fail','--location','--proto','=https','--proto-redir','=https','--max-redirs','5','--connect-timeout','10','--max-time','60','--max-filesize',str(spec['bytes']),'--retry','0','--silent','--show-error','--output',str(path),spec['url']]
    assert spec['url']=='https://github.com/rclone/rclone/releases/download/v1.75.2/'+spec['name']
    stdout=O/'collection'/(spec['name']+'.curl.stdout');stderr=O/'collection'/(spec['name']+'.curl.stderr')
    row=dict(name=spec['name'],canonical_url=spec['url'],argv=argv,original_curl_returncode=None,wait_observed=False)
    downloads.append(row)
    with stdout.open('xb') as so,stderr.open('xb') as se:
        # The qualified outer subreaper owns interruption cleanup; never invent a missing wait.
        p=subprocess.run(argv,stdout=so,stderr=se,cwd=O/'archives',env={'PATH':'/usr/bin:/bin','HOME':str(O/'empty-home'),'LC_ALL':'C'},preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(spec['bytes'],spec['bytes'])))
    row.update(original_curl_returncode=p.returncode,wait_observed=True)
    put(O/'collection'/(spec['name']+'.curl.wait.json'),row)
    row.update(stdout=digest(stdout,1024**2),stderr=digest(stderr,1024**2))
    assert type(p.returncode)is int and p.returncode==0,'original download failed'
    actual=digest(path,40*1024**2)
    assert actual['bytes']==spec['bytes'] and actual['sha256']==spec['sha256'],'release archive identity mismatch'
    assert digest(Path(curl['path']),16*1024**2)==before,'curl changed'
    return actual

def module_headers(data):
    result={};replacements=[]
    for line in data.decode('utf-8').splitlines():
        if not line.startswith('# '):continue
        fields=line[2:].split()
        if len(fields)>=2 and fields[1].startswith('v'):
            module,version=fields[:2];assert module not in result,'duplicate vendor module'
            result[module]=dict(version=version,replacement=fields[2:])
            if fields[2:]:replacements.append(line)
        elif '=>' in fields:replacements.append(line)
        else:raise ValueError('unrecognized vendor module header')
    return result,replacements

def notice(n):
    p=PurePosixPath(n)
    return bool(re.match(r'(?i)^(licen[cs]e|copying|notice|copyright|patents?|authors)(?:[._-].*)?$',p.name)) or any(x.lower() in ['licenses','licences'] for x in p.parts[:-1])
try:
    plan=json.loads((O/'collection-plan.json').read_text());tools=json.loads((O/'host-tools.json').read_text())
    assert len(plan['archives'])==2 and len(plan['selected_modules'])==242
    for name,h in plan['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    (O/'archives').mkdir(mode=0o700);(O/'collection').mkdir(mode=0o700);(O/'collection/texts').mkdir(mode=0o700);(O/'empty-home').mkdir(mode=0o700)
    for spec in plan['archives']:download(spec,tools['curl'])
    source,vendor=plan['archives'];prefix=plan['source_prefix']
    found,meta=read_archive(source,lambda n:n.startswith(prefix) and n[len(prefix):] in plan['source_members'],True,'source-member-index.json');archives.append(meta)
    for n,wanted in plan['source_members'].items():
        item=found.get(prefix+n)
        if item is None:gaps.append(dict(member=n,gap='declared source member unavailable'));continue
        assert item[0]['git_blob_sha1']==wanted['git_blob_sha1'] and item[0]['bytes']==wanted['bytes'],'source member differs from exact tag tree'
    assert all(prefix+n in found for n in ['COPYING','go.mod','go.sum']),'required top source missing'
    sums={tuple(line.split()) for line in found[prefix+'go.sum'][1].decode().splitlines()}
    assert all((m['module'],m['version'],m['go_h1']) in sums for m in plan['selected_modules']),'selected source checksum mismatch'
    first,meta=read_archive(vendor,lambda n:n=='vendor/modules.txt',True,'vendor-member-index.json');archives.append(meta)
    assert 'vendor/modules.txt' in first,'vendor module index absent'
    headers,replacements=module_headers(first['vendor/modules.txt'][1]);put(O/'collection/vendor-modules.json',dict(modules=headers,replacements=replacements))
    roots={m['module']:'vendor/'+m['module'] for m in plan['selected_modules']}
    def applicable(n,root):
        if n.startswith(root+'/'):
            owning=[('vendor/'+m) for m in headers if n.startswith('vendor/'+m+'/')]
            return max(owning,key=len,default=root)==root
        # Only direct notice siblings at each ancestor, never unrelated subtrees.
        return str(PurePosixPath(n).parent) in [str(p) for p in PurePosixPath(root).parents if str(p)!='.']
    texts,_=read_archive(vendor,lambda n:notice(n) and any(applicable(n,r) for r in roots.values()),True,None)
    for m in plan['selected_modules']:
        h=headers.get(m['module']);matches=h is not None and h['version']==m['version'] and not h['replacement'] and not any(line.split()[1]==m['module'] for line in replacements)
        refs=[entry for n,(entry,data) in texts.items() if applicable(n,roots[m['module']])]
        row=dict(selection=m,vendor_header=h,exact_selected_version=matches,notice_candidates=refs,license_clearance=False)
        if not matches:gaps.append(dict(module=m['module'],version=m['version'],gap='vendor version missing/different/replaced; selected embedded version remains authoritative'))
        if not refs:gaps.append(dict(module=m['module'],version=m['version'],gap='no notice candidate found within bounded filename/ancestor selection'))
        rows.append(row)
    put(O/'collection/selected-members.json',list(selected.values()))
    put(O/'collection/module-notice-map.json',rows)
    for spec in plan['archives']:
        assert digest(O/'archives'/spec['name'],40*1024**2)['sha256']==spec['sha256']
    for name,h in plan['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h
    gaps.append(dict(gap='Exact upstream dirty file list remains unknown; selected notice candidates are not license or publication clearance'))
    rc=0
except BaseException as exc:
    error=type(exc).__name__+': '+str(exc)
finally:
    # Preserve partial original downloads/member observations on all failures.
    if (O/'collection').exists() and not (O/'collection/selected-members.json').exists():put(O/'collection/selected-members.json',list(selected.values()))
    put(O/'collection-result.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),result='COLLECTED_WITH_EXPLICIT_GAPS' if rc==0 else 'COLLECTION_FAILED',original_collector_exit=rc,error=error,rows=rows,archives=archives,downloads=downloads,gaps=gaps,retained_member_bytes=retained_bytes,named_bytes_read=read_bytes,elapsed_seconds=time.monotonic()-start,target_execution=False,network_used=True,source_rebuild=False,dirty_file_list_reconstructed=False,independent_SYSTEM_relation_established=False,publication_clearance=False,outputs_held=True,deleted_bytes=0))
sys.exit(rc)

#!/usr/bin/env python3
"""Consume only original successful collection channels; gaps never become clearance."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent
B=runpy.run_path(str(O/'bindings.py'));B['verify'](O)
assert Path.cwd()==B['VM_TREE']
load,sha=B['load'],B['sha']
run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs'
B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
for f in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert f.read_text().strip()=='0',f
result,cleanup=load(O/'result.json'),load(O/'cleanup.json')
assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete'] is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established'] is False
assert result['execution_error'] is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json')
assert child['wait_observed'] is True and type(child['original_child_returncode']) is int and child['original_child_returncode']==0
assert child['qualification'] is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json')
assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit']) is int and report['original_collector_exit']==0
assert report['publication_clearance'] is False and report['independent_SYSTEM_relation_established'] is False
assert len(report['rows'])==242 and len(report['archives'])==2 and len(report['downloads'])==2
assert report['source_rebuild']is False and report['dirty_file_list_reconstructed']is False and report['network_used']is True
plan=load(O/'collection-plan.json')
assert [r['selection'] for r in report['rows']]==plan['selected_modules']
for spec,original,download in zip(plan['archives'],report['archives'],report['downloads']):
    p=O/'archives'/spec['name'];assert p.stat().st_size==spec['bytes'] and sha(p)==spec['sha256']
    assert original['archive']['path']==str(p) and original['archive']['sha256']==spec['sha256']
    assert type(download['original_curl_returncode'])is int and download['original_curl_returncode']==0 and download['wait_observed']is True
    wait=load(O/'collection'/(spec['name']+'.curl.wait.json'))
    assert wait['original_curl_returncode']==0 and type(wait['original_curl_returncode'])is int and wait['wait_observed']is True
    assert wait['argv']==download['argv'] and wait['canonical_url']==spec['url']
    for key in ['stdout','stderr']:
        p=Path(download[key]['path']);assert p.parent==O/'collection' and sha(p)==download[key]['sha256']
selected=load(O/'collection/selected-members.json')
assert 1<=len(selected)<=4096 and sum(r['bytes'] for r in selected)<=32*1024**2
for r in selected:
    p=Path(r['retained_path']);assert p.parent==O/'collection/texts' and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert cleanup['all_recorded_identities_absent'] is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped'] is False
# Same qualified final-inventory strict census and PID/start identity custody.
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']()
owned_keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']}
supervisor=cleanup['supervisor_identity'];assert supervisor is not None
owned_keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in owned_keys]
parents={r['pid'] for r in matching};descendants=[]
while parents:
    children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants]
    descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants,'recorded identity or owned descendant still present'
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[O/n for n in ['result.json','cleanup.json','collection-result.json','collection-plan.json','preparation.json','host-tools.json','seal.json','inner.rc','outer.rc','launcher-result.json','tool-wrapper.rc']]+[run/'runner-result.json',run/'build.rc']
files+=sorted(p for d in ['stage','collection'] for p in (O/d).rglob('*') if p.is_file())
files+=sorted(p for p in (O/'archives').iterdir() if p.is_file())
assert len(files)<=4200 and sum(p.stat().st_size for p in files)<=128*1024**2
out=O/'admission-completion-evidence.json'
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Only two exact rclone release archives and selected source/notice data collected. Missing/version-conflicting notices and unknown dirty source remain explicit; no source rebuild, independent SYSTEM, license or publication clearance. All prior producer dispositions unchanged.')
with out.open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed exact source collection; dirty-source/notice/publication gaps retained')

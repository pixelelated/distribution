from pathlib import Path
import hashlib,json,shutil,difflib
P=Path(__file__).resolve().parent
S=Path('/tmp/pix-m7-prebuilt-source-disposition-20261015')
R=Path('/tmp/pix-m7-prebuilt-strip-20261015-03')
def put(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inv=json.loads((S/'module-inventory.json').read_text())
groups=[g for g in inv['groups'].values() if g['module_records'][0]==['path','github.com/rclone/rclone']]
assert len(groups)==1
mods=[dict(module=r[1],version=r[2],go_h1=r[3]) for r in groups[0]['module_records'] if r[0]=='dep']
assert len(mods)==242 and not any(r[0]=='=>' for r in groups[0]['module_records'])
tree=json.loads((S/'upstream/rclone-tree.json').read_text());tree={r['path']:r for r in tree['tree']}
names=['COPYING','go.mod','go.sum','RELEASE.md','Makefile','bin/cross-compile.go','.github/workflows/build.yml','cmd/bisync/LICENSE.cjnaz','cmd/serve/dlna/LICENSE.anacrolix','fs/rc/js/LICENSE.wasmexec']
selected={n:dict(git_blob_sha1=tree[n]['sha'],bytes=tree[n]['size']) for n in names}
refs=[S/'module-inventory.json',S/'source-findings.json',S/'next-action.json',S/'source-blob-verification.json',S/'upstream/rclone-release.json',S/'upstream/rclone-tree.json',S/'upstream/rclone-Makefile',S/'upstream/rclone-go.sum']
refs += [Path('/workspace/tmp/pix-m7-prebuilt-association-20261015-01/collection-result.json'),Path('/workspace/tmp/pix-m7-prebuilt-strip-20261015-02/collection-result.json'),Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T105557Z-8aa7d0f7/admission-consumed.json')]
plan=dict(issue=528,tag='v1.75.2',commit='be8d6044eacb843b74d335db0c5fbe09222031fe',archives=json.loads((S/'next-action.json').read_text())['archives'],selected_modules=mods,source_members=selected,binding_refs={str(p):sha(p) for p in refs},source_prefix='rclone-v1.75.2/',vendor_prefix='vendor/',publication_clearance=False,dirty_file_list_known=False)
put(P/'collection-plan.json',plan)
for n in ['module-inventory.json','source-findings.json','next-action.json','source-blob-verification.json']:
 shutil.copy2(S/n,P/'originals'/n)
for n in ['run.py','run.sh','process-identity.py','consume.py']:
 shutil.copy2(R/'templates'/n,P/'templates'/n)
for n in ['frozen-tools.json']:shutil.copy2(R/n,P/n)
r=(P/'templates/run.py').read_text().replace("'selected-prebuilt-strip-derivation'","'rclone-release-source-and-selected-notices'")
r=r.replace("assert len(report['rows'])==9 and report['publication_clearance'] is False","assert len(report['rows'])==242 and len(report['archives'])==2 and report['publication_clearance'] is False")
r=r.replace("report['network_used'] is False","report['network_used'] is True")
r=r.replace('PASS_STRIP_DERIVATION_WITH_GAPS','PASS_SOURCE_COLLECTION_WITH_GAPS').replace('STRIP_DERIVATION_INCOMPLETE','SOURCE_COLLECTION_INCOMPLETE')
r=r.replace('Nine private strip transformations plus four retained texts only; no target execution, source reproducibility, independent SYSTEM or publication clearance; prior producer dispositions unchanged.','Two exact rclone release archives and selected source/notice members only; no target execution, source rebuild, dirty-file reconstruction, independent SYSTEM or publication clearance; prior producer dispositions unchanged.')
(P/'templates/run.py').write_text(r)
put(P/'resources.json',dict(address_space_bytes=2147483648,cleanup_seconds=15,collector_seconds=600,cpu_affinity=[0,1],outer_seconds=630,owner_output_ceiling_bytes=134217728,per_file_bytes=134217728,retention_budget_bytes=1073741824,download_count=2,download_body_expected_bytes=34770062,download_body_ceiling_bytes=41943040,connect_seconds=10,request_seconds=60,archive_members_per_archive=65536,decoded_bytes_per_archive_pass=536870912,selected_text_bytes=33554432,selected_file_bytes=2097152,selected_text_files=4096,scope='Two bounded canonical HTTPS requests; retain exact source/vendor archives and selected texts. No cache, target or Go execution, extraction or deletion. No whole-wire byte claim.'))
put(P/'source-provenance.json',dict(status='SOURCE_ONLY_UNRUN',prior_lifecycle_packet=str(R),prior_lifecycle_seal=sha(R/'SHA256SUMS'),prior_accepted_owner='/workspace/tmp/pix-m7-prebuilt-strip-20261015-02',prior_accepted_run='20261015T105557Z-8aa7d0f7',prior_accepted_admission='ed6fa1a7e7ef440599eca47e6790f978',disposition_source=str(S),future_curl_identity_required=True,no_download=True,no_import_or_execution=True))

# Current image/profile mapping derivative — unrun

This is a source-only derivative of the accepted metadata assembler. It writes three small JSON files under a fresh `/workspace/tmp/pix-m7-final-profile-map-20261015-NN` owner. It does not run a build, read cache or Nix trees, open an archive, copy a payload, extract notices, contact anyone, or perform delivery.

The accepted inputs are the 2,366-row historical join at `162920Z-33308c8a`, exact39 custody at `163942Z-6041fb99` (consumed `7f9891f258114e748581402347d7eaae`), and GENERIC reader02 at `163127Z-5682551e` (consumed `ee024372b00f4314afa9fc96495b83de`). `plan.json` binds their actual metadata bytes. Original failed producers/readers remain failed and are not read as substitutes for successful acceptance.

## Required actual next inputs

1. H70005 and SM8550-06 accepted readers at source `077197e6cd3ea31f33b28aaf3882a694b3423b53`, timestamp `20261015T161744Z`. Supply each actual `admission-consumed.json` path and SHA256. The helper follows only the consumed evidence's explicitly required JSON members, verifies consumed original command/monitor/runner0 and launcher0, links the successful producer, and binds exact image/variant outputs. The current ARM manifest and installed ARM handoff bind the companion profiles; the SM reader also binds its 14 cached FEX payloads. H700/SM pending hashes are not guessed or prefilled.
2. The exact077197 distribution snapshot. The held additive store currently contains only historical f863/9aa7 distribution snapshots; they cannot be relabeled. Reuse the pinned existing `snapshot(spec,seq,distribution=True)` collector route for just077197, retaining its private Git view, export-attribute protections, blob/mode/symlink readback and original child outcomes. `existing-routes.json` identifies that route. Supply the actual consumed collector JSON, original consumption-evidence JSON, and manifest path/SHA256 after acceptance. Its existing `snapshots[]` entry must name `distribution/077197e6cd3ea31f33b28aaf3882a694b3423b53.tar.gz` and `metadata/077197e6cd3ea31f33b28aaf3882a694b3423b53.json`, with the actual archive and metadata hashes. The map opens the JSON metadata only, never that archive.

The snapshot input contract deliberately retains the existing collector's `snapshots`/`entries` fields. Its manifest must occur in the original consumed evidence. The original evidence uses the established `run`, `expected_rc`, `evidence[{path,sha256}]` shape. If a separately prepared snapshot collector emits a different schema, adapt a narrow derivative before execution; do not manufacture receipts or silently accept a report in place of originals.

## Execution after those inputs exist

Root fills the nine `TASK_*` input variables required by `commands.sh` from actual accepted metadata, then runs:

```bash
bash /tmp/pix-m7-final-profile-map-plan-20261015/commands.sh
```

This uses the already accepted `tools/watch-build --record-only -- python3 -I -S -B ...` metadata route. Root owns serial scheduling and verifies the printed actual run's original `runner-result.json` and `build.rc`, plus the new owner's `result.json`. Successful completion is exactly original0/0/0 and `PASS_METADATA_ONLY`. On failure retain the original result and fresh owner; correct a new packet/owner rather than overwriting evidence. No build admission is created or consumed by this small metadata helper.

## What the outputs mean

`current-profile-source-map.json` binds the three accepted native image sets and both ARM companions. It verifies every carried selected recipe/inheritance/local-file/symlink hash against current snapshot metadata. It keeps the original join immutable by reference, marks every membership row `membership_newly_measured: false`, and preserves the historical inventory's original source/input hashes. It makes no fresh complete inventory claim.

Exactly three native ZeroTier rows change selection. Their current recipe is `b876990d…`, patch `5fe6dcc7…`, and the five current held members are the filtered14,194,934-byte source archive (`10273d13…`), current recipe, patch, BUILD.md and filtered-source manifest. The historical full upstream archive is absent from current ZeroTier `selected_members`; it remains in historical evidence. Both ARM profiles omit ZeroTier. Shared-source16 edges, two ARM companion edges, Tailscale/Koko and FEX references carry forward unchanged. The39 held payload identities are linked explicitly, so temporary original FEX/source locations do not become an instruction to acquire them again.

`delivery-assembly-plan.json` names existing held member sets and the remaining delivery operations. Full notice texts and their accepted metadata belong to `source_custody_delta`; no notice extraction or settled shader decision is repeated here. Historical unresolved wording stays in the historical join and is not promoted to a new gate. Current map success is local metadata assembly only: it does not mark the complete delivery bundle, independent retrieval, off-host custody, VM runtime qualification, device boot, RC or publication complete.

`result.json` preserves actual input references, finite read/write counts and the outcome. Bounds are512MiB address space,30seconds,8MiB per JSON file,64MiB aggregate reads including the final metadata recheck,16MiB total output with1MiB reserved for the failure/result receipt. The previous assembler's4MiB single-file bound was raised because its accepted joined index is4,447,095bytes. No child is spawned by the assembler.

Retain old image/receipt provenance. Do not repeat source acquisitions, accepted exact39 copying, full inventories, historical source/notice joins, isolated ZeroTier proof, accepted image builds/readbacks, or FEX/Nix resolution for this metadata task. No consumer in this packet owns a cache or Nix tree.

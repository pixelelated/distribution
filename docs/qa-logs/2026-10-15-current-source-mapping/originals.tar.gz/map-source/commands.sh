#!/bin/bash
# UNRUN. Root supplies actual completed/consumed metadata; this does not prepare or run images.
set -euo pipefail
: "${TASK_H700_CONSUMED_JSON:?actual accepted H700 admission-consumed.json}"
: "${TASK_H700_CONSUMED_SHA256:?actual H700 consumed SHA256}"
: "${TASK_SM8550_CONSUMED_JSON:?actual accepted SM8550 admission-consumed.json}"
: "${TASK_SM8550_CONSUMED_SHA256:?actual SM8550 consumed SHA256}"
: "${TASK_SNAPSHOT_CONSUMED_JSON:?actual accepted current-snapshot admission-consumed.json}"
: "${TASK_SNAPSHOT_CONSUMED_SHA256:?actual current-snapshot consumed SHA256}"
: "${TASK_SNAPSHOT_EVIDENCE_JSON:?actual current-snapshot consumption evidence JSON}"
: "${TASK_SNAPSHOT_MANIFEST_JSON:?actual current-snapshot custody manifest JSON}"
: "${TASK_SNAPSHOT_MANIFEST_SHA256:?actual current-snapshot manifest SHA256}"
TASK_PACKET=/tmp/pix-m7-final-profile-map-plan-20261015
TASK_OUTPUT=${TASK_OUTPUT:-/workspace/tmp/pix-m7-final-profile-map-20261015-01}
cd /workspace/repos/rocknix.worktrees/m7-player-setup
tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/assemble-profile-map.py" \
  --h700-consumed "$TASK_H700_CONSUMED_JSON" "$TASK_H700_CONSUMED_SHA256" \
  --sm8550-consumed "$TASK_SM8550_CONSUMED_JSON" "$TASK_SM8550_CONSUMED_SHA256" \
  --snapshot-consumed "$TASK_SNAPSHOT_CONSUMED_JSON" "$TASK_SNAPSHOT_CONSUMED_SHA256" \
  --snapshot-evidence "$TASK_SNAPSHOT_EVIDENCE_JSON" \
  --snapshot-manifest "$TASK_SNAPSHOT_MANIFEST_JSON" "$TASK_SNAPSHOT_MANIFEST_SHA256" \
  --output "$TASK_OUTPUT"

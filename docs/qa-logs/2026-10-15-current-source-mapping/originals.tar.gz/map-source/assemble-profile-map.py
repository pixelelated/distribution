#!/usr/bin/env python3
"""UNRUN: bounded metadata derivative of the accepted source-assembly join."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import stat
import time

HERE = Path(__file__).resolve().parent
SOURCE = '077197e6cd3ea31f33b28aaf3882a694b3423b53'
STAMP = '20261015T161744Z'
ZT = 'projects/ROCKNIX/packages/network/zerotier-one/'
RECIPE = 'b876990db897995a230330a78704e16ad881e5424f6ff172fee9d7f2203a1aba'
PATCH = '5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5'
READ = WRITTEN = 0
SEEN = {}
START = time.monotonic()
LIMIT = 16 * 1024**2

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(body):
    return hashlib.sha256(body).hexdigest()

def read(path, digest, size=None):
    global READ
    p = Path(path)
    require(p.is_absolute() and p.resolve() == p and not p.is_symlink(), 'metadata path changed: '+str(p))
    require(p.suffix == '.json', 'only explicit JSON metadata inputs are allowed')
    s = p.stat()
    require(stat.S_ISREG(s.st_mode) and s.st_size <= 8*1024**2, 'metadata file bound')
    require(size is None or s.st_size == size, 'metadata size changed')
    require(re.fullmatch('[a-f0-9]{64}', digest) is not None, 'actual SHA256 required')
    require(READ+s.st_size <= 64*1024**2, 'aggregate metadata bound')
    READ += s.st_size
    body = p.read_bytes()
    require(len(body) == s.st_size and sha(body) == digest, 'metadata identity changed: '+str(p))
    ref = {'path':str(p), 'bytes':len(body), 'sha256':digest}
    require(str(p) not in SEEN or SEEN[str(p)] == ref, 'conflicting metadata reference')
    SEEN[str(p)] = ref
    return json.loads(body)

def refread(ref):
    return read(ref['path'], ref['sha256'], ref.get('bytes'))

def write(out, name, value, receipt=False):
    global WRITTEN
    body = (json.dumps(value, sort_keys=True, separators=(',',':'))+'\n').encode()
    require(len(body) <= (1024**2 if receipt else LIMIT-1024**2), 'output file bound')
    require(WRITTEN+len(body) <= (LIMIT if receipt else LIMIT-1024**2), 'aggregate output bound')
    WRITTEN += len(body)
    with (out/name).open('xb') as stream:
        stream.write(body)
    return {'name':name, 'bytes':len(body), 'sha256':sha(body)}

def zeros(result):
    return all(type(result.get(k)) is int and result[k] == 0 for k in ('command_rc','monitor_rc','runner_rc'))

def consumed(arg, expected_source=None):
    path, digest = arg
    c = read(path, digest)
    require(c['state'] == 'consumed' and zeros(c['original_result']), 'original run not consumed with all zeros')
    require(str(Path(c['run'])/'admission-consumed.json') == path, 'consumed path/run mismatch')
    if expected_source:
        require(c['source']['head'] == expected_source, 'wrong actual source')
    return c

def evidence(c, supplied=None):
    path = supplied or str(Path(c['submission_owner'])/'consumption-evidence.json')
    e = read(path, c['evidence_sha256'])
    require(e['run'] == c['run'] and e['expected_rc'] == 0, 'consumption evidence mismatch')
    refs = {r['path']:r['sha256'] for r in e['evidence']}
    require(len(refs) == len(e['evidence']), 'duplicate evidence path')
    return refs

def member(refs, path):
    path = str(path)
    require(path in refs, 'required original is absent from consumption: '+path)
    return read(path, refs[path])

def zero_product(z):
    require(z['recipe_sha256'] == RECIPE and z['patch_sha256'] == PATCH, 'wrong ZeroTier source')
    require(z['one_service_sha256'] == 'b546cf4e77dc15175cca16c4143b5f615808e5d30a0ceafdf802881425b812e8', 'wrong patched source')
    require(z['nonfree_absent'] is True and z['target_execution'] is False, 'ZeroTier readback scope')
    require(z['dependency_completeness_claim'] is False and z['dependency_record_mode'] in
            ('not-requested-by-canonical-build','observed-compiler-records-no-completeness-claim'), 'dependency scope changed')

def accepted_image(arg, device, tree):
    c = consumed(arg, SOURCE)
    require(c['checkout'] == tree and Path(c['run']).parent == Path(tree)/'.build-runs', 'wrong image checkout/run')
    owner = Path(c['submission_owner'])
    short = {'GENERIC_X64':'generic','H700':'h700','SM8550':'sm8550'}[device]
    require(re.fullmatch('/workspace/tmp/pix-m7-zerotier-'+short+'-readback-20261015-[0-9]{2}', str(owner)), 'wrong reader owner')
    refs = evidence(c)
    runner = member(refs, Path(c['run'])/'runner-result.json')
    require(runner == c['original_result'] and zeros(runner), 'original runner mismatch')
    require(member(refs, owner/'launcher-result.json')['runner_returncode'] == 0, 'launcher failed')
    inp = member(refs, owner/'inputs.json')
    require(inp['build_timestamp'] == STAMP, 'wrong coordinated timestamp')
    result = {'device':device, 'source':SOURCE, 'timestamp':STAMP, 'reader_run':c['run'],
              'consumption_id':c['id'], 'consumed':SEEN[arg[0]], 'original_result':runner,
              'membership_basis':'Historical profile membership carried forward; selected recipe/local-source continuity checked against current exact snapshot. Not a fresh package inventory.'}
    if device == 'GENERIC_X64':
        require(inp['source'] == SOURCE, 'GENERIC source mismatch')
        a = member(refs, owner/'artifacts/inputs.json')
        r = member(refs, owner/'artifacts/result.json')
        identity = a['identity']
        require(r['status'] == 'PASS' and r['source'] == SOURCE and r['runtime_qualified'] is False, 'GENERIC artifact proof missing')
        require(identity['build_commit'] == SOURCE and identity['build_timestamp'] == STAMP and identity['device'] == device and identity['dirty'] == 'no', 'GENERIC identity mismatch')
        zero_product(r['zerotier'])
        require(a['build_inputs_sha256'] == inp['build_inputs_sha256'], 'GENERIC build input binding')
        producer = consumed((str(Path(inp['build_run'])/'admission-consumed.json'), inp['admission_consumed_sha256']), SOURCE)
        require(producer['submission_owner'] == inp['build_owner'], 'GENERIC producer owner mismatch')
        result.update(artifacts=a['artifacts'], payload=r['payload'], identity=identity,
                      reader_result=SEEN[str(owner/'artifacts/result.json')], zerotier=r['zerotier'])
    else:
        require(inp['distribution_commit'] == SOURCE and inp['device'] == device and inp['host_worktree'] == tree, 'native reader source mismatch')
        a = member(refs, owner/'artifacts/acceptance.json')
        outputs = member(refs, owner/'artifacts/output-manifest.json')
        affected = member(refs, owner/'artifacts/affected-products.json')
        require(a['result'] == 'PASS' and a['distribution_commit'] == SOURCE and a['reader_run'] == c['run'], 'native acceptance mismatch')
        require(a['scratch_removed'] and a['source_unchanged'] and a['independent_bundle_inodes'], 'acceptance closure missing')
        require(a['producer_combined_run_returncode'] == 0 and a['producer_run'] == inp['compiled_run'] and a['producer_consumed_sha256'] == inp['compiled_consumed_sha256'], 'producer binding mismatch')
        producer = consumed((str(Path(inp['compiled_run'])/'admission-consumed.json'), inp['compiled_consumed_sha256']), SOURCE)
        require(producer['submission_owner'] == inp['compiled_owner'], 'native producer owner mismatch')
        require(affected['result'] == 'PASS' and affected['source'] == SOURCE and affected['device'] == device, 'affected product result')
        zero_product(affected['special']['zerotier'])
        require(outputs['distribution_commit'] == SOURCE and len(outputs['files']) == (7 if device == 'H700' else 5), 'output membership differs')
        require(len(a['variants']) == (2 if device == 'H700' else 1), 'variant count differs')
        require(all(STAMP in name and SOURCE[:12] in name for name in outputs['files']), 'output identity differs')
        arm = member(refs, owner/'artifacts/arm-output-manifest.json')
        handoff = member(refs, owner/'artifacts/arm-handoff.json')
        require(arm['result'] == 'PASS' and len(handoff) == a['arm_handoff_files'] > 4, 'ARM handoff missing')
        require(all(arm['files'][row['source']] == row['sha256'] for row in handoff), 'ARM handoff hash mismatch')
        result.update(artifacts=outputs['files'], variants=a['variants'], reader_result=SEEN[str(owner/'artifacts/acceptance.json')],
                      arm_manifest=SEEN[str(owner/'artifacts/arm-output-manifest.json')],
                      arm_handoff=SEEN[str(owner/'artifacts/arm-handoff.json')], zerotier=affected['special']['zerotier'])
        if device == 'SM8550':
            fex = member(refs, owner/'artifacts/fex-package.json')
            installed = member(refs, owner/'artifacts/fex-installed.json')
            require(fex['result'] == 'PASS' and len(fex['files']) == 14 and installed['files'] == fex['files'] and fex['target_execution'] is False and fex['nix_execution'] is False, 'cached FEX acceptance mismatch')
            result['fex'] = SEEN[str(owner/'artifacts/fex-package.json')]
    require(producer['run'] == (inp['build_run'] if device == 'GENERIC_X64' else inp['compiled_run']), 'wrong producer run')
    result['producer_run'] = producer['run']
    result['producer_original_result'] = producer['original_result']
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('h700-consumed','sm8550-consumed','snapshot-consumed','snapshot-manifest'):
        parser.add_argument('--'+name, nargs=2, metavar=('JSON_PATH','ACTUAL_SHA256'), required=True)
    parser.add_argument('--snapshot-evidence', required=True, help='actual original consumption evidence JSON path')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output
    require(re.fullmatch('/workspace/tmp/pix-m7-final-profile-map-20261015-[0-9]{2}', str(out)) and out.parent.resolve() == out.parent and not out.exists(), 'fresh exact metadata output required')
    resource.setrlimit(resource.RLIMIT_AS, (512*1024**2,512*1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE, (LIMIT,LIMIT))
    resource.setrlimit(resource.RLIMIT_CORE, (0,0))
    def expired(_sig,_frame):
        raise TimeoutError('30-second metadata bound')
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(30)
    out.mkdir(mode=0o700)
    result = {'status':'FAIL','outputs':[], 'source_payloads_opened':0,'archives_opened':0,
              'child_processes':0,'network_used':False,'runtime_qualification':False,'publication_bundle_complete':False}
    try:
        plan = json.loads((HERE/'plan.json').read_text())
        fixed = {name:refread(ref) for name,ref in plan['refs'].items()}
        base = fixed['join']
        custody = fixed['custody_manifest']
        payloads = fixed['custody_payloads']
        require(fixed['join_result']['status'] == 'PASS_METADATA_ONLY' and base['component_rows'] == len(base['components']) == 2366, 'wrong accepted join')
        require(zeros(fixed['join_runner']), 'join original failed')
        require(custody['assembly_index_sha256'] == plan['refs']['join']['sha256'] and custody['payload_index_sha256'] == plan['refs']['custody_payloads']['sha256'], 'custody metadata binding')
        require(custody['payload_files'] == len(payloads) == 39 and sum(r['bytes'] for r in payloads) == custody['payload_bytes'] == 293582752, 'exact39 membership changed')
        cc = fixed['custody_consumed']
        require(cc['state'] == 'consumed' and cc['id'] == '7f9891f258114e748581402347d7eaae' and zeros(cc['original_result']), 'exact39 original result')
        images = {'generic-x64':accepted_image(plan['generic_consumed'], 'GENERIC_X64', plan['trees']['generic-x64']),
                  'h700':accepted_image(args.h700_consumed, 'H700', plan['trees']['h700']),
                  'sm8550':accepted_image(args.sm8550_consumed, 'SM8550', plan['trees']['sm8550'])}
        sc = consumed(args.snapshot_consumed)
        sr = evidence(sc, args.snapshot_evidence)
        require(sr.get(args.snapshot_manifest[0]) == args.snapshot_manifest[1], 'snapshot manifest not in consumed originals')
        sm = read(*args.snapshot_manifest)
        choices = [r for r in sm['snapshots'] if r['commit'] == SOURCE]
        require(len(choices) == 1, 'exact current distribution snapshot missing')
        snapshot = choices[0]
        require(snapshot['archive_member'] == 'distribution/'+SOURCE+'.tar.gz' and not snapshot['submodules'] and not snapshot['lfs_pointer_paths'], 'distribution snapshot shape')
        root = Path(args.snapshot_manifest[0]).parent
        meta_path = root/snapshot['metadata_member']
        require(meta_path.parent == root/'metadata' and meta_path.name == SOURCE+'.json', 'snapshot metadata member changed')
        meta = read(str(meta_path), snapshot['metadata_sha256'])
        require(meta['commit'] == SOURCE and meta['archive_sha256'] == snapshot['sha256'] and meta['archive_bytes'] == snapshot['bytes'] and meta['archive_member'] == snapshot['archive_member'], 'snapshot archive/metadata binding')
        require(meta['verified_blob_entries'] == snapshot['tracked_blobs'] == len(meta['entries']) and not meta['submodules'] and not meta['lfs_pointer_paths'], 'snapshot verification scope')
        current_snapshot = {'manifest':SEEN[args.snapshot_manifest[0]], 'metadata':SEEN[str(meta_path)],
                            'consumed':SEEN[args.snapshot_consumed[0]], 'member':snapshot, 'payload_reopened_here':False}
        prefix = Path(plan['refs']['custody_manifest']['path']).parent
        held = [{k:r[k] for k in ('member','bytes','sha256','kind')} | {'path':str(prefix/r['member'])} for r in payloads]
        zero = [r for r in held if r['member'].startswith('zerotier/')]
        require(len(zero) == 5 and {r['member']:r['sha256'] for r in zero} == plan['zerotier_members'], 'filtered ZeroTier custody differs')
        rows = []
        profiles = []
        seen = set()
        replacements = shared = companions = 0
        for old in base['profiles']:
            native = old['profile'].rsplit('-',1)[0]
            profiles.append({'profile':old['profile'], 'historical_inventory':old, 'image':native,
                             'current_source':SOURCE,'membership_newly_measured':False,
                             'arm_handoff':images[native].get('arm_handoff') if old['profile'].endswith('-arm') else None})
        for i, row in enumerate(base['components']):
            original = row['original_component']
            extra = row['assembly_additions']
            key = (original['profile'], original['component'])
            require(key not in seen, 'duplicate component'); seen.add(key)
            local = dict(extra['local_recipe_files'])
            inheritance = [dict(r) for r in original['recipe_inheritance']]
            recipe_sha = original['recipe_sha256']
            members = original['members']
            if original['component'] == 'zerotier-one':
                require(not original['profile'].endswith('-arm') and original['recipe'] == ZT+'package.mk', 'ZeroTier profile changed')
                replacements += 1
                recipe_sha = RECIPE
                local[ZT+'package.mk'] = RECIPE
                local[ZT+'patches/001-client-without-nonfree-headers.patch'] = PATCH
                for r in inheritance:
                    if r['path'] == ZT+'package.mk': r['sha256'] = RECIPE
                members = zero
            require(meta['entries'][original['recipe']]['sha256'] == recipe_sha, 'selected recipe continuity: '+str(key))
            for r in inheritance:
                require(meta['entries'][r['path']]['sha256'] == r['sha256'], 'recipe inheritance changed: '+r['path'])
            for path, digest in local.items():
                require(meta['entries'][path]['sha256'] == digest, 'local source changed: '+path)
            for path, target in extra['local_recipe_symlinks'].items():
                require(meta['entries'][path]['mode'] == '120000' and meta['entries'][path]['sha256'] == sha(os.fsencode(target)), 'local symlink changed: '+path)
            shared += len(extra.get('shared_source_components',[]))
            companions += int('companion_profile' in extra)
            # Historical notices and pending wording remain solely in the unchanged base index.
            additions = {k:v for k,v in extra.items() if k not in ('local_recipe_files','local_recipe_symlinks','historical_notice_occurrences','pending_new_image_source_selection')}
            rows.append({'profile':key[0], 'component':key[1], 'historical_row':i,
                         'recipe':original['recipe'], 'recipe_sha256':recipe_sha, 'recipe_inheritance':inheritance,
                         'distribution_snapshot':snapshot['archive_member'], 'selected_members':members,
                         'local_recipe_files':local, 'local_recipe_symlinks':extra['local_recipe_symlinks'],
                         'carried_source_additions':additions,
                         'additional_corresponding_source_refs':original['additional_corresponding_source_refs'],
                         'membership_newly_measured':False})
        require((replacements,shared,companions) == (3,16,2), 'profile/source edges changed')
        mapped = {'schema':1,'status':'CURRENT_IMAGE_BINDINGS_WITH_INHERITED_PROFILE_MEMBERSHIP',
                  'source':SOURCE,'build_timestamp':STAMP,'historical_join':plan['refs']['join'],
                  'current_distribution_snapshot':current_snapshot,'images':images,'profiles':profiles,
                  'components':rows,'component_rows':2366,'held_supplement_members':held,
                  'historical_records_unchanged':True,'new_package_inventory_claim':False,
                  'publication_bundle_complete':False,'runtime_qualification':False}
        delivery = {'schema':1,'status':'LOCAL_METADATA_ASSEMBLY_ONLY','distribution_snapshot':current_snapshot,
                    'source_map':'current-profile-source-map.json','held_exact39':plan['refs']['custody_manifest'],
                    'reuse_historical_join':plan['refs']['join'], 'held_supplement_members':held,
                    'zerotier_selected_members':zero,
                    'zerotier_historical_whole_archive_selected':False,
                    'do_not_repeat':plan['do_not_repeat'], 'remaining_delivery_actions':plan['remaining_delivery_actions'],
                    'notice_text_owner':'source_custody_delta', 'historical_legal_dispositions_reopened':False,
                    'public_delivery_bundle_created':False,'independent_retrieval_performed':False,'off_host_transfer_performed':False}
        # Recheck finite metadata originals before writing successful mapping outputs.
        for ref in list(SEEN.values()): refread(ref)
        result['outputs'].append(write(out,'current-profile-source-map.json',mapped))
        result['outputs'].append(write(out,'delivery-assembly-plan.json',delivery))
        result.update(status='PASS_METADATA_ONLY',source=SOURCE,component_rows=2366,zerotier_replacements=3,
                      shared_source_edges=shared,arm_companion_edges=companions,metadata_refs=list(SEEN.values()))
    except BaseException as exc:
        result['error'] = str(exc)[:2048]
    finally:
        signal.alarm(0)
        result.update(elapsed_seconds=time.monotonic()-START,metadata_bytes_read=READ,output_bytes_before_receipt=WRITTEN)
        write(out,'result.json',result,receipt=True)
    print(json.dumps({'status':result['status'],'output':str(out)}))
    return 0 if result['status'] == 'PASS_METADATA_ONLY' else 1

if __name__ == '__main__':
    raise SystemExit(main())

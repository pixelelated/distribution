#!/usr/bin/env python3
"""Offline single distribution snapshot custody; import/execution requires a separately admitted owner."""
from pathlib import Path,PurePosixPath
import base64,datetime,gzip,hashlib,io,json,os,selectors,stat,subprocess,sys,tarfile,time
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path'])
START=time.monotonic();READ=0;CALLS=[];WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1

def tick(n=0):
 global READ
 assert n>=0;READ+=n
 assert READ<=R['total_read_bytes'] and time.monotonic()-START<R['soft_seconds'],'read/time ceiling'
def safe(name):
 assert isinstance(name,str) and name and len(os.fsencode(name))<=R['path_bytes'] and '\0' not in name and '\\' not in name
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p)==name and '.git' not in p.parts,name
 return name

def ident(p,regular=True):
 p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.resolve(strict=True)==p,p
 s=p.stat();assert not regular or stat.S_ISREG(s.st_mode),p
 return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def digest(p,cap=268435456):
 before=ident(p);assert before['bytes']<=cap
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));h.update(b)
 assert ident(p)==before,'input changed while hashing'
 return dict(before,sha256=h.hexdigest())
def root_for(p):
 for root in [O,D]:
  if p.is_relative_to(root):return root
 raise AssertionError('write outside owned roots')
def mkdir(p):
 root=root_for(p);assert len(DIRS)<R['output_directories'];assert not p.exists() and not p.is_symlink()
 assert p.parent.resolve(strict=True)==p.parent and not p.parent.is_symlink();p.mkdir(mode=0o700);DIRS.add(str(p))
def reserve(p,n,failure=False):
 tick();root=root_for(p);cap=R['custody_output_ceiling_bytes'] if root==D else R['owner_output_ceiling_bytes']-R['supervisor_reserve_bytes']
 if failure:assert root==O and n<=R['failure_receipt_budget_bytes'];cap+=R['failure_receipt_budget_bytes']
 assert n>=0 and OUTPUT[str(root)]+n<=cap,'aggregate before-write ceiling'
 assert WRITES[str(p)]+n<=R['per_file_bytes'],'individual before-write ceiling'
 OUTPUT[str(root)]+=n;WRITES[str(p)]+=n
class Writer:
 def __init__(self,p,failure=False):
  self.p=Path(p);root_for(self.p);safe(str(self.p.relative_to(root_for(self.p))))
  assert len(WRITES)<R['output_files'] and str(self.p) not in WRITES
  assert self.p.parent.resolve(strict=True)==self.p.parent and not self.p.exists() and not self.p.is_symlink()
  WRITES[str(self.p)]=0;self.failure=failure;self.f=self.p.open('xb')
 def write(self,b):reserve(self.p,len(b),self.failure);return self.f.write(b)
 def flush(self):self.f.flush()
 def tell(self):return self.f.tell()
 def close(self):self.f.close()
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
def put(p,obj,failure=False):
 raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
 if failure:assert len(raw)<=R['failure_receipt_budget_bytes']
 with Writer(p,failure) as f:f.write(raw)
def rawput(p,b):
 with Writer(p) as f:f.write(b)
def load(p):
 before=ident(p);assert before['bytes']<16*1024**2
 raw=Path(p).read_bytes();tick(len(raw));assert ident(p)==before;return json.loads(raw)

def command(argv,cap,sink=None):
 assert len(CALLS)<R['git_commands'] and argv[0]==PLAN['host_git']['path']
 row=dict(argv=argv,original_returncode=None,wait_observed=False,stdout_bytes=0,stderr_bytes=0);CALLS.append(row)
 env={'PATH':'/usr/bin:/bin','HOME':str(O/'empty-home'),'LC_ALL':'C','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0','GIT_NO_REPLACE_OBJECTS':'1','GIT_ATTR_NOSYSTEM':'1','GIT_CONFIG_COUNT':'5','GIT_CONFIG_KEY_0':'core.hooksPath','GIT_CONFIG_VALUE_0':'/dev/null','GIT_CONFIG_KEY_1':'protocol.allow','GIT_CONFIG_VALUE_1':'never','GIT_CONFIG_KEY_2':'core.attributesFile','GIT_CONFIG_VALUE_2':'/dev/null','GIT_CONFIG_KEY_3':'core.fsmonitor','GIT_CONFIG_VALUE_3':'false','GIT_CONFIG_KEY_4':'core.untrackedCache','GIT_CONFIG_VALUE_4':'false'}
 p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,cwd=O)
 # The outer qualified subreaper owns interruption cleanup and adopted waits.
 # Never signal a numeric group or invent an original child wait on early refusal.
 sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ,'stdout');sel.register(p.stderr,selectors.EVENT_READ,'stderr');buf={'stdout':bytearray(),'stderr':bytearray()};deadline=time.monotonic()+R['git_seconds']
 try:
  while sel.get_map():
   tick();assert time.monotonic()<deadline,'Git command deadline'
   for key,_ in sel.select(.2):
    b=os.read(key.fileobj.fileno(),65536)
    if not b:sel.unregister(key.fileobj);continue
    which=key.data;row[which+'_bytes']+=len(b);tick(len(b))
    assert row[which+'_bytes']<=(cap if which=='stdout' else R['git_stderr_bytes']),'Git output ceiling'
    if which=='stdout' and sink is not None:sink.write(b)
    else:buf[which].extend(b)
  p.wait(timeout=max(.01,deadline-time.monotonic()));row.update(original_returncode=p.returncode,wait_observed=True,stderr=buf['stderr'].decode('utf-8','backslashreplace'))
  assert p.returncode==0,'Git original exit '+str(p.returncode)
  return bytes(buf['stdout'])
 finally:
  sel.close();p.stdout.close();p.stderr.close()
def git(repo,*args,cap=None):return command([PLAN['host_git']['path'],'-C',str(repo),*args],R['git_stdout_metadata_bytes'] if cap is None else cap)
def private_view(spec,seq):
 v=O/'scratch'/('view-'+str(seq)+'.git');mkdir(v)
 for rel in ['objects','objects/info','refs','info']:mkdir(v/rel)
 rawput(v/'HEAD',b'ref: refs/heads/unused\n');rawput(v/'config',b'[core]\n\trepositoryformatversion = 0\n\tbare = true\n[tar]\n\tumask = 0022\n')
 objects=Path(spec['objects']);assert objects.is_absolute() and objects.resolve(strict=True)==objects and not objects.is_symlink()
 rawput(v/'objects/info/alternates',(str(objects)+'\n').encode())
 rawput(v/'info/attributes',b'* -export-ignore -export-subst -text -eol -ident -filter -working-tree-encoding\n')
 return v
class Decoded:
 def __init__(self,f):self.f=f;self.n=0
 def read(self,n=-1):
  assert n>=0;b=self.f.read(n);self.n+=len(b);tick(len(b));assert self.n<=R['archive_decoded_bytes'],'decoded archive ceiling';return b

def snapshot(spec,seq,distribution=False):
 commit=spec['commit'];assert len(commit)==40
 commit_raw=git(spec['source_repository'],'cat-file','commit',commit,cap=65536)
 assert hashlib.sha1(b'commit '+str(len(commit_raw)).encode()+b'\0'+commit_raw).hexdigest()==commit
 roots=spec.get('roots',[]);raw=git(spec['source_repository'],'ls-tree','-r','-z',commit,'--',*roots)
 entries={};edges=[]
 for record in raw.split(b'\0'):
  if not record:continue
  meta,name=record.split(b'\t',1);mode,kind,oid=meta.decode().split();name=safe(os.fsdecode(name));assert name not in entries
  if mode=='160000':assert kind=='commit';edges.append(dict(path=name,commit=oid));continue
  assert kind=='blob' and mode in ['100644','100755','120000'];entries[name]=dict(mode=mode,git_blob=oid)
  assert len(entries)<=R['tree_entries']
 assert entries, 'empty Git source tree'
 inputs=load(spec['input_manifest']) if distribution else None
 if distribution:
  assert not edges and set(entries)==set(inputs['source_files'])|set(inputs['source_symlinks']),'distribution map differs from exact tree'
 else:assert edges==[dict(path=s['path'],commit=s['commit']) for s in spec['submodules']]
 view=private_view(spec,seq);member=('distribution/' if distribution else 'trees/')+commit+'.tar.gz';target=D/member
 with Writer(target) as out:
  with gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0,compresslevel=6) as z:
   command([PLAN['host_git']['path'],'--git-dir',str(view),'archive','--format=tar',commit,'--',*roots],R['archive_decoded_bytes'],z)
 witnessed=set();seen=set();lfs=[];declared=0
 with target.open('rb') as f,gzip.GzipFile(fileobj=f,mode='rb') as gz:
  dec=Decoded(gz)
  with tarfile.open(fileobj=dec,mode='r|',encoding='utf-8',errors='surrogateescape') as tar:
   for m in tar:
    name=safe(m.name.rstrip('/'));assert name not in seen;seen.add(name);assert len(seen)<=R['tar_entries']
    if m.isdir():continue
    assert name in entries;expected=entries[name];assert m.size>=0;declared+=m.size;assert declared<=R['archive_decoded_bytes']
    if m.issym():
     assert expected['mode']=='120000';data=os.fsencode(m.linkname);h=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data);sh=hashlib.sha256(data)
     if distribution:assert data==os.fsencode(inputs['source_symlinks'][name]),name
    else:
     assert m.isfile() and not m.issparse() and expected['mode'] in ['100644','100755'] and (m.mode&0o777)==(0o755 if expected['mode']=='100755' else 0o644)
     h=hashlib.sha1(b'blob '+str(m.size).encode()+b'\0');sh=hashlib.sha256();stream=tar.extractfile(m);got=0
     while True:
      b=stream.read(1024**2)
      if not b:break
      if got==0 and b.startswith(b'version https://git-lfs.github.com/spec/v1\n'):lfs.append(name)
      got+=len(b);tick(len(b));h.update(b);sh.update(b)
     assert got==m.size
     if distribution:assert sh.hexdigest()==inputs['source_files'][name],name
    assert h.hexdigest()==expected['git_blob'],name
    expected['sha256']=sh.hexdigest();expected['bytes']=len(data) if m.issym() else m.size;witnessed.add(name)
  while dec.read(1024**2):pass
 assert witnessed==set(entries)
 archive=digest(target);meta=dict(commit=commit,commit_object_base64=base64.b64encode(commit_raw).decode('ascii'),entries=entries,submodules=edges,lfs_pointer_paths=lfs,archive_member=member,archive_sha256=archive['sha256'],archive_bytes=archive['bytes'],verified_blob_entries=len(entries),source_input=spec.get('input_manifest'),claim='Exact Git blob bytes, executable modes and raw symlink targets; export-ignore/substitution disabled in private view; distribution maps match accepted source_files/source_symlinks')
 put(D/'metadata'/(commit+'.json'),meta)
 return dict(commit=commit,archive_member=member,sha256=archive['sha256'],bytes=archive['bytes'],metadata_member='metadata/'+commit+'.json',metadata_sha256=digest(D/'metadata'/(commit+'.json'))['sha256'],tracked_blobs=len(entries),submodules=edges,lfs_pointer_paths=lfs)

try:
 assert D.parent==Path('/workspace/artifacts/pixelelated-release-sources') and D.name=='m7-distribution-snapshot-'+O.name.removeprefix('pix-m7-distribution-snapshot-') and not D.exists() and not D.is_symlink()
 for p in O.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():OUTPUT[str(O)]+=p.stat().st_size
 assert OUTPUT[str(O)]<8*1024**2
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 assert digest(PLAN['host_git']['path'],16*1024**2)==PLAN['host_git']['identity']
 assert PLAN['candidate_commit']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and len(PLAN['distribution'])==1
 inputs=load(PLAN['distribution'][0]['input_manifest'])
 assert inputs['distribution_commit']==PLAN['candidate_commit'] and len(inputs['source_files'])==6561 and len(inputs['source_symlinks'])==180
 mkdir(D)
 for n in ['distribution','metadata']:mkdir(D/n)
 mkdir(O/'scratch');mkdir(O/'empty-home')
 selected=snapshot(PLAN['distribution'][0],0,True)
 metadata=load(D/selected['metadata_member'])
 assert selected['tracked_blobs']==PLAN['expected_tracked_blob_entries']==6741 and not selected['submodules'] and not selected['lfs_pointer_paths']
 assert sum(e['bytes'] for e in metadata['entries'].values())==PLAN['expected_blob_bytes']==64485661
 assert len(CALLS)==3 and all(r['wait_observed'] and r['original_returncode']==0 for r in CALLS)
 manifest=dict(schema=1,scope=PLAN['scope'],candidate_commit=PLAN['candidate_commit'],binding_refs=PLAN['binding_refs'],snapshots=[selected],
   source_roots=PLAN['distribution'][0]['roots'],expected_source_map_sha256=digest(PLAN['distribution'][0]['input_manifest'])['sha256'],
   source_membership='Exact tracked build-source roots only; no untracked/ignored files or unrelated docs/history.',
   new_distribution_snapshots=1,new_other_sources=0,publication_bundle_complete=False,unresolved=PLAN['unresolved'])
 put(D/'manifest.json',manifest)
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 assert digest(PLAN['host_git']['path'],16*1024**2)==PLAN['host_git']['identity']
 put(O/'git-command-waits.json',CALLS)
 files=[dict(path=p,bytes=n,sha256=digest(p)['sha256']) for p,n in WRITES.items() if Path(p).is_relative_to(D)]
 assert len(files)==3
 for item in files:Path(item['path']).chmod(0o444)
 for p in sorted([Path(p) for p in DIRS if Path(p).is_relative_to(D)],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
 put(O/'collection-result.json',dict(result='COLLECTED_EXACT_DISTRIBUTION_SNAPSHOT',original_collector_exit=0,candidate_commit=PLAN['candidate_commit'],custody_path=str(D),manifest_sha256=digest(D/'manifest.json')['sha256'],files=files,
   new_distribution_snapshots=1,new_other_sources=0,tracked_blob_entries=6741,source_blob_bytes=64485661,network_used=False,target_execution=False,source_rebuild=False,publication_clearance=False,publication_bundle_complete=False,
   outputs_held=True,deleted_bytes=0,accounted_output_bytes=OUTPUT,read_bytes=READ,elapsed_seconds=time.monotonic()-START,git_commands=len(CALLS)))
 rc=0
except BaseException as exc:
 # One finite reserved failure receipt; never replay a refused large manifest.
 try:put(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(exc).__name__+': '+str(exc)[:4096],accounted_output_bytes=OUTPUT,written_files=len(WRITES),git_command_statuses=[dict(argv=r['argv'],original_returncode=r['original_returncode'],wait_observed=r['wait_observed'],stdout_bytes=r['stdout_bytes'],stderr_bytes=r['stderr_bytes']) for r in CALLS],publication_bundle_complete=False,outputs_held=True,deleted_bytes=0),failure=True)
 except BaseException as receipt_error:print('Failure receipt refused: '+type(receipt_error).__name__,file=sys.stderr)
sys.exit(rc)

from pathlib import Path
import datetime,hashlib,json
O=Path(__file__).parent;HEAD='077197e6cd3ea31f33b28aaf3882a694b3423b53';CONTROL='f8636de1d105275dbf9420bbabbbc26f79abb10f';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
s=Path('/workspace/tmp/pix-m7-distribution-snapshot-20261015-01');m=Path('/workspace/tmp/pix-m7-final-profile-map-20261015-01');dest=Path('/workspace/artifacts/pixelelated-release-sources/m7-distribution-snapshot-20261015-01');sr=Path((s/'run.path').read_text().strip());mr=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T172629Z-6c2483f3')
seals=[]
for path,seal in [('/tmp/pix-m7-distribution-snapshot-plan-20261015','7b1922f8528e56309deaba5903303eaeb951f7ba0d49e7ca3187dfeb2e43fd8e'),('/tmp/pix-m7-final-profile-map-plan-20261015','8dfc31cb12938748afd78ff92e83af0323eb03a08eb82d5c0f79c3af5baec805')]:
 p=Path(path);assert h(p/'SHA256SUMS')==seal;count=0
 for ln in (p/'SHA256SUMS').read_text().splitlines():
  expected,name=ln.split('  ',1);f=p/name;assert f.is_relative_to(p) and f.stat().st_size<2*1024**2 and h(f)==expected;count+=1
 seals.append({'path':path,'seal':seal,'members':count})
assert sr.name=='20261015T172546Z-5eae7d01';cons=j(sr/'admission-consumed.json');ev=j(s/'admission-completion-evidence.json');runner=j(sr/'runner-result.json')
assert cons['state']=='consumed' and cons['id']=='6daffe18bfbf4b71996a2567564c4526' and cons['original_result']==runner and cons['pid_namespace']==4026531836 and cons['source']['head']==CONTROL
assert cons['run']==str(sr) and cons['submission_owner']==str(s) and cons['evidence_sha256']==h(s/'admission-completion-evidence.json')
assert ev['disposition']=='qualified' and ev['expected_rc']==0 and ev['run']==str(sr)
assert all(runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc']) and j(s/'launcher-result.json')['runner_returncode']==0
for p in [s/'inner.rc',s/'outer.rc',s/'tool-wrapper.rc',sr/'build.rc']:assert p.read_text()=='0\n'
collection=j(s/'collection-result.json');result=j(s/'result.json');cleanup=j(s/'cleanup.json');manifest=j(dest/'manifest.json');meta=j(dest/'metadata'/f'{HEAD}.json')
assert collection['result']=='COLLECTED_EXACT_DISTRIBUTION_SNAPSHOT' and result['result']=='PASS_DISTRIBUTION_SNAPSHOT_CUSTODY' and result['runtime_control_source']==CONTROL
assert result['cleanup_errors']==result['receipt_errors']==result['interrupted_signals']==[] and result['execution_error'] is None
assert cleanup['all_recorded_identities_absent'] and not cleanup['direct_child_unreaped'] and all(cleanup[k]==[] for k in ['errors','receipt_errors','signals_sent','survivors_after_cleanup','recorded_identities_still_present'])
assert collection['candidate_commit']==manifest['candidate_commit']==meta['commit']==HEAD and collection['original_collector_exit']==0 and collection['new_distribution_snapshots']==1 and collection['new_other_sources']==0
assert all(collection[k] is False for k in ['network_used','source_rebuild','target_execution','publication_bundle_complete','publication_clearance'])
assert len(manifest['snapshots'])==1;sn=manifest['snapshots'][0];assert sn['bytes']==meta['archive_bytes']==25399839 and sn['sha256']==meta['archive_sha256']=='faf860905ee4e979ef1dc84b55ef0940143c0e031a63cf1d6a4e1a8c13377fb1'
assert sn['tracked_blobs']==meta['verified_blob_entries']==len(meta['entries'])==collection['tracked_blob_entries']==6741 and not sn['lfs_pointer_paths'] and not sn['submodules']
assert sn['metadata_sha256']==h(dest/sn['metadata_member']) and collection['manifest_sha256']==h(dest/'manifest.json')
archive=dest/sn['archive_member'];skipped=[];verified=[];small_view=[]
for e in ev['evidence']:
 p=Path(e['path'])
 if p==archive:
  assert e['sha256']==sn['sha256'];skipped.append({'path':str(p),'sha256':e['sha256'],'bytes':sn['bytes'],'reason':'Explicitly excluded; no body opened, hashed or copied for compact custody.'});continue
 assert (p.is_relative_to(s) or p.is_relative_to(sr) or p.is_relative_to(dest/'metadata') or p==dest/'manifest.json') and p.stat().st_size<2*1024**2 and h(p)==e['sha256']
 verified.append(e)
 if p.is_relative_to(s/'scratch'):
  assert p.name in ['config','HEAD','attributes','alternates'] and p.stat().st_size<256;small_view.append(str(p))
assert len(skipped)==1 and len(small_view)==4
sc=Path('/tmp/pix-m7-snapshot-coordinator-20261015');records=[];exits={}
for p in sorted(sc.glob('*.exit.json')):
 expected=1 if p.name=='preflight.exit.json' else 0;assert j(p)['original_tool_exit']==expected;exits[p.name]=expected
assert 'READY: /swap.img active, priority -1, 8388348 KiB free' in (sc/'reclaim-swap.stdout').read_text()
for name in ['prepare','report']:
 run=Path((sc/(name+'.stderr')).read_text().strip().removeprefix('watch-build: recording in '));rr=j(run/'runner-result.json');assert all(rr[k]==0 for k in ['command_rc','monitor_rc','runner_rc']) and (run/'build.rc').read_text()=='0\n';records.append({'run':str(run),'original_result':rr})
mapresult=j(m/'result.json');mapping=j(m/'current-profile-source-map.json');delivery=j(m/'delivery-assembly-plan.json');maprun=j(mr/'runner-result.json')
assert all(maprun[k]==0 for k in ['command_rc','monitor_rc','runner_rc']) and (mr/'build.rc').read_text()=='0\n'
mc=Path('/tmp/pix-m7-profile-map-coordinator-20261015');assert j(mc/'launch.exit.json')['original_tool_exit']==0 and str(mr) in (mc/'launch.stderr').read_text()
assert mapresult['status']=='PASS_METADATA_ONLY' and mapresult['archives_opened']==mapresult['source_payloads_opened']==mapresult['child_processes']==0
assert not mapresult['network_used'] and not mapresult['publication_bundle_complete'] and not mapresult['runtime_qualification']
for out in mapresult['outputs']:assert (m/out['name']).stat().st_size==out['bytes'] and h(m/out['name'])==out['sha256']
assert h(m/'current-profile-source-map.json')=='7d95e91f64bcbec38096de94f236f107c0760762645f93481369cc3f17bcb741'
assert mapping['source']==mapresult['source']==HEAD and len(mapping['components'])==mapping['component_rows']==mapresult['component_rows']==2366
assert all(x['membership_newly_measured'] is False for x in mapping['components']) and all(x['membership_newly_measured'] is False for x in mapping['profiles'])
assert mapping['historical_records_unchanged'] and not mapping['new_package_inventory_claim'] and not mapping['publication_bundle_complete'] and not mapping['runtime_qualification']
assert len(mapping['images'])==3 and len(mapping['profiles'])==5 and sum(x['arm_handoff'] is not None for x in mapping['profiles'])==mapresult['arm_companion_edges']==2
assert len([x for x in mapping['components'] if x['component']=='zerotier-one'])==mapresult['zerotier_replacements']==3
assert mapping['current_distribution_snapshot']['member']==sn and not mapping['current_distribution_snapshot']['payload_reopened_here']
assert not delivery['public_delivery_bundle_created'] and not delivery['independent_retrieval_performed'] and not delivery['off_host_transfer_performed'] and not delivery['zerotier_historical_whole_archive_selected']
refs=[]
for ref in mapresult['metadata_refs']:
 p=Path(ref['path']);assert p.suffix=='.json' and p.stat().st_size==ref['bytes'] and ref['bytes']<=5*1024**2 and h(p)==ref['sha256'];refs.append(ref)
for image in mapping['images'].values():
 assert image['source']==HEAD and all(image['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc']);c=j(image['consumed']['path']);assert c['state']=='consumed' and c['id']==image['consumption_id'] and c['original_result']==image['original_result']
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_COMPACT_SNAPSHOT_AND_CURRENT_METADATA_MAP_RECORDS','source_seals':seals,'snapshot_run':str(sr),'snapshot_original_result':runner,'snapshot_consumed_id':cons['id'],'snapshot_consumed_sha256':h(sr/'admission-consumed.json'),'snapshot_control_source':CONTROL,'snapshot_actual_source':HEAD,'snapshot_elapsed_seconds':collection['elapsed_seconds'],'snapshot_metadata_sha256':h(dest/sn['metadata_member']),'snapshot_manifest_sha256':h(dest/'manifest.json'),'archive_body_not_read':skipped,'compact_evidence_checked':len(verified),'small_private_git_view_metadata_files':small_view,'root_exit_observations':exits,'preparation_and_retention_runs':records,'map_run':str(mr),'map_original_result':maprun,'map_elapsed_seconds':mapresult['elapsed_seconds'],'map_sha256':h(m/'current-profile-source-map.json'),'map_components':2366,'all_membership_newly_measured_false':True,'images':3,'profiles':5,'ARM_companion_edges':2,'zerotier_selection_replacements':3,'metadata_refs_verified':refs,'no_live_census_or_source_payload_read':True,'scope':'Compact originals only; no source replay, package re-inventory, archive rehash, independent retrieval, runtime or publication claim.'}
(O/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'receipt_sha256':h(O/'record-readback.json'),'snapshot_compact_evidence_checked':len(verified),'map_metadata_refs_verified':len(refs),'archive_bodies_opened':0}))

from pathlib import Path
import hashlib,json,subprocess,sys,os,shutil
P=Path('/tmp/pix-m7-distribution-snapshot-plan-20261015');R=Path('/tmp/pix-m7-snapshot-coordinator-20261015');R.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'SHA256SUMS')=='7b1922f8528e56309deaba5903303eaeb951f7ba0d49e7ca3187dfeb2e43fd8e'
for ln in (P/'SHA256SUMS').read_text().splitlines():h,n=ln.split('  ',1);assert sha(P/n)==h,n
stage=sys.argv[1];assert stage in ['prepare','preflight','report','admit','launch','consume'];env=os.environ.copy()
if stage=='prepare':
 git=Path(shutil.which('git')).resolve(strict=True);env.update(TASK_GIT_PATH=str(git),TASK_GIT_SHA256=sha(git))
 (R/'host-git-input.json').write_text(json.dumps({'path':str(git),'sha256':sha(git),'uid':git.stat().st_uid,'gid':git.stat().st_gid,'bytes':git.stat().st_size})+'\n')
cmd=['bash',str(P/'commands.sh'),stage]
with (R/(stage+'.stdout')).open('xb') as out,(R/(stage+'.stderr')).open('xb') as err:p=subprocess.run(cmd,env=env,stdout=out,stderr=err)
(R/(stage+'.exit.json')).write_text(json.dumps({'original_tool_exit':p.returncode,'argv':cmd})+'\n');print(json.dumps({'stage':stage,'original_tool_exit':p.returncode,'stdout':str(R/(stage+'.stdout'))}));raise SystemExit(p.returncode)

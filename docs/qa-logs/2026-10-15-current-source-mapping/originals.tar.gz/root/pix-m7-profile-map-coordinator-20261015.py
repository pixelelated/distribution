from pathlib import Path
import hashlib,json,subprocess,os
P=Path('/tmp/pix-m7-final-profile-map-plan-20261015');R=Path('/tmp/pix-m7-profile-map-coordinator-20261015');R.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'SHA256SUMS')=='8dfc31cb12938748afd78ff92e83af0323eb03a08eb82d5c0f79c3af5baec805'
for line in (P/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(P/n)==h,n
assert not [j for j in json.loads(Path('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json').read_text())['jobs'].values() if j['state']!='consumed']
env=os.environ.copy()
for name,owner in [('H700','/workspace/tmp/pix-m7-zerotier-h700-readback-20261015-01'),('SM8550','/workspace/tmp/pix-m7-zerotier-sm8550-readback-20261015-01'),('SNAPSHOT','/workspace/tmp/pix-m7-distribution-snapshot-20261015-01')]:
 o=Path(owner);r=Path((o/'run.path').read_text().strip());p=r/'admission-consumed.json';j=json.loads(p.read_text());assert j['state']=='consumed';env['TASK_'+name+'_CONSUMED_JSON']=str(p);env['TASK_'+name+'_CONSUMED_SHA256']=sha(p)
e=Path('/workspace/tmp/pix-m7-distribution-snapshot-20261015-01/admission-completion-evidence.json');m=Path('/workspace/artifacts/pixelelated-release-sources/m7-distribution-snapshot-20261015-01/manifest.json')
env.update(TASK_SNAPSHOT_EVIDENCE_JSON=str(e),TASK_SNAPSHOT_MANIFEST_JSON=str(m),TASK_SNAPSHOT_MANIFEST_SHA256=sha(m))
(R/'actual-inputs.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith('TASK_')},indent=2)+'\n')
cmd=['bash',str(P/'commands.sh')]
with (R/'launch.stdout').open('xb') as out,(R/'launch.stderr').open('xb') as err:p=subprocess.run(cmd,env=env,stdout=out,stderr=err)
(R/'launch.exit.json').write_text(json.dumps({'original_tool_exit':p.returncode,'argv':cmd})+'\n');print(json.dumps({'original_tool_exit':p.returncode,'stdout':str(R/'launch.stdout')}));raise SystemExit(p.returncode)

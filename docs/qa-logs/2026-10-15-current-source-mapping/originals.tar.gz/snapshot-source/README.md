# Exact077197 distribution snapshot — source-only continuation

Status: UNRUN. Root schedules preparation/admission/collection after the H700 and SM8550 work. No preparer, collector, Git command, archive payload read, runtime census, cache walk, checkout mutation, allocation or network operation was performed while preparing this packet. Reads were limited to named source helpers and existing metadata.

This continues the actual accepted additive collector at `/workspace/tmp/pix-m7-additive-source-custody-20261015-01`, run `20261015T123133Z-e603a11c`, consumed `cb2b87b9816a4f1e987bb683fa5d53f3`, original0/0/0. Its collector SHA is `314e2426b83d4dc11ca1715e31aae2e6f08adae5b381112eb491c488747d1464`. `snapshot()` is byte-identical. `source-provenance.json` pins the actual accepted code and receipts; `changes.diff` shows the full derivative. The proven subreaper, signal-masked spawn, PID/start and pidfd custody, original waits, bounded cleanup and ordinary consumption remain.

Only candidate `077197e6cd3ea31f33b28aaf3882a694b3423b53` is archived. Later evidence-only `next` heads, including b5250a18, do not change that argument. The frozen runtime control checkout remains `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02` at f863; this is the collector's control source, not the archive's candidate source.

## Exact source scope

As in the accepted corresponding-source snapshot, the tracked roots are `LICENSE.md`, `Makefile`, `TRADEMARK.md`, `config`, `distributions`, `packages`, `projects` and `scripts`. All matching tracked files, executable modes, raw symlink targets and public notices are retained. This is the exact tracked build-source tree under those declared roots; it is not an archive of unrelated fork documentation/history. It never includes untracked files, device data, cache extras, worktree dirt, other source archives or Git internals. No FEX/Nix/ES/Tailscale/Koko/source acquisition is repeated.

`current-source-inputs.json` derives from the accepted9aa7 source map and original metadata: it changes only ZeroTier `package.mk` to `b876990d…` and adds the patch `5fe6dcc7…`. The candidate is expected to have6,561 regular tracked files and180 symlinks (6,741 entries), totaling64,485,661 blob bytes. These are expected values, not claimed new measurements. During collection the exact077197 `ls-tree` membership must equal this map, and independent archive readback must match every Git blob SHA1, source SHA256, executable mode and symlink target. A mismatch fails the original run; the expected map is never treated as proof by itself.

Only three Git children run, sequentially: exact commit-object read, exact recursive tree listing under the declared roots, and `git archive` through a private bare view. The private view reads only the named repository object store and disables export-ignore, export-subst, text conversion, filters and hooks. The archive readback verifies the commit object, complete entry membership, declared sizes and each blob. No checkout is made. No branch/ref moves. No target, build tool, downloaded code or source hook executes.

## Root command route

Default new owner: `/workspace/tmp/pix-m7-distribution-snapshot-20261015-01`.
Default new custody: `/workspace/artifacts/pixelelated-release-sources/m7-distribution-snapshot-20261015-01`.
Both must be absent. Root supplies `TASK_GIT_PATH` and `TASK_GIT_SHA256` from the actual host executable before preparation; the preparer captures its real device/inode/uid/gid/mode/hash. No sandbox ownership metadata is substituted.

Run each action separately after the previous action completes:

```bash
bash /tmp/pix-m7-distribution-snapshot-plan-20261015/commands.sh prepare
bash /tmp/pix-m7-distribution-snapshot-plan-20261015/commands.sh preflight
bash /tmp/pix-m7-distribution-snapshot-plan-20261015/commands.sh report
bash /tmp/pix-m7-distribution-snapshot-plan-20261015/commands.sh admit
bash /tmp/pix-m7-distribution-snapshot-plan-20261015/commands.sh launch
```

Root actively supervises the actual printed run at intervals no longer than60seconds. Submission is not completion. After original success and clean owned-process closure:

```bash
bash /tmp/pix-m7-distribution-snapshot-plan-20261015/commands.sh consume
```

Success requires collector/stage/inner/outer/tool-wrapper/launcher/command/monitor/runner0, all three original Git waits0, no cleanup signal/error/survivor, and exactly the three declared custody files. `collection-result.json` reports `COLLECTED_EXACT_DISTRIBUTION_SNAPSHOT`; supervisor `result.json` reports `PASS_DISTRIBUTION_SNAPSHOT_CUSTODY`. The consumer rehashes those three held files and writes ordinary original `admission-completion-evidence.json`. Failure retains partial outputs and all original statuses and requires the existing investigated-failure consumption route; it never runs this success consumer or relabels an old run.

## Outputs and mapping handoff

The only new retained custody files are:

- `distribution/077197e6cd3ea31f33b28aaf3882a694b3423b53.tar.gz`
- `metadata/077197e6cd3ea31f33b28aaf3882a694b3423b53.json`
- `manifest.json`

The manifest deliberately uses the existing `snapshots[]` schema expected by `/tmp/pix-m7-final-profile-map-plan-20261015/assemble-profile-map.py`. After consumption root supplies that mapper the actual run's `admission-consumed.json` plus SHA256, this owner's `admission-completion-evidence.json`, and the actual custody `manifest.json` plus SHA256. The mapper reads metadata only. No archive hash, snapshot result or consumption ID is invented here.

Bounds: twoCPU slots,2GiB address space,150second soft work/180second supervisor/210second outer timeout plus15second kill allowance; unchanged13second owned-child cleanup. Each Git command allows60seconds, metadata8MiB, stderr64KiB. Tree8,192 entries, tar16,384 entries, decoded archive256MiB, per output128MiB, custody256MiB, owner64MiB, total accounted reads1GiB,64 output files/24 directories. Ordinary retention reserves512MiB, with no deletion candidates and only the new empty retention-scan root. The expected source size is64.5MB and prior comparable archives25.4MB; these bounds do not allocate those amounts or copy compiler caches. No raw tar scratch is created.

Can this be done on the VM? This is host Git source custody with no target behavior claim. It needs no physical device or provider. Root owns its issue/work-log entry and serialized allocation. Snapshot custody does not itself complete current image mapping, full-notice assembly, independent retrieval, off-host custody or publication. Existing settled dispositions remain unchanged.

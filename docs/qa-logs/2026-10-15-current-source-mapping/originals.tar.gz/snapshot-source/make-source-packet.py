from pathlib import Path
import ast,difflib,hashlib,json
P=Path('/tmp/pix-m7-distribution-snapshot-plan-20261015')
OLD=Path('/tmp/pix-m7-additive-source-custody-20261015-03')
ACCEPTED=Path('/workspace/tmp/pix-m7-additive-source-custody-20261015-01')
COMMIT='077197e6cd3ea31f33b28aaf3882a694b3423b53'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def put(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
old_input=Path('/workspace/tmp/pix-m7-final-inventory-20261015-01/profiles/sm8550-arm/inventory-inputs.json')
old_meta=Path('/workspace/artifacts/pixelelated-release-sources/m7-additive-source-20261015-01/metadata/9aa7affee9d4ad5e69725cab20b6d7ad84d93dea.json')
base=json.loads(old_input.read_text());meta=json.loads(old_meta.read_text())
assert base['distribution_commit']=='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea'
assert (len(base['source_files']),len(base['source_symlinks']))==(6560,180)
for n,h in base['source_files'].items():assert meta['entries'][n]['sha256']==h
for n,t in base['source_symlinks'].items():assert meta['entries'][n]['sha256']==hashlib.sha256(t.encode()).hexdigest()
recipe='projects/ROCKNIX/packages/network/zerotier-one/package.mk'
patch='projects/ROCKNIX/packages/network/zerotier-one/patches/001-client-without-nonfree-headers.patch'
files=dict(base['source_files']);assert files[recipe]=='8ff699da5820673e17264a160ac4a84c734ce3496a38022fbb8248b0d513b431' and patch not in files
files[recipe]='b876990db897995a230330a78704e16ad881e5424f6ff172fee9d7f2203a1aba'
files[patch]='5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5'
current=dict(schema=1,distribution_commit=COMMIT,source_files=files,source_symlinks=base['source_symlinks'],
 derivation=dict(original_source_map=ref(old_input),original_snapshot_metadata=ref(old_meta),changed=[recipe],added=[patch],
 claim='Expected exact current build-source map; runtime snapshot checks every tracked Git blob/mode/symlink against077197 before acceptance. Historical package membership is not remeasured.'))
put(P/'current-source-inputs.json',current)
oldrun=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T123133Z-e603a11c')
generic=Path('/workspace/tmp/pix-m7-zerotier-generic-readback-20261015-02')
genericrun=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03/.build-runs/20261015T163127Z-5682551e')
paths=[old_input,old_meta,oldrun/'admission-consumed.json',ACCEPTED/'collection-result.json',ACCEPTED/'collect.py',genericrun/'admission-consumed.json',generic/'artifacts/result.json',P/'current-source-inputs.json']
refs={str(p):sha(p) for p in paths}
plan=dict(schema=1,scope='One exact077197 distribution build-source snapshot; existing local custody mechanism only. No package source acquisitions or new image acceptance.',
 candidate_commit=COMMIT,publication_bundle_complete=False,binding_refs=refs,
 distribution=[dict(commit=COMMIT,input_manifest=None,source_repository='/workspace/repos/rocknix',objects='/workspace/repos/rocknix/.git/objects',
 roots=['LICENSE.md','Makefile','TRADEMARK.md','config','distributions','packages','projects','scripts'],source_files=6561,source_symlinks=180)],
 expected_tracked_blob_entries=6741,expected_blob_bytes=64485661,
 original_source_inventory=str(old_input),original_snapshot_metadata=str(old_meta),
 accepted_predecessor=dict(owner=str(ACCEPTED),run=str(oldrun),consumption_id='cb2b87b9816a4f1e987bb683fa5d53f3',collector_sha256=sha(ACCEPTED/'collect.py')),
 accepted_current_zerotier=dict(reader=str(generic),run=str(genericrun),consumption_id='ee024372b00f4314afa9fc96495b83de'),
 unresolved=['Delivery/profile assembly, existing full-notice assembly, independent retrieval and off-host custody remain separate.'])
put(P/'collection-plan.json',plan)
resources=json.loads((OLD/'resources.json').read_text())
for key in ['extra_bytes','extra_entries','extra_file_bytes']:resources.pop(key)
resources.update(archive_decoded_bytes=256*1024**2,collector_seconds=180,custody_output_ceiling_bytes=256*1024**2,git_commands=3,git_seconds=60,
 outer_seconds=210,output_directories=24,output_files=64,per_file_bytes=128*1024**2,retention_budget_bytes=512*1024**2,soft_seconds=150,total_read_bytes=1024**3,tree_entries=8192,tar_entries=16384)
put(P/'resources.json',resources)
(P/'frozen-tools.json').write_bytes((OLD/'frozen-tools.json').read_bytes())
# Preserve exact snapshot helpers; remove now unreachable archive-copy/extras paths.
source=(OLD/'templates/collect.py').read_text();head=source[:source.index('\ndef copy_archive(spec):')]
head=head.replace('Offline additive source custody;', 'Offline single distribution snapshot custody;')
main='''
try:
 assert D.parent==Path('/workspace/artifacts/pixelelated-release-sources') and D.name=='m7-distribution-snapshot-'+O.name.removeprefix('pix-m7-distribution-snapshot-') and not D.exists() and not D.is_symlink()
 for p in O.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():OUTPUT[str(O)]+=p.stat().st_size
 assert OUTPUT[str(O)]<8*1024**2
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 assert digest(PLAN['host_git']['path'],16*1024**2)==PLAN['host_git']['identity']
 assert PLAN['candidate_commit']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and len(PLAN['distribution'])==1
 inputs=load(PLAN['distribution'][0]['input_manifest'])
 assert inputs['distribution_commit']==PLAN['candidate_commit'] and len(inputs['source_files'])==6561 and len(inputs['source_symlinks'])==180
 mkdir(D)
 for n in ['distribution','metadata']:mkdir(D/n)
 mkdir(O/'scratch');mkdir(O/'empty-home')
 selected=snapshot(PLAN['distribution'][0],0,True)
 metadata=load(D/selected['metadata_member'])
 assert selected['tracked_blobs']==PLAN['expected_tracked_blob_entries']==6741 and not selected['submodules'] and not selected['lfs_pointer_paths']
 assert sum(e['bytes'] for e in metadata['entries'].values())==PLAN['expected_blob_bytes']==64485661
 assert len(CALLS)==3 and all(r['wait_observed'] and r['original_returncode']==0 for r in CALLS)
 manifest=dict(schema=1,scope=PLAN['scope'],candidate_commit=PLAN['candidate_commit'],binding_refs=PLAN['binding_refs'],snapshots=[selected],
   source_roots=PLAN['distribution'][0]['roots'],expected_source_map_sha256=digest(PLAN['distribution'][0]['input_manifest'])['sha256'],
   source_membership='Exact tracked build-source roots only; no untracked/ignored files or unrelated docs/history.',
   new_distribution_snapshots=1,new_other_sources=0,publication_bundle_complete=False,unresolved=PLAN['unresolved'])
 put(D/'manifest.json',manifest)
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 assert digest(PLAN['host_git']['path'],16*1024**2)==PLAN['host_git']['identity']
 put(O/'git-command-waits.json',CALLS)
 files=[dict(path=p,bytes=n,sha256=digest(p)['sha256']) for p,n in WRITES.items() if Path(p).is_relative_to(D)]
 assert len(files)==3
 for item in files:Path(item['path']).chmod(0o444)
 for p in sorted([Path(p) for p in DIRS if Path(p).is_relative_to(D)],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
 put(O/'collection-result.json',dict(result='COLLECTED_EXACT_DISTRIBUTION_SNAPSHOT',original_collector_exit=0,candidate_commit=PLAN['candidate_commit'],custody_path=str(D),manifest_sha256=digest(D/'manifest.json')['sha256'],files=files,
   new_distribution_snapshots=1,new_other_sources=0,tracked_blob_entries=6741,source_blob_bytes=64485661,network_used=False,target_execution=False,source_rebuild=False,publication_clearance=False,publication_bundle_complete=False,
   outputs_held=True,deleted_bytes=0,accounted_output_bytes=OUTPUT,read_bytes=READ,elapsed_seconds=time.monotonic()-START,git_commands=len(CALLS)))
 rc=0
'''
fail=source[source.index('except BaseException as exc:'):]
(P/'templates/collect.py').write_text(head+main+fail)
# Keep proven lifecycle and process identity implementation, changing predicates/scope only.
run=(OLD/'templates/run.py').read_text().replace("'profile':'additive-source-custody'","'profile':'distribution-snapshot'")
run=run.replace("report['result']=='COLLECTED_WITH_EXPLICIT_GAPS'", "report['result']=='COLLECTED_EXACT_DISTRIBUTION_SNAPSHOT'")
run=run.replace("report['archives']==4 and report['new_git_roots']==1 and report['new_distribution_snapshots']==2 and report['component_rows']==2366", "report['new_distribution_snapshots']==1 and report['new_other_sources']==0 and report['tracked_blob_entries']==6741 and report['candidate_commit']=='077197e6cd3ea31f33b28aaf3882a694b3423b53'")
run=run.replace('PASS_SOURCE_COLLECTION_WITH_GAPS','PASS_DISTRIBUTION_SNAPSHOT_CUSTODY')
run=run.replace('Additive exact source custody only;606archive/43Git-root current memberships reference preserved historical custody; generated/FEX/Nix/Tailscale/licence/retrieval/offhost/publication gaps remain; prior producer dispositions unchanged.','One exact077197 build-source snapshot only; other held sources unchanged. Delivery assembly/retrieval/offhost/publication remain separate; no current image or membership claim.')
(P/'templates/run.py').write_text(run)
(P/'templates/process-identity.py').write_bytes((OLD/'templates/process-identity.py').read_bytes())
(P/'templates/run.sh').write_text((OLD/'templates/run.sh').read_text().replace('--fsize=268435456','--fsize=134217728').replace('930s','210s'))
bind=(OLD/'templates/bindings.py').read_text()
bind=bind.replace("assert len(plan['binding_refs'])==16", "assert len(plan['binding_refs'])==9")
bind=bind.replace(" assert len(plan['archives'])==4 and sum(r['bytes'] for r in plan['archives'])==39691947\n assert plan['current_unique_archive_count']==606 and plan['current_unique_git_root_count']==43", " assert plan['candidate_commit']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and len(plan['distribution'])==1\n assert plan['distribution'][0]['commit']==plan['candidate_commit'] and plan['distribution'][0]['input_manifest']==str(O/'current-source-inputs.json')\n assert plan['expected_tracked_blob_entries']==6741 and plan['expected_blob_bytes']==64485661")
bind=bind.replace('m7-additive-source-', 'm7-distribution-snapshot-').replace('pix-m7-additive-source-custody-', 'pix-m7-distribution-snapshot-')
bind=bind.replace("removeprefix('pix-m7-distribution-snapshot-custody-')", "removeprefix('pix-m7-distribution-snapshot-')")
(P/'templates/bindings.py').write_text(bind)
prepare=(OLD/'prepare-owner.py').read_text().replace('pix-m7-additive-source-custody-', 'pix-m7-distribution-snapshot-').replace('m7-additive-source-', 'm7-distribution-snapshot-')
prepare=prepare.replace("for n in ['resources.json','frozen-tools.json']", "for n in ['resources.json','frozen-tools.json','current-source-inputs.json']")
prepare=prepare.replace(" put('collection-plan.json',plan);", " plan['distribution'][0]['input_manifest']=str(O/'current-source-inputs.json')\n plan['binding_refs'][str(O/'current-source-inputs.json')]=sha(O/'current-source-inputs.json')\n put('collection-plan.json',plan);")
prepare=prepare.replace("'exact_additive_custody_and_margin':2147483648", "'exact_one_distribution_snapshot_and_margin':536870912")
prepare=prepare.replace('1GiB new source custody plus64MiB owner ceiling, under2GiB reserved including filesystem overhead; no cache scan/deletion.', '256MiB snapshot custody plus64MiB owner ceiling, under512MiB reserved including filesystem overhead; no cache scan/deletion.')
(P/'prepare-owner.py').write_text(prepare)
commands=(OLD/'commands.sh').read_text().replace('TASK_PACKET=/tmp/pix-m7-additive-source-custody-20261015-03','TASK_PACKET=/tmp/pix-m7-distribution-snapshot-plan-20261015').replace('TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-additive-source-custody-20261015-01}','TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-distribution-snapshot-20261015-01}')
(P/'commands.sh').write_text(commands)
# Success consumer preserves all original process/result checks; only membership changes.
consume=(OLD/'templates/consume.py').read_text().replace('PASS_SOURCE_COLLECTION_WITH_GAPS','PASS_DISTRIBUTION_SNAPSHOT_CUSTODY').replace('COLLECTED_WITH_EXPLICIT_GAPS','COLLECTED_EXACT_DISTRIBUTION_SNAPSHOT')
a="assert report['archives']==4 and report['new_cache_archives']==2 and report['new_git_roots']==1 and report['new_distribution_snapshots']==2 and report['component_rows']==2366\nassert report['current_archive_count']==606 and report['current_git_root_count']==43 and "
b="assert report['new_distribution_snapshots']==1 and report['new_other_sources']==0 and report['tracked_blob_entries']==6741 and report['source_blob_bytes']==64485661\nassert report['candidate_commit']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and "
assert a in consume;consume=consume.replace(a,b).replace("len(report['files'])<=512", "len(report['files'])==3").replace("<=1024**3", "<=256*1024**2")
a="assert sha(D/'component-member-index.json')==manifest['component_index_sha256']"
b="""assert manifest['candidate_commit']==plan['candidate_commit'] and len(manifest['snapshots'])==1
snapshot=manifest['snapshots'][0];assert snapshot['commit']==plan['candidate_commit'] and snapshot['tracked_blobs']==6741 and not snapshot['submodules'] and not snapshot['lfs_pointer_paths']
assert snapshot['archive_member']=='distribution/'+plan['candidate_commit']+'.tar.gz' and snapshot['metadata_member']=='metadata/'+plan['candidate_commit']+'.json'
assert {r['path'] for r in report['files']}=={str(D/'manifest.json'),str(D/snapshot['archive_member']),str(D/snapshot['metadata_member'])}
assert sha(D/snapshot['archive_member'])==snapshot['sha256'] and sha(D/snapshot['metadata_member'])==snapshot['metadata_sha256']
metadata=load(D/snapshot['metadata_member']);assert metadata['commit']==plan['candidate_commit'] and metadata['archive_sha256']==snapshot['sha256'] and metadata['archive_bytes']==snapshot['bytes'] and len(metadata['entries'])==6741
assert sum(e['bytes'] for e in metadata['entries'].values())==64485661"""
assert a in consume;consume=consume.replace(a,b).replace("1<=len(waits)<=40", "len(waits)==3")
consume=consume.replace('Exact additive custody only; current memberships reference historical originals; all generated/prebuilt/licence/retrieval/offhost/publication gaps retained. Original previous runs unchanged.','One exact077197 distribution build-source snapshot and metadata only. Other sources and original outcomes unchanged. Mapping/delivery/retrieval/offhost/publication remain separate.')
consume=consume.replace('PASS consumed additive source custody; explicit publication gaps retained','PASS consumed exact077197 distribution snapshot; delivery remains separate')
(P/'templates/consume.py').write_text(consume)
# Preserve original proven-mechanism provenance by hashes and an exact source delta.
files=['prepare-owner.py','commands.sh','resources.json','templates/bindings.py','templates/collect.py','templates/consume.py','templates/run.py','templates/run.sh','templates/process-identity.py']
diff=''.join(''.join(difflib.unified_diff((OLD/n).read_text().splitlines(True),(P/n).read_text().splitlines(True),fromfile=str(OLD/n),tofile=str(P/n))) for n in files)
(P/'changes.diff').write_text(diff)
put(P/'source-provenance.json',dict(status='UNRUN',predecessor=str(OLD),accepted_owner=str(ACCEPTED),accepted_run=str(oldrun),accepted_consumption='cb2b87b9816a4f1e987bb683fa5d53f3',
 accepted_originals={n:ref(ACCEPTED/n) for n in ['collect.py','run.py','process-identity.py','seal.json','collection-result.json']},
 predecessor_files={n:ref(OLD/n) for n in files},scope='Only single distribution snapshot path retained; archive/extras/ES/acquisition/membership collection removed. Original lifecycle/process functions unchanged except narrow source labels and completion predicates.'))
for p in [P/'prepare-owner.py',*sorted((P/'templates').glob('*.py'))]:ast.parse(p.read_text());compile(p.read_text(),str(p),'exec',dont_inherit=True)
# Snapshot body itself is identical to the accepted mechanism.
oldfn=source[source.index('def snapshot('):source.index('\ndef copy_archive(')]
newsource=(P/'templates/collect.py').read_text();newfn=newsource[newsource.index('def snapshot('):newsource.index('\ntry:\n assert D.parent')]
assert oldfn.strip()==newfn.strip()
put(P/'static-review.json',dict(status='SOURCE_ONLY_NOT_EXECUTED',snapshot_function='Byte-identical to accepted collector',python_syntax='AST and compile only; no module execution or pyc',expected_source_files=6561,expected_symlinks=180,expected_tracked_entries=6741,expected_blob_bytes=64485661,
 actual_new_snapshot_hash=None,source_map_status='Expected map derived from accepted9aa7 metadata plus verified ZeroTier hashes; actual077197 Git-tree/archive verification is required at runtime.',runtime_or_preparer_executed=False,source_payloads_read=0,archive_payloads_read=0,cache_census=False))

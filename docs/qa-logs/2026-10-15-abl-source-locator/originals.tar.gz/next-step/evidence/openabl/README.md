# OpenABL source locator — #601

Read-only upstream intake now identifies a concrete alternative source path. ROCKNIX commit [71d8932b](https://github.com/ROCKNIX/distribution/commit/71d8932b3374d2a9e04fbc200b5779394a57dae2) switches the package, device options, SD bootloader directory and updater payload path to OpenHandheldCollective/OpenABL. It is more than an archive checksum change; the current accepted SM artifact remains unchanged.

[OpenABL v1.0](https://github.com/OpenHandheldCollective/OpenABL/releases/tag/v1.0) publishes a 102,272,376-byte source archive alongside the binaries. Its release notes explicitly identify the SM8550 binary with commit 78b81b585f0f82882e9272cead99e1d395622de5, while the other binaries use the initial commit. That distinction must survive any adoption/source mapping; neither a tag nor one generic source archive is assumed to match both without inspection.

The exact SM source [fetch script](https://github.com/OpenHandheldCollective/OpenABL/blob/78b81b585f0f82882e9272cead99e1d395622de5/Scripts/fetch.sh) pins Qualcomm edk2, microui and qtestsign commits. Its dependency fetch is conditional on those Git objects already existing. [The notice map](https://github.com/OpenHandheldCollective/OpenABL/blob/78b81b585f0f82882e9272cead99e1d395622de5/LICENSES.md) and the linked source exception identify the combined-source obligations explicitly. These files were read and Git-blob-verified; no script was executed.

This is a promising adoption candidate, not corresponding source for the existing ABL v1.2 payload. A lookup of that payload's e9d37131 implementation commit in the new repository still fails. Next evidence is actual source-archive membership against the distinct SM commit, exact binary association and updater/backup/recovery compatibility before any adoption decision. The new source archive has not been downloaded, rebuilt or boot-tested. No physical action, package change, licence clearance or new current-build gate is implied; existing #528 holds remain.

Can this be done on the VM? Public source, archive membership and updater logic can be checked on the host/VM. Signing acceptance and actual Qualcomm boot/recovery would require the separately approved device phase if adoption is selected.

Recorded 2026-10-15T12:01:52.002215+00:00. Earlier public web cache misses and local unavailable Git object reads were not successful source retrievals. The GitHub API originals and exact decoded source files are retained separately in this packet. Existing ABL1.2 source gap remains unchanged.

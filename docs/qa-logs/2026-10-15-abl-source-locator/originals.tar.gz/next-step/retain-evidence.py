from pathlib import Path
import hashlib,json,stat,subprocess,tarfile
P=Path(__file__).resolve().parent;E=P/'evidence';E.mkdir();R=Path('/workspace/repos/rocknix.worktrees/m7-player-setup');idx=[]
def store(name,b,origin):
 out=E/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);idx.append(dict(retained=str(out.relative_to(P)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),**origin))
def file(p,name):
 p=Path(p);s=p.stat();store(name,p.read_bytes(),dict(path=str(p),mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns))
base=Path('/tmp/pix-m7-abl-source-review-20261015/metadata')
for name in ['release-v1.2.json','abl-v1.2-tag.json','abl-source-tree.json','abl-release-workflow.source','abl-release-workflow.json','linuxloader-e9d37131.error','http-observations-03.json']:
 file(base/name,'selected/'+name)
file('/tmp/pix-m7-abl-archive-20261015/result.json','selected/original-archive-read.json')
file('/tmp/pix-m7-sm8550-abl-format-20261015/payload-header-readback.json','selected/original-header-read.json')
p=R/'docs/qa-logs/2026-10-15-source-scope-followup/originals.tar.gz';archive_sha=hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(p,'r:gz') as tf:
 for name in ['release-v1.0.json','old-implementation.json','old-implementation.stderr','LICENSES.md','Scripts_fetch.sh','sm8550-root-tree.json','README.md']:
  m=tf.getmember('openabl-locator/'+name);store('openabl/'+name,tf.extractfile(m).read(),dict(archive_path=str(p),archive_sha256=archive_sha,member=m.name,mode=m.mode,uid=m.uid,gid=m.gid,pax_mtime=m.pax_headers.get('mtime',str(m.mtime))))
p=R/'docs/qa-logs/2026-10-15-sm8550-abl-format/accepted/originals.tar.gz';archive_sha=hashlib.sha256(p.read_bytes()).hexdigest()
with tarfile.open(p,'r:gz') as tf:
 for name in ['owner/acceptance/artifacts/acceptance.json','owner/acceptance/artifacts/payload-equality.json']:
  m=tf.getmember(name);store('selected/'+Path(name).name,tf.extractfile(m).read(),dict(archive_path=str(p),archive_sha256=archive_sha,member=name,mode=m.mode,uid=m.uid,gid=m.gid,pax_mtime=m.pax_headers.get('mtime',str(m.mtime))))
rel='projects/ROCKNIX/packages/bootloader/rocknix-abl/package.mk'
# Exact path from frozen source, no checkout or product writes.
paths=subprocess.check_output(['git','-C',str(R),'ls-tree','-r','--name-only','9aa7affee9d4ad5e69725cab20b6d7ad84d93dea','projects/ROCKNIX/packages']).decode().splitlines();matches=[x for x in paths if x.endswith('/rocknix-abl/package.mk')];assert len(matches)==1;rel=matches[0]
b=subprocess.check_output(['git','-C',str(R),'show','9aa7affee9d4ad5e69725cab20b6d7ad84d93dea:'+rel]);store('selected/package.mk',b,dict(git_commit='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea',git_path=rel))
(P/'evidence-index.json').write_text(json.dumps(idx,indent=2)+'\n');print(json.dumps({'retained_files':len(idx),'retained_bytes':sum(r['bytes'] for r in idx),'no_source_or_binary_downloads':True}))

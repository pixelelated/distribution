#!/usr/bin/env python3
"""Exact allocated metadata lookup; no downloads of source/binaries or execution."""
from pathlib import Path
import datetime,hashlib,json,re,signal,time,urllib.error,urllib.parse,urllib.request
P=Path(__file__).resolve().parent
PLAN=Path('/tmp/pix-m7-abl-source-next-step-20261015/next-lookup.json')
EXPECTED='e9d37131c0c2273076468156fb0f87aa6834202b';CAP=524288;TOTAL=2097152
rows=[];used=0
class RefuseRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args):return None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),RefuseRedirect())
def timeout(signum,frame):raise TimeoutError('15-second total request deadline')
signal.signal(signal.SIGALRM,timeout)
def put(name,obj):
 raw=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<65536
 with (P/name).open('xb') as f:f.write(raw)
def request(url,label):
 global used
 assert len(rows)<3 and used<TOTAL
 u=urllib.parse.urlsplit(url);assert u.scheme=='https' and u.netloc=='api.github.com' and not u.username and not u.password and not u.fragment
 row=dict(number=len(rows)+1,label=label,method='GET',url=url,request_identity_sha256=hashlib.sha256(('GET '+url).encode()).hexdigest(),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),request_seconds_limit=15,response_bytes_limit=min(CAP,TOTAL-used),retry=False,redirects=False,authentication=False)
 rows.append(row);data=bytearray();start=time.monotonic();response=None
 signal.setitimer(signal.ITIMER_REAL,15)
 try:
  try:response=opener.open(urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','Accept-Encoding':'identity','User-Agent':'pixelelated-source-metadata-review'}),timeout=15)
  except urllib.error.HTTPError as e:response=e
  row['http_status']=response.code
  row['headers']={k:v for k,v in response.headers.items() if k.lower() in {'date','content-type','content-length','etag','last-modified','x-github-request-id','x-ratelimit-limit','x-ratelimit-remaining'}}
  length=response.headers.get('Content-Length');limit=row['response_bytes_limit']
  if length is not None and int(length)>limit:raise ValueError('declared response exceeds allocated cap')
  while len(data)<limit:
   chunk=response.read(min(65536,limit-len(data)))
   if not chunk:break
   data.extend(chunk)
  else:
   if length is None or len(data)!=int(length):raise ValueError('response cap reached without proven end')
  if length is not None:assert len(data)==int(length),'short response body'
  row['transport_complete']=True
 except Exception as e:row.update(error=type(e).__name__+': '+str(e),transport_complete=False)
 finally:
  signal.setitimer(signal.ITIMER_REAL,0)
  if response is not None:response.close()
  used+=len(data);assert used<=TOTAL and len(data)<=row['response_bytes_limit']
  name=f"{row['number']:02d}-{label}.body.json";b=bytes(data)
  with (P/name).open('xb') as f:f.write(b)
  row.update(body=name,bytes=len(b),body_sha256=hashlib.sha256(b).hexdigest(),elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
  put(f"{row['number']:02d}-{label}.request-result.json",row)
 if row.get('http_status')!=200 or not row['transport_complete']:return None
 try:return json.loads(data)
 except Exception as e:row['parse_error']=type(e).__name__;return None
result={'status':'INCOMPLETE','exact_commit':EXPECTED,'plan_path':str(PLAN),'plan_sha256':hashlib.sha256(PLAN.read_bytes()).hexdigest(),'source_or_binary_downloaded':False,'source_executed':False,'worldwide_absence_established':False}
try:
 search=request('https://api.github.com/search/commits?q='+EXPECTED+'&per_page=10','exact-search')
 if search is None:result['status']='SEARCH_INACCESSIBLE_OR_INVALID'
 else:
  assert isinstance(search.get('items'),list) and len(search['items'])<=10
  result['reported_total_count']=search.get('total_count');result['incomplete_results']=search.get('incomplete_results')
  matches=[x for x in search['items'] if x.get('sha')==EXPECTED];result['exact_matching_results_in_page']=len(matches)
  if search.get('incomplete_results')is not False:result['status']='SEARCH_INCOMPLETE'
  elif not matches:result['status']='NO_EXACT_MATCH_IN_BOUNDED_SEARCH'
  else:
   item=sorted(matches,key=lambda x:x['repository']['full_name'])[0];repo=item['repository']['full_name'];assert re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repo)
   result['selected_public_repository']=repo
   commit=request('https://api.github.com/repos/'+repo+'/git/commits/'+EXPECTED,'exact-commit')
   if commit is None:result['status']='MATCHED_COMMIT_INACCESSIBLE_OR_INVALID'
   else:
    assert commit['sha']==EXPECTED and re.fullmatch('[0-9a-f]{40}',commit['tree']['sha']);tree_id=commit['tree']['sha'];result['commit_tree_sha1']=tree_id
    tree=request('https://api.github.com/repos/'+repo+'/git/trees/'+tree_id,'root-tree')
    if tree is None:result['status']='ROOT_TREE_INACCESSIBLE_OR_INVALID'
    else:
     assert tree['sha']==tree_id and tree['truncated']is False and isinstance(tree['tree'],list)
     result.update(status='EXACT_PUBLIC_COMMIT_AND_ROOT_TREE_LOCATED',root_entries=len(tree['tree']),scope='Public exact locator established only; full source bytes/dependencies/notices not acquired or cleared')
except Exception as e:result.update(status='LOOKUP_REFUSED',error=type(e).__name__+': '+str(e))
result.update(requests=len(rows),response_bytes=used,requests_limit=3,response_bytes_limit=CAP,aggregate_limit=TOTAL,request_results=[{'label':r['label'],'status':r.get('http_status'),'bytes':r['bytes'],'body_sha256':r['body_sha256']} for r in rows],network_complete_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
put('result.json',result);print(json.dumps(result,indent=2))

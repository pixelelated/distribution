# Focused no-NIC proof after compiler consumption — UNRUN

The first packet's source, worker excerpts, observer, backend and four controls
are unchanged. Its independent source reviewer found no correction needed;
this is source review, not an executed PASS. Keep original outcomes, particularly
the baseline observer failure, before any cleanup or aggregate verdict.

Use the existing accepted Wi-Fi VM lifecycle in one fresh root-owned guest,
8 GiB/4 CPU, no NIC, with exact image/readback/source and executable hashes. Bind
proof source from the sealed first packet and driver binaries from the consumed
compiler artifact receipt. No listener, real Wi-Fi radio, credentials or cloud
is needed. The exported guest packet must include original per-control stdout,
stderr, result JSON, PID/start/PGID observations and adopted child wait statuses.

Within the already admitted guest, a distinct fresh output directory for each:

```bash
# These paths are supplied by the existing guest owner after byte verification.
# Do not run these commands on the host.
python3 -I -S -B "$TASK_PROOF/fixtures/observe-proof.py" \
  --binary "$TASK_DRIVER/baseline" --binary-sha256 "$TASK_BASELINE_SHA" \
  --backend-dir "$TASK_PROOF/fixtures/bin" --output "$TASK_RESULTS/baseline-explicit" --mode explicit
# Preserve original observer1 / driver0 and its pre-cleanup surviving children.
# This expected failed observation is the negative control, never rewritten0.
python3 -I -S -B "$TASK_PROOF/fixtures/observe-proof.py" \
  --binary "$TASK_DRIVER/candidate" --binary-sha256 "$TASK_CANDIDATE_SHA" \
  --backend-dir "$TASK_PROOF/fixtures/bin" --output "$TASK_RESULTS/candidate-explicit" --mode explicit
python3 -I -S -B "$TASK_PROOF/fixtures/observe-proof.py" \
  --binary "$TASK_DRIVER/candidate" --binary-sha256 "$TASK_CANDIDATE_SHA" \
  --backend-dir "$TASK_PROOF/fixtures/bin" --output "$TASK_RESULTS/candidate-atexit" --mode atexit
python3 -I -S -B "$TASK_PROOF/fixtures/observe-proof.py" \
  --binary "$TASK_DRIVER/candidate" --binary-sha256 "$TASK_CANDIDATE_SHA" \
  --backend-dir "$TASK_PROOF/fixtures/bin" --output "$TASK_RESULTS/candidate-complete" --mode complete
```

The existing guest owner must capture every command's actual return code and
continue from expected baseline1 explicitly; do not place the sequence under
an unqualified `set -e` or use `|| true`. Candidate observer/driver must be0 with
no forced cleanup or survivors. Baseline ownership cleanup may occur only after
its original failed observation is durable. A failed candidate stops acceptance.
Allocate each control20s outer, the four together120s plus30s cleanup reserve;
retain the observer's existing finite per-child deadlines. Running these target
drivers on the host is not the approved environment and may use the wrong loader.

Actual installed GUI flow remains a separate real-frontend proof. The minimum
new flow is the candidate blocked scan -> Back -> NETWORK SETTINGS -> reopen
same pending scan -> ordinary SIGINT exit. At both640x480 and1280x800, capture the
three unchanged states searching / network-settings-after-back / reopened-searching
(6 candidate frames total). Retain exact source/build/language/frame hashes and
an explicit visual review against prior accepted Back/reopen frames. Assert one
backend enumeration and the same leader/descendant PID-start identities through
Back/reopen; actual input-to-return <=1s is the proposed responsiveness ceiling.
Signal only the verified ES PID with SIGINT to exercise the existing main-loop
normal exit: scan shutdown/join <=3s, whole ES exit <=10s, original exit0, group
absent/reaped, no later saved/current backend calls, no teardown error. The guest
owner should hold subreaper custody where available and preserve adopted wait
statuses; absence alone is not a fabricated wait result.

The original packet also proposes one installed baseline blocked-scan/normal
SIGINT negative observation to establish actual frontend wiring. It should run
only once at one resolution in this fresh owner if that GUI baseline has not
already been observed; the extracted-driver negative is not a claimed main-hook
test. Preserve original failure and exact owned descendant cleanup. Do not repeat
accepted full picker/protocol/native matrices. Driver complete/atexit controls
cover completed-refresh/fallback branches; no extra presentation branches exist.
For the narrow GUI owner propose <=180s per resolution, <=600s combined work
(including the4controls) plus120s cleanup, inside the qualified lifecycle's1200s
host work envelope. These are allocation proposals pending root's guest adapter,
not executed timing measurements. No final VM adapter is supplied here.

References: `docs/es-menu-map.md` Wi-Fi flow420–492;
`docs/qa-logs/2026-10-13-setup-qualification/installed` Back/reopen frames;
`docs/qa-logs/2026-10-15-wifi-remaining-result` 24accepted branch frames /27calls;
first packet `flow-and-proof.md`. No row, label, layout or navigation change is
introduced. Coordinator adds the exact-source frame index/evidence link and
normal-whole-frontend-exit note only after acceptance. A candidate bind overlay
is explicit draft evidence; final installed-image proof requires actual final
/usr/bin/emulationstation and final readback/source binding.

D-CLOUD-133 is unchanged: SIGTERM does not become normal ES teardown. Fatal
signals, SIGKILL, _exit, escaped groups and uninterruptible tasks remain outside
this correction. `KillMode=process` is unchanged. No universal shutdown or
physical-radio/hardware proof is claimed.

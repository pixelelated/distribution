#!/usr/bin/env python3
"""Read-only metadata analysis used to author the UNRUN compiler plan; not a build entrypoint."""
from pathlib import Path
import json,hashlib,subprocess,shlex,os,re
out=Path(__file__).parent;proof=Path('/tmp/pix-m7-wifi-normal-exit-20261015')
physical=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01');inside=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated');source=Path('/home/max/Development/emulationstation-next.worktrees/m7-wifi-normal-exit-20261015')
base='3178b832b8d134198b2b4eede4f725d4ed283f8c';candidate='16dbac5211eea7e70db7394372033be2be7df829';brel=Path('build.pixelelated-GENERIC_X64.x86_64');erel=brel/'build'/('emulationstation-'+base);e=physical/erel;ec=inside/erel;cwd=ec/'.x86_64-rocknix-linux-gnu';cb=e/'.x86_64-rocknix-linux-gnu';tool=inside/brel/'toolchain/bin';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=subprocess.check_output(['git','-C',str(source),'diff','--name-only',base,candidate],text=True).splitlines();assert len(changed)==4
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
commands=json.loads((cb/'compile_commands.json').read_text());ninja=(cb/'build.ninja').read_text().splitlines()
units=['es-app/src/guis/GuiWifi.cpp','es-app/src/guis/GuiMenu.cpp','es-app/src/main.cpp'];compile=[];objects={}
for name in units:
 matches=[x for x in commands if x['file']==str(ec/name)];assert len(matches)==1;row=matches[0];argv=shlex.split(row['command']);obj=argv[argv.index('-o')+1];target='/work/'+Path(name).stem+'.o';dep='/work/'+Path(name).stem+'.d';objects[obj]=target
 assert argv[argv.index('-c')+1]==str(ec/name);assert not any(a in argv for a in ['-MD','-MF','-MT'])
 new=argv.copy();new[new.index('-o')+1]=target;new+=['-MD','-MF',dep,'-MT',target]
 compile.append({'source':name,'original':argv,'argv':new,'object':target,'dependency':dep,'label':'compile-'+Path(name).stem})
li=[i for i,l in enumerate(ninja) if ': CXX_EXECUTABLE_LINKER__emulationstation_Release ' in l];assert len(li)==1;i=li[0];edges=ninja[i].split(': ',1)[1].split(' | ',1)[0].split();linkobj=edges[1:];assert all(x in linkobj for x in objects)
v={}
for l in ninja[i+1:]:
 if not l.startswith('  '):break
 k,value=l.strip().split(' = ',1);v[k]=value
assert v['PRE_LINK']==v['POST_BUILD']==':'
original=[str(tool/'x86_64-rocknix-linux-gnu-g++')]+shlex.split(v['FLAGS'])+shlex.split(v['LINK_FLAGS'])+linkobj+['-o',v['TARGET_FILE']]+shlex.split(v.get('LINK_PATH',''))+shlex.split(v['LINK_LIBRARIES'])
link=[objects.get(x,x) for x in original];link[link.index('-o')+1]='/work/emulationstation';flag='-Wl,--dependency-file='+v['DEP_FILE'];assert link.count(flag)==1;link[link.index(flag)]='-Wl,--dependency-file=/work/link.d'
inputs={}
def resolve_host(host):
 path=Path(host);chain=[]
 for _ in range(40):
  if path.is_relative_to(inside):path=physical/path.relative_to(inside)
  path=Path(os.path.normpath(path));changed=False
  for depth in range(2,len(path.parts)+1):
   component=Path(*path.parts[:depth])
   if component.is_symlink():
    target=os.readlink(component);chain.append({'host_path':str(component),'target':target});dest=Path(target) if target.startswith('/') else component.parent/target
    path=dest.joinpath(*path.parts[depth:]);changed=True;break
  if not changed:
   assert path.is_file(),path
   return path,chain
 raise AssertionError('symlink depth')
def add(host,container=None,kind='frozen'):
 host=Path(host);container=str(container if container is not None else inside/host.relative_to(physical));resolved,chain=resolve_host(host);assert resolved.is_relative_to(physical) or resolved.is_relative_to(proof)
 inputs[(str(host),container)]={'host_path':str(host),'resolved_host_path':str(resolved),'container_path':container,'bytes':resolved.stat().st_size,'sha256':sha(resolved),'symlink_chain':chain,'kind':kind}
for name in ['build.ninja','compile_commands.json','CMakeCache.txt','CMakeFiles/rules.ninja']:add(cb/name)
for name in ['ccache','ninja','x86_64-rocknix-linux-gnu-g++','x86_64-rocknix-linux-gnu-g++-15.2.0','x86_64-rocknix-linux-gnu-strip','x86_64-rocknix-linux-gnu-readelf','x86_64-rocknix-linux-gnu-ld.bfd']:add(physical/brel/'toolchain/bin'/name)
for p in (physical/brel/'toolchain/libexec/gcc/x86_64-rocknix-linux-gnu/15.2.0').glob('*'):
 if p.is_file():add(p)
for x in original:
 if x.endswith(('.o','.a','.so')) or re.search(r'\.so\.[0-9.]+$',x):
  p=Path(x);p=p if p.is_absolute() else cwd/p;add(physical/p.relative_to(inside),p)
names=subprocess.check_output(['git','-C',str(source),'ls-tree','-r','--name-only',base],text=True).splitlines();matched=[];overlays=[]
for name in names:
 if name.startswith(('es-app/src/','es-core/src/','external/')) and (e/name).is_file():
  raw=subprocess.check_output(['git','-C',str(source),'show',base+':'+name]);assert hashlib.sha256(raw).hexdigest()==sha(e/name),name;matched.append(name)
  if name in changed:
   assert (proof/'source/candidate'/name).read_bytes()==(source/name).read_bytes()
   overlays.append({'host':str(proof/'source/candidate'/name),'container':str(ec/name),'sha256':sha(source/name),'relative':name,'baseline_sha256':sha(e/name)})
   add(proof/'source/candidate'/name,ec/name,'candidate-overlay')
  else:add(e/name)
assert len(overlays)==4
consumers=[]
for part in ['es-app','es-core']:
 for p in (source/part).rglob('*'):
  if p.is_file() and p.suffix in ('.cpp','.h','.hpp','.cc','.cxx') and re.search(r'^\s*#\s*include\s*[<"](?:guis/)?(?:GuiWifi|WifiScanProcess)\.h[>"]',p.read_text(errors='replace'),re.M):consumers.append(str(p.relative_to(source)))
assert sorted(consumers)==sorted(units)
plan={'status':'SOURCE_PREPARED_RUNTIME_UNRUN','physical_root':str(physical),'container_root':str(inside),'cwd':str(cwd),'build_root':str(inside/brel),'es_root':str(ec),'distribution_commit':'d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a','baseline_es_commit':base,'candidate_es_commit':candidate,'candidate_checkout':str(source),'changed_files':changed,'builder_image':'ghcr.io/pixelelated/build@sha256:988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39','proof_packet':str(proof),'proof_packet_seal':sha(proof/'SHA256SUMS'),'overlays':overlays,'syntax':['bash','/runner/es-syntax-check','--root',str(inside/brel),'--tree',str(ec)]+[str(ec/u) for u in units],'compile':compile,'original_link':original,'link':link,'strip':[str(tool/'x86_64-rocknix-linux-gnu-strip'),'/work/emulationstation'],'readelf':[str(tool/'x86_64-rocknix-linux-gnu-readelf'),'-h','-d','/work/emulationstation'],'fixtures':['bash','/proof/fixtures/build-fixtures.sh',str(tool/'x86_64-rocknix-linux-gnu-g++'),'/work/drivers'],'environment':{'CCACHE_DISABLE':'1','CCACHE_DIR':'/work/tmp/ccache','CCACHE_TEMPDIR':'/work/tmp','TMPDIR':'/work/tmp'},'inputs':list(inputs.values()),'static_source_comparison':{'cached_files_matching_base':len(matched),'header_consumers':sorted(consumers),'unexpected_differences':[]},'budgets':{'work_seconds':900,'cleanup_forecast_seconds':600,'memory_bytes':4*1024**3,'cpus':2,'pids':256,'scratch_bytes':1024**3},'target_placement':{'host':'<owner>/work/emulationstation','guest_draft':'private executable tmpfs; optional explicitly owned /usr/bin/emulationstation bind overlay','final':'new image actual installed /usr/bin/emulationstation; separate final image binding required'}}
(out/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(out/'input-summary.json').write_text(json.dumps({'input_count':len(inputs),'bytes_hashed':sum(x['bytes'] for x in inputs.values()),'source_comparison':plan['static_source_comparison'],'original_link_objects':len(linkobj),'candidate_objects':list(objects.values()),'original_lifecycle':'/tmp/m7-dolphin-ra-runtime-plan-20261015','unchanged_files':{n:sha(out/n) for n in ['docker_owner.py','watchdog.py']},'syntax_tool_sha256':sha(out/'es-syntax-check')},indent=2)+'\n')
print(json.dumps({'inputs':len(inputs),'bytes':sum(x['bytes'] for x in inputs.values()),'source_files':len(matched),'objects':len(linkobj)}))

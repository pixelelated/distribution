# #593 ES normal-exit compiler packet — UNRUN

This packet allocates no compiler, Docker container, fixture, listener, or VM.
Only its source authoring, static parsing, and read-only source/input comparison
have occurred. Root alone allocates execution. The sealed first proof packet
`/tmp/pix-m7-wifi-normal-exit-20261015` remains byte-identical, seal
`84e0fdd157206d39f90eb8d02e2f657110e5c7589b67c6f1f6c30272851ebf3f`.

The actual candidate is local ES commit
`16dbac5211eea7e70db7394372033be2be7df829`, based on
`3178b832b8d134198b2b4eede4f725d4ed283f8c`, in
`/home/max/Development/emulationstation-next.worktrees/m7-wifi-normal-exit-20261015`.
There is no integration, pin promotion, push, or new-image claim here.

The frozen distro/cache is
`/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01`, source
`d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a`, with ES3178. It is mounted read-only at
its generated compiler prefix `/workspace/repos/rocknix.worktrees/m7-pixelelated`.
Only the four immutable candidate source files from the sealed first packet are
mounted read-only over their exact source paths in that container. Source pin,
clean tracked state, baseline four files, candidate checkout/files, both packet
seals, and the explicit input inventory are checked before and after work.

The previous ES compiler pattern is retained in
`docs/qa-logs/2026-10-13-setup-qualification/compile/fixtures/{build,inner}.py`:
exact generated compiler commands, syntax checks, actual object builds and link.
This derivative uses the newer qualified Dolphin owner from
`/tmp/m7-dolphin-ra-runtime-plan-20261015` for admission, host PID namespace and
container PID handshake, cgroup membership, independent watchdog, original
attach/container exits, exact CID retirement, and survivor checks.
`docker_owner.py` and `watchdog.py` are byte-identical; `originals/` and `.diff`
files expose the small family, source binding, and compiler-stage adaptations.
Inherited `pix574` labels are ownership keys, not an issue attribution.

The 828 checked cache source/header files match exact ES3178. Only GuiWifi.cpp,
GuiMenu.cpp and main.cpp include either changed header; all three are rebuilt.
The 112 original link object arguments and ordered libraries, including repeats,
are preserved, replacing only those three objects. No archive is changed.
The exact original compile flags are retained; output/dependency destinations
are private. The linker output and existing linker dependency destination move
to private storage. There is no CMake reconfigure, Ninja rebuild, catalog rebuild,
whole-cache copy, shared stamp change, or dependency installation.
The plan has 967 explicitly hashed file inputs (462,458,060 bytes), including
compiler tools and baseline source. This is an explicit input basis, not a claim
that every implicit sysroot input is known in advance. Actual compiler/linker
`.d` files are retained and their surviving consumed dependencies hashed afterward.

The sole compiler stage runs, sequentially:

1. The unchanged `tools/es-syntax-check` over the three affected units, with
   `--root` bound to the frozen toolchain and `--tree` to the overlaid exact source.
2. Those three actual target object compilations, actual ES link, strip and ELF
   header/dynamic readback.
3. The unchanged first packet `build-fixtures.sh`: two target binaries,
   baseline/candidate, serving four later VM controls. No proof binary executes
   in this compiler owner. “Four controls” does not imply four identical builds.

The container uses the qualified pinned builder digest, no network, read-only
root, 4 GiB RAM/no swap, 2 CPUs, 256 PIDs, private TMPDIR/CCACHE_DIR, and disabled
ccache. One 900-second work clock covers all stages. Scratch is sampled against
1 GiB, with a 512 MiB host free-space floor. A resource or deadline violation
fails and triggers exact owned cleanup. The inherited per-operation cleanup
limits and 300-second watchdog wait remain; reserve 600 seconds after work as a
conservative forecast, not an invented global cleanup deadline. Root supervises
in short polls. Retain original failures and all launcher/wrapper/command/watch/
container/guard channels; forced cleanup cannot pass.

## Root execution commands, after exclusive allocation

Do not execute while another VM/compiler owner holds the allocation. The
repository admission lock enforces its scope; root must additionally serialize
this allocation with all independently owned runtime families. The local
family lock prevents reuse/concurrency within this owner. There is no broad
process kill or cross-owner cleanup.

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-player-setup
TASK_PACKET=/tmp/pix-m7-wifi-compile-20261015
TASK_OWNER=/workspace/tmp/pix-m7-wifi-compile-20261015-01
cd "$TASK_TREE"
python3 -I -S -B "$TASK_PACKET/plan.py" --checkout "$TASK_TREE" --owner "$TASK_OWNER"
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/stages/wifi-compile/retention-plan.json" \
  --output "$TASK_OWNER/stages/wifi-compile/retention-report.json"
# Read and consume the original report/watch results; then prepare admission.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/stages/wifi-compile/admission-plan.json" \
  --output "$TASK_OWNER/stages/wifi-compile/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/stages/wifi-compile/submit" -- \
  --admission "$TASK_OWNER/stages/wifi-compile/admission.json" \
  --activity-dir "$TASK_OWNER/stages/wifi-compile/logs" -- \
  python3 -I -S -B "$TASK_PACKET/run-stage.py" \
  --checkout "$TASK_TREE" --owner "$TASK_OWNER" --stage wifi-compile
```

A genuinely fresh owner is mandatory. These commands are launch-ready source,
not proof that preparation/admission succeeds. The host must expose the actual
host PID namespace, existing Docker daemon and already cached pinned builder;
no pull is allowed. A missing cache dependency fails this owner; do not rebuild
or edit the frozen cache to hide it. Root reviews the original result and uses
the existing `build-admission consume` receipt schema after verifying all exits,
exact CID/process absence, OOM counters, source/input readback and artifacts.

Successful output placement is `<owner>/work/emulationstation` and
`<owner>/work/drivers/{baseline,candidate}`. Exact identities, size, source commits
and proof seal appear in `stages/wifi-compile/target-artifact.json`.
The target is an actual ES executable rebuilt from the candidate source delta;
it is not an installed new-image binary. Keep it only for the next accepted
source-bound proof, then retain compact originals and source custody before any
separately guarded scratch retirement. No automatic media cleanup is included.

## Focused VM dependency and limits

See `vm-proof-plan.md`. Before allocating, root records on #593:
“Can this be done on the VM? Yes: process ownership and normal frontend teardown
need no physical radio, provider, or hardware fact.” The compiler owner must be
fully closed and consumed first. The new VM owner must preserve existing no-NIC,
serial, executable/process identity, selected-state custody, exit and export
controls. The plan does not launch a VM or create a replacement generic runner.

A future image with ES16dbac must bind final source, image readback and the actual
installed executable. A temporary owned installed-path bind of this candidate
can prove the candidate GUI/main flow; record it as an overlay and retain the
underlying original executable hash. It cannot satisfy final installed-image
acceptance by relabeling the overlay. Hardware/radio behavior remains unclaimed.

#!/usr/bin/env python3
"""UNRUN preparation for one separately admitted ES compile/link; allocates no compute."""
import argparse,re,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import DISK_LIMIT,HERE,read,require,sha,verify_packet,write

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--owner',type=Path,required=True);p.add_argument('--checkout',type=Path,required=True);a=p.parse_args()
 owner=a.owner;tree=a.checkout;stage=owner/'stages/wifi-compile'
 require(re.fullmatch('/workspace/tmp/[A-Za-z0-9_-]+',str(owner)) and owner.resolve()==owner,'real new owner required')
 require(tree.is_absolute() and tree.resolve()==tree,'absolute real coordinator required');verify_packet(HERE)
 binding=read(HERE/'build-plan.json');seal=sha(HERE/'SHA256SUMS');owner.mkdir(mode=0o700)
 for name in ['work','work/tmp','stages','stages/wifi-compile','stages/wifi-compile/scan','stages/wifi-compile/logs','stages/wifi-compile/submit']:(owner/name).mkdir()
 write(owner/'family.json',{'family':'wifi','checkout':str(tree),'runner_manifest_sha256':seal})
 outputs=[{'path':str(owner/'work'),'issue':593,'kind':'build-cache','release_when':'After source-bound candidate VM proof, retain binary/source/dependency hashes and original result channels.'},{'path':str(owner/'stages'),'issue':593,'kind':'qa-scratch','release_when':'After original watcher/container/cleanup receipts are sealed.'}]
 write(stage/'retention-plan.json',{'volume':'/workspace','scan_roots':[str(stage/'scan')],'reference_stores':[],'protected':[str(HERE),binding['physical_root'],binding['candidate_checkout'],binding['proof_packet']],'candidates':[],'builds':[{'name':'m7-wifi-normal-exit-compile','terms_bytes':{'selected_family_scratch_ceiling':DISK_LIMIT},'basis':'Three affected ES objects and exact link; syntax check and two target drivers for four later VM controls. Frozen cache read-only plus four immutable candidate source-file overlays. One900s stage,4GiB2CPU256PIDs,1GiB sampled scratch. No executable tests or cache copy.','evidence':[{'path':str(HERE/'build-plan.json'),'sha256':sha(HERE/'build-plan.json')}]}]})
 write(stage/'admission-plan.json',{'checkout':str(tree),'retention_plan':str(stage/'retention-plan.json'),'retention_report':str(stage/'retention-report.json'),'stage':'m7-wifi-normal-exit-compile','profiles':[{'PROJECT':'ROCKNIX','DEVICE':'GENERIC_X64','ARCH':'x86_64'}],'outputs':outputs})
 write(stage/'selection.json',{'stage':'wifi-compile','owner':str(owner),'runner_manifest_sha256':seal,'sealed_manifest_sha256':seal})
 print(stage/'admission-plan.json')
if __name__=='__main__':main()

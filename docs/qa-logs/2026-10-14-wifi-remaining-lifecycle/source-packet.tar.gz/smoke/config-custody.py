#!/usr/bin/python3
"""Own disposable guest configuration custody; no values in the JSON receipt."""
import hashlib,json,shutil,sys,tarfile
from pathlib import Path
R=Path('/storage');Q=R/'qa570flows';NAMES=['.config/system/configs','.config/emulationstation/es_settings.cfg']
def inventory():
 rows={}
 def visit(p):
  key=str(p.relative_to(R));s=p.lstat();entry={'mode':oct(s.st_mode&0o777)}
  if p.is_symlink():entry.update(type='link',target=str(p.readlink()))
  elif p.is_file():entry.update(type='file',sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
  elif p.is_dir():
   entry['type']='directory'
   for child in sorted(p.iterdir()):visit(child)
  else:raise RuntimeError('unexpected configuration entry type')
  rows[key]=entry
 for n in NAMES:
  p=R/n
  if p.exists() or p.is_symlink():visit(p)
 return rows
if sys.argv[1]=='snapshot':
 assert not (Q/'original-config.tar').exists()
 facts=inventory()
 with tarfile.open(Q/'original-config.tar','w') as t:
  for n in NAMES:
   if n in facts:t.add(R/n,arcname=n)
 (Q/'original-config.json').write_text(json.dumps(facts,indent=2)+'\n')
 print('PASS private original configuration captured')
elif sys.argv[1]=='restore':
 facts=json.loads((Q/'original-config.json').read_text())
 # Validate complete own backup before any restoration mutation.
 with tarfile.open(Q/'original-config.tar') as t:
  assert set(t.getnames())==set(facts)
  for n in NAMES:
   p=R/n
   if p.is_symlink() or p.is_file():p.unlink()
   elif p.is_dir():shutil.rmtree(p)
  t.extractall(R,filter='fully_trusted')
 after=inventory();assert after==facts,'original config bytes/types/modes differ'
 (Q/'configuration-restored.json').write_text(json.dumps({'status':'PASS','entries':len(facts),'original_manifest_sha256':hashlib.sha256((Q/'original-config.json').read_bytes()).hexdigest()},indent=2)+'\n')
 print('PASS original configuration bytes/types/modes restored')
else:raise SystemExit(2)

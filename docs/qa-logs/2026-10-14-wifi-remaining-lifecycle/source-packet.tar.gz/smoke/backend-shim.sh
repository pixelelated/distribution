# Sourced only by the observer's hash-bound installed wifictl child.
# No product/profile edit; no replacement sleeps or settings functions.
ls() {
  if [[ "$#" == 1 && "$1" == /sys/class/net ]]; then printf '%s\n' wlan577;
  else command ls "$@"; fi
}
function [() {
  if [[ $# == 3 && "$1" == -d && "$2" == /sys/class/net/wlan577 && "$3" == ']' ]]; then return 0;
  elif [[ $# == 4 && "$1" == '!' && "$2" == -d && "$3" == /sys/class/net/wlan577 && "$4" == ']' ]]; then return 1;
  else builtin [ "$@"; fi
}
iwctl() { /usr/bin/python3 -I -S -B /storage/qa-wifi-577-followup/backend.py iwctl "$@"; }
iw() { /usr/bin/python3 -I -S -B /storage/qa-wifi-577-followup/backend.py iw "$@"; }
nmcli() { /usr/bin/python3 -I -S -B /storage/qa-wifi-577-followup/backend.py nmcli "$@"; }

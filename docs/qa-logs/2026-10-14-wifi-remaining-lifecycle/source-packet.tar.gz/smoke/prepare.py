#!/usr/bin/env python3
"""Bind a fresh source-only derivative to the completed final SYSTEM receipt."""
import argparse,ast,hashlib,json,re,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
MEMBERS=['usr/bin/emulationstation','usr/bin/wifictl','etc/profile','etc/profile.d/001-functions','usr/config/locale/fr/LC_MESSAGES/emulationstation2.mo','usr/config/locale/en_GB/LC_MESSAGES/emulationstation2.mo']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--image-verification',type=Path,required=True);p.add_argument('--ssh-command',type=Path,required=True);p.add_argument('--monitor',type=Path,required=True);p.add_argument('--playwright-python',type=Path,required=True);p.add_argument('--chromium',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--expected-source',required=True);p.add_argument('--expected-es',required=True);a=p.parse_args()
 report=json.loads(a.image_verification.read_text());assert re.fullmatch('[0-9a-f]{40}',a.expected_source) and re.fullmatch('[0-9a-f]{40}',a.expected_es)
 assert report['status']=='PASS' and report['source']==a.expected_source and report['es_commit']==a.expected_es
 members={x:report['products'][x] for x in MEMBERS}
 ssh=json.loads(a.ssh_command.read_text());assert isinstance(ssh,list) and ssh[0]=='ssh' and ssh[-1]=='root@127.0.0.1'
 assert a.playwright_python.is_file() and a.chromium.is_file();assert not a.out.exists()
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert digest(HERE/n)==h,n
 for name,h in json.loads((HERE/'dependencies.json').read_text()).items():assert digest(Path(name))==h,name
 a.out.mkdir(mode=0o700);(a.out/'vm').mkdir();(a.out/'vm/monitor.sock').symlink_to(a.monitor.resolve());(a.out/'ssh-command.json').write_text(json.dumps(ssh)+'\n')
 for x in ['run.py','common.py','config-custody.py','wifi-followup.py','backend.py','backend-shim.sh']:
  shutil.copyfile(HERE/x,a.out/x)
 (a.out/'binding.json').write_text(json.dumps({'status':'PREPARED_UNRUN','source':report['source'],'es_source':report['es_commit'],'members':members,'verification':{'path':str(a.image_verification.resolve()),'sha256':digest(a.image_verification)},'playwright_python':str(a.playwright_python.absolute()),'chromium':str(a.chromium.resolve()),'chromium_sha256':digest(a.chromium),'seams':['wifictl observer bind runs byte-identical installed copy with real profile/settings; BASH_ENV supplies only synthetic adapter/iwctl/nmcli; natural sleeps and original status retained; no radio claim']},indent=2)+'\n')
 print(str(a.out/'run.py'))
if __name__=='__main__':main()

from pathlib import Path
import base64,json,os,shlex,signal,subprocess,time,uuid
R=Path(__file__).resolve().parent
SSH=json.loads((R/'ssh-command.json').read_text())
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def command(label,args,seconds=30,data=None,directory=None):
 dest=directory or R/'commands';dest.mkdir(exist_ok=True);stem=dest/(label+'-'+uuid.uuid4().hex[:8]);row={'argv':list(map(str,args)),'started':time.time(),'original_returncode':None,'timed_out':False};child=None
 try:
  with Path(str(stem)+'.stdout').open('xb') as out,Path(str(stem)+'.stderr').open('xb') as err:
   child=subprocess.Popen(row['argv'],stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);row['pid']=child.pid
   try:child.communicate(input=data,timeout=seconds)
   except subprocess.TimeoutExpired:
    row['timed_out']=True
    if child.poll() is None:
     try:
      with_pid=os.pidfd_open(child.pid)
      try:signal.pidfd_send_signal(with_pid,signal.SIGKILL)
      finally:os.close(with_pid)
     except ProcessLookupError:pass
    child.communicate(timeout=5)
   row['original_returncode']=child.wait()
 finally:
  row['ended']=time.time();write(Path(str(stem)+'.json'),row)
 assert row['original_returncode']==0 and not row['timed_out'],str(stem)
 return Path(str(stem)+'.stdout').read_text()
def remote(label,text,seconds=30,data=None):return command(label,SSH+[text],seconds,data)
def guest(label,code,seconds=30):return remote(label,'python3 -I -S -B -c '+shlex.quote(code),seconds)
def upload(name,dest):return remote('upload-'+name,'cat > '+shlex.quote(dest),data=(R/name).read_bytes())
def facts():
 return json.loads(guest('facts',"import json,hashlib,subprocess;from pathlib import Path;p=int(subprocess.check_output(['pidof','emulationstation']));print(json.dumps({'boot':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'pid':p,'start':Path('/proc',str(p),'stat').read_text().rsplit(')',1)[1].split()[19],'es_sha256':hashlib.file_digest(Path('/proc',str(p),'exe').open('rb'),'sha256').hexdigest()}))"))
def idle():
 end=time.monotonic()+40
 while time.monotonic()<end:
  answer=remote('idle',"curl -fsS --max-time 2 http://127.0.0.1:1234/isIdle 2>/dev/null || true")
  if answer.replace(' ','').strip()=='[true]':return
  time.sleep(.4)
 raise AssertionError('frontend readiness')

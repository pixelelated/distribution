#!/usr/bin/python3
"""Synthetic lower transport + recorder around byte-identical installed wifictl."""
import fcntl,hashlib,json,os,subprocess,sys,time,uuid
from pathlib import Path
R=Path('/storage/qa-wifi-577-followup')
def save(p,d):
 t=p.with_name(p.name+'.'+uuid.uuid4().hex+'.new');t.write_text(json.dumps(d,indent=2)+'\n');os.replace(t,p)
def escaped(s):return s.replace('\\','\\\\').replace(':','\\:')
def event(d):
 d.update(pid=os.getpid(),monotonic_ns=time.monotonic_ns())
 with (R/'events.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
def nmcli(a,s,scan):
 profiles=s['profiles'];active=s.get('active_profile','');current=next((p['ssid'] for p in profiles if p['name']==active),'')
 if a in [['-w','15','dev','wifi','rescan','ifname','wlan577'],['dev','wifi','rescan','ifname','wlan577']]:return '',0
 if a==['-t','-f','SSID','dev','wifi','list','ifname','wlan577']:
  assert scan is not None,'enumeration outside owned scan'
  return ''.join(escaped(x)+'\n' for x in scan['networks']),scan.get('rc',0)
 if a==['-t','-f','ACTIVE,SSID','device','wifi','list','ifname','wlan577','--rescan','no']:return ('yes:'+escaped(current)+'\n' if current else ''),0
 if a==['-t','-f','NAME,TYPE,ACTIVE','connection','show']:return ''.join(escaped(p['name'])+':802-11-wireless:'+('yes' if p['name']==active else 'no')+'\n' for p in profiles),0
 if a==['-t','-f','NAME,TYPE','connection','show']:return ''.join(escaped(p['name'])+':802-11-wireless\n' for p in profiles),0
 if a==['-t','-f','GENERAL.CONNECTION','device','show','wlan577']:return 'GENERAL.CONNECTION:'+escaped(active)+'\n',0
 if len(a)==8 and a[:4]==['--escape','no','-g','802-11-wireless.ssid'] and a[4:7]==['connection','show','id']:
  p=next((p for p in profiles if p['name']==a[7]),None);return (p['ssid']+'\n',0) if p else ('',10)
 if a[:5]==['--escape','no','-s','-g','802-11-wireless-security.psk'] and len(a)==9 and a[5:8]==['connection','show','id']:
  assert any(p['name']==a[8] for p in profiles);return '',0 # synthetic open profile, no credential
 if a[:4]==['--escape','no','-g','802-11-wireless-security.key-mgmt'] and len(a)==8 and a[4:7]==['connection','show','id']:
  assert any(p['name']==a[7] for p in profiles);return '',0
 if len(a)==5 and a[:2]==['connection','modify'] and a[3]=='connection.autoconnect-priority':
  assert any(p['name']==a[2] for p in profiles) and a[4] in ['0','100'];s.setdefault('priorities',{})[a[2]]=a[4];return '',0
 if len(a)==4 and a[:3]==['connection','delete','id']:
  assert any(p['name']==a[3] for p in profiles);s['profiles']=[p for p in profiles if p['name']!=a[3]]
  if active==a[3]:s['active_profile']=''
  s.setdefault('deletions',[]).append(a[3]);return '',0
 if a==['-t','-f','SSID,SECURITY','device','wifi','list','ifname','wlan577','--rescan','no']:
  return ''.join(escaped(x)+':unrecognized\n' for x in s['view']['networks']),0
 raise AssertionError('unexpected synthetic nmcli argv: '+repr(a))
def main():
 assert (R/'ALLOW-SYNTHETIC-WIFI').read_text()=='577\n';operation=sys.argv[1];args=sys.argv[2:]
 with (R/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);s=json.loads((R/'state.json').read_text());plan=json.loads((R/'plan.json').read_text())
  if operation=='wrapper':
   assert args and args[0] in ['list','scanlist','saved','current','join','forget','security','has_ap_mode']
   ident=uuid.uuid4().hex;row={'id':ident,'args':args,'started':time.time(),'original_returncode':None,'phase':s['phase']}
   index=None
   if args[0] in ['list','scanlist']:
    index=s.get('next_scan',0);assert index<len(plan['scans']),'unexpected extra scan';s['next_scan']=index+1;save(R/'state.json',s)
   row['scan_index']=index;save(R/'calls'/(ident+'.start.json'),row)
  else:
   index=os.environ.get('QA577_SCAN_INDEX');scan=plan['scans'][int(index)] if index is not None else None
   if operation=='nmcli':out,rc=nmcli(args,s,scan)
   elif operation=='iwctl' and args==['device','list']:out,rc='wlan577\n',0
   elif operation=='iwctl' and len(args)==3 and args[0]=='adapter' and args[2]=='show':out,rc='',1
   elif operation=='iw' and len(args)==3 and args[:2]==['reg','set']:out,rc='',0
   else:raise AssertionError('unexpected lower transport')
   event({'phase':s['phase'],'operation':operation,'args':args,'stdout':out,'original_returncode':rc});save(R/'state.json',s)
   sys.stdout.write(out);return rc
 original=R/'wifictl-installed';expected=json.loads((R/'installed-copy.json').read_text())
 assert hashlib.sha256(original.read_bytes()).hexdigest()==expected['sha256']
 env=dict(os.environ,BASH_ENV=str(R/'backend-shim.sh'));env.pop('QA577_SCAN_INDEX',None)
 if index is not None:env['QA577_SCAN_INDEX']=str(index)
 # Inherit WifiScanProcess's process group and actual product deadlines.
 # If the UI deadline kills the group, absent completion remains a failure.
 with (R/'calls'/(ident+'.stdout')).open('xb') as out,(R/'calls'/(ident+'.stderr')).open('xb') as err:
  child=subprocess.Popen(['/bin/bash',str(original),*args],stdout=out,stderr=err,env=env);row['child_pid']=child.pid;save(R/'calls'/(ident+'.start.json'),row)
  row['original_returncode']=child.wait()
 row['ended']=time.time();save(R/'calls'/(ident+'.result.json'),row) # before returning any verdict/output
 with (R/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);s=json.loads((R/'state.json').read_text())
  if index is not None and row['original_returncode']==0:s['view']=plan['scans'][index];save(R/'state.json',s)
 data=(R/'calls'/(ident+'.stdout')).read_bytes();err=(R/'calls'/(ident+'.stderr')).read_bytes();assert len(data)+len(err)<=65536
 sys.stdout.buffer.write(data);sys.stderr.buffer.write(err)
 return row['original_returncode'] if row['original_returncode']>=0 else 128-row['original_returncode']
if __name__=='__main__':
 try:sys.exit(main())
 except BaseException as e:
  if isinstance(e,SystemExit):raise
  event({'operation':'fixture-error','type':type(e).__name__,'error':str(e)});raise

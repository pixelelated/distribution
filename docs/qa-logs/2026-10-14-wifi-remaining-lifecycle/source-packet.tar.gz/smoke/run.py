#!/usr/bin/env python3
"""Owned final-image #577 continuation; existing lifecycle owns hard deadline."""
import base64,hashlib,json,stat,time,traceback
from pathlib import Path
from common import R,command,remote,guest,upload,write,idle
B=json.loads((R/'binding.json').read_text());Q='/storage/qa-wifi-577-followup';C='/storage/qa570flows'
assert not (R/'result.json').exists(),'fresh result required'
result={'status':'FAIL','started':time.time(),'stages':[]};prepared=False;backup=False;bound=False

def persist():write(R/'result.json',result)
def products():
 code="import hashlib,json,stat;from pathlib import Path;b=json.loads(Path('"+C+"/binding.json').read_text());print(json.dumps({n:{'sha256':hashlib.file_digest((Path('/')/n).open('rb'),'sha256').hexdigest(),'mode':stat.filemode((Path('/')/n).stat().st_mode)} for n in b['members']}))"
 facts=json.loads(guest('products',code));assert all(facts[n]['sha256']==v['sha256'] and facts[n]['mode']==v['mode'] for n,v in B['members'].items());return facts

def export():
 code="""import base64,json
from pathlib import Path
r=Path('/storage/qa-wifi-577-followup');rows={};total=0
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 name=str(p.relative_to(r))
 if not (name in ['state.json','plan.json','events.jsonl','installed-copy.json'] or p.parent==r/'calls'):continue
 assert p.stat().st_size<=1024**2;total+=p.stat().st_size;assert total<=8*1024**2
 rows[name]=base64.b64encode(p.read_bytes()).decode()
assert len(rows)<=512;print(json.dumps(rows))
"""
 rows=json.loads(guest('export-backend',code));dest=R/'backend-originals';dest.mkdir();manifest=[]
 for name,value in rows.items():
  p=Path(name);assert not p.is_absolute() and '..' not in p.parts
  target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(value,validate=True);target.write_bytes(raw);manifest.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 write(dest/'manifest.json',manifest);result['backend_export']={'files':len(manifest),'bytes':sum(x['bytes'] for x in manifest)}

def check_quiescent():
 code="""import json
from pathlib import Path
r=Path('/storage/qa-wifi-577-followup');starts={p.name.split('.')[0] for p in (r/'calls').glob('*.start.json')};ends={p.name.split('.')[0] for p in (r/'calls').glob('*.result.json')};live=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:args=(p/'cmdline').read_bytes().split(b'\\0')
 except (FileNotFoundError,ProcessLookupError):continue
 if any(a in [str(r/'backend.py').encode(),str(r/'wifictl-installed').encode()] for a in args):live.append(int(p.name))
print(json.dumps({'starts':len(starts),'ends':len(ends),'missing_completion':sorted(starts-ends),'live':live}))
"""
 facts=json.loads(guest('backend-quiescence',code));write(R/'backend-quiescence.json',facts);assert not facts['live'] and not facts['missing_completion']
try:
 assert remote('fresh',"test ! -e "+C+" && test ! -e "+Q+" && echo fresh").strip()=='fresh'
 assert remote('idle-broker','cloud_oauth status').strip()=='idle'
 remote('mkdir','mkdir -m700 '+C+' '+Q+' '+Q+'/calls');prepared=True
 for name in ['binding.json','config-custody.py']:upload(name,C+'/'+name)
 remote('snapshot','python3 -I -S -B '+C+'/config-custody.py snapshot');backup=True
 result['before']=products();assert not guest('preexisting-mount-refusal',"from pathlib import Path;print(''.join(l for l in Path('/proc/self/mountinfo').read_text().splitlines() if l.split()[4]=='/usr/bin/wifictl'))").strip();result['boot_id']=remote('boot','cat /proc/sys/kernel/random/boot_id').strip()
 for name in ['backend.py','backend-shim.sh']:upload(name,Q+'/'+name)
 remote('installed-copy','cp -p /usr/bin/wifictl '+Q+'/wifictl-installed')
 expected=B['members']['usr/bin/wifictl'];assert remote('copy-hash','sha256sum '+Q+'/wifictl-installed').split()[0]==expected['sha256']
 remote('copy-receipt','cat > '+Q+'/installed-copy.json',data=(json.dumps({'origin':'/usr/bin/wifictl','sha256':expected['sha256'],'mode':expected['mode'],'copy_byte_identical':True,'source_modified':False})+'\n').encode())
 remote('marker','printf "577\\n" > '+Q+'/ALLOW-SYNTHETIC-WIFI')
 wrapper='#!/bin/sh\nexec /usr/bin/python3 -I -S -B '+Q+'/backend.py wrapper "$@"\n'
 remote('wrapper','cat > '+Q+'/wifictl-observer',data=wrapper.encode())
 bound=True
 remote('bind','set -e; chmod 755 '+Q+'/wifictl-observer; mount --bind '+Q+'/wifictl-observer /usr/bin/wifictl; mount --make-private /usr/bin/wifictl')
 mountinfo=guest('mountinfo',"from pathlib import Path;print(''.join(l+'\\n' for l in Path('/proc/self/mountinfo').read_text().splitlines() if l.split()[4]=='/usr/bin/wifictl'))");(R/'owned-mount.txt').write_text(mountinfo);assert len(mountinfo.splitlines())==1
 row={'name':'missing-wifi-cases','started':time.time(),'timed_out':False,'original_returncode':None};result['stages'].append(row);persist()
 try:
  command('missing-wifi-cases',['python3','-B',R/'wifi-followup.py'],450)
  row['original_returncode']=0
 except BaseException:
  # common retained exact wait/timeout status before raising; copy the actual row.
  receipts=list((R/'commands').glob('missing-wifi-cases-*.json'));assert len(receipts)==1
  actual=json.loads(receipts[0].read_text());row.update(original_returncode=actual['original_returncode'],timed_out=actual['timed_out']);raise
 finally:row['ended']=time.time();persist()
 assert json.loads((R/'wifi-followup/result.json').read_text())['rc']==0
 assert remote('same-boot','cat /proc/sys/kernel/random/boot_id').strip()==result['boot_id'];result['status']='PASS'
except BaseException as e:result['error']=type(e).__name__+': '+str(e);traceback.print_exc()
finally:
 if prepared:
  try:
   remote('stop-es-cleanup','systemctl stop essway.service',60)
   # Read/export original lower and installed-script results even after failure.
   export();check_quiescent()
  except BaseException as e:result['backend_cleanup_error']=str(e);result['status']='FAIL';traceback.print_exc()
  try:
   if bound:
    present=guest('owned-mount-present',"from pathlib import Path;print(sum(l.split()[4]=='/usr/bin/wifictl' for l in Path('/proc/self/mountinfo').read_text().splitlines()))").strip();assert present in ['0','1']
    if present=='1':remote('unbind','umount /usr/bin/wifictl')
   result['restored_products']=products()
   assert not guest('mounts-absent',"from pathlib import Path;print(''.join(l for l in Path('/proc/self/mountinfo').read_text().splitlines() if l.split()[4]=='/usr/bin/wifictl'))").strip()
   if backup:
    remote('restore','python3 -I -S -B '+C+'/config-custody.py restore');write(R/'configuration-restored.json',json.loads(remote('restore-result','cat '+C+'/configuration-restored.json')))
   remote('start-es-cleanup','systemctl start essway.service',60);idle();result['cleanup']='PASS'
  except BaseException as e:result['cleanup_error']=str(e);result['status']='FAIL';traceback.print_exc()
 result['ended']=time.time();persist()
raise SystemExit(0 if result['status']=='PASS' else 1)

from pathlib import Path
import hashlib,json,subprocess,sys,os,shutil
P=Path('/tmp/pix-m7-notice-delivery-plan-20261015');R=Path('/tmp/pix-m7-notice-delivery-coordinator-20261015');R.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'SHA256SUMS')=='5f15e01d01eb18665e5fcd818a3281f4745f26d3a802c7513ae38d2e0b69969f'
for ln in (P/'SHA256SUMS').read_text().splitlines():h,n=ln.split('  ',1);assert sha(P/n)==h,n
stage=sys.argv[1];assert stage in ['prepare','preflight','report','admit','launch','consume'];env=os.environ.copy()
cmd=['bash',str(P/'commands.sh'),stage]
with (R/(stage+'.stdout')).open('xb') as out,(R/(stage+'.stderr')).open('xb') as err:p=subprocess.run(cmd,env=env,stdout=out,stderr=err)
(R/(stage+'.exit.json')).write_text(json.dumps({'original_tool_exit':p.returncode,'argv':cmd})+'\n');print(json.dumps({'stage':stage,'original_tool_exit':p.returncode,'stdout':str(R/(stage+'.stdout'))}));raise SystemExit(p.returncode)

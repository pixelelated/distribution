#!/usr/bin/env python3
"""Read only finite held metadata; prepare additive exact notice selection, never payloads."""
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;INPUTS={};FILES={};ROWS=[];READ=0
BASE_ROOT=Path('/workspace/artifacts/pixelelated-release-sources/m7-delivery-source-20261015-01')
OWNER=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-04')
def load(p):
 global READ
 p=Path(p);assert p.stat().st_size<16*1024**2
 raw=p.read_bytes();READ+=len(raw);assert READ<64*1024**2
 INPUTS[str(p)]=dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());return json.loads(raw)
def put(n,o):(P/n).write_text(json.dumps(o,sort_keys=True,indent=2)+'\n')
base=load(BASE_ROOT/'manifest.json');catalog={r['sha256']:r for r in base['objects']};assert len(catalog)==1869
current=load('/workspace/tmp/pix-m7-final-profile-map-20261015-01/current-profile-source-map.json');keys={r['profile']+':'+r['component'] for r in current['components']}
def components(component):
 if component=='idtech-lr/doom.wad':return [k for k in sorted(keys) if k.endswith(':idtech-lr') and k.split(':')[0] in ['h700-aarch64','sm8550-aarch64']]
 return [k for k in sorted(keys) if k.endswith(':'+component)]
def add(path,h,n,role,association=None):
 assert len(h)==64 and type(n)is int and 0<=n<16*1024**2
 if h in catalog:
  assert catalog[h]['bytes']==n;ref=dict(bundle='base',**catalog[h])
 else:
  if h not in FILES:FILES[h]=dict(member='objects/'+h,sha256=h,bytes=n,source_paths=[str(path)],roles=[role])
  else:
   assert FILES[h]['bytes']==n
   if role not in FILES[h]['roles']:FILES[h]['roles'].append(role)
  ref=dict(bundle='supplement',member='objects/'+h,sha256=h,bytes=n)
 if association:ROWS.append(dict(association,notice=ref,role=role))
 return ref
# Exact named current notice rebindings from the already held small projection.
remaining=Path('/tmp/pix-m7-remaining-notice-disposition-20261015');summary=load(remaining/'retained-record-summary.json')
projection=[]
for r in summary['records']:
 if r['component']=='zerotier-one':continue
 projection.append({k:r[k] for k in ['component','profile','record','selected_identity','notice_rebindings']})
 for n in r['notice_rebindings']:
  c=n.get('current') or {};t=c.get('retained_text')
  if not t:continue
  add(OWNER/t['retained'],t['sha256'],t['bytes'],'current-notice-rebinding',dict(component=r['component'],profiles=[r['profile']],relative=c['relative'],original_record=r['record'],original_rebinding_status=n['status'],empty_not_coverage=t.get('empty',False)))
libs=Path('/tmp/pix-m7-notice-disposition-20261015');coverage=load(libs/'coverage-map.json')
for h,r in coverage['notice_index'].items():
 for a in r['logical_members']:
  add(libs/r['retained'],h,r['bytes'],'accepted-four-library-notice',dict(component=a['component'],profiles=[a['profile']],relative=a['relative'],source_path_provenance=a['source_path'],empty_not_coverage=r['bytes']==0))
# Complete already rendered vendor notices plus separately attributed full LGPLs.
f=Path('/tmp/pix-m7-freej2me-vendor-notices-20261015');fm=load('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-freej2me-vendor-notices/members.json')
held={r['original_path']:r for r in fm['members'] if r['kind']=='file'}
for name in ['NOTICE-TEXTS.txt','supplemental-license-texts/LGPL-2','supplemental-license-texts/LGPL-2.1']:
 p=f/name;r=held[str(p)];add(p,r['sha256'],r['bytes'],'complete-FreeJ2ME-vendor-notice-or-supplement',dict(component='freej2me-lr',profiles=[k.split(':')[0] for k in components('freej2me-lr')],relative=name,source_archive_sha256='509c3590827c8556cc0f8ff42c22693dd40e99e01e15f8f5c0e2e00bdbd8c130',scope='49 exact complete header blocks/103 references; local LGPL texts separately attributed. Full vendor source is already in the delivered source archive.'))
for name in ['notice-block-index.json','profile-bindings.json','archive-binding.json','supplemental-license-provenance.json','readback.json','execution-observation.json']:load(f/name)
# Reuse accepted named shader notice contexts, not the full7187-text collector corpus.
sh=Path('/tmp/pix-m7-shader-notice-disposition-20261015');e=load(sh/'evidence-text-index.json')
a=Path('/workspace/tmp/pix-m7-shader-attribution-20261015-02/attribution');texts=load(a/'texts.json');sources=load(a/'sources.json');notices=load(a/'notices.json')
selected_shader=[];omitted_context=[]
for r in e:
 t=texts[r['sha256']]
 if not (t['document'] or t['candidates']):omitted_context.append(dict(sha256=r['sha256'],bytes=r['bytes'],reason='No notice/document candidate in accepted text classification; source/configuration remains in delivered full source archive.'));continue
 selected_shader.append(r)
 seen=set()
 for sid in r['source_ids']+r['notice_ids']:
  s=sources.get(sid,notices.get(sid));assert s is not None
  akey=(s['component'],s['relative'])
  if akey in seen:continue
  seen.add(akey)
  add(sh/r['packet_member'],r['sha256'],r['bytes'],'accepted-scoped-shader-notice-text',dict(component=s['component'],profiles=[k.split(':')[0] for k in components(s['component'])],relative=s['relative'],source_id=sid,source_identity=s['source_identity'],scope='Existing scoped text classification and source association; no new permission or blanket inheritance decision.'))
# Settled68-member noncommercial inclusion and exact supplied licence versions.
d=Path('/tmp/pix-m7-shader-distribution-disposition-20261015');inclusion=load(d/'member-inclusion.json');dm=load(d/'members.json');drows={r['member']:r for r in dm['members']}
for r in inclusion['members']:
 n=r['full_original_notice_source'];add(n['path'],n['sha256'],n['bytes'],'settled-shader-member-full-notice',dict(component=r['component'],profiles=[k.split(':')[0] for k in components(r['component'])],relative=r['relative'],source_identity=r['source_identity'],license=r['license'],license_uri=r['license_uri'],notice_actions=r['notice_actions'],existing_disposition=r['disposition']))
for name in ['01-cc-by-nc-sa-3-legalcode.html','02-cc-by-nc-sa-4-legalcode.html']:
 r=drows[name];add(d/name,r['sha256'],r['bytes'],'complete-held-CC-legalcode',dict(component='shader-licence-text',profiles=[],relative=name,applies_to=[x['relative'] for x in inclusion['members'] if ('-3-' in name)==(x['license']=='CC-BY-NC-SA-3.0')]))
# Later settled FreeJ2ME/Doom scope supersedes the old question; never reintroduce oldZT.
fin=Path('/tmp/pix-m7-final-notice-scope-20261015');actions=load(fin/'inclusion-actions.json');final_actions=[r for r in actions['actions'] if r['component']!='zerotier-one'];final_manifest=load(fin/'packet-manifest.json');final_rows={r['path']:r for r in final_manifest['files']}
for name in ['evidence/doom/wad-ENDOOM.txt','evidence/doom/mirror-doom19-readme.txt']:
 r=final_rows[name];add(fin/name,r['sha256'],r['bytes'],'settled-Doom-shareware-notice',dict(component='idtech-lr',profiles=['h700-aarch64','sm8550-aarch64'],relative=name,source_archive_sha256='ff35cde05801cfb27005229a6c55f20130ffa8f026ca27d7717c03152634e168'))
# Minimal self-contained metadata projections avoid the old whole-sourceZT payload and
# avoid copying large source inventories, heuristic lists, unrelated contexts or sources.
put('notice-associations.json',dict(schema=1,source=current['source'],base_manifest_sha256=INPUTS[str(BASE_ROOT/'manifest.json')]['sha256'],rows=ROWS,settled_inclusion_actions=final_actions,shader_scope_note='Settled shader family/inclusion decisions are retained; uncertain MAME adaptation remains pending. No exhaustive header expansion or new completeness gate.',omitted_non_notice_shader_context=omitted_context))
put('current-notice-rebindings.json',projection)
# Small exact supporting indices/receipts only. Large attribution tables remain pinned
# input provenance; their necessary associations are projected above, not duplicated.
for p,r in list(INPUTS.items()):
 if p in [str(f/n) for n in ['notice-block-index.json','profile-bindings.json','archive-binding.json','supplemental-license-provenance.json']]:add(p,r['sha256'],r['bytes'],'FreeJ2ME-notice-map-metadata')
for name in ['notice-associations.json','current-notice-rebindings.json']:
 p=P/name;raw=p.read_bytes();add(p,hashlib.sha256(raw).hexdigest(),len(raw),'portable-notice-mapping')
# Accepted originals bind execution without replaying any producer.
for name in [
 '/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T175402Z-f2709ea1/admission-consumed.json',
 '/workspace/tmp/pix-m7-delivery-assembly-20261015-01/collection-result.json',
 '/workspace/tmp/pix-m7-delivery-assembly-20261015-01/independent-readback.json',
 '/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T113024Z-b6cc9938/admission-consumed.json',
 '/workspace/tmp/pix-m7-current-notice-supplement-20261015-04/collection-result.json',
 '/tmp/pix-m7-shader-notice-disposition-20261015/accepted-inputs.json',
 '/tmp/pix-m7-shader-distribution-disposition-20261015/readback-observation.json']:
 load(name)
refs={r['notice']['sha256']:r['notice'] for r in ROWS if r['notice']['bundle']=='base'}
files=sorted(FILES.values(),key=lambda r:r['sha256']);counts=dict(new_files=len(files),new_bytes=sum(r['bytes'] for r in files),base_reused_notice_hashes=len(refs),base_reused_notice_bytes=sum(r['bytes'] for r in refs.values()),notice_associations=len(ROWS),shader_named_notice_contexts=len(selected_shader),shader_non_notice_contexts_omitted=len(omitted_context),shader_settled_noncommercial_members=len(inclusion['members']),freej2me_rendered_blocks=49,freej2me_source_member_references=103,metadata_bytes_read=READ,source_archive_payloads_read=0,old_zerotier_occurrences_excluded=3,publication_bundle_complete=False)
assert all('zerotier' not in r.get('component','') for r in ROWS)
put('selection.json',dict(files=files,base_refs=list(refs.values()),counts=counts,base_manifest=INPUTS[str(BASE_ROOT/'manifest.json')],association_member=next(r['member'] for r in files if 'portable-notice-mapping' in r['roles'] and r['source_paths'][0].endswith('notice-associations.json'))))
put('metadata-inputs.json',INPUTS);put('coverage.json',counts);print(json.dumps(counts))

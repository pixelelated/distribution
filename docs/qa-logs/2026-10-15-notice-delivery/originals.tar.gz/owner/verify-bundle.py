#!/usr/bin/env python3
"""Read exact supplement and explicitly supplied base directory only; no original-path fallback."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,re,stat,time

def verify(root,base_root,expected_manifest_sha256):
 roots={'supplement':Path(root),'base':Path(base_root)};start=time.monotonic();read_bytes=0;verified={}
 for p in roots.values():assert p.is_absolute() and p.resolve(strict=True)==p and p.is_dir() and not p.is_symlink()
 assert roots['supplement']!=roots['base'] and re.fullmatch('[0-9a-f]{64}',expected_manifest_sha256)
 def member(bundle,name):
  assert bundle in roots and isinstance(name,str) and 0<len(name)<=4096 and '\\' not in name and '\0' not in name
  q=PurePosixPath(name);assert not q.is_absolute() and '..' not in q.parts and '.' not in q.parts and '.git' not in q.parts and str(q)==name
  p=roots[bundle]/name;assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.is_relative_to(roots[bundle]);return p
 def read(bundle,name,expected=None,body=False):
  nonlocal read_bytes
  p=member(bundle,name);before=p.stat();assert stat.S_ISREG(before.st_mode) and before.st_size<16*1024**2
  h=hashlib.sha256();parts=[]
  with p.open('rb') as f:
   while True:
    block=f.read(1024**2)
    if not block:break
    read_bytes+=len(block);assert read_bytes<=32*1024**2 and time.monotonic()-start<120
    h.update(block)
    if body:parts.append(block)
  after=p.stat();assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
  r=dict(member=name,bytes=before.st_size,sha256=h.hexdigest())
  if expected:assert r=={k:expected[k] for k in ['member','bytes','sha256']}
  verified[(bundle,name)]=dict(bundle=bundle,**r)
  return (r,b''.join(parts)) if body else r
 mr,raw=read('supplement','manifest.json',body=True);assert mr['sha256']==expected_manifest_sha256;m=json.loads(raw)
 assert m['source']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and m['publication_bundle_complete']is False and m['off_host_destination']is None
 assert m['object_count']==126 and m['object_bytes']==2059815 and m['notice_associations']==271
 br,raw=read('base','manifest.json',body=True);assert br['sha256']==m['base_manifest_sha256'];b=json.loads(raw);assert b['source']==m['source'] and b['object_count']==1869
 base={r['sha256']:r for r in b['objects']};new={r['sha256']:r for r in m['objects']};assert len(new)==126 and len(new.keys()&base.keys())==0
 assert sum(r['bytes'] for r in new.values())==2059815
 assert all(r['member']=='objects/'+r['sha256'] and re.fullmatch('[0-9a-f]{64}',r['sha256']) for r in new.values())
 rows=m['objects']+m['metadata'];assert len(rows)==129 and len({r['member'] for r in rows})==129 and sum(r['bytes'] for r in rows)+mr['bytes']<16*1024**2
 bodies={}
 for r in rows:
  body=r['member'] in [m['association_member'],'delivery-status.json','object-member-index.json']
  result=read('supplement',r['member'],r,body)
  if body:bodies[r['member']]=json.loads(result[1])
 assert len(m['base_refs'])==26 and len({r['sha256'] for r in m['base_refs']})==26
 for r in m['base_refs']:
  assert r['bundle']=='base' and {k:r[k] for k in ['member','bytes','sha256']}==base[r['sha256']];read('base',r['member'],r)
 associations=bodies[m['association_member']];assert associations['source']==m['source'] and associations['base_manifest_sha256']==br['sha256'] and len(associations['rows'])==271
 for r in associations['rows']:
  assert 'zerotier' not in r['component'];n=r['notice'];catalog=base if n['bundle']=='base' else new
  assert n['bundle'] in ['base','supplement'] and {k:n[k] for k in ['member','bytes','sha256']}==catalog[n['sha256']] and (n['bundle'],n['member']) in verified
 objects=bodies['object-member-index.json'];assert [{k:r[k] for k in ['member','bytes','sha256']} for r in objects]==m['objects'] and all(r['independent_copy']is True for r in objects)
 status=bodies['delivery-status.json'];assert status['unresolved']==m['unresolved'] and status['publication_bundle_complete']is False and status['off_host_destination']is None
 actual=set()
 for p in roots['supplement'].iterdir():
  assert not p.is_symlink()
  if p.is_dir():
   assert p.name=='objects'
   for child in p.iterdir():assert len(actual)<256 and child.is_file() and not child.is_symlink();actual.add(str(child.relative_to(roots['supplement'])))
  else:assert p.is_file();actual.add(p.name)
 assert len(actual)==m['expected_file_count']==130 and actual=={n for bundle,n in verified if bundle=='supplement'}
 for p in [roots['supplement'],roots['supplement']/'objects',*[roots['supplement']/n for n in actual]]:assert stat.S_IMODE(p.stat().st_mode)==(0o555 if p.is_dir() else 0o444)
 return dict(status='PASS_ADDITIVE_NOTICES_AND_RELATIVE_BASE_REFERENCES',manifest_sha256=expected_manifest_sha256,base_manifest_sha256=br['sha256'],new_files=126,new_bytes=2059815,base_reused_notices=26,notice_associations=271,files=list(verified.values()),read_bytes=read_bytes,elapsed_seconds=time.monotonic()-start,original_paths_opened=0,network_used=False,publication_bundle_complete=False)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--base-root',type=Path,required=True);p.add_argument('--expected-manifest-sha256',required=True);a=p.parse_args();print(json.dumps(verify(a.root,a.base_root,a.expected_manifest_sha256),sort_keys=True))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Consume exact original success channels only; retention does not clear publication."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent;B=runpy.run_path(str(O/'bindings.py'));plan=B['verify'](O)
assert Path.cwd()==B['VM_TREE'];load,sha=B['load'],B['sha'];run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs';B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert p.read_text().strip()=='0',p
result,cleanup=load(O/'result.json'),load(O/'cleanup.json');assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established']is False
assert result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0
assert child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit'])is int and report['original_collector_exit']==0
assert report['objects']==126 and report['object_bytes']==2059815 and report['notice_associations']==271
assert report['read_bytes']<=512*1024**2 and report['elapsed_seconds']<270
for k in ['source_execution','archive_decode','publication_clearance','publication_bundle_complete','network_used','target_execution']:assert report[k]is False
assert not (O/'collection-failure.json').exists();D=Path(load(O/'destination.json')['path']);base=Path(plan['base_manifest']['path']).parent;assert report['custody_path']==str(D)
V=runpy.run_path(str(O/'verify-bundle.py'));verification=V['verify'](D,base,report['manifest_sha256'])
assert {str(D/r['member']):(r['bytes'],r['sha256']) for r in verification['files'] if r['bundle']=='supplement'}=={r['path']:(r['bytes'],r['sha256']) for r in report['files']}
assert load(D/'delivery-status.json')['binding_refs']==plan['binding_refs'] and load(D/'manifest.json')['unresolved']==plan['unresolved']
selection=load(O/'selection.json');objects=load(D/'object-member-index.json')
assert [{k:r[k] for k in ['member','sha256','bytes']} for r in objects]==[{k:r[k] for k in ['member','sha256','bytes']} for r in selection['files']]
for obj,spec in zip(objects,selection['files']):
 assert obj['source_identity']['path']==spec['source_paths'][0] and obj['roles']==spec['roles'];st=(D/obj['member']).stat();assert (st.st_dev,st.st_ino)!=(obj['source_identity']['device'],obj['source_identity']['inode'])
raw=(json.dumps(verification,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<1024**2
with (O/'independent-readback.json').open('xb') as f:f.write(raw)
assert cleanup['all_recorded_identities_absent']is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped']is False
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']();keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']};supervisor=cleanup['supervisor_identity'];assert supervisor is not None;keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in keys];parents={r['pid'] for r in matching};descendants=[]
while parents:
 children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants];descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[p for p in O.rglob('*') if p.is_file()]+[run/'runner-result.json',run/'build.rc'];assert len(files)<=128 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=64*1024**2
out=O/'admission-completion-evidence.json';evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files]+[dict(path=str((base if r['bundle']=='base' else D)/r['member']),sha256=r['sha256']) for r in verification['files']],scope='Small additive notice assembly plus independent relative-path readback of new notices and explicitly reused base notices only. Current ABL/MAME source dispositions and off-host/publication requirements unchanged; no producer replay or new notice completeness gate.')
raw=(json.dumps(evidence,indent=2)+'\n').encode();assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=64*1024**2
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True,timeout=120)
print('PASS consumed additive notice custody and relative base references; existing dispositions preserved')

#!/usr/bin/env python3
"""Offline immutable-copy custody; execution requires root's separate admission."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,sys,time
from urllib.parse import urlsplit
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path'])
START=time.monotonic();READ=0;WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1
def tick(n=0):
 global READ
 assert n>=0;READ+=n
 assert READ<=R['total_read_bytes'] and time.monotonic()-START<R['soft_seconds'],'read/time ceiling'
def safe(name):
 assert isinstance(name,str) and name and len(os.fsencode(name))<=R['path_bytes'] and '\0' not in name and '\\' not in name
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p)==name and '.git' not in p.parts,name
 return name

def ident(p,regular=True):
 p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.resolve(strict=True)==p,p
 s=p.stat();assert not regular or stat.S_ISREG(s.st_mode),p
 return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def digest(p,cap=268435456):
 before=ident(p);assert before['bytes']<=cap
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));h.update(b)
 assert ident(p)==before,'input changed while hashing'
 return dict(before,sha256=h.hexdigest())
def root_for(p):
 for root in [O,D]:
  if p.is_relative_to(root):return root
 raise AssertionError('write outside owned roots')
def mkdir(p):
 root=root_for(p);assert len(DIRS)<R['output_directories'];assert not p.exists() and not p.is_symlink()
 assert p.parent.resolve(strict=True)==p.parent and not p.parent.is_symlink();p.mkdir(mode=0o700);DIRS.add(str(p))
def reserve(p,n,failure=False):
 tick();root=root_for(p);cap=R['custody_output_ceiling_bytes'] if root==D else R['owner_output_ceiling_bytes']-R['supervisor_reserve_bytes']
 if failure:assert root==O and n<=R['failure_receipt_budget_bytes'];cap+=R['failure_receipt_budget_bytes']
 assert n>=0 and OUTPUT[str(root)]+n<=cap,'aggregate before-write ceiling'
 assert WRITES[str(p)]+n<=R['per_file_bytes'],'individual before-write ceiling'
 OUTPUT[str(root)]+=n;WRITES[str(p)]+=n
class Writer:
 def __init__(self,p,failure=False):
  self.p=Path(p);root_for(self.p);safe(str(self.p.relative_to(root_for(self.p))))
  assert len(WRITES)<R['output_files'] and str(self.p) not in WRITES
  assert self.p.parent.resolve(strict=True)==self.p.parent and not self.p.exists() and not self.p.is_symlink()
  WRITES[str(self.p)]=0;self.failure=failure;self.f=self.p.open('xb')
 def write(self,b):reserve(self.p,len(b),self.failure);return self.f.write(b)
 def flush(self):self.f.flush()
 def tell(self):return self.f.tell()
 def close(self):self.f.close()
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
def put(p,obj,failure=False):
 raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
 if failure:assert len(raw)<=R['failure_receipt_budget_bytes']
 with Writer(p,failure) as f:f.write(raw)
def rawput(p,b):
 with Writer(p) as f:f.write(b)
def load(p):
 before=ident(p);assert before['bytes']<16*1024**2
 raw=Path(p).read_bytes();tick(len(raw));assert ident(p)==before;return json.loads(raw)

def copy_file(spec,member):
 safe(member);p=Path(spec['path']);before=digest(p,R['per_file_bytes'])
 assert before['bytes']==spec['bytes'] and before['sha256']==spec['sha256']
 if 'held_identity' in spec:assert before==spec['held_identity']
 target=D/member
 with p.open('rb') as f,Writer(target) as out:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));out.write(b)
 after=digest(target,R['per_file_bytes']);assert after['sha256']==before['sha256'] and after['bytes']==before['bytes']
 assert (after['device'],after['inode'])!=(before['device'],before['inode']) and digest(p,R['per_file_bytes'])==before
 return dict(member=member,bytes=after['bytes'],sha256=after['sha256'],source_identity=before,independent_copy=True)



def ref(r):return {k:r[k] for k in ['member','sha256','bytes']}
try:
 assert D.parent==Path('/workspace/artifacts/pixelelated-release-sources') and D.name=='m7-notice-delivery-'+O.name.removeprefix('pix-m7-notice-delivery-') and not D.exists() and not D.is_symlink()
 for p in O.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():OUTPUT[str(O)]+=p.stat().st_size
 assert OUTPUT[str(O)]<8*1024**2
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 assert digest(O/'selection.json',16*1024**2)['sha256']==PLAN['selection_sha256']
 selection=load(O/'selection.json');assert len(selection['files'])==126
 mkdir(D);mkdir(D/'objects');objects=[]
 for spec in selection['files']:
  out=copy_file(dict(path=spec['source_paths'][0],bytes=spec['bytes'],sha256=spec['sha256']),spec['member']);objects.append(dict(out,roles=spec['roles']))
 assert sum(r['bytes'] for r in objects)==PLAN['expected_object_bytes']
 put(D/'object-member-index.json',objects)
 put(D/'delivery-status.json',dict(scope=PLAN['scope'],coverage=selection['counts'],publication_bundle_complete=False,off_host_destination=None,unresolved=PLAN['unresolved'],binding_refs=PLAN['binding_refs']))
 verifier=O/'verify-bundle.py';body=verifier.read_bytes();tick(len(body));rawput(D/'verify-bundle.py',body)
 metadata=[]
 for name in ['object-member-index.json','delivery-status.json','verify-bundle.py']:
  r=digest(D/name,16*1024**2);metadata.append(dict(member=name,bytes=r['bytes'],sha256=r['sha256']))
 manifest=dict(schema=1,source=PLAN['source'],object_count=126,object_bytes=2059815,notice_associations=271,objects=[ref(r) for r in objects],metadata=metadata,association_member=selection['association_member'],base_manifest_sha256=PLAN['base_manifest']['sha256'],base_refs=selection['base_refs'],publication_bundle_complete=False,off_host_destination=None,unresolved=PLAN['unresolved'],expected_file_count=130)
 put(D/'manifest.json',manifest)
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 files=[dict(path=p,bytes=n,sha256=digest(p,R['per_file_bytes'])['sha256']) for p,n in WRITES.items() if Path(p).is_relative_to(D)];assert len(files)==130
 for r in files:Path(r['path']).chmod(0o444)
 for p in sorted([Path(p) for p in DIRS if Path(p).is_relative_to(D)],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
 put(O/'collection-result.json',dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,custody_path=str(D),manifest_sha256=digest(D/'manifest.json')['sha256'],files=files,objects=126,object_bytes=2059815,notice_associations=271,network_used=False,target_execution=False,source_execution=False,archive_decode=False,publication_clearance=False,publication_bundle_complete=False,outputs_held=True,deleted_bytes=0,accounted_output_bytes=OUTPUT,read_bytes=READ,elapsed_seconds=time.monotonic()-START,unresolved=PLAN['unresolved']))
 rc=0
except BaseException as exc:
 try:put(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(exc).__name__+': '+str(exc)[:4096],accounted_output_bytes=OUTPUT,written_files=len(WRITES),publication_bundle_complete=False,outputs_held=True,deleted_bytes=0),failure=True)
 except BaseException as receipt_error:print('Failure receipt refused: '+type(receipt_error).__name__,file=sys.stderr)
sys.exit(rc)

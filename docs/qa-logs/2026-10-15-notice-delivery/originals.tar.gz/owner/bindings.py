"""Exact held metadata/host bindings; no payload execution at import."""
from pathlib import Path
import hashlib,json,os,re
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def prerequisites(plan):
 assert plan['source']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and plan['publication_bundle_complete']is False
 run=Path(plan['base_run']);c=load(run/'admission-consumed.json');r=load(run/'runner-result.json')
 assert c['state']=='consumed' and c['run']==str(run) and c['submission_owner']==plan['base_owner'] and c['source']['head']==COMMIT and c['original_result']==r
 assert all(type(r[k])is int and r[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
 report=load(Path(plan['base_owner'])/'collection-result.json');v=load(Path(plan['base_owner'])/'independent-readback.json')
 assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and report['original_collector_exit']==0 and report['manifest_sha256']==plan['base_manifest']['sha256']
 assert v['status']=='PASS_LOCAL_BYTES_AND_PORTABLE_MAP_WITH_EXPLICIT_GAPS' and v['original_paths_opened']==0 and v['manifest_sha256']==report['manifest_sha256']
 assert sha(plan['base_manifest']['path'])==plan['base_manifest']['sha256']
 m=load(plan['base_manifest']['path']);assert m['source']==plan['source'] and m['object_count']==1869
 return m

def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 plan=load(O/'collection-plan.json');assert 1<=len(plan['binding_refs'])<=128
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 s=load(O/'selection.json');assert sha(O/'selection.json')==plan['selection_sha256']
 assert len(s['files'])==plan['expected_members']==126 and sum(r['bytes'] for r in s['files'])==plan['expected_object_bytes']==2059815
 assert len({r['sha256'] for r in s['files']})==126
 for r in s['files']:
  assert re.fullmatch('[0-9a-f]{64}',r['sha256']) and r['member']=='objects/'+r['sha256'] and type(r['bytes'])is int and 0<=r['bytes']<16*1024**2
  assert len(r['source_paths'])==1 and all(Path(p).is_absolute() and '/build.' not in p and '/nix/store/' not in p and '/cache/' not in p for p in r['source_paths'])
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-notice-delivery-'+O.name.removeprefix('pix-m7-notice-delivery-')
 base=prerequisites(plan);known={r['sha256']:r for r in base['objects']}
 assert all(r['sha256'] not in known for r in s['files'])
 assert all({k:r[k] for k in ['member','bytes','sha256']}==known[r['sha256']] for r in s['base_refs'])
 return plan

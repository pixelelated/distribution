from pathlib import Path
import datetime,decimal,gzip,hashlib,json,stat,sys,tarfile
spec=json.loads(Path(sys.argv[1]).read_text());out=Path(spec['out'])
assert out==Path('/tmp/pix-m7-notice-delivery-accepted-20261015') and not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[]
for label,root in spec['groups']:
 root=Path(root);assert root.is_dir() and not root.is_symlink()
 for p in [root]+sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if any(p==Path(x) or p.is_relative_to(Path(x)) for x in spec.get('excluded',[])):continue
  s=p.lstat();assert stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode),p
  paths.append((p,label+('/'+str(rel) if rel.parts else ''),s))
for label,source in spec.get('files',[]):
 p=Path(source);s=p.lstat();assert stat.S_ISREG(s.st_mode),p
 assert label not in {name for _,name,_ in paths}
 paths.append((p,label,s))
assert len(paths)<2000 and sum(s.st_size for _,_,s in paths if stat.S_ISREG(s.st_mode))<32*1024**2
out.mkdir();rows=[];archive=out/'originals.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
 for p,name,s in paths:
  ti=tf.gettarinfo(str(p),arcname=name);ti.pax_headers['mtime']=str(decimal.Decimal(s.st_mtime_ns)/10**9)
  if ti.isfile():
   digest=sha(p)
   with p.open('rb') as f:tf.addfile(ti,f)
  else:tf.addfile(ti);digest=None
  a=p.lstat();assert (a.st_size,a.st_mode,a.st_uid,a.st_gid,a.st_mtime_ns)==(s.st_size,s.st_mode,s.st_uid,s.st_gid,s.st_mtime_ns)
  rows.append(dict(member=name,original_path=str(p),kind='file' if ti.isfile() else 'directory',bytes=ti.size,sha256=digest,mode=stat.S_IMODE(ti.mode),uid=ti.uid,gid=ti.gid,mtime_ns=s.st_mtime_ns))
with tarfile.open(archive,'r:gz') as tf:
 actual={m.name:m for m in tf.getmembers()};assert len(actual)==len(rows)
 for r in rows:
  m=actual[r['member']];assert (m.size,m.mode,m.uid,m.gid)==(r['bytes'],r['mode'],r['uid'],r['gid'])
  assert int(decimal.Decimal(m.pax_headers['mtime'])*10**9)==r['mtime_ns']
  if r['kind']=='file':assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==r['sha256']==sha(Path(r['original_path']))
(out/'members.json').write_text(json.dumps({'archive_sha256':sha(archive),'members':rows},indent=2)+'\n')
(out/'custody-verification.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_ARCHIVE_AND_LIVE_ORIGINALS','members':len(rows),'files':sum(r['kind']=='file' for r in rows),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'bytes':sum(r['bytes'] for r in rows),'publication_clearance':False},indent=2)+'\n')
(out/'README.md').write_text(spec['readme'])
(out/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(json.dumps({'packet':str(out),'seal':sha(out/'SHA256SUMS'),'members':len(rows),'archive_bytes':archive.stat().st_size}))

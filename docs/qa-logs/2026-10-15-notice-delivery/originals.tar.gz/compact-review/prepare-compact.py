from pathlib import Path
import datetime,difflib,hashlib,json,stat
W=Path(__file__).parent;O=Path('/workspace/tmp/pix-m7-notice-delivery-20261015-01');D=Path('/workspace/artifacts/pixelelated-release-sources/m7-notice-delivery-20261015-01');BASE=Path('/workspace/artifacts/pixelelated-release-sources/m7-delivery-source-20261015-01');CO=Path('/tmp/pix-m7-notice-delivery-coordinator-20261015');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
run=Path((O/'run.path').read_text().strip());assert run.name=='20261015T180717Z-99f88381';rr=j(run/'runner-result.json');c=j(run/'admission-consumed.json');ev=j(O/'admission-completion-evidence.json');r=j(O/'collection-result.json');v=j(O/'independent-readback.json');result=j(O/'result.json');cleanup=j(O/'cleanup.json');m=j(D/'manifest.json')
assert c['state']=='consumed' and c['id']=='8ec026cd07d84f5faffc87d52e983d3e' and c['original_result']==rr and c['source']['head']=='f8636de1d105275dbf9420bbabbbc26f79abb10f' and c['pid_namespace']==4026531836
assert c['submission_owner']==str(O) and c['evidence_sha256']==h(O/'admission-completion-evidence.json') and all(rr[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert j(O/'launcher-result.json')['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',O/'stage/association.exit',run/'build.rc']:assert p.read_text()=='0\n'
assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['execution_error'] is None and all(not result[k] for k in ['cleanup_errors','receipt_errors','interrupted_signals'])
assert cleanup['all_recorded_identities_absent'] and not cleanup['direct_child_unreaped'] and all(not cleanup[k] for k in ['errors','receipt_errors','signals_sent','survivors_after_cleanup','recorded_identities_still_present'])
assert r['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and r['original_collector_exit']==0 and v['status']=='PASS_ADDITIVE_NOTICES_AND_RELATIVE_BASE_REFERENCES'
assert r['manifest_sha256']==v['manifest_sha256']==h(D/'manifest.json')=='aa373739d72621aa5033025644840be8f9456289ed9171194e200f616c7f9e2c'
assert r['objects']==v['new_files']==m['object_count']==126 and r['object_bytes']==v['new_bytes']==2059815 and r['notice_associations']==v['notice_associations']==271
assert v['base_reused_notices']==len(m['base_refs'])==26 and v['original_paths_opened']==0 and v['base_manifest_sha256']==m['base_manifest_sha256']=='dfbc11140c9f51d1a92572909e5404a7451df1d43a47a223827da1277e1bfb90'
assert len(r['files'])==m['expected_file_count']==130 and len(v['files'])==157
assert {str(D/x['member']):(x['bytes'],x['sha256']) for x in v['files'] if x['bundle']=='supplement'}=={x['path']:(x['bytes'],x['sha256']) for x in r['files']}
metadata=[*m['metadata'],{'member':'manifest.json','bytes':(D/'manifest.json').stat().st_size,'sha256':h(D/'manifest.json')}];assert len(metadata)==4
for x in metadata:assert (D/x['member']).stat().st_size==x['bytes'] and h(D/x['member'])==x['sha256']
excluded=[];verified=[]
for e in ev['evidence']:
 p=Path(e['path'])
 if p.is_relative_to(D/'objects') or p.is_relative_to(BASE/'objects'):excluded.append(e);continue
 assert p.is_relative_to(O) or p.is_relative_to(run) or p in [D/x['member'] for x in metadata] or p==BASE/'manifest.json'
 assert p.stat().st_size<2*1024**2 and h(p)==e['sha256'];verified.append(e)
assert len(excluded)==152
records=[]
for p in CO.glob('*.exit.json'):assert j(p)['original_tool_exit']==0
for name in ['prepare','report']:
 p=Path((CO/(name+'.stderr')).read_text().strip().removeprefix('watch-build: recording in '));x=j(p/'runner-result.json');assert all(x[k]==0 for k in ['command_rc','monitor_rc','runner_rc']);records.append({'name':name,'run':str(p),'original_result':x})
seals=[]
for path,seal in [('/tmp/pix-m7-notice-delivery-plan-20261015','5f15e01d01eb18665e5fcd818a3281f4745f26d3a802c7513ae38d2e0b69969f'),('/tmp/pix-m7-notice-delivery-review-20261015','b43a900675d305774fd9885e02dc92aef5601d4d39e9726f2c01ce3d269b7c58')]:
 p=Path(path);assert h(p/'SHA256SUMS')==seal
 for line in (p/'SHA256SUMS').read_text().splitlines():expected,n=line.split('  ',1);assert h(p/n)==expected
 seals.append({'path':path,'seal':seal})
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_COMPACT_NOTICE_DELIVERY_ORIGINALS','run':str(run),'original_result':rr,'consumed_id':c['id'],'consumed_utc':c['consumed'],'consumed_sha256':h(run/'admission-consumed.json'),'source_seals':seals,'collector_elapsed_seconds':r['elapsed_seconds'],'collector_read_bytes':r['read_bytes'],'readback_elapsed_seconds':v['elapsed_seconds'],'readback_bytes':v['read_bytes'],'new_files':126,'new_bytes':2059815,'base_refs':26,'associations':271,'manifest_sha256':h(D/'manifest.json'),'metadata':metadata,'compact_rehashed_references':len(verified),'payload_refs_excluded':152,'payload_bodies_opened':0,'record_only_runs':records,'original_custody_bytes':r['accounted_output_bytes'][str(D)],'scope':'Completed original records and small metadata only; no new notice/base payload read, census or operational helper execution.'}
(W/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n')
base=Path('/tmp/pix-m7-h700-transfer-custody-20261015/custody-helper.py');raw=base.read_text();old="assert out.parent==Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs') and not out.exists()";new="assert out==Path('/tmp/pix-m7-notice-delivery-accepted-20261015') and not out.exists()";assert raw.count(old)==1;changed=raw.replace(old,new);(W/'custody-helper.py').write_text(changed);(W/'custody-helper.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True),changed.splitlines(True),fromfile=str(base),tofile=str(W/'custody-helper.py'))))
(W/'helper-provenance.json').write_text(json.dumps({'base':str(base),'base_sha256':h(base),'derivative_sha256':h(W/'custody-helper.py'),'sole_delta':'Exact output assertion for authorized /tmp packet; all bytes/metadata custody operations unchanged.'},indent=2)+'\n')
groups=[['source-packet',seals[0]['path']],['source-review',seals[1]['path']],['owner',str(O)],['run',str(run)],['coordinator-observations',str(CO)],['compact-review',str(W)]]+[['record-only-runs/'+Path(x['run']).name,x['run']] for x in records]
files=[['supplement-metadata/'+x['member'],str(D/x['member'])] for x in metadata]+[['root/pix-m7-notice-delivery-coordinator-20261015.py','/tmp/pix-m7-notice-delivery-coordinator-20261015.py']]
readme='''# Accepted additive notice delivery: compact originals

Exact source packet `5f15e01d01eb18665e5fcd818a3281f4745f26d3a802c7513ae38d2e0b69969f` and independent review `b43a900675d305774fd9885e02dc92aef5601d4d39e9726f2c01ce3d269b7c58` are retained unchanged with actual owner/run/coordinator originals.

Run `20261015T180717Z-99f88381` under frozen GENERIC02 was ordinarily consumed as `8ec026cd07d84f5faffc87d52e983d3e`. Original command/monitor/runner, launcher, inner/outer/tool-wrapper and association exits are zero; all coordinator command receipts and the two original preparation/report runs are zero. Cleanup records all owned identities absent, no signals, survivors, timeout, cleanup or receipt errors. Host-control f863 remains distinct from candidate source077197.

The collector reports `COLLECTED_WITH_EXPLICIT_GAPS`, elapsed **0.0547514648642391 seconds**, read **54,062,014 bytes**, and **126 new objects / 2,059,815 bytes** through **271 notice associations**. There are **26 reused base notice hashes**; no base payload is copied or modified. The completed supplement has130 files /2,172,662 bytes including four metadata files. Manifest SHA is **`aa373739d72621aa5033025644840be8f9456289ed9171194e200f616c7f9e2c`** at `/workspace/artifacts/pixelelated-release-sources/m7-notice-delivery-20261015-01/manifest.json`.

Original independent readback is `PASS_ADDITIVE_NOTICES_AND_RELATIVE_BASE_REFERENCES`: **0.0071309939958155155 seconds /2,823,361 bytes**, zero original paths opened. It binds accepted base manifest `dfbc11140c9f51d1a92572909e5404a7451df1d43a47a223827da1277e1bfb90`, explicit roots and relative members. The existing admission consumer then returned zero. These original verification passes were not replayed during retention.

Only the four small supplement metadata files are copied here. The126 new bodies and26 reused base notice bodies are excluded and were not reopened, rehashed or traversed. Exact full lists, source identities, hashes, sizes and mappings remain in the original receipt/manifest records. Compact review checked the ordinary consumption binding, original exits, source/review seals and selected metadata. It performed no helper import/execution, process census, archive decode, source or base payload replay.

`originals.tar.gz` and `members.json` preserve exact original bytes/SHA-256, modes, UID/GID and nanosecond mtimes. The established writer changes only its exact authorized output assertion; that one-line derivative is retained. A separate archive/original comparison precedes release. All original source and base records remain unchanged.

This preserves the scoped accepted notice actions; it adds no license standard or completeness gate. Current ABL implementation, uncertain MAME adaptation, owner off-host destination/transfer/retrieval/backup and publication remain outside this local acceptance. No canonical records, tracker or product files were edited.
'''
spec={'out':'/tmp/pix-m7-notice-delivery-accepted-20261015','groups':groups,'files':files,'excluded':[],'readme':readme};Path('/tmp/pix-m7-notice-delivery-accepted-spec-20261015.json').write_text(json.dumps(spec,indent=2)+'\n')
count=0;total=0
for label,path in groups:
 root=Path(path)
 for q in [root]+sorted(root.rglob('*')):
  st=q.lstat();assert stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode);count+=1
  if stat.S_ISREG(st.st_mode):assert st.st_size<2*1024**2;total+=st.st_size
for label,path in files:count+=1;total+=Path(path).stat().st_size
assert count<2000 and total<32*1024**2
print(json.dumps({'status':receipt['status'],'members':count,'bytes':total,'payload_bodies_opened':0,'compact_rehashed':len(verified)}))

from pathlib import Path
import datetime,hashlib,json
OUT=Path(__file__).parent
P=Path('/tmp/pix-m7-zerotier-h700-refresh-20261015/transfer02')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
j=lambda p:json.loads(Path(p).read_text())
assert h(P/'SHA256SUMS')=='4e844fda1c085b1a43d2cb6d6c6bbd032219c7c5ba6f583930ae537d74b769a8'
seals=[]
for sub in [P,P/'arm',P/'aarch64']:
 count=0
 for line in (sub/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1);f=sub/name;assert f.is_relative_to(sub) and h(f)==expected;count+=1
 seals.append({'path':str(sub),'seal':h(sub/'SHA256SUMS'),'payloads':count})
rows=[];observations=[]
for abi,inode,runid,consumed_id in [('arm',148539050,'20261015T163646Z-18f35105','9fe9cbe7416f40d8bb204db7d7adebcc'),('aarch64',148539056,'20261015T163801Z-0bad10ae','9170fa3ad82146a88d189e3b0973081a')]:
 o=Path('/workspace/tmp/pix-m7-zerotier-h700-transfer-'+abi+'-20261015-01');r=Path((o/'run.path').read_text().strip());assert r.name==runid
 tr=j(o/'transfer-result.json');d=j(o/'dependency-assessed.json');raw=j(o/'dependency-readback.json');ev=j(o/'consumption-evidence.json');cons=j(r/'admission-consumed.json');runner=j(r/'runner-result.json')
 assert (runner['command_rc'],runner['monitor_rc'],runner['runner_rc'])==(0,0,0) and cons['original_result']==runner
 assert cons['state']=='consumed' and cons['id']==consumed_id and cons['pid_namespace']==4026531836 and cons['run']==str(r) and cons['submission_owner']==str(o)
 assert cons['evidence_sha256']==h(o/'consumption-evidence.json')
 assert tr['status']=='PASS' and tr['method']=='same-filesystem-rename' and tr['copy_performed'] is False and tr['renamed'] is True
 assert tr['source_head']=='f8636de1d105275dbf9420bbabbbc26f79abb10f' and tr['destination_head']==cons['source']['head']=='077197e6cd3ea31f33b28aaf3882a694b3423b53'
 assert tr['before_identity']==tr['after_identity']==d['root_identity']=={'device':66304,'inode':inode}
 assert {k:raw['identity'][k] for k in ['device','inode']}==tr['before_identity']
 assert tr['old_target_identity']=={'device':66304,'inode':148419564}
 assert (o/'cache-ready.json').read_bytes()==(o/'transfer-result.json').read_bytes()
 assert tr['dependency_readback']['readback']==d and tr['dependency_readback']['sha256']==h(o/'dependency-assessed.json') and tr['dependency_readback']['path']==str(o/'dependency-assessed.json')
 assert d['original_readback']==str(o/'dependency-readback.json') and d['original_readback_sha256']==h(o/'dependency-readback.json')
 assert d['status']=='CLEAR_WITH_STATED_SCOPE' and d['utc_epoch']==raw['utc_epoch'] and d['host_pid_namespace']==raw['host_pid_namespace']==4026531836
 assert d['process_errors']==raw['errors'] and d['process_matches']==raw['matches']==[] and raw['container_references']==raw['active_admissions']==d['active_admissions']==d['remaining_consumers']==[] and d['prepared_consumers_resolved']
 assert {x['pid'] for x in d['excluded_from_fd_scope']}=={2325,2342,564119,2590490,2739866,3133343}=={x['pid'] for x in raw['errors']}
 assert 0<=tr['utc_start_epoch']-raw['utc_epoch']<=900
 assert j(o/'launcher-result.json')['runner_returncode']==0
 for f in [o/'inner.rc',o/'tool-wrapper.rc',r/'build.rc']:assert f.read_text()=='0\n'
 for e in ev['evidence']:
  p=Path(e['path']);assert p.stat().st_size<1024**2 and h(p)==e['sha256']
 b=tr['original_build_consumption'];assert h(b['path'])==b['sha256'] and j(b['path'])['original_result']==b['original_result'] and b['original_result']['command_rc']==b['original_result']['runner_rc']==1 and b['original_result']['monitor_rc']==0 and b['failed_investigated']
 for e in tr['generic_dependency']['receipts']:
  assert h(e['path'])==e['sha256'];c=j(e['path']);assert c['id']==e['id'] and c['state']=='consumed' and c['original_result']['runner_rc']==0
 assert tr['generic_dependency']['runtime_claim'] is False
 co=Path('/tmp/pix-m7-h700-transfer-'+abi+'-coordinator-20261015')
 for stage in ['prepare','preflight','report','dependencies','admit','launch','consume']:
  ex=j(co/(stage+'.exit.json'));assert ex['original_tool_exit']==0
 for stage in ['report','dependencies']:
  stderr=(co/(stage+'.stderr')).read_text().strip();prefix='watch-build: recording in ';assert stderr.startswith(prefix)
  watch=Path(stderr[len(prefix):]);wr=j(watch/'runner-result.json');assert (wr['command_rc'],wr['monitor_rc'],wr['runner_rc'])==(0,0,0) and (watch/'build.rc').read_text()=='0\n'
  observations.append({'abi':abi,'stage':stage,'run':str(watch),'original_result':wr})
 rows.append({'abi':abi,'run':str(r),'consumed_id':consumed_id,'consumed_utc':cons['consumed'],'consumed_sha256':h(r/'admission-consumed.json'),'original_result':runner,'launcher_returncode':0,'recorded_before_after_identity':tr['before_identity'],'recorded_old_target_identity':tr['old_target_identity'],'dependency_utc':raw['utc'],'process_scope':raw['scope'],'own_uid_processes_scanned':raw['own_uid_processes_scanned'],'other_uid_without_fd_census':raw['other_uid_processes_without_fd_census'],'explicit_exclusions':d['excluded_from_fd_scope'],'docker_mount_metadata_rows':len(d['docker_all_mounts']),'transfer_sha256':h(o/'transfer-result.json'),'prior_failed_producer':b,'independent_old_artifact_acceptance':tr['accepted_artifact']})
assert datetime.datetime.fromisoformat(rows[0]['consumed_utc'])<datetime.datetime.fromisoformat(j(Path(rows[1]['run'])/'admission-consumed.json')['admitted'])
r={'status':'PASS_COMPACT_ORIGINAL_TRANSFER_RECORDS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_seals':seals,'transfers':rows,'record_only_observations':observations,'cache_roots_statted_or_traversed':False,'payloads_opened':False,'live_process_or_container_census':False,'new_build_or_runtime_qualification':False,'scope':'Record equality and original outcome verification only; source assessment scope exclusions preserved.'}
(OUT/'record-readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'transfers':2,'record_only_runs':len(observations),'receipt_sha256':h(OUT/'record-readback.json')}))

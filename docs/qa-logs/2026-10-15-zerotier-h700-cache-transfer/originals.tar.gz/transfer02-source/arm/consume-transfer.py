#!/usr/bin/env python3
"""Existing normal admission-consumption route, scoped to one atomic cache transfer."""
from pathlib import Path
import argparse,hashlib,json,subprocess
q=argparse.ArgumentParser();q.add_argument('--owner',type=Path,required=True);a=q.parse_args();O=a.owner.resolve(strict=True)
T=Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05');assert Path.cwd().resolve()==T
assert O.parent==Path('/workspace/tmp') and O.name.startswith('pix-m7-zerotier-h700-transfer-arm-20261015-')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
run=Path((O/'run.path').read_text().strip());ad=json.loads((run/'admission.json').read_text())
assert ad['source']['head']=='077197e6cd3ea31f33b28aaf3882a694b3423b53' and ad['submission_owner']==str(O)
r=json.loads((O/'transfer-result.json').read_text());assert r==json.loads((O/'cache-ready.json').read_text())
assert r['status']=='PASS' and r['renamed'] and not r['copy_performed']
assert r['before_identity']==r['after_identity'] and not Path(r['old']).exists()
assert r['new']==str(T/'build.pixelelated-H700.arm');st=Path(r['new']).stat()
assert r['after_identity']==dict(device=st.st_dev,inode=st.st_ino)
runner=json.loads((run/'runner-result.json').read_text());assert all(runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert json.loads((O/'launcher-result.json').read_text())['runner_returncode']==0
files=[O/'transfer-result.json',O/'cache-ready.json',O/'launcher-result.json',run/'runner-result.json']
for f in [O/'inner.rc',O/'tool-wrapper.rc',run/'build.rc']:assert f.read_text().strip()=='0';files.append(f)
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=ad['outputs'],evidence=[dict(path=str(f),sha256=sha(f)) for f in files],scope='Single arm cache transfer only; second ABI transfer and build are separate; prior producer failures unchanged')
out=O/'consumption-evidence.json'
with out.open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
subprocess.run(['python3','-I',str(T/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS single arm cache transfer consumed; no claim that the other ABI moved')

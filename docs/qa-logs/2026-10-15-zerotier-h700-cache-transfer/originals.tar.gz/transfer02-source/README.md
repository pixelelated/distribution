# Narrow transfer02 binding

This successor changes only the GENERIC artifact prerequisite from failed reader01 to actual accepted reader02 at20261015T163127Z-5682551e. Reader02 consumed ID is ee024372b00f4314afa9fc96495b83de; its exact consumed/result hashes are checked by both transfer entrypoints. Reader01 remains failed1/0/1 consumedf57142e9fc6842f7b29a4f0b061b6fcc. Initial `transfer/` remains unchanged with its original seal; do not run its obsolete reader01 dependency. No move, preparer, admission or cache scan was executed in preparing this successor.

# H700 cache custody — source only, ready for review

Exact new source077197e6cd3ea31f33b28aaf3882a694b3423b53. New checkout `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05`, branch `build/m7-pixelelated-h700-05`, must be created clean at that commit by root. Old source `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04` remains frozen atf8636de1d105275dbf9420bbabbbc26f79abb10f. Source preparation did not create a worktree, scan a cache, run a preparer/admission, move/copy a cache or run firmware.

Two independent atomic rename transfers are supplied, one per ABI: `arm/` and `aarch64/`. Both retain the GENERIC adapter's exact same-filesystem `renameat2(RENAME_NOREPLACE)` mechanism,120s bound, original device/inode, fresh actual-host≤900s dependency assessment, source/publication and admission checks. Stable container prefix is `/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-01`. No overwrite, symlink/hardlink alias, copy fallback, rollback or duplicate cache.

This follows accepted atomic ownership-transfer precedent: GENERIC transfer20261015T161403Z-91c45da4, consumedca5afc3cd3184396a56e9bcae9990cf0, and its earlier035306Z-b0f999e1 predecessor. It is an explicitly reviewed custody succession, separate from device-builds' normal independent-copy recipe. Old tracked source, target and original receipts remain unchanged. No claim is made that a pair of renames is one filesystem transaction.

The current H700 cache provenance binds the actual combined producer20261015T060011Z-92b2fe8b, consumed61759727b2944475ba2544bd238337a0, with original1/0/1 and launcher1. It stays failed-investigated. Independent acceptance20261015T064734Z-8868082e, consumed4ebc249f9b7d4e9a8c61cff36cc23fea, qualified DDR3/DDR4/raw/update artifact scope under acceptancee8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db. Earlier initial gateway2 and selected-state acceptance1 are not relabelled. Each `predecessor-binding.json` binds the actual selected original receipts.

Both transfer entrypoints refuse until the new GENERIC build AND independent artifact proof at the fixed `pix-m7-zerotier-generic-build-20261015-01` and `pix-m7-zerotier-generic-readback-20261015-02` owners have been consumed with original zeros at077197. They recheck actual completion-evidence hashes and PASS artifact content. No generic runtime claim is inferred.

Run the following sequence separately for `TASK_ABI=arm` and `TASK_ABI=aarch64`. Finish and consume the first before submitting the second. Root's new owners and cache destination paths must be fresh. Do not run this as a single unattended loop.

```bash
TASK_ABI=arm
TASK_PACKET=/tmp/pix-m7-zerotier-h700-refresh-20261015/transfer02/$TASK_ABI
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-05
TASK_OWNER=/workspace/tmp/pix-m7-zerotier-h700-transfer-$TASK_ABI-20261015-01
(cd "$TASK_PACKET" && sha256sum -c SHA256SUMS)
mkdir -m 700 "$TASK_OWNER"
cd "$TASK_TREE"
tools/build-preflight
python3 -I "$TASK_PACKET/prepare-plan.py" --checkout "$TASK_TREE" --commit 077197e6cd3ea31f33b28aaf3882a694b3423b53 --es-recipe-sha256 1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719 --expected-es 16dbac5211eea7e70db7394372033be2be7df829 --measurement "$TASK_PACKET/capacity-measurement.json" --owner "$TASK_OWNER" --stage transfer
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
tools/watch-build --record-only -- python3 -I "$TASK_PACKET/dependency-readback.py" --output "$TASK_OWNER/dependency-readback.json"
```

Root writes a fresh `dependency-assessed.json` only after reviewing the original census/error scope and prepared consumers of THIS ABI root. Use the existing assessment schema (`root`, `root_identity`, original `utc_epoch`, actual host namespace, `status=CLEAR_WITH_STATED_SCOPE`, raw evidence/hash, justified errors/exemptions, `prepared_consumers_resolved`, empty `process_matches`, `remaining_consumers`, `active_admissions`, and `docker_all_mounts`). Never copy an old CLEAR or refresh its observation timestamp. A remaining consumer of the other root must be assessed separately before that root's move.

```bash
TASK_DEPENDENCY_SHA=$(sha256sum "$TASK_OWNER/dependency-assessed.json")
TASK_DEPENDENCY_SHA=${TASK_DEPENDENCY_SHA%% *}
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" --activity-dir "$TASK_OWNER" -- python3 -I "$TASK_PACKET/transfer-cache.py" --owner "$TASK_OWNER" --commit 077197e6cd3ea31f33b28aaf3882a694b3423b53 --es-recipe-sha256 1d91f4a72032c67b89c0d986d26b728cf501f11bb9de891c168eb4f3f37d2719 --dependency-readback "$TASK_OWNER/dependency-assessed.json" --dependency-sha256 "$TASK_DEPENDENCY_SHA"
# After actual original watcher and launcher completion:
python3 -I "$TASK_PACKET/consume-transfer.py" --owner "$TASK_OWNER"
```

A failed transfer remains failed. If ARM moves and AArch64 fails, only ARM is transferred; retain its consumed receipt and do not rerun it. A fresh reviewed retry owner may attempt only the still-unmoved root after actual state assessment. No automatic move-back or pair-PASS summary is supplied. New build preparation will require BOTH exact consumed cache-ready records, with current destination device/inode and old-root absence. No build can use the partially transferred pair.

The capacity JSON is the existing05:23 H70003 historical measurement (ARM26,834,862,080B/AArch64111,496,507,392B); it is explicitly not current H70004 occupancy. Transfers retain the existing metadata+64GiB operating-margin allowance, no copy reservation and no future deletion credit. The original measurement hash and24-hour age guard stay. Both cache roots are retained only for the immediately queued canonical H700 ARM→AArch64 image and readback/source dependency. Retire superseded large firmware/scratch through the existing retention workflow after named immediate consumers close, preserving compact originals (D-INFRA-022).

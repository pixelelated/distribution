# Corrected engineering payload continuation — SOURCE ONLY, UNRUN

Completed image02 is fac608ff89940ce358ea9b8a95e9a08a6fe26568 / ES3178b832b8d134198b2b4eede4f725d4ed283f8c, identity0.0.1-dev+20261014T230300Z.gfac608ff8994. Existing independent readback is /workspace/tmp/pix-m7-image-readback-20261014-02/artifacts. No image verification, source producer, runtime, component control, VM, build, allocation, provider or host state checker ran in this source lane.

The remaining actual-artifact step is unchanged tools/pixelelated-state-check --payload on the new update tar and install img.gz, followed by the unchanged #566 positive shared-pair reader on those two original JSON outputs. This is the existing selected-state/release-isolation policy, not a new acceptance gate. Actual update/install artifacts remain on their frozen target path and are hashed before and after each inspection. Their SYSTEM/KERNEL/raw-update equivalence is already accepted readback; do not repeat it.

payload-check.sh is byte-identical to the successful payload02 PATH-corrected wrapper5116dd44…5ac809. It includes /usr/sbin so debugfs is available, and supplies exactly the bound mcopy executable on private PATH. check-shared-identity.py is unchanged16864703…f38542. The old source-inputs.json would refuse fac608ff because it pins checker a0b03f17. The additive source-inputs.json pins the qualified6d061af8 checker and same2050c806 mcopy bytes at the transferred tree02 cache path. Historical binding remains in original-source-inputs.json; no original packet or outcome was changed.

The two actual artifact bindings are:

- update tar2123130880B: e409bc18236cebfe12b24cdaede092c338d51cfe601ea6b89b486ff5578a2e42;
- install img.gz2122142712B: d816d36abc66b292500b0719e672c98c33eb0cd4fc7fc0bf19f7e26e4108bb16.

source-applicability.json independently compares the small completed old/new verifier records:97 selected members' bytes/modes/rooted links equal, only os-release differs; five newly inventoried members comprise newly retained libgstnet plus four already-existing plugin consumers. This is not whole-image equality. Exact git product-path comparison finds only the GStreamer override change. All45 proxy pycs, final native ELF, controller/scanner, ES and selected other product identities remain equal. The accepted original112-source/45-pyc/24-allocated-section chain therefore remains applicable to those identical bytes; do not rerun source export/compiler/imports. Its original limits remain: nested build/compileall0 inferred through install309 DONE/fail-fast sources, no standalone waits, original strip exit unknown. This continuation is not a rewritten provenance receipt or new-image runtime PASS.

Public release preparation is intentionally inapplicable to this engineering identity: unchanged tools/fork-publish-release:31–33 requires MAJOR.MINOR.PATCH[-rc.N] and rejects0.0.1-dev before reaching its actual payload inspection. Do not relabel these artifacts or fabricate a public bundle. Previously accepted synthetic release-preparation controls remain accepted. At eventual authorized public preparation the exact existing command is `tools/fork-publish-release --prepare IMMUTABLE_PUBLIC_BUNDLE`; it must inspect every actual final asset again. These direct engineering payload reports cannot bypass that integration. No public release, RC designation, upload, tag or external transfer is requested.

## Concrete coordinator commands

owner-template contains only small unexecuted source files with owner03 paths. Do not launch until the active owner in tree02 is finished/consumed and root allocates this short host-only reader. The source lane did not create/register that owner.

```bash
TASK_PACKET=/tmp/pix-m7-corrected-payload-continuation-20261014
TASK_OWNER=/workspace/tmp/pix-m7-payload-chain-20261014-03
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02
# Verify this delivered SHA256SUMS before copying the exact owner files.
test ! -e "$TASK_OWNER"
mkdir -m 700 "$TASK_OWNER" "$TASK_OWNER/empty-scan"
cp "$TASK_PACKET/owner-template/run.sh" "$TASK_PACKET/owner-template/launch.sh" "$TASK_PACKET/owner-template/inputs.json" "$TASK_PACKET/owner-template/retention-plan.json" "$TASK_PACKET/owner-template/admission-plan.json" "$TASK_OWNER/"
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
# Consume the report's actual original channels before the fresh admission.
python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" --activity-dir "$TASK_OWNER" -- bash "$TASK_OWNER/launch.sh"
```

Unchanged bounds: oneCPU0,8GiB address space/process,16GiB file-size limit/process,1500s whole timeout+15s kill allowance; each payload timeout600s+15s, shared-pair reader30s+5s. Existing retention reserves25GiB extraction scratch+8GiB margin. This is a declared disk allowance, not a kernel filesystem quota. The actual outputs are tiny selected-policy reports; temporary extraction belongs only under owner03/payload-scratch and a successful wrapper requires that directory empty. No old raw image/cache copy occurs. New run.sh adds only small dependency-hash checks before the original two command stages; it records binding.rc and preserves the original child return code in payload.rc/shared-identity.rc. Fail-stop behavior is unchanged.

Require original launcher/command/monitor/runner/tool-wrapper0, binding.rc0, payload.rc0, update.rc0, install.rc0 and shared-identity.rc0. Both reports must be clean-image selected policy pass, zero errors/blocked, exact input kinds update-tar/install-image. Positive reader must show approved shared identity count>0 and unapproved developer count0 in both. Inspect actual process exits and private scratch emptiness; use the printed actual watch-build run path for the ordinary reviewed consumption evidence. Preserve original JSON/stdout/stderr/rc files and immutable inputs/source-applicability/seal. Do not manufacture pass from exporter0 or overwrite a failed owner; a failed run retains its originals for diagnosis.

After review, consume the existing admission with exact outputs and evidence hashes, retain compact receipts, then retire only this owner's scratch/bin link. No source/component fixture repeats, new clean boot, retained upgrade or UI case are part of this allocation. Those accepted and ongoing runtime owners keep their own source-bound scope and genuine original exits. Nova historical provenance remains unknown as previously recorded.

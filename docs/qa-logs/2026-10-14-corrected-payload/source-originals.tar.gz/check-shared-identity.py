#!/usr/bin/env python3
"""UNRUN reader for the existing #566 positive compiled-pair criterion."""
import argparse
import json
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--update',type=Path,required=True)
p.add_argument('--install',type=Path,required=True)
a=p.parse_args()
result={'status':'FAIL','criterion':'existing-566-approved-compiled-pair','reports':{}}
try:
    for name,path,kind in [('update',a.update,'update-tar'),('install',a.install,'install-image')]:
        assert path.stat().st_size <= 2*1024**2
        report=json.loads(path.read_text())
        assert report['schema']==1 and report['policy']=='pixelelated-selected-state-v1'
        assert report['status']=='pass' and report['blocked_count']==0 and report['error_count']==0
        assert report['input_kind']==kind
        rows=[r for r in report['checks'] if r['path']=='/usr/bin/emulationstation']
        counts={}
        for category,status in [('approved-shared-developer-identity','allowed'),('developer-service-identity','clear')]:
            matches=[r for r in rows if r['category']==category]
            assert len(matches)==1 and matches[0]['present'] is True
            row=matches[0];assert type(row['count']) is int and row['status']==status
            counts[category]=row['count']
        assert counts['approved-shared-developer-identity']>0 and counts['developer-service-identity']==0
        result['reports'][name]=counts
    result['status']='PASS'
except Exception:
    result['error']='original-payload-report-or-shared-identity-criterion-failed'
print(json.dumps(result,sort_keys=True))
raise SystemExit(0 if result['status']=='PASS' else 1)

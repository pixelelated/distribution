#!/bin/bash
# Administrator command proposal only. Not invoked during source preparation.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-stopped-media-root-readback-20261015
TASK_OUTPUT=/workspace/tmp/pix-m7-stopped-media-root-readback-20261015-01
cd "$TASK_PACKET"
/usr/bin/sha256sum --check SHA256SUMS >/dev/null
umask 077
# Refuse an existing output owner; no original receipt is replaced.
/usr/bin/mkdir -- "$TASK_OUTPUT"
/usr/bin/cp -- commands.sh "$TASK_OUTPUT/command.sh"
/usr/bin/sha256sum -- readonly-process-dependencies.py scope.json > "$TASK_OUTPUT/input-sha256.txt"
/usr/bin/date --utc --iso-8601=ns > "$TASK_OUTPUT/started.txt"
# The administrator authenticates this one read-only command normally.
# No sudoers change, installation, cached-auth request, or process stop is involved.
set +e
/usr/bin/sudo -- /usr/bin/timeout --signal=TERM --kill-after=5s 60s \
  /usr/bin/python3 -I -S -B "$TASK_PACKET/readonly-process-dependencies.py" \
  > "$TASK_OUTPUT/readback.json" 2> "$TASK_OUTPUT/command.stderr"
TASK_COMMAND_RC=$?
set -e
printf '%s\n' "$TASK_COMMAND_RC" > "$TASK_OUTPUT/command.exit"
/usr/bin/date --utc --iso-8601=ns > "$TASK_OUTPUT/finished.txt"
# This is the observed sudo/timeout command status, not an invented inner wait.
# 124 remains an outer timeout; no child success is inferred from partial JSON.
exit "$TASK_COMMAND_RC"

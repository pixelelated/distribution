#!/bin/bash
# One-use user-terminal readback only. Source prepared; not executed by the agent.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-stopped-media-root-readback-20261015
TASK_OUTPUT=/workspace/tmp/pix-m7-stopped-media-root-readback-20261015-02
TASK_TERMINAL_WRAPPER=/tmp/pix-m7-stopped-media-root-readback-terminal-20261015/commands.sh
if [[ "$#" -ne 0 || ! -t 0 || ! -t 1 || ! -t 2 ]]; then
  printf 'Run this exact command, without arguments, in your own terminal for authentication.\n' >&2
  exit 2
fi
TASK_EXPECTED_SEAL=a777127dfcd052de9edf9a84ba0e9e42b924cbdccc62657f4502d1c42eeafe61
TASK_OBSERVED_SEAL=$(/usr/bin/sha256sum -- "$TASK_PACKET/SHA256SUMS")
[[ "${TASK_OBSERVED_SEAL%% *}" == "$TASK_EXPECTED_SEAL" ]]
cd "$TASK_PACKET"
/usr/bin/sha256sum --check SHA256SUMS >/dev/null
umask 077
# Refuse an existing output owner; no original receipt is replaced.
/usr/bin/mkdir -- "$TASK_OUTPUT"
/usr/bin/cp -- "$TASK_TERMINAL_WRAPPER" "$TASK_OUTPUT/command.sh"
/usr/bin/sha256sum -- readonly-process-dependencies.py scope.json > "$TASK_OUTPUT/input-sha256.txt"
/usr/bin/date --utc --iso-8601=ns > "$TASK_OUTPUT/started.txt"
# The administrator authenticates this one read-only command normally.
# No sudoers change, installation, cached-auth request, or process stop is involved.
set +e
/usr/bin/sudo -- /usr/bin/timeout --signal=TERM --kill-after=5s 60s \
  /usr/bin/python3 -I -S -B "$TASK_PACKET/readonly-process-dependencies.py" \
  > "$TASK_OUTPUT/readback.json" 2> "$TASK_OUTPUT/command.stderr"
TASK_COMMAND_RC=$?
set -e
printf '%s\n' "$TASK_COMMAND_RC" > "$TASK_OUTPUT/command.exit"
/usr/bin/date --utc --iso-8601=ns > "$TASK_OUTPUT/finished.txt"
# This is the observed sudo/timeout command status, not an invented inner wait.
# 124 remains an outer timeout; no child success is inferred from partial JSON.
exit "$TASK_COMMAND_RC"

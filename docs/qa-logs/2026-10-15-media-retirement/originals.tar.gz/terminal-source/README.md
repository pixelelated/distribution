# User-terminal readback continuation, owner02 (#493)

SOURCE ONLY / UNRUN. The original owner01 failed before the privileged reader
started: command exit1, empty readback.json, and exact stderr
`sudo: A terminal is required to authenticate`. The earlier successful
`sudo -n -l` command only listed permission; it did not establish that execution
could authenticate without a terminal. The original source and failed owner01
remain unchanged.

The exact user-terminal command is:

```sh
bash /tmp/pix-m7-stopped-media-root-readback-terminal-20261015/commands.sh
```

Wrapper SHA256:
`2143a3202a267cb3cc260eca30e9092096ed650b22877903e93e7714c1dea087`.
It accepts no arguments and requires terminal stdin/stdout/stderr before
creating the fresh output owner
`/workspace/tmp/pix-m7-stopped-media-root-readback-20261015-02`.
It verifies the original packet seal
`a777127dfcd052de9edf9a84ba0e9e42b924cbdccc62657f4502d1c42eeafe61`
and every payload hash. The reader remains byte-identical
`f8f5b424076a48972eb4fb743e8fe1c8ff89c722ec114e904b51682320023a5d`
at its original fixed path, with scope
`b36e940bfca07640cfef66c91fe4e7e5ef13f5b6b802549cc2765788264d460c`.

The sole privileged action is unchanged:

```sh
/usr/bin/sudo -- /usr/bin/timeout --signal=TERM --kill-after=5s 60s \
  /usr/bin/python3 -I -S -B \
  /tmp/pix-m7-stopped-media-root-readback-20261015/readonly-process-dependencies.py
```

The user authenticates in their own terminal. No password is supplied to the
agent, passed in arguments/stdin, or stored. This command only reads the exact
five files' metadata and target-scoped process references. It cannot delete,
stop another process, install a helper, change sudoers, read the media payloads,
or authorize cleanup. The timeout can end its own reader. Its stdout/stderr,
observed command status and timestamps are captured by the unprivileged shell.
Outer124 and missing/partial output remain failures, not invented inner status.
A zero result still supplies only a scoped snapshot for root review; ordinary
current dependencies and consumed holds are not waived.

`commands.diff` is the complete wrapper delta. It changes only the fresh owner,
terminal/argument guard, original seal check, and captured wrapper source path.
The fixed privileged command is byte-identical. Static bash syntax check passed;
neither this wrapper nor the reader was invoked during preparation.

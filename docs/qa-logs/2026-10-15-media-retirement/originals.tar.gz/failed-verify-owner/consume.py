"""Read original record-only completion; never consume or rewrite a registry row."""
from pathlib import Path
import argparse,hashlib,json,os
O=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['verify','apply']);parser.add_argument('--failed-investigated',action='store_true');args=parser.parse_args()
P=O/args.phase;J=json.loads((O/'plan.json').read_text());assert Path.cwd()==Path(J['tree'])
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert os.stat('/proc/self/ns/pid').st_ino==J['required_actual_host_pid_namespace'] and os.getuid()==J['uid']
for name,h in load(O/'seal.json').items():assert sha(Path(name))==h,name
run=Path((P/'run.path').read_text().strip());assert run.parent==Path(J['tree'])/'.build-runs' and not (run/'admission.json').exists()
r=load(run/'runner-result.json');launch=load(P/'launcher-result.json')
assert all(type(r[k]) is int for k in ('command_rc','monitor_rc','runner_rc'))
assert r['monitor_rc']==0 and r['command_rc']==int((run/'build.rc').read_text())
assert (run/'build.status').read_text().startswith('state:       finished\n')
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==r['runner_rc']==int((P/'tool-wrapper.rc').read_text())
pids={launch['pid']}
for name in ('build.pid','command.pid','watcher.pid','build.status.pid'):
 p=run/name
 if p.exists():pids.add(int(p.read_text().strip()))
assert all(not Path('/proc',str(pid)).exists() for pid in pids)
proof=P/'artifacts/retirement-result.json';journal=P/'artifacts/retirement.jsonl'
rows=[json.loads(line) for line in journal.read_text().splitlines()]
inner=int((P/'inner.rc').read_text()) if (P/'inner.rc').exists() else None
if not args.failed_investigated:
 assert r['command_rc']==r['runner_rc']==inner==0
 j=load(proof);assert j['result']=='PASS' and j['status']==('VERIFIED' if args.phase=='verify' else 'RETIRED')
 assert rows[-1]['status']==j['status']
 if args.phase=='apply':assert set(j['removed'])=={t['path'] for t in J['targets']} and all(not os.path.lexists(t['path']) for t in J['targets'])
else:
 assert r['runner_rc']!=0
 # An outer timeout124 or missing inner status remains exactly that observation.
 assert rows[-1]['status'] in ('REFUSED_WITHOUT_DELETION','FAILED_PARTIAL','STARTED','VALIDATED','UNLINKED','VERIFIED','RETIRED')
files=[O/'plan.json',O/'seal.json',P/'launcher-result.json',P/'tool-wrapper.rc',run/'runner-result.json',run/'build.rc',run/'build.status',journal,P/'console.log']
for p in [P/'inner.rc',proof,P/'artifacts/process-visibility-refusal.json']:
 if p.exists():files.append(p)
record={'result':'FAILED_INVESTIGATED' if args.failed_investigated else 'PASS','phase':args.phase,'run':str(run),'original_result':r,'original_inner_returncode':inner,'original_outer_returncode':r['command_rc'],'original_launcher_returncode':launch['runner_returncode'],'pids_absent':sorted(pids),'result_sha256':sha(proof) if proof.exists() else None,'evidence':[{'path':str(p),'sha256':sha(p)} for p in files],'registry_mutation':False,'old_consumed_output_holds_unchanged':True,'scope':'Evidence consumption of a record-only operation; this is not build-admission consumption or a relabelled old hold'}
with (P/'consumption.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'result':record['result'],'phase':args.phase,'original_inner':inner,'original_outer':r['command_rc'],'registry_mutation':False}))

"""One in-process phase; original inner status is distinct from outer timeout124."""
from pathlib import Path
import hashlib,json,os,runpy,signal,sys
O=Path(__file__).resolve().parent
phase=sys.argv[1];assert phase in ('verify','apply')
P=O/phase;J=json.loads((O/'plan.json').read_text());assert Path.cwd()==Path(J['tree'])
with (P/'run.path').open('x') as f:f.write(str(Path.cwd()/os.environ['RASTERATOPS_BUILD_RUN'])+'\n')
def terminate(signum,frame):raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
rc=1
try:
 for name,h in json.loads((O/'seal.json').read_text()).items():
  assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
 sys.argv=[str(O/'retire.py'),phase]
 runpy.run_path(str(O/'retire.py'),run_name='__main__')
 rc=0
except SystemExit as error:
 rc=error.code if type(error.code) is int else 1
 raise
finally:
 with (P/'inner.rc').open('x') as f:f.write(str(rc)+'\n')
sys.exit(rc)

#!/usr/bin/env python3
"""One reviewed five-file retirement; no recursive deletion or privilege change."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import struct
import subprocess
import time

HERE = Path(__file__).resolve().parent
ARTIFACTS = None

def require(value, message):
    if not value:
        raise RuntimeError(message)


def read(path, limit=16 * 1024 * 1024):
    with Path(path).open('rb') as stream:
        value = stream.read(limit + 1)
    require(len(value) <= limit, 'oversized input: ' + str(path))
    return value


def load(path):
    return json.loads(read(path))


def shape(value):
    return {k: getattr(value, 'st_' + k) for k in
            ('dev', 'ino', 'mode', 'nlink', 'uid', 'gid', 'size',
             'mtime_ns', 'ctime_ns', 'blocks')}


def same_inode(value, expected):
    return all(getattr(value, 'st_' + k) == expected[k]
               for k in ('dev', 'ino', 'mode', 'uid', 'gid'))


def backing_file(path):
    require(path.resolve() == path and stat.S_ISREG(path.lstat().st_mode),
            'QCOW path is not a direct regular file: ' + str(path))
    with path.open('rb') as stream:
        header = stream.read(20)
        require(len(header) == 20, 'short QCOW header: ' + str(path))
        magic, version, offset, length = struct.unpack('>4sIQI', header)
        require(magic == b'QFI\xfb' and version in (2, 3), 'unknown QCOW header')
        if not length:
            require(offset == 0, 'unexpected empty QCOW backing offset')
            return None
        require(20 <= offset <= 65536 and length <= 4096,
                'QCOW backing reference outside bounded header')
        stream.seek(offset)
        raw = stream.read(length)
        require(len(raw) == length and b'\0' not in raw, 'invalid backing name')
        value = Path(raw.decode())
        return str((path.parent / value).resolve())

def check_receipts(plan):
    for name, row in plan['receipt_bindings'].items():
        p = Path(name)
        require(p.resolve() == p and stat.S_ISREG(p.lstat().st_mode), 'receipt redirected: ' + name)
        data = read(p, 32 * 1024 * 1024)
        require(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'receipt changed: ' + name)
    for item in plan['admissions']:
        receipt = load(item['receipt']['path'])
        require(receipt['state'] == 'consumed' and receipt['id'] == item['id'] and receipt['run'] == item['run'], 'original admission changed')
        require(receipt['submission_owner'] == item['submission_owner'], 'original owner changed')
        require(receipt['outputs_held'] is True and receipt['deleted_bytes'] == 0, 'original hold record changed')
        for key, code in item['expected_original_result'].items():
            require(type(receipt['original_result'][key]) is int and receipt['original_result'][key] == code, 'original status changed')
        run = Path(item['run']); owner = Path(item['submission_owner'])
        require(load(run / 'runner-result.json') == receipt['original_result'], 'runner differs from consumed result')
        code = receipt['original_result']['runner_rc']
        require(load(owner / 'launcher-result.json')['runner_returncode'] == code == int(read(owner / 'tool-wrapper.rc')), 'original launcher differs')
        require(int(read(run / 'build.rc')) == receipt['original_result']['command_rc'], 'original command differs')
    # This supplements original output holds; it never edits or re-consumes them.
    for row in plan['protected']:
        p = Path(row['path']); require(p.resolve() == p and same_inode(p.lstat(), row['identity']), 'protected path replaced')
    h = load('/workspace/tmp/pix-m7-h700-state-acceptance-20261015-01/artifacts/acceptance.json')
    require(h['result'] == 'PASS' and h['scratch_removed'] is True and h['failed_acceptance_returncode'] == 1, 'replacement acceptance scope changed')
    require(all(v['system_sha256'] == '69dafbfacc07a6f59a12d35dc35c1839027458d695ba2fb0493d800bac7b5e67' for v in h['variants']), 'replacement SYSTEM changed')


def check_registry(plan, run):
    require(not (run / 'admission.json').exists(), 'retirement must use record-only monitoring')
    jobs = load(Path(plan['registry']) / 'jobs.json')['jobs']
    for item in plan['admissions']:
        row = jobs[item['id']]; receipt = load(item['receipt']['path'])
        for key in ('id', 'state', 'run', 'submission_owner', 'original_result', 'evidence_sha256', 'outputs', 'outputs_held', 'deleted_bytes'):
            require(row[key] == receipt[key], 'prior registry entry changed: ' + key)
    targets = [r['path'] for r in plan['targets']]
    parents = sorted({r['parent'] for r in plan['targets']})
    active = []
    for row in jobs.values():
        if row.get('state') == 'consumed':
            continue
        for output in row.get('outputs', []):
            require(not any(overlaps(output['path'], t) for t in targets), 'unconsumed output hold overlaps target')
        texts = [json.dumps(row)]
        submission = row.get('submission_owner')
        if submission:
            # Existing known owner metadata only, not a filesystem-wide search.
            for base in (Path(submission), Path(submission).parent):
                for name in ('config.json', 'bindings.json', 'plan.json'):
                    candidate = base / name
                    if candidate.exists():
                        require(candidate.resolve() == candidate, 'active owner metadata redirected')
                        texts.append(read(candidate).decode())
        require(not any(p in text for p in parents for text in texts), 'unconsumed owner metadata refers to target media')
        active.append(row['id'])
    return {'prior_consumed_ids': [a['id'] for a in plan['admissions']], 'other_unconsumed_ids_checked': active, 'old_outputs_held_unchanged': True, 'registry_write_performed': False}


def proc_identity(p):
    raw = read(p / 'stat', 65536); prefix, sep, tail = raw.rpartition(b')')
    require(sep and prefix.split(b' (', 1)[0] == p.name.encode(), 'malformed process stat')
    f = tail.split(); require(len(f) >= 20, 'short process stat')
    status = read(p / 'status', 65536).decode()
    values = dict(line.split(':', 1) for line in status.splitlines() if ':' in line)
    return {'pid': int(p.name), 'start_ticks': int(f[19]), 'state': f[0].decode(), 'kernel': values.get('Kthread', '').strip() == '1'}


def exists_pid(p):
    try:
        p.stat(); return True
    except (FileNotFoundError, ProcessLookupError):
        return False


def check_processes(plan):
    require(os.stat('/proc/self/ns/pid').st_ino == plan['required_actual_host_pid_namespace'] and os.getuid() == plan['uid'], 'wrong actual-host namespace or UID')
    for pid in plan['recorded_pids_must_be_absent']:
        require(not exists_pid(Path('/proc') / str(pid)), 'recorded owner PID exists: ' + str(pid))
    names = [r['path'] for r in plan['targets']]
    parents = sorted({r['parent'] for r in plan['targets']})
    identities = {(r['identity']['dev'], r['identity']['ino']) for r in plan['targets']}
    identities |= {(r['parent_identity']['dev'], r['parent_identity']['ino']) for r in plan['targets']}
    checked = []; unavailable = []; deadline = time.monotonic() + 30
    for p in Path('/proc').iterdir():
        if not p.name.isascii() or not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        require(time.monotonic() < deadline, 'process checks exceeded 30 seconds')
        try:
            before = proc_identity(p)
            if before['kernel']:
                continue
            argv = read(p / 'cmdline', 4 * 1024 * 1024)
            require(not any(n.encode() in argv for n in parents), 'live argv references selected parent: ' + p.name)
            denied = []
            try:
                links = [p / 'cwd', p / 'root', *list((p / 'fd').iterdir())]
            except PermissionError:
                links = [p / 'cwd', p / 'root']; denied.append('fd')
            for link in links:
                try:
                    s = link.stat(); target = os.readlink(link)
                except (FileNotFoundError, ProcessLookupError):
                    if link.parent == p / 'fd':
                        continue
                    if not exists_pid(p):
                        raise
                    if before['state'] == 'Z':
                        continue
                    raise RuntimeError('live process has missing cwd/root: ' + p.name)
                except PermissionError:
                    denied.append(str(link.relative_to(p))); continue
                require((s.st_dev, s.st_ino) not in identities and not any(n in target for n in parents), 'live descriptor/cwd/root uses target: ' + p.name)
            try:
                maps = read(p / 'maps', 16 * 1024 * 1024)
                require(not any(n.encode() in maps for n in names), 'live mapping uses target: ' + p.name)
            except PermissionError:
                denied.append('maps')
            after = proc_identity(p)
            require(before['pid'] == after['pid'] and before['start_ticks'] == after['start_ticks'], 'PID changed during check')
            if denied:
                unavailable.append({'identity': before, 'fields': denied})
            checked.append(before)
        except (FileNotFoundError, ProcessLookupError):
            require(not exists_pid(p), 'incomplete live process check: ' + p.name)
    report = {'checked_process_identities': checked, 'unreadable': unavailable, 'inherited_exceptions': [], 'whole_host_absence_claimed': False}
    if unavailable:
        with (ARTIFACTS / 'process-visibility-refusal.json').open('x') as f:
            json.dump(report, f, indent=2); f.write('\n')
        raise RuntimeError('unresolved exact process fields; no deletion or automatic privileged request')
    return report


def child_output(args):
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20, check=False)
    require(p.returncode == 0 and not p.stderr and len(p.stdout) <= 4 * 1024 * 1024, 'dependency command failed/diagnostic/oversized: ' + args[0])
    return p.stdout


def overlaps(path, target):
    return path == target or path.startswith(target.rstrip('/') + '/') or target.startswith(path.rstrip('/') + '/')


def check_dependencies(plan):
    targets = [r['path'] for r in plan['targets']]
    qcows = []; deadline = time.monotonic() + 30
    # Existing conventional media layouts only; no recursive volume walk or grep.
    with os.scandir('/workspace/tmp') as owners:
        for owner in owners:
            if not owner.is_dir(follow_symlinks=False):
                continue
            for sub in ('vm', 'pair'):
                d = Path(owner.path) / sub
                try:
                    s = d.lstat()
                except FileNotFoundError:
                    continue
                require(stat.S_ISDIR(s.st_mode) and not d.is_symlink(), 'unexpected conventional media directory')
                with os.scandir(d) as entries:
                    for e in entries:
                        if e.name.endswith('.qcow2'):
                            require(len(qcows) < 512 and time.monotonic() < deadline, 'backing inventory bound exceeded')
                            p = Path(e.path); backing = backing_file(p)
                            require(backing not in targets, 'another disk depends on selected media: ' + str(p))
                            qcows.append({'path': str(p), 'backing': backing})
    selected = next(r['path'] for r in plan['targets'] if r['path'].endswith('/disk.qcow2'))
    require(any(r['path'] == selected and r['backing'] is None for r in qcows), 'selected disk missing or gained backing dependency')
    cids = child_output(['docker', 'ps', '-aq', '--no-trunc']).decode().split()
    require(len(cids) <= 128 and len(set(cids)) == len(cids), 'unexpected container inventory')
    containers = json.loads(child_output(['docker', 'inspect', *cids])) if cids else []
    require({c['Id'] for c in containers} == set(cids), 'container inspection membership changed')
    for c in containers:
        for mount in c['Mounts']:
            require(not any(overlaps(mount['Source'], t) for t in targets), 'container mount uses target')
    def decode(value):
        for a, b in [('\\040',' '), ('\\011','\t'), ('\\012','\n'), ('\\134','\\')]: value = value.replace(a,b)
        return value
    mountrows = read('/proc/self/mountinfo', 4 * 1024 * 1024).decode().splitlines()
    for row in mountrows:
        left, right = row.split(' - ', 1); f = left.split(); g = right.split()
        require(len(f) >= 6 and len(g) >= 2, 'malformed mount row')
        # An ancestor filesystem like /workspace is normal; a mounted target is not.
        for value in (decode(f[4]), decode(f[3]), decode(g[1])):
            require(not any(value == t or value.startswith(t + '/') for t in targets), 'target appears in mount association')
    loops = []
    for p in Path('/sys/block').glob('loop*/loop/backing_file'):
        value = read(p, 65536).decode().strip(); value = '/' + value.lstrip('/')
        require(not any(value == t or value.startswith(t + '/') for t in targets), 'loop device references target')
        loops.append({'sysfs': str(p), 'backing': value})
    return {'qcow_headers': qcows, 'container_ids': cids, 'host_mount_rows_checked': len(mountrows), 'loop_backing_files': loops, 'scope': 'Conventional /workspace/tmp/*/{vm,pair} QCOW headers; all Docker mounts, current host mount namespace and visible loop associations; no recursive filesystem scan'}


def open_targets(plan):
    parents = {}; fds = {}
    try:
        for row in plan['targets']:
            p = Path(row['path']); parent = p.parent
            require(p.resolve() == p and stat.S_ISREG(p.lstat().st_mode), 'target redirected')
            if str(parent) not in parents:
                fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                parents[str(parent)] = fd
                require(shape(os.fstat(fd)) == row['parent_identity'], 'parent changed')
                require(set(os.listdir(fd)) == set(row['parent_members']), 'parent membership changed')
                require(os.fstat(fd).st_uid == plan['uid'] and os.fstat(fd).st_mode & stat.S_IWUSR, 'parent is not writable by owner')
            fd = parents[str(parent)]
            child = os.open(p.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd); fds[str(p)] = child
            s = os.fstat(child)
            require(shape(s) == row['identity'] and stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_uid == plan['uid'], 'target identity/ownership changed')
        return parents, fds
    except BaseException:
        for fd in [*fds.values(), *parents.values()]: os.close(fd)
        raise


def main():
    global ARTIFACTS
    parser = argparse.ArgumentParser(); parser.add_argument('phase', choices=['verify', 'apply']); args = parser.parse_args()
    phase_owner = HERE / args.phase; ARTIFACTS = phase_owner / 'artifacts'
    plan = load(HERE / 'plan.json'); run = Path(read(phase_owner / 'run.path').decode().strip())
    require(run.parent == Path(plan['tree']) / '.build-runs', 'wrong watched run')
    require(str(HERE) == plan['owner'] and len(plan['targets']) == 5, 'wrong exact owner/scope')
    removed = []; parents = {}; fds = {}; hashes = {}
    journal = ARTIFACTS / 'retirement.jsonl'
    with journal.open('x') as output:
        def event(status, **fields):
            output.write(json.dumps({'status': status, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), **fields}, sort_keys=True)+'\n')
            output.flush(); os.fsync(output.fileno())
        event('STARTED', plan_sha256=hashlib.sha256(read(HERE / 'plan.json')).hexdigest(), original_consumed_holds_preserved=True, phase=args.phase)
        lock = os.open(Path(plan['registry'])/'lock', os.O_RDONLY | os.O_NOFOLLOW)
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            check_receipts(plan); registry = check_registry(plan, run)
            parents, fds = open_targets(plan)
            for row in plan['targets']:
                h = hashlib.sha256(); fd = fds[row['path']]; os.lseek(fd, 0, os.SEEK_SET)
                while True:
                    b = os.read(fd, 1024*1024)
                    if not b: break
                    h.update(b)
                hashes[row['path']] = h.hexdigest()
                require(shape(os.fstat(fd)) == row['identity'], 'target changed while hashing')
                if row.get('historical_sha256'):
                    require(h.hexdigest() == row['historical_sha256'], 'target differs from recorded content')
            if args.phase == 'apply':
                consumed = load(HERE / 'verify/consumption.json')
                prior = HERE / 'verify/artifacts/retirement-result.json'
                require(consumed['result'] == 'PASS' and consumed['phase'] == 'verify' and consumed['result_sha256'] == hashlib.sha256(read(prior)).hexdigest(), 'verify completion not consumed')
                require(load(prior)['status'] == 'VERIFIED' and load(prior)['payload_sha256'] == hashes, 'verified media content changed')
            processes = check_processes(plan); deps = check_dependencies(plan)
            before = os.statvfs('/workspace'); available_before = before.f_bavail * before.f_frsize
            event('VALIDATED', registry=registry, processes=processes, dependencies=deps, payload_sha256=hashes, available_before=available_before)
            if args.phase == 'verify':
                result = {'result': 'PASS', 'status': 'VERIFIED', 'removed': [], 'payload_sha256': hashes, 'plan_sha256': hashlib.sha256(read(HERE / 'plan.json')).hexdigest(), 'original_consumed_holds_unchanged': True, 'deletion_performed': False}
                with (ARTIFACTS / 'retirement-result.json').open('x') as f: json.dump(result,f,indent=2); f.write('\n')
                event('VERIFIED', payload_sha256=hashes, removed=[])
                return
            for row in plan['targets']:
                check_registry(plan, run)
                p = Path(row['path']); parentfd = parents[row['parent']]
                require(same_inode(p.parent.lstat(), row['parent_identity']), 'parent path replaced')
                expected = set(row['parent_members']) - {Path(x).name for x in removed if str(Path(x).parent) == row['parent']}
                require(set(os.listdir(parentfd)) == expected, 'parent membership changed before unlink')
                require(shape(os.stat(p.name, dir_fd=parentfd, follow_symlinks=False)) == row['identity'], 'target changed immediately before unlink')
                # No child is spawned here. Delay interruption only across unlink plus fsynced journal.
                mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGTERM, signal.SIGINT})
                try:
                    os.unlink(p.name, dir_fd=parentfd); removed.append(row['path'])
                    os.fsync(parentfd)
                    event('UNLINKED', path=row['path'], identity=row['identity'], sha256=hashes[row['path']])
                finally:
                    signal.pthread_sigmask(signal.SIG_SETMASK, mask)
            # Closing the last read descriptor releases unlinked payload allocation.
            for fd in fds.values(): os.close(fd)
            fds.clear()
            require(all(not os.path.lexists(r['path']) for r in plan['targets']), 'selected path still exists')
            check_receipts(plan); check_registry(plan, run)
            after = os.statvfs('/workspace'); available_after = after.f_bavail * after.f_frsize
            result = {'result':'PASS','status':'RETIRED','removed':removed,'payload_sha256':hashes,'available_before':available_before,'available_after':available_after,'observed_available_delta_bytes':available_after-available_before,'unlinked_allocated_file_bytes':plan['expected_allocated_file_bytes'],'original_consumed_holds_unchanged':True,'retirement_record_supplements_holds':True,'bound_evidence_unchanged':True,'parent_directories_retained':True,'scope':'Only exact five files; available-space delta may include unrelated host activity'}
            with (ARTIFACTS/'retirement-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
            event('RETIRED', **{k:v for k,v in result.items() if k!='status'})
        except BaseException as error:
            event('FAILED_PARTIAL' if removed else 'REFUSED_WITHOUT_DELETION', error_type=type(error).__name__, error=str(error), removed=removed)
            raise
        finally:
            for fd in [*fds.values(),*parents.values()]:os.close(fd)
            os.close(lock)


if __name__ == '__main__':
    main()

# Five-file administrator process readback proposal (#493)

SOURCE ONLY / UNRUN. This packet prepares the exact read-only command needed to
investigate the stopped-media verify refusal. It does not retry verification,
modify the retirement adapter, grant a process exception, or authorize removal.

The original verify run `20261015T100631Z-25a99dcd` ended with original
command/monitor/runner `1/0/1`, launcher `1`, at process visibility. Parent reports
ordinary FAILED_INVESTIGATED consumption. No unlink occurred and the later
container/mount/backing dependency check was not reached. The exact retained
refusal identifies 195 process identities and 829 unreadable field entries;
253 identities were checked. The original failure and sealed retirement packet
`c50e35adabc168d099dc12b030eee7c570f853043d11f29c379a9c91eaed6586`
remain unchanged.

## Why this requires a separate administrator read

The root coordinator's actual inventory found only the installed
`/usr/local/sbin/pixelelated-reclaim-swap` helper. The canonical
`tools/host-maintenance/install` and README grant only its exact `--reclaim`
action. They provide no process-readback action. The installed policy file was
not readable in this agent's namespace; no claim is made to have read its bytes.
No noninteractive sudo command or privilege probe was attempted.

The existing October12 `readonly-process-dependencies.py` provided this same
read-only administrator workflow for 17 exact old trees. Its exact source and
README are retained under `originals/`; `source.diff` shows the one-use derivative.
Historical root snapshots do not cover these five new files. This is no new
installed helper or generic privileged executor: the derivative accepts no
arguments and reads one hash-bound scope from its fixed packet path.

## Exact scope

The only proposed removal identities remain these files; this reader does not
open their payloads or hash their bytes:

- `/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/OVMF.fd`, inode 206834831.
- `/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/disk.qcow2`, inode 206834830.
- `/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/input.ext4`, inode 206834876.
- `/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/output.ext4`, inode 206834877.
- `/workspace/tmp/pix-m7-h700-reader-20261015-01/acceptance/scratch/SYSTEM`, inode 192196638.

All five have recorded device 66304. `scope.json` binds their complete recorded
metadata and the identities of the two exact containing directories. Directory
references remain dependency matches because the existing verifier also checks
those two parents; neither directory is a removal target. Identity comparisons
include file size, type/mode, uid/gid, link count, allocation, mtime and ctime.
There is no broad filesystem walk or cache/firmware read.

The root reader checks actual-host PID namespace 4026531836, then reads numeric
`/proc` process identities, descriptor links/stat, cwd/exe/root links/stat,
cmdline and maps. It compares only the reviewed path scopes and device/inode
identities. Output includes matched reviewed paths and PID/start ticks/field
status. It does not emit raw arguments, full mappings, environment, file contents,
unrelated linked paths, credentials, or process names.

The 195 original PID/start-tick identities retain their exact field obligations.
Original readable identities and current extra identities are checked afresh;
reused PIDs are distinct. Vanished identities are recorded. Changed or unreadable
live identities are not accepted. A second numeric census reports any live
identity not covered by the first pass; it causes nonzero completion. Kernel
threads and this exact read-only reader are explicitly identified exclusions.
The reader holds no media payload descriptor. Closed descriptors and missing
zombie links are distinguished from incomplete reads of live processes.

Bounds are 30 seconds internally, 8192 processes, 16384 descriptors per process,
64 KiB identity fields, 4 MiB cmdline and 16 MiB maps. The proposed outer timeout
is 60 seconds plus a 5-second TERM-to-KILL grace for this command's own reader.
No other process is signalled. Exceeding a bound, unreadable data, identity
changes, late uncovered processes, or selected reference matches retains a
nonzero result. A fatal read emits only its error class/errno, not raw data.

## Concrete command for root review and later administrator execution

Review the sealed source and exact target list first. This agent has not invoked
any command in this section. There is no request to change sudoers or install a
helper. The administrator would run the wrapper in a normal terminal:

```sh
bash /tmp/pix-m7-stopped-media-root-readback-20261015/commands.sh
```

Its sole privileged action is exactly:

```sh
/usr/bin/sudo -- /usr/bin/timeout --signal=TERM --kill-after=5s 60s \
  /usr/bin/python3 -I -S -B \
  /tmp/pix-m7-stopped-media-root-readback-20261015/readonly-process-dependencies.py
```

Authentication stays in the administrator's terminal; no password is passed in
arguments, stdin, a file, or to the agent. Hash verification precedes the command.
The reviewed packet must stay unchanged through execution. This is a one-use
reviewed source invocation, not an enforced sudo command-digest policy.

The unprivileged wrapper exclusively creates the fresh output directory
`/workspace/tmp/pix-m7-stopped-media-root-readback-20261015-01`, captures stdout,
stderr, the exact input hashes, command copy, timestamps and actual command exit.
An existing output directory refuses the invocation. Output capture is not a
root write or permission change. `command.exit` is the sudo/timeout command's
status. Outer 124 remains a timeout; partial JSON never becomes a child success
or launcher receipt. Missing/failed authentication likewise leaves nonzero
originals and does not authorize a fallback. No readback owner exists from this
preparation task.

## What a later result can establish

A zero exit plus an intact complete JSON result can establish that this scoped
read observed no selected process reference. It remains a point-in-time snapshot,
not continuous custody or whole-host absence. It does not inspect registry
reservations, Docker mounts, loop devices, QCOW backing chains, or selected
payload hashes. The ordinary verify failed before those checks.

Root must inspect actual originals before proposing any narrowly bound consumer
change; no consumer or apply adapter is supplied here. Later current checks must
still cover newly created/reused processes and changed references. This packet
does not waive new/unreadable process evidence or consumed output holds, and it
does not make the five files ready for deletion by itself.

## Source-only validation

`static-review.py` parses source and inspects syntax/AST; it never imports or
executes the reader. Bash syntax validation likewise does not run the wrapper.
The original executable/helper and original refusal are retained exactly.
`static-review.json` and `static-execution-observation.json` describe only these
source checks; they are not privileged/runtime proof. No sudo, process census,
large-payload hashing, cleanup, admission or registry mutation ran in preparation.

"""One-use #493 read-only process reference snapshot for five stopped media files.

Derived from the October12 readonly-process-dependencies.py, retained in originals/.
No process stop, payload read, filesystem traversal, deletion or installed root grant.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import sys
import time

PACKET = Path('/tmp/pix-m7-stopped-media-root-readback-20261015')
SCOPE_SHA256 = 'b36e940bfca07640cfef66c91fe4e7e5ef13f5b6b802549cc2765788264d460c'
PROC = Path('/proc')
MAX_PROCESSES = 8192
MAX_FDS = 16384
DEADLINE = time.monotonic() + 30


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def bounded_read(path, limit):
    require(time.monotonic() < DEADLINE, '30-second readback budget exceeded')
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    require(len(data) <= limit, 'bounded field limit exceeded')
    return data


def identity(p):
    raw = bounded_read(p / 'stat', 65536)
    prefix, sep, tail = raw.rpartition(b')')
    require(sep and prefix.split(b' (', 1)[0] == p.name.encode(), 'malformed process stat')
    fields = tail.split()
    require(len(fields) >= 20, 'short process stat')
    status = bounded_read(p / 'status', 65536).decode()
    values = dict(line.split(':', 1) for line in status.splitlines() if ':' in line)
    return {'pid': int(p.name), 'start_ticks': int(fields[19]),
            'state': fields[0].decode(), 'kernel': values.get('Kthread', '').strip() == '1'}


def process_key(row):
    return row['pid'], row['start_ticks']


def exists(p):
    try:
        p.stat()
        return True
    except (FileNotFoundError, ProcessLookupError):
        return False


def numeric_processes():
    result = []
    with os.scandir(PROC) as entries:
        for entry in entries:
            if entry.name.isascii() and entry.name.isdigit():
                result.append(int(entry.name))
                require(len(result) <= MAX_PROCESSES, 'process count exceeds finite bound')
    return sorted(result)


def metadata(row):
    p = Path(row['path'])
    require(p.resolve() == p, 'reviewed target or parent path redirected')
    s = p.lstat()
    actual = {k: getattr(s, 'st_' + k) for k in row['identity']}
    require(actual == row['identity'], 'reviewed target or parent identity changed')
    return actual


def scan_process(p, before, pattern, inode_names, wanted):
    hits = set()
    failures = []
    read_fields = set()
    absent_fields = set()

    def classify(kind, value, stat_result=None):
        for match in pattern.finditer(value):
            hits.add((kind, match.group(0), 'reviewed-path'))
        if stat_result is not None:
            for name in inode_names.get((stat_result.st_dev, stat_result.st_ino), []):
                hits.add((kind, name, 'device-inode'))

    def link(field):
        try:
            value = os.readlink(p / field)
            s = (p / field).stat()
            classify(field, value, s)
            read_fields.add(field)
        except (FileNotFoundError, ProcessLookupError):
            if field.startswith('fd/') or before['state'] == 'Z' or not exists(p):
                absent_fields.add(field)
            else:
                failures.append({'field': field, 'reason': 'missing-on-live-process'})
        except OSError as exc:
            failures.append({'field': field, 'errno': exc.errno})

    for field in ('cwd', 'exe', 'root'):
        link(field)
    try:
        argv = bounded_read(p / 'cmdline', 4 * 1024 * 1024)
        for token in argv.split(b'\0'):
            classify('argument', os.fsdecode(token))
        read_fields.add('cmdline')
    except OSError as exc:
        failures.append({'field': 'cmdline', 'errno': exc.errno})
    try:
        with os.scandir(p / 'fd') as entries:
            fds = []
            for entry in entries:
                require(entry.name.isascii() and entry.name.isdigit(), 'unexpected descriptor entry')
                fds.append(entry.name)
                require(len(fds) <= MAX_FDS, 'descriptor count exceeds finite bound')
        for fd in sorted(fds, key=int):
            require(time.monotonic() < DEADLINE, '30-second readback budget exceeded')
            link('fd/' + fd)
        read_fields.add('fd')
        absent_fields.update(field for field in wanted if field.startswith('fd/')
                             and field not in read_fields and field not in {'fd/' + x for x in fds})
    except OSError as exc:
        failures.append({'field': 'fd', 'errno': exc.errno})
    try:
        maps = bounded_read(p / 'maps', 16 * 1024 * 1024).decode(errors='surrogateescape')
        for line in maps.splitlines():
            parts = line.split(None, 5)
            require(len(parts) >= 5, 'malformed mapping row')
            major, minor = parts[3].split(':')
            map_identity = (os.makedev(int(major, 16), int(minor, 16)), int(parts[4]))
            for name in inode_names.get(map_identity, []):
                hits.add(('mapping', name, 'device-inode'))
            if len(parts) == 6:
                classify('mapping', parts[5])
        read_fields.add('maps')
    except OSError as exc:
        failures.append({'field': 'maps', 'errno': exc.errno})
    after = identity(p)
    require(process_key(before) == process_key(after), 'PID identity changed during read')
    return {'identity': before, 'read_fields': sorted(read_fields),
            'absent_fields': sorted(absent_fields), 'unreadable': failures,
            'matches': [{'kind': k, 'reviewed_path': n, 'method': m} for k, n, m in sorted(hits)]}


def main():
    require(len(sys.argv) == 1, 'this reviewed reader accepts no arguments')
    require(Path(__file__).resolve() == PACKET / 'readonly-process-dependencies.py', 'unexpected reader path')
    require(os.geteuid() == 0, 'administrator read-only execution required')
    raw = bounded_read(PACKET / 'scope.json', 262144)
    require(hashlib.sha256(raw).hexdigest() == SCOPE_SHA256, 'reviewed scope bytes changed')
    scope = json.loads(raw)
    namespace = os.stat('/proc/self/ns/pid').st_ino
    require(namespace == scope['required_pid_namespace'], 'not the reviewed actual-host PID namespace')
    require(len(scope['targets']) == 5 and len(scope['original_refusals']) == 195, 'scope count changed')
    rows = scope['targets'] + scope['parent_dependency_scopes']
    for row in rows:
        metadata(row)
    names = [r['path'] for r in rows]
    pattern = re.compile('(?:' + '|'.join(re.escape(n) for n in sorted(names, key=len, reverse=True))
                         + r')(?=/|$|[\s\x00])')
    inode_names = {}
    for row in rows:
        inode_names.setdefault((row['identity']['dev'], row['identity']['ino']), []).append(row['path'])
    previous = {process_key(r): r for r in scope['original_checked_processes']}
    refusals = {process_key(r['identity']): r['fields'] for r in scope['original_refusals']}
    self_identity = identity(PROC / str(os.getpid()))
    observed, gone, errors, checked, kernel = [], [], [], set(), []
    for pid in numeric_processes():
        if pid == os.getpid():
            continue
        p = PROC / str(pid)
        before = None
        try:
            before = identity(p)
            if before['kernel']:
                kernel.append(before)
                checked.add(process_key(before))
                continue
            row = scan_process(p, before, pattern, inode_names, refusals.get(process_key(before), []))
            key = process_key(before)
            row['relation_to_original'] = ('original-refused' if key in refusals else
                                            'original-readable' if key in previous else 'current-extra')
            row['original_refused_fields'] = refusals.get(key, [])
            observed.append(row)
            checked.add(key)
        except (FileNotFoundError, ProcessLookupError):
            if exists(p):
                errors.append({'pid': pid, 'reason': 'incomplete-live-process-read'})
            else:
                gone.append({'pid': pid, 'identity': before, 'reason': 'disappeared-during-read'})
        except OSError as exc:
            errors.append({'pid': pid, 'identity': before, 'errno': exc.errno})
    # Explicitly refuse unseen or reused processes at the end. Never import old coverage.
    final_identities = []
    late = []
    for pid in numeric_processes():
        if pid == os.getpid():
            continue
        p = PROC / str(pid)
        try:
            now = identity(p)
            final_identities.append(now)
            if not now['kernel'] and process_key(now) not in checked:
                late.append(now)
        except (FileNotFoundError, ProcessLookupError):
            if exists(p):
                errors.append({'pid': pid, 'reason': 'incomplete-final-identity'})
        except OSError as exc:
            errors.append({'pid': pid, 'field': 'final-identity', 'errno': exc.errno})
    for row in rows:
        metadata(row)
    final = {process_key(r): r for r in final_identities}
    final_pids = {r['pid'] for r in final_identities}
    by_key = {process_key(r['identity']): r for r in observed}
    obligations = []
    for key, fields in sorted(refusals.items()):
        row = by_key.get(key)
        obligations.append({'pid': key[0], 'start_ticks': key[1], 'original_fields': fields,
                            'status': ('checked' if row and not row['unreadable'] else
                                       'unreadable' if row else 'not-covered' if key in final else
                                       'old-identity-gone-pid-reused' if key[0] in final_pids else 'no-longer-present'),
                            'original_fields_now_absent': sorted(set(fields) & set(row['absent_fields'])) if row else []})
    unreadable = [r for r in observed if r['unreadable']]
    matches = [{'identity': r['identity'], 'references': r['matches']} for r in observed if r['matches']]
    complete = not errors and not late and not unreadable
    output = {'schema': 1, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'effective_uid': os.geteuid(), 'pid_namespace': namespace, 'readonly': True,
              'scope_sha256': SCOPE_SHA256,
              'reader_sha256': hashlib.sha256(bounded_read(Path(__file__), 65536)).hexdigest(),
              'original_refusal_sha256': scope['original_refusal_sha256'],
              'targets': scope['targets'], 'parent_dependency_scopes': scope['parent_dependency_scopes'],
              'original_refused_processes': 195, 'original_refused_fields': scope['original_refused_field_count'],
              'original_refusal_dispositions': obligations, 'processes': observed,
              'current_extra_count': sum(r['relation_to_original'] == 'current-extra' for r in observed),
              'kernel_threads_excluded': kernel, 'disappeared': gone, 'late_uncovered_identities': late,
              'final_identities': final_identities, 'errors': errors, 'matches': matches,
              'field_read_complete': complete, 'no_selected_reference_observed': complete and not matches,
              'self_exclusion': {'identity': self_identity, 'reason': 'this exact read-only reader; no media payload descriptors'},
              'deletion_authorized': False, 'whole_host_absence_claimed': False,
              'limit': 'Point-in-time process references only. No registry/container/mount/backing-chain proof or exemption from fresh cleanup guards.'}
    print(json.dumps(output, indent=2, ensure_ascii=True))
    return 0 if complete and not matches else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError, KeyError) as exc:
        # No raw exception text from filesystem/proc values enters the output.
        print(json.dumps({'schema': 1, 'readonly': True, 'field_read_complete': False,
                          'deletion_authorized': False, 'fatal_type': type(exc).__name__,
                          'fatal_errno': getattr(exc, 'errno', None)}))
        raise SystemExit(1)

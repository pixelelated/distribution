"""Source/AST checks only; never import or execute the proposed reader."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

p = Path('/tmp/pix-m7-stopped-media-root-readback-20261015')
source = (p / 'readonly-process-dependencies.py').read_text()
tree = ast.parse(source)
imports = {n.names[0].name for n in ast.walk(tree) if isinstance(n, ast.Import)}
assert imports == {'datetime', 'hashlib', 'json', 'os', 're', 'sys', 'time'}
assert [(n.module, [a.name for a in n.names]) for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)] == [('pathlib', ['Path'])]
for n in ast.walk(tree):
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute):
        assert n.func.attr not in {'unlink', 'rmdir', 'rmtree', 'remove', 'chmod', 'chown', 'rename', 'replace', 'kill', 'killpg', 'system', 'popen', 'execv', 'execve', 'write_text', 'write_bytes', 'mkdir', 'touch'}
        if n.func.attr == 'open':
            assert len(n.args) == 1 and isinstance(n.args[0], ast.Constant) and n.args[0].value == 'rb'
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
        assert n.func.id not in {'exec', 'eval', 'compile', '__import__', 'open'}
assert 'subprocess' not in source and '/environ' not in source
assert 'len(sys.argv) == 1' in source
constants = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and isinstance(n.value, ast.Constant)}
assert constants['SCOPE_SHA256'] == hashlib.sha256((p / 'scope.json').read_bytes()).hexdigest()
scope = json.loads((p / 'scope.json').read_text())
old = json.loads((p / 'originals/process-visibility-refusal.json').read_text())
assert scope['original_refusals'] == old['unreadable'] and scope['original_checked_processes'] == old['checked_process_identities']
assert len(scope['targets']) == 5 and len(scope['parent_dependency_scopes']) == 2
assert len(scope['original_refusals']) == 195 and sum(len(r['fields']) for r in scope['original_refusals']) == 829
plan = json.loads((p / 'originals/retirement-plan.json').read_text())
assert scope['targets'] == [{'path': r['path'], 'identity': r['identity']} for r in plan['targets']]
for row in json.loads((p / 'source-provenance.json').read_text())['originals']:
    assert hashlib.sha256((p / row['copy']).read_bytes()).hexdigest() == row['sha256']
syntax = subprocess.run(['/bin/bash', '-n', str(p / 'commands.sh')], capture_output=True, check=False)
assert syntax.returncode == 0 and not syntax.stdout and not syntax.stderr
report = {'source_only': True, 'reader_imported_or_executed': False, 'process_scan': False, 'sudo': False, 'payload_read_or_hash': False, 'source_sha256': hashlib.sha256(source.encode()).hexdigest(), 'scope_sha256': constants['SCOPE_SHA256'], 'targets': 5, 'parent_dependency_scopes': 2, 'original_refused_processes': 195, 'original_refused_fields': 829, 'checks': ['Python AST parses; only fixed stdlib imports', 'No execution/process signal/mutation APIs; opens read-only', 'No arguments; fixed scope SHA', 'All original refusal identities and fields exact', 'All five target identities and two parent scopes exact', 'Historical source and refusal copies rehash exactly', 'bash -n exit0 with empty stdout/stderr'], 'runtime_result': None}
(p / 'static-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

"""Source-only inspection: parse text; never import or execute candidate modules."""
from pathlib import Path
import ast,hashlib,json,subprocess
P=Path(__file__).resolve().parent
files=[P/'prepare.py',P/'static-review.py',*sorted((P/'templates').glob('*.py'))]
for f in files:ast.parse(f.read_text(),filename=str(f))
old=ast.parse((P/'originals/retire-six-files.py').read_text());new=ast.parse((P/'templates/retire.py').read_text())
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
a,b=functions(old),functions(new)
identical=['require','read','load','shape','same_inode','backing_file']
assert all(a[n]==b[n] for n in identical)
code=(P/'templates/retire.py').read_text();calls=[n for n in ast.walk(new) if isinstance(n,ast.Call)]
qualified=lambda n:ast.unparse(n.func)
unlinks=[n for n in calls if qualified(n)=='os.unlink'];assert len(unlinks)==1 and any(k.arg=='dir_fd' for k in unlinks[0].keywords)
assert not any(qualified(n) in ('shutil.rmtree','os.rmdir','os.chmod','os.kill','os.killpg') for n in calls)
assert "os.O_RDONLY | os.O_NOFOLLOW" in code and "fcntl.LOCK_EX | fcntl.LOCK_NB" in code
assert "signal.pthread_sigmask(signal.SIG_SETMASK, mask)" in code
assert "if args.phase == 'verify':" in code and code.index("event('VERIFIED'")<code.index('os.unlink(')
commands=(P/'commands.sh').read_text();assert '--record-only' in commands and '--admission' not in commands
assert 'build-admission' not in (P/'templates/consume.py').read_text().replace('not build-admission consumption','')
assert 'subprocess' not in (P/'templates/run.py').read_text()
plan=json.loads((P/'plan.json').read_text());assert len(plan['targets'])==5 and len(plan['admissions'])==4
assert any(a['expected_original_result']=={'command_rc':1,'monitor_rc':0,'runner_rc':1} for a in plan['admissions'])
r=subprocess.run(['bash','-n',str(P/'commands.sh')],capture_output=True,check=False);assert r.returncode==0 and not r.stdout and not r.stderr
result={'status':'PASS','scope':'AST and shell-source checks only; no candidate import/runtime/test/target hash/process scan','parsed_files':[str(f.relative_to(P)) for f in files],'unchanged_helper_AST':identical,'exact_unlink_calls':1,'descriptor_relative_unlink':True,'recursive_delete_or_chmod_or_signal_calls':False,'record_only_two_phase':True,'old_failure_preserved':True,'bash_n_original_exit':r.returncode,'source_sha256':{str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files+[P/'commands.sh',P/'plan.json']}}
with (P/'static-review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,sort_keys=True))

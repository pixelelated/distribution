"""Materialize one fresh two-phase record-only owner; no target payload hashes or scans."""
from pathlib import Path
import hashlib,json,os,shutil,stat,subprocess
P=Path(__file__).resolve().parent
J=json.loads((P/'plan.json').read_text());O=Path(J['owner']);T=Path(J['tree'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def shape(p):
 s=p.lstat();return {k:getattr(s,'st_'+k) for k in ('dev','ino','mode','nlink','uid','gid','size','mtime_ns','ctime_ns','blocks')}
assert Path.cwd()==T and os.getuid()==J['uid']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,text=True).strip()==J['source_commit']
subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=T,check=True)
assert not O.exists() and O.parent.resolve()==O.parent
for line in (P/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);q=P/name;assert q.is_file() and q.resolve()==q and sha(q)==h,name
for name,h in J['frozen_tools'].items():assert sha(T/name)==h,name
for name,binding in J['receipt_bindings'].items():
 q=Path(name);assert q.resolve()==q and q.is_file() and q.stat().st_size==binding['bytes'] and sha(q)==binding['sha256'],name
for row in J['targets']:
 q=Path(row['path']);assert q.resolve()==q and shape(q)==row['identity'] and stat.S_ISREG(q.lstat().st_mode)
 assert shape(q.parent)==row['parent_identity'] and sorted(x.name for x in q.parent.iterdir())==row['parent_members']
O.mkdir(mode=0o700)
for name in ['retire.py','run.py','consume.py']:shutil.copy2(P/'templates'/name,O/name)
shutil.copy2(P/'plan.json',O/'plan.json')
for phase in ('verify','apply'):(O/phase/'artifacts').mkdir(parents=True,mode=0o700)
seal={str(q):sha(q) for q in [O/'plan.json',O/'retire.py',O/'run.py',O/'consume.py']}
with (O/'seal.json').open('x') as f:json.dump(seal,f,indent=2);f.write('\n')
with (O/'preparation.json').open('x') as f:
 json.dump({'packet':str(P),'packet_seal_sha256':sha(P/'SHA256SUMS'),'source_commit':J['source_commit'],'operation':'Exact source/evidence and metadata preparation only','target_payload_hashes_read':False,'process_or_dependency_scan':False,'deletion_performed':False,'admission_created':False,'registry_mutation':False,'output_scope':[str(O/'verify'),str(O/'apply')],'bounded_output_allowance_bytes':64*1024*1024,'preserved_old_consumed_ids':[a['id'] for a in J['admissions']]},f,indent=2);f.write('\n')
print('PREPARED fresh record-only verify/apply owner; targets unchanged')

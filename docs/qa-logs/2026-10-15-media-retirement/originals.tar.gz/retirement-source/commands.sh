#!/bin/bash
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-stopped-media-retirement-source-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=/workspace/tmp/pix-m7-stopped-media-retirement-20261015-01
cd "$TASK_TREE"
case "${1:?prepare, verify, consume-verify, apply, consume-apply, investigate-verify, or investigate-apply}" in
 prepare)
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare.py"
  ;;
 verify|apply)
  TASK_PHASE="$1"
  tools/watch-build-submit --owner "$TASK_OWNER/$TASK_PHASE" -- --record-only -- /usr/bin/timeout --signal=TERM --kill-after=15s 300s python3 -I -S -B "$TASK_OWNER/run.py" "$TASK_PHASE"
  # Root supervises original completion; submission0 is not completion0.
  ;;
 consume-verify)
  python3 -I -S -B "$TASK_OWNER/consume.py" verify
  ;;
 consume-apply)
  python3 -I -S -B "$TASK_OWNER/consume.py" apply
  ;;
 investigate-verify)
  python3 -I -S -B "$TASK_OWNER/consume.py" verify --failed-investigated
  ;;
 investigate-apply)
  python3 -I -S -B "$TASK_OWNER/consume.py" apply --failed-investigated
  ;;
 *) exit 2;;
esac

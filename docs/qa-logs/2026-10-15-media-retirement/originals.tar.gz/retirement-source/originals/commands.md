# Conditional command plan — not executed

1. Recheck this source proposal before creating any execution owner:

   ```bash
   cd /tmp/pix-m7-stopped-media-retirement-20261015
   sha256sum -c SHA256SUMS
   ```

2. Root prepares one fresh exact-file adapter and source seal in a new private
   packet, reusing the existing guards listed in README. This source task did
   not create that executor. Do not call the historical retire.py, broad
   execute-cleanup.py, UI rmtree or SSH baseline script against these paths.
   The new adapter must have a verify-only phase, the exact five-file plan,
   bound56 evidence rows, and a new result path outside both removal directories.

3. Root allocates one fresh watched **record-only** owner for the bounded
   readback/removal operation. Use the current coordinator's ordinary
   `tools/watch-build-submit --owner FRESH_OWNER -- --record-only -- COMMAND`
   interface, after source/command review. This is not compilation and needs no
   fake build admission. Existing consumed output records remain immutable.
   `FRESH_OWNER` and `COMMAND` are intentionally unresolved here: there is no
   reviewed five-file executor yet, so no command is falsely presented as ready.

4. The adapter's verify-only phase rehashes the five payloads (binding the two
   historical expected hashes), rechecks file/parent identities and permissions,
   rehashes compact evidence, and records current target-aware dependency/use
   observations. Require the four exact consumed receipt/registry matches and
   no live reservation/config/queued input using selected media. Do not acquire
   free-space credit until actual unlink. Unknown visibility produces a retained
   refusal, not a repeated allocation or inherited service exception.

5. Only after root accepts the fresh observations, the same sealed adapter's
   apply phase reacquires the ordinary registry lock and repeats the relevant
   live/identity checks immediately before descriptor-relative unlink. Remove
   exactly these names, leaving all owner records untouched:

   ```text
   /workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/disk.qcow2
   /workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/input.ext4
   /workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/output.ext4
   /workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02/vm/OVMF.fd
   /workspace/tmp/pix-m7-h700-reader-20261015-01/acceptance/scratch/SYSTEM
   ```

   Leave the last SYSTEM untouched if a current consumer or hash mismatch is
   found. A partial batch keeps its exact original failure and unlink journal;
   no replay of removed entries. Remove only an empty verified parent after its
   listed files. No recursive removal, chmod, owner-root removal or registry edit.

6. Retain original launcher/command/monitor/runner channels, each exact removed
   identity/hash, pre/post `f_bavail` and measured recovery, and post-operation
   preservation/absence results in that fresh owner. Root publishes a compact
   retirement receipt next to existing evidence. A source plan or consumed
   admission alone never supplies a RETIRED result.

Pending root-only input is narrowly defined: fresh actual-host consumer and
visibility observations, plus the current immediately queued test list. A
privileged target-scoped readback is needed only if ordinary observations leave
an actual unresolved dependency field; this packet requests no root census.

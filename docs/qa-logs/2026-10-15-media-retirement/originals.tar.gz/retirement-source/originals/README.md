# Exact stopped-media retirement proposal

Prepared source/readback only. No process/namespace/container scan, target program,
reader, candidate-store verification, payload hash pass, registry mutation,
permission change, signal or deletion ran. Current `lstat` metadata and small
receipt/manifests were read. The five files remain present. This is not a
ready-to-execute retirement owner.

## Scope and reason for release

| Target relative to its owner | Logical bytes | Allocated bytes | Current inode |
| --- | ---: | ---: | ---: |
| Steam bridge02 `vm/OVMF.fd` | 540672 | 540672 | 206834831 |
| Steam bridge02 `vm/disk.qcow2` | 2308374528 | 2308325376 | 206834830 |
| Steam bridge02 `vm/input.ext4` | 268435456 | 17768448 | 206834876 |
| Steam bridge02 `vm/output.ext4` | 134217728 | 17207296 | 206834877 |
| H700 reader01 `acceptance/scratch/SYSTEM` | 1285365760 | 1285369856 | 192196638 |

Device66304, UID/GID1000, single-link regular files. Full absolute names,
current metadata, exact parent identities/membership and historical hash sources
are in `retirement-plan.json`. Total logical3,996,934,144 B;
allocated3,629,211,648 B, excluding directory blocks. These are potential released
allocations, not measured recovery. Parent directories are already writable by
the owner; no permission change is planned. Remove no enclosing owner directory.
Only an empty `vm/` or `scratch/` may be removed after its exact selected contents.

Steam's immediate case completed and admissiondeaa4df3 was ordinarily consumed.
The exact82 host,11 exported guest and74 nested fixture files plus completion/
consumption records are independently retained at coordinator
`docs/qa-logs/2026-10-15-steam-artifact-bridge-runtime/`, seal8c621cbe. Its four
large media files carry no independently identified immediate next test in the
reviewed records. Historical references to these names stay as provenance.

H700's old failed acceptance21f58942 remains1/0/1. Fresh readerba91e876 and
replacement acceptance4ebc249f are consumed with original0/0/0. Acceptance
`e8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db`
qualifies the same SYSTEM hash
`69dafbfacc07a6f59a12d35dc35c1839027458d695ba2fb0493d800bac7b5e67`
for both DDR variants; its newly created scratch was removed. The earlier
failed scratch has sole memberSYSTEM and is now superseded. Failure and
replacement compact records are independently retained at
`docs/qa-logs/2026-10-15-device-refresh/{state-failure03,h70004}/`.

This preparation does not rehash the large scratch or VM files. SYSTEM's hash
is the original failure/replacement hash, and input.ext4's recorded initial hash
is85e052ba; neither is labelled a fresh content observation. Other VM payload
hashes remain null until the separately allocated guarded retirement readback.
All56 small preserved source/evidence bindings in `evidence-bindings.json` were
actually rehashed for this preparation.

## Protected inputs and current consumers

The accepted H700 bundle32f7a652 and SM bundle09addac6 retain their exact manifest
hashes and current directory identities. Their files, current GENERIC artifacts,
H700/SM reader artifacts, all original owner/run receipts, source packets,
required source/licence objects and build caches are outside deletion scope.
No new bulk preservation copy is needed. Current inventory/source-publication
work may consume these protected artifacts and compact receipts; it does not
justify deleting any of them or retaining a completed VM by historical path alone.

Before execution, root must confirm that the currently active/queued work has
no actual dependency on the five selected files. Under the shared registry lock,
all four named receipt entries must still exactly match their consumed originals;
no live/prepared reservation may refer to these targets or depend on their media.
The broader immediate-test decision is root's current coordination readback,
not something this historical source packet can infer. Consumption releases a
reservation, not outputs. Do not re-consume old runs or directly edit the registry.

## Established tools and the concrete interface gap

Current `tools/host-maintenance/build-admission` has no deletion operation.
`tools/host-maintenance/retention-report` is read-only and its candidate evaluator
requires QCOW2 and older completion schemas; it cannot classify the OVMF, ext4
or extracted SYSTEM as eligible. Do not mislabel them as QCOW2 or fabricate its
receipt schema. A successful capacity report is not deletion authority.

The existing `/tmp/m7-retained-media-retirement-20261014-02/retire.py`
(SHAace7c33e3f72652c710855bcdd8a274980db52093ef2611debc976feb76e5689)
provides the relevant exact-file pattern: receipt rehash, consumed-registry lock,
actual-host process identity/reference checks, nofollow directory descriptors,
full identity recheck before each unlink and fsynced partial/failure journal.
It cannot run unchanged: it requires an old overlay/base pair,27 different
receipts, zero statuses for both owners, a diagnostic VM absence check and two
`vm` directories. Its process exceptions and earliest-start threshold belong to
that original batch. No such exception is inherited here.

The October12 `guards.py` supplies the already-corrected exact administrator-root
coverage check and container/host mount checks. Its full executor is bound to
17 historical worktrees and must not be replayed. The older UI rmtree helper
and SSH/VM-stop baseline helper also do not match this stopped five-file scope.

A minimal fresh adapter of those existing guards is required before an executable
removal command exists. Scope it to this plan: accept the exact original failed
H700 result rather than all-zero fiction; preserve file-only nofollow removal;
handle `scratch` as well as `vm`; remove the unrelated overlay/base special case;
check reverse backing references for the real declared VM layouts; include fresh
host/container mount checks; bind current compact records and ordinary consumed
receipts; journal exact removals and unchanged protected evidence afterward.
No framework, automatic cleanup policy or product change is proposed here.

## Fresh visibility still needed

No fresh active-use claim was made. Required execution observations are actual
host namespace4026531836 and UID1000, original owner/child absence, target-aware
registry consumers, readable argv/cwd/root/fd/maps, container mounts (including
stopped containers), host mount associations, and relevant QCOW backing chains.
An unexpected hardlink, file/parent identity change, new member or live reference
refuses removal. Check any loop-backed association if the actual mount inventory
makes it relevant; do not infer it from an empty guest result.

A general administrator census is not automatically required by this source
review. If fresh ordinary visibility is complete for the relevant target uses,
record that scope. If it encounters inaccessible live descriptor/root/maps or
unresolved mount visibility that could conceal a target, HOLD. Resolving that
specific refusal needs a separately authorized, exact-target readback; do not
reuse the old October14 protected-session snapshot or accept a process name as
proof. The known old refusal may have changed, but no process was inspected here.

Follow `commands.md` for the conditional ordinary watched-owner sequence.

#!/usr/bin/env python3
"""One-shot, exact six-file retirement. No process signals or recursive deletion."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import struct
import time


HERE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise RuntimeError(message)


def read(path, limit=16 * 1024 * 1024):
    with Path(path).open('rb') as stream:
        value = stream.read(limit + 1)
    require(len(value) <= limit, 'oversized input: ' + str(path))
    return value


def load(path):
    return json.loads(read(path))


def shape(value):
    return {k: getattr(value, 'st_' + k) for k in
            ('dev', 'ino', 'mode', 'nlink', 'uid', 'gid', 'size',
             'mtime_ns', 'ctime_ns', 'blocks')}


def same_inode(value, expected):
    return all(getattr(value, 'st_' + k) == expected[k]
               for k in ('dev', 'ino', 'mode', 'uid', 'gid'))


def check_receipts(plan):
    for name, binding in plan['receipt_bindings'].items():
        p = Path(name)
        require(p.resolve() == p and stat.S_ISREG(p.lstat().st_mode),
                'receipt path changed: ' + name)
        data = read(p)
        require(len(data) == binding['bytes'] and
                hashlib.sha256(data).hexdigest() == binding['sha256'],
                'receipt bytes changed: ' + name)
    before, after = load(plan['base_before']), load(plan['base_after'])
    require(before == after, 'original base before/after differ')
    base = plan['ordered_targets'][1]['files']['disk.qcow2']
    require(before['shape'] == {
        'device': base['dev'], 'inode': base['ino'], 'bytes': base['size'],
        'mtime_ns': base['mtime_ns'], 'mode': base['mode']},
        'base original hash receipt does not bind the selected inode')
    for admission in plan['admissions']:
        receipt = load(admission['receipt'])
        require(receipt['id'] == admission['id'] and receipt['state'] == 'consumed',
                'admission not consumed')
        require(receipt['run'] == admission['run'] and
                receipt['submission_owner'] == admission['owner'] + '/lifecycle-owner',
                'admission owner/run changed')
        require(all(receipt['original_result'][k] == 0
                    for k in ('command_rc', 'monitor_rc', 'runner_rc')),
                'original admission result is not zero')


def check_registry(plan):
    jobs = load(Path(plan['registry']) / 'jobs.json')['jobs']
    for admission in plan['admissions']:
        row = jobs[admission['id']]
        receipt = load(admission['receipt'])
        for key in ('id', 'state', 'run', 'submission_owner', 'original_result',
                    'evidence_sha256'):
            require(row[key] == receipt[key], 'registry changed: ' + key)
    # Other allocations may run. Refuse only a live reservation whose declared
    # output or prepared configuration refers to these particular owners.
    owners = [a['owner'] for a in plan['admissions']]
    for row in jobs.values():
        if row.get('state') in ('consumed', 'released', 'cancelled'):
            continue
        texts = [json.dumps(row)]
        submission = row.get('submission_owner')
        if submission:
            p = Path(submission).parent / 'config.json'
            if p.exists():
                texts.append(read(p).decode())
        require(not any(owner in text for owner in owners for text in texts),
                'active allocation references media owner: ' + str(row.get('id')))


def proc_absent(pid):
    try:
        (Path('/proc') / str(pid)).stat()
    except (FileNotFoundError, ProcessLookupError):
        return True
    return False


def process_identity(p):
    raw = read(p / 'stat', 65536)
    prefix, separator, tail = raw.rpartition(b')')
    require(separator and prefix.split(b' (', 1)[0] == p.name.encode(),
            'malformed process identity: ' + p.name)
    fields = tail.split()
    require(len(fields) >= 20, 'short process identity: ' + p.name)
    status = read(p / 'status').decode()
    uid_line = next(line for line in status.splitlines() if line.startswith('Uid:'))
    return {'pid': int(p.name), 'ppid': int(fields[1]),
            'start_ticks': int(fields[19]), 'state': fields[0].decode(),
            'comm': read(p / 'comm').decode().strip(),
            'uids': [int(x) for x in uid_line.split()[1:]],
            'cgroup': read(p / 'cgroup').decode(),
            'cmdline_sha256': hashlib.sha256(read(p / 'cmdline')).hexdigest()}


def classify_inaccessible(p, identity, plan):
    matches = [row for row in plan['protected_unrelated_processes']
               if row['pid'] == int(p.name)]
    require(len(matches) == 1, 'unclassified inaccessible process: PID ' + p.name)
    expected = matches[0]
    require(expected['pid'] not in plan['recorded_pids_must_be_absent'] and
            expected['start_ticks'] < plan['earliest_admitted_runner_start'],
            'inaccessible process may be an original owner/descendant: PID ' + p.name)
    current = process_identity(p)
    for key in ('pid', 'ppid', 'start_ticks', 'comm', 'uids', 'cgroup', 'cmdline_sha256'):
        require(identity[key] == expected[key] == current[key],
                'protected process identity changed: PID ' + p.name + ', ' + key)
    if expected['classification'] == 'exited_known_session_zombie':
        require(identity['state'] == current['state'] == 'Z',
                'known zombie is not exited: PID ' + p.name)
        require(current['cmdline_sha256'] == hashlib.sha256(b'').hexdigest(),
                'known zombie has command content: PID ' + p.name)
    else:
        require(identity['state'] not in ('Z', 'X') and current['state'] not in ('Z', 'X'),
                'protected session service no longer live: PID ' + p.name)
    return expected['classification']


def check_processes(plan):
    require(os.stat('/proc/self/ns/pid').st_ino == plan['host_pid_namespace'],
            'not the original real host PID namespace')
    require(os.getuid() == plan['uid'], 'wrong executing UID')
    for pid in plan['recorded_pids_must_be_absent']:
        require(proc_absent(pid), 'recorded owner PID exists: ' + str(pid))
    targets = [t['path'] for t in plan['ordered_targets']]
    inodes = {(x['dev'], x['ino']) for t in plan['ordered_targets']
              for x in [t['shape'], *t['files'].values()]}
    checked, deadline = 0, time.monotonic() + 30
    limitations, other_uid = [], 0
    for p in Path('/proc').iterdir():
        if not p.name.isascii() or not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        require(time.monotonic() < deadline, 'process census exceeded 30 seconds')
        try:
            # Readable argv always participates, including classified protected
            # services. No command bytes or mapped contents are exported.
            command = read(p / 'cmdline', 4 * 1024 * 1024)
            require(not any(t.encode() in command for t in targets),
                    'live command refers to selected media: PID ' + p.name)
            identity = process_identity(p)
            if plan['uid'] not in identity['uids']:
                other_uid += 1
                continue
            checked += 1
            unavailable = []
            links = [p / 'cwd', p / 'root']
            try:
                links.extend((p / 'fd').iterdir())
            except PermissionError:
                unavailable.append({'resource': 'fd', 'reason': 'PermissionError'})
            for link in links:
                resource = str(link.relative_to(p))
                try:
                    value = link.stat()
                    target = os.readlink(link)
                except (FileNotFoundError, ProcessLookupError):
                    if link.parent == p / 'fd':
                        continue  # A descriptor can close while its process lives.
                    if proc_absent(int(p.name)):
                        raise
                    # Only exact, already-exited known zombies may lack cwd/root.
                    classification = classify_inaccessible(p, identity, plan)
                    require(classification == 'exited_known_session_zombie',
                            'live process lacks cwd/root: PID ' + p.name)
                    unavailable.append({'resource': resource, 'reason': 'KnownZombieMissingLink'})
                    continue
                except PermissionError:
                    unavailable.append({'resource': resource, 'reason': 'PermissionError'})
                    continue
                require((value.st_dev, value.st_ino) not in inodes and
                        not any(t in target for t in targets),
                        'live descriptor/cwd refers to selected media: PID ' + p.name)
            try:
                maps = read(p / 'maps', 16 * 1024 * 1024)
            except PermissionError:
                unavailable.append({'resource': 'maps', 'reason': 'PermissionError'})
            else:
                require(not any(t.encode() in maps for t in targets),
                        'live mapping refers to selected media: PID ' + p.name)
            if unavailable:
                classification = classify_inaccessible(p, identity, plan)
                limitations.append({'pid': identity['pid'], 'start_ticks': identity['start_ticks'],
                                    'classification': classification, 'unavailable': unavailable,
                                    'readable_argv_checked': True,
                                    'predates_original_admitted_owners': True})
        except (FileNotFoundError, ProcessLookupError):
            require(proc_absent(int(p.name)), 'incomplete live process census: ' + p.name)
    return {'same_uid_processes_checked': checked,
            'other_uid_without_fd_maps_census': other_uid,
            'inaccessible_classified_unrelated_processes': limitations,
            'whole_host_absence_claimed': False,
            'scope': 'original owned family absence plus readable argv/fd/cwd/root/maps, '
                     'with exact known unrelated protected identities recorded as limitations'}


def backing_file(path):
    require(path.resolve() == path and stat.S_ISREG(path.lstat().st_mode),
            'QCOW path is not a direct regular file: ' + str(path))
    with path.open('rb') as stream:
        header = stream.read(20)
        require(len(header) == 20, 'short QCOW header: ' + str(path))
        magic, version, offset, length = struct.unpack('>4sIQI', header)
        require(magic == b'QFI\xfb' and version in (2, 3), 'unknown QCOW header')
        if not length:
            require(offset == 0, 'unexpected empty QCOW backing offset')
            return None
        require(20 <= offset <= 65536 and length <= 4096,
                'QCOW backing reference outside bounded header')
        stream.seek(offset)
        raw = stream.read(length)
        require(len(raw) == length and b'\0' not in raw, 'invalid backing name')
        value = Path(raw.decode())
        return str((path.parent / value).resolve())


def check_dependencies(plan, overlay_present):
    overlay = plan['ordered_targets'][0]['path'] + '/disk.qcow2'
    base = plan['ordered_targets'][1]['path'] + '/disk.qcow2'
    paths = sorted(Path('/workspace/tmp').glob('*/vm/*.qcow2'))
    require(len(paths) <= 256, 'unexpectedly broad conventional VM inventory')
    found, rows = set(), []
    for p in paths:
        parent = backing_file(p)
        found.add(str(p))
        rows.append({'path': str(p), 'backing': parent})
        if str(p) == overlay:
            require(overlay_present and parent == base, 'overlay dependency changed')
        elif str(p) == base:
            require(parent is None, 'original retained disk gained a backing file')
        else:
            require(parent not in (overlay, base), 'another conventional VM depends on media')
    require(base in found and ((overlay in found) == overlay_present),
            'selected media missing/returned during dependency check')
    require(not os.path.lexists(plan['diagnostic_vm_must_remain_absent']),
            'retired diagnostic media has returned')
    return rows


def open_target(target):
    p = Path(target['path'])
    require(p.resolve() == p and p.name == 'vm', 'target path or symlink changed')
    require(same_inode(p.parent.stat(), target['parent_shape']), 'owner directory replaced')
    fd = os.open(p, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        require(shape(os.fstat(fd)) == target['shape'], 'VM directory metadata changed')
        require(set(os.listdir(fd)) == set(target['files']), 'unexpected VM directory contents')
        for name, expected in target['files'].items():
            s = os.stat(name, dir_fd=fd, follow_symlinks=False)
            require(shape(s) == expected and stat.S_ISREG(s.st_mode) and s.st_nlink == 1,
                    'media identity changed: ' + str(p / name))
    except BaseException:
        os.close(fd)
        raise
    return fd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--result', required=True, type=Path,
                        help='new JSONL result outside either media directory')
    args = parser.parse_args()
    plan = load(HERE / 'plan.json')
    require(args.result.is_absolute() and args.result.parent.resolve() == args.result.parent,
            'result must use an absolute, direct existing parent')
    require(all(not args.result.is_relative_to(Path(t['path']))
                for t in plan['ordered_targets']), 'result is inside deletion scope')
    removed = []
    with args.result.open('x', encoding='utf-8') as output:
        def event(status, **fields):
            output.write(json.dumps({'status': status,
                                     'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                     **fields}, sort_keys=True) + '\n')
            output.flush()
            os.fsync(output.fileno())
        event('STARTED', plan_sha256=hashlib.sha256(read(HERE / 'plan.json')).hexdigest())
        fds = []
        try:
            lock = os.open(Path(plan['registry']) / 'lock', os.O_RDONLY | os.O_NOFOLLOW)
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                check_receipts(plan)
                check_registry(plan)
                census = check_processes(plan)
                dependencies = check_dependencies(plan, True)
                for target in plan['ordered_targets']:
                    fds.append(open_target(target))
                event('VALIDATED', census=census, dependencies=dependencies)
                for index, (target, fd) in enumerate(zip(plan['ordered_targets'], fds)):
                    if index:
                        check_registry(plan)
                        census = check_processes(plan)
                        dependencies = check_dependencies(plan, False)
                        event('BASE_REVALIDATED', census=census, dependencies=dependencies)
                    p = Path(target['path'])
                    require(same_inode(p.lstat(), target['shape']), 'VM directory replaced')
                    require(set(os.listdir(fd)) == set(target['files']), 'VM contents changed')
                    for name, expected in target['files'].items():
                        require(shape(os.stat(name, dir_fd=fd, follow_symlinks=False)) == expected,
                                'media changed immediately before unlink: ' + str(p / name))
                        os.unlink(name, dir_fd=fd)
                        removed.append(str(p / name))
                        event('UNLINKED', path=removed[-1], inode=expected['ino'],
                              logical_bytes=expected['size'], allocated_bytes=expected['blocks'] * 512)
                    require(not os.listdir(fd), 'VM directory not empty after exact unlinks')
                    require(same_inode(p.lstat(), target['shape']), 'VM path replaced before rmdir')
                    os.rmdir(p)
                    require(not os.path.lexists(p), 'VM directory still exists')
                    event('DIRECTORY_REMOVED', path=str(p))
                check_receipts(plan)
                event('RETIRED', removed=removed,
                      unlinked_logical_bytes=plan['expected_logical_bytes'],
                      unlinked_allocated_bytes=plan['expected_allocated_bytes'],
                      bound_receipts_unchanged=True)
            finally:
                os.close(lock)
        except BaseException as error:
            event('FAILED_PARTIAL' if removed else 'REFUSED_WITHOUT_DELETION',
                  error_type=type(error).__name__, error=str(error), removed=removed)
            raise
        finally:
            for fd in fds:
                os.close(fd)


if __name__ == '__main__':
    main()

# Exact five-file retirement — source only, UNRUN

This is the narrow adapter of the existing six-file descriptor-relative remover
for the four stopped Steam bridge02 media files and the superseded failed H700
scratch SYSTEM. Nothing here has been prepared or executed against the host.
No target payload hash, process scan, dependency command, unlink, signal,
permission change, registry mutation or original-receipt change ran during source
preparation. Only source parsing, shell syntax and byte/AST comparisons ran.

The parent proposal remains immutable under `originals/`, including its original
seal `f68cfa6b879dcadb7f94ceda6ecdf63e0ddff928d4f3a066ea03ea4a1ae5e75d`.
That proposal's illustrative execution gap is addressed by this packet. Its
record-only semantics are retained: **no new build reservation and no call to
build-admission prepare/consume**. The earlier intermediate design proposing a
fresh reservation was withdrawn before any allocation.

## Exact scope and preserved dependencies

`plan.json` binds exactly five single-link regular files on device66304,
3,996,934,144 logical bytes and3,629,211,648 allocated file bytes. The existing
parent directories remain; there is no rmdir or recursive removal. Parent
identities, permissions and sole/exact file membership are checked through
nofollow descriptors. Full identities are rechecked immediately before unlink.
No mode changes are required or permitted.

The plan binds92 compact receipt/source files and17 original owner PIDs. It
preserves Steam's original0/0/0 and H700's earlier selected-state failure1/0/1,
alongside reader0 and replacement acceptance0. Original consumed output holds
must still match the shared registry, including held=true and deleted_bytes0.
They are never rewritten or re-consumed. A new exact retirement journal records
which released files were removed and supplements those historical hold rows.

The Steam custody seal8c621cbe, H700 failure/state-failure03 and replacement/h70004
records, current H700 bundle32f7a652, SM bundle09addac6, current GENERIC/reader
artifacts, source packets, source/licence inputs and caches remain protected.
No large preservation copy is made. Root's preparation context explicitly states
that immediately queued tests exclude all five target files and current
source/provenance work uses accepted staged binaries/archives. This does not
replace fresh actual-use checks.

SYSTEM's expected69dafb hash is supported by both the original failure and fresh
accepted replacement; input.ext4's expected85e052ba hash comes from its original
creation receipt. Both are freshly checked by the future verify/apply phases.
The other media have no invented prior full hash; verify records their actual
hashes, then apply requires the identical bytes and repeats the hash pass.

## Two ordinary monitored phases

The fresh root is `/workspace/tmp/pix-m7-stopped-media-retirement-20261015-01`.
Its `verify/` and `apply/` are distinct durable launcher owners, each used once.
The frozen runner tree is `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02`
atf863. The preparer binds frozen tool bytes and source state, copies only the
small reviewed scripts/plan, and allocates phase artifact directories. It reads
current target metadata, not payload hashes or process state. Its recorded
output allowance is64MiB; no expected reclaimed bytes are treated as free space.

Root commands after final source review:

```bash
bash /tmp/pix-m7-stopped-media-retirement-source-20261015/commands.sh prepare
bash /tmp/pix-m7-stopped-media-retirement-source-20261015/commands.sh verify
# Root actively supervises original completion, then reads exact observations.
bash /tmp/pix-m7-stopped-media-retirement-source-20261015/commands.sh consume-verify
# Only after root accepts that fresh verify result:
bash /tmp/pix-m7-stopped-media-retirement-source-20261015/commands.sh apply
# Root actively supervises original completion, then reads exact removals.
bash /tmp/pix-m7-stopped-media-retirement-source-20261015/commands.sh consume-apply
```

Each real phase uses `watch-build-submit --record-only`, with GNU timeout300s
and15s kill-after. The worker calls the remover in-process, so it has no extra
unowned worker child. Dependency Docker commands are bounded20s and `subprocess.run`
waits their original status. SIGTERM/SIGINT produce a recorded inner status;
GNU timeout's outer124 stays separate in original runner/build channels. No
launcher rc is written by this packet. Missing/unknown originals cannot pass.

`consume.py` is a small evidence-only completion reader, not an admission tool.
It checks original launcher/wrapper/runner/build statuses, terminal monitor,
actual recorded PID absence, plan/source seal and phase result/journal, then
writes a new `consumption.json`. Verify consumption cannot be reused as apply
success. Apply requires exact successful verify consumption and redoes the
hash, registry, identity and live-dependency checks before removing anything.

If a phase fails, preserve its originals and inspect the failure before root
uses `investigate-verify` or `investigate-apply`. Those commands require a nonzero
original runner and write FAILED_INVESTIGATED, retaining distinct inner and outer
statuses. They cannot release a successful verify prerequisite or label a
partial apply complete. No failed owner is retried. Any continuation after a
partial removal requires a newly reviewed remaining-target packet; no automatic
reconciliation or general garbage collector is introduced.

## Existing guards reused, with honest scope

Six helpers (`require`, `read`, `load`, `shape`, `same_inode`, `backing_file`) are
AST-identical to the earlier qualified remover. `retire.py.diff` shows the whole
adapter against that source. The old overlay/base assumptions, base-before/
after receipt and inherited service exceptions are removed from this distinct
packet. There is no change to the old sealed executor.

Both phases hold the existing registry lock while checking exact prior consumed
rows. Any unconsumed output overlapping a target or known owner metadata naming
its media parent refuses. Only the existing owner config/bindings/plan paths are
read; there is no blanket filesystem grep. No registry write occurs.

Fresh process checks require actual host PID namespace4026531836 and UID1000,
all17 recorded PIDs absent, and readable argv/cwd/root/fd/maps observations.
Only vanished processes/descriptors and positively observed exited zombies have
narrow race handling. There are no inherited protected-service/name exceptions.
An unreadable field records an exact visibility refusal and stops verify before
any unlink. The packet does not request privileged access or imply that a
particular current process is readable. Root may resolve a concrete refusal
separately; no catchall root census or approval fallback is built in.

Reverse backing checks read bounded QCOW headers in the established
`/workspace/tmp/*/{vm,pair}/*.qcow2` layouts, at most512 files. The selected
Steam disk must have no backing file and no observed disk may depend on any
selected target. This is not a recursive inventory of arbitrary dormant images.
Fresh Docker inventory includes stopped containers and checks every returned
mount; current host mount and visible loop backing associations are also checked.
Unreadable/changed/unexpected inputs refuse. No target program, VM, mount,
container creation, process stop or network request is used.

The actual unlink/journal pair delays SIGTERM/SIGINT only across its
nofollow-descriptor-relative unlink, parent fsync and fsynced JSONL record.
The old signal mask is restored immediately afterward; no child is spawned
while signals are blocked. Files remain open for identity custody until the
batch ends, then descriptors are closed before measuring available space.
Original failures/partial journals remain. The result distinguishes unlinked
allocated bytes from the observed free-space delta, which can include unrelated
host activity. Only RETIRED plus complete original successful channels can pass
apply consumption.

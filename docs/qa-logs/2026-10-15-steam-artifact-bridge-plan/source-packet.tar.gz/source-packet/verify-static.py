#!/usr/bin/env python3
"""Source/AST/byte review only. Never import or execute the prepared fixture."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

R = Path(__file__).resolve().parent
REPO = Path('/workspace/repos/rocknix')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def functions(path):
    return {n.name: ast.dump(n, include_attributes=False)
            for n in ast.parse(path.read_text()).body
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}


parsed = []
for p in sorted(R.rglob('*.py')):
    ast.parse(p.read_text(), filename=str(p))
    parsed.append(str(p.relative_to(R)))

refs = json.loads((R / 'source-original-locators.json').read_text())
for row in refs:
    p = Path(row['original'])
    assert p.is_file() and not p.is_symlink()
    assert sha(p.read_bytes()) == row['original_sha256']
    assert p.stat().st_size == row['original_bytes']
    if row['relationship'] == 'identical':
        assert p.read_bytes() == (R / row['copy']).read_bytes()

old = json.loads((R / 'originals/fixture-source.json').read_text())
new = json.loads((R / 'fixture/source.json').read_text())
old['installer_sha256'] = '1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b'
old['helpers']['runtime']['shell_function_sha256'] = '24c5feedf7c1addc616cbb261e12450d43a4288a356bc471262c6851e0a2b7d7'
old['cases'] = ['existing-profile-dot']
assert old == new
boundary = (R / 'originals/boundary.py').read_text()
before = "assert args[:-1] == ['-fsSL']"
after = "assert args[:-1] == ['-q', '-fsSL', '--connect-timeout', '10', '--max-time', '30', '--max-filesize', '1048576']"
assert boundary.count(before) == 1
assert boundary.replace(before, after) == (R / 'fixture/boundary.py').read_text()

seen = set()
for line in (R / 'fixture/SHA256SUMS').read_text().splitlines():
    h, n = line.split('  ', 1)
    assert n not in seen and not Path(n).is_absolute() and '..' not in Path(n).parts
    seen.add(n)
    assert sha((R / 'fixture' / n).read_bytes()) == h
assert seen == {str(p.relative_to(R / 'fixture')) for p in (R / 'fixture').rglob('*')
                if p.is_file() and p != R / 'fixture/SHA256SUMS'}
assert sha((R / 'fixture/SHA256SUMS').read_bytes()) == '4f3bcb8d46b6780dcb4bfab7bd27113e93fd81fa6e7cf6e69a3a501095542262'

guest_old = (R / 'originals/guest-stage.py').read_text()
guest_new = (R / 'guest-stage.py').read_text()
guest_functions = functions(R / 'guest-stage.py')
old_functions = functions(R / 'originals/guest-stage.py')
# Scope text changes inside main; all execution/containment assertions remain.
old_ast = ast.parse(guest_old.replace('source chroot; no installed/native Steam claim',
                                    'actual packaged portable script in isolated VM; no native ARM Steam claim'))
adjusted = {n.name: ast.dump(n, include_attributes=False) for n in old_ast.body if isinstance(n, ast.FunctionDef)}
assert guest_functions == adjusted
lifecycle_functions = functions(R / 'vm-lifecycle.py')
assert lifecycle_functions == functions(R / 'originals/vm-lifecycle.py')
assert functions(R / 'export.py') == functions(R / 'originals/export.py')
assert 'metadata_rows' not in (R / 'export.py').read_text()
assert 'metadata-stage' not in (R / 'vm-lifecycle.py').read_text()
assert 'extract-installed' not in (R / 'vm-lifecycle.py').read_text()

source_rows = {}
rel = 'projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh'
for commit in ['f8636de1d105275dbf9420bbabbbc26f79abb10f',
               '9aa7affee9d4ad5e69725cab20b6d7ad84d93dea']:
    raw = subprocess.check_output(['git', 'show', commit + ':' + rel], cwd=REPO, timeout=20)
    assert sha(raw) == new['installer_sha256'] and len(raw) == 124399
    for row in new['helpers'].values():
        first = ("<<'" + row['marker'] + "'\n").encode()
        last = ('\n' + row['marker'] + '\n').encode()
        assert raw.count(first) == raw.count(last) == 1
        body = raw.split(first, 1)[1].split(last, 1)[0]
        assert sha(body) == row['helper_sha256'] and sha(body + b'\n') == row['stdin_sha256']
        shell = raw[raw.index((row['shell_start'] + '() {').encode()):raw.index((row['shell_end'] + '() {').encode())]
        assert sha(shell) == row['shell_function_sha256']
    source_rows[commit] = {'sha256': sha(raw), 'bytes': len(raw), 'five_embedded_helpers_and_stdin': 'IDENTICAL'}

result = {'status': 'PASS', 'scope': 'source AST/bytes only; no fixture/preparer/VM/helper execution',
          'python_files_parsed': parsed, 'original_references_rehashed': len(refs),
          'fixture_payloads': len(seen), 'fixture_changes': ['source.json three bindings', 'boundary.py one exact argv assertion'],
          'guest_functions_after_scope_text_only': len(guest_functions),
          'lifecycle_functions_identical': len(lifecycle_functions),
          'export_functions_identical': len(functions(R / 'export.py')), 'sources': source_rows,
          'runtime_status': 'UNRUN; actual consumed SM acceptance and new serialized owner required'}
with (R / 'static-review.json').open('x') as f:
    json.dump(result, f, indent=2); f.write('\n')
print('PASS source AST/byte review; fixture, preparation and runtime remain UNRUN')

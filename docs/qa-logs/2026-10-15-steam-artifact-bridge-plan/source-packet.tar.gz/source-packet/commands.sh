#!/usr/bin/env bash
# SOURCE ONLY. Invoke one named action only after root review and serialization.
set -euo pipefail
TASK_PACKET=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-01}
TASK_EXPORT=${TASK_EXPORT:-/workspace/tmp/pix-m7-steam-artifact-bridge-evidence-20261015-01}
case ${1:?prepare|preflight|admit|launch|export|retain-failed|consume} in
  prepare)
    python3 -I -S -B "$TASK_PACKET/prepare.py" --owner "$TASK_OWNER" \
      --vnc "${TASK_VNC:?actual observed free display}" \
      --sm-acceptance-sha256 "${TASK_SM_ACCEPTANCE_SHA256:?actual successful acceptance hash}" \
      --sm-consumed-sha256 "${TASK_SM_CONSUMED_SHA256:?actual ordinary consumed acceptance hash}"
    ;;
  preflight)
    cd "$TASK_TREE"
    tools/build-preflight
    tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
      --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
    ;;
  admit)
    cd "$TASK_TREE"
    python3 -I tools/host-maintenance/build-admission prepare \
      --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
    ;;
  launch)
    cd "$TASK_TREE"
    tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
      --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
      python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
    ;;
  export|retain-failed)
    TASK_ARGS=()
    if [[ $1 == retain-failed ]]; then TASK_ARGS+=(--retain-failed); fi
    python3 -I -S -B "$TASK_PACKET/export.py" --owner "$TASK_OWNER" \
      --checkout "$TASK_TREE" --run "${TASK_RUN:?actual completed frozen watch run path}" \
      --output "$TASK_EXPORT" "${TASK_ARGS[@]}"
    ;;
  consume)
    cd "$TASK_TREE"
    python3 -I tools/host-maintenance/build-admission consume \
      --run "${TASK_RUN:?actual completed frozen watch run path}" \
      --evidence "${TASK_COMPLETION_EVIDENCE:?root-reviewed actual originals and disposition}"
    ;;
  *) exit 64 ;;
esac

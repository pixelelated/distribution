# One packaged Steam caller bridge — source only, UNRUN

This additive packet selects the existing `existing-profile-dot` case from the
accepted full-caller fixture. It does not execute preparation, extraction,
admission, VM, fixture or cleanup during source preparation. Root owns the next
serialized allocation and the literal #564.4/#579.4/#580.4 acceptance decision.
This packet neither changes those criteria nor closes them.

The input is the **accepted packaged-byte-equivalent staged SM module**. The
already required independent firmware reader proves its equality to actual
SYSTEM by bytes, mode and link chain. After ordinary consumed acceptance,
preparation rehashes that exact staged member and copies it into its private
records; it never substitutes an unverified Git copy or claims a new extraction.
`module-input.md` describes this provenance. Actual SM acceptance/consumption
hashes are required future inputs; this packet has no predicted values.

The mixed engineering inputs are explicit: final GENERIC source
`f8636de1d105275dbf9420bbabbbc26f79abb10f`, accepted image SHA
`75caa85ab55309d7e01728c1034cd7c53173549d9fe418e0f1d538db090f47a1`,
and pending SM source `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea`.
Their product delta is only the ABL checksum; the Steam module bytes are identical
SHA `1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b`,
124399 bytes, mode0755, with no installed symlink. GENERIC intentionally omits
this module. The guest stages those SM bytes into the existing isolated fixture
and uses the actual final GENERIC installed interpreters and tools. This is not
a claim that the GENERIC SYSTEM originally contained the module, nor a common RC
identity. The GENERIC producer's #597 reporting failure remains distinct from
its successful independent artifact readback; no missing launcher exit is invented.

## Narrow derivative and evidence carry

The predecessor is
`docs/qa-logs/2026-10-15-steam-vm-helper-correction/`. `changes.diff` contains
the complete executable/binding delta. Within `fixture/`, only `source.json`
(whole-module SHA, runtime shell-slice SHA, one selected case), `boundary.py`
(the exact already accepted metadata curl flags for the same two providers),
and its derived manifest differ. The fixture, payload, ptrace/census/namespace
containment, interpreter boundary, client helper, event collection and format
contract remain byte-identical. Historical source fields, old CRC-failure
records, and original static reports inside that copied directory remain
historical; they are not new qualification of this derivative.

All five embedded helper bodies and stdin digests remain identical to the prior
accepted failure/transaction matrices. `installer-source-continuity.json` records
each digest. Root/FEX/Proton/client shell slices are also identical; the runtime
shell slice differs only by the accepted absolute isolated Python invocation.
`accepted-installer-to-current.diff` records exactly that invocation and bounded
metadata curl argv. The existing Python boundary already accepts `-I -S -B`.
No failure matrix, provider timeout suite, ordinary-save or native gameplay
proof is replayed here. Prior 14-case and helper matrix evidence remains scoped
to its original source and originals, with this explicit helper-byte continuity.

One existing-profile case seeds a retained client/channel, custom profile and
support path, old runtime/FEX and both Proton families plus unrelated files.
The original fixture must observe exactly these nine calls in order:

1. `ensure_fex_rootfs`
2. `link_steam_library`
3. `ensure_steam_desktop_stub`
4. `install_steam_runtime_arm64`
5. `install_steam_client_arm64`
6. `install_bundled_proton_files`
7. `install_proton_cachyos`
8. `install_proton_ge`
9. `run_steam_first_launch`

Review the actual caller-observation, trace, helper events and before/after
manifests: original caller/trace/namespace/fixture0; retained client/channel/
profile and protected game/save/unrelated-FEX identities preserved; profile
actually sourced; client not reacquired; deliberate new FEX generation; runtime
and Proton helper outcomes; transaction scratch gone. FEX extra config is
preserved by bytes/mode, with its expected atomic inode change. Exactly one
native client exec is denied with EACCES13 and native success stays false.
No forced/rescued/unknown original outcome qualifies.

This establishes portable installed-script behavior with installed x86_64 tools
and explicit synthetic transport, FEX and payload boundaries. It does not prove
native ARM FEXRootFSFetcher, loader closure, Wine/Proton games, Steam login,
native launch/self-update, consumer quiescence, or power-loss durability. Actual
SM FEX ELF/package/source equality remains separate artifact evidence. The
coordinator must assess the literal issue criteria without silently treating
these observations as native ARM execution.

## Guarded handoff after actual SM acceptance

First finish and consume ordinary SM acceptance. Fill the two required SM
acceptance/consumption hashes and currently free VNC display in `commands.sh`. `prepare` creates only
the new owner (default `/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-01`).
`preflight` produces fresh resources/retention; inspect original results and
actual current owners before `admit`, then `launch`. Invoke each action
separately; these are not an unattended chain.

All ordinary VM commands use the **frozen GENERIC checkout's own** admission,
watch and launcher tools. Do not substitute the newer SM/coordinator admission
tool or use #597 reporting recovery. The accepted no-network host helper and
adjacent profile are hash-bound independently in `vm-helper-binding.json`.

The single fresh guest has no NIC, 8GiB RAM/4CPU, a16GiB disk,256MiB read-only
input and128MiB output media. The family allows900s plus bounded final sealing/
flush/stop (20/15/35s command limits with existing serial overhead). A case only
starts with180s plus90s reserve remaining. Original guest160s, timeout120+10s,
fixture90s/trace80s/cleanup10s,3GiB private tmpfs and retained byte limits remain.
Budgeted host growth is raw4,333,764,608B +16GiB disk +640MiB media/records;
no separate extraction allocation or additional firmware scan is needed. Root monitors
launcher/runner/stage originals at most60s apart. This is one VM, no providers,
host listeners or external transfer.

The normal path checks selected real guest state unchanged, descendants and
namespaces gone, scratch unmounted, output flushed and QEMU stopped. `export`
requires original family/launcher/watcher success and rehashes the guest member
manifest and host-original archive. Root reviews all originals before creating
completion evidence and invoking `consume`. Export PASS is not independent
acceptance of the issue's broader behavior. No retirement/deletion is performed.

On a booted failed family use `retain-failed` only after teardown, preserving
the actual failure. The inherited exporter expects a recorded boot and guest
manifest: for a preboot failure preserve original host owner/run receipts and
investigate through the existing failed-run path; do not synthesize a boot or
manifest, rerun the fixture, or reinterpret an exit. The lifecycle records
captured failing-command diagnostics and original return codes.

`static-review.json` and its invocation receipts are source/AST/byte checks
only. Preparation, extraction, host helper, VM and fixture remain UNRUN.

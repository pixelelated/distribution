# Accepted packaged-byte-equivalent module — future required input

No second extraction is necessary. After actual ordinary SM acceptance is
consumed, the existing independent reader has already compared the staged
`usr/config/modules/Install Steam.sh` against the extracted update SYSTEM by
bytes, mode and complete link chain. Raw/update SYSTEM equality is checked in
the same accepted firmware family. These are recorded artifact observations,
not an assumption that a source file was installed unchanged.

The preparer requires those original accepted/consumed records and rehashes
their evidence. `affected-products.json` must say PASS, source9aa7, SM8550,
and `staged and independently extracted SYSTEM bytes/modes/link chains`.
The exact selected row must be124399bytes, mode`-rwxr-xr-x`, SHA
`1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b`,
and link chain `{"resolved":"/usr/config/modules/Install Steam.sh","links":[]}`.
The source mapping must identify the actual virtual/emulators module path.

The actual accepted bundle manifest is bound by acceptance, and its complete
`inputs` must equal the stopped owner's inputs: SM05 source9aa7, SM8550,
`build.pixelelated-SM8550.aarch64`. The new ordinary acceptance run must be
consumed with original command/monitor/runner0 and qualified completion;
reporting-failure recovery or an explicitly nonqualified closeout is rejected.
The original completion evidence includes the launcher/wrapper/watch channels
that ordinary consumption already checked. All small evidence is copied into
the new VM owner's private provenance records before use.

Preparation reads only the selected member beneath that bound staged SYSTEM,
rejects all symlink components, checks its actual bytes/size/mode against the
independently accepted row, and checks the bound source mapping's SHA. It then
copies those124399bytes/mode into `records/installed-module.sh`. The receipt
`records/installed-module.json` says `BOUND_INPUT` and explicitly **accepted
packaged-byte-equivalent staged module; no second SYSTEM extraction**. It binds
the original staged locator, source mapping, accepted SYSTEM/update identity,
row, acceptance/consumption hashes, and copied path. It does not invent an
extraction command, extraction exit, or new artifact PASS.

The lifecycle rehashes this private copy when building input media. The guest
and full-caller fixture independently rehash it before execution. Only this
portable shell module enters the guest; ARM ELF binaries are never staged for
execution. The existing accepted SM native-package/ELF readback remains
separate from this x86_64 portable behavior proof.

The original independent reader source is
`/tmp/pix-m7-sm8550-abl-retry-20261015/verify-additions.py` and
`templates/SM8550/acceptance/verify-firmware.py`; both are retained by hash in
`source-original-locators.json`. No reader, extraction lifecycle or new test
gate is introduced by this packet.

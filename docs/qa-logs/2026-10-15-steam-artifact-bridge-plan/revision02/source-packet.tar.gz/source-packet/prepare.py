#!/usr/bin/env python3
"""Prepare one packaged-script VM bridge; requires completed ordinary SM acceptance."""
from pathlib import Path
import argparse, hashlib, json, shutil, stat, subprocess

HERE = Path(__file__).resolve().parent
VM_COMMIT = 'f8636de1d105275dbf9420bbabbbc26f79abb10f'
SM_COMMIT = '9aa7affee9d4ad5e69725cab20b6d7ad84d93dea'
INSTALLER_SHA = '1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b'
SM_OWNER = Path('/workspace/tmp/pix-m7-sm8550-reader-20261015-01')
SM_TREE = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05')

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''): h.update(b)
    return h.hexdigest()

def load(p):
    assert p.is_file() and not p.is_symlink() and p.stat().st_size <= 8*1024**2
    return json.loads(p.read_text())

def save(p,j):
    with p.open('x') as f: json.dump(j,f,indent=2);f.write('\n')

def sealed(p):
    rows={}
    for line in (p/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);assert n not in rows and not Path(n).is_absolute() and '..' not in Path(n).parts
        f=p/n;assert f.resolve(strict=True)==f and f.is_file() and sha(f)==h;rows[n]=h
    assert set(rows)=={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f!=p/'SHA256SUMS'}
    return rows

p=argparse.ArgumentParser();p.add_argument('--owner',type=Path,required=True);p.add_argument('--vnc',type=int,required=True)
p.add_argument('--sm-acceptance-sha256',required=True);p.add_argument('--sm-consumed-sha256',required=True)
a=p.parse_args();assert a.owner.parent==Path('/workspace/tmp') and a.owner.is_absolute() and not a.owner.exists() and not a.owner.is_symlink();assert 100<=a.vnc<=199
sealed(HERE);fixture=sealed(HERE/'fixture');fixture_seal=sha(HERE/'fixture/SHA256SUMS')
# Bind the released #602 source contract, then require its actual later receipts.
sm_bindings_path=SM_OWNER/'bindings.json';assert sha(sm_bindings_path)==sha(HERE/'reader-source/bindings.json')
sm_bindings=load(sm_bindings_path)
assert sm_bindings['source_commit']==SM_COMMIT and sm_bindings['tree']==str(SM_TREE) and sm_bindings['new_owner']==str(SM_OWNER)
assert sm_bindings['old_owner']=='/workspace/tmp/pix-m7-sm8550-refresh-20261015-02'
failed_run=Path(sm_bindings['failed_run']);assert failed_run==SM_TREE/'.build-runs/20261015T081827Z-07dceee9'
failed_completion=Path(sm_bindings['failure_evidence']);failed_consumed=failed_run/'admission-consumed.json'
bound_originals={r['path']:r['sha256'] for r in sm_bindings['files']}
assert sha(failed_completion)==bound_originals[str(failed_completion)] and sha(failed_consumed)==bound_originals[str(failed_consumed)]
failed_done=load(failed_completion);failed_used=load(failed_consumed)
assert failed_done['run']==str(failed_run) and failed_done['disposition']=='failed-investigated' and type(failed_done['expected_rc']) is int and failed_done['expected_rc']==1
assert failed_used['state']=='consumed' and failed_used['run']==str(failed_run) and failed_used['id']==sm_bindings['failed_admission']
assert failed_used['source']['head']==SM_COMMIT and failed_used['checkout']==str(SM_TREE) and failed_used['submission_owner']==sm_bindings['old_owner']
assert failed_used['evidence_sha256']==sha(failed_completion) and failed_used['outputs_held'] is True and failed_used['deleted_bytes']==0
assert all(type(failed_used['original_result'][k]) is int and failed_used['original_result'][k]==v for k,v in [('command_rc',1),('monitor_rc',0),('runner_rc',1)])
accepted=SM_OWNER/'acceptance/artifacts/acceptance.json';assert sha(accepted)==a.sm_acceptance_sha256
acc=load(accepted);assert acc['result']=='PASS' and acc['distribution_commit']==SM_COMMIT
assert acc['scratch_removed'] and acc['source_unchanged'] and acc['independent_bundle_inodes']
assert type(acc['producer_combined_run_returncode']) is int and acc['producer_combined_run_returncode']==1 and acc['producer_failed_run']==str(failed_run)
completion=SM_OWNER/'acceptance/admission-completion-evidence.json';done=load(completion)
assert done['disposition']=='qualified' and done['expected_rc']==0
assert type(done['original_combined_producer_returncode']) is int and done['original_combined_producer_returncode']==1
run=Path(done['run']);assert run.parent==SM_TREE/'.build-runs'
consumed=run/'admission-consumed.json';assert sha(consumed)==a.sm_consumed_sha256
used=load(consumed);assert used['state']=='consumed' and used['evidence_sha256']==sha(completion)
assert used['source']['head']==SM_COMMIT and used['checkout']==str(SM_TREE) and used['run']==str(run)
assert used['submission_owner']==str(SM_OWNER/'acceptance') and run!=failed_run
assert all(used['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert 'launcher_reporting_failure' not in used and used.get('qualification',True) is not False
assert used['outputs_held'] is True and used['deleted_bytes']==0
refs={accepted:sha(accepted),completion:sha(completion),consumed:sha(consumed)}
evidence_paths=set()
for row in done['evidence']:
    f=Path(row['path']);assert f not in evidence_paths and sha(f)==row['sha256'];refs[f]=row['sha256'];evidence_paths.add(f)
products_path=SM_OWNER/'acceptance/artifacts/affected-products.json'
base=SM_OWNER/'acceptance'
assert evidence_paths=={accepted,products_path,base/'artifacts/selected-state.stdout',base/'artifacts/selected-state.exit',base/'inner.rc',base/'outer.rc',base/'launcher-result.json',base/'tool-wrapper.rc',run/'runner-result.json',run/'build.rc',SM_OWNER/'reader-consumption.json',sm_bindings_path,failed_completion,failed_consumed}
assert load(base/'launcher-result.json')['runner_returncode']==0
assert load(run/'runner-result.json')==used['original_result']
assert load(base/'artifacts/selected-state.stdout')['status']=='pass'
for f in [base/'artifacts/selected-state.exit',base/'inner.rc',base/'outer.rc',base/'tool-wrapper.rc',run/'build.rc']:assert int(f.read_text())==0
# The fresh independent acceptance follows an ordinarily consumed fresh reader0.
prior=load(SM_OWNER/'reader-consumption.json')
assert prior['result']=='PASS' and prior['stage']=='reader' and type(prior['original_combined_producer_returncode']) is int and prior['original_combined_producer_returncode']==1
reader_run=Path(prior['run']);assert reader_run.parent==SM_TREE/'.build-runs' and reader_run not in (failed_run,run)
reader_consumed=reader_run/'admission-consumed.json';reader_completion=SM_OWNER/'admission-completion-evidence.json'
assert sha(reader_consumed)==prior['consumed_receipt_sha256'] and sha(reader_completion)==prior['completion_evidence_sha256']
reader_used=load(reader_consumed);reader_done=load(reader_completion)
assert reader_used['state']=='consumed' and reader_used['run']==str(reader_run) and reader_used['checkout']==str(SM_TREE) and reader_used['source']['head']==SM_COMMIT and reader_used['submission_owner']==str(SM_OWNER)
assert reader_used['evidence_sha256']==sha(reader_completion) and reader_used['original_result']==prior['original_result']==load(reader_run/'runner-result.json')
assert all(type(reader_used['original_result'][k]) is int and reader_used['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert 'launcher_reporting_failure' not in reader_used and reader_used.get('qualification',True) is not False
assert reader_used['outputs_held'] is True and reader_used['deleted_bytes']==0
assert reader_done['run']==str(reader_run) and reader_done['disposition']=='qualified' and type(reader_done['expected_rc']) is int and reader_done['expected_rc']==0
assert type(reader_done['original_combined_producer_returncode']) is int and reader_done['original_combined_producer_returncode']==1
refs.update({reader_consumed:sha(reader_consumed),reader_completion:sha(reader_completion)})
reader_evidence=set()
for item in reader_done['evidence']:
    f=Path(item['path']);assert f not in reader_evidence and sha(f)==item['sha256'];refs[f]=item['sha256'];reader_evidence.add(f)
reader_artifacts=SM_OWNER/'artifacts'
assert reader_evidence=={reader_artifacts/'reader-validation.json',reader_artifacts/'output-manifest.json',reader_artifacts/'installed-inclusion.json',reader_artifacts/'affected-products-staged.json',reader_artifacts/'arm-output-manifest.json',SM_OWNER/'inner.rc',SM_OWNER/'outer.rc',SM_OWNER/'tool-wrapper.rc',reader_run/'build.rc',SM_OWNER/'launcher-result.json',reader_run/'runner-result.json',sm_bindings_path,failed_completion,failed_consumed}
assert type(load(SM_OWNER/'launcher-result.json')['runner_returncode']) is int and load(SM_OWNER/'launcher-result.json')['runner_returncode']==0
for f in [SM_OWNER/'inner.rc',SM_OWNER/'outer.rc',SM_OWNER/'tool-wrapper.rc',reader_run/'build.rc']:assert f.read_text().strip()=='0'
reader_proof=load(reader_artifacts/'reader-validation.json');reader_outputs=load(reader_artifacts/'output-manifest.json')
assert reader_proof['result']=='PASS' and reader_proof['source']==SM_COMMIT and reader_proof['original_combined_run_returncode']==1 and reader_proof['failed_producer_run']==str(failed_run)
assert sha(reader_artifacts/'output-manifest.json')==prior['output_manifest_sha256']==reader_proof['output_manifest_sha256']
assert sha(reader_artifacts/'installed-inclusion.json')==reader_proof['installed_inclusion_sha256'] and sha(reader_artifacts/'affected-products-staged.json')==reader_proof['affected_products_sha256']
assert reader_outputs['distribution_commit']==SM_COMMIT and reader_outputs['original_combined_run_returncode']==1 and reader_outputs['failed_producer_run']==str(failed_run)
assert reader_outputs['result']=='READ_VALIDATED_REQUIRES_ARTIFACT_ACCEPTANCE' and reader_outputs['original_output_manifest_sha256']==sm_bindings['output_manifest_sha256']
assert reader_outputs['arm_manifest_sha256']==sha(reader_artifacts/'arm-output-manifest.json')
products=load(products_path);assert products['result']=='PASS'  and products['source']==SM_COMMIT and products['device']=='SM8550'
assert products['comparison']=='staged and independently extracted SYSTEM bytes/modes/link chains'
module='usr/config/modules/Install Steam.sh';row=products['products'][module]
assert row['sha256']==INSTALLER_SHA and row['bytes']==124399 and row['mode']=='-rwxr-xr-x'
assert row['link_chain']=={'resolved':'/'+module,'links':[]}
assert products['source_mappings'][module]=='projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh'
bundle=Path(acc['bundle']);manifest_path=bundle/'manifest.json';assert sha(manifest_path)==acc['bundle_manifest_sha256'];refs[manifest_path]=sha(manifest_path)
manifest=load(manifest_path);assert manifest['inputs']['distribution_commit']==SM_COMMIT and manifest['inputs']['device']=='SM8550'
tars=[n for n in manifest['files'] if n.endswith('.tar')];assert len(tars)==1;archive=bundle/tars[0]
assert archive.is_file() and not archive.is_symlink() and archive.stat().st_size==manifest['files'][tars[0]]['bytes']
assert len(acc['variants'])==1 and acc['variants'][0]['variant']=='SM8550'
checker=SM_TREE/'tools/pixelelated-state-check';assert sha(checker)=='65ab515ec2c0ccdf474f08128cabf1dea774846a8add3725cd05d334b2e1eba6';refs[checker]=sha(checker)
vm_original=Path('/workspace/tmp/pix-m7-image-readback-20261015-02/artifacts')
for n,h in [('inputs.json','7c3f497b08f494d15a233ae99be05e61af1656aec173120b00b41dd0266e2728'),('result.json','3d3b85724062a6db2f7bddc5dd62aeb1366f0f6182f267a7b0e6131322c0649c')]:assert sha(vm_original/n)==h;refs[vm_original/n]=h
vi=load(vm_original/'inputs.json');vr=load(vm_original/'result.json');assert vi['source']==vr['source']==VM_COMMIT and vr['status']=='PASS'
assert vi['identity']['device']=='GENERIC_X64' and vi['identity']['arch']=='x86_64'
tree=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True,timeout=20).strip()==VM_COMMIT
assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree,timeout=20).strip()
images=[(Path(n),r) for n,r in vi['artifacts'].items() if n.endswith('.img.gz')];assert len(images)==1;image,im=images[0]
assert image.is_file() and not image.is_symlink() and image.stat().st_size==im['bytes']
raw_bytes=(vm_original/'candidate.img').stat().st_size;assert raw_bytes==4333764608
helper=load(HERE/'vm-helper-binding.json')
for x in [helper,helper['profile']]:assert sha(Path(x['path']))==x['sha256'];refs[Path(x['path'])]=x['sha256']
# The independent accepted reader already proved staged/SYSTEM byte, mode and
# link-chain equality. Copy that exact staged member; do not claim a second extraction.
sm_inputs_path=SM_OWNER/'inputs.json';sm_inputs=load(sm_inputs_path)
assert sm_inputs['host_worktree']==str(SM_TREE) and sm_inputs['distribution_commit']==SM_COMMIT
assert sm_inputs['device']=='SM8550' and sm_inputs['build_root']=='build.pixelelated-SM8550.aarch64'
assert manifest['inputs']==sm_inputs
continuation=sm_inputs['validation_continuation']
assert continuation['failed_owner']==sm_bindings['old_owner'] and continuation['failed_run']==str(failed_run) and continuation['failed_admission']==sm_bindings['failed_admission']
assert type(continuation['original_combined_run_returncode']) is int and continuation['original_combined_run_returncode']==1 and continuation['compiler_or_image_rerun'] is False
assert continuation['original_output_manifest_sha256']==sm_bindings['output_manifest_sha256'] and continuation['bindings_sha256']==sha(sm_bindings_path)
assert continuation['source_packet_sha256']==sha(HERE/'reader-source/SHA256SUMS')
assert sm_inputs['arm_manifest']==str(reader_artifacts/'arm-output-manifest.json')
refs[sm_inputs_path]=sha(sm_inputs_path)
staged_module=SM_TREE/sm_inputs['build_root']/'image/system'/module
assert staged_module.resolve(strict=True)==staged_module and staged_module.is_file()
assert sha(staged_module)==row['sha256'] and staged_module.stat().st_size==row['bytes']
assert stat.filemode(staged_module.stat().st_mode)==row['mode']
source_module=SM_TREE/products['source_mappings'][module]
assert source_module.resolve(strict=True)==source_module and sha(source_module)==INSTALLER_SHA
a.owner.mkdir()
for name in ['records','records/provenance','scan','vm','stages','lifecycle-owner','logs']:(a.owner/name).mkdir()
for f,h in refs.items():
    copied=a.owner/'records/provenance'/h;shutil.copyfile(f,copied);assert sha(copied)==h
save(a.owner/'records/reference-originals.json',[{'path':str(f),'sha256':h} for f,h in refs.items()])
sm={'source':SM_COMMIT,'acceptance':str(accepted),'acceptance_sha256':sha(accepted),'consumed':str(consumed),'consumed_sha256':sha(consumed),'archive':str(archive),**manifest['files'][tars[0]],'system_sha256':acc['variants'][0]['system_sha256'],'module':module,'product':row,'checker':str(checker),'checker_sha256':sha(checker)}
sm.update({'reader_consumption':str(SM_OWNER/'reader-consumption.json'),'reader_consumption_sha256':sha(SM_OWNER/'reader-consumption.json'),'reader_consumed':str(reader_consumed),'reader_consumed_sha256':sha(reader_consumed),'bindings':str(sm_bindings_path),'bindings_sha256':sha(sm_bindings_path),'producer_combined_run_returncode':1,'producer_failed_run':str(failed_run),'producer_failed_completion_sha256':sha(failed_completion),'producer_failed_consumed_sha256':sha(failed_consumed)})
save(a.owner/'records/sm-artifact.json',sm)
module_copy=a.owner/'records/installed-module.sh';shutil.copy2(staged_module,module_copy)
assert sha(module_copy)==INSTALLER_SHA and stat.filemode(module_copy.stat().st_mode)==row['mode']
save(a.owner/'records/installed-module.json',{'status':'BOUND_INPUT','provenance':'Accepted packaged-byte-equivalent staged module; no second SYSTEM extraction',
 'source':SM_COMMIT,'staged_path':str(staged_module),'copied_path':str(module_copy),'source_mapping':str(source_module),
 'acceptance_sha256':sha(accepted),'consumed_sha256':sha(consumed),'affected_products_sha256':sha(products_path),
 'archive':str(archive),'archive_sha256':manifest['files'][tars[0]]['sha256'],'system_sha256':acc['variants'][0]['system_sha256'],
 'installed_path':'/'+module,**row})
family={'cases':['existing-profile-dot'],'source_commit':VM_COMMIT,'installer_path':'accepted-sm/'+module,'installer_sha256':INSTALLER_SHA,'scope':'Packaged portable script with installed VM dependencies; synthetic boundaries; no native ARM','sm_artifact':sm,'remaining_packet_seal':fixture_seal}
save(a.owner/'records/family.json',family)
files=[{'path':str(HERE/'fixture'/n),'destination':'docs/qa-logs/2026-10-14-steam-remaining-source/'+n,'sha256':sha(HERE/'fixture'/n)} for n in [*fixture,'SHA256SUMS']]
for f,n in [(HERE/'guest-stage.py','guest-stage.py'),(a.owner/'records/family.json','family.json'),(module_copy,'accepted-sm/'+module)]:files.append({'path':str(f),'destination':n,'sha256':sha(f)})
save(a.owner/'records/inputs.json',{'files':files,'helper':helper})
save(a.owner/'records/image-size.json',{'image':str(image),'compressed_bytes':im['bytes'],'raw_bytes_from_backup_lba':raw_bytes,'sha256':im['sha256']})
shutil.copyfile(HERE/'vm-lifecycle.py',a.owner/'vm-lifecycle.py')
runtime={'checkout':str(tree),'commit':VM_COMMIT,'panel':'640x480','cases':['existing-profile-dot'],'vnc':a.vnc,'family_seconds':900,'stage_seconds':180,'installer_sha256':INSTALLER_SHA,'tool_hashes':{n:sha(tree/n) for n in ['tools/vm-serial','tools/vm-stop']},'packet':str(HERE),'packet_manifest_sha256':sha(HERE/'SHA256SUMS')}
save(a.owner/'records/runtime.json',runtime)
terms={'raw_image':raw_bytes,'guest_disk':16*1024**3,'input_media':256*1024**2,'output_media':128*1024**2,'records_export':256*1024**2}
plan={'volume':'/workspace','scan_roots':[str(a.owner/'scan')],'reference_stores':[],'protected':[str(HERE),str(tree),str(image),str(SM_OWNER),str(SM_TREE),str(bundle),str(staged_module),helper['path'],helper['profile']['path']],'candidates':[],'builds':[{'name':'pix-m7-steam-artifact-bridge','terms_bytes':terms,'basis':'One serialized no-NIC8GiB/4CPU guest,900s family/90s bounded finally; unchanged90s case/80s trace/120+10 wrapper;3GiB guest tmpfs; actual accepted SM SYSTEM module only, no native ARM target execution.','evidence':[{'path':str(a.owner/n),'sha256':sha(a.owner/n)} for n in ['records/sm-artifact.json','records/image-size.json','records/inputs.json','records/runtime.json','vm-lifecycle.py']]}]}
save(a.owner/'retention-plan.json',plan)
save(a.owner/'admission-plan.json',{'checkout':str(tree),'retention_plan':str(a.owner/'retention-plan.json'),'retention_report':str(a.owner/'retention-report.json'),'stage':'pix-m7-steam-artifact-bridge','profiles':[{'PROJECT':'ROCKNIX','DEVICE':'GENERIC_X64','ARCH':'x86_64'}],'outputs':[{'path':str(a.owner/'vm'),'issue':564,'kind':'qa-scratch','release_when':'Original packaged-script result exported/reviewed/consumed and actual owners absent; guarded retirement only.'}]})
print(a.owner/'admission-plan.json')

# Accepted packaged-byte-equivalent module — revision02 future input

No second extraction is necessary. After actual ordinary SM acceptance is
consumed, the existing independent reader has already compared the staged
`usr/config/modules/Install Steam.sh` against the extracted update SYSTEM by
bytes, mode and complete link chain. Raw/update SYSTEM equality is checked in
the same accepted firmware family. These are recorded artifact observations,
not an assumption that a source file was installed unchanged.

The preparer requires those original accepted/consumed records and rehashes
their evidence. `affected-products.json` must say PASS, source9aa7, SM8550,
and `staged and independently extracted SYSTEM bytes/modes/link chains`.
The exact selected row must be124399bytes, mode`-rwxr-xr-x`, SHA
`1694f7a9b892988a67a3445c8f51031c5a5c8be02628b0be8031f233b512ad3b`,
and link chain `{"resolved":"/usr/config/modules/Install Steam.sh","links":[]}`.
The source mapping must identify the actual virtual/emulators module path.

The actual accepted bundle manifest is bound by acceptance, and its complete
`inputs` must equal the stopped owner's inputs: SM05 source9aa7, SM8550,
`build.pixelelated-SM8550.aarch64`. The new ordinary acceptance run must be
consumed with original command/monitor/runner0 and qualified completion;
reporting-failure recovery or an explicitly nonqualified closeout is rejected.
The exact fourteen-member acceptance evidence set includes the original ten channels plus `reader-consumption.json`, `bindings.json`, the original failed producer completion evidence, and that failed run's consumed receipt. The preparer separately verifies the reader's fourteen-member evidence set, actual ordinary consumed0, launcher/wrapper/watch0, output/ARM manifest identities, and failed-producer provenance. The exact released bindings and input `validation_continuation` require producer1, unchanged SM source9aa7, and no compiler/image rerun. All small evidence is copied into the new VM owner's private provenance records before use.

Preparation reads only the selected member beneath that bound staged SYSTEM,
rejects all symlink components, checks its actual bytes/size/mode against the
independently accepted row, and checks the bound source mapping's SHA. It then
copies those124399bytes/mode into `records/installed-module.sh`. The receipt
`records/installed-module.json` says `BOUND_INPUT` and explicitly **accepted
packaged-byte-equivalent staged module; no second SYSTEM extraction**. It binds
the original staged locator, source mapping, accepted SYSTEM/update identity,
row, acceptance/consumption hashes, and copied path. It does not invent an
extraction command, extraction exit, or new artifact PASS.

The lifecycle rehashes this private copy when building input media. The guest
and full-caller fixture independently rehash it before execution. Only this
portable shell module enters the guest; ARM ELF binaries are never staged for
execution. The existing accepted SM native-package/ELF readback remains
separate from this x86_64 portable behavior proof.

The accepted-owner input is now `/workspace/tmp/pix-m7-sm8550-reader-20261015-01`, whose future accepted bundle contains its exact revised `inputs.json`. The failed producer remains `/workspace/tmp/pix-m7-sm8550-refresh-20261015-02`, run `20261015T081827Z-07dceee9`. Their failure completion/consumed hashes are already real and bound by the released #602 source; reader and acceptance outcome hashes remain future required values.

The current independent reader source is `/tmp/pix-m7-sm8550-abl-format-20261015`, source seal `a21e5fb59b64de08d2d000def1e622f657711a66b54238efba5aeae2a90b0fa7`. The selected `consume-reader-stage.py`, `reader.py`, acceptance `run.py`/`verify-firmware.py`, preparer, bindings and handoff are retained under `reader-source/` by exact sealed hashes. `source-original-locators.json` continues to describe the immutable original bridge's earlier source references; it is not silently rewritten. No reader, extraction lifecycle, or new test gate is introduced by this packet.

"""AST/byte checks only; never import or execute candidate/preparer/fixture code."""
from pathlib import Path
import ast,hashlib,json,stat,subprocess
P=Path(__file__).resolve().parent;O=Path('/tmp/pix-m7-steam-artifact-bridge-20261015');R=Path('/tmp/pix-m7-sm8550-abl-format-20261015')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(O/'SHA256SUMS')=='f4d2b12736468a0b9811786515761b0505981aa0918411ffa7e757f1c0273355'
assert sha(P/'prepare.py')=='6bd3dcf736183d0527f3bd52a77cee7377d0b85c62025f39e8af1d66999a60af'
assert sha(P/'revision02-code.diff')=='21fab173ac25cab75bdecb2bebeced83afa61fd0ddae4d28a93f616069945c9b'
assert (P/'predecessor-SHA256SUMS').read_bytes()==(O/'SHA256SUMS').read_bytes()
assert (P/'predecessor-manifest.json').read_bytes()==(O/'manifest.json').read_bytes()
expected_changes={'prepare.py','commands.sh','README.md','module-input.md','manifest.json'}
identical=[]
for line in (O/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(O/n)==h
 if n not in expected_changes:
  assert sha(P/n)==h and stat.S_IMODE((P/n).stat().st_mode)==stat.S_IMODE((O/n).stat().st_mode);identical.append(n)
parsed=[]
for f in sorted(P.rglob('*.py')):ast.parse(f.read_text(),filename=str(f));parsed.append(str(f.relative_to(P)))
functions=lambda f:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(f.read_text()).body if isinstance(n,ast.FunctionDef)}
assert functions(P/'prepare.py')==functions(O/'prepare.py')
a=(O/'prepare.py').read_text();b=(P/'prepare.py').read_text()
assert a[a.index("module_copy=a.owner/"):]==b[b.index("module_copy=a.owner/"):]
assert a[a.index("module='usr/config/modules/Install Steam.sh'"):a.index('vm_original=Path')]==b[b.index("module='usr/config/modules/Install Steam.sh'"):b.index('vm_original=Path')]
assert a[a.index('vm_original=Path'):a.index("assert manifest['inputs']==sm_inputs")]==b[b.index('vm_original=Path'):b.index("assert manifest['inputs']==sm_inputs")]
expected=(O/'commands.sh').read_text().replace('/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-01','/workspace/tmp/pix-m7-steam-artifact-bridge-20261015-02').replace('/workspace/tmp/pix-m7-steam-artifact-bridge-evidence-20261015-01','/workspace/tmp/pix-m7-steam-artifact-bridge-evidence-20261015-02')
assert expected==(P/'commands.sh').read_text()
assert sha(R/'SHA256SUMS')=='a21e5fb59b64de08d2d000def1e622f657711a66b54238efba5aeae2a90b0fa7'
assert (P/'reader-source/SHA256SUMS').read_bytes()==(R/'SHA256SUMS').read_bytes()
reader_rows={n:h for h,n in (line.split('  ',1) for line in (R/'SHA256SUMS').read_text().splitlines())}
reader_copies=[]
for f in sorted((P/'reader-source').rglob('*')):
 if f.is_file() and f.name!='SHA256SUMS':
  n=str(f.relative_to(P/'reader-source'));assert sha(f)==reader_rows[n]==sha(R/n);reader_copies.append(n)
for line in (P/'fixture/SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(P/'fixture'/n)==h
required=json.loads((P/'required-actual-inputs.json').read_text())
assert all(required[k] is None for k in ['sm_acceptance_sha256','sm_consumed_sha256','reader_consumption_sha256','reader_consumed_sha256'])
subprocess.run(['bash','-n',str(P/'commands.sh')],check=True)
result={'status':'PASS','scope':'Source AST/byte/shell syntax only; no preparer, candidate import, fixture, VM, runtime or artifact reads','predecessor_seal':sha(O/'SHA256SUMS'),'reader_source_seal':sha(R/'SHA256SUMS'),'unchanged_predecessor_payload_count':len(identical),'unchanged_predecessor_payloads':identical,'python_sources_parsed':parsed,'reader_source_copies_verified':reader_copies,'helper_functions_ast_identical':True,'module_validation_and_vm_source_inputs_unchanged':True,'module_copy_through_all_runtime_resource_admission_plan_source_bytes_identical':True,'commands_only_two_default_path_substitutions':True,'future_outcome_hashes_remain_null':True,'runtime_status':'UNRUN'}
with (P/'revision02-static-review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('PASS prerequisite-only source rebind; all VM/fixture/helper/resource/lifecycle bytes unchanged; runtime UNRUN')

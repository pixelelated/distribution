from pathlib import Path
import subprocess,json,struct,hashlib,time
owner=Path('/workspace/tmp/pix-m7-installed-clean588-20261014-01'); out=owner/'marker-readback';out.mkdir()
assert not Path('/proc/831646').exists()
disk=owner/'vm/disk.qcow2'; cmds=[]
def run(args,name,timeout=30):
 t=time.time();r=subprocess.run(args,capture_output=True,timeout=timeout);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);cmds.append({'argv':args,'rc':r.returncode,'seconds':time.time()-t});assert r.returncode==0;return r.stdout
run(['qemu-img','dd','-f','qcow2','bs=512','count=128','if='+str(disk),'of='+str(out/'head.bin')],'header')
b=(out/'head.bin').read_bytes();assert b[512:520]==b'EFI PART';lba,n,size=struct.unpack_from('<QII',b,512+72);assert size==128 and n<=128
parts=[]
for i in range(n):
 e=b[lba*512+i*size:lba*512+(i+1)*size]
 if not any(e[:16]):continue
 start,end=struct.unpack_from('<QQ',e,32);name=e[56:].decode('utf-16-le').rstrip('\0');parts.append({'start':start,'end':end,'name':name})
assert len(parts)==2
p=parts[1];raw=owner/'vm/marker-storage.ext4';assert not raw.exists()
opts='driver=raw,offset='+str(p['start']*512)+',size='+str((p['end']-p['start']+1)*512)+',file.driver=qcow2,file.file.filename='+str(disk)
run(['qemu-img','convert','--image-opts','-O','raw','-S','4096','-m','1',opts,str(raw)],'storage',90)
for name,request in [('marker','cat /.cache/cloud_sync/log-scrubbed'),('cache-list','ls -l /.cache/cloud_sync'),('es-log-stat','stat /.config/emulationstation/es_log.txt'),('es-log','cat /.config/emulationstation/es_log.txt')]:
 run(['/usr/sbin/debugfs','-R',request,str(raw)],name)
(out/'result.json').write_text(json.dumps({'partitions':parts,'commands':cmds,'storage_allocated':raw.stat().st_blocks*512,'source_unchanged':True},indent=2)+'\n')
print((out/'marker.stdout').read_text());print('allocated',raw.stat().st_blocks*512)

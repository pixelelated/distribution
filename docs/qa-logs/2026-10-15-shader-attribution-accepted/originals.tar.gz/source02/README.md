# Shader attribution pass revision02 — SOURCE ONLY, UNRUN

This additive #604 correction preserves source01 and its failed original run. Read [REVISION02.md](REVISION02.md) for the exact duplicate-record diagnosis, provenance-preserving change and controls; allocation/output scope remains #528.

This is a small derivative of accepted notice04's host lifecycle for #528. It analyzes completed retained text and exact selected-member mappings. It does not collect shader source again, open source archives or firmware, scan source/build caches, execute targets, change products, or decide legal permission. The preparer, pass, controls and lifecycle have **not** been run. Only source parsing and helper byte/AST comparisons were performed during preparation.

## Fixed input scope

`attribution-plan.json` binds eight historical occurrence JSONs by exact path/hash/size, plus notice04's actual result, original consumption and reuse receipts. The records total 55,954,144 bytes and contain 20,018 selected rows. H700 common/RetroPie reports overlap the same installed prefix; exact `(profile, installed path)` observations must agree before they collapse to 18,523 physical rows: 18,516 source/package/staged byte matches and seven generated empty `.overlay` markers. Unexpected ambiguity, disagreement, unmatched content or a changed bound input fails the pass.

The input records remain historical originals from failed owner03 (some were first produced by owner01). Their exact completed rows were reused and accepted by notice04, admission `23d610ed3610468c8902f9019a38a65e`; original03's collector1 and 256MiB bound breach remain explicitly preserved by `bindings.py`. A successful analysis will not relabel those producers. Notice04's 7,187-member text index supplies the allowlist; the pass reads only the selected existing hash-addressed files beneath its completed `collection/notices/` directory. Paths in source/package/staged metadata are provenance strings and are never opened by this pass.

Both record formats are handled: older `notice_members` arrays and newer `notice_member_refs` plus `notice_member_index`. Source identities include component, recipe hash, unpacked pin and archive identity; equal file bytes do not merge different components or paths. Shared source members across profiles are joined by this identity. Original source/staged equality remains the previously observed relationship; no fresh SYSTEM extraction is claimed.

## What one pass produces

Eight compact files under the fresh owner's `attribution/` directory:

- `source-identities.json`: four exact component source identities.
- `installed-observations.json`: exact physical installed mapping plus all original record/row references, including duplicate report custody.
- `sources.json`: one row per component/pin/relative member/hash, its complete retained-text reference when available, disposition, and scope references.
- `notices.json`: deduplicated notice metadata with original source path and text hash.
- `texts.json`: existing content-addressed text paths and exact candidate byte/line ranges, range hashes, and credit/grant/licence/restriction/URL cue tags. Text itself is not recopied. Non-UTF8 text remains exact byte references.
- `scope-edges.json`: exact self/ancestor/unrelated relationships with `permission_inherited:false`. A root licence filename is not a grant for every member.
- `specific-review-entries.json`: named source members with exact asset/permission/restriction or cross-reference questions. Standard “all rights reserved” is recorded as attribution, not alone as a restriction.
- `input-read-receipt.json`: every actual bounded metadata/text read and its verified hash/size.

Comment blocks and named notice documents are referenced whole when recognized; isolated attribution/reference lines are also retained as exact ranges. All full texts remain available through existing custody. Recognition misses are labelled as such, never as absence of permission. In-file grant/licence cues can support conservative full source/notices inclusion for review; ancestor cues retain an explicit applicability question. Hash-only assets remain individually named and linked to scoped notices, without asserting that a shader's code licence covers its image/font/texture. Mixed or restrictive wording is a review candidate, not an automatic exclusion or a new policy gate.

This supplies the actual per-member index needed to review the already identified crt-royale, nnedi3, ArtCNN, crt-beans, CuNNy, scanline-classic/koko, Mega_Bezel community-pack and handheld-nebula credit scopes. It does not recollect them or infer a collection-wide licence. Earlier GLSL crt-royale relative-member reporting and generated-overlay origin questions stay resolved by the existing source/mapping evidence.

## Bounds and unchanged lifecycle

The child reads at most128MiB of named inputs, including metadata, and at most128MiB of retained text; each text is at most2MiB, each metadata record at most16MiB. It permits at most65,536 selected rows, source members, notice nodes, scope edges and candidate ranges; at most8,192 distinct text hashes. The fixed input is eight occurrence records, not a directory traversal. These are hard failure bounds, with no automatic increase or skipping.

The owner output bound is **64MiB**, reduced from notice04's256MiB because full text/records are external references. Its exact qualified `account_output` AST preserves before-write checks, exclusive creation, the4MiB normal reserve, a maximum3MiB failure receipt and1MiB supervisor margin. Existing owner files count from startup. `attribution-members.json` binds every emitted payload. Supervisor and consumer independently check actual retained owner bytes.

The qualified outer limit remains630s with600s child wait,580s internal deadline,2GiB address space, CPU affinity0,1, and bounded identity/pidfd cleanup. The10 supervisor functions, `process-identity.py`, `run.sh`, and host/serialization binding functions are unchanged. `lifecycle.diff` shows only the task label, accepted-input/output assertions and result scope changes. The established `notices` stage filenames and `original_collector_exit` schema key are retained for lifecycle compatibility; here the command performs retained-evidence analysis, not new source collection. Original exits, timeout/interruption state, launcher result, strict descendant census and ordinary consumption remain mandatory.

`qualified-helper-provenance.json` names the exact accepted helper originals. `frozen-tools.json` requires the frozen `f8636de1` tree's ordinary admission/watch tools. The coordinator's #597 reporting-failure route is not used.

## Narrow controls and execution handoff

`controls.py` contains25 pure checks: the15 original ancestry/candidate checks, eight duplicate payload/reference cases and two notice-provenance cases. It loads `templates/scope.py` (no I/O or production paths) and compiles only the exact `content_id`/`notice_id` function ASTs into a synthetic namespace. It never imports or initializes the pass, reads completed text inputs or invokes filesystem-writing helpers. **Revision02 controls are UNRUN.** Root may allocate them as a single bounded host child (<1s expected; <1MiB scratch), retaining the actual command, original exit and output. No control result is asserted here.

After review, root uses each separate boundary in `commands.sh`: `prepare`, `preflight`, `report`, inspect the actual reports, then `admit`, `launch`, supervised original completion, review outputs, and `consume`. The proposed fresh owner is `/workspace/tmp/pix-m7-shader-attribution-20261015-02`; none was created during preparation. Do not combine allocation and report inspection or pre-create launcher-owned receipts. Failures stay held for ordinary investigated consumption; this packet provides no missing-receipt fallback.

Successful technical completion means every bound selected observation and retained text was accounted for and exact candidate/scope artifacts were emitted. Specific permission questions may remain; their presence is not a technical failure. Public retrieval, off-host custody, source publication, and existing ABL/Doom/ZeroTier issues remain separate. No whole-release clearance or product-removal requirement is added.

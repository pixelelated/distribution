#!/usr/bin/env python3
"""Prepare one fresh retained-shader analysis owner; do not run its pass."""
from pathlib import Path
import argparse,hashlib,json,re,runpy,shutil
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def main():
 q=argparse.ArgumentParser(description=__doc__);q.add_argument('--owner',type=Path,required=True);a=q.parse_args()
 names=[]
 for line in (P/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);p=P/n
  assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink() and sha(p)==h
  names.append(n)
 assert sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
 B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']()
 assert Path.cwd()==B['VM_TREE'];O=a.owner
 assert O.parent==Path('/workspace/tmp') and re.fullmatch('pix-m7-shader-attribution-20261015-[0-9]{2}',O.name)
 assert not O.exists() and not O.is_symlink()
 O.mkdir(mode=0o700);(O/'stage').mkdir();(O/'empty-retention-scan').mkdir()
 for p in sorted((P/'templates').iterdir()):assert p.is_file() and not p.is_symlink();shutil.copy2(p,O/p.name)
 for n in ['resources.json','frozen-tools.json','attribution-plan.json']:shutil.copy2(P/n,O/n)
 put(O/'preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),prior_notice_admission='23d610ed3610468c8902f9019a38a65e',analysis_executed=False,cache_inputs_read=False,publication_clearance=False))
 protected=['/workspace/tmp/pix-m7-current-notice-supplement-20261015-01','/workspace/tmp/pix-m7-current-notice-supplement-20261015-03','/workspace/tmp/pix-m7-current-notice-supplement-20261015-04','/workspace/tmp/pix-m7-final-inventory-20261015-01','/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources',str(B['VM_TREE']),str(P)]
 put(O/'retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=protected,candidates=[],builds=[dict(name='m7-retained-shader-attribution',terms_bytes={'bounded_metadata_and_margin':512*1024**2},basis='64MiB owner output bound plus operating margin; exact completed evidence read only; no deletion credit.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])]))
 put(O/'admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-retained-shader-attribution',profiles=[dict(PROJECT='ROCKNIX',DEVICE=d,ARCH=arch) for d,arch in [('GENERIC_X64','x86_64'),('H700','arm'),('H700','aarch64'),('SM8550','arm'),('SM8550','aarch64')]],outputs=[dict(path=str(O),kind='qa-scratch',issue=528,release_when='Original bounded retained-text analysis consumed and compact evidence retained; notice applicability and publication holds remain explicit.')]))
 put(O/'seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()});B['verify'](O)
 print(json.dumps(dict(owner=str(O),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),publication_clearance=False)))
if __name__=='__main__':main()

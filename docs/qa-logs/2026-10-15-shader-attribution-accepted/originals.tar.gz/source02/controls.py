#!/usr/bin/env python3
"""UNRUN pure candidate/ancestry controls; only this packet's pure source is loaded."""
from pathlib import Path
import ast,copy,hashlib,json,runpy
S=runpy.run_path(str(Path(__file__).resolve().parent/'templates/scope.py'))
R,C,D=S['relation'],S['candidates'],S['disposition'];checked=[]
def check(name,condition):assert condition,name;checked.append(name)
check('ancestor-directory',R('crt/a.slang','crt/LICENSE')=='ANCESTOR_CANDIDATE')
check('not-lexical-prefix',R('crt2/a.slang','crt/LICENSE')=='UNRELATED_CANDIDATE')
check('self-notice',R('README.md','README.md')=='SELF')
check('root-is-candidate-only',R('crt/a.slang','LICENSE')=='ANCESTOR_CANDIDATE')
try:R('../escape','LICENSE')
except AssertionError:checked.append('parent-traversal-refused')
else:raise AssertionError('traversal accepted')
raw=b'/* Copyright A\nPermission is hereby granted to use.\n*/\nvoid main() {}\n';cs=C(raw)
check('whole-comment-reference',any(c['start_byte']==0 and c['end_byte_exclusive']==raw.index(b'*/')+2 for c in cs))
check('exact-byte-hashes',all(c['sha256']==hashlib.sha256(raw[c['start_byte']:c['end_byte_exclusive']]).hexdigest() for c in cs))
check('no-candidate-clearance',all(c['permission_determined'] is False for c in cs))
check('copyright-only-not-permission',D(True,['copyright'],[])=='ATTRIBUTION_WITHOUT_RECOGNIZED_PERMISSION_CANDIDATE')
check('filename-does-not-grant',D(True,[],[])=='NO_RECOGNIZED_PERMISSION_CANDIDATE_REVIEW_RETAINED_TEXT')
check('ancestor-not-automatic',D(True,[],['licence_reference'])=='ANCESTOR_PERMISSION_OR_LICENCE_CANDIDATE_SCOPE_OPEN')
check('asset-stays-specific-open',D(False,[],['permission_clause'])=='ASSET_OR_UNRETAINED_TEXT_SCOPE_OPEN')
mixed=C(b'/* GPL license. Portion under MIT license. Non-commercial use only. */')
check('mixed-restriction-retained',any('restriction_candidate' in c['tags'] and 'licence_reference' in c['tags'] for c in mixed))
raw=b'// Copyright Ren\xe9\n// Licensed under MIT license\n';cs=C(raw)
check('nonutf8-byte-custody',len(cs)==1 and cs[0]['sha256']==hashlib.sha256(raw).hexdigest())
doc=b'Copyright A\n\nPermission is hereby granted.\n\nOther details.\n';cs=C(doc,document=True)
check('complete-document-reference',len(cs)==1 and cs[0]['start_byte']==0 and cs[0]['end_byte_exclusive']==len(doc))
select=S['selected_payload']
source={'relative':'bicubic/README.md','sha256':'a'*64,'bytes':701,'kind':'file','status':'OBSERVED_REGULAR_FILE'}
ref={'sha256':'a'*64,'bytes':701,'retained':'collection/notices/'+'a'*64,'empty':False,'notice_coverage_established':False}
notice=dict(source,retained_text=ref,path='/first/README.md')
second=copy.deepcopy(notice);second['path']='/another-provenance/README.md'
check('duplicate-identical-identity-ref-accepted',select(source,[notice,second])==ref)
check('direct-reference-and-duplicates-accepted',select(dict(source,retained_text=copy.deepcopy(ref)),[notice,second])==ref)
check('no-self-notice-no-payload',select(source,[]) is None)
def refuses(name,notices,selected=source):
 try:select(selected,notices)
 except AssertionError:checked.append(name)
 else:raise AssertionError(name)
bad=copy.deepcopy(second);bad['sha256']='b'*64
refuses('same-relative-conflicting-hash-refused',[notice,bad])
bad=copy.deepcopy(second);bad['retained_text']['retained']='collection/notices/'+'b'*64
refuses('same-identity-conflicting-path-refused',[notice,bad])
bad=copy.deepcopy(second);bad['retained_text']['bytes']=702
refuses('same-identity-conflicting-size-refused',[notice,bad])
bad=copy.deepcopy(second);bad['retained_text']['notice_coverage_established']=True
refuses('differing-full-reference-refused',[notice,bad])
bad=copy.deepcopy(ref);bad['bytes']=702
refuses('direct-reference-conflict-refused',[notice],dict(source,retained_text=bad))
# Read only two exact function ASTs into an isolated synthetic namespace. Never
# import collect.py, its globals, main, inputs or any filesystem-writing helper.
tree=ast.parse((Path(__file__).resolve().parent/'templates/collect.py').read_text())
fragments=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'content_id','notice_id'}]
assert len(fragments)==2
ns={'json':json,'sha':lambda b:hashlib.sha256(b).hexdigest(),'relative':S['relative'],'PurePosixPath':S['PurePosixPath'],'text_ref':lambda ref,document=False:ref['sha256'],'NOTICES':{}}
exec(compile(ast.Module(body=fragments,type_ignores=[]),'<exact-notice-functions-synthetic-only>','exec'),ns)
key=ns['notice_id']('component','pin',notice,['record-a',1,0])
check('duplicate-notice-provenance-retained',ns['notice_id']('component','pin',second,['record-b',2,1])==key and ns['NOTICES'][key]['original_record_refs']==[['record-a',1,0],['record-b',2,1]])
bad=copy.deepcopy(second);bad['retained_text']['notice_coverage_established']=True
try:ns['notice_id']('component','pin',bad,['record-c',3,2])
except AssertionError:checked.append('duplicate-notice-conflicting-reference-refused')
else:raise AssertionError('duplicate notice conflicting reference accepted')
print(json.dumps(dict(result='PASS_PURE_SOURCE_CANDIDATE_CONTROLS',cases=checked,production_inputs_read=False,collector_imported=False,target_execution=False),sort_keys=True))

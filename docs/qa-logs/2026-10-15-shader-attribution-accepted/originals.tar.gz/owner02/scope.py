"""Pure byte-range candidate and lexical ancestry functions; no input/output."""
from pathlib import PurePosixPath
import hashlib,re

PATTERNS = {
 'copyright': rb'copyright|\(c\)\s*(?:19|20)\d\d|\xc2\xa9|all rights reserved',
 'credit': rb'\bauthor\b|\bcredits?\b|\battribution\b|\bported (?:by|from)\b|\badapted (?:by|from)\b|\bderived from\b|NASA|STScI',
 'permission_clause': rb'permission is (?:hereby )?granted|redistribution and use|you (?:can|may) redistribute|released (?:under|into)|licensed under|distributed under|\bpublic domain\b',
 'licence_reference': rb'SPDX-License-Identifier|(?:GNU|Lesser|Library)\s+General\s+Public\s+Licen[cs]e|\b[AL]?GPL\b|\bMIT licen[cs]e\b|\bBSD\b|\bCC[- ](?:BY|0)\b|\bzlib\b|licen[cs]e',
 'restriction_candidate': rb'non[- ]?commercial|commercial use|not for (?:public )?distribution|no derivatives|no[- ]?derivatives|permission (?:from|of|must)|may not (?:redistribute|distribute)|not (?:included|covered).*licen[cs]e|separate.*(?:licen[cs]e|terms)',
 'source_or_credit_url': rb'https?://|www\.',
}

def relative(value):
 p=PurePosixPath(value)
 assert value and not p.is_absolute() and '..' not in p.parts and str(p)==value, 'unsafe or noncanonical relative member'
 return p

def relation(member,notice):
 m,n=relative(member),relative(notice)
 if m==n:return 'SELF'
 if n.parent==PurePosixPath('.') or n.parent in m.parents:return 'ANCESTOR_CANDIDATE'
 return 'UNRELATED_CANDIDATE'

def tags(raw):
 return [name for name,pattern in PATTERNS.items() if re.search(pattern,raw,re.I)]

def candidates(raw,document=False):
 """Reference complete comments/documents, never rewrite their licence text.

 Bytes preserve even non-UTF8 credits. A recognition miss remains an explicit
 review state; this does not classify permission or infer licence inheritance.
 """
 assert isinstance(raw,bytes)
 spans=[]
 for opening,closing in [(b'/*',b'*/'),(b'<!--',b'-->')]:
  at=0
  while True:
   start=raw.find(opening,at)
   if start<0:break
   end=raw.find(closing,start+len(opening))
   if end<0:break
   end+=len(closing);spans.append((start,end));at=end
 # Contiguous line-comment groups preserve their entire header/attribution block.
 offset=0;start=None
 for line in raw.splitlines(keepends=True):
  stripped=line.lstrip()
  comment=stripped.startswith((b'//',b'#',b';'))
  if comment and start is None:start=offset
  if not comment and start is not None:spans.append((start,offset));start=None
  offset+=len(line)
 if start is not None:spans.append((start,len(raw)))
 if document:spans=[(0,len(raw))]
 # Preserve isolated prose/reference lines outside recognized comment forms too.
 ordered=sorted(spans);at=0;offset=0
 for line in raw.splitlines(keepends=True):
  end=offset+len(line)
  while at<len(ordered) and ordered[at][1]<=offset:at+=1
  covered=at<len(ordered) and ordered[at][0]<=offset<ordered[at][1]
  if not covered and tags(line):spans.append((offset,end))
  offset=end
 out=[]
 for start,end in sorted(set(spans)):
  selected=raw[start:end];found=tags(selected)
  if not found:continue
  out.append(dict(start_byte=start,end_byte_exclusive=end,start_line=raw[:start].count(b'\n')+1,end_line=raw[:max(start,end-1)].count(b'\n')+1,sha256=hashlib.sha256(selected).hexdigest(),tags=found,complete_source_text_remains_authoritative=True,permission_determined=False))
 return out

def disposition(has_text,self_tags,ancestor_tags):
 """Triage evidence, not legal permission; no root-file-name inference."""
 if not has_text:return 'ASSET_OR_UNRETAINED_TEXT_SCOPE_OPEN'
 if 'permission_clause' in self_tags or 'licence_reference' in self_tags:return 'IN_FILE_PERMISSION_OR_LICENCE_CANDIDATE'
 if 'permission_clause' in ancestor_tags or 'licence_reference' in ancestor_tags:return 'ANCESTOR_PERMISSION_OR_LICENCE_CANDIDATE_SCOPE_OPEN'
 if 'copyright' in self_tags or 'credit' in self_tags or 'copyright' in ancestor_tags or 'credit' in ancestor_tags:return 'ATTRIBUTION_WITHOUT_RECOGNIZED_PERMISSION_CANDIDATE'
 return 'NO_RECOGNIZED_PERMISSION_CANDIDATE_REVIEW_RETAINED_TEXT'

def selected_payload(source,notices):
 """Coalesce equal self-notice references, preserving caller-owned provenance.

 A notice may be discovered both as a named ancestor notice and as the selected
 text payload. Count is not identity. Compare all same-relative candidates,
 including contradictory hashes, before choosing any retained text reference.
 """
 relative(source['relative'])
 payload=source.get('retained_text')
 def check(ref):
  assert isinstance(ref,dict), 'self notice has no retained text reference'
  assert ref['sha256']==source['sha256'] and ref['bytes']==source['bytes'], 'self notice payload identity differs'
  assert ref['retained']=='collection/notices/'+source['sha256'], 'self notice retained path differs'
 if payload is not None:check(payload)
 for notice in notices:
  if notice['relative']!=source['relative']:continue
  assert all(notice.get(k)==source.get(k) for k in ['relative','sha256','bytes','kind','status']), 'self notice source identity differs'
  ref=notice.get('retained_text');check(ref)
  if payload is None:payload=ref
  else:assert ref==payload, 'conflicting self notice retained text references'
 return payload

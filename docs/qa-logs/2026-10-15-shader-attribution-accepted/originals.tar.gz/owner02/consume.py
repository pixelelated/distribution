#!/usr/bin/env python3
"""Consume only original successful collection channels; gaps never become clearance."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent
B=runpy.run_path(str(O/'bindings.py'));B['verify'](O)
assert Path.cwd()==B['VM_TREE']
load,sha=B['load'],B['sha']
run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs'
B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k]) is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode']) is int and launch['runner_returncode']==0
for f in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/notices.exit']:assert f.read_text().strip()=='0',f
result,cleanup=load(O/'result.json'),load(O/'cleanup.json')
assert result['result']=='PASS_RETAINED_SHADER_ATTRIBUTION_WITH_OPEN_DISPOSITIONS' and result['publication_bundle_complete'] is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established'] is False
assert result['execution_error'] is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['notices_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/notices.result.json')
assert child['wait_observed'] is True and type(child['original_child_returncode']) is int and child['original_child_returncode']==0
assert child['qualification'] is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');plan=load(O/'attribution-plan.json');limits=plan['limits']
assert report['result']=='ATTRIBUTED_RETAINED_EVIDENCE_WITH_OPEN_DISPOSITIONS' and type(report['original_collector_exit']) is int and report['original_collector_exit']==0
assert report['publication_clearance'] is False and report['independent_SYSTEM_relation_established'] is False
assert report['records']==8 and report['input_selected_rows']==20018 and report['physical_observations']==18523
assert report['matched_content_observations']==18516 and report['generated_markers']==7
assert report['archives_opened'] is False and report['network_used'] is False and report['target_execution'] is False and report['source_cache_read'] is False
assert report['prior_failure_results_preserved'] is True and report['accepted_notice_admission']==plan['accepted_notice_admission']
assert report['owner_output_enforcement']==plan['owner_output_enforcement']
assert report['source_members']<=limits['source_members'] and report['candidate_ranges']<=limits['candidate_ranges']
assert report['text_members_read']<=limits['text_members'] and report['text_bytes_read']<=limits['text_read_bytes'] and report['input_bytes_read']<=limits['input_read_bytes']
assert sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=load(O/'resources.json')['owner_output_ceiling_bytes']
members=load(O/'attribution-members.json');assert len(members)==8
assert len(members)==len({m['path'] for m in members})
actual=sorted(str(p.relative_to(O)) for p in (O/'attribution').rglob('*') if p.is_file())
assert actual==sorted(m['path'] for m in members)
for member in members:
    p=O/member['path'];assert p.resolve(strict=True).is_relative_to(O/'attribution') and not p.is_symlink()
    assert sha(p)==member['sha256'] and p.stat().st_size==member['bytes']
assert cleanup['all_recorded_identities_absent'] is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped'] is False
# Same qualified final-inventory strict census and PID/start identity custody.
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']()
owned_keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']}
supervisor=cleanup['supervisor_identity'];assert supervisor is not None
owned_keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in owned_keys]
parents={r['pid'] for r in matching};descendants=[]
while parents:
    children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants]
    descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants,'recorded identity or owned descendant still present'
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[O/n for n in ['result.json','cleanup.json','collection-result.json','attribution-plan.json','preparation.json','attribution-members.json','seal.json','inner.rc','outer.rc','launcher-result.json','tool-wrapper.rc']]+[run/'runner-result.json',run/'build.rc']
files+=sorted(p for p in (O/'stage').iterdir() if p.is_file())
assert len(files)<=100 and sum(p.stat().st_size for p in files)<=64*1024**2
out=O/'admission-completion-evidence.json'
evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Only bounded analysis of already retained shader evidence qualified. Eight exact outputs are verified through attribution-members.json; header/credit candidates and source ancestry do not grant permission. Specific asset/notice questions and publication holds remain explicit; no source recollection or prior producer relabel.')
with out.open('x') as f:json.dump(evidence,f,indent=2);f.write('\n')
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed original retained-shader analysis; explicit scope/permission/publication questions retained')

#!/usr/bin/env python3
"""One bounded pass over completed retained shader evidence; no source collection."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,time,traceback,runpy

O=Path(__file__).resolve().parent
SCOPE=runpy.run_path(str(O/'scope.py'))
relative,relation,candidates,disposition,selected_payload=(SCOPE[n] for n in ['relative','relation','candidates','disposition','selected_payload'])
PLAN=json.loads((O/'attribution-plan.json').read_text());L=PLAN['limits']
RESOURCES=json.loads((O/'resources.json').read_text())
START=time.monotonic();INPUT_BYTES=0;TEXT_BYTES=0
OUTPUT_BYTES=sum(p.stat().st_size for p in O.rglob('*') if p.is_file())
INITIAL_OUTPUT_BYTES=OUTPUT_BYTES
MEMBERS=[];TEXTS={};NOTICES={};SOURCES={};PHYSICAL={};RECORDS=[];READS=[];CANDIDATE_COUNT=0

def sha(raw):return hashlib.sha256(raw).hexdigest()
def tick():assert time.monotonic()-START<L['soft_seconds'], 'analysis soft deadline exceeded'
def read_bound(path,h,size,limit):
 global INPUT_BYTES
 tick();p=Path(path)
 assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(), p
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size==size and size<=limit,p
 assert INPUT_BYTES+size<=L['input_read_bytes'],'named input read budget exceeded'
 with p.open('rb') as f:
  raw=f.read(limit+1);inside=os.fstat(f.fileno())
 after=p.lstat()
 assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(inside.st_dev,inside.st_ino,inside.st_size,inside.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),'input changed while read'
 assert len(raw)==size and sha(raw)==h,p
 INPUT_BYTES+=size;READS.append(dict(path=str(p),sha256=h,bytes=size));return raw

# Unchanged qualified before-write guard and reserve split from notice04.
def account_output(size, failure=False):
 global OUTPUT_BYTES
 assert size<=RESOURCES['per_file_bytes'], 'retained output exceeds existing per-file resource bound'
 policy=PLAN['owner_output_enforcement']
 if failure:assert size<=policy['failure_receipt_budget_bytes'], 'failure receipt exceeds its bounded reserve share'
 reserve=policy['supervisor_receipt_margin_bytes'] if failure else policy['supervisor_receipt_reserve_bytes']
 assert OUTPUT_BYTES+size<=RESOURCES['owner_output_ceiling_bytes']-reserve, 'retained owner-output budget exceeded before write'
 OUTPUT_BYTES+=size

def write(path,value):
 assert not path.exists() and not path.is_symlink(),'refuse retained output overwrite: '+str(path)
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
 account_output(len(raw),failure=path.name=='collection-failure.json')
 with path.open('xb') as f:f.write(raw)
 if path.parent==O/'attribution':MEMBERS.append(dict(path=str(path.relative_to(O)),sha256=sha(raw),bytes=len(raw)))

def content_id(value):return sha(json.dumps(value,sort_keys=True,separators=(',',':')).encode())

def text_ref(ref,document=False):
 global TEXT_BYTES,CANDIDATE_COUNT
 h=ref['sha256'];assert h in TEXT_INDEX,'not in accepted retained-text inventory'
 known=TEXT_INDEX[h];assert ref['bytes']==known['bytes'] and ref['retained']=='collection/notices/'+h
 if h not in TEXTS:
  assert len(TEXTS)<L['text_members'] and TEXT_BYTES+known['bytes']<=L['text_read_bytes']
  raw=read_bound(str(Path(PLAN['text_owner'])/known['path']),h,known['bytes'],L['text_member_bytes'])
  TEXT_BYTES+=len(raw)
  try:raw.decode('utf-8');encoding='UTF8'
  except UnicodeDecodeError:encoding='NON_UTF8_BYTES_PRESERVED_BY_REFERENCE'
  TEXTS[h]=dict(sha256=h,bytes=len(raw),retained_path=str(Path(PLAN['text_owner'])/known['path']),encoding=encoding,document=False,candidates=candidates(raw),_raw=raw)
  CANDIDATE_COUNT+=len(TEXTS[h]['candidates'])
 if document and not TEXTS[h]['document']:
  CANDIDATE_COUNT-=len(TEXTS[h]['candidates']);TEXTS[h]['document']=True;TEXTS[h]['candidates']=candidates(TEXTS[h]['_raw'],document=True);CANDIDATE_COUNT+=len(TEXTS[h]['candidates'])
 assert CANDIDATE_COUNT<=L['candidate_ranges'],'candidate range budget exceeded'
 return h

def notice_id(component,source_identity,row,original_ref):
 rel=str(relative(row['relative']));ref=row.get('retained_text');assert ref and row['sha256']==ref['sha256'] and row['bytes']==ref['bytes']
 h=text_ref(ref,document=PurePosixPath(rel).name.lower().startswith(('license','copying','notice','authors','readme')))
 value=dict(component=component,source_identity=source_identity,relative=rel,sha256=h,bytes=row['bytes'])
 n=content_id(value)
 if n not in NOTICES:NOTICES[n]=dict(value,original_source_path=row['path'],text_ref=h,retained_text_reference=ref,original_record_refs=[],scope='RELATIVE_SOURCE_LOCATION_ONLY_NOT_AUTOMATIC_LICENCE_INHERITANCE')
 else:assert NOTICES[n]['retained_text_reference']==ref, 'conflicting duplicate notice retained text references'
 NOTICES[n]['original_record_refs'].append(original_ref)
 return n

def main():
 global TEXT_INDEX
 assert set(PLAN['components'])=={'common-shaders','retropie-shaders','glsl-shaders','slang-shaders'}
 ref=PLAN['accepted_members'];inventory=json.loads(read_bound(ref['path'],ref['sha256'],ref['bytes'],L['metadata_member_bytes']))
 TEXT_INDEX={}
 for row in inventory:
  if row['path'].startswith('collection/notices/'):
   h=row['path'].split('/')[-1];assert h==row['sha256'] and len(h)==64 and h not in TEXT_INDEX;TEXT_INDEX[h]=row
 assert len(TEXT_INDEX)==7187
 # Exact metadata rows only. Paths inside original records are provenance strings,
 # never opened. Eight record JSONs are the complete fixed input allowlist.
 identities={};registry={}
 for ref in PLAN['records']:
  r=json.loads(read_bound(ref['path'],ref['sha256'],ref['bytes'],L['metadata_member_bytes']))
  assert (r['component'],r['profile'])==(ref['component'],ref['profile'])
  a=r['accepted_input'];c=a['component_row'];pin=dict(component=r['component'],recipe_sha256=c['recipe_sha256'],unpacked=c['unpacked_source']['unpacked'],archives=c['unpacked_source']['cache'])
  sid=content_id(pin)
  if r['component'] in identities:assert identities[r['component']]['id']==sid,'component pin differs between profiles'
  identities[r['component']]=dict(id=sid,identity=pin)
  registry[(r['component'],r['profile'])]=r;RECORDS.append((ref,r))
 assert len(RECORDS)==8
 input_rows=0
 for ref,r in RECORDS:
  for ordinal,f in enumerate(r['selected_files']):
   tick();input_rows+=1;assert input_rows<=L['selected_rows']
   final=f['final'];path=str(relative(final['relative']));key=(r['profile'],path)
   observation=dict(profile=r['profile'],installed_relative=path,sha256=final.get('sha256'),bytes=final.get('bytes'),mode=final.get('mode'),origin_ids=[],record_refs=[dict(record_sha256=ref['sha256'],selected_row=ordinal)])
   matches=f['matching_origins']
   if not matches:
    assert path in PLAN['generated_markers'] and final['bytes']==0 and final['sha256']==PLAN['empty_sha256'],'unexpected unmatched installed member'
    observation['disposition']='RECIPE_GENERATED_EMPTY_OVERLAY'
   else:
    assert len(matches)==1,'new installed-origin collision requires explicit review'
    origins=[v for v in f['origins'] if v['component'] in matches]
    assert len(origins)==1
    origin=origins[0];component=origin['component'];source=origin['source'];package=origin['package'];sid=identities[component]['id']
    assert all(origin[k] is True for k in ['source_byte_origin_match','source_matches_package','package_matches_final'])
    assert source['sha256']==package['sha256']==final['sha256'] and source['bytes']==package['bytes']==final['bytes']
    rel=str(relative(source['relative']));value=dict(component=component,source_identity=sid,relative=rel,sha256=source['sha256'],bytes=source['bytes'])
    source_id=content_id(value);observation['origin_ids']=[source_id]
    notices=origin.get('notice_members')
    if notices is None:notices=[r['notice_member_index'][n] for n in origin['notice_member_refs']]
    payload=selected_payload(source,notices)
    refs=[notice_id(component,sid,n,[ref['sha256'],ordinal,i]) for i,n in enumerate(notices)]
    h=text_ref(payload) if payload else None
    # A metadata-only asset remains hash-bound; never open its original path.
    node=SOURCES.setdefault(source_id,dict(value,text_ref=h,payload_text_disposition=source.get('payload_text_disposition','LEGACY_COMPLETE_TEXT_REFERENCE' if h else 'LEGACY_HASH_ONLY_ASSET_OR_TEXT'),notice_ids=set()))
    assert node['text_ref']==h
    node['notice_ids'].update(refs)
    observation['disposition']='EXACT_SOURCE_PACKAGE_STAGED_BYTE_ORIGIN'
   if key in PHYSICAL:
    previous=PHYSICAL[key]
    assert {k:v for k,v in previous.items() if k!='record_refs'}=={k:v for k,v in observation.items() if k!='record_refs'},'overlapping report disagreement'
    previous['record_refs']+=observation['record_refs']
   else:PHYSICAL[key]=observation
 assert input_rows==20018 and len(PHYSICAL)==18523
 assert len(SOURCES)<=L['source_members'] and len(NOTICES)<=L['notice_nodes']
 # Candidate parsing finished before any disposition so document upgrades are
 # consistent even when the same bytes appear in multiple components/profiles.
 exceptions=[];counts={};scope_edges=[]
 for identity,node in sorted(SOURCES.items()):
  own=TEXTS[node['text_ref']]['candidates'] if node['text_ref'] else []
  own_tags=sorted({t for c in own for t in c['tags']});ancestor_tags=set();scope_ids=[];unrelated=[]
  for nid in sorted(node['notice_ids']):
   notice=NOTICES[nid];rel=relation(node['relative'],notice['relative']);ntags=sorted({t for c in TEXTS[notice['text_ref']]['candidates'] for t in c['tags']})
   edge=dict(source_id=identity,notice_id=nid,relationship=rel,permission_inherited=False)
   scope_ids.append(len(scope_edges));scope_edges.append(edge)
   if rel=='ANCESTOR_CANDIDATE':ancestor_tags.update(ntags)
   if rel=='UNRELATED_CANDIDATE':unrelated.append(nid)
  node['notice_ids']=sorted(node['notice_ids']);node['scope_edge_ids']=scope_ids
  status=disposition(node['text_ref'] is not None,own_tags,ancestor_tags);node['disposition']=status;node['permission_determined']=False
  node['restriction_candidate']=bool('restriction_candidate' in own_tags or 'restriction_candidate' in ancestor_tags)
  counts[status]=counts.get(status,0)+1
  questions=[]
  if unrelated:questions.append('A retained candidate is not a lexical ancestor/self notice; establish its explicit cross-reference before applying it: '+','.join(unrelated))
  if node['restriction_candidate']:questions.append('Review exact restriction/exception wording and its stated scope; a keyword match is not an exclusion decision.')
  if status=='ASSET_OR_UNRETAINED_TEXT_SCOPE_OPEN':questions.append('Identify specific asset/credit permission from retained related notices; original asset bytes are hash-bound only and will not be reread.')
  elif status=='ANCESTOR_PERMISSION_OR_LICENCE_CANDIDATE_SCOPE_OPEN':questions.append('Review this exact ancestor statement for file/directory applicability; location alone does not grant permission.')
  elif status in ['ATTRIBUTION_WITHOUT_RECOGNIZED_PERMISSION_CANDIDATE','NO_RECOGNIZED_PERMISSION_CANDIDATE_REVIEW_RETAINED_TEXT']:questions.append('Review the already retained complete member and scoped notice text for an applicable grant or precise remaining permission question; no new collection is implied.')
  if questions:exceptions.append(dict(source_id=identity,component=node['component'],relative=node['relative'],sha256=node['sha256'],disposition=status,questions=questions,scope_edge_ids=scope_ids))
  else:node['review_note']='Exact in-file grant/licence candidate available; conservative full source/notice inclusion is proposed, not automatic publication clearance.'
 assert len(scope_edges)<=L['scope_edges']
 out=O/'attribution';out.mkdir()
 write(out/'source-identities.json',identities)
 write(out/'texts.json',{h:{k:v for k,v in row.items() if k!='_raw'} for h,row in sorted(TEXTS.items())})
 write(out/'notices.json',NOTICES);write(out/'sources.json',SOURCES)
 write(out/'scope-edges.json',scope_edges);write(out/'installed-observations.json',list(PHYSICAL.values()))
 write(out/'specific-review-entries.json',exceptions);write(out/'input-read-receipt.json',READS)
 write(O/'attribution-members.json',MEMBERS)
 report=dict(result='ATTRIBUTED_RETAINED_EVIDENCE_WITH_OPEN_DISPOSITIONS',original_collector_exit=0,records=8,input_selected_rows=input_rows,physical_observations=len(PHYSICAL),matched_content_observations=sum(bool(x['origin_ids']) for x in PHYSICAL.values()),generated_markers=sum(not x['origin_ids'] for x in PHYSICAL.values()),source_members=len(SOURCES),notice_nodes=len(NOTICES),text_members_read=len(TEXTS),text_bytes_read=TEXT_BYTES,input_bytes_read=INPUT_BYTES,dispositions=counts,specific_review_entries=len(exceptions),candidate_ranges=sum(len(x['candidates']) for x in TEXTS.values()),owner_output_enforcement=PLAN['owner_output_enforcement'],accounted_owner_bytes_before_report=OUTPUT_BYTES,initial_owner_bytes=INITIAL_OUTPUT_BYTES,archives_opened=False,source_cache_read=False,target_execution=False,network_used=False,publication_clearance=False,publication_bundle_complete=False,independent_SYSTEM_relation_established=False,prior_failure_results_preserved=True,accepted_notice_admission=PLAN['accepted_notice_admission'])
 assert report['matched_content_observations']==18516 and report['generated_markers']==7
 write(O/'collection-result.json',report)
 print(json.dumps(report,sort_keys=True))

if __name__=='__main__':
 try:main()
 except BaseException as e:
  write(O/'collection-failure.json',dict(result='INCOMPLETE_RETAINED_SHADER_ATTRIBUTION',error=type(e).__name__+': '+str(e),input_bytes_read=INPUT_BYTES,text_bytes_read=TEXT_BYTES,accounted_owner_bytes=OUTPUT_BYTES,source_members=len(SOURCES),physical_observations=len(PHYSICAL),publication_clearance=False))
  raise

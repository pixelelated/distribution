#!/usr/bin/env python3
"""Only missing #577 real-backend composition / disappearance / connected / forget."""
import json,shlex,time,traceback
from pathlib import Path
from common import R,command,remote,guest,write,facts,idle
B=json.loads((R/'binding.json').read_text());Q='/storage/qa-wifi-577-followup';OUT=R/'wifi-followup';assert not OUT.exists();OUT.mkdir();result={'rc':1,'started':time.time(),'cases':[]}
VISUAL='/workspace/repos/rocknix.worktrees/m7-player-setup/tools/vm-visual-qa'
def walk(name,steps,seconds=45):
 p=OUT/(name+'.steps');p.write_text(steps);return command(name,[VISUAL,'--monitor',R/'vm/monitor.sock','run',p,'--outdir',OUT/name],seconds,directory=OUT)
def state():return json.loads(remote('state','cat '+Q+'/state.json'))
def calls():
 return json.loads(guest('calls',"import json;from pathlib import Path;r=Path('"+Q+"');print(json.dumps([json.loads(p.read_text()) for p in sorted((r/'calls').glob('*.result.json'))]))"))
def log():return remote('es-log',"cat /var/log/es_log.txt")
def scan_count():return sum('wifi picker: scan completed;' in s or 'wifi picker: scan failed;' in s for s in log().splitlines())
def wait_scan(number):
 end=time.monotonic()+60
 while time.monotonic()<end:
  if scan_count()>=number:return
  time.sleep(.4)
 raise AssertionError('actual UI scan did not complete')
def restart(phase,scans,profiles=None,active=''):
 remote('stop-es','systemctl stop essway.service',60)
 old=facts_if_running()
 assert old is None
 data={'phase':phase,'profiles':profiles or [],'active_profile':active,'next_scan':0,'view':{'networks':[]}}
 remote('write-plan','cat > '+Q+'/plan.json',data=(json.dumps({'scans':scans})+'\n').encode())
 remote('write-state','cat > '+Q+'/state.json',data=(json.dumps(data)+'\n').encode())
 guest('es-log-level', """from pathlib import Path
import xml.etree.ElementTree as ET
p=Path('/storage/.config/emulationstation/es_settings.cfg')
t=ET.parse(p);r=t.getroot();assert r.tag=='config'
matches=r.findall("string[@name='LogLevel']");assert len(matches)<=1
node=matches[0] if matches else ET.SubElement(r,'string',{'name':'LogLevel'})
node.set('value','information');t.write(p,encoding='utf-8',xml_declaration=True)
assert ET.parse(p).getroot().find("string[@name='LogLevel']").get('value')=='information'
print('PASS actual ES LogLevel is information before startup')
""")
 remote('start-es','. /etc/profile >/dev/null 2>&1; set_setting system.language en_US; systemctl start essway.service',60);idle()
 ident=facts();assert ident['es_sha256']==B['members']['usr/bin/emulationstation']['sha256'];return ident
def facts_if_running():
 return remote('es-absent',"pidof emulationstation || true").strip() or None
def open_picker(label):
 n=scan_count();walk(label,'wake\nkey ret\nwait-for-change\nsettle\nkey up x6\nkey x\nwait-for-change\nsettle\nshot network-settings\nkey down x5\nkey x\nwait 1\nshot searching\n');wait_scan(n+1);walk(label+'-complete','settle\nshot picker\n')
def click_refresh(label):
 # Button center from accepted EN640 full-screen final-image frame. Sway1.11
 # seat cursor semantics are source-bound; ButtonComponent mouse click does
 # not move the keyboard cursor. No key move is inserted before fallback witness.
 n=scan_count()
 code="""import json,subprocess,os
from pathlib import Path
sockets=list(Path('/run/0-runtime-dir').glob('sway-ipc.*.sock'));assert len(sockets)==1
for action in ['set 180 455','press button1','release button1','set 0 0']:
 p=subprocess.run(['swaymsg','-s',str(sockets[0]),'-r','seat','seat0','cursor',*action.split()],capture_output=True,text=True)
 print(json.dumps({'action':action,'stdout':p.stdout,'stderr':p.stderr,'original_returncode':p.returncode}),flush=True)
 assert p.returncode==0 and all(x.get('success') for x in json.loads(p.stdout))
"""
 guest(label+'-click',code);walk(label+'-pending','wait 1\nshot pending\n');wait_scan(n+1);walk(label+'-complete','settle\nshot complete\n')
def subset(phase):return sorted([r for r in calls() if r['phase']==phase],key=lambda r:r['started'])
def assert_same(before):assert facts()==before,'same actual frontend/boot required within flow'
try:
 ident=restart('backend-disappearance',[{'networks':['QA network 01','QA network 02','QA network 03']},{'networks':['DISCARD FAILED PARTIAL'],'rc':8},{'networks':['QA network 01','QA network 02']}])
 open_picker('backend-initial');walk('select-disappearing','key down x2\nsettle\nshot selected-third\n')
 click_refresh('backend-failure');rows=subset('backend-disappearance');scans=[r for r in rows if r['args'][0] in ['list','scanlist']];assert [r['original_returncode'] for r in scans]==[0,8]
 # Explicit backend-failure trace plus image review distinguishes retained rows.
 text=log();assert 'wifi picker: scan failed; rows=3; retained=1' in text
 failed=next(r for r in scans if r['original_returncode']==8)
 assert remote('failed-stdout','cat '+Q+'/calls/'+failed['id']+'.stdout')=='','real backend must discard partial lower output'
 click_refresh('disappearance-retry');walk('fallback-action','key x\nwait 1\nsettle\nshot fallback-key-editor\n')
 end=time.monotonic()+10
 while not any(r['args']==['security','QA network 02'] for r in subset('backend-disappearance')):
  assert time.monotonic()<end;time.sleep(.25)
 rows=subset('backend-disappearance');assert [r['original_returncode'] for r in rows if r['args'][0] in ['list','scanlist']]==[0,8,0]
 assert [r['args'] for r in rows if r['args'][0]=='security']==[['security','QA network 02']]
 walk('fallback-cancel','key esc\nwait-for-change\nsettle\nshot picker-return\nkey z\nwait-for-change\nsettle\nshot network-return\n');assert_same(ident)
 result['cases'].append({'name':'real-backend-failure-retry-and-disappearance','identity':ident,'scan_original_rcs':[0,8,0],'selected_fallback':'QA network 02','scope':'actual installed wifictl child; synthetic adapter/iwctl/nmcli, natural sleeps; actual installed ES selection witness'})
 profiles=[{'name':'Home profile','ssid':'Home Wi-Fi'},{'name':'Cafe profile A','ssid':'Cafe Wi-Fi'},{'name':'Cafe profile B','ssid':'Cafe Wi-Fi'}]
 ident=restart('connected-forget',[{'networks':['Home Wi-Fi','Cafe Wi-Fi']} for _ in range(3)],profiles,'Home profile');open_picker('connected')
 walk('connected-action','key x\nwait 2\nsettle\nshot connected-return\n');rows=subset('connected-forget');joins=[r for r in rows if r['args'][0]=='join'];assert len(joins)==1 and joins[0]['args']==['join','Home profile'] and joins[0]['original_returncode']==0
 assert state()['active_profile']=='Home profile';assert remote('joined-output','cat '+Q+'/calls/'+joins[0]['id']+'.stdout')=='joined\n'
 # Reopen the picker from its unchanged NETWORK SETTINGS row.
 n=scan_count();walk('forget-open','key down x5\nkey x\nwait 1\nshot searching\n');wait_scan(n+1)
 walk('forget-confirmation-back','settle\nkey down\nkey x\nwait-for-change\nsettle\nshot profile-choice\nkey x\nwait-for-change\nsettle\nshot saved-choice\nkey right\nkey x\nwait-for-change\nsettle\nshot forget-confirmation\nkey z\nwait-for-change\nsettle\nshot cancelled\n',60)
 assert state()['profiles']==profiles and not state().get('deletions');assert not [r for r in subset('connected-forget') if r['args'][0]=='forget']
 n=scan_count();walk('forget-accept','key x\nwait-for-change\nsettle\nkey x\nwait-for-change\nsettle\nkey right\nkey x\nwait-for-change\nsettle\nshot final-confirmation\nkey x\nwait 1\nshot deletion-pending\n',60);wait_scan(n+1);walk('forgotten','settle\nshot sibling-preserved\n')
 rows=subset('connected-forget');forgets=[r for r in rows if r['args'][0]=='forget'];assert len(forgets)==1 and forgets[0]['args']==['forget','Cafe profile A'] and forgets[0]['original_returncode']==0
 final=state();assert final['profiles']==[profiles[0],profiles[2]] and final['active_profile']=='Home profile' and final['deletions']==['Cafe profile A']
 assert remote('forgotten-output','cat '+Q+'/calls/'+forgets[0]['id']+'.stdout')=='forgotten\n'
 assert [r['original_returncode'] for r in rows if r['args'][0] in ['list','scanlist']]==[0,0,0]
 assert_same(ident);result['cases'].append({'name':'connected-profile-and-forget-back-confirm','identity':ident,'joined_profile':'Home profile','forgotten_profile':'Cafe profile A','sibling_preserved':'Cafe profile B','original_join_rc':0,'original_forget_rc':0,'all_synthetic':True})
 walk('normal-return','key z\nwait-for-change\nsettle\nkey z\nwait-for-change\nsettle\nshot frontend-return\n');idle();result['rc']=0
except BaseException as e:result['error']=type(e).__name__+': '+str(e);traceback.print_exc()
finally:
 try:write(OUT/'backend-result-readback.json',calls());(OUT/'es-log.txt').write_text(log())
 except BaseException as e:result['readback_error']=str(e);result['rc']=1
 result['ended']=time.time();write(OUT/'result.json',result)
raise SystemExit(result['rc'])

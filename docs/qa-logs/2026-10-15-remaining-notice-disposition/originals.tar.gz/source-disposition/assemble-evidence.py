"""Retain selected existing evidence for source review; never inspect build directories."""
from pathlib import Path
import json,hashlib,shutil,subprocess,collections
D=Path('/tmp/pix-m7-remaining-notice-disposition-20261015');O=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-04');C=Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
rows=json.loads((D/'retained-record-summary.json').read_text())['records'];prefix=json.loads((D/'prefix-assessment.json').read_text());idx={};refs=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def retain(p,reason,expected=None):
 h=sha(p);assert expected is None or h==expected
 dest=D/'evidence'/h;dest.parent.mkdir(exist_ok=True)
 if not dest.exists():shutil.copy2(p,dest)
 s=p.stat();r={'original_path':str(p),'sha256':h,'bytes':s.st_size,'mode':s.st_mode&0o7777,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'retained':str(dest.relative_to(D)),'reason':reason};refs.append(r);return r
for r in rows:
 for x in r['notice_rebindings']:
  q=x.get('current') or {};rt=q.get('retained_text')
  if rt:retain(O/rt['retained'],r['component']+':'+r['profile']+':'+q['relative'],rt['sha256'])
 for x in r['source_semantics']:
  q=x.get('original') or {};rt=q.get('retained_text')
  if rt:retain(O/rt['retained'],r['component']+':source semantics:'+q['relative'],rt['sha256'])
 for x in r['build_selection']:
  wanted=(r['component']=='harfbuzz-icu' and x['pattern'] in ['meson-info/intro-targets.json','meson-info/intro-installed.json','meson-info/intro-buildoptions.json']) or (r['component']=='wildmidi' and x['pattern'] in ['CMakeCache.txt','install_manifest.txt','compile_commands.json'])
  q=x.get('original') or {};rt=q.get('retained_text')
  if wanted and rt:retain(O/rt['retained'],r['component']+':'+r['profile']+':generated:'+q['relative'],rt['sha256'])
for r in prefix:
 named=[]
 for n in r.pop('ancestor_notices'):
  rel=n.get('relative','');rt=n.get('retained_text')
  if Path(rel).name.lower() not in ['license','license.txt','copying','readme.md','readme']:continue
  named.append(n)
  if rt:retain(O/rt['retained'],r['component']+':'+r['profile']+':scoped candidate:'+rel,rt['sha256'])
 r['named_notice_candidates']=named
(D/'prefix-assessment.json').write_text(json.dumps(prefix,indent=2)+'\n')
for p in [Path('/tmp/pix-m7-source-notice-root-review-20261015/issue528-before.json'),Path('/tmp/pix-m7-notice-followup-20261015/references/licence-basis-corrected.json'),Path('/tmp/pix-m7-notice-followup-20261015/references/engineering-dispositions.json'),Path('/tmp/pix-m7-notice-followup-20261015/references/shader-archive-review.json'),O/'collection-result.json',O/'resume.json',C/'docs/qa-logs/2026-10-15-notice-supplement/accepted/SHA256SUMS']:
 retain(p,'Existing current-status/prior-disposition/accepted-custody binding')
gitrows=[]
paths={r['selected_identity']['recipe'] for r in rows if r.get('selected_identity')};paths.add('projects/ROCKNIX/packages/emulators/libretro/retroarch/package.mk');paths.update(['projects/ROCKNIX/packages/emulators/standalone/openbor/config/Saves/default.cfg','projects/ROCKNIX/packages/emulators/standalone/openbor/config/master.cfg'])
# Actual named frozen tracked blobs only. No cache traversal and no guessed installed association.
for path in sorted(paths):
 b=subprocess.run(['git','-C',str(C),'show','f8636de1d105275dbf9420bbabbbc26f79abb10f:'+path],capture_output=True,check=True).stdout
 h=hashlib.sha256(b).hexdigest();dest=D/'tracked-source'/h;dest.parent.mkdir(exist_ok=True);dest.write_bytes(b)
 gitrows.append({'source_commit':'f8636de1d105275dbf9420bbabbbc26f79abb10f','path':path,'sha256':h,'bytes':len(b),'retained':str(dest.relative_to(D)),'original_command_exit':0})
(D/'evidence-index.json').write_text(json.dumps({'retained_files':refs,'frozen_git_blobs':gitrows,'scope':'Exact already retained source/notice/generated metadata plus named frozen tracked blobs; historical records remain unchanged. No collector/test/target/network/cache scan.'},indent=2)+'\n')
# Derive selected metadata interpretations while retaining full original files by hash above.
facts=[]
for r in rows:
 if r['component']=='harfbuzz-icu':
  def read(pat):
   q=next(x['original'] for x in r['build_selection'] if x['pattern']==pat and x.get('original'));return json.loads((O/q['retained_text']['retained']).read_text()),q['sha256']
  ts,th=read('meson-info/intro-targets.json');opts,oh=read('meson-info/intro-buildoptions.json');ins,ih=read('meson-info/intro-installed.json')
  facts.append({'component':r['component'],'profile':r['profile'],'targets_sha256':th,'icu_targets':[t for t in ts if t['name']=='harfbuzz-icu'],'options_sha256':oh,'options':{x['name']:x['value'] for x in opts if x['name'] in ['icu','tests','icu_builtin','docs','utilities']},'installed_metadata_sha256':ih,'selected_install_map':{k:v for k,v in ins.items() if 'libharfbuzz-icu' in k},'historical_build_path_literals_preserved':True})
 if r['component']=='wildmidi':facts.append({'component':r['component'],'profile':r['profile'],'effective_cache_observations':r['effective_cache_observations'],'selected_files':r['selected_files']})
(D/'generated-selection-facts.json').write_text(json.dumps({'facts':facts,'scope':'Actual retained generated metadata: inherited old build-directory strings remain literal, not relabeled current invocations. Current selected package/staged byte identity is separately retained.'},indent=2)+'\n')
print(json.dumps({'logical_refs':len(refs),'unique_evidence_files':len(list((D/'evidence').iterdir())),'evidence_bytes':sum(p.stat().st_size for p in (D/'evidence').iterdir()),'tracked_blobs':len(gitrows),'generated_facts':len(facts)},indent=2))

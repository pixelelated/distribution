from pathlib import Path
import json,hashlib,collections,shutil
O=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-04');D=Path('/tmp/pix-m7-remaining-notice-disposition-20261015')
r=json.loads((O/'resume.json').read_text());entries={(x['component'],x['profile']):(Path(x['path']),x['sha256']) for x in r['completed']}
for p in (O/'collection').glob('*.json'):
 if p.name=='extra-records.json':continue
 a=json.loads(p.read_text());entries[(a['component'],a['profile'])]=(p,hashlib.sha256(p.read_bytes()).hexdigest())
skip={'enet','libspeexdsp','libxmp-lite','opusfile'};result=[]
def small(x):
 if not x:return x
 return {k:x[k] for k in ['path','relative','status','kind','sha256','bytes','link_target','retained_text'] if k in x}
for (component,profile),(p,h) in sorted(entries.items()):
 if component in skip:continue
 raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==h;a=json.loads(raw)
 row={'component':component,'profile':profile,'record':{'path':str(p),'sha256':h,'bytes':len(raw)},'status':a['status'],'selected_identity':a.get('accepted_input',{}).get('component_row'), 'notice_rebindings':[{'status':x.get('status'),'current':small(x.get('current')),'historical_sha256':x.get('historical',{}).get('sha256')} for x in a.get('notice_rebindings',[])],'build_selection':[{k:(small(v) if k=='original' else v) for k,v in x.items() if k in ['pattern','role','original','status']} for x in a.get('build_selection',[])],'source_semantics':[{k:(small(v) if k=='original' else v) for k,v in x.items() if k in ['pattern','role','original','status']} for x in a.get('source_semantics',[])],'effective_cache_observations':a.get('effective_cache_observations'),'shared_source_parents':[{k:v for k,v in x.items() if k!='identity'} for x in a.get('shared_source_parents',[])],'unresolved':a.get('unresolved')}
 fs=a.get('selected_files',[]);row['selected_file_count']=len(fs);row['selected_file_schema']=list(fs[0]) if fs else []
 if len(fs)<50:row['selected_files']=[{k:small(v) if k in ['package','staged_image','source'] else v for k,v in x.items() if k not in ['relation']} for x in fs]
 row['top_keys']=list(a)
 row['notice_member_index_count']=len(a.get('notice_member_index',{}))
 if len(fs)>50:
  row['selected_file_example']={k:v for k,v in fs[0].items() if k not in ['origins','package','staged_image']}
  row['direct_matches']=dict(collections.Counter(str(x.get('package_matches_staged')) for x in fs))
  row['origins_example']=fs[0].get('origins')
 result.append(row)
(D/'retained-record-summary.json').write_text(json.dumps({'records':result,'scope':'Derived summaries from29 accepted existing occurrence records only; no cache/source enumeration or new collection.'},indent=2)+'\n')
for x in result:
 print(x['component'],x['profile'],'files',x['selected_file_count'],'notice',len(x['notice_rebindings']),'build',[(t['pattern'],t.get('original',{}).get('relative'),t.get('status'),t.get('original',{}).get('sha256','')[:10]) for t in x['build_selection'] if t.get('original')],'effective',x['effective_cache_observations'])
print('recordcount',len(result))

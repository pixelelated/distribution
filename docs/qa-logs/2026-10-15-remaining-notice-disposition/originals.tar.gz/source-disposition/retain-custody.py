"""Preserve the scoped source-only disposition; no collector or target execution."""
from pathlib import Path
import hashlib,json,stat,tarfile,gzip,decimal,datetime,shutil
S=Path('/tmp/pix-m7-remaining-notice-disposition-20261015')
D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-remaining-notice-disposition')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
idx=load(S/'evidence-index.json')
for r in idx['retained_files']+idx['frozen_git_blobs']:
 p=S/r['retained'];assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
for n in ['zerotier-named-source.json','zerotier-header-source.json']:
 for r in load(S/n)['files']:
  p=S/r['retained'];assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
assert len(load(S/'record-custody.json')['records'])==29
assert not (S/'SHA256SUMS').exists()
files=sorted(p for p in S.rglob('*') if p.is_file());(S/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(S))+'\n' for p in files))
for line in (S/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(S/n)==h
assert not D.exists();D.mkdir(parents=True)
rows=[];pairs=[]
for p in [S,*sorted(S.rglob('*'))]:
 assert not p.is_symlink() and (p.is_file() or p.is_dir());s=p.stat();name='source-disposition'+('/'+str(p.relative_to(S)) if p!=S else '')
 row={'member':name,'original_path':str(p),'kind':'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None};rows.append(row);pairs.append((p,name,row))
archive=D/'originals.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for p,name,row in pairs:
    m=t.gettarinfo(str(p),arcname=name);m.pax_headers={'mtime':str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(10**9))};row['uname']=m.uname;row['gname']=m.gname
    if p.is_file():
     with p.open('rb') as src:t.addfile(m,src)
    else:t.addfile(m)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  assert m.name.rstrip('/')==r['member'] and m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'] and m.uname==r['uname'] and m.gname==r['gname']
  assert int(decimal.Decimal(m.pax_headers['mtime'])*decimal.Decimal(10**9))==r['mtime_ns']
  if r['kind']=='file':assert m.isfile() and m.size==r['bytes'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']==sha(Path(r['original_path']))
  else:assert m.isdir()
dump(D/'members.json',{'archive_sha256':sha(archive),'members':rows,'files':sum(r['kind']=='file' for r in rows),'directories':sum(r['kind']=='directory' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)})
for n in ['decision-table.md','zerotier-source-selection.md']:shutil.copy2(S/n,D/n);assert sha(S/n)==sha(D/n)
(D/'README.md').write_text('''# #528 remaining current notice dispositions

Read [decision-table.md](decision-table.md) for the12-component/29-occurrence proposal and [zerotier-source-selection.md](zerotier-source-selection.md) for the exact default-switch trace. The separate four-library disposition was already accepted. This packet is source/evidence review, not whole-release notice or permission clearance, product-removal authority, or a new test/inventory run. Parent owns acceptance/integration and later allocation.

originals.tar.gz preserves the complete private proposal, exact copied retained notices/generated metadata, named frozen Git blobs and nine explicitly named ZeroTier source/header reads. members.json verifies all archive bytes, modes, owners and nanosecond mtimes against the immutable private packet. Its internal evidence indices retain original source paths/metadata and exact prior-custody references for all29 occurrence records; large historical record JSONs are not duplicated. All24 historical plus5 accepted04 records remain attributed to their original producers.

Concrete resolved facts include HarfBuzz library versus test-font scope, actual WildMIDI player/library selection, conservative OpenBOR notices, database selected data/attribution, shader installed origins and GLSL crt-royale's generic missing-relative-member report. ZeroTier's declared ordinary default excludes controller implementation objects; absent historical flags alone is not a blocker. The distinct remaining source-publication question concerns included nonfree header declarations and current terms, not a guessed active controller. Exact FreeJ2ME bundled notices, remaining scoped shader/asset attribution, Doom terms and ABL implementation/access remain as specified in the table.

No collector, inventory replay, test, service, VM, target-binary read/execution, source-archive fetch/open, cache directory traversal, external model/network call, product change, tracker mutation or shared canonical edit occurred. Source inspection errors and original statuses are retained candidly inside source-observations.json. Source/notice bundle materialization, actual delivery, independent retrieval and off-host custody remain existing #528 work; no new blanket flag/reproducibility gate was introduced.
''')
dump(D/'custody-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_CUSTODY_SOURCE_ONLY_DISPOSITION_PROPOSAL','source_seal':sha(S/'SHA256SUMS'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'decision_table_sha256':sha(S/'decision-table.md'),'zerotier_source_selection_sha256':sha(S/'zerotier-source-selection.md'),'referenced_occurrence_records':29,'new_runtime_or_tests':False,'publication_clearance':False})
files=sorted(p for p in D.iterdir() if p.is_file());(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
for line in (D/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(D/n)==h
print(json.dumps({'directory':str(D),'seal':sha(D/'SHA256SUMS'),'source_seal':sha(S/'SHA256SUMS'),'archive':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'table_sha256':sha(S/'decision-table.md')},indent=2))

from pathlib import Path
import subprocess,json,struct,hashlib,time,shutil
owner=Path('/workspace/tmp/pix-m7-retained20-20261014-01')
out=Path('/workspace/tmp/pix-m7-retained20-evidence-20261014-01/disk-readback')
assert Path('/proc/self/ns/pid').stat().st_ino==4026531836
assert not Path('/proc',str(json.loads((owner/'qemu.json').read_text())['pid'])).exists()
out.mkdir(mode=0o700)
disk=owner/'vm/disk.qcow2';cmds=[]
def run(args,name,timeout=30):
 t=time.time();r=subprocess.run(args,capture_output=True,timeout=timeout)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 cmds.append({'argv':args,'rc':r.returncode,'seconds':time.time()-t});assert r.returncode==0
 return r.stdout
run(['qemu-img','dd','-f','qcow2','bs=512','count=128','if='+str(disk),'of='+str(out/'head.bin')],'header')
b=(out/'head.bin').read_bytes();assert b[512:520]==b'EFI PART'
lba,n,size=struct.unpack_from('<QII',b,584);assert size==128 and n<=128
parts=[]
for i in range(n):
 e=b[lba*512+i*size:lba*512+(i+1)*size]
 if not any(e[:16]):continue
 start,end=struct.unpack_from('<QQ',e,32);parts.append({'start':start,'end':end,'name':e[56:].decode('utf-16-le').rstrip('\0')})
assert len(parts)==2
p=parts[1];raw=owner/'vm/diagnostic-storage.ext4';assert not raw.exists()
opts='driver=raw,offset='+str(p['start']*512)+',size='+str((p['end']-p['start']+1)*512)+',file.driver=qcow2,file.file.filename='+str(disk)
run(['qemu-img','convert','--image-opts','-O','raw','-S','4096','-m','1',opts,str(raw)],'storage',90)
conf=run(['/usr/sbin/debugfs','-R','cat /.config/cloud_sync.conf',str(raw)],'cloud-config')
assert 0<len(conf)<1024*1024
for name,request in [('receipts','ls -l /.cache/pixelelated-installed-state-m7-retained-20261014-01'),('backups','ls -l /roms/backup')]:
 run(['/usr/sbin/debugfs','-R',request,str(raw)],name)
shipped=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-01/build.pixelelated-GENERIC_X64.x86_64/image/system/usr/config/cloud_sync.conf').read_bytes()
result={'commands':cmds,'partitions':parts,'config_sha256':hashlib.sha256(conf).hexdigest(),'config_bytes':len(conf),'continuations':conf.count(b'\\\n'),'equal_to_shipped':conf==shipped,'shipped_sha256':hashlib.sha256(shipped).hexdigest(),'source_disk_unchanged':True,'temporary_storage_allocated':raw.stat().st_blocks*512}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copy2(__file__,out/'source.py')
raw.unlink();print(json.dumps({k:v for k,v in result.items() if k not in ['commands','partitions']}))

#!/bin/bash
# SOURCE ONLY / UNRUN. Root reviews exact seal, allocates, and supervises each action.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-fex-held-source-custody-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-fex-held-source-custody-20261015-01}
TASK_GUARD_REPORT=${TASK_GUARD_REPORT:-/workspace/tmp/pix-m7-fex-held-source-guards-20261015-01.json}
cd "$TASK_TREE"
case "${1:?guards, prepare, preflight, report, admit, launch, or consume}" in
 guards) tools/watch-build --record-only -- timeout --signal=TERM --kill-after=5s 30s /usr/bin/python3.14 -I -S -B "$TASK_PACKET/guard-controls.py" --output "${TASK_GUARD_REPORT:?fresh guard report}" ;;
 prepare) tools/watch-build --record-only -- /usr/bin/python3.14 -I -S -B "$TASK_PACKET/prepare-owner.py" --owner "$TASK_OWNER" --guard-report "$TASK_GUARD_REPORT" --guard-run "${TASK_GUARD_RUN:?original watched guard run}" ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json" ;;
 admit) python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json" ;;
 launch) env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh" ;;
 consume) python3 -I "$TASK_OWNER/consume.py" ;;
 *) exit 2 ;;
esac
# Submission is not completion. Root checks originals and host PID/start identities
# at most60seconds apart; no disconnected notification is armed by this packet.
# Failures require ordinary failed-investigated consumption, never this success consumer.

# Held FEX phase-B source custody — source only, unrun

This packet prepares retention of the already-held Nixpkgs tree and twenty named patches. It references the accepted libglvnd source reuse and leaves the two normalized patches separate. The collector, guards, and preparer remain unrun. The Nixpkgs tree and twenty patch payloads have not been collected; preparation read only named receipts and normalization metadata.

The exact Nixpkgs pin is `b6018f87da91d19d0ab4cf979885689b469cdd41`. The single allowed source tree is `/workspace/tmp/pix-m7-sm8550-refresh-20261015-02/nix/store/4k79ns9drp02wyvcix81c7nnz4hn8psi-source`. Its frozen database records a **195,961,000-byte canonical NAR** with SHA-256 **`b705cf16a16caeb639af6f1987b1e89a0729da050c06043a5834bdf10ff7c452`**. The collector must reproduce both values before reporting success. This hash describes the complete normalized filesystem tree, not a compressed HTTP archive.

`templates/nar.py` implements the [Nix archive framing](https://nix.dev/manual/nix/2.24/protocols/nix-archive): little-endian length prefixes, eight-byte padding, directory entries sorted by raw filename bytes, regular contents with the owner executable bit, and raw symlink targets. It opens members relative to held directory descriptors with `O_NOFOLLOW`, checks descriptor/path identities before and after, refuses special files, and rechecks directory membership. Symlinks are serialized as data. No source is executed or followed outside the named tree. Content streams through bounded chunks; neither the whole tree nor the NAR is held in memory. The complete written NAR is independently rehashed from disk.

`collection-plan.json` contains all twenty exact patch paths, complete SHA-256 hashes, byte lengths, modes, and accepted file identities. Their total is **1,959,776 bytes**. Each patch is rehashed before copying, copied to `patches/<sha256>.patch`, rehashed there, and rechecked at its original path. The source mode and identity remain in the manifest; custody files are private data. No other Nix store path or compiler closure is enumerated.

Libglvnd is reused from historical archive SHA-256 `073e7292788d4d3eeb45ea6c7bdcce9bfdb3b3eef8d7dbd47f2f30dce046ef98`. Root's accepted watcher `20261015T143521Z-7d559a90` recorded all original channels zero. Its independent data-only probe produced the expected NAR SHA-256 `d94f49b691b23f895bc6d54978fe465208795ed865a0fbc5230dbcfa795d631f`, 6,669,360 NAR bytes and 292 nodes. The exact probe and root acceptance are bound; the archive is not downloaded or copied again.

The default future owner is `/workspace/tmp/pix-m7-fex-held-source-custody-20261015-01`. The fresh custody destination is `/workspace/artifacts/pixelelated-release-sources/m7-fex-held-source-20261015-01`. Both remain uncreated. Success retains one NAR, twenty patch files and one compact manifest: 22 custody files. The manifest records full source identities, accepted libglvnd reuse, and the two remaining inputs; it does not create another package inventory.

Bounds are enforced before writes: **384 MiB custody + 64 MiB owner = 448 MiB combined**, under a 1 GiB retention reservation. The owner preserves a 16 MiB normal receipt reserve; the collector's failure receipt is at most 1 MiB and can still be written after a read/time refusal. The unchanged supervisor caps its receipts at 8 MiB and child logs at 256 KiB each. The NAR sink refuses bytes beyond the exact 195,961,000-byte target. General per-file and outer `RLIMIT_FSIZE` are 192 MiB; patch files are at most 4 MiB each / 8 MiB aggregate. The observed 1,925,063-byte glibc patch fits these bounds.

The finite source-tree limits are one root, 200,000 nodes, depth 64, 4,096-byte paths, 32 MiB per regular source member and 16 MiB aggregate filename bytes. Streamed collector reads are capped at 1 GiB, sufficient for the approximately 196 MiB source representation, two complete custody NAR readbacks, and bounded patch/receipt reads. Destination limits are 128 files / 8 directories. The collector starts no child processes. The existing supervisor starts one collector and retains its original wait and PID/start identity. Runtime limits are two CPUs, 2 GiB address space, a 280-second collector soft deadline, 300-second supervised child deadline, and 330+15-second outer timeout. Any exceeded bound stops and preserves partial custody for ordinary failure consumption; no automatic widening or retry.

The accepted additive03 supervisor and process-identity helper are reused. Supervisor function bodies are unchanged; edits select the Python identity, scope and success checks. Preparation adds the original watched guard binding and exact host Python byte identity. The consumer retains the existing original-channel, cleanup, process-custody and admission checks, with exact NAR/patch readback checks replacing additive membership checks. `source-provenance.json` and `changes.diff` record these edits. Thirty focused memory-only controls are prepared for NAR framing, unsafe names/special types, exact size ceilings and receipt reserves, including failure after deadline. **They have not run.** Full-tree correctness additionally requires the independently known NAR digest and size.

The two remaining patch outputs are explicit:

| Normalized output | Required flat SHA-256 |
| --- | --- |
| libglvnd large-file patch | `63a602cddfe36755593fd6c59479078f34b04a15de03b88959dc9fc69813da5d` |
| xorgproto meson patch | `233cf3f489f9dd6ec20befa4d5b2ebefc892ae6c69166d5c1fca9c4a9a6da144` |

`patchutils-normalization-disposition.json` records the exact raw URLs and normalization pipeline. The recorded normalizer is patchutils 0.3.3 plus `drop-comments.patch`; `--clean` removes unified hunk comments. Neither the recorded Nix tools nor host patchutils are installed. The cached Ubuntu package index supplies patchutils 0.4.3-1ubuntu1 amd64, **82,352 bytes**, SHA-256 **`241c8bed2c24bbf6b46a818278e3200f1dd99465815b3d7ec9de708552af0ba4`**, matching the version on the [official Ubuntu package page](https://packages.ubuntu.com/resolute/patchutils). It is only a candidate substitute. A separately reviewed package acquisition/data inspection could identify the tools without installation; any later normalization must match both known output hashes exactly. No package was acquired, installed, or executed. No equivalence is inferred from a version label. Raw HTTP hashes remain distinct from normalized output hashes.

Static preparation used named existing receipts, bounded host package metadata and official text pages only. It did not read the held Nixpkgs tree recursively or reread the twenty patch payloads. Notice aggregation, independent retrieval, offhost custody, and publication clearance remain separate; this does not create a full compiler-closure gate.

Root reviews and allocates each separate step, retaining original receipts:

```bash
bash /tmp/pix-m7-fex-held-source-custody-20261015/commands.sh guards
# Export TASK_GUARD_RUN from the successful original watched guard run.
bash /tmp/pix-m7-fex-held-source-custody-20261015/commands.sh prepare
bash /tmp/pix-m7-fex-held-source-custody-20261015/commands.sh preflight
bash /tmp/pix-m7-fex-held-source-custody-20261015/commands.sh report
bash /tmp/pix-m7-fex-held-source-custody-20261015/commands.sh admit
bash /tmp/pix-m7-fex-held-source-custody-20261015/commands.sh launch
# Root actively supervises at intervals no longer than 60 seconds.
# Only after all original success channels and independent custody review:
bash /tmp/pix-m7-fex-held-source-custody-20261015/commands.sh consume
```

Never rerun a used owner, overwrite partial source custody, or use the success-only consumer for a failed run. Released source packets and previous run outcomes stay immutable.

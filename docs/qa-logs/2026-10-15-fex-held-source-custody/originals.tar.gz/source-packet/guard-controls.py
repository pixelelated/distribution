#!/usr/bin/env python3
"""Focused memory-only guards. Candidate imports/main and production reads are forbidden."""
from pathlib import Path,PurePosixPath
import argparse,ast,hashlib,io,json,os,re,stat
P=Path(__file__).resolve().parent
def extracted(path,names,ns):
    tree=ast.parse(path.read_bytes());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
    assert {n.name for n in nodes}==set(names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'memory-only-selected-guards','exec'),ns)
    return ns
nar=extracted(P/'templates/nar.py',['u64','frame','node_header','entry_header','kind_of'],{'stat':stat})
ns=extracted(P/'templates/collect.py',['root_for','reserve','safe','NarSink'],{'PurePosixPath':PurePosixPath,'os':os,'hashlib':hashlib})
rows=[]
def case(name,fn,refuse=False):
    try:fn()
    except AssertionError:
        assert refuse,name;rows.append(dict(case=name,result='PASS_EXPECTED_REFUSAL'))
    else:
        assert not refuse,name;rows.append(dict(case=name,result='PASS'))
def equal(a,b):assert a==b,(a,b)
case('nar-empty-string-vector',lambda:equal(nar['frame'](b''),bytes(8)))
case('nar-one-byte-string-padding-vector',lambda:equal(nar['frame'](b'a'),b'\x01'+bytes(7)+b'a'+bytes(7)))
case('nar-aligned-content-no-extra-padding',lambda:equal(nar['frame'](b'12345678'),b'\x08'+bytes(7)+b'12345678'))
case('nar-negative-size-refused',lambda:nar['u64'](-1),True)
case('nar-overflow-size-refused',lambda:nar['u64'](2**64),True)
case('nar-boolean-size-refused',lambda:nar['u64'](True),True)
case('nar-raw-nonutf8-name-preserved',lambda:equal(nar['entry_header'](b'\xff')[-16:],nar['frame'](b'node')))
for name,value in [('parent',b'..'),('dot',b'.'),('slash',b'a/b'),('nul',b'a\0b'),('empty',b''),('long',b'a'*4097)]:
    case('nar-entry-'+name+'-refused',lambda value=value:nar['entry_header'](value),True)
case('nar-special-file-refused',lambda:nar['kind_of'](stat.S_IFIFO|0o600),True)
case('nar-directory-executable-marker-refused',lambda:nar['node_header']('directory',True),True)
case('nar-regular-executable-marker-distinguished',lambda:equal(len(nar['node_header']('regular',True))-len(nar['node_header']('regular',False)),32))
O=Path('/memory-owner');D=Path('/memory-custody');target=D/'member';failure=O/'collection-failure.json'
def setup():
    ns.update(O=O,D=D,WRITES={str(target):0,str(failure):0},OUTPUT={str(O):0,str(D):0},R={'custody_output_ceiling_bytes':100,'owner_output_ceiling_bytes':80,'supervisor_reserve_bytes':16,'failure_receipt_budget_bytes':8,'per_file_bytes':100,'path_bytes':4096},tick=lambda:None)
setup();case('destination-exact-before-write-boundary',lambda:ns['reserve'](target,100))
case('destination-overflow-before-write-refused',lambda:ns['reserve'](target,1),True);assert ns['OUTPUT'][str(D)]==100
setup();case('owner-normal-reserve-preserved',lambda:ns['reserve'](failure,64))
case('owner-normal-cannot-use-receipt-reserve',lambda:ns['reserve'](failure,1),True)
case('bounded-failure-uses-assigned-reserve',lambda:ns['reserve'](failure,8,True));assert ns['OUTPUT'][str(O)]==72
case('failure-reserve-overflow-refused',lambda:ns['reserve'](failure,1,True),True)
setup()
def expired():raise AssertionError('deadline')
ns['tick']=expired
case('normal-output-refuses-after-deadline',lambda:ns['reserve'](target,1),True)
case('failure-receipt-still-accounted-after-deadline',lambda:ns['reserve'](failure,8,True))
case('outside-owned-root-refuses',lambda:ns['root_for'](Path('/other/member')),True)
for name,value in [('parent','../x'),('absolute','/x'),('empty','')]:case('output-'+name+'-refuses',lambda value=value:ns['safe'](value),True)
ns['PLAN']={'nixpkgs':{'database_nar_size':3}};out=io.BytesIO();sink=ns['NarSink'](out)
case('nar-sink-exact-size-boundary',lambda:sink.write(b'abc'))
case('nar-sink-overflow-refuses-before-output',lambda:sink.write(b'd'),True);assert out.getvalue()==b'abc' and sink.bytes==3
report=dict(result='PASS_HELD_SOURCE_GUARDS',cases=rows,collector_sha256=hashlib.sha256((P/'templates/collect.py').read_bytes()).hexdigest(),nar_source_sha256=hashlib.sha256((P/'templates/nar.py').read_bytes()).hexdigest(),guard_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),network_used=False,production_sources_read=False,candidate_imported_or_main_executed=False,filesystem_writes_except_receipt=False)
q=argparse.ArgumentParser(description=__doc__);q.add_argument('--output',type=Path,required=True);a=q.parse_args()
assert a.output.parent==Path('/workspace/tmp') and a.output.parent.resolve(strict=True)==a.output.parent and re.fullmatch(r'pix-m7-fex-held-source-guards-20261015-[0-9]{2}\.json',a.output.name)
assert not a.output.exists() and not a.output.is_symlink();raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode();assert len(raw)<=256*1024
with a.output.open('xb') as f:f.write(raw)
print(raw.decode(),end='')

#!/usr/bin/env python3
"""Consume exact original success channels only; retention does not clear publication."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent;B=runpy.run_path(str(O/'bindings.py'));plan=B['verify'](O)
assert Path.cwd()==B['VM_TREE'];load,sha=B['load'],B['sha'];run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs';B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert p.read_text().strip()=='0',p
result,cleanup=load(O/'result.json'),load(O/'cleanup.json');assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established']is False
assert result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0
assert child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit'])is int and report['original_collector_exit']==0
assert report['patch_count']==20 and report['patch_bytes']==1959776 and report['nar_bytes']==195961000 and report['nar_sha256']==plan['nixpkgs']['database_nar_sha256']
assert report['publication_clearance']is False and report['source_bundle_complete']is False and report['network_used']is False and report['target_execution']is False and report['source_execution']is False and report['Nix_invoked']is False
assert not (O/'collection-failure.json').exists();D=Path(load(O/'destination.json')['path']);assert report['custody_path']==str(D)
assert len(report['files'])==22 and len({r['path'] for r in report['files']})==22
for r in report['files']:
 p=Path(r['path']);assert p.is_relative_to(D) and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert {r['path'] for r in report['files']}=={str(p) for p in D.rglob('*') if p.is_file()}
assert sum(r['bytes'] for r in report['files'])<=384*1024**2 and sha(D/'manifest.json')==report['manifest_sha256']
manifest=load(D/'manifest.json');assert manifest['source_bundle_complete']is False and manifest['binding_refs']==plan['binding_refs'] and manifest['unresolved']==plan['unresolved'] and manifest['libglvnd_reused']==plan['libglvnd_reused']
assert manifest['nixpkgs']['custody']['sha256']==report['nar_sha256'] and manifest['nixpkgs']['custody']['bytes']==report['nar_bytes']
assert manifest['nixpkgs']['canonical_nar_exact']is True and manifest['nixpkgs']['independent_tree_hash_recomputed']is True
nar_record=next(r for r in report['files'] if r['path']==str(D/plan['nixpkgs']['member']))
assert nar_record==manifest['nixpkgs']['custody'] and nar_record['sha256']==plan['nixpkgs']['database_nar_sha256'] and nar_record['bytes']==195961000
assert [r['source'] for r in manifest['patches']]==plan['patches']
assert {r['custody']['sha256'] for r in manifest['patches']}=={r['sha256'] for r in plan['patches']}
for patch in manifest['patches']:
 assert patch['custody']['path']==str(D/'patches'/(patch['source']['sha256']+'.patch')) and patch['custody'] in report['files']
assert cleanup['all_recorded_identities_absent']is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped']is False
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']();keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']};supervisor=cleanup['supervisor_identity'];assert supervisor is not None;keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in keys];parents={r['pid'] for r in matching};descendants=[]
while parents:
 children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants];descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[p for p in O.rglob('*') if p.is_file()]+[run/'runner-result.json',run/'build.rc']+[Path(r['path']) for r in report['files']]
assert len(files)<=1024 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=64*1024**2
out=O/'admission-completion-evidence.json';evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Exact held Nixpkgs canonical NAR and twenty named patches retained. Accepted libglvnd reuse referenced; two normalized patches, notice, retrieval, offhost and publication remain separate.')
raw=(json.dumps(evidence,indent=2)+'\n').encode();assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=64*1024**2
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed held FEX source custody; two normalized patches and publication remain unresolved')

"""Canonical NAR streaming of one named directory; never follow symlinks or run sources."""
import os,stat,hashlib
def u64(n):
    assert type(n)is int and 0<=n<2**64
    return n.to_bytes(8,'little')
def frame(value):
    assert type(value)is bytes
    return u64(len(value))+value+b'\0'*((-len(value))%8)
def node_header(kind,executable=False):
    assert kind in ['regular','directory','symlink'] and type(executable)is bool
    assert kind=='regular' or not executable
    return frame(b'(')+frame(b'type')+frame(kind.encode())+(frame(b'executable')+frame(b'') if executable else b'')
def entry_header(name):
    assert type(name)is bytes and 0<len(name)<=4096 and name not in [b'.',b'..'] and b'/' not in name and b'\0' not in name
    return frame(b'entry')+frame(b'(')+frame(b'name')+frame(name)+frame(b'node')
def kind_of(mode):
    if stat.S_ISREG(mode):return 'regular'
    if stat.S_ISDIR(mode):return 'directory'
    if stat.S_ISLNK(mode):return 'symlink'
    raise AssertionError('special source member refused')
def fingerprint(s):
    return tuple(getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_nlink'])
def dump(root,sink,limits,tick):
    root=os.fsencode(root);assert root.startswith(b'/') and len(root)<=limits['path_bytes']
    counts=dict(nodes=0,regular=0,directory=0,symlink=0,executable=0,source_bytes=0,name_bytes=0)
    def emit(data):tick();sink.write(data)
    def names(fd):
        result=[];name_bytes=0
        with os.scandir(fd) as entries:
            for e in entries:
                tick();name=os.fsencode(e.name);entry_header(name)
                assert len(result)+1<=limits['source_tree_entries']
                name_bytes+=len(name);assert name_bytes<=limits['directory_name_bytes']
                result.append(name)
        result.sort();assert len(result)==len(set(result));return result
    def node(parent,name,relative,depth):
        tick();assert depth<=limits['source_depth'] and len(relative)<=limits['path_bytes'] and len(root)+len(relative)+1<=limits['path_bytes']
        assert counts['nodes']<limits['source_tree_entries'];counts['nodes']+=1
        before=os.stat(name,dir_fd=parent,follow_symlinks=False);kind=kind_of(before.st_mode);counts[kind]+=1
        if kind=='directory':
            fd=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
            try:
                assert fingerprint(os.fstat(fd))==fingerprint(before)
                children=names(fd);emit(node_header(kind))
                for child in children:
                    counts['name_bytes']+=len(child);assert counts['name_bytes']<=limits['directory_name_bytes']
                    emit(entry_header(child));node(fd,child,relative+b'/'+child,depth+1);emit(frame(b')'))
                assert names(fd)==children and fingerprint(os.fstat(fd))==fingerprint(before),'directory changed'
            finally:os.close(fd)
        elif kind=='symlink':
            target=os.readlink(name,dir_fd=parent);assert type(target)is bytes and len(target)<=limits['path_bytes']
            emit(node_header(kind)+frame(b'target')+frame(target))
            assert os.readlink(name,dir_fd=parent)==target
        else:
            assert 0<=before.st_size<=limits['source_member_bytes']
            assert counts['source_bytes']+before.st_size<=limits['nar_bytes']
            executable=bool(before.st_mode&stat.S_IXUSR);counts['executable']+=int(executable)
            emit(node_header(kind,executable)+frame(b'contents')+u64(before.st_size))
            fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
            try:
                assert fingerprint(os.fstat(fd))==fingerprint(before)
                remaining=before.st_size
                while remaining:
                    tick();data=os.read(fd,min(1024**2,remaining));assert data,'truncated source file'
                    tick(len(data));remaining-=len(data);counts['source_bytes']+=len(data);emit(data)
                assert os.read(fd,1)==b'' and fingerprint(os.fstat(fd))==fingerprint(before),'regular source changed'
            finally:os.close(fd)
            emit(b'\0'*((-before.st_size)%8))
        emit(frame(b')'))
        assert fingerprint(os.stat(name,dir_fd=parent,follow_symlinks=False))==fingerprint(before),'source identity changed'
    parent,name=os.path.split(root);fd=os.open(parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        emit(frame(b'nix-archive-1'));node(fd,name,b'',0)
    finally:os.close(fd)
    return counts

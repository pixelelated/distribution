#!/usr/bin/env python3
"""Offline exact held source custody. Root admission required; no source execution."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,runpy,stat,sys,time
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path']);N=runpy.run_path(str(O/'nar.py'))
START=time.monotonic();READ=0;WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1
def tick(n=0):
    global READ
    assert type(n)is int and n>=0 and READ+n<=R['total_read_bytes'] and time.monotonic()-START<R['soft_seconds'],'read/time ceiling'
    READ+=n
def safe(name):
    assert isinstance(name,str) and name and len(os.fsencode(name))<=R['path_bytes'] and '\0' not in name
    p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p)==name
    return name
def ident(p):
    p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.resolve(strict=True)==p
    s=p.stat();assert stat.S_ISREG(s.st_mode)
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def digest(p,cap):
    before=ident(p);assert before['bytes']<=cap and READ+before['bytes']<=R['total_read_bytes']
    h=hashlib.sha256()
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        with os.fdopen(fd,'rb',closefd=False) as f:
            for b in iter(lambda:f.read(1024**2),b''):tick(len(b));h.update(b)
    finally:os.close(fd)
    assert ident(p)==before
    return dict(before,sha256=h.hexdigest())
def root_for(p):
    for root in [O,D]:
        if p.is_relative_to(root):return root
    raise AssertionError('write outside owned roots')
def mkdir(p):
    root_for(p);assert len(DIRS)<R['output_directories'] and not p.exists() and not p.is_symlink()
    assert p.parent.resolve(strict=True)==p.parent;p.mkdir(mode=0o700);DIRS.add(str(p))
def reserve(p,n,failure=False):
    # A deadline/read refusal must still retain its bounded original failure receipt.
    if not failure:tick()
    root=root_for(p);cap=R['custody_output_ceiling_bytes'] if root==D else R['owner_output_ceiling_bytes']-R['supervisor_reserve_bytes']
    if failure:assert root==O and n<=R['failure_receipt_budget_bytes'];cap+=R['failure_receipt_budget_bytes']
    assert type(n)is int and n>=0 and OUTPUT[str(root)]+n<=cap and WRITES[str(p)]+n<=R['per_file_bytes'],'before-write ceiling'
    OUTPUT[str(root)]+=n;WRITES[str(p)]+=n
class Writer:
    def __init__(self,p,failure=False):
        self.p=Path(p);root_for(self.p);safe(str(self.p.relative_to(root_for(self.p))))
        assert len(WRITES)<R['output_files'] and str(self.p) not in WRITES
        assert self.p.parent.resolve(strict=True)==self.p.parent and not self.p.exists() and not self.p.is_symlink()
        WRITES[str(self.p)]=0;self.failure=failure;self.f=self.p.open('xb')
    def write(self,b):
        reserve(self.p,len(b),self.failure);written=self.f.write(b);assert written==len(b);return written
    def __enter__(self):return self
    def __exit__(self,*args):self.f.close()
def put(p,obj,failure=False):
    raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode();assert len(raw)<=1024**2
    with Writer(p,failure) as f:f.write(raw)
class NarSink:
    def __init__(self,out):self.out=out;self.bytes=0;self.hash=hashlib.sha256()
    def write(self,b):
        assert self.bytes+len(b)<=PLAN['nixpkgs']['database_nar_size'],'NAR exact size ceiling before write'
        self.out.write(b);self.bytes+=len(b);self.hash.update(b)
def copy_patch(row):
    p=Path(row['path']);before=digest(p,R['patch_per_file_bytes']);assert before==row,'named patch changed'
    target=D/'patches'/(row['sha256']+'.patch')
    with p.open('rb') as source,Writer(target) as out:
        for b in iter(lambda:source.read(1024**2),b''):tick(len(b));out.write(b)
    after=digest(target,R['patch_per_file_bytes']);assert after['bytes']==row['bytes'] and after['sha256']==row['sha256']
    assert (after['device'],after['inode'])!=(before['device'],before['inode']) and digest(p,R['patch_per_file_bytes'])==before
    return dict(source=before,member=str(target.relative_to(D)),custody=after)
try:
    os.umask(0o077)
    assert D.parent==Path('/workspace/artifacts/pixelelated-release-sources') and D.name=='m7-fex-held-source-'+O.name.removeprefix('pix-m7-fex-held-source-custody-')
    assert not D.exists() and not D.is_symlink()
    initial_files=0
    for p in O.rglob('*'):
        assert not p.is_symlink()
        if p.is_file():
            initial_files+=1;assert initial_files<=128;OUTPUT[str(O)]+=p.stat().st_size
            assert OUTPUT[str(O)]<=8*1024**2
    for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
    assert len(PLAN['patches'])==20 and sum(r['bytes'] for r in PLAN['patches'])==PLAN['patch_total_bytes']==1959776
    assert PLAN['patch_total_bytes']<=R['patch_aggregate_bytes']
    source=Path(PLAN['nixpkgs']['physical_root']);assert source.resolve(strict=True)==source and source.is_dir() and not source.is_symlink()
    before=N['fingerprint'](source.stat());mkdir(D);mkdir(D/'patches')
    target=D/PLAN['nixpkgs']['member']
    with Writer(target) as out:
        sink=NarSink(out);counts=N['dump'](str(source),sink,R,tick)
        assert sink.bytes==PLAN['nixpkgs']['database_nar_size'] and sink.hash.hexdigest()==PLAN['nixpkgs']['database_nar_sha256'],'canonical NAR differs from frozen identity'
    assert N['fingerprint'](source.stat())==before
    nar=digest(target,R['nar_bytes']);assert nar['bytes']==sink.bytes and nar['sha256']==sink.hash.hexdigest()
    patches=[copy_patch(r) for r in PLAN['patches']]
    for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
    manifest=dict(format='canonical-nar-and-exact-flat-patches',nixpkgs=dict(PLAN['nixpkgs'],custody=nar,counts=counts,source_root_identity=before,independent_tree_hash_recomputed=True,canonical_nar_exact=True),patches=patches,libglvnd_reused=PLAN['libglvnd_reused'],binding_refs=PLAN['binding_refs'],unresolved=PLAN['unresolved'],publication_clearance=False,source_bundle_complete=False)
    put(D/'manifest.json',manifest)
    files=[digest(Path(p),R['per_file_bytes']) for p in sorted(WRITES) if Path(p).is_relative_to(D)]
    put(O/'collection-result.json',dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,custody_path=str(D),nar_bytes=nar['bytes'],nar_sha256=nar['sha256'],patch_count=20,patch_bytes=1959776,files=files,manifest_sha256=next(r['sha256'] for r in files if r['path']==str(D/'manifest.json')),counts=counts,elapsed_seconds=time.monotonic()-START,named_read_bytes=READ,output_accounted_bytes=OUTPUT,source_execution=False,target_execution=False,network_used=False,Nix_invoked=False,publication_clearance=False,source_bundle_complete=False,outputs_held=True,deleted_bytes=0));rc=0
except BaseException as error:
    put(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error_type=type(error).__name__,elapsed_seconds=time.monotonic()-START,named_read_bytes=READ,output_accounted_bytes=OUTPUT,partial_files=WRITES,publication_clearance=False,source_bundle_complete=False,outputs_held=True,deleted_bytes=0),failure=True)
sys.exit(rc)

"""Exact source/host bindings; no collection at import."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def python_identity(expected):
 p=Path(expected['path']);assert p==Path('/usr/bin/python3.14') and p.resolve(strict=True)==p and not p.is_symlink()
 s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_size<8*1024**2 and os.access(p,os.X_OK)
 actual=dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),mtime_ns=s.st_mtime_ns,sha256=sha(p))
 assert all(actual[k]==expected[k] for k in actual),'host Python differs from bound byte identity'
 after=p.stat();assert all(getattr(after,k)==getattr(s,k) for k in ['st_dev','st_ino','st_size','st_mode','st_mtime_ns'])
 return actual
def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h
 plan=load(O/'collection-plan.json')
 assert len(plan['binding_refs'])<=32
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h
 source=load('/tmp/pix-m7-fex-source-phaseb-20261015/phase-b-plan.json');evidence=load('/tmp/pix-m7-fex-source-phaseb-20261015/held-source-evidence.json')
 assert plan['nixpkgs']['physical_root']==source['held_nixpkgs']['physical_root']=='/workspace/tmp/pix-m7-sm8550-refresh-20261015-02/nix/store/4k79ns9drp02wyvcix81c7nnz4hn8psi-source'
 assert plan['nixpkgs']['commit']=='b6018f87da91d19d0ab4cf979885689b469cdd41'
 assert plan['nixpkgs']['database_nar_size']==195961000 and plan['nixpkgs']['database_nar_sha256']=='b705cf16a16caeb639af6f1987b1e89a0729da050c06043a5834bdf10ff7c452'
 assert len(plan['patches'])==20 and len({r['path'] for r in plan['patches']})==20 and sum(r['bytes'] for r in plan['patches'])==plan['patch_total_bytes']==1959776
 assert all(r in evidence['named_source_reads'] and str(Path(r['path']).parent).endswith('/nix/store') for r in plan['patches'])
 assert len(plan['unresolved'])==2 and {r['recorded_output_sha256'] for r in plan['unresolved']}=={'63a602cddfe36755593fd6c59479078f34b04a15de03b88959dc9fc69813da5d','233cf3f489f9dd6ec20befa4d5b2ebefc892ae6c69166d5c1fca9c4a9a6da144'}
 reuse=plan['libglvnd_reused'];probe=load(reuse['probe']);accepted=load(reuse['acceptance']);run=Path(reuse['run'])
 assert probe['result']=='EXACT_RECURSIVE_SOURCE_REUSE' and probe['original_exit']==0 and probe['computed_nar_sha256']==reuse['nar_sha256']=='d94f49b691b23f895bc6d54978fe465208795ed865a0fbc5230dbcfa795d631f'
 assert probe['nar_bytes']==reuse['nar_bytes']==6669360 and probe['archive']==reuse['archive'] and probe['network_used']is False and probe['source_execution']is False
 assert accepted['run']==str(run) and accepted['original_tool_exit']==0
 assert run.parent==VM_TREE/'.build-runs' and (run/'build.rc').read_text().strip()=='0'
 assert all(type(load(run/'runner-result.json')[k])is int and load(run/'runner-result.json')[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
 assert plan['publication_clearance']is False and plan['source_bundle_complete']is False
 python_identity(plan['host_python'])
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-fex-held-source-'+O.name.removeprefix('pix-m7-fex-held-source-custody-')
 guard=load(O/'guard-report.json');assert guard['result']=='PASS_HELD_SOURCE_GUARDS' and guard['collector_sha256']==sha(O/'collect.py') and guard['nar_source_sha256']==sha(O/'nar.py') and guard['network_used']is False and guard['production_sources_read']is False
 assert len(guard['cases'])==30 and len({r['case'] for r in guard['cases']})==30 and all(r['result'].startswith('PASS') for r in guard['cases'])
 gr=Path(plan['guard_run']);assert gr.parent==VM_TREE/'.build-runs' and (gr/'build.rc').read_text().strip()=='0'
 assert all(type(load(gr/'runner-result.json')[k])is int and load(gr/'runner-result.json')[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
 return plan


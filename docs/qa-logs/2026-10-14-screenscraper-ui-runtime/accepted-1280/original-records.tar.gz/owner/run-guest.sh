set -eu
python3 -I -S -B /tmp/pix-input/pix566/guest-control.py provision --panel 1280x800

# #566 two-panel offline UI route — prepared, UNRUN

This additive packet consumes the coordinator's successful component02:
ES3178b832b8d134198b2b4eede4f725d4ed283f8c,
ELF62d256b2a391493030639fba27c198d16cc2ee68ca0ed82748713ef2b30a270b.
`compiled-inputs.json` binds all three actual output hashes and the original
component receipt. No sealed component packet, product, shared record or old
allocation is edited. No guest/service/input/locale compiler has been executed
while preparing this route.

`prepare.py --checkout` accepts the frozen runtime checkout
`/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-01` at e483. Admission,
watcher and serial/visual/stop tools use that checkout; a dirty coordinator is
not substituted. The VM launcher remains the exact accepted no-NIC helper
5b058ed8a8b11135cd5997e3d925939baff30726033125acf1244863a756318d
from m7-offline-vm-567. The frozen checkout's launcher lacks `--no-network` and
is deliberately not selected. Existing VM20 image1a23cf57 remains unchanged.

The lifecycle is the existing English640 visual handoff, with a visible
`lifecycle.diff`. It creates one fresh VM per panel, keeps the original8GiB/4CPU
profile and16GiB disk, and allows two language cases under a **1200-second total
lifecycle alarm** including preparation, boot, visuals and shutdown. Each guest
case has a240-second external supervisor,40-second startup readiness and180-second
UI limit. The unchanged peer has120seconds starting immediately before ES;
locale/log preparation now precedes that clock. Trigger SCRAPE NOW promptly after
the three setup frames. No limit resets, automatic retry or new generic runner.

## Known fixture corrections, all source-bound

`guest/guest-case.py` is an additive derivative; `guest-case.diff` lists every
change from sealed component02. Source3178 and `rejection-peer.py` are unchanged.
It imports byte-identical accepted `output_guard.py` from81d618: worker/helper
files8MiB, ES FSIZE64MiB for its real PulseAudio memfd, named ES output on a
separate8MiB/64-inode tmpfs with bounded mirrored export. The supported private
`emulationstation.ini` `log=` override and `LogLevel=information` come from
accepted84faea63d9, with executable-directory INI refusal. No unsupported
`--log-path` remains. Startup requires actual API idle plus the captured native
startup line; logs are copied while live and after normal exit. A forced timeout
does not claim a retained-FD final log tail.

The actual French libc locale is prepared with the production `localedef`
inputs/flags in private storage when absent. It uses `/usr/share/i18n`, UTF-8,
the selected language and the private locale directory; actual `setlocale`
readback must succeed before ES. `LOCPATH` and `LANGUAGE` are explicit. The full
`es_settings` script is not run. Exact newly compiled FR catalogs populate both
fr and fr_FR paths, retaining English and installed public resources.

## Prepare and launch the first panel

Run only after original component consumption, as already reported by the
coordinator. Can this be done on the VM? **Yes**; these are actual compiled
frontend frames against an offline simulated rejection, within existing #566.
Prepare a new owner; choose an observed-free VNC display. The example uses126.
Nothing below has been executed by this worker.

```sh
PIX566_ROUTE=/tmp/m7-screenscraper-vm-route-20261014
PIX566_RUNTIME=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-01
PIX566_BUILD=/workspace/tmp/pix566-es-component-20261014-02
PIX566_VM=/workspace/tmp/pix566-ui640-20261014-01
python3 -I -S -B "$PIX566_ROUTE/prepare.py" \
  --checkout "$PIX566_RUNTIME" --owner "$PIX566_VM" \
  --build-owner "$PIX566_BUILD" --panel 640x480 --vnc 126
cd "$PIX566_RUNTIME"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$PIX566_VM/retention-plan.json" \
  --output "$PIX566_VM/retention-report.json"
# Consume original report channels before admission.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$PIX566_VM/admission-plan.json" --output "$PIX566_VM/admission.json"
tools/watch-build-submit --owner "$PIX566_VM/lifecycle-owner" -- \
  --admission "$PIX566_VM/admission.json" --activity-dir "$PIX566_VM/logs" -- \
  python3 -I -S -B "$PIX566_VM/vm-lifecycle.py"
```

The lifecycle verifies the frozen checkout and host tools, unchanged image and
helper, generated/actual QEMU argv with exactly `-nic none`, observed guest lo-only
topology and read-only input medium. `guest-control.py provision` stops only the
original essway frontend while retaining Sway, verifies/copied executable and
catalogs, captures the actual output dimensions and actual installed input map,
then returns. A bounded60-second compositor/input/panel readiness poll runs
before stopping essway, within the existing120-second provision budget; serial
login availability is not treated as display readiness. The lifecycle writes
`visual-ready.json` and releases serial.
It watches host files/PID until handoff; it does not poll serial during visuals.

## Focused serial and frame actions

Use only `host-action.py` while visual ownership is active. Both it and lifecycle
acquire the same `OWNER/serial.lock`; no extra serial reader, raw polling loop or
concurrent HMP/QMP/VNC client is permitted. The HMP socket sends key/screenshot
operations; it is not a QMP socket. All media operations finish before handoff.
Every action releases the lock and serial connection when it returns.

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" start \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language en_US
python3 -I -S -B "$PIX566_ROUTE/host-action.py" status \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language en_US
```

`start` detaches the finite guest supervisor and returns immediately. `status`
returns its original records, and `armed.json` appears only after actual ES/log
readiness. Do not save context or wait for another worker while the peer is armed.

For each input use `key --key ACTION`; ACTION is resolved from the **copied actual
input config**, not a guessed QEMU key. On the current source's normal keyboard
mapping: start→ret, a→x, b→z, up/down/left/right→arrow keys, shoulders→q/w. Provision
records the observed mappings and refuses missing required actions. If those
actual values differ, the host adapter uses the recorded values.

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" key \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language en_US --key start
```

The focused route is: START main menu → visible SCRAPER row → A. Capture entry.
The page opens on its first row; UP goes to the tab strip, LEFT/RIGHT there change
tabs, DOWN returns to rows (`MenuComponent.cpp:107`). Capture OPTIONS and ACCOUNTS,
showing personal account fields and absence of developer fields. Return to SCRAPE.
The private settings select ScreenScraper, ALL, no recent-game exclusion and one
GB platform with a non-executable metadata-only fixture. Select SCRAPE NOW in the
button bar and A; do not launch the metadata-only library item. The actual
scrape-start caller then makes the two peer requests and opens the actual error.
Capture the complete message/prefix/OK/help bar, dismiss OK, capture returned
library, then finish. Resolve focus by the observed frame; do not replay ambiguous
keypresses or substitute a guessed fixed row count.

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" capture \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language en_US --frame accounts
# Inspect the emitted PNG, then record that actual review:
python3 -I -S -B "$PIX566_ROUTE/host-action.py" review \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language en_US \
  --frame accounts --review 'REPLACE WITH ACTUAL OBSERVED FINDINGS'
```

Required roles are `entry`, `accounts`, `options`, `error`, `returned`. Each
capture verifies PNG dimensions against actual Sway panel readback and records
its hash. Review records must bind unchanged frame bytes. If a page needs a
second scrolled frame, capture it before leaving; older capture PNG/receipts
remain retained in their unique invocation directory. All reviewed content,
including scroll coverage, belongs in root's canonical frame index.

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" finish \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language en_US
# Poll status briefly until original supervisor/case exit0 and supervisor absent.
python3 -I -S -B "$PIX566_ROUTE/host-action.py" status \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language en_US
```

`finish` refuses missing/unreviewed roles, then writes the guest handoff marker.
It does not manufacture the guest success result. Repeat start/actions/reviews/
finish for `fr_FR` in this same panel VM only after EN exits. Confirm actual
French text and locale, not merely the selected setting. Peer receipts require
exact public compiled pair equality despite conflicting synthetic runtime fields;
personal account fields remain empty. All five frames are required for each
language. Then:

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" panel-complete \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME"
```

This requires both original supervisors0/absent and ten reviewed role receipts,
exports a compact guest manifest, restores the original frontend service, and
only then writes `visual-result.json`. Lifecycle resumes serial, flushes/unmounts
output and stops the exact QEMU PID. A timeout, abnormal child exit, output quota
fault or forced cleanup stays FAIL. Preserve that original owner for diagnosis.

## Export, consume, then the second panel

Consume original lifecycle/watch runner/command/monitor and submit launcher/
tool-wrapper channels and verify actual owner exits. Set `PIX566_RUN` to the
original watched run printed by submit. Export only after clean original shutdown:

```sh
python3 -I -S -B "$PIX566_ROUTE/export.py" \
  --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --run "$PIX566_RUN" \
  --output /workspace/tmp/pix566-ui640-evidence-20261014-01
```

The exporter binds the original0 channels, absent PIDs, original flush/stop
receipt and guest manifest; each compact ext4 readback is rehashed. It preserves
host/frame/watcher records. It neither consumes admission nor retires media;
root does those existing final steps after reviewing the real evidence.

Only then prepare a separate owner, e.g.
`/workspace/tmp/pix566-ui1280-20261014-01`, with `--panel 1280x800 --vnc 127` and
repeat the same two-language route. This keeps each realistic family bound at
1200seconds and avoids claiming an unobserved dynamic panel resize. Both owners
use the exact same component/catalog hashes. Root owns canonical #566 menu-flow/
frame-index updates and pin promotion; this fixture establishes no provider
acceptance or native Dolphin gameplay.

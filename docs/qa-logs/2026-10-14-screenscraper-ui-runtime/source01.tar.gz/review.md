# Independent source review and execution boundary

Root-assigned reviewer `/root/proxy_native_build` inspected the sealed guest
source and additive route without edits or runtime. Its concrete finding was
missing French libc locale data: ES could return before gettext binding and
render English. The derivative now prepares that locale in private storage,
sets LOCPATH/LANGUAGE, and requires actual setlocale readback before ES.

The review confirmed cached VM20 Python3.14 unshare support, kernel namespaces,
BusyBox mount flags, localedef/i18n inputs, and resolving public theme/resource/
catalog paths. It found no further deterministic blocker in the written route.
This is a local source review, not runtime qualification or a formal council.

The reviewer emphasized shared serial.lock ownership and the original120-second
peer timer. Both host-action and lifecycle use that same lock. The peer now
starts after locale/log preparation and before frontend readiness; that readiness
still consumes part of the peer budget, so root must perform the focused walk
promptly. No timers were extended. The outer240-second case supervisor retains
failure and group cleanup; timeout output has periodic bounded snapshots but
does not claim an fd-preserved final tail.

Root separately requested display readiness before stopping essway; the route
now polls actual Wayland/Sway/input/panel readiness for at most60seconds within
the existing120-second provision budget. Static AST/hash checks cover the final
files, including original host-tool timeout exit recording and verified archive
readback. Every VM, service, locale-generation and UI command remains UNRUN by
this source worker. Root owns original execution, visual review and acceptance.

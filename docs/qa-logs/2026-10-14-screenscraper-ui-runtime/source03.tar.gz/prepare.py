#!/usr/bin/env python3
"""Prepare one fresh, admitted-later #566 panel owner; never launches a guest."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
OLD = Path('/workspace/tmp/pix581-en640-vm-20261014-01')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n')

p = argparse.ArgumentParser()
p.add_argument('--checkout', type=Path, required=True)
p.add_argument('--owner', type=Path, required=True)
p.add_argument('--build-owner', type=Path, required=True)
p.add_argument('--panel', choices=['640x480', '1280x800'], required=True)
p.add_argument('--vnc', type=int, required=True)
a = p.parse_args()
assert 100 <= a.vnc <= 199 and a.owner.parent == Path('/workspace/tmp')
assert a.checkout.is_absolute() and a.checkout.resolve() == a.checkout
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=a.checkout).strip()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=a.checkout, text=True).strip()
assert commit.startswith('e483'), 'unexpected frozen runtime checkout'
for line in (HERE / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert sha(HERE / name) == digest
built = json.loads((a.build_owner / 'work/component-result.json').read_text())
assert built['rc'] == 0 and json.loads((a.build_owner / 'stages/es-component/result.json').read_text())['status'] == 'PASS'
assert (a.build_owner / 'stages/es-component/cleanup-complete.json').exists()
a.owner.mkdir()
for name in ('records', 'scan', 'vm', 'frames', 'lifecycle-owner', 'logs'):
    (a.owner / name).mkdir()
facts = json.loads((OLD / 'records/image-size.json').read_text())
helper = json.loads((OLD / 'records/inputs.json').read_text())['helper']
assert sha(Path(helper['path'])) == helper['sha256']
files = []
for f in sorted((HERE / 'guest').rglob('*')):
    if f.is_file():
        files.append({'path': str(f), 'destination': 'pix566/' + str(f.relative_to(HERE / 'guest')), 'sha256': sha(f)})
for name, row in built['artifacts'].items():
    f = a.build_owner / 'work/artifacts' / name
    assert sha(f) == row['sha256']
    files.append({'path': str(f), 'destination': 'artifacts/' + name, 'sha256': sha(f)})
f = a.build_owner / 'work/component-result.json'
files.append({'path': str(f), 'destination': 'component-result.json', 'sha256': sha(f)})
save(a.owner / 'records/image-size.json', facts)
save(a.owner / 'records/inputs.json', {'files': files, 'helper': helper})
tools = ['tools/vm-serial', 'tools/vm-visual-qa', 'tools/vm-stop']
save(a.owner / 'records/runtime.json', {'checkout': str(a.checkout), 'commit': commit, 'panel': a.panel, 'vnc': a.vnc, 'family_seconds': 1200, 'tool_hashes': {n: sha(a.checkout / n) for n in tools}, 'packet': str(HERE), 'packet_manifest_sha256': sha(HERE / 'SHA256SUMS')})
shutil.copyfile(HERE / 'vm-lifecycle.py', a.owner / 'vm-lifecycle.py')
(a.owner / 'run-guest.sh').write_text('set -eu\npython3 -I -S -B /tmp/pix-input/pix566/guest-control.py provision --panel ' + a.panel + '\n')
save(a.owner / 'records/lifecycle-basis.json', {'source': str(OLD / 'vm-lifecycle.py'), 'sha256': sha(OLD / 'vm-lifecycle.py'), 'changes': ['frozen checkout parameter', 'panel/VNC parameter', '1200s for two cases per panel', 'shared serial lock and explicit visual ownership', 'two original cases plus reviewed frame handoff']})
plan = {'volume': '/workspace', 'scan_roots': [str(a.owner / 'scan')], 'reference_stores': [], 'protected': [str(HERE), str(a.checkout), facts['image']], 'candidates': [], 'builds': [{'name': 'pix566-' + a.panel, 'terms_bytes': {'raw_image': facts['raw_bytes_from_backup_lba'], 'guest_disk': 16 * 1024**3, 'media_records': 512 * 1024**2}, 'basis': 'Existing no-NIC VM20 profile,8GiB RAM/4CPU,16GiB virtual disk. Two language cases per panel,360s outer case each,1200s lifecycle including boot/provision/visual coordination/flush. Exact consumed ES artifacts. No provider/account or game execution.', 'evidence': [{'path': str(a.owner / n), 'sha256': sha(a.owner / n)} for n in ['records/image-size.json', 'records/inputs.json', 'records/runtime.json', 'vm-lifecycle.py', 'run-guest.sh']]}]}
save(a.owner / 'retention-plan.json', plan)
save(a.owner / 'admission-plan.json', {'checkout': str(a.checkout), 'retention_plan': str(a.owner / 'retention-plan.json'), 'retention_report': str(a.owner / 'retention-report.json'), 'stage': 'pix566-' + a.panel, 'profiles': [{'PROJECT': 'ROCKNIX', 'DEVICE': 'GENERIC_X64', 'ARCH': 'x86_64'}], 'outputs': [{'path': str(a.owner / 'vm'), 'issue': 566, 'kind': 'qa-scratch', 'release_when': 'Original case/frame/lifecycle/watcher channels exported and consumed; actual owners gone; retire disk/media/UEFI.'}, {'path': str(a.owner / 'frames'), 'issue': 566, 'kind': 'qa-scratch', 'release_when': 'Preserve reviewed exact-source frames and compact original action receipts.'}]})
print(str(a.owner / 'admission-plan.json'))

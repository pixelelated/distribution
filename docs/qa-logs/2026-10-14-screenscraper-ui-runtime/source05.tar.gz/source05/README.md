# #566 remaining exact-source UI cases — route05, UNRUN

EN640 is already fully qualified by owner04: exact ELF62d256b2, peer/ES/worker/supervisor0, five reviewed roles, original normal HTTP quit200. Keep that proof. Owner04's French localedef helper returned original1 before peer/frontend; all originals were exported and the coordinator consumed/retired the failed panel owner. Do not rerun EN640 merely for freshness.

This additive packet supports only the remaining FR640 and EN/FR1280 allocations. Source3178b832 and component02 artifacts are unchanged. The explicit preparation language is bound into the owner runtime record; host action, guest export and lifecycle require precisely that declared set and five personally reviewed roles per language. No case result is imported from another owner or manufactured. The host exporter remains byte-identical to04.

GNU localedef warning status1 is retained verbatim in localedef.exit.json. The fixture recognizes only the nine observed optional-field warnings, rejects other diagnostic classes, verifies and hashes all generated locale categories, then requires actual installed setlocale readback0 before peer or ES starts. Original warning output remains evidence. This is not normalization to0. See correction05.diff and correction05-review.json. Prior04 is retained in README-route04.md for history.

Fresh FR640 owner, after coordinator consumption of04 (completed), with observed-free VNC126:

```sh
PIX566_ROUTE=/tmp/m7-screenscraper-vm-route-20261014-05
PIX566_RUNTIME=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-01
PIX566_BUILD=/workspace/tmp/pix566-es-component-20261014-02
PIX566_VM=/workspace/tmp/pix566-ui640-20261014-05
python3 -I -S -B "$PIX566_ROUTE/prepare.py" --checkout "$PIX566_RUNTIME" \
  --owner "$PIX566_VM" --build-owner "$PIX566_BUILD" \
  --panel 640x480 --language fr_FR --vnc 126
cd "$PIX566_RUNTIME"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$PIX566_VM/retention-plan.json" --output "$PIX566_VM/retention-report.json"
# Consume original report command/monitor/runner/tool exits before admission.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$PIX566_VM/admission-plan.json" --output "$PIX566_VM/admission.json"
tools/watch-build-submit --owner "$PIX566_VM/lifecycle-owner" -- \
  --admission "$PIX566_VM/admission.json" --activity-dir "$PIX566_VM/logs" -- \
  python3 -I -S -B "$PIX566_VM/vm-lifecycle.py"
```

One sole operator; no extra serial/HMP reader. Wait on host visual-ready.json; all host-action operations acquire the exact same serial.lock as lifecycle. Shared lock release precedes atomic completion publication. No fixture edits, timer resets or automatic retries. Bounds remain peer240s, armed UI300s, supervisor360s, original family1200s, startup40s. 8GiB/4CPU no-NIC VM20 and finite output guards are unchanged.

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" start --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language fr_FR
python3 -I -S -B "$PIX566_ROUTE/host-action.py" status --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language fr_FR
# After actual armed.json, each key is a single operation, resolved from copied installed input cfg:
python3 -I -S -B "$PIX566_ROUTE/host-action.py" key --key start --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language fr_FR
```

Observe MAIN MENU before navigating SCRAPER. On the actual04 keyboard map start=ret, a=x, b=z, arrows as named. Current source tab flow: first-row UP to strip; LEFT/RIGHT switch tabs, DOWN enters rows. Capture SCRAPE entry, OPTIONS top and bottom if needed, full ACCOUNTS (blank personal fields, no developer fields), actual rejection, and returned MAIN MENU with SCRAPER selected. Do not launch the metadata-only item. Source SCRAPE NOW is reached by UP from SCRAPE tab strip; verify focus whenever ambiguous. Capture role names remain entry/options/accounts/error/returned. Every screenshot must be personally viewed, then reviewed against actual bytes:

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" capture --frame accounts --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language fr_FR
# View emitted PNG before this operation; supply actual findings, including clipping and footer presence/absence.
python3 -I -S -B "$PIX566_ROUTE/host-action.py" review --frame accounts --review 'ACTUAL OBSERVATION' --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language fr_FR
```

The actual caller must send the two expected loopback TLS requests with the exact public compiled pair despite conflicting synthetic runtime fields. Peer records booleans only, personal account fields empty. Trigger promptly after setup frames; no real provider/account/network access. Dismiss actual OK and record returned menu before finish. Normal finish calls existing GET /quit, captures original HTTP status/body and requires ES0; abnormal cleanup remains failure.

```sh
python3 -I -S -B "$PIX566_ROUTE/host-action.py" finish --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language fr_FR
python3 -I -S -B "$PIX566_ROUTE/host-action.py" status --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" --language fr_FR
# Only after original worker/supervisor0 and supervisor absent:
python3 -I -S -B "$PIX566_ROUTE/host-action.py" panel-complete --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME"
# Await original lifecycle/watch/launcher exits; then set PIX566_RUN to printed original watched run.
python3 -I -S -B "$PIX566_ROUTE/export.py" --owner "$PIX566_VM" --checkout "$PIX566_RUNTIME" \
  --run "$PIX566_RUN" --output /workspace/tmp/pix566-ui640-evidence-20261014-05
```

Coordinator reviews/consumes/retire-media before the large panel. Then prepare a fresh owner e.g. /workspace/tmp/pix566-ui1280-20261014-01 with --panel 1280x800 --vnc 127 and omit --language. Run en_US then fr_FR, each only after the previous original supervisor exits0. This same sealed packet requires ten reviewed roles and both original case exits before panel-complete. Export to /workspace/tmp/pix566-ui1280-evidence-20261014-01. Root owns canonical flow/frame index and pin promotion. No product or shared record edits; no gameplay/provider acceptance claimed.

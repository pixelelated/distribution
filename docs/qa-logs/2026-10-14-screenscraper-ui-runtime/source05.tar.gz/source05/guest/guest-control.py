#!/usr/bin/env python3
"""Small #566 provision/case supervisor; invoked by the single serial owner."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = Path('/tmp/pix-output/pix566')
INPUT = Path('/tmp/pix-input')
ARTIFACTS = Path('/tmp/pix566-artifacts')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    pending = path.with_name(path.name + '.pending')
    pending.write_text(json.dumps(value, indent=2) + '\n')
    pending.replace(path)

def identity(pid):
    try:
        text = Path('/proc', str(pid), 'stat').read_text()
        return {'pid': pid, 'start_ticks': text.rsplit(')', 1)[1].split()[19]}
    except FileNotFoundError:
        return None

def same(before):
    return before is not None and identity(before['pid']) == before

def run(label, argv, timeout=25):
    with (ROOT / (label + '.stdout')).open('xb') as out, (ROOT / (label + '.stderr')).open('xb') as err:
        p = subprocess.run(argv, stdout=out, stderr=err, timeout=timeout)
    save(ROOT / (label + '.exit.json'), {'argv': argv, 'original_exit': p.returncode})
    assert p.returncode == 0, label
    return (ROOT / (label + '.stdout')).read_text()

def provision(panel):
    assert sorted(x.name for x in Path('/sys/class/net').iterdir()) == ['lo']
    ROOT.mkdir(exist_ok=False)
    (ROOT / 'cases').mkdir()
    built = json.loads((INPUT / 'component-result.json').read_text())
    assert built['rc'] == 0 and built['source_commit'] == '3178b832b8d134198b2b4eede4f725d4ed283f8c'
    original = sha('/usr/bin/emulationstation')
    # Serial login readiness does not imply compositor/input readiness. Bound
    # this ordinary startup poll inside the existing120s provision budget.
    ready_until = time.monotonic() + 60
    observations = []
    width, height = map(int, panel.split('x'))
    while True:
        displays = [x for x in Path('/run/0-runtime-dir').glob('wayland-*') if x.is_socket()]
        sway = [x for x in Path('/run/0-runtime-dir').glob('sway-ipc.*.sock') if x.is_socket()]
        observation = {'time': time.time(), 'wayland_sockets': list(map(str, displays)), 'sway_sockets': list(map(str, sway))}
        ready = False
        if len(displays) == len(sway) == 1 and Path('/storage/.config/emulationstation/es_input.cfg').is_file():
            query = subprocess.run(['swaymsg', '-s', str(sway[0]), '-t', 'get_outputs', '-r'], capture_output=True, text=True, timeout=3)
            observation.update(original_exit=query.returncode, stdout=query.stdout, stderr=query.stderr)
            if query.returncode == 0:
                active = [x for x in json.loads(query.stdout) if x.get('active')]
                ready = len(active) == 1 and (active[0].get('current_mode') or {}).get('width') == width and (active[0].get('current_mode') or {}).get('height') == height
        observations.append(observation)
        if ready:
            break
        assert time.monotonic() < ready_until, 'compositor/input/panel startup readiness timeout'
        time.sleep(.5)
    save(ROOT / 'display-ready.json', {'rc': 0, 'observations': observations})
    run('stop-original-es', ['systemctl', 'stop', 'essway.service'])
    ARTIFACTS.mkdir(exist_ok=False)
    for name, row in built['artifacts'].items():
        assert sha(INPUT / 'artifacts' / name) == row['sha256']
        shutil.copyfile(INPUT / 'artifacts' / name, ARTIFACTS / name)
        (ARTIFACTS / name).chmod(0o755 if name == 'emulationstation' else 0o644)
    displays = [x for x in Path('/run/0-runtime-dir').glob('wayland-*') if x.is_socket()]
    sway = [x for x in Path('/run/0-runtime-dir').glob('sway-ipc.*.sock') if x.is_socket()]
    assert len(displays) == len(sway) == 1, 'requires one actual compositor'
    outputs = json.loads(run('sway-output-readback', ['swaymsg', '-s', str(sway[0]), '-t', 'get_outputs', '-r']))
    active = [x for x in outputs if x.get('active')]
    width, height = map(int, panel.split('x'))
    assert len(active) == 1 and active[0]['current_mode']['width'] == width and active[0]['current_mode']['height'] == height, 'actual panel differs'
    config = Path('/storage/.config/emulationstation/es_input.cfg')
    keyboard = ET.fromstring(config.read_bytes()).find("inputConfig[@type='keyboard']")
    assert keyboard is not None
    codes = {int(x.get('id')): x.get('name') for x in keyboard.findall('input') if x.get('type') == 'key'}
    translations = {13: 'ret', 27: 'esc', 1073741903: 'right', 1073741904: 'left', 1073741905: 'down', 1073741906: 'up', 1073742053: 'shift_r'}
    mapping = {}
    for x in keyboard.findall('input'):
        if x.get('type') != 'key':
            continue
        code = int(x.get('id'))
        key = translations.get(code, chr(code) if 97 <= code <= 122 else None)
        if key:
            mapping[x.get('name')] = key
    assert all(x in mapping for x in ('a', 'b', 'start', 'up', 'down', 'left', 'right'))
    save(ROOT / 'provision.json', {'rc': 0, 'panel': [width, height], 'original_es_sha256': original, 'artifacts': built['artifacts'], 'wayland_display': displays[0].name, 'xdg_runtime_dir': str(displays[0].parent), 'input_sha256': sha(config), 'input_keys': mapping, 'outputs': active})
    shutil.copyfile(config, ROOT / 'copied-es_input.cfg')
    return json.loads((ROOT / 'provision.json').read_text())

def status(language):
    folder = ROOT / 'cases' / language
    report = {'language': language, 'started': folder.exists()}
    if folder.exists():
        for name in ('supervisor.json', 'armed.json', 'result.json', 'supervisor-result.json'):
            path = folder / name if name != 'supervisor.json' else ROOT / (language + '-supervisor.json')
            if path.exists():
                report[name] = json.loads(path.read_text())
        record = ROOT / (language + '-supervisor.json')
        report['supervisor_alive'] = same(json.loads(record.read_text())['identity']) if record.exists() else False
    return report

def supervise(language):
    provisioned = json.loads((ROOT / 'provision.json').read_text())
    folder = ROOT / 'cases' / language
    result = {'rc': 1, 'started': time.time(), 'language': language}
    args = ['python3', '-I', '-S', '-B', str(HERE / 'guest-case.py'), '--disposable-guest', '--artifacts', str(ARTIFACTS), '--component-result', str(INPUT / 'component-result.json'), '--output', str(folder), '--language', language, '--xdg-runtime-dir', provisioned['xdg_runtime_dir'], '--wayland-display', provisioned['wayland_display']]
    child = None
    try:
        with (ROOT / (language + '-case.stdout')).open('xb') as out, (ROOT / (language + '-case.stderr')).open('xb') as err:
            child = subprocess.Popen(args, stdout=out, stderr=err, start_new_session=True)
            result['child'] = identity(child.pid)
            try:
                result['original_exit'] = child.wait(timeout=360)
            except subprocess.TimeoutExpired:
                result['timed_out'] = True
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=5)
                result['original_exit'] = child.returncode
                raise
        case = json.loads((folder / 'result.json').read_text())
        assert result['original_exit'] == case['rc'] == 0 and not result.get('timed_out')
        assert all(x['original_exit'] == 0 and not x['forced_cleanup'] and not Path('/proc', str(x['pid'])).exists() for x in case['exits'])
        result['rc'] = 0
    finally:
        result['ended'] = time.time()
        folder.mkdir(exist_ok=True)
        save(folder / 'supervisor-result.json', result)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('operation', choices=['provision', 'start', 'status', 'finish', 'supervise', 'export'])
    p.add_argument('--panel', choices=['640x480', '1280x800'])
    p.add_argument('--language', choices=['en_US', 'fr_FR'])
    p.add_argument('--review')
    a = p.parse_args()
    if a.operation == 'provision':
        return provision(a.panel)
    if a.operation == 'supervise':
        supervise(a.language)
        return {'supervisor_exit': 0}
    if a.operation == 'start':
        assert not (ROOT / 'cases' / a.language).exists()
        for other in ('en_US', 'fr_FR'):
            record = ROOT / (other + '-supervisor.json')
            if record.exists():
                assert not same(json.loads(record.read_text())['identity']), 'previous case still running'
        with (ROOT / (a.language + '-supervisor.stdout')).open('xb') as out, (ROOT / (a.language + '-supervisor.stderr')).open('xb') as err:
            child = subprocess.Popen(['python3', '-I', '-S', '-B', str(HERE / 'guest-control.py'), 'supervise', '--language', a.language], stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
        record = {'identity': identity(child.pid), 'language': a.language}
        save(ROOT / (a.language + '-supervisor.json'), record)
        return record
    if a.operation == 'status':
        return status(a.language)
    if a.operation == 'finish':
        assert a.review and len(a.review) <= 2000
        folder = ROOT / 'cases' / a.language
        assert (folder / 'armed.json').exists() and not (folder / 'ui-reviewed.done').exists()
        (folder / 'ui-reviewed.done').write_text(a.review + '\n')
        return {'handoff': 'review marker created; original case exit still due'}
    if a.operation == 'export':
        languages = [a.language] if a.language else ['en_US', 'fr_FR']
        for language in languages:
            assert json.loads((ROOT / 'cases' / language / 'supervisor-result.json').read_text())['rc'] == 0
            assert not same(json.loads((ROOT / (language + '-supervisor.json')).read_text())['identity'])
        original = json.loads((ROOT / 'provision.json').read_text())['original_es_sha256']
        assert sha('/usr/bin/emulationstation') == original
        run('restart-original-es', ['systemctl', 'start', 'essway.service'])
        rows = []
        for f in sorted(ROOT.rglob('*')):
            relative = f.relative_to(ROOT)
            if any(x in ('storage', 'es-output') for x in relative.parts) or f.name == 'key.pem' or not f.is_file():
                continue
            assert not f.is_symlink() and f.stat().st_size <= 8 * 1024**2
            rows.append({'path': str(f.relative_to(Path('/tmp/pix-output'))), 'bytes': f.stat().st_size, 'sha256': sha(f)})
        save(Path('/tmp/pix-output/guest-export-manifest.json'), rows)
        return {'rc': 0, 'files': len(rows), 'languages': languages}

if __name__ == '__main__':
    print('PIX566_JSON=' + json.dumps(main()), flush=True)

#!/usr/bin/env python3
"""Reuse the English640 one-operation serial/HMP flow for two #566 languages."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import signal
import struct
import subprocess
import time
import uuid

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n')

p = argparse.ArgumentParser()
p.add_argument('operation', choices=['start', 'status', 'key', 'capture', 'review', 'finish', 'panel-complete'])
p.add_argument('--owner', type=Path, required=True)
p.add_argument('--checkout', type=Path, required=True)
p.add_argument('--language', choices=['en_US', 'fr_FR'])
p.add_argument('--key', help='actual input action name, e.g. start/a/b/up/down/left/right')
p.add_argument('--frame', choices=['entry', 'accounts', 'options', 'error', 'returned'])
p.add_argument('--review')
a = p.parse_args()
r = a.owner
runtime = json.loads((r / 'records/runtime.json').read_text())
assert str(a.checkout) == runtime['checkout']
assert runtime['languages'] in (['fr_FR'], ['en_US', 'fr_FR'])
for name, digest in runtime['tool_hashes'].items():
    assert sha(a.checkout / name) == digest
assert (r / 'visual-ready.json').exists() and not (r / 'visual-result.json').exists()
provision_lines = re.findall(r'^PIX566_JSON=(.*)\r?$', (r / 'qa-serial.txt').read_text(), re.M)
assert len(provision_lines) == 1
provision = json.loads(provision_lines[0])
handoff_pending = None
with (r / 'serial.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    invocation = r / 'frames' / (time.strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8])
    invocation.mkdir()
    def execute(label, argv, seconds=30):
        timed_out = False
        with (invocation / (label + '.stdout')).open('xb') as out, (invocation / (label + '.stderr')).open('xb') as err:
            child = subprocess.Popen(list(map(str, argv)), stdout=out, stderr=err, start_new_session=True)
            try:
                code = child.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=5)
        save(invocation / (label + '.json'), {'argv': list(map(str, argv)), 'original_exit': code, 'timed_out': timed_out})
        assert code == 0 and not timed_out, label
        return (invocation / (label + '.stdout')).read_text()
    def serial(label, words):
        tag = 'PIX566_EXIT_' + uuid.uuid4().hex
        command = shlex.join(['python3', '-I', '-S', '-B', '/tmp/pix-input/pix566/guest-control.py', *words])
        command += '; pxrc=$?; printf "\\n' + tag + '=%s\\n" "$pxrc"'
        output = execute(label, [a.checkout / 'tools/vm-serial', '--socket', r / 'vm/serial.sock', '--timeout', '20', 'sh', command], 27)
        assert re.findall(r'^' + tag + r'=([0-9]+)\r?$', output, re.M) == ['0']
        data = re.findall(r'^PIX566_JSON=(.*)\r?$', output, re.M)
        assert len(data) == 1
        return json.loads(data[0])
    def visual(label, *words):
        return execute(label, [a.checkout / 'tools/vm-visual-qa', '--monitor', r / 'vm/monitor.sock', *words], 30)
    def reviewed(language):
        records = []
        for role in ('entry', 'accounts', 'options', 'error', 'returned'):
            value = json.loads((r / 'frames' / (language + '-' + role + '-review.json')).read_text())
            assert sha(Path(value['frame'])) == value['sha256'] and value['review']
            records.append(value)
        return records
    if a.operation == 'panel-complete':
        records = []
        for language in runtime['languages']:
            state = serial('status-' + language, ['status', '--language', language])
            assert state['supervisor-result.json']['rc'] == 0 and not state['supervisor_alive']
            records.extend(reviewed(language))
        exported = serial('export', ['export'] + (['--language', 'fr_FR'] if runtime['languages'] == ['fr_FR'] else []))
        assert exported['rc'] == 0
        handoff_pending = r / ('visual-result.' + uuid.uuid4().hex + '.pending')
        save(handoff_pending, {'languages': runtime['languages'], 'case_original_exits': [0] * len(runtime['languages']), 'supervisors_alive': False, 'reviewed_frames': len(records), 'frames': records, 'export': exported})
        print(json.dumps(exported))
    elif a.operation in ('start', 'status'):
        assert a.language in runtime['languages']
        print(json.dumps(serial(a.operation, [a.operation, '--language', a.language]), indent=2))
    else:
        assert a.language in runtime['languages']
        state = serial('status', ['status', '--language', a.language])
        save(invocation / 'status.json', state)
        assert 'armed.json' in state and state.get('supervisor_alive'), 'case is not armed/live'
        if a.operation == 'key':
            key = provision['input_keys'][a.key]
            save(invocation / 'input-claim.json', {'action': a.key, 'qemu_key': key, 'status': 'claimed before send; never replay after ambiguous tool exit'})
            visual('key', 'key', key)
        elif a.operation == 'capture':
            assert a.frame
            visual('settle', 'settle', '--timeout', '8')
            frame = invocation / (a.language + '-' + a.frame + '.png')
            visual('shot', 'shot', str(frame))
            data = frame.read_bytes()
            assert data[:8] == b'\x89PNG\r\n\x1a\n' and list(struct.unpack('!II', data[16:24])) == provision['panel']
            receipt = {'frame': str(frame), 'sha256': sha(frame), 'panel': provision['panel'], 'language': a.language, 'role': a.frame}
            save(r / 'frames' / (a.language + '-' + a.frame + '-capture.json'), receipt)
            print(str(frame))
        elif a.operation == 'review':
            assert a.frame and a.review and len(a.review) <= 2000
            receipt = json.loads((r / 'frames' / (a.language + '-' + a.frame + '-capture.json')).read_text())
            assert sha(Path(receipt['frame'])) == receipt['sha256']
            receipt['review'] = a.review
            save(r / 'frames' / (a.language + '-' + a.frame + '-review.json'), receipt)
        elif a.operation == 'finish':
            reviewed(a.language)
            print(json.dumps(serial('finish', ['finish', '--language', a.language, '--review', 'Five actual frames reviewed; see bound host frame receipts.'])))

# Publish only complete bytes after releasing the same lock lifecycle needs.
if handoff_pending is not None:
    os.replace(handoff_pending, r / 'visual-result.json')

#!/usr/bin/env python3
"""One bounded passive readback. Uses only Python standard-library byte parsing."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import struct
import sys
import time

OWNER = Path('/tmp/pix-m7-fex-generated-source-readback-20261015')
PLAN = OWNER / 'inputs.json'
ELF_ROOT = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05/build.pixelelated-SM8550.aarch64/install_pkg/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d')
INPUT_CAP = 20 * 1024 * 1024
OUTPUT_CAP = 16 * 1024 * 1024
RECEIPT_RESERVE = 65536
START = time.monotonic()
START_UTC = datetime.datetime.now(datetime.timezone.utc).isoformat()
INPUT_BYTES = 0
OUTPUT_BYTES = 0
GENERATED = []
ELFS = []
LAST = None


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check_time():
    if time.monotonic() - START > 55:
        raise TimeoutError('55-second work deadline; 5 seconds reserved for receipt')


def timeout(_signum, _frame):
    raise TimeoutError('55-second alarm; no further input allowed')


def stable(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid,
            s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def metadata(s):
    return dict(device=s.st_dev, inode=s.st_ino, mode=oct(s.st_mode),
                uid=s.st_uid, gid=s.st_gid, bytes=s.st_size,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)


def read_exact(path, size, expected_sha256, per_file_cap):
    global INPUT_BYTES, LAST
    check_time()
    LAST = str(path)
    require(path.is_absolute() and path.resolve(strict=True) == path,
            'input is not a canonical explicit path')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'input is not a regular file')
    require(before.st_size == size and 0 <= size <= per_file_cap,
            'input size changed or exceeds bound')
    require(INPUT_BYTES + size <= INPUT_CAP, 'total input bound exceeded')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        require(stable(os.fstat(fd)) == stable(before), 'input changed at open')
        chunks = []
        remaining = size
        while remaining:
            check_time()
            chunk = os.read(fd, min(remaining, 262144))
            require(bool(chunk), 'input shortened')
            INPUT_BYTES += len(chunk)
            chunks.append(chunk)
            remaining -= len(chunk)
        after = os.fstat(fd)
        require(stable(after) == stable(before) == stable(path.lstat()),
                'input metadata changed during read')
    finally:
        os.close(fd)
    payload = b''.join(chunks)
    digest = hashlib.sha256(payload).hexdigest()
    if expected_sha256 is not None:
        require(digest == expected_sha256, 'input SHA-256 mismatch; stop')
    return payload, dict(source_path=str(path), bytes=size, sha256=digest,
                         expected_sha256=expected_sha256,
                         expected_hash_matched=(expected_sha256 is not None),
                         stat=metadata(before))


def write_new(relative, payload, receipt=False):
    global OUTPUT_BYTES
    if not receipt:
        check_time()
    require(len(payload) <= (RECEIPT_RESERVE if receipt else OUTPUT_CAP),
            'individual output exceeds bound')
    limit = OUTPUT_CAP if receipt else OUTPUT_CAP - RECEIPT_RESERVE
    require(OUTPUT_BYTES + len(payload) <= limit, 'retained output bound exceeded')
    target = OWNER / relative
    require(target.parent == OWNER or target.parent == OWNER / 'generated',
            'output parent outside explicit owner directories')
    space = os.statvfs(OWNER)
    require(space.f_bavail * space.f_frsize >= len(payload) + RECEIPT_RESERVE,
            'insufficient free space for bounded write and receipt')
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        position = 0
        while position < len(payload):
            n = os.write(fd, payload[position:])
            require(n > 0, 'short output write')
            OUTPUT_BYTES += n
            position += n
        os.fsync(fd)
    finally:
        os.close(fd)
    return str(relative)


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def parse_elf(data, expected):
    require(data[:4] == b'\x7fELF', 'missing ELF magic')
    require(data[4] in (1, 2) and data[5] == 1 and data[6] == 1,
            'only known little-endian ELF classes/version accepted')
    bits = 64 if data[4] == 2 else 32
    require(bits == expected['bits'], 'ELF class mismatch')
    header_fmt = '<HHIQQQIHHHHHH' if bits == 64 else '<HHIIIIIHHHHHH'
    header_size = 64 if bits == 64 else 52
    require(len(data) >= header_size, 'ELF header truncated')
    h = struct.unpack_from(header_fmt, data, 16)
    kind, machine, version, entry, phoff, shoff, flags, ehsize, phentsize, phnum, shentsize, shnum, shstrndx = h
    require(kind == 3 and version == 1 and machine == expected['machine'],
            'ELF type/machine/version differs from accepted expectation')
    require(ehsize == header_size, 'unexpected ELF header size')
    expected_phsize = 56 if bits == 64 else 32
    require(phentsize == expected_phsize and 0 < phnum <= 128,
            'program-header count/size outside strict bounds')
    require(phoff >= header_size and phoff + phnum * phentsize <= len(data),
            'program-header table outside file')
    headers = []
    for i in range(phnum):
        v = struct.unpack_from('<IIQQQQQQ' if bits == 64 else '<IIIIIIII',
                               data, phoff + i * phentsize)
        if bits == 64:
            typ, pflags, offset, vaddr, paddr, filesz, memsz, align = v
        else:
            typ, offset, vaddr, paddr, filesz, memsz, pflags, align = v
        require(offset <= len(data) and filesz <= len(data) - offset,
                'program segment outside file')
        if typ == 1:
            require(filesz <= memsz, 'LOAD file size exceeds memory size')
        headers.append(dict(type=typ, flags=pflags, offset=offset, virtual_address=vaddr,
                            physical_address=paddr, file_size=filesz,
                            memory_size=memsz, alignment=align))
    dynamic = [p for p in headers if p['type'] == 2]
    require(len(dynamic) == 1, 'expected exactly one PT_DYNAMIC')
    p = dynamic[0]
    entsize = 16 if bits == 64 else 8
    require(p['file_size'] % entsize == 0 and p['file_size'] // entsize <= 4096,
            'dynamic table count/size outside bound')
    tags = []
    terminated = False
    for offset in range(p['offset'], p['offset'] + p['file_size'], entsize):
        tag, value = struct.unpack_from('<qQ' if bits == 64 else '<iI', data, offset)
        if tag == 0:
            terminated = True
            break
        tags.append((tag, value))
    require(terminated, 'dynamic table lacks DT_NULL')
    strtabs = [v for t, v in tags if t == 5]
    strsizes = [v for t, v in tags if t == 10]
    require(len(strtabs) == len(strsizes) == 1, 'ambiguous dynamic string table')
    address, size = strtabs[0], strsizes[0]
    require(0 < size <= len(data), 'dynamic string size invalid')
    segments = [x for x in headers if x['type'] == 1 and
                x['virtual_address'] <= address and
                address - x['virtual_address'] + size <= x['file_size']]
    require(len(segments) == 1, 'dynamic string table not in one file-backed LOAD')
    base = segments[0]['offset'] + address - segments[0]['virtual_address']
    strings = data[base:base + size]

    def string(value):
        require(0 <= value < size, 'dynamic string offset outside table')
        end = strings.find(b'\0', value, min(size, value + 4097))
        require(end >= value, 'dynamic string absent NUL or exceeds 4096 bytes')
        return strings[value:end].decode('utf-8', errors='strict')

    def values(tag):
        return [string(v) for t, v in tags if t == tag]

    needed, soname, rpath, runpath = values(1), values(14), values(15), values(29)
    require(len(needed) <= 128 and len(soname) <= 1 and len(rpath) <= 1 and len(runpath) <= 1,
            'dynamic dependency/name count outside bound')
    return dict(bits=bits, endian='little', machine=machine, elf_type=kind,
                entry=entry, program_headers=headers, dynamic_entries_before_null=len(tags),
                DT_NEEDED=needed, DT_SONAME=soname[0] if soname else None,
                DT_RPATH=rpath[0] if rpath else None,
                DT_RUNPATH=runpath[0] if runpath else None,
                undefined_symbols_parsed=False,
                interpretation='Dynamic tags only; no dependency resolution, target execution, or inference about static/inline incorporated code')


def main():
    global INPUT_BYTES, OUTPUT_BYTES
    require(OWNER.resolve(strict=True) == OWNER and not OWNER.is_symlink(),
            'owner is not canonical')
    # These are the only preexisting owner files. No directory traversal is used.
    for name in ['readback.py', 'inputs.json', 'prepare.json']:
        s = (OWNER / name).lstat()
        require(stat.S_ISREG(s.st_mode), 'owner input is not regular')
        OUTPUT_BYTES += s.st_size
    require(not (OWNER / 'generated').exists(), 'generated destination already exists')
    raw, plan_meta = read_exact(PLAN, PLAN.stat().st_size, None, 262144)
    plan = json.loads(raw)
    generated = plan['generated_source']['files']
    expected = plan['passive_elf']['expectations']
    require(len(generated) == len(expected) == 13, 'expected exactly 13 + 13 files')
    require(sum(x['bytes'] for x in generated) == 7807417 and
            sum(x['bytes'] for x in expected) == 5107948, 'input totals changed')
    require(len({x['path'] for x in generated}) == len({x['path'] for x in expected}) == 13,
            'duplicate input path')
    verified = []
    for e in expected:
        relative = Path(e['path'])
        require(not relative.is_absolute() and '..' not in relative.parts,
                'unexpected ELF relative path')
        require(relative.parts[:3] == ('usr', 'share', 'fex-emu'), 'unexpected ELF prefix')
        data, receipt = read_exact(ELF_ROOT / relative, e['bytes'], e['sha256'], 2097152)
        verified.append((e, data, receipt))
    # Hash every accepted ELF before parsing or retaining generated source.
    for e, data, receipt in verified:
        receipt['accepted_relative_path'] = e['path']
        receipt['elf'] = parse_elf(data, e)
        ELFS.append(receipt)
    (OWNER / 'generated').mkdir(mode=0o700)
    prefix = '/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/'
    for row in generated:
        path = Path(row['path'])
        require(str(path).startswith(prefix), 'unexpected generated-source prefix')
        rel = str(path)[len(prefix):]
        parts = Path(rel).parts
        require(len(parts) == 3 and parts[0] in ('Guest', 'Guest_32') and parts[1] == 'gen'
                and parts[2].startswith('thunkgen_guest_lib') and parts[2].endswith('.inl'),
                'unexpected generated-source path')
        data, receipt = read_exact(path, row['bytes'], row['sha256'], 4194304)
        data.decode('utf-8', errors='strict')
        receipt['member'] = write_new('generated/' + parts[0] + '-' + parts[2], data)
        receipt['prior_hash_status'] = row['hash_status']
        GENERATED.append(receipt)
    report = dict(scope='Passive source/artifact data inspection under #528; not runtime qualification',
                  distribution_commit='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea',
                  FEX_commit='e869aa644a16e4332cdc15c1ea0b4d13d482385d',
                  disposition_sha256sums='901c51021c68726ac34703072457bc794500e1375ee7f46030f39ff8a3d7aea0',
                  input_plan=plan_meta, elf_root=str(ELF_ROOT), generated_sources=GENERATED,
                  accepted_elf_files=ELFS, binaries_retained=False,
                  no_new_full_inventory=True, generated_to_binary_reproducibility_claim=False,
                  source_bundle_complete=False)
    write_new('readback.json', json_bytes(report))


if __name__ == '__main__':
    signal.signal(signal.SIGALRM, timeout)
    signal.alarm(55)
    rc = 1
    error = None
    try:
        main()
        check_time()
        rc = 0
    except BaseException as exc:
        error = (type(exc).__name__ + ': ' + str(exc))[:2048]
    finally:
        signal.alarm(0)
        result = dict(result='PASS' if rc == 0 else 'FAIL', original_exit_code=rc,
                      start_utc=START_UTC, elapsed_seconds=time.monotonic() - START,
                      pid=os.getpid(), input_bytes_read=INPUT_BYTES,
                      output_bytes_before_receipt=OUTPUT_BYTES,
                      generated_files_retained=len(GENERATED), elf_files_parsed=len(ELFS),
                      last_input=LAST, error=error,
                      bounds=dict(input_bytes=INPUT_CAP, retained_output_bytes=OUTPUT_CAP,
                                  total_seconds=60, work_seconds=55, failure_receipt_bytes=RECEIPT_RESERVE),
                      runtime_qualification=False,
                      actions_excluded=['network', 'listener', 'service', 'VM', 'Nix', 'compiler',
                                        'readelf', 'loader', 'target or acquired-code execution', 'cache traversal'])
        try:
            write_new('result.json', json_bytes(result), receipt=True)
        except BaseException as exc:
            print(json.dumps(dict(result='FAIL_RECEIPT', original_exit_code=rc,
                                  error=(type(exc).__name__ + ': ' + str(exc))[:256])))
            sys.exit(2)
        print(json.dumps(dict(result=result['result'], original_exit_code=rc,
                              elapsed_seconds=result['elapsed_seconds'],
                              input_bytes_read=INPUT_BYTES, output_bytes=OUTPUT_BYTES)))
        sys.exit(rc)

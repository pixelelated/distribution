# Passive FEX generated-source and ELF readback

PASS: original Python process exit **0**, elapsed **0.026758668944239616 seconds**. This was the root-authorized #528 host source/artifact inspection, not runtime qualification. The source-disposition packet remains unchanged.

The reader consumed **12,927,611 bytes**: 13 generated source files (7,807,417 bytes), 13 ELF files (5,107,948 bytes), and the 12,246-byte input plan. All accepted ELF hashes, sizes, classes, and machines match. All five previously retained generated-source hashes match; the other eight now have exact retained bytes and fresh hashes. Every input was read through an exact canonical path with stable device/inode/mode/size/time metadata checks. Source bytes and ELF metadata are retained; ELF binaries are not copied.

| Payloads | Observed DT_NEEDED |
| --- | --- |
| All 13 guest thunks, including both VDSO thunks | `libstdc++.so.6` |
| Both GL thunks, additionally | `libX11.so.6` |
| Both EGL thunks, additionally | `libGL.so.1` |

All 13 have a SONAME and no DT_RPATH or DT_RUNPATH. Exact names, program headers, dynamic-tag counts, input hashes, and metadata are in `readback.json`; `dependency-summary.json` is the compact mapping. The GL/EGL dependencies match the configured link relationships previously recorded, and `libstdc++.so.6` is now observed in the actual accepted payloads, rather than inferred from compiler flags.

These tags identify dynamic names, not which runtime file will satisfy them, whether that file is bundled elsewhere, or what static/inline source was incorporated. Undefined symbols and transitive dependency resolution were outside this bounded readback. Existing guest source/header notice work still applies. No source downloads or patch acquisitions occurred, and this receipt does not mark a source bundle or publication complete.

`generated/` holds all 13 exact generated `.inl` files, with architecture prefixes to preserve their distinct paths. They came from the explicitly named frozen build directories. Their retention and the accepted ELF hash matches do not claim that a rebuild from this packet reproduces those binaries.

`readback.py` uses standard-library byte parsing only: ELF headers, program headers, PT_DYNAMIC, and its mapped string table. It never invokes `readelf`, a loader, Nix, a compiler, target code, acquired code, network, services, a listener, or a VM. Inputs have per-file and total bounds; writes check retained byte limits and reserve receipt space before writing. The work alarm is 55 seconds within the authorized 60-second total, with 20 MiB input and 16 MiB retained-output ceilings. The successful observed run stayed well within all three.

`prepare.json` records the exact script and plan hashes before execution. `result.json` preserves the original elapsed time, exit, counters, and bounds. The tool returned exit 0 independently. `SHA256SUMS` seals the exact source payloads and metadata; generated payload hashes are the hashes computed from the bytes passed to the exclusive bounded writes. The seal is not a fresh second read of the original build files.

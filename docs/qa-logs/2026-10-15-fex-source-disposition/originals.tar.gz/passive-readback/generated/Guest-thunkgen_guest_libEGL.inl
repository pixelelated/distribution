extern "C" {
MAKE_THUNK(libEGL, eglBindAPI, "0x2b, 0x5c, 0x2d, 0x4b, 0x7a, 0x9a, 0xb4, 0xcc, 0x59, 0x3f, 0xb6, 0x39, 0x7c, 0x15, 0x5, 0x20, 0x87, 0x58, 0xb0, 0xc4, 0x7c, 0x10, 0xce, 0x55, 0x7, 0x6d, 0xe2, 0x57, 0xec, 0x8e, 0x41, 0xfb")
MAKE_THUNK(libEGL, eglChooseConfig, "0x1a, 0xdd, 0xe4, 0xc6, 0xf3, 0x3c, 0xf, 0x80, 0x33, 0xfd, 0xd0, 0xe9, 0xd2, 0x2, 0x47, 0x45, 0xb6, 0xac, 0xda, 0x5f, 0x1b, 0x2d, 0x5c, 0x36, 0xea, 0xd5, 0x85, 0xb5, 0xa9, 0xa9, 0x3a, 0x12")
MAKE_THUNK(libEGL, eglDestroyContext, "0x55, 0x2d, 0xda, 0xaf, 0x6c, 0x86, 0x5d, 0xa9, 0x84, 0xe6, 0xf4, 0x8e, 0x5a, 0xa5, 0xd9, 0xf4, 0x24, 0xb2, 0x42, 0xe9, 0xf4, 0x0, 0x86, 0x26, 0x67, 0x9f, 0x89, 0x18, 0x2e, 0x38, 0xf4, 0xfb")
MAKE_THUNK(libEGL, eglDestroySurface, "0xc4, 0x5b, 0x66, 0x7, 0x9a, 0x6c, 0x7, 0xa6, 0x40, 0x33, 0x42, 0x26, 0xb1, 0x51, 0xaf, 0x12, 0xb, 0x30, 0x62, 0x7a, 0xa3, 0x64, 0x17, 0x61, 0xff, 0xd2, 0x92, 0xf0, 0xb1, 0x88, 0xc0, 0x21")
MAKE_THUNK(libEGL, eglInitialize, "0x79, 0xc5, 0x94, 0x7, 0x3d, 0x7f, 0xca, 0xaf, 0x69, 0xa6, 0x20, 0x4, 0xc7, 0xc6, 0xc7, 0xd2, 0x56, 0x2b, 0x82, 0xcf, 0xa9, 0xa1, 0x6d, 0x56, 0xc, 0xb7, 0x1b, 0x26, 0xd6, 0xe5, 0x9c, 0xb")
MAKE_THUNK(libEGL, eglMakeCurrent, "0x74, 0xbe, 0x4c, 0xe5, 0xcd, 0xd2, 0x1f, 0xb0, 0xb, 0xa4, 0x88, 0x6, 0x91, 0xa6, 0x83, 0x3, 0xe9, 0xe1, 0x72, 0xdc, 0xd1, 0x29, 0x5d, 0x5a, 0x22, 0x72, 0x1, 0xca, 0x39, 0xa4, 0x61, 0x4c")
MAKE_THUNK(libEGL, eglQuerySurface, "0xb3, 0xd1, 0x2a, 0x4c, 0x32, 0x4b, 0x41, 0x30, 0x9f, 0x65, 0xe, 0x4a, 0xda, 0xa3, 0x6e, 0x48, 0x5d, 0xd2, 0x42, 0x51, 0xe7, 0xd5, 0x13, 0x7e, 0x5d, 0x72, 0x41, 0x93, 0xd1, 0xa5, 0xd7, 0x33")
MAKE_THUNK(libEGL, eglSurfaceAttrib, "0x39, 0xec, 0x64, 0x47, 0x6e, 0x2f, 0x79, 0xf5, 0x63, 0x8a, 0xa3, 0x5e, 0x63, 0x4c, 0xd8, 0x56, 0x8b, 0xc3, 0x2f, 0x18, 0xdd, 0x64, 0x7d, 0xd1, 0x6a, 0x49, 0xa9, 0x62, 0x23, 0x33, 0x91, 0xc1")
MAKE_THUNK(libEGL, eglSwapBuffers, "0x17, 0x40, 0x76, 0xab, 0x20, 0xba, 0xd8, 0xc5, 0xe5, 0x6d, 0xf0, 0x5e, 0xbb, 0x2b, 0x26, 0x2, 0xa0, 0x61, 0x9, 0x49, 0xd5, 0xf2, 0x23, 0x15, 0x8d, 0xf7, 0x53, 0x27, 0xa4, 0xcc, 0xa, 0x9f")
MAKE_THUNK(libEGL, eglTerminate, "0x4a, 0xd5, 0x8c, 0xfc, 0xb1, 0x91, 0xb8, 0x8a, 0xb5, 0x9e, 0xc5, 0xe7, 0x7b, 0x90, 0xf6, 0x42, 0x1f, 0x8b, 0xe6, 0xc, 0x5b, 0x5, 0xa8, 0xf7, 0x1, 0x67, 0xb9, 0xc1, 0x29, 0xd2, 0x35, 0x40")
MAKE_THUNK(libEGL, eglGetError, "0x6d, 0x35, 0xdc, 0xaf, 0xe5, 0xc7, 0x1a, 0xc3, 0x79, 0x2d, 0x32, 0x19, 0xb3, 0xc7, 0xd1, 0xce, 0xd1, 0xfc, 0x34, 0xda, 0x3f, 0x5a, 0x49, 0x8, 0x59, 0x13, 0x89, 0xaa, 0x59, 0x47, 0x55, 0x96")
MAKE_THUNK(libEGL, eglCreateContext, "0xbb, 0x83, 0x3d, 0xb0, 0x50, 0x33, 0x69, 0x36, 0xba, 0x17, 0x98, 0x21, 0xc1, 0xfa, 0x84, 0x55, 0xcf, 0x47, 0x28, 0xaf, 0xfd, 0x1f, 0x5a, 0xc0, 0x85, 0x49, 0x8e, 0xae, 0x45, 0x69, 0xd4, 0x29")
MAKE_THUNK(libEGL, eglCreateWindowSurface, "0xe0, 0x12, 0x1, 0x13, 0xa2, 0x24, 0xac, 0x9c, 0x40, 0xcf, 0x75, 0x0, 0x5e, 0x68, 0x17, 0xe0, 0x60, 0xf2, 0xd7, 0x25, 0xd1, 0xd3, 0x99, 0xb6, 0xfc, 0xc, 0xfd, 0x5, 0x8d, 0x59, 0x25, 0x71")
MAKE_THUNK(libEGL, eglGetCurrentContext, "0xef, 0xa6, 0x30, 0x1d, 0xd6, 0x76, 0x65, 0xc0, 0xb1, 0x42, 0x64, 0x5f, 0x6d, 0xf8, 0x11, 0x37, 0x62, 0xca, 0x4f, 0xab, 0x2d, 0x12, 0x87, 0x50, 0x96, 0x6f, 0x44, 0xa, 0xd4, 0xce, 0x10, 0x33")
MAKE_THUNK(libEGL, eglGetCurrentDisplay, "0x5a, 0x3, 0x5c, 0xcc, 0xdb, 0xef, 0xaa, 0xfd, 0x78, 0xb6, 0xd3, 0x3c, 0xc9, 0x5f, 0x20, 0xa0, 0xf1, 0x91, 0x22, 0x5e, 0xd0, 0x14, 0xb7, 0x7d, 0xae, 0x30, 0x11, 0xb8, 0x79, 0x6, 0xfd, 0xaa")
MAKE_THUNK(libEGL, eglGetCurrentSurface, "0xc9, 0x40, 0xd5, 0xa9, 0x3a, 0x2a, 0x1b, 0xbc, 0x61, 0x8b, 0x63, 0x21, 0xc9, 0x75, 0x9f, 0x96, 0x1, 0x10, 0xc6, 0xd9, 0x7d, 0xc8, 0x98, 0x85, 0x7b, 0xb, 0x75, 0x18, 0xe9, 0xfb, 0xcd, 0x5")
MAKE_THUNK(libEGL, eglGetDisplay, "0xe8, 0xcc, 0x69, 0xdc, 0xe4, 0xe0, 0xfa, 0xcc, 0xbc, 0x3f, 0xec, 0x96, 0xa5, 0xe1, 0x74, 0x9a, 0x6a, 0x39, 0x63, 0xb3, 0xd0, 0x3c, 0xff, 0x3c, 0xe9, 0x91, 0xa0, 0x1d, 0x56, 0xb5, 0xf7, 0x3")
}
extern "C" {
FEX_PACKFN_LINKAGE auto fexfn_pack_eglBindAPI(EGLenum a_0) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLenum a_0;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libEGL_eglBindAPI(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglChooseConfig(EGLDisplay a_0, const EGLint * a_1, EGLConfig * a_2, EGLint a_3, EGLint * a_4) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    const EGLint * a_1;
    EGLConfig * a_2;
    EGLint a_3;
    EGLint * a_4;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libEGL_eglChooseConfig(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglDestroyContext(EGLDisplay a_0, EGLContext a_1) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLContext a_1;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libEGL_eglDestroyContext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglDestroySurface(EGLDisplay a_0, EGLSurface a_1) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLSurface a_1;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libEGL_eglDestroySurface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglInitialize(EGLDisplay a_0, EGLint * a_1, EGLint * a_2) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLint * a_1;
    EGLint * a_2;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libEGL_eglInitialize(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglMakeCurrent(EGLDisplay a_0, EGLSurface a_1, EGLSurface a_2, EGLContext a_3) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLSurface a_1;
    EGLSurface a_2;
    EGLContext a_3;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libEGL_eglMakeCurrent(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglQuerySurface(EGLDisplay a_0, EGLSurface a_1, EGLint a_2, EGLint * a_3) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLSurface a_1;
    EGLint a_2;
    EGLint * a_3;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libEGL_eglQuerySurface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglSurfaceAttrib(EGLDisplay a_0, EGLSurface a_1, EGLint a_2, EGLint a_3) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLSurface a_1;
    EGLint a_2;
    EGLint a_3;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libEGL_eglSurfaceAttrib(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglSwapBuffers(EGLDisplay a_0, EGLSurface a_1) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLSurface a_1;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libEGL_eglSwapBuffers(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglTerminate(EGLDisplay a_0) -> EGLBoolean {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLBoolean rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libEGL_eglTerminate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglGetError() -> EGLint {
  struct __attribute__((packed)) {
    EGLint rv;
  } args;
  fexthunks_libEGL_eglGetError(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglCreateContext(EGLDisplay a_0, EGLConfig a_1, EGLContext a_2, const EGLint * a_3) -> EGLContext {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLConfig a_1;
    EGLContext a_2;
    const EGLint * a_3;
    EGLContext rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libEGL_eglCreateContext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglCreateWindowSurface(EGLDisplay a_0, EGLConfig a_1, EGLNativeWindowType a_2, const EGLint * a_3) -> EGLSurface {
  struct __attribute__((packed)) {
    EGLDisplay a_0;
    EGLConfig a_1;
    EGLNativeWindowType a_2;
    const EGLint * a_3;
    EGLSurface rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libEGL_eglCreateWindowSurface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglGetCurrentContext() -> EGLContext {
  struct __attribute__((packed)) {
    EGLContext rv;
  } args;
  fexthunks_libEGL_eglGetCurrentContext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglGetCurrentDisplay() -> EGLDisplay {
  struct __attribute__((packed)) {
    EGLDisplay rv;
  } args;
  fexthunks_libEGL_eglGetCurrentDisplay(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglGetCurrentSurface(EGLint a_0) -> EGLSurface {
  struct __attribute__((packed)) {
    EGLint a_0;
    EGLSurface rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libEGL_eglGetCurrentSurface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_eglGetDisplay(EGLNativeDisplayType a_0) -> EGLDisplay {
  struct __attribute__((packed)) {
    EGLNativeDisplayType a_0;
    EGLDisplay rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libEGL_eglGetDisplay(&args);
  return args.rv;
}
}
extern "C" {
__attribute__((alias("fexfn_pack_eglBindAPI"))) auto eglBindAPI(EGLenum a_0) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglChooseConfig"))) auto eglChooseConfig(EGLDisplay a_0, const EGLint * a_1, EGLConfig * a_2, EGLint a_3, EGLint * a_4) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglDestroyContext"))) auto eglDestroyContext(EGLDisplay a_0, EGLContext a_1) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglDestroySurface"))) auto eglDestroySurface(EGLDisplay a_0, EGLSurface a_1) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglInitialize"))) auto eglInitialize(EGLDisplay a_0, EGLint * a_1, EGLint * a_2) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglMakeCurrent"))) auto eglMakeCurrent(EGLDisplay a_0, EGLSurface a_1, EGLSurface a_2, EGLContext a_3) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglQuerySurface"))) auto eglQuerySurface(EGLDisplay a_0, EGLSurface a_1, EGLint a_2, EGLint * a_3) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglSurfaceAttrib"))) auto eglSurfaceAttrib(EGLDisplay a_0, EGLSurface a_1, EGLint a_2, EGLint a_3) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglSwapBuffers"))) auto eglSwapBuffers(EGLDisplay a_0, EGLSurface a_1) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglTerminate"))) auto eglTerminate(EGLDisplay a_0) -> EGLBoolean;
__attribute__((alias("fexfn_pack_eglGetError"))) auto eglGetError() -> EGLint;
__attribute__((alias("fexfn_pack_eglCreateContext"))) auto eglCreateContext(EGLDisplay a_0, EGLConfig a_1, EGLContext a_2, const EGLint * a_3) -> EGLContext;
__attribute__((alias("fexfn_pack_eglCreateWindowSurface"))) auto eglCreateWindowSurface(EGLDisplay a_0, EGLConfig a_1, EGLNativeWindowType a_2, const EGLint * a_3) -> EGLSurface;
__attribute__((alias("fexfn_pack_eglGetCurrentContext"))) auto eglGetCurrentContext() -> EGLContext;
__attribute__((alias("fexfn_pack_eglGetCurrentDisplay"))) auto eglGetCurrentDisplay() -> EGLDisplay;
__attribute__((alias("fexfn_pack_eglGetCurrentSurface"))) auto eglGetCurrentSurface(EGLint a_0) -> EGLSurface;
__attribute__((alias("fexfn_pack_eglGetDisplay"))) auto eglGetDisplay(EGLNativeDisplayType a_0) -> EGLDisplay;
}
#define FOREACH_SYMBOL(EXPAND) \
  EXPAND(eglBindAPI, "TODO") \
  EXPAND(eglChooseConfig, "TODO") \
  EXPAND(eglDestroyContext, "TODO") \
  EXPAND(eglDestroySurface, "TODO") \
  EXPAND(eglInitialize, "TODO") \
  EXPAND(eglMakeCurrent, "TODO") \
  EXPAND(eglQuerySurface, "TODO") \
  EXPAND(eglSurfaceAttrib, "TODO") \
  EXPAND(eglSwapBuffers, "TODO") \
  EXPAND(eglTerminate, "TODO") \
  EXPAND(eglGetError, "TODO") \
  EXPAND(eglCreateContext, "TODO") \
  EXPAND(eglCreateWindowSurface, "TODO") \
  EXPAND(eglGetCurrentContext, "TODO") \
  EXPAND(eglGetCurrentDisplay, "TODO") \
  EXPAND(eglGetCurrentSurface, "TODO") \
  EXPAND(eglGetDisplay, "TODO") \


from pathlib import Path
import collections,hashlib,json,re
P=Path(__file__).resolve().parent;L=json.loads((P/'read-ledger.json').read_text())
def record(s):return next(r for r in L if r['status']=='EXACT_TEXT' and r['path'].endswith(s))
def text(s):return (P/record(s)['member']).read_text()
def data(s):return json.loads(text(s))
def put(n,d):(P/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
fex=data('/artifacts/fex-package.json');installed=data('fex-installed.json');accept=data('/acceptance/artifacts/acceptance.json');consumed=data('admission-consumed.json');proof=record('/artifacts/fex-package.json');assert installed['package_proof_sha256']==proof['sha256'] and installed['files']==fex['files'] and installed['result']=='PASS';assert accept['distribution_commit']=='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea';assert consumed['state']=='consumed' and all(consumed['original_result'][k]==0 for k in ['command_rc','monitor_rc','runner_rc']);assert record('package.mk')['sha256']==fex['recipe_sha256'];assert record('/originals/CMakeCache.txt')['sha256']==fex['cmake_cache_sha256']
for n,key in [('default.nix','default.nix'),('shell.nix','shell.nix'),('lib/.version','.version')]:
 r=next(r for r in L if '/4k79ns9drp02wyvcix81c7nnz4hn8psi-source/' in r['path'] and r['path'].endswith('/'+n));assert r['sha256']==fex['generated_inputs']['nixpkgs_selected_source_sha256'][key]
R='/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d'
header_families={'asound':['alsa-lib','glibc','GCC C++ headers'],'vulkan':['FEX Vulkan-Headers submodule','xorgproto','libx11','libxcb','libxrandr','libxrender','glibc','GCC C++ headers'],'drm':['libdrm','glibc','GCC C++ headers'],'wayland-client':['wayland','glibc','GCC C++ headers'],'VDSO':['glibc','FEX Types.h'],'GL':['libglvnd','xorgproto','libx11','FEX glcorearb.h','glibc','GCC C++ headers'],'EGL':['libglvnd','glibc','GCC C++ headers'],'cuda':['FEX cuda_defines.h (MIT)','glibc','GCC C++ headers']}
rows=[];generated=[];manifests=[]
for directory,bits in [('Guest',64),('Guest_32',32)]:
 manifest=text('/'+directory+'/install_manifest.txt').splitlines();manifests.extend(n.lstrip('/') for n in manifest)
 ninja=text('/'+directory+'/build.ninja');blocks=re.split(r'(?m)^build ',ninja)[1:]
 for dest in manifest:
  basename=Path(dest).name;name=basename.removeprefix('lib').removesuffix('-guest.so');actual=next(f for f in installed['files'] if f['path']==dest.lstrip('/'));assert actual['bits']==bits
  block=next(b for b in blocks if b.splitlines()[0].startswith(basename+': CXX_SHARED_LIBRARY_LINKER'))
  link_lines=[line.strip() for line in block.splitlines()[1:] if line.startswith(('  LANGUAGE_COMPILE_FLAGS =','  LINK_FLAGS =','  LINK_LIBRARIES =','  TARGET_FILE ='))]
  generator=next(line.strip() for line in ninja.splitlines() if line.startswith('  COMMAND =') and ' '+basename.replace('-guest.so','')+' -guest ' in line)
  gp=R+'/.aarch64-rocknix-linux-gnu/'+directory+'/gen/thunkgen_guest_lib'+name+'.inl';s=Path(gp).stat();prior=next((r for r in L if r['path']==gp and r['status']=='EXACT_TEXT'),None)
  gen=dict(path=gp,bytes=s.st_size,sha256=prior['sha256'] if prior else None,retained_text=prior is not None,hash_status='exact retained bytes' if prior else 'stat-only size; payload not read in this source-only scope')
  generated.append(gen);rows.append(dict(installed=actual,install_manifest=record('/'+directory+'/install_manifest.txt'),generated=gen,generator_command=generator,link_configuration=link_lines,header_source_candidates=header_families[name],source_component='FEX e869aa644a16e4332cdc15c1ea0b4d13d482385d',frozen_recipe_sha256=fex['recipe_sha256'],DT_NEEDED_observed=False,dependency_scope='Configured source/header/link inputs; neither 81 Nix packages nor -lstdc++ alone is an observed dynamic shipped dependency'))
assert sorted(manifests)==sorted(f['path'] for f in installed['files'] if 'GuestThunks' in f['path']) and len(rows)==13
put('guest-thunk-map.json',dict(distribution_commit=accept['distribution_commit'],FEX_commit='e869aa644a16e4332cdc15c1ea0b4d13d482385d',accepted_artifact_refs={r['path']:r['sha256'] for r in [proof,record('fex-installed.json'),record('/acceptance/artifacts/acceptance.json'),record('admission-consumed.json')]},native_fex=next(f for f in installed['files'] if f['path']=='usr/bin/FEX'),guest_bytes=sum(r['installed']['bytes'] for r in rows),guest_count=13,rows=rows,parent_manifest_exclusion_claim=False,placeholderX11=dict(built_for_link=True,installed_by_guest_CMake=False,reason='PlaceholderX11 target has no install() rule; both complete nested install manifests omit it; GL explicit SONAME dependency still needs actual ELF readback'),publication_complete=False))
put('generated-source-candidates.json',dict(files=generated,total_bytes=sum(r['bytes'] for r in generated),currently_retained=sum(r['retained_text'] for r in generated),scope='All 13 generated source paths are explicitly named by current Ninja configuration and nested install maps; this packet reads only 5 small ones. No generated binary was executed.'))
D=data('derivation-custody.json');drv=json.loads((P/'parsed-derivations.json').read_text());scope=data('readback.json');families={'glibc','gcc','i686-unknown-linux-gnu-gcc','libgcc-i686-unknown-linux-gnu','compiler-rt-libc','linux-headers','alsa-lib','libdrm','libglvnd','wayland','libx11','libxcb','libxrandr','libxrender','xorgproto','libxext','libxau','libxdmcp'};candidates=[]
for d in drv:
 e=d['environment'];pn=e.get('pname');
 if pn not in families:continue
 fetch=[dict(path=x[0],outputs=x[1]) for x in d['input_derivations'] if any(s in x[0] for s in ['source.drv','-src-','.tar.'])]
 candidates.append(dict(package=pn,version=e.get('version'),derivation_path=d['path'],derivation_sha256=d['sha256'],source_store_path=e.get('src'),source_root=e.get('sourceRoot'),patch_store_paths=e.get('patches','').split(),fetch_derivations=fetch,source_acquired=False,role='Candidate headers/runtime support selected by guest sysroot or implicit compiler support; retain source/patch/notices for scoped generated-output assessment, not a claim this package is itself shipped'))
put('source-acquisition-candidates.json',dict(nixpkgs=dict(commit='b6018f87da91d19d0ab4cf979885689b469cdd41',url=fex['nixpkgs_url'],resolved_store=fex['generated_inputs']['nixpkgs_resolved_path'],selected_source_hashes=fex['generated_inputs']['nixpkgs_selected_source_sha256'],archive_acquired=False,archive_sha256=None),candidate_derivations=candidates,missing_direct_derivations=[r for r in D['derivations'] if r['status']=='MISSING'],scope='Exact retained derivation source/patch references; fetch derivations have not yet been read, no URLs/hashes invented, no recursive acquisition or Nix evaluation.'))
closure=[]
for r in scope['referenced_store_paths']:
 name=Path(r['path']).name[33:]
 if name.startswith(('toolchain_nix','fex-dev-rootfs')):role='generated development configuration/rootfs'
 elif any(s in name for s in ['glibc','gcc','compiler-rt','linux-headers']):role='C/C++ headers and possible runtime support; actual inclusion remains scoped'
 elif name.startswith(('alsa-lib','libdrm','libglvnd','wayland','libx11','libxcb','libxrandr','libxrender','xorgproto','libxext','libxau','libxdmcp')):role='API header/dev-rootfs provider or its library output; not automatically shipped'
 elif any(s in name for s in ['clang','llvm','binutils']):role='compiler/linker and their host libraries; build closure, not guest inventory'
 else:role='transitive build/development closure; no shipped inference'
 closure.append(dict(path=r['path'],deriver=r['deriver'],name=name,role=role,nar_hash_is_metadata_only=True,shipped_claim=False))
put('nix-closure-disposition.json',dict(rows=closure,counts=dict(collections.Counter(r['role'] for r in closure)),observed_store_rows=len(closure),shipped_package_count_inferred=None,scope='Classifies roles without turning 81 current reference rows into 81 distributed components.'))
print(json.dumps(dict(guest_count=len(rows),guest_bytes=sum(r['installed']['bytes'] for r in rows),generated_bytes=sum(r['bytes'] for r in generated),candidates=len(candidates),closure_counts=dict(collections.Counter(r['role'] for r in closure))),indent=2))

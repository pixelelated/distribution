from pathlib import Path
import argparse,datetime,hashlib,json,stat
O=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('paths',nargs='+');a=p.parse_args()
l=O/'read-ledger.json';rows=json.loads(l.read_text()) if l.exists() else []
for name in a.paths:
 path=Path(name);assert path.is_absolute() and len(name)<4096
 if any(r['path']==name for r in rows):continue
 assert len(rows)<256
 try:
  s=path.lstat();assert stat.S_ISREG(s.st_mode) and path.resolve(strict=True)==path and s.st_size<=1024*1024
 except FileNotFoundError:
  rows.append(dict(path=name,status='ABSENT_NAMED_PATH'));l.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n');continue
 assert sum(r.get('bytes',0) for r in rows)+s.st_size<=8*1024**2
 raw=path.read_bytes();assert len(raw)==s.st_size and all(getattr(path.lstat(),k)==getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']) and b'\0' not in raw
 h=hashlib.sha256(raw).hexdigest();dest=O/'originals'/(h+'-'+path.name)
 if not dest.exists():dest.write_bytes(raw)
 rows.append(dict(path=name,bytes=len(raw),sha256=h,member=str(dest.relative_to(O)),status='EXACT_TEXT',mtime_ns=s.st_mtime_ns));l.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
l.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(named_files=len(rows),bytes=sum(r.get('bytes',0) for r in rows),present=sum(r['status']=='EXACT_TEXT' for r in rows))))

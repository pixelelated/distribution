extern "C" {
MAKE_THUNK(libvulkan, vkGetDeviceProcAddr, "0xb9, 0x1f, 0x7b, 0x53, 0x48, 0xee, 0xb1, 0x5f, 0xd7, 0x6d, 0xb2, 0x28, 0xd2, 0x89, 0xc6, 0xbf, 0xb1, 0x6c, 0x95, 0xdd, 0x3b, 0x5f, 0xad, 0xb4, 0xb4, 0x8c, 0x16, 0x73, 0x62, 0x8b, 0xd0, 0x3f")
MAKE_THUNK(libvulkan, vkGetInstanceProcAddr, "0xe1, 0x5b, 0x95, 0x28, 0xe8, 0x16, 0xb2, 0xea, 0xc7, 0xbf, 0x6e, 0x30, 0x8e, 0x90, 0x63, 0x8e, 0xf3, 0xfb, 0xb3, 0xc0, 0xe5, 0xdf, 0xc4, 0xaf, 0x97, 0x49, 0x51, 0x81, 0xe4, 0xec, 0x4f, 0x6b")
MAKE_THUNK(libvulkan, Vulkan_SetGuestXSync, "0xc6, 0x3c, 0xad, 0xda, 0x36, 0xd7, 0x7d, 0x37, 0xc2, 0x76, 0xa, 0xd, 0x70, 0x40, 0xd4, 0xbd, 0x8c, 0x1, 0x48, 0x2e, 0xeb, 0xd2, 0xd3, 0x74, 0xf1, 0xac, 0x75, 0x7d, 0xfc, 0x85, 0xa7, 0x2e")
MAKE_THUNK(libvulkan, Vulkan_SetGuestXGetVisualInfo, "0xf0, 0x30, 0x51, 0x97, 0x6e, 0xb1, 0x6e, 0x4, 0x3f, 0x83, 0x8e, 0xcd, 0xb, 0xe1, 0xcf, 0xc5, 0xfd, 0xd7, 0xc, 0x14, 0x18, 0x65, 0x1f, 0xc3, 0x61, 0x24, 0xa5, 0xcd, 0x9c, 0xa0, 0xc0, 0xc1")
MAKE_THUNK(libvulkan, Vulkan_SetGuestXDisplayString, "0xe1, 0xf5, 0x74, 0x80, 0xc, 0xdd, 0xb4, 0x74, 0x67, 0x5d, 0x4f, 0x4c, 0x91, 0xc1, 0x86, 0x4, 0x7e, 0xfe, 0xcb, 0x9e, 0x26, 0x51, 0xb7, 0x32, 0x56, 0xe9, 0xee, 0xd6, 0x61, 0x86, 0x8e, 0x5a")
MAKE_THUNK(libvulkan, vkCreateInstance, "0x6, 0x6d, 0xc8, 0xcb, 0xdd, 0x71, 0x1e, 0x59, 0xd1, 0xd5, 0xc1, 0x47, 0x44, 0x50, 0xf5, 0xa1, 0x68, 0xe7, 0x40, 0x36, 0x75, 0xd7, 0xe0, 0xfe, 0x59, 0x7d, 0xd2, 0x40, 0xf2, 0x8e, 0x69, 0x3a")
MAKE_THUNK(libvulkan, vkDestroyInstance, "0xd8, 0x2d, 0xd7, 0x82, 0x6c, 0xf, 0x8a, 0xe9, 0x6d, 0xb6, 0xd4, 0x62, 0xcf, 0x25, 0x82, 0x80, 0x28, 0x28, 0x84, 0x4a, 0x3b, 0x77, 0xd8, 0x2b, 0x3d, 0xcf, 0xa8, 0x24, 0xef, 0xb0, 0xd4, 0x47")
MAKE_THUNK(libvulkan, vkEnumeratePhysicalDevices, "0xbd, 0x9b, 0x41, 0x99, 0xfe, 0xe5, 0x59, 0x1b, 0x60, 0x8c, 0x6, 0xae, 0x66, 0x55, 0xf, 0xba, 0xaf, 0xce, 0x51, 0x9, 0xca, 0x43, 0x37, 0x52, 0x52, 0xa, 0x9d, 0x74, 0xe2, 0x36, 0xef, 0xec")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceFeatures, "0xb, 0xd5, 0xf2, 0xa7, 0x4f, 0x2c, 0x68, 0x5d, 0x44, 0x19, 0xa1, 0xb6, 0xcf, 0x30, 0x8d, 0x4e, 0x4b, 0x44, 0xea, 0xe2, 0x8c, 0x3a, 0xbf, 0xd9, 0xa4, 0xb1, 0x58, 0x96, 0x31, 0x80, 0xa, 0xfd")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceFormatProperties, "0x4c, 0xe, 0x37, 0xcc, 0xcb, 0xf1, 0x35, 0x8d, 0xd9, 0x87, 0x9a, 0x20, 0x3a, 0x76, 0xb0, 0xb2, 0x68, 0x73, 0xa5, 0x9, 0x23, 0x61, 0x3c, 0xbd, 0x1a, 0x44, 0x0, 0xa9, 0x49, 0x8f, 0xfd, 0x44")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceImageFormatProperties, "0x7a, 0xc4, 0x38, 0x1c, 0x31, 0x79, 0xfd, 0xf2, 0x42, 0x94, 0xcc, 0xa8, 0x3b, 0x26, 0x5f, 0xeb, 0xc5, 0x85, 0x4, 0x61, 0x2a, 0xf6, 0xe4, 0xd2, 0xa0, 0x69, 0x12, 0xc5, 0xc6, 0xe9, 0x8a, 0x1c")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceProperties, "0x7, 0x18, 0xde, 0x64, 0x1b, 0x2f, 0xdf, 0x38, 0x8, 0x8c, 0xe0, 0x3c, 0x5d, 0xfe, 0xd1, 0xb1, 0xb2, 0xd3, 0x94, 0xfe, 0x9f, 0xe2, 0x77, 0x34, 0x64, 0x22, 0xcd, 0xb5, 0x94, 0xbe, 0xaa, 0xbe")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceQueueFamilyProperties, "0xb1, 0xe9, 0x65, 0xdc, 0xe, 0x5e, 0xa3, 0xc5, 0xa4, 0x96, 0x56, 0x95, 0x5, 0x31, 0xce, 0x40, 0x1a, 0x32, 0xd0, 0xb7, 0x6, 0xe4, 0x24, 0xef, 0xe2, 0x9, 0xb5, 0xd2, 0x3c, 0x8b, 0xe1, 0xd0")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceMemoryProperties, "0x46, 0x8a, 0xe, 0xe1, 0xc3, 0xdb, 0x71, 0x8f, 0xf, 0xa3, 0x3, 0xc4, 0xf2, 0xc4, 0x66, 0xc4, 0x26, 0xbf, 0xd, 0x10, 0x83, 0xa6, 0xb2, 0x11, 0x21, 0xa6, 0x42, 0x3, 0x82, 0xd0, 0x83, 0xf3")
MAKE_THUNK(libvulkan, vkCreateDevice, "0xad, 0x4c, 0x20, 0x6a, 0x0, 0xdc, 0x58, 0x93, 0x51, 0xa2, 0x7a, 0x50, 0xeb, 0xc8, 0xe8, 0x94, 0xab, 0xf5, 0x64, 0x8d, 0x66, 0x83, 0xa, 0xf4, 0xd8, 0x6c, 0x92, 0x4d, 0xa2, 0xbb, 0x41, 0xd9")
MAKE_THUNK(libvulkan, vkDestroyDevice, "0xc1, 0x16, 0x59, 0xb2, 0x2f, 0x62, 0x8b, 0x91, 0x5c, 0x8d, 0x7b, 0xa1, 0x59, 0xc3, 0x11, 0xa4, 0x20, 0x93, 0x25, 0x8b, 0xc0, 0x48, 0x86, 0x83, 0x27, 0x2e, 0x14, 0xe2, 0xb4, 0x3c, 0x2c, 0x49")
MAKE_THUNK(libvulkan, vkEnumerateInstanceExtensionProperties, "0xab, 0xc9, 0x94, 0x66, 0x93, 0xd1, 0xfb, 0xf3, 0xdb, 0xd6, 0x3e, 0xe7, 0xdf, 0x5b, 0x89, 0xe3, 0xc8, 0x63, 0x5e, 0xc1, 0x9e, 0x65, 0x49, 0xd1, 0x51, 0xf3, 0xb4, 0xb5, 0xa, 0x15, 0x99, 0x7c")
MAKE_THUNK(libvulkan, vkEnumerateDeviceExtensionProperties, "0x41, 0x89, 0xae, 0x65, 0xb6, 0x3, 0xbb, 0x29, 0xbd, 0xb, 0xd7, 0x86, 0x79, 0x8d, 0xa6, 0x20, 0xdb, 0xa8, 0xae, 0x1e, 0xea, 0xfb, 0x27, 0xa0, 0x9, 0xf4, 0x25, 0x3d, 0x42, 0xf5, 0x6e, 0xbd")
MAKE_THUNK(libvulkan, vkEnumerateInstanceLayerProperties, "0x8b, 0x20, 0xd5, 0x51, 0x7b, 0x37, 0xdf, 0x58, 0x36, 0xec, 0xbd, 0x4c, 0x70, 0xbf, 0x7f, 0x64, 0x3b, 0x84, 0x3, 0xc2, 0x70, 0xe6, 0xd6, 0xa1, 0xce, 0xa3, 0x17, 0x77, 0xab, 0xcd, 0x9b, 0xa1")
MAKE_THUNK(libvulkan, vkEnumerateDeviceLayerProperties, "0xb5, 0xcc, 0xe6, 0xa7, 0x7e, 0x7b, 0x1e, 0xef, 0x90, 0xab, 0x4e, 0xff, 0x4e, 0x1, 0x88, 0x7b, 0x7, 0xa2, 0x67, 0xfe, 0xb9, 0x76, 0x41, 0x15, 0x87, 0x5d, 0xe3, 0x75, 0xf, 0xc8, 0xc6, 0xa8")
MAKE_THUNK(libvulkan, vkGetDeviceQueue, "0xeb, 0x12, 0xd5, 0x7, 0xd, 0x1e, 0x90, 0x40, 0xa6, 0x5d, 0x94, 0x7, 0xeb, 0x5b, 0x5e, 0xfd, 0xcc, 0xd, 0x3d, 0x17, 0x94, 0xe1, 0x5b, 0x1e, 0xca, 0xdd, 0x61, 0x9c, 0xfd, 0x94, 0xe2, 0xc2")
MAKE_THUNK(libvulkan, vkQueueSubmit, "0xfb, 0xbd, 0xb0, 0x7e, 0xd7, 0x55, 0x98, 0x9f, 0x9f, 0xdb, 0x9f, 0xa2, 0x96, 0x31, 0x14, 0x75, 0xd4, 0x10, 0x8a, 0xc4, 0x22, 0xa1, 0xed, 0x5c, 0xeb, 0xbe, 0x6b, 0x22, 0x64, 0xdd, 0xa5, 0x24")
MAKE_THUNK(libvulkan, vkQueueWaitIdle, "0xe1, 0x3c, 0x6e, 0x31, 0xbf, 0xe3, 0x6c, 0xc9, 0xa7, 0x41, 0x81, 0x80, 0x0, 0xf0, 0x49, 0x32, 0x20, 0xad, 0xf5, 0x14, 0xae, 0x67, 0xe0, 0x7b, 0xf3, 0x7e, 0xa6, 0x1, 0xf9, 0x62, 0x3d, 0xd")
MAKE_THUNK(libvulkan, vkDeviceWaitIdle, "0x35, 0x33, 0x27, 0xeb, 0x51, 0x21, 0xfc, 0x4a, 0x4c, 0xb6, 0xae, 0xeb, 0xa5, 0x5, 0x2c, 0xe5, 0x5e, 0xc3, 0x56, 0xc8, 0x8a, 0xe8, 0xab, 0x17, 0xce, 0x88, 0x3c, 0x90, 0x11, 0x5b, 0x73, 0x9c")
MAKE_THUNK(libvulkan, vkAllocateMemory, "0x64, 0x9e, 0x1e, 0x67, 0xd6, 0xa, 0x3, 0x7e, 0x90, 0x1c, 0x60, 0xb1, 0x37, 0x1c, 0x8b, 0x8, 0x6, 0x77, 0x23, 0xec, 0x39, 0xf6, 0xe1, 0x70, 0xb8, 0xf2, 0xa5, 0x56, 0xf5, 0x7, 0x8e, 0x56")
MAKE_THUNK(libvulkan, vkFreeMemory, "0x16, 0x38, 0xd7, 0xdb, 0x9f, 0x62, 0xcc, 0xf6, 0x76, 0x13, 0x32, 0x5e, 0x8, 0xba, 0xd2, 0x95, 0xa9, 0xfd, 0xe2, 0xa6, 0xab, 0x11, 0x66, 0xc8, 0x9c, 0xab, 0x84, 0xca, 0xaa, 0xd5, 0xa, 0x86")
MAKE_THUNK(libvulkan, vkMapMemory, "0x10, 0xdc, 0x8f, 0x6f, 0x64, 0x12, 0x38, 0xbe, 0x2d, 0xc3, 0xae, 0x6, 0x34, 0xbd, 0x3, 0x2f, 0x72, 0x24, 0xbe, 0x3d, 0x6a, 0x71, 0x70, 0xe3, 0xed, 0x7b, 0x74, 0x7a, 0xa4, 0x3f, 0xda, 0x1d")
MAKE_THUNK(libvulkan, vkUnmapMemory, "0x88, 0xf1, 0x16, 0x6, 0x46, 0xe7, 0x81, 0x22, 0xdb, 0xfd, 0x9e, 0x8a, 0x53, 0x66, 0xc7, 0x5, 0xc5, 0xf8, 0x33, 0x42, 0xd6, 0xb5, 0x2e, 0x3d, 0xd4, 0x74, 0xa4, 0xcc, 0x1, 0xa1, 0xf1, 0x3")
MAKE_THUNK(libvulkan, vkFlushMappedMemoryRanges, "0xc2, 0xca, 0x3f, 0xb, 0x70, 0x52, 0x9d, 0x8e, 0x70, 0x62, 0xce, 0xfc, 0x94, 0xa5, 0xa7, 0xe5, 0xd7, 0x36, 0x54, 0x54, 0xbb, 0xb1, 0x76, 0x37, 0xd5, 0x5f, 0xac, 0xeb, 0xb8, 0x90, 0x8a, 0xdd")
MAKE_THUNK(libvulkan, vkInvalidateMappedMemoryRanges, "0xcc, 0xbb, 0x73, 0x40, 0xca, 0x92, 0x1d, 0x28, 0xb9, 0x70, 0x9a, 0xe1, 0xa1, 0x59, 0xe0, 0xa9, 0xee, 0x24, 0x60, 0xdd, 0xf2, 0xae, 0xf6, 0x30, 0xb0, 0xaa, 0xd1, 0xce, 0xf9, 0x1a, 0x66, 0xa")
MAKE_THUNK(libvulkan, vkGetDeviceMemoryCommitment, "0x10, 0xfa, 0x84, 0x73, 0x78, 0x9b, 0x9b, 0x4, 0x9, 0x41, 0x5c, 0x1b, 0x2a, 0xea, 0x76, 0xd2, 0x85, 0xaa, 0xe8, 0xca, 0xf2, 0x34, 0x5, 0x4f, 0x9e, 0xb9, 0x57, 0x40, 0x5d, 0xa3, 0xf, 0xa7")
MAKE_THUNK(libvulkan, vkBindBufferMemory, "0xaa, 0xf2, 0x88, 0x34, 0xfc, 0x7a, 0x0, 0x68, 0xb3, 0xac, 0xa2, 0x2a, 0xc, 0x2d, 0xb, 0xcd, 0x54, 0xf, 0x8b, 0xfb, 0xb8, 0x20, 0x40, 0x98, 0x42, 0x2b, 0xfc, 0xdf, 0x89, 0x57, 0xf6, 0x77")
MAKE_THUNK(libvulkan, vkBindImageMemory, "0xa2, 0xbd, 0x78, 0x95, 0xb3, 0x7e, 0x3c, 0xc4, 0xb1, 0x2d, 0x6c, 0x98, 0x3f, 0xf3, 0x1f, 0xc4, 0x4, 0x72, 0x56, 0xec, 0x76, 0x34, 0x4c, 0x9f, 0xeb, 0x4, 0xc1, 0x45, 0xe0, 0xed, 0xce, 0xbe")
MAKE_THUNK(libvulkan, vkGetBufferMemoryRequirements, "0xaf, 0xed, 0x70, 0x7f, 0xc1, 0x2f, 0xe5, 0x13, 0x4e, 0x7c, 0x14, 0x6f, 0xc9, 0xf1, 0x40, 0x13, 0xe6, 0x8b, 0x2a, 0x37, 0xbe, 0x5d, 0xcc, 0x91, 0x53, 0x8d, 0x9f, 0xf9, 0x7d, 0x45, 0xf, 0x88")
MAKE_THUNK(libvulkan, vkGetImageMemoryRequirements, "0x44, 0xd0, 0xb1, 0xd, 0x3a, 0x95, 0x82, 0x7, 0xd6, 0xd3, 0xf7, 0x85, 0x4b, 0x39, 0x38, 0xef, 0xd2, 0xf8, 0xd0, 0x58, 0x1b, 0x6e, 0x52, 0xf4, 0x7d, 0xad, 0x39, 0x16, 0xfc, 0x93, 0xae, 0x89")
MAKE_THUNK(libvulkan, vkGetImageSparseMemoryRequirements, "0x52, 0x32, 0xd2, 0x1b, 0xcd, 0x87, 0x13, 0x16, 0x34, 0xb7, 0x47, 0xb, 0xb8, 0xf7, 0xd4, 0xa2, 0x28, 0xc, 0x76, 0x25, 0x60, 0x2c, 0xbe, 0x9, 0xbc, 0xd9, 0xc, 0xa9, 0xef, 0x5, 0xc2, 0xf7")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSparseImageFormatProperties, "0xd6, 0xf, 0x82, 0x5d, 0xab, 0xb8, 0x50, 0xa8, 0xcc, 0x3d, 0x5c, 0x75, 0x79, 0xd9, 0x59, 0x1e, 0x98, 0x8b, 0x1f, 0x9b, 0x1a, 0x7f, 0xd6, 0x44, 0x74, 0x37, 0xc, 0x1d, 0x49, 0x15, 0x2f, 0x10")
MAKE_THUNK(libvulkan, vkQueueBindSparse, "0x36, 0x75, 0x86, 0x5e, 0x9c, 0x28, 0x69, 0x4c, 0x74, 0x50, 0x3c, 0xe7, 0xb3, 0xcd, 0x8e, 0x81, 0x53, 0x55, 0x8a, 0xaf, 0x8b, 0xe7, 0xb3, 0xdf, 0xff, 0x16, 0xd, 0x4c, 0xe9, 0x4e, 0xc9, 0x8e")
MAKE_THUNK(libvulkan, vkCreateFence, "0xe6, 0x6d, 0x50, 0xed, 0x44, 0x68, 0xf4, 0xce, 0x98, 0xb8, 0xba, 0xf1, 0xa5, 0x4e, 0x17, 0xc6, 0xbe, 0x92, 0xba, 0x45, 0xc3, 0x8, 0xf1, 0x4, 0x33, 0xe8, 0x70, 0xe0, 0x37, 0xb8, 0xf1, 0xea")
MAKE_THUNK(libvulkan, vkDestroyFence, "0x5a, 0xfb, 0x14, 0x24, 0x8, 0xbe, 0xbe, 0x7e, 0xa3, 0x5d, 0xff, 0x25, 0xb3, 0x6e, 0x12, 0xe9, 0x1, 0xb9, 0x39, 0xff, 0x2a, 0x97, 0xec, 0xb8, 0xbd, 0x84, 0x2a, 0xd1, 0x1f, 0xa5, 0x30, 0x41")
MAKE_THUNK(libvulkan, vkResetFences, "0x67, 0x82, 0x5b, 0x65, 0x29, 0x19, 0xe1, 0x1f, 0xf1, 0x2a, 0xe0, 0x4b, 0xab, 0xde, 0x4e, 0x6c, 0x95, 0x15, 0x36, 0x79, 0x9a, 0xd5, 0xe, 0x55, 0x8, 0xcf, 0x16, 0x53, 0x66, 0x86, 0xaf, 0x29")
MAKE_THUNK(libvulkan, vkGetFenceStatus, "0x78, 0x49, 0xb4, 0x26, 0x1f, 0xea, 0x96, 0xd, 0x68, 0x35, 0x4e, 0xd1, 0x1b, 0xad, 0x22, 0x5b, 0x3f, 0x34, 0x1f, 0xac, 0x27, 0x21, 0xf9, 0xce, 0x7b, 0x10, 0xf4, 0xf9, 0x36, 0xd0, 0xa, 0x85")
MAKE_THUNK(libvulkan, vkWaitForFences, "0xc6, 0x53, 0x6f, 0xb5, 0xa4, 0x49, 0x6f, 0x16, 0xe, 0xe4, 0x19, 0xbf, 0x8, 0x95, 0x53, 0x1a, 0x64, 0x4c, 0x71, 0x23, 0x31, 0x4a, 0xc3, 0x69, 0x11, 0xae, 0x98, 0x74, 0x8f, 0x85, 0xdf, 0xf3")
MAKE_THUNK(libvulkan, vkCreateSemaphore, "0x28, 0xf1, 0x53, 0xfa, 0x7e, 0x60, 0x9f, 0x2d, 0xdb, 0x50, 0x39, 0x3f, 0x6b, 0xb6, 0xe7, 0x2, 0xc0, 0xe6, 0x44, 0x4c, 0x66, 0x56, 0x78, 0x22, 0x44, 0x7c, 0xf, 0xf2, 0xe8, 0xaf, 0x88, 0x79")
MAKE_THUNK(libvulkan, vkDestroySemaphore, "0x43, 0x14, 0xd1, 0xf5, 0xb7, 0xcb, 0x19, 0xea, 0xa3, 0x42, 0x2d, 0x76, 0x44, 0xec, 0x43, 0xf5, 0x8, 0xc2, 0xe1, 0xc, 0x5c, 0xc, 0xbd, 0xdc, 0xec, 0xea, 0x95, 0xd2, 0x51, 0xf3, 0xe8, 0x96")
MAKE_THUNK(libvulkan, vkCreateQueryPool, "0x92, 0x81, 0x8a, 0x2d, 0x43, 0xaf, 0xfb, 0xca, 0x3, 0xf6, 0x15, 0x23, 0x51, 0x6b, 0x1d, 0x40, 0x70, 0xa2, 0x63, 0x76, 0x8e, 0xad, 0xb8, 0xc0, 0xc6, 0x8f, 0x86, 0x4c, 0xe3, 0xa7, 0x2a, 0xfd")
MAKE_THUNK(libvulkan, vkDestroyQueryPool, "0xa1, 0xb9, 0x10, 0x33, 0x56, 0x16, 0x5d, 0xc1, 0x49, 0x1f, 0x29, 0xc1, 0x56, 0x48, 0xda, 0x41, 0x8b, 0x69, 0x53, 0x9a, 0x7c, 0xdc, 0x97, 0x8a, 0xf0, 0xd3, 0x7e, 0x88, 0xdb, 0xb7, 0x4, 0x12")
MAKE_THUNK(libvulkan, vkGetQueryPoolResults, "0xb4, 0x4f, 0x7e, 0x8e, 0xee, 0xc1, 0x1c, 0x85, 0xa8, 0x6d, 0xa5, 0xd4, 0xdd, 0x71, 0xea, 0x53, 0xb5, 0xa7, 0xb0, 0x8e, 0xce, 0x7c, 0x9d, 0xe6, 0xa2, 0x67, 0x7f, 0x75, 0x73, 0xa, 0x0, 0x59")
MAKE_THUNK(libvulkan, vkCreateBuffer, "0xce, 0x8a, 0x69, 0xa8, 0x8d, 0x76, 0xbb, 0xc6, 0xd0, 0xf, 0x85, 0x83, 0xfa, 0xff, 0x5f, 0x21, 0x38, 0x91, 0xb2, 0xd8, 0x5b, 0x63, 0xc9, 0x34, 0xad, 0x45, 0x60, 0x1f, 0x58, 0xea, 0x99, 0x6c")
MAKE_THUNK(libvulkan, vkDestroyBuffer, "0x1b, 0xd5, 0xa1, 0xda, 0x14, 0xa3, 0x1f, 0x8, 0x84, 0xcc, 0x86, 0xa1, 0x7c, 0x12, 0xec, 0x87, 0xd4, 0x2, 0x35, 0x64, 0x4e, 0xc6, 0xb2, 0x1f, 0xaa, 0xba, 0xd2, 0x7d, 0xb2, 0x1a, 0xf1, 0xe1")
MAKE_THUNK(libvulkan, vkCreateImage, "0xfb, 0xb8, 0xe9, 0xf6, 0x4, 0x91, 0xda, 0x1d, 0x7a, 0xf2, 0xe, 0x2f, 0x4d, 0x2e, 0x6, 0x54, 0xe3, 0xcb, 0x62, 0x3d, 0xc9, 0x7, 0x18, 0x46, 0x84, 0xd0, 0x30, 0xf9, 0xed, 0x40, 0xd, 0x61")
MAKE_THUNK(libvulkan, vkDestroyImage, "0x81, 0xe3, 0x9, 0x88, 0x9, 0xbd, 0x58, 0xac, 0xc9, 0xe8, 0x8c, 0xbd, 0xfc, 0xa1, 0x1a, 0xe9, 0x1b, 0x30, 0x37, 0x15, 0x69, 0xa4, 0xc8, 0xd2, 0x9f, 0xbf, 0x25, 0xd1, 0x96, 0x9d, 0xec, 0x67")
MAKE_THUNK(libvulkan, vkGetImageSubresourceLayout, "0x4, 0xb8, 0x6d, 0xaf, 0xc9, 0xe8, 0xe6, 0xe7, 0xba, 0xdf, 0xfd, 0xc1, 0xed, 0x87, 0x9f, 0x7c, 0x41, 0xdb, 0xd7, 0x76, 0xb7, 0xd9, 0xd8, 0xe2, 0x61, 0x74, 0xc9, 0x38, 0xcd, 0x72, 0x2a, 0x1b")
MAKE_THUNK(libvulkan, vkCreateImageView, "0x6a, 0xfa, 0x18, 0x78, 0xac, 0x62, 0x28, 0x4f, 0xf4, 0x41, 0x1a, 0xe9, 0x4e, 0x68, 0x47, 0xda, 0x4c, 0x1d, 0x37, 0x3d, 0xf1, 0xc6, 0x51, 0xc4, 0xe0, 0x29, 0xf2, 0xf0, 0xc2, 0x9c, 0x8, 0x62")
MAKE_THUNK(libvulkan, vkDestroyImageView, "0xb0, 0x2a, 0xf5, 0xdf, 0x86, 0x5a, 0x5f, 0x5a, 0xf6, 0x9, 0x65, 0x96, 0xdf, 0xf5, 0xce, 0xcb, 0xfd, 0x1b, 0x18, 0xcb, 0x1d, 0x2a, 0xdd, 0xab, 0x59, 0x82, 0xbe, 0x7d, 0xe4, 0xb2, 0x83, 0x46")
MAKE_THUNK(libvulkan, vkCreateCommandPool, "0x61, 0xfe, 0xaa, 0x56, 0x9a, 0xc6, 0x7d, 0x1a, 0x7d, 0x43, 0x6c, 0xc0, 0x7a, 0xdb, 0x6, 0xab, 0x1f, 0x79, 0xad, 0x3a, 0x75, 0x9b, 0xbd, 0xf5, 0x26, 0xbb, 0xb0, 0x49, 0xac, 0xcc, 0xba, 0xa0")
MAKE_THUNK(libvulkan, vkDestroyCommandPool, "0x78, 0xa8, 0x27, 0xbf, 0xb0, 0x92, 0x1d, 0x44, 0x4d, 0xe6, 0x60, 0xfe, 0xfb, 0xa3, 0x81, 0x1d, 0xb5, 0x6, 0x9b, 0x5d, 0x90, 0x58, 0x43, 0xae, 0xb, 0x13, 0xa2, 0x9e, 0x81, 0xaa, 0x27, 0xa3")
MAKE_THUNK(libvulkan, vkResetCommandPool, "0x25, 0x97, 0xde, 0x96, 0x5e, 0x7e, 0x5b, 0x50, 0xd4, 0xa1, 0x74, 0xab, 0x89, 0x44, 0xd9, 0x42, 0xd9, 0xda, 0xf8, 0x88, 0xf1, 0x71, 0x8d, 0xfe, 0x24, 0x61, 0x7c, 0xb0, 0x21, 0x2d, 0x2a, 0x2e")
MAKE_THUNK(libvulkan, vkAllocateCommandBuffers, "0x13, 0x87, 0x44, 0x54, 0x5f, 0x1a, 0xb5, 0xe5, 0x88, 0x6c, 0x75, 0x40, 0xb4, 0x69, 0x86, 0x3b, 0x2a, 0x3, 0x2e, 0x9e, 0x25, 0x6c, 0xbc, 0xf9, 0x34, 0xcc, 0x91, 0xbe, 0x89, 0x8f, 0xe4, 0x6a")
MAKE_THUNK(libvulkan, vkFreeCommandBuffers, "0xbe, 0x46, 0xe0, 0x42, 0xd4, 0xb2, 0xfa, 0xa3, 0x2c, 0xf5, 0x74, 0xa0, 0x20, 0x55, 0xe3, 0x35, 0x77, 0x3, 0xd9, 0x64, 0xd4, 0xcd, 0x12, 0x2b, 0x2a, 0x8b, 0xb, 0x4b, 0x84, 0x44, 0x22, 0xd8")
MAKE_THUNK(libvulkan, vkBeginCommandBuffer, "0xb6, 0x90, 0x25, 0x6e, 0xc5, 0x4d, 0x9d, 0xda, 0x6e, 0x83, 0x65, 0x6a, 0x39, 0x1a, 0xf7, 0x74, 0xf1, 0x88, 0x13, 0xdb, 0x15, 0xf, 0x1d, 0x48, 0xc4, 0xbf, 0x84, 0x41, 0xc8, 0x1, 0xc7, 0xb0")
MAKE_THUNK(libvulkan, vkEndCommandBuffer, "0xeb, 0x12, 0xc1, 0x77, 0x8c, 0xaf, 0xa0, 0xa9, 0x86, 0x97, 0xb7, 0x7c, 0x30, 0xd0, 0xca, 0xeb, 0x61, 0xfa, 0x23, 0xc, 0x4b, 0x23, 0x29, 0x49, 0x3e, 0x60, 0xf, 0xa6, 0xdc, 0x2, 0xed, 0xce")
MAKE_THUNK(libvulkan, vkResetCommandBuffer, "0x8c, 0xfb, 0xbd, 0x63, 0xef, 0x9b, 0x45, 0xac, 0xbd, 0xdd, 0xe1, 0x86, 0x23, 0xf8, 0x30, 0x3, 0xbd, 0x8d, 0x7a, 0x6a, 0x7f, 0x7d, 0x76, 0x61, 0x36, 0x2e, 0x72, 0xe9, 0x17, 0x10, 0x4b, 0xa7")
MAKE_THUNK(libvulkan, vkCmdCopyBuffer, "0xc2, 0xde, 0x66, 0x78, 0xb, 0xd5, 0x8b, 0x14, 0xfa, 0x69, 0x97, 0x61, 0x1, 0xf9, 0xcf, 0x7a, 0x9a, 0x9e, 0x6e, 0xbc, 0x58, 0x80, 0x71, 0xd2, 0x4b, 0x26, 0xc5, 0xc1, 0x67, 0xd4, 0xb1, 0xf7")
MAKE_THUNK(libvulkan, vkCmdCopyImage, "0x81, 0xaf, 0xe4, 0x41, 0x7d, 0x86, 0x4d, 0x1f, 0x54, 0x95, 0x88, 0x17, 0xe4, 0xf5, 0xd1, 0xec, 0xfa, 0x6b, 0xf9, 0xf6, 0x17, 0x93, 0xd2, 0xe2, 0x7c, 0x45, 0x1d, 0x68, 0x1a, 0x83, 0xe0, 0x91")
MAKE_THUNK(libvulkan, vkCmdCopyBufferToImage, "0x17, 0x76, 0xc4, 0x36, 0xd7, 0xac, 0xd1, 0xa9, 0x3c, 0x37, 0x7e, 0xb5, 0x51, 0x41, 0xe2, 0xb9, 0xeb, 0x3b, 0x48, 0x8a, 0x27, 0x48, 0x51, 0xec, 0x6d, 0x4e, 0x8d, 0xa7, 0xb5, 0x22, 0x49, 0x96")
MAKE_THUNK(libvulkan, vkCmdCopyImageToBuffer, "0xc5, 0x80, 0x70, 0x97, 0xa7, 0x22, 0x7b, 0x92, 0x5f, 0x42, 0x87, 0xbd, 0xa5, 0xa7, 0x66, 0x83, 0x1b, 0x3e, 0x91, 0x78, 0xc6, 0xc3, 0x4c, 0x12, 0xa6, 0x36, 0x3d, 0x7f, 0x85, 0x4f, 0x1b, 0xdb")
MAKE_THUNK(libvulkan, vkCmdUpdateBuffer, "0xdf, 0x74, 0x5e, 0xfb, 0xc7, 0x15, 0x59, 0x92, 0xd, 0x7, 0x4c, 0xaa, 0x48, 0x95, 0x1f, 0x8b, 0x99, 0x51, 0xa7, 0x7a, 0x5e, 0xde, 0x4c, 0x2a, 0xc0, 0xbb, 0x76, 0x67, 0x16, 0x8f, 0x28, 0xc8")
MAKE_THUNK(libvulkan, vkCmdFillBuffer, "0xab, 0x78, 0x12, 0xef, 0x79, 0x36, 0x4c, 0x6d, 0x8, 0xd4, 0xfb, 0x9b, 0x5, 0xdf, 0xfa, 0x11, 0x2b, 0x7e, 0xfe, 0xec, 0x31, 0xc3, 0xf7, 0xd7, 0x35, 0xe5, 0x1f, 0x6f, 0x4c, 0x48, 0xed, 0x8")
MAKE_THUNK(libvulkan, vkCmdPipelineBarrier, "0x18, 0x25, 0x0, 0x65, 0xd0, 0xea, 0x75, 0x83, 0x92, 0x18, 0xd9, 0x8b, 0x7e, 0xf4, 0x23, 0xc9, 0x15, 0xa, 0x70, 0x7f, 0xdc, 0xee, 0x5, 0x6f, 0xe9, 0x9c, 0x65, 0xd9, 0xf2, 0x1e, 0x94, 0x8d")
MAKE_THUNK(libvulkan, vkCmdBeginQuery, "0xbe, 0x47, 0xfa, 0x7e, 0x8d, 0xb7, 0x64, 0xb6, 0xfa, 0x23, 0x70, 0xc6, 0xfe, 0x7a, 0x95, 0x89, 0x4d, 0x5f, 0xa3, 0xb6, 0xe8, 0xa4, 0x10, 0xbc, 0xa0, 0x62, 0xe, 0x32, 0x65, 0x4c, 0xfc, 0x9d")
MAKE_THUNK(libvulkan, vkCmdEndQuery, "0x7, 0x73, 0x4c, 0x28, 0x35, 0xeb, 0xa7, 0xc, 0xa5, 0xab, 0xd8, 0x8f, 0x53, 0x7e, 0xe7, 0xce, 0x2d, 0x6d, 0xc3, 0x5b, 0x56, 0x2b, 0xd7, 0xc8, 0xcb, 0xa6, 0xa6, 0xdf, 0xdc, 0xb0, 0x27, 0xbc")
MAKE_THUNK(libvulkan, vkCmdResetQueryPool, "0x67, 0xbb, 0xe0, 0x1c, 0x4a, 0xfc, 0x74, 0x91, 0x75, 0x3b, 0x29, 0x39, 0x52, 0x25, 0x9d, 0xf3, 0xf5, 0x38, 0xd4, 0xbb, 0xa8, 0xd4, 0x98, 0x26, 0xe3, 0xdf, 0xfa, 0xda, 0xf1, 0x3b, 0x89, 0x60")
MAKE_THUNK(libvulkan, vkCmdWriteTimestamp, "0x73, 0xbe, 0xa0, 0x8b, 0x59, 0xf0, 0x3, 0x4, 0xe6, 0x7b, 0x82, 0xa5, 0xf3, 0xb2, 0x2b, 0x3d, 0x95, 0x39, 0x21, 0x58, 0x3b, 0x5, 0x2, 0x4d, 0xcb, 0xb5, 0xea, 0x78, 0x91, 0x64, 0x4d, 0x75")
MAKE_THUNK(libvulkan, vkCmdCopyQueryPoolResults, "0xb1, 0x90, 0x6e, 0x8f, 0xcb, 0x1e, 0x8b, 0xfd, 0x73, 0xf, 0xd, 0x2f, 0x11, 0xe3, 0x8f, 0xf0, 0xe7, 0xb4, 0x22, 0x3b, 0xce, 0xaf, 0x2, 0xae, 0xfe, 0x34, 0xa4, 0xe6, 0xc3, 0x11, 0x9f, 0xa6")
MAKE_THUNK(libvulkan, vkCmdExecuteCommands, "0x79, 0x17, 0xed, 0x9a, 0x92, 0xb5, 0x6b, 0xbe, 0x13, 0xd4, 0x82, 0xa8, 0x22, 0xe1, 0x36, 0x7f, 0x6d, 0xaa, 0xa1, 0x1a, 0xbc, 0xd8, 0x42, 0xcd, 0xa, 0x50, 0x41, 0x8, 0xfe, 0xbc, 0xad, 0x46")
MAKE_THUNK(libvulkan, vkCreateEvent, "0xfb, 0x6e, 0x75, 0x9c, 0xf9, 0xa, 0xbb, 0x65, 0x1c, 0xf3, 0x77, 0xd, 0xbb, 0xf2, 0xcf, 0x3f, 0x36, 0xd2, 0x8, 0xeb, 0xe4, 0x22, 0xa1, 0x93, 0xee, 0x53, 0xf4, 0xca, 0xf2, 0xe7, 0xb7, 0x2f")
MAKE_THUNK(libvulkan, vkDestroyEvent, "0x89, 0xcf, 0x28, 0xfc, 0x50, 0xc2, 0xaa, 0x34, 0x5, 0x45, 0xb8, 0xac, 0x69, 0xec, 0x77, 0x58, 0xef, 0xa8, 0x95, 0xc5, 0xea, 0xe0, 0x4, 0xa9, 0x4e, 0xa0, 0x3b, 0xc, 0xdb, 0x24, 0x4d, 0x5b")
MAKE_THUNK(libvulkan, vkGetEventStatus, "0x2f, 0x26, 0xe9, 0xd3, 0x2, 0xd3, 0xbd, 0xb8, 0xe, 0xeb, 0xdf, 0xb4, 0x6e, 0xda, 0x50, 0x29, 0x54, 0xd4, 0x7f, 0x1c, 0x2d, 0x2d, 0x93, 0xcb, 0x9f, 0x2, 0x2f, 0x41, 0xfa, 0x12, 0xa8, 0x13")
MAKE_THUNK(libvulkan, vkSetEvent, "0xb9, 0x1d, 0xe4, 0x96, 0x97, 0x56, 0x6a, 0x5d, 0x1e, 0xb4, 0xab, 0xbb, 0x15, 0x3d, 0x25, 0x15, 0xdb, 0xda, 0xea, 0x5e, 0xf4, 0x6f, 0xe0, 0x53, 0xa2, 0x79, 0x6e, 0x69, 0x75, 0xc7, 0x5d, 0x69")
MAKE_THUNK(libvulkan, vkResetEvent, "0xba, 0x13, 0x4c, 0x52, 0xb4, 0xb7, 0xab, 0xaf, 0x6f, 0x9c, 0x76, 0xfe, 0xf2, 0x9c, 0xe0, 0x70, 0x2c, 0x65, 0x4a, 0xbe, 0xdb, 0x16, 0xf8, 0x9a, 0x4d, 0x1b, 0xbf, 0x1a, 0xa9, 0x40, 0x8f, 0x16")
MAKE_THUNK(libvulkan, vkCreateBufferView, "0xb1, 0x53, 0xef, 0xfb, 0x55, 0x63, 0xce, 0xef, 0x3b, 0x74, 0x76, 0xe4, 0xb7, 0xb5, 0x5f, 0xda, 0x8b, 0xb1, 0x43, 0xa2, 0x3d, 0x7, 0xc9, 0x3e, 0x69, 0x4c, 0xd5, 0x48, 0x6b, 0xaa, 0x4f, 0xfa")
MAKE_THUNK(libvulkan, vkDestroyBufferView, "0x2b, 0x3, 0x7f, 0x81, 0x67, 0xa9, 0xc5, 0xec, 0xd5, 0xc5, 0x2c, 0xe8, 0x6c, 0x9a, 0x4, 0x7e, 0x1e, 0xc5, 0xf5, 0x0, 0x7, 0xfa, 0xa5, 0x51, 0x1d, 0xc4, 0xdc, 0x74, 0xed, 0xd5, 0xb2, 0x36")
MAKE_THUNK(libvulkan, vkCreateShaderModule, "0xf9, 0xad, 0xc, 0xd1, 0x23, 0xed, 0x64, 0x2f, 0x27, 0x4f, 0x40, 0xad, 0xc4, 0x76, 0x4d, 0x59, 0xd8, 0x71, 0x20, 0x7f, 0x25, 0xb, 0xd2, 0x9b, 0x62, 0xb1, 0x4e, 0x45, 0xd8, 0x3b, 0xc0, 0xcb")
MAKE_THUNK(libvulkan, vkDestroyShaderModule, "0x23, 0xd9, 0x13, 0x3f, 0xd2, 0x7f, 0x17, 0x97, 0x89, 0x46, 0x37, 0xd3, 0x2b, 0xc4, 0xc0, 0x85, 0xc6, 0x71, 0x6c, 0xf8, 0x3a, 0xc0, 0x6, 0x6f, 0xa8, 0xec, 0x8c, 0xb8, 0x79, 0x65, 0x9b, 0x61")
MAKE_THUNK(libvulkan, vkCreatePipelineCache, "0x85, 0x81, 0xc1, 0xfb, 0x87, 0xa4, 0xae, 0x2b, 0x42, 0x7c, 0x66, 0xd6, 0xd8, 0x6b, 0xa9, 0x39, 0xeb, 0x99, 0x67, 0x23, 0xa8, 0x5d, 0xa0, 0xee, 0xbf, 0x64, 0xa5, 0x4d, 0x6f, 0x6, 0x6c, 0xae")
MAKE_THUNK(libvulkan, vkDestroyPipelineCache, "0x7f, 0x88, 0x78, 0x7d, 0x5c, 0xeb, 0x2b, 0xeb, 0x69, 0xe2, 0x26, 0xa3, 0x6f, 0xf9, 0xde, 0x9e, 0x81, 0x62, 0xeb, 0x65, 0x22, 0xc0, 0x4a, 0xb8, 0x3f, 0x3d, 0x49, 0xe4, 0x94, 0xcd, 0x83, 0x72")
MAKE_THUNK(libvulkan, vkGetPipelineCacheData, "0xe8, 0xac, 0x97, 0x53, 0x80, 0x88, 0x76, 0x2c, 0xdb, 0x98, 0xb5, 0x79, 0x1, 0xc2, 0x1e, 0x39, 0xcb, 0xbb, 0x67, 0x94, 0x90, 0xa7, 0x5e, 0x70, 0xa8, 0xcd, 0x5a, 0x21, 0xa6, 0x78, 0x77, 0x58")
MAKE_THUNK(libvulkan, vkMergePipelineCaches, "0xcd, 0xc7, 0xa7, 0x94, 0xe6, 0x9b, 0xfc, 0x17, 0xd0, 0x1f, 0x3d, 0xe4, 0xad, 0x70, 0xf2, 0x9b, 0x80, 0xce, 0x79, 0x89, 0x4a, 0x94, 0x41, 0x68, 0x1c, 0x13, 0x29, 0xd2, 0x84, 0xe2, 0x4, 0x3f")
MAKE_THUNK(libvulkan, vkCreateComputePipelines, "0x64, 0xae, 0xf2, 0xe0, 0x92, 0xa5, 0x69, 0x86, 0xaf, 0xb2, 0xff, 0x64, 0xc7, 0x82, 0x6d, 0x29, 0x46, 0xe7, 0xc9, 0x89, 0x34, 0x94, 0x77, 0x51, 0xfa, 0x2, 0x29, 0xee, 0x97, 0xec, 0x9f, 0x8b")
MAKE_THUNK(libvulkan, vkDestroyPipeline, "0x65, 0xda, 0x3a, 0x2, 0xaf, 0x1a, 0x62, 0x17, 0x2c, 0xb5, 0x1d, 0xf0, 0x12, 0x66, 0xdb, 0x2f, 0xba, 0x38, 0x76, 0x96, 0x70, 0x3d, 0xa3, 0x2d, 0xf4, 0xda, 0x85, 0x49, 0x7f, 0x8a, 0xcd, 0xa7")
MAKE_THUNK(libvulkan, vkCreatePipelineLayout, "0xc, 0x8d, 0x8f, 0x1, 0x35, 0x41, 0xec, 0xf9, 0x55, 0xc6, 0x3d, 0x1b, 0x49, 0x81, 0x72, 0xd8, 0xa1, 0xa4, 0x9, 0xd1, 0x5c, 0x6c, 0x98, 0x4e, 0x4c, 0xe9, 0x8f, 0x9e, 0xf6, 0x1d, 0xe6, 0xbc")
MAKE_THUNK(libvulkan, vkDestroyPipelineLayout, "0x2b, 0x23, 0xd9, 0xf3, 0x5e, 0xef, 0x89, 0x97, 0xcb, 0x98, 0xf2, 0xd8, 0x2d, 0x1f, 0x25, 0x2c, 0x96, 0x58, 0x8d, 0x1a, 0x95, 0xdd, 0x24, 0x6c, 0x37, 0x13, 0xa1, 0xb, 0xf6, 0x68, 0xbd, 0x21")
MAKE_THUNK(libvulkan, vkCreateSampler, "0xd0, 0xfe, 0x91, 0xbe, 0xf5, 0x13, 0x4f, 0x71, 0xfa, 0x2, 0x9b, 0x37, 0x2e, 0x7d, 0xa7, 0xdf, 0x6b, 0x86, 0xf3, 0x64, 0x42, 0xd9, 0xf6, 0x74, 0xad, 0x2c, 0xc, 0x1c, 0x5a, 0x26, 0xfe, 0x1b")
MAKE_THUNK(libvulkan, vkDestroySampler, "0x1c, 0x5f, 0xc8, 0xda, 0xcd, 0xf0, 0xdb, 0x4b, 0x8a, 0xb6, 0x38, 0x5f, 0x51, 0xa8, 0x1a, 0x97, 0x4f, 0x69, 0x74, 0xb5, 0x74, 0xb4, 0x26, 0xfc, 0x84, 0x20, 0x39, 0xe3, 0xea, 0x56, 0x1d, 0xb1")
MAKE_THUNK(libvulkan, vkCreateDescriptorSetLayout, "0xd7, 0x13, 0x1f, 0x33, 0x0, 0x2b, 0xa7, 0xe7, 0x60, 0x60, 0x69, 0xd1, 0xc2, 0xf2, 0xd0, 0xa, 0x8b, 0xe4, 0x2b, 0x53, 0x41, 0x35, 0x69, 0x3a, 0xdd, 0x7b, 0xed, 0xc0, 0x73, 0xfd, 0x4b, 0xd8")
MAKE_THUNK(libvulkan, vkDestroyDescriptorSetLayout, "0x3f, 0xd8, 0x6b, 0x17, 0x70, 0xbf, 0xc8, 0xe7, 0x84, 0x98, 0x11, 0xc1, 0xa5, 0x18, 0x82, 0x3b, 0xa3, 0xc1, 0x34, 0x14, 0xfb, 0xca, 0x88, 0xd4, 0x5, 0x6c, 0x83, 0x62, 0xd1, 0x47, 0xe3, 0xf5")
MAKE_THUNK(libvulkan, vkCreateDescriptorPool, "0x27, 0xcb, 0xe, 0xd, 0xd8, 0x3f, 0x4a, 0x1e, 0x73, 0x32, 0x85, 0x4d, 0x1f, 0xef, 0x46, 0xab, 0xf7, 0x2d, 0x94, 0x43, 0xa2, 0xaf, 0x2e, 0x45, 0x60, 0xa6, 0xf2, 0x8f, 0xed, 0xb5, 0xcf, 0x42")
MAKE_THUNK(libvulkan, vkDestroyDescriptorPool, "0xb, 0xef, 0x87, 0x77, 0x6f, 0xd9, 0xd3, 0x2f, 0xc2, 0xd4, 0x85, 0x74, 0xa, 0x6e, 0xf8, 0x8d, 0x77, 0xe0, 0x36, 0x61, 0xdf, 0xe, 0x47, 0xfb, 0xf, 0xc7, 0xe7, 0x61, 0x5b, 0x46, 0x59, 0x25")
MAKE_THUNK(libvulkan, vkResetDescriptorPool, "0x5a, 0xff, 0xfc, 0xb5, 0xbe, 0x94, 0x52, 0xe3, 0x4a, 0xf5, 0xee, 0xc4, 0xe3, 0xb1, 0x8, 0x79, 0x9b, 0x7b, 0x6e, 0x71, 0x96, 0x7b, 0x62, 0x7f, 0x87, 0x1d, 0x7b, 0xf5, 0x76, 0x5a, 0xa9, 0xb7")
MAKE_THUNK(libvulkan, vkAllocateDescriptorSets, "0xe0, 0x0, 0xa7, 0x7f, 0x24, 0xa6, 0x21, 0xe9, 0x76, 0xd4, 0xf1, 0x14, 0xdf, 0x47, 0xac, 0x37, 0x29, 0x89, 0x1, 0x7a, 0x9b, 0xbc, 0xe4, 0xb8, 0x9c, 0xf4, 0x65, 0x66, 0x76, 0xd4, 0x4d, 0x5f")
MAKE_THUNK(libvulkan, vkFreeDescriptorSets, "0xb8, 0xfa, 0x28, 0x51, 0xc5, 0x7a, 0xc1, 0x76, 0xc6, 0xda, 0x8c, 0x9, 0x1e, 0xd0, 0x26, 0x9e, 0xd9, 0xae, 0xf0, 0x3a, 0xa0, 0x39, 0xff, 0x8d, 0xc0, 0x4f, 0x91, 0xfb, 0x1b, 0x72, 0x85, 0xf3")
MAKE_THUNK(libvulkan, vkUpdateDescriptorSets, "0x1e, 0x22, 0x4d, 0xda, 0x80, 0x98, 0x39, 0x49, 0x3e, 0xf4, 0xa6, 0xa3, 0x48, 0xff, 0xae, 0x7c, 0x71, 0xcc, 0x4, 0x69, 0xc6, 0x13, 0x1e, 0xe2, 0x2c, 0x47, 0x3f, 0xfe, 0xd4, 0x1e, 0x51, 0x75")
MAKE_THUNK(libvulkan, vkCmdBindPipeline, "0xff, 0x8e, 0x47, 0xe, 0x6a, 0xef, 0xd0, 0x6, 0xbb, 0xdd, 0x98, 0xbd, 0xc1, 0x44, 0x4e, 0x9d, 0xa3, 0x7, 0x57, 0x83, 0x26, 0x80, 0xa2, 0xb7, 0xd1, 0x2d, 0x9b, 0x94, 0x51, 0xd0, 0xc2, 0xbf")
MAKE_THUNK(libvulkan, vkCmdBindDescriptorSets, "0x34, 0x86, 0xe6, 0x37, 0x9b, 0x20, 0xf3, 0x66, 0x1, 0x1d, 0xa3, 0xe0, 0x2c, 0xcb, 0xa7, 0x1b, 0xb5, 0x58, 0x16, 0x82, 0x8, 0x18, 0x7b, 0xdc, 0x5e, 0x7a, 0x59, 0xf4, 0x80, 0x4e, 0xfe, 0x96")
MAKE_THUNK(libvulkan, vkCmdClearColorImage, "0xb, 0x38, 0xdb, 0x6c, 0x86, 0xe2, 0x3c, 0x3c, 0x72, 0x57, 0xc0, 0x6e, 0x6d, 0x7, 0x80, 0x86, 0x34, 0x5a, 0xee, 0x14, 0x8, 0x9b, 0x3d, 0x6b, 0xc7, 0x9b, 0xb4, 0x5, 0x3d, 0x24, 0xc4, 0x67")
MAKE_THUNK(libvulkan, vkCmdDispatch, "0xe, 0xa2, 0x89, 0x40, 0xd4, 0x52, 0x1b, 0xc1, 0xe9, 0xf1, 0xfe, 0xcf, 0x28, 0x15, 0x32, 0x66, 0x6e, 0x3f, 0xbd, 0x97, 0x32, 0x97, 0x7d, 0x80, 0x88, 0xca, 0x7, 0x5d, 0x68, 0x76, 0xe7, 0x37")
MAKE_THUNK(libvulkan, vkCmdDispatchIndirect, "0xf6, 0xb3, 0x92, 0x75, 0xcd, 0x89, 0xa0, 0xb0, 0x9e, 0x64, 0x17, 0x2e, 0x65, 0x43, 0x52, 0xf3, 0x67, 0xd8, 0x27, 0x4b, 0xf9, 0x27, 0x8d, 0xe0, 0xd, 0xcb, 0x75, 0x1c, 0xdc, 0x88, 0x4, 0x41")
MAKE_THUNK(libvulkan, vkCmdSetEvent, "0xf1, 0x94, 0x51, 0x73, 0xf9, 0x1e, 0x4c, 0xeb, 0x8d, 0x7c, 0xaa, 0xc9, 0xe9, 0x13, 0x9a, 0xd3, 0x78, 0x59, 0xcb, 0x7a, 0x21, 0xf4, 0x8, 0x7f, 0xad, 0xb1, 0x5, 0x94, 0x6, 0x32, 0x75, 0x7c")
MAKE_THUNK(libvulkan, vkCmdResetEvent, "0xf6, 0xf9, 0xc3, 0xa2, 0xba, 0xe2, 0xfe, 0x79, 0xc4, 0x62, 0xb7, 0x46, 0x11, 0x7a, 0x97, 0xe0, 0xe8, 0x39, 0x7f, 0x5c, 0x55, 0x49, 0x0, 0xd5, 0x47, 0xe0, 0x80, 0xa5, 0xa3, 0x1e, 0x81, 0x3c")
MAKE_THUNK(libvulkan, vkCmdWaitEvents, "0x90, 0x46, 0x15, 0x19, 0x5a, 0x5a, 0x46, 0x55, 0x86, 0x22, 0xc4, 0x99, 0x70, 0x73, 0x16, 0x7e, 0x8a, 0x26, 0x48, 0xce, 0x1f, 0xaa, 0x4b, 0xc3, 0xcb, 0xc4, 0x14, 0x54, 0xdd, 0x43, 0xe0, 0xe3")
MAKE_THUNK(libvulkan, vkCmdPushConstants, "0x16, 0x8c, 0xa9, 0xd0, 0x1a, 0xd, 0xc8, 0x88, 0x47, 0xb8, 0x28, 0x7, 0xd0, 0x81, 0x8, 0x2a, 0x3a, 0xef, 0x3a, 0xb, 0xd7, 0x8b, 0xce, 0x8e, 0x39, 0x5, 0x7f, 0xdf, 0x1a, 0xff, 0x11, 0xe8")
MAKE_THUNK(libvulkan, vkCreateGraphicsPipelines, "0x6f, 0x89, 0xb8, 0xef, 0x7b, 0x73, 0x58, 0x7b, 0x88, 0x46, 0xf1, 0x12, 0x31, 0x2, 0x84, 0x8c, 0x46, 0x5e, 0xb9, 0x8d, 0x8, 0xd3, 0xb1, 0x8, 0x98, 0x3a, 0x65, 0x81, 0x5a, 0x64, 0x38, 0x7e")
MAKE_THUNK(libvulkan, vkCreateFramebuffer, "0x94, 0xbe, 0x38, 0xb, 0xf4, 0xb1, 0x19, 0xa0, 0x67, 0x46, 0x4a, 0xf9, 0x84, 0x65, 0xe2, 0x40, 0xb, 0x19, 0xff, 0x50, 0x3a, 0x82, 0x84, 0x3c, 0xef, 0x9b, 0xe9, 0xdc, 0xd7, 0x10, 0x4c, 0x71")
MAKE_THUNK(libvulkan, vkDestroyFramebuffer, "0xad, 0x7a, 0xbe, 0x38, 0xac, 0x69, 0xec, 0xa5, 0x8d, 0xaf, 0x42, 0xb4, 0x98, 0xba, 0x40, 0x67, 0x69, 0x71, 0xee, 0x27, 0x4b, 0x64, 0xe7, 0x29, 0x7, 0xca, 0xa9, 0xbd, 0x59, 0x6d, 0x2f, 0x91")
MAKE_THUNK(libvulkan, vkCreateRenderPass, "0x21, 0x2d, 0x50, 0x90, 0x65, 0x1e, 0x8c, 0x4e, 0x95, 0xb0, 0x2e, 0x5c, 0x7d, 0xea, 0xa8, 0xa5, 0x35, 0x3, 0x5e, 0xe9, 0xdb, 0xff, 0xc0, 0x30, 0x19, 0x6c, 0x34, 0xa, 0xc8, 0xf0, 0xfe, 0x4a")
MAKE_THUNK(libvulkan, vkDestroyRenderPass, "0xdc, 0xea, 0x7a, 0xd0, 0x12, 0xc3, 0x42, 0x5, 0xfa, 0xb1, 0x3, 0x7e, 0x17, 0xb8, 0xa5, 0xd5, 0x52, 0xca, 0x7a, 0x62, 0x3c, 0x1f, 0x97, 0x16, 0xc5, 0x34, 0x9c, 0x1c, 0x91, 0x7a, 0x55, 0x79")
MAKE_THUNK(libvulkan, vkGetRenderAreaGranularity, "0x9a, 0x75, 0x3f, 0x5d, 0xe0, 0xb3, 0x4b, 0x88, 0x79, 0xea, 0x64, 0xf3, 0x1, 0x70, 0x92, 0xa2, 0x42, 0xc6, 0x1c, 0x8b, 0x26, 0xe9, 0x5f, 0xe1, 0x52, 0xdf, 0xfb, 0x62, 0xca, 0xe, 0xc2, 0x4")
MAKE_THUNK(libvulkan, vkCmdSetViewport, "0xbf, 0x57, 0x19, 0xc2, 0xd4, 0xe9, 0x43, 0x98, 0x11, 0x29, 0x54, 0xc7, 0xf4, 0x1a, 0x7c, 0xd3, 0xab, 0xb5, 0xc, 0x99, 0x70, 0xd0, 0xd6, 0x1c, 0x3f, 0x83, 0x9e, 0x78, 0xba, 0x6d, 0x0, 0x8")
MAKE_THUNK(libvulkan, vkCmdSetScissor, "0x90, 0xf, 0xfb, 0x16, 0x67, 0x93, 0xa6, 0x4a, 0x79, 0xf5, 0x86, 0x9f, 0x3c, 0xc8, 0xfc, 0x73, 0xe8, 0xa9, 0xfc, 0xeb, 0x84, 0x17, 0x80, 0x55, 0x48, 0x5b, 0x57, 0x2b, 0x5c, 0xf2, 0xbe, 0xe2")
MAKE_THUNK(libvulkan, vkCmdSetLineWidth, "0x1c, 0x70, 0xe8, 0x38, 0x8f, 0x8, 0x46, 0x17, 0x9d, 0x82, 0x3a, 0x5d, 0x85, 0xe7, 0x69, 0x68, 0x28, 0x37, 0x27, 0xf0, 0x54, 0xb0, 0x42, 0x59, 0x6a, 0x1f, 0x35, 0xa6, 0xed, 0x18, 0x3a, 0xb0")
MAKE_THUNK(libvulkan, vkCmdSetDepthBias, "0xa5, 0xdb, 0xb9, 0x94, 0x9e, 0xa7, 0x49, 0x62, 0x2f, 0x30, 0x14, 0xd1, 0x64, 0x3e, 0x1, 0x6e, 0x1a, 0x6e, 0x18, 0xe, 0xd5, 0xeb, 0x6b, 0xb7, 0xa8, 0x4c, 0x6c, 0x23, 0x8e, 0x93, 0xc1, 0x53")
MAKE_THUNK(libvulkan, vkCmdSetBlendConstants, "0x20, 0xa9, 0x24, 0xc, 0x9f, 0xd2, 0x8a, 0xc4, 0x7a, 0x5b, 0x4c, 0x1c, 0xbe, 0x46, 0xfb, 0x90, 0x3f, 0xec, 0x74, 0x2b, 0x60, 0x58, 0x34, 0xb2, 0x5e, 0x9d, 0xd1, 0xaf, 0x2d, 0x7c, 0x8a, 0xd8")
MAKE_THUNK(libvulkan, vkCmdSetDepthBounds, "0xb2, 0x89, 0xe5, 0x73, 0xf7, 0xb0, 0xfb, 0x12, 0x32, 0x24, 0x93, 0x29, 0x45, 0xa6, 0xf2, 0xc7, 0x26, 0x3d, 0x8e, 0xaa, 0x9c, 0xfc, 0x6c, 0x9e, 0x49, 0x21, 0x18, 0xde, 0x49, 0x4d, 0x2f, 0x7b")
MAKE_THUNK(libvulkan, vkCmdSetStencilCompareMask, "0x17, 0x4a, 0x2b, 0x80, 0xd1, 0x53, 0x78, 0x76, 0xb3, 0x35, 0x2, 0x49, 0x46, 0x58, 0xd5, 0x51, 0xfd, 0x72, 0x44, 0x72, 0x78, 0x6d, 0x8d, 0xf5, 0xe3, 0x4e, 0x20, 0xe9, 0xd4, 0x5d, 0xc0, 0xc")
MAKE_THUNK(libvulkan, vkCmdSetStencilWriteMask, "0x5, 0x9c, 0x4e, 0x65, 0x5b, 0xf5, 0x88, 0x36, 0x18, 0xf4, 0x18, 0xef, 0xab, 0x6b, 0xe4, 0x3d, 0xbd, 0xe4, 0xa8, 0x8b, 0xab, 0xf, 0x67, 0xc7, 0x50, 0xad, 0x25, 0xd8, 0xc7, 0x2f, 0x6, 0xdc")
MAKE_THUNK(libvulkan, vkCmdSetStencilReference, "0x27, 0x7c, 0xc7, 0x86, 0x5f, 0xab, 0xed, 0xf4, 0xe7, 0x7e, 0x40, 0x8a, 0xc2, 0xa4, 0x6e, 0x93, 0x15, 0x35, 0x33, 0xc6, 0x7b, 0x16, 0xe7, 0x4f, 0xf0, 0x87, 0x3, 0x39, 0x1, 0x6b, 0xf, 0x7a")
MAKE_THUNK(libvulkan, vkCmdBindIndexBuffer, "0x3c, 0x4, 0x2f, 0x29, 0x7f, 0xcb, 0xc6, 0xdd, 0x53, 0x3, 0x3f, 0x61, 0xf2, 0xdb, 0x93, 0x48, 0x8b, 0x4c, 0x34, 0x93, 0xe8, 0x79, 0x11, 0x63, 0x23, 0x83, 0x4b, 0x30, 0xfe, 0xf1, 0xa7, 0x2a")
MAKE_THUNK(libvulkan, vkCmdBindVertexBuffers, "0xb, 0x7, 0x6d, 0xe3, 0xc1, 0x17, 0xfe, 0xbc, 0xbb, 0xb8, 0x83, 0xbb, 0xd7, 0x34, 0x26, 0xe5, 0x9c, 0x98, 0xe3, 0x79, 0x3b, 0x6e, 0x65, 0x1d, 0xc3, 0x47, 0x1c, 0xc6, 0xe5, 0x8b, 0x17, 0xa1")
MAKE_THUNK(libvulkan, vkCmdDraw, "0xc9, 0x8d, 0xd1, 0x38, 0xc9, 0x8e, 0xbc, 0x97, 0xc6, 0x4a, 0x40, 0x1, 0x58, 0xd3, 0x64, 0x94, 0x51, 0x10, 0x68, 0xd5, 0x13, 0xa8, 0xe9, 0x6c, 0xcd, 0x2c, 0x25, 0x45, 0x4a, 0xb9, 0xf2, 0xef")
MAKE_THUNK(libvulkan, vkCmdDrawIndexed, "0x98, 0xd9, 0x9d, 0xd5, 0xbd, 0x98, 0x2a, 0x2e, 0xd1, 0xba, 0xb6, 0x83, 0xa1, 0xa2, 0xa9, 0x35, 0x83, 0x48, 0xab, 0x90, 0x62, 0xf3, 0x51, 0xc7, 0x82, 0x2d, 0xd9, 0x85, 0x4a, 0xa7, 0x44, 0xb2")
MAKE_THUNK(libvulkan, vkCmdDrawIndirect, "0x21, 0x48, 0xbd, 0x94, 0xfb, 0x97, 0x3b, 0x83, 0xe7, 0x61, 0xd3, 0xdd, 0x3d, 0x17, 0x31, 0x54, 0x2f, 0xd6, 0x9a, 0x56, 0xa9, 0xc3, 0x1e, 0x4e, 0x4a, 0x4d, 0xb5, 0xdd, 0xff, 0x78, 0x15, 0x3")
MAKE_THUNK(libvulkan, vkCmdDrawIndexedIndirect, "0x6e, 0x3c, 0xff, 0x4e, 0x6a, 0xec, 0x2d, 0x78, 0xeb, 0x8a, 0x45, 0x6b, 0xc, 0xa7, 0xdb, 0x62, 0xeb, 0x91, 0x44, 0x3a, 0xbd, 0xc3, 0x66, 0xbf, 0x16, 0xd0, 0xf0, 0x87, 0x27, 0x35, 0xec, 0x2a")
MAKE_THUNK(libvulkan, vkCmdBlitImage, "0x51, 0xb9, 0xe0, 0x3b, 0x6b, 0xb, 0x8c, 0x11, 0xeb, 0xbd, 0x76, 0xd9, 0x71, 0xc4, 0xa5, 0x43, 0xf0, 0x69, 0xcf, 0xd, 0x2c, 0xe3, 0x86, 0xb9, 0x0, 0x6, 0x52, 0x67, 0xa8, 0xac, 0x9e, 0x91")
MAKE_THUNK(libvulkan, vkCmdClearDepthStencilImage, "0x63, 0x93, 0xa3, 0x3f, 0xa0, 0x4a, 0xe7, 0x91, 0x5f, 0x13, 0xc0, 0x57, 0x9e, 0x43, 0x69, 0x3e, 0xfa, 0x8b, 0x19, 0x86, 0xaa, 0x6, 0x8, 0x78, 0xd5, 0xce, 0xc2, 0x78, 0x33, 0x5d, 0x3a, 0xf6")
MAKE_THUNK(libvulkan, vkCmdClearAttachments, "0x84, 0x76, 0x5a, 0x9b, 0x8, 0x46, 0xec, 0xb1, 0x36, 0x63, 0xe6, 0x1c, 0xeb, 0x41, 0xf1, 0x3d, 0xc6, 0x6, 0x29, 0xe0, 0xf4, 0x69, 0xc0, 0x6a, 0x95, 0x23, 0x68, 0x70, 0x85, 0x76, 0xca, 0x2a")
MAKE_THUNK(libvulkan, vkCmdResolveImage, "0x16, 0xca, 0x23, 0xeb, 0x45, 0x91, 0x83, 0x7, 0xdb, 0x29, 0x2b, 0x55, 0x52, 0x2a, 0xa, 0xb9, 0x48, 0x9d, 0x67, 0x45, 0x2, 0x10, 0xb4, 0xf3, 0xfa, 0x40, 0x24, 0x4, 0xf6, 0x60, 0x17, 0x13")
MAKE_THUNK(libvulkan, vkCmdBeginRenderPass, "0x3, 0x1d, 0xac, 0x61, 0x57, 0x44, 0xba, 0xfb, 0x9c, 0x4b, 0x71, 0x87, 0xf1, 0x1b, 0xc1, 0x54, 0x95, 0x60, 0x67, 0x55, 0x4, 0x15, 0xca, 0x33, 0xd5, 0x38, 0xa4, 0x4, 0x2d, 0xc5, 0xb6, 0xb4")
MAKE_THUNK(libvulkan, vkCmdNextSubpass, "0xc3, 0x68, 0x15, 0xf3, 0x50, 0x2d, 0x56, 0xb9, 0x7f, 0xcd, 0x85, 0xfa, 0x78, 0x74, 0xfc, 0x86, 0x3, 0x5f, 0xeb, 0x9a, 0x7a, 0x11, 0xa0, 0x21, 0x9e, 0x74, 0xe4, 0xbc, 0x20, 0x57, 0x40, 0x6a")
MAKE_THUNK(libvulkan, vkCmdEndRenderPass, "0x74, 0x35, 0x52, 0x4f, 0x8d, 0xcd, 0x6d, 0x57, 0x46, 0x91, 0x19, 0x38, 0x4e, 0x5c, 0x73, 0xe3, 0xbd, 0x1b, 0xd6, 0xcb, 0xde, 0xc5, 0xca, 0x52, 0x7d, 0x5f, 0xad, 0xf, 0xa2, 0x87, 0xc4, 0x1e")
MAKE_THUNK(libvulkan, vkEnumerateInstanceVersion, "0xdd, 0x4f, 0xa1, 0x92, 0x4, 0x20, 0xae, 0x41, 0x2, 0xf9, 0x4d, 0x3e, 0xb5, 0xc1, 0xda, 0x41, 0x4c, 0xd4, 0xfd, 0x77, 0xb7, 0xd4, 0xf8, 0x16, 0x72, 0xf2, 0xf9, 0x31, 0x1b, 0xd5, 0x23, 0x87")
MAKE_THUNK(libvulkan, vkBindBufferMemory2, "0x97, 0xad, 0x38, 0xf5, 0x90, 0xa8, 0x6, 0x9, 0x9c, 0x18, 0xc4, 0xb6, 0x1a, 0x77, 0x46, 0xfc, 0xc5, 0x61, 0xfa, 0xf5, 0x39, 0x44, 0x20, 0xf8, 0xe8, 0x75, 0x9f, 0x5e, 0xf5, 0xe9, 0x3e, 0xac")
MAKE_THUNK(libvulkan, vkBindImageMemory2, "0x6d, 0x2d, 0x9, 0x1d, 0x22, 0xaf, 0x1c, 0xa9, 0xe9, 0xfc, 0x52, 0xa, 0xef, 0x30, 0x9e, 0x42, 0x54, 0x8c, 0x6f, 0xdd, 0x14, 0x56, 0xa8, 0xcd, 0x45, 0xf6, 0xdd, 0x5c, 0xbb, 0xb5, 0xea, 0x7d")
MAKE_THUNK(libvulkan, vkGetDeviceGroupPeerMemoryFeatures, "0x2, 0x9e, 0x5f, 0x2, 0x56, 0xb0, 0xc8, 0xde, 0xec, 0x73, 0xd1, 0xdd, 0x99, 0xcf, 0x96, 0xd5, 0x57, 0x8c, 0x8, 0x93, 0xc5, 0xc7, 0x48, 0x27, 0x7c, 0x7a, 0x43, 0x1, 0xa8, 0x5, 0xbc, 0x8c")
MAKE_THUNK(libvulkan, vkCmdSetDeviceMask, "0x8c, 0x13, 0xac, 0xc6, 0xe3, 0xfb, 0xf6, 0xfd, 0x52, 0x44, 0xd4, 0x65, 0xbd, 0x89, 0x5d, 0x66, 0xa5, 0x9c, 0xc7, 0x62, 0xa5, 0xd3, 0xa6, 0x7b, 0xb0, 0xe9, 0x92, 0x34, 0x22, 0x14, 0xb0, 0x83")
MAKE_THUNK(libvulkan, vkEnumeratePhysicalDeviceGroups, "0x55, 0x41, 0x9f, 0xc5, 0x18, 0x93, 0xb2, 0xba, 0x23, 0x35, 0x71, 0xb3, 0x8e, 0x5d, 0xd7, 0xef, 0x9c, 0x31, 0xf6, 0x6, 0xbe, 0xb7, 0xc0, 0x85, 0xe6, 0x92, 0xd, 0x95, 0x40, 0x33, 0x33, 0x54")
MAKE_THUNK(libvulkan, vkGetImageMemoryRequirements2, "0x82, 0x53, 0x53, 0x40, 0x4b, 0x40, 0x98, 0x3c, 0xb, 0xff, 0x89, 0xc7, 0x90, 0x93, 0x2f, 0xa6, 0x18, 0x9f, 0xb4, 0xb8, 0x18, 0xa9, 0x57, 0x71, 0x20, 0x7c, 0xc2, 0xb6, 0xfc, 0x1f, 0xc4, 0x14")
MAKE_THUNK(libvulkan, vkGetBufferMemoryRequirements2, "0xae, 0x88, 0xa5, 0xea, 0x33, 0xc8, 0xc3, 0x6e, 0x4c, 0x4, 0xfd, 0xd4, 0x92, 0x29, 0x18, 0x8e, 0xaa, 0xe8, 0xa9, 0x41, 0xb1, 0x73, 0x5, 0xe7, 0xb6, 0xc3, 0x29, 0x1d, 0xb9, 0x8e, 0x7e, 0x7c")
MAKE_THUNK(libvulkan, vkGetImageSparseMemoryRequirements2, "0x48, 0xc, 0x1f, 0x4d, 0xe0, 0x23, 0x67, 0x6c, 0x5, 0x71, 0xbf, 0x9c, 0x48, 0xdd, 0x1c, 0xed, 0x95, 0xd2, 0xd3, 0x71, 0x5f, 0xa4, 0x2f, 0x9c, 0x5e, 0xc0, 0xee, 0x43, 0xda, 0x26, 0x61, 0xa8")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceFeatures2, "0x82, 0xee, 0x1a, 0xc8, 0xb3, 0x69, 0x79, 0xb0, 0x68, 0xa6, 0x56, 0x9e, 0x0, 0x55, 0x49, 0x62, 0x60, 0xbe, 0x20, 0x33, 0x80, 0x6a, 0x68, 0x1d, 0xcd, 0x99, 0x68, 0xaa, 0xdc, 0x8a, 0xed, 0xc2")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceProperties2, "0xca, 0xde, 0x1f, 0xf7, 0x76, 0xb2, 0xd9, 0x6a, 0x95, 0x84, 0xf0, 0xf, 0xab, 0xb3, 0x61, 0x58, 0x69, 0x2, 0x44, 0x5, 0xc8, 0xb2, 0x80, 0x3c, 0x8a, 0x11, 0x33, 0xf7, 0x19, 0x59, 0x98, 0x93")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceFormatProperties2, "0x2, 0x7, 0x1f, 0x87, 0xf4, 0xdb, 0xf6, 0x92, 0x27, 0x8f, 0x99, 0xf1, 0x36, 0xc5, 0x98, 0x5c, 0x5e, 0xaf, 0x81, 0xf4, 0xb4, 0x4, 0x9d, 0x5e, 0x8, 0xf2, 0x30, 0x4, 0x8b, 0xe0, 0xe1, 0xf7")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceImageFormatProperties2, "0xcb, 0xbb, 0xf5, 0x66, 0x52, 0x90, 0x49, 0x70, 0xa5, 0x36, 0x16, 0xe1, 0xab, 0xbd, 0xb5, 0x30, 0xd9, 0x4a, 0x75, 0xca, 0x26, 0xd7, 0xb9, 0xaf, 0xd3, 0x99, 0x74, 0x6f, 0xc5, 0x52, 0xf8, 0x8e")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceQueueFamilyProperties2, "0xc7, 0xb7, 0x88, 0x7e, 0xa8, 0xc9, 0x8b, 0xae, 0x78, 0x23, 0xc3, 0x7a, 0x8d, 0x6f, 0x8b, 0x78, 0x17, 0x8, 0x33, 0x64, 0x93, 0x13, 0x35, 0xa7, 0x9b, 0x22, 0x9c, 0x88, 0x9f, 0xf5, 0xe4, 0x58")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceMemoryProperties2, "0xdd, 0xec, 0x61, 0xf0, 0xe2, 0xb, 0xa, 0x99, 0xca, 0x73, 0x68, 0xa0, 0x41, 0x5e, 0xb5, 0x74, 0xcb, 0xc9, 0x6f, 0x16, 0x29, 0xb0, 0xc3, 0xc1, 0x7f, 0x9b, 0x35, 0x27, 0x96, 0x63, 0x37, 0x15")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSparseImageFormatProperties2, "0xeb, 0x2f, 0x47, 0xf, 0x2, 0xe3, 0x3b, 0xd7, 0xe6, 0x12, 0x74, 0x67, 0x14, 0xee, 0xf2, 0xd0, 0x5d, 0x37, 0x78, 0x5f, 0x94, 0x1c, 0x97, 0xcf, 0x71, 0xe5, 0x83, 0xba, 0xa4, 0x12, 0x98, 0xe6")
MAKE_THUNK(libvulkan, vkTrimCommandPool, "0x8a, 0xfc, 0x55, 0x60, 0xb7, 0x4e, 0xd9, 0x12, 0xf5, 0x41, 0xc6, 0x20, 0xed, 0x13, 0x3b, 0x51, 0xb7, 0x35, 0xe4, 0xb6, 0xf4, 0x1e, 0xec, 0x18, 0x4f, 0x2, 0xf1, 0xbf, 0x37, 0xe1, 0xd1, 0x7c")
MAKE_THUNK(libvulkan, vkGetDeviceQueue2, "0xba, 0x37, 0xf6, 0xc4, 0x55, 0x8c, 0x9f, 0x27, 0x79, 0x2c, 0xa6, 0x83, 0x3e, 0x90, 0xca, 0x25, 0xd2, 0xc5, 0x6e, 0xba, 0x67, 0x2f, 0x2e, 0x83, 0x1c, 0x68, 0x67, 0x4e, 0x72, 0xd7, 0x69, 0x5a")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalBufferProperties, "0x9e, 0x52, 0xe7, 0xcd, 0xc2, 0xbb, 0xad, 0x29, 0xd8, 0xdb, 0xf1, 0x9d, 0x64, 0x71, 0x90, 0xdb, 0x91, 0x47, 0x45, 0x49, 0x8, 0x7d, 0xec, 0x69, 0xeb, 0x77, 0xae, 0x73, 0x71, 0xb6, 0xc3, 0xff")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalFenceProperties, "0x98, 0xa6, 0xb, 0x16, 0xf, 0xb, 0xf9, 0x7f, 0x79, 0x77, 0xc2, 0xb0, 0x66, 0xab, 0xf4, 0xad, 0xa4, 0xb5, 0x9a, 0x2c, 0xce, 0xbb, 0x2, 0x93, 0xb8, 0xe0, 0x15, 0x23, 0xb4, 0x2d, 0x91, 0xbe")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalSemaphoreProperties, "0x90, 0x5a, 0x1b, 0x23, 0x9c, 0xa5, 0xcd, 0xb7, 0x4a, 0x12, 0xc3, 0xf3, 0xa4, 0xf0, 0xda, 0xaa, 0x76, 0xff, 0xab, 0x0, 0x3a, 0x26, 0x68, 0x4d, 0x48, 0x1c, 0x68, 0x6e, 0xe4, 0xa2, 0x10, 0x11")
MAKE_THUNK(libvulkan, vkCmdDispatchBase, "0x65, 0x49, 0x3c, 0xfb, 0xb8, 0x1d, 0x63, 0xf5, 0x5b, 0x4f, 0x66, 0x2f, 0xfc, 0x24, 0x39, 0xd9, 0xff, 0xce, 0x8e, 0x1d, 0xc9, 0xed, 0x94, 0xc, 0x35, 0x47, 0xf2, 0x9a, 0x57, 0x96, 0x64, 0xa8")
MAKE_THUNK(libvulkan, vkCreateDescriptorUpdateTemplate, "0x1a, 0x8e, 0x50, 0xd7, 0x5c, 0xda, 0x1d, 0x29, 0xf2, 0xf, 0x2f, 0x3b, 0xb4, 0xec, 0x26, 0xba, 0x72, 0x8f, 0x57, 0xe7, 0x4c, 0x4e, 0x2b, 0xcc, 0x7b, 0x79, 0x3c, 0x2b, 0x5, 0xa1, 0x7c, 0x9a")
MAKE_THUNK(libvulkan, vkDestroyDescriptorUpdateTemplate, "0x61, 0xd8, 0xc5, 0xee, 0x46, 0x2f, 0xb1, 0x7a, 0x8a, 0x2, 0xf5, 0xbe, 0x9, 0xd7, 0x92, 0xe2, 0x8f, 0xb0, 0xab, 0xa1, 0x8a, 0x88, 0x26, 0x1, 0x99, 0xd6, 0x8b, 0xee, 0x58, 0x45, 0x2b, 0xe0")
MAKE_THUNK(libvulkan, vkUpdateDescriptorSetWithTemplate, "0x9b, 0x5d, 0x79, 0x42, 0xc8, 0xae, 0x9c, 0xd0, 0xc7, 0x43, 0x3e, 0xc7, 0x44, 0xb3, 0x4f, 0x53, 0x7c, 0xd7, 0xe4, 0xca, 0x34, 0x10, 0xf4, 0xb, 0x6a, 0x6, 0x85, 0x45, 0x9, 0x36, 0xbc, 0x9b")
MAKE_THUNK(libvulkan, vkGetDescriptorSetLayoutSupport, "0x52, 0x84, 0xfa, 0x3e, 0xc6, 0x32, 0xb7, 0xec, 0x52, 0xb4, 0xe8, 0x89, 0xd2, 0x24, 0x79, 0x42, 0x85, 0x9, 0x1b, 0x25, 0x9d, 0x98, 0x44, 0x77, 0x33, 0xcb, 0xd9, 0xe0, 0x79, 0xcb, 0xb0, 0x64")
MAKE_THUNK(libvulkan, vkCreateSamplerYcbcrConversion, "0xf6, 0x8b, 0x83, 0xa1, 0xd9, 0xcf, 0x74, 0x57, 0xd8, 0x38, 0x8c, 0xaa, 0xc1, 0x8b, 0x29, 0x86, 0x15, 0xdd, 0xaa, 0x5a, 0x6, 0x5e, 0x26, 0x9a, 0x8c, 0x51, 0x60, 0xfd, 0x40, 0xb3, 0x14, 0xa9")
MAKE_THUNK(libvulkan, vkDestroySamplerYcbcrConversion, "0x86, 0x33, 0x1a, 0x4, 0xcc, 0x5f, 0x71, 0x4a, 0xac, 0x80, 0xcd, 0x2f, 0xca, 0xe2, 0xa3, 0x88, 0xdb, 0x50, 0xf0, 0x67, 0x7f, 0xb3, 0x4b, 0x3, 0x6a, 0x9d, 0x24, 0x58, 0xb6, 0xab, 0x10, 0x8f")
MAKE_THUNK(libvulkan, vkResetQueryPool, "0x51, 0x76, 0xa3, 0xbf, 0x9b, 0x6f, 0xf6, 0x58, 0x38, 0x6, 0x9d, 0x7a, 0x45, 0xd3, 0x73, 0x5b, 0x0, 0xbe, 0xb, 0x59, 0xcc, 0xae, 0xa7, 0x2b, 0xb6, 0x5f, 0x48, 0x4f, 0xfe, 0xeb, 0x45, 0x99")
MAKE_THUNK(libvulkan, vkGetSemaphoreCounterValue, "0x15, 0xf9, 0x20, 0xa6, 0xd5, 0xd9, 0x90, 0xa3, 0xe, 0x50, 0xac, 0x8d, 0xb, 0x37, 0xcb, 0x2b, 0x10, 0xa3, 0x43, 0x61, 0xec, 0xd7, 0xab, 0xca, 0xd9, 0x20, 0x5d, 0xd0, 0x83, 0x46, 0x12, 0x2e")
MAKE_THUNK(libvulkan, vkWaitSemaphores, "0xdd, 0xf, 0x5c, 0x67, 0x54, 0x12, 0x41, 0xb5, 0xda, 0xcb, 0x9f, 0xb9, 0xc8, 0x38, 0xb7, 0xc3, 0x7c, 0xdd, 0xa1, 0xc8, 0xd1, 0xe5, 0x8e, 0xc1, 0x54, 0x77, 0xb4, 0xd4, 0x67, 0x1f, 0x90, 0x54")
MAKE_THUNK(libvulkan, vkSignalSemaphore, "0x49, 0x97, 0x2d, 0xf8, 0x3a, 0x8c, 0xdd, 0x3b, 0xdb, 0xa0, 0x4e, 0x4, 0x9a, 0x87, 0x45, 0x14, 0xde, 0xc2, 0x2b, 0x50, 0xc0, 0x3a, 0xa7, 0xf0, 0xc6, 0xd8, 0xd4, 0x3e, 0x21, 0x7b, 0xb8, 0xce")
MAKE_THUNK(libvulkan, vkGetBufferDeviceAddress, "0xda, 0xd3, 0x9d, 0x3b, 0x50, 0x1e, 0x48, 0x42, 0xde, 0x5a, 0xbe, 0x5, 0x84, 0xaa, 0x2a, 0x5b, 0xba, 0x53, 0x47, 0x34, 0x2f, 0x51, 0xd0, 0xeb, 0x1a, 0xba, 0x6e, 0x12, 0x66, 0x55, 0x8c, 0xa3")
MAKE_THUNK(libvulkan, vkGetBufferOpaqueCaptureAddress, "0x2c, 0x5c, 0xf3, 0xa4, 0xd5, 0xe7, 0xa5, 0x9e, 0x43, 0xac, 0xf9, 0x94, 0xa3, 0x30, 0x12, 0x66, 0x4a, 0x55, 0x1d, 0xd7, 0x2e, 0x3, 0x64, 0x75, 0xeb, 0xfc, 0x9e, 0x3, 0x4e, 0xc6, 0xdd, 0x93")
MAKE_THUNK(libvulkan, vkGetDeviceMemoryOpaqueCaptureAddress, "0xa4, 0xa6, 0x12, 0xa9, 0x11, 0xbb, 0xdd, 0x3c, 0xd, 0xa0, 0xbd, 0x9e, 0xef, 0xc7, 0x43, 0xbe, 0x7d, 0x7f, 0x80, 0x24, 0xac, 0xcf, 0x2a, 0x5, 0x23, 0x27, 0x3b, 0xf8, 0xc5, 0xd6, 0xef, 0xc9")
MAKE_THUNK(libvulkan, vkCmdDrawIndirectCount, "0x97, 0x2c, 0x9, 0x3c, 0x5c, 0xa, 0x4d, 0xb7, 0x92, 0x50, 0x82, 0xfe, 0x61, 0x92, 0xd2, 0x57, 0xd3, 0x4c, 0x48, 0x46, 0xf7, 0x12, 0x79, 0x2a, 0x3c, 0x69, 0xc0, 0xe8, 0xdb, 0xa3, 0xd5, 0xfa")
MAKE_THUNK(libvulkan, vkCmdDrawIndexedIndirectCount, "0x2c, 0xad, 0x58, 0x18, 0x58, 0xbc, 0x41, 0x6a, 0xa3, 0x4b, 0x98, 0x76, 0x6b, 0x37, 0x30, 0x7f, 0x7e, 0xf3, 0x6b, 0xb9, 0x89, 0xd0, 0x5d, 0xd1, 0x24, 0xdb, 0xa0, 0x3a, 0xbc, 0x86, 0xa4, 0xbf")
MAKE_THUNK(libvulkan, vkCreateRenderPass2, "0x8b, 0x29, 0xc0, 0x57, 0x21, 0xd0, 0x25, 0xa2, 0x50, 0xff, 0xe9, 0xbc, 0xa9, 0x29, 0xa0, 0x66, 0xd1, 0x9f, 0xd6, 0x27, 0x5c, 0x6f, 0xfc, 0x9e, 0xc9, 0xb1, 0xb, 0x54, 0x6f, 0xe2, 0x86, 0xf5")
MAKE_THUNK(libvulkan, vkCmdBeginRenderPass2, "0x2f, 0x56, 0x3c, 0x8e, 0xb8, 0x11, 0x3c, 0x1a, 0xaf, 0x5d, 0xe2, 0x26, 0xd7, 0xfc, 0xab, 0x7d, 0x5e, 0x5b, 0xe3, 0x1f, 0xc7, 0xeb, 0xab, 0xa0, 0xd6, 0x78, 0x7e, 0x8a, 0x9a, 0x50, 0xef, 0x4")
MAKE_THUNK(libvulkan, vkCmdNextSubpass2, "0x99, 0x23, 0xdc, 0xe, 0x81, 0x7e, 0x1, 0x5e, 0xe3, 0x46, 0xf7, 0x79, 0xe2, 0x93, 0x44, 0xc5, 0x17, 0x45, 0x3f, 0x60, 0xe5, 0xd3, 0xa9, 0x8d, 0x52, 0xd5, 0xd8, 0x7, 0xee, 0x86, 0x16, 0xf2")
MAKE_THUNK(libvulkan, vkCmdEndRenderPass2, "0xe6, 0xa3, 0xb8, 0x50, 0xb2, 0x88, 0xb2, 0x71, 0xbf, 0x61, 0x10, 0xa6, 0x23, 0x6d, 0xf4, 0x31, 0x4b, 0x4c, 0xbd, 0xf9, 0x4b, 0xd7, 0xbb, 0xbe, 0xe4, 0x8d, 0xc9, 0xcc, 0xa5, 0xd3, 0x61, 0x9d")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceToolProperties, "0x86, 0xab, 0x28, 0xf, 0xa4, 0xd1, 0x86, 0x5d, 0x71, 0x6b, 0x5a, 0xb7, 0xf5, 0x8c, 0xff, 0xea, 0xd9, 0x8, 0x8e, 0xa3, 0xf0, 0x56, 0x64, 0x2e, 0xaf, 0x29, 0x8c, 0x49, 0xed, 0x3a, 0xb8, 0x84")
MAKE_THUNK(libvulkan, vkCreatePrivateDataSlot, "0xa1, 0xe3, 0x2, 0x4f, 0x3d, 0xd0, 0xee, 0x3e, 0x79, 0x8a, 0x84, 0xc0, 0x46, 0xf2, 0x48, 0x68, 0x13, 0x12, 0xd9, 0x6c, 0xb8, 0x3a, 0xba, 0x5b, 0x65, 0x26, 0x57, 0x79, 0x38, 0x97, 0x13, 0x5d")
MAKE_THUNK(libvulkan, vkDestroyPrivateDataSlot, "0xf2, 0x6a, 0xb6, 0xfb, 0x6, 0xe5, 0xca, 0xc1, 0xf2, 0xb7, 0x95, 0x99, 0xb7, 0xfd, 0x86, 0x33, 0x4e, 0x74, 0xe0, 0xaa, 0x12, 0xa1, 0x97, 0xee, 0x37, 0xd, 0x95, 0x7c, 0xd9, 0xbe, 0xef, 0x98")
MAKE_THUNK(libvulkan, vkSetPrivateData, "0x6f, 0x25, 0xf6, 0x48, 0xfd, 0xbd, 0x5, 0x7f, 0x53, 0xf3, 0x49, 0x80, 0xcc, 0x29, 0x7b, 0xe4, 0x10, 0x5b, 0x60, 0xaf, 0xf6, 0xfc, 0xb4, 0xbc, 0xc9, 0xb, 0x24, 0x86, 0xa7, 0x9e, 0x1, 0x2b")
MAKE_THUNK(libvulkan, vkGetPrivateData, "0x32, 0x2e, 0x38, 0xd1, 0x80, 0xc0, 0xd3, 0xaf, 0xb7, 0x8, 0x3f, 0x19, 0xad, 0xab, 0xa, 0x23, 0xd5, 0xff, 0x4c, 0xbd, 0xf7, 0x84, 0xe8, 0xe, 0x7c, 0x20, 0x35, 0x14, 0x5a, 0x8c, 0x7, 0x66")
MAKE_THUNK(libvulkan, vkCmdPipelineBarrier2, "0xd5, 0xe1, 0xbc, 0x1b, 0x78, 0x4b, 0x4e, 0xf7, 0x7e, 0x2, 0x21, 0xa4, 0xf5, 0x43, 0x46, 0xb0, 0xdd, 0xea, 0xd4, 0xdb, 0xe6, 0x6d, 0xbb, 0xdc, 0x18, 0x6e, 0xd3, 0x2, 0x54, 0xff, 0xf7, 0x84")
MAKE_THUNK(libvulkan, vkCmdWriteTimestamp2, "0x5, 0x7a, 0x1c, 0x35, 0x0, 0x45, 0x33, 0x38, 0x9, 0xbd, 0xc9, 0xbf, 0x49, 0x16, 0x7d, 0xb2, 0x11, 0x4e, 0x6f, 0xc4, 0x7c, 0x27, 0x74, 0x7e, 0x50, 0xfd, 0x75, 0xef, 0xae, 0x97, 0x21, 0xdf")
MAKE_THUNK(libvulkan, vkQueueSubmit2, "0x55, 0xa9, 0xbe, 0xd7, 0x79, 0x49, 0x6a, 0x88, 0x6, 0xe9, 0x31, 0xf6, 0xce, 0xcf, 0xc3, 0x36, 0x34, 0x22, 0xec, 0x33, 0xb7, 0xac, 0x2a, 0x7c, 0x4b, 0x1c, 0x1c, 0xbb, 0x8a, 0xc1, 0xa7, 0xd")
MAKE_THUNK(libvulkan, vkCmdCopyBuffer2, "0xcf, 0xb9, 0xe9, 0xc4, 0xc4, 0x20, 0x14, 0x27, 0xc, 0xe3, 0x71, 0xb, 0xd7, 0x4f, 0xba, 0x2e, 0x35, 0xf7, 0x2a, 0xbb, 0xdd, 0xaa, 0xd, 0x75, 0x78, 0x20, 0x1c, 0x5d, 0x35, 0x3b, 0x5b, 0x7f")
MAKE_THUNK(libvulkan, vkCmdCopyImage2, "0x44, 0xeb, 0xb6, 0x51, 0xc7, 0x94, 0x3a, 0xb3, 0x6f, 0xd6, 0xa6, 0x58, 0xe6, 0xed, 0xf7, 0xb0, 0x7f, 0xdc, 0x90, 0xe2, 0xb6, 0xf4, 0xe2, 0xc3, 0x66, 0xe8, 0x39, 0x19, 0xa9, 0xf, 0xcd, 0xb9")
MAKE_THUNK(libvulkan, vkCmdCopyBufferToImage2, "0x43, 0xa2, 0x85, 0xe0, 0x7b, 0xc2, 0x8b, 0x71, 0x38, 0x7, 0x65, 0x87, 0xbc, 0xe8, 0x49, 0x58, 0x88, 0x69, 0xcd, 0x2c, 0x28, 0x6b, 0xab, 0xe3, 0xae, 0xde, 0x2a, 0x48, 0x60, 0xfa, 0x6, 0xbc")
MAKE_THUNK(libvulkan, vkCmdCopyImageToBuffer2, "0x8b, 0x16, 0xf6, 0x14, 0xc2, 0x30, 0xb5, 0x8c, 0xae, 0xea, 0x9f, 0xea, 0x51, 0x1a, 0x1a, 0xaa, 0x46, 0xa7, 0x72, 0xf, 0x87, 0x54, 0x44, 0x75, 0x61, 0x20, 0x49, 0x4a, 0xa4, 0xa6, 0xb6, 0x1f")
MAKE_THUNK(libvulkan, vkGetDeviceBufferMemoryRequirements, "0xa3, 0xd4, 0xa5, 0x3a, 0x4a, 0xde, 0x6b, 0xe2, 0xdd, 0x23, 0x3f, 0xb1, 0x77, 0x65, 0x9e, 0x47, 0xda, 0x21, 0x6b, 0x44, 0x9e, 0xc8, 0x97, 0xba, 0x91, 0x8d, 0x2e, 0xa0, 0x38, 0x1a, 0xe1, 0xc5")
MAKE_THUNK(libvulkan, vkGetDeviceImageMemoryRequirements, "0x6, 0x8c, 0x48, 0x87, 0x9e, 0xbc, 0x32, 0xd7, 0xa5, 0xf2, 0xef, 0x87, 0x7d, 0x9f, 0x9, 0xce, 0x7, 0xa, 0x4e, 0x6e, 0xdb, 0x74, 0x1e, 0x43, 0x8b, 0xdb, 0xd8, 0xa5, 0x25, 0x6f, 0xb1, 0x9e")
MAKE_THUNK(libvulkan, vkGetDeviceImageSparseMemoryRequirements, "0x2, 0xda, 0xf1, 0xd1, 0xf4, 0x7c, 0x3d, 0x85, 0x4f, 0xf8, 0x66, 0x20, 0xdf, 0xee, 0xe0, 0x7, 0xb6, 0x6, 0x9d, 0xfb, 0x56, 0x72, 0x52, 0x43, 0xe5, 0x3b, 0x7a, 0xf5, 0x5a, 0xa, 0x34, 0x6e")
MAKE_THUNK(libvulkan, vkCmdSetEvent2, "0x73, 0xe7, 0xd5, 0x36, 0x4f, 0x44, 0x6e, 0xe3, 0x9a, 0xe9, 0x49, 0x98, 0x7, 0xa7, 0xf2, 0x2b, 0xff, 0x4a, 0x26, 0xf8, 0x3d, 0xdb, 0xe6, 0x91, 0xa4, 0xef, 0xfc, 0xe1, 0xf4, 0x8, 0x4b, 0x61")
MAKE_THUNK(libvulkan, vkCmdResetEvent2, "0x4f, 0x72, 0xc1, 0x69, 0xec, 0x27, 0x96, 0x80, 0x7b, 0x19, 0xd4, 0xa3, 0xb6, 0x83, 0x15, 0x7f, 0x94, 0xb8, 0x47, 0xdf, 0xf6, 0xfd, 0xe9, 0x46, 0xa6, 0x5a, 0x2a, 0x7e, 0x13, 0xce, 0x87, 0x7d")
MAKE_THUNK(libvulkan, vkCmdWaitEvents2, "0x14, 0x9d, 0x3e, 0x9d, 0xdb, 0x54, 0x3, 0xf3, 0x95, 0x67, 0xeb, 0x92, 0xb6, 0xd7, 0x32, 0x1e, 0xd5, 0xed, 0x97, 0x87, 0x29, 0xc6, 0x31, 0xb4, 0x8d, 0xee, 0x94, 0x9b, 0x0, 0xb1, 0xff, 0x12")
MAKE_THUNK(libvulkan, vkCmdBlitImage2, "0x15, 0x6e, 0xa6, 0xa1, 0x31, 0xc, 0x6e, 0xd0, 0x21, 0x57, 0x61, 0xcf, 0x7f, 0xdc, 0x38, 0xc0, 0x14, 0xa2, 0x14, 0x14, 0x54, 0xf7, 0x3c, 0x3d, 0x1a, 0x70, 0xd, 0xd9, 0xf1, 0xb4, 0xa3, 0xb1")
MAKE_THUNK(libvulkan, vkCmdResolveImage2, "0x7f, 0x2e, 0x31, 0x9f, 0x64, 0xac, 0x1c, 0xe1, 0xd5, 0x6b, 0x32, 0xdf, 0x78, 0x96, 0xc7, 0xa9, 0x1c, 0xb4, 0x30, 0xf3, 0x93, 0x7f, 0xf3, 0x80, 0x8e, 0xf4, 0x5a, 0x23, 0x7, 0x3d, 0x95, 0x63")
MAKE_THUNK(libvulkan, vkCmdBeginRendering, "0x78, 0x86, 0xd4, 0x71, 0x23, 0x3a, 0x10, 0xba, 0x41, 0x90, 0xff, 0xde, 0x3, 0xd0, 0x79, 0x5c, 0x87, 0x53, 0xca, 0x59, 0xe4, 0x7, 0x2e, 0x6b, 0x6b, 0x34, 0xc, 0x6e, 0x4d, 0xea, 0x4b, 0x6f")
MAKE_THUNK(libvulkan, vkCmdEndRendering, "0x75, 0x93, 0xd3, 0xdf, 0xf2, 0x48, 0xcf, 0xd, 0x19, 0xe3, 0xe0, 0xd3, 0xd6, 0x5, 0x40, 0x97, 0x42, 0xca, 0x10, 0xed, 0x2b, 0x82, 0xd8, 0x20, 0x21, 0xe5, 0x9f, 0xdb, 0x9, 0xa0, 0xf9, 0x2a")
MAKE_THUNK(libvulkan, vkCmdSetCullMode, "0x71, 0x38, 0xf5, 0x11, 0x34, 0x56, 0x56, 0x9b, 0xb, 0xfe, 0xb5, 0xa4, 0x95, 0x4b, 0x6, 0xec, 0x57, 0x3c, 0xf6, 0xaf, 0xd7, 0xb4, 0xc, 0xe7, 0x14, 0x28, 0x1d, 0x6, 0xe5, 0x46, 0x75, 0x9d")
MAKE_THUNK(libvulkan, vkCmdSetFrontFace, "0x57, 0xf0, 0xdc, 0xeb, 0xcf, 0xda, 0x3c, 0x95, 0x5a, 0xe7, 0x68, 0x86, 0x83, 0x1a, 0x67, 0x58, 0x76, 0xa0, 0xb3, 0xee, 0x76, 0x4f, 0xab, 0x41, 0x3b, 0xc2, 0x5a, 0x2b, 0x22, 0x75, 0x1b, 0x78")
MAKE_THUNK(libvulkan, vkCmdSetPrimitiveTopology, "0xfb, 0x30, 0xf4, 0xcc, 0x3c, 0x60, 0xa2, 0x16, 0x16, 0xa6, 0x7d, 0x19, 0x26, 0x9, 0xc6, 0xef, 0xfc, 0xd5, 0x29, 0x2f, 0x7f, 0x16, 0xe6, 0xc9, 0xf1, 0x10, 0x5f, 0x6a, 0xbc, 0xb2, 0x37, 0x60")
MAKE_THUNK(libvulkan, vkCmdSetViewportWithCount, "0x26, 0xc8, 0x49, 0xc6, 0x40, 0x25, 0xe5, 0x9, 0x19, 0x9e, 0xd, 0x18, 0x8e, 0xb9, 0x9c, 0xac, 0x47, 0x4f, 0xd4, 0x9f, 0xc1, 0xc4, 0xa1, 0xab, 0x98, 0xe0, 0x1b, 0xe4, 0x4f, 0x41, 0x3f, 0xa9")
MAKE_THUNK(libvulkan, vkCmdSetScissorWithCount, "0x46, 0x6d, 0x39, 0xd6, 0xf0, 0x31, 0xf6, 0x37, 0xa9, 0x2b, 0xd7, 0x6f, 0x84, 0xc0, 0xa, 0xdd, 0xcf, 0x4f, 0x93, 0xd9, 0x1e, 0x70, 0xa, 0x91, 0x14, 0xbb, 0xde, 0x9f, 0x19, 0x71, 0xf, 0xff")
MAKE_THUNK(libvulkan, vkCmdBindVertexBuffers2, "0x0, 0x9d, 0x28, 0xca, 0x6f, 0x47, 0xd8, 0xd9, 0x50, 0xae, 0xd9, 0xfe, 0x19, 0xe3, 0xf2, 0x92, 0xbe, 0x94, 0x75, 0xa7, 0x61, 0x23, 0x1f, 0x91, 0x27, 0x62, 0x45, 0x3d, 0x9d, 0x38, 0x6f, 0xa0")
MAKE_THUNK(libvulkan, vkCmdSetDepthTestEnable, "0xf6, 0x76, 0xe7, 0xae, 0xfd, 0x4c, 0xd3, 0x38, 0x61, 0xdb, 0x67, 0x3e, 0xa8, 0x7f, 0x78, 0xda, 0xa4, 0x9c, 0x11, 0x8f, 0x1b, 0xad, 0xae, 0xcf, 0x19, 0x6a, 0xbf, 0x2e, 0x85, 0xd2, 0x52, 0xe1")
MAKE_THUNK(libvulkan, vkCmdSetDepthWriteEnable, "0xc5, 0x14, 0xb3, 0x3b, 0x37, 0x8c, 0xe9, 0x89, 0x78, 0x8a, 0x31, 0x2c, 0x4, 0xcc, 0x86, 0xb9, 0x52, 0xe1, 0x9, 0x20, 0xa4, 0x81, 0x30, 0x3e, 0xee, 0xe1, 0xcc, 0x90, 0xf0, 0x40, 0xc5, 0xf0")
MAKE_THUNK(libvulkan, vkCmdSetDepthCompareOp, "0x79, 0x30, 0xf8, 0x51, 0xbb, 0xf8, 0xc7, 0x67, 0xa2, 0xb1, 0x20, 0xf5, 0x8c, 0xc7, 0xdf, 0xb7, 0xed, 0xf, 0xf, 0xc3, 0xb4, 0x69, 0x76, 0x5b, 0xa0, 0xfe, 0x7c, 0x14, 0x85, 0x15, 0x2a, 0xf")
MAKE_THUNK(libvulkan, vkCmdSetDepthBoundsTestEnable, "0xfa, 0x93, 0xa6, 0x63, 0x45, 0x83, 0x5, 0x2b, 0xa2, 0xf8, 0x6, 0xb3, 0x2f, 0x1a, 0xdb, 0xb8, 0x44, 0x66, 0x5c, 0x87, 0x90, 0xdd, 0x58, 0xd2, 0x72, 0x68, 0xd3, 0x7d, 0xbe, 0x23, 0x54, 0x9e")
MAKE_THUNK(libvulkan, vkCmdSetStencilTestEnable, "0x96, 0x85, 0x5d, 0x51, 0xc9, 0xbc, 0x95, 0xc6, 0x6c, 0x92, 0xd9, 0xe5, 0x61, 0x99, 0xc5, 0xad, 0x19, 0x5d, 0xba, 0x29, 0x2b, 0xa4, 0xd4, 0x17, 0x6c, 0x35, 0x9b, 0xd2, 0x3, 0x84, 0x2e, 0x11")
MAKE_THUNK(libvulkan, vkCmdSetStencilOp, "0x16, 0x1, 0x4b, 0xce, 0x39, 0x6, 0xc6, 0x2e, 0xb7, 0x58, 0xe9, 0x37, 0x82, 0x8, 0xb5, 0x5d, 0x79, 0x10, 0xbe, 0x76, 0xe0, 0xe6, 0xb1, 0x3f, 0xae, 0x6a, 0x3c, 0x7f, 0xcc, 0xb1, 0x10, 0x7d")
MAKE_THUNK(libvulkan, vkCmdSetRasterizerDiscardEnable, "0x62, 0x8f, 0x95, 0x83, 0xdb, 0x5a, 0x12, 0xcf, 0x39, 0x60, 0x42, 0x5b, 0xf0, 0x2f, 0x33, 0x95, 0xb6, 0x42, 0xab, 0x63, 0x4e, 0xe, 0x4e, 0x1d, 0x36, 0x80, 0x35, 0x66, 0x48, 0x3, 0x4c, 0xe6")
MAKE_THUNK(libvulkan, vkCmdSetDepthBiasEnable, "0x3e, 0xf9, 0x2b, 0x8f, 0x20, 0x30, 0xc, 0xf7, 0xc4, 0xfd, 0xfa, 0x6b, 0xed, 0xd2, 0x35, 0xee, 0x64, 0x95, 0x39, 0x6b, 0x46, 0xbc, 0xba, 0x6e, 0xca, 0xbb, 0x6e, 0xc5, 0x77, 0x3e, 0xf5, 0x36")
MAKE_THUNK(libvulkan, vkCmdSetPrimitiveRestartEnable, "0xe, 0x10, 0x66, 0x4, 0x6f, 0xa7, 0x5e, 0x85, 0xc5, 0x8f, 0xa8, 0x72, 0x19, 0xfb, 0xb7, 0xa5, 0x8d, 0x74, 0x35, 0x5a, 0xcd, 0x55, 0xc0, 0xdf, 0xfc, 0x3, 0x2, 0x9f, 0x8f, 0x6b, 0x85, 0xfa")
MAKE_THUNK(libvulkan, vkMapMemory2, "0x55, 0x4e, 0xa0, 0x68, 0xda, 0xd9, 0x5f, 0x60, 0x4c, 0x7, 0x64, 0x35, 0x62, 0xad, 0x90, 0x1e, 0x38, 0x6d, 0xc8, 0x9d, 0x2b, 0x2b, 0xb, 0x63, 0xa9, 0xce, 0x52, 0x2a, 0x12, 0x72, 0x65, 0x91")
MAKE_THUNK(libvulkan, vkUnmapMemory2, "0x50, 0x38, 0x20, 0x3b, 0xc6, 0xe5, 0x6b, 0x53, 0xf4, 0x82, 0xd8, 0x30, 0x33, 0x26, 0x7, 0xc0, 0x19, 0x6, 0x7a, 0xba, 0xe3, 0x16, 0x5c, 0x45, 0xd0, 0x2f, 0xb6, 0x97, 0x65, 0xec, 0x88, 0xdc")
MAKE_THUNK(libvulkan, vkGetDeviceImageSubresourceLayout, "0x90, 0x7d, 0x96, 0x60, 0xc8, 0xee, 0xa2, 0xcd, 0x78, 0xfc, 0xa5, 0x87, 0x58, 0xd8, 0xea, 0xc, 0xdc, 0x3f, 0xb6, 0xe2, 0x50, 0x6b, 0x87, 0x10, 0xd2, 0xba, 0x5f, 0x28, 0x81, 0x7, 0x38, 0x9a")
MAKE_THUNK(libvulkan, vkGetImageSubresourceLayout2, "0xd1, 0x6e, 0xfe, 0xe4, 0x2a, 0xb3, 0xe9, 0xbf, 0x69, 0xea, 0x6b, 0x24, 0x59, 0x67, 0x91, 0x9c, 0x23, 0x92, 0x94, 0x36, 0xff, 0x75, 0xd, 0x67, 0xf, 0x2e, 0x7, 0xfb, 0xf8, 0x98, 0xf, 0xda")
MAKE_THUNK(libvulkan, vkCopyMemoryToImage, "0x4, 0x3f, 0x8a, 0xe4, 0xc4, 0xc3, 0x5b, 0xb6, 0x85, 0xe0, 0x64, 0xe9, 0x18, 0xc8, 0x48, 0xd2, 0xd0, 0x26, 0xe3, 0xa0, 0x1d, 0x46, 0xbf, 0xc3, 0xb2, 0x88, 0x38, 0x72, 0x27, 0xdd, 0xf1, 0x6d")
MAKE_THUNK(libvulkan, vkCopyImageToMemory, "0x21, 0x6c, 0x4f, 0x1c, 0x6, 0xaa, 0x4e, 0xa1, 0x5, 0x79, 0xb2, 0x30, 0xbf, 0xcd, 0x96, 0xc8, 0x78, 0xd5, 0xfc, 0x72, 0xdf, 0x6, 0x51, 0x4e, 0x9b, 0xb, 0x19, 0xd3, 0xf2, 0xfb, 0x26, 0xce")
MAKE_THUNK(libvulkan, vkCopyImageToImage, "0x8c, 0xc7, 0x31, 0x5c, 0xc6, 0xec, 0x1a, 0x35, 0xc4, 0x4c, 0xdf, 0x78, 0x35, 0x14, 0x88, 0xc8, 0xe2, 0x8, 0x7f, 0x53, 0x10, 0xec, 0x5a, 0x48, 0x92, 0xc0, 0xe3, 0xed, 0xdb, 0x9a, 0xdf, 0x11")
MAKE_THUNK(libvulkan, vkTransitionImageLayout, "0xfc, 0xf4, 0xb8, 0x87, 0x1f, 0xff, 0x39, 0x5c, 0x0, 0x84, 0x3e, 0xd4, 0xdc, 0xe7, 0x4c, 0x42, 0x70, 0xdc, 0xca, 0x10, 0xd5, 0x1c, 0xf8, 0x94, 0xe, 0xbb, 0x82, 0x8d, 0xbc, 0xf8, 0xc, 0xe9")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSet, "0x41, 0x84, 0x76, 0x52, 0xa4, 0xaf, 0x36, 0x4a, 0x49, 0x6a, 0x13, 0x7a, 0x6f, 0x2a, 0x7e, 0x9c, 0x2c, 0x4, 0xa, 0x46, 0xe5, 0xcc, 0xa5, 0xc3, 0xa9, 0x5b, 0xf6, 0x59, 0x4, 0xb2, 0x8b, 0xa8")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSetWithTemplate, "0x96, 0x19, 0xd9, 0xbb, 0x78, 0xe5, 0xd5, 0xdd, 0xbd, 0xd4, 0xc3, 0xcd, 0xae, 0xde, 0xa6, 0x68, 0xd2, 0xb4, 0xd8, 0x3e, 0x6e, 0x24, 0x94, 0xc1, 0x14, 0x39, 0x4, 0x9d, 0xa4, 0x52, 0xa8, 0x1a")
MAKE_THUNK(libvulkan, vkCmdBindDescriptorSets2, "0x4b, 0xe1, 0xf4, 0x5b, 0xd, 0x5e, 0x8, 0x34, 0xca, 0x3d, 0x5c, 0xcd, 0x77, 0xc, 0xbe, 0x30, 0xb7, 0x2f, 0x5f, 0x8, 0x60, 0x50, 0x92, 0x6d, 0x58, 0x14, 0x15, 0x94, 0x45, 0x6f, 0x30, 0xd7")
MAKE_THUNK(libvulkan, vkCmdPushConstants2, "0x6c, 0x4f, 0x65, 0x56, 0xaa, 0xe0, 0x10, 0x74, 0xef, 0xed, 0x7, 0x6a, 0xc, 0x24, 0x39, 0xea, 0xd4, 0xb8, 0xe4, 0xc1, 0x83, 0x9b, 0xbd, 0xd, 0x75, 0xce, 0x9e, 0x8d, 0x85, 0x68, 0xfe, 0x22")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSet2, "0xbd, 0xcc, 0x36, 0x15, 0xea, 0x64, 0x5e, 0x86, 0x24, 0xdf, 0x54, 0x17, 0x90, 0x27, 0x8d, 0xed, 0x43, 0x94, 0x2e, 0xd8, 0xe7, 0xad, 0xfc, 0xc7, 0xa6, 0x36, 0x48, 0xbf, 0xb7, 0x52, 0x79, 0xa7")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSetWithTemplate2, "0xcf, 0x10, 0x43, 0x33, 0x41, 0x1b, 0x6d, 0xd9, 0x8a, 0x5d, 0xda, 0xdd, 0x44, 0x86, 0x2c, 0xf1, 0x17, 0x6a, 0xd0, 0xa8, 0x88, 0x87, 0xf, 0x5f, 0xbd, 0x1d, 0xc0, 0x8b, 0x8, 0x51, 0xff, 0x1")
MAKE_THUNK(libvulkan, vkCmdSetLineStipple, "0x8a, 0xfb, 0xc5, 0x18, 0xa5, 0x97, 0x84, 0x76, 0x93, 0xc1, 0xd8, 0xcc, 0xe1, 0x80, 0x2d, 0xf9, 0x67, 0x74, 0x20, 0x22, 0x6c, 0xff, 0x26, 0x6e, 0x43, 0xfe, 0xa, 0x8e, 0xcd, 0x1c, 0x16, 0xce")
MAKE_THUNK(libvulkan, vkCmdBindIndexBuffer2, "0x23, 0x11, 0x26, 0xef, 0x48, 0x22, 0xd3, 0xba, 0x2, 0x6c, 0xdf, 0x28, 0x5e, 0xdf, 0x8d, 0xea, 0xa9, 0x92, 0xfd, 0x5f, 0x76, 0xbb, 0x9b, 0xb9, 0x5b, 0xb1, 0x7e, 0x2a, 0xf2, 0x10, 0xaf, 0xa5")
MAKE_THUNK(libvulkan, vkGetRenderingAreaGranularity, "0x29, 0x6, 0x4c, 0x60, 0x32, 0xd8, 0xd7, 0x55, 0xe1, 0x5a, 0xb1, 0xe0, 0xef, 0xc7, 0xf4, 0x23, 0x7c, 0x4d, 0x89, 0x4b, 0xc4, 0x7d, 0x66, 0x1f, 0xe1, 0xba, 0x97, 0xe9, 0x16, 0xf4, 0x62, 0x0")
MAKE_THUNK(libvulkan, vkCmdSetRenderingAttachmentLocations, "0x1f, 0xbc, 0xde, 0x1, 0x31, 0xb1, 0xe7, 0x96, 0xb5, 0xe6, 0xb5, 0xb6, 0x28, 0x61, 0x78, 0xe4, 0xe8, 0xe8, 0x20, 0xfe, 0xe8, 0xeb, 0x84, 0xd5, 0xcb, 0x75, 0x7b, 0xf1, 0x5, 0xaa, 0x47, 0x81")
MAKE_THUNK(libvulkan, vkCmdSetRenderingInputAttachmentIndices, "0x3a, 0xf6, 0x32, 0x80, 0xe1, 0xdd, 0xfd, 0xcc, 0x42, 0x87, 0x76, 0x5d, 0xc5, 0x7f, 0x45, 0xa4, 0xcc, 0x9f, 0x7c, 0xf9, 0x6d, 0x4f, 0xb1, 0x38, 0xa0, 0x5, 0xae, 0x60, 0xee, 0x5b, 0x87, 0xe6")
MAKE_THUNK(libvulkan, vkDestroySurfaceKHR, "0x8c, 0x76, 0x94, 0xd1, 0xa4, 0xc7, 0xf7, 0x38, 0xe2, 0x73, 0x7c, 0x1f, 0xd4, 0x9d, 0x15, 0x55, 0xe1, 0xe0, 0x11, 0x69, 0xe9, 0x87, 0x99, 0xaf, 0x61, 0x71, 0x57, 0x9c, 0xd4, 0xfa, 0x62, 0x31")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSurfaceSupportKHR, "0x5b, 0xb2, 0x19, 0x14, 0xb, 0xfe, 0xc3, 0x36, 0xc7, 0x61, 0xb0, 0x3a, 0x41, 0x3e, 0xbd, 0xb, 0xba, 0xf5, 0xa7, 0xec, 0x19, 0x4, 0xfa, 0x1d, 0x9e, 0xdd, 0x81, 0x28, 0x88, 0x2, 0x7e, 0x5")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSurfaceCapabilitiesKHR, "0xdd, 0x84, 0x18, 0x7f, 0x7a, 0x46, 0xf1, 0x69, 0xc0, 0xe2, 0xa5, 0xa0, 0x3e, 0x81, 0x6e, 0x3f, 0x4b, 0x88, 0xbf, 0x2, 0xf, 0x3d, 0xa5, 0xa2, 0xa0, 0xf3, 0x20, 0x46, 0xd6, 0x37, 0xd5, 0x63")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSurfaceFormatsKHR, "0xb9, 0xd6, 0x3c, 0x89, 0xc4, 0x75, 0xba, 0x6a, 0x49, 0x33, 0x48, 0x99, 0x8e, 0xbc, 0xa4, 0x96, 0x2d, 0xf0, 0xf3, 0xdd, 0xe6, 0x5c, 0x21, 0x38, 0xd1, 0x97, 0x46, 0xd, 0x6d, 0x3c, 0xc1, 0x69")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSurfacePresentModesKHR, "0xf8, 0x38, 0xf8, 0xfe, 0x4e, 0x5b, 0xed, 0x73, 0x63, 0x78, 0xf1, 0xb1, 0xa5, 0xfa, 0xd2, 0x71, 0xf9, 0x49, 0xca, 0x98, 0x8b, 0x69, 0xb, 0xf3, 0x92, 0xec, 0xc9, 0x77, 0x24, 0xb1, 0x2b, 0x5d")
MAKE_THUNK(libvulkan, vkCreateSwapchainKHR, "0x69, 0x0, 0x75, 0x5b, 0x10, 0x6b, 0x1f, 0x4b, 0x52, 0x74, 0xeb, 0xba, 0x3, 0xd3, 0xc5, 0x10, 0xec, 0x27, 0x7f, 0x34, 0x6e, 0x23, 0xaf, 0x32, 0x85, 0xbd, 0x11, 0x9, 0x11, 0xf3, 0xef, 0xfa")
MAKE_THUNK(libvulkan, vkDestroySwapchainKHR, "0xc4, 0x77, 0xba, 0x11, 0x2f, 0x99, 0x72, 0x3, 0xa, 0x56, 0xa2, 0xc3, 0xe0, 0x69, 0x9f, 0xb2, 0x21, 0x6e, 0x7d, 0x4b, 0xfe, 0x81, 0x39, 0x50, 0xae, 0x99, 0x9c, 0x1, 0xb7, 0xfc, 0x95, 0x28")
MAKE_THUNK(libvulkan, vkGetSwapchainImagesKHR, "0x3f, 0x3f, 0xeb, 0x52, 0xf1, 0x1d, 0x6, 0x2f, 0xa3, 0x3e, 0xa4, 0x3d, 0x35, 0x8c, 0x21, 0x0, 0x8a, 0x71, 0xa8, 0xc7, 0xb1, 0x6c, 0x9, 0x3d, 0x5a, 0xde, 0xfe, 0xb5, 0xf5, 0x53, 0xee, 0x87")
MAKE_THUNK(libvulkan, vkAcquireNextImageKHR, "0x46, 0xbf, 0xa3, 0x99, 0xe4, 0x70, 0xdb, 0xbb, 0x1c, 0x76, 0x53, 0x7b, 0xa8, 0xc0, 0xa5, 0xc, 0x14, 0x43, 0x98, 0x26, 0x4e, 0x3e, 0xec, 0x5, 0xbe, 0xdc, 0xc3, 0x28, 0xd0, 0xd2, 0x7, 0x83")
MAKE_THUNK(libvulkan, vkQueuePresentKHR, "0x92, 0xbf, 0x47, 0xd7, 0x30, 0x55, 0x97, 0xf8, 0x8c, 0xae, 0x77, 0xf2, 0x43, 0x66, 0x39, 0xb2, 0x2c, 0x28, 0x99, 0x9a, 0x8f, 0x98, 0xf1, 0x18, 0x51, 0x66, 0xff, 0xdc, 0xe1, 0xa8, 0x60, 0x97")
MAKE_THUNK(libvulkan, vkGetDeviceGroupPresentCapabilitiesKHR, "0x75, 0x16, 0x8e, 0xab, 0x9c, 0xb1, 0x13, 0xd6, 0x17, 0x88, 0x15, 0x55, 0xb2, 0xfa, 0xa1, 0xc0, 0xa2, 0x54, 0xa2, 0x9f, 0x68, 0xc8, 0xc3, 0x1, 0x19, 0x88, 0xdc, 0x1b, 0xd2, 0xff, 0xa1, 0x5a")
MAKE_THUNK(libvulkan, vkGetDeviceGroupSurfacePresentModesKHR, "0xac, 0x80, 0x96, 0xc, 0x4f, 0xdd, 0xd3, 0x20, 0x97, 0x7a, 0xcb, 0xc9, 0xa6, 0x1b, 0x70, 0x83, 0x98, 0xcc, 0x7d, 0xd0, 0x44, 0xab, 0x6, 0x70, 0xa9, 0xa1, 0xe8, 0xfd, 0x1e, 0xe8, 0x30, 0x87")
MAKE_THUNK(libvulkan, vkGetPhysicalDevicePresentRectanglesKHR, "0x6b, 0xf1, 0x84, 0x49, 0x47, 0xd2, 0x16, 0x86, 0x33, 0xb8, 0xb0, 0x6b, 0x77, 0x64, 0x1c, 0x71, 0x43, 0x3c, 0x1a, 0xd2, 0x9e, 0x8, 0xde, 0x10, 0x72, 0x66, 0x53, 0xf2, 0xf9, 0xf1, 0x46, 0xdb")
MAKE_THUNK(libvulkan, vkAcquireNextImage2KHR, "0xef, 0x68, 0x6d, 0x4a, 0x77, 0x2f, 0x9a, 0xb4, 0x38, 0x70, 0x7b, 0xde, 0x74, 0x8c, 0xc3, 0x64, 0x63, 0x3d, 0x4e, 0x3d, 0x6e, 0x0, 0xaf, 0x56, 0xdb, 0x71, 0x51, 0x1, 0x1c, 0x1c, 0x18, 0x41")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceDisplayPropertiesKHR, "0xc5, 0xbb, 0x26, 0x55, 0x7c, 0xa2, 0x61, 0x64, 0x7d, 0xa0, 0x7e, 0x51, 0x14, 0xd3, 0x7a, 0xfa, 0x43, 0x9f, 0xb1, 0x4f, 0x2e, 0x4f, 0xcb, 0x65, 0xed, 0xda, 0x73, 0xf, 0x1d, 0x62, 0x1d, 0x2")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceDisplayPlanePropertiesKHR, "0x71, 0x78, 0x60, 0xa6, 0xcf, 0xb8, 0x9, 0xa5, 0x6a, 0xbb, 0xf5, 0xb9, 0x1c, 0x14, 0x51, 0xa, 0x15, 0x7d, 0x74, 0x9b, 0xb8, 0xff, 0xa0, 0xc4, 0x42, 0xad, 0x90, 0xc0, 0x2d, 0x79, 0x75, 0x84")
MAKE_THUNK(libvulkan, vkGetDisplayPlaneSupportedDisplaysKHR, "0xea, 0x1f, 0x9a, 0x1, 0x8d, 0xa, 0x46, 0x5e, 0x6c, 0xf8, 0x52, 0x49, 0xe3, 0x3a, 0x97, 0x9, 0x5b, 0x10, 0x20, 0xa5, 0xb9, 0x8d, 0x1a, 0x67, 0xc9, 0x92, 0x6, 0x9, 0x49, 0xc, 0x78, 0x34")
MAKE_THUNK(libvulkan, vkGetDisplayModePropertiesKHR, "0x96, 0x22, 0xd6, 0x2, 0x53, 0x43, 0xeb, 0x9e, 0x69, 0x36, 0x26, 0xb1, 0x50, 0xbf, 0xf9, 0x22, 0x7, 0x2c, 0xe2, 0xb4, 0xef, 0x67, 0x6b, 0x34, 0xed, 0xc9, 0x14, 0xea, 0xe9, 0xe0, 0x31, 0x6f")
MAKE_THUNK(libvulkan, vkCreateDisplayModeKHR, "0x11, 0x1f, 0x78, 0x70, 0xae, 0x47, 0x91, 0x57, 0x4c, 0x2e, 0xa, 0xc1, 0xe1, 0x94, 0xda, 0xb8, 0xf6, 0x5c, 0x72, 0x6e, 0xd2, 0x79, 0x89, 0x8d, 0x20, 0xbb, 0x1, 0x95, 0x72, 0xe9, 0x2e, 0xee")
MAKE_THUNK(libvulkan, vkGetDisplayPlaneCapabilitiesKHR, "0xe1, 0x1a, 0x35, 0x2c, 0x12, 0x6b, 0xee, 0x46, 0xce, 0xf4, 0xa6, 0x33, 0xd1, 0x8, 0xfe, 0x55, 0xc7, 0x41, 0x68, 0x9, 0xe3, 0x80, 0x55, 0xb9, 0xc1, 0xcc, 0xfc, 0xf0, 0x97, 0x12, 0x3d, 0x94")
MAKE_THUNK(libvulkan, vkCreateDisplayPlaneSurfaceKHR, "0x88, 0xf5, 0x12, 0xf0, 0x77, 0xfe, 0x37, 0xec, 0x49, 0x99, 0xbb, 0xf8, 0x69, 0xfe, 0xc, 0x4d, 0x4a, 0x3c, 0x9, 0x3c, 0xf7, 0x71, 0x3, 0x3d, 0x24, 0xfd, 0x9b, 0x8d, 0x5b, 0x11, 0x7f, 0x97")
MAKE_THUNK(libvulkan, vkCreateSharedSwapchainsKHR, "0x4e, 0x13, 0xa7, 0x2a, 0xd4, 0xe9, 0xb2, 0x1a, 0x27, 0x99, 0x3, 0xde, 0xaa, 0x0, 0xb3, 0xd2, 0x73, 0xd3, 0x0, 0x31, 0x40, 0xea, 0xa2, 0x7a, 0x95, 0xd4, 0x54, 0x20, 0x23, 0x7d, 0x12, 0xb")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceVideoCapabilitiesKHR, "0x5f, 0xc5, 0xd3, 0x8e, 0x8c, 0x65, 0xc6, 0x8a, 0x1, 0x5b, 0x55, 0x7d, 0xbd, 0x8d, 0x91, 0x29, 0x2d, 0xb9, 0x1e, 0x7a, 0xc6, 0x91, 0x92, 0xc1, 0x2e, 0x94, 0x44, 0xd6, 0xa, 0xf2, 0x31, 0x50")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceVideoFormatPropertiesKHR, "0x66, 0xde, 0x4b, 0xa6, 0xd6, 0x9, 0x77, 0x2d, 0x5d, 0xba, 0xe9, 0x31, 0xe6, 0xcf, 0x25, 0x24, 0x34, 0xda, 0xd1, 0xcb, 0x39, 0x1f, 0x3a, 0x37, 0xf6, 0x98, 0xb0, 0x6a, 0x5d, 0x13, 0x45, 0xcc")
MAKE_THUNK(libvulkan, vkCreateVideoSessionKHR, "0xad, 0x11, 0xfa, 0xda, 0xd9, 0xb4, 0x4, 0x57, 0x1a, 0x70, 0x9d, 0x21, 0x82, 0x59, 0xd6, 0x71, 0x73, 0x84, 0x13, 0x29, 0x99, 0x23, 0x2c, 0x17, 0xdd, 0x4b, 0x5e, 0xba, 0xb1, 0xd0, 0x5f, 0xe7")
MAKE_THUNK(libvulkan, vkDestroyVideoSessionKHR, "0x13, 0x7a, 0x1a, 0xd5, 0x2f, 0xe7, 0x62, 0xf5, 0x36, 0x31, 0x57, 0x99, 0xc5, 0x55, 0x15, 0xfe, 0xb5, 0xa5, 0xd6, 0xc1, 0x3b, 0xa6, 0x68, 0x67, 0xb, 0x95, 0xa2, 0xd9, 0xa5, 0x64, 0x13, 0x5c")
MAKE_THUNK(libvulkan, vkGetVideoSessionMemoryRequirementsKHR, "0x51, 0x43, 0xea, 0xa5, 0x4a, 0xf9, 0x2a, 0xfe, 0xf0, 0x7a, 0x6e, 0xfc, 0xa, 0x48, 0x2a, 0xca, 0xfc, 0xec, 0x1c, 0x8c, 0xaf, 0x99, 0xb5, 0xb9, 0x34, 0x4f, 0xd4, 0x63, 0x13, 0x12, 0x6b, 0x19")
MAKE_THUNK(libvulkan, vkBindVideoSessionMemoryKHR, "0xd8, 0xf9, 0x8e, 0x5e, 0x6f, 0x2e, 0x75, 0xb3, 0x5d, 0xda, 0xd9, 0x43, 0x33, 0x93, 0x77, 0xee, 0x17, 0x93, 0x56, 0x9d, 0xdd, 0x2c, 0xa2, 0xc, 0xf, 0x8c, 0x22, 0x44, 0x70, 0xed, 0x1a, 0xf3")
MAKE_THUNK(libvulkan, vkCreateVideoSessionParametersKHR, "0x27, 0x8a, 0x16, 0x35, 0x83, 0xfc, 0x12, 0x6, 0x76, 0x6, 0x67, 0x63, 0x70, 0xfb, 0xb8, 0x96, 0xb3, 0x7d, 0x45, 0x73, 0x55, 0x46, 0xb0, 0x3a, 0xe8, 0xad, 0x5d, 0xda, 0xce, 0x4b, 0x9a, 0xbb")
MAKE_THUNK(libvulkan, vkUpdateVideoSessionParametersKHR, "0x9f, 0x5b, 0x1e, 0x2e, 0xdd, 0xdc, 0x3f, 0xeb, 0x81, 0xe5, 0xd5, 0x21, 0xd4, 0x68, 0x3, 0xdb, 0xe9, 0x54, 0x6e, 0x6e, 0x49, 0xce, 0x62, 0xc7, 0xd6, 0xd4, 0x9c, 0x99, 0x7c, 0xd0, 0xd4, 0xd9")
MAKE_THUNK(libvulkan, vkDestroyVideoSessionParametersKHR, "0xd4, 0x66, 0x70, 0xf1, 0x90, 0x60, 0x31, 0x9, 0xae, 0x63, 0x30, 0x92, 0x61, 0x83, 0x1b, 0x66, 0x82, 0x16, 0x11, 0x8d, 0x6f, 0xdd, 0xcd, 0x1d, 0xf8, 0x2f, 0x82, 0xa3, 0xbb, 0xa9, 0xdd, 0x4f")
MAKE_THUNK(libvulkan, vkCmdBeginVideoCodingKHR, "0x8f, 0xde, 0x3, 0x92, 0x28, 0xc4, 0xd2, 0x43, 0xd8, 0x83, 0x17, 0x9a, 0xd0, 0x64, 0xa, 0xb8, 0x65, 0xed, 0x4b, 0x56, 0x49, 0x42, 0xa3, 0x88, 0x12, 0x5e, 0xb3, 0x56, 0x32, 0x89, 0x33, 0x7")
MAKE_THUNK(libvulkan, vkCmdEndVideoCodingKHR, "0x48, 0x24, 0x44, 0xf3, 0x99, 0xd, 0x35, 0xcf, 0xae, 0x66, 0xd8, 0x2, 0xbb, 0xae, 0x99, 0x81, 0xbb, 0xdd, 0x90, 0x50, 0xaf, 0x12, 0x32, 0x61, 0x51, 0xfb, 0x70, 0xd7, 0x18, 0x2c, 0xdd, 0x4c")
MAKE_THUNK(libvulkan, vkCmdControlVideoCodingKHR, "0x5e, 0x5c, 0xda, 0x66, 0x77, 0x51, 0xe, 0xd, 0x13, 0xf3, 0xca, 0xf2, 0xe0, 0x4d, 0x4b, 0xa6, 0x65, 0x69, 0x8b, 0x37, 0x3b, 0x0, 0xc4, 0x54, 0xa9, 0xe9, 0x69, 0x9f, 0x24, 0xc7, 0x69, 0x52")
MAKE_THUNK(libvulkan, vkCmdDecodeVideoKHR, "0xa6, 0xfc, 0x40, 0x3b, 0x55, 0x92, 0x98, 0xa8, 0xe4, 0xdb, 0xe7, 0x16, 0x4, 0xfb, 0xb, 0xac, 0x11, 0xad, 0x95, 0x8b, 0x1b, 0x8d, 0x1e, 0x90, 0x27, 0xe7, 0xca, 0x2c, 0x2c, 0x65, 0x59, 0xb2")
MAKE_THUNK(libvulkan, vkCmdBeginRenderingKHR, "0x14, 0xeb, 0xf0, 0x92, 0x54, 0x2f, 0x99, 0x51, 0x99, 0x2e, 0xcb, 0xfb, 0x84, 0x58, 0xc0, 0x6, 0x41, 0x5c, 0xc3, 0x17, 0xdb, 0xe0, 0xea, 0x77, 0x24, 0x38, 0x5, 0xa2, 0x88, 0xca, 0xcf, 0xbf")
MAKE_THUNK(libvulkan, vkCmdEndRenderingKHR, "0x8c, 0xf3, 0xf, 0xd4, 0xdd, 0x1f, 0xd2, 0x5e, 0x2, 0xa, 0x72, 0x9f, 0x67, 0x22, 0x32, 0x8b, 0xd0, 0x50, 0xe4, 0x66, 0xba, 0x27, 0xf1, 0xcf, 0xdc, 0x17, 0xed, 0x23, 0x7a, 0x6e, 0x9c, 0x7f")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceFeatures2KHR, "0x1a, 0x25, 0x41, 0x3b, 0xeb, 0x35, 0xf3, 0xa, 0x9a, 0xdf, 0xc4, 0xbb, 0xcd, 0x9e, 0xb6, 0x1f, 0xc2, 0x84, 0x35, 0x29, 0x70, 0xd8, 0xad, 0x5, 0x3b, 0x5c, 0x35, 0x7e, 0x9e, 0xa3, 0x1f, 0xa9")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceProperties2KHR, "0x84, 0xdc, 0x75, 0xb1, 0xa3, 0x9b, 0x39, 0x2a, 0x10, 0xf0, 0x6e, 0x47, 0x29, 0xcc, 0x8f, 0x3f, 0x61, 0x63, 0x8, 0x60, 0xb8, 0x5a, 0x25, 0x65, 0xb0, 0x5c, 0xdb, 0xec, 0x79, 0x80, 0xe1, 0x5a")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceFormatProperties2KHR, "0x2, 0xf7, 0xe0, 0xd1, 0xe7, 0xe2, 0x11, 0x4c, 0x39, 0xc6, 0xb6, 0x62, 0x3b, 0x8e, 0xba, 0xb0, 0x76, 0xf1, 0xec, 0x57, 0x1b, 0x92, 0xd7, 0x41, 0xe9, 0xbb, 0xb3, 0x54, 0x1f, 0xbf, 0x7e, 0x4a")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceImageFormatProperties2KHR, "0xbd, 0xc0, 0x9, 0x3f, 0xe2, 0x51, 0xa2, 0x4f, 0xe3, 0x18, 0xbd, 0xf6, 0x52, 0x4a, 0x8a, 0xd9, 0x2f, 0xa7, 0x7b, 0xf9, 0x2a, 0xf1, 0xbd, 0x2b, 0x97, 0x95, 0x1, 0xc1, 0x6c, 0xca, 0x59, 0x33")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceQueueFamilyProperties2KHR, "0x11, 0x72, 0x71, 0x13, 0x1c, 0x5b, 0xa7, 0xec, 0x21, 0x6b, 0xb2, 0xda, 0x82, 0xb8, 0x64, 0xfb, 0xa6, 0xfe, 0x72, 0x31, 0x31, 0xfa, 0xaa, 0x99, 0x8d, 0xaa, 0xe8, 0x7f, 0xf4, 0x44, 0x92, 0xdc")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceMemoryProperties2KHR, "0x86, 0x1f, 0xa5, 0x48, 0x81, 0x1e, 0xff, 0xae, 0xb0, 0x1d, 0xbf, 0x4d, 0xa5, 0x2e, 0xf2, 0x3c, 0xa9, 0x3f, 0xf, 0x78, 0x36, 0xa0, 0xc2, 0x7d, 0x8a, 0xbf, 0x8e, 0x47, 0x7f, 0x37, 0x3b, 0x72")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSparseImageFormatProperties2KHR, "0xb8, 0xd8, 0x2f, 0xa4, 0xc3, 0xd9, 0x66, 0x7f, 0x14, 0x61, 0x3c, 0xd9, 0xc4, 0x2f, 0x13, 0x1f, 0xad, 0x7b, 0x35, 0x2c, 0xc4, 0x84, 0x69, 0x3c, 0x78, 0x9c, 0x97, 0x34, 0x5c, 0x83, 0xbc, 0xe0")
MAKE_THUNK(libvulkan, vkGetDeviceGroupPeerMemoryFeaturesKHR, "0x6d, 0x99, 0x73, 0xe8, 0xc9, 0x42, 0x85, 0xb8, 0x74, 0x2e, 0x8f, 0x79, 0x5d, 0x97, 0x43, 0x93, 0x3a, 0x8f, 0x4, 0x4c, 0xa6, 0x53, 0x6, 0xd1, 0x1e, 0xc1, 0xd, 0x5e, 0xa5, 0x2c, 0xe9, 0x8c")
MAKE_THUNK(libvulkan, vkCmdSetDeviceMaskKHR, "0x96, 0x62, 0x1a, 0xcc, 0x74, 0xfd, 0x41, 0xae, 0x4a, 0x5a, 0x48, 0xdd, 0x71, 0x6c, 0x70, 0x5d, 0xee, 0x4e, 0xa1, 0xa7, 0x44, 0x2a, 0x3b, 0xe6, 0xab, 0x81, 0xc6, 0x8d, 0xd0, 0xfd, 0xd9, 0x44")
MAKE_THUNK(libvulkan, vkCmdDispatchBaseKHR, "0xb, 0xa8, 0x9b, 0xc4, 0xa1, 0x41, 0x2d, 0x6e, 0xd1, 0xae, 0xf9, 0xd5, 0x14, 0xa6, 0x22, 0x57, 0x67, 0x16, 0xec, 0x5e, 0x6e, 0xa1, 0x8, 0x4a, 0x8e, 0x23, 0x46, 0xe8, 0xbb, 0xbe, 0x83, 0xff")
MAKE_THUNK(libvulkan, vkTrimCommandPoolKHR, "0x82, 0x9d, 0xd7, 0x9d, 0xed, 0x93, 0x0, 0xf3, 0x29, 0x51, 0x4b, 0x25, 0xdc, 0x77, 0x5, 0xb8, 0x21, 0x14, 0x73, 0xfc, 0xa7, 0xaf, 0x8d, 0xee, 0xaf, 0x43, 0x3c, 0x32, 0x90, 0x2a, 0xfc, 0x17")
MAKE_THUNK(libvulkan, vkEnumeratePhysicalDeviceGroupsKHR, "0x9, 0x63, 0xae, 0xd, 0xa3, 0x26, 0xd1, 0x8e, 0xcf, 0xaa, 0xb2, 0x7c, 0xcf, 0x9f, 0xc6, 0xe, 0x81, 0x18, 0xe0, 0x74, 0x8e, 0x77, 0x4d, 0x4a, 0xcf, 0xc3, 0xa4, 0xd5, 0xb1, 0x9, 0x7c, 0xed")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalBufferPropertiesKHR, "0x89, 0xdf, 0x75, 0xab, 0x76, 0x8b, 0x98, 0xb7, 0x42, 0xd2, 0x10, 0x62, 0xd2, 0x47, 0xcd, 0xa0, 0xe8, 0x62, 0x1a, 0x76, 0x27, 0x71, 0xb, 0xc, 0x20, 0x9e, 0xd5, 0x8c, 0xba, 0x36, 0x7a, 0x91")
MAKE_THUNK(libvulkan, vkGetMemoryFdKHR, "0x20, 0xd3, 0x58, 0x36, 0x3c, 0xa, 0xc8, 0x2b, 0x5b, 0x29, 0xab, 0xa7, 0x17, 0x1c, 0x4e, 0xc1, 0xf8, 0x9a, 0x5c, 0x8e, 0xb8, 0x72, 0x32, 0x11, 0x1d, 0x25, 0x21, 0xd4, 0x62, 0xca, 0x6c, 0x85")
MAKE_THUNK(libvulkan, vkGetMemoryFdPropertiesKHR, "0xfd, 0xf8, 0xa9, 0x85, 0xac, 0x33, 0xa0, 0x25, 0x8, 0xf5, 0xd1, 0xe0, 0x98, 0x8a, 0x69, 0x56, 0x72, 0xa3, 0x42, 0xab, 0x63, 0xb8, 0x76, 0x95, 0x3a, 0x8d, 0x36, 0x90, 0x8d, 0xdf, 0x91, 0x81")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalSemaphorePropertiesKHR, "0x4, 0x31, 0xe7, 0x24, 0xea, 0x4e, 0x3f, 0x53, 0xb3, 0xd7, 0xa8, 0x25, 0x23, 0xc1, 0x88, 0x67, 0xd4, 0x3f, 0xe, 0x29, 0x1c, 0x42, 0xd4, 0x5f, 0x6a, 0xd, 0xe0, 0xa1, 0x49, 0xfe, 0x95, 0xbd")
MAKE_THUNK(libvulkan, vkImportSemaphoreFdKHR, "0x96, 0x91, 0xe3, 0x9f, 0x18, 0x38, 0xe9, 0xe5, 0x52, 0x38, 0x18, 0x21, 0xa8, 0x15, 0xbb, 0x15, 0x46, 0x45, 0x0, 0xf9, 0x26, 0x54, 0x2d, 0xb3, 0x1a, 0x2c, 0xc7, 0x95, 0xee, 0xfd, 0xf, 0x4d")
MAKE_THUNK(libvulkan, vkGetSemaphoreFdKHR, "0xa, 0x8d, 0x10, 0xf8, 0x17, 0x29, 0xff, 0xdc, 0x55, 0x43, 0x92, 0x1e, 0x7c, 0xa2, 0x7d, 0x33, 0xbe, 0x51, 0x8d, 0x6, 0xb4, 0xe7, 0xfe, 0x54, 0x5, 0x1a, 0xdb, 0x28, 0xbe, 0xd7, 0xd9, 0xb9")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSetKHR, "0xbc, 0x6d, 0x89, 0x9b, 0xb1, 0xf6, 0xe1, 0xe1, 0xfc, 0xaa, 0x99, 0x57, 0x1b, 0x93, 0x3c, 0xf3, 0xe5, 0xd7, 0xa1, 0xae, 0xd3, 0xb4, 0xb6, 0x2d, 0x28, 0x68, 0x72, 0xf4, 0x81, 0x13, 0xf4, 0x1")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSetWithTemplateKHR, "0xdd, 0xb9, 0x4c, 0xd, 0xac, 0xcb, 0x6, 0xa0, 0x3b, 0x32, 0x89, 0x21, 0xf2, 0x46, 0xd7, 0xa4, 0xa2, 0xa7, 0xef, 0x15, 0xfb, 0xdd, 0x32, 0xcf, 0x1c, 0xd9, 0x8f, 0x1c, 0xe3, 0x80, 0x89, 0xb5")
MAKE_THUNK(libvulkan, vkCreateDescriptorUpdateTemplateKHR, "0x40, 0x80, 0xd, 0x2b, 0x12, 0x50, 0x1b, 0x61, 0xda, 0x23, 0x53, 0x37, 0x45, 0xa, 0x1e, 0xfe, 0xb, 0xf6, 0x61, 0xc4, 0xd3, 0x76, 0x1b, 0x23, 0xf0, 0x73, 0xf7, 0xfc, 0x99, 0xbe, 0xec, 0x4c")
MAKE_THUNK(libvulkan, vkDestroyDescriptorUpdateTemplateKHR, "0x2b, 0xc6, 0x1d, 0x12, 0x85, 0x42, 0xc4, 0xb1, 0x62, 0x53, 0xe9, 0xd5, 0x42, 0xa7, 0x47, 0xd5, 0x26, 0x6d, 0xb6, 0xa, 0x66, 0x14, 0xc9, 0x69, 0x8d, 0x32, 0xc9, 0xd3, 0xa2, 0x11, 0x68, 0x23")
MAKE_THUNK(libvulkan, vkUpdateDescriptorSetWithTemplateKHR, "0xbd, 0x81, 0x69, 0x0, 0x18, 0x13, 0xb6, 0x20, 0x90, 0x3c, 0x9, 0x3b, 0x2f, 0x28, 0x82, 0x52, 0xc5, 0xc, 0x96, 0x6c, 0xcc, 0xea, 0xe7, 0x1d, 0x78, 0x61, 0x4e, 0x2f, 0xfb, 0x7, 0xcb, 0x90")
MAKE_THUNK(libvulkan, vkCreateRenderPass2KHR, "0x27, 0xe4, 0x34, 0x5a, 0x7c, 0xa6, 0x74, 0x5, 0x40, 0x5a, 0x7c, 0xdd, 0xec, 0xc, 0x89, 0x34, 0x83, 0x7, 0xa6, 0x73, 0xa3, 0x7d, 0xd3, 0xf5, 0x5c, 0xdf, 0x7d, 0xef, 0x79, 0xa4, 0xb8, 0x4f")
MAKE_THUNK(libvulkan, vkCmdBeginRenderPass2KHR, "0x80, 0x79, 0xf6, 0xfa, 0xcc, 0x1c, 0xe4, 0x38, 0x19, 0x48, 0xad, 0x5a, 0xf3, 0x33, 0x8c, 0x68, 0x23, 0x7a, 0x74, 0x94, 0xc3, 0xc3, 0x80, 0x20, 0x2, 0xf0, 0x56, 0x3e, 0xe4, 0xc6, 0x35, 0x3e")
MAKE_THUNK(libvulkan, vkCmdNextSubpass2KHR, "0xe7, 0xd5, 0x15, 0x1f, 0xcd, 0x85, 0x3e, 0x83, 0xe9, 0xd1, 0x6b, 0xb2, 0x25, 0xb, 0x87, 0x96, 0xf5, 0x2c, 0xec, 0x36, 0xab, 0x8b, 0x94, 0x6e, 0xfd, 0x91, 0xb8, 0x3d, 0x45, 0xea, 0x81, 0x1")
MAKE_THUNK(libvulkan, vkCmdEndRenderPass2KHR, "0xb6, 0x15, 0x96, 0xad, 0x40, 0xd3, 0x54, 0x70, 0x12, 0x7e, 0x99, 0xcb, 0xb5, 0xe, 0x6d, 0x7, 0x9d, 0x6f, 0xa4, 0x9, 0xc4, 0xc3, 0x96, 0x32, 0x38, 0xf8, 0x29, 0x90, 0xb9, 0x98, 0xb0, 0xb2")
MAKE_THUNK(libvulkan, vkGetSwapchainStatusKHR, "0x5e, 0xb7, 0xef, 0x42, 0x44, 0x6, 0xcd, 0x46, 0x4, 0x83, 0xa1, 0xf, 0x10, 0x19, 0x75, 0x8a, 0x8c, 0x93, 0xf8, 0x2c, 0x5e, 0x8, 0x34, 0x89, 0x42, 0x8, 0x4c, 0xfc, 0x1a, 0x48, 0x9, 0x21")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalFencePropertiesKHR, "0x96, 0x27, 0x4c, 0x1f, 0xf6, 0x26, 0xdc, 0xfd, 0xc3, 0x38, 0xbb, 0xe8, 0x43, 0x6d, 0x92, 0xa2, 0x66, 0x12, 0x91, 0x46, 0x16, 0x6, 0x9b, 0x7b, 0xaa, 0xd1, 0xfc, 0x29, 0xbe, 0xd5, 0x35, 0x2a")
MAKE_THUNK(libvulkan, vkImportFenceFdKHR, "0xd2, 0xf6, 0xd5, 0x20, 0xdc, 0xa3, 0x3b, 0x6a, 0xa6, 0x3d, 0x94, 0xee, 0x2, 0x23, 0x50, 0x5b, 0x34, 0x80, 0x9c, 0xc9, 0x4a, 0xe5, 0x6b, 0x8e, 0xc0, 0xbb, 0xd8, 0xda, 0x3d, 0x67, 0x8f, 0x93")
MAKE_THUNK(libvulkan, vkGetFenceFdKHR, "0xcc, 0x8e, 0xfe, 0xdf, 0x1d, 0x82, 0x94, 0xb, 0x20, 0x4d, 0x20, 0xb1, 0x5b, 0xc1, 0xe0, 0x59, 0x58, 0x77, 0x83, 0x4a, 0xfd, 0xf4, 0x59, 0x74, 0xc, 0x27, 0x97, 0xc4, 0xbf, 0xe6, 0x40, 0x31")
MAKE_THUNK(libvulkan, vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR, "0x44, 0x7c, 0xc1, 0x67, 0xb2, 0xa2, 0x54, 0x51, 0xb, 0x1e, 0x83, 0xde, 0x6f, 0xa1, 0x3c, 0x15, 0xce, 0x3a, 0x3e, 0x89, 0x97, 0xae, 0x23, 0x8, 0xd2, 0xe5, 0x79, 0x59, 0x6, 0xe1, 0xcc, 0xb7")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR, "0xde, 0x4b, 0x52, 0xb, 0xde, 0xd9, 0xde, 0xd3, 0x22, 0x39, 0x7c, 0x60, 0x87, 0xc2, 0x63, 0x5e, 0xb3, 0x7c, 0xfa, 0x11, 0x97, 0x47, 0xb9, 0xbd, 0x64, 0x7c, 0x37, 0xa3, 0x3a, 0xa4, 0x16, 0x7e")
MAKE_THUNK(libvulkan, vkAcquireProfilingLockKHR, "0x74, 0xbd, 0x1, 0x5d, 0x2c, 0x85, 0x42, 0xac, 0x9c, 0x29, 0x3c, 0x50, 0x8c, 0xfe, 0x16, 0x42, 0xe5, 0x44, 0xdd, 0x99, 0x48, 0xa4, 0xc8, 0xe, 0x5f, 0x7e, 0xf8, 0x28, 0xe3, 0x40, 0x4c, 0x13")
MAKE_THUNK(libvulkan, vkReleaseProfilingLockKHR, "0x93, 0x8, 0x7a, 0xac, 0xf4, 0x4a, 0x47, 0xd2, 0xe0, 0x83, 0x5e, 0xb8, 0x57, 0x25, 0x4, 0x97, 0xec, 0x13, 0xe8, 0xee, 0x84, 0xce, 0xac, 0xe2, 0xab, 0xe7, 0x9, 0x68, 0x60, 0x81, 0x21, 0xc4")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSurfaceCapabilities2KHR, "0x63, 0xb4, 0x9e, 0x4b, 0x20, 0x27, 0x29, 0x3d, 0x1b, 0x1a, 0x25, 0xf9, 0xb5, 0xe0, 0x2d, 0x69, 0xb2, 0x40, 0xfe, 0x46, 0xd0, 0x28, 0x4c, 0x52, 0xf0, 0x74, 0x1f, 0x31, 0x13, 0x1, 0x19, 0x80")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSurfaceFormats2KHR, "0x69, 0x2c, 0x4a, 0x8c, 0xc2, 0x89, 0x14, 0x47, 0x10, 0x6b, 0x82, 0x29, 0x96, 0x7f, 0xcb, 0x14, 0x8f, 0x65, 0x48, 0x31, 0xf6, 0x8d, 0xbd, 0x15, 0xda, 0xe7, 0x52, 0x33, 0x6d, 0xa0, 0x38, 0xdc")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceDisplayProperties2KHR, "0x4e, 0x61, 0x46, 0x27, 0x9d, 0xe4, 0xa4, 0xf5, 0xc0, 0xba, 0x5, 0xdb, 0xb2, 0x21, 0xf0, 0xa1, 0x99, 0x3b, 0x2, 0x51, 0xdb, 0xe1, 0x8, 0xe3, 0xd7, 0x5e, 0x4e, 0xd0, 0x49, 0xac, 0x76, 0x97")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceDisplayPlaneProperties2KHR, "0xbf, 0xab, 0x54, 0x5b, 0xb4, 0x12, 0xdb, 0xc, 0x8a, 0x19, 0x10, 0xe7, 0x6e, 0xca, 0x54, 0xca, 0x7b, 0x3, 0x42, 0x34, 0x46, 0x7d, 0xc9, 0x73, 0x5b, 0x1e, 0x1e, 0xca, 0xc0, 0x4b, 0x18, 0xe6")
MAKE_THUNK(libvulkan, vkGetDisplayModeProperties2KHR, "0xe7, 0x9b, 0xe6, 0xbb, 0xba, 0x2b, 0xee, 0x83, 0x70, 0x87, 0xbd, 0xf6, 0x6f, 0xfa, 0x90, 0xe2, 0x9e, 0xf9, 0xcb, 0x7e, 0x7c, 0xff, 0x9d, 0x36, 0x83, 0x4, 0x20, 0xd, 0x41, 0x35, 0xcf, 0xcc")
MAKE_THUNK(libvulkan, vkGetDisplayPlaneCapabilities2KHR, "0xce, 0x1, 0xd3, 0x40, 0x1a, 0xee, 0xd9, 0x3e, 0x8e, 0x22, 0x42, 0x4, 0x13, 0xe5, 0xe1, 0x53, 0x3c, 0xb5, 0x24, 0xee, 0x3, 0x5, 0xbb, 0x89, 0x46, 0x39, 0x5b, 0xbf, 0x1, 0x6e, 0x4d, 0xaf")
MAKE_THUNK(libvulkan, vkGetImageMemoryRequirements2KHR, "0xcb, 0xa5, 0xb8, 0xb2, 0x4, 0x7, 0xfa, 0x42, 0x51, 0xa2, 0x4f, 0x44, 0x19, 0x3c, 0x24, 0xaf, 0xd1, 0xf7, 0x5b, 0x2f, 0xb1, 0xf2, 0x14, 0xe9, 0x7d, 0x8c, 0x5f, 0x55, 0x55, 0x1c, 0xbb, 0xa")
MAKE_THUNK(libvulkan, vkGetBufferMemoryRequirements2KHR, "0x20, 0x59, 0x0, 0x90, 0x22, 0xb, 0x80, 0x5b, 0x6f, 0x92, 0x2d, 0x19, 0x91, 0x45, 0x4c, 0x7e, 0x56, 0x8c, 0xa1, 0x59, 0x0, 0xa1, 0xb7, 0xc7, 0x31, 0xef, 0x10, 0x1f, 0x41, 0x60, 0xfc, 0xc6")
MAKE_THUNK(libvulkan, vkGetImageSparseMemoryRequirements2KHR, "0x50, 0x79, 0xbe, 0x67, 0x3f, 0x23, 0xa1, 0xa5, 0x50, 0x7f, 0xe0, 0xc6, 0x7e, 0x26, 0x64, 0xde, 0x6, 0x38, 0x1c, 0xfc, 0xeb, 0xaf, 0xc1, 0x4d, 0x14, 0xb4, 0x9a, 0xc5, 0x0, 0x45, 0xbf, 0xd8")
MAKE_THUNK(libvulkan, vkCreateSamplerYcbcrConversionKHR, "0x5f, 0xb9, 0xcd, 0x5c, 0xb2, 0xbe, 0x98, 0xe0, 0x54, 0x2b, 0xa, 0xa5, 0x56, 0xa6, 0xa2, 0xee, 0x89, 0x95, 0xe8, 0x35, 0x20, 0x4c, 0x6b, 0x86, 0x26, 0xfe, 0x5c, 0x3e, 0xfe, 0x69, 0xb6, 0xea")
MAKE_THUNK(libvulkan, vkDestroySamplerYcbcrConversionKHR, "0x20, 0x84, 0x5c, 0xf7, 0xf3, 0x5d, 0xdb, 0x38, 0xe3, 0xa0, 0x2a, 0x62, 0xa3, 0x2, 0x44, 0x45, 0xc, 0xee, 0x2a, 0xa9, 0xb4, 0x54, 0x75, 0xe3, 0x5b, 0x95, 0x42, 0x68, 0x9e, 0xcc, 0xef, 0xde")
MAKE_THUNK(libvulkan, vkBindBufferMemory2KHR, "0x34, 0x7e, 0xe5, 0xe1, 0x5b, 0x3c, 0xf4, 0xaa, 0x81, 0x3c, 0x5c, 0x7d, 0x62, 0x4a, 0xf3, 0x48, 0xfa, 0xa8, 0x8f, 0x18, 0x36, 0x80, 0xb8, 0x62, 0xa9, 0x34, 0xc6, 0x8f, 0xb, 0xfa, 0x3d, 0x28")
MAKE_THUNK(libvulkan, vkBindImageMemory2KHR, "0xb5, 0xb3, 0x2f, 0x1a, 0x42, 0xca, 0xcd, 0x7f, 0xc, 0xd9, 0x10, 0xee, 0x55, 0x3d, 0x90, 0x70, 0x9, 0x5, 0x7, 0x75, 0x76, 0xf5, 0xf4, 0xb3, 0xcd, 0x38, 0xd, 0xda, 0xc4, 0xb7, 0xf5, 0x64")
MAKE_THUNK(libvulkan, vkGetDescriptorSetLayoutSupportKHR, "0x37, 0xa9, 0x73, 0xcf, 0x52, 0x71, 0x30, 0x5, 0x2a, 0x96, 0x63, 0xe, 0x5f, 0x36, 0x93, 0xa, 0x79, 0x91, 0x57, 0x10, 0xb1, 0x21, 0xe3, 0x5a, 0xe5, 0x2e, 0x8c, 0x70, 0x9b, 0x11, 0xf3, 0x3b")
MAKE_THUNK(libvulkan, vkCmdDrawIndirectCountKHR, "0x2d, 0xf2, 0xa2, 0x1, 0xad, 0x1f, 0xd4, 0xe, 0x89, 0x27, 0x7c, 0x88, 0x67, 0xfd, 0x6d, 0x2d, 0xdd, 0x79, 0x2d, 0xa7, 0x93, 0x88, 0x99, 0xd2, 0xac, 0x9f, 0x93, 0x90, 0x29, 0x6c, 0x64, 0xb3")
MAKE_THUNK(libvulkan, vkCmdDrawIndexedIndirectCountKHR, "0xe, 0x39, 0x49, 0x16, 0x28, 0x3b, 0x8c, 0x80, 0xa1, 0x76, 0x6, 0xfd, 0x8, 0xb4, 0x11, 0x2c, 0x32, 0xff, 0x8e, 0x25, 0xd9, 0x66, 0x59, 0x65, 0xfe, 0x3, 0xa6, 0x31, 0xa, 0xab, 0xd2, 0x7")
MAKE_THUNK(libvulkan, vkGetSemaphoreCounterValueKHR, "0x12, 0x70, 0xd3, 0x43, 0xab, 0xf8, 0xa4, 0x55, 0x55, 0x83, 0x36, 0x29, 0xe1, 0x6d, 0x60, 0x5c, 0x8d, 0x72, 0x5c, 0xde, 0x12, 0x88, 0x9, 0xf4, 0x6f, 0xd2, 0x35, 0x7d, 0xdd, 0xcd, 0x57, 0xe")
MAKE_THUNK(libvulkan, vkWaitSemaphoresKHR, "0x73, 0x31, 0x87, 0xaa, 0x55, 0x9c, 0x48, 0x5f, 0x15, 0xc7, 0xed, 0x9c, 0xc1, 0xcf, 0x27, 0xca, 0xd7, 0x93, 0x88, 0x79, 0x67, 0x61, 0x2e, 0x24, 0x7d, 0x62, 0x3b, 0xc3, 0xe7, 0x9, 0x37, 0xb5")
MAKE_THUNK(libvulkan, vkSignalSemaphoreKHR, "0x87, 0x9, 0x58, 0x68, 0xf0, 0x3d, 0xa6, 0xf2, 0x25, 0xdd, 0x78, 0x53, 0xcb, 0x92, 0xa7, 0xdd, 0xd7, 0xf5, 0xe2, 0x89, 0xc0, 0x85, 0x54, 0x97, 0x10, 0xbb, 0x94, 0x59, 0xe1, 0xe1, 0xda, 0x53")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceFragmentShadingRatesKHR, "0x4f, 0xda, 0xca, 0xc6, 0x9c, 0xe7, 0x59, 0xd9, 0x20, 0x28, 0x43, 0xb6, 0x48, 0x3a, 0xb5, 0x1b, 0x2c, 0x98, 0x5c, 0x4a, 0xe6, 0x8c, 0xbc, 0xee, 0xa1, 0x78, 0xa0, 0xb2, 0xda, 0x0, 0x9b, 0xf5")
MAKE_THUNK(libvulkan, vkCmdSetFragmentShadingRateKHR, "0xa3, 0xf3, 0x7, 0xe8, 0xad, 0xb1, 0x65, 0x3e, 0x70, 0x2f, 0x1b, 0x29, 0x8, 0x56, 0x87, 0x43, 0x2, 0xbe, 0x6b, 0x29, 0x1b, 0x62, 0x60, 0x47, 0xb3, 0xe9, 0xe7, 0xdd, 0x8a, 0xd, 0x42, 0x14")
MAKE_THUNK(libvulkan, vkCmdSetRenderingAttachmentLocationsKHR, "0x9c, 0x6f, 0xa8, 0x6e, 0x7b, 0x55, 0xc7, 0x79, 0x85, 0xe2, 0xff, 0xad, 0xd3, 0x75, 0x90, 0x94, 0xfe, 0x0, 0xe, 0xc3, 0xda, 0xf2, 0xc9, 0xe6, 0x19, 0x8b, 0xaa, 0xab, 0x5a, 0x1f, 0xa3, 0xd1")
MAKE_THUNK(libvulkan, vkCmdSetRenderingInputAttachmentIndicesKHR, "0x90, 0x17, 0xf6, 0x6f, 0x1c, 0x32, 0x67, 0x12, 0x66, 0x34, 0x4f, 0xf6, 0x5e, 0x4d, 0x43, 0xdf, 0xed, 0x86, 0xb6, 0x61, 0xd, 0xab, 0xa8, 0x58, 0xc6, 0xc6, 0x89, 0x2b, 0x6, 0xd7, 0x61, 0x34")
MAKE_THUNK(libvulkan, vkWaitForPresentKHR, "0x87, 0xb8, 0x4d, 0x88, 0x77, 0x7d, 0x32, 0xe0, 0xd6, 0x73, 0xff, 0x4a, 0x9b, 0xce, 0x26, 0x23, 0x53, 0xbe, 0x8b, 0xfe, 0x32, 0xbe, 0x60, 0x82, 0x14, 0x71, 0x2c, 0xf1, 0x18, 0x7f, 0x24, 0x16")
MAKE_THUNK(libvulkan, vkGetBufferDeviceAddressKHR, "0x33, 0x30, 0x1e, 0x3d, 0xc7, 0x68, 0x8d, 0x25, 0xaa, 0x93, 0xf8, 0xfa, 0xa1, 0xe3, 0x42, 0xe1, 0x48, 0x26, 0x9b, 0xab, 0xbd, 0x99, 0x6a, 0xa0, 0x5b, 0x97, 0xd9, 0x7d, 0x74, 0x25, 0x4b, 0x45")
MAKE_THUNK(libvulkan, vkGetBufferOpaqueCaptureAddressKHR, "0x43, 0xd2, 0x23, 0xc9, 0xb5, 0x5a, 0xb0, 0xb8, 0xa7, 0xdb, 0x97, 0x2e, 0x64, 0x9e, 0x53, 0x8f, 0x58, 0x85, 0x4c, 0x9b, 0x1, 0xad, 0xea, 0x25, 0x5a, 0xef, 0x70, 0x1a, 0x49, 0x50, 0x2f, 0xfb")
MAKE_THUNK(libvulkan, vkGetDeviceMemoryOpaqueCaptureAddressKHR, "0x2d, 0xa6, 0xe6, 0xf5, 0x69, 0xff, 0x8f, 0x33, 0x20, 0x92, 0x6a, 0x0, 0x7a, 0x6f, 0xbb, 0x0, 0xb9, 0x8, 0xa0, 0x77, 0xcd, 0x42, 0x43, 0x46, 0x3, 0x10, 0x54, 0x54, 0x6e, 0xe0, 0xa2, 0xd2")
MAKE_THUNK(libvulkan, vkCreateDeferredOperationKHR, "0x54, 0x99, 0x27, 0xb2, 0xa4, 0xa2, 0xd6, 0x36, 0x2b, 0x71, 0xe, 0x53, 0x53, 0x15, 0xdb, 0xa0, 0x73, 0x8, 0xad, 0xd4, 0xbc, 0xb7, 0x70, 0xbc, 0xfe, 0x8b, 0xac, 0xc0, 0x9e, 0x33, 0x58, 0xb3")
MAKE_THUNK(libvulkan, vkDestroyDeferredOperationKHR, "0x3, 0x86, 0xd1, 0xa1, 0x9, 0x92, 0x2d, 0xfd, 0x7f, 0x5d, 0x82, 0xa5, 0xba, 0xf6, 0xe5, 0xd0, 0xea, 0xea, 0x90, 0x35, 0x74, 0x5, 0x7a, 0xfc, 0x3c, 0xd1, 0xe8, 0x99, 0x14, 0xf4, 0xdd, 0xdc")
MAKE_THUNK(libvulkan, vkGetDeferredOperationMaxConcurrencyKHR, "0x7b, 0xd7, 0x73, 0xf5, 0x41, 0x58, 0xf5, 0xbd, 0xa3, 0xa4, 0xd4, 0x49, 0x91, 0xa3, 0x57, 0x5f, 0xb1, 0x81, 0xc8, 0x21, 0xb1, 0x62, 0x15, 0xaf, 0x33, 0x52, 0xd9, 0xf7, 0x5a, 0xe1, 0x81, 0x6e")
MAKE_THUNK(libvulkan, vkGetDeferredOperationResultKHR, "0x74, 0xd1, 0xcf, 0xcf, 0xa8, 0xd5, 0x79, 0x7c, 0xc9, 0xed, 0x17, 0x31, 0xb2, 0xc9, 0xb, 0x77, 0xef, 0x9a, 0xc5, 0xca, 0xa4, 0x96, 0x11, 0x82, 0xa, 0xad, 0xd5, 0x74, 0xb1, 0xe1, 0x18, 0x98")
MAKE_THUNK(libvulkan, vkDeferredOperationJoinKHR, "0x1, 0xb6, 0x66, 0xb7, 0xce, 0x5b, 0xc5, 0x2a, 0xb8, 0xed, 0xf3, 0x24, 0x52, 0x2f, 0xc3, 0xa3, 0x8f, 0x22, 0xc2, 0x83, 0xff, 0x54, 0x8f, 0xaf, 0x4b, 0x55, 0x88, 0xd9, 0xd3, 0x73, 0xb7, 0xfc")
MAKE_THUNK(libvulkan, vkGetPipelineExecutablePropertiesKHR, "0x4d, 0x95, 0xba, 0x7e, 0x8a, 0xdc, 0xee, 0x4, 0x82, 0x5a, 0xc9, 0x35, 0xcc, 0xf5, 0x19, 0x52, 0x85, 0x20, 0xad, 0x63, 0x9, 0xe1, 0x3e, 0xa4, 0xf1, 0xe3, 0x1, 0x7e, 0xdf, 0x46, 0x5, 0x35")
MAKE_THUNK(libvulkan, vkGetPipelineExecutableStatisticsKHR, "0x8a, 0x78, 0xa3, 0x7c, 0xb9, 0x7e, 0x8b, 0xb1, 0x2e, 0xc1, 0x47, 0xa8, 0x8e, 0x66, 0x38, 0x97, 0x39, 0x3c, 0x34, 0xf6, 0x53, 0x71, 0xd5, 0x66, 0x2e, 0x57, 0x48, 0x86, 0xb7, 0xd9, 0xc3, 0xef")
MAKE_THUNK(libvulkan, vkGetPipelineExecutableInternalRepresentationsKHR, "0xe6, 0x51, 0x83, 0xb4, 0xae, 0x56, 0xaa, 0x1a, 0xb6, 0xbc, 0x57, 0x81, 0x51, 0x88, 0x2e, 0x14, 0xd6, 0x54, 0x7f, 0xde, 0x96, 0xa, 0xbc, 0x99, 0x8c, 0x5, 0x7f, 0x51, 0x6c, 0x9d, 0xc3, 0xb3")
MAKE_THUNK(libvulkan, vkMapMemory2KHR, "0xb3, 0xc0, 0x8d, 0x45, 0x88, 0x67, 0xd9, 0xe, 0x8b, 0x8d, 0x25, 0xc9, 0x92, 0x86, 0xe5, 0xfa, 0x71, 0x83, 0x5d, 0x61, 0xb8, 0xe0, 0x98, 0xac, 0x37, 0xd3, 0x19, 0x4c, 0xf3, 0xbd, 0xe0, 0xb2")
MAKE_THUNK(libvulkan, vkUnmapMemory2KHR, "0x6e, 0x84, 0x3d, 0x94, 0x9c, 0x90, 0x7e, 0xf4, 0x8d, 0x4c, 0xf4, 0xc5, 0x8f, 0x30, 0x93, 0xfe, 0xa3, 0xb0, 0x29, 0xb0, 0x22, 0x41, 0xe6, 0xb0, 0xa8, 0x49, 0xf9, 0x6, 0x38, 0x44, 0x52, 0x3a")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceVideoEncodeQualityLevelPropertiesKHR, "0x63, 0x96, 0x6f, 0xf2, 0xf0, 0x1d, 0x2c, 0x3e, 0x16, 0xb6, 0xe6, 0x59, 0x3, 0x50, 0x6c, 0x16, 0x46, 0x2d, 0x57, 0x15, 0x3a, 0x16, 0x6, 0xf5, 0x3f, 0x45, 0x84, 0xfc, 0xb4, 0x39, 0xc6, 0x0")
MAKE_THUNK(libvulkan, vkGetEncodedVideoSessionParametersKHR, "0xb5, 0xa7, 0x70, 0xfe, 0x84, 0x31, 0x9d, 0x70, 0x60, 0x5a, 0x6e, 0xf1, 0xdb, 0xd, 0x1d, 0x40, 0xc2, 0x5b, 0xdf, 0x96, 0x6f, 0x44, 0x2a, 0x9b, 0xc8, 0x92, 0x5b, 0x74, 0xcf, 0xd4, 0xa1, 0x5a")
MAKE_THUNK(libvulkan, vkCmdEncodeVideoKHR, "0xf7, 0x69, 0x44, 0xd, 0x38, 0xc9, 0x45, 0x46, 0xa7, 0x1f, 0x36, 0x24, 0x5a, 0x9f, 0xc9, 0xf, 0x1c, 0x98, 0xc2, 0x36, 0xcc, 0x26, 0xb2, 0x10, 0x30, 0x2b, 0x42, 0x37, 0x7c, 0x6d, 0x70, 0x90")
MAKE_THUNK(libvulkan, vkCmdSetEvent2KHR, "0xaa, 0xdb, 0xed, 0x79, 0xb, 0xc7, 0xa0, 0xa7, 0x61, 0xb6, 0x3f, 0xe1, 0x8e, 0x26, 0x40, 0xa3, 0x68, 0x64, 0xc5, 0x64, 0xd0, 0x1a, 0x47, 0x2b, 0xf5, 0x3, 0x9d, 0xc5, 0xaf, 0xee, 0x82, 0xeb")
MAKE_THUNK(libvulkan, vkCmdResetEvent2KHR, "0x6a, 0x3f, 0x79, 0xdd, 0x33, 0xc6, 0xc3, 0x8f, 0x7, 0xff, 0x9f, 0xd2, 0xb0, 0x4c, 0x60, 0xcc, 0xa5, 0x16, 0xef, 0x12, 0x3f, 0x8a, 0xa5, 0xac, 0x36, 0x90, 0x51, 0x5a, 0x63, 0x4f, 0xf9, 0xe")
MAKE_THUNK(libvulkan, vkCmdWaitEvents2KHR, "0x99, 0xae, 0xfb, 0x9a, 0xde, 0xd8, 0x90, 0x89, 0x64, 0x4f, 0x38, 0x49, 0xfa, 0xfc, 0x64, 0x1c, 0x89, 0xc, 0x90, 0x1f, 0x8e, 0x75, 0xc8, 0x78, 0xe8, 0x5d, 0x86, 0x6e, 0x47, 0x74, 0xf0, 0xed")
MAKE_THUNK(libvulkan, vkCmdPipelineBarrier2KHR, "0xb1, 0x63, 0x9f, 0x92, 0x7a, 0x92, 0x11, 0xac, 0x93, 0x7b, 0xa, 0x6a, 0x2e, 0x64, 0x40, 0x18, 0xf3, 0x2c, 0xea, 0x53, 0x3a, 0xe9, 0xae, 0x27, 0x72, 0x2e, 0xbe, 0x48, 0x64, 0x63, 0x93, 0x7f")
MAKE_THUNK(libvulkan, vkCmdWriteTimestamp2KHR, "0x84, 0xec, 0x77, 0x93, 0x39, 0x8c, 0x2f, 0x88, 0xfa, 0x25, 0x45, 0x50, 0xa6, 0x35, 0x6d, 0x33, 0xf1, 0x5, 0x9a, 0xf7, 0xf3, 0xf1, 0xf5, 0xb0, 0xd, 0xb4, 0xf8, 0x4f, 0x89, 0x60, 0xf3, 0x50")
MAKE_THUNK(libvulkan, vkQueueSubmit2KHR, "0x7b, 0x7e, 0x9d, 0x20, 0xf2, 0xe4, 0xff, 0x1f, 0x30, 0x6e, 0xc7, 0x58, 0xae, 0xca, 0xfe, 0x8b, 0x4c, 0x30, 0xf4, 0xe3, 0xe5, 0x3f, 0x7f, 0x45, 0x27, 0x44, 0xa4, 0xfc, 0x8f, 0xa9, 0x53, 0xe8")
MAKE_THUNK(libvulkan, vkCmdCopyBuffer2KHR, "0x97, 0xd, 0x44, 0x2d, 0xb1, 0xc7, 0x2a, 0xe3, 0x19, 0xce, 0x91, 0x71, 0x2c, 0x84, 0x71, 0xba, 0x65, 0xe1, 0xef, 0x7c, 0x40, 0xaf, 0xfb, 0xa2, 0x87, 0x4c, 0x84, 0xc4, 0x50, 0xc0, 0x4a, 0xfb")
MAKE_THUNK(libvulkan, vkCmdCopyImage2KHR, "0xd8, 0x22, 0xc0, 0x64, 0x83, 0x8, 0x5d, 0xa6, 0xb4, 0x88, 0x83, 0x67, 0x1, 0xfa, 0xfa, 0xb4, 0x40, 0x1, 0xcb, 0x3d, 0xe4, 0xf4, 0x2, 0x8e, 0x20, 0xd6, 0x3c, 0x13, 0x5f, 0x68, 0x1b, 0x70")
MAKE_THUNK(libvulkan, vkCmdCopyBufferToImage2KHR, "0xaf, 0x7d, 0x87, 0x8b, 0x55, 0x38, 0x52, 0x7b, 0x76, 0x1a, 0x0, 0x76, 0xda, 0xd8, 0x64, 0x86, 0x48, 0x13, 0x7c, 0x5, 0x3b, 0xa4, 0x20, 0xd1, 0xad, 0x60, 0xf7, 0x3b, 0x48, 0x4e, 0xe9, 0x75")
MAKE_THUNK(libvulkan, vkCmdCopyImageToBuffer2KHR, "0x2, 0x95, 0x29, 0xd, 0x1d, 0x30, 0xff, 0x86, 0xa5, 0x5a, 0x24, 0xa2, 0x20, 0xf4, 0x48, 0x4d, 0x77, 0x93, 0x85, 0xc3, 0x5f, 0xc6, 0xa5, 0x49, 0x7c, 0x30, 0x9a, 0x9b, 0xc6, 0x1d, 0xd9, 0x6c")
MAKE_THUNK(libvulkan, vkCmdBlitImage2KHR, "0xc8, 0x1a, 0x17, 0xb3, 0xb1, 0xa5, 0x78, 0x88, 0x9c, 0x90, 0xdc, 0x7d, 0x46, 0xe4, 0xa0, 0xc7, 0x2d, 0xaa, 0x6d, 0x20, 0x9d, 0xc0, 0x48, 0xd8, 0x4f, 0x31, 0x85, 0x82, 0xad, 0x64, 0x32, 0x38")
MAKE_THUNK(libvulkan, vkCmdResolveImage2KHR, "0xa4, 0xa3, 0xc2, 0x27, 0x83, 0x3c, 0xa0, 0xc5, 0x63, 0xc0, 0xb0, 0xbb, 0xcc, 0xc1, 0xab, 0xc4, 0xa7, 0xff, 0x30, 0x83, 0xe0, 0x68, 0x41, 0x95, 0x85, 0xfc, 0x24, 0x89, 0xf5, 0xf6, 0xd6, 0xec")
MAKE_THUNK(libvulkan, vkCmdTraceRaysIndirect2KHR, "0x94, 0xf4, 0x89, 0xef, 0x59, 0xa2, 0x8b, 0x30, 0xc6, 0xb7, 0x85, 0xe0, 0x4b, 0x95, 0xa3, 0x99, 0x5, 0xae, 0x25, 0x1f, 0xb5, 0x55, 0xd2, 0xc5, 0x9b, 0x9f, 0xa, 0xf, 0xc5, 0x75, 0x67, 0xc5")
MAKE_THUNK(libvulkan, vkGetDeviceBufferMemoryRequirementsKHR, "0x7e, 0x12, 0x15, 0x98, 0x16, 0xb1, 0xf9, 0x9e, 0x94, 0xe9, 0xc3, 0x70, 0x33, 0x2, 0x72, 0x18, 0x51, 0x4c, 0xd6, 0x6e, 0x80, 0x11, 0xef, 0x30, 0x29, 0xee, 0x39, 0x86, 0xbf, 0x7e, 0xbe, 0x61")
MAKE_THUNK(libvulkan, vkGetDeviceImageMemoryRequirementsKHR, "0xc, 0x93, 0xb0, 0xce, 0xd0, 0x26, 0x15, 0xd8, 0xf5, 0xe, 0x91, 0xe2, 0x71, 0xd9, 0xd2, 0x5d, 0x81, 0x72, 0x4b, 0x5f, 0x68, 0x86, 0x73, 0x94, 0xc8, 0x1f, 0x3b, 0x14, 0x5b, 0x99, 0x5f, 0xf6")
MAKE_THUNK(libvulkan, vkGetDeviceImageSparseMemoryRequirementsKHR, "0x8b, 0x3c, 0x94, 0x6d, 0x7a, 0x19, 0x1f, 0x43, 0x25, 0xc9, 0x2b, 0x9d, 0x10, 0x49, 0x1c, 0x3b, 0x23, 0x7a, 0x61, 0x1a, 0x52, 0xcf, 0x20, 0x5e, 0xae, 0x3a, 0x39, 0xe7, 0x6e, 0x9, 0x5d, 0x5d")
MAKE_THUNK(libvulkan, vkCmdBindIndexBuffer2KHR, "0xd6, 0x91, 0x52, 0xdb, 0xe7, 0x73, 0x3f, 0xa5, 0x5, 0x1d, 0xec, 0xdc, 0xba, 0xd6, 0xc8, 0xfc, 0x84, 0xc, 0x26, 0xaa, 0xa5, 0x58, 0x6a, 0x6f, 0x22, 0xcc, 0xe, 0x43, 0x1, 0xaf, 0xd2, 0x57")
MAKE_THUNK(libvulkan, vkGetRenderingAreaGranularityKHR, "0xb6, 0xee, 0xc3, 0x1a, 0x52, 0xae, 0xce, 0x61, 0x39, 0xf0, 0xc8, 0x6a, 0xc6, 0xa3, 0xbc, 0xa3, 0xc7, 0x6f, 0x30, 0xe6, 0x42, 0x9b, 0x46, 0x4a, 0x3f, 0xc2, 0xe5, 0xe8, 0x27, 0xd3, 0xe4, 0x9a")
MAKE_THUNK(libvulkan, vkGetDeviceImageSubresourceLayoutKHR, "0xf7, 0xdf, 0x17, 0xe0, 0xf5, 0xd2, 0xe1, 0x7a, 0xe9, 0x9b, 0xb5, 0xdc, 0x44, 0x66, 0x7f, 0x32, 0x89, 0x5e, 0xcb, 0x73, 0xb0, 0x74, 0x43, 0x3d, 0x43, 0xcd, 0x2, 0x29, 0xc6, 0x8e, 0xa1, 0xbb")
MAKE_THUNK(libvulkan, vkGetImageSubresourceLayout2KHR, "0xe2, 0xaf, 0xbd, 0x83, 0xba, 0x90, 0x9e, 0x80, 0x8f, 0x73, 0x16, 0xcd, 0x94, 0x78, 0xa2, 0x3a, 0x4, 0xec, 0x89, 0x86, 0x64, 0x2d, 0x69, 0x59, 0x21, 0x50, 0xfa, 0xd4, 0xf, 0x1f, 0x8b, 0x79")
MAKE_THUNK(libvulkan, vkWaitForPresent2KHR, "0x4f, 0x11, 0x6c, 0x6, 0x7, 0x4e, 0xd1, 0xc3, 0xb5, 0xa8, 0xcc, 0xa8, 0x92, 0xfe, 0x56, 0xd5, 0x30, 0x59, 0x9, 0xa9, 0x16, 0xe5, 0xc9, 0x87, 0x9, 0xc6, 0x39, 0xc0, 0xd3, 0x7c, 0xef, 0x65")
MAKE_THUNK(libvulkan, vkCreatePipelineBinariesKHR, "0xe, 0x62, 0x27, 0x92, 0xdd, 0xcb, 0x75, 0xdc, 0x1, 0xf3, 0xcd, 0x76, 0x6f, 0xe9, 0x7e, 0x67, 0xd0, 0x79, 0xc7, 0xf1, 0x92, 0xe9, 0x21, 0x43, 0x6d, 0x4a, 0x4b, 0x16, 0x7b, 0xce, 0x22, 0xc6")
MAKE_THUNK(libvulkan, vkDestroyPipelineBinaryKHR, "0x27, 0xaf, 0xca, 0xd1, 0x35, 0x7b, 0xbc, 0xe9, 0x33, 0x94, 0xdb, 0x36, 0x87, 0x64, 0xe5, 0xb0, 0x6d, 0xb1, 0x3c, 0xa1, 0xe5, 0x4a, 0x72, 0xa, 0xc9, 0xfc, 0x15, 0x18, 0x8b, 0x8b, 0x2a, 0xab")
MAKE_THUNK(libvulkan, vkGetPipelineKeyKHR, "0x29, 0x81, 0xa6, 0xf2, 0x7f, 0xe1, 0x31, 0xc1, 0xd3, 0x1e, 0x43, 0x1a, 0x47, 0x23, 0xeb, 0x85, 0xe1, 0x52, 0x91, 0x28, 0xd2, 0x6c, 0x41, 0xb1, 0xcd, 0x55, 0xb6, 0xd5, 0x4a, 0xdb, 0x74, 0xd6")
MAKE_THUNK(libvulkan, vkGetPipelineBinaryDataKHR, "0xc5, 0xa, 0x4, 0x83, 0x6b, 0xf0, 0x2, 0x45, 0x48, 0x8d, 0x1d, 0xf8, 0x8a, 0x8b, 0x1a, 0x86, 0xe0, 0x4, 0x7b, 0x2b, 0x7d, 0x3c, 0xf4, 0x1b, 0x98, 0x41, 0xe6, 0x67, 0xff, 0xa7, 0xd3, 0xd6")
MAKE_THUNK(libvulkan, vkReleaseCapturedPipelineDataKHR, "0xf9, 0xa9, 0xb9, 0xe0, 0x1a, 0x1e, 0xeb, 0xd0, 0x0, 0xa8, 0x73, 0xf6, 0x50, 0x7a, 0xd, 0x53, 0x32, 0x30, 0x99, 0xe4, 0xc0, 0xf6, 0x21, 0x62, 0xe2, 0xbd, 0xe1, 0x43, 0xbe, 0x4c, 0x98, 0xb2")
MAKE_THUNK(libvulkan, vkReleaseSwapchainImagesKHR, "0x24, 0xf, 0x84, 0x96, 0x43, 0x80, 0x33, 0x5f, 0x73, 0x33, 0x16, 0xa5, 0x6f, 0x87, 0x4b, 0x1e, 0x54, 0x7d, 0x74, 0xe2, 0xad, 0x2c, 0x2d, 0xc6, 0xdf, 0x6a, 0xa2, 0xe8, 0x19, 0x51, 0x18, 0x0")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceCooperativeMatrixPropertiesKHR, "0x83, 0x1a, 0x39, 0x4c, 0x67, 0x46, 0x1c, 0x19, 0xac, 0xa0, 0x85, 0xbd, 0x17, 0x82, 0x1f, 0xe2, 0x80, 0xc9, 0x5, 0x6f, 0x27, 0x49, 0xe6, 0xd8, 0xc5, 0x2b, 0xd9, 0x23, 0x8c, 0xd6, 0x30, 0x71")
MAKE_THUNK(libvulkan, vkCmdSetLineStippleKHR, "0xa6, 0x5, 0x6b, 0xd0, 0xd7, 0x6c, 0xa0, 0x1d, 0x34, 0xc, 0x88, 0xa5, 0x7, 0xc1, 0x7b, 0xc6, 0xf1, 0xa2, 0x21, 0x27, 0x4b, 0x2b, 0x2b, 0x41, 0x52, 0x51, 0x94, 0x9f, 0x88, 0x5e, 0xe8, 0x89")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceCalibrateableTimeDomainsKHR, "0xd9, 0xe2, 0xaa, 0x47, 0xfe, 0xd8, 0x29, 0xc, 0x2c, 0x12, 0x7a, 0x7e, 0x39, 0xa7, 0x87, 0x16, 0x97, 0x59, 0x54, 0x76, 0x93, 0xd4, 0x9d, 0x8f, 0xb6, 0x37, 0x16, 0xde, 0x13, 0x1d, 0xd0, 0xf")
MAKE_THUNK(libvulkan, vkGetCalibratedTimestampsKHR, "0x47, 0xc3, 0x6b, 0x4c, 0x22, 0x9b, 0x58, 0x23, 0xaa, 0x9b, 0xc3, 0xd9, 0xcf, 0x18, 0x19, 0x83, 0x83, 0x1c, 0xe, 0x21, 0x8a, 0xbb, 0xfb, 0xec, 0x6b, 0x1c, 0x86, 0x86, 0x4b, 0x74, 0x73, 0x60")
MAKE_THUNK(libvulkan, vkCmdBindDescriptorSets2KHR, "0x10, 0x22, 0x8b, 0x87, 0xa2, 0x20, 0x5a, 0x5a, 0xa6, 0x7d, 0x21, 0xa4, 0x8, 0x41, 0xf4, 0x92, 0x89, 0xd7, 0x4c, 0x3b, 0x3, 0x7f, 0x5f, 0xe3, 0xb2, 0x1b, 0x26, 0x7, 0xdd, 0x86, 0x14, 0x2f")
MAKE_THUNK(libvulkan, vkCmdPushConstants2KHR, "0x8f, 0xda, 0x7a, 0xdd, 0x8e, 0xf3, 0xd4, 0x6c, 0xff, 0x49, 0x4a, 0xa5, 0xd8, 0x55, 0xa, 0x73, 0xa3, 0xeb, 0xae, 0x35, 0xc0, 0xd7, 0xce, 0x5c, 0xac, 0xb0, 0x9, 0xfb, 0x7a, 0x17, 0x67, 0x88")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSet2KHR, "0xb, 0x14, 0xa2, 0xce, 0x78, 0xad, 0xcc, 0xf1, 0xe2, 0x6, 0x64, 0x2b, 0x17, 0x74, 0xe9, 0xcd, 0x2f, 0x7f, 0xd9, 0xbb, 0x18, 0x1b, 0xb7, 0x49, 0x1, 0xb5, 0xe1, 0xeb, 0x22, 0x3d, 0xa3, 0xa4")
MAKE_THUNK(libvulkan, vkCmdPushDescriptorSetWithTemplate2KHR, "0x4c, 0x9, 0x59, 0xc2, 0xa1, 0x6b, 0xa0, 0x4a, 0x6b, 0x55, 0x7f, 0xd, 0xdf, 0x67, 0x8f, 0x33, 0x9a, 0xb5, 0xd3, 0xdc, 0x62, 0xb8, 0x50, 0xb7, 0x97, 0xd2, 0x5c, 0x66, 0xd2, 0xac, 0x50, 0x43")
MAKE_THUNK(libvulkan, vkCmdSetDescriptorBufferOffsets2EXT, "0x6d, 0x5b, 0xbb, 0x43, 0x32, 0x76, 0x4c, 0x3c, 0x1a, 0xc6, 0xbb, 0xa8, 0x1f, 0x46, 0xc0, 0xb6, 0x9a, 0x97, 0x9c, 0x79, 0xf2, 0x98, 0x43, 0x3d, 0x5b, 0xc2, 0xbe, 0x96, 0x82, 0xd6, 0xa9, 0x7c")
MAKE_THUNK(libvulkan, vkCmdBindDescriptorBufferEmbeddedSamplers2EXT, "0xb9, 0xaf, 0x10, 0x13, 0x54, 0xc4, 0x3a, 0x8d, 0x8f, 0xc7, 0x53, 0x6b, 0x2d, 0x73, 0x87, 0xb1, 0x61, 0x46, 0xd8, 0xf6, 0xd3, 0x23, 0xee, 0x25, 0xa9, 0xb8, 0xf7, 0x45, 0xe5, 0x60, 0xaf, 0x9")
MAKE_THUNK(libvulkan, vkCmdCopyMemoryIndirectKHR, "0xb9, 0xfb, 0xaa, 0x25, 0xe3, 0xbf, 0xaf, 0x49, 0x49, 0xd4, 0x99, 0x35, 0xce, 0xde, 0x33, 0x59, 0xcf, 0x2a, 0xd2, 0xca, 0x28, 0x8e, 0xce, 0xd0, 0x0, 0xa8, 0x18, 0x7a, 0x30, 0x5b, 0xc3, 0xca")
MAKE_THUNK(libvulkan, vkCmdCopyMemoryToImageIndirectKHR, "0x64, 0xa2, 0xe, 0x52, 0xb2, 0x5, 0xe1, 0x65, 0x48, 0x3a, 0xe7, 0x52, 0x5a, 0x4, 0xbb, 0x7d, 0xfc, 0x5d, 0x52, 0xdd, 0x48, 0xd3, 0x6e, 0x53, 0x2f, 0x50, 0x9e, 0x8c, 0x51, 0x52, 0xad, 0xe0")
MAKE_THUNK(libvulkan, vkCmdEndRendering2KHR, "0xb1, 0xc7, 0xe3, 0x53, 0x5c, 0x61, 0x5c, 0x9a, 0x99, 0xad, 0x6f, 0x3d, 0x20, 0x2b, 0xd5, 0x5f, 0x99, 0x9d, 0x1f, 0x88, 0x77, 0x3e, 0x86, 0x4b, 0x78, 0xd5, 0xee, 0x2c, 0x15, 0xaa, 0xf6, 0x61")
MAKE_THUNK(libvulkan, vkCreateDebugReportCallbackEXT, "0x3e, 0x8c, 0xfb, 0x7c, 0x9a, 0xbb, 0x95, 0xb1, 0x28, 0x72, 0x3c, 0x6c, 0x72, 0x77, 0xd3, 0x61, 0x73, 0x1c, 0x90, 0x43, 0x1b, 0xa7, 0xf0, 0xda, 0x2d, 0xb7, 0x8, 0x1, 0x70, 0x55, 0xe5, 0x9e")
MAKE_THUNK(libvulkan, vkDestroyDebugReportCallbackEXT, "0x8a, 0xb7, 0xd2, 0xed, 0xe0, 0x2c, 0x25, 0x58, 0x3a, 0xe2, 0x54, 0xa, 0x51, 0x52, 0x2d, 0x2b, 0x8a, 0xf5, 0xf8, 0x7f, 0x42, 0x5e, 0x5d, 0x29, 0x2f, 0xe8, 0x52, 0x27, 0x78, 0xf6, 0x7d, 0x16")
MAKE_THUNK(libvulkan, vkDebugReportMessageEXT, "0x1c, 0xa7, 0x80, 0xb2, 0x99, 0xe, 0x55, 0xc5, 0xfb, 0x73, 0x8, 0x6b, 0x9b, 0x99, 0x4, 0x23, 0xbd, 0x76, 0x21, 0x94, 0xc2, 0x2e, 0xc3, 0xc7, 0xb5, 0x1c, 0xc, 0x58, 0xaa, 0x5b, 0x1, 0xb0")
MAKE_THUNK(libvulkan, vkDebugMarkerSetObjectTagEXT, "0xa5, 0x42, 0x84, 0xd7, 0xf7, 0x12, 0xf6, 0x6, 0xbb, 0xc2, 0x3b, 0xa9, 0x4c, 0x6d, 0x19, 0x33, 0x39, 0x3b, 0x76, 0xb8, 0xe, 0x4d, 0x8e, 0x76, 0xdc, 0x33, 0xbe, 0x92, 0xfd, 0xb1, 0x91, 0x5e")
MAKE_THUNK(libvulkan, vkDebugMarkerSetObjectNameEXT, "0x78, 0xb5, 0x32, 0x32, 0x36, 0x82, 0xad, 0x32, 0xef, 0x1, 0xcb, 0x61, 0x8b, 0x84, 0x39, 0xe2, 0x77, 0x66, 0x83, 0xbb, 0x61, 0x99, 0x79, 0x70, 0x6, 0x37, 0x44, 0x69, 0xaf, 0x94, 0xa1, 0x5a")
MAKE_THUNK(libvulkan, vkCmdDebugMarkerBeginEXT, "0x42, 0x3c, 0xb, 0xda, 0xb0, 0x34, 0x27, 0x3d, 0x47, 0x27, 0x88, 0x8b, 0x9e, 0xab, 0x7c, 0xe5, 0xd7, 0x5c, 0x32, 0xb3, 0xc8, 0xbd, 0x89, 0x34, 0xe5, 0x23, 0x68, 0x5, 0x37, 0xd2, 0x8, 0x11")
MAKE_THUNK(libvulkan, vkCmdDebugMarkerEndEXT, "0x13, 0xc4, 0x6e, 0xb8, 0xa0, 0x4, 0xd6, 0x90, 0xb0, 0x27, 0x75, 0x38, 0x98, 0x3d, 0x24, 0x8a, 0x5b, 0xb2, 0x2c, 0x46, 0x2d, 0x2e, 0x54, 0x9f, 0x52, 0xfe, 0xf0, 0x37, 0x69, 0xb9, 0xc, 0xc4")
MAKE_THUNK(libvulkan, vkCmdDebugMarkerInsertEXT, "0xe1, 0x99, 0x5, 0x3d, 0x3e, 0x40, 0xe0, 0x39, 0x6a, 0x20, 0x8a, 0xbc, 0x18, 0xe4, 0xc5, 0xe3, 0x2a, 0x81, 0x88, 0x20, 0x71, 0xa4, 0xa7, 0x96, 0x22, 0xc4, 0xd1, 0xde, 0x81, 0xaf, 0xff, 0xf9")
MAKE_THUNK(libvulkan, vkCmdBindTransformFeedbackBuffersEXT, "0xa6, 0x92, 0x37, 0x20, 0xe8, 0x4a, 0x93, 0x48, 0x42, 0xd1, 0x2e, 0xba, 0xce, 0x14, 0x8d, 0x6e, 0x99, 0x18, 0xaa, 0xe7, 0xdd, 0x55, 0xe0, 0xa2, 0xee, 0xb0, 0x4, 0xb7, 0xc4, 0xc8, 0xcb, 0x50")
MAKE_THUNK(libvulkan, vkCmdBeginTransformFeedbackEXT, "0x13, 0xef, 0x6e, 0xec, 0xed, 0x4b, 0xd4, 0x92, 0xde, 0x5f, 0xe6, 0x88, 0x5, 0x9, 0x5c, 0x9d, 0x47, 0x6d, 0xa0, 0x1a, 0x42, 0xd7, 0x0, 0xe3, 0xa, 0x93, 0x65, 0xa8, 0x1a, 0x33, 0x50, 0x82")
MAKE_THUNK(libvulkan, vkCmdEndTransformFeedbackEXT, "0x4c, 0x47, 0x1a, 0xf2, 0x4b, 0xb7, 0x1d, 0xcf, 0x9a, 0x74, 0x63, 0xd9, 0x84, 0x3b, 0xae, 0x3, 0x51, 0x97, 0xe3, 0xb, 0x6e, 0xfa, 0xd9, 0x4e, 0xc7, 0x3f, 0x44, 0xbc, 0xd8, 0xb5, 0x84, 0x50")
MAKE_THUNK(libvulkan, vkCmdBeginQueryIndexedEXT, "0xfc, 0xde, 0xb2, 0x43, 0x32, 0xcc, 0x77, 0x8d, 0x52, 0x91, 0xb8, 0x6d, 0x7d, 0x6d, 0xb5, 0xa5, 0xd0, 0x31, 0xef, 0x81, 0xd4, 0x94, 0xd6, 0x8a, 0xbe, 0xba, 0xf9, 0x4a, 0x81, 0x6f, 0xdb, 0x17")
MAKE_THUNK(libvulkan, vkCmdEndQueryIndexedEXT, "0x5b, 0xf, 0x1e, 0x1a, 0x97, 0x78, 0x5, 0xe3, 0x97, 0x7, 0x38, 0xca, 0x2b, 0x5e, 0xdb, 0x8f, 0xdc, 0xd, 0x46, 0xd8, 0x6b, 0x1c, 0x78, 0xc3, 0x6a, 0x6d, 0x92, 0x52, 0xaa, 0x7e, 0x8, 0xd4")
MAKE_THUNK(libvulkan, vkCmdDrawIndirectByteCountEXT, "0x9a, 0xe4, 0x5e, 0x13, 0x2b, 0x1a, 0x54, 0xc4, 0x8a, 0x15, 0x99, 0x24, 0xb, 0x69, 0x8a, 0x4d, 0x90, 0x3, 0xed, 0xa, 0x90, 0xc, 0x77, 0xe9, 0xfa, 0x10, 0x6d, 0x35, 0xba, 0x1f, 0xc1, 0x83")
MAKE_THUNK(libvulkan, vkCreateCuModuleNVX, "0x3e, 0xad, 0xeb, 0x2c, 0x65, 0xb5, 0x1a, 0x92, 0x44, 0xea, 0x2f, 0x3b, 0x2c, 0x8c, 0x4a, 0xd3, 0xef, 0x7c, 0x26, 0x89, 0xa3, 0xe4, 0xe9, 0x71, 0xa8, 0x61, 0xde, 0x2e, 0xfa, 0xe3, 0x67, 0x2f")
MAKE_THUNK(libvulkan, vkCreateCuFunctionNVX, "0x9b, 0xcf, 0xfe, 0xf5, 0xab, 0x8, 0x26, 0x8f, 0x47, 0xd, 0x2d, 0xc, 0x8b, 0x9, 0xa9, 0xce, 0x45, 0xaf, 0x84, 0xae, 0x89, 0x92, 0xd3, 0x1b, 0x5f, 0xaf, 0x95, 0xef, 0x7e, 0xba, 0x63, 0xb4")
MAKE_THUNK(libvulkan, vkDestroyCuModuleNVX, "0xab, 0x88, 0x98, 0x0, 0x57, 0xce, 0x39, 0x9f, 0x32, 0xee, 0xac, 0xea, 0x2, 0x43, 0xaa, 0x78, 0x7c, 0xe7, 0xf5, 0xb, 0xda, 0xcf, 0x43, 0x8c, 0x4e, 0x1f, 0xbd, 0x87, 0x94, 0x67, 0xb4, 0x92")
MAKE_THUNK(libvulkan, vkDestroyCuFunctionNVX, "0x3a, 0xe6, 0x73, 0x8e, 0x71, 0xd4, 0x7b, 0xd8, 0x6e, 0x85, 0x89, 0x9d, 0x20, 0xdb, 0x27, 0x60, 0x63, 0xb, 0xc0, 0x49, 0x51, 0x80, 0x2d, 0x9, 0xce, 0xa1, 0x84, 0x8f, 0xe9, 0x2f, 0x8d, 0xd2")
MAKE_THUNK(libvulkan, vkCmdCuLaunchKernelNVX, "0x1d, 0xc7, 0x28, 0xef, 0xe1, 0x11, 0x8a, 0x84, 0x43, 0xe5, 0x18, 0xe3, 0xde, 0x64, 0x42, 0x49, 0x68, 0x79, 0x20, 0xf4, 0x64, 0xb7, 0x82, 0x99, 0x49, 0xa6, 0xe6, 0x37, 0xba, 0xc3, 0x21, 0x26")
MAKE_THUNK(libvulkan, vkGetImageViewHandleNVX, "0x50, 0xbb, 0x59, 0xcf, 0xbf, 0x76, 0x46, 0x70, 0x30, 0x30, 0xb1, 0xba, 0x8, 0x2a, 0x46, 0x8b, 0xd5, 0x60, 0xa6, 0xab, 0xf0, 0x7c, 0x4d, 0x20, 0x6d, 0xcf, 0xc5, 0xa, 0xaa, 0x6c, 0xdb, 0xde")
MAKE_THUNK(libvulkan, vkGetImageViewHandle64NVX, "0xf9, 0x37, 0xae, 0x99, 0x29, 0x6c, 0x33, 0x17, 0xe8, 0x29, 0x5c, 0x47, 0x30, 0xf8, 0xd8, 0x22, 0xab, 0xe6, 0xb6, 0x6a, 0xb2, 0x68, 0xd, 0x59, 0x0, 0xb3, 0x32, 0xd, 0x6b, 0xae, 0x3e, 0x4d")
MAKE_THUNK(libvulkan, vkGetImageViewAddressNVX, "0x77, 0x74, 0x5a, 0x5a, 0x56, 0xbb, 0x40, 0xb1, 0xab, 0x47, 0x68, 0x39, 0x34, 0xcf, 0xa5, 0x3a, 0x12, 0xe7, 0xc3, 0x77, 0x96, 0xbf, 0x3d, 0x81, 0x97, 0x2a, 0xaf, 0xf0, 0x58, 0xf3, 0x7e, 0xd7")
MAKE_THUNK(libvulkan, vkCmdDrawIndirectCountAMD, "0x73, 0xc7, 0x7a, 0xbd, 0xf0, 0xf, 0x6c, 0xb3, 0x84, 0xb, 0xca, 0xb3, 0x5a, 0xc7, 0x3f, 0x2b, 0x73, 0xa8, 0xf3, 0x29, 0x22, 0xfb, 0x80, 0xa4, 0xe4, 0x75, 0x40, 0xbb, 0x79, 0xa8, 0x97, 0x71")
MAKE_THUNK(libvulkan, vkCmdDrawIndexedIndirectCountAMD, "0x37, 0x99, 0x41, 0x8a, 0xa0, 0xaa, 0x1e, 0xd0, 0x94, 0xbf, 0x4, 0xd2, 0x78, 0x38, 0x77, 0x26, 0x85, 0xcf, 0x67, 0xf9, 0xf6, 0x55, 0x41, 0x42, 0xc5, 0x26, 0x0, 0x7e, 0xe1, 0x56, 0x94, 0x3b")
MAKE_THUNK(libvulkan, vkGetShaderInfoAMD, "0x41, 0x24, 0x3, 0x5, 0x1d, 0xfb, 0x87, 0x90, 0x12, 0xf0, 0xa5, 0x27, 0x4d, 0x97, 0x5e, 0xa7, 0x7e, 0xb4, 0x68, 0x6a, 0xbf, 0x3f, 0x50, 0xed, 0x47, 0x45, 0x29, 0xce, 0xcd, 0x57, 0x63, 0x55")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalImageFormatPropertiesNV, "0xbc, 0x46, 0x84, 0x9c, 0x59, 0xe, 0x2a, 0x6a, 0x81, 0x33, 0x77, 0xcc, 0x15, 0x2, 0x94, 0x5a, 0x56, 0xa6, 0x26, 0x36, 0x46, 0x76, 0x50, 0xfa, 0x0, 0xa0, 0x9e, 0x91, 0x6a, 0x56, 0x76, 0x54")
MAKE_THUNK(libvulkan, vkCmdBeginConditionalRenderingEXT, "0x87, 0xf9, 0x6d, 0x68, 0xf4, 0x9e, 0xaf, 0xb8, 0xda, 0xf0, 0x9e, 0xbf, 0x64, 0xf, 0x8, 0x9, 0xbe, 0xd0, 0xbd, 0xb5, 0x3, 0x13, 0x7a, 0x12, 0xb4, 0xed, 0x4, 0x13, 0x8c, 0x8f, 0x60, 0x30")
MAKE_THUNK(libvulkan, vkCmdEndConditionalRenderingEXT, "0x5a, 0xf3, 0xd1, 0xa5, 0xfc, 0xed, 0x65, 0x28, 0xf3, 0x45, 0x9c, 0xe3, 0xa1, 0x18, 0x60, 0xd9, 0x46, 0xc3, 0xdd, 0x6d, 0xf7, 0xd1, 0xad, 0xc2, 0x2e, 0xd8, 0xcd, 0x91, 0xdd, 0xc9, 0x91, 0xab")
MAKE_THUNK(libvulkan, vkCmdSetViewportWScalingNV, "0xdd, 0xfe, 0xdc, 0x82, 0x6c, 0x2b, 0x1f, 0x8f, 0xef, 0xf3, 0x46, 0x43, 0x41, 0x22, 0xd0, 0xdc, 0x1e, 0xa5, 0x5c, 0xd3, 0x31, 0xc0, 0xce, 0xcb, 0xde, 0x4d, 0x64, 0x1c, 0xd2, 0xbe, 0x35, 0xf5")
MAKE_THUNK(libvulkan, vkReleaseDisplayEXT, "0xa9, 0x97, 0x3d, 0xbf, 0x62, 0xa2, 0xd2, 0x29, 0xf9, 0x4f, 0x69, 0x8f, 0xf8, 0x53, 0x7d, 0x24, 0xc0, 0x70, 0x85, 0x80, 0xd, 0x4, 0xd3, 0x8f, 0x28, 0x4e, 0xff, 0x8, 0x3d, 0x90, 0xa1, 0x9e")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSurfaceCapabilities2EXT, "0xe6, 0xda, 0xe4, 0x96, 0x58, 0xf6, 0xa5, 0x3c, 0xfa, 0x24, 0xf6, 0xa2, 0x71, 0x71, 0xc2, 0x23, 0x78, 0xd3, 0x5, 0x82, 0x1e, 0x8, 0x93, 0xd1, 0xa2, 0xd9, 0x21, 0xc3, 0xa6, 0x27, 0x47, 0xe4")
MAKE_THUNK(libvulkan, vkDisplayPowerControlEXT, "0x93, 0x9f, 0xf6, 0x24, 0x69, 0x7f, 0x95, 0xdc, 0x1b, 0xbd, 0xd0, 0x59, 0x89, 0xcc, 0x55, 0x6b, 0xd7, 0xc6, 0x8e, 0x95, 0x15, 0xdc, 0x4c, 0xf6, 0xaf, 0x29, 0x51, 0x86, 0x70, 0xcb, 0x8, 0x77")
MAKE_THUNK(libvulkan, vkRegisterDeviceEventEXT, "0x2d, 0x2b, 0xad, 0x80, 0xc, 0x4f, 0x98, 0xec, 0x9b, 0x4f, 0xe7, 0x83, 0x83, 0x4e, 0x5c, 0x98, 0xe0, 0xe8, 0x45, 0x8, 0x9, 0x76, 0x8b, 0x7, 0x9f, 0x9c, 0x49, 0x7c, 0x92, 0xb6, 0x4, 0x82")
MAKE_THUNK(libvulkan, vkRegisterDisplayEventEXT, "0x46, 0x2b, 0x23, 0x5c, 0x13, 0x65, 0xf8, 0xd9, 0xfc, 0xd8, 0xc8, 0x1b, 0x4a, 0x1f, 0x62, 0x1a, 0xdc, 0x62, 0xbf, 0x32, 0x9, 0x7a, 0x9f, 0xf0, 0x7b, 0xb7, 0x43, 0xf2, 0x30, 0x9f, 0x27, 0x50")
MAKE_THUNK(libvulkan, vkGetSwapchainCounterEXT, "0x52, 0x38, 0x89, 0xf5, 0x39, 0x51, 0xb9, 0x2b, 0x7e, 0x91, 0xf4, 0xc4, 0xd, 0x5b, 0x2c, 0x12, 0xb6, 0xb7, 0x64, 0xae, 0xbd, 0x52, 0xf1, 0xa8, 0x10, 0x5f, 0xe3, 0xee, 0x7c, 0x64, 0x68, 0x1")
MAKE_THUNK(libvulkan, vkGetRefreshCycleDurationGOOGLE, "0xfa, 0x5f, 0x4e, 0x52, 0x89, 0x4, 0xef, 0x75, 0xc4, 0x5f, 0x56, 0x24, 0x25, 0xcb, 0xbf, 0x81, 0x9f, 0x14, 0x72, 0xd2, 0x13, 0xb0, 0xd1, 0x20, 0xf, 0x56, 0x23, 0x15, 0x63, 0x9a, 0x2, 0xc8")
MAKE_THUNK(libvulkan, vkGetPastPresentationTimingGOOGLE, "0x5c, 0x51, 0x84, 0xed, 0x97, 0x99, 0xee, 0x3d, 0x6a, 0xac, 0x87, 0xff, 0xcc, 0x15, 0xf, 0x95, 0x2, 0xa6, 0x89, 0x70, 0xe5, 0x27, 0x7b, 0xdf, 0x49, 0x73, 0xff, 0xd2, 0xa, 0xc1, 0xc1, 0x5c")
MAKE_THUNK(libvulkan, vkCmdSetDiscardRectangleEXT, "0xfa, 0x1e, 0x38, 0x77, 0x58, 0x56, 0x25, 0x9a, 0xca, 0xc9, 0xcd, 0xf2, 0x91, 0x8b, 0x14, 0x5d, 0xab, 0xf9, 0x87, 0x4, 0x97, 0xc3, 0xd5, 0x1d, 0x7d, 0x6e, 0x36, 0x34, 0xf1, 0xe2, 0xae, 0x7a")
MAKE_THUNK(libvulkan, vkCmdSetDiscardRectangleEnableEXT, "0x53, 0x9a, 0xca, 0xc8, 0xea, 0xac, 0x9b, 0x35, 0x16, 0x14, 0xc8, 0x94, 0x69, 0xd0, 0x28, 0xd5, 0x32, 0xce, 0xf, 0x5f, 0x1, 0xcb, 0x7c, 0xc7, 0x69, 0x8, 0x5b, 0xab, 0xa0, 0xc, 0x9, 0x4b")
MAKE_THUNK(libvulkan, vkCmdSetDiscardRectangleModeEXT, "0x1b, 0xb1, 0xab, 0x6, 0x37, 0xa0, 0x36, 0x23, 0x3f, 0xd7, 0x6e, 0xf5, 0x99, 0xd7, 0x8d, 0x8b, 0x6f, 0x3e, 0xa7, 0x9a, 0xca, 0x38, 0xd, 0xb9, 0xa4, 0x96, 0xda, 0xed, 0x4e, 0x5d, 0x4c, 0x91")
MAKE_THUNK(libvulkan, vkSetHdrMetadataEXT, "0x40, 0xdf, 0x97, 0xc8, 0x32, 0x8f, 0x7f, 0x58, 0x37, 0x2e, 0x8f, 0x14, 0x9c, 0xb2, 0x84, 0x96, 0x78, 0xac, 0x36, 0x25, 0xf8, 0x46, 0x19, 0x88, 0xee, 0x95, 0x32, 0x1a, 0xa9, 0x2c, 0xd8, 0x5e")
MAKE_THUNK(libvulkan, vkSetDebugUtilsObjectNameEXT, "0xcb, 0xea, 0xe6, 0xa, 0xac, 0x53, 0xba, 0xf7, 0x8a, 0x9e, 0x33, 0x88, 0xa9, 0xf4, 0x7e, 0x81, 0x93, 0x43, 0xbd, 0x5c, 0xa3, 0xbc, 0xaa, 0x6b, 0xd0, 0x6, 0xd, 0xf4, 0x9d, 0xac, 0xad, 0x2")
MAKE_THUNK(libvulkan, vkSetDebugUtilsObjectTagEXT, "0xb7, 0x1f, 0x9f, 0x2f, 0x9b, 0x11, 0x9, 0x18, 0xcb, 0x41, 0x62, 0xdc, 0x27, 0x48, 0x0, 0x6c, 0xab, 0xab, 0x86, 0x7c, 0x13, 0xb4, 0xbf, 0xba, 0x82, 0x2a, 0x42, 0xd1, 0x89, 0x9d, 0x79, 0xc8")
MAKE_THUNK(libvulkan, vkQueueBeginDebugUtilsLabelEXT, "0x29, 0x9e, 0xa7, 0xff, 0x81, 0x60, 0x2, 0xb8, 0x4c, 0x76, 0x3c, 0xcb, 0x88, 0x60, 0xed, 0xb6, 0xfc, 0xd7, 0x1c, 0xb2, 0x84, 0x87, 0x10, 0x2d, 0x3b, 0x52, 0x33, 0xf4, 0x67, 0x4e, 0x23, 0xb3")
MAKE_THUNK(libvulkan, vkQueueEndDebugUtilsLabelEXT, "0x82, 0x48, 0xa0, 0x45, 0x66, 0x77, 0xdc, 0xe3, 0x91, 0x28, 0x35, 0xb8, 0x7a, 0x20, 0x69, 0x5b, 0x86, 0xf8, 0x3a, 0xc6, 0xeb, 0x2b, 0x1e, 0x87, 0xf6, 0x66, 0x68, 0x46, 0x41, 0x9, 0x88, 0x5f")
MAKE_THUNK(libvulkan, vkQueueInsertDebugUtilsLabelEXT, "0x4f, 0x51, 0x80, 0x9b, 0x77, 0xf8, 0xb9, 0x8b, 0xfc, 0x1e, 0x83, 0x90, 0x10, 0xdd, 0xc, 0xa8, 0xc, 0x88, 0x6d, 0x8b, 0x7e, 0xe7, 0x22, 0x2f, 0xe, 0x3c, 0xa, 0x55, 0x9d, 0xef, 0x77, 0xc7")
MAKE_THUNK(libvulkan, vkCmdBeginDebugUtilsLabelEXT, "0x1d, 0x35, 0x7d, 0xd1, 0x4b, 0xec, 0x6f, 0x89, 0xe4, 0xcb, 0xfc, 0x2d, 0x6a, 0x3, 0xa2, 0x5e, 0x5d, 0xb2, 0x24, 0xf5, 0x7, 0x1d, 0x27, 0xed, 0xbc, 0xe5, 0xe, 0xd4, 0xea, 0x5f, 0xf0, 0x20")
MAKE_THUNK(libvulkan, vkCmdEndDebugUtilsLabelEXT, "0x28, 0xbb, 0xca, 0x13, 0x94, 0x46, 0x85, 0xfb, 0x45, 0x2b, 0x1e, 0xa, 0x4c, 0x1e, 0xee, 0xfc, 0x92, 0x8a, 0xeb, 0x40, 0xd, 0xb6, 0x7d, 0x8b, 0x25, 0x7e, 0xa3, 0x27, 0x38, 0x22, 0xc7, 0xa7")
MAKE_THUNK(libvulkan, vkCmdInsertDebugUtilsLabelEXT, "0x7c, 0x96, 0xe3, 0xe6, 0x94, 0x36, 0x95, 0x8b, 0x66, 0x37, 0x82, 0xcc, 0xca, 0x13, 0x54, 0xe9, 0xf7, 0x97, 0x12, 0x38, 0xb8, 0xa9, 0x78, 0x4a, 0x35, 0x13, 0xfe, 0xec, 0x88, 0xa4, 0xd3, 0xa9")
MAKE_THUNK(libvulkan, vkCreateDebugUtilsMessengerEXT, "0x0, 0x86, 0xf8, 0x59, 0x82, 0x89, 0x19, 0x16, 0xcc, 0x5e, 0x39, 0x29, 0x48, 0xc2, 0xbe, 0x45, 0xf7, 0xc2, 0xc7, 0x56, 0xe2, 0x8, 0xfc, 0x90, 0x3a, 0x94, 0xf4, 0x44, 0x7f, 0x50, 0xb1, 0xc0")
MAKE_THUNK(libvulkan, vkDestroyDebugUtilsMessengerEXT, "0xaf, 0x3d, 0xf6, 0xc6, 0x33, 0xc, 0x8, 0x0, 0x29, 0xd3, 0xcf, 0x16, 0x3a, 0x1b, 0xd0, 0x1b, 0xf6, 0xbf, 0xd2, 0x3b, 0xae, 0x56, 0x24, 0x40, 0x1, 0x90, 0xb7, 0xae, 0xa5, 0x6e, 0xab, 0x49")
MAKE_THUNK(libvulkan, vkSubmitDebugUtilsMessageEXT, "0xf5, 0xd7, 0x55, 0xa0, 0x75, 0xa, 0x2a, 0xf, 0x57, 0x14, 0x43, 0xeb, 0x4f, 0xe9, 0x21, 0x21, 0x3f, 0xb1, 0x8a, 0x93, 0xa, 0xaf, 0xfb, 0x2f, 0xcd, 0xb3, 0x1c, 0x47, 0x38, 0xa5, 0xe8, 0x21")
MAKE_THUNK(libvulkan, vkCmdSetSampleLocationsEXT, "0xd2, 0xe3, 0x40, 0xcc, 0xdc, 0xbb, 0x34, 0xea, 0x7c, 0x74, 0xe0, 0x7e, 0x74, 0xc6, 0x4d, 0x7c, 0xbc, 0x54, 0x89, 0xec, 0x41, 0x22, 0xfb, 0x4a, 0x4f, 0x6c, 0x75, 0xbd, 0x75, 0x6f, 0xc1, 0x4a")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceMultisamplePropertiesEXT, "0x61, 0xc6, 0xe2, 0xdc, 0x5a, 0x45, 0xc, 0x6d, 0x2a, 0x57, 0xb1, 0x8, 0xe6, 0xed, 0xdb, 0x92, 0xc6, 0x3e, 0xa2, 0x78, 0x22, 0xd8, 0xbd, 0xcf, 0x11, 0x8e, 0xd9, 0x0, 0xcd, 0x8e, 0x6f, 0xe2")
MAKE_THUNK(libvulkan, vkGetImageDrmFormatModifierPropertiesEXT, "0x73, 0x8b, 0x85, 0x19, 0x23, 0xa5, 0x43, 0x59, 0x3d, 0xcd, 0xf1, 0x8c, 0x36, 0x3d, 0x16, 0x2c, 0xc0, 0xe2, 0x27, 0xa, 0xc8, 0xdb, 0xa9, 0xf0, 0xbf, 0x4b, 0x7c, 0x8c, 0x48, 0x7c, 0x2f, 0xb1")
MAKE_THUNK(libvulkan, vkCreateValidationCacheEXT, "0xc7, 0x86, 0x86, 0x56, 0x1b, 0xa2, 0xa3, 0xb3, 0x19, 0xd7, 0x59, 0xed, 0xb8, 0x8b, 0xf4, 0xb2, 0x9b, 0x2a, 0x36, 0x4c, 0xef, 0x84, 0xda, 0xa8, 0xac, 0xb8, 0x33, 0xa3, 0xf1, 0x5d, 0x4, 0x28")
MAKE_THUNK(libvulkan, vkDestroyValidationCacheEXT, "0x3e, 0xbe, 0x71, 0x96, 0xea, 0xdb, 0xe, 0xad, 0x33, 0xb4, 0xfe, 0x37, 0x2, 0x44, 0x2b, 0x8d, 0xb2, 0xc4, 0x59, 0x6c, 0x83, 0x6c, 0xe5, 0xdd, 0x55, 0xb2, 0x7f, 0xa7, 0xc1, 0x8d, 0xc7, 0xd1")
MAKE_THUNK(libvulkan, vkMergeValidationCachesEXT, "0x2a, 0x5a, 0x26, 0x1f, 0x75, 0x0, 0x11, 0x6e, 0xfd, 0x15, 0xbc, 0x1b, 0x42, 0xed, 0x80, 0xe9, 0xc1, 0xe6, 0xfa, 0x5f, 0x40, 0xb, 0xf1, 0xfe, 0x45, 0x9d, 0x5c, 0x88, 0x3e, 0xd7, 0xf6, 0xe8")
MAKE_THUNK(libvulkan, vkGetValidationCacheDataEXT, "0xc2, 0x2b, 0x21, 0xff, 0x99, 0x6, 0xf2, 0x2a, 0xb0, 0x6, 0x6a, 0x30, 0xf7, 0x7d, 0xbc, 0x6b, 0xab, 0xea, 0x3a, 0x26, 0x72, 0x29, 0x8d, 0x1e, 0xf8, 0x29, 0x26, 0xe, 0x8, 0xac, 0xe7, 0x3e")
MAKE_THUNK(libvulkan, vkCmdBindShadingRateImageNV, "0x8d, 0xe4, 0xb7, 0x55, 0xad, 0x37, 0x94, 0x61, 0x61, 0x68, 0xd7, 0x9f, 0x71, 0xe2, 0x9d, 0x73, 0xfc, 0x3a, 0x7a, 0x74, 0x73, 0x49, 0xa5, 0xca, 0xb3, 0x2, 0xe3, 0x40, 0x6f, 0xc1, 0x20, 0x73")
MAKE_THUNK(libvulkan, vkCmdSetViewportShadingRatePaletteNV, "0x9d, 0xb8, 0x80, 0xff, 0xaa, 0x8a, 0xff, 0x27, 0x89, 0x11, 0x41, 0x2e, 0xab, 0x0, 0x51, 0x81, 0xa9, 0xd5, 0x88, 0x74, 0x66, 0xe3, 0x4b, 0x92, 0x66, 0x38, 0xc5, 0xdd, 0x49, 0x32, 0x5b, 0x6d")
MAKE_THUNK(libvulkan, vkCmdSetCoarseSampleOrderNV, "0xa4, 0x64, 0x23, 0x13, 0x1f, 0xb2, 0xd1, 0xdc, 0x85, 0xbf, 0x54, 0x71, 0x55, 0x9a, 0x15, 0x9b, 0xf7, 0xdf, 0x6d, 0x9e, 0xa3, 0xad, 0x13, 0x9f, 0x4a, 0x91, 0x3b, 0xcd, 0xbd, 0x2b, 0xb8, 0xa1")
MAKE_THUNK(libvulkan, vkCreateAccelerationStructureNV, "0x17, 0xe5, 0xa6, 0xa, 0xad, 0x26, 0xc3, 0xbc, 0x7b, 0x3d, 0x36, 0x5, 0x9, 0xd5, 0xb0, 0x90, 0xf3, 0x35, 0x53, 0xd0, 0x4a, 0x2b, 0x8b, 0xfc, 0x9c, 0xd, 0xa7, 0xf1, 0x6a, 0xa4, 0x43, 0x7b")
MAKE_THUNK(libvulkan, vkDestroyAccelerationStructureNV, "0x11, 0xa6, 0x69, 0xa, 0xcb, 0xf2, 0xb8, 0x96, 0x31, 0x98, 0x61, 0x22, 0xae, 0xc4, 0xc5, 0x47, 0x9f, 0x10, 0xb9, 0xf3, 0x8f, 0x90, 0x77, 0x83, 0x1f, 0x60, 0xb0, 0x1f, 0x14, 0x49, 0x77, 0xc8")
MAKE_THUNK(libvulkan, vkGetAccelerationStructureMemoryRequirementsNV, "0xfd, 0x0, 0x3a, 0x48, 0x2, 0x1d, 0x4e, 0x39, 0x26, 0x4c, 0xbb, 0x74, 0xd1, 0x2e, 0x41, 0x1, 0x30, 0xbd, 0x49, 0xc, 0xc4, 0xb0, 0x7, 0x3e, 0x6e, 0x99, 0x3a, 0xca, 0x9a, 0x52, 0x7a, 0x8")
MAKE_THUNK(libvulkan, vkBindAccelerationStructureMemoryNV, "0xe6, 0x6f, 0xa, 0xd1, 0xa2, 0xb2, 0xbd, 0x46, 0xaf, 0x8e, 0xc8, 0xc8, 0xec, 0x61, 0x8e, 0x2c, 0x2f, 0xb1, 0x60, 0x84, 0x14, 0x2f, 0x30, 0xd3, 0x88, 0xf3, 0xad, 0xc8, 0x53, 0x7f, 0xc2, 0xf8")
MAKE_THUNK(libvulkan, vkCmdBuildAccelerationStructureNV, "0x5d, 0x9e, 0x7d, 0xf5, 0x5b, 0x8e, 0x89, 0xd2, 0x68, 0xb3, 0x12, 0xd5, 0x40, 0xb0, 0x34, 0x39, 0x37, 0x6b, 0x61, 0x12, 0x7, 0x7c, 0xd4, 0xa0, 0x3, 0xe2, 0xbd, 0x99, 0xa9, 0x77, 0xa9, 0x30")
MAKE_THUNK(libvulkan, vkCmdCopyAccelerationStructureNV, "0xdc, 0x3b, 0x74, 0x22, 0x9b, 0x6e, 0xdb, 0xaf, 0x95, 0x84, 0x1c, 0x5e, 0x67, 0xc3, 0x14, 0x76, 0xb5, 0xa1, 0x58, 0xb0, 0x3c, 0x88, 0xa1, 0x2e, 0xdb, 0x73, 0xf6, 0x0, 0x35, 0xf3, 0xd3, 0x79")
MAKE_THUNK(libvulkan, vkCmdTraceRaysNV, "0x85, 0xa4, 0xa, 0x44, 0x86, 0x3c, 0xa, 0x88, 0xa8, 0x7e, 0xf5, 0x32, 0x41, 0x59, 0x50, 0x38, 0x84, 0x26, 0x26, 0x64, 0x7a, 0x51, 0x44, 0xea, 0xa5, 0x1b, 0xa8, 0x16, 0x5f, 0xda, 0xc7, 0x5c")
MAKE_THUNK(libvulkan, vkCreateRayTracingPipelinesNV, "0x76, 0x8b, 0x47, 0xb2, 0xe6, 0x1a, 0xc1, 0xef, 0xa5, 0x17, 0xa2, 0xe3, 0xa3, 0x78, 0x55, 0x8d, 0xb1, 0x8, 0x34, 0xbe, 0xdd, 0xb7, 0x2, 0xa0, 0xa7, 0xde, 0x5f, 0xf, 0x49, 0x6a, 0xd4, 0x76")
MAKE_THUNK(libvulkan, vkGetRayTracingShaderGroupHandlesKHR, "0x94, 0x58, 0xa1, 0xf1, 0xf8, 0xc1, 0xf2, 0xd6, 0xae, 0xa7, 0x14, 0x86, 0xaa, 0x1d, 0xff, 0xdf, 0xc1, 0x4e, 0x42, 0x43, 0x49, 0x87, 0xf6, 0x3c, 0xc, 0xaa, 0x93, 0x5d, 0xf4, 0xf4, 0x14, 0x6")
MAKE_THUNK(libvulkan, vkGetRayTracingShaderGroupHandlesNV, "0x9c, 0x87, 0xaa, 0x3b, 0x45, 0x5, 0x41, 0xe6, 0x45, 0x7c, 0x75, 0x2b, 0xcb, 0x44, 0x3c, 0x2e, 0x74, 0x9, 0x1a, 0x3c, 0x55, 0x96, 0x1e, 0x16, 0x8a, 0x62, 0xc7, 0x8a, 0xdc, 0x1d, 0xc3, 0x5c")
MAKE_THUNK(libvulkan, vkGetAccelerationStructureHandleNV, "0x15, 0x1a, 0x4e, 0xd3, 0x4, 0x25, 0x29, 0x6b, 0x4d, 0x0, 0xc7, 0xf4, 0xa2, 0xa7, 0x7d, 0xf7, 0x60, 0x8c, 0x6, 0xde, 0xb1, 0xec, 0xf8, 0x9a, 0x99, 0xf9, 0xe1, 0x80, 0xb6, 0xc6, 0x52, 0x47")
MAKE_THUNK(libvulkan, vkCmdWriteAccelerationStructuresPropertiesNV, "0xd4, 0x5c, 0x72, 0x7e, 0xe5, 0x73, 0x3, 0xac, 0x8d, 0x36, 0x7f, 0xcd, 0x35, 0x1f, 0xc8, 0x44, 0xe3, 0x69, 0x77, 0x38, 0x5b, 0x31, 0xd3, 0x74, 0xc3, 0x8d, 0x57, 0xd5, 0x1d, 0x60, 0xdc, 0xdd")
MAKE_THUNK(libvulkan, vkCompileDeferredNV, "0x99, 0x3d, 0x85, 0x8f, 0xf2, 0x30, 0x63, 0x5, 0x66, 0x52, 0x54, 0x1e, 0x3e, 0xc, 0x63, 0x51, 0x55, 0x96, 0xec, 0xff, 0x88, 0x96, 0x6f, 0x75, 0x3c, 0x57, 0xba, 0xae, 0x61, 0x58, 0x78, 0xe7")
MAKE_THUNK(libvulkan, vkGetMemoryHostPointerPropertiesEXT, "0x52, 0x39, 0xf0, 0xd0, 0xbc, 0x6a, 0xf0, 0xe0, 0x37, 0x50, 0x2f, 0x71, 0x4a, 0x20, 0x68, 0x90, 0x2c, 0xa9, 0x16, 0xd8, 0xa5, 0xa6, 0x2a, 0xb9, 0xf0, 0x39, 0x6c, 0x18, 0x80, 0xff, 0x51, 0x6f")
MAKE_THUNK(libvulkan, vkCmdWriteBufferMarkerAMD, "0xda, 0x82, 0x28, 0x9a, 0x25, 0x4d, 0xde, 0xfd, 0x86, 0x82, 0xc6, 0x8b, 0x8e, 0x34, 0x4e, 0x59, 0x4f, 0x51, 0xf4, 0xf0, 0xcb, 0x34, 0x32, 0xff, 0xed, 0x85, 0x9d, 0x28, 0xc8, 0xe5, 0x3a, 0x8f")
MAKE_THUNK(libvulkan, vkCmdWriteBufferMarker2AMD, "0xef, 0x1d, 0x49, 0x4f, 0xd1, 0x27, 0xf4, 0x41, 0xde, 0x32, 0x6e, 0x93, 0x2c, 0x27, 0x3, 0x7, 0xf1, 0x93, 0x4c, 0xd9, 0x18, 0x66, 0xf0, 0x8d, 0x3b, 0x2f, 0xe3, 0x87, 0x77, 0xdd, 0x65, 0x43")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceCalibrateableTimeDomainsEXT, "0x6a, 0x79, 0x4e, 0x51, 0xe5, 0x69, 0x37, 0xe7, 0xf5, 0x83, 0xf2, 0x3b, 0x53, 0x62, 0xd3, 0xb1, 0x5a, 0xae, 0xb4, 0x4d, 0x11, 0x3, 0xbb, 0x6f, 0xa7, 0x2b, 0xfd, 0x6c, 0xa, 0x2f, 0x3d, 0x84")
MAKE_THUNK(libvulkan, vkGetCalibratedTimestampsEXT, "0xfa, 0xc0, 0x52, 0x36, 0xf2, 0x5d, 0xa, 0xb8, 0xee, 0x2c, 0x4b, 0xa1, 0x9d, 0x4d, 0xb2, 0x1e, 0x84, 0x22, 0x9b, 0xe0, 0xe5, 0xc3, 0xc, 0x9, 0x82, 0xe0, 0xb3, 0xe0, 0xed, 0xcd, 0x5c, 0x47")
MAKE_THUNK(libvulkan, vkCmdDrawMeshTasksNV, "0x82, 0x1d, 0x52, 0xe0, 0xb3, 0xa7, 0xc8, 0x5d, 0xc3, 0x87, 0x2e, 0xba, 0x98, 0xa2, 0x1d, 0x60, 0xa, 0x50, 0xbd, 0x38, 0xdd, 0x70, 0x4, 0x9e, 0x71, 0x6d, 0xb2, 0x6a, 0xe1, 0x34, 0x84, 0xf1")
MAKE_THUNK(libvulkan, vkCmdDrawMeshTasksIndirectNV, "0x62, 0xd7, 0x92, 0x6c, 0x80, 0x41, 0x15, 0x6a, 0xa8, 0x65, 0x5c, 0x34, 0x47, 0xa5, 0x26, 0x2a, 0x73, 0x2b, 0x77, 0x18, 0xc1, 0x4b, 0xb5, 0x1a, 0x41, 0x26, 0x53, 0x73, 0xef, 0x2f, 0xa9, 0x6d")
MAKE_THUNK(libvulkan, vkCmdDrawMeshTasksIndirectCountNV, "0xc2, 0x65, 0xcd, 0xe, 0xd5, 0x20, 0xec, 0x1c, 0xd6, 0x13, 0xb6, 0x32, 0xcc, 0xc9, 0xdb, 0xfe, 0x44, 0x1e, 0x2, 0x5, 0x7d, 0x94, 0xf3, 0x8f, 0xc4, 0xed, 0xe6, 0xe2, 0xce, 0x94, 0x49, 0xdd")
MAKE_THUNK(libvulkan, vkCmdSetExclusiveScissorEnableNV, "0xf8, 0x79, 0xf4, 0x5e, 0x59, 0xb3, 0x98, 0x87, 0x80, 0xc9, 0x3e, 0x3, 0x88, 0x89, 0xe8, 0x46, 0x29, 0x43, 0x83, 0x8c, 0x17, 0xf7, 0xf9, 0x84, 0x0, 0xb8, 0xc2, 0x71, 0x5c, 0x40, 0x61, 0xd6")
MAKE_THUNK(libvulkan, vkCmdSetExclusiveScissorNV, "0x51, 0x11, 0x78, 0x39, 0xdc, 0x7e, 0x7b, 0xf8, 0x75, 0x19, 0xe8, 0x61, 0xa8, 0xa8, 0xce, 0x5f, 0x97, 0xda, 0xde, 0xbc, 0xe1, 0x17, 0xbe, 0x48, 0xe6, 0xe9, 0xe1, 0x30, 0xf7, 0xa2, 0xc1, 0xc2")
MAKE_THUNK(libvulkan, vkCmdSetCheckpointNV, "0x4e, 0xc3, 0x6, 0x4a, 0x23, 0x5d, 0x78, 0xd1, 0x8b, 0xa6, 0xb7, 0xd5, 0x58, 0xdb, 0xbb, 0x29, 0xa6, 0x43, 0x83, 0xa9, 0xea, 0x69, 0x42, 0x7a, 0x7f, 0x25, 0xb5, 0x71, 0x21, 0xd4, 0xa4, 0x5b")
MAKE_THUNK(libvulkan, vkGetQueueCheckpointDataNV, "0xa9, 0xf8, 0xe7, 0xee, 0xa7, 0x45, 0x1c, 0xef, 0x63, 0x2b, 0xbd, 0xf6, 0xae, 0x2c, 0xbc, 0xbc, 0xde, 0x18, 0x50, 0xd1, 0xa5, 0xef, 0x2b, 0x3b, 0xf9, 0x19, 0x6f, 0xb4, 0xc8, 0x21, 0xa6, 0xf6")
MAKE_THUNK(libvulkan, vkGetQueueCheckpointData2NV, "0x98, 0xe0, 0xde, 0x4c, 0xc9, 0x74, 0xce, 0x18, 0xa2, 0x94, 0x27, 0xc5, 0x27, 0x5c, 0xe7, 0x57, 0x4e, 0x24, 0x79, 0x8e, 0xd4, 0x43, 0x89, 0xa, 0x3c, 0x3e, 0x39, 0x33, 0xbd, 0x99, 0xf3, 0x36")
MAKE_THUNK(libvulkan, vkSetSwapchainPresentTimingQueueSizeEXT, "0xed, 0xa5, 0x41, 0xc5, 0xa6, 0x6c, 0x8f, 0x20, 0x6c, 0x97, 0xfa, 0x58, 0xc4, 0xe6, 0x18, 0x30, 0xe2, 0xda, 0x91, 0xe1, 0x5a, 0x23, 0x75, 0x96, 0x57, 0x80, 0x60, 0x83, 0x6f, 0x10, 0xe4, 0xf8")
MAKE_THUNK(libvulkan, vkGetSwapchainTimingPropertiesEXT, "0xaa, 0x38, 0xe, 0xac, 0xf1, 0x6, 0xf4, 0x3a, 0x29, 0xa9, 0x59, 0x27, 0x8d, 0x7, 0x44, 0xae, 0x3d, 0x29, 0x28, 0xf, 0x83, 0xfc, 0xf2, 0x5f, 0xbc, 0x23, 0x55, 0x47, 0xf8, 0x4d, 0x4d, 0xb8")
MAKE_THUNK(libvulkan, vkGetSwapchainTimeDomainPropertiesEXT, "0x1e, 0xf1, 0xfc, 0xcc, 0x82, 0xda, 0x5d, 0x3d, 0x19, 0x6b, 0xa0, 0xfc, 0xc0, 0xde, 0x79, 0xeb, 0x30, 0x9, 0xa7, 0x99, 0xbd, 0x4d, 0xea, 0x89, 0x6a, 0xf5, 0x4, 0xfb, 0xde, 0xd5, 0x87, 0x8a")
MAKE_THUNK(libvulkan, vkGetPastPresentationTimingEXT, "0x9, 0x7c, 0x85, 0x72, 0x4, 0x9a, 0xfb, 0xb1, 0x49, 0x4b, 0xd6, 0x32, 0x9e, 0x44, 0x4, 0x29, 0xa4, 0xb, 0xd8, 0x32, 0x91, 0x7b, 0x49, 0x67, 0xd5, 0xf9, 0x50, 0xdb, 0xcd, 0x12, 0x82, 0x8")
MAKE_THUNK(libvulkan, vkInitializePerformanceApiINTEL, "0xcc, 0xb9, 0xc3, 0xa7, 0xc2, 0x67, 0x29, 0x7c, 0xaa, 0x64, 0xa7, 0xa0, 0x2c, 0xc1, 0x8b, 0x2c, 0x18, 0xb0, 0xe4, 0xbe, 0xc2, 0x36, 0x50, 0x31, 0xcd, 0xf5, 0xc4, 0xbc, 0x10, 0x32, 0x6c, 0xfa")
MAKE_THUNK(libvulkan, vkUninitializePerformanceApiINTEL, "0x6d, 0x58, 0xd5, 0xfb, 0xb0, 0x32, 0xe6, 0xda, 0x55, 0x7a, 0xdf, 0xc7, 0x2d, 0x76, 0x7a, 0xf3, 0x9f, 0x98, 0x2b, 0xac, 0x4a, 0xbd, 0x67, 0xa0, 0xab, 0x2d, 0xbb, 0x9, 0xc, 0x4a, 0xdc, 0xd9")
MAKE_THUNK(libvulkan, vkCmdSetPerformanceMarkerINTEL, "0x12, 0x5e, 0xa6, 0x7c, 0x49, 0x6d, 0x8e, 0x78, 0xdf, 0x45, 0x43, 0x26, 0x6b, 0x0, 0xa2, 0x23, 0x62, 0x8c, 0xc, 0x67, 0x94, 0xae, 0x84, 0x93, 0x4f, 0x45, 0x48, 0x1, 0x1f, 0xae, 0xd3, 0xc9")
MAKE_THUNK(libvulkan, vkCmdSetPerformanceStreamMarkerINTEL, "0xd2, 0x8b, 0x9b, 0xe7, 0x1b, 0xb8, 0x93, 0xbd, 0x49, 0xb0, 0x64, 0x8, 0xa9, 0x1f, 0xf9, 0xd5, 0xed, 0xa7, 0x2f, 0x11, 0xd5, 0x11, 0xa4, 0xa6, 0xd7, 0xd7, 0xc1, 0x3b, 0x76, 0x6a, 0xde, 0xa3")
MAKE_THUNK(libvulkan, vkCmdSetPerformanceOverrideINTEL, "0xa7, 0x64, 0xc, 0xb8, 0x98, 0xbd, 0x8e, 0xed, 0x4a, 0x62, 0x5e, 0xa9, 0x94, 0x80, 0x65, 0x2d, 0x5b, 0x20, 0x36, 0x76, 0x5, 0x90, 0x6f, 0x38, 0x97, 0xb5, 0xec, 0x21, 0xf3, 0x6f, 0x3a, 0x90")
MAKE_THUNK(libvulkan, vkAcquirePerformanceConfigurationINTEL, "0xc1, 0x22, 0xe9, 0xaa, 0xf5, 0x86, 0x99, 0x5d, 0x8f, 0x24, 0x53, 0xb5, 0x2, 0xea, 0x80, 0x6a, 0xac, 0xc3, 0x27, 0x11, 0xca, 0x42, 0xd9, 0x47, 0x7b, 0x1c, 0x53, 0xa2, 0xd5, 0x63, 0xe6, 0x5e")
MAKE_THUNK(libvulkan, vkReleasePerformanceConfigurationINTEL, "0x76, 0x74, 0x37, 0xdf, 0xab, 0x1a, 0x7, 0xea, 0x2c, 0xb3, 0x8c, 0x6e, 0xb1, 0xd6, 0xa0, 0xe2, 0x1c, 0x1a, 0xdf, 0xbb, 0x9e, 0x22, 0xb1, 0x81, 0xc8, 0x60, 0xcd, 0x11, 0xcf, 0xb1, 0x45, 0x46")
MAKE_THUNK(libvulkan, vkQueueSetPerformanceConfigurationINTEL, "0x61, 0xe0, 0x72, 0xf, 0x87, 0x74, 0xc8, 0xa4, 0x61, 0xad, 0x98, 0xb4, 0x93, 0xb0, 0x6a, 0xac, 0x9, 0x76, 0x75, 0x57, 0x59, 0x64, 0x3, 0x1, 0x68, 0x69, 0x57, 0xf6, 0x84, 0x1d, 0xa6, 0x2e")
MAKE_THUNK(libvulkan, vkGetPerformanceParameterINTEL, "0x70, 0x33, 0x1a, 0x53, 0x7, 0x6f, 0x67, 0xfd, 0xd8, 0x3e, 0xf2, 0xa1, 0x1f, 0x21, 0xc0, 0x82, 0x64, 0x3e, 0x16, 0x56, 0x6c, 0xc1, 0x40, 0x4, 0xa7, 0x28, 0x37, 0x6, 0x99, 0x45, 0x38, 0x33")
MAKE_THUNK(libvulkan, vkSetLocalDimmingAMD, "0x5c, 0x4d, 0xde, 0xe1, 0x13, 0x38, 0x55, 0x1, 0xea, 0x4a, 0x8d, 0x99, 0xf1, 0xf7, 0x1e, 0x49, 0x71, 0xfc, 0xc, 0x64, 0x88, 0x55, 0xa1, 0xe, 0x53, 0x9a, 0x62, 0x5c, 0xe4, 0xc2, 0x9c, 0x30")
MAKE_THUNK(libvulkan, vkGetBufferDeviceAddressEXT, "0xd0, 0x5e, 0x29, 0xcc, 0x34, 0x7f, 0xef, 0xcd, 0x41, 0x31, 0xa3, 0x3b, 0x5a, 0xbf, 0x43, 0x62, 0x88, 0x52, 0x88, 0xdf, 0x66, 0x7c, 0xe6, 0x1f, 0xa1, 0xf4, 0xae, 0x8c, 0x15, 0x85, 0x48, 0x41")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceToolPropertiesEXT, "0x70, 0xe1, 0xbc, 0xf6, 0x89, 0x20, 0x69, 0x53, 0x59, 0xb4, 0xdf, 0xd6, 0x7, 0xc8, 0x53, 0xc8, 0x6c, 0xbb, 0x3b, 0x12, 0xc6, 0xc0, 0x66, 0xa1, 0x1f, 0x70, 0x75, 0xce, 0x4d, 0xa, 0x4e, 0x19")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceCooperativeMatrixPropertiesNV, "0xd5, 0x25, 0xf3, 0x68, 0x7a, 0xb3, 0xa3, 0x1d, 0xc2, 0x3d, 0x42, 0xa1, 0x4c, 0x1f, 0x53, 0xe, 0x34, 0xec, 0x62, 0x6f, 0x2e, 0xbf, 0xfb, 0x20, 0x8b, 0xee, 0xaa, 0xe8, 0xb5, 0xed, 0xba, 0x3c")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceSupportedFramebufferMixedSamplesCombinationsNV, "0x9d, 0xf1, 0x32, 0xa7, 0x6, 0x71, 0x3b, 0x9a, 0x21, 0x7e, 0xb1, 0x85, 0x32, 0x56, 0xe1, 0x14, 0x58, 0xcd, 0x84, 0x1e, 0xad, 0xfd, 0xe9, 0x67, 0x54, 0x8e, 0x1c, 0x6, 0xa8, 0x3f, 0x9, 0xbb")
MAKE_THUNK(libvulkan, vkCreateHeadlessSurfaceEXT, "0x85, 0xac, 0x75, 0xed, 0xc, 0xaf, 0x2, 0x9d, 0xed, 0x55, 0x75, 0x86, 0xd9, 0x8, 0xe5, 0x19, 0x9e, 0x7f, 0xb9, 0xfd, 0x2a, 0xea, 0xb3, 0x21, 0x11, 0x1f, 0xce, 0x8b, 0x9, 0x5, 0xe7, 0x99")
MAKE_THUNK(libvulkan, vkCmdSetLineStippleEXT, "0x3f, 0x49, 0x12, 0xb4, 0xd3, 0x84, 0x8a, 0xc8, 0x64, 0xc9, 0x79, 0x34, 0xa2, 0xd4, 0x92, 0x9a, 0xf0, 0x4c, 0x96, 0xec, 0xaa, 0x16, 0xae, 0xce, 0x40, 0x49, 0xb2, 0x53, 0xb9, 0x8e, 0x9e, 0x18")
MAKE_THUNK(libvulkan, vkResetQueryPoolEXT, "0x1e, 0xe5, 0xf, 0xef, 0x2d, 0xee, 0x7f, 0x35, 0xc0, 0x10, 0x1, 0x39, 0x87, 0xca, 0x97, 0x4a, 0xa2, 0x63, 0x54, 0x3e, 0xb8, 0x3e, 0x5a, 0x50, 0xbe, 0x41, 0x19, 0x5, 0x50, 0xea, 0x8d, 0xd2")
MAKE_THUNK(libvulkan, vkCmdSetCullModeEXT, "0xee, 0x9, 0x2a, 0xe4, 0x71, 0xd0, 0x91, 0x3a, 0x2c, 0x95, 0xf9, 0x0, 0xb8, 0x86, 0x10, 0x9a, 0x6e, 0xa7, 0x76, 0x3, 0x9c, 0xa7, 0xb5, 0x5e, 0x7c, 0x5f, 0x12, 0x6f, 0x2e, 0x5d, 0x84, 0x24")
MAKE_THUNK(libvulkan, vkCmdSetFrontFaceEXT, "0x88, 0xdf, 0xf8, 0x85, 0x4a, 0x26, 0x14, 0xe9, 0x3a, 0x36, 0x1b, 0xfb, 0xe8, 0xf5, 0xcb, 0x55, 0xcf, 0x2a, 0xf2, 0x86, 0xe, 0x3d, 0x6f, 0xcc, 0x55, 0x31, 0xb9, 0x59, 0xbb, 0x5, 0x5e, 0xd8")
MAKE_THUNK(libvulkan, vkCmdSetPrimitiveTopologyEXT, "0xda, 0xea, 0xcf, 0x92, 0xd3, 0x85, 0x5f, 0x5b, 0x2d, 0x30, 0x15, 0x4f, 0xdd, 0x9a, 0xa4, 0x5d, 0x72, 0x67, 0xf2, 0xa7, 0x43, 0x80, 0xfa, 0xa0, 0x1f, 0xf1, 0x2d, 0x39, 0x9c, 0x4a, 0x5b, 0xa8")
MAKE_THUNK(libvulkan, vkCmdSetViewportWithCountEXT, "0xb5, 0xa2, 0x11, 0xf8, 0xba, 0x70, 0x3f, 0x33, 0xee, 0x45, 0x87, 0x70, 0x5a, 0x92, 0xf0, 0x49, 0x65, 0x1, 0xf6, 0x70, 0x85, 0x11, 0x5d, 0xf9, 0x4, 0x7b, 0x18, 0x32, 0xc7, 0x6d, 0x29, 0x8a")
MAKE_THUNK(libvulkan, vkCmdSetScissorWithCountEXT, "0xa3, 0x66, 0x41, 0xb8, 0x42, 0xd5, 0x6d, 0xdf, 0x91, 0xa, 0xe3, 0xf2, 0x9e, 0xdc, 0xeb, 0xa4, 0x7f, 0x8a, 0xd1, 0x23, 0xc6, 0x29, 0xae, 0xa7, 0x90, 0x42, 0x14, 0xcf, 0x4, 0xcb, 0x42, 0x3")
MAKE_THUNK(libvulkan, vkCmdBindVertexBuffers2EXT, "0xc5, 0x86, 0x73, 0x6e, 0x5b, 0x84, 0x7e, 0xb6, 0x56, 0x99, 0x46, 0x29, 0xc4, 0xdc, 0x34, 0x8d, 0x8f, 0x53, 0x3c, 0xb3, 0x9e, 0x79, 0x25, 0x20, 0x66, 0xe8, 0x5d, 0xa1, 0xdc, 0xc5, 0x46, 0x8a")
MAKE_THUNK(libvulkan, vkCmdSetDepthTestEnableEXT, "0x3, 0xf0, 0x92, 0xa5, 0xb1, 0x37, 0x57, 0xcc, 0xd7, 0xe4, 0xb9, 0xe2, 0xd8, 0x9, 0xd5, 0xa, 0xad, 0x76, 0x9, 0x4b, 0xdb, 0xb4, 0x3d, 0x4c, 0xfe, 0xf5, 0x8e, 0x3d, 0xdb, 0x25, 0xf7, 0xf")
MAKE_THUNK(libvulkan, vkCmdSetDepthWriteEnableEXT, "0x49, 0xb1, 0x3, 0x9d, 0x2b, 0xda, 0x31, 0x16, 0x30, 0x2c, 0xb3, 0x69, 0x53, 0x1b, 0x23, 0xe9, 0x11, 0x1, 0xbe, 0x91, 0xa3, 0xca, 0x8d, 0xf3, 0xa1, 0xc2, 0x33, 0x5b, 0x90, 0x55, 0x7, 0x70")
MAKE_THUNK(libvulkan, vkCmdSetDepthCompareOpEXT, "0x49, 0x5f, 0xaf, 0x80, 0x74, 0xce, 0x16, 0xc2, 0xda, 0xe9, 0x5d, 0xf9, 0x63, 0xb2, 0x39, 0x9d, 0x58, 0xb8, 0xe, 0xaf, 0xb7, 0xcb, 0xa7, 0x2d, 0x3d, 0xc1, 0xee, 0xbb, 0xe6, 0x2e, 0xc1, 0xbe")
MAKE_THUNK(libvulkan, vkCmdSetDepthBoundsTestEnableEXT, "0x9f, 0x3, 0x9c, 0xd2, 0x5d, 0xc, 0xbe, 0xbb, 0x3e, 0x15, 0x1d, 0x24, 0xa7, 0x55, 0x40, 0xec, 0x1, 0xef, 0x61, 0xef, 0x7e, 0x3, 0xe6, 0x7e, 0x4f, 0xf4, 0x4a, 0x71, 0xb7, 0xb7, 0x49, 0x59")
MAKE_THUNK(libvulkan, vkCmdSetStencilTestEnableEXT, "0xb4, 0x6, 0x8c, 0x78, 0x5b, 0xe3, 0x1f, 0x58, 0x90, 0xce, 0xd5, 0xda, 0x86, 0x25, 0x2f, 0xaa, 0x41, 0x37, 0xc2, 0x2c, 0x4b, 0x82, 0xeb, 0x13, 0xa0, 0xf2, 0x69, 0xb, 0x43, 0x49, 0xe9, 0x76")
MAKE_THUNK(libvulkan, vkCmdSetStencilOpEXT, "0xc2, 0x3, 0xb4, 0xb6, 0xe2, 0xeb, 0x52, 0x25, 0xbc, 0xcf, 0x42, 0x46, 0x22, 0x70, 0xe0, 0xf5, 0xad, 0x8c, 0xc6, 0xa4, 0x0, 0xd9, 0x5c, 0xe6, 0x8f, 0xe1, 0x6d, 0x29, 0x3e, 0x95, 0xf5, 0x84")
MAKE_THUNK(libvulkan, vkCopyMemoryToImageEXT, "0xf1, 0xb0, 0x86, 0xe1, 0x61, 0x2e, 0xbc, 0xa8, 0x83, 0x71, 0x9, 0x5d, 0xdd, 0xb2, 0xcb, 0xe7, 0xc7, 0xe3, 0x22, 0x17, 0x2c, 0x85, 0xd5, 0x87, 0x3c, 0x19, 0x69, 0x5d, 0x13, 0x89, 0xe3, 0x80")
MAKE_THUNK(libvulkan, vkCopyImageToMemoryEXT, "0x28, 0x71, 0x44, 0xe9, 0x49, 0xee, 0x4d, 0x85, 0xb6, 0x76, 0x91, 0x7, 0x3a, 0x4d, 0xc, 0xb5, 0x93, 0xa2, 0x2e, 0x72, 0xe4, 0x28, 0xd3, 0x4d, 0xf8, 0x8c, 0x1f, 0x55, 0xd4, 0x27, 0xee, 0xe3")
MAKE_THUNK(libvulkan, vkCopyImageToImageEXT, "0xd2, 0x38, 0xe0, 0xa2, 0x1c, 0x5b, 0x42, 0x4b, 0x3, 0xa7, 0xba, 0x20, 0x6, 0x59, 0x40, 0x98, 0x55, 0xe6, 0x1, 0x79, 0x81, 0x5c, 0x63, 0xcf, 0x27, 0xaa, 0xda, 0xc0, 0xa7, 0x7c, 0xab, 0xe4")
MAKE_THUNK(libvulkan, vkTransitionImageLayoutEXT, "0x12, 0x17, 0x4, 0xf2, 0xfc, 0xa2, 0xb2, 0x51, 0x86, 0xa9, 0x1e, 0x7a, 0xf4, 0x48, 0x87, 0xdd, 0xa5, 0x1, 0x52, 0x9d, 0x5f, 0x15, 0x3b, 0x92, 0x59, 0xa, 0xfc, 0xe1, 0x11, 0x64, 0xaf, 0xca")
MAKE_THUNK(libvulkan, vkGetImageSubresourceLayout2EXT, "0x51, 0x34, 0x26, 0xc8, 0xb8, 0x55, 0xf0, 0x98, 0xa0, 0x5, 0x30, 0xcf, 0x2b, 0xc4, 0xa0, 0xbb, 0xc5, 0xc9, 0x5e, 0x8f, 0xdc, 0x3d, 0xf8, 0x87, 0x42, 0x97, 0xb8, 0xf2, 0xbc, 0x24, 0xfe, 0xe9")
MAKE_THUNK(libvulkan, vkReleaseSwapchainImagesEXT, "0x40, 0x7c, 0x15, 0xce, 0x2e, 0xa5, 0x52, 0xc9, 0xc2, 0x87, 0xb3, 0x4f, 0x3, 0xff, 0x5e, 0xdb, 0xff, 0xc1, 0xac, 0xbb, 0x91, 0xa1, 0xb2, 0xfa, 0x37, 0x5e, 0xa6, 0xb1, 0xf8, 0xa7, 0x7b, 0xa1")
MAKE_THUNK(libvulkan, vkGetGeneratedCommandsMemoryRequirementsNV, "0x28, 0xeb, 0xe9, 0x86, 0x32, 0xf8, 0x7d, 0xaa, 0x8c, 0xb7, 0x67, 0x14, 0x16, 0x8e, 0xb0, 0xbc, 0x5c, 0x9b, 0x1a, 0xc2, 0x9e, 0xf2, 0xcd, 0x80, 0x91, 0x16, 0xa5, 0xab, 0x7e, 0xb2, 0x64, 0xdb")
MAKE_THUNK(libvulkan, vkCmdPreprocessGeneratedCommandsNV, "0x76, 0x70, 0x38, 0xa1, 0x17, 0x9f, 0xa0, 0x88, 0x6b, 0x73, 0x27, 0xcb, 0x9c, 0xa1, 0x50, 0x2f, 0xab, 0x4e, 0xfb, 0x92, 0xeb, 0x77, 0x63, 0x96, 0xf2, 0xae, 0x5a, 0x14, 0xf5, 0xda, 0x43, 0x9")
MAKE_THUNK(libvulkan, vkCmdExecuteGeneratedCommandsNV, "0x85, 0x5c, 0xfb, 0x2f, 0x9a, 0xfd, 0x29, 0xba, 0x19, 0x88, 0x3f, 0xd, 0xf9, 0xae, 0xed, 0xd4, 0xa, 0xf0, 0x1d, 0xa0, 0x2a, 0xea, 0xa4, 0xb1, 0x0, 0xeb, 0x42, 0xa5, 0xc0, 0xf7, 0x27, 0x56")
MAKE_THUNK(libvulkan, vkCmdBindPipelineShaderGroupNV, "0x4c, 0x7e, 0xfb, 0xbc, 0x9b, 0x44, 0xac, 0x1a, 0xe0, 0xfb, 0x8d, 0xad, 0x4, 0x38, 0x1f, 0x8e, 0xdb, 0x18, 0x28, 0xa3, 0x0, 0x10, 0x44, 0x9a, 0x9b, 0x4e, 0xe6, 0xde, 0x2d, 0x0, 0x31, 0x16")
MAKE_THUNK(libvulkan, vkCreateIndirectCommandsLayoutNV, "0x69, 0x7a, 0x4d, 0x2c, 0x19, 0xc4, 0xa8, 0xc5, 0x7c, 0x6c, 0x2e, 0xe2, 0x95, 0x11, 0x9f, 0x62, 0x7a, 0x69, 0x58, 0x78, 0x57, 0x3f, 0x93, 0xb5, 0x80, 0x1f, 0x68, 0xcc, 0x6, 0x76, 0xcd, 0xa2")
MAKE_THUNK(libvulkan, vkDestroyIndirectCommandsLayoutNV, "0x8e, 0xf, 0x34, 0x43, 0x62, 0x54, 0xec, 0xe2, 0x74, 0x85, 0x48, 0xae, 0x4c, 0xd, 0xe0, 0x60, 0x9, 0xa9, 0x69, 0xce, 0x3, 0xef, 0xa9, 0x25, 0x18, 0xe4, 0xdd, 0xdf, 0xf0, 0xbe, 0x89, 0x1b")
MAKE_THUNK(libvulkan, vkCmdSetDepthBias2EXT, "0xb, 0x45, 0x1f, 0x3f, 0x32, 0xd4, 0x40, 0xe9, 0xf9, 0x45, 0xf4, 0x96, 0x20, 0x9, 0x0, 0xe9, 0x3b, 0xa, 0x7e, 0xce, 0x77, 0x2a, 0x2, 0xb1, 0x54, 0x2d, 0x57, 0xfd, 0xe8, 0xf3, 0xbc, 0xfc")
MAKE_THUNK(libvulkan, vkAcquireDrmDisplayEXT, "0xf1, 0x6a, 0x76, 0xe4, 0x2f, 0xe2, 0x6c, 0xf9, 0x74, 0xe2, 0xeb, 0x8b, 0x74, 0x33, 0x26, 0x66, 0x1, 0x1d, 0x74, 0x73, 0x97, 0x6e, 0xc6, 0x93, 0x98, 0xc8, 0x4c, 0xc2, 0x6a, 0xc8, 0x5, 0xe1")
MAKE_THUNK(libvulkan, vkGetDrmDisplayEXT, "0xb7, 0xfe, 0x6f, 0xd9, 0xdc, 0x81, 0x7a, 0x67, 0xa6, 0x65, 0xdb, 0xfd, 0x28, 0x8, 0xbc, 0x9e, 0x60, 0x75, 0x67, 0xc8, 0xa8, 0x98, 0xd0, 0x3f, 0xa8, 0xe1, 0xa2, 0x65, 0xc0, 0x30, 0xa9, 0x29")
MAKE_THUNK(libvulkan, vkCreatePrivateDataSlotEXT, "0x37, 0x29, 0x73, 0xaa, 0xee, 0xc0, 0xfc, 0xb8, 0xe1, 0xa1, 0xf6, 0x2, 0xa0, 0xb8, 0xae, 0xa0, 0xf6, 0x83, 0x81, 0x1a, 0xc6, 0xfd, 0x73, 0x12, 0x71, 0x75, 0x70, 0xf0, 0xa9, 0x99, 0x3e, 0x55")
MAKE_THUNK(libvulkan, vkDestroyPrivateDataSlotEXT, "0x71, 0x27, 0xb4, 0xb2, 0xb8, 0x8d, 0x72, 0x35, 0x1c, 0xc8, 0xdf, 0x43, 0x99, 0xe3, 0xfa, 0xfd, 0x1a, 0x33, 0xe, 0x24, 0x86, 0x8e, 0xe6, 0xcc, 0xbc, 0xad, 0xb2, 0x52, 0xfc, 0xb5, 0xec, 0xf8")
MAKE_THUNK(libvulkan, vkSetPrivateDataEXT, "0xb6, 0x11, 0xa, 0x4, 0x38, 0xdf, 0xe0, 0x4d, 0xfc, 0x55, 0x79, 0xad, 0x74, 0x76, 0xca, 0xbf, 0xec, 0xbd, 0xd6, 0xe5, 0x89, 0xc0, 0x3c, 0xb6, 0x81, 0x6, 0x17, 0xa3, 0x72, 0x3e, 0x9, 0xaf")
MAKE_THUNK(libvulkan, vkGetPrivateDataEXT, "0x6d, 0xf, 0x7c, 0xd6, 0x50, 0x80, 0xe3, 0x4b, 0xaa, 0xb8, 0x37, 0xcb, 0x15, 0x88, 0x6e, 0x8f, 0x80, 0x2, 0x64, 0x6b, 0x87, 0x83, 0xd6, 0xa3, 0x71, 0x9c, 0x34, 0x3c, 0x8e, 0x4a, 0x3b, 0x7d")
MAKE_THUNK(libvulkan, vkCmdDispatchTileQCOM, "0x7f, 0xb7, 0x3, 0x70, 0x22, 0x3d, 0xc9, 0x54, 0xae, 0x86, 0xa6, 0xd2, 0xb2, 0xd, 0x66, 0x3e, 0xc4, 0x6, 0x7, 0xd7, 0xc3, 0x28, 0xc6, 0xa3, 0x6, 0xa2, 0x65, 0x78, 0xb0, 0x17, 0x49, 0xd8")
MAKE_THUNK(libvulkan, vkCmdBeginPerTileExecutionQCOM, "0xf, 0x11, 0xd4, 0xbc, 0xee, 0xea, 0xfb, 0xfd, 0xce, 0xa, 0xae, 0x1d, 0x39, 0x52, 0xca, 0xdd, 0xec, 0x7d, 0xbe, 0xe5, 0xe6, 0x81, 0xdf, 0x1, 0x17, 0xe, 0x30, 0xa, 0x54, 0xa0, 0x60, 0x39")
MAKE_THUNK(libvulkan, vkCmdEndPerTileExecutionQCOM, "0xd1, 0x20, 0xc2, 0x72, 0x6d, 0x85, 0xab, 0xc, 0x5e, 0xfc, 0x1e, 0x38, 0x4c, 0xae, 0xf4, 0x65, 0x2a, 0xba, 0x24, 0x87, 0x85, 0xe8, 0x35, 0xf1, 0x67, 0xd5, 0x5c, 0x42, 0x40, 0x4d, 0x3a, 0xfc")
MAKE_THUNK(libvulkan, vkGetDescriptorSetLayoutSizeEXT, "0x0, 0x5d, 0xb6, 0x20, 0xf8, 0xb8, 0xfd, 0x96, 0x70, 0x85, 0xf9, 0xe3, 0x2e, 0xfa, 0xc, 0x18, 0xbd, 0xc, 0xa1, 0x9a, 0xdf, 0xcd, 0xdd, 0x7e, 0x2d, 0x95, 0x54, 0xda, 0xb, 0x5, 0x4a, 0x4b")
MAKE_THUNK(libvulkan, vkGetDescriptorSetLayoutBindingOffsetEXT, "0x0, 0xae, 0x2f, 0x78, 0xf8, 0x4, 0x2b, 0x52, 0xa6, 0x3a, 0x21, 0x34, 0x36, 0xf8, 0xe4, 0x6b, 0x5, 0xf4, 0xce, 0xb0, 0x7e, 0x43, 0x2, 0x65, 0x52, 0x51, 0x82, 0xf1, 0xc9, 0x8c, 0x19, 0xb8")
MAKE_THUNK(libvulkan, vkGetDescriptorEXT, "0x5b, 0x79, 0xe7, 0xd, 0xf4, 0x95, 0xe8, 0x32, 0x45, 0xc9, 0x51, 0x66, 0x9a, 0x20, 0xee, 0xb0, 0x4b, 0xaa, 0x54, 0xc0, 0x46, 0x70, 0xc0, 0xf0, 0x57, 0xa, 0x4c, 0xf8, 0x30, 0xba, 0xa, 0x98")
MAKE_THUNK(libvulkan, vkCmdBindDescriptorBuffersEXT, "0x50, 0x55, 0x15, 0xf7, 0x69, 0x7d, 0x11, 0x32, 0x41, 0x53, 0xd8, 0xf9, 0xe6, 0xbe, 0xf8, 0x2a, 0xe6, 0x2f, 0xe2, 0x6e, 0x41, 0x1d, 0xc, 0x92, 0xcc, 0xec, 0xcb, 0xa1, 0xb2, 0x9c, 0xb9, 0xe5")
MAKE_THUNK(libvulkan, vkCmdSetDescriptorBufferOffsetsEXT, "0xe3, 0x5f, 0x85, 0x56, 0xcc, 0x5e, 0x95, 0x4, 0xf1, 0xf0, 0xb7, 0x49, 0x67, 0xd8, 0xdc, 0xe6, 0xd7, 0x1e, 0x68, 0x8c, 0x56, 0x2b, 0xe8, 0x3a, 0x26, 0x82, 0x66, 0x35, 0xba, 0x69, 0xf, 0x87")
MAKE_THUNK(libvulkan, vkCmdBindDescriptorBufferEmbeddedSamplersEXT, "0x70, 0x3, 0x29, 0x2b, 0xc0, 0x78, 0x8, 0x13, 0x33, 0xa, 0x58, 0x78, 0xa2, 0x21, 0x3, 0x5c, 0xcd, 0x68, 0x65, 0xb5, 0x10, 0x9d, 0x68, 0x6c, 0xfb, 0x81, 0x12, 0x94, 0x6f, 0xfe, 0x3, 0x3f")
MAKE_THUNK(libvulkan, vkGetBufferOpaqueCaptureDescriptorDataEXT, "0xb1, 0x47, 0xe8, 0xbc, 0x47, 0x72, 0x5d, 0x5, 0xd3, 0xfe, 0xb, 0xfb, 0x2d, 0x91, 0x90, 0xfe, 0x4a, 0x7e, 0x9e, 0x69, 0xab, 0xfc, 0x9d, 0xcf, 0x4c, 0xcb, 0x14, 0xfb, 0xd6, 0x9f, 0xfc, 0xf2")
MAKE_THUNK(libvulkan, vkGetImageOpaqueCaptureDescriptorDataEXT, "0x36, 0x25, 0xcc, 0x35, 0xab, 0xab, 0xc2, 0xc5, 0xa8, 0x66, 0x1f, 0x21, 0xf, 0xd4, 0x3d, 0xaa, 0x73, 0xc0, 0xaa, 0x50, 0x27, 0x6f, 0x57, 0x94, 0x8e, 0x18, 0x1f, 0xd, 0xf5, 0x9d, 0xdf, 0x1f")
MAKE_THUNK(libvulkan, vkGetImageViewOpaqueCaptureDescriptorDataEXT, "0xaa, 0x4c, 0x94, 0xe9, 0xf3, 0x78, 0x61, 0x2c, 0xed, 0x2, 0x70, 0xc, 0x92, 0xf9, 0x1, 0x71, 0x30, 0x64, 0xce, 0x10, 0x6d, 0x59, 0xf5, 0x56, 0x82, 0xe9, 0xd1, 0x6f, 0x79, 0x5f, 0xa, 0xb3")
MAKE_THUNK(libvulkan, vkGetSamplerOpaqueCaptureDescriptorDataEXT, "0x1, 0x17, 0xa9, 0xb1, 0xd1, 0xbd, 0x4d, 0x74, 0xf7, 0x6b, 0x96, 0xc8, 0x40, 0x95, 0x81, 0x20, 0x24, 0x16, 0x50, 0xca, 0xb3, 0x5b, 0xcf, 0xf6, 0x79, 0x3c, 0xa3, 0xe0, 0x32, 0x57, 0x3e, 0xc")
MAKE_THUNK(libvulkan, vkGetAccelerationStructureOpaqueCaptureDescriptorDataEXT, "0xb2, 0xd6, 0xa4, 0x69, 0xa6, 0xd4, 0x86, 0x5b, 0x41, 0xfb, 0xda, 0x71, 0x3a, 0x56, 0xeb, 0xd0, 0x7d, 0xbc, 0x2b, 0x95, 0xad, 0x9b, 0x70, 0xc9, 0x28, 0xcb, 0x13, 0x13, 0x90, 0x79, 0xc5, 0x8f")
MAKE_THUNK(libvulkan, vkCmdSetFragmentShadingRateEnumNV, "0x15, 0x81, 0x11, 0x1, 0xdd, 0x10, 0xc2, 0x6c, 0x28, 0xd0, 0x27, 0xd4, 0xe3, 0x1e, 0x46, 0x17, 0x3b, 0x8f, 0xdf, 0xc0, 0x84, 0xb1, 0xd, 0x39, 0xed, 0xf6, 0xe5, 0xfb, 0xdf, 0x73, 0x2b, 0xd3")
MAKE_THUNK(libvulkan, vkGetDeviceFaultInfoEXT, "0xc6, 0xf8, 0x6b, 0x2d, 0x72, 0x3d, 0x53, 0x31, 0x3c, 0x6a, 0x10, 0xb2, 0x48, 0x65, 0xed, 0xd3, 0x3e, 0x6f, 0xcf, 0x4c, 0x1d, 0xed, 0x90, 0x5e, 0xbf, 0x60, 0x83, 0xfd, 0xa9, 0xf9, 0xb7, 0x8e")
MAKE_THUNK(libvulkan, vkCmdSetVertexInputEXT, "0x33, 0x13, 0x1c, 0xa6, 0x28, 0x8f, 0xac, 0x2, 0xf7, 0xe4, 0xd1, 0x6c, 0x4c, 0x2b, 0x0, 0x3e, 0x20, 0x3a, 0x9e, 0xf8, 0x24, 0xa0, 0x68, 0xa, 0x30, 0xc7, 0xdd, 0x1d, 0x40, 0x60, 0xad, 0x69")
MAKE_THUNK(libvulkan, vkGetDeviceSubpassShadingMaxWorkgroupSizeHUAWEI, "0xd0, 0xf0, 0x8, 0x1, 0x54, 0xdd, 0x77, 0xcb, 0x8c, 0xaf, 0xc2, 0x5b, 0x8b, 0x2b, 0x79, 0x57, 0x59, 0x89, 0xcb, 0xeb, 0x5a, 0x87, 0x9f, 0x39, 0xac, 0xb8, 0x3a, 0x64, 0x4, 0x69, 0xb4, 0x45")
MAKE_THUNK(libvulkan, vkCmdSubpassShadingHUAWEI, "0x52, 0xb3, 0xa5, 0x24, 0x2b, 0x8f, 0xe7, 0x83, 0x61, 0x8, 0x62, 0xae, 0xd2, 0x2, 0xc, 0x20, 0x6e, 0x6a, 0x87, 0x84, 0x3d, 0x6e, 0xe5, 0xf4, 0x9f, 0xaa, 0x36, 0x23, 0xef, 0x9b, 0xe0, 0x1f")
MAKE_THUNK(libvulkan, vkCmdBindInvocationMaskHUAWEI, "0x32, 0x82, 0x97, 0xbd, 0x27, 0x1b, 0xa3, 0xed, 0xee, 0xab, 0x3c, 0x77, 0x8, 0xc5, 0x62, 0x7d, 0xea, 0x82, 0xa1, 0x64, 0x5c, 0xe7, 0xc1, 0x41, 0xd7, 0xe, 0xf1, 0xee, 0xf6, 0xa, 0xd6, 0xe5")
MAKE_THUNK(libvulkan, vkGetMemoryRemoteAddressNV, "0x8b, 0xa8, 0xb6, 0x68, 0x4a, 0x61, 0x7c, 0xf1, 0xa, 0x8f, 0xea, 0xc, 0x22, 0x8, 0x6c, 0x3c, 0x85, 0x3c, 0xc5, 0x99, 0xb7, 0xe6, 0xec, 0xda, 0x3c, 0x67, 0xd6, 0x7d, 0xbe, 0xc2, 0x72, 0x29")
MAKE_THUNK(libvulkan, vkGetPipelinePropertiesEXT, "0xfd, 0x77, 0xb1, 0x66, 0xeb, 0x9, 0xa, 0x4d, 0x5a, 0x6a, 0x68, 0x41, 0x86, 0x17, 0x14, 0xc4, 0x9a, 0xec, 0x47, 0xf0, 0xbd, 0xf4, 0xc7, 0xb8, 0x86, 0xb6, 0x69, 0xcb, 0x17, 0xd3, 0x32, 0x1")
MAKE_THUNK(libvulkan, vkCmdSetPatchControlPointsEXT, "0x57, 0x8c, 0xe6, 0xdb, 0xfa, 0xa9, 0xab, 0xf8, 0xbf, 0x79, 0xa8, 0x48, 0xb6, 0x69, 0xe, 0x39, 0xe8, 0xa1, 0x40, 0xe2, 0x5d, 0x3b, 0x43, 0xa2, 0x1b, 0x44, 0xa9, 0xa2, 0x22, 0xb6, 0xe4, 0xb1")
MAKE_THUNK(libvulkan, vkCmdSetRasterizerDiscardEnableEXT, "0x7f, 0xb8, 0x2, 0x11, 0x1a, 0x42, 0xe0, 0x47, 0x6c, 0x5e, 0xa8, 0xd, 0x61, 0x1c, 0xea, 0x58, 0x18, 0xe0, 0x59, 0xc8, 0xad, 0x1b, 0x32, 0x4d, 0x39, 0xb0, 0x1c, 0x4f, 0xb6, 0x68, 0xbe, 0xcc")
MAKE_THUNK(libvulkan, vkCmdSetDepthBiasEnableEXT, "0x3c, 0xac, 0x7e, 0xb6, 0xbc, 0x4, 0x9b, 0xf7, 0xea, 0xc0, 0x7e, 0xbb, 0x96, 0xe5, 0xa, 0x3f, 0xf2, 0x95, 0x91, 0x73, 0xb3, 0x6f, 0xdb, 0x8c, 0xf, 0x83, 0x9, 0x36, 0x67, 0x30, 0x14, 0x94")
MAKE_THUNK(libvulkan, vkCmdSetLogicOpEXT, "0xdd, 0xaf, 0x6b, 0x79, 0x45, 0xc6, 0x8, 0x9d, 0xb9, 0x7a, 0x2a, 0xca, 0xd0, 0x4f, 0xe5, 0x17, 0xa0, 0x14, 0x6c, 0x55, 0x6f, 0xbc, 0x54, 0x54, 0x33, 0x0, 0xa2, 0x10, 0x77, 0x39, 0xb0, 0xfb")
MAKE_THUNK(libvulkan, vkCmdSetPrimitiveRestartEnableEXT, "0x4b, 0xbb, 0x0, 0xf4, 0x27, 0x3, 0x96, 0xe5, 0x48, 0xfa, 0xf, 0xc6, 0x56, 0xd8, 0x43, 0xe6, 0xd, 0x7b, 0x83, 0x7, 0x6c, 0xd0, 0xb8, 0xa5, 0x86, 0x95, 0x52, 0xed, 0xfd, 0x9c, 0xbe, 0xcd")
MAKE_THUNK(libvulkan, vkCmdSetColorWriteEnableEXT, "0xd0, 0x1d, 0x4a, 0x38, 0xd6, 0x74, 0xf6, 0x89, 0x2e, 0xd5, 0x44, 0x12, 0x6a, 0xcf, 0xcb, 0xd9, 0xb8, 0xd1, 0xf8, 0x51, 0x81, 0x27, 0x5b, 0xb1, 0xb6, 0x61, 0x40, 0xc8, 0xa7, 0xa, 0x98, 0x11")
MAKE_THUNK(libvulkan, vkCmdDrawMultiEXT, "0x99, 0x7d, 0xe, 0x43, 0xe3, 0x22, 0xb0, 0xfa, 0x2a, 0x17, 0xa7, 0xb, 0x2a, 0xc, 0x69, 0xa7, 0x92, 0xc5, 0x1e, 0x74, 0xfc, 0x35, 0x56, 0x63, 0xa6, 0xbf, 0xca, 0xcf, 0xe1, 0x9, 0x43, 0x3a")
MAKE_THUNK(libvulkan, vkCmdDrawMultiIndexedEXT, "0xf4, 0x36, 0xb7, 0xe2, 0x5, 0x6b, 0x2a, 0x73, 0x6c, 0x19, 0xfa, 0xd0, 0x2, 0x3d, 0x70, 0xd0, 0x89, 0x9c, 0x0, 0x78, 0x1a, 0x9d, 0x78, 0x7c, 0x29, 0x84, 0xaf, 0x69, 0xd9, 0x2e, 0xac, 0xc1")
MAKE_THUNK(libvulkan, vkCreateMicromapEXT, "0xd9, 0x57, 0x53, 0x15, 0x59, 0x80, 0x85, 0x42, 0x70, 0x88, 0x53, 0x4a, 0xeb, 0xcf, 0x5b, 0x82, 0x20, 0x90, 0x4, 0x77, 0x23, 0x91, 0xdc, 0x8b, 0x5d, 0x2f, 0x6, 0xf0, 0xfd, 0x32, 0xc2, 0xf5")
MAKE_THUNK(libvulkan, vkDestroyMicromapEXT, "0x6c, 0xdf, 0xbb, 0x91, 0xd7, 0xb2, 0xb8, 0x6c, 0xf3, 0xd4, 0xc, 0x94, 0x3b, 0x1d, 0x8, 0x2e, 0xe6, 0x96, 0x42, 0x6a, 0xed, 0x85, 0xcb, 0xb0, 0x1, 0x7b, 0x8e, 0xb0, 0xa3, 0x74, 0xec, 0xa7")
MAKE_THUNK(libvulkan, vkCmdBuildMicromapsEXT, "0x54, 0xf9, 0x46, 0xf2, 0x9e, 0x80, 0xed, 0xa2, 0xe4, 0x34, 0xaa, 0x7e, 0x9b, 0x34, 0xd6, 0x74, 0x7e, 0x86, 0xf9, 0xc2, 0xc4, 0x34, 0x6, 0x6f, 0x1, 0xd8, 0xc6, 0x24, 0x90, 0x67, 0xd2, 0x6")
MAKE_THUNK(libvulkan, vkBuildMicromapsEXT, "0x21, 0x36, 0x95, 0x7e, 0x97, 0x5e, 0x58, 0x99, 0x9c, 0x8a, 0xea, 0xbf, 0x98, 0x84, 0x7b, 0x53, 0xa6, 0x89, 0x6e, 0x7e, 0xae, 0x1, 0x43, 0xae, 0xfc, 0x7b, 0x43, 0xb4, 0xa3, 0x5b, 0xd9, 0x47")
MAKE_THUNK(libvulkan, vkCopyMicromapEXT, "0xe7, 0xf7, 0x48, 0x1e, 0x7, 0xa0, 0x69, 0x12, 0x10, 0x54, 0xdc, 0x3b, 0xa1, 0x32, 0x2e, 0x3a, 0xa6, 0x8, 0x47, 0xfc, 0xb1, 0x84, 0xb8, 0xa1, 0xdd, 0xe5, 0x74, 0x48, 0x8d, 0x13, 0xe4, 0xfd")
MAKE_THUNK(libvulkan, vkCopyMicromapToMemoryEXT, "0x1, 0xf2, 0x62, 0xa0, 0x2d, 0xea, 0xb3, 0x17, 0xb8, 0xe5, 0x29, 0xbe, 0x15, 0xa3, 0x92, 0xca, 0xf9, 0xf9, 0x6e, 0x4a, 0x79, 0xa5, 0x90, 0x8b, 0x7, 0xf3, 0xb3, 0x35, 0xa9, 0x5b, 0x6f, 0x71")
MAKE_THUNK(libvulkan, vkCopyMemoryToMicromapEXT, "0x25, 0x19, 0xd1, 0xbd, 0x88, 0xfd, 0x1f, 0x1d, 0x99, 0x75, 0x18, 0xc7, 0x9d, 0xf1, 0x29, 0xc6, 0xbe, 0x7b, 0x53, 0xc, 0x24, 0xfc, 0xfa, 0xcb, 0xe, 0x29, 0x54, 0x58, 0x77, 0x69, 0x51, 0xd7")
MAKE_THUNK(libvulkan, vkWriteMicromapsPropertiesEXT, "0x2a, 0x35, 0xf2, 0xdb, 0xf0, 0x88, 0x74, 0x5, 0x4b, 0x26, 0x5e, 0xb9, 0x96, 0xad, 0x30, 0xda, 0xb1, 0x83, 0x17, 0xb6, 0xd7, 0xb, 0x71, 0x3b, 0xcd, 0x11, 0x14, 0xbb, 0x14, 0x50, 0xf9, 0x15")
MAKE_THUNK(libvulkan, vkCmdCopyMicromapEXT, "0xa4, 0x1a, 0xe3, 0xc0, 0xf, 0x98, 0x1f, 0x48, 0xf3, 0x34, 0xc1, 0xa5, 0x8, 0x64, 0x6b, 0x1c, 0x19, 0xa4, 0xc9, 0xb0, 0x50, 0x12, 0xec, 0x9b, 0x2f, 0x5d, 0x9d, 0x59, 0xb, 0x17, 0x97, 0x6b")
MAKE_THUNK(libvulkan, vkCmdCopyMicromapToMemoryEXT, "0x6d, 0x3, 0x27, 0xa3, 0xbb, 0x6c, 0x85, 0xc7, 0x6, 0x91, 0xf5, 0x59, 0xcd, 0x5b, 0xfc, 0x67, 0x95, 0x4b, 0xae, 0x9e, 0x75, 0x60, 0x77, 0xe, 0x97, 0x8c, 0x56, 0xba, 0xf2, 0x61, 0x2, 0x7c")
MAKE_THUNK(libvulkan, vkCmdCopyMemoryToMicromapEXT, "0x2e, 0x46, 0xbe, 0x44, 0x81, 0xff, 0x39, 0x49, 0x61, 0xa0, 0xff, 0x87, 0x92, 0x3, 0xa5, 0x47, 0x81, 0x3a, 0x1c, 0x37, 0x28, 0x2c, 0xc2, 0xfb, 0x1e, 0xc8, 0x19, 0x4c, 0x7b, 0x39, 0x80, 0x7")
MAKE_THUNK(libvulkan, vkCmdWriteMicromapsPropertiesEXT, "0x88, 0xfa, 0xb6, 0x55, 0xc9, 0x49, 0x5b, 0xa9, 0xf, 0x9, 0x2e, 0x81, 0x7b, 0x5d, 0xe3, 0xf7, 0xa1, 0xf5, 0x76, 0x8a, 0xc7, 0xd0, 0xb1, 0x14, 0x15, 0xd2, 0xfb, 0x62, 0x85, 0x27, 0x7d, 0xc")
MAKE_THUNK(libvulkan, vkGetDeviceMicromapCompatibilityEXT, "0xf5, 0xc1, 0xed, 0xdc, 0x44, 0xc9, 0x1b, 0x97, 0xa6, 0x4f, 0xe8, 0xc5, 0xf4, 0x51, 0xd3, 0xde, 0xbe, 0xf9, 0x17, 0xed, 0xf7, 0x6f, 0xc7, 0xb8, 0x83, 0xa7, 0xca, 0x73, 0x97, 0xf9, 0x16, 0xd5")
MAKE_THUNK(libvulkan, vkGetMicromapBuildSizesEXT, "0xaa, 0xa6, 0xe1, 0x92, 0x15, 0xaf, 0x5c, 0xd0, 0x99, 0x19, 0xba, 0xee, 0x69, 0xdb, 0xfa, 0x65, 0xd2, 0x59, 0x22, 0xfe, 0xe1, 0x6e, 0x82, 0xcb, 0x1e, 0xdf, 0x56, 0x8, 0x90, 0xd7, 0xa1, 0xce")
MAKE_THUNK(libvulkan, vkCmdDrawClusterHUAWEI, "0x82, 0xb, 0xfa, 0x5e, 0xfe, 0xec, 0xe, 0xff, 0x16, 0x9c, 0x3f, 0x17, 0x3e, 0xff, 0x8, 0x53, 0x8e, 0xf8, 0x4, 0xf4, 0x1a, 0xd5, 0xb6, 0xa0, 0x89, 0x76, 0x74, 0xb0, 0xaf, 0x3, 0x57, 0x9a")
MAKE_THUNK(libvulkan, vkCmdDrawClusterIndirectHUAWEI, "0x8, 0x5a, 0x23, 0x35, 0x67, 0xf6, 0x66, 0xab, 0x27, 0x9c, 0x39, 0xfa, 0xe2, 0x77, 0x1e, 0x84, 0x85, 0x14, 0x8, 0xbc, 0x50, 0x13, 0xd7, 0x9c, 0x24, 0x3b, 0x16, 0xe2, 0x4b, 0xc1, 0xb0, 0x22")
MAKE_THUNK(libvulkan, vkSetDeviceMemoryPriorityEXT, "0xe6, 0x13, 0x69, 0x3d, 0xe8, 0x99, 0xad, 0xfe, 0x72, 0xda, 0x77, 0xd5, 0xac, 0xc, 0xd1, 0x5f, 0x66, 0x2d, 0xe0, 0xc3, 0x6, 0xa2, 0x2, 0x12, 0x25, 0x8b, 0xdc, 0x83, 0x61, 0x22, 0x29, 0x88")
MAKE_THUNK(libvulkan, vkGetDescriptorSetLayoutHostMappingInfoVALVE, "0x3, 0x6b, 0xb, 0x82, 0x9, 0xab, 0xcf, 0xec, 0x61, 0x19, 0xf2, 0xec, 0x16, 0x3, 0x9a, 0x24, 0xf9, 0x59, 0xc, 0xf6, 0x9a, 0x58, 0x48, 0x26, 0xf, 0xd6, 0x50, 0x28, 0xbf, 0x86, 0x3e, 0xca")
MAKE_THUNK(libvulkan, vkGetDescriptorSetHostMappingVALVE, "0x71, 0x29, 0x71, 0xce, 0x49, 0x42, 0xb9, 0x14, 0xf9, 0xfc, 0x8b, 0xe4, 0x49, 0x7d, 0xba, 0x8a, 0x25, 0x44, 0xa6, 0xba, 0x19, 0xec, 0x34, 0xe3, 0x72, 0xbd, 0xc0, 0x1f, 0x80, 0x50, 0x5d, 0xc6")
MAKE_THUNK(libvulkan, vkCmdCopyMemoryIndirectNV, "0x9c, 0x23, 0x9c, 0xc1, 0x1a, 0x3a, 0xc3, 0x1, 0x25, 0xe0, 0xb2, 0x33, 0x10, 0x71, 0xa4, 0xa7, 0xaf, 0x5b, 0x3, 0x76, 0xcc, 0x2, 0x11, 0x56, 0x53, 0x40, 0xd, 0xd7, 0xc6, 0xed, 0x45, 0xd8")
MAKE_THUNK(libvulkan, vkCmdCopyMemoryToImageIndirectNV, "0xaa, 0xce, 0x47, 0xcc, 0xaf, 0xe2, 0xce, 0x24, 0xac, 0x0, 0x8a, 0x3a, 0x2a, 0xd6, 0x6b, 0x66, 0xd2, 0x6c, 0xff, 0x31, 0xd0, 0x1a, 0x67, 0x34, 0x2a, 0x6e, 0xbc, 0xc9, 0x44, 0x18, 0x5c, 0x75")
MAKE_THUNK(libvulkan, vkCmdDecompressMemoryNV, "0x46, 0x34, 0x6c, 0xec, 0x2f, 0xa, 0x85, 0x38, 0xab, 0xb1, 0xcb, 0x51, 0x8a, 0x61, 0x60, 0xe8, 0xd6, 0x1f, 0xa8, 0x91, 0x79, 0x59, 0x71, 0xb7, 0x32, 0x33, 0xed, 0xe3, 0x14, 0x69, 0xb9, 0xf8")
MAKE_THUNK(libvulkan, vkCmdDecompressMemoryIndirectCountNV, "0x55, 0xf4, 0x4e, 0x8, 0x50, 0x2e, 0xe9, 0x90, 0x9c, 0xc8, 0x94, 0x9, 0x4a, 0xce, 0x13, 0x75, 0x8c, 0x4a, 0x33, 0x80, 0x22, 0x98, 0xa2, 0xca, 0xb4, 0x2c, 0xa6, 0x61, 0xad, 0xb9, 0xf9, 0xf7")
MAKE_THUNK(libvulkan, vkGetPipelineIndirectMemoryRequirementsNV, "0x74, 0xde, 0xa7, 0x3c, 0x80, 0x73, 0xaa, 0xa3, 0xec, 0x23, 0x78, 0xa7, 0x61, 0x41, 0xd1, 0x5c, 0x91, 0x7b, 0xbe, 0xd, 0x2c, 0xda, 0x36, 0xf6, 0xd4, 0x94, 0x65, 0x44, 0xa3, 0x68, 0x1e, 0xaf")
MAKE_THUNK(libvulkan, vkCmdUpdatePipelineIndirectBufferNV, "0x4b, 0x71, 0x83, 0x9b, 0x33, 0xdb, 0x27, 0xb6, 0x5c, 0x67, 0xe0, 0x5d, 0xd2, 0xf9, 0x74, 0x4b, 0x4f, 0xf6, 0x87, 0x8d, 0x35, 0x52, 0x2, 0x21, 0x10, 0xe7, 0x63, 0x46, 0x19, 0xbf, 0x68, 0xf8")
MAKE_THUNK(libvulkan, vkGetPipelineIndirectDeviceAddressNV, "0x5e, 0xdd, 0xe9, 0x97, 0x78, 0x41, 0x51, 0x9, 0x52, 0x9f, 0x99, 0xb5, 0x67, 0x66, 0x88, 0x6e, 0xda, 0xa7, 0xe6, 0x9a, 0xc3, 0x4c, 0xef, 0xd7, 0xd6, 0xcb, 0xe4, 0x98, 0x99, 0xa, 0x77, 0xac")
MAKE_THUNK(libvulkan, vkCmdSetDepthClampEnableEXT, "0x34, 0x7, 0x40, 0x2, 0xc5, 0x2d, 0xd1, 0xad, 0x5b, 0x58, 0x1, 0x35, 0x62, 0x20, 0x9e, 0x27, 0xa3, 0xc4, 0x33, 0xe1, 0x59, 0x38, 0xcf, 0xa9, 0xb, 0xaa, 0x59, 0xc0, 0xa2, 0xb2, 0x4b, 0xdc")
MAKE_THUNK(libvulkan, vkCmdSetPolygonModeEXT, "0x6, 0x9b, 0x3, 0xa4, 0x4f, 0xf8, 0x8b, 0xa1, 0xe1, 0x84, 0x7, 0x54, 0x41, 0xf7, 0x9b, 0x74, 0xda, 0x7a, 0xf0, 0x2f, 0x9d, 0x28, 0xa1, 0xd1, 0xd7, 0xbe, 0x37, 0x95, 0xd0, 0x5a, 0xf8, 0xfd")
MAKE_THUNK(libvulkan, vkCmdSetRasterizationSamplesEXT, "0xb2, 0xdb, 0xe8, 0x1a, 0xfb, 0x36, 0xeb, 0x8b, 0x72, 0x93, 0x3a, 0x32, 0xe8, 0x16, 0x23, 0xf3, 0xf2, 0xc8, 0x4a, 0x77, 0x75, 0xa, 0x76, 0x21, 0xa3, 0x60, 0xd5, 0x96, 0xf0, 0x90, 0x7b, 0x89")
MAKE_THUNK(libvulkan, vkCmdSetSampleMaskEXT, "0x6b, 0x4a, 0x70, 0x42, 0x5d, 0x36, 0x9f, 0x76, 0xb4, 0xd, 0x76, 0xc2, 0x2, 0xaa, 0x18, 0x4f, 0xa9, 0xf6, 0xb2, 0x9d, 0x76, 0x3a, 0xca, 0xbb, 0xb5, 0x90, 0xf3, 0x81, 0xaa, 0x1d, 0xf, 0xb3")
MAKE_THUNK(libvulkan, vkCmdSetAlphaToCoverageEnableEXT, "0xf, 0x1b, 0x30, 0x20, 0xf5, 0x82, 0x8d, 0xfa, 0xf5, 0x7d, 0x34, 0x45, 0x9b, 0x65, 0x81, 0x49, 0xb4, 0xa2, 0x37, 0x4, 0xb6, 0xb2, 0xe5, 0x1d, 0x9d, 0x40, 0x1a, 0xb4, 0xec, 0x55, 0x2a, 0x63")
MAKE_THUNK(libvulkan, vkCmdSetAlphaToOneEnableEXT, "0x2b, 0x7e, 0xf4, 0x82, 0xeb, 0xc6, 0xbf, 0x78, 0xd3, 0xdf, 0x6, 0xab, 0x8b, 0x62, 0xe7, 0xed, 0x4e, 0x5f, 0xa6, 0x3, 0xeb, 0xf2, 0x8, 0xf8, 0x1e, 0xdf, 0xc2, 0x97, 0x0, 0x75, 0xd8, 0x77")
MAKE_THUNK(libvulkan, vkCmdSetLogicOpEnableEXT, "0x8b, 0x4d, 0x52, 0x5a, 0x52, 0xa6, 0xd, 0x78, 0x85, 0xe7, 0x7c, 0xa8, 0x4, 0x3a, 0x4c, 0xcf, 0xb2, 0x38, 0x82, 0xdf, 0x75, 0xb1, 0x57, 0x2a, 0x56, 0xed, 0x50, 0xdb, 0xf, 0x70, 0x65, 0xd6")
MAKE_THUNK(libvulkan, vkCmdSetColorBlendEnableEXT, "0x55, 0x8e, 0x42, 0xcf, 0xbf, 0x43, 0x63, 0xf5, 0x96, 0xa1, 0xe3, 0x3c, 0x38, 0x54, 0x14, 0xb3, 0x0, 0xec, 0xf9, 0x14, 0x43, 0x4, 0x20, 0x76, 0xb4, 0xbe, 0x80, 0x21, 0x6a, 0xe3, 0x57, 0xbb")
MAKE_THUNK(libvulkan, vkCmdSetColorBlendEquationEXT, "0xe1, 0x21, 0xbb, 0x51, 0xc4, 0xe, 0xe7, 0xa4, 0xe3, 0x40, 0x7, 0xc4, 0x50, 0xc3, 0xf6, 0x9f, 0x45, 0x66, 0xcb, 0x8f, 0xa5, 0x4a, 0x2c, 0xab, 0x43, 0xe8, 0xa4, 0x78, 0x10, 0xa1, 0xfe, 0x65")
MAKE_THUNK(libvulkan, vkCmdSetColorWriteMaskEXT, "0x1a, 0x6b, 0x5e, 0xfc, 0xbd, 0x7d, 0x8f, 0x10, 0xff, 0x2d, 0x95, 0xfd, 0x96, 0x3d, 0xf4, 0xac, 0x3e, 0x69, 0x79, 0x90, 0x49, 0xaa, 0x70, 0x40, 0x20, 0x7b, 0xb, 0x5d, 0xa7, 0x8c, 0x68, 0x91")
MAKE_THUNK(libvulkan, vkCmdSetTessellationDomainOriginEXT, "0x94, 0x1f, 0x76, 0x97, 0xfc, 0xdf, 0x58, 0xb7, 0x65, 0x46, 0x87, 0xb4, 0xc7, 0xb, 0xc5, 0xad, 0x76, 0x2b, 0x2b, 0x35, 0xa2, 0xf0, 0x90, 0x3d, 0xe7, 0x6c, 0x34, 0x9f, 0xa0, 0x1e, 0xad, 0x68")
MAKE_THUNK(libvulkan, vkCmdSetRasterizationStreamEXT, "0x96, 0x76, 0xc0, 0x7e, 0x36, 0x42, 0xbb, 0x9a, 0xcd, 0x62, 0x53, 0xc7, 0x5e, 0x98, 0xb7, 0xe4, 0x3c, 0x5d, 0x91, 0xb9, 0xdf, 0xed, 0x59, 0x19, 0xc4, 0xc8, 0x3c, 0xbc, 0x18, 0x34, 0xd6, 0x2e")
MAKE_THUNK(libvulkan, vkCmdSetConservativeRasterizationModeEXT, "0x20, 0x57, 0x5, 0x49, 0x37, 0x12, 0x9d, 0xcc, 0xaa, 0x77, 0xda, 0xcd, 0x3d, 0xb9, 0x85, 0xf0, 0x26, 0xbe, 0xd5, 0x84, 0x1c, 0x95, 0xd7, 0xfa, 0xf, 0x4, 0x3a, 0x5a, 0x70, 0x77, 0x90, 0x8b")
MAKE_THUNK(libvulkan, vkCmdSetExtraPrimitiveOverestimationSizeEXT, "0xee, 0xe3, 0x66, 0x71, 0x7c, 0x29, 0xca, 0x98, 0xd8, 0xb7, 0x71, 0x33, 0xc7, 0x2b, 0xe2, 0x3f, 0x95, 0xab, 0xb6, 0x74, 0xfa, 0x16, 0xe5, 0x8a, 0xaf, 0x40, 0xd1, 0xb1, 0xc8, 0xc3, 0x5f, 0xd7")
MAKE_THUNK(libvulkan, vkCmdSetDepthClipEnableEXT, "0x3b, 0x65, 0x3d, 0x16, 0x7f, 0x1d, 0x93, 0xf5, 0x47, 0xf1, 0xb3, 0xaa, 0xa4, 0xa2, 0x89, 0xfa, 0x33, 0xd6, 0xef, 0x92, 0xa6, 0xde, 0x1b, 0x7f, 0x27, 0x96, 0xb8, 0xba, 0x7b, 0xe3, 0xc7, 0x90")
MAKE_THUNK(libvulkan, vkCmdSetSampleLocationsEnableEXT, "0x24, 0x55, 0xa9, 0x20, 0x1f, 0x6b, 0x27, 0x8e, 0x37, 0x8a, 0x8c, 0xd7, 0x91, 0xfc, 0x15, 0xae, 0xf8, 0x5e, 0x9e, 0xe2, 0xeb, 0x1c, 0x4b, 0x47, 0xce, 0x32, 0x9b, 0x9c, 0xd7, 0x1f, 0x59, 0x93")
MAKE_THUNK(libvulkan, vkCmdSetColorBlendAdvancedEXT, "0x80, 0xba, 0xa6, 0x91, 0x92, 0xe6, 0xd0, 0xa4, 0xc8, 0x9c, 0xe7, 0xf1, 0x2c, 0xf3, 0xd, 0x9d, 0x70, 0xe4, 0x82, 0xc5, 0xe4, 0xfd, 0xe3, 0xe4, 0xbc, 0xa, 0x65, 0x3f, 0xf7, 0xd4, 0xb2, 0x2b")
MAKE_THUNK(libvulkan, vkCmdSetProvokingVertexModeEXT, "0xb, 0xe3, 0x53, 0xfa, 0xe5, 0x50, 0xb3, 0x97, 0xc6, 0x62, 0xec, 0x59, 0x2f, 0xff, 0xdf, 0x1b, 0x27, 0x29, 0xe9, 0x75, 0x99, 0x4, 0x9e, 0x8f, 0xba, 0xf, 0xd6, 0x94, 0x98, 0x72, 0x88, 0xf2")
MAKE_THUNK(libvulkan, vkCmdSetLineRasterizationModeEXT, "0xac, 0x6a, 0xc7, 0x6c, 0xca, 0x4b, 0x48, 0xb3, 0xb0, 0xca, 0x45, 0xb6, 0xf0, 0xcf, 0x8f, 0x3c, 0x79, 0x57, 0xf7, 0x9e, 0xcf, 0x17, 0xc, 0x85, 0xdf, 0x49, 0x6, 0x5b, 0xb1, 0x9, 0x13, 0x29")
MAKE_THUNK(libvulkan, vkCmdSetLineStippleEnableEXT, "0xab, 0xbd, 0x75, 0x61, 0x33, 0x5d, 0xad, 0xb5, 0x8a, 0x56, 0x91, 0x36, 0x34, 0x8, 0x43, 0x61, 0x8d, 0x86, 0x79, 0x11, 0x4e, 0x1e, 0x5f, 0x55, 0x1, 0x65, 0xbc, 0x6e, 0x74, 0x65, 0xff, 0x50")
MAKE_THUNK(libvulkan, vkCmdSetDepthClipNegativeOneToOneEXT, "0x30, 0xbe, 0xf1, 0xcf, 0xb5, 0x5c, 0x94, 0x13, 0x1c, 0x53, 0x8c, 0x3d, 0xb5, 0x5d, 0xda, 0xea, 0x8, 0x2f, 0x50, 0x52, 0x61, 0xc2, 0x4b, 0xa5, 0x31, 0x51, 0xef, 0xb4, 0x54, 0xe4, 0xed, 0x8f")
MAKE_THUNK(libvulkan, vkCmdSetViewportWScalingEnableNV, "0xa8, 0x2e, 0x1e, 0xdb, 0x39, 0x59, 0xcc, 0x60, 0x8b, 0xa8, 0x6, 0x38, 0xb5, 0xfd, 0xca, 0x3, 0xfa, 0xf5, 0xeb, 0xa9, 0x4c, 0xcd, 0x2f, 0xb0, 0xea, 0xce, 0x26, 0x3d, 0x12, 0xa0, 0x48, 0xea")
MAKE_THUNK(libvulkan, vkCmdSetViewportSwizzleNV, "0x9b, 0x87, 0x4d, 0x9e, 0x39, 0xf7, 0xd5, 0x82, 0xf0, 0xff, 0x35, 0xd5, 0x32, 0xa1, 0x74, 0xb9, 0xe8, 0xcc, 0x6f, 0x6a, 0x77, 0x3e, 0xbd, 0x8c, 0xc2, 0x2, 0xc9, 0x16, 0x14, 0xb2, 0x9a, 0xce")
MAKE_THUNK(libvulkan, vkCmdSetCoverageToColorEnableNV, "0x61, 0x2f, 0x2c, 0x8c, 0xa0, 0xe1, 0xe5, 0xb1, 0x88, 0x96, 0x8e, 0xcc, 0x1, 0xc2, 0x1f, 0x83, 0x33, 0xbf, 0xb7, 0xd2, 0x4b, 0x80, 0x6c, 0xaf, 0x15, 0x3c, 0x13, 0x1d, 0x36, 0xe1, 0x2c, 0x5e")
MAKE_THUNK(libvulkan, vkCmdSetCoverageToColorLocationNV, "0xb1, 0xa7, 0xe5, 0x44, 0x95, 0x22, 0xe9, 0xd7, 0x15, 0xcb, 0x65, 0xbd, 0xc6, 0x5d, 0xad, 0x9b, 0x78, 0x12, 0xe1, 0xe1, 0x9f, 0x71, 0x35, 0x2d, 0x6, 0xd6, 0xbf, 0xda, 0xa8, 0x8b, 0x63, 0x4d")
MAKE_THUNK(libvulkan, vkCmdSetCoverageModulationModeNV, "0xb3, 0x33, 0x99, 0x82, 0xf9, 0xb1, 0x70, 0xbb, 0x73, 0xe6, 0x13, 0xc2, 0xde, 0x80, 0xbe, 0xd6, 0x6c, 0x6f, 0x30, 0x4b, 0x92, 0x89, 0x75, 0x81, 0xf7, 0x62, 0x67, 0xf6, 0xf1, 0x51, 0xc9, 0xff")
MAKE_THUNK(libvulkan, vkCmdSetCoverageModulationTableEnableNV, "0x19, 0xff, 0xc9, 0xba, 0xb7, 0x12, 0xa1, 0xf3, 0xed, 0x7b, 0xb7, 0xc4, 0xec, 0x61, 0xd3, 0xd4, 0x8a, 0x39, 0x2e, 0x88, 0x42, 0x61, 0x4c, 0x83, 0x52, 0xc6, 0x18, 0xad, 0x61, 0xeb, 0xf8, 0x7")
MAKE_THUNK(libvulkan, vkCmdSetCoverageModulationTableNV, "0x53, 0xc7, 0xa, 0x4a, 0x4d, 0x1, 0x23, 0xd, 0x68, 0xb8, 0xa9, 0xa4, 0x60, 0x9, 0x4e, 0x85, 0x10, 0x40, 0xd5, 0xc2, 0x6c, 0x4, 0x95, 0xe0, 0x35, 0xb6, 0x49, 0x95, 0x2d, 0x1b, 0x81, 0x39")
MAKE_THUNK(libvulkan, vkCmdSetShadingRateImageEnableNV, "0xb6, 0x6e, 0x9, 0xaf, 0x9, 0x12, 0xda, 0x82, 0xcc, 0x4f, 0x11, 0x5b, 0x34, 0x37, 0xb2, 0x59, 0xcb, 0x98, 0xfd, 0x77, 0x4e, 0xd8, 0x6d, 0xad, 0x2f, 0x67, 0xed, 0x96, 0xcc, 0x51, 0xc0, 0xae")
MAKE_THUNK(libvulkan, vkCmdSetRepresentativeFragmentTestEnableNV, "0x3b, 0x6b, 0x5b, 0x1e, 0x3b, 0x50, 0xd3, 0x91, 0x40, 0x88, 0xf6, 0x89, 0x47, 0xf5, 0xf, 0x8b, 0xe1, 0xfb, 0x80, 0xfd, 0x29, 0x4, 0xff, 0xce, 0x9e, 0x9e, 0x42, 0x8, 0xd5, 0x8a, 0x5c, 0x74")
MAKE_THUNK(libvulkan, vkCmdSetCoverageReductionModeNV, "0xf, 0x59, 0xed, 0x3b, 0x13, 0xfd, 0x16, 0xb5, 0xe2, 0x24, 0xd0, 0x92, 0x2d, 0x31, 0x6e, 0xce, 0x2d, 0x8a, 0x85, 0x3f, 0x3c, 0x9c, 0xfb, 0x16, 0xe8, 0x36, 0x9b, 0x15, 0x1a, 0xc1, 0x23, 0x88")
MAKE_THUNK(libvulkan, vkCreateTensorARM, "0x9, 0xcf, 0x3e, 0x99, 0x9f, 0x89, 0x0, 0x4a, 0x35, 0xb9, 0x71, 0x18, 0x72, 0xf6, 0x56, 0xf6, 0xd8, 0xa7, 0x7a, 0xbd, 0x69, 0x29, 0x1e, 0x5b, 0x59, 0xbb, 0x29, 0x5b, 0x61, 0xa6, 0xe2, 0x3e")
MAKE_THUNK(libvulkan, vkDestroyTensorARM, "0x5a, 0x28, 0x5f, 0x2d, 0x5a, 0x59, 0x76, 0x53, 0x59, 0x63, 0xe3, 0x63, 0x78, 0x55, 0x68, 0xe4, 0x15, 0x58, 0xf2, 0x5e, 0x54, 0xf0, 0x8e, 0x7d, 0x77, 0x1d, 0xd, 0x83, 0x68, 0x4, 0x57, 0x29")
MAKE_THUNK(libvulkan, vkCreateTensorViewARM, "0x5, 0x2c, 0x18, 0xb9, 0xeb, 0x7f, 0xc8, 0x5b, 0xb3, 0xdc, 0x6f, 0x2d, 0x4d, 0x5b, 0xa5, 0x5f, 0xbf, 0xda, 0x1b, 0xd9, 0xe0, 0x81, 0xf4, 0x55, 0x1e, 0x1d, 0xa9, 0x8a, 0xc6, 0xb9, 0x3a, 0xaf")
MAKE_THUNK(libvulkan, vkDestroyTensorViewARM, "0x2b, 0x9f, 0x67, 0xf6, 0x15, 0xb0, 0x1b, 0x3a, 0xf4, 0x23, 0x50, 0x51, 0x4c, 0x55, 0x40, 0x75, 0x18, 0xfa, 0x80, 0x15, 0x53, 0xe, 0x5d, 0x99, 0xb4, 0xf2, 0x4b, 0x1c, 0x17, 0x7f, 0x23, 0x78")
MAKE_THUNK(libvulkan, vkGetTensorMemoryRequirementsARM, "0x6, 0xe1, 0xa0, 0x39, 0xb8, 0x53, 0x1c, 0xc9, 0xe0, 0x9f, 0xf6, 0x7d, 0x18, 0xf5, 0xcf, 0x18, 0x4f, 0x97, 0x3c, 0x2, 0xc9, 0xa5, 0xc2, 0xb8, 0xd, 0x36, 0xd3, 0xe, 0x6e, 0x65, 0x82, 0xe")
MAKE_THUNK(libvulkan, vkBindTensorMemoryARM, "0x55, 0x9, 0x40, 0xd5, 0x1a, 0x3f, 0xe0, 0x23, 0xb4, 0x89, 0xdb, 0xb7, 0xc2, 0xf8, 0xca, 0x5b, 0x86, 0x7e, 0xd4, 0xa0, 0x1e, 0x30, 0xe7, 0xe, 0xbb, 0x46, 0x10, 0x51, 0x15, 0xb, 0x40, 0x4e")
MAKE_THUNK(libvulkan, vkGetDeviceTensorMemoryRequirementsARM, "0x41, 0xeb, 0xf5, 0x21, 0x6, 0x59, 0xd, 0x89, 0x37, 0x7e, 0x40, 0xed, 0xec, 0xb6, 0xf, 0x7b, 0x2, 0x18, 0x6f, 0x5f, 0x18, 0x3c, 0xc5, 0x5b, 0xd4, 0xb3, 0x90, 0x17, 0x36, 0x33, 0x8d, 0x9d")
MAKE_THUNK(libvulkan, vkCmdCopyTensorARM, "0x5d, 0x7, 0xf8, 0xdb, 0x43, 0xd4, 0x83, 0xf0, 0xd4, 0x14, 0xd7, 0x9c, 0x12, 0x20, 0xd5, 0x26, 0x8d, 0x8e, 0xa, 0x9e, 0x31, 0xb, 0x8e, 0xed, 0x7d, 0x85, 0xb8, 0xa5, 0xf1, 0xff, 0xc9, 0xfd")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceExternalTensorPropertiesARM, "0x5e, 0x35, 0x34, 0x5d, 0x18, 0x64, 0xd5, 0x5e, 0x4, 0x3, 0x4b, 0xa0, 0xb1, 0x96, 0x41, 0x11, 0x34, 0x77, 0xdc, 0x30, 0x58, 0x28, 0xac, 0xd, 0x1a, 0x49, 0x47, 0xd4, 0xcc, 0x30, 0xc1, 0xb9")
MAKE_THUNK(libvulkan, vkGetTensorOpaqueCaptureDescriptorDataARM, "0xc5, 0x16, 0xbd, 0x77, 0x7a, 0x9f, 0xe4, 0x8f, 0x5b, 0x6a, 0xcc, 0x18, 0x2f, 0x8a, 0x48, 0xb7, 0x99, 0xda, 0x8e, 0x96, 0x64, 0x6, 0xbe, 0xbe, 0xec, 0x94, 0xd7, 0xd5, 0xb8, 0x3f, 0xc9, 0x43")
MAKE_THUNK(libvulkan, vkGetTensorViewOpaqueCaptureDescriptorDataARM, "0xaa, 0x95, 0x69, 0x62, 0xbc, 0x48, 0x4b, 0xc9, 0x71, 0x71, 0xc2, 0x2b, 0xcd, 0x3f, 0x1e, 0x91, 0x9c, 0x9f, 0x50, 0x68, 0xcd, 0x4e, 0xd0, 0x0, 0x76, 0xe5, 0x2b, 0xc3, 0x6b, 0x60, 0x28, 0x31")
MAKE_THUNK(libvulkan, vkGetShaderModuleIdentifierEXT, "0x76, 0x9d, 0x6, 0xa1, 0x16, 0xfa, 0x77, 0x80, 0x4b, 0xd1, 0x9, 0x18, 0x28, 0x23, 0xf5, 0xec, 0xe0, 0x14, 0x5a, 0x6d, 0x1f, 0x74, 0x70, 0x6a, 0xfb, 0x9f, 0xfe, 0x1a, 0x4d, 0x2, 0x75, 0x17")
MAKE_THUNK(libvulkan, vkGetShaderModuleCreateInfoIdentifierEXT, "0x6, 0x1d, 0xb5, 0x41, 0x11, 0x33, 0x72, 0x49, 0x9e, 0x67, 0xf9, 0xcb, 0x8f, 0xd7, 0x8d, 0xb0, 0x3b, 0x93, 0xe6, 0x76, 0x2, 0x14, 0x3b, 0x2b, 0xd7, 0x95, 0x5a, 0x92, 0x7a, 0xe9, 0x8b, 0xec")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceOpticalFlowImageFormatsNV, "0xb, 0xc7, 0x8a, 0x2d, 0xc3, 0x55, 0xa1, 0x7, 0x39, 0x31, 0x12, 0x44, 0x9c, 0x3f, 0xd0, 0x75, 0x9a, 0x16, 0xf9, 0x0, 0xa3, 0x66, 0x36, 0x46, 0x3e, 0x45, 0xae, 0x40, 0x64, 0x8c, 0xe6, 0xd4")
MAKE_THUNK(libvulkan, vkCreateOpticalFlowSessionNV, "0x49, 0xf5, 0xcf, 0x67, 0x35, 0xbb, 0xee, 0x83, 0xa4, 0xb9, 0xfe, 0x88, 0x61, 0xbb, 0x56, 0xf5, 0xcf, 0x1f, 0x95, 0x3e, 0xf1, 0xf8, 0xc4, 0x18, 0xaf, 0x96, 0xe8, 0x9e, 0x3c, 0x66, 0x5c, 0xc6")
MAKE_THUNK(libvulkan, vkDestroyOpticalFlowSessionNV, "0xb2, 0xec, 0x47, 0xcb, 0x12, 0x64, 0x80, 0x3c, 0x39, 0xa3, 0xc3, 0xd0, 0xb5, 0x0, 0x91, 0xcb, 0x17, 0xe2, 0x4, 0x7d, 0x3f, 0xd6, 0xcc, 0x73, 0xd7, 0xea, 0xeb, 0xdc, 0x5f, 0xe5, 0x20, 0xfe")
MAKE_THUNK(libvulkan, vkBindOpticalFlowSessionImageNV, "0xf1, 0x5e, 0x90, 0xea, 0x17, 0x6e, 0x3a, 0x33, 0xba, 0x3c, 0x99, 0x86, 0x72, 0xf8, 0x4f, 0x5f, 0x8, 0x6b, 0x12, 0x75, 0x1e, 0xb5, 0xf3, 0xd5, 0x26, 0x11, 0x8e, 0x28, 0xd2, 0x8b, 0x67, 0x18")
MAKE_THUNK(libvulkan, vkCmdOpticalFlowExecuteNV, "0xd7, 0x78, 0x79, 0x8, 0x28, 0x50, 0xaa, 0x4e, 0x4a, 0x3e, 0xdc, 0x87, 0xad, 0x3c, 0x9a, 0x61, 0x1b, 0x79, 0x40, 0x14, 0x66, 0x85, 0x1c, 0x94, 0xb0, 0x4b, 0x81, 0x59, 0xc2, 0x2b, 0x2a, 0x92")
MAKE_THUNK(libvulkan, vkAntiLagUpdateAMD, "0x26, 0x24, 0xab, 0x8c, 0xe, 0x88, 0xae, 0x71, 0x59, 0xda, 0xa8, 0xc0, 0x52, 0xf0, 0x4b, 0x9, 0x9a, 0xa9, 0xf1, 0xd1, 0x58, 0x6c, 0xf8, 0xfe, 0x2d, 0x51, 0x1a, 0x47, 0xf9, 0xc8, 0x91, 0xe5")
MAKE_THUNK(libvulkan, vkCreateShadersEXT, "0xaf, 0x4e, 0xc4, 0xbf, 0x45, 0x8a, 0xc2, 0x2f, 0x51, 0x0, 0xb6, 0x6c, 0xf1, 0x9c, 0xd7, 0xf8, 0xd9, 0x6e, 0x31, 0xb7, 0x5c, 0xbe, 0x13, 0x26, 0x5f, 0x4, 0x1, 0x52, 0x8, 0x8e, 0x93, 0x91")
MAKE_THUNK(libvulkan, vkDestroyShaderEXT, "0xc8, 0x94, 0xdb, 0xde, 0x2b, 0xc6, 0xcc, 0x75, 0xeb, 0xb5, 0x5d, 0x6e, 0x83, 0x2c, 0x3d, 0xc8, 0x23, 0xc1, 0x76, 0x92, 0xb0, 0xec, 0x70, 0x7b, 0x2f, 0xb8, 0xc3, 0x2d, 0x64, 0x42, 0x6e, 0x4f")
MAKE_THUNK(libvulkan, vkGetShaderBinaryDataEXT, "0xc, 0xbe, 0x80, 0x8f, 0x24, 0x69, 0x5c, 0x43, 0x8d, 0x51, 0x63, 0x47, 0xd2, 0x3f, 0x52, 0xd4, 0x52, 0x69, 0x26, 0xbb, 0xb5, 0x3e, 0x75, 0x6a, 0x41, 0x53, 0xae, 0xa5, 0x73, 0x9d, 0x8b, 0xe0")
MAKE_THUNK(libvulkan, vkCmdBindShadersEXT, "0x65, 0x15, 0xbf, 0xd, 0xec, 0x35, 0x3c, 0x97, 0x6b, 0xb0, 0xe4, 0xcb, 0xf4, 0xcc, 0x94, 0xe5, 0x3c, 0xa0, 0x29, 0xae, 0x53, 0xd8, 0x80, 0x5a, 0x80, 0xb0, 0x2a, 0xc3, 0xee, 0xdb, 0xa4, 0x45")
MAKE_THUNK(libvulkan, vkCmdSetDepthClampRangeEXT, "0x58, 0xbf, 0x18, 0x64, 0x39, 0xf2, 0x1c, 0xab, 0x22, 0xa, 0x85, 0xc2, 0xec, 0x33, 0xdf, 0x49, 0x89, 0x1a, 0x8f, 0x57, 0xbd, 0xc7, 0x2e, 0x90, 0x8f, 0xeb, 0x2e, 0x73, 0x72, 0x42, 0x14, 0x26")
MAKE_THUNK(libvulkan, vkGetFramebufferTilePropertiesQCOM, "0x23, 0x7a, 0x67, 0xb4, 0x66, 0xc0, 0x8b, 0x62, 0xd9, 0x69, 0xfe, 0xfc, 0x9b, 0x33, 0xda, 0x3e, 0x9a, 0x34, 0x2a, 0x79, 0xdb, 0x87, 0xb5, 0x9d, 0x1c, 0x37, 0x9f, 0xab, 0xee, 0xfb, 0xf4, 0x66")
MAKE_THUNK(libvulkan, vkGetDynamicRenderingTilePropertiesQCOM, "0x55, 0xc7, 0x4b, 0xbc, 0x62, 0xe1, 0xba, 0x58, 0x70, 0xad, 0x81, 0x74, 0xe2, 0xeb, 0x60, 0x76, 0x57, 0x2c, 0x1a, 0xda, 0x77, 0xa4, 0x19, 0xf8, 0xda, 0x82, 0xee, 0xd2, 0xbb, 0x16, 0xef, 0xfb")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceCooperativeVectorPropertiesNV, "0x6d, 0xdc, 0xfc, 0x41, 0x14, 0x34, 0xe2, 0xaa, 0x7a, 0xc7, 0x3b, 0xed, 0x53, 0xa0, 0xdd, 0xe2, 0x48, 0xd0, 0x1f, 0xc4, 0xfd, 0xf0, 0xe1, 0xc, 0xb0, 0x50, 0xb4, 0x91, 0xbe, 0x76, 0xbf, 0x3b")
MAKE_THUNK(libvulkan, vkConvertCooperativeVectorMatrixNV, "0x86, 0x73, 0x49, 0xcc, 0x36, 0x98, 0x76, 0xdd, 0x7, 0x75, 0x1b, 0xcd, 0xe0, 0x87, 0xb2, 0x7, 0xd9, 0xb6, 0x3c, 0x18, 0x3e, 0x8f, 0x20, 0xa3, 0xd0, 0x4f, 0xe9, 0x9e, 0x1d, 0x42, 0xd3, 0xcf")
MAKE_THUNK(libvulkan, vkCmdConvertCooperativeVectorMatrixNV, "0x11, 0x32, 0xa7, 0x75, 0x1b, 0x41, 0xba, 0xa4, 0xf5, 0xd3, 0x41, 0x3e, 0xdf, 0x88, 0xf2, 0x3a, 0xeb, 0x9d, 0x74, 0x84, 0xc8, 0x34, 0xe2, 0x9e, 0xe3, 0x5a, 0x7c, 0xe5, 0x3c, 0xfa, 0x33, 0x94")
MAKE_THUNK(libvulkan, vkSetLatencySleepModeNV, "0xd6, 0xc6, 0x7a, 0x2d, 0xa7, 0x7a, 0x43, 0x2a, 0x41, 0xb0, 0x1b, 0x79, 0xf3, 0xa8, 0x1, 0xf0, 0x35, 0x20, 0x7f, 0xe, 0x3a, 0x4e, 0x88, 0x83, 0x3c, 0xbb, 0xca, 0x64, 0xa4, 0x18, 0xfc, 0x8")
MAKE_THUNK(libvulkan, vkLatencySleepNV, "0x37, 0xce, 0x86, 0x68, 0x36, 0xaf, 0x48, 0x16, 0x7f, 0x77, 0x95, 0xfa, 0xf9, 0x41, 0x12, 0xd3, 0xfc, 0xb1, 0xb8, 0xab, 0xba, 0xd4, 0x19, 0x65, 0xc1, 0x2e, 0xcb, 0xd6, 0x44, 0xc1, 0x54, 0x27")
MAKE_THUNK(libvulkan, vkSetLatencyMarkerNV, "0x2d, 0xe1, 0x73, 0xf8, 0xd0, 0xbc, 0xdc, 0x88, 0x85, 0x60, 0x16, 0x54, 0x27, 0xc4, 0x6f, 0x75, 0x9, 0xa8, 0x4c, 0x2c, 0x4d, 0xc9, 0x7d, 0xd, 0x19, 0x91, 0x83, 0xd6, 0xb0, 0x41, 0x2b, 0x4e")
MAKE_THUNK(libvulkan, vkGetLatencyTimingsNV, "0x6f, 0xa1, 0x83, 0x63, 0x54, 0x4b, 0x31, 0x99, 0x29, 0x4a, 0xb4, 0x2f, 0xa9, 0x87, 0xee, 0xb9, 0x89, 0xad, 0x5b, 0x39, 0x9, 0x86, 0x78, 0x4a, 0xc2, 0xbc, 0xd2, 0x2c, 0xb6, 0xb, 0xe5, 0x82")
MAKE_THUNK(libvulkan, vkQueueNotifyOutOfBandNV, "0x1, 0x6b, 0x3c, 0x45, 0x1b, 0x74, 0xe8, 0xef, 0x39, 0xe, 0x80, 0x59, 0x83, 0xf6, 0xf9, 0x6c, 0x29, 0x8c, 0xd2, 0x78, 0x70, 0x86, 0x1d, 0x13, 0x18, 0x92, 0x8f, 0xce, 0x98, 0xf, 0x43, 0x9e")
MAKE_THUNK(libvulkan, vkCreateDataGraphPipelinesARM, "0xa3, 0x40, 0xe7, 0x83, 0x67, 0xa3, 0xd0, 0xaa, 0xa7, 0xe5, 0xca, 0x28, 0xcb, 0x11, 0x49, 0x7d, 0x33, 0x95, 0xef, 0xe5, 0xa2, 0xf5, 0xde, 0x3, 0xaa, 0x29, 0xa5, 0x37, 0xf6, 0xe2, 0xf6, 0x23")
MAKE_THUNK(libvulkan, vkCreateDataGraphPipelineSessionARM, "0x12, 0x24, 0xd9, 0xcf, 0x13, 0xc0, 0xa8, 0x10, 0x5a, 0xd8, 0xe2, 0x74, 0x88, 0x5f, 0x67, 0xf1, 0x3, 0x6, 0xf3, 0x68, 0x43, 0x32, 0x9a, 0x90, 0x89, 0x1d, 0x68, 0xe0, 0xe, 0x58, 0x2a, 0xfa")
MAKE_THUNK(libvulkan, vkGetDataGraphPipelineSessionBindPointRequirementsARM, "0xe4, 0xb2, 0x16, 0xd8, 0xcb, 0x55, 0x3a, 0xeb, 0xb7, 0x7f, 0xf4, 0xbe, 0x6c, 0xd2, 0xc7, 0xcb, 0x69, 0xbc, 0x9e, 0x6b, 0x28, 0xe0, 0xd3, 0xad, 0x35, 0xe3, 0xe1, 0xc0, 0xa6, 0x6b, 0x37, 0xd2")
MAKE_THUNK(libvulkan, vkGetDataGraphPipelineSessionMemoryRequirementsARM, "0xa5, 0x41, 0xf0, 0xf7, 0x35, 0x4e, 0x68, 0xf0, 0x36, 0xfa, 0xa6, 0xba, 0x36, 0x81, 0x6f, 0xf3, 0xb1, 0xc0, 0xae, 0x6b, 0xb7, 0x35, 0x3f, 0xe3, 0x44, 0x76, 0x0, 0xb3, 0xb5, 0x46, 0x6e, 0x5e")
MAKE_THUNK(libvulkan, vkBindDataGraphPipelineSessionMemoryARM, "0x85, 0x94, 0xa8, 0xee, 0x5d, 0x92, 0xcd, 0x8, 0x41, 0x88, 0x3c, 0x56, 0xf, 0x46, 0x71, 0xac, 0x10, 0xc5, 0xfa, 0x60, 0xb1, 0x8c, 0xc3, 0x24, 0x82, 0x22, 0xe4, 0x6e, 0xf1, 0x5b, 0x64, 0x28")
MAKE_THUNK(libvulkan, vkDestroyDataGraphPipelineSessionARM, "0x68, 0x62, 0x59, 0xc5, 0xf2, 0xe7, 0x30, 0xa3, 0x8d, 0x88, 0x66, 0x88, 0x8f, 0xdb, 0x0, 0x0, 0xab, 0xec, 0x5b, 0xa9, 0x3e, 0x88, 0x5a, 0xb4, 0xd4, 0xaa, 0x38, 0xcb, 0xa2, 0x65, 0x8e, 0x69")
MAKE_THUNK(libvulkan, vkCmdDispatchDataGraphARM, "0xc5, 0xa, 0xd7, 0xfa, 0x24, 0x17, 0xb4, 0xce, 0xa0, 0x6f, 0x77, 0x9c, 0xf6, 0xcf, 0xb3, 0x27, 0xe1, 0x8f, 0x90, 0x6e, 0x9a, 0x51, 0xc1, 0x28, 0x76, 0x7f, 0x59, 0xce, 0x35, 0xc6, 0x82, 0x13")
MAKE_THUNK(libvulkan, vkGetDataGraphPipelineAvailablePropertiesARM, "0x63, 0x4f, 0x58, 0xd, 0xe, 0x22, 0x8f, 0xb9, 0x8b, 0x96, 0xf3, 0x61, 0xd2, 0xda, 0x3, 0x11, 0xe2, 0x2c, 0x48, 0x4a, 0x68, 0x92, 0x57, 0xab, 0x3, 0x7, 0x16, 0xc1, 0x6d, 0x4c, 0xd1, 0x83")
MAKE_THUNK(libvulkan, vkGetDataGraphPipelinePropertiesARM, "0x67, 0x4e, 0x45, 0x21, 0x55, 0xe9, 0x4b, 0x78, 0x82, 0x29, 0x60, 0x51, 0x7a, 0x4f, 0xb9, 0xce, 0x63, 0x8e, 0x77, 0x9a, 0xc1, 0x5a, 0x43, 0x56, 0x9c, 0xe2, 0x26, 0xf1, 0xbf, 0xee, 0x22, 0x14")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceQueueFamilyDataGraphPropertiesARM, "0xd6, 0x3c, 0x8a, 0x8d, 0xc6, 0x63, 0x8b, 0x4e, 0xf3, 0x63, 0x6b, 0x54, 0x9c, 0xfe, 0x9b, 0x45, 0xb5, 0x24, 0xe6, 0x98, 0x5a, 0xe4, 0xef, 0x34, 0x76, 0x16, 0xf1, 0x88, 0x13, 0x88, 0x38, 0x14")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceQueueFamilyDataGraphProcessingEnginePropertiesARM, "0x45, 0x38, 0xca, 0x20, 0x3b, 0x8, 0x7d, 0x7a, 0xba, 0x2e, 0xc9, 0xe, 0x35, 0x4c, 0x5d, 0x2f, 0xd6, 0xb1, 0x8c, 0x2c, 0xae, 0xbd, 0x95, 0xf1, 0xea, 0xbf, 0x82, 0xdb, 0x77, 0x15, 0x17, 0xc8")
MAKE_THUNK(libvulkan, vkCmdSetAttachmentFeedbackLoopEnableEXT, "0x72, 0xed, 0x41, 0xfd, 0x34, 0x35, 0x9d, 0x88, 0xe4, 0xf9, 0xca, 0x8e, 0x2b, 0x55, 0x10, 0x4d, 0xb8, 0x76, 0x41, 0xbd, 0x6f, 0x18, 0x4f, 0xc6, 0x23, 0x15, 0xdf, 0x77, 0x92, 0x13, 0x69, 0x43")
MAKE_THUNK(libvulkan, vkCmdBindTileMemoryQCOM, "0x6a, 0x69, 0x86, 0xdf, 0xf1, 0xab, 0x1a, 0x8, 0xd4, 0x27, 0xba, 0x3c, 0x25, 0xa3, 0xa9, 0x32, 0xc3, 0xa8, 0x3b, 0xb0, 0x34, 0x1f, 0x44, 0x52, 0xbe, 0x5b, 0x30, 0x42, 0xc5, 0x9b, 0xe, 0x84")
MAKE_THUNK(libvulkan, vkCmdDecompressMemoryEXT, "0x56, 0xd5, 0x8c, 0xd5, 0xf8, 0xb5, 0x8f, 0x90, 0xf7, 0x61, 0xa9, 0xff, 0x91, 0xc8, 0x24, 0x74, 0xd7, 0x67, 0xe1, 0xec, 0x69, 0x2e, 0x99, 0x89, 0x1c, 0x8a, 0x7, 0x2e, 0x85, 0xa3, 0xdb, 0x6b")
MAKE_THUNK(libvulkan, vkCmdDecompressMemoryIndirectCountEXT, "0xf3, 0x7a, 0x58, 0x33, 0xdc, 0x50, 0x59, 0x8e, 0x2, 0x43, 0x46, 0xf5, 0x38, 0xc2, 0x33, 0x3f, 0xfd, 0xd6, 0xc5, 0xb5, 0x51, 0x95, 0x5f, 0x48, 0xf1, 0x4a, 0x2c, 0x8d, 0x90, 0x86, 0xc5, 0x41")
MAKE_THUNK(libvulkan, vkCreateExternalComputeQueueNV, "0x8a, 0x8e, 0x5, 0x3c, 0x1b, 0x7c, 0xd5, 0xa2, 0x16, 0xc, 0x4b, 0x48, 0x82, 0xf, 0xc9, 0x24, 0xf6, 0x16, 0xc4, 0x3c, 0x77, 0xef, 0x64, 0x63, 0xeb, 0x8, 0xe0, 0x96, 0xcb, 0xc2, 0x8f, 0xff")
MAKE_THUNK(libvulkan, vkDestroyExternalComputeQueueNV, "0xa0, 0xe2, 0x8b, 0x7d, 0x46, 0x62, 0xca, 0x70, 0x94, 0x5a, 0xab, 0xe4, 0x4b, 0x5a, 0x2, 0x10, 0x40, 0x7d, 0xab, 0x67, 0x13, 0xe2, 0x14, 0x83, 0x87, 0xfb, 0xc2, 0x84, 0x1d, 0x56, 0x9a, 0x7a")
MAKE_THUNK(libvulkan, vkGetExternalComputeQueueDataNV, "0xd5, 0xb3, 0x39, 0x93, 0x2c, 0x81, 0x3b, 0xb6, 0x86, 0x7b, 0xf0, 0x4, 0xc8, 0x84, 0xd8, 0x9, 0xdd, 0xa5, 0x8b, 0xcd, 0x23, 0xe4, 0x2e, 0xf6, 0x1a, 0xa4, 0xfb, 0x5a, 0xcf, 0x2, 0xaa, 0x67")
MAKE_THUNK(libvulkan, vkGetClusterAccelerationStructureBuildSizesNV, "0xd3, 0xcb, 0x6, 0x30, 0x13, 0x90, 0x8b, 0x48, 0xbf, 0x3f, 0x21, 0xf9, 0xa5, 0xbc, 0xcb, 0x94, 0x41, 0x4d, 0x4f, 0xed, 0x28, 0xac, 0xca, 0x8, 0x50, 0x72, 0xd3, 0x4b, 0x90, 0x27, 0x78, 0x96")
MAKE_THUNK(libvulkan, vkCmdBuildClusterAccelerationStructureIndirectNV, "0x72, 0x2, 0xbb, 0x12, 0x9e, 0x9e, 0xe9, 0x22, 0xe4, 0xf9, 0xb5, 0x3f, 0xa8, 0x97, 0x60, 0x63, 0x7d, 0xce, 0x57, 0x29, 0x5d, 0x6f, 0x5a, 0xf6, 0x52, 0x2a, 0xea, 0xe2, 0xdd, 0x99, 0x27, 0xa8")
MAKE_THUNK(libvulkan, vkGetPartitionedAccelerationStructuresBuildSizesNV, "0x6b, 0x8f, 0x53, 0x4f, 0x4d, 0xd8, 0xd0, 0xb4, 0xde, 0x15, 0x7b, 0x27, 0xa8, 0xc0, 0x84, 0x92, 0x75, 0xb7, 0xa0, 0x5a, 0x73, 0xfb, 0xc0, 0x5a, 0x1f, 0xda, 0x87, 0xa7, 0xa6, 0xd, 0xd3, 0xa9")
MAKE_THUNK(libvulkan, vkCmdBuildPartitionedAccelerationStructuresNV, "0x7d, 0xd8, 0x9c, 0x58, 0x49, 0x5, 0x86, 0x3d, 0x98, 0xc2, 0x53, 0xaa, 0x2c, 0xb8, 0xa9, 0x27, 0x87, 0x38, 0x14, 0x6, 0x76, 0x3a, 0xfd, 0x67, 0xc4, 0x9c, 0xf3, 0x26, 0x28, 0xd8, 0x25, 0xa7")
MAKE_THUNK(libvulkan, vkGetGeneratedCommandsMemoryRequirementsEXT, "0xd, 0x31, 0x51, 0x83, 0xc7, 0xd9, 0xcf, 0x85, 0x5a, 0x77, 0x44, 0x71, 0x3a, 0xb0, 0x73, 0xf0, 0xc4, 0x96, 0xcd, 0x96, 0xc9, 0xb3, 0xfc, 0xa7, 0x15, 0x33, 0xab, 0x24, 0xac, 0xe5, 0xe3, 0x1d")
MAKE_THUNK(libvulkan, vkCmdPreprocessGeneratedCommandsEXT, "0x45, 0x61, 0x33, 0x2f, 0x4f, 0x97, 0xb5, 0xd9, 0x9b, 0xab, 0x5b, 0x46, 0x2c, 0xdf, 0x61, 0x80, 0x91, 0xa2, 0xba, 0x46, 0xf2, 0xd2, 0xbd, 0x3d, 0xb, 0x33, 0x83, 0x9, 0x34, 0x9a, 0x87, 0xde")
MAKE_THUNK(libvulkan, vkCmdExecuteGeneratedCommandsEXT, "0x94, 0xe2, 0x6c, 0x93, 0x8e, 0x3b, 0xbd, 0xef, 0xc5, 0x65, 0x14, 0x20, 0x51, 0x84, 0x6f, 0x35, 0x9e, 0xf, 0xb3, 0x79, 0x48, 0x9d, 0xc8, 0xd4, 0xbd, 0xb4, 0x58, 0x71, 0x3b, 0x49, 0x4e, 0x54")
MAKE_THUNK(libvulkan, vkCreateIndirectCommandsLayoutEXT, "0xf3, 0x23, 0xcd, 0x93, 0x8b, 0xe4, 0x35, 0x9e, 0xac, 0x96, 0x1f, 0xbb, 0xa5, 0xa3, 0xd4, 0x9d, 0x3, 0xd7, 0x48, 0xa, 0x87, 0xef, 0xdb, 0xee, 0x6c, 0x5b, 0x5, 0x57, 0xa, 0x6b, 0x1c, 0x58")
MAKE_THUNK(libvulkan, vkDestroyIndirectCommandsLayoutEXT, "0x72, 0x99, 0x17, 0x33, 0x62, 0xf3, 0x61, 0xc5, 0x56, 0xe9, 0xde, 0x81, 0xfb, 0xf0, 0x8a, 0x22, 0x70, 0x97, 0x38, 0xa8, 0x19, 0x5f, 0xfb, 0xd1, 0xcc, 0x6f, 0xe8, 0xc3, 0xc6, 0x2e, 0xaa, 0xa3")
MAKE_THUNK(libvulkan, vkCreateIndirectExecutionSetEXT, "0x69, 0x72, 0x1d, 0x52, 0x48, 0x87, 0xc8, 0xff, 0xe1, 0xe7, 0xa7, 0x94, 0x9c, 0x50, 0xf7, 0x6, 0x91, 0x85, 0xdc, 0xa0, 0x8a, 0xab, 0x83, 0x8e, 0x5a, 0xa, 0x46, 0x5e, 0x42, 0x48, 0x7f, 0x36")
MAKE_THUNK(libvulkan, vkDestroyIndirectExecutionSetEXT, "0x60, 0xa3, 0xa7, 0x95, 0x8b, 0xb0, 0x2f, 0x73, 0xcd, 0x1e, 0xf, 0xb4, 0xc, 0xa1, 0xc2, 0x3a, 0x19, 0x3b, 0x43, 0x2, 0x81, 0x74, 0x78, 0xa7, 0x4b, 0x46, 0x9e, 0x42, 0x91, 0xdd, 0x45, 0x87")
MAKE_THUNK(libvulkan, vkUpdateIndirectExecutionSetPipelineEXT, "0x3d, 0xf3, 0x5c, 0xd7, 0xd0, 0x77, 0x32, 0xfb, 0x9a, 0x93, 0x65, 0xe4, 0x4b, 0x72, 0xbf, 0x53, 0xb7, 0xc9, 0x74, 0xdb, 0x3d, 0x90, 0x32, 0x78, 0x2d, 0x2, 0x51, 0xdc, 0x5f, 0x56, 0x0, 0x49")
MAKE_THUNK(libvulkan, vkUpdateIndirectExecutionSetShaderEXT, "0xda, 0xc6, 0x21, 0x99, 0xa0, 0xe1, 0xc0, 0x42, 0x7, 0x1f, 0x9c, 0x13, 0x59, 0xc2, 0x67, 0x5e, 0xaf, 0x37, 0x12, 0x6, 0x72, 0xa, 0x5a, 0x5f, 0x2c, 0x20, 0x51, 0x6, 0xb8, 0x2b, 0x6d, 0x32")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceCooperativeMatrixFlexibleDimensionsPropertiesNV, "0x9a, 0xf0, 0xa9, 0x95, 0x95, 0x7f, 0x63, 0xf2, 0x65, 0xd8, 0x9f, 0x63, 0x23, 0x30, 0xe2, 0xec, 0x7, 0xae, 0xe6, 0xc6, 0x55, 0x34, 0xdf, 0xc6, 0x5a, 0x32, 0xcf, 0x82, 0x5, 0x5a, 0xbb, 0x9f")
MAKE_THUNK(libvulkan, vkEnumeratePhysicalDeviceQueueFamilyPerformanceCountersByRegionARM, "0xd3, 0x8, 0x40, 0x7a, 0x6e, 0x6b, 0x1d, 0xd1, 0x86, 0xf5, 0x15, 0x8d, 0x61, 0xda, 0xb2, 0xda, 0x14, 0x71, 0x9b, 0xa1, 0xf4, 0x74, 0xa2, 0x47, 0xd, 0xc9, 0xa6, 0xa8, 0x67, 0x61, 0xe1, 0x99")
MAKE_THUNK(libvulkan, vkCmdEndRendering2EXT, "0x9c, 0xf1, 0xa7, 0x46, 0xbd, 0x44, 0x56, 0x69, 0xdd, 0x44, 0x65, 0x68, 0x92, 0x4c, 0xb3, 0xa9, 0xa9, 0x9, 0xbb, 0xe6, 0x14, 0xb4, 0x5d, 0x6a, 0xa0, 0x45, 0xa1, 0x73, 0xb5, 0x96, 0x5, 0xfa")
MAKE_THUNK(libvulkan, vkCmdBeginCustomResolveEXT, "0x41, 0x3e, 0x59, 0x3, 0x63, 0x9a, 0x45, 0x7d, 0xcd, 0x7a, 0x9c, 0xf4, 0xfd, 0x16, 0x96, 0xd, 0x90, 0x1b, 0x12, 0xb1, 0x34, 0x55, 0x79, 0x7c, 0xcf, 0x46, 0xca, 0xe0, 0x37, 0x17, 0xf7, 0x8a")
MAKE_THUNK(libvulkan, vkCmdSetComputeOccupancyPriorityNV, "0xf, 0xa4, 0xb, 0x40, 0x7c, 0xff, 0x85, 0xd2, 0x3e, 0x76, 0x3d, 0xfd, 0x92, 0x3f, 0x92, 0x3e, 0x6d, 0x92, 0x9c, 0x47, 0xe3, 0x63, 0x52, 0xb3, 0xfa, 0x6c, 0x8b, 0x8e, 0x76, 0x1, 0xc6, 0x3")
MAKE_THUNK(libvulkan, vkCreateAccelerationStructureKHR, "0x78, 0x4f, 0xdd, 0x91, 0x63, 0x9b, 0x64, 0x79, 0x14, 0x55, 0x77, 0xa3, 0xa, 0x17, 0x70, 0x27, 0xd1, 0xb1, 0xb0, 0x3a, 0x18, 0x43, 0xf0, 0x3, 0x2f, 0x16, 0x2b, 0xe3, 0xf7, 0xa2, 0xd3, 0x3e")
MAKE_THUNK(libvulkan, vkDestroyAccelerationStructureKHR, "0xa7, 0x1d, 0x28, 0x44, 0xec, 0x47, 0x42, 0x63, 0x76, 0x46, 0x7c, 0xa3, 0x6b, 0x47, 0x5a, 0x8, 0xac, 0xe2, 0x82, 0xd7, 0xa7, 0xef, 0x1d, 0x61, 0xed, 0xc3, 0xc3, 0xda, 0x77, 0x19, 0x45, 0x2")
MAKE_THUNK(libvulkan, vkCmdBuildAccelerationStructuresKHR, "0xc, 0xd8, 0xf5, 0xbb, 0xb0, 0xdd, 0x34, 0xf1, 0xd5, 0xc2, 0x5a, 0x34, 0x2b, 0xae, 0xd0, 0x5e, 0x35, 0x64, 0xe3, 0x64, 0x8f, 0x2a, 0x58, 0x9e, 0x18, 0xf0, 0xd8, 0xe6, 0xfa, 0x79, 0x7b, 0x47")
MAKE_THUNK(libvulkan, vkCmdBuildAccelerationStructuresIndirectKHR, "0x7b, 0xd6, 0xb3, 0xbf, 0x90, 0xab, 0xc9, 0x69, 0x42, 0x7f, 0x45, 0x61, 0xfc, 0x68, 0xd8, 0x2a, 0x5c, 0xd4, 0xd5, 0xc2, 0x2e, 0xa7, 0xe4, 0xc5, 0xaf, 0x4a, 0xf0, 0x6a, 0x9c, 0xfa, 0x8b, 0xbc")
MAKE_THUNK(libvulkan, vkBuildAccelerationStructuresKHR, "0xa7, 0x63, 0x1f, 0x9a, 0xa3, 0xbd, 0x88, 0x20, 0x58, 0x2a, 0xbe, 0x91, 0xae, 0xf4, 0x3, 0x22, 0x7c, 0xde, 0x76, 0x6f, 0xa, 0xca, 0xe9, 0xe1, 0x8a, 0x6e, 0xeb, 0x33, 0xd1, 0xa0, 0x76, 0x9f")
MAKE_THUNK(libvulkan, vkCopyAccelerationStructureKHR, "0x82, 0x57, 0xc5, 0x22, 0x1b, 0x7, 0x6b, 0x48, 0x6b, 0xcb, 0xaa, 0x79, 0xbd, 0x8d, 0x68, 0xcd, 0x7a, 0x3, 0x94, 0xfe, 0xef, 0x27, 0xa5, 0x48, 0xcc, 0x26, 0x28, 0x7a, 0x67, 0xb6, 0x44, 0xd8")
MAKE_THUNK(libvulkan, vkCopyAccelerationStructureToMemoryKHR, "0xc, 0x90, 0x68, 0xfe, 0xa4, 0x36, 0x37, 0x5f, 0x7a, 0x67, 0xea, 0xf6, 0xde, 0xb6, 0x3e, 0x8d, 0x36, 0xb, 0xa2, 0xf2, 0x54, 0x7a, 0x71, 0x4b, 0x3, 0x35, 0x3f, 0x39, 0x9a, 0xc1, 0xfc, 0x12")
MAKE_THUNK(libvulkan, vkCopyMemoryToAccelerationStructureKHR, "0xdc, 0xc4, 0x5a, 0x12, 0x33, 0xb0, 0xbb, 0x49, 0x66, 0xec, 0xca, 0x78, 0x83, 0x5b, 0xb, 0xb3, 0x84, 0x53, 0xb7, 0x7c, 0xf9, 0x63, 0x99, 0x1d, 0xa1, 0xb1, 0xf1, 0x13, 0xa4, 0x6c, 0xf4, 0x94")
MAKE_THUNK(libvulkan, vkWriteAccelerationStructuresPropertiesKHR, "0x4e, 0x8, 0x52, 0x1a, 0xec, 0x34, 0x4c, 0xcd, 0xa3, 0x63, 0xa4, 0x79, 0x6d, 0xc9, 0xc4, 0xea, 0xbf, 0x37, 0xb0, 0x1d, 0xf, 0x56, 0x9e, 0xae, 0xb7, 0xd8, 0xd5, 0xcb, 0x1b, 0xfc, 0x30, 0x40")
MAKE_THUNK(libvulkan, vkCmdCopyAccelerationStructureKHR, "0x2f, 0x81, 0x33, 0x42, 0x2e, 0x68, 0x6f, 0x7e, 0x83, 0xf3, 0x59, 0x5e, 0x7, 0xbb, 0xa3, 0x4f, 0xab, 0x19, 0x4b, 0x64, 0x33, 0xbb, 0xde, 0xa, 0x63, 0x14, 0x5d, 0x4e, 0x7, 0x3d, 0x2, 0x99")
MAKE_THUNK(libvulkan, vkCmdCopyAccelerationStructureToMemoryKHR, "0xa4, 0xe1, 0x23, 0xad, 0x43, 0x4d, 0x7d, 0xa5, 0xa, 0x6f, 0x9f, 0x39, 0xb3, 0xd, 0x4f, 0xf1, 0x52, 0x5f, 0x90, 0x30, 0x75, 0xe7, 0xad, 0xa4, 0x35, 0x46, 0x2d, 0x84, 0xa9, 0x78, 0xce, 0x7c")
MAKE_THUNK(libvulkan, vkCmdCopyMemoryToAccelerationStructureKHR, "0x2d, 0xe8, 0xe, 0xf1, 0x7, 0xc4, 0x74, 0x81, 0xf9, 0x1a, 0x11, 0x20, 0xec, 0x28, 0xe2, 0x3a, 0x41, 0xb3, 0xf3, 0xc9, 0x4b, 0xc0, 0x79, 0x38, 0xf1, 0xc4, 0xdb, 0xef, 0x1, 0xd6, 0x57, 0xdd")
MAKE_THUNK(libvulkan, vkGetAccelerationStructureDeviceAddressKHR, "0xa8, 0x57, 0x2, 0xa4, 0x9a, 0x92, 0x67, 0x96, 0x68, 0x2e, 0x7d, 0x2, 0x2f, 0x91, 0x29, 0x8a, 0xd4, 0x2b, 0x90, 0xc6, 0x52, 0x13, 0x46, 0xb4, 0xf6, 0x5c, 0x52, 0x19, 0xda, 0x30, 0x82, 0x23")
MAKE_THUNK(libvulkan, vkCmdWriteAccelerationStructuresPropertiesKHR, "0xda, 0x92, 0x7d, 0x8d, 0xab, 0x4f, 0xfd, 0xa0, 0xed, 0xc0, 0x2a, 0xb6, 0x49, 0xbb, 0xf1, 0xa1, 0xc6, 0xdb, 0x77, 0xa9, 0xf5, 0x6f, 0xe0, 0xf2, 0xc7, 0x6e, 0xed, 0xc4, 0xc4, 0xd, 0xa6, 0x9c")
MAKE_THUNK(libvulkan, vkGetDeviceAccelerationStructureCompatibilityKHR, "0x17, 0x33, 0xbf, 0x90, 0x74, 0x79, 0x3c, 0xa4, 0x82, 0x35, 0xd5, 0x4a, 0x47, 0xae, 0xf8, 0x47, 0xfe, 0xc1, 0xee, 0xdf, 0x73, 0x2d, 0x89, 0x4f, 0x1d, 0xfd, 0xf0, 0x99, 0x84, 0xe, 0xd8, 0x83")
MAKE_THUNK(libvulkan, vkGetAccelerationStructureBuildSizesKHR, "0xc4, 0xdd, 0xa2, 0x90, 0xa, 0x64, 0x7f, 0xd0, 0x70, 0x56, 0xcb, 0x5d, 0xdd, 0x56, 0x85, 0xc1, 0x5c, 0x10, 0x2a, 0x5f, 0x54, 0xae, 0x82, 0x2f, 0xa, 0xe6, 0xc7, 0x42, 0x41, 0x58, 0xf1, 0x32")
MAKE_THUNK(libvulkan, vkCmdTraceRaysKHR, "0xfe, 0x71, 0x89, 0x93, 0x8, 0x5a, 0xbf, 0x66, 0x24, 0x1e, 0xdc, 0x22, 0xe8, 0x9b, 0x77, 0x41, 0x8f, 0x31, 0x3e, 0x4c, 0x4b, 0x17, 0x15, 0x18, 0x86, 0x0, 0x9e, 0x6f, 0xb8, 0xb8, 0x15, 0x72")
MAKE_THUNK(libvulkan, vkCreateRayTracingPipelinesKHR, "0x63, 0x61, 0xe6, 0x7a, 0x58, 0x84, 0x9f, 0x6a, 0x78, 0x39, 0x61, 0x71, 0xc6, 0x7b, 0xef, 0x80, 0x94, 0xa5, 0xe0, 0xea, 0x44, 0x32, 0xb1, 0x76, 0xb1, 0x8e, 0xeb, 0x35, 0x84, 0xae, 0xad, 0x86")
MAKE_THUNK(libvulkan, vkGetRayTracingCaptureReplayShaderGroupHandlesKHR, "0x85, 0x39, 0x63, 0x43, 0xf3, 0x4b, 0x39, 0x93, 0x81, 0x3f, 0x72, 0xa4, 0xe8, 0x8, 0x36, 0xb4, 0x31, 0x54, 0x22, 0x87, 0xbe, 0x7c, 0xce, 0x3e, 0x45, 0xee, 0x54, 0x3c, 0xac, 0x68, 0xf1, 0x37")
MAKE_THUNK(libvulkan, vkCmdTraceRaysIndirectKHR, "0x7f, 0x53, 0xe, 0xbe, 0x6e, 0xd5, 0xeb, 0xb, 0x1a, 0x8d, 0xc, 0x16, 0xfa, 0x85, 0xf1, 0x92, 0x2a, 0xe6, 0x64, 0xb9, 0x7b, 0x86, 0x2a, 0xf4, 0xd2, 0x13, 0x8e, 0x38, 0x8a, 0xf6, 0xa0, 0xd5")
MAKE_THUNK(libvulkan, vkGetRayTracingShaderGroupStackSizeKHR, "0x95, 0x8d, 0x41, 0x24, 0x2e, 0x12, 0x69, 0xd5, 0x95, 0xeb, 0x4f, 0xcb, 0x2d, 0xb8, 0x86, 0x4, 0x5c, 0xf8, 0x11, 0xcc, 0xe8, 0xda, 0xef, 0x2c, 0x46, 0xa3, 0xe0, 0x25, 0x14, 0xad, 0x36, 0x6")
MAKE_THUNK(libvulkan, vkCmdSetRayTracingPipelineStackSizeKHR, "0x26, 0x75, 0xef, 0x9a, 0xee, 0xf1, 0xf1, 0x1a, 0x48, 0x2, 0xa7, 0xa9, 0xea, 0x93, 0x62, 0x13, 0x3d, 0x89, 0xaa, 0x60, 0xad, 0x1d, 0xd, 0xc3, 0xe1, 0xe3, 0x6c, 0x17, 0x24, 0x40, 0xb4, 0x85")
MAKE_THUNK(libvulkan, vkCmdDrawMeshTasksEXT, "0x2c, 0x6a, 0xa5, 0xe8, 0x8c, 0xe3, 0xd7, 0x1c, 0x2d, 0xc4, 0x6a, 0xf2, 0x2c, 0x30, 0x98, 0x50, 0xc8, 0x23, 0xcb, 0x87, 0xd1, 0x11, 0x92, 0x1c, 0x64, 0x9c, 0xb1, 0xce, 0xf, 0x71, 0x8f, 0xaa")
MAKE_THUNK(libvulkan, vkCmdDrawMeshTasksIndirectEXT, "0x31, 0x4f, 0x5e, 0x81, 0x72, 0xfb, 0xca, 0xb1, 0x1, 0xdc, 0xf3, 0xd6, 0x18, 0x81, 0x10, 0xaf, 0x79, 0xf3, 0x49, 0x8d, 0x69, 0x87, 0x6a, 0x84, 0x78, 0x63, 0x3e, 0x87, 0xe, 0x7e, 0xdb, 0x7")
MAKE_THUNK(libvulkan, vkCmdDrawMeshTasksIndirectCountEXT, "0x1, 0x5e, 0xbd, 0xac, 0xe5, 0x66, 0xf9, 0x3d, 0xd6, 0xa3, 0xa8, 0x17, 0x51, 0x6f, 0xca, 0xf3, 0xbd, 0x99, 0x21, 0xb1, 0x43, 0xa, 0xb2, 0xc2, 0x32, 0xa5, 0x53, 0xce, 0xb0, 0xa1, 0xe, 0x83")
MAKE_THUNK(libvulkan, vkAcquireXlibDisplayEXT, "0x5d, 0x1, 0xf5, 0x9, 0x53, 0x47, 0xc1, 0xe9, 0x7c, 0xe7, 0x8d, 0xc0, 0xa2, 0x6, 0xba, 0x8e, 0x17, 0x3a, 0xea, 0x9e, 0x9f, 0x6b, 0x91, 0x7f, 0x79, 0xc5, 0x9, 0x92, 0xdc, 0x78, 0x59, 0xbc")
MAKE_THUNK(libvulkan, vkGetRandROutputDisplayEXT, "0x99, 0x34, 0x2, 0x74, 0x34, 0x49, 0x38, 0x3a, 0xe, 0x33, 0xd6, 0x5e, 0x8f, 0xe5, 0xda, 0xce, 0xd5, 0x42, 0x46, 0x58, 0x64, 0xde, 0x18, 0xe1, 0xa0, 0xe2, 0x3, 0x78, 0x1a, 0x4b, 0x9f, 0x56")
MAKE_THUNK(libvulkan, vkCreateWaylandSurfaceKHR, "0x62, 0xb8, 0x55, 0x52, 0xf4, 0x5b, 0x38, 0x6a, 0xd8, 0x87, 0x1f, 0x9, 0x87, 0xb6, 0xde, 0x98, 0xdc, 0xdd, 0xbf, 0xb5, 0xda, 0xd2, 0x73, 0xc4, 0x69, 0xe3, 0xf7, 0x60, 0x1a, 0x6a, 0xa, 0xa9")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceWaylandPresentationSupportKHR, "0xd9, 0x32, 0x29, 0x8e, 0xf7, 0xf8, 0x97, 0x4a, 0x72, 0x26, 0x63, 0x29, 0x6d, 0x84, 0x9e, 0x87, 0x87, 0x79, 0x26, 0x2e, 0x7b, 0xc4, 0x66, 0x8b, 0xa2, 0x9, 0x64, 0x16, 0xe7, 0x4a, 0xe3, 0x3c")
MAKE_THUNK(libvulkan, vkCreateXcbSurfaceKHR, "0x69, 0xef, 0xee, 0xf0, 0x1, 0x4, 0xf0, 0x48, 0xf6, 0x92, 0x81, 0x30, 0x61, 0x4d, 0xd4, 0x84, 0x5, 0x94, 0xcf, 0xeb, 0x26, 0x26, 0x89, 0x31, 0xcc, 0x27, 0xdc, 0xcb, 0x18, 0xc, 0x42, 0x5")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceXcbPresentationSupportKHR, "0x94, 0x14, 0xdd, 0xba, 0xfe, 0x5f, 0xf1, 0xa5, 0xe3, 0xb2, 0x59, 0x9, 0x77, 0xfb, 0x1b, 0xe2, 0x82, 0xbf, 0xde, 0xcf, 0x78, 0x59, 0x5e, 0x58, 0x88, 0x1c, 0x60, 0xd6, 0xbc, 0xc0, 0xfc, 0x77")
MAKE_THUNK(libvulkan, vkCreateXlibSurfaceKHR, "0x25, 0xc7, 0x36, 0x45, 0xae, 0x52, 0x43, 0xd6, 0x7c, 0xed, 0x72, 0xe6, 0xfc, 0x2d, 0xa7, 0xb0, 0x3f, 0xdb, 0x30, 0x64, 0xe3, 0x13, 0x94, 0xa9, 0x4, 0x91, 0xfc, 0x49, 0xdb, 0x40, 0x1b, 0x27")
MAKE_THUNK(libvulkan, vkGetPhysicalDeviceXlibPresentationSupportKHR, "0xc5, 0xd6, 0x64, 0x30, 0xf0, 0xbd, 0x7f, 0xaa, 0x7e, 0x49, 0xfa, 0x51, 0x19, 0x98, 0x42, 0x7a, 0xd4, 0x3c, 0x9, 0xc9, 0xb7, 0x9f, 0xb0, 0xd2, 0x38, 0xd3, 0x7a, 0x57, 0x9, 0x15, 0x50, 0xf4")
}
  // unsigned int (struct VkPhysicalDevice_T *, unsigned int, struct _XDisplay *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_0, unsigned int (struct VkPhysicalDevice_T *, unsigned int, struct _XDisplay *, unsigned long), "0xcb, 0x8d, 0x7f, 0xc1, 0x2a, 0xe7, 0xe5, 0x15, 0xe4, 0x20, 0xff, 0x65, 0xe5, 0x15, 0xa1, 0x36, 0x5, 0x5, 0x57, 0xd6, 0xb8, 0x34, 0x5b, 0x69, 0x4c, 0xb9, 0xf8, 0xcf, 0xe, 0x2e, 0x0, 0x3");
  // enum VkResult (struct VkInstance_T *, const struct VkXlibSurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_1, enum VkResult (struct VkInstance_T *, const struct VkXlibSurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x16, 0xc2, 0xa, 0x8f, 0x9, 0xd7, 0x22, 0x6a, 0x52, 0x26, 0xfc, 0xc6, 0x2b, 0x90, 0x4a, 0xda, 0xf9, 0xf9, 0xf1, 0x1f, 0xf3, 0x52, 0x1d, 0x4d, 0x97, 0xf1, 0x7c, 0x6, 0x24, 0xb7, 0xdb, 0x21");
  // enum VkResult (struct VkInstance_T *, const struct VkXcbSurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_2, enum VkResult (struct VkInstance_T *, const struct VkXcbSurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x69, 0xcf, 0x89, 0xd0, 0xc9, 0xee, 0xca, 0xc3, 0x34, 0xc6, 0x3d, 0xec, 0x6c, 0xa6, 0xb0, 0x10, 0x52, 0x12, 0x98, 0xa3, 0x30, 0x8d, 0xd5, 0xd7, 0x7b, 0x67, 0x3b, 0x28, 0x34, 0xeb, 0x80, 0xb5");
  // unsigned int (struct VkPhysicalDevice_T *, unsigned int, struct wl_display *)
  MAKE_CALLBACK_THUNK(callback_3, unsigned int (struct VkPhysicalDevice_T *, unsigned int, struct wl_display *), "0x32, 0xd, 0x34, 0xbe, 0xc4, 0xf0, 0x9b, 0x40, 0x5d, 0x23, 0x95, 0x15, 0xb3, 0xa5, 0x16, 0xc, 0xd7, 0xec, 0xda, 0xe6, 0x6e, 0x47, 0xd2, 0x25, 0xd6, 0x31, 0x3b, 0x4b, 0x35, 0x60, 0x2c, 0xdc");
  // enum VkResult (struct VkInstance_T *, const struct VkWaylandSurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_4, enum VkResult (struct VkInstance_T *, const struct VkWaylandSurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x1, 0x94, 0xf1, 0x7, 0xd6, 0x5b, 0x28, 0x41, 0x5d, 0xf6, 0x43, 0xf6, 0x7f, 0xb9, 0x10, 0x1f, 0x11, 0xab, 0x54, 0x81, 0xa9, 0xc6, 0x86, 0x7d, 0x3b, 0x52, 0x7b, 0xe7, 0x8a, 0x2, 0x74, 0xdf");
  // enum VkResult (struct VkPhysicalDevice_T *, struct _XDisplay *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_5, enum VkResult (struct VkPhysicalDevice_T *, struct _XDisplay *, unsigned long), "0x17, 0x9a, 0xd6, 0xe3, 0x67, 0x25, 0xad, 0x1f, 0xa6, 0x4d, 0xe1, 0x53, 0xca, 0x5e, 0x5c, 0xa0, 0xd9, 0x39, 0x8e, 0xef, 0x95, 0x1f, 0x76, 0x4b, 0x59, 0x1e, 0x46, 0x18, 0x5e, 0x27, 0x9b, 0x46");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned long, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_6, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned long, unsigned int, unsigned int), "0xaf, 0x5a, 0xc7, 0x28, 0xcd, 0xd4, 0xe9, 0x61, 0x4e, 0x97, 0x10, 0xe1, 0x3, 0x95, 0x16, 0x1f, 0x86, 0x1, 0xa5, 0xab, 0x57, 0x8a, 0xec, 0xc9, 0x73, 0xfb, 0x96, 0xc0, 0xa5, 0xf3, 0x8a, 0x64");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_7, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int, unsigned int), "0xac, 0x73, 0x81, 0x8f, 0x6f, 0xfc, 0x1b, 0x92, 0xd2, 0x88, 0x8b, 0xa, 0x18, 0xc7, 0xd0, 0x2b, 0xe6, 0x9d, 0x16, 0x11, 0x9b, 0xbe, 0x47, 0x48, 0x63, 0x87, 0x8a, 0x4a, 0x61, 0x6d, 0xbf, 0xa4");
  // unsigned long (struct VkDevice_T *, unsigned long, unsigned int, enum VkShaderGroupShaderKHR)
  MAKE_CALLBACK_THUNK(callback_8, unsigned long (struct VkDevice_T *, unsigned long, unsigned int, enum VkShaderGroupShaderKHR), "0x23, 0xc, 0xe, 0xcb, 0x75, 0x8, 0xef, 0x1a, 0x27, 0x3, 0xd4, 0xd, 0x46, 0xe, 0x8f, 0x51, 0x1, 0xd, 0x22, 0x4a, 0x2d, 0x52, 0xce, 0x6c, 0x51, 0x7c, 0xca, 0xbe, 0x8d, 0xb0, 0x18, 0xe4");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, unsigned int, unsigned long, void *)
  MAKE_CALLBACK_THUNK(callback_9, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, unsigned int, unsigned long, void *), "0x46, 0xa2, 0x76, 0xb3, 0x55, 0x6d, 0x3c, 0x1, 0x1f, 0xcf, 0xc6, 0x96, 0xad, 0xb9, 0x52, 0x46, 0x67, 0xbb, 0xc9, 0x52, 0x71, 0x3a, 0x66, 0x6d, 0x61, 0x96, 0x50, 0xdc, 0xa7, 0x15, 0xa, 0x7c");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned int, const struct VkRayTracingPipelineCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_10, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned int, const struct VkRayTracingPipelineCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x1d, 0x6d, 0x56, 0xd, 0x29, 0x1d, 0x46, 0xe1, 0xc0, 0x10, 0x74, 0x91, 0x79, 0x36, 0x20, 0xb0, 0xc7, 0x12, 0xfd, 0x74, 0x9d, 0xc3, 0xdf, 0x8c, 0xed, 0x89, 0xe9, 0x4c, 0xaa, 0xdd, 0xfd, 0x86");
  // void (struct VkCommandBuffer_T *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, unsigned int, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_11, void (struct VkCommandBuffer_T *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, unsigned int, unsigned int, unsigned int), "0x81, 0xf5, 0xaa, 0xc7, 0x24, 0xdb, 0xd, 0x6c, 0xee, 0x1b, 0xdf, 0x36, 0xe9, 0x7a, 0x7e, 0x42, 0x6d, 0xbb, 0x8, 0x8f, 0x4d, 0x31, 0x6b, 0x84, 0x46, 0xba, 0x4c, 0xba, 0xa0, 0x80, 0x6b, 0xfc");
  // void (struct VkDevice_T *, enum VkAccelerationStructureBuildTypeKHR, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const unsigned int *, struct VkAccelerationStructureBuildSizesInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_12, void (struct VkDevice_T *, enum VkAccelerationStructureBuildTypeKHR, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const unsigned int *, struct VkAccelerationStructureBuildSizesInfoKHR *), "0xa4, 0x62, 0x4c, 0x13, 0x5f, 0x3a, 0xa7, 0xa7, 0x9a, 0xea, 0x83, 0x3d, 0x5d, 0x65, 0x44, 0x66, 0x25, 0x4a, 0x12, 0x83, 0x1b, 0x7f, 0x32, 0xf1, 0xbe, 0x37, 0x4, 0x19, 0xa0, 0xde, 0x9e, 0x6f");
  // void (struct VkCommandBuffer_T *, unsigned int, const unsigned long *, enum VkQueryType, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_13, void (struct VkCommandBuffer_T *, unsigned int, const unsigned long *, enum VkQueryType, unsigned long, unsigned int), "0xa0, 0x5b, 0x60, 0xec, 0xfb, 0x55, 0x20, 0x60, 0x39, 0xb0, 0x25, 0x16, 0x4b, 0xaf, 0x8, 0x25, 0xe7, 0x34, 0x2e, 0xa1, 0x7e, 0xa9, 0xf8, 0x51, 0xb5, 0x60, 0x4c, 0xa9, 0xc8, 0x9d, 0x4b, 0x30");
  // unsigned long (struct VkDevice_T *, const struct VkAccelerationStructureDeviceAddressInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_14, unsigned long (struct VkDevice_T *, const struct VkAccelerationStructureDeviceAddressInfoKHR *), "0xbf, 0xad, 0xff, 0x94, 0x56, 0xa9, 0x7f, 0x3a, 0x54, 0xe7, 0x96, 0x53, 0xcc, 0xcb, 0xce, 0x50, 0xc, 0xbc, 0xa0, 0xdb, 0xdf, 0xa3, 0xbd, 0xbe, 0xc4, 0x8f, 0x15, 0xc5, 0x98, 0x45, 0xf0, 0x64");
  // void (struct VkCommandBuffer_T *, const struct VkCopyMemoryToAccelerationStructureInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_15, void (struct VkCommandBuffer_T *, const struct VkCopyMemoryToAccelerationStructureInfoKHR *), "0x5a, 0xb, 0x79, 0xde, 0xae, 0x70, 0xdb, 0xa2, 0xeb, 0x36, 0x49, 0x79, 0x50, 0x53, 0x8e, 0xf3, 0xc9, 0xde, 0xb6, 0x32, 0xa3, 0x4b, 0x56, 0xb3, 0x40, 0xb0, 0x56, 0x4c, 0x76, 0xca, 0xd1, 0x78");
  // enum VkResult (struct VkDevice_T *, unsigned int, const unsigned long *, enum VkQueryType, unsigned long, void *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_16, enum VkResult (struct VkDevice_T *, unsigned int, const unsigned long *, enum VkQueryType, unsigned long, void *, unsigned long), "0x6b, 0x4f, 0x6b, 0xfc, 0x28, 0xd7, 0xff, 0xbd, 0x3, 0x8c, 0xb1, 0x28, 0xb9, 0xb3, 0x61, 0x3b, 0x46, 0xc9, 0x34, 0xba, 0x33, 0xe4, 0xef, 0xe3, 0x5b, 0x23, 0x9, 0x1, 0xa, 0xfb, 0x9b, 0x1c");
  // void (struct VkDevice_T *, unsigned long, const struct VkAllocationCallbacks *)
  MAKE_CALLBACK_THUNK(callback_17, void (struct VkDevice_T *, unsigned long, const struct VkAllocationCallbacks *), "0x27, 0x91, 0xf5, 0x5f, 0x73, 0x3a, 0xf5, 0xe7, 0xd4, 0x67, 0x4d, 0xcc, 0x10, 0x3, 0x2f, 0xa6, 0x7e, 0x72, 0x0, 0x1f, 0x22, 0x4e, 0x61, 0x21, 0xf9, 0x87, 0xd7, 0x6, 0x6b, 0xe, 0x9e, 0xee");
  // enum VkResult (struct VkDevice_T *, const struct VkAccelerationStructureCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_18, enum VkResult (struct VkDevice_T *, const struct VkAccelerationStructureCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x65, 0x3a, 0x7c, 0x4c, 0xeb, 0xd8, 0x7d, 0xd8, 0xd5, 0x75, 0x2d, 0x8, 0xa4, 0x4a, 0x44, 0xb3, 0x3b, 0xa1, 0x69, 0x7d, 0xf2, 0xf4, 0xae, 0xd4, 0x91, 0xe0, 0x65, 0xf8, 0x7f, 0x8b, 0xe2, 0x82");
  // void (struct VkCommandBuffer_T *, const struct VkComputeOccupancyPriorityParametersNV *)
  MAKE_CALLBACK_THUNK(callback_19, void (struct VkCommandBuffer_T *, const struct VkComputeOccupancyPriorityParametersNV *), "0xa0, 0x57, 0xdc, 0x10, 0x18, 0xeb, 0x40, 0xd, 0x27, 0x8b, 0x27, 0xde, 0xea, 0xeb, 0xa3, 0xb, 0x3a, 0x6, 0xc9, 0xcb, 0x81, 0x40, 0x3c, 0xe1, 0xfd, 0x90, 0xd8, 0x6b, 0x8b, 0xdb, 0x68, 0xf1");
  // void (struct VkCommandBuffer_T *, const struct VkBeginCustomResolveInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_20, void (struct VkCommandBuffer_T *, const struct VkBeginCustomResolveInfoEXT *), "0xb1, 0xb4, 0x2a, 0x60, 0x19, 0x16, 0xd4, 0x3c, 0xf3, 0x9b, 0xd7, 0x84, 0x39, 0x66, 0x10, 0xf6, 0xe6, 0xfe, 0x62, 0xbd, 0xc1, 0xb6, 0x48, 0xff, 0x60, 0x4b, 0x39, 0x92, 0x7b, 0x2f, 0x88, 0x2");
  // void (struct VkDevice_T *, unsigned long, unsigned int, const struct VkWriteIndirectExecutionSetShaderEXT *)
  MAKE_CALLBACK_THUNK(callback_21, void (struct VkDevice_T *, unsigned long, unsigned int, const struct VkWriteIndirectExecutionSetShaderEXT *), "0x91, 0x2c, 0x1d, 0x5, 0x71, 0x15, 0xf6, 0x16, 0x3d, 0x77, 0x96, 0x7d, 0xa5, 0xce, 0xcc, 0xb8, 0x8c, 0xc5, 0xd4, 0x40, 0xb0, 0xda, 0xb8, 0xab, 0x14, 0x61, 0x52, 0x25, 0xe3, 0x3b, 0x59, 0xf8");
  // enum VkResult (struct VkDevice_T *, const struct VkIndirectExecutionSetCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_22, enum VkResult (struct VkDevice_T *, const struct VkIndirectExecutionSetCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0xe2, 0xa5, 0x9e, 0xaa, 0xca, 0x7c, 0xdd, 0x76, 0x65, 0x56, 0xbc, 0x9e, 0x10, 0x3c, 0x6d, 0xb3, 0xb8, 0x64, 0xe7, 0x5b, 0xc9, 0x4a, 0xbb, 0x9, 0xd8, 0x86, 0xae, 0xfe, 0xba, 0x8d, 0xe5, 0x54");
  // enum VkResult (struct VkDevice_T *, const struct VkIndirectCommandsLayoutCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_23, enum VkResult (struct VkDevice_T *, const struct VkIndirectCommandsLayoutCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0xa2, 0x98, 0x64, 0xa1, 0xb3, 0x34, 0xd4, 0x65, 0xe2, 0xf1, 0xed, 0x8, 0x91, 0x76, 0x2e, 0xe5, 0xce, 0xe0, 0x5b, 0x82, 0x3f, 0xa6, 0xd8, 0xe, 0xa0, 0xf6, 0x6a, 0x63, 0xfe, 0xe4, 0x40, 0xd0");
  // void (struct VkCommandBuffer_T *, const struct VkGeneratedCommandsInfoEXT *, struct VkCommandBuffer_T *)
  MAKE_CALLBACK_THUNK(callback_25, void (struct VkCommandBuffer_T *, const struct VkGeneratedCommandsInfoEXT *, struct VkCommandBuffer_T *), "0x61, 0xac, 0xbc, 0x92, 0xee, 0xa5, 0x0, 0x6d, 0x95, 0x27, 0x8e, 0x83, 0x2, 0xe6, 0x23, 0x8a, 0x69, 0x39, 0x13, 0x25, 0x77, 0x5e, 0xc, 0xdf, 0x48, 0x84, 0xb0, 0xf, 0x3d, 0x6b, 0x32, 0x9a");
  // void (struct VkDevice_T *, const struct VkPartitionedAccelerationStructureInstancesInputNV *, struct VkAccelerationStructureBuildSizesInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_26, void (struct VkDevice_T *, const struct VkPartitionedAccelerationStructureInstancesInputNV *, struct VkAccelerationStructureBuildSizesInfoKHR *), "0x85, 0xa4, 0xd6, 0x2d, 0x75, 0x57, 0xbf, 0x44, 0xcf, 0x93, 0x4a, 0xa1, 0xb5, 0xa9, 0x74, 0x4, 0x5b, 0x57, 0xfd, 0xc6, 0x16, 0x15, 0xc0, 0x2e, 0x9d, 0x7f, 0x8, 0x95, 0x19, 0xfb, 0x32, 0xc3");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_27, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int), "0x66, 0xcc, 0x40, 0x8d, 0xa0, 0xad, 0x9c, 0x9a, 0xc8, 0xb4, 0x8c, 0x1d, 0xc, 0x70, 0xe1, 0xed, 0x20, 0xdf, 0x61, 0xf2, 0x4c, 0x52, 0x77, 0xfa, 0xdc, 0xe4, 0x6a, 0xb6, 0xb5, 0xf, 0xfa, 0xd2");
  // void (struct VkCommandBuffer_T *, const struct VkClusterAccelerationStructureCommandsInfoNV *)
  MAKE_CALLBACK_THUNK(callback_28, void (struct VkCommandBuffer_T *, const struct VkClusterAccelerationStructureCommandsInfoNV *), "0xf4, 0xa5, 0x12, 0xd4, 0xd7, 0x5a, 0x9f, 0xc0, 0x75, 0xea, 0x6, 0x5d, 0x40, 0xe0, 0xd, 0x50, 0xf7, 0x42, 0x90, 0x1d, 0xf8, 0x45, 0xcd, 0xb6, 0x15, 0x20, 0xdf, 0xdc, 0x4c, 0x3f, 0xdb, 0xb9");
  // void (struct VkDevice_T *, struct VkExternalComputeQueueNV_T *, const struct VkAllocationCallbacks *)
  MAKE_CALLBACK_THUNK(callback_29, void (struct VkDevice_T *, struct VkExternalComputeQueueNV_T *, const struct VkAllocationCallbacks *), "0x3f, 0xeb, 0xfd, 0xbc, 0x29, 0x23, 0x29, 0xed, 0xba, 0xfb, 0xc1, 0x5c, 0xf3, 0x5b, 0x51, 0xb9, 0xd9, 0xd0, 0x84, 0x65, 0x9a, 0xc2, 0xfc, 0xaa, 0xcf, 0xd5, 0x8f, 0xfc, 0x94, 0xd7, 0x17, 0x8f");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_30, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned int, unsigned int), "0x4e, 0xa8, 0x9a, 0x87, 0xa9, 0xea, 0x15, 0x5e, 0x0, 0x4a, 0xe5, 0xa, 0x94, 0x4c, 0xd5, 0xa0, 0xe6, 0xe5, 0x73, 0xb8, 0xab, 0xc, 0x3b, 0x9c, 0xa7, 0x10, 0x16, 0x16, 0x8, 0xec, 0x97, 0x9b");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const unsigned long *, const unsigned int *, const unsigned int *const *)
  MAKE_CALLBACK_THUNK(callback_31, void (struct VkCommandBuffer_T *, unsigned int, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const unsigned long *, const unsigned int *, const unsigned int *const *), "0x37, 0xfb, 0x11, 0x6f, 0x75, 0xdf, 0xf3, 0x9e, 0xa2, 0xf3, 0xce, 0x40, 0xab, 0x44, 0x7a, 0xb8, 0x17, 0x83, 0x9, 0x94, 0xb6, 0x14, 0xe4, 0xa7, 0x8c, 0x87, 0x6a, 0x23, 0xea, 0x76, 0x63, 0x2e");
  // void (struct VkCommandBuffer_T *, const struct VkTileMemoryBindInfoQCOM *)
  MAKE_CALLBACK_THUNK(callback_32, void (struct VkCommandBuffer_T *, const struct VkTileMemoryBindInfoQCOM *), "0x26, 0x28, 0x7d, 0x1f, 0xd8, 0x1a, 0xad, 0x41, 0x8b, 0xd4, 0x6f, 0x31, 0x30, 0x6f, 0x3d, 0x95, 0xf2, 0xca, 0xa1, 0x77, 0x9f, 0x65, 0xcf, 0x31, 0xc3, 0x2c, 0x7c, 0xd7, 0x4c, 0xc0, 0x96, 0x25");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, struct VkQueueFamilyDataGraphPropertiesARM *)
  MAKE_CALLBACK_THUNK(callback_33, enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, struct VkQueueFamilyDataGraphPropertiesARM *), "0x53, 0x7c, 0x53, 0x87, 0xb, 0x20, 0xdb, 0xca, 0xbe, 0xde, 0xe5, 0xaf, 0x8d, 0xf2, 0x0, 0xe, 0x1c, 0xc3, 0x4d, 0x66, 0x38, 0xee, 0xea, 0xcd, 0xe0, 0xfd, 0xa0, 0x56, 0x25, 0x8a, 0x7f, 0x6");
  // void (struct VkCommandBuffer_T *, unsigned long, const struct VkDataGraphPipelineDispatchInfoARM *)
  MAKE_CALLBACK_THUNK(callback_34, void (struct VkCommandBuffer_T *, unsigned long, const struct VkDataGraphPipelineDispatchInfoARM *), "0xd7, 0x4b, 0x30, 0xbc, 0x0, 0xe, 0xd, 0x39, 0xb5, 0xcd, 0xb7, 0xfa, 0x4, 0x75, 0xe1, 0x2c, 0xc4, 0x87, 0xab, 0x6d, 0x7e, 0xb, 0x5e, 0x23, 0xed, 0xe6, 0xc0, 0xd1, 0x1b, 0xfb, 0x28, 0xf");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindDataGraphPipelineSessionMemoryInfoARM *)
  MAKE_CALLBACK_THUNK(callback_36, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindDataGraphPipelineSessionMemoryInfoARM *), "0x30, 0x82, 0xb1, 0x4, 0xa3, 0x3b, 0x8f, 0xd5, 0x6f, 0x55, 0x8e, 0x48, 0x3a, 0xcd, 0xe3, 0xd6, 0xdf, 0x54, 0x4, 0xf2, 0x46, 0x99, 0x4b, 0xf8, 0xd7, 0x5d, 0x2c, 0x57, 0x59, 0x2b, 0xf5, 0x21");
  // enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineSessionBindPointRequirementsInfoARM *, unsigned int *, struct VkDataGraphPipelineSessionBindPointRequirementARM *)
  MAKE_CALLBACK_THUNK(callback_37, enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineSessionBindPointRequirementsInfoARM *, unsigned int *, struct VkDataGraphPipelineSessionBindPointRequirementARM *), "0x18, 0x61, 0x99, 0xf7, 0xa2, 0xd0, 0x68, 0xc3, 0x22, 0xdd, 0xe9, 0xb4, 0x67, 0x5f, 0x95, 0xb, 0xdd, 0x7e, 0x8, 0x8b, 0x5, 0xc0, 0x1, 0x6a, 0x5b, 0xf4, 0xdd, 0xbc, 0xc0, 0x89, 0x5e, 0x2c");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned int, const struct VkDataGraphPipelineCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_38, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned int, const struct VkDataGraphPipelineCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *), "0x4, 0x15, 0x5d, 0x87, 0x7e, 0x1e, 0x50, 0x12, 0x3, 0x77, 0x3e, 0x2a, 0xa1, 0x8c, 0xf8, 0x14, 0xe, 0x46, 0xba, 0x90, 0xd1, 0xe6, 0xb, 0x3e, 0x6f, 0xbe, 0xf2, 0x86, 0x6f, 0x84, 0x61, 0x60");
  // void (struct VkDevice_T *, unsigned long, struct VkGetLatencyMarkerInfoNV *)
  MAKE_CALLBACK_THUNK(callback_39, void (struct VkDevice_T *, unsigned long, struct VkGetLatencyMarkerInfoNV *), "0x72, 0x93, 0x7a, 0x33, 0x30, 0x32, 0xbd, 0x60, 0xc8, 0x4a, 0x43, 0x10, 0xf1, 0xf4, 0x1f, 0xc0, 0x8b, 0xd7, 0xed, 0x37, 0x14, 0xf, 0x9a, 0xa8, 0x51, 0xfe, 0xb2, 0x49, 0xd0, 0x70, 0xd, 0x73");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkLatencySleepInfoNV *)
  MAKE_CALLBACK_THUNK(callback_40, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkLatencySleepInfoNV *), "0x3b, 0xcd, 0xb1, 0x5f, 0xdf, 0x83, 0xbb, 0x9b, 0x9e, 0x76, 0xe9, 0x75, 0xe9, 0xfd, 0x91, 0x59, 0x6f, 0x49, 0x24, 0xea, 0x8c, 0x87, 0xef, 0xe7, 0x79, 0xbb, 0x3b, 0x13, 0xa7, 0xba, 0x2b, 0x1");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeVectorPropertiesNV *)
  MAKE_CALLBACK_THUNK(callback_41, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeVectorPropertiesNV *), "0xc3, 0x2c, 0x86, 0x4a, 0x31, 0xe7, 0x7a, 0xf, 0xcf, 0xa9, 0x8c, 0x3f, 0xe1, 0x11, 0xa2, 0x52, 0x4e, 0x1d, 0xc, 0x74, 0x53, 0x77, 0x54, 0x1c, 0xa4, 0xa, 0x49, 0xbe, 0xda, 0x10, 0xcd, 0xa4");
  // enum VkResult (struct VkDevice_T *, const struct VkRenderingInfo *, struct VkTilePropertiesQCOM *)
  MAKE_CALLBACK_THUNK(callback_42, enum VkResult (struct VkDevice_T *, const struct VkRenderingInfo *, struct VkTilePropertiesQCOM *), "0xbe, 0x51, 0x9d, 0x16, 0x20, 0xd9, 0x37, 0x47, 0xd7, 0xa9, 0x32, 0xec, 0x87, 0xef, 0x64, 0x91, 0x37, 0x5, 0xbc, 0x6b, 0x3b, 0xf9, 0xda, 0x99, 0x6, 0x51, 0x69, 0x6d, 0x4f, 0x5a, 0x87, 0xf");
  // void (struct VkCommandBuffer_T *, enum VkDepthClampModeEXT, const struct VkDepthClampRangeEXT *)
  MAKE_CALLBACK_THUNK(callback_43, void (struct VkCommandBuffer_T *, enum VkDepthClampModeEXT, const struct VkDepthClampRangeEXT *), "0x20, 0xb0, 0x6d, 0xc8, 0xfa, 0x45, 0x3f, 0xd1, 0x93, 0x3a, 0x7d, 0x24, 0x4f, 0xe9, 0x1a, 0x8d, 0x26, 0xcc, 0x68, 0x4f, 0x66, 0xcc, 0xc7, 0xec, 0xf7, 0x70, 0xc4, 0x91, 0x32, 0x5e, 0x57, 0x2a");
  // void (struct VkCommandBuffer_T *, unsigned int, const enum VkShaderStageFlagBits *, const unsigned long *)
  MAKE_CALLBACK_THUNK(callback_44, void (struct VkCommandBuffer_T *, unsigned int, const enum VkShaderStageFlagBits *, const unsigned long *), "0xba, 0xa, 0x91, 0x2f, 0x9c, 0x60, 0x1e, 0x79, 0x7f, 0xc, 0xf4, 0x9d, 0x87, 0xfd, 0xeb, 0x92, 0x50, 0x13, 0x90, 0xa5, 0x32, 0xd1, 0x45, 0x1e, 0xeb, 0x79, 0x99, 0x56, 0x19, 0xa4, 0x64, 0xd8");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long *, void *)
  MAKE_CALLBACK_THUNK(callback_45, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long *, void *), "0xcb, 0xd7, 0x81, 0x77, 0xa7, 0x91, 0xd9, 0x77, 0xa6, 0xc0, 0x31, 0x28, 0x2, 0x3d, 0xa7, 0xf2, 0xef, 0x57, 0xec, 0xcb, 0xd2, 0xf1, 0xbe, 0xa8, 0x59, 0x5e, 0x64, 0xe8, 0xfc, 0x88, 0x90, 0x48");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkShaderCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_46, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkShaderCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0x15, 0x33, 0x7f, 0xfe, 0x10, 0x4f, 0x2c, 0xfa, 0x7d, 0xba, 0xbd, 0x41, 0xc2, 0x87, 0xa1, 0x8, 0xbb, 0x56, 0xd3, 0xa3, 0xb3, 0x47, 0x68, 0x3f, 0xbf, 0x56, 0xf4, 0x8a, 0xde, 0x12, 0xcd, 0xe");
  // void (struct VkDevice_T *, const struct VkAntiLagDataAMD *)
  MAKE_CALLBACK_THUNK(callback_47, void (struct VkDevice_T *, const struct VkAntiLagDataAMD *), "0x1f, 0xf2, 0xfe, 0x78, 0x9e, 0x33, 0x36, 0xc1, 0x39, 0x3d, 0xf7, 0x81, 0xb7, 0xd0, 0xf5, 0xb, 0xe8, 0x59, 0x4f, 0x19, 0x2e, 0x2d, 0x3b, 0x2c, 0x8a, 0x38, 0x33, 0xa1, 0xb1, 0x30, 0xb5, 0xf8");
  // enum VkResult (struct VkDevice_T *, const struct VkOpticalFlowSessionCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_49, enum VkResult (struct VkDevice_T *, const struct VkOpticalFlowSessionCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *), "0xa1, 0xd5, 0xff, 0x96, 0x23, 0x40, 0x48, 0x80, 0xe5, 0xc6, 0xc1, 0x7a, 0x9e, 0x4, 0xf5, 0xb6, 0xb9, 0x38, 0x7d, 0x4c, 0xb7, 0x8a, 0x71, 0x5a, 0xf9, 0xbe, 0xee, 0x5a, 0xf0, 0xd5, 0xc6, 0x18");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkOpticalFlowImageFormatInfoNV *, unsigned int *, struct VkOpticalFlowImageFormatPropertiesNV *)
  MAKE_CALLBACK_THUNK(callback_50, enum VkResult (struct VkPhysicalDevice_T *, const struct VkOpticalFlowImageFormatInfoNV *, unsigned int *, struct VkOpticalFlowImageFormatPropertiesNV *), "0x1b, 0xf6, 0xbf, 0x48, 0xd3, 0x60, 0x95, 0x3, 0x3b, 0x2, 0xff, 0xf2, 0x5d, 0x86, 0x65, 0xa7, 0x26, 0x9d, 0xe4, 0x83, 0x8b, 0xf9, 0x9c, 0x62, 0xbe, 0x9, 0xd7, 0x32, 0x34, 0x75, 0xdf, 0xfc");
  // void (struct VkDevice_T *, const struct VkShaderModuleCreateInfo *, struct VkShaderModuleIdentifierEXT *)
  MAKE_CALLBACK_THUNK(callback_51, void (struct VkDevice_T *, const struct VkShaderModuleCreateInfo *, struct VkShaderModuleIdentifierEXT *), "0x8a, 0xc2, 0x23, 0xdb, 0x9b, 0x25, 0x82, 0xe7, 0x3d, 0x28, 0xe6, 0x58, 0xd3, 0x57, 0x8c, 0xc9, 0x26, 0x1d, 0xdc, 0x82, 0xd5, 0x75, 0xcb, 0xbd, 0x9b, 0x4c, 0x4b, 0x67, 0xb, 0xb1, 0xa9, 0x9c");
  // void (struct VkDevice_T *, unsigned long, struct VkShaderModuleIdentifierEXT *)
  MAKE_CALLBACK_THUNK(callback_52, void (struct VkDevice_T *, unsigned long, struct VkShaderModuleIdentifierEXT *), "0x20, 0xa8, 0xb0, 0xa9, 0x93, 0xec, 0x8c, 0xf6, 0x74, 0xe4, 0x1b, 0xde, 0xbd, 0xe3, 0xe6, 0xa6, 0xdd, 0x64, 0x85, 0xb7, 0x87, 0x69, 0x48, 0x4b, 0x47, 0xbf, 0xeb, 0x43, 0x49, 0x9b, 0x43, 0x83");
  // enum VkResult (struct VkDevice_T *, const struct VkTensorCaptureDescriptorDataInfoARM *, void *)
  MAKE_CALLBACK_THUNK(callback_53, enum VkResult (struct VkDevice_T *, const struct VkTensorCaptureDescriptorDataInfoARM *, void *), "0x5d, 0xbd, 0xef, 0x3c, 0x2c, 0x6c, 0xed, 0x85, 0x2e, 0xc8, 0xb6, 0x6a, 0x3, 0x8a, 0x53, 0xf3, 0xd8, 0xe, 0xe4, 0xc, 0xd2, 0x13, 0xb3, 0xf, 0x31, 0xdd, 0x94, 0x72, 0x85, 0x9f, 0xc9, 0x68");
  // void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalTensorInfoARM *, struct VkExternalTensorPropertiesARM *)
  MAKE_CALLBACK_THUNK(callback_54, void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalTensorInfoARM *, struct VkExternalTensorPropertiesARM *), "0x51, 0x28, 0x84, 0x66, 0xc3, 0x1f, 0x45, 0xe4, 0xf0, 0x49, 0x14, 0xa, 0x90, 0x40, 0x46, 0xd3, 0xeb, 0x63, 0x82, 0x97, 0xa4, 0x3a, 0xc8, 0x5c, 0x21, 0x84, 0xa4, 0xc, 0x95, 0xf3, 0x83, 0x14");
  // void (struct VkCommandBuffer_T *, const struct VkCopyTensorInfoARM *)
  MAKE_CALLBACK_THUNK(callback_55, void (struct VkCommandBuffer_T *, const struct VkCopyTensorInfoARM *), "0x36, 0xa0, 0x81, 0x89, 0xeb, 0xa1, 0x14, 0x7a, 0x19, 0x4c, 0xf6, 0xec, 0xc4, 0x16, 0x87, 0x9, 0xe0, 0xb0, 0xb6, 0x13, 0x6a, 0x98, 0xfe, 0x38, 0xa1, 0xff, 0x71, 0x17, 0xf6, 0xd5, 0x7a, 0xa0");
  // void (struct VkDevice_T *, const struct VkDeviceTensorMemoryRequirementsARM *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_56, void (struct VkDevice_T *, const struct VkDeviceTensorMemoryRequirementsARM *, struct VkMemoryRequirements2 *), "0xc6, 0xab, 0x59, 0x17, 0x82, 0x3c, 0x65, 0x91, 0xa, 0xc6, 0x68, 0x5f, 0x94, 0xf, 0x48, 0x27, 0xb8, 0x8f, 0x55, 0xf2, 0x1a, 0xc9, 0x46, 0x36, 0xaa, 0x31, 0xf8, 0x6c, 0x56, 0xe4, 0xd7, 0x0");
  // void (struct VkCommandBuffer_T *, const struct VkDecompressMemoryInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_57, void (struct VkCommandBuffer_T *, const struct VkDecompressMemoryInfoEXT *), "0x2f, 0x84, 0xa9, 0x68, 0x41, 0xd7, 0xf8, 0xf0, 0xb2, 0xce, 0x6c, 0xa2, 0xc1, 0x31, 0x15, 0x9, 0xff, 0x1, 0x89, 0x47, 0xe2, 0x8f, 0xc, 0xb7, 0xd6, 0x3c, 0x34, 0xa, 0xde, 0xa5, 0x59, 0x4b");
  // enum VkResult (struct VkDevice_T *, const struct VkTensorCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_59, enum VkResult (struct VkDevice_T *, const struct VkTensorCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *), "0x4c, 0xdd, 0xeb, 0x63, 0x66, 0xf9, 0x5d, 0x99, 0xdb, 0x12, 0xbe, 0xa1, 0xbf, 0xb0, 0x73, 0x62, 0xd4, 0xb3, 0xfb, 0x55, 0x2, 0xf4, 0x88, 0x21, 0x74, 0x32, 0x97, 0x6c, 0x8, 0xb, 0x95, 0xf4");
  // void (struct VkCommandBuffer_T *, unsigned int)
  MAKE_CALLBACK_THUNK(callback_60, void (struct VkCommandBuffer_T *, unsigned int), "0x48, 0x8a, 0x55, 0x65, 0xf7, 0xbb, 0x7a, 0x15, 0x53, 0x3, 0x24, 0x1d, 0x1b, 0xbf, 0x16, 0x54, 0x59, 0x1, 0x55, 0x3, 0x1c, 0xfe, 0x9a, 0x9d, 0x51, 0x62, 0x20, 0x1d, 0x75, 0x17, 0xd7, 0xe5");
  // void (struct VkCommandBuffer_T *, enum VkCoverageModulationModeNV)
  MAKE_CALLBACK_THUNK(callback_62, void (struct VkCommandBuffer_T *, enum VkCoverageModulationModeNV), "0xb7, 0xaf, 0xb6, 0xa2, 0xc8, 0xe9, 0xe8, 0xe9, 0x6c, 0xc7, 0x3d, 0xd1, 0xf0, 0xee, 0x51, 0x37, 0xc1, 0x2, 0x5a, 0x4c, 0xb7, 0x47, 0xea, 0xbb, 0xd7, 0x49, 0xe3, 0x58, 0x5b, 0x27, 0x59, 0xd2");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkViewportSwizzleNV *)
  MAKE_CALLBACK_THUNK(callback_65, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkViewportSwizzleNV *), "0xd9, 0xbb, 0x24, 0x38, 0x57, 0x0, 0xa7, 0xa3, 0x8a, 0x75, 0x52, 0xe4, 0xc9, 0xe5, 0x27, 0xc0, 0xb, 0x9, 0xa1, 0x8b, 0x14, 0xa9, 0x80, 0xa, 0x8, 0x47, 0x70, 0x6c, 0x2f, 0x98, 0xd0, 0xb3");
  // void (struct VkDevice_T *, const struct VkGeneratedCommandsMemoryRequirementsInfoEXT *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_66, void (struct VkDevice_T *, const struct VkGeneratedCommandsMemoryRequirementsInfoEXT *, struct VkMemoryRequirements2 *), "0x9b, 0x67, 0xb4, 0x28, 0x71, 0x76, 0xf9, 0x6a, 0xc5, 0x71, 0xe6, 0x50, 0x72, 0xad, 0xf2, 0x81, 0x33, 0x71, 0xb7, 0x4, 0x70, 0x2a, 0x9b, 0xde, 0x16, 0x54, 0xd, 0x8c, 0x77, 0x6b, 0x0, 0x3c");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkConvertCooperativeVectorMatrixInfoNV *)
  MAKE_CALLBACK_THUNK(callback_68, void (struct VkCommandBuffer_T *, unsigned int, const struct VkConvertCooperativeVectorMatrixInfoNV *), "0xca, 0xe, 0xe1, 0x51, 0xf, 0xaa, 0x9f, 0xcc, 0x26, 0x0, 0xcd, 0x1a, 0xbc, 0x58, 0xee, 0x46, 0x47, 0x4, 0xc2, 0x6d, 0x0, 0xb, 0x6c, 0xbf, 0x16, 0xf9, 0x5f, 0x19, 0x2a, 0x64, 0xe4, 0xf4");
  // void (struct VkCommandBuffer_T *, enum VkProvokingVertexModeEXT)
  MAKE_CALLBACK_THUNK(callback_71, void (struct VkCommandBuffer_T *, enum VkProvokingVertexModeEXT), "0x72, 0x3b, 0x14, 0x3, 0xe9, 0x30, 0x84, 0xba, 0x4a, 0x65, 0x96, 0xa, 0x43, 0x9e, 0x68, 0x33, 0x5e, 0x12, 0xb2, 0xe2, 0x8f, 0x3f, 0x49, 0x1f, 0xeb, 0x43, 0xc3, 0xcc, 0x11, 0xee, 0x78, 0x21");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned int *)
  MAKE_CALLBACK_THUNK(callback_74, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned int *), "0x8e, 0x4, 0x84, 0xa8, 0x18, 0x6e, 0x45, 0x9e, 0x87, 0x20, 0xb4, 0x1f, 0x32, 0x72, 0x62, 0x3a, 0x84, 0x1b, 0x36, 0x41, 0xd2, 0x3c, 0xf3, 0x92, 0x72, 0x2, 0xe6, 0x28, 0xd2, 0xd, 0xd5, 0xe8");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkColorBlendEquationEXT *)
  MAKE_CALLBACK_THUNK(callback_75, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkColorBlendEquationEXT *), "0x51, 0x3f, 0x47, 0x41, 0x78, 0xda, 0x90, 0xb0, 0x66, 0xb7, 0x6b, 0xc2, 0xea, 0xc0, 0x88, 0xe6, 0xd1, 0xbd, 0xd9, 0x3, 0x92, 0x3d, 0x73, 0xc2, 0x51, 0xcb, 0x8c, 0x39, 0x86, 0x72, 0xf5, 0x4c");
  // void (struct VkCommandBuffer_T *, enum VkSampleCountFlagBits, const unsigned int *)
  MAKE_CALLBACK_THUNK(callback_80, void (struct VkCommandBuffer_T *, enum VkSampleCountFlagBits, const unsigned int *), "0x3c, 0xf9, 0x4e, 0x81, 0x8f, 0x46, 0x7c, 0xe6, 0x8d, 0x51, 0x66, 0x92, 0x12, 0xc3, 0xc3, 0x16, 0xf0, 0xd5, 0x92, 0xb0, 0xd5, 0x43, 0xf9, 0x45, 0xd7, 0xb1, 0x39, 0xa4, 0x96, 0xb7, 0x9b, 0x8c");
  // void (struct VkCommandBuffer_T *, enum VkSampleCountFlagBits)
  MAKE_CALLBACK_THUNK(callback_81, void (struct VkCommandBuffer_T *, enum VkSampleCountFlagBits), "0xea, 0x31, 0x6b, 0x33, 0x70, 0x37, 0xf1, 0xe2, 0xe9, 0x38, 0xe1, 0x42, 0x95, 0x36, 0xa0, 0x81, 0xc1, 0x7f, 0xcc, 0x48, 0xb3, 0xe7, 0xb0, 0x2b, 0x84, 0xb6, 0x7b, 0x83, 0x3b, 0xa4, 0xec, 0xce");
  // void (struct VkCommandBuffer_T *, enum VkPolygonMode)
  MAKE_CALLBACK_THUNK(callback_82, void (struct VkCommandBuffer_T *, enum VkPolygonMode), "0x72, 0x23, 0x4c, 0x18, 0x2d, 0xf, 0x6f, 0xc2, 0x57, 0x30, 0x78, 0x20, 0xd0, 0xa3, 0xeb, 0x78, 0xf0, 0x2e, 0x30, 0x83, 0x5, 0x5b, 0xed, 0xd2, 0x76, 0xd5, 0xce, 0xd0, 0x67, 0x4a, 0x94, 0xea");
  // unsigned long (struct VkDevice_T *, const struct VkPipelineIndirectDeviceAddressInfoNV *)
  MAKE_CALLBACK_THUNK(callback_84, unsigned long (struct VkDevice_T *, const struct VkPipelineIndirectDeviceAddressInfoNV *), "0xa5, 0xf0, 0x21, 0xb1, 0x6e, 0x6c, 0x53, 0x84, 0xc1, 0x8d, 0xb3, 0x57, 0xb2, 0x60, 0xd6, 0x34, 0x86, 0xfa, 0xc3, 0x79, 0xa7, 0x6e, 0x89, 0x6b, 0x66, 0x50, 0x62, 0xa3, 0x85, 0xf7, 0x53, 0xc4");
  // void (struct VkDevice_T *, const struct VkComputePipelineCreateInfo *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_85, void (struct VkDevice_T *, const struct VkComputePipelineCreateInfo *, struct VkMemoryRequirements2 *), "0x78, 0x5a, 0x61, 0x3b, 0xfa, 0x22, 0x30, 0x1c, 0xbb, 0x3d, 0xf3, 0x48, 0xc2, 0xe3, 0x12, 0x5, 0x66, 0x5e, 0x15, 0xec, 0x27, 0x2d, 0x24, 0x96, 0xdf, 0x3, 0xf7, 0xcf, 0x80, 0xe3, 0x43, 0x40");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_86, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int), "0x47, 0x35, 0x15, 0x72, 0x48, 0xe2, 0x42, 0x39, 0x25, 0x66, 0x97, 0x9b, 0x62, 0x36, 0x2, 0x60, 0xf2, 0x8a, 0x3a, 0xf7, 0x59, 0xf8, 0xfa, 0xf7, 0xe2, 0xf8, 0xa4, 0x4a, 0xec, 0xbe, 0x15, 0x1a");
  // enum VkResult (struct VkDevice_T *, const struct VkConvertCooperativeVectorMatrixInfoNV *)
  MAKE_CALLBACK_THUNK(callback_87, enum VkResult (struct VkDevice_T *, const struct VkConvertCooperativeVectorMatrixInfoNV *), "0x2a, 0x12, 0xa6, 0xe9, 0xa8, 0xc8, 0xfa, 0x42, 0x5a, 0x25, 0xc5, 0x6c, 0x3c, 0xe4, 0x17, 0x5d, 0x65, 0xd2, 0xf9, 0xa, 0xf8, 0xb4, 0x14, 0x89, 0xe4, 0xb4, 0x59, 0x20, 0xfb, 0x8c, 0x59, 0xa3");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkDecompressMemoryRegionNV *)
  MAKE_CALLBACK_THUNK(callback_88, void (struct VkCommandBuffer_T *, unsigned int, const struct VkDecompressMemoryRegionNV *), "0x96, 0x99, 0x23, 0x54, 0x98, 0x74, 0x45, 0x7d, 0x74, 0x16, 0xa2, 0x7, 0xce, 0x35, 0xa7, 0x27, 0xc7, 0x62, 0xe, 0x26, 0x4c, 0x82, 0x6f, 0x93, 0x85, 0x0, 0xdf, 0x65, 0xae, 0x63, 0xac, 0xea");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned long, enum VkImageLayout, const struct VkImageSubresourceLayers *)
  MAKE_CALLBACK_THUNK(callback_89, void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned long, enum VkImageLayout, const struct VkImageSubresourceLayers *), "0xca, 0x39, 0x25, 0xa5, 0x54, 0x72, 0x38, 0x50, 0xfc, 0xc8, 0x3a, 0xea, 0x91, 0xa0, 0x9a, 0xb1, 0xb, 0x4, 0xfb, 0x4f, 0x7a, 0xd, 0x34, 0x92, 0xd6, 0x29, 0x99, 0x23, 0x7e, 0x95, 0xa5, 0x9");
  // void (struct VkDevice_T *, const struct VkDescriptorSetBindingReferenceVALVE *, struct VkDescriptorSetLayoutHostMappingInfoVALVE *)
  MAKE_CALLBACK_THUNK(callback_90, void (struct VkDevice_T *, const struct VkDescriptorSetBindingReferenceVALVE *, struct VkDescriptorSetLayoutHostMappingInfoVALVE *), "0x8a, 0xbe, 0x9b, 0xed, 0x4c, 0xb5, 0xb7, 0x82, 0x19, 0xb1, 0xa6, 0xcf, 0xbd, 0xee, 0x42, 0xab, 0x47, 0xf8, 0xd4, 0x3a, 0x34, 0x2, 0x7c, 0x3d, 0x9f, 0xff, 0x43, 0x4c, 0x25, 0x22, 0x3c, 0x7b");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long)
  MAKE_CALLBACK_THUNK(callback_91, void (struct VkCommandBuffer_T *, unsigned long, unsigned long), "0xb0, 0xe9, 0x95, 0xbe, 0xee, 0xec, 0x2, 0x23, 0xa7, 0x3a, 0x75, 0x2c, 0x73, 0xd2, 0xf5, 0x4e, 0xb4, 0x4a, 0x6, 0xd2, 0xd8, 0x1, 0x44, 0xef, 0xf0, 0x38, 0xa2, 0xc1, 0x3c, 0xda, 0x3d, 0x76");
  // void (struct VkDevice_T *, enum VkAccelerationStructureBuildTypeKHR, const struct VkMicromapBuildInfoEXT *, struct VkMicromapBuildSizesInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_92, void (struct VkDevice_T *, enum VkAccelerationStructureBuildTypeKHR, const struct VkMicromapBuildInfoEXT *, struct VkMicromapBuildSizesInfoEXT *), "0xde, 0xbb, 0x65, 0x5e, 0xc5, 0x80, 0x28, 0xca, 0x69, 0x53, 0x4c, 0xa0, 0x9, 0x54, 0x74, 0xc, 0x91, 0x15, 0x79, 0xab, 0xd6, 0x6, 0xa3, 0x36, 0x6f, 0xb9, 0xa, 0x34, 0x77, 0x54, 0xb, 0xb2");
  // void (struct VkDevice_T *, const struct VkMicromapVersionInfoEXT *, enum VkAccelerationStructureCompatibilityKHR *)
  MAKE_CALLBACK_THUNK(callback_93, void (struct VkDevice_T *, const struct VkMicromapVersionInfoEXT *, enum VkAccelerationStructureCompatibilityKHR *), "0x8, 0x1b, 0x4f, 0x52, 0x6a, 0xd2, 0x8b, 0xc2, 0x99, 0xaa, 0x40, 0x32, 0x50, 0x1c, 0xec, 0x14, 0x19, 0x47, 0x70, 0xcd, 0x87, 0xf9, 0x2c, 0x8d, 0xb0, 0xb4, 0x13, 0x58, 0x3e, 0xd5, 0x3e, 0xf8");
  // void (struct VkCommandBuffer_T *, const struct VkCopyMemoryToMicromapInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_95, void (struct VkCommandBuffer_T *, const struct VkCopyMemoryToMicromapInfoEXT *), "0x28, 0xce, 0xe1, 0x7e, 0xc6, 0x8e, 0xc4, 0x53, 0x55, 0x38, 0x98, 0x91, 0xa3, 0x13, 0x7d, 0xb3, 0x8f, 0x97, 0x5d, 0x4f, 0xd4, 0x82, 0xde, 0xb5, 0xba, 0x3a, 0xd, 0xcc, 0xd4, 0x49, 0xcb, 0x1d");
  // void (struct VkCommandBuffer_T *, const struct VkCopyMicromapToMemoryInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_96, void (struct VkCommandBuffer_T *, const struct VkCopyMicromapToMemoryInfoEXT *), "0xea, 0xdb, 0xe2, 0x65, 0xa1, 0x4f, 0xb9, 0x35, 0x60, 0x3, 0xb2, 0xcf, 0x5a, 0xfa, 0xb4, 0x9f, 0x69, 0xb6, 0x78, 0xf4, 0x1e, 0xb2, 0x96, 0x13, 0x55, 0x73, 0x72, 0x3d, 0x48, 0x16, 0x8e, 0x81");
  // void (struct VkCommandBuffer_T *, const struct VkCopyMicromapInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_97, void (struct VkCommandBuffer_T *, const struct VkCopyMicromapInfoEXT *), "0xb6, 0x9a, 0xd3, 0xa3, 0xeb, 0x5d, 0x8f, 0xc5, 0xe7, 0x3e, 0xa0, 0x45, 0xc5, 0x3b, 0xe2, 0xfc, 0xac, 0xf3, 0x48, 0xff, 0x26, 0xb8, 0x9f, 0xad, 0x4a, 0xee, 0x7e, 0x92, 0x69, 0xbb, 0x37, 0x3e");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMemoryToMicromapInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_99, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMemoryToMicromapInfoEXT *), "0xce, 0xf5, 0xd3, 0x1a, 0x1f, 0x45, 0x34, 0xc4, 0x72, 0x75, 0xe7, 0x3c, 0x69, 0x7d, 0x5c, 0xf8, 0x65, 0x52, 0x9b, 0x7a, 0xdc, 0xb9, 0x5, 0x14, 0x22, 0x3f, 0x72, 0x5b, 0x8e, 0x29, 0x89, 0xd");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMicromapToMemoryInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_100, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMicromapToMemoryInfoEXT *), "0xb4, 0xd1, 0xa8, 0x75, 0xb4, 0xd6, 0x53, 0x28, 0x17, 0x3d, 0x8c, 0x67, 0xad, 0x74, 0x75, 0x48, 0x80, 0xdc, 0xce, 0xd1, 0xfd, 0x1d, 0x61, 0x24, 0x8a, 0x81, 0x1e, 0x20, 0x76, 0xa6, 0x72, 0xe4");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkMicromapBuildInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_101, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkMicromapBuildInfoEXT *), "0xc2, 0x23, 0xd6, 0x37, 0xfe, 0x51, 0x3e, 0x9d, 0x49, 0x72, 0x58, 0xde, 0x44, 0x9d, 0xd5, 0xb3, 0xc6, 0xc8, 0x41, 0x0, 0x6a, 0x38, 0x17, 0x40, 0x83, 0x70, 0xec, 0xff, 0xc2, 0xf3, 0xc8, 0x9c");
  // void (struct VkDevice_T *, unsigned long, const struct VkSetLatencyMarkerInfoNV *)
  MAKE_CALLBACK_THUNK(callback_103, void (struct VkDevice_T *, unsigned long, const struct VkSetLatencyMarkerInfoNV *), "0x7b, 0xb4, 0x32, 0xe4, 0xe5, 0xdd, 0xc0, 0xb0, 0xd8, 0x73, 0x2b, 0xa5, 0xbe, 0xa4, 0xf4, 0xba, 0x16, 0x5c, 0x92, 0xa5, 0xc5, 0x2e, 0x75, 0x74, 0x43, 0x46, 0x81, 0xf7, 0xce, 0x66, 0xcf, 0x13");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkMultiDrawIndexedInfoEXT *, unsigned int, unsigned int, unsigned int, const int *)
  MAKE_CALLBACK_THUNK(callback_104, void (struct VkCommandBuffer_T *, unsigned int, const struct VkMultiDrawIndexedInfoEXT *, unsigned int, unsigned int, unsigned int, const int *), "0x59, 0xbb, 0x54, 0x38, 0x2, 0x6a, 0x36, 0x4f, 0xee, 0x61, 0x48, 0x8d, 0xe, 0x53, 0x9c, 0x30, 0x16, 0xe8, 0xbd, 0x2e, 0xa1, 0x7d, 0xb7, 0x7b, 0xc3, 0x1a, 0x83, 0x1a, 0x8a, 0x95, 0xa6, 0xb1");
  // void (struct VkCommandBuffer_T *, enum VkLogicOp)
  MAKE_CALLBACK_THUNK(callback_106, void (struct VkCommandBuffer_T *, enum VkLogicOp), "0x65, 0xa0, 0xa5, 0x87, 0xdb, 0x2c, 0x70, 0x9d, 0x3b, 0x18, 0x7d, 0xac, 0xe5, 0x69, 0x4c, 0xfe, 0x11, 0x3d, 0x3c, 0x7f, 0xe, 0xaa, 0xdb, 0x5, 0x2c, 0x4e, 0x8f, 0x1e, 0xde, 0xe2, 0xb0, 0x34");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineInfoKHR *, struct VkBaseOutStructure *)
  MAKE_CALLBACK_THUNK(callback_109, enum VkResult (struct VkDevice_T *, const struct VkPipelineInfoKHR *, struct VkBaseOutStructure *), "0xc2, 0x6e, 0x8a, 0xdf, 0x23, 0xdc, 0xac, 0x9a, 0x10, 0x97, 0x11, 0xde, 0x6e, 0x2, 0x76, 0xd, 0x53, 0x4d, 0x77, 0xda, 0xb6, 0x11, 0xb6, 0xfa, 0xd, 0xfd, 0x6a, 0x50, 0x4f, 0xfe, 0xfb, 0x74");
  // enum VkResult (struct VkDevice_T *, const struct VkMemoryGetRemoteAddressInfoNV *, void **)
  MAKE_CALLBACK_THUNK(callback_110, enum VkResult (struct VkDevice_T *, const struct VkMemoryGetRemoteAddressInfoNV *, void **), "0xf8, 0x56, 0xc6, 0xe5, 0x7, 0x8, 0x1d, 0xda, 0x6f, 0x59, 0x9c, 0x88, 0xa5, 0xfd, 0xde, 0x66, 0x1d, 0x51, 0x31, 0x94, 0xc7, 0xaa, 0x47, 0x41, 0x94, 0x7e, 0x48, 0x42, 0xac, 0x3a, 0x9, 0x56");
  // void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout)
  MAKE_CALLBACK_THUNK(callback_111, void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout), "0xdc, 0x47, 0x6f, 0xd, 0xf, 0xb0, 0x44, 0xf9, 0x4e, 0x16, 0xc7, 0x82, 0xf8, 0x20, 0x83, 0x48, 0x39, 0x23, 0xf9, 0x7, 0x8f, 0x5c, 0x24, 0xcc, 0xf6, 0xb4, 0xa6, 0x3b, 0x6f, 0x8b, 0x53, 0xbb");
  // enum VkResult (struct VkDevice_T *, unsigned long, struct VkExtent2D *)
  MAKE_CALLBACK_THUNK(callback_112, enum VkResult (struct VkDevice_T *, unsigned long, struct VkExtent2D *), "0x9e, 0x85, 0xac, 0xfd, 0x3b, 0xad, 0xbf, 0xe1, 0xeb, 0xf5, 0xe2, 0xaa, 0x14, 0x6d, 0x98, 0xcc, 0xd9, 0x85, 0x9, 0x23, 0xd0, 0x2e, 0x59, 0xbf, 0x3b, 0x31, 0xf5, 0x31, 0xf0, 0xef, 0xd, 0x86");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkVideoProfileInfoKHR *, struct VkVideoCapabilitiesKHR *)
  MAKE_CALLBACK_THUNK(callback_113, enum VkResult (struct VkPhysicalDevice_T *, const struct VkVideoProfileInfoKHR *, struct VkVideoCapabilitiesKHR *), "0x8d, 0x1c, 0x29, 0xed, 0x96, 0x38, 0xf6, 0x6, 0x88, 0x33, 0x80, 0x3d, 0xdd, 0xc7, 0x83, 0xb3, 0x8f, 0x48, 0x38, 0xd7, 0x89, 0xd0, 0x32, 0xfc, 0xd, 0xf2, 0xd0, 0x79, 0x2a, 0xa4, 0x60, 0xdd");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkSwapchainCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_114, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkSwapchainCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x58, 0xbd, 0x36, 0xe, 0x8d, 0x21, 0xbe, 0x80, 0xf0, 0x72, 0xe, 0x87, 0xc7, 0xef, 0xd9, 0x25, 0x3a, 0x27, 0xdd, 0xf0, 0x77, 0xec, 0xd9, 0xd8, 0x33, 0x9a, 0xc3, 0xb6, 0x41, 0xf0, 0x47, 0xb4");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int, struct VkDisplayPlaneCapabilitiesKHR *)
  MAKE_CALLBACK_THUNK(callback_115, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int, struct VkDisplayPlaneCapabilitiesKHR *), "0x48, 0x5f, 0x33, 0x32, 0x35, 0xaa, 0x4d, 0x55, 0xfd, 0x5d, 0x66, 0x40, 0x28, 0x19, 0x9, 0x47, 0x70, 0x3f, 0x12, 0xf3, 0x9d, 0x25, 0xe0, 0x79, 0xc4, 0xe5, 0x18, 0x79, 0x1e, 0xb7, 0x1d, 0x97");
  // void (struct VkDevice_T *)
  MAKE_CALLBACK_THUNK(callback_116, void (struct VkDevice_T *), "0xbc, 0xcd, 0x89, 0x29, 0x32, 0x32, 0xa3, 0x7b, 0x19, 0xef, 0x8f, 0x55, 0xa4, 0x8d, 0x73, 0xf2, 0x38, 0xd1, 0x89, 0x89, 0x58, 0xa8, 0xd7, 0x1, 0x52, 0xd7, 0xcf, 0xb7, 0xc2, 0xea, 0xa6, 0x80");
  // enum VkResult (struct VkPhysicalDevice_T *, struct _XDisplay *, unsigned long, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_117, enum VkResult (struct VkPhysicalDevice_T *, struct _XDisplay *, unsigned long, unsigned long *), "0x91, 0xd5, 0xd6, 0x2e, 0xb5, 0xa4, 0x38, 0x1c, 0x52, 0x8f, 0xd7, 0x6, 0x0, 0x52, 0x6, 0x9c, 0xe9, 0xe0, 0x80, 0x95, 0x19, 0x57, 0x28, 0x1c, 0xeb, 0x30, 0xc5, 0xab, 0xa, 0x74, 0xb4, 0x18");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int, const struct VkBufferCopy *)
  MAKE_CALLBACK_THUNK(callback_118, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int, const struct VkBufferCopy *), "0x89, 0x18, 0xae, 0x76, 0x2a, 0x38, 0x73, 0xba, 0x71, 0x76, 0xcb, 0x92, 0x36, 0xd5, 0x9a, 0xbd, 0x6e, 0xeb, 0x8d, 0x91, 0x94, 0x69, 0x71, 0x90, 0xed, 0x5c, 0xb0, 0x35, 0x5c, 0x30, 0x83, 0x84");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMicromapInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_120, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMicromapInfoEXT *), "0xf4, 0x76, 0xbb, 0xc8, 0xc, 0xf7, 0x2b, 0xe, 0x86, 0x68, 0xdc, 0x20, 0x23, 0xe0, 0x91, 0x5a, 0x25, 0x3, 0xd3, 0x0, 0xb0, 0x5, 0x27, 0x90, 0x8b, 0x5c, 0x9e, 0xdc, 0xb1, 0xd7, 0x7f, 0x5f");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_121, enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, unsigned long *), "0xd3, 0x57, 0x86, 0x18, 0xea, 0xe, 0xa7, 0x24, 0x5a, 0x37, 0x6, 0x1f, 0x3c, 0xbe, 0x24, 0x63, 0x5d, 0x80, 0x4a, 0x38, 0x87, 0x6d, 0x91, 0x8d, 0xe9, 0x60, 0xd5, 0xdd, 0x3, 0x97, 0x40, 0xe3");
  // enum VkResult (struct VkQueue_T *, unsigned int, const struct VkSubmitInfo *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_122, enum VkResult (struct VkQueue_T *, unsigned int, const struct VkSubmitInfo *, unsigned long), "0x78, 0xf3, 0x86, 0xcd, 0xb5, 0xc6, 0xd8, 0x35, 0xd7, 0x5, 0x2f, 0x23, 0xce, 0xc2, 0x69, 0x62, 0xba, 0x92, 0xe2, 0xb2, 0xbf, 0x33, 0x32, 0x89, 0xdf, 0xc2, 0xc5, 0xbd, 0x57, 0x23, 0x6c, 0xb");
  // enum VkResult (struct VkDevice_T *, const struct VkAcquireNextImageInfoKHR *, unsigned int *)
  MAKE_CALLBACK_THUNK(callback_123, enum VkResult (struct VkDevice_T *, const struct VkAcquireNextImageInfoKHR *, unsigned int *), "0x25, 0x72, 0x89, 0x99, 0x9d, 0x9e, 0x81, 0xd3, 0x72, 0xed, 0x50, 0xce, 0xc7, 0x1d, 0x95, 0xdc, 0xa9, 0x23, 0xa0, 0x65, 0x82, 0x2e, 0x45, 0xab, 0xc8, 0x24, 0xc7, 0xc6, 0x29, 0x51, 0xea, 0x6b");
  // void (struct VkInstance_T *, unsigned long, const struct VkAllocationCallbacks *)
  MAKE_CALLBACK_THUNK(callback_124, void (struct VkInstance_T *, unsigned long, const struct VkAllocationCallbacks *), "0xe1, 0x3b, 0xaa, 0x6a, 0xa7, 0x9a, 0x97, 0x11, 0x4f, 0x55, 0xd7, 0xf4, 0x5, 0x9f, 0x9c, 0x30, 0xd3, 0xb5, 0x77, 0xbf, 0x16, 0x7e, 0xa4, 0x73, 0x3f, 0x5e, 0x87, 0xbe, 0x8f, 0xff, 0x66, 0xc4");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceVideoFormatInfoKHR *, unsigned int *, struct VkVideoFormatPropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_125, enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceVideoFormatInfoKHR *, unsigned int *, struct VkVideoFormatPropertiesKHR *), "0xea, 0xbb, 0xdb, 0xa4, 0xb9, 0x91, 0x97, 0xde, 0xbd, 0x1c, 0x6f, 0xab, 0xc0, 0x67, 0x8b, 0x5b, 0xcf, 0x54, 0xe0, 0x22, 0x15, 0x74, 0xe5, 0x87, 0x39, 0xd2, 0x2d, 0x1a, 0x40, 0x26, 0x56, 0xec");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_126, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, unsigned long *), "0x5a, 0x9, 0x9d, 0xe7, 0xaa, 0x6, 0x1f, 0x5a, 0x93, 0xa2, 0xf8, 0x1a, 0x81, 0x20, 0x2a, 0xf3, 0x11, 0x90, 0x9e, 0xb8, 0xbd, 0x9a, 0xee, 0x84, 0x62, 0x11, 0xa1, 0x4e, 0xa, 0x7d, 0xec, 0xde");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const unsigned long *)
  MAKE_CALLBACK_THUNK(callback_127, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const unsigned long *), "0x4, 0x8e, 0x6b, 0xdd, 0x3e, 0x49, 0x8, 0x18, 0xe9, 0xcc, 0xb4, 0xc0, 0x4, 0x5a, 0x8, 0x7c, 0xa0, 0x7b, 0x60, 0x2b, 0xe0, 0x1c, 0x2d, 0x79, 0xb9, 0x92, 0xcc, 0x16, 0x98, 0x29, 0x1d, 0xce");
  // enum VkResult (struct VkDevice_T *, const struct VkSwapchainCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_128, enum VkResult (struct VkDevice_T *, const struct VkSwapchainCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x18, 0x91, 0xd9, 0x89, 0x7f, 0x71, 0xfe, 0xc5, 0x6d, 0x80, 0xd0, 0x6a, 0x79, 0xdc, 0x3f, 0xbb, 0xed, 0xe8, 0x96, 0xc3, 0xe, 0xe3, 0xfc, 0xaf, 0x69, 0x2b, 0x7b, 0xee, 0xb5, 0x82, 0x3e, 0x8a");
  // enum VkResult (struct VkDevice_T *, const struct VkSamplerCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_130, enum VkResult (struct VkDevice_T *, const struct VkSamplerCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xc2, 0xaa, 0x31, 0x73, 0xe6, 0x3a, 0xaa, 0xcd, 0xab, 0x46, 0xb7, 0x32, 0x3f, 0xde, 0xd7, 0xef, 0xfc, 0x20, 0x40, 0xa3, 0xe8, 0xe1, 0x85, 0x86, 0x44, 0x75, 0x27, 0x0, 0x8e, 0xe8, 0x75, 0x74");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, enum VkPresentModeKHR *)
  MAKE_CALLBACK_THUNK(callback_131, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, enum VkPresentModeKHR *), "0x1b, 0x7, 0xc5, 0xee, 0xec, 0x1e, 0x8d, 0x4d, 0xa0, 0x62, 0xf7, 0xfb, 0x39, 0x94, 0x69, 0x38, 0x6c, 0x97, 0x35, 0x90, 0x2, 0x89, 0xb7, 0x70, 0xe8, 0xc0, 0x51, 0x10, 0xf4, 0x37, 0x14, 0x63");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, struct VkSurfaceCapabilitiesKHR *)
  MAKE_CALLBACK_THUNK(callback_132, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, struct VkSurfaceCapabilitiesKHR *), "0x36, 0x8f, 0x75, 0xf6, 0x70, 0x9d, 0xc0, 0x9d, 0x30, 0xdc, 0x1a, 0x31, 0x44, 0x9c, 0x30, 0xce, 0x21, 0x9, 0x2d, 0x15, 0x16, 0x4b, 0x74, 0x25, 0x9, 0xa9, 0x75, 0x82, 0x8f, 0xc9, 0xc0, 0x58");
  // void (struct VkCommandBuffer_T *, const struct VkSubpassBeginInfo *, const struct VkSubpassEndInfo *)
  MAKE_CALLBACK_THUNK(callback_133, void (struct VkCommandBuffer_T *, const struct VkSubpassBeginInfo *, const struct VkSubpassEndInfo *), "0x7c, 0x67, 0xe3, 0x3b, 0x3f, 0x7e, 0xff, 0xc4, 0x3d, 0xd6, 0xcf, 0xf, 0xb6, 0xff, 0x25, 0x82, 0x25, 0x5e, 0x7c, 0x27, 0x38, 0xc0, 0x4b, 0x1a, 0x52, 0x9b, 0x39, 0xa4, 0xc9, 0x2b, 0xfc, 0x47");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkPhysicalDeviceToolProperties *)
  MAKE_CALLBACK_THUNK(callback_134, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkPhysicalDeviceToolProperties *), "0x54, 0x13, 0x2a, 0xf1, 0xbb, 0xb1, 0x50, 0xf5, 0x77, 0xa, 0x63, 0x66, 0x3, 0xf1, 0x2b, 0x56, 0x65, 0x66, 0xbc, 0x72, 0x25, 0x1c, 0x9d, 0x84, 0x78, 0xb4, 0x6e, 0xa, 0xfd, 0xff, 0x3d, 0xaf");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned long, unsigned int *)
  MAKE_CALLBACK_THUNK(callback_135, enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned long, unsigned int *), "0x2b, 0x4d, 0x33, 0x63, 0x6d, 0xe8, 0x98, 0x89, 0xd2, 0x4f, 0xa4, 0x86, 0xfe, 0xd1, 0x5b, 0xce, 0x3e, 0xff, 0x9, 0xa8, 0xaa, 0x5e, 0xae, 0xc4, 0xbd, 0xb8, 0xe7, 0x89, 0x16, 0x54, 0x5f, 0xe8");
  // void (struct VkCommandBuffer_T *, const struct VkRenderingInputAttachmentIndexInfo *)
  MAKE_CALLBACK_THUNK(callback_136, void (struct VkCommandBuffer_T *, const struct VkRenderingInputAttachmentIndexInfo *), "0xdf, 0xb4, 0xcb, 0x77, 0xde, 0xf5, 0xe1, 0xe6, 0x4d, 0x9f, 0xa8, 0x74, 0xa6, 0x5c, 0x2f, 0xe9, 0xe3, 0xbc, 0x5e, 0xd2, 0xb2, 0x5d, 0x31, 0x66, 0x1, 0x6f, 0xef, 0x19, 0xc0, 0x69, 0x6f, 0x3a");
  // void (struct VkCommandBuffer_T *, const struct VkRenderingAttachmentLocationInfo *)
  MAKE_CALLBACK_THUNK(callback_137, void (struct VkCommandBuffer_T *, const struct VkRenderingAttachmentLocationInfo *), "0x88, 0x7a, 0x4c, 0xa7, 0xc5, 0xbb, 0xf6, 0x8c, 0x31, 0xf8, 0xd2, 0x5, 0x71, 0x15, 0x12, 0xda, 0x6d, 0x28, 0xfb, 0x7, 0x83, 0x37, 0xf, 0x9f, 0xf9, 0xb0, 0xaf, 0xfc, 0x5b, 0x18, 0xad, 0x55");
  // void (struct VkCommandBuffer_T *)
  MAKE_CALLBACK_THUNK(callback_138, void (struct VkCommandBuffer_T *), "0xa2, 0x28, 0xfa, 0x5d, 0xf4, 0x6e, 0xa1, 0x33, 0x24, 0xc3, 0xbe, 0xe7, 0xa1, 0xc5, 0x9c, 0x91, 0x9a, 0x79, 0xae, 0xd1, 0x90, 0x30, 0x96, 0xaf, 0xe3, 0x9f, 0xbd, 0x5d, 0x62, 0x60, 0xfa, 0xd6");
  // void (struct VkCommandBuffer_T *, const struct VkSetDescriptorBufferOffsetsInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_139, void (struct VkCommandBuffer_T *, const struct VkSetDescriptorBufferOffsetsInfoEXT *), "0x9d, 0xe1, 0xbd, 0x9, 0xe5, 0xc9, 0x25, 0x10, 0xb3, 0xa7, 0x36, 0x6a, 0x4e, 0xfe, 0x96, 0xee, 0x31, 0x1a, 0xfe, 0x5, 0x7a, 0x41, 0x33, 0x42, 0xce, 0xf4, 0x96, 0x20, 0xba, 0xa0, 0xf3, 0xcc");
  // void (struct VkCommandBuffer_T *, const struct VkPushDescriptorSetInfo *)
  MAKE_CALLBACK_THUNK(callback_140, void (struct VkCommandBuffer_T *, const struct VkPushDescriptorSetInfo *), "0x18, 0x24, 0xa1, 0x35, 0x6d, 0xc5, 0x85, 0xff, 0x73, 0xf2, 0x5d, 0xef, 0xb1, 0xae, 0x53, 0x3f, 0xc6, 0xe, 0x83, 0x58, 0x33, 0xc2, 0x91, 0xd2, 0xdc, 0xdb, 0xa6, 0x73, 0x9f, 0x13, 0x72, 0x6");
  // void (struct VkDevice_T *, const struct VkDeviceImageMemoryRequirements *, unsigned int *, struct VkSparseImageMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_142, void (struct VkDevice_T *, const struct VkDeviceImageMemoryRequirements *, unsigned int *, struct VkSparseImageMemoryRequirements2 *), "0x65, 0x9c, 0x96, 0xba, 0x37, 0x51, 0x0, 0xe, 0xb5, 0xd9, 0x58, 0xca, 0x35, 0xef, 0x8b, 0xf8, 0x30, 0x90, 0x3f, 0x21, 0xec, 0x11, 0x1a, 0x64, 0xde, 0x46, 0xe2, 0xa1, 0x1c, 0x6a, 0xa4, 0x88");
  // enum VkResult (struct VkDevice_T *, const struct VkPerformanceConfigurationAcquireInfoINTEL *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_144, enum VkResult (struct VkDevice_T *, const struct VkPerformanceConfigurationAcquireInfoINTEL *, unsigned long *), "0xf, 0x2e, 0xe0, 0xf9, 0x4c, 0x8b, 0x62, 0x1e, 0x9e, 0x6f, 0xec, 0x86, 0x3e, 0xc5, 0x2, 0xd1, 0xd6, 0x3, 0x74, 0xb3, 0xe7, 0xd4, 0x7d, 0x56, 0x1f, 0xb8, 0xf4, 0x37, 0xa1, 0x36, 0x6d, 0xe");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkVertexInputBindingDescription2EXT *, unsigned int, const struct VkVertexInputAttributeDescription2EXT *)
  MAKE_CALLBACK_THUNK(callback_145, void (struct VkCommandBuffer_T *, unsigned int, const struct VkVertexInputBindingDescription2EXT *, unsigned int, const struct VkVertexInputAttributeDescription2EXT *), "0x50, 0x26, 0x1d, 0xda, 0xf3, 0xa3, 0xad, 0x67, 0x40, 0x5f, 0x2, 0x10, 0xf1, 0x8f, 0x3, 0xab, 0x78, 0x40, 0xe0, 0xde, 0xed, 0xd, 0xdd, 0x40, 0x9a, 0x16, 0x55, 0x17, 0xf1, 0xdc, 0xeb, 0xfb");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int, const void *)
  MAKE_CALLBACK_THUNK(callback_146, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned int, const void *), "0x9a, 0x91, 0xcf, 0xf6, 0xd2, 0xf3, 0x4, 0x4e, 0xc6, 0x2c, 0x82, 0xd1, 0x54, 0xf7, 0x14, 0x46, 0xa2, 0x7a, 0x13, 0x85, 0x92, 0xac, 0x1f, 0xda, 0x9d, 0x1c, 0xd7, 0xf5, 0x6b, 0x53, 0x6d, 0x8f");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkClearAttachment *, unsigned int, const struct VkClearRect *)
  MAKE_CALLBACK_THUNK(callback_147, void (struct VkCommandBuffer_T *, unsigned int, const struct VkClearAttachment *, unsigned int, const struct VkClearRect *), "0xc5, 0x96, 0x45, 0xcd, 0x10, 0xe5, 0x4d, 0x67, 0x45, 0x37, 0xc6, 0x3c, 0x95, 0x33, 0xad, 0xfc, 0xcd, 0xe9, 0x7e, 0xf7, 0x56, 0xe5, 0x6b, 0xc8, 0x2f, 0x59, 0x55, 0x48, 0x61, 0xb9, 0x60, 0x6c");
  // enum VkResult (struct VkDevice_T *, const struct VkDebugUtilsObjectNameInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_148, enum VkResult (struct VkDevice_T *, const struct VkDebugUtilsObjectNameInfoEXT *), "0xb5, 0x6, 0x56, 0xcd, 0x45, 0x2b, 0xf8, 0x70, 0x7b, 0x7c, 0x1e, 0xe7, 0x8, 0xbe, 0x9, 0xcd, 0x91, 0xb9, 0x56, 0x8a, 0xbe, 0x1, 0xf4, 0x7d, 0x65, 0x42, 0x5a, 0x6e, 0xae, 0xab, 0x75, 0xad");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkHostImageLayoutTransitionInfo *)
  MAKE_CALLBACK_THUNK(callback_149, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkHostImageLayoutTransitionInfo *), "0xbc, 0xb4, 0xc2, 0x12, 0x28, 0xfe, 0x73, 0x5f, 0x85, 0x10, 0x77, 0xfd, 0x62, 0x44, 0x1d, 0x7a, 0xab, 0xf2, 0x3b, 0x5d, 0x71, 0x18, 0x20, 0x22, 0x9d, 0x8e, 0xf4, 0xb5, 0x9c, 0xd4, 0xcf, 0x9f");
  // enum VkResult (struct VkDevice_T *, const struct VkMemoryMapInfo *, void **)
  MAKE_CALLBACK_THUNK(callback_150, enum VkResult (struct VkDevice_T *, const struct VkMemoryMapInfo *, void **), "0x8d, 0x19, 0xab, 0xae, 0x67, 0xe8, 0x16, 0xf2, 0xcc, 0x10, 0xb6, 0xaf, 0x3, 0x13, 0x2c, 0xeb, 0xf3, 0x1, 0x3c, 0x2, 0x82, 0xd7, 0x64, 0xdb, 0x75, 0x54, 0x42, 0xbb, 0xca, 0xea, 0x97, 0x70");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayPlanePropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_151, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayPlanePropertiesKHR *), "0x13, 0x5c, 0xdb, 0xf, 0x95, 0xc3, 0xba, 0xa4, 0x6f, 0xbe, 0xaf, 0xec, 0xb4, 0x33, 0xd, 0xe1, 0xf2, 0x48, 0xe, 0xf7, 0x42, 0x73, 0xe7, 0xac, 0xfa, 0x9b, 0x9, 0xa8, 0x60, 0x49, 0xf3, 0xd2");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, unsigned int, unsigned long, void *, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_152, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, unsigned int, unsigned long, void *, unsigned long, unsigned int), "0x37, 0x1b, 0xf8, 0x90, 0xd8, 0xd7, 0x9d, 0x71, 0x7a, 0x2a, 0x54, 0xa3, 0x77, 0x93, 0x95, 0x8d, 0xdf, 0x7f, 0xe6, 0xae, 0xa7, 0xc8, 0xd8, 0xc4, 0x9f, 0x46, 0xea, 0x8e, 0x39, 0x6d, 0xcc, 0x9d");
  // void (struct VkDevice_T *, const struct VkDeviceImageMemoryRequirements *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_154, void (struct VkDevice_T *, const struct VkDeviceImageMemoryRequirements *, struct VkMemoryRequirements2 *), "0x16, 0xd1, 0xbc, 0x93, 0x1c, 0xb3, 0xf1, 0x4, 0x36, 0xd4, 0x35, 0x78, 0x73, 0x62, 0x2f, 0xc6, 0xb1, 0xc4, 0x9f, 0x61, 0xc8, 0x12, 0x27, 0x3b, 0x1b, 0xa3, 0x41, 0xa, 0x75, 0x98, 0x53, 0x5");
  // void (struct VkCommandBuffer_T *, enum VkCompareOp)
  MAKE_CALLBACK_THUNK(callback_155, void (struct VkCommandBuffer_T *, enum VkCompareOp), "0xbb, 0xd0, 0x45, 0x13, 0x2c, 0xfb, 0x78, 0x50, 0x51, 0xe2, 0x66, 0x5f, 0xa2, 0xea, 0x51, 0xaf, 0xa1, 0x70, 0x3d, 0xe1, 0x10, 0x83, 0x7c, 0x16, 0xe2, 0x96, 0x46, 0x93, 0x42, 0x3b, 0x29, 0x2b");
  // void (struct VkCommandBuffer_T *, enum VkCoarseSampleOrderTypeNV, unsigned int, const struct VkCoarseSampleOrderCustomNV *)
  MAKE_CALLBACK_THUNK(callback_156, void (struct VkCommandBuffer_T *, enum VkCoarseSampleOrderTypeNV, unsigned int, const struct VkCoarseSampleOrderCustomNV *), "0xf9, 0x3e, 0x19, 0xe1, 0x3a, 0x12, 0x74, 0xbc, 0xf1, 0x9c, 0x27, 0x47, 0x8b, 0xb4, 0x62, 0x62, 0x6d, 0xa2, 0x94, 0x5d, 0xa1, 0xb1, 0x34, 0xc7, 0x70, 0x95, 0x58, 0x13, 0xde, 0x8c, 0xd, 0xf4");
  // enum VkResult (struct VkDevice_T *, const struct VkExternalComputeQueueCreateInfoNV *, const struct VkAllocationCallbacks *, struct VkExternalComputeQueueNV_T **)
  MAKE_CALLBACK_THUNK(callback_159, enum VkResult (struct VkDevice_T *, const struct VkExternalComputeQueueCreateInfoNV *, const struct VkAllocationCallbacks *, struct VkExternalComputeQueueNV_T **), "0xa2, 0xaf, 0x72, 0x81, 0x45, 0x20, 0x2c, 0xbc, 0x17, 0x88, 0xeb, 0x3a, 0x9a, 0xc9, 0x3d, 0xba, 0xf1, 0xf0, 0x6b, 0x2f, 0x7, 0xb, 0xf8, 0x3c, 0x56, 0xd9, 0x69, 0xd2, 0x61, 0x18, 0x57, 0x7");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned long *, const unsigned long *, const unsigned long *, const unsigned long *)
  MAKE_CALLBACK_THUNK(callback_160, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned long *, const unsigned long *, const unsigned long *, const unsigned long *), "0x3e, 0xb5, 0xe2, 0x8, 0xb9, 0x6f, 0x3b, 0x98, 0x71, 0xd3, 0x1c, 0xda, 0x16, 0x64, 0x6f, 0x7d, 0xc9, 0xcd, 0x7e, 0x60, 0x54, 0x2c, 0xde, 0x64, 0xb9, 0x90, 0x73, 0xb1, 0x49, 0xaf, 0xd0, 0xf7");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkBindVideoSessionMemoryInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_161, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkBindVideoSessionMemoryInfoKHR *), "0x2f, 0xab, 0x35, 0xf0, 0x8f, 0xeb, 0x6c, 0x9e, 0x2d, 0xc1, 0x53, 0x6b, 0xa6, 0x81, 0x61, 0xcc, 0x90, 0xb5, 0x50, 0xc9, 0x39, 0x38, 0xd5, 0xd5, 0x96, 0x78, 0x7, 0x6, 0x44, 0x56, 0xe5, 0xc9");
  // enum VkResult (struct VkInstance_T *, const struct VkHeadlessSurfaceCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_163, enum VkResult (struct VkInstance_T *, const struct VkHeadlessSurfaceCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0x68, 0x7f, 0xa6, 0x99, 0x12, 0x44, 0x6d, 0x25, 0x7f, 0x81, 0x97, 0xfc, 0x2, 0xd3, 0x75, 0xf4, 0xb0, 0x2c, 0x8b, 0xc, 0x9a, 0xa9, 0x3a, 0x52, 0xfe, 0xb, 0xd8, 0xf2, 0x9e, 0x27, 0x9f, 0x1b");
  // enum VkResult (struct VkDevice_T *, const struct VkDescriptorSetAllocateInfo *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_164, enum VkResult (struct VkDevice_T *, const struct VkDescriptorSetAllocateInfo *, unsigned long *), "0x17, 0xcc, 0xb8, 0xd4, 0xec, 0xaf, 0x19, 0x37, 0xe7, 0x83, 0x65, 0xdc, 0x58, 0x1f, 0x88, 0x64, 0xc4, 0x68, 0x63, 0xb9, 0xc0, 0xb1, 0x40, 0x35, 0xa5, 0xd6, 0x3d, 0xf8, 0xb3, 0xfc, 0xd0, 0x61");
  // enum VkResult (unsigned int *, struct VkLayerProperties *)
  MAKE_CALLBACK_THUNK(callback_165, enum VkResult (unsigned int *, struct VkLayerProperties *), "0xa4, 0xb5, 0x4a, 0x8a, 0x35, 0xee, 0x48, 0xc0, 0x80, 0x7f, 0x88, 0x44, 0x18, 0xd8, 0xf7, 0x77, 0xed, 0x64, 0xd1, 0x16, 0x9d, 0x7d, 0xdd, 0x87, 0xec, 0x60, 0x5, 0xd, 0x45, 0xab, 0xd4, 0x1a");
  // enum VkResult (struct VkDevice_T *, const struct VkMemoryUnmapInfo *)
  MAKE_CALLBACK_THUNK(callback_167, enum VkResult (struct VkDevice_T *, const struct VkMemoryUnmapInfo *), "0x5f, 0x6, 0x7, 0x10, 0xf2, 0x45, 0x49, 0xe3, 0x5c, 0xd0, 0x32, 0x3f, 0x33, 0x23, 0xea, 0xe2, 0x9d, 0x9, 0x89, 0x15, 0xbb, 0x32, 0x49, 0x5a, 0xa5, 0xf, 0xc8, 0xc4, 0x94, 0xaf, 0x14, 0xd8");
  // void (struct VkCommandBuffer_T *, unsigned long, const struct VkOpticalFlowExecuteInfoNV *)
  MAKE_CALLBACK_THUNK(callback_168, void (struct VkCommandBuffer_T *, unsigned long, const struct VkOpticalFlowExecuteInfoNV *), "0x1f, 0x3b, 0x28, 0x5f, 0xf1, 0xac, 0xae, 0xf3, 0x0, 0x61, 0xcb, 0xb7, 0x5a, 0x72, 0x30, 0x18, 0x6d, 0x6f, 0xa1, 0x2e, 0x75, 0xb2, 0xa, 0xfd, 0x6d, 0xdc, 0xab, 0x42, 0xf0, 0xd0, 0x9f, 0x86");
  // void (struct VkCommandBuffer_T *, const struct VkRenderingInfo *)
  MAKE_CALLBACK_THUNK(callback_169, void (struct VkCommandBuffer_T *, const struct VkRenderingInfo *), "0x9b, 0x61, 0x9f, 0x55, 0x43, 0xd7, 0x1, 0xb0, 0xb7, 0xdf, 0x56, 0x5f, 0xe5, 0xc5, 0xb4, 0xda, 0xe5, 0x50, 0x2, 0x83, 0x90, 0x90, 0x3b, 0x99, 0xd0, 0x5b, 0x3f, 0x7c, 0xc, 0x53, 0x4d, 0xf3");
  // void (struct VkCommandBuffer_T *, const struct VkResolveImageInfo2 *)
  MAKE_CALLBACK_THUNK(callback_170, void (struct VkCommandBuffer_T *, const struct VkResolveImageInfo2 *), "0x61, 0x40, 0xe9, 0x20, 0xfc, 0x9f, 0x75, 0x4e, 0x65, 0x6e, 0xbd, 0xce, 0x17, 0x42, 0x63, 0x66, 0x13, 0xd1, 0x56, 0x0, 0x42, 0x6f, 0x50, 0xf8, 0x9c, 0xdd, 0xd5, 0xfe, 0x85, 0xb7, 0x9b, 0x5b");
  // void (struct VkCommandBuffer_T *, unsigned int, const unsigned long *, const struct VkDependencyInfo *)
  MAKE_CALLBACK_THUNK(callback_171, void (struct VkCommandBuffer_T *, unsigned int, const unsigned long *, const struct VkDependencyInfo *), "0x59, 0x39, 0x17, 0xf9, 0xc4, 0x1a, 0xa4, 0x5, 0x9a, 0x5e, 0xe, 0xc0, 0x7e, 0xf2, 0x4, 0x8d, 0x58, 0x4f, 0x15, 0xdf, 0x7e, 0x75, 0xb2, 0xc2, 0xf2, 0x3c, 0x92, 0x79, 0xa1, 0x8c, 0x39, 0xaa");
  // void (struct VkCommandBuffer_T *, const struct VkCopyImageInfo2 *)
  MAKE_CALLBACK_THUNK(callback_172, void (struct VkCommandBuffer_T *, const struct VkCopyImageInfo2 *), "0xad, 0x76, 0x25, 0x17, 0xdf, 0x1b, 0xc4, 0x87, 0x79, 0x5b, 0x5b, 0x48, 0xe3, 0x42, 0xdc, 0x40, 0x48, 0x2f, 0xf6, 0x3f, 0xa5, 0x64, 0x8, 0x63, 0xfa, 0x82, 0x96, 0x6a, 0x2f, 0x40, 0x9b, 0x38");
  // void (struct VkDevice_T *, const struct VkBufferMemoryRequirementsInfo2 *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_173, void (struct VkDevice_T *, const struct VkBufferMemoryRequirementsInfo2 *, struct VkMemoryRequirements2 *), "0x7f, 0x81, 0xdb, 0x54, 0xf3, 0xab, 0x2b, 0x37, 0xed, 0x75, 0x93, 0x87, 0x98, 0xca, 0xbc, 0x3f, 0x6a, 0xea, 0x64, 0xc3, 0x12, 0x0, 0x80, 0x89, 0xac, 0x73, 0x80, 0x6d, 0x29, 0xb, 0xc9, 0xd2");
  // void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long)
  MAKE_CALLBACK_THUNK(callback_174, void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long), "0xd0, 0x85, 0x6d, 0x46, 0x23, 0xe4, 0x86, 0xfc, 0xa0, 0x7, 0xbf, 0x7c, 0xe9, 0x76, 0x47, 0x40, 0x93, 0x88, 0x10, 0x45, 0x42, 0x98, 0xec, 0x3c, 0x5c, 0x2b, 0x4b, 0xd5, 0x13, 0x7c, 0x2c, 0xb4");
  // void (struct VkCommandBuffer_T *, const struct VkCopyBufferInfo2 *)
  MAKE_CALLBACK_THUNK(callback_175, void (struct VkCommandBuffer_T *, const struct VkCopyBufferInfo2 *), "0x8d, 0x71, 0x52, 0xc6, 0x93, 0x2b, 0xa4, 0xa6, 0xda, 0x9a, 0x1e, 0xb, 0x4f, 0x70, 0xc, 0x98, 0x98, 0xa4, 0xcd, 0x81, 0x33, 0xa7, 0xf9, 0x16, 0xc1, 0x88, 0x69, 0xeb, 0x38, 0x16, 0x7, 0x30");
  // void (struct VkCommandBuffer_T *, const struct VkVideoEndCodingInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_176, void (struct VkCommandBuffer_T *, const struct VkVideoEndCodingInfoKHR *), "0x23, 0x94, 0xed, 0x9f, 0x17, 0x7d, 0x1f, 0xd7, 0xc1, 0x7d, 0xf3, 0x10, 0x8d, 0x8, 0x6d, 0x5d, 0xb, 0xf6, 0x33, 0x78, 0xf4, 0x26, 0xf1, 0x98, 0xa1, 0xe2, 0xe5, 0xde, 0x3, 0xc2, 0xf2, 0x9d");
  // void (struct VkDevice_T *, enum VkObjectType, unsigned long, unsigned long, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_177, void (struct VkDevice_T *, enum VkObjectType, unsigned long, unsigned long, unsigned long *), "0xe7, 0x91, 0x20, 0x8, 0x3b, 0x47, 0x52, 0x25, 0xae, 0x6c, 0xbc, 0x82, 0x6d, 0x69, 0x1, 0x7e, 0xd5, 0xfd, 0xee, 0xf5, 0xcf, 0xba, 0xb5, 0x3f, 0xf1, 0xb0, 0x24, 0x69, 0x79, 0xf9, 0x9c, 0xeb");
  // enum VkResult (struct VkDevice_T *, const struct VkCopyImageToImageInfo *)
  MAKE_CALLBACK_THUNK(callback_178, enum VkResult (struct VkDevice_T *, const struct VkCopyImageToImageInfo *), "0x6c, 0x1, 0xfa, 0x39, 0xa3, 0xbb, 0xd3, 0x82, 0x88, 0x6b, 0x35, 0x9d, 0x22, 0x80, 0x17, 0xfd, 0xa4, 0x10, 0x67, 0xac, 0xf8, 0x61, 0x99, 0x5f, 0xd0, 0xe8, 0xd9, 0xf5, 0x8f, 0xfe, 0xdb, 0x15");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned long, unsigned int, void **)
  MAKE_CALLBACK_THUNK(callback_179, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned long, unsigned int, void **), "0x6a, 0xe8, 0xec, 0x76, 0x8d, 0x35, 0x5c, 0xab, 0x54, 0x4c, 0x24, 0x26, 0xb3, 0x9e, 0x26, 0xbf, 0x71, 0xdd, 0x15, 0xd2, 0x93, 0x3, 0x45, 0xd6, 0x22, 0x6d, 0x5a, 0x62, 0x1c, 0xe8, 0x8f, 0x70");
  // enum VkResult (struct VkDevice_T *, const struct VkPrivateDataSlotCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_181, enum VkResult (struct VkDevice_T *, const struct VkPrivateDataSlotCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x6b, 0x94, 0x33, 0x2e, 0x11, 0x66, 0x83, 0x56, 0x40, 0x7e, 0x4d, 0x3f, 0x12, 0x44, 0xc1, 0x3d, 0x87, 0x73, 0x22, 0x83, 0xa1, 0x8e, 0x18, 0x3f, 0x1a, 0xe5, 0xec, 0xb0, 0x44, 0xd8, 0xdf, 0x8");
  // void (struct VkCommandBuffer_T *, const struct VkSubpassEndInfo *)
  MAKE_CALLBACK_THUNK(callback_182, void (struct VkCommandBuffer_T *, const struct VkSubpassEndInfo *), "0x2f, 0x71, 0x6d, 0x50, 0xdf, 0x7e, 0xf5, 0x51, 0x14, 0xe6, 0x63, 0x4f, 0xf, 0x42, 0x8e, 0x30, 0x9f, 0xfc, 0xaf, 0xc6, 0x7f, 0xd8, 0x87, 0x17, 0xca, 0xf6, 0x9c, 0x1c, 0xd5, 0xfd, 0x62, 0xb1");
  // void (struct VkCommandBuffer_T *, enum VkFragmentShadingRateNV, const enum VkFragmentShadingRateCombinerOpKHR *)
  MAKE_CALLBACK_THUNK(callback_184, void (struct VkCommandBuffer_T *, enum VkFragmentShadingRateNV, const enum VkFragmentShadingRateCombinerOpKHR *), "0xde, 0xfc, 0xd5, 0xee, 0xab, 0xd2, 0xbd, 0xc6, 0xf5, 0x9d, 0x79, 0x8c, 0x19, 0x1, 0x8b, 0xa6, 0xa4, 0x2f, 0x8e, 0xf6, 0xc7, 0x57, 0x1b, 0x1e, 0x6b, 0xdc, 0xdf, 0x20, 0x20, 0xbd, 0x1e, 0x19");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkSurfaceFormatKHR *)
  MAKE_CALLBACK_THUNK(callback_185, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkSurfaceFormatKHR *), "0xd7, 0x58, 0x69, 0xf7, 0x5a, 0xd8, 0x40, 0x56, 0x94, 0xcd, 0x93, 0x5c, 0x90, 0xe0, 0x83, 0x43, 0xbf, 0x7c, 0xd1, 0x0, 0xa0, 0x87, 0xc0, 0x91, 0xf3, 0x25, 0x78, 0xf, 0x88, 0xef, 0x98, 0xc7");
  // enum VkResult (struct VkCommandBuffer_T *, unsigned int)
  MAKE_CALLBACK_THUNK(callback_186, enum VkResult (struct VkCommandBuffer_T *, unsigned int), "0xea, 0x6, 0x6b, 0xee, 0x1e, 0x5c, 0xc3, 0x41, 0x6c, 0xdd, 0xb3, 0x38, 0x24, 0x67, 0xce, 0x71, 0x93, 0x77, 0x1f, 0xbd, 0x14, 0x32, 0xf1, 0x4a, 0x54, 0xd, 0x80, 0xfd, 0x73, 0x41, 0x3b, 0x9c");
  // void (struct VkCommandBuffer_T *, const struct VkRenderPassBeginInfo *, const struct VkSubpassBeginInfo *)
  MAKE_CALLBACK_THUNK(callback_187, void (struct VkCommandBuffer_T *, const struct VkRenderPassBeginInfo *, const struct VkSubpassBeginInfo *), "0xe3, 0xc9, 0x69, 0x31, 0x2f, 0xba, 0x76, 0xe7, 0xe5, 0x24, 0x0, 0xbf, 0x6b, 0x32, 0x42, 0xce, 0xb3, 0xe4, 0x62, 0xba, 0xc9, 0x76, 0xce, 0x43, 0xe3, 0xb0, 0x5a, 0xae, 0x9, 0x7f, 0x4, 0xa1");
  // enum VkResult (struct VkDevice_T *, const struct VkRenderPassCreateInfo2 *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_188, enum VkResult (struct VkDevice_T *, const struct VkRenderPassCreateInfo2 *, const struct VkAllocationCallbacks *, unsigned long *), "0x8d, 0x94, 0xe7, 0x5, 0xd5, 0x10, 0x19, 0xb7, 0xde, 0x5f, 0xa3, 0xdf, 0x54, 0xc6, 0x4c, 0xe2, 0xa5, 0x26, 0x75, 0x21, 0x83, 0x7d, 0xa3, 0x15, 0x85, 0x1e, 0xc6, 0xf0, 0xd0, 0x2a, 0xdf, 0x38");
  // unsigned long (struct VkDevice_T *, const struct VkDeviceMemoryOpaqueCaptureAddressInfo *)
  MAKE_CALLBACK_THUNK(callback_190, unsigned long (struct VkDevice_T *, const struct VkDeviceMemoryOpaqueCaptureAddressInfo *), "0xc2, 0x8a, 0xab, 0xab, 0x38, 0x3f, 0xd6, 0x7, 0xc9, 0xfd, 0x2d, 0x9c, 0xc7, 0xaa, 0x6d, 0xb, 0x9b, 0xac, 0xb0, 0xfe, 0x93, 0x2, 0xd2, 0x68, 0x34, 0xfa, 0x4e, 0xeb, 0x54, 0x1f, 0xea, 0x8c");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned int, const void *)
  MAKE_CALLBACK_THUNK(callback_191, void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned int, const void *), "0x43, 0xe9, 0xb6, 0x27, 0x41, 0xe0, 0x3a, 0x66, 0xa, 0x68, 0x9c, 0x88, 0xb6, 0xa0, 0xd9, 0xa8, 0xf4, 0xd, 0x7, 0x42, 0x50, 0xf2, 0xa0, 0x79, 0xf4, 0x4a, 0x45, 0x34, 0xcc, 0x1d, 0x74, 0xde");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, struct VkPerformanceCounterARM *, struct VkPerformanceCounterDescriptionARM *)
  MAKE_CALLBACK_THUNK(callback_192, enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, struct VkPerformanceCounterARM *, struct VkPerformanceCounterDescriptionARM *), "0x76, 0x46, 0x62, 0x4a, 0x2b, 0x99, 0x62, 0xa, 0xb5, 0xde, 0x17, 0xc3, 0x6a, 0xff, 0x2b, 0xf, 0x1b, 0xa6, 0x89, 0xed, 0xc9, 0x96, 0x1a, 0xfb, 0xa8, 0x6d, 0x6d, 0x69, 0xcb, 0x13, 0xe4, 0xb5");
  // unsigned long (struct VkDevice_T *, const struct VkBufferDeviceAddressInfo *)
  MAKE_CALLBACK_THUNK(callback_193, unsigned long (struct VkDevice_T *, const struct VkBufferDeviceAddressInfo *), "0xb8, 0x36, 0x62, 0xc, 0x8b, 0xc9, 0x4c, 0x36, 0xbd, 0xd5, 0x35, 0x14, 0xdb, 0xf, 0x9c, 0xa9, 0x41, 0xc9, 0xff, 0x5b, 0x7b, 0xae, 0xc7, 0xe, 0x9b, 0xf9, 0xc3, 0x4b, 0x52, 0x55, 0x81, 0x9f");
  // void (struct VkCommandBuffer_T *, enum VkFrontFace)
  MAKE_CALLBACK_THUNK(callback_194, void (struct VkCommandBuffer_T *, enum VkFrontFace), "0xa, 0x4c, 0x1e, 0x81, 0xe6, 0x3, 0x2f, 0x22, 0x5, 0x1b, 0x68, 0xa8, 0x7e, 0xba, 0x2, 0x45, 0x5e, 0x79, 0x24, 0x40, 0x14, 0x33, 0xd2, 0xf7, 0x54, 0x62, 0xe5, 0xd0, 0x8f, 0x30, 0xb, 0xb2");
  // enum VkResult (struct VkDevice_T *, const struct VkVideoSessionCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_195, enum VkResult (struct VkDevice_T *, const struct VkVideoSessionCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x89, 0x45, 0x53, 0xe0, 0x5c, 0x6, 0x4b, 0x8b, 0xe3, 0x3c, 0xa9, 0xcf, 0xfa, 0xed, 0x83, 0xc4, 0x7e, 0x1b, 0x79, 0xff, 0x7b, 0xc1, 0xe3, 0x33, 0xed, 0x9f, 0x28, 0xd9, 0x97, 0x0, 0xab, 0xaa");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, enum VkIndexType)
  MAKE_CALLBACK_THUNK(callback_196, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, enum VkIndexType), "0xb, 0xbc, 0x1e, 0x98, 0xf4, 0x2b, 0xb8, 0xd3, 0x89, 0x24, 0xe2, 0xf4, 0x65, 0x83, 0x9b, 0x5e, 0x16, 0x1b, 0x40, 0xff, 0xeb, 0x62, 0x6c, 0x95, 0xaa, 0xf9, 0x93, 0x26, 0x77, 0x7e, 0x8c, 0xa8");
  // enum VkResult (struct VkDevice_T *, const struct VkSemaphoreWaitInfo *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_197, enum VkResult (struct VkDevice_T *, const struct VkSemaphoreWaitInfo *, unsigned long), "0x45, 0xe2, 0xe9, 0xb3, 0x1a, 0x8, 0x99, 0xe, 0x1, 0x71, 0xed, 0xec, 0xa3, 0xd4, 0xc1, 0x18, 0x97, 0xa1, 0xab, 0xe, 0xf7, 0x5, 0x3, 0x4e, 0x4e, 0xce, 0x90, 0x8b, 0x5f, 0x58, 0x1b, 0x12");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_198, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long *), "0xd0, 0x36, 0xac, 0x67, 0x25, 0x4b, 0xb, 0xbf, 0x3b, 0x95, 0x3, 0x5b, 0xa6, 0x60, 0x5f, 0xd4, 0xbd, 0x8d, 0x83, 0xf7, 0x31, 0x71, 0xe1, 0x46, 0xc7, 0x5d, 0x38, 0x84, 0x95, 0x28, 0x3e, 0x8a");
  // enum VkResult (struct VkDevice_T *, const struct VkCopyMemoryToImageInfo *)
  MAKE_CALLBACK_THUNK(callback_199, enum VkResult (struct VkDevice_T *, const struct VkCopyMemoryToImageInfo *), "0x80, 0xc9, 0xf9, 0x3d, 0x4d, 0x9, 0x6c, 0x3d, 0xe2, 0x1d, 0x2c, 0xd8, 0x73, 0xc4, 0xc3, 0x6, 0x21, 0x6a, 0xe6, 0x2c, 0xa1, 0x49, 0x61, 0x9a, 0x80, 0x2b, 0xce, 0x6c, 0xd9, 0xc6, 0x74, 0x13");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayProperties2KHR *)
  MAKE_CALLBACK_THUNK(callback_200, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayProperties2KHR *), "0xda, 0x8d, 0x68, 0xec, 0xa1, 0x47, 0xf7, 0x5a, 0x72, 0x29, 0xd5, 0xc5, 0x31, 0xdf, 0xe9, 0x81, 0x4c, 0xe2, 0xe1, 0xbb, 0x61, 0xd0, 0x72, 0xb5, 0xf5, 0xb1, 0x6b, 0x7b, 0x4b, 0x3c, 0x9d, 0x86");
  // void (struct VkDevice_T *, unsigned long, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_201, void (struct VkDevice_T *, unsigned long, unsigned int, unsigned int), "0x7f, 0xc7, 0x15, 0x88, 0xea, 0xb3, 0x24, 0xfb, 0x1e, 0x41, 0x99, 0xda, 0xd3, 0x66, 0xf7, 0x8b, 0x99, 0x59, 0x58, 0x32, 0x2d, 0x51, 0x18, 0x5e, 0x39, 0xed, 0xe3, 0x67, 0x14, 0x46, 0x1f, 0x6f");
  // enum VkResult (struct VkDevice_T *, const struct VkSamplerYcbcrConversionCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_202, enum VkResult (struct VkDevice_T *, const struct VkSamplerYcbcrConversionCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x56, 0xdd, 0xa2, 0x1a, 0xf5, 0x9f, 0xb7, 0x9a, 0x2f, 0xfc, 0x64, 0x1d, 0x31, 0x41, 0x3e, 0xa3, 0xfa, 0xe8, 0xd1, 0xaa, 0x7d, 0x67, 0x6e, 0xb5, 0x58, 0x89, 0x21, 0x41, 0x45, 0x7b, 0x99, 0x35");
  // void (struct VkDevice_T *, const struct VkDescriptorSetLayoutCreateInfo *, struct VkDescriptorSetLayoutSupport *)
  MAKE_CALLBACK_THUNK(callback_203, void (struct VkDevice_T *, const struct VkDescriptorSetLayoutCreateInfo *, struct VkDescriptorSetLayoutSupport *), "0x6d, 0xec, 0xd5, 0x44, 0xcd, 0x81, 0xa7, 0xc4, 0x2, 0x78, 0x95, 0x33, 0xda, 0xa5, 0x87, 0xb5, 0x9d, 0xc8, 0x56, 0xda, 0x7e, 0xa3, 0xe2, 0x77, 0x5b, 0x11, 0xb3, 0xb7, 0xfe, 0xe1, 0xeb, 0xf1");
  // void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, enum VkImageLayout, unsigned int, const struct VkImageBlit *, enum VkFilter)
  MAKE_CALLBACK_THUNK(callback_204, void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, enum VkImageLayout, unsigned int, const struct VkImageBlit *, enum VkFilter), "0x8f, 0x23, 0xb7, 0x24, 0x7a, 0x4c, 0x51, 0xbb, 0x59, 0x42, 0x3d, 0x2a, 0x53, 0x6f, 0x57, 0xa6, 0x87, 0x40, 0x11, 0x56, 0xb7, 0xb7, 0x96, 0x67, 0xb7, 0x85, 0x82, 0x4a, 0x8c, 0xd2, 0xa4, 0x8");
  // enum VkResult (struct VkQueue_T *, unsigned int, const struct VkBindSparseInfo *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_205, enum VkResult (struct VkQueue_T *, unsigned int, const struct VkBindSparseInfo *, unsigned long), "0x8, 0xc, 0xac, 0xc6, 0xc2, 0x7a, 0xf, 0xf, 0x15, 0x14, 0x40, 0x19, 0x71, 0x89, 0x33, 0xc8, 0xaf, 0x83, 0x8c, 0x66, 0xdf, 0xfa, 0xfc, 0x9f, 0xf1, 0x3f, 0x11, 0xbd, 0xd3, 0x5a, 0x51, 0x4c");
  // void (struct VkDevice_T *, const struct VkDeviceQueueInfo2 *, struct VkQueue_T **)
  MAKE_CALLBACK_THUNK(callback_206, void (struct VkDevice_T *, const struct VkDeviceQueueInfo2 *, struct VkQueue_T **), "0x62, 0xc4, 0x1e, 0x6a, 0x1f, 0xd5, 0x5a, 0x4f, 0x62, 0x6e, 0xc0, 0xbb, 0x35, 0x4d, 0x9f, 0xde, 0x2a, 0x96, 0x37, 0x1f, 0x2b, 0xfe, 0x1f, 0x70, 0xf0, 0x7, 0x0, 0x78, 0xa5, 0x8e, 0xb0, 0x83");
  // void (struct VkDevice_T *, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_207, void (struct VkDevice_T *, unsigned long, unsigned int), "0xb6, 0xb7, 0x14, 0x3d, 0x56, 0xf6, 0x27, 0x6c, 0x46, 0xa9, 0x2b, 0x53, 0xf6, 0x69, 0xd8, 0x36, 0x5d, 0xaa, 0x91, 0x70, 0xd3, 0x9f, 0xbe, 0x4f, 0xef, 0xe8, 0xa9, 0x55, 0x8e, 0x4c, 0xdc, 0xfe");
  // void (struct VkDevice_T *, const struct VkDeviceBufferMemoryRequirements *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_209, void (struct VkDevice_T *, const struct VkDeviceBufferMemoryRequirements *, struct VkMemoryRequirements2 *), "0x33, 0xe9, 0x6f, 0x24, 0xde, 0x7f, 0x9e, 0x19, 0xbb, 0xc1, 0x3b, 0xd9, 0x2e, 0xca, 0xc3, 0x78, 0xec, 0x5a, 0x19, 0x45, 0x87, 0x36, 0x73, 0xcf, 0x92, 0xc5, 0x29, 0x76, 0x1b, 0x27, 0xc5, 0x8c");
  // void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalFenceInfo *, struct VkExternalFenceProperties *)
  MAKE_CALLBACK_THUNK(callback_210, void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalFenceInfo *, struct VkExternalFenceProperties *), "0x4f, 0x41, 0xaa, 0x1, 0x73, 0x25, 0xe, 0x75, 0x6c, 0x4d, 0xe0, 0xca, 0x6e, 0x50, 0xba, 0x12, 0xf5, 0xf1, 0x7b, 0xa2, 0x41, 0xe2, 0x70, 0x7b, 0xe2, 0x83, 0x57, 0x66, 0xd0, 0x10, 0x6d, 0x2d");
  // enum VkResult (struct VkDevice_T *, const struct VkSemaphoreSignalInfo *)
  MAKE_CALLBACK_THUNK(callback_211, enum VkResult (struct VkDevice_T *, const struct VkSemaphoreSignalInfo *), "0x11, 0xec, 0x5f, 0x51, 0x4b, 0xd4, 0xe, 0xbf, 0x6, 0x76, 0x27, 0x73, 0x22, 0x87, 0x4f, 0x77, 0xf2, 0xf, 0xf6, 0x80, 0xa0, 0x8d, 0x0, 0x47, 0x40, 0x3a, 0x1, 0x7a, 0xf3, 0x88, 0xc0, 0xe0");
  // void (struct VkPhysicalDevice_T *, enum VkFormat, struct VkFormatProperties2 *)
  MAKE_CALLBACK_THUNK(callback_212, void (struct VkPhysicalDevice_T *, enum VkFormat, struct VkFormatProperties2 *), "0xea, 0x1d, 0x95, 0x28, 0x92, 0x1d, 0xb2, 0x1, 0xe5, 0xa0, 0x88, 0x6b, 0xa3, 0xba, 0x1, 0xc9, 0xc, 0xb0, 0xb2, 0x1b, 0x5c, 0x76, 0xbd, 0xc6, 0x44, 0x96, 0x81, 0x4d, 0x84, 0x1b, 0x84, 0xde");
  // enum VkResult (struct VkQueue_T *, const struct VkPresentInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_213, enum VkResult (struct VkQueue_T *, const struct VkPresentInfoKHR *), "0x1f, 0x22, 0xe6, 0x6e, 0xd5, 0x95, 0xba, 0xd3, 0x48, 0xa3, 0xed, 0x17, 0xc, 0xea, 0x4c, 0x6c, 0x2a, 0x43, 0x9f, 0xb3, 0x1a, 0x3d, 0x51, 0xd2, 0x78, 0x50, 0xcc, 0x3c, 0x74, 0xf6, 0x7a, 0x1e");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkRayTracingPipelineCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_215, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkRayTracingPipelineCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *), "0x20, 0x48, 0x4d, 0xde, 0xf6, 0x1, 0x4c, 0x4c, 0x4f, 0x6d, 0x2b, 0x85, 0x3a, 0x69, 0x8f, 0x8a, 0x3b, 0xb6, 0xdd, 0xf6, 0xf2, 0x23, 0x13, 0x1e, 0xc4, 0x45, 0xda, 0xc8, 0x11, 0xc3, 0x33, 0xf0");
  // unsigned int (struct VkPhysicalDevice_T *, unsigned int, struct xcb_connection_t *, unsigned int)
  MAKE_CALLBACK_THUNK(callback_216, unsigned int (struct VkPhysicalDevice_T *, unsigned int, struct xcb_connection_t *, unsigned int), "0x1c, 0x79, 0x60, 0xa9, 0x80, 0x66, 0x37, 0x82, 0x2, 0xc6, 0x3c, 0x44, 0x5f, 0xde, 0x16, 0x29, 0x5e, 0x3, 0x32, 0x3b, 0x15, 0x80, 0x8e, 0xd4, 0x84, 0x95, 0x10, 0xb, 0x62, 0xdf, 0xaf, 0x5f");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkCalibratedTimestampInfoKHR *, unsigned long *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_217, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkCalibratedTimestampInfoKHR *, unsigned long *, unsigned long *), "0xb4, 0xf2, 0xda, 0x49, 0x78, 0xb3, 0xed, 0xba, 0xeb, 0x83, 0xee, 0xf4, 0xfa, 0x58, 0x75, 0x7f, 0xfd, 0x4f, 0x78, 0x1a, 0x37, 0x67, 0xac, 0x8, 0xbf, 0x5b, 0x4, 0x52, 0x84, 0x36, 0x30, 0xa4");
  // void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceProperties2 *)
  MAKE_CALLBACK_THUNK(callback_218, void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceProperties2 *), "0x9d, 0xc8, 0x12, 0x65, 0xbe, 0x8c, 0xdd, 0x30, 0xbd, 0x2e, 0xde, 0xc2, 0x7b, 0x22, 0xcd, 0x23, 0xa9, 0xcd, 0xa5, 0x8d, 0x57, 0xad, 0xf8, 0xdf, 0x96, 0x8c, 0x69, 0xeb, 0x25, 0x96, 0xcb, 0xcd");
  // void (struct VkDevice_T *, const struct VkClusterAccelerationStructureInputInfoNV *, struct VkAccelerationStructureBuildSizesInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_219, void (struct VkDevice_T *, const struct VkClusterAccelerationStructureInputInfoNV *, struct VkAccelerationStructureBuildSizesInfoKHR *), "0xd5, 0xf4, 0x8e, 0x3, 0x15, 0x6a, 0xa3, 0x22, 0x99, 0x10, 0x5e, 0xb8, 0xc6, 0x51, 0x73, 0xc, 0x65, 0x6, 0x23, 0xcc, 0x86, 0xbc, 0xd3, 0x45, 0xe8, 0xd1, 0x60, 0x4e, 0x47, 0x13, 0xd8, 0x40");
  // void (struct VkDevice_T *, const struct VkImageSparseMemoryRequirementsInfo2 *, unsigned int *, struct VkSparseImageMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_220, void (struct VkDevice_T *, const struct VkImageSparseMemoryRequirementsInfo2 *, unsigned int *, struct VkSparseImageMemoryRequirements2 *), "0x2a, 0xf3, 0xee, 0x72, 0x3, 0x18, 0xea, 0xd6, 0x6e, 0x70, 0x67, 0xf1, 0xc8, 0xc8, 0x2a, 0x6c, 0xe, 0x6d, 0x50, 0x4e, 0xc1, 0x9e, 0x6c, 0x1f, 0x4a, 0x20, 0x95, 0xe5, 0x7b, 0xdb, 0x5b, 0xee");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkDisplayPowerInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_221, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkDisplayPowerInfoEXT *), "0xd6, 0xc9, 0xba, 0x72, 0x69, 0xb3, 0xb6, 0x61, 0x93, 0x3a, 0xd2, 0xf5, 0x8b, 0x7d, 0x4f, 0x4, 0x1a, 0x10, 0xd7, 0x7b, 0x45, 0xde, 0x35, 0xda, 0x14, 0x7d, 0x89, 0xd, 0x8f, 0x83, 0x99, 0xe5");
  // void (struct VkDevice_T *, unsigned int, unsigned int, unsigned int, unsigned int *)
  MAKE_CALLBACK_THUNK(callback_223, void (struct VkDevice_T *, unsigned int, unsigned int, unsigned int, unsigned int *), "0xa6, 0x8c, 0x50, 0xa3, 0x9c, 0x57, 0xd8, 0xe0, 0xe6, 0x31, 0x2c, 0xa8, 0xf3, 0xbe, 0xd0, 0x95, 0xf6, 0x50, 0xad, 0xb3, 0xbd, 0x45, 0x55, 0xb7, 0x61, 0xb1, 0x48, 0x3, 0x35, 0x6f, 0xec, 0xf6");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindImageMemoryInfo *)
  MAKE_CALLBACK_THUNK(callback_224, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindImageMemoryInfo *), "0x11, 0x2f, 0x8b, 0xf9, 0x1b, 0xac, 0x2e, 0xec, 0x2e, 0xc7, 0xe2, 0xf9, 0xdf, 0x58, 0xe2, 0x62, 0x3d, 0x94, 0x80, 0x15, 0xa2, 0x2a, 0x75, 0xc3, 0x15, 0x47, 0x3d, 0xae, 0xf6, 0xea, 0x81, 0x76");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindBufferMemoryInfo *)
  MAKE_CALLBACK_THUNK(callback_225, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindBufferMemoryInfo *), "0xf0, 0xcd, 0x7b, 0x1d, 0x8, 0xcb, 0x21, 0x86, 0xa4, 0x8, 0xe1, 0x6c, 0xab, 0x2, 0xc8, 0xe5, 0x8e, 0x71, 0x8, 0xa8, 0x1c, 0xde, 0xe7, 0x7e, 0xe1, 0x4f, 0xbb, 0xd8, 0x2, 0xdb, 0x87, 0x1f");
  // void (struct VkCommandBuffer_T *, const struct VkPushConstantsInfo *)
  MAKE_CALLBACK_THUNK(callback_226, void (struct VkCommandBuffer_T *, const struct VkPushConstantsInfo *), "0xe0, 0xf2, 0x4e, 0x21, 0x69, 0x37, 0xe1, 0x95, 0xfc, 0xdc, 0xfd, 0x1f, 0xff, 0x1a, 0xd7, 0xc5, 0xc3, 0x17, 0x7b, 0xed, 0xdf, 0xbf, 0x15, 0xbd, 0xf0, 0x5e, 0xc, 0x71, 0x75, 0x6c, 0x1, 0x3");
  // enum VkResult (struct VkCommandBuffer_T *, const struct VkPerformanceStreamMarkerInfoINTEL *)
  MAKE_CALLBACK_THUNK(callback_227, enum VkResult (struct VkCommandBuffer_T *, const struct VkPerformanceStreamMarkerInfoINTEL *), "0xa7, 0xf5, 0x31, 0xa2, 0x9c, 0xc3, 0x15, 0x41, 0x77, 0x7d, 0x36, 0x1f, 0x15, 0xc6, 0x1, 0xf6, 0xc9, 0xd2, 0xff, 0xa4, 0xb3, 0x75, 0x71, 0xc1, 0xc2, 0xf6, 0x97, 0xa4, 0x7, 0x4a, 0xf2, 0xe9");
  // enum VkResult (unsigned int *)
  MAKE_CALLBACK_THUNK(callback_228, enum VkResult (unsigned int *), "0x7a, 0x3e, 0xdd, 0xa9, 0x3c, 0x28, 0x2d, 0x5, 0xd1, 0x74, 0xb3, 0x20, 0x85, 0x6e, 0xf, 0x48, 0xbc, 0xff, 0xe5, 0x52, 0x81, 0x47, 0xa0, 0xb1, 0xec, 0x73, 0x8c, 0x8a, 0x4a, 0xd2, 0xad, 0xb9");
  // void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalSemaphoreInfo *, struct VkExternalSemaphoreProperties *)
  MAKE_CALLBACK_THUNK(callback_229, void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalSemaphoreInfo *, struct VkExternalSemaphoreProperties *), "0xe4, 0x8a, 0x2d, 0xc7, 0x29, 0x54, 0x79, 0xa5, 0x8b, 0x54, 0xf7, 0x75, 0x6d, 0x80, 0x2d, 0x8b, 0xa, 0x8d, 0x23, 0x28, 0x11, 0x33, 0x1d, 0xc5, 0x3c, 0x54, 0x1f, 0x2f, 0xab, 0xe7, 0x4, 0xbd");
  // void (struct VkCommandBuffer_T *, enum VkSubpassContents)
  MAKE_CALLBACK_THUNK(callback_230, void (struct VkCommandBuffer_T *, enum VkSubpassContents), "0xe1, 0xd9, 0x37, 0xe5, 0x13, 0xde, 0xfc, 0x8a, 0xd, 0x18, 0xc3, 0xcc, 0x70, 0x1, 0xe8, 0xe6, 0xe, 0xa7, 0x3e, 0x87, 0x74, 0xdc, 0x6, 0xb7, 0xb3, 0x12, 0x2d, 0xee, 0x29, 0x50, 0x27, 0xf7");
  // enum VkResult (struct VkDevice_T *, unsigned int, const unsigned long *, unsigned int, unsigned long)
  MAKE_CALLBACK_THUNK(callback_231, enum VkResult (struct VkDevice_T *, unsigned int, const unsigned long *, unsigned int, unsigned long), "0xee, 0x87, 0x23, 0x3d, 0x4c, 0x41, 0x9a, 0xd1, 0xf2, 0x25, 0xf, 0x7e, 0xdb, 0x76, 0x8, 0x6e, 0xf4, 0x24, 0xba, 0x15, 0x4e, 0xb6, 0xa7, 0x71, 0x3f, 0x8b, 0x81, 0x9b, 0xf1, 0x42, 0x29, 0xa1");
  // void (struct VkCommandBuffer_T *, const struct VkSampleLocationsInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_232, void (struct VkCommandBuffer_T *, const struct VkSampleLocationsInfoEXT *), "0xf9, 0xe3, 0xd, 0x93, 0xdf, 0xe8, 0x82, 0xdf, 0x42, 0x26, 0x7b, 0x7b, 0x31, 0x2a, 0xfa, 0x50, 0x8a, 0x6a, 0x6d, 0xb6, 0x46, 0x4, 0xc0, 0xfb, 0xb6, 0xe2, 0x51, 0xb, 0xcd, 0x6a, 0xbb, 0x61");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_233, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, unsigned int), "0xb7, 0x66, 0x57, 0x18, 0xff, 0x5b, 0x64, 0x7c, 0x7f, 0xca, 0x71, 0x87, 0xf1, 0x1b, 0x2a, 0x34, 0xe2, 0x2b, 0x77, 0x92, 0x46, 0xdf, 0x23, 0xd4, 0xba, 0x42, 0x2b, 0x61, 0x71, 0x1, 0x3c, 0x3a");
  // void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, enum VkImageLayout, unsigned int, const struct VkImageResolve *)
  MAKE_CALLBACK_THUNK(callback_234, void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, enum VkImageLayout, unsigned int, const struct VkImageResolve *), "0x8c, 0x73, 0xa0, 0xfa, 0xcb, 0xc4, 0xfd, 0x26, 0x78, 0xc8, 0x1f, 0xae, 0x7a, 0xdf, 0xcb, 0x85, 0xe0, 0xfd, 0x81, 0x81, 0x5a, 0xcf, 0x78, 0x9e, 0xa1, 0x16, 0xf7, 0x89, 0xa5, 0x5, 0xd5, 0x6b");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineExecutableInfoKHR *, unsigned int *, struct VkPipelineExecutableStatisticKHR *)
  MAKE_CALLBACK_THUNK(callback_235, enum VkResult (struct VkDevice_T *, const struct VkPipelineExecutableInfoKHR *, unsigned int *, struct VkPipelineExecutableStatisticKHR *), "0xae, 0x7, 0x4b, 0xe4, 0x4c, 0x18, 0xd0, 0x41, 0xff, 0x27, 0x37, 0xd6, 0xa7, 0xca, 0xa, 0x70, 0x3a, 0xde, 0x93, 0x92, 0x53, 0xa1, 0xb1, 0xb0, 0x5b, 0xf7, 0xdd, 0xfd, 0x6d, 0xdc, 0x6a, 0x47");
  // void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, const struct VkClearDepthStencilValue *, unsigned int, const struct VkImageSubresourceRange *)
  MAKE_CALLBACK_THUNK(callback_236, void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, const struct VkClearDepthStencilValue *, unsigned int, const struct VkImageSubresourceRange *), "0x90, 0xb6, 0xca, 0x3b, 0x82, 0x97, 0xa3, 0xc3, 0xe7, 0x9b, 0x8f, 0x82, 0x40, 0x6, 0x88, 0x3f, 0x40, 0x35, 0x5e, 0x9f, 0x45, 0x63, 0x68, 0x5d, 0xcd, 0x60, 0xa3, 0xa1, 0xed, 0x16, 0x94, 0x8b");
  // void (struct VkCommandBuffer_T *, const struct VkPushDescriptorSetWithTemplateInfo *)
  MAKE_CALLBACK_THUNK(callback_237, void (struct VkCommandBuffer_T *, const struct VkPushDescriptorSetWithTemplateInfo *), "0x6e, 0x1e, 0x2e, 0x4f, 0x3c, 0x95, 0x8f, 0xa1, 0xeb, 0x3d, 0x9c, 0xd0, 0xa7, 0xa1, 0x61, 0x94, 0x10, 0x0, 0xdf, 0x68, 0x93, 0x9a, 0xa9, 0x7f, 0x32, 0x41, 0x71, 0x48, 0x45, 0x1e, 0x47, 0xf0");
  // enum VkResult (struct VkDevice_T *, unsigned long, enum VkOpticalFlowSessionBindingPointNV, unsigned long, enum VkImageLayout)
  MAKE_CALLBACK_THUNK(callback_238, enum VkResult (struct VkDevice_T *, unsigned long, enum VkOpticalFlowSessionBindingPointNV, unsigned long, enum VkImageLayout), "0x8f, 0x9c, 0xf1, 0xc, 0xe, 0x62, 0x86, 0x17, 0xc6, 0xcb, 0xf9, 0xd9, 0xd, 0x7b, 0x2c, 0xd4, 0x71, 0x1e, 0xdf, 0x3c, 0x43, 0xec, 0xe0, 0x3b, 0x2e, 0x85, 0x2, 0x40, 0x45, 0xc5, 0x4a, 0x62");
  // enum VkResult (struct VkDevice_T *, const struct VkReleaseCapturedPipelineDataInfoKHR *, const struct VkAllocationCallbacks *)
  MAKE_CALLBACK_THUNK(callback_240, enum VkResult (struct VkDevice_T *, const struct VkReleaseCapturedPipelineDataInfoKHR *, const struct VkAllocationCallbacks *), "0x72, 0x8b, 0x8b, 0x7, 0x2c, 0x5, 0xb2, 0x49, 0xd8, 0x35, 0xf3, 0x1b, 0x50, 0xcc, 0xcc, 0x59, 0x1c, 0x1a, 0x49, 0x8c, 0xeb, 0xe1, 0xba, 0xa2, 0x34, 0xa6, 0x14, 0x70, 0xba, 0x78, 0xce, 0x21");
  // void (struct VkCommandBuffer_T *, const struct VkCopyAccelerationStructureInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_242, void (struct VkCommandBuffer_T *, const struct VkCopyAccelerationStructureInfoKHR *), "0xad, 0x15, 0xbe, 0x56, 0xf7, 0x4a, 0x95, 0x77, 0x72, 0x48, 0x47, 0x57, 0xc1, 0x6a, 0x10, 0xd4, 0xce, 0xbc, 0x7b, 0x3f, 0x6d, 0x10, 0x73, 0x9, 0x69, 0x30, 0x26, 0x9c, 0xa3, 0x53, 0x14, 0x52");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned long, unsigned long, unsigned int *)
  MAKE_CALLBACK_THUNK(callback_244, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned long, unsigned long, unsigned int *), "0x8d, 0x93, 0x8c, 0x4e, 0x8b, 0x3e, 0x62, 0x3c, 0x72, 0x85, 0x12, 0x4d, 0x98, 0xdc, 0x68, 0x88, 0xfb, 0x1a, 0xf3, 0xca, 0xc7, 0xd4, 0xca, 0xed, 0xe6, 0xbf, 0x11, 0x12, 0xfd, 0x47, 0x91, 0xce");
  // void (struct VkDevice_T *, const struct VkImageMemoryRequirementsInfo2 *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_245, void (struct VkDevice_T *, const struct VkImageMemoryRequirementsInfo2 *, struct VkMemoryRequirements2 *), "0x43, 0xbf, 0x7d, 0x5, 0x40, 0x2e, 0x22, 0x8c, 0x7e, 0xe, 0x9, 0x36, 0xde, 0x83, 0xf7, 0x6e, 0x75, 0x4c, 0xa4, 0xa7, 0x7b, 0xe3, 0x12, 0xad, 0x59, 0xe5, 0x8d, 0xb0, 0xcb, 0xc0, 0xec, 0x80");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned long)
  MAKE_CALLBACK_THUNK(callback_246, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, unsigned long), "0x6a, 0x13, 0x36, 0x83, 0x2b, 0x78, 0xba, 0x24, 0xb8, 0xa1, 0x91, 0xee, 0x0, 0xc8, 0x28, 0x6f, 0x7e, 0x2, 0xcc, 0x60, 0xee, 0x2e, 0x87, 0xee, 0x9b, 0xb4, 0x8a, 0xb6, 0x8e, 0xb8, 0x56, 0xfc");
  // void (struct VkDevice_T *, unsigned long, unsigned int, struct VkCommandBuffer_T *const *)
  MAKE_CALLBACK_THUNK(callback_247, void (struct VkDevice_T *, unsigned long, unsigned int, struct VkCommandBuffer_T *const *), "0x4b, 0x15, 0x33, 0xe, 0xc5, 0x6a, 0x6f, 0x2, 0x15, 0x53, 0xf3, 0xdc, 0x92, 0x1a, 0xc2, 0xf3, 0xfa, 0xa7, 0xc7, 0xc7, 0x8c, 0xd5, 0x45, 0xb9, 0xec, 0x44, 0x1d, 0x1e, 0x4b, 0x6e, 0xf, 0xce");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkGeneratedCommandsInfoNV *)
  MAKE_CALLBACK_THUNK(callback_249, void (struct VkCommandBuffer_T *, unsigned int, const struct VkGeneratedCommandsInfoNV *), "0x1d, 0x42, 0x26, 0xe6, 0x7c, 0xff, 0xa3, 0xe3, 0x3c, 0xbe, 0x8e, 0xfd, 0x44, 0xfa, 0x71, 0xda, 0xb9, 0x74, 0x5d, 0xa, 0x76, 0x62, 0xc1, 0x7a, 0xc6, 0x76, 0xac, 0x12, 0xfa, 0xd9, 0xa3, 0xeb");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned short)
  MAKE_CALLBACK_THUNK(callback_253, void (struct VkCommandBuffer_T *, unsigned int, unsigned short), "0x9, 0xcf, 0x38, 0x2e, 0xf5, 0xf9, 0x9d, 0x30, 0xb1, 0xfc, 0xd, 0xbf, 0x17, 0xc2, 0x8b, 0x3a, 0x5c, 0x9b, 0xd4, 0x84, 0x3b, 0xd, 0x9c, 0xc8, 0x98, 0xc0, 0x2a, 0x9d, 0x7e, 0x18, 0x78, 0x52");
  // void (struct VkDevice_T *, unsigned long, unsigned int, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_254, void (struct VkDevice_T *, unsigned long, unsigned int, unsigned long *), "0x89, 0x33, 0xec, 0x46, 0x13, 0xa3, 0x7a, 0x58, 0x19, 0x12, 0xe8, 0xe2, 0xb7, 0xb7, 0xb5, 0x93, 0x93, 0xee, 0x9b, 0xe8, 0xbf, 0x12, 0x54, 0x38, 0xeb, 0x6a, 0x7b, 0x8e, 0xcf, 0x17, 0x63, 0x95");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_255, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int), "0xbc, 0x63, 0x4c, 0xc1, 0xdc, 0x88, 0x61, 0xcb, 0xb, 0x24, 0x29, 0x79, 0xdb, 0xa5, 0x26, 0x75, 0x83, 0xe9, 0xb1, 0xa0, 0xe7, 0xc2, 0x51, 0x88, 0x97, 0x6a, 0x14, 0xf4, 0x73, 0x4e, 0x3d, 0xef");
  // void (struct VkDevice_T *, unsigned long, unsigned int *, struct VkSparseImageMemoryRequirements *)
  MAKE_CALLBACK_THUNK(callback_256, void (struct VkDevice_T *, unsigned long, unsigned int *, struct VkSparseImageMemoryRequirements *), "0x77, 0x90, 0x87, 0x5e, 0x41, 0xef, 0x3e, 0xd0, 0xe1, 0xc0, 0x98, 0x6, 0x2b, 0xfc, 0xdd, 0xf2, 0x98, 0xab, 0x58, 0x1f, 0xc4, 0xfd, 0x7a, 0xca, 0xe9, 0x6, 0x25, 0xb9, 0xfb, 0x77, 0xf9, 0x9d");
  // void (struct VkDevice_T *, unsigned long, const struct VkImageSubresource *, struct VkSubresourceLayout *)
  MAKE_CALLBACK_THUNK(callback_257, void (struct VkDevice_T *, unsigned long, const struct VkImageSubresource *, struct VkSubresourceLayout *), "0x8c, 0x44, 0x4f, 0xa0, 0x54, 0x3a, 0x9, 0x6d, 0xcb, 0x38, 0x86, 0xf2, 0xfb, 0x7e, 0xab, 0x65, 0x7c, 0x6a, 0xe8, 0x5a, 0xdd, 0x43, 0x90, 0x56, 0x8b, 0x75, 0x23, 0xfa, 0xa2, 0x90, 0xf7, 0xaf");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkMultiDrawInfoEXT *, unsigned int, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_258, void (struct VkCommandBuffer_T *, unsigned int, const struct VkMultiDrawInfoEXT *, unsigned int, unsigned int, unsigned int), "0x4a, 0x80, 0x94, 0x3f, 0x86, 0x5a, 0x99, 0xde, 0x4, 0x1, 0x61, 0x38, 0x7f, 0x2b, 0x25, 0x73, 0x80, 0x9e, 0xcf, 0xbe, 0x32, 0x47, 0x82, 0xd8, 0xd3, 0xb9, 0x97, 0x19, 0xf9, 0x57, 0xa8, 0x4");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkMappedMemoryRange *)
  MAKE_CALLBACK_THUNK(callback_259, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkMappedMemoryRange *), "0x2f, 0xaa, 0xd7, 0xf6, 0x6c, 0x31, 0x58, 0xa, 0xd7, 0x6, 0x74, 0x8e, 0x6c, 0x8a, 0xe6, 0xc4, 0x57, 0x7f, 0x7c, 0x2a, 0xe3, 0x28, 0xda, 0xb9, 0x7d, 0x3e, 0x6f, 0x17, 0x6f, 0x6b, 0x68, 0x24");
  // void (struct VkCommandBuffer_T *, unsigned long, const struct VkDependencyInfo *)
  MAKE_CALLBACK_THUNK(callback_260, void (struct VkCommandBuffer_T *, unsigned long, const struct VkDependencyInfo *), "0x9e, 0xe0, 0x48, 0xb, 0xc0, 0xcd, 0xbc, 0xca, 0x58, 0x93, 0x8f, 0xdc, 0x3, 0xb4, 0x18, 0x70, 0x66, 0x37, 0xc3, 0x44, 0x2, 0x95, 0x43, 0xcf, 0x4d, 0x47, 0x66, 0xd4, 0x11, 0x52, 0xd4, 0x8a");
  // enum VkResult (struct VkDevice_T *, const struct VkFramebufferCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_261, enum VkResult (struct VkDevice_T *, const struct VkFramebufferCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x9a, 0x31, 0xaa, 0x42, 0x1e, 0x51, 0x3c, 0x5e, 0xc1, 0x87, 0xce, 0x6, 0xac, 0xb0, 0x70, 0x53, 0x99, 0x51, 0x43, 0xa6, 0x82, 0x65, 0x5a, 0x9b, 0xb5, 0x8f, 0x5, 0x25, 0x65, 0x53, 0x26, 0xe9");
  // void (struct VkDevice_T *, const struct VkDataGraphPipelineSessionMemoryRequirementsInfoARM *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_262, void (struct VkDevice_T *, const struct VkDataGraphPipelineSessionMemoryRequirementsInfoARM *, struct VkMemoryRequirements2 *), "0xe3, 0xd, 0x47, 0xeb, 0x39, 0x55, 0xb9, 0x98, 0xf9, 0x24, 0xc9, 0x5e, 0xc, 0xb3, 0xcf, 0x62, 0x3, 0x86, 0xaf, 0x40, 0x7b, 0x2e, 0x78, 0x21, 0xfb, 0x92, 0xd3, 0xbe, 0x5b, 0x26, 0x79, 0x9e");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, void *)
  MAKE_CALLBACK_THUNK(callback_263, enum VkResult (struct VkDevice_T *, unsigned long, unsigned long, void *), "0xdd, 0x4a, 0x3, 0xb6, 0xd5, 0xf8, 0x70, 0xfc, 0x3d, 0x63, 0x1c, 0x9c, 0x29, 0xb9, 0xa, 0x75, 0xe9, 0xf2, 0xce, 0xe4, 0x1, 0xfe, 0x3b, 0xb1, 0x1f, 0x8c, 0x1b, 0xc, 0xbb, 0x5a, 0x92, 0xc1");
  // void (struct VkCommandBuffer_T *, float, float, float)
  MAKE_CALLBACK_THUNK(callback_264, void (struct VkCommandBuffer_T *, float, float, float), "0xd6, 0x15, 0x5c, 0x9e, 0x50, 0x92, 0xfd, 0x99, 0x76, 0xae, 0x7c, 0xe7, 0xdf, 0xfc, 0x4f, 0xf3, 0x75, 0x77, 0x7c, 0xf9, 0x5, 0x59, 0xd0, 0x4, 0x92, 0x14, 0xdb, 0x22, 0x42, 0x47, 0x99, 0x1f");
  // void (struct VkCommandBuffer_T *, const struct VkBindDescriptorSetsInfo *)
  MAKE_CALLBACK_THUNK(callback_265, void (struct VkCommandBuffer_T *, const struct VkBindDescriptorSetsInfo *), "0xbc, 0x9c, 0xcc, 0xf9, 0x76, 0xd3, 0x5e, 0xa6, 0x39, 0x32, 0xc8, 0x96, 0xe2, 0xd7, 0x28, 0xbb, 0x8d, 0xc2, 0xa7, 0xe4, 0xab, 0x85, 0x2c, 0x94, 0x1e, 0x0, 0xc, 0x87, 0x98, 0xbb, 0xf9, 0x36");
  // void (struct VkCommandBuffer_T *, enum VkConservativeRasterizationModeEXT)
  MAKE_CALLBACK_THUNK(callback_266, void (struct VkCommandBuffer_T *, enum VkConservativeRasterizationModeEXT), "0x20, 0x63, 0x7c, 0x79, 0x22, 0x1, 0x97, 0xd0, 0x56, 0x66, 0x32, 0x6, 0x9b, 0xc9, 0xa3, 0xd1, 0x79, 0xda, 0x3b, 0xa8, 0xed, 0x7f, 0x3, 0x6c, 0x55, 0x37, 0xfc, 0xac, 0x5, 0xd, 0x20, 0x9c");
  // enum VkResult (struct VkDevice_T *, const struct VkImageCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_267, enum VkResult (struct VkDevice_T *, const struct VkImageCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xd2, 0x97, 0x92, 0x4b, 0xa3, 0xb5, 0x15, 0xf2, 0xf1, 0xe5, 0x88, 0x0, 0x4, 0xb0, 0x1, 0x77, 0x5b, 0x10, 0x1d, 0x9c, 0xa6, 0xf6, 0x1f, 0xc1, 0xa7, 0xf8, 0x81, 0xc6, 0xf4, 0xaa, 0x5f, 0xca");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceImageFormatInfo2 *, struct VkImageFormatProperties2 *)
  MAKE_CALLBACK_THUNK(callback_268, enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceImageFormatInfo2 *, struct VkImageFormatProperties2 *), "0x1f, 0xff, 0x91, 0x6a, 0xa5, 0x27, 0x28, 0x1d, 0x94, 0xb, 0x32, 0x39, 0x7b, 0x42, 0xbd, 0x67, 0xaf, 0x31, 0x60, 0x68, 0x90, 0x4d, 0x63, 0xcc, 0xdb, 0xff, 0x4a, 0x65, 0xac, 0x99, 0xf3, 0x24");
  // enum VkResult (struct VkDevice_T *, const struct VkBufferCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_269, enum VkResult (struct VkDevice_T *, const struct VkBufferCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xde, 0xfb, 0xdc, 0x32, 0xaf, 0xfb, 0x68, 0x5c, 0xb4, 0x47, 0xe6, 0x29, 0xb2, 0xce, 0xe3, 0x75, 0x85, 0xf6, 0x3b, 0x3, 0xb2, 0xb8, 0xb3, 0xd0, 0xd5, 0xfe, 0x6b, 0x70, 0x62, 0xa0, 0x47, 0x27");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_270, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int), "0x8d, 0xde, 0xd9, 0x58, 0x26, 0x57, 0x4c, 0x2d, 0xc9, 0xb2, 0x34, 0xdc, 0x90, 0x81, 0x2c, 0xde, 0x62, 0x1, 0xd9, 0x9, 0xad, 0x8c, 0x4d, 0x77, 0x0, 0x8, 0xe1, 0x4a, 0x42, 0x23, 0x24, 0xa8");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, enum VkImageLayout, unsigned int, const struct VkBufferImageCopy *)
  MAKE_CALLBACK_THUNK(callback_271, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, enum VkImageLayout, unsigned int, const struct VkBufferImageCopy *), "0x66, 0x6c, 0x7c, 0xaf, 0x23, 0xf9, 0x42, 0x4b, 0xe5, 0x4a, 0x60, 0xaf, 0xf1, 0xa, 0xe6, 0x16, 0xcd, 0x3d, 0xc0, 0x9d, 0x6d, 0x6e, 0xa, 0x66, 0xf7, 0x61, 0x13, 0xa1, 0x1a, 0x9f, 0xc9, 0x22");
  // enum VkResult (struct VkDevice_T *, const struct VkCommandPoolCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_272, enum VkResult (struct VkDevice_T *, const struct VkCommandPoolCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xb0, 0x7d, 0x5, 0x37, 0xf8, 0xa0, 0xb5, 0xe4, 0xbe, 0xf5, 0x8e, 0xff, 0x2f, 0xd8, 0x9, 0x78, 0xfd, 0x64, 0xa5, 0xc7, 0xcb, 0xee, 0x6e, 0x3d, 0x23, 0xd5, 0xd7, 0xb8, 0xaf, 0xe0, 0x34, 0x6a");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkLatencySleepModeInfoNV *)
  MAKE_CALLBACK_THUNK(callback_273, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkLatencySleepModeInfoNV *), "0x4c, 0x4a, 0xcd, 0x2a, 0x86, 0x4e, 0xe9, 0xd8, 0x47, 0x48, 0xcf, 0x36, 0x9b, 0x4, 0xfb, 0x8e, 0x69, 0x7f, 0x51, 0x6f, 0x7f, 0x1e, 0x24, 0xbb, 0xeb, 0x4b, 0xa7, 0x35, 0xfc, 0x64, 0x70, 0x1e");
  // void (struct VkCommandBuffer_T *, const struct VkCopyBufferToImageInfo2 *)
  MAKE_CALLBACK_THUNK(callback_275, void (struct VkCommandBuffer_T *, const struct VkCopyBufferToImageInfo2 *), "0x2a, 0x14, 0x45, 0x62, 0xe3, 0x8f, 0xfb, 0x9, 0x3f, 0x77, 0x62, 0x1d, 0xd8, 0x5e, 0x31, 0x89, 0xfb, 0x6a, 0xd2, 0xb, 0x39, 0x2c, 0x3e, 0xc4, 0x6b, 0x37, 0x27, 0xd9, 0xdf, 0x21, 0xb, 0xf9");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_276, void (struct VkCommandBuffer_T *, unsigned int, unsigned int), "0x84, 0xec, 0xb8, 0xff, 0x9b, 0x6e, 0x2, 0x49, 0x70, 0xc6, 0x78, 0xce, 0xa6, 0x2b, 0xa5, 0xc, 0xcd, 0x78, 0x4d, 0xaa, 0xfe, 0x0, 0xa5, 0x55, 0x59, 0x77, 0x21, 0x31, 0x70, 0x65, 0x17, 0xa6");
  // enum VkResult (struct VkDevice_T *, enum VkObjectType, unsigned long, unsigned long, unsigned long)
  MAKE_CALLBACK_THUNK(callback_277, enum VkResult (struct VkDevice_T *, enum VkObjectType, unsigned long, unsigned long, unsigned long), "0xc1, 0x3b, 0x6b, 0x3f, 0xbd, 0x2e, 0xfe, 0x3a, 0xbe, 0xbb, 0xe4, 0x64, 0xb9, 0xbf, 0xd6, 0xf8, 0xf7, 0xeb, 0xc, 0xd8, 0x90, 0x14, 0x3, 0x50, 0x72, 0x3b, 0xee, 0x36, 0xb8, 0x45, 0xe0, 0x27");
  // void (struct VkCommandBuffer_T *, const struct VkVideoEncodeInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_278, void (struct VkCommandBuffer_T *, const struct VkVideoEncodeInfoKHR *), "0xf8, 0xe2, 0x85, 0x6a, 0x41, 0xc5, 0x62, 0x52, 0x8b, 0x8d, 0x60, 0x1, 0x54, 0xd3, 0xd5, 0x44, 0x60, 0x69, 0xfa, 0x54, 0x3d, 0x44, 0xd, 0x71, 0x74, 0x2c, 0x8b, 0xb4, 0x58, 0x78, 0x1d, 0xab");
  // void (struct VkPhysicalDevice_T *, enum VkSampleCountFlagBits, struct VkMultisamplePropertiesEXT *)
  MAKE_CALLBACK_THUNK(callback_279, void (struct VkPhysicalDevice_T *, enum VkSampleCountFlagBits, struct VkMultisamplePropertiesEXT *), "0x1b, 0xc6, 0xde, 0xcf, 0x34, 0xd3, 0x38, 0xad, 0x30, 0xb, 0x80, 0xf5, 0xb8, 0x75, 0x41, 0x4, 0xdf, 0x40, 0x4f, 0xd8, 0xea, 0x69, 0xde, 0x86, 0xc9, 0x6, 0x77, 0x2c, 0xda, 0x31, 0x65, 0x4a");
  // enum VkResult (const struct VkInstanceCreateInfo *, const struct VkAllocationCallbacks *, struct VkInstance_T **)
  MAKE_CALLBACK_THUNK(callback_281, enum VkResult (const struct VkInstanceCreateInfo *, const struct VkAllocationCallbacks *, struct VkInstance_T **), "0xe1, 0x70, 0x77, 0x78, 0xef, 0xe, 0x8a, 0xf2, 0x20, 0x66, 0x65, 0xa9, 0x43, 0x56, 0xd0, 0x14, 0xb6, 0x27, 0x6c, 0xa2, 0x4d, 0x3b, 0xa8, 0x9d, 0x2c, 0x39, 0x49, 0x9a, 0x61, 0xdd, 0x7a, 0x51");
  // enum VkResult (struct VkDevice_T *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_282, enum VkResult (struct VkDevice_T *, unsigned long), "0x69, 0x5d, 0x62, 0x8c, 0x1a, 0x3b, 0x5f, 0x6a, 0xf8, 0x6c, 0x9e, 0x7b, 0x5c, 0x25, 0x1d, 0x88, 0x3e, 0xc6, 0x44, 0xe7, 0x17, 0xf1, 0x1a, 0x22, 0x91, 0xde, 0x15, 0x22, 0xc3, 0x79, 0x9, 0x8a");
  // void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceMemoryProperties2 *)
  MAKE_CALLBACK_THUNK(callback_283, void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceMemoryProperties2 *), "0x48, 0x8c, 0xea, 0x2a, 0xe0, 0x88, 0x2f, 0xa, 0xf5, 0x5, 0xc6, 0x91, 0xc6, 0x85, 0x62, 0xa4, 0x2f, 0x36, 0xac, 0x55, 0xcf, 0x1b, 0x9b, 0x4e, 0xea, 0x68, 0x28, 0x76, 0xaa, 0xc7, 0x44, 0x6e");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_284, void (struct VkCommandBuffer_T *, unsigned long, unsigned int), "0x63, 0xaa, 0xe9, 0x22, 0x7f, 0x1b, 0xfb, 0x83, 0xf2, 0xf8, 0xc4, 0xc7, 0x3, 0x1b, 0x20, 0xf5, 0x62, 0xef, 0x87, 0x41, 0x20, 0x59, 0x2, 0x10, 0x79, 0xf1, 0x42, 0xfe, 0xb2, 0x75, 0xe6, 0xac");
  // enum VkResult (struct VkDevice_T *, const struct VkPastPresentationTimingInfoEXT *, struct VkPastPresentationTimingPropertiesEXT *)
  MAKE_CALLBACK_THUNK(callback_285, enum VkResult (struct VkDevice_T *, const struct VkPastPresentationTimingInfoEXT *, struct VkPastPresentationTimingPropertiesEXT *), "0x48, 0xdb, 0xac, 0x6a, 0x2c, 0x26, 0x92, 0xee, 0x6d, 0xda, 0x71, 0x70, 0xfd, 0xe6, 0xc6, 0x6a, 0xc3, 0x4c, 0xb4, 0x70, 0xb8, 0xb9, 0xfa, 0xbe, 0x63, 0x44, 0xc0, 0x6c, 0xe9, 0x51, 0x5, 0x1f");
  // enum VkResult (struct VkDevice_T *, const struct VkFenceCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_287, enum VkResult (struct VkDevice_T *, const struct VkFenceCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xc, 0x97, 0x5b, 0x7a, 0xf0, 0x2, 0x2b, 0x9b, 0xd5, 0x36, 0x85, 0xc3, 0xd5, 0x56, 0x8b, 0x6b, 0x7c, 0xf8, 0xe5, 0x6b, 0x3e, 0x2e, 0xc5, 0xc, 0x52, 0xe6, 0x28, 0x7f, 0x85, 0xd7, 0xf4, 0x61");
  // enum VkResult (struct VkInstance_T *, const struct VkDebugUtilsMessengerCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_288, enum VkResult (struct VkInstance_T *, const struct VkDebugUtilsMessengerCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0xa6, 0x74, 0xf4, 0x9, 0xe9, 0xd7, 0xa9, 0x3b, 0x84, 0x43, 0xc1, 0xbc, 0x3b, 0xee, 0xdd, 0x61, 0xfb, 0xcc, 0xf9, 0x10, 0x48, 0xa0, 0x3e, 0xe8, 0xc9, 0x5a, 0x19, 0x8, 0x6d, 0xbb, 0xa6, 0x6a");
  // enum VkResult (struct VkCommandBuffer_T *)
  MAKE_CALLBACK_THUNK(callback_289, enum VkResult (struct VkCommandBuffer_T *), "0xa7, 0xa5, 0x7f, 0x5f, 0x1, 0xc6, 0xd8, 0x78, 0x6f, 0x54, 0xff, 0x38, 0x69, 0xda, 0x2, 0xe4, 0x9, 0x11, 0xf8, 0x2, 0xc0, 0x82, 0x95, 0x21, 0x3b, 0x15, 0x5f, 0xd6, 0x68, 0x22, 0x97, 0xe2");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceVideoEncodeQualityLevelInfoKHR *, struct VkVideoEncodeQualityLevelPropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_291, enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceVideoEncodeQualityLevelInfoKHR *, struct VkVideoEncodeQualityLevelPropertiesKHR *), "0x94, 0x3d, 0xfb, 0xa5, 0x63, 0x39, 0xa2, 0x85, 0xb7, 0x47, 0xed, 0x8c, 0x61, 0xbf, 0xc1, 0x7f, 0xdb, 0x9c, 0xf3, 0xe5, 0x0, 0xc9, 0xae, 0x78, 0xa7, 0xc4, 0x3a, 0xb7, 0xfd, 0x9c, 0x83, 0x35");
  // void (struct VkCommandBuffer_T *, enum VkPrimitiveTopology)
  MAKE_CALLBACK_THUNK(callback_292, void (struct VkCommandBuffer_T *, enum VkPrimitiveTopology), "0x96, 0x85, 0xfc, 0x1d, 0x55, 0x5a, 0xc9, 0xed, 0xe0, 0xa5, 0xe5, 0x5b, 0x32, 0x11, 0xa3, 0x6c, 0x36, 0x82, 0x1e, 0x4b, 0xff, 0x48, 0xf8, 0xca, 0xd0, 0x9d, 0x50, 0xde, 0xd3, 0x56, 0xe9, 0xf7");
  // enum VkResult (struct VkPhysicalDevice_T *, enum VkFormat, enum VkImageType, enum VkImageTiling, unsigned int, unsigned int, struct VkImageFormatProperties *)
  MAKE_CALLBACK_THUNK(callback_294, enum VkResult (struct VkPhysicalDevice_T *, enum VkFormat, enum VkImageType, enum VkImageTiling, unsigned int, unsigned int, struct VkImageFormatProperties *), "0x57, 0x7b, 0xad, 0xcb, 0xd2, 0x6b, 0x3, 0xe6, 0xe5, 0x31, 0xcf, 0x4b, 0xa6, 0xd3, 0x4d, 0x6, 0x76, 0x8f, 0xcb, 0x9b, 0x18, 0x7, 0x1a, 0x0, 0xc2, 0x50, 0xc0, 0x1b, 0x51, 0xf5, 0x1c, 0xff");
  // enum VkResult (struct VkDevice_T *, const struct VkMemoryAllocateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_299, enum VkResult (struct VkDevice_T *, const struct VkMemoryAllocateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xbb, 0x24, 0x14, 0xbc, 0xf7, 0x38, 0xe0, 0xd5, 0xaf, 0x82, 0x88, 0x84, 0x6e, 0x54, 0xc7, 0xfe, 0xda, 0x0, 0x89, 0xe1, 0x35, 0xc3, 0x3c, 0x38, 0x2c, 0xca, 0x29, 0x5a, 0x8c, 0x47, 0xeb, 0x9b");
  // void (struct VkCommandBuffer_T *, unsigned int, const float *)
  MAKE_CALLBACK_THUNK(callback_300, void (struct VkCommandBuffer_T *, unsigned int, const float *), "0xd7, 0x8c, 0x2f, 0x9c, 0xd6, 0xe7, 0x63, 0xe, 0x87, 0xb2, 0x16, 0xa8, 0x63, 0x8, 0x4e, 0xd1, 0x32, 0xdd, 0xf1, 0xaf, 0x31, 0x68, 0xf1, 0xc, 0x0, 0x65, 0x68, 0xf3, 0xbb, 0x9b, 0x6a, 0x23");
  // enum VkResult (struct VkInstance_T *, unsigned int *, struct VkPhysicalDeviceGroupProperties *)
  MAKE_CALLBACK_THUNK(callback_301, enum VkResult (struct VkInstance_T *, unsigned int *, struct VkPhysicalDeviceGroupProperties *), "0x0, 0x2, 0xdc, 0x96, 0x36, 0x53, 0x9, 0x8e, 0xef, 0x22, 0xc1, 0xcb, 0x34, 0x97, 0x3d, 0x4a, 0x67, 0x40, 0x2d, 0x96, 0x44, 0xe, 0x88, 0x6f, 0x8b, 0x73, 0xad, 0x37, 0xfd, 0xe5, 0xab, 0xbe");
  // unsigned int (struct VkDevice_T *, const struct VkImageViewHandleInfoNVX *)
  MAKE_CALLBACK_THUNK(callback_303, unsigned int (struct VkDevice_T *, const struct VkImageViewHandleInfoNVX *), "0x2f, 0xe6, 0xb, 0xbe, 0x7f, 0xc1, 0x62, 0xca, 0x86, 0x61, 0xa, 0x7b, 0x69, 0x47, 0xbf, 0x13, 0x60, 0x93, 0x2, 0xe8, 0x7d, 0xb8, 0x57, 0x82, 0x24, 0x7a, 0xbe, 0xd3, 0x7, 0xbb, 0xb7, 0x73");
  // enum VkResult (struct VkDevice_T *, unsigned int, const unsigned long *)
  MAKE_CALLBACK_THUNK(callback_304, enum VkResult (struct VkDevice_T *, unsigned int, const unsigned long *), "0x96, 0xfa, 0xb2, 0x3b, 0xe0, 0x7a, 0x6c, 0x2e, 0x6f, 0xbd, 0xd9, 0x9a, 0xef, 0x15, 0xf4, 0x3f, 0x64, 0x9d, 0x43, 0x77, 0x7b, 0x33, 0x62, 0xc0, 0xb8, 0x80, 0xaf, 0x14, 0x95, 0xd6, 0x8, 0x23");
  // enum VkResult (struct VkDevice_T *, unsigned long, struct VkImageViewAddressPropertiesNVX *)
  MAKE_CALLBACK_THUNK(callback_305, enum VkResult (struct VkDevice_T *, unsigned long, struct VkImageViewAddressPropertiesNVX *), "0x60, 0xc8, 0x5e, 0xf0, 0xe5, 0x7d, 0xa9, 0x2f, 0x26, 0xb5, 0xa2, 0x75, 0xf8, 0xf9, 0xaf, 0xe3, 0xd6, 0x3d, 0xff, 0xf8, 0xae, 0x50, 0x26, 0xf5, 0x2b, 0xe1, 0xe4, 0xd0, 0x32, 0x1d, 0xc3, 0xb");
  // void (struct VkCommandBuffer_T *, const struct VkRenderingEndInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_306, void (struct VkCommandBuffer_T *, const struct VkRenderingEndInfoKHR *), "0x59, 0x1, 0x36, 0xea, 0xc9, 0x3f, 0xbc, 0xa9, 0xef, 0xba, 0x2f, 0x62, 0x76, 0xfa, 0x4f, 0xa8, 0xd5, 0x91, 0x21, 0x9f, 0x7e, 0x1, 0xd6, 0x13, 0xfd, 0x5f, 0xd4, 0xa6, 0x93, 0x1b, 0xfd, 0xc4");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineBinaryCreateInfoKHR *, const struct VkAllocationCallbacks *, struct VkPipelineBinaryHandlesInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_308, enum VkResult (struct VkDevice_T *, const struct VkPipelineBinaryCreateInfoKHR *, const struct VkAllocationCallbacks *, struct VkPipelineBinaryHandlesInfoKHR *), "0xc9, 0x75, 0x7, 0xf4, 0x2c, 0x1b, 0xcc, 0x3e, 0xf9, 0x82, 0xca, 0x77, 0x31, 0xe9, 0xb3, 0xbb, 0xcb, 0xa1, 0xbd, 0x0, 0x78, 0xa2, 0x8f, 0x2f, 0x61, 0x1e, 0xbb, 0x87, 0xbf, 0xdd, 0x59, 0xe5");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const struct VkAccelerationStructureBuildRangeInfoKHR *const *)
  MAKE_CALLBACK_THUNK(callback_309, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const struct VkAccelerationStructureBuildRangeInfoKHR *const *), "0x9a, 0xc9, 0x48, 0x54, 0x8f, 0x73, 0x9f, 0x6f, 0xac, 0xfa, 0xb1, 0xf6, 0xea, 0x95, 0x4a, 0x1a, 0xee, 0x4, 0x3e, 0x61, 0x45, 0x60, 0xf6, 0xa5, 0x97, 0x23, 0x1f, 0x64, 0xe3, 0xca, 0x7f, 0xfc");
  // enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineSessionCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_311, enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineSessionCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *), "0xe3, 0xe0, 0xbd, 0xc2, 0x89, 0x2, 0xfe, 0x3, 0xde, 0x5b, 0xbb, 0x89, 0x3d, 0x43, 0x45, 0x43, 0x5e, 0x99, 0x36, 0x56, 0x3a, 0x72, 0x66, 0x1d, 0x2e, 0x33, 0x7a, 0x79, 0x83, 0x5, 0x62, 0x5f");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkGraphicsPipelineCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_313, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkGraphicsPipelineCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xaf, 0x50, 0x4b, 0x4b, 0xe8, 0x27, 0x17, 0x4b, 0x76, 0xd2, 0x9, 0xe0, 0x47, 0xd1, 0x1, 0xb3, 0x19, 0x79, 0xdc, 0x1d, 0xcb, 0x2f, 0x3f, 0xc5, 0xf3, 0xd7, 0x2a, 0xa, 0xf4, 0x2f, 0xdb, 0x7c");
  // void (struct VkExternalComputeQueueNV_T *, struct VkExternalComputeQueueDataParamsNV *, void *)
  MAKE_CALLBACK_THUNK(callback_315, void (struct VkExternalComputeQueueNV_T *, struct VkExternalComputeQueueDataParamsNV *, void *), "0x9b, 0x60, 0x4e, 0xb8, 0x6a, 0x50, 0x14, 0x73, 0xa1, 0x38, 0xba, 0x9f, 0x1d, 0x8, 0x27, 0xc1, 0x1f, 0x2a, 0xb3, 0x88, 0x32, 0x28, 0x34, 0x68, 0xae, 0x68, 0xa0, 0x99, 0x43, 0x32, 0xa6, 0x56");
  // void (struct VkCommandBuffer_T *, const struct VkCopyImageToBufferInfo2 *)
  MAKE_CALLBACK_THUNK(callback_316, void (struct VkCommandBuffer_T *, const struct VkCopyImageToBufferInfo2 *), "0x71, 0x71, 0x7b, 0x34, 0x63, 0x41, 0xd0, 0x30, 0xad, 0xc3, 0x83, 0xe, 0x9c, 0x9f, 0x14, 0xee, 0x82, 0x72, 0x14, 0x9a, 0xda, 0xed, 0x67, 0xd, 0x85, 0x30, 0xd6, 0xb5, 0x29, 0xdb, 0xe, 0xdf");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkRect2D *)
  MAKE_CALLBACK_THUNK(callback_320, void (struct VkCommandBuffer_T *, unsigned int, const struct VkRect2D *), "0xce, 0x86, 0x91, 0x3b, 0x4b, 0xb5, 0xd6, 0x5, 0xdf, 0x48, 0x5d, 0x34, 0x87, 0xb5, 0x14, 0xd1, 0x68, 0xe2, 0xf8, 0x66, 0x8e, 0xde, 0x38, 0xb4, 0x28, 0x24, 0x7b, 0x1d, 0x6d, 0x97, 0x80, 0xb6");
  // void (struct VkCommandBuffer_T *, const struct VkDebugMarkerMarkerInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_321, void (struct VkCommandBuffer_T *, const struct VkDebugMarkerMarkerInfoEXT *), "0x4e, 0xea, 0xbf, 0xab, 0xf3, 0x2d, 0xe, 0x88, 0xbf, 0x59, 0x72, 0x4c, 0x8a, 0x4d, 0xad, 0xa5, 0x22, 0xe, 0xda, 0x85, 0x8c, 0xa0, 0xef, 0x3, 0xae, 0x16, 0x3d, 0x41, 0x58, 0xfc, 0xc6, 0xea");
  // void (struct VkCommandBuffer_T *, const void *)
  MAKE_CALLBACK_THUNK(callback_322, void (struct VkCommandBuffer_T *, const void *), "0x97, 0xa2, 0x8, 0xd8, 0xa, 0x3e, 0xc4, 0x45, 0x7b, 0xd2, 0x1a, 0x4, 0x4c, 0xb5, 0xd0, 0x1d, 0x76, 0x14, 0x33, 0x63, 0x14, 0xe2, 0x2b, 0xb6, 0xc2, 0x73, 0x97, 0x9b, 0x97, 0x4e, 0x53, 0x7d");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkDeviceCreateInfo *, const struct VkAllocationCallbacks *, struct VkDevice_T **)
  MAKE_CALLBACK_THUNK(callback_324, enum VkResult (struct VkPhysicalDevice_T *, const struct VkDeviceCreateInfo *, const struct VkAllocationCallbacks *, struct VkDevice_T **), "0x1a, 0xda, 0x5d, 0xe5, 0xf, 0xcf, 0x1f, 0x2b, 0xd6, 0x8b, 0x58, 0x60, 0x1e, 0x1d, 0xa5, 0x20, 0x12, 0xb7, 0x4, 0xe, 0xa, 0xb, 0x99, 0xd3, 0x1f, 0x5, 0x14, 0xfa, 0x68, 0xe7, 0x4, 0xc1");
  // void (struct VkCommandBuffer_T *, const struct VkDepthBiasInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_325, void (struct VkCommandBuffer_T *, const struct VkDepthBiasInfoEXT *), "0xe, 0x72, 0xd1, 0x4e, 0x63, 0x5c, 0x59, 0x36, 0x61, 0xa4, 0x90, 0xdc, 0xbc, 0x2d, 0xe2, 0xb4, 0xe4, 0xab, 0xd, 0x40, 0xc2, 0x8f, 0xa5, 0xd1, 0x4f, 0x54, 0xb8, 0xcb, 0x90, 0x2c, 0x14, 0x28");
  // enum VkResult (struct VkDevice_T *, const struct VkCommandBufferAllocateInfo *, struct VkCommandBuffer_T **)
  MAKE_CALLBACK_THUNK(callback_327, enum VkResult (struct VkDevice_T *, const struct VkCommandBufferAllocateInfo *, struct VkCommandBuffer_T **), "0x8b, 0xed, 0xe, 0x15, 0x23, 0x3b, 0x47, 0x95, 0x8a, 0x34, 0x9, 0x6a, 0xac, 0x75, 0xbd, 0x5d, 0xcc, 0xc8, 0xcf, 0xa5, 0xac, 0x54, 0xb1, 0x7, 0xc1, 0xaa, 0x96, 0x38, 0x4, 0x61, 0xde, 0xdf");
  // void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceQueueFamilyDataGraphProcessingEngineInfoARM *, struct VkQueueFamilyDataGraphProcessingEnginePropertiesARM *)
  MAKE_CALLBACK_THUNK(callback_328, void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceQueueFamilyDataGraphProcessingEngineInfoARM *, struct VkQueueFamilyDataGraphProcessingEnginePropertiesARM *), "0xd, 0x14, 0xd4, 0xb, 0xe4, 0x20, 0xba, 0x6c, 0xc2, 0x6c, 0x33, 0x53, 0xb8, 0x89, 0x9e, 0x16, 0x19, 0xaf, 0xc8, 0xe, 0x75, 0xb9, 0xba, 0x2f, 0x7b, 0xbf, 0x9f, 0x5a, 0x15, 0x2b, 0x88, 0xab");
  // void (struct VkDevice_T *, const struct VkAccelerationStructureVersionInfoKHR *, enum VkAccelerationStructureCompatibilityKHR *)
  MAKE_CALLBACK_THUNK(callback_331, void (struct VkDevice_T *, const struct VkAccelerationStructureVersionInfoKHR *, enum VkAccelerationStructureCompatibilityKHR *), "0x4, 0x81, 0x4e, 0x7c, 0x0, 0xf8, 0x95, 0x99, 0x38, 0x6, 0x1d, 0x77, 0x66, 0x1d, 0x90, 0xbd, 0x57, 0x26, 0x21, 0x4f, 0x39, 0x8, 0x61, 0x9f, 0x5c, 0x5b, 0x41, 0x11, 0xf1, 0x86, 0xdb, 0xc7");
  // void (struct VkDevice_T *, unsigned long, const struct VkImageSubresource2 *, struct VkSubresourceLayout2 *)
  MAKE_CALLBACK_THUNK(callback_332, void (struct VkDevice_T *, unsigned long, const struct VkImageSubresource2 *, struct VkSubresourceLayout2 *), "0xfb, 0x6, 0xe, 0x2f, 0x72, 0x5a, 0x60, 0x47, 0x10, 0x3, 0xc0, 0x45, 0xd3, 0x17, 0x44, 0xc9, 0x43, 0xeb, 0x29, 0x38, 0x76, 0x27, 0xff, 0x18, 0x85, 0x24, 0x89, 0x88, 0x2, 0xba, 0xa8, 0x4a");
  // enum VkResult (struct VkDevice_T *, const struct VkSemaphoreGetFdInfoKHR *, int *)
  MAKE_CALLBACK_THUNK(callback_333, enum VkResult (struct VkDevice_T *, const struct VkSemaphoreGetFdInfoKHR *, int *), "0xa0, 0xc5, 0x97, 0x5b, 0x85, 0x7f, 0xb9, 0x10, 0x61, 0x8a, 0x9e, 0xe1, 0xdc, 0x82, 0x81, 0x32, 0x88, 0x99, 0xfb, 0x8, 0x63, 0x4e, 0x8f, 0x93, 0x63, 0xe1, 0x7e, 0x50, 0xe6, 0xd7, 0x49, 0xc8");
  // void (struct VkCommandBuffer_T *, const struct VkDebugUtilsLabelEXT *)
  MAKE_CALLBACK_THUNK(callback_334, void (struct VkCommandBuffer_T *, const struct VkDebugUtilsLabelEXT *), "0x26, 0x11, 0xa9, 0xbf, 0x72, 0x25, 0xfa, 0xba, 0x88, 0x3c, 0xb4, 0x5f, 0xe8, 0xaf, 0xb4, 0xd9, 0xcc, 0xf0, 0xe9, 0x79, 0x6, 0xb0, 0xd3, 0x6, 0xb1, 0xd2, 0x97, 0xd5, 0xc5, 0x46, 0x8b, 0xda");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned long, unsigned long, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_335, void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned long, unsigned long, unsigned long, unsigned int), "0xc0, 0x6d, 0x19, 0x97, 0xe, 0x9c, 0x62, 0x6, 0x46, 0x46, 0x19, 0x56, 0xa, 0x2d, 0xf1, 0x58, 0x60, 0x94, 0x34, 0x36, 0xe1, 0xa9, 0xa9, 0x74, 0x6b, 0xb6, 0x27, 0x3f, 0xd5, 0x3, 0xb5, 0x15");
  // void (struct VkCommandBuffer_T *, float)
  MAKE_CALLBACK_THUNK(callback_338, void (struct VkCommandBuffer_T *, float), "0x98, 0xf7, 0x5, 0xd4, 0xf6, 0x40, 0x5f, 0x54, 0xb5, 0xbc, 0x4b, 0xad, 0x98, 0x7b, 0x53, 0x1d, 0x76, 0xfa, 0xdd, 0xa0, 0x34, 0xc, 0x38, 0xaf, 0xf9, 0x30, 0xa0, 0x13, 0x71, 0x2f, 0xbd, 0x84");
  // void (struct VkCommandBuffer_T *, enum VkTessellationDomainOrigin)
  MAKE_CALLBACK_THUNK(callback_340, void (struct VkCommandBuffer_T *, enum VkTessellationDomainOrigin), "0x8, 0xd, 0x9d, 0x48, 0xde, 0x71, 0xe5, 0x8f, 0xb5, 0x5e, 0x4b, 0x7, 0xb1, 0xc5, 0xd, 0x50, 0x70, 0x1, 0xd6, 0x9c, 0xf, 0xf5, 0x84, 0xc, 0x43, 0x9a, 0x8a, 0x7d, 0xc4, 0x9f, 0xdd, 0xe2");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkPhysicalDeviceFragmentShadingRateKHR *)
  MAKE_CALLBACK_THUNK(callback_341, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkPhysicalDeviceFragmentShadingRateKHR *), "0x49, 0xab, 0x4a, 0xd0, 0x7c, 0x1, 0xb4, 0x5a, 0x5e, 0x6f, 0xfc, 0x2, 0x22, 0x52, 0x42, 0xc8, 0x2c, 0xd0, 0x28, 0x7c, 0x9f, 0x84, 0x96, 0x4b, 0x1f, 0xf9, 0x8a, 0xcd, 0x30, 0x95, 0x6f, 0xb1");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned long *, const unsigned long *, const unsigned long *)
  MAKE_CALLBACK_THUNK(callback_342, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned long *, const unsigned long *, const unsigned long *), "0x4a, 0xc2, 0x72, 0x32, 0xbe, 0xad, 0x8d, 0xb4, 0xa2, 0x1c, 0x1b, 0xf0, 0xac, 0xd0, 0x34, 0xe8, 0x6e, 0xfd, 0xb1, 0xbc, 0xaf, 0x69, 0x3f, 0xdb, 0xea, 0x68, 0x2a, 0xe2, 0x58, 0x79, 0xde, 0xce");
  // void (struct VkCommandBuffer_T *, unsigned int, const unsigned long *, unsigned int, unsigned int, unsigned int, const struct VkMemoryBarrier *, unsigned int, const struct VkBufferMemoryBarrier *, unsigned int, const struct VkImageMemoryBarrier *)
  MAKE_CALLBACK_THUNK(callback_344, void (struct VkCommandBuffer_T *, unsigned int, const unsigned long *, unsigned int, unsigned int, unsigned int, const struct VkMemoryBarrier *, unsigned int, const struct VkBufferMemoryBarrier *, unsigned int, const struct VkImageMemoryBarrier *), "0xad, 0x36, 0xa, 0xc8, 0x3f, 0x18, 0x73, 0xbc, 0x3e, 0x9d, 0x15, 0x9, 0xcd, 0x57, 0x5c, 0x38, 0xc0, 0x6, 0x2d, 0x2b, 0xbe, 0x53, 0xa4, 0xa1, 0x9c, 0x80, 0x45, 0xea, 0x2f, 0x5d, 0xdd, 0x70");
  // enum VkResult (struct VkDevice_T *, const struct VkQueryPoolCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_345, enum VkResult (struct VkDevice_T *, const struct VkQueryPoolCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x46, 0x6, 0x64, 0xf7, 0x24, 0xfa, 0xc0, 0xab, 0x77, 0xeb, 0x1b, 0x7c, 0xe4, 0xee, 0xe6, 0xf, 0xc, 0xab, 0x44, 0xf9, 0x6f, 0x9c, 0x5a, 0xa7, 0x6c, 0xc7, 0x8, 0xde, 0x67, 0x83, 0xbe, 0x59");
  // enum VkResult (struct VkDevice_T *, const struct VkVideoSessionParametersCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_349, enum VkResult (struct VkDevice_T *, const struct VkVideoSessionParametersCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x3f, 0x4c, 0x5f, 0x2a, 0xbe, 0x3d, 0xa, 0x53, 0x59, 0xa1, 0x69, 0x6, 0xf7, 0x96, 0x7b, 0x15, 0xb, 0xc9, 0x52, 0x5a, 0x15, 0x10, 0xa9, 0x2b, 0xc5, 0x50, 0x3, 0x71, 0xd6, 0x21, 0x48, 0x49");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkGeneratedCommandsInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_350, void (struct VkCommandBuffer_T *, unsigned int, const struct VkGeneratedCommandsInfoEXT *), "0xc1, 0xf8, 0x3f, 0xb, 0xf, 0x52, 0x22, 0xab, 0xc9, 0x8c, 0x10, 0x59, 0x1c, 0x7f, 0xa3, 0xad, 0xcf, 0xd4, 0xbe, 0x37, 0x32, 0xcc, 0xf0, 0xe, 0x9e, 0xda, 0x43, 0x36, 0xdb, 0x47, 0xd6, 0xf9");
  // void (struct VkDevice_T *, const struct VkRenderingAreaInfo *, struct VkExtent2D *)
  MAKE_CALLBACK_THUNK(callback_351, void (struct VkDevice_T *, const struct VkRenderingAreaInfo *, struct VkExtent2D *), "0x5b, 0x7a, 0x14, 0x8a, 0xad, 0x80, 0xd3, 0xe9, 0xe5, 0x9f, 0x1c, 0x38, 0x95, 0xa4, 0xbc, 0x75, 0x36, 0x7e, 0xa6, 0xa9, 0x26, 0x91, 0x94, 0x34, 0xac, 0xd7, 0x78, 0xd, 0x96, 0x3, 0xc3, 0xb");
  // enum VkResult (struct VkQueue_T *)
  MAKE_CALLBACK_THUNK(callback_353, enum VkResult (struct VkQueue_T *), "0x7, 0xa2, 0xa1, 0xff, 0x75, 0x65, 0x18, 0xae, 0x52, 0x5f, 0xfc, 0xb6, 0x24, 0xf1, 0x46, 0x6e, 0x4b, 0x86, 0xec, 0x3f, 0x61, 0x45, 0x74, 0x1, 0xb8, 0x45, 0xd5, 0xf6, 0x90, 0xf7, 0x5a, 0xf9");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, enum VkIndexType)
  MAKE_CALLBACK_THUNK(callback_354, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, enum VkIndexType), "0xeb, 0x74, 0x37, 0x7f, 0xac, 0x90, 0x96, 0x3e, 0xad, 0x45, 0x40, 0x3a, 0x4c, 0x2b, 0xb, 0xd, 0x49, 0x3d, 0xc8, 0xe0, 0x46, 0x10, 0x11, 0xb5, 0x95, 0x13, 0x57, 0x2, 0x9c, 0xc6, 0x14, 0xa1");
  // enum VkResult (struct VkDevice_T *, const struct VkSemaphoreCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_356, enum VkResult (struct VkDevice_T *, const struct VkSemaphoreCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x9b, 0xe6, 0x8b, 0x3f, 0x33, 0x0, 0xef, 0x3d, 0xed, 0x6, 0xa6, 0xf1, 0xec, 0x9b, 0x3d, 0xfa, 0x6, 0x57, 0x3d, 0x5, 0xcb, 0xb3, 0x8e, 0x6c, 0x5c, 0x99, 0x69, 0x32, 0x6, 0xd6, 0x59, 0x9c");
  // void (struct VkPhysicalDevice_T *, unsigned int *, struct VkQueueFamilyProperties2 *)
  MAKE_CALLBACK_THUNK(callback_358, void (struct VkPhysicalDevice_T *, unsigned int *, struct VkQueueFamilyProperties2 *), "0x39, 0xd8, 0x68, 0x56, 0xf2, 0x4f, 0x90, 0x37, 0xa, 0x55, 0x15, 0x94, 0xe9, 0xdf, 0x90, 0x7a, 0xc8, 0x1f, 0xa5, 0x86, 0x16, 0xd5, 0xc1, 0x82, 0xcb, 0x6b, 0x27, 0xb0, 0x7b, 0x57, 0x2b, 0xbb");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkLayerProperties *)
  MAKE_CALLBACK_THUNK(callback_361, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkLayerProperties *), "0xca, 0x49, 0x60, 0x61, 0x2f, 0x31, 0x73, 0x61, 0xd3, 0xcf, 0x1e, 0xe7, 0x15, 0x65, 0x97, 0x74, 0x36, 0x5a, 0x45, 0x94, 0xa8, 0x34, 0xe8, 0x26, 0xf2, 0x31, 0xc1, 0x47, 0x71, 0x2e, 0x57, 0x19");
  // void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceFeatures2 *)
  MAKE_CALLBACK_THUNK(callback_362, void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceFeatures2 *), "0x61, 0x9a, 0x19, 0x1f, 0xcb, 0x2d, 0x23, 0xa8, 0x1a, 0x26, 0xd, 0x81, 0x24, 0xa6, 0xd0, 0x6, 0xbd, 0x4e, 0x44, 0x9b, 0x7a, 0x7e, 0x19, 0x1a, 0xef, 0x0, 0x51, 0xa8, 0xab, 0x25, 0x71, 0x21");
  // enum VkResult (struct VkDevice_T *, const struct VkCopyImageToMemoryInfo *)
  MAKE_CALLBACK_THUNK(callback_363, enum VkResult (struct VkDevice_T *, const struct VkCopyImageToMemoryInfo *), "0x61, 0x3f, 0xc1, 0x41, 0x71, 0xd7, 0x72, 0x1, 0xdf, 0xaa, 0xb8, 0xf1, 0xab, 0xe8, 0x27, 0xca, 0xd9, 0x7e, 0xe5, 0x9, 0xff, 0x22, 0xce, 0xa4, 0x1d, 0xd6, 0xba, 0x76, 0x5a, 0x5, 0xd6, 0xbd");
  // void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, enum VkImageLayout, unsigned int, const struct VkImageCopy *)
  MAKE_CALLBACK_THUNK(callback_364, void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, enum VkImageLayout, unsigned int, const struct VkImageCopy *), "0x8a, 0x7c, 0x45, 0xb4, 0x26, 0x40, 0xa0, 0xc7, 0xa2, 0x9e, 0x10, 0x3, 0x10, 0xd, 0xe, 0x8c, 0xc8, 0xfd, 0x6a, 0xc0, 0x58, 0xb, 0x45, 0xd2, 0x1, 0x67, 0x29, 0xb5, 0x95, 0xfb, 0xd9, 0x25");
  // void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceMemoryProperties *)
  MAKE_CALLBACK_THUNK(callback_365, void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceMemoryProperties *), "0xf9, 0x4e, 0x37, 0xf5, 0xe2, 0xe1, 0x3d, 0x47, 0x16, 0x2f, 0x30, 0xb0, 0xed, 0x32, 0x81, 0x89, 0xec, 0xac, 0xb0, 0x9a, 0x81, 0xc8, 0x65, 0xb7, 0xda, 0x9e, 0xe9, 0x6b, 0xbc, 0xe6, 0x2a, 0x6e");
  // void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, const union VkClearColorValue *, unsigned int, const struct VkImageSubresourceRange *)
  MAKE_CALLBACK_THUNK(callback_367, void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, const union VkClearColorValue *, unsigned int, const struct VkImageSubresourceRange *), "0x4c, 0xb8, 0xe7, 0x3f, 0xc5, 0xad, 0x7f, 0x2, 0x9b, 0x7a, 0xe5, 0x3, 0x1b, 0x5e, 0xd1, 0xfb, 0xf, 0xc2, 0xc8, 0x32, 0xe5, 0x5e, 0x2d, 0x57, 0x95, 0x74, 0xe2, 0xe6, 0x7f, 0xd5, 0x2f, 0x2a");
  // void (struct VkCommandBuffer_T *, const struct VkCopyAccelerationStructureToMemoryInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_368, void (struct VkCommandBuffer_T *, const struct VkCopyAccelerationStructureToMemoryInfoKHR *), "0xc2, 0x8e, 0x52, 0x19, 0xfb, 0x7c, 0xab, 0x78, 0xd7, 0x3a, 0x7f, 0x25, 0x27, 0x5d, 0x9e, 0xd2, 0x77, 0xf7, 0x18, 0x34, 0x9f, 0xb8, 0x65, 0x1a, 0x5d, 0xbb, 0xb0, 0x69, 0x25, 0xa8, 0x75, 0xe7");
  // void (struct VkDevice_T *, unsigned int, unsigned int, struct VkQueue_T **)
  MAKE_CALLBACK_THUNK(callback_369, void (struct VkDevice_T *, unsigned int, unsigned int, struct VkQueue_T **), "0xde, 0x66, 0xb6, 0xbf, 0x27, 0xdd, 0xf6, 0x4, 0x1b, 0x3b, 0xa9, 0xb1, 0x6d, 0x1d, 0x22, 0x74, 0xe7, 0xfb, 0x4c, 0x1e, 0x1d, 0x1d, 0x3d, 0xb8, 0x95, 0xd, 0x99, 0xcb, 0xfe, 0xd6, 0x76, 0xe1");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineBinaryDataInfoKHR *, struct VkPipelineBinaryKeyKHR *, unsigned long *, void *)
  MAKE_CALLBACK_THUNK(callback_370, enum VkResult (struct VkDevice_T *, const struct VkPipelineBinaryDataInfoKHR *, struct VkPipelineBinaryKeyKHR *, unsigned long *, void *), "0x87, 0x81, 0x22, 0xdd, 0x26, 0x5a, 0x6d, 0x7c, 0x17, 0x41, 0x51, 0x6f, 0x51, 0x46, 0x7c, 0x55, 0x16, 0x48, 0x6d, 0x56, 0x35, 0x2d, 0x44, 0xe1, 0x75, 0x4a, 0x22, 0x75, 0x50, 0x35, 0x8, 0xce");
  // enum VkResult (struct VkDevice_T *, const struct VkEventCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_371, enum VkResult (struct VkDevice_T *, const struct VkEventCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xa3, 0x59, 0xa3, 0x8d, 0xdc, 0x82, 0x31, 0x6b, 0xbf, 0x5f, 0x6c, 0x20, 0x1, 0x43, 0x9, 0xea, 0x5f, 0xb, 0x60, 0xa7, 0x44, 0xe2, 0x96, 0x8f, 0xd8, 0x10, 0xe, 0x4a, 0x1, 0x51, 0x3, 0xdf");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned long *, const unsigned long *)
  MAKE_CALLBACK_THUNK(callback_372, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const unsigned long *, const unsigned long *), "0x15, 0x71, 0xff, 0xfa, 0xfc, 0x79, 0x99, 0x22, 0x6a, 0xd8, 0x9b, 0x3, 0x5a, 0x48, 0x75, 0xdd, 0x51, 0xd6, 0x5c, 0xae, 0xbd, 0x49, 0xf1, 0xc4, 0x36, 0xc6, 0xe6, 0x25, 0x59, 0x2, 0xda, 0x4a");
  // void (struct VkCommandBuffer_T *, enum VkLineRasterizationMode)
  MAKE_CALLBACK_THUNK(callback_373, void (struct VkCommandBuffer_T *, enum VkLineRasterizationMode), "0x2b, 0x69, 0x41, 0x30, 0x31, 0x61, 0xb, 0xa3, 0xc7, 0x9c, 0x64, 0x11, 0x7e, 0x8b, 0xea, 0x6a, 0xd8, 0xbe, 0x9f, 0x24, 0x84, 0x4d, 0x5a, 0x26, 0x6b, 0xac, 0xdb, 0x2a, 0xbf, 0xf, 0xd, 0xff");
  // enum VkResult (struct VkDevice_T *, const struct VkReleaseSwapchainImagesInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_374, enum VkResult (struct VkDevice_T *, const struct VkReleaseSwapchainImagesInfoKHR *), "0xdf, 0x8c, 0x7, 0x71, 0xb7, 0x88, 0x1e, 0xe0, 0x6d, 0x4c, 0x87, 0x84, 0xf4, 0xc5, 0x11, 0x96, 0x32, 0xe6, 0x94, 0xb8, 0xc, 0x96, 0xa9, 0xa1, 0xdf, 0x11, 0xdc, 0x4a, 0xce, 0xa5, 0x79, 0x2a");
  // enum VkResult (struct VkDevice_T *, const struct VkDescriptorSetLayoutCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_375, enum VkResult (struct VkDevice_T *, const struct VkDescriptorSetLayoutCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x7c, 0xa1, 0x19, 0xf2, 0x98, 0x8e, 0x15, 0xb2, 0x63, 0xd9, 0x35, 0xd3, 0x6d, 0x64, 0xff, 0x6b, 0x7d, 0xab, 0xa8, 0xd6, 0xa2, 0x83, 0xb6, 0x3, 0xfe, 0xb3, 0xe9, 0xf4, 0xf3, 0x86, 0x4b, 0x2a");
  // void (struct VkPhysicalDevice_T *, enum VkFormat, enum VkImageType, enum VkSampleCountFlagBits, unsigned int, enum VkImageTiling, unsigned int *, struct VkSparseImageFormatProperties *)
  MAKE_CALLBACK_THUNK(callback_376, void (struct VkPhysicalDevice_T *, enum VkFormat, enum VkImageType, enum VkSampleCountFlagBits, unsigned int, enum VkImageTiling, unsigned int *, struct VkSparseImageFormatProperties *), "0xfa, 0x9f, 0x93, 0xf3, 0x29, 0x1b, 0x9f, 0xab, 0xff, 0xe2, 0xeb, 0xe5, 0x11, 0x17, 0xad, 0x7d, 0x91, 0xb7, 0xd8, 0xa5, 0x1c, 0xaa, 0x4d, 0xb1, 0x97, 0x3e, 0xda, 0x83, 0xbb, 0x34, 0x2e, 0x91");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkDisplayModePropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_377, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkDisplayModePropertiesKHR *), "0xbe, 0x87, 0xca, 0xce, 0x26, 0xf2, 0xe5, 0xf8, 0x26, 0xe2, 0xa5, 0xef, 0xe2, 0x55, 0x62, 0x9b, 0xf4, 0xfd, 0x6a, 0xe5, 0xb0, 0x6b, 0xcd, 0xd2, 0x31, 0x7e, 0x5e, 0x8b, 0xe9, 0xb, 0x73, 0xbd");
  // void (struct VkDevice_T *, unsigned long, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_378, void (struct VkDevice_T *, unsigned long, unsigned long *), "0xcc, 0xc6, 0x2, 0x16, 0x9a, 0x72, 0x30, 0xc8, 0x4b, 0xac, 0xd6, 0x85, 0x8f, 0xda, 0x35, 0x9, 0x45, 0xdf, 0x98, 0x31, 0x4, 0xa1, 0xc7, 0x75, 0xce, 0x23, 0x6a, 0xe6, 0x1b, 0x30, 0x7f, 0x8d");
  // void (struct VkDevice_T *, unsigned long, struct VkMemoryRequirements *)
  MAKE_CALLBACK_THUNK(callback_379, void (struct VkDevice_T *, unsigned long, struct VkMemoryRequirements *), "0xc1, 0xfc, 0x3, 0x70, 0xc3, 0xb8, 0x12, 0x20, 0xd4, 0x58, 0xd4, 0x8c, 0xf8, 0x75, 0xa2, 0x63, 0x65, 0x10, 0x39, 0x93, 0xa2, 0x5b, 0x1e, 0x6, 0x12, 0xa0, 0x75, 0x34, 0xe8, 0x33, 0x1b, 0x5f");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkComputePipelineCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_380, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int, const struct VkComputePipelineCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xe7, 0x74, 0x63, 0x72, 0x46, 0xb7, 0xea, 0x94, 0x77, 0x95, 0x3f, 0xd1, 0x1e, 0x21, 0x97, 0xa5, 0x47, 0x1d, 0x2a, 0xe3, 0x83, 0x65, 0x6, 0xa4, 0x28, 0x4b, 0x7e, 0x64, 0x43, 0x15, 0x17, 0xfe");
  // void (struct VkPhysicalDevice_T *, enum VkFormat, struct VkFormatProperties *)
  MAKE_CALLBACK_THUNK(callback_381, void (struct VkPhysicalDevice_T *, enum VkFormat, struct VkFormatProperties *), "0xcb, 0xbd, 0x66, 0xe0, 0xea, 0xf1, 0xc6, 0x1, 0x45, 0x1b, 0xdb, 0x31, 0x55, 0xd8, 0x1, 0x11, 0x9f, 0x68, 0x12, 0xb4, 0x12, 0xbd, 0xec, 0xeb, 0x24, 0x76, 0x90, 0xd2, 0xcd, 0x1e, 0xdb, 0x7f");
  // enum VkResult (const char *, unsigned int *, struct VkExtensionProperties *)
  MAKE_CALLBACK_THUNK(callback_382, enum VkResult (const char *, unsigned int *, struct VkExtensionProperties *), "0xd3, 0xa6, 0xc9, 0xd7, 0x2e, 0x9b, 0x6d, 0x2e, 0x4d, 0xc5, 0xe2, 0x47, 0xa8, 0x78, 0xae, 0x68, 0x3c, 0xcf, 0x1a, 0x81, 0xf9, 0x65, 0x43, 0x41, 0x51, 0x36, 0xc4, 0xcb, 0xe4, 0x60, 0x55, 0x0");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkViewport *)
  MAKE_CALLBACK_THUNK(callback_383, void (struct VkCommandBuffer_T *, unsigned int, const struct VkViewport *), "0xe7, 0xa0, 0x59, 0xce, 0xcf, 0x53, 0x97, 0xb, 0xcd, 0x24, 0xfa, 0x70, 0xd0, 0xfb, 0x90, 0x34, 0x96, 0xce, 0xa2, 0x1c, 0x77, 0x1e, 0x8f, 0xb, 0x33, 0x7d, 0x7e, 0xd9, 0x2f, 0x3b, 0x73, 0x5f");
  // enum VkResult (struct VkDevice_T *, unsigned long, struct VkImageDrmFormatModifierPropertiesEXT *)
  MAKE_CALLBACK_THUNK(callback_384, enum VkResult (struct VkDevice_T *, unsigned long, struct VkImageDrmFormatModifierPropertiesEXT *), "0x17, 0xab, 0x9d, 0xb, 0x3a, 0x28, 0xcc, 0x77, 0x28, 0xbd, 0x45, 0xed, 0x15, 0x1e, 0xe5, 0x79, 0xa9, 0xa2, 0x11, 0xdc, 0x1f, 0x7b, 0x89, 0x10, 0x12, 0xf, 0x4e, 0x45, 0x95, 0x93, 0x2f, 0x77");
  // void (struct VkQueue_T *, const struct VkDebugUtilsLabelEXT *)
  MAKE_CALLBACK_THUNK(callback_385, void (struct VkQueue_T *, const struct VkDebugUtilsLabelEXT *), "0xc0, 0xea, 0x8d, 0xd0, 0x98, 0x7e, 0x1, 0xc9, 0xad, 0x21, 0x4a, 0x4d, 0x3b, 0xdc, 0xe4, 0xc6, 0x5b, 0x5e, 0x92, 0x28, 0x44, 0x6d, 0x14, 0x9b, 0xf4, 0xeb, 0x5a, 0xda, 0xda, 0x70, 0x1d, 0xf1");
  // void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceFeatures *)
  MAKE_CALLBACK_THUNK(callback_386, void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceFeatures *), "0xb6, 0x5e, 0x28, 0xc3, 0xaf, 0x16, 0x8c, 0x1b, 0xf4, 0xa0, 0x7a, 0xd6, 0x70, 0x88, 0xc0, 0x20, 0x54, 0x70, 0x55, 0xe2, 0xdb, 0x3a, 0x9, 0x96, 0x43, 0xd0, 0xce, 0x5e, 0x4a, 0x8b, 0xa9, 0xbd");
  // enum VkResult (struct VkDevice_T *, const struct VkImportFenceFdInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_388, enum VkResult (struct VkDevice_T *, const struct VkImportFenceFdInfoKHR *), "0x99, 0xa9, 0x4, 0x17, 0x24, 0x3a, 0xf, 0x51, 0x40, 0x5, 0xfa, 0x13, 0xbb, 0xc8, 0x67, 0xeb, 0x47, 0x6, 0xf9, 0x84, 0x38, 0x50, 0x52, 0xf7, 0xa5, 0x3, 0xf8, 0xd6, 0x77, 0x12, 0x1d, 0x3e");
  // void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, unsigned int, const struct VkBufferImageCopy *)
  MAKE_CALLBACK_THUNK(callback_390, void (struct VkCommandBuffer_T *, unsigned long, enum VkImageLayout, unsigned long, unsigned int, const struct VkBufferImageCopy *), "0xad, 0x4b, 0xea, 0xef, 0xa9, 0x6e, 0x80, 0x5e, 0xf5, 0xb3, 0xa6, 0x68, 0xd5, 0x50, 0xdd, 0xc3, 0x20, 0xfc, 0x7e, 0x96, 0x42, 0xd3, 0xd0, 0x14, 0x1, 0xf3, 0xe6, 0x67, 0x7e, 0x3b, 0xb4, 0xd3");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, const void *)
  MAKE_CALLBACK_THUNK(callback_391, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, const void *), "0xb4, 0x95, 0x7f, 0xd4, 0x47, 0x5d, 0xe4, 0xbc, 0x36, 0xc9, 0x21, 0x64, 0xa7, 0x1b, 0xed, 0x58, 0x70, 0x87, 0xb1, 0x21, 0xe, 0x75, 0xb1, 0x3e, 0x39, 0x92, 0x15, 0x9d, 0x59, 0x95, 0x12, 0xc6");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineInfoKHR *, unsigned int *, struct VkPipelineExecutablePropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_393, enum VkResult (struct VkDevice_T *, const struct VkPipelineInfoKHR *, unsigned int *, struct VkPipelineExecutablePropertiesKHR *), "0x99, 0x52, 0x16, 0xa2, 0x9c, 0xc7, 0x30, 0xc5, 0x46, 0x4a, 0xe1, 0x30, 0x8c, 0x3d, 0x91, 0x69, 0x63, 0x48, 0x41, 0xac, 0xe, 0x2b, 0x7a, 0xc1, 0x3b, 0x3b, 0x33, 0x9a, 0x18, 0xd4, 0x7f, 0x84");
  // void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int, unsigned int, const struct VkWriteDescriptorSet *)
  MAKE_CALLBACK_THUNK(callback_395, void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int, unsigned int, const struct VkWriteDescriptorSet *), "0xd3, 0x5a, 0xba, 0x3f, 0xc5, 0x6, 0xd4, 0x2c, 0xa7, 0xcc, 0x75, 0xa8, 0x9b, 0xc5, 0xba, 0xfd, 0x62, 0xbd, 0xb5, 0x99, 0x64, 0x4a, 0xf9, 0x54, 0x5b, 0xda, 0x28, 0xa, 0x65, 0xb8, 0x89, 0xd6");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, unsigned int, const struct VkMemoryBarrier *, unsigned int, const struct VkBufferMemoryBarrier *, unsigned int, const struct VkImageMemoryBarrier *)
  MAKE_CALLBACK_THUNK(callback_397, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, unsigned int, const struct VkMemoryBarrier *, unsigned int, const struct VkBufferMemoryBarrier *, unsigned int, const struct VkImageMemoryBarrier *), "0x12, 0x3, 0xee, 0x8c, 0xd8, 0x44, 0xb9, 0x30, 0xd7, 0x3b, 0x49, 0x29, 0x33, 0xe, 0x1a, 0xe3, 0x47, 0x34, 0x71, 0x7c, 0x93, 0xc2, 0x81, 0x8e, 0xeb, 0xa8, 0xc, 0x7f, 0x6d, 0x27, 0x61, 0xc3");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeMatrixPropertiesNV *)
  MAKE_CALLBACK_THUNK(callback_400, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeMatrixPropertiesNV *), "0xd4, 0x9d, 0x41, 0xfd, 0x5, 0x2, 0x32, 0xe1, 0x14, 0xda, 0x5, 0x90, 0x3d, 0xba, 0x68, 0x75, 0x94, 0x77, 0x8, 0x25, 0xd4, 0xbb, 0xa4, 0x8c, 0x3a, 0x44, 0x4b, 0xef, 0xde, 0x26, 0xdd, 0xf1");
  // void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int, unsigned int, const unsigned long *, unsigned int, const unsigned int *)
  MAKE_CALLBACK_THUNK(callback_402, void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int, unsigned int, const unsigned long *, unsigned int, const unsigned int *), "0xa4, 0x66, 0x85, 0x8d, 0x9b, 0xd0, 0x61, 0xde, 0xe1, 0xc6, 0x9f, 0xea, 0x15, 0xe8, 0x11, 0x33, 0xd0, 0x75, 0xe3, 0x81, 0x9f, 0xfa, 0x51, 0xff, 0xa3, 0xb6, 0x70, 0x16, 0x44, 0xc7, 0x47, 0xac");
  // enum VkResult (struct VkDevice_T *, const struct VkBufferViewCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_403, enum VkResult (struct VkDevice_T *, const struct VkBufferViewCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x4f, 0x83, 0x10, 0x2f, 0x23, 0x4e, 0x29, 0xe6, 0x4c, 0x19, 0x3d, 0xea, 0x6c, 0xc8, 0x63, 0xb6, 0xd6, 0x6, 0x1d, 0xa1, 0xa3, 0x6e, 0x52, 0xad, 0x97, 0xc3, 0xad, 0x6f, 0x76, 0x62, 0xcc, 0xf");
  // enum VkResult (struct VkDevice_T *, const struct VkShaderModuleCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_404, enum VkResult (struct VkDevice_T *, const struct VkShaderModuleCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xd3, 0x84, 0x36, 0x25, 0x9, 0xd8, 0xf8, 0xba, 0xe8, 0xe4, 0x51, 0xf0, 0xf7, 0xf4, 0xca, 0x33, 0x8a, 0x91, 0x2e, 0x1d, 0xf4, 0xd9, 0x4f, 0x60, 0xe8, 0x9c, 0xc3, 0xf0, 0x2a, 0x6d, 0x28, 0x78");
  // void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceSparseImageFormatInfo2 *, unsigned int *, struct VkSparseImageFormatProperties2 *)
  MAKE_CALLBACK_THUNK(callback_405, void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceSparseImageFormatInfo2 *, unsigned int *, struct VkSparseImageFormatProperties2 *), "0x30, 0x29, 0xaf, 0xa5, 0x44, 0x1a, 0xdf, 0x47, 0x44, 0x47, 0xf5, 0x34, 0xfc, 0x53, 0x33, 0xf1, 0xb9, 0x31, 0x33, 0x20, 0xbe, 0x0, 0xaf, 0xe3, 0x7b, 0xf, 0x2d, 0xa7, 0xaf, 0x90, 0xfb, 0x21");
  // void (struct VkDevice_T *, unsigned long, unsigned int, const struct VkWriteIndirectExecutionSetPipelineEXT *)
  MAKE_CALLBACK_THUNK(callback_407, void (struct VkDevice_T *, unsigned long, unsigned int, const struct VkWriteIndirectExecutionSetPipelineEXT *), "0x1, 0x38, 0xaf, 0x6e, 0x6b, 0x40, 0x2a, 0x46, 0x63, 0x69, 0x35, 0x8b, 0xc0, 0xc7, 0x90, 0xce, 0xe9, 0x6e, 0xbe, 0x79, 0x9d, 0x1e, 0x61, 0x10, 0x9d, 0xa0, 0x36, 0x9d, 0xd1, 0x8e, 0x32, 0xfc");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkColorBlendAdvancedEXT *)
  MAKE_CALLBACK_THUNK(callback_408, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkColorBlendAdvancedEXT *), "0xf8, 0xa, 0xf5, 0xe9, 0x7a, 0xcf, 0x76, 0x4f, 0x7f, 0x7b, 0x72, 0x12, 0x6e, 0xf, 0xbf, 0x6f, 0x79, 0x2e, 0xb4, 0x8d, 0xaf, 0xab, 0xbe, 0x15, 0xb1, 0x4b, 0xd5, 0x18, 0xcc, 0xe4, 0xf1, 0xad");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyAccelerationStructureInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_410, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyAccelerationStructureInfoKHR *), "0x14, 0x3e, 0xc6, 0x2b, 0x1b, 0xd2, 0xff, 0xbd, 0x74, 0x23, 0x5, 0x9a, 0x9c, 0xb1, 0xc0, 0xff, 0x53, 0x4b, 0x28, 0xca, 0x8, 0xe9, 0xae, 0xa5, 0x11, 0xb8, 0xb2, 0xd6, 0x26, 0xc9, 0xcd, 0x26");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkMicromapBuildInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_411, void (struct VkCommandBuffer_T *, unsigned int, const struct VkMicromapBuildInfoEXT *), "0x32, 0xb5, 0x49, 0x36, 0xd8, 0xc4, 0xa9, 0xa4, 0x13, 0xfa, 0xe9, 0xc2, 0x57, 0x31, 0xaf, 0x57, 0xaf, 0x6a, 0x3d, 0x94, 0x4c, 0x91, 0x7c, 0x7d, 0x3c, 0xaf, 0x1c, 0x9d, 0x6a, 0x43, 0x77, 0x92");
  // void (struct VkDevice_T *, unsigned long, void **)
  MAKE_CALLBACK_THUNK(callback_414, void (struct VkDevice_T *, unsigned long, void **), "0x1a, 0xbc, 0x2b, 0x4b, 0x43, 0xe1, 0x60, 0xe9, 0x69, 0xc, 0xb0, 0x72, 0xc4, 0xb7, 0x94, 0x24, 0xf6, 0x8d, 0x66, 0xe7, 0x25, 0xa2, 0xb1, 0xd8, 0x58, 0x63, 0x9, 0x58, 0x6d, 0x6b, 0x2c, 0xc7");
  // void (struct VkCommandBuffer_T *, unsigned int, const unsigned int *)
  MAKE_CALLBACK_THUNK(callback_416, void (struct VkCommandBuffer_T *, unsigned int, const unsigned int *), "0x4e, 0xc2, 0x17, 0x36, 0xb2, 0xd2, 0x60, 0xc5, 0x75, 0xeb, 0x5c, 0xbf, 0xae, 0x6a, 0x40, 0xd, 0xeb, 0xf3, 0x4e, 0x2f, 0x16, 0x11, 0xf6, 0x49, 0xd, 0x4, 0xc6, 0x9f, 0x78, 0x4f, 0x4c, 0x57");
  // enum VkResult (struct VkDevice_T *, const struct VkDescriptorUpdateTemplateCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_418, enum VkResult (struct VkDevice_T *, const struct VkDescriptorUpdateTemplateCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xbe, 0x9b, 0x55, 0x72, 0xd9, 0xb5, 0xbf, 0x81, 0x5a, 0x33, 0x2, 0xb5, 0xd5, 0x9d, 0x35, 0x8a, 0xca, 0xfc, 0xdd, 0xcd, 0x45, 0xd7, 0xd6, 0x8, 0xb8, 0x62, 0xd3, 0x67, 0x81, 0x5a, 0xcf, 0x2d");
  // enum VkResult (struct VkPhysicalDevice_T *, int, unsigned long)
  MAKE_CALLBACK_THUNK(callback_420, enum VkResult (struct VkPhysicalDevice_T *, int, unsigned long), "0xeb, 0x81, 0x81, 0x9e, 0xc8, 0xab, 0x5c, 0x7b, 0xe1, 0xcc, 0x8a, 0x22, 0x88, 0x1e, 0x18, 0xfc, 0x31, 0xd2, 0x52, 0xa4, 0x3f, 0x8f, 0xd2, 0x7c, 0x5, 0xa6, 0x7d, 0xf6, 0x24, 0x23, 0xfd, 0xfb");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineCacheCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_421, enum VkResult (struct VkDevice_T *, const struct VkPipelineCacheCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xca, 0x98, 0x5, 0xe4, 0xad, 0x7f, 0x69, 0x1b, 0x5c, 0xaf, 0xa9, 0xb3, 0x3a, 0x4c, 0x3, 0xeb, 0xe2, 0xc3, 0xaf, 0x45, 0xe, 0x58, 0xab, 0x99, 0x4c, 0x49, 0xb7, 0xe8, 0x52, 0xaa, 0x49, 0x56");
  // void (struct VkCommandBuffer_T *, const struct VkDependencyInfo *)
  MAKE_CALLBACK_THUNK(callback_423, void (struct VkCommandBuffer_T *, const struct VkDependencyInfo *), "0xa7, 0x1d, 0x24, 0x50, 0xad, 0xd5, 0x72, 0xc7, 0x1d, 0x27, 0x9b, 0x78, 0x43, 0x3f, 0xa4, 0x18, 0xae, 0x8d, 0xcd, 0x63, 0x98, 0x95, 0xb3, 0xb1, 0x23, 0xa3, 0xc7, 0x93, 0x66, 0x1d, 0x18, 0x5");
  // void (struct VkCommandBuffer_T *, const struct VkPerTileEndInfoQCOM *)
  MAKE_CALLBACK_THUNK(callback_424, void (struct VkCommandBuffer_T *, const struct VkPerTileEndInfoQCOM *), "0x56, 0x5a, 0x31, 0x56, 0x82, 0xc5, 0x6, 0x69, 0x3f, 0xc8, 0x5e, 0xd2, 0xb1, 0xea, 0xbc, 0xa7, 0x42, 0x8f, 0x67, 0xd5, 0x72, 0x33, 0x52, 0x7a, 0x43, 0xd1, 0x2a, 0x19, 0x5b, 0xdb, 0x63, 0x78");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineLayoutCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_426, enum VkResult (struct VkDevice_T *, const struct VkPipelineLayoutCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0xb2, 0x64, 0xd5, 0x79, 0xa0, 0x59, 0x17, 0x68, 0xb3, 0x31, 0x68, 0x50, 0x35, 0x6, 0xf7, 0x87, 0x6d, 0x64, 0x83, 0x31, 0x5, 0x77, 0x13, 0x90, 0x1b, 0xc2, 0x8f, 0x81, 0xbe, 0xd8, 0x55, 0xe2");
  // void (struct VkCommandBuffer_T *, float, float)
  MAKE_CALLBACK_THUNK(callback_428, void (struct VkCommandBuffer_T *, float, float), "0x17, 0xa4, 0x9d, 0xd2, 0x90, 0xb2, 0x71, 0x4d, 0xde, 0x50, 0xed, 0xe5, 0xef, 0x3f, 0x7b, 0x4c, 0xcc, 0x6f, 0x59, 0xbb, 0x7b, 0x3b, 0x13, 0xea, 0xf0, 0xf2, 0xf9, 0x20, 0x79, 0xf9, 0x90, 0x86");
  // void (struct VkCommandBuffer_T *, const struct VkBlitImageInfo2 *)
  MAKE_CALLBACK_THUNK(callback_430, void (struct VkCommandBuffer_T *, const struct VkBlitImageInfo2 *), "0xa6, 0x97, 0xfb, 0xce, 0x9e, 0xdf, 0x37, 0x45, 0x1e, 0x4d, 0x0, 0x21, 0xec, 0x63, 0xdf, 0x86, 0x63, 0xf6, 0x40, 0x59, 0x26, 0x62, 0xdc, 0xaa, 0xc3, 0xb7, 0xee, 0x41, 0xd5, 0xf4, 0x41, 0xb6");
  // void (struct VkCommandBuffer_T *, const struct VkVideoBeginCodingInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_433, void (struct VkCommandBuffer_T *, const struct VkVideoBeginCodingInfoKHR *), "0x6f, 0x16, 0xc6, 0x82, 0xf2, 0xf1, 0xaf, 0x92, 0x53, 0xee, 0x7c, 0x45, 0x93, 0xe8, 0x54, 0x42, 0xbe, 0x8e, 0x2e, 0x2b, 0x44, 0x7f, 0x61, 0x6b, 0xdb, 0xd0, 0x4b, 0x35, 0xe, 0xb0, 0x7e, 0x49");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyAccelerationStructureToMemoryInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_437, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyAccelerationStructureToMemoryInfoKHR *), "0x16, 0xda, 0x25, 0xb0, 0x1f, 0x7, 0xa9, 0x4c, 0xdc, 0x5f, 0xe0, 0x94, 0xb2, 0xa0, 0x61, 0x8, 0x63, 0x1c, 0x26, 0x3a, 0x89, 0x41, 0xf6, 0xbc, 0x9f, 0xb, 0x79, 0x8e, 0xf3, 0x7c, 0xae, 0xa4");
  // void (struct VkCommandBuffer_T *, enum VkPipelineStageFlagBits, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_438, void (struct VkCommandBuffer_T *, enum VkPipelineStageFlagBits, unsigned long, unsigned int), "0xaa, 0x8b, 0xe4, 0x50, 0x18, 0xe5, 0xdc, 0x77, 0xbf, 0x16, 0xe3, 0xc, 0xa5, 0x7d, 0x6c, 0x84, 0xdc, 0x64, 0x3a, 0xdf, 0x74, 0x36, 0x2a, 0xd5, 0x53, 0xf8, 0x4a, 0xe1, 0x89, 0x9d, 0xf4, 0x50");
  // enum VkResult (struct VkDevice_T *, const struct VkRenderPassCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_439, enum VkResult (struct VkDevice_T *, const struct VkRenderPassCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x1, 0xf7, 0x89, 0x74, 0xfd, 0x31, 0xf9, 0xce, 0x73, 0x5b, 0x3c, 0x36, 0xb0, 0xbc, 0xf, 0x4, 0xcf, 0x4a, 0xa8, 0xc1, 0x23, 0x76, 0x90, 0x7b, 0xb7, 0x9d, 0x2e, 0x38, 0x34, 0xc4, 0x21, 0x22");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_440, void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int), "0x36, 0xc9, 0x87, 0xaf, 0x65, 0x27, 0x3c, 0x74, 0xb1, 0xc9, 0xe2, 0x85, 0xd6, 0xcf, 0xe6, 0x8b, 0xd4, 0x7d, 0xb9, 0x88, 0x69, 0x64, 0x68, 0xae, 0xd7, 0x92, 0x33, 0x5f, 0xcd, 0xc1, 0x6a, 0xe7");
  // void (struct VkDevice_T *, const struct VkAllocationCallbacks *)
  MAKE_CALLBACK_THUNK(callback_442, void (struct VkDevice_T *, const struct VkAllocationCallbacks *), "0x8b, 0x84, 0x82, 0xef, 0x86, 0xc6, 0x7f, 0xce, 0x48, 0xec, 0xca, 0xe8, 0x4b, 0xf6, 0x97, 0xdc, 0x46, 0x84, 0xed, 0x89, 0xcd, 0xa0, 0x48, 0xc6, 0xa1, 0x19, 0xf6, 0x44, 0x88, 0x34, 0xd9, 0xcf");
  // void (struct VkDevice_T *, unsigned int, const struct VkWriteDescriptorSet *, unsigned int, const struct VkCopyDescriptorSet *)
  MAKE_CALLBACK_THUNK(callback_443, void (struct VkDevice_T *, unsigned int, const struct VkWriteDescriptorSet *, unsigned int, const struct VkCopyDescriptorSet *), "0x9f, 0x80, 0x23, 0x40, 0x3d, 0x1d, 0xf, 0x9c, 0x27, 0x4d, 0x4c, 0xe9, 0xc4, 0x96, 0xf2, 0x45, 0xcd, 0x20, 0xf8, 0xf1, 0xdf, 0xaf, 0x56, 0xb3, 0x3a, 0x53, 0x31, 0xdf, 0x65, 0x9b, 0x9a, 0xc4");
  // void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalBufferInfo *, struct VkExternalBufferProperties *)
  MAKE_CALLBACK_THUNK(callback_449, void (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceExternalBufferInfo *, struct VkExternalBufferProperties *), "0xa5, 0x5b, 0x2a, 0x1e, 0x77, 0x15, 0xce, 0xa7, 0xdd, 0x47, 0x38, 0x1, 0x36, 0xa6, 0xad, 0x8b, 0xf8, 0x4a, 0x4b, 0x7e, 0xd, 0x6, 0xe7, 0x12, 0xa1, 0x8e, 0xfd, 0x92, 0x5d, 0x18, 0xe7, 0xd4");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayPropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_452, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayPropertiesKHR *), "0x25, 0x9b, 0x39, 0x85, 0x5d, 0xd4, 0x72, 0x5f, 0x88, 0x3e, 0x4f, 0x2e, 0xa6, 0x9f, 0xd2, 0x3, 0x81, 0x37, 0x4a, 0x20, 0x41, 0x5e, 0x53, 0x33, 0xee, 0x38, 0x26, 0xe6, 0x85, 0x54, 0x4e, 0xd");
  // void (struct VkCommandBuffer_T *, enum VkDiscardRectangleModeEXT)
  MAKE_CALLBACK_THUNK(callback_453, void (struct VkCommandBuffer_T *, enum VkDiscardRectangleModeEXT), "0x89, 0xad, 0xb0, 0xe0, 0x42, 0x7c, 0xff, 0xc8, 0xea, 0x9e, 0x29, 0xa0, 0x7b, 0x9d, 0xc8, 0x9f, 0xc2, 0x1b, 0x51, 0x9, 0xb8, 0x37, 0xf3, 0x83, 0x1f, 0xb2, 0xc8, 0xef, 0x18, 0x3e, 0xce, 0xe1");
  // void (struct VkDevice_T *, unsigned long, struct VkExtent2D *)
  MAKE_CALLBACK_THUNK(callback_455, void (struct VkDevice_T *, unsigned long, struct VkExtent2D *), "0xe8, 0x62, 0x16, 0xb, 0x7a, 0xda, 0x37, 0x26, 0x38, 0xfc, 0x7f, 0xf, 0x10, 0x85, 0x92, 0x60, 0x5e, 0x52, 0xa7, 0x40, 0x2a, 0x2a, 0x4f, 0x71, 0x6e, 0xc9, 0xa3, 0x5e, 0xab, 0x2e, 0xf2, 0xaf");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkViewport *)
  MAKE_CALLBACK_THUNK(callback_456, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkViewport *), "0xaf, 0xec, 0xeb, 0x27, 0xc9, 0xde, 0x87, 0x1e, 0xbb, 0xe, 0x25, 0xd1, 0x26, 0x88, 0x69, 0x4, 0x38, 0x17, 0xa9, 0xc, 0x36, 0xa, 0xf5, 0xff, 0x57, 0x55, 0xeb, 0xd4, 0x78, 0x1c, 0x78, 0xdf");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkRect2D *)
  MAKE_CALLBACK_THUNK(callback_457, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkRect2D *), "0xea, 0x67, 0x2a, 0x57, 0x24, 0x20, 0x47, 0xce, 0xfd, 0xfc, 0x16, 0xad, 0xb1, 0x26, 0xdb, 0x12, 0xb6, 0x4c, 0xe2, 0xd5, 0xbc, 0x1b, 0xc0, 0x90, 0xd8, 0xa0, 0xd0, 0x87, 0xfd, 0xba, 0x8e, 0xaa");
  // enum VkResult (struct VkQueue_T *, unsigned int, const struct VkSubmitInfo2 *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_460, enum VkResult (struct VkQueue_T *, unsigned int, const struct VkSubmitInfo2 *, unsigned long), "0x55, 0x39, 0x61, 0x4a, 0x8c, 0xf4, 0x89, 0xe9, 0x83, 0x3b, 0x91, 0x97, 0xe, 0xde, 0xfd, 0x47, 0x19, 0xb5, 0xcb, 0x9b, 0xf2, 0xd9, 0x74, 0x4a, 0x10, 0x5d, 0x51, 0xc2, 0x19, 0xdd, 0x60, 0x64");
  // void (struct VkCommandBuffer_T *, enum VkCoverageReductionModeNV)
  MAKE_CALLBACK_THUNK(callback_461, void (struct VkCommandBuffer_T *, enum VkCoverageReductionModeNV), "0xdf, 0x8a, 0xc0, 0x19, 0xe9, 0x9f, 0x30, 0x8, 0x2a, 0x81, 0x1d, 0x88, 0x2b, 0xed, 0x2b, 0xeb, 0xe4, 0x3d, 0xb7, 0x29, 0x31, 0xee, 0x77, 0xb8, 0xd0, 0x55, 0xba, 0x76, 0x41, 0xe2, 0x3b, 0xdb");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, struct VkVideoSessionMemoryRequirementsKHR *)
  MAKE_CALLBACK_THUNK(callback_464, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, struct VkVideoSessionMemoryRequirementsKHR *), "0x9e, 0x78, 0x30, 0x2, 0x0, 0xc5, 0xe0, 0xc8, 0xe1, 0xf1, 0xe, 0xfe, 0x1e, 0xfe, 0x8b, 0x4c, 0xc1, 0x12, 0xc7, 0x2, 0x3, 0x89, 0x88, 0x20, 0x1d, 0x15, 0xb2, 0xb6, 0x1c, 0x50, 0xf, 0x44");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkVideoSessionParametersUpdateInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_465, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkVideoSessionParametersUpdateInfoKHR *), "0x65, 0xae, 0xa4, 0x6c, 0xdf, 0x28, 0xe7, 0xeb, 0x33, 0xaa, 0xde, 0xcf, 0x28, 0x5e, 0xcc, 0xf4, 0xe2, 0x68, 0xdc, 0x5e, 0x12, 0xbc, 0x45, 0x8b, 0x22, 0xbd, 0xdf, 0x73, 0xf7, 0xce, 0xf, 0x51");
  // void (struct VkCommandBuffer_T *, const struct VkVideoCodingControlInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_469, void (struct VkCommandBuffer_T *, const struct VkVideoCodingControlInfoKHR *), "0xda, 0x27, 0x62, 0x83, 0xff, 0x13, 0x4e, 0xf7, 0x54, 0xc8, 0x50, 0xdb, 0x10, 0x12, 0x4b, 0xd7, 0xd1, 0x86, 0x2d, 0xd9, 0x48, 0x4b, 0x34, 0xee, 0xaa, 0x38, 0x3, 0x1, 0xe, 0x8b, 0x7d, 0x7e");
  // void (struct VkCommandBuffer_T *, const struct VkRenderPassBeginInfo *, enum VkSubpassContents)
  MAKE_CALLBACK_THUNK(callback_470, void (struct VkCommandBuffer_T *, const struct VkRenderPassBeginInfo *, enum VkSubpassContents), "0xc9, 0x30, 0x86, 0x88, 0xf3, 0xcd, 0xd9, 0xb7, 0x9c, 0x79, 0x54, 0x7d, 0x10, 0x7c, 0x2a, 0x7d, 0xd1, 0x9f, 0xac, 0x62, 0xe8, 0xbd, 0x48, 0xb2, 0xd9, 0xfb, 0xf3, 0x4d, 0x74, 0xa0, 0x5a, 0xa0");
  // void (struct VkCommandBuffer_T *, const struct VkCopyMemoryIndirectInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_471, void (struct VkCommandBuffer_T *, const struct VkCopyMemoryIndirectInfoKHR *), "0xb4, 0x7c, 0x73, 0xd7, 0xb6, 0x7c, 0xf9, 0xc1, 0xd2, 0xa0, 0x13, 0xf1, 0x3, 0xfb, 0x51, 0x5a, 0xc1, 0x9a, 0x29, 0x5a, 0x26, 0x7d, 0xab, 0x71, 0x3c, 0xad, 0x7d, 0x10, 0x8e, 0xd9, 0x13, 0x3e");
  // void (struct VkCommandBuffer_T *, const struct VkVideoDecodeInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_472, void (struct VkCommandBuffer_T *, const struct VkVideoDecodeInfoKHR *), "0x24, 0x11, 0x66, 0x9, 0xe4, 0xa7, 0x5d, 0x45, 0x2, 0x32, 0xf1, 0x11, 0x9c, 0xe5, 0x8e, 0x79, 0x4d, 0x47, 0x22, 0xc7, 0x8, 0xce, 0xbf, 0xd5, 0x46, 0x4c, 0x30, 0x8d, 0x51, 0xcb, 0xd8, 0x78");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, enum VkCopyAccelerationStructureModeKHR)
  MAKE_CALLBACK_THUNK(callback_473, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, enum VkCopyAccelerationStructureModeKHR), "0x3c, 0x71, 0xb5, 0xf7, 0x19, 0xf8, 0x2, 0x39, 0x27, 0xd4, 0x41, 0x3a, 0xb0, 0x62, 0x12, 0x12, 0x72, 0x86, 0x6d, 0x6e, 0x1f, 0x96, 0x4a, 0x24, 0x5d, 0x33, 0xc4, 0xf4, 0x4a, 0x66, 0x81, 0x88");
  // enum VkResult (struct VkInstance_T *, unsigned int *, struct VkPhysicalDevice_T **)
  MAKE_CALLBACK_THUNK(callback_475, enum VkResult (struct VkInstance_T *, unsigned int *, struct VkPhysicalDevice_T **), "0x73, 0xee, 0xf0, 0xa6, 0x8a, 0x61, 0x66, 0x28, 0x7d, 0xa6, 0xb2, 0x64, 0x68, 0xb5, 0xfa, 0xee, 0x2, 0x13, 0xef, 0x8, 0x52, 0xd3, 0x92, 0x6a, 0xbd, 0x3b, 0xc4, 0xcc, 0x48, 0xe1, 0x95, 0x79");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_476, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned int), "0x50, 0x50, 0xaa, 0x44, 0x85, 0x27, 0x6b, 0xd0, 0xb1, 0x43, 0x54, 0xb0, 0xab, 0x87, 0x76, 0x94, 0x7e, 0xcb, 0xd4, 0xe5, 0x8e, 0xe9, 0x89, 0xa5, 0x26, 0xbb, 0x1, 0xba, 0x2f, 0x36, 0x6c, 0x14");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkViewportWScalingNV *)
  MAKE_CALLBACK_THUNK(callback_479, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkViewportWScalingNV *), "0x79, 0xfe, 0x62, 0xfc, 0x58, 0xbc, 0x72, 0x5b, 0x5e, 0x54, 0x82, 0xe4, 0x28, 0xf1, 0x4a, 0x33, 0x4f, 0x9a, 0x2c, 0xe7, 0x79, 0xd1, 0xb5, 0x46, 0x4a, 0x75, 0x68, 0x56, 0x2e, 0xf5, 0x89, 0x2");
  // void (struct VkCommandBuffer_T *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_480, void (struct VkCommandBuffer_T *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, const struct VkStridedDeviceAddressRegionKHR *, unsigned long), "0xaf, 0xdd, 0xa4, 0x12, 0x66, 0x63, 0x5a, 0x81, 0x12, 0x8, 0x28, 0x92, 0xcc, 0x29, 0xb1, 0x72, 0xea, 0xef, 0x9f, 0x4c, 0x1b, 0x24, 0x3f, 0xcf, 0x42, 0x5c, 0xd8, 0x1e, 0x50, 0x38, 0x12, 0x39");
  // enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineInfoARM *, unsigned int, struct VkDataGraphPipelinePropertyQueryResultARM *)
  MAKE_CALLBACK_THUNK(callback_482, enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineInfoARM *, unsigned int, struct VkDataGraphPipelinePropertyQueryResultARM *), "0x4a, 0xa8, 0x93, 0x21, 0x6, 0x4c, 0x4e, 0x73, 0xd9, 0x22, 0x21, 0xbc, 0x9c, 0xb7, 0x54, 0x64, 0x7f, 0xd3, 0x7a, 0x86, 0xa7, 0xd5, 0x68, 0xca, 0xbe, 0x2e, 0xd2, 0xb7, 0x70, 0x4b, 0x41, 0x9a");
  // void (struct VkCommandBuffer_T *, const float *)
  MAKE_CALLBACK_THUNK(callback_483, void (struct VkCommandBuffer_T *, const float *), "0xf1, 0x65, 0xff, 0xe2, 0x4f, 0xb7, 0x97, 0xaf, 0xf7, 0x26, 0xcf, 0xbb, 0xc0, 0xc5, 0x49, 0xaf, 0xef, 0x91, 0xcf, 0xad, 0x3b, 0x3, 0x17, 0x34, 0xec, 0xeb, 0xf8, 0xe9, 0x74, 0x37, 0xd3, 0xa3");
  // void (struct VkCommandBuffer_T *, unsigned int, struct VkCommandBuffer_T *const *)
  MAKE_CALLBACK_THUNK(callback_485, void (struct VkCommandBuffer_T *, unsigned int, struct VkCommandBuffer_T *const *), "0x11, 0x7c, 0x37, 0x1, 0xd4, 0xfc, 0x92, 0xce, 0x1a, 0xf8, 0xba, 0x35, 0x3f, 0x55, 0x28, 0x9d, 0x0, 0x29, 0x9f, 0xe4, 0xab, 0x14, 0xc4, 0xe6, 0x15, 0x9d, 0x68, 0x4c, 0x83, 0x49, 0xb7, 0x10");
  // void (struct VkQueue_T *, const struct VkOutOfBandQueueTypeInfoNV *)
  MAKE_CALLBACK_THUNK(callback_487, void (struct VkQueue_T *, const struct VkOutOfBandQueueTypeInfoNV *), "0xe2, 0xef, 0xfb, 0xf1, 0x4d, 0xbe, 0x48, 0x8c, 0x2f, 0xe4, 0x75, 0xd7, 0xba, 0x61, 0xb1, 0x38, 0xe, 0x28, 0x9c, 0xaf, 0x9d, 0xba, 0x77, 0xf8, 0x24, 0x47, 0x5b, 0xfe, 0xd9, 0x1e, 0xd6, 0x5b");
  // enum VkResult (struct VkDevice_T *, const struct VkMemoryGetFdInfoKHR *, int *)
  MAKE_CALLBACK_THUNK(callback_488, enum VkResult (struct VkDevice_T *, const struct VkMemoryGetFdInfoKHR *, int *), "0x39, 0x7c, 0x8d, 0x5d, 0xf8, 0xcc, 0x82, 0x64, 0x9f, 0xfd, 0xfd, 0x2b, 0x94, 0xa7, 0x91, 0x9c, 0xc9, 0xe9, 0xfb, 0xc9, 0x97, 0x20, 0xdd, 0x52, 0x74, 0xcb, 0xb7, 0xed, 0xee, 0xd1, 0xbf, 0xe5");
  // enum VkResult (struct VkCommandBuffer_T *, const struct VkCommandBufferBeginInfo *)
  MAKE_CALLBACK_THUNK(callback_494, enum VkResult (struct VkCommandBuffer_T *, const struct VkCommandBufferBeginInfo *), "0x4a, 0xf9, 0xfc, 0xf9, 0x70, 0xfa, 0x16, 0x96, 0xf, 0x9f, 0xc1, 0x6b, 0xcd, 0x41, 0xec, 0xdb, 0x7c, 0x7b, 0xaa, 0x4d, 0x6e, 0xb1, 0x44, 0x89, 0x8a, 0x86, 0x6d, 0x77, 0x54, 0xb4, 0xbb, 0xf4");
  // enum VkResult (struct VkDevice_T *, const struct VkFenceGetFdInfoKHR *, int *)
  MAKE_CALLBACK_THUNK(callback_495, enum VkResult (struct VkDevice_T *, const struct VkFenceGetFdInfoKHR *, int *), "0x4, 0x22, 0xee, 0x98, 0x70, 0xe0, 0x1f, 0xd3, 0x45, 0x1b, 0xe2, 0x25, 0x7a, 0xa4, 0xbd, 0x3d, 0xe2, 0x7d, 0x93, 0xa7, 0xcc, 0x18, 0x2, 0x78, 0x1d, 0x6d, 0x4, 0xe4, 0x97, 0x5, 0x47, 0xfd");
  // enum VkResult (struct VkDevice_T *, enum VkExternalMemoryHandleTypeFlagBits, int, struct VkMemoryFdPropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_496, enum VkResult (struct VkDevice_T *, enum VkExternalMemoryHandleTypeFlagBits, int, struct VkMemoryFdPropertiesKHR *), "0xd7, 0xbf, 0xe, 0x4f, 0x46, 0x75, 0x8f, 0x53, 0x58, 0xa2, 0xce, 0xa2, 0x43, 0x19, 0x31, 0x80, 0xc7, 0x1, 0x8d, 0x1e, 0x4d, 0x93, 0x89, 0xc3, 0xac, 0xc, 0xea, 0x3, 0x3d, 0x9, 0xef, 0xd4");
  // enum VkResult (struct VkDevice_T *, unsigned long, enum VkSurfaceCounterFlagBitsEXT, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_497, enum VkResult (struct VkDevice_T *, unsigned long, enum VkSurfaceCounterFlagBitsEXT, unsigned long *), "0x5c, 0x42, 0x94, 0x74, 0x12, 0xb, 0x2f, 0x8c, 0x2b, 0x1, 0x1b, 0x36, 0x2d, 0xe1, 0x18, 0x55, 0x6b, 0x3, 0x38, 0x5c, 0x63, 0xb8, 0x7b, 0x69, 0x49, 0x23, 0x55, 0x47, 0x7a, 0x3, 0x8d, 0x25");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindAccelerationStructureMemoryInfoNV *)
  MAKE_CALLBACK_THUNK(callback_498, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindAccelerationStructureMemoryInfoNV *), "0xab, 0x6c, 0x44, 0xf4, 0x61, 0x9, 0x8e, 0xa0, 0x18, 0xac, 0xef, 0x56, 0x6a, 0x28, 0x4e, 0x79, 0x23, 0x6d, 0xfe, 0x7, 0x4a, 0x6, 0x6, 0x13, 0xcc, 0x1c, 0x40, 0xf7, 0x9f, 0x76, 0x84, 0x1c");
  // void (struct VkDevice_T *, const struct VkTensorMemoryRequirementsInfoARM *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_499, void (struct VkDevice_T *, const struct VkTensorMemoryRequirementsInfoARM *, struct VkMemoryRequirements2 *), "0x1f, 0xf6, 0x1e, 0x46, 0x72, 0xc1, 0xc4, 0xa6, 0x43, 0x55, 0x30, 0xcc, 0x0, 0xe, 0xfe, 0xeb, 0xd3, 0xad, 0xb6, 0x5e, 0xcb, 0xb4, 0x1e, 0x2e, 0xf6, 0x76, 0x88, 0xb4, 0x63, 0xce, 0x13, 0x28");
  // void (struct VkDevice_T *, unsigned long, unsigned long, const void *)
  MAKE_CALLBACK_THUNK(callback_504, void (struct VkDevice_T *, unsigned long, unsigned long, const void *), "0xc9, 0x97, 0x86, 0xa9, 0x57, 0x3a, 0x8b, 0x1b, 0x44, 0x6b, 0xa1, 0x92, 0x7d, 0x1e, 0x2e, 0xda, 0xd, 0x44, 0x72, 0x6, 0xd5, 0x6e, 0x24, 0x71, 0xc5, 0x88, 0xeb, 0x39, 0xeb, 0x44, 0x20, 0xc1");
  // void (struct VkQueue_T *)
  MAKE_CALLBACK_THUNK(callback_505, void (struct VkQueue_T *), "0x5d, 0x22, 0x22, 0x33, 0xbc, 0xd5, 0x7b, 0x64, 0x34, 0x67, 0xfc, 0x1, 0x2, 0xb2, 0xc8, 0xe6, 0x1f, 0xfb, 0x97, 0xd2, 0x42, 0xc1, 0xa7, 0x76, 0xfa, 0xf1, 0x7a, 0x87, 0x8d, 0x57, 0xf7, 0x12");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, enum VkTimeDomainKHR *)
  MAKE_CALLBACK_THUNK(callback_506, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, enum VkTimeDomainKHR *), "0xd1, 0xa6, 0xc2, 0x9c, 0x30, 0xd7, 0xc7, 0x8f, 0xdd, 0x4d, 0xf, 0x76, 0x40, 0x26, 0xf7, 0xa6, 0x85, 0xef, 0x1, 0x51, 0x4b, 0xd7, 0xc5, 0x8c, 0x2, 0xa9, 0x84, 0x8f, 0x40, 0x9a, 0x12, 0xe8");
  // void (struct VkCommandBuffer_T *, enum VkPipelineStageFlagBits, unsigned long, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_507, void (struct VkCommandBuffer_T *, enum VkPipelineStageFlagBits, unsigned long, unsigned long, unsigned int), "0x67, 0xcb, 0x24, 0xc2, 0x4a, 0x36, 0x60, 0xb1, 0xef, 0x83, 0x46, 0xb5, 0x39, 0xf7, 0xdf, 0xa3, 0x7c, 0x7b, 0xbd, 0x85, 0xf6, 0xb4, 0x26, 0x1f, 0xd9, 0x4, 0x3e, 0x47, 0xd1, 0x37, 0x27, 0x4a");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, struct VkPerformanceCounterKHR *, struct VkPerformanceCounterDescriptionKHR *)
  MAKE_CALLBACK_THUNK(callback_509, enum VkResult (struct VkPhysicalDevice_T *, unsigned int, unsigned int *, struct VkPerformanceCounterKHR *, struct VkPerformanceCounterDescriptionKHR *), "0x9f, 0xdd, 0xc5, 0x52, 0xf, 0xe1, 0xd9, 0x2, 0x1a, 0xef, 0xb6, 0x39, 0xf, 0x4e, 0x35, 0xcd, 0xe, 0x6c, 0x48, 0x31, 0x10, 0x4b, 0xe8, 0xfc, 0x37, 0xf3, 0x1f, 0xcd, 0x8, 0xde, 0xe8, 0xde");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const struct VkAccelerationStructureBuildRangeInfoKHR *const *)
  MAKE_CALLBACK_THUNK(callback_510, void (struct VkCommandBuffer_T *, unsigned int, const struct VkAccelerationStructureBuildGeometryInfoKHR *, const struct VkAccelerationStructureBuildRangeInfoKHR *const *), "0xbe, 0x79, 0xf7, 0xfd, 0x64, 0x3c, 0xbd, 0x3, 0xfe, 0x33, 0xfd, 0x11, 0x2b, 0x20, 0x30, 0xbd, 0x49, 0x68, 0x91, 0xc9, 0xbe, 0x4, 0xa9, 0xd3, 0x1f, 0x99, 0x8e, 0x4d, 0x63, 0xe0, 0x5e, 0x5");
  // enum VkResult (struct VkDevice_T *, const struct VkAcquireProfilingLockInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_513, enum VkResult (struct VkDevice_T *, const struct VkAcquireProfilingLockInfoKHR *), "0x20, 0xd8, 0x99, 0x92, 0x5b, 0x34, 0xe2, 0x8a, 0x9, 0x34, 0x63, 0x62, 0x7f, 0x82, 0x88, 0x47, 0x7b, 0x95, 0x33, 0xda, 0x1b, 0x83, 0xc5, 0xc5, 0x6e, 0x40, 0x42, 0xdb, 0xf6, 0xec, 0xe2, 0x76");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceSurfaceInfo2KHR *, struct VkSurfaceCapabilities2KHR *)
  MAKE_CALLBACK_THUNK(callback_514, enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceSurfaceInfo2KHR *, struct VkSurfaceCapabilities2KHR *), "0xf, 0x37, 0x3d, 0x5e, 0xb9, 0xff, 0x1a, 0x96, 0x20, 0x35, 0x2f, 0x58, 0x48, 0xb7, 0x97, 0xad, 0x53, 0x63, 0x26, 0xec, 0xcd, 0x3b, 0x6c, 0x5f, 0xf5, 0x94, 0x23, 0xdc, 0x50, 0x1c, 0xe, 0x78");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceSurfaceInfo2KHR *, unsigned int *, struct VkSurfaceFormat2KHR *)
  MAKE_CALLBACK_THUNK(callback_515, enum VkResult (struct VkPhysicalDevice_T *, const struct VkPhysicalDeviceSurfaceInfo2KHR *, unsigned int *, struct VkSurfaceFormat2KHR *), "0x5e, 0xfc, 0x5a, 0x8a, 0x3e, 0x83, 0x1f, 0x56, 0x5b, 0xfb, 0xe3, 0x47, 0x4b, 0x78, 0xd0, 0xb2, 0x8a, 0x1d, 0x73, 0xed, 0xd7, 0x47, 0x4a, 0x2b, 0xf4, 0x4b, 0xf, 0x3b, 0xd4, 0x46, 0x79, 0xc3");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayPlaneProperties2KHR *)
  MAKE_CALLBACK_THUNK(callback_518, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkDisplayPlaneProperties2KHR *), "0x0, 0xf4, 0x81, 0x2d, 0xe1, 0xc6, 0xd2, 0xa3, 0xd0, 0xb7, 0x98, 0x7e, 0x5a, 0xd2, 0x73, 0x48, 0xa8, 0x37, 0x65, 0xac, 0xdf, 0x80, 0x96, 0x58, 0xa5, 0x2e, 0x32, 0xeb, 0xdf, 0xe5, 0x2d, 0xc5");
  // enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineInfoARM *, unsigned int *, enum VkDataGraphPipelinePropertyARM *)
  MAKE_CALLBACK_THUNK(callback_519, enum VkResult (struct VkDevice_T *, const struct VkDataGraphPipelineInfoARM *, unsigned int *, enum VkDataGraphPipelinePropertyARM *), "0x80, 0x65, 0x41, 0x3, 0x88, 0xfc, 0xa1, 0x33, 0xa4, 0x95, 0x16, 0x96, 0x2e, 0xe2, 0xd9, 0x1c, 0xd8, 0x7d, 0x50, 0xcc, 0x2a, 0x61, 0xe4, 0x1b, 0x2e, 0x1d, 0x63, 0xb2, 0xc1, 0x35, 0xae, 0xba");
  // enum VkResult (struct VkDevice_T *, const struct VkCuFunctionCreateInfoNVX *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_520, enum VkResult (struct VkDevice_T *, const struct VkCuFunctionCreateInfoNVX *, const struct VkAllocationCallbacks *, unsigned long *), "0xe4, 0xd2, 0x84, 0x70, 0x8e, 0x50, 0xbb, 0x6e, 0xe9, 0x31, 0x8b, 0xb9, 0xfe, 0x96, 0xd9, 0x8a, 0xbf, 0xac, 0x54, 0xd0, 0x40, 0xa5, 0x4a, 0x9a, 0x9, 0x9d, 0x4b, 0x96, 0xf8, 0x88, 0x1a, 0x8");
  // void (struct VkInstance_T *, const struct VkAllocationCallbacks *)
  MAKE_CALLBACK_THUNK(callback_521, void (struct VkInstance_T *, const struct VkAllocationCallbacks *), "0x15, 0x26, 0x40, 0x3b, 0x9d, 0xe8, 0x29, 0xba, 0xc3, 0xe3, 0xec, 0x9d, 0x1, 0x68, 0x62, 0xb2, 0x17, 0xee, 0x19, 0x9b, 0xb0, 0x30, 0x40, 0xf7, 0x2, 0xb4, 0xbd, 0xc0, 0x7, 0x52, 0xa6, 0x9e");
  // enum VkResult (struct VkDevice_T *, unsigned long, struct VkRefreshCycleDurationGOOGLE *)
  MAKE_CALLBACK_THUNK(callback_522, enum VkResult (struct VkDevice_T *, unsigned long, struct VkRefreshCycleDurationGOOGLE *), "0x12, 0x13, 0x69, 0x79, 0xe3, 0x30, 0xa, 0xde, 0xaa, 0x76, 0x45, 0xde, 0x83, 0x9b, 0x11, 0xbd, 0x61, 0xd3, 0x13, 0x4e, 0xd7, 0xa, 0xbb, 0x83, 0xbd, 0xdc, 0xb4, 0xf2, 0x59, 0x5a, 0xfb, 0x8f");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkDisplayModeProperties2KHR *)
  MAKE_CALLBACK_THUNK(callback_523, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkDisplayModeProperties2KHR *), "0xa4, 0x74, 0x76, 0x94, 0x76, 0x6a, 0x90, 0xa8, 0xcf, 0x1a, 0xd5, 0xc, 0xc2, 0x1f, 0xb7, 0x8d, 0xc6, 0xba, 0x4c, 0x34, 0xa6, 0xf8, 0xa0, 0x5, 0x84, 0xc9, 0x91, 0x1f, 0x1e, 0xfe, 0x34, 0x74");
  // enum VkResult (struct VkPhysicalDevice_T *, const struct VkDisplayPlaneInfo2KHR *, struct VkDisplayPlaneCapabilities2KHR *)
  MAKE_CALLBACK_THUNK(callback_524, enum VkResult (struct VkPhysicalDevice_T *, const struct VkDisplayPlaneInfo2KHR *, struct VkDisplayPlaneCapabilities2KHR *), "0x6a, 0xbf, 0xae, 0xa4, 0x60, 0xce, 0x32, 0x39, 0x9b, 0x1e, 0xc6, 0x1e, 0x1c, 0x7f, 0x44, 0x1b, 0xc7, 0xe1, 0xc9, 0x55, 0xee, 0x43, 0x2, 0xbd, 0x3f, 0x94, 0x6e, 0xbf, 0x6f, 0xb1, 0x70, 0xa6");
  // void (struct VkDevice_T *, const struct VkDeviceImageSubresourceInfo *, struct VkSubresourceLayout2 *)
  MAKE_CALLBACK_THUNK(callback_525, void (struct VkDevice_T *, const struct VkDeviceImageSubresourceInfo *, struct VkSubresourceLayout2 *), "0x93, 0x39, 0x62, 0xa9, 0x18, 0xfd, 0x7d, 0x69, 0x68, 0x2c, 0x0, 0x98, 0xa0, 0xc3, 0x9e, 0x4f, 0xba, 0x16, 0xc2, 0x8f, 0x42, 0x22, 0x4a, 0x4b, 0xdf, 0x87, 0x92, 0x32, 0xc2, 0xd5, 0x71, 0xbf");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *)
  MAKE_CALLBACK_THUNK(callback_534, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *), "0x1, 0xf, 0x84, 0xae, 0xf9, 0x44, 0x64, 0xdd, 0x29, 0x5, 0xac, 0xc3, 0xde, 0x42, 0x59, 0xd0, 0xef, 0x33, 0x50, 0x21, 0xb, 0x2b, 0x7, 0xd0, 0x80, 0xc1, 0x60, 0x39, 0x1f, 0xd8, 0xb9, 0x46");
  // void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceProperties *)
  MAKE_CALLBACK_THUNK(callback_535, void (struct VkPhysicalDevice_T *, struct VkPhysicalDeviceProperties *), "0xc9, 0x68, 0xf1, 0x19, 0xf5, 0x7a, 0x24, 0x7a, 0xaf, 0x6c, 0xee, 0x55, 0xac, 0x10, 0xbb, 0xc7, 0xaf, 0x53, 0x65, 0xed, 0xed, 0x96, 0xcf, 0xda, 0x3, 0xf4, 0x99, 0x99, 0xde, 0xac, 0xe7, 0x35");
  // enum VkResult (struct VkDevice_T *, const struct VkCuModuleCreateInfoNVX *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_536, enum VkResult (struct VkDevice_T *, const struct VkCuModuleCreateInfoNVX *, const struct VkAllocationCallbacks *, unsigned long *), "0x82, 0xc, 0xeb, 0x7b, 0xd2, 0x7e, 0x25, 0xe3, 0x3c, 0xc4, 0xb4, 0xa4, 0x9c, 0xf2, 0x8f, 0x2a, 0xbd, 0xe1, 0x87, 0xac, 0x85, 0xcc, 0xb, 0xcb, 0x8a, 0xcc, 0xb2, 0xdd, 0x6, 0x9f, 0x8c, 0xf9");
  // enum VkResult (struct VkDevice_T *, const struct VkAccelerationStructureCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_538, enum VkResult (struct VkDevice_T *, const struct VkAccelerationStructureCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *), "0xc, 0x77, 0x7f, 0xe3, 0xfb, 0xb9, 0xfc, 0xc5, 0xc4, 0xe, 0x2b, 0xd1, 0xcb, 0x4a, 0xdb, 0xda, 0x72, 0x5, 0x41, 0x90, 0xad, 0x4e, 0x30, 0xdd, 0x5c, 0x15, 0x33, 0x18, 0xb7, 0xc, 0xb1, 0xfe");
  // void (struct VkCommandBuffer_T *, unsigned int, enum VkStencilOp, enum VkStencilOp, enum VkStencilOp, enum VkCompareOp)
  MAKE_CALLBACK_THUNK(callback_541, void (struct VkCommandBuffer_T *, unsigned int, enum VkStencilOp, enum VkStencilOp, enum VkStencilOp, enum VkCompareOp), "0x2a, 0x6d, 0xfc, 0xe4, 0xc5, 0xf5, 0x77, 0xa0, 0x46, 0x64, 0x3e, 0x7b, 0xaa, 0x8, 0x6d, 0x0, 0xe1, 0xf2, 0x17, 0x5c, 0x0, 0xaa, 0xdb, 0xd7, 0x5, 0x1c, 0x79, 0x48, 0x6e, 0x27, 0xf6, 0x93");
  // void (struct VkCommandBuffer_T *, const struct VkBindDescriptorBufferEmbeddedSamplersInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_544, void (struct VkCommandBuffer_T *, const struct VkBindDescriptorBufferEmbeddedSamplersInfoEXT *), "0x2a, 0xfe, 0xf, 0x63, 0x3c, 0x68, 0xa, 0x8b, 0x2e, 0x27, 0x3f, 0x3e, 0x5d, 0x37, 0xb9, 0xaf, 0xc1, 0x9e, 0x7a, 0x3a, 0xfb, 0x60, 0xf0, 0x9f, 0x91, 0xaa, 0x67, 0xa, 0xa7, 0xda, 0xa0, 0x91");
  // void (struct VkPhysicalDevice_T *, const struct VkQueryPoolPerformanceCreateInfoKHR *, unsigned int *)
  MAKE_CALLBACK_THUNK(callback_546, void (struct VkPhysicalDevice_T *, const struct VkQueryPoolPerformanceCreateInfoKHR *, unsigned int *), "0xe5, 0x37, 0x8a, 0xab, 0x1c, 0x62, 0x1f, 0x2f, 0xc6, 0x8f, 0x76, 0x7a, 0x9a, 0x14, 0x94, 0xe6, 0xfa, 0x27, 0x71, 0xbb, 0x42, 0x3c, 0xe3, 0x1c, 0xa9, 0x4e, 0x7e, 0x53, 0xef, 0xce, 0xfe, 0x3d");
  // void (struct VkCommandBuffer_T *, const struct VkExtent2D *, const enum VkFragmentShadingRateCombinerOpKHR *)
  MAKE_CALLBACK_THUNK(callback_547, void (struct VkCommandBuffer_T *, const struct VkExtent2D *, const enum VkFragmentShadingRateCombinerOpKHR *), "0x5, 0x8e, 0x8, 0xeb, 0x6b, 0x37, 0x20, 0x57, 0x71, 0xb6, 0x26, 0x19, 0x39, 0x2d, 0x9, 0xe6, 0xfd, 0xa2, 0xaf, 0xf6, 0x14, 0x7d, 0x2, 0x9, 0x1f, 0x5e, 0xfd, 0xbf, 0xbe, 0x69, 0x8, 0x66");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_548, enum VkResult (struct VkPhysicalDevice_T *, unsigned long), "0xc0, 0x96, 0xc3, 0xe9, 0xbb, 0xfb, 0x6d, 0xac, 0xa6, 0x4, 0xc1, 0xe1, 0x5a, 0x90, 0x77, 0x75, 0x90, 0xad, 0xe8, 0xaa, 0xcf, 0x31, 0x39, 0x5, 0xc8, 0x75, 0x5f, 0x65, 0x81, 0x24, 0x9, 0x59");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMemoryToAccelerationStructureInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_550, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkCopyMemoryToAccelerationStructureInfoKHR *), "0xfd, 0x75, 0x71, 0xbd, 0xcc, 0x3f, 0x9, 0x19, 0x6, 0x99, 0x49, 0xca, 0x1d, 0x1f, 0xe2, 0xd, 0x2a, 0xac, 0x42, 0x58, 0x5d, 0xdf, 0x3b, 0xbc, 0xe3, 0x92, 0xd0, 0xae, 0xb3, 0x33, 0xb0, 0xfe");
  // void (struct VkCommandBuffer_T *, const struct VkCopyMemoryToImageIndirectInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_552, void (struct VkCommandBuffer_T *, const struct VkCopyMemoryToImageIndirectInfoKHR *), "0x3f, 0x8d, 0xcc, 0x4a, 0x5a, 0x57, 0x53, 0x9b, 0xf1, 0x99, 0xb3, 0xb6, 0x1, 0xa0, 0x2e, 0x5f, 0x33, 0x2e, 0x4d, 0xf3, 0xba, 0x47, 0x55, 0x8a, 0x1d, 0x8b, 0xa3, 0x6b, 0x8a, 0xbb, 0xb0, 0x7c");
  // enum VkResult (struct VkPhysicalDevice_T *, const char *, unsigned int *, struct VkExtensionProperties *)
  MAKE_CALLBACK_THUNK(callback_553, enum VkResult (struct VkPhysicalDevice_T *, const char *, unsigned int *, struct VkExtensionProperties *), "0x84, 0x8d, 0x40, 0x98, 0x96, 0xa7, 0xac, 0x9c, 0x6c, 0x1c, 0x75, 0x39, 0x84, 0x49, 0x29, 0x44, 0xf3, 0x30, 0xa9, 0x41, 0x69, 0x51, 0xf0, 0x31, 0x44, 0xed, 0x45, 0x1c, 0x6d, 0x10, 0xfa, 0x4c");
  // enum VkResult (struct VkDevice_T *, struct VkDeviceFaultCountsEXT *, struct VkDeviceFaultInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_555, enum VkResult (struct VkDevice_T *, struct VkDeviceFaultCountsEXT *, struct VkDeviceFaultInfoEXT *), "0x43, 0xcd, 0xb9, 0xe1, 0xaa, 0xd1, 0xc8, 0xfc, 0x17, 0xd8, 0xfd, 0xa1, 0x71, 0x4e, 0xf0, 0x51, 0xff, 0xd5, 0x90, 0xbe, 0x46, 0x0, 0x3e, 0xc, 0x6b, 0x3, 0xc8, 0xc2, 0xc4, 0xc9, 0xf3, 0xcf");
  // enum VkResult (struct VkDevice_T *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_556, enum VkResult (struct VkDevice_T *, const struct VkAllocationCallbacks *, unsigned long *), "0x14, 0xfb, 0x7a, 0xe6, 0x60, 0xdc, 0xa8, 0x61, 0x91, 0x47, 0x30, 0x76, 0xdd, 0xb5, 0x7b, 0x95, 0xe4, 0x80, 0x2, 0x7a, 0xa5, 0x2e, 0x4, 0x90, 0x93, 0xed, 0xf5, 0xef, 0x7, 0x88, 0x9d, 0x52");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineCreateInfoKHR *, struct VkPipelineBinaryKeyKHR *)
  MAKE_CALLBACK_THUNK(callback_559, enum VkResult (struct VkDevice_T *, const struct VkPipelineCreateInfoKHR *, struct VkPipelineBinaryKeyKHR *), "0x6a, 0x95, 0x42, 0x38, 0xf5, 0x75, 0xfd, 0x27, 0x6e, 0x28, 0x41, 0xa0, 0x5f, 0xb, 0xc2, 0x49, 0x3a, 0xe4, 0xb8, 0x2f, 0x7, 0x25, 0x57, 0xdc, 0x70, 0x9f, 0xc1, 0xaf, 0x62, 0x10, 0xa0, 0xa9");
  // enum VkResult (struct VkDevice_T *, const struct VkTensorViewCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_560, enum VkResult (struct VkDevice_T *, const struct VkTensorViewCreateInfoARM *, const struct VkAllocationCallbacks *, unsigned long *), "0x43, 0xe1, 0x2f, 0x58, 0x39, 0x39, 0x73, 0x7b, 0xba, 0x25, 0xa4, 0x1b, 0xc2, 0xd6, 0x72, 0xf1, 0x79, 0x58, 0xf0, 0x56, 0x8e, 0x70, 0x3, 0xed, 0xf1, 0x4, 0x9e, 0x7b, 0x76, 0x2, 0xb7, 0x62");
  // enum VkResult (struct VkDevice_T *, const struct VkTensorViewCaptureDescriptorDataInfoARM *, void *)
  MAKE_CALLBACK_THUNK(callback_562, enum VkResult (struct VkDevice_T *, const struct VkTensorViewCaptureDescriptorDataInfoARM *, void *), "0x41, 0x91, 0x83, 0x29, 0x3b, 0x4, 0x60, 0x8, 0x68, 0x72, 0x26, 0x7e, 0x9b, 0x9e, 0xb, 0xf9, 0xb3, 0xa7, 0x17, 0x28, 0x55, 0x6e, 0xe7, 0x14, 0xbe, 0xf2, 0x34, 0x9, 0xbe, 0xeb, 0xf9, 0x4c");
  // unsigned int (struct VkDevice_T *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_563, unsigned int (struct VkDevice_T *, unsigned long), "0x42, 0xdb, 0x2c, 0x4b, 0xd2, 0x77, 0x62, 0xf4, 0xf8, 0x32, 0xa6, 0x4f, 0xa9, 0x3c, 0xda, 0xef, 0x2c, 0xe8, 0xd6, 0xf2, 0x62, 0x9c, 0xf4, 0xc6, 0xc6, 0x65, 0x8e, 0x31, 0x32, 0xae, 0x39, 0x3a");
  // void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int, unsigned int, const unsigned int *, const unsigned long *)
  MAKE_CALLBACK_THUNK(callback_565, void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int, unsigned int, const unsigned int *, const unsigned long *), "0x4a, 0x9d, 0x5a, 0x76, 0x57, 0x6e, 0xc5, 0xe3, 0x6, 0x5e, 0x98, 0x23, 0x4f, 0x45, 0xb5, 0x32, 0x86, 0x17, 0x8f, 0xc9, 0x89, 0xd1, 0x50, 0x29, 0x64, 0xfe, 0xa2, 0x7d, 0x58, 0xa5, 0xa5, 0xa");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, struct VkTilePropertiesQCOM *)
  MAKE_CALLBACK_THUNK(callback_567, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, struct VkTilePropertiesQCOM *), "0x3d, 0xf7, 0xd0, 0xc6, 0x9a, 0x12, 0x19, 0x95, 0xa9, 0xd5, 0x6b, 0x21, 0xcc, 0x61, 0x42, 0x4, 0x5b, 0x6e, 0x92, 0x9c, 0xdc, 0xcf, 0x9d, 0x24, 0xaf, 0xb5, 0xf4, 0x82, 0x9b, 0x69, 0xd8, 0x8d");
  // enum VkResult (struct VkDevice_T *, const struct VkPipelineExecutableInfoKHR *, unsigned int *, struct VkPipelineExecutableInternalRepresentationKHR *)
  MAKE_CALLBACK_THUNK(callback_568, enum VkResult (struct VkDevice_T *, const struct VkPipelineExecutableInfoKHR *, unsigned int *, struct VkPipelineExecutableInternalRepresentationKHR *), "0x43, 0x70, 0x63, 0x26, 0x27, 0xa1, 0xa6, 0x55, 0xae, 0x30, 0x76, 0xce, 0xb1, 0x75, 0xd1, 0x35, 0xc3, 0xea, 0xcd, 0xd9, 0xf, 0x9d, 0x3d, 0x97, 0xbe, 0xdf, 0xc4, 0xb7, 0xcd, 0x2e, 0xe5, 0x34");
  // enum VkResult (struct VkDevice_T *, const struct VkVideoEncodeSessionParametersGetInfoKHR *, struct VkVideoEncodeSessionParametersFeedbackInfoKHR *, unsigned long *, void *)
  MAKE_CALLBACK_THUNK(callback_569, enum VkResult (struct VkDevice_T *, const struct VkVideoEncodeSessionParametersGetInfoKHR *, struct VkVideoEncodeSessionParametersFeedbackInfoKHR *, unsigned long *, void *), "0x8d, 0x80, 0xca, 0xe1, 0xc6, 0xec, 0x42, 0xc9, 0xda, 0xad, 0x8b, 0x3d, 0x1b, 0x41, 0xcb, 0x18, 0xa5, 0xf8, 0x7f, 0x4b, 0xa1, 0xdd, 0x65, 0x7e, 0xb9, 0x66, 0x1, 0x9d, 0x9d, 0xe7, 0x2e, 0x5b");
  // enum VkResult (struct VkInstance_T *, const struct VkDisplaySurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_575, enum VkResult (struct VkInstance_T *, const struct VkDisplaySurfaceCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x75, 0x18, 0xc1, 0x4b, 0xf8, 0x13, 0xa5, 0x5d, 0xa7, 0x69, 0x4a, 0xfa, 0xb1, 0xd0, 0x25, 0x44, 0x99, 0x83, 0x85, 0xbf, 0x7d, 0x81, 0x8f, 0x1c, 0xc8, 0x37, 0x0, 0x14, 0xd4, 0xd1, 0xe5, 0x17");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkFramebufferMixedSamplesCombinationNV *)
  MAKE_CALLBACK_THUNK(callback_579, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkFramebufferMixedSamplesCombinationNV *), "0x4a, 0xce, 0x5b, 0x55, 0x13, 0x4a, 0x92, 0xad, 0x47, 0x7d, 0xff, 0xb4, 0x82, 0x16, 0xcc, 0x1d, 0x22, 0x34, 0x51, 0xca, 0xb, 0x13, 0x2f, 0xa, 0x74, 0x5d, 0x21, 0xc2, 0x41, 0x8d, 0x15, 0x5");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, const struct VkDisplayModeCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_583, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, const struct VkDisplayModeCreateInfoKHR *, const struct VkAllocationCallbacks *, unsigned long *), "0x1d, 0xde, 0x9a, 0xcb, 0xed, 0xac, 0x72, 0xc7, 0x25, 0x38, 0xd7, 0x5a, 0xff, 0xda, 0x6a, 0x88, 0x8d, 0xc6, 0x65, 0xad, 0xc7, 0xf5, 0x5c, 0xef, 0x3a, 0xa, 0x81, 0x1b, 0xb7, 0x95, 0x22, 0xa2");
  // enum VkResult (struct VkDevice_T *, unsigned long, enum VkShaderStageFlagBits, enum VkShaderInfoTypeAMD, unsigned long *, void *)
  MAKE_CALLBACK_THUNK(callback_584, enum VkResult (struct VkDevice_T *, unsigned long, enum VkShaderStageFlagBits, enum VkShaderInfoTypeAMD, unsigned long *, void *), "0x27, 0xde, 0x75, 0x1a, 0xe3, 0x66, 0x96, 0xd0, 0x2e, 0x3, 0xcd, 0xb5, 0x14, 0xbb, 0xb4, 0xba, 0x37, 0xd8, 0x11, 0x1e, 0xa6, 0xf6, 0x93, 0x55, 0x2f, 0xd6, 0x69, 0x9, 0x7b, 0x91, 0x3d, 0x71");
  // void (struct VkCommandBuffer_T *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_585, void (struct VkCommandBuffer_T *, unsigned long), "0x84, 0x40, 0x26, 0x7b, 0x4c, 0x59, 0xad, 0xf2, 0x32, 0xb8, 0xe8, 0xe9, 0xe7, 0x17, 0xe, 0xd0, 0x6e, 0xd7, 0xe9, 0x79, 0xa3, 0xf6, 0xef, 0x4e, 0xf5, 0xa0, 0xe5, 0x29, 0xaf, 0xa9, 0x4, 0xf2");
  // enum VkResult (struct VkDevice_T *, const struct VkIndirectCommandsLayoutCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_588, enum VkResult (struct VkDevice_T *, const struct VkIndirectCommandsLayoutCreateInfoNV *, const struct VkAllocationCallbacks *, unsigned long *), "0x8, 0xd6, 0xa8, 0xa6, 0x86, 0xbc, 0xff, 0xf4, 0x37, 0xd1, 0xc4, 0x90, 0x28, 0xf3, 0xf1, 0x5a, 0x7f, 0x40, 0xcc, 0xee, 0x50, 0xa2, 0xda, 0x58, 0xe9, 0xd2, 0xe7, 0xb8, 0xd9, 0xf3, 0xfd, 0x41");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkPresentWait2InfoKHR *)
  MAKE_CALLBACK_THUNK(callback_593, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkPresentWait2InfoKHR *), "0x0, 0x63, 0x4f, 0xf5, 0x23, 0xa7, 0x38, 0xd4, 0x3e, 0x33, 0xa5, 0x8f, 0xe4, 0x35, 0xff, 0xc0, 0x89, 0x27, 0x1b, 0x70, 0xe4, 0xe5, 0xa3, 0x37, 0x78, 0x18, 0x8b, 0xdb, 0xa0, 0x1e, 0xdf, 0xd7");
  // enum VkResult (struct VkPhysicalDevice_T *, int, unsigned int, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_596, enum VkResult (struct VkPhysicalDevice_T *, int, unsigned int, unsigned long *), "0x65, 0xb2, 0xb, 0x22, 0xc5, 0x8a, 0x56, 0x18, 0x34, 0x61, 0xaa, 0xd3, 0xdf, 0x23, 0x4, 0x9, 0x3b, 0x50, 0xf, 0xa5, 0xc5, 0x99, 0x56, 0x8c, 0xae, 0xb0, 0x9c, 0x76, 0xde, 0xfe, 0xbb, 0xf8");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeMatrixPropertiesKHR *)
  MAKE_CALLBACK_THUNK(callback_599, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeMatrixPropertiesKHR *), "0x5f, 0xb3, 0xc7, 0xeb, 0xb8, 0xbf, 0xcb, 0xa3, 0x4c, 0x5b, 0x7f, 0x1c, 0xe0, 0x5d, 0x3e, 0x9a, 0x4a, 0x2, 0x4a, 0x1, 0x85, 0xa3, 0xd0, 0x9b, 0xc1, 0x17, 0x63, 0x6e, 0xf, 0x33, 0x9c, 0x79");
  // enum VkResult (struct VkDevice_T *, const struct VkImageViewCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_602, enum VkResult (struct VkDevice_T *, const struct VkImageViewCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x8a, 0x1e, 0x16, 0x67, 0x6b, 0xe7, 0x97, 0x3b, 0x98, 0xd5, 0x51, 0x74, 0x71, 0x71, 0xfb, 0x68, 0x4, 0xb4, 0x32, 0xf0, 0xd9, 0x10, 0xb0, 0x26, 0x74, 0x24, 0x94, 0x2f, 0x53, 0xf0, 0x7d, 0xa1");
  // void (struct VkCommandBuffer_T *, const struct VkDispatchTileInfoQCOM *)
  MAKE_CALLBACK_THUNK(callback_604, void (struct VkCommandBuffer_T *, const struct VkDispatchTileInfoQCOM *), "0x8b, 0xd8, 0x30, 0x83, 0x2d, 0xa4, 0x92, 0xe1, 0x34, 0x33, 0x44, 0x30, 0xc3, 0x66, 0x95, 0xa7, 0x61, 0x65, 0x44, 0x39, 0x22, 0x42, 0xc3, 0xc0, 0xec, 0x82, 0xce, 0xf8, 0xf2, 0x7f, 0xb, 0x40");
  // enum VkResult (struct VkInstance_T *, const struct VkDebugReportCallbackCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_611, enum VkResult (struct VkInstance_T *, const struct VkDebugReportCallbackCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0x6b, 0xed, 0x51, 0x6f, 0xe8, 0xa7, 0x64, 0x85, 0xed, 0x85, 0x6d, 0x4, 0x9c, 0xda, 0xfc, 0x5, 0x7e, 0x79, 0xb2, 0x7c, 0x30, 0x2b, 0xd8, 0xd6, 0xa9, 0x4e, 0x83, 0x8a, 0xcb, 0xff, 0x24, 0xe9");
  // void (struct VkInstance_T *, unsigned int, enum VkDebugReportObjectTypeEXT, unsigned long, unsigned long, int, const char *, const char *)
  MAKE_CALLBACK_THUNK(callback_613, void (struct VkInstance_T *, unsigned int, enum VkDebugReportObjectTypeEXT, unsigned long, unsigned long, int, const char *, const char *), "0xd8, 0xff, 0x14, 0xae, 0x5, 0xd4, 0x4e, 0x69, 0xcd, 0x84, 0xed, 0xd8, 0x2e, 0x19, 0x13, 0x9f, 0x27, 0x23, 0xf2, 0xcc, 0xa3, 0x2e, 0x6f, 0xc2, 0x6c, 0x2c, 0xe, 0xaf, 0x8b, 0x96, 0xa8, 0xaf");
  // enum VkResult (struct VkDevice_T *, const struct VkDebugMarkerObjectTagInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_614, enum VkResult (struct VkDevice_T *, const struct VkDebugMarkerObjectTagInfoEXT *), "0x6e, 0x71, 0x4b, 0x3f, 0xb2, 0xb4, 0xbc, 0xc0, 0x30, 0xa2, 0x39, 0xcd, 0x7c, 0x2f, 0xfb, 0x2b, 0xca, 0xf0, 0xf6, 0x1, 0xce, 0x42, 0x23, 0x94, 0x34, 0xc9, 0x6b, 0x4c, 0xa, 0xb2, 0x85, 0xeb");
  // enum VkResult (struct VkDevice_T *, const struct VkDebugMarkerObjectNameInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_615, enum VkResult (struct VkDevice_T *, const struct VkDebugMarkerObjectNameInfoEXT *), "0x20, 0xfa, 0x48, 0x1d, 0x36, 0xe4, 0x9a, 0xe8, 0x66, 0xe8, 0x8d, 0xd, 0xa8, 0x11, 0x3f, 0x13, 0xfa, 0xe0, 0x72, 0xbc, 0xd1, 0x23, 0x25, 0x37, 0xbd, 0xa3, 0xc8, 0x43, 0x7c, 0xaa, 0x6e, 0x59");
  // void (struct VkCommandBuffer_T *, const struct VkBuildPartitionedAccelerationStructureInfoNV *)
  MAKE_CALLBACK_THUNK(callback_616, void (struct VkCommandBuffer_T *, const struct VkBuildPartitionedAccelerationStructureInfoNV *), "0x35, 0xcf, 0x8d, 0xff, 0xab, 0x3, 0x70, 0x4b, 0x14, 0x83, 0x60, 0xba, 0xe8, 0x5d, 0x99, 0xa8, 0x7c, 0x2, 0x2f, 0x67, 0xd7, 0xeb, 0xf, 0xf1, 0xe4, 0xfc, 0xc9, 0x96, 0xdd, 0xee, 0x98, 0x59");
  // void (struct VkCommandBuffer_T *, unsigned int, const struct VkDescriptorBufferBindingInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_618, void (struct VkCommandBuffer_T *, unsigned int, const struct VkDescriptorBufferBindingInfoEXT *), "0x2d, 0x90, 0x37, 0xa8, 0x15, 0x6f, 0xb1, 0xd3, 0x70, 0xc4, 0xa0, 0xba, 0x5d, 0x8e, 0x65, 0x1a, 0x2c, 0xb8, 0x6f, 0x31, 0xa5, 0xe5, 0x7c, 0xf1, 0x83, 0xd3, 0xc9, 0xea, 0x3, 0x3e, 0xca, 0xa8");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_622, void (struct VkCommandBuffer_T *, unsigned long, unsigned int, unsigned int, unsigned int), "0x4f, 0xe7, 0x44, 0x3e, 0x43, 0xcb, 0xa0, 0x32, 0xec, 0xfe, 0x10, 0xa2, 0x6, 0xd9, 0xde, 0x42, 0x41, 0xc, 0x4b, 0x29, 0x5b, 0xac, 0x35, 0x78, 0xd1, 0xff, 0x8e, 0xeb, 0xf9, 0x5c, 0xfd, 0x89");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned long, unsigned long, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_626, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned long, unsigned long, unsigned int, unsigned int), "0xe9, 0xdf, 0xff, 0xbc, 0x61, 0xae, 0x36, 0x20, 0x37, 0x3b, 0x44, 0x8b, 0x2, 0xe5, 0x88, 0x32, 0x67, 0xa6, 0xa3, 0xa2, 0xc8, 0xbe, 0xd7, 0x8, 0x7c, 0xd6, 0xf8, 0xc9, 0xc5, 0xe1, 0x6a, 0x64");
  // enum VkResult (struct VkDevice_T *)
  MAKE_CALLBACK_THUNK(callback_627, enum VkResult (struct VkDevice_T *), "0xac, 0x49, 0xb7, 0x87, 0x29, 0x5f, 0x5d, 0xee, 0x75, 0xac, 0xa6, 0x43, 0x12, 0xc7, 0x21, 0xe8, 0xd9, 0x5e, 0xc9, 0x9a, 0xd9, 0xf9, 0x88, 0x60, 0xa8, 0x13, 0x86, 0x4c, 0xca, 0x8f, 0xcd, 0x4f");
  // void (struct VkCommandBuffer_T *, const struct VkCuLaunchInfoNVX *)
  MAKE_CALLBACK_THUNK(callback_629, void (struct VkCommandBuffer_T *, const struct VkCuLaunchInfoNVX *), "0xe5, 0x24, 0xf3, 0xaf, 0x74, 0xfb, 0x16, 0xaf, 0xac, 0xad, 0xd3, 0x78, 0xbe, 0x59, 0x63, 0x1c, 0xea, 0xa6, 0xc, 0xac, 0xfb, 0x17, 0xe, 0x8d, 0xae, 0x6f, 0x14, 0xf, 0xe7, 0xe4, 0x23, 0x6e");
  // void (struct VkDevice_T *, unsigned int, const unsigned long *, const struct VkHdrMetadataEXT *)
  MAKE_CALLBACK_THUNK(callback_630, void (struct VkDevice_T *, unsigned int, const unsigned long *, const struct VkHdrMetadataEXT *), "0x5d, 0x13, 0x51, 0xa6, 0xd9, 0xee, 0x5c, 0xa3, 0x7d, 0xcd, 0x9, 0x32, 0x5, 0x18, 0x92, 0x25, 0x75, 0xe, 0xcf, 0x8a, 0x9e, 0xc, 0x74, 0x69, 0x91, 0xad, 0x93, 0xc2, 0xb, 0xc6, 0x1f, 0x9b");
  // enum VkResult (struct VkDevice_T *, const struct VkMicromapCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_634, enum VkResult (struct VkDevice_T *, const struct VkMicromapCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0x7f, 0x47, 0x12, 0x85, 0x32, 0xf0, 0x81, 0xea, 0xd, 0xf3, 0x6f, 0x17, 0x31, 0x50, 0x97, 0xbb, 0x58, 0x88, 0x90, 0xbc, 0x88, 0x9d, 0x7c, 0x52, 0x28, 0x42, 0x67, 0x75, 0xbb, 0x9, 0x90, 0xd");
  // unsigned long (struct VkDevice_T *, const struct VkImageViewHandleInfoNVX *)
  MAKE_CALLBACK_THUNK(callback_635, unsigned long (struct VkDevice_T *, const struct VkImageViewHandleInfoNVX *), "0xed, 0xd5, 0xb, 0x14, 0x9a, 0xd7, 0x6, 0xe1, 0x2e, 0x20, 0x3, 0xb2, 0xf9, 0x8a, 0xc2, 0xfe, 0xa0, 0xc, 0x20, 0x49, 0xa7, 0x29, 0x58, 0x7a, 0x19, 0x2b, 0x9c, 0xca, 0xe2, 0x4d, 0x70, 0x29");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeMatrixFlexibleDimensionsPropertiesNV *)
  MAKE_CALLBACK_THUNK(callback_636, enum VkResult (struct VkPhysicalDevice_T *, unsigned int *, struct VkCooperativeMatrixFlexibleDimensionsPropertiesNV *), "0x97, 0xaf, 0x43, 0x7e, 0xb2, 0x13, 0x65, 0xad, 0x3b, 0x6f, 0xa8, 0xcc, 0x80, 0x26, 0xdb, 0x56, 0xcd, 0x2, 0x64, 0x13, 0x68, 0x9f, 0xea, 0xd6, 0x3f, 0x40, 0xab, 0x15, 0xd1, 0x6, 0xdc, 0x31");
  // enum VkResult (struct VkPhysicalDevice_T *, enum VkFormat, enum VkImageType, enum VkImageTiling, unsigned int, unsigned int, unsigned int, struct VkExternalImageFormatPropertiesNV *)
  MAKE_CALLBACK_THUNK(callback_639, enum VkResult (struct VkPhysicalDevice_T *, enum VkFormat, enum VkImageType, enum VkImageTiling, unsigned int, unsigned int, unsigned int, struct VkExternalImageFormatPropertiesNV *), "0x45, 0x4f, 0x49, 0x48, 0xc3, 0xa3, 0x35, 0x93, 0x6b, 0x82, 0x4a, 0xda, 0x1e, 0x47, 0xdc, 0xfc, 0x85, 0x8, 0x21, 0xea, 0x50, 0xe1, 0xda, 0x29, 0xc8, 0x37, 0x0, 0x70, 0xf1, 0x32, 0x4c, 0x69");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkShadingRatePaletteNV *)
  MAKE_CALLBACK_THUNK(callback_640, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, const struct VkShadingRatePaletteNV *), "0x71, 0x85, 0xcf, 0x48, 0xbf, 0x2b, 0x95, 0xc9, 0xbf, 0x75, 0xfd, 0x28, 0xb7, 0x66, 0x2a, 0xbf, 0x66, 0x7a, 0xc4, 0xd8, 0x89, 0xde, 0xed, 0xae, 0x6d, 0x8d, 0x61, 0x31, 0xc1, 0x31, 0xc9, 0x44");
  // void (struct VkCommandBuffer_T *, const struct VkConditionalRenderingBeginInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_641, void (struct VkCommandBuffer_T *, const struct VkConditionalRenderingBeginInfoEXT *), "0x43, 0x4a, 0x7c, 0x91, 0x95, 0xd7, 0x2b, 0x47, 0x31, 0xf2, 0x75, 0x5e, 0x8e, 0xc3, 0x80, 0x8c, 0xef, 0xf, 0xbf, 0x93, 0x5, 0x30, 0x93, 0xe0, 0x5, 0x5a, 0x9f, 0x68, 0x71, 0x18, 0xc6, 0x93");
  // void (struct VkPhysicalDevice_T *, unsigned int *, struct VkQueueFamilyProperties *)
  MAKE_CALLBACK_THUNK(callback_642, void (struct VkPhysicalDevice_T *, unsigned int *, struct VkQueueFamilyProperties *), "0x10, 0xf6, 0x11, 0x7a, 0xa0, 0x65, 0x81, 0xaf, 0x6f, 0x52, 0x3a, 0x57, 0xf5, 0xdc, 0xa8, 0x83, 0x24, 0x64, 0xc8, 0x79, 0xc9, 0x14, 0xc8, 0xf, 0x47, 0xc2, 0x34, 0x28, 0xce, 0x12, 0x47, 0x2f");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, struct VkSurfaceCapabilities2EXT *)
  MAKE_CALLBACK_THUNK(callback_644, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, struct VkSurfaceCapabilities2EXT *), "0x7e, 0x5e, 0xf8, 0x30, 0x9d, 0xb2, 0x71, 0x40, 0xaf, 0x70, 0xd5, 0x4d, 0xb5, 0xc7, 0x30, 0x86, 0x7d, 0xbb, 0x24, 0x7c, 0xa7, 0x57, 0x9f, 0x51, 0x5f, 0xb8, 0x5c, 0x4b, 0xfe, 0x3c, 0xeb, 0x2e");
  // enum VkResult (struct VkDevice_T *, const struct VkDeviceEventInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_647, enum VkResult (struct VkDevice_T *, const struct VkDeviceEventInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0x8a, 0xa7, 0xfd, 0x7, 0x71, 0xb0, 0x53, 0x40, 0x97, 0x32, 0x0, 0xb8, 0xfc, 0x96, 0xca, 0x4b, 0x60, 0x77, 0x4f, 0x6c, 0x90, 0x1b, 0x6d, 0xcc, 0xf5, 0xe0, 0xe4, 0x8, 0xe3, 0x61, 0x8d, 0x9");
  // enum VkResult (struct VkDevice_T *, unsigned long, const struct VkDisplayEventInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_648, enum VkResult (struct VkDevice_T *, unsigned long, const struct VkDisplayEventInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0xef, 0x35, 0x8a, 0x6d, 0xb5, 0x6c, 0x1c, 0x64, 0x3a, 0x96, 0x88, 0x80, 0x20, 0x95, 0xbf, 0x6e, 0x51, 0x89, 0x71, 0xbb, 0xb5, 0x19, 0xf, 0x87, 0x2b, 0xcd, 0x1c, 0x7a, 0xc6, 0x17, 0xda, 0x33");
  // enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, struct VkPastPresentationTimingGOOGLE *)
  MAKE_CALLBACK_THUNK(callback_649, enum VkResult (struct VkDevice_T *, unsigned long, unsigned int *, struct VkPastPresentationTimingGOOGLE *), "0xfd, 0xa7, 0x81, 0xe3, 0x27, 0x9c, 0x8f, 0xa4, 0x1, 0x3a, 0xb4, 0x8, 0x61, 0xc5, 0xa0, 0x3a, 0xe4, 0x46, 0xf7, 0x7c, 0xd0, 0x21, 0x15, 0x55, 0x3a, 0x42, 0x2f, 0x2b, 0xd6, 0x20, 0xf5, 0xf6");
  // enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkRect2D *)
  MAKE_CALLBACK_THUNK(callback_650, enum VkResult (struct VkPhysicalDevice_T *, unsigned long, unsigned int *, struct VkRect2D *), "0x1, 0x69, 0xd4, 0x6c, 0x92, 0x54, 0x5a, 0x32, 0xe7, 0xf9, 0xe, 0x77, 0xe6, 0x1d, 0x64, 0xb0, 0xbc, 0x1f, 0x9e, 0x99, 0x56, 0x22, 0x3d, 0x62, 0x23, 0x2b, 0x49, 0x91, 0x28, 0x1d, 0x1c, 0xb8");
  // enum VkResult (struct VkDevice_T *, const struct VkDebugUtilsObjectTagInfoEXT *)
  MAKE_CALLBACK_THUNK(callback_651, enum VkResult (struct VkDevice_T *, const struct VkDebugUtilsObjectTagInfoEXT *), "0xb7, 0x75, 0x92, 0x6c, 0xe0, 0x5d, 0x1a, 0xd1, 0x86, 0x41, 0xe6, 0x7a, 0x77, 0x78, 0x7c, 0x1a, 0x21, 0xc9, 0x69, 0xb, 0xb1, 0x31, 0x75, 0xc7, 0xcc, 0x93, 0x3d, 0x9e, 0xb9, 0xc7, 0xd1, 0x91");
  // void (struct VkInstance_T *, enum VkDebugUtilsMessageSeverityFlagBitsEXT, unsigned int, const struct VkDebugUtilsMessengerCallbackDataEXT *)
  MAKE_CALLBACK_THUNK(callback_654, void (struct VkInstance_T *, enum VkDebugUtilsMessageSeverityFlagBitsEXT, unsigned int, const struct VkDebugUtilsMessengerCallbackDataEXT *), "0x52, 0x51, 0xda, 0x32, 0x94, 0x68, 0xc0, 0x1f, 0xc1, 0x23, 0xd7, 0x42, 0xbb, 0x68, 0x9c, 0x91, 0xbb, 0x46, 0x68, 0x5b, 0xa1, 0x63, 0x39, 0x1c, 0x13, 0x8, 0x9b, 0x93, 0x53, 0xe2, 0xf2, 0x4f");
  // enum VkResult (struct VkDevice_T *, const struct VkValidationCacheCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_656, enum VkResult (struct VkDevice_T *, const struct VkValidationCacheCreateInfoEXT *, const struct VkAllocationCallbacks *, unsigned long *), "0x4d, 0xa, 0x3e, 0x3f, 0xb9, 0x8e, 0x5c, 0x6b, 0x80, 0x3c, 0x31, 0x1d, 0xd4, 0x3d, 0xa4, 0xc3, 0x2d, 0x19, 0x65, 0x6c, 0x1, 0xc1, 0x12, 0xf3, 0x1f, 0xe5, 0xa3, 0x73, 0x3c, 0x6e, 0x9e, 0x2f");
  // void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_658, void (struct VkCommandBuffer_T *, unsigned int, unsigned int, unsigned int, int, unsigned int), "0xac, 0x8e, 0xef, 0xe5, 0x3b, 0x25, 0x31, 0x1e, 0x41, 0x68, 0xf0, 0x21, 0x59, 0xc9, 0x4a, 0x26, 0x8c, 0x5e, 0xc1, 0x7a, 0x93, 0xfa, 0x51, 0xf5, 0xfd, 0xb6, 0x40, 0x5, 0xc0, 0x31, 0x3, 0x97");
  // void (struct VkDevice_T *, const struct VkAccelerationStructureMemoryRequirementsInfoNV *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_660, void (struct VkDevice_T *, const struct VkAccelerationStructureMemoryRequirementsInfoNV *, struct VkMemoryRequirements2 *), "0x1f, 0x60, 0x89, 0xe7, 0x54, 0xe8, 0xd4, 0x3c, 0xca, 0x1d, 0xe5, 0x1e, 0xd0, 0x40, 0x1f, 0x1, 0x8d, 0x4a, 0x40, 0xeb, 0x43, 0x84, 0x4e, 0x47, 0x65, 0x80, 0x7, 0xed, 0x83, 0x8b, 0xcd, 0x7e");
  // void (struct VkDevice_T *, unsigned long, float)
  MAKE_CALLBACK_THUNK(callback_661, void (struct VkDevice_T *, unsigned long, float), "0x75, 0x79, 0x6d, 0xb7, 0x33, 0xe0, 0xfc, 0x99, 0x59, 0x5f, 0x91, 0xd8, 0x3f, 0x69, 0xd3, 0x9a, 0xa2, 0x93, 0x1, 0xd7, 0xc, 0x51, 0x45, 0x8c, 0x5a, 0x85, 0xd9, 0x15, 0x86, 0xf1, 0x85, 0xbd");
  // void (struct VkCommandBuffer_T *, const struct VkAccelerationStructureInfoNV *, unsigned long, unsigned long, unsigned int, unsigned long, unsigned long, unsigned long, unsigned long)
  MAKE_CALLBACK_THUNK(callback_662, void (struct VkCommandBuffer_T *, const struct VkAccelerationStructureInfoNV *, unsigned long, unsigned long, unsigned int, unsigned long, unsigned long, unsigned long, unsigned long), "0xf3, 0x94, 0xa7, 0xab, 0x8b, 0xb8, 0xe2, 0xf0, 0x46, 0x8f, 0x47, 0xd0, 0x83, 0xa4, 0x82, 0x33, 0xf6, 0xcf, 0xbb, 0x50, 0x38, 0x5, 0x31, 0xf3, 0x3d, 0x1a, 0x6d, 0xf9, 0xb3, 0x98, 0x14, 0x3d");
  // enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindTensorMemoryInfoARM *)
  MAKE_CALLBACK_THUNK(callback_663, enum VkResult (struct VkDevice_T *, unsigned int, const struct VkBindTensorMemoryInfoARM *), "0xf2, 0x73, 0x71, 0xe1, 0xff, 0xcf, 0xd7, 0x39, 0x17, 0x18, 0xef, 0xc1, 0x90, 0xd, 0xec, 0x48, 0x57, 0xd9, 0xa5, 0xb9, 0x90, 0xd9, 0xed, 0x3, 0x63, 0xb6, 0x37, 0xcd, 0xd0, 0x40, 0x2d, 0x1a");
  // void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned int, unsigned int, unsigned int)
  MAKE_CALLBACK_THUNK(callback_664, void (struct VkCommandBuffer_T *, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long, unsigned int, unsigned int, unsigned int), "0xc1, 0xf4, 0x50, 0xda, 0xe2, 0x8, 0x9f, 0xfc, 0x34, 0xa6, 0xeb, 0x95, 0xc1, 0x7, 0x66, 0x2e, 0x4b, 0xa, 0xd6, 0x84, 0x5, 0x11, 0x57, 0x13, 0x9e, 0x26, 0xb1, 0x18, 0x80, 0xfe, 0xe3, 0x66");
  // enum VkResult (struct VkDevice_T *, const struct VkImportSemaphoreFdInfoKHR *)
  MAKE_CALLBACK_THUNK(callback_665, enum VkResult (struct VkDevice_T *, const struct VkImportSemaphoreFdInfoKHR *), "0xc5, 0x9d, 0xd9, 0xbd, 0x45, 0xe4, 0x45, 0x63, 0x7c, 0x77, 0x7b, 0xad, 0xbb, 0xef, 0x4b, 0xa3, 0x52, 0xd9, 0x24, 0x29, 0x75, 0x2c, 0xf5, 0x11, 0xa8, 0x30, 0xee, 0xd7, 0xff, 0x71, 0x1a, 0x89");
  // enum VkResult (struct VkDevice_T *, const struct VkDescriptorPoolCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_667, enum VkResult (struct VkDevice_T *, const struct VkDescriptorPoolCreateInfo *, const struct VkAllocationCallbacks *, unsigned long *), "0x92, 0xe9, 0xba, 0x7d, 0xe2, 0x75, 0xe, 0x55, 0x12, 0x1d, 0xd8, 0x7b, 0x36, 0xbf, 0xd9, 0xd2, 0x5b, 0x8d, 0xf8, 0xaf, 0x2e, 0x77, 0xf6, 0x4a, 0x90, 0x5b, 0x68, 0x80, 0xa3, 0x92, 0x95, 0x99");
  // enum VkResult (struct VkDevice_T *, struct VkDeviceGroupPresentCapabilitiesKHR *)
  MAKE_CALLBACK_THUNK(callback_669, enum VkResult (struct VkDevice_T *, struct VkDeviceGroupPresentCapabilitiesKHR *), "0xb4, 0xed, 0x57, 0xa3, 0x88, 0x98, 0x42, 0x21, 0x12, 0x9d, 0x87, 0x1b, 0x77, 0x8f, 0x73, 0x5d, 0x90, 0xcb, 0x58, 0x39, 0xf1, 0xf3, 0xce, 0x26, 0x59, 0xa2, 0x1f, 0xf3, 0xb1, 0xe, 0x8b, 0x80");
  // enum VkResult (struct VkDevice_T *, enum VkExternalMemoryHandleTypeFlagBits, const void *, struct VkMemoryHostPointerPropertiesEXT *)
  MAKE_CALLBACK_THUNK(callback_670, enum VkResult (struct VkDevice_T *, enum VkExternalMemoryHandleTypeFlagBits, const void *, struct VkMemoryHostPointerPropertiesEXT *), "0xe2, 0xa0, 0x22, 0x37, 0x23, 0xc8, 0xd4, 0x26, 0xdc, 0x74, 0x2b, 0xb0, 0x87, 0x70, 0xea, 0xe4, 0x3c, 0x4c, 0x42, 0xdd, 0x6a, 0x70, 0xa9, 0xbf, 0x82, 0x4d, 0x85, 0x4a, 0x6c, 0x8d, 0xcc, 0xcd");
  // void (struct VkQueue_T *, unsigned int *, struct VkCheckpointDataNV *)
  MAKE_CALLBACK_THUNK(callback_674, void (struct VkQueue_T *, unsigned int *, struct VkCheckpointDataNV *), "0x64, 0x93, 0x6c, 0x53, 0x24, 0xda, 0x2a, 0x17, 0xc8, 0xa2, 0x23, 0xe7, 0xa5, 0xf7, 0x86, 0xc8, 0xd5, 0xcf, 0x79, 0xfc, 0xf1, 0x62, 0x37, 0x8d, 0x5d, 0x28, 0xfa, 0xc9, 0xc1, 0x37, 0x80, 0xb8");
  // void (struct VkQueue_T *, unsigned int *, struct VkCheckpointData2NV *)
  MAKE_CALLBACK_THUNK(callback_675, void (struct VkQueue_T *, unsigned int *, struct VkCheckpointData2NV *), "0x7c, 0x10, 0xa4, 0xfd, 0x53, 0x16, 0x23, 0x1b, 0x4d, 0x57, 0xdb, 0x27, 0x49, 0x1, 0xf4, 0x99, 0x7d, 0xb8, 0xeb, 0xac, 0x1c, 0x7c, 0x25, 0x17, 0x8a, 0x17, 0x7a, 0xbe, 0x46, 0xc5, 0xf2, 0x29");
  // enum VkResult (struct VkDevice_T *, unsigned long, struct VkSwapchainTimingPropertiesEXT *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_676, enum VkResult (struct VkDevice_T *, unsigned long, struct VkSwapchainTimingPropertiesEXT *, unsigned long *), "0xe6, 0xb3, 0xb6, 0x79, 0xbc, 0x49, 0x3e, 0x7, 0xbd, 0xb0, 0x71, 0x6f, 0x2, 0xb3, 0x68, 0xec, 0x3c, 0x65, 0x1, 0x65, 0x8a, 0x8e, 0xab, 0xfc, 0x66, 0x78, 0x8b, 0x35, 0xd0, 0xd8, 0xcd, 0x15");
  // enum VkResult (struct VkDevice_T *, unsigned long, struct VkSwapchainTimeDomainPropertiesEXT *, unsigned long *)
  MAKE_CALLBACK_THUNK(callback_678, enum VkResult (struct VkDevice_T *, unsigned long, struct VkSwapchainTimeDomainPropertiesEXT *, unsigned long *), "0x57, 0x5b, 0x40, 0xf4, 0xf1, 0xcf, 0x61, 0x56, 0x6c, 0x8c, 0x40, 0xb8, 0x84, 0x85, 0x7, 0x18, 0x3, 0xf5, 0x8b, 0x92, 0x20, 0x7d, 0x45, 0x4c, 0xdc, 0x45, 0xa3, 0x7b, 0xbb, 0xa, 0xf2, 0x68");
  // enum VkResult (struct VkCommandBuffer_T *, const struct VkPerformanceOverrideInfoINTEL *)
  MAKE_CALLBACK_THUNK(callback_679, enum VkResult (struct VkCommandBuffer_T *, const struct VkPerformanceOverrideInfoINTEL *), "0xb7, 0x1c, 0xb7, 0x43, 0x11, 0x26, 0x2a, 0xd4, 0xf8, 0x87, 0xb3, 0x23, 0x1a, 0xc8, 0xe7, 0x32, 0x3, 0xdf, 0xc7, 0x4f, 0xaf, 0xc7, 0x41, 0x6e, 0xdb, 0x52, 0x14, 0xa2, 0xc, 0xcb, 0xf6, 0x1c");
  // enum VkResult (struct VkCommandBuffer_T *, const struct VkPerformanceMarkerInfoINTEL *)
  MAKE_CALLBACK_THUNK(callback_682, enum VkResult (struct VkCommandBuffer_T *, const struct VkPerformanceMarkerInfoINTEL *), "0x68, 0x9e, 0xe1, 0x10, 0xf8, 0x4d, 0xbf, 0xf4, 0xf6, 0x5, 0x5a, 0xd4, 0xd3, 0xe6, 0x72, 0x31, 0xc2, 0xf6, 0xaa, 0x56, 0x6f, 0xc, 0x94, 0x4b, 0x5a, 0x3f, 0xe7, 0xcb, 0x78, 0x51, 0x89, 0xf4");
  // enum VkResult (struct VkDevice_T *, enum VkPerformanceParameterTypeINTEL, struct VkPerformanceValueINTEL *)
  MAKE_CALLBACK_THUNK(callback_684, enum VkResult (struct VkDevice_T *, enum VkPerformanceParameterTypeINTEL, struct VkPerformanceValueINTEL *), "0x87, 0x3b, 0xf9, 0x4, 0x7b, 0x12, 0x83, 0x51, 0x60, 0x27, 0x5c, 0x8, 0x2e, 0x3f, 0xc0, 0x65, 0xdb, 0x12, 0x21, 0x65, 0xc6, 0x47, 0xad, 0xed, 0xaf, 0xd8, 0xb7, 0x8e, 0xeb, 0x1f, 0xe6, 0x98");
  // void (struct VkDevice_T *, const struct VkGeneratedCommandsMemoryRequirementsInfoNV *, struct VkMemoryRequirements2 *)
  MAKE_CALLBACK_THUNK(callback_699, void (struct VkDevice_T *, const struct VkGeneratedCommandsMemoryRequirementsInfoNV *, struct VkMemoryRequirements2 *), "0x2f, 0x78, 0xe2, 0x78, 0x42, 0xe5, 0xa2, 0x7a, 0x3d, 0x58, 0xa1, 0xca, 0xa9, 0x83, 0x52, 0x8e, 0x7e, 0x62, 0x7a, 0x18, 0x50, 0xb0, 0xb8, 0x17, 0xcf, 0xf, 0xc5, 0xc0, 0x9e, 0x5f, 0x9b, 0x9");
  // void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int)
  MAKE_CALLBACK_THUNK(callback_700, void (struct VkCommandBuffer_T *, enum VkPipelineBindPoint, unsigned long, unsigned int), "0xd2, 0x37, 0x46, 0xbf, 0x48, 0x84, 0x65, 0x8e, 0x5b, 0xe8, 0x47, 0x54, 0xed, 0xe7, 0x85, 0xab, 0xd, 0x0, 0x7e, 0x9a, 0x28, 0xa3, 0x63, 0x3, 0xaa, 0x3f, 0x3d, 0x3, 0x22, 0xb1, 0xe2, 0x85");
  // void (struct VkCommandBuffer_T *, const struct VkGeneratedCommandsInfoNV *)
  MAKE_CALLBACK_THUNK(callback_701, void (struct VkCommandBuffer_T *, const struct VkGeneratedCommandsInfoNV *), "0x4c, 0xa6, 0x33, 0xc7, 0xe9, 0xa, 0xc9, 0x8b, 0xb8, 0xc1, 0x81, 0xb9, 0xab, 0x98, 0x7e, 0x2d, 0x8f, 0xe1, 0x1a, 0x3f, 0x1c, 0xc7, 0xb0, 0x2a, 0x80, 0xc3, 0x24, 0x31, 0xdf, 0xbc, 0xf6, 0x16");
  // enum VkResult (struct VkQueue_T *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_702, enum VkResult (struct VkQueue_T *, unsigned long), "0x2a, 0xb5, 0x31, 0x61, 0xb6, 0x99, 0x5f, 0xf0, 0xa, 0x52, 0xfc, 0x49, 0x61, 0xd6, 0x38, 0x5f, 0xbc, 0xc0, 0x96, 0xf0, 0x93, 0x3d, 0x27, 0x55, 0x86, 0x2c, 0x38, 0x19, 0x9e, 0x2, 0xed, 0x9");
  // enum VkResult (struct VkDevice_T *, const struct VkInitializePerformanceApiInfoINTEL *)
  MAKE_CALLBACK_THUNK(callback_704, enum VkResult (struct VkDevice_T *, const struct VkInitializePerformanceApiInfoINTEL *), "0xe0, 0xf4, 0x90, 0xfa, 0x5b, 0x62, 0x59, 0x68, 0x74, 0x6b, 0x49, 0xf, 0xc4, 0x6e, 0xfe, 0xe9, 0xb8, 0x2c, 0x7c, 0xfe, 0x17, 0xd7, 0x95, 0x3d, 0xee, 0x5d, 0xf5, 0x1f, 0xac, 0xb, 0x32, 0xca");
  // void (struct VkCommandBuffer_T *, const struct VkPerTileBeginInfoQCOM *)
  MAKE_CALLBACK_THUNK(callback_705, void (struct VkCommandBuffer_T *, const struct VkPerTileBeginInfoQCOM *), "0xf6, 0x3c, 0xf5, 0x3d, 0x34, 0x46, 0x55, 0x96, 0xc, 0x7a, 0x6d, 0x41, 0x45, 0x81, 0x46, 0xa5, 0x12, 0xf3, 0x82, 0x10, 0x8f, 0x59, 0x4, 0xef, 0x84, 0x9c, 0xdb, 0x51, 0x2e, 0x0, 0xdb, 0xcc");
  // void (struct VkDevice_T *, const struct VkDescriptorGetInfoEXT *, unsigned long, void *)
  MAKE_CALLBACK_THUNK(callback_706, void (struct VkDevice_T *, const struct VkDescriptorGetInfoEXT *, unsigned long, void *), "0x55, 0xf6, 0x23, 0xb8, 0xcc, 0x26, 0xe9, 0x86, 0xe9, 0x54, 0x6a, 0x7, 0x5f, 0xe6, 0x59, 0x65, 0x1a, 0xd6, 0x5f, 0xb1, 0x43, 0x6b, 0x54, 0x6a, 0x7a, 0x92, 0xa2, 0x5e, 0x3f, 0xeb, 0xdb, 0xe0");
  // void (struct VkDevice_T *, unsigned long)
  MAKE_CALLBACK_THUNK(callback_707, void (struct VkDevice_T *, unsigned long), "0xf2, 0x3f, 0x7f, 0x52, 0x28, 0x99, 0x51, 0xa8, 0x9a, 0x6f, 0xe1, 0x8a, 0x29, 0xa2, 0x6d, 0x19, 0xca, 0x6b, 0x2c, 0x36, 0x87, 0xd9, 0x93, 0xe6, 0xe5, 0x44, 0x91, 0xba, 0x33, 0xea, 0xae, 0xa3");
  // enum VkResult (struct VkDevice_T *, const struct VkBufferCaptureDescriptorDataInfoEXT *, void *)
  MAKE_CALLBACK_THUNK(callback_708, enum VkResult (struct VkDevice_T *, const struct VkBufferCaptureDescriptorDataInfoEXT *, void *), "0xe5, 0x56, 0x17, 0x90, 0x1, 0x74, 0x4, 0x73, 0xda, 0x39, 0x2, 0xa4, 0x79, 0xc5, 0xcc, 0xd9, 0xe3, 0x25, 0x3d, 0x20, 0x49, 0xb3, 0x36, 0x34, 0xea, 0xba, 0x55, 0x8, 0x9d, 0x16, 0xf6, 0x77");
  // enum VkResult (struct VkDevice_T *, const struct VkImageCaptureDescriptorDataInfoEXT *, void *)
  MAKE_CALLBACK_THUNK(callback_709, enum VkResult (struct VkDevice_T *, const struct VkImageCaptureDescriptorDataInfoEXT *, void *), "0xc7, 0x97, 0x19, 0x4a, 0x5b, 0x55, 0x74, 0x82, 0x94, 0x16, 0xc, 0x65, 0x63, 0xf7, 0xed, 0x4d, 0xda, 0x4f, 0x3e, 0x1, 0xa8, 0xdf, 0x8d, 0x18, 0xdd, 0x21, 0x8b, 0xb9, 0x8d, 0xa, 0xee, 0xf");
  // enum VkResult (struct VkDevice_T *, const struct VkImageViewCaptureDescriptorDataInfoEXT *, void *)
  MAKE_CALLBACK_THUNK(callback_711, enum VkResult (struct VkDevice_T *, const struct VkImageViewCaptureDescriptorDataInfoEXT *, void *), "0x84, 0xe9, 0x5f, 0x70, 0x15, 0x18, 0xab, 0x2d, 0x39, 0x17, 0xf3, 0x52, 0xac, 0x4f, 0xf4, 0x9a, 0xe2, 0xa7, 0xe, 0x95, 0x70, 0x9c, 0xf8, 0x10, 0x5d, 0x43, 0x3c, 0x93, 0xa4, 0xa2, 0xb2, 0x8e");
  // enum VkResult (struct VkDevice_T *, const struct VkSamplerCaptureDescriptorDataInfoEXT *, void *)
  MAKE_CALLBACK_THUNK(callback_712, enum VkResult (struct VkDevice_T *, const struct VkSamplerCaptureDescriptorDataInfoEXT *, void *), "0xda, 0x70, 0xdf, 0x9b, 0x86, 0xb, 0x2f, 0xe8, 0x8d, 0xf5, 0x9d, 0x74, 0xf8, 0x2a, 0x7a, 0xc3, 0xf, 0xde, 0xba, 0x55, 0x78, 0xb2, 0xca, 0x44, 0x50, 0xd5, 0x38, 0xe9, 0xa0, 0x73, 0xa, 0x1f");
  // enum VkResult (struct VkDevice_T *, const struct VkAccelerationStructureCaptureDescriptorDataInfoEXT *, void *)
  MAKE_CALLBACK_THUNK(callback_713, enum VkResult (struct VkDevice_T *, const struct VkAccelerationStructureCaptureDescriptorDataInfoEXT *, void *), "0xbc, 0xa1, 0x13, 0x98, 0xd7, 0x8a, 0x67, 0x68, 0x7c, 0x7c, 0x5, 0x30, 0x96, 0x7c, 0x88, 0x49, 0x79, 0x3b, 0x96, 0x4, 0x50, 0x5d, 0xac, 0x91, 0x77, 0x38, 0xfd, 0xa8, 0x4c, 0x51, 0x6c, 0x35");
extern "C" {
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceProcAddr(VkDevice a_0, const char * a_1) -> PFN_vkVoidFunction {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const char * a_1;
    PFN_vkVoidFunction rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetDeviceProcAddr(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetInstanceProcAddr(VkInstance a_0, const char * a_1) -> PFN_vkVoidFunction {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const char * a_1;
    PFN_vkVoidFunction rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetInstanceProcAddr(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_Vulkan_SetGuestXSync(uintptr_t a_0, uintptr_t a_1) -> void {
  struct __attribute__((packed)) {
    uintptr_t a_0;
    uintptr_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_Vulkan_SetGuestXSync(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_Vulkan_SetGuestXGetVisualInfo(uintptr_t a_0, uintptr_t a_1) -> void {
  struct __attribute__((packed)) {
    uintptr_t a_0;
    uintptr_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_Vulkan_SetGuestXGetVisualInfo(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_Vulkan_SetGuestXDisplayString(uintptr_t a_0, uintptr_t a_1) -> void {
  struct __attribute__((packed)) {
    uintptr_t a_0;
    uintptr_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_Vulkan_SetGuestXDisplayString(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateInstance(const VkInstanceCreateInfo * a_0, const VkAllocationCallbacks * a_1, VkInstance * a_2) -> VkResult {
  struct __attribute__((packed)) {
    const VkInstanceCreateInfo * a_0;
    const VkAllocationCallbacks * a_1;
    VkInstance * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCreateInstance(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyInstance(VkInstance a_0, const VkAllocationCallbacks * a_1) -> void {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkAllocationCallbacks * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkDestroyInstance(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumeratePhysicalDevices(VkInstance a_0, uint32_t * a_1, VkPhysicalDevice * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    uint32_t * a_1;
    VkPhysicalDevice * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkEnumeratePhysicalDevices(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceFeatures(VkPhysicalDevice a_0, VkPhysicalDeviceFeatures * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceFeatures * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceFeatures(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceFormatProperties(VkPhysicalDevice a_0, VkFormat a_1, VkFormatProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkFormat a_1;
    VkFormatProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceFormatProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceImageFormatProperties(VkPhysicalDevice a_0, VkFormat a_1, VkImageType a_2, VkImageTiling a_3, VkImageUsageFlags a_4, VkImageCreateFlags a_5, VkImageFormatProperties * a_6) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkFormat a_1;
    VkImageType a_2;
    VkImageTiling a_3;
    VkImageUsageFlags a_4;
    VkImageCreateFlags a_5;
    VkImageFormatProperties * a_6;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkGetPhysicalDeviceImageFormatProperties(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceProperties(VkPhysicalDevice a_0, VkPhysicalDeviceProperties * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceProperties * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceQueueFamilyProperties(VkPhysicalDevice a_0, uint32_t * a_1, VkQueueFamilyProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkQueueFamilyProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceQueueFamilyProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceMemoryProperties(VkPhysicalDevice a_0, VkPhysicalDeviceMemoryProperties * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceMemoryProperties * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceMemoryProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDevice(VkPhysicalDevice a_0, const VkDeviceCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDevice * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkDeviceCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkDevice * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDevice(VkDevice a_0, const VkAllocationCallbacks * a_1) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAllocationCallbacks * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkDestroyDevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumerateInstanceExtensionProperties(const char * a_0, uint32_t * a_1, VkExtensionProperties * a_2) -> VkResult {
  struct __attribute__((packed)) {
    const char * a_0;
    uint32_t * a_1;
    VkExtensionProperties * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkEnumerateInstanceExtensionProperties(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumerateDeviceExtensionProperties(VkPhysicalDevice a_0, const char * a_1, uint32_t * a_2, VkExtensionProperties * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const char * a_1;
    uint32_t * a_2;
    VkExtensionProperties * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkEnumerateDeviceExtensionProperties(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumerateInstanceLayerProperties(uint32_t * a_0, VkLayerProperties * a_1) -> VkResult {
  struct __attribute__((packed)) {
    uint32_t * a_0;
    VkLayerProperties * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkEnumerateInstanceLayerProperties(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumerateDeviceLayerProperties(VkPhysicalDevice a_0, uint32_t * a_1, VkLayerProperties * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkLayerProperties * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkEnumerateDeviceLayerProperties(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceQueue(VkDevice a_0, uint32_t a_1, uint32_t a_2, VkQueue * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    uint32_t a_2;
    VkQueue * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDeviceQueue(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueSubmit(VkQueue a_0, uint32_t a_1, const VkSubmitInfo * a_2, VkFence a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkQueue a_0;
    uint32_t a_1;
    const VkSubmitInfo * a_2;
    VkFence a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkQueueSubmit(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueWaitIdle(VkQueue a_0) -> VkResult {
  struct __attribute__((packed)) {
    VkQueue a_0;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkQueueWaitIdle(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDeviceWaitIdle(VkDevice a_0) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkDeviceWaitIdle(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAllocateMemory(VkDevice a_0, const VkMemoryAllocateInfo * a_1, const VkAllocationCallbacks * a_2, VkDeviceMemory * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMemoryAllocateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkDeviceMemory * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkAllocateMemory(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkFreeMemory(VkDevice a_0, VkDeviceMemory a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeviceMemory a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkFreeMemory(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkMapMemory(VkDevice a_0, VkDeviceMemory a_1, VkDeviceSize a_2, VkDeviceSize a_3, VkMemoryMapFlags a_4, void ** a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeviceMemory a_1;
    VkDeviceSize a_2;
    VkDeviceSize a_3;
    VkMemoryMapFlags a_4;
    void ** a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkMapMemory(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUnmapMemory(VkDevice a_0, VkDeviceMemory a_1) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeviceMemory a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkUnmapMemory(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkFlushMappedMemoryRanges(VkDevice a_0, uint32_t a_1, const VkMappedMemoryRange * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkMappedMemoryRange * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkFlushMappedMemoryRanges(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkInvalidateMappedMemoryRanges(VkDevice a_0, uint32_t a_1, const VkMappedMemoryRange * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkMappedMemoryRange * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkInvalidateMappedMemoryRanges(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceMemoryCommitment(VkDevice a_0, VkDeviceMemory a_1, VkDeviceSize * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeviceMemory a_1;
    VkDeviceSize * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceMemoryCommitment(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindBufferMemory(VkDevice a_0, VkBuffer a_1, VkDeviceMemory a_2, VkDeviceSize a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkBuffer a_1;
    VkDeviceMemory a_2;
    VkDeviceSize a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkBindBufferMemory(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindImageMemory(VkDevice a_0, VkImage a_1, VkDeviceMemory a_2, VkDeviceSize a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    VkDeviceMemory a_2;
    VkDeviceSize a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkBindImageMemory(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferMemoryRequirements(VkDevice a_0, VkBuffer a_1, VkMemoryRequirements * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkBuffer a_1;
    VkMemoryRequirements * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetBufferMemoryRequirements(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageMemoryRequirements(VkDevice a_0, VkImage a_1, VkMemoryRequirements * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    VkMemoryRequirements * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetImageMemoryRequirements(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageSparseMemoryRequirements(VkDevice a_0, VkImage a_1, uint32_t * a_2, VkSparseImageMemoryRequirements * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    uint32_t * a_2;
    VkSparseImageMemoryRequirements * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetImageSparseMemoryRequirements(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSparseImageFormatProperties(VkPhysicalDevice a_0, VkFormat a_1, VkImageType a_2, VkSampleCountFlagBits a_3, VkImageUsageFlags a_4, VkImageTiling a_5, uint32_t * a_6, VkSparseImageFormatProperties * a_7) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkFormat a_1;
    VkImageType a_2;
    VkSampleCountFlagBits a_3;
    VkImageUsageFlags a_4;
    VkImageTiling a_5;
    uint32_t * a_6;
    VkSparseImageFormatProperties * a_7;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkGetPhysicalDeviceSparseImageFormatProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueBindSparse(VkQueue a_0, uint32_t a_1, const VkBindSparseInfo * a_2, VkFence a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkQueue a_0;
    uint32_t a_1;
    const VkBindSparseInfo * a_2;
    VkFence a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkQueueBindSparse(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateFence(VkDevice a_0, const VkFenceCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkFence * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkFenceCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkFence * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateFence(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyFence(VkDevice a_0, VkFence a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkFence a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyFence(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkResetFences(VkDevice a_0, uint32_t a_1, const VkFence * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkFence * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkResetFences(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetFenceStatus(VkDevice a_0, VkFence a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkFence a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetFenceStatus(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkWaitForFences(VkDevice a_0, uint32_t a_1, const VkFence * a_2, VkBool32 a_3, uint64_t a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkFence * a_2;
    VkBool32 a_3;
    uint64_t a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkWaitForFences(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateSemaphore(VkDevice a_0, const VkSemaphoreCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSemaphore * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSemaphoreCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkSemaphore * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateSemaphore(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroySemaphore(VkDevice a_0, VkSemaphore a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSemaphore a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroySemaphore(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateQueryPool(VkDevice a_0, const VkQueryPoolCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkQueryPool * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkQueryPoolCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkQueryPool * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateQueryPool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyQueryPool(VkDevice a_0, VkQueryPool a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkQueryPool a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyQueryPool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetQueryPoolResults(VkDevice a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5, VkDeviceSize a_6, VkQueryResultFlags a_7) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    uint32_t a_3;
    size_t a_4;
    void * a_5;
    VkDeviceSize a_6;
    VkQueryResultFlags a_7;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkGetQueryPoolResults(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateBuffer(VkDevice a_0, const VkBufferCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkBuffer * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkBuffer * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateBuffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyBuffer(VkDevice a_0, VkBuffer a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkBuffer a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyBuffer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateImage(VkDevice a_0, const VkImageCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkImage * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkImage * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateImage(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyImage(VkDevice a_0, VkImage a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyImage(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageSubresourceLayout(VkDevice a_0, VkImage a_1, const VkImageSubresource * a_2, VkSubresourceLayout * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    const VkImageSubresource * a_2;
    VkSubresourceLayout * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetImageSubresourceLayout(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateImageView(VkDevice a_0, const VkImageViewCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkImageView * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageViewCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkImageView * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateImageView(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyImageView(VkDevice a_0, VkImageView a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImageView a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyImageView(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateCommandPool(VkDevice a_0, const VkCommandPoolCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkCommandPool * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCommandPoolCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkCommandPool * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateCommandPool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyCommandPool(VkDevice a_0, VkCommandPool a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkCommandPool a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyCommandPool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkResetCommandPool(VkDevice a_0, VkCommandPool a_1, VkCommandPoolResetFlags a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkCommandPool a_1;
    VkCommandPoolResetFlags a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkResetCommandPool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAllocateCommandBuffers(VkDevice a_0, const VkCommandBufferAllocateInfo * a_1, VkCommandBuffer * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCommandBufferAllocateInfo * a_1;
    VkCommandBuffer * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkAllocateCommandBuffers(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkFreeCommandBuffers(VkDevice a_0, VkCommandPool a_1, uint32_t a_2, const VkCommandBuffer * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkCommandPool a_1;
    uint32_t a_2;
    const VkCommandBuffer * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkFreeCommandBuffers(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBeginCommandBuffer(VkCommandBuffer a_0, const VkCommandBufferBeginInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCommandBufferBeginInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkBeginCommandBuffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEndCommandBuffer(VkCommandBuffer a_0) -> VkResult {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkEndCommandBuffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkResetCommandBuffer(VkCommandBuffer a_0, VkCommandBufferResetFlags a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCommandBufferResetFlags a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkResetCommandBuffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkBuffer a_2, uint32_t a_3, const VkBufferCopy * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkBuffer a_2;
    uint32_t a_3;
    const VkBufferCopy * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdCopyBuffer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkImage a_3, VkImageLayout a_4, uint32_t a_5, const VkImageCopy * a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImage a_1;
    VkImageLayout a_2;
    VkImage a_3;
    VkImageLayout a_4;
    uint32_t a_5;
    const VkImageCopy * a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdCopyImage(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyBufferToImage(VkCommandBuffer a_0, VkBuffer a_1, VkImage a_2, VkImageLayout a_3, uint32_t a_4, const VkBufferImageCopy * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkImage a_2;
    VkImageLayout a_3;
    uint32_t a_4;
    const VkBufferImageCopy * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdCopyBufferToImage(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyImageToBuffer(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkBuffer a_3, uint32_t a_4, const VkBufferImageCopy * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImage a_1;
    VkImageLayout a_2;
    VkBuffer a_3;
    uint32_t a_4;
    const VkBufferImageCopy * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdCopyImageToBuffer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdUpdateBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, const void * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkDeviceSize a_3;
    const void * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdUpdateBuffer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdFillBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkDeviceSize a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdFillBuffer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPipelineBarrier(VkCommandBuffer a_0, VkPipelineStageFlags a_1, VkPipelineStageFlags a_2, VkDependencyFlags a_3, uint32_t a_4, const VkMemoryBarrier * a_5, uint32_t a_6, const VkBufferMemoryBarrier * a_7, uint32_t a_8, const VkImageMemoryBarrier * a_9) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineStageFlags a_1;
    VkPipelineStageFlags a_2;
    VkDependencyFlags a_3;
    uint32_t a_4;
    const VkMemoryBarrier * a_5;
    uint32_t a_6;
    const VkBufferMemoryBarrier * a_7;
    uint32_t a_8;
    const VkImageMemoryBarrier * a_9;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  args.a_8 = a_8;
  args.a_9 = a_9;
  fexthunks_libvulkan_vkCmdPipelineBarrier(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginQuery(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, VkQueryControlFlags a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    VkQueryControlFlags a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdBeginQuery(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndQuery(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkQueryPool a_1;
    uint32_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdEndQuery(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdResetQueryPool(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdResetQueryPool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteTimestamp(VkCommandBuffer a_0, VkPipelineStageFlagBits a_1, VkQueryPool a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineStageFlagBits a_1;
    VkQueryPool a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdWriteTimestamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyQueryPoolResults(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3, VkBuffer a_4, VkDeviceSize a_5, VkDeviceSize a_6, VkQueryResultFlags a_7) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    uint32_t a_3;
    VkBuffer a_4;
    VkDeviceSize a_5;
    VkDeviceSize a_6;
    VkQueryResultFlags a_7;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkCmdCopyQueryPoolResults(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdExecuteCommands(VkCommandBuffer a_0, uint32_t a_1, const VkCommandBuffer * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkCommandBuffer * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdExecuteCommands(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateEvent(VkDevice a_0, const VkEventCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkEvent * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkEventCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkEvent * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateEvent(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyEvent(VkDevice a_0, VkEvent a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkEvent a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyEvent(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetEventStatus(VkDevice a_0, VkEvent a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkEvent a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetEventStatus(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetEvent(VkDevice a_0, VkEvent a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkEvent a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkSetEvent(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkResetEvent(VkDevice a_0, VkEvent a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkEvent a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkResetEvent(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateBufferView(VkDevice a_0, const VkBufferViewCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkBufferView * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferViewCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkBufferView * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateBufferView(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyBufferView(VkDevice a_0, VkBufferView a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkBufferView a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyBufferView(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateShaderModule(VkDevice a_0, const VkShaderModuleCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkShaderModule * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkShaderModuleCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkShaderModule * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateShaderModule(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyShaderModule(VkDevice a_0, VkShaderModule a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkShaderModule a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyShaderModule(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreatePipelineCache(VkDevice a_0, const VkPipelineCacheCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPipelineCache * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineCacheCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkPipelineCache * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreatePipelineCache(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyPipelineCache(VkDevice a_0, VkPipelineCache a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineCache a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyPipelineCache(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineCacheData(VkDevice a_0, VkPipelineCache a_1, size_t * a_2, void * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineCache a_1;
    size_t * a_2;
    void * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPipelineCacheData(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkMergePipelineCaches(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkPipelineCache * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineCache a_1;
    uint32_t a_2;
    const VkPipelineCache * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkMergePipelineCaches(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateComputePipelines(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkComputePipelineCreateInfo * a_3, const VkAllocationCallbacks * a_4, VkPipeline * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineCache a_1;
    uint32_t a_2;
    const VkComputePipelineCreateInfo * a_3;
    const VkAllocationCallbacks * a_4;
    VkPipeline * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCreateComputePipelines(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyPipeline(VkDevice a_0, VkPipeline a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipeline a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyPipeline(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreatePipelineLayout(VkDevice a_0, const VkPipelineLayoutCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPipelineLayout * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineLayoutCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkPipelineLayout * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreatePipelineLayout(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyPipelineLayout(VkDevice a_0, VkPipelineLayout a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineLayout a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyPipelineLayout(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateSampler(VkDevice a_0, const VkSamplerCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSampler * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSamplerCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkSampler * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateSampler(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroySampler(VkDevice a_0, VkSampler a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSampler a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroySampler(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDescriptorSetLayout(VkDevice a_0, const VkDescriptorSetLayoutCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorSetLayout * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorSetLayoutCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkDescriptorSetLayout * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDescriptorSetLayout(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDescriptorSetLayout(VkDevice a_0, VkDescriptorSetLayout a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorSetLayout a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDescriptorSetLayout(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDescriptorPool(VkDevice a_0, const VkDescriptorPoolCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorPool * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorPoolCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkDescriptorPool * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDescriptorPool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDescriptorPool(VkDevice a_0, VkDescriptorPool a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorPool a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDescriptorPool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkResetDescriptorPool(VkDevice a_0, VkDescriptorPool a_1, VkDescriptorPoolResetFlags a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorPool a_1;
    VkDescriptorPoolResetFlags a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkResetDescriptorPool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAllocateDescriptorSets(VkDevice a_0, const VkDescriptorSetAllocateInfo * a_1, VkDescriptorSet * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorSetAllocateInfo * a_1;
    VkDescriptorSet * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkAllocateDescriptorSets(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkFreeDescriptorSets(VkDevice a_0, VkDescriptorPool a_1, uint32_t a_2, const VkDescriptorSet * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorPool a_1;
    uint32_t a_2;
    const VkDescriptorSet * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkFreeDescriptorSets(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUpdateDescriptorSets(VkDevice a_0, uint32_t a_1, const VkWriteDescriptorSet * a_2, uint32_t a_3, const VkCopyDescriptorSet * a_4) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkWriteDescriptorSet * a_2;
    uint32_t a_3;
    const VkCopyDescriptorSet * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkUpdateDescriptorSets(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindPipeline(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipeline a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipeline a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBindPipeline(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindDescriptorSets(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const VkDescriptorSet * a_5, uint32_t a_6, const uint32_t * a_7) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipelineLayout a_2;
    uint32_t a_3;
    uint32_t a_4;
    const VkDescriptorSet * a_5;
    uint32_t a_6;
    const uint32_t * a_7;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkCmdBindDescriptorSets(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdClearColorImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, const VkClearColorValue * a_3, uint32_t a_4, const VkImageSubresourceRange * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImage a_1;
    VkImageLayout a_2;
    const VkClearColorValue * a_3;
    uint32_t a_4;
    const VkImageSubresourceRange * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdClearColorImage(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDispatch(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdDispatch(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDispatchIndirect(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdDispatchIndirect(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetEvent(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkEvent a_1;
    VkPipelineStageFlags a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetEvent(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdResetEvent(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkEvent a_1;
    VkPipelineStageFlags a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdResetEvent(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWaitEvents(VkCommandBuffer a_0, uint32_t a_1, const VkEvent * a_2, VkPipelineStageFlags a_3, VkPipelineStageFlags a_4, uint32_t a_5, const VkMemoryBarrier * a_6, uint32_t a_7, const VkBufferMemoryBarrier * a_8, uint32_t a_9, const VkImageMemoryBarrier * a_10) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkEvent * a_2;
    VkPipelineStageFlags a_3;
    VkPipelineStageFlags a_4;
    uint32_t a_5;
    const VkMemoryBarrier * a_6;
    uint32_t a_7;
    const VkBufferMemoryBarrier * a_8;
    uint32_t a_9;
    const VkImageMemoryBarrier * a_10;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  args.a_8 = a_8;
  args.a_9 = a_9;
  args.a_10 = a_10;
  fexthunks_libvulkan_vkCmdWaitEvents(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushConstants(VkCommandBuffer a_0, VkPipelineLayout a_1, VkShaderStageFlags a_2, uint32_t a_3, uint32_t a_4, const void * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineLayout a_1;
    VkShaderStageFlags a_2;
    uint32_t a_3;
    uint32_t a_4;
    const void * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdPushConstants(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateGraphicsPipelines(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkGraphicsPipelineCreateInfo * a_3, const VkAllocationCallbacks * a_4, VkPipeline * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineCache a_1;
    uint32_t a_2;
    const VkGraphicsPipelineCreateInfo * a_3;
    const VkAllocationCallbacks * a_4;
    VkPipeline * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCreateGraphicsPipelines(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateFramebuffer(VkDevice a_0, const VkFramebufferCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkFramebuffer * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkFramebufferCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkFramebuffer * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateFramebuffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyFramebuffer(VkDevice a_0, VkFramebuffer a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkFramebuffer a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyFramebuffer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateRenderPass(VkDevice a_0, const VkRenderPassCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkRenderPass * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkRenderPassCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkRenderPass * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateRenderPass(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyRenderPass(VkDevice a_0, VkRenderPass a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkRenderPass a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyRenderPass(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRenderAreaGranularity(VkDevice a_0, VkRenderPass a_1, VkExtent2D * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkRenderPass a_1;
    VkExtent2D * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetRenderAreaGranularity(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetViewport(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkViewport * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkViewport * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetViewport(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetScissor(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkRect2D * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkRect2D * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetScissor(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLineWidth(VkCommandBuffer a_0, float a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    float a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetLineWidth(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthBias(VkCommandBuffer a_0, float a_1, float a_2, float a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    float a_1;
    float a_2;
    float a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetDepthBias(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetBlendConstants(VkCommandBuffer a_0, const float * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const float * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetBlendConstants(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthBounds(VkCommandBuffer a_0, float a_1, float a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    float a_1;
    float a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetDepthBounds(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetStencilCompareMask(VkCommandBuffer a_0, VkStencilFaceFlags a_1, uint32_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkStencilFaceFlags a_1;
    uint32_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetStencilCompareMask(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetStencilWriteMask(VkCommandBuffer a_0, VkStencilFaceFlags a_1, uint32_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkStencilFaceFlags a_1;
    uint32_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetStencilWriteMask(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetStencilReference(VkCommandBuffer a_0, VkStencilFaceFlags a_1, uint32_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkStencilFaceFlags a_1;
    uint32_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetStencilReference(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindIndexBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkIndexType a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkIndexType a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdBindIndexBuffer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindVertexBuffers(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBuffer * a_3;
    const VkDeviceSize * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdBindVertexBuffers(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDraw(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdDraw(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndexed(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, int32_t a_4, uint32_t a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
    int32_t a_4;
    uint32_t a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdDrawIndexed(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndirect(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    uint32_t a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdDrawIndirect(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndexedIndirect(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    uint32_t a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdDrawIndexedIndirect(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBlitImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkImage a_3, VkImageLayout a_4, uint32_t a_5, const VkImageBlit * a_6, VkFilter a_7) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImage a_1;
    VkImageLayout a_2;
    VkImage a_3;
    VkImageLayout a_4;
    uint32_t a_5;
    const VkImageBlit * a_6;
    VkFilter a_7;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkCmdBlitImage(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdClearDepthStencilImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, const VkClearDepthStencilValue * a_3, uint32_t a_4, const VkImageSubresourceRange * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImage a_1;
    VkImageLayout a_2;
    const VkClearDepthStencilValue * a_3;
    uint32_t a_4;
    const VkImageSubresourceRange * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdClearDepthStencilImage(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdClearAttachments(VkCommandBuffer a_0, uint32_t a_1, const VkClearAttachment * a_2, uint32_t a_3, const VkClearRect * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkClearAttachment * a_2;
    uint32_t a_3;
    const VkClearRect * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdClearAttachments(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdResolveImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkImage a_3, VkImageLayout a_4, uint32_t a_5, const VkImageResolve * a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImage a_1;
    VkImageLayout a_2;
    VkImage a_3;
    VkImageLayout a_4;
    uint32_t a_5;
    const VkImageResolve * a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdResolveImage(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginRenderPass(VkCommandBuffer a_0, const VkRenderPassBeginInfo * a_1, VkSubpassContents a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderPassBeginInfo * a_1;
    VkSubpassContents a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBeginRenderPass(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdNextSubpass(VkCommandBuffer a_0, VkSubpassContents a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkSubpassContents a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdNextSubpass(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndRenderPass(VkCommandBuffer a_0) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkCmdEndRenderPass(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumerateInstanceVersion(uint32_t * a_0) -> VkResult {
  struct __attribute__((packed)) {
    uint32_t * a_0;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkEnumerateInstanceVersion(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindBufferMemory2(VkDevice a_0, uint32_t a_1, const VkBindBufferMemoryInfo * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkBindBufferMemoryInfo * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkBindBufferMemory2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindImageMemory2(VkDevice a_0, uint32_t a_1, const VkBindImageMemoryInfo * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkBindImageMemoryInfo * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkBindImageMemory2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceGroupPeerMemoryFeatures(VkDevice a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, VkPeerMemoryFeatureFlags * a_4) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
    VkPeerMemoryFeatureFlags * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetDeviceGroupPeerMemoryFeatures(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDeviceMask(VkCommandBuffer a_0, uint32_t a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDeviceMask(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumeratePhysicalDeviceGroups(VkInstance a_0, uint32_t * a_1, VkPhysicalDeviceGroupProperties * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    uint32_t * a_1;
    VkPhysicalDeviceGroupProperties * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkEnumeratePhysicalDeviceGroups(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageMemoryRequirements2(VkDevice a_0, const VkImageMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageMemoryRequirementsInfo2 * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetImageMemoryRequirements2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferMemoryRequirements2(VkDevice a_0, const VkBufferMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferMemoryRequirementsInfo2 * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetBufferMemoryRequirements2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageSparseMemoryRequirements2(VkDevice a_0, const VkImageSparseMemoryRequirementsInfo2 * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageSparseMemoryRequirementsInfo2 * a_1;
    uint32_t * a_2;
    VkSparseImageMemoryRequirements2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetImageSparseMemoryRequirements2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceFeatures2(VkPhysicalDevice a_0, VkPhysicalDeviceFeatures2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceFeatures2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceFeatures2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceProperties2(VkPhysicalDevice a_0, VkPhysicalDeviceProperties2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceProperties2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceProperties2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceFormatProperties2(VkPhysicalDevice a_0, VkFormat a_1, VkFormatProperties2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkFormat a_1;
    VkFormatProperties2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceFormatProperties2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceImageFormatProperties2(VkPhysicalDevice a_0, const VkPhysicalDeviceImageFormatInfo2 * a_1, VkImageFormatProperties2 * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceImageFormatInfo2 * a_1;
    VkImageFormatProperties2 * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceImageFormatProperties2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceQueueFamilyProperties2(VkPhysicalDevice a_0, uint32_t * a_1, VkQueueFamilyProperties2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkQueueFamilyProperties2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceQueueFamilyProperties2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceMemoryProperties2(VkPhysicalDevice a_0, VkPhysicalDeviceMemoryProperties2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceMemoryProperties2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceMemoryProperties2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSparseImageFormatProperties2(VkPhysicalDevice a_0, const VkPhysicalDeviceSparseImageFormatInfo2 * a_1, uint32_t * a_2, VkSparseImageFormatProperties2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceSparseImageFormatInfo2 * a_1;
    uint32_t * a_2;
    VkSparseImageFormatProperties2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceSparseImageFormatProperties2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkTrimCommandPool(VkDevice a_0, VkCommandPool a_1, VkCommandPoolTrimFlags a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkCommandPool a_1;
    VkCommandPoolTrimFlags a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkTrimCommandPool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceQueue2(VkDevice a_0, const VkDeviceQueueInfo2 * a_1, VkQueue * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceQueueInfo2 * a_1;
    VkQueue * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceQueue2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalBufferProperties(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalBufferInfo * a_1, VkExternalBufferProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceExternalBufferInfo * a_1;
    VkExternalBufferProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalBufferProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalFenceProperties(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalFenceInfo * a_1, VkExternalFenceProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceExternalFenceInfo * a_1;
    VkExternalFenceProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalFenceProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalSemaphoreProperties(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalSemaphoreInfo * a_1, VkExternalSemaphoreProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceExternalSemaphoreInfo * a_1;
    VkExternalSemaphoreProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalSemaphoreProperties(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDispatchBase(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
    uint32_t a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDispatchBase(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDescriptorUpdateTemplate(VkDevice a_0, const VkDescriptorUpdateTemplateCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorUpdateTemplate * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorUpdateTemplateCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkDescriptorUpdateTemplate * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDescriptorUpdateTemplate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDescriptorUpdateTemplate(VkDevice a_0, VkDescriptorUpdateTemplate a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorUpdateTemplate a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDescriptorUpdateTemplate(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUpdateDescriptorSetWithTemplate(VkDevice a_0, VkDescriptorSet a_1, VkDescriptorUpdateTemplate a_2, const void * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorSet a_1;
    VkDescriptorUpdateTemplate a_2;
    const void * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkUpdateDescriptorSetWithTemplate(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDescriptorSetLayoutSupport(VkDevice a_0, const VkDescriptorSetLayoutCreateInfo * a_1, VkDescriptorSetLayoutSupport * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorSetLayoutCreateInfo * a_1;
    VkDescriptorSetLayoutSupport * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDescriptorSetLayoutSupport(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateSamplerYcbcrConversion(VkDevice a_0, const VkSamplerYcbcrConversionCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSamplerYcbcrConversion * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSamplerYcbcrConversionCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkSamplerYcbcrConversion * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateSamplerYcbcrConversion(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroySamplerYcbcrConversion(VkDevice a_0, VkSamplerYcbcrConversion a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSamplerYcbcrConversion a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroySamplerYcbcrConversion(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkResetQueryPool(VkDevice a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkResetQueryPool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSemaphoreCounterValue(VkDevice a_0, VkSemaphore a_1, uint64_t * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSemaphore a_1;
    uint64_t * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetSemaphoreCounterValue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkWaitSemaphores(VkDevice a_0, const VkSemaphoreWaitInfo * a_1, uint64_t a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSemaphoreWaitInfo * a_1;
    uint64_t a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkWaitSemaphores(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSignalSemaphore(VkDevice a_0, const VkSemaphoreSignalInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSemaphoreSignalInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkSignalSemaphore(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferDeviceAddress(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> VkDeviceAddress {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferDeviceAddressInfo * a_1;
    VkDeviceAddress rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetBufferDeviceAddress(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferOpaqueCaptureAddress(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> uint64_t {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferDeviceAddressInfo * a_1;
    uint64_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetBufferOpaqueCaptureAddress(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceMemoryOpaqueCaptureAddress(VkDevice a_0, const VkDeviceMemoryOpaqueCaptureAddressInfo * a_1) -> uint64_t {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceMemoryOpaqueCaptureAddressInfo * a_1;
    uint64_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetDeviceMemoryOpaqueCaptureAddress(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndirectCount(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawIndirectCount(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndexedIndirectCount(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawIndexedIndirectCount(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateRenderPass2(VkDevice a_0, const VkRenderPassCreateInfo2 * a_1, const VkAllocationCallbacks * a_2, VkRenderPass * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkRenderPassCreateInfo2 * a_1;
    const VkAllocationCallbacks * a_2;
    VkRenderPass * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateRenderPass2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginRenderPass2(VkCommandBuffer a_0, const VkRenderPassBeginInfo * a_1, const VkSubpassBeginInfo * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderPassBeginInfo * a_1;
    const VkSubpassBeginInfo * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBeginRenderPass2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdNextSubpass2(VkCommandBuffer a_0, const VkSubpassBeginInfo * a_1, const VkSubpassEndInfo * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkSubpassBeginInfo * a_1;
    const VkSubpassEndInfo * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdNextSubpass2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndRenderPass2(VkCommandBuffer a_0, const VkSubpassEndInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkSubpassEndInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdEndRenderPass2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceToolProperties(VkPhysicalDevice a_0, uint32_t * a_1, VkPhysicalDeviceToolProperties * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkPhysicalDeviceToolProperties * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceToolProperties(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreatePrivateDataSlot(VkDevice a_0, const VkPrivateDataSlotCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPrivateDataSlot * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPrivateDataSlotCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkPrivateDataSlot * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreatePrivateDataSlot(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyPrivateDataSlot(VkDevice a_0, VkPrivateDataSlot a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPrivateDataSlot a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyPrivateDataSlot(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetPrivateData(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkObjectType a_1;
    uint64_t a_2;
    VkPrivateDataSlot a_3;
    uint64_t a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkSetPrivateData(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPrivateData(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t * a_4) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkObjectType a_1;
    uint64_t a_2;
    VkPrivateDataSlot a_3;
    uint64_t * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetPrivateData(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPipelineBarrier2(VkCommandBuffer a_0, const VkDependencyInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDependencyInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPipelineBarrier2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteTimestamp2(VkCommandBuffer a_0, VkPipelineStageFlags2 a_1, VkQueryPool a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineStageFlags2 a_1;
    VkQueryPool a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdWriteTimestamp2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueSubmit2(VkQueue a_0, uint32_t a_1, const VkSubmitInfo2 * a_2, VkFence a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkQueue a_0;
    uint32_t a_1;
    const VkSubmitInfo2 * a_2;
    VkFence a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkQueueSubmit2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyBuffer2(VkCommandBuffer a_0, const VkCopyBufferInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyBufferInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyBuffer2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyImage2(VkCommandBuffer a_0, const VkCopyImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyImage2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyBufferToImage2(VkCommandBuffer a_0, const VkCopyBufferToImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyBufferToImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyBufferToImage2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyImageToBuffer2(VkCommandBuffer a_0, const VkCopyImageToBufferInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyImageToBufferInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyImageToBuffer2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceBufferMemoryRequirements(VkDevice a_0, const VkDeviceBufferMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceBufferMemoryRequirements * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceBufferMemoryRequirements(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceImageMemoryRequirements(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceImageMemoryRequirements * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceImageMemoryRequirements(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceImageSparseMemoryRequirements(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceImageMemoryRequirements * a_1;
    uint32_t * a_2;
    VkSparseImageMemoryRequirements2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDeviceImageSparseMemoryRequirements(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetEvent2(VkCommandBuffer a_0, VkEvent a_1, const VkDependencyInfo * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkEvent a_1;
    const VkDependencyInfo * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetEvent2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdResetEvent2(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags2 a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkEvent a_1;
    VkPipelineStageFlags2 a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdResetEvent2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWaitEvents2(VkCommandBuffer a_0, uint32_t a_1, const VkEvent * a_2, const VkDependencyInfo * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkEvent * a_2;
    const VkDependencyInfo * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdWaitEvents2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBlitImage2(VkCommandBuffer a_0, const VkBlitImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkBlitImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBlitImage2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdResolveImage2(VkCommandBuffer a_0, const VkResolveImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkResolveImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdResolveImage2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginRendering(VkCommandBuffer a_0, const VkRenderingInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBeginRendering(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndRendering(VkCommandBuffer a_0) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkCmdEndRendering(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCullMode(VkCommandBuffer a_0, VkCullModeFlags a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCullModeFlags a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCullMode(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetFrontFace(VkCommandBuffer a_0, VkFrontFace a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkFrontFace a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetFrontFace(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPrimitiveTopology(VkCommandBuffer a_0, VkPrimitiveTopology a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPrimitiveTopology a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPrimitiveTopology(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetViewportWithCount(VkCommandBuffer a_0, uint32_t a_1, const VkViewport * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkViewport * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetViewportWithCount(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetScissorWithCount(VkCommandBuffer a_0, uint32_t a_1, const VkRect2D * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkRect2D * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetScissorWithCount(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindVertexBuffers2(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4, const VkDeviceSize * a_5, const VkDeviceSize * a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBuffer * a_3;
    const VkDeviceSize * a_4;
    const VkDeviceSize * a_5;
    const VkDeviceSize * a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdBindVertexBuffers2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthTestEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthTestEnable(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthWriteEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthWriteEnable(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthCompareOp(VkCommandBuffer a_0, VkCompareOp a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCompareOp a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthCompareOp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthBoundsTestEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthBoundsTestEnable(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetStencilTestEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetStencilTestEnable(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetStencilOp(VkCommandBuffer a_0, VkStencilFaceFlags a_1, VkStencilOp a_2, VkStencilOp a_3, VkStencilOp a_4, VkCompareOp a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkStencilFaceFlags a_1;
    VkStencilOp a_2;
    VkStencilOp a_3;
    VkStencilOp a_4;
    VkCompareOp a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdSetStencilOp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRasterizerDiscardEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRasterizerDiscardEnable(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthBiasEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthBiasEnable(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPrimitiveRestartEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPrimitiveRestartEnable(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkMapMemory2(VkDevice a_0, const VkMemoryMapInfo * a_1, void ** a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMemoryMapInfo * a_1;
    void ** a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkMapMemory2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUnmapMemory2(VkDevice a_0, const VkMemoryUnmapInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMemoryUnmapInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkUnmapMemory2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceImageSubresourceLayout(VkDevice a_0, const VkDeviceImageSubresourceInfo * a_1, VkSubresourceLayout2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceImageSubresourceInfo * a_1;
    VkSubresourceLayout2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceImageSubresourceLayout(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageSubresourceLayout2(VkDevice a_0, VkImage a_1, const VkImageSubresource2 * a_2, VkSubresourceLayout2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    const VkImageSubresource2 * a_2;
    VkSubresourceLayout2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetImageSubresourceLayout2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyMemoryToImage(VkDevice a_0, const VkCopyMemoryToImageInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCopyMemoryToImageInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCopyMemoryToImage(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyImageToMemory(VkDevice a_0, const VkCopyImageToMemoryInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCopyImageToMemoryInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCopyImageToMemory(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyImageToImage(VkDevice a_0, const VkCopyImageToImageInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCopyImageToImageInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCopyImageToImage(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkTransitionImageLayout(VkDevice a_0, uint32_t a_1, const VkHostImageLayoutTransitionInfo * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkHostImageLayoutTransitionInfo * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkTransitionImageLayout(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSet(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const VkWriteDescriptorSet * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipelineLayout a_2;
    uint32_t a_3;
    uint32_t a_4;
    const VkWriteDescriptorSet * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdPushDescriptorSet(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSetWithTemplate(VkCommandBuffer a_0, VkDescriptorUpdateTemplate a_1, VkPipelineLayout a_2, uint32_t a_3, const void * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDescriptorUpdateTemplate a_1;
    VkPipelineLayout a_2;
    uint32_t a_3;
    const void * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdPushDescriptorSetWithTemplate(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindDescriptorSets2(VkCommandBuffer a_0, const VkBindDescriptorSetsInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkBindDescriptorSetsInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBindDescriptorSets2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushConstants2(VkCommandBuffer a_0, const VkPushConstantsInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPushConstantsInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPushConstants2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSet2(VkCommandBuffer a_0, const VkPushDescriptorSetInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPushDescriptorSetInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPushDescriptorSet2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSetWithTemplate2(VkCommandBuffer a_0, const VkPushDescriptorSetWithTemplateInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPushDescriptorSetWithTemplateInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPushDescriptorSetWithTemplate2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLineStipple(VkCommandBuffer a_0, uint32_t a_1, uint16_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint16_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetLineStipple(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindIndexBuffer2(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, VkIndexType a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkDeviceSize a_3;
    VkIndexType a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdBindIndexBuffer2(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRenderingAreaGranularity(VkDevice a_0, const VkRenderingAreaInfo * a_1, VkExtent2D * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkRenderingAreaInfo * a_1;
    VkExtent2D * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetRenderingAreaGranularity(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRenderingAttachmentLocations(VkCommandBuffer a_0, const VkRenderingAttachmentLocationInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingAttachmentLocationInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRenderingAttachmentLocations(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRenderingInputAttachmentIndices(VkCommandBuffer a_0, const VkRenderingInputAttachmentIndexInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingInputAttachmentIndexInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRenderingInputAttachmentIndices(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroySurfaceKHR(VkInstance a_0, VkSurfaceKHR a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkInstance a_0;
    VkSurfaceKHR a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroySurfaceKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSurfaceSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, VkSurfaceKHR a_2, VkBool32 * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    VkSurfaceKHR a_2;
    VkBool32 * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceSurfaceSupportKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSurfaceCapabilitiesKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, VkSurfaceCapabilitiesKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkSurfaceKHR a_1;
    VkSurfaceCapabilitiesKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceSurfaceCapabilitiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSurfaceFormatsKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, uint32_t * a_2, VkSurfaceFormatKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkSurfaceKHR a_1;
    uint32_t * a_2;
    VkSurfaceFormatKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceSurfaceFormatsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSurfacePresentModesKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, uint32_t * a_2, VkPresentModeKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkSurfaceKHR a_1;
    uint32_t * a_2;
    VkPresentModeKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceSurfacePresentModesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateSwapchainKHR(VkDevice a_0, const VkSwapchainCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSwapchainKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSwapchainCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkSwapchainKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateSwapchainKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroySwapchainKHR(VkDevice a_0, VkSwapchainKHR a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroySwapchainKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSwapchainImagesKHR(VkDevice a_0, VkSwapchainKHR a_1, uint32_t * a_2, VkImage * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    uint32_t * a_2;
    VkImage * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetSwapchainImagesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAcquireNextImageKHR(VkDevice a_0, VkSwapchainKHR a_1, uint64_t a_2, VkSemaphore a_3, VkFence a_4, uint32_t * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    uint64_t a_2;
    VkSemaphore a_3;
    VkFence a_4;
    uint32_t * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkAcquireNextImageKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueuePresentKHR(VkQueue a_0, const VkPresentInfoKHR * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkQueue a_0;
    const VkPresentInfoKHR * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkQueuePresentKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceGroupPresentCapabilitiesKHR(VkDevice a_0, VkDeviceGroupPresentCapabilitiesKHR * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeviceGroupPresentCapabilitiesKHR * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetDeviceGroupPresentCapabilitiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceGroupSurfacePresentModesKHR(VkDevice a_0, VkSurfaceKHR a_1, VkDeviceGroupPresentModeFlagsKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSurfaceKHR a_1;
    VkDeviceGroupPresentModeFlagsKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceGroupSurfacePresentModesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDevicePresentRectanglesKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, uint32_t * a_2, VkRect2D * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkSurfaceKHR a_1;
    uint32_t * a_2;
    VkRect2D * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDevicePresentRectanglesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAcquireNextImage2KHR(VkDevice a_0, const VkAcquireNextImageInfoKHR * a_1, uint32_t * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAcquireNextImageInfoKHR * a_1;
    uint32_t * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkAcquireNextImage2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceDisplayPropertiesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayPropertiesKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkDisplayPropertiesKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceDisplayPropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceDisplayPlanePropertiesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayPlanePropertiesKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkDisplayPlanePropertiesKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceDisplayPlanePropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDisplayPlaneSupportedDisplaysKHR(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkDisplayKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    uint32_t * a_2;
    VkDisplayKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDisplayPlaneSupportedDisplaysKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDisplayModePropertiesKHR(VkPhysicalDevice a_0, VkDisplayKHR a_1, uint32_t * a_2, VkDisplayModePropertiesKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkDisplayKHR a_1;
    uint32_t * a_2;
    VkDisplayModePropertiesKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDisplayModePropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDisplayModeKHR(VkPhysicalDevice a_0, VkDisplayKHR a_1, const VkDisplayModeCreateInfoKHR * a_2, const VkAllocationCallbacks * a_3, VkDisplayModeKHR * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkDisplayKHR a_1;
    const VkDisplayModeCreateInfoKHR * a_2;
    const VkAllocationCallbacks * a_3;
    VkDisplayModeKHR * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCreateDisplayModeKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDisplayPlaneCapabilitiesKHR(VkPhysicalDevice a_0, VkDisplayModeKHR a_1, uint32_t a_2, VkDisplayPlaneCapabilitiesKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkDisplayModeKHR a_1;
    uint32_t a_2;
    VkDisplayPlaneCapabilitiesKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDisplayPlaneCapabilitiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDisplayPlaneSurfaceKHR(VkInstance a_0, const VkDisplaySurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkDisplaySurfaceCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkSurfaceKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDisplayPlaneSurfaceKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateSharedSwapchainsKHR(VkDevice a_0, uint32_t a_1, const VkSwapchainCreateInfoKHR * a_2, const VkAllocationCallbacks * a_3, VkSwapchainKHR * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkSwapchainCreateInfoKHR * a_2;
    const VkAllocationCallbacks * a_3;
    VkSwapchainKHR * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCreateSharedSwapchainsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceVideoCapabilitiesKHR(VkPhysicalDevice a_0, const VkVideoProfileInfoKHR * a_1, VkVideoCapabilitiesKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkVideoProfileInfoKHR * a_1;
    VkVideoCapabilitiesKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceVideoCapabilitiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceVideoFormatPropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceVideoFormatInfoKHR * a_1, uint32_t * a_2, VkVideoFormatPropertiesKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceVideoFormatInfoKHR * a_1;
    uint32_t * a_2;
    VkVideoFormatPropertiesKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceVideoFormatPropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateVideoSessionKHR(VkDevice a_0, const VkVideoSessionCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkVideoSessionKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkVideoSessionCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkVideoSessionKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateVideoSessionKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyVideoSessionKHR(VkDevice a_0, VkVideoSessionKHR a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkVideoSessionKHR a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyVideoSessionKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetVideoSessionMemoryRequirementsKHR(VkDevice a_0, VkVideoSessionKHR a_1, uint32_t * a_2, VkVideoSessionMemoryRequirementsKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkVideoSessionKHR a_1;
    uint32_t * a_2;
    VkVideoSessionMemoryRequirementsKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetVideoSessionMemoryRequirementsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindVideoSessionMemoryKHR(VkDevice a_0, VkVideoSessionKHR a_1, uint32_t a_2, const VkBindVideoSessionMemoryInfoKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkVideoSessionKHR a_1;
    uint32_t a_2;
    const VkBindVideoSessionMemoryInfoKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkBindVideoSessionMemoryKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateVideoSessionParametersKHR(VkDevice a_0, const VkVideoSessionParametersCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkVideoSessionParametersKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkVideoSessionParametersCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkVideoSessionParametersKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateVideoSessionParametersKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUpdateVideoSessionParametersKHR(VkDevice a_0, VkVideoSessionParametersKHR a_1, const VkVideoSessionParametersUpdateInfoKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkVideoSessionParametersKHR a_1;
    const VkVideoSessionParametersUpdateInfoKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkUpdateVideoSessionParametersKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyVideoSessionParametersKHR(VkDevice a_0, VkVideoSessionParametersKHR a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkVideoSessionParametersKHR a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyVideoSessionParametersKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginVideoCodingKHR(VkCommandBuffer a_0, const VkVideoBeginCodingInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkVideoBeginCodingInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBeginVideoCodingKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndVideoCodingKHR(VkCommandBuffer a_0, const VkVideoEndCodingInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkVideoEndCodingInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdEndVideoCodingKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdControlVideoCodingKHR(VkCommandBuffer a_0, const VkVideoCodingControlInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkVideoCodingControlInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdControlVideoCodingKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDecodeVideoKHR(VkCommandBuffer a_0, const VkVideoDecodeInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkVideoDecodeInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdDecodeVideoKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginRenderingKHR(VkCommandBuffer a_0, const VkRenderingInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBeginRenderingKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndRenderingKHR(VkCommandBuffer a_0) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkCmdEndRenderingKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceFeatures2KHR(VkPhysicalDevice a_0, VkPhysicalDeviceFeatures2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceFeatures2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceFeatures2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceProperties2KHR(VkPhysicalDevice a_0, VkPhysicalDeviceProperties2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceProperties2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceProperties2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceFormatProperties2KHR(VkPhysicalDevice a_0, VkFormat a_1, VkFormatProperties2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkFormat a_1;
    VkFormatProperties2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceFormatProperties2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceImageFormatProperties2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceImageFormatInfo2 * a_1, VkImageFormatProperties2 * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceImageFormatInfo2 * a_1;
    VkImageFormatProperties2 * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceImageFormatProperties2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceQueueFamilyProperties2KHR(VkPhysicalDevice a_0, uint32_t * a_1, VkQueueFamilyProperties2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkQueueFamilyProperties2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceQueueFamilyProperties2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceMemoryProperties2KHR(VkPhysicalDevice a_0, VkPhysicalDeviceMemoryProperties2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkPhysicalDeviceMemoryProperties2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPhysicalDeviceMemoryProperties2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSparseImageFormatProperties2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceSparseImageFormatInfo2 * a_1, uint32_t * a_2, VkSparseImageFormatProperties2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceSparseImageFormatInfo2 * a_1;
    uint32_t * a_2;
    VkSparseImageFormatProperties2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceSparseImageFormatProperties2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceGroupPeerMemoryFeaturesKHR(VkDevice a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, VkPeerMemoryFeatureFlags * a_4) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
    VkPeerMemoryFeatureFlags * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetDeviceGroupPeerMemoryFeaturesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDeviceMaskKHR(VkCommandBuffer a_0, uint32_t a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDeviceMaskKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDispatchBaseKHR(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
    uint32_t a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDispatchBaseKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkTrimCommandPoolKHR(VkDevice a_0, VkCommandPool a_1, VkCommandPoolTrimFlags a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkCommandPool a_1;
    VkCommandPoolTrimFlags a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkTrimCommandPoolKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumeratePhysicalDeviceGroupsKHR(VkInstance a_0, uint32_t * a_1, VkPhysicalDeviceGroupProperties * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    uint32_t * a_1;
    VkPhysicalDeviceGroupProperties * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkEnumeratePhysicalDeviceGroupsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalBufferPropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalBufferInfo * a_1, VkExternalBufferProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceExternalBufferInfo * a_1;
    VkExternalBufferProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalBufferPropertiesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetMemoryFdKHR(VkDevice a_0, const VkMemoryGetFdInfoKHR * a_1, int * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMemoryGetFdInfoKHR * a_1;
    int * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetMemoryFdKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetMemoryFdPropertiesKHR(VkDevice a_0, VkExternalMemoryHandleTypeFlagBits a_1, int a_2, VkMemoryFdPropertiesKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkExternalMemoryHandleTypeFlagBits a_1;
    int a_2;
    VkMemoryFdPropertiesKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetMemoryFdPropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalSemaphorePropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalSemaphoreInfo * a_1, VkExternalSemaphoreProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceExternalSemaphoreInfo * a_1;
    VkExternalSemaphoreProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalSemaphorePropertiesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkImportSemaphoreFdKHR(VkDevice a_0, const VkImportSemaphoreFdInfoKHR * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImportSemaphoreFdInfoKHR * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkImportSemaphoreFdKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSemaphoreFdKHR(VkDevice a_0, const VkSemaphoreGetFdInfoKHR * a_1, int * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSemaphoreGetFdInfoKHR * a_1;
    int * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetSemaphoreFdKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSetKHR(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const VkWriteDescriptorSet * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipelineLayout a_2;
    uint32_t a_3;
    uint32_t a_4;
    const VkWriteDescriptorSet * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdPushDescriptorSetKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSetWithTemplateKHR(VkCommandBuffer a_0, VkDescriptorUpdateTemplate a_1, VkPipelineLayout a_2, uint32_t a_3, const void * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDescriptorUpdateTemplate a_1;
    VkPipelineLayout a_2;
    uint32_t a_3;
    const void * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdPushDescriptorSetWithTemplateKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDescriptorUpdateTemplateKHR(VkDevice a_0, const VkDescriptorUpdateTemplateCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorUpdateTemplate * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorUpdateTemplateCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkDescriptorUpdateTemplate * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDescriptorUpdateTemplateKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDescriptorUpdateTemplateKHR(VkDevice a_0, VkDescriptorUpdateTemplate a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorUpdateTemplate a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDescriptorUpdateTemplateKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUpdateDescriptorSetWithTemplateKHR(VkDevice a_0, VkDescriptorSet a_1, VkDescriptorUpdateTemplate a_2, const void * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorSet a_1;
    VkDescriptorUpdateTemplate a_2;
    const void * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkUpdateDescriptorSetWithTemplateKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateRenderPass2KHR(VkDevice a_0, const VkRenderPassCreateInfo2 * a_1, const VkAllocationCallbacks * a_2, VkRenderPass * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkRenderPassCreateInfo2 * a_1;
    const VkAllocationCallbacks * a_2;
    VkRenderPass * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateRenderPass2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginRenderPass2KHR(VkCommandBuffer a_0, const VkRenderPassBeginInfo * a_1, const VkSubpassBeginInfo * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderPassBeginInfo * a_1;
    const VkSubpassBeginInfo * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBeginRenderPass2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdNextSubpass2KHR(VkCommandBuffer a_0, const VkSubpassBeginInfo * a_1, const VkSubpassEndInfo * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkSubpassBeginInfo * a_1;
    const VkSubpassEndInfo * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdNextSubpass2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndRenderPass2KHR(VkCommandBuffer a_0, const VkSubpassEndInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkSubpassEndInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdEndRenderPass2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSwapchainStatusKHR(VkDevice a_0, VkSwapchainKHR a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetSwapchainStatusKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalFencePropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalFenceInfo * a_1, VkExternalFenceProperties * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceExternalFenceInfo * a_1;
    VkExternalFenceProperties * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalFencePropertiesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkImportFenceFdKHR(VkDevice a_0, const VkImportFenceFdInfoKHR * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImportFenceFdInfoKHR * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkImportFenceFdKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetFenceFdKHR(VkDevice a_0, const VkFenceGetFdInfoKHR * a_1, int * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkFenceGetFdInfoKHR * a_1;
    int * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetFenceFdKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkPerformanceCounterKHR * a_3, VkPerformanceCounterDescriptionKHR * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    uint32_t * a_2;
    VkPerformanceCounterKHR * a_3;
    VkPerformanceCounterDescriptionKHR * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR(VkPhysicalDevice a_0, const VkQueryPoolPerformanceCreateInfoKHR * a_1, uint32_t * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkQueryPoolPerformanceCreateInfoKHR * a_1;
    uint32_t * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAcquireProfilingLockKHR(VkDevice a_0, const VkAcquireProfilingLockInfoKHR * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAcquireProfilingLockInfoKHR * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkAcquireProfilingLockKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkReleaseProfilingLockKHR(VkDevice a_0) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkReleaseProfilingLockKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSurfaceCapabilities2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceSurfaceInfo2KHR * a_1, VkSurfaceCapabilities2KHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceSurfaceInfo2KHR * a_1;
    VkSurfaceCapabilities2KHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceSurfaceCapabilities2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSurfaceFormats2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceSurfaceInfo2KHR * a_1, uint32_t * a_2, VkSurfaceFormat2KHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceSurfaceInfo2KHR * a_1;
    uint32_t * a_2;
    VkSurfaceFormat2KHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceSurfaceFormats2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceDisplayProperties2KHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayProperties2KHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkDisplayProperties2KHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceDisplayProperties2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceDisplayPlaneProperties2KHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayPlaneProperties2KHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkDisplayPlaneProperties2KHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceDisplayPlaneProperties2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDisplayModeProperties2KHR(VkPhysicalDevice a_0, VkDisplayKHR a_1, uint32_t * a_2, VkDisplayModeProperties2KHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkDisplayKHR a_1;
    uint32_t * a_2;
    VkDisplayModeProperties2KHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDisplayModeProperties2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDisplayPlaneCapabilities2KHR(VkPhysicalDevice a_0, const VkDisplayPlaneInfo2KHR * a_1, VkDisplayPlaneCapabilities2KHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkDisplayPlaneInfo2KHR * a_1;
    VkDisplayPlaneCapabilities2KHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDisplayPlaneCapabilities2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageMemoryRequirements2KHR(VkDevice a_0, const VkImageMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageMemoryRequirementsInfo2 * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetImageMemoryRequirements2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferMemoryRequirements2KHR(VkDevice a_0, const VkBufferMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferMemoryRequirementsInfo2 * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetBufferMemoryRequirements2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageSparseMemoryRequirements2KHR(VkDevice a_0, const VkImageSparseMemoryRequirementsInfo2 * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageSparseMemoryRequirementsInfo2 * a_1;
    uint32_t * a_2;
    VkSparseImageMemoryRequirements2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetImageSparseMemoryRequirements2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateSamplerYcbcrConversionKHR(VkDevice a_0, const VkSamplerYcbcrConversionCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSamplerYcbcrConversion * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSamplerYcbcrConversionCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkSamplerYcbcrConversion * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateSamplerYcbcrConversionKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroySamplerYcbcrConversionKHR(VkDevice a_0, VkSamplerYcbcrConversion a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSamplerYcbcrConversion a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroySamplerYcbcrConversionKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindBufferMemory2KHR(VkDevice a_0, uint32_t a_1, const VkBindBufferMemoryInfo * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkBindBufferMemoryInfo * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkBindBufferMemory2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindImageMemory2KHR(VkDevice a_0, uint32_t a_1, const VkBindImageMemoryInfo * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkBindImageMemoryInfo * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkBindImageMemory2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDescriptorSetLayoutSupportKHR(VkDevice a_0, const VkDescriptorSetLayoutCreateInfo * a_1, VkDescriptorSetLayoutSupport * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorSetLayoutCreateInfo * a_1;
    VkDescriptorSetLayoutSupport * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDescriptorSetLayoutSupportKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndirectCountKHR(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawIndirectCountKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndexedIndirectCountKHR(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawIndexedIndirectCountKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSemaphoreCounterValueKHR(VkDevice a_0, VkSemaphore a_1, uint64_t * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSemaphore a_1;
    uint64_t * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetSemaphoreCounterValueKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkWaitSemaphoresKHR(VkDevice a_0, const VkSemaphoreWaitInfo * a_1, uint64_t a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSemaphoreWaitInfo * a_1;
    uint64_t a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkWaitSemaphoresKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSignalSemaphoreKHR(VkDevice a_0, const VkSemaphoreSignalInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSemaphoreSignalInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkSignalSemaphoreKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceFragmentShadingRatesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkPhysicalDeviceFragmentShadingRateKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkPhysicalDeviceFragmentShadingRateKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceFragmentShadingRatesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetFragmentShadingRateKHR(VkCommandBuffer a_0, const VkExtent2D * a_1, const VkFragmentShadingRateCombinerOpKHR * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkExtent2D * a_1;
    const VkFragmentShadingRateCombinerOpKHR * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetFragmentShadingRateKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRenderingAttachmentLocationsKHR(VkCommandBuffer a_0, const VkRenderingAttachmentLocationInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingAttachmentLocationInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRenderingAttachmentLocationsKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRenderingInputAttachmentIndicesKHR(VkCommandBuffer a_0, const VkRenderingInputAttachmentIndexInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingInputAttachmentIndexInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRenderingInputAttachmentIndicesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkWaitForPresentKHR(VkDevice a_0, VkSwapchainKHR a_1, uint64_t a_2, uint64_t a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    uint64_t a_2;
    uint64_t a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkWaitForPresentKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferDeviceAddressKHR(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> VkDeviceAddress {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferDeviceAddressInfo * a_1;
    VkDeviceAddress rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetBufferDeviceAddressKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferOpaqueCaptureAddressKHR(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> uint64_t {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferDeviceAddressInfo * a_1;
    uint64_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetBufferOpaqueCaptureAddressKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceMemoryOpaqueCaptureAddressKHR(VkDevice a_0, const VkDeviceMemoryOpaqueCaptureAddressInfo * a_1) -> uint64_t {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceMemoryOpaqueCaptureAddressInfo * a_1;
    uint64_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetDeviceMemoryOpaqueCaptureAddressKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDeferredOperationKHR(VkDevice a_0, const VkAllocationCallbacks * a_1, VkDeferredOperationKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAllocationCallbacks * a_1;
    VkDeferredOperationKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCreateDeferredOperationKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDeferredOperationKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDeferredOperationKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeferredOperationMaxConcurrencyKHR(VkDevice a_0, VkDeferredOperationKHR a_1) -> uint32_t {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    uint32_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetDeferredOperationMaxConcurrencyKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeferredOperationResultKHR(VkDevice a_0, VkDeferredOperationKHR a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetDeferredOperationResultKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDeferredOperationJoinKHR(VkDevice a_0, VkDeferredOperationKHR a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkDeferredOperationJoinKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineExecutablePropertiesKHR(VkDevice a_0, const VkPipelineInfoKHR * a_1, uint32_t * a_2, VkPipelineExecutablePropertiesKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineInfoKHR * a_1;
    uint32_t * a_2;
    VkPipelineExecutablePropertiesKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPipelineExecutablePropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineExecutableStatisticsKHR(VkDevice a_0, const VkPipelineExecutableInfoKHR * a_1, uint32_t * a_2, VkPipelineExecutableStatisticKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineExecutableInfoKHR * a_1;
    uint32_t * a_2;
    VkPipelineExecutableStatisticKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPipelineExecutableStatisticsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineExecutableInternalRepresentationsKHR(VkDevice a_0, const VkPipelineExecutableInfoKHR * a_1, uint32_t * a_2, VkPipelineExecutableInternalRepresentationKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineExecutableInfoKHR * a_1;
    uint32_t * a_2;
    VkPipelineExecutableInternalRepresentationKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPipelineExecutableInternalRepresentationsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkMapMemory2KHR(VkDevice a_0, const VkMemoryMapInfo * a_1, void ** a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMemoryMapInfo * a_1;
    void ** a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkMapMemory2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUnmapMemory2KHR(VkDevice a_0, const VkMemoryUnmapInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMemoryUnmapInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkUnmapMemory2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceVideoEncodeQualityLevelPropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceVideoEncodeQualityLevelInfoKHR * a_1, VkVideoEncodeQualityLevelPropertiesKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceVideoEncodeQualityLevelInfoKHR * a_1;
    VkVideoEncodeQualityLevelPropertiesKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceVideoEncodeQualityLevelPropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetEncodedVideoSessionParametersKHR(VkDevice a_0, const VkVideoEncodeSessionParametersGetInfoKHR * a_1, VkVideoEncodeSessionParametersFeedbackInfoKHR * a_2, size_t * a_3, void * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkVideoEncodeSessionParametersGetInfoKHR * a_1;
    VkVideoEncodeSessionParametersFeedbackInfoKHR * a_2;
    size_t * a_3;
    void * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetEncodedVideoSessionParametersKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEncodeVideoKHR(VkCommandBuffer a_0, const VkVideoEncodeInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkVideoEncodeInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdEncodeVideoKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetEvent2KHR(VkCommandBuffer a_0, VkEvent a_1, const VkDependencyInfo * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkEvent a_1;
    const VkDependencyInfo * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetEvent2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdResetEvent2KHR(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags2 a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkEvent a_1;
    VkPipelineStageFlags2 a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdResetEvent2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWaitEvents2KHR(VkCommandBuffer a_0, uint32_t a_1, const VkEvent * a_2, const VkDependencyInfo * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkEvent * a_2;
    const VkDependencyInfo * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdWaitEvents2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPipelineBarrier2KHR(VkCommandBuffer a_0, const VkDependencyInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDependencyInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPipelineBarrier2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteTimestamp2KHR(VkCommandBuffer a_0, VkPipelineStageFlags2 a_1, VkQueryPool a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineStageFlags2 a_1;
    VkQueryPool a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdWriteTimestamp2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueSubmit2KHR(VkQueue a_0, uint32_t a_1, const VkSubmitInfo2 * a_2, VkFence a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkQueue a_0;
    uint32_t a_1;
    const VkSubmitInfo2 * a_2;
    VkFence a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkQueueSubmit2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyBuffer2KHR(VkCommandBuffer a_0, const VkCopyBufferInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyBufferInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyBuffer2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyImage2KHR(VkCommandBuffer a_0, const VkCopyImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyImage2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyBufferToImage2KHR(VkCommandBuffer a_0, const VkCopyBufferToImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyBufferToImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyBufferToImage2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyImageToBuffer2KHR(VkCommandBuffer a_0, const VkCopyImageToBufferInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyImageToBufferInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyImageToBuffer2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBlitImage2KHR(VkCommandBuffer a_0, const VkBlitImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkBlitImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBlitImage2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdResolveImage2KHR(VkCommandBuffer a_0, const VkResolveImageInfo2 * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkResolveImageInfo2 * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdResolveImage2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdTraceRaysIndirect2KHR(VkCommandBuffer a_0, VkDeviceAddress a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDeviceAddress a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdTraceRaysIndirect2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceBufferMemoryRequirementsKHR(VkDevice a_0, const VkDeviceBufferMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceBufferMemoryRequirements * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceBufferMemoryRequirementsKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceImageMemoryRequirementsKHR(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceImageMemoryRequirements * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceImageMemoryRequirementsKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceImageSparseMemoryRequirementsKHR(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceImageMemoryRequirements * a_1;
    uint32_t * a_2;
    VkSparseImageMemoryRequirements2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDeviceImageSparseMemoryRequirementsKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindIndexBuffer2KHR(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, VkIndexType a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkDeviceSize a_3;
    VkIndexType a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdBindIndexBuffer2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRenderingAreaGranularityKHR(VkDevice a_0, const VkRenderingAreaInfo * a_1, VkExtent2D * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkRenderingAreaInfo * a_1;
    VkExtent2D * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetRenderingAreaGranularityKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceImageSubresourceLayoutKHR(VkDevice a_0, const VkDeviceImageSubresourceInfo * a_1, VkSubresourceLayout2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceImageSubresourceInfo * a_1;
    VkSubresourceLayout2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceImageSubresourceLayoutKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageSubresourceLayout2KHR(VkDevice a_0, VkImage a_1, const VkImageSubresource2 * a_2, VkSubresourceLayout2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    const VkImageSubresource2 * a_2;
    VkSubresourceLayout2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetImageSubresourceLayout2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkWaitForPresent2KHR(VkDevice a_0, VkSwapchainKHR a_1, const VkPresentWait2InfoKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    const VkPresentWait2InfoKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkWaitForPresent2KHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreatePipelineBinariesKHR(VkDevice a_0, const VkPipelineBinaryCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkPipelineBinaryHandlesInfoKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineBinaryCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkPipelineBinaryHandlesInfoKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreatePipelineBinariesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyPipelineBinaryKHR(VkDevice a_0, VkPipelineBinaryKHR a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineBinaryKHR a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyPipelineBinaryKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineKeyKHR(VkDevice a_0, const VkPipelineCreateInfoKHR * a_1, VkPipelineBinaryKeyKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineCreateInfoKHR * a_1;
    VkPipelineBinaryKeyKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPipelineKeyKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineBinaryDataKHR(VkDevice a_0, const VkPipelineBinaryDataInfoKHR * a_1, VkPipelineBinaryKeyKHR * a_2, size_t * a_3, void * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineBinaryDataInfoKHR * a_1;
    VkPipelineBinaryKeyKHR * a_2;
    size_t * a_3;
    void * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetPipelineBinaryDataKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkReleaseCapturedPipelineDataKHR(VkDevice a_0, const VkReleaseCapturedPipelineDataInfoKHR * a_1, const VkAllocationCallbacks * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkReleaseCapturedPipelineDataInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkReleaseCapturedPipelineDataKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkReleaseSwapchainImagesKHR(VkDevice a_0, const VkReleaseSwapchainImagesInfoKHR * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkReleaseSwapchainImagesInfoKHR * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkReleaseSwapchainImagesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceCooperativeMatrixPropertiesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeMatrixPropertiesKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkCooperativeMatrixPropertiesKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceCooperativeMatrixPropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLineStippleKHR(VkCommandBuffer a_0, uint32_t a_1, uint16_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint16_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetLineStippleKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceCalibrateableTimeDomainsKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkTimeDomainKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkTimeDomainKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceCalibrateableTimeDomainsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetCalibratedTimestampsKHR(VkDevice a_0, uint32_t a_1, const VkCalibratedTimestampInfoKHR * a_2, uint64_t * a_3, uint64_t * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkCalibratedTimestampInfoKHR * a_2;
    uint64_t * a_3;
    uint64_t * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetCalibratedTimestampsKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindDescriptorSets2KHR(VkCommandBuffer a_0, const VkBindDescriptorSetsInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkBindDescriptorSetsInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBindDescriptorSets2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushConstants2KHR(VkCommandBuffer a_0, const VkPushConstantsInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPushConstantsInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPushConstants2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSet2KHR(VkCommandBuffer a_0, const VkPushDescriptorSetInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPushDescriptorSetInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPushDescriptorSet2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPushDescriptorSetWithTemplate2KHR(VkCommandBuffer a_0, const VkPushDescriptorSetWithTemplateInfo * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPushDescriptorSetWithTemplateInfo * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPushDescriptorSetWithTemplate2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDescriptorBufferOffsets2EXT(VkCommandBuffer a_0, const VkSetDescriptorBufferOffsetsInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkSetDescriptorBufferOffsetsInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDescriptorBufferOffsets2EXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindDescriptorBufferEmbeddedSamplers2EXT(VkCommandBuffer a_0, const VkBindDescriptorBufferEmbeddedSamplersInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkBindDescriptorBufferEmbeddedSamplersInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBindDescriptorBufferEmbeddedSamplers2EXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMemoryIndirectKHR(VkCommandBuffer a_0, const VkCopyMemoryIndirectInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyMemoryIndirectInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyMemoryIndirectKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMemoryToImageIndirectKHR(VkCommandBuffer a_0, const VkCopyMemoryToImageIndirectInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyMemoryToImageIndirectInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyMemoryToImageIndirectKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndRendering2KHR(VkCommandBuffer a_0, const VkRenderingEndInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingEndInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdEndRendering2KHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDebugReportCallbackEXT(VkInstance a_0, const VkDebugReportCallbackCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkDebugReportCallbackEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkDebugReportCallbackCreateInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkDebugReportCallbackEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDebugReportCallbackEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDebugReportCallbackEXT(VkInstance a_0, VkDebugReportCallbackEXT a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkInstance a_0;
    VkDebugReportCallbackEXT a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDebugReportCallbackEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDebugReportMessageEXT(VkInstance a_0, VkDebugReportFlagsEXT a_1, VkDebugReportObjectTypeEXT a_2, uint64_t a_3, size_t a_4, int32_t a_5, const char * a_6, const char * a_7) -> void {
  struct __attribute__((packed)) {
    VkInstance a_0;
    VkDebugReportFlagsEXT a_1;
    VkDebugReportObjectTypeEXT a_2;
    uint64_t a_3;
    size_t a_4;
    int32_t a_5;
    const char * a_6;
    const char * a_7;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkDebugReportMessageEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDebugMarkerSetObjectTagEXT(VkDevice a_0, const VkDebugMarkerObjectTagInfoEXT * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDebugMarkerObjectTagInfoEXT * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkDebugMarkerSetObjectTagEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDebugMarkerSetObjectNameEXT(VkDevice a_0, const VkDebugMarkerObjectNameInfoEXT * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDebugMarkerObjectNameInfoEXT * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkDebugMarkerSetObjectNameEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDebugMarkerBeginEXT(VkCommandBuffer a_0, const VkDebugMarkerMarkerInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDebugMarkerMarkerInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdDebugMarkerBeginEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDebugMarkerEndEXT(VkCommandBuffer a_0) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkCmdDebugMarkerEndEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDebugMarkerInsertEXT(VkCommandBuffer a_0, const VkDebugMarkerMarkerInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDebugMarkerMarkerInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdDebugMarkerInsertEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindTransformFeedbackBuffersEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4, const VkDeviceSize * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBuffer * a_3;
    const VkDeviceSize * a_4;
    const VkDeviceSize * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdBindTransformFeedbackBuffersEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginTransformFeedbackEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBuffer * a_3;
    const VkDeviceSize * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdBeginTransformFeedbackEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndTransformFeedbackEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBuffer * a_3;
    const VkDeviceSize * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdEndTransformFeedbackEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginQueryIndexedEXT(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, VkQueryControlFlags a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    VkQueryControlFlags a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdBeginQueryIndexedEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndQueryIndexedEXT(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdEndQueryIndexedEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndirectByteCountEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawIndirectByteCountEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateCuModuleNVX(VkDevice a_0, const VkCuModuleCreateInfoNVX * a_1, const VkAllocationCallbacks * a_2, VkCuModuleNVX * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCuModuleCreateInfoNVX * a_1;
    const VkAllocationCallbacks * a_2;
    VkCuModuleNVX * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateCuModuleNVX(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateCuFunctionNVX(VkDevice a_0, const VkCuFunctionCreateInfoNVX * a_1, const VkAllocationCallbacks * a_2, VkCuFunctionNVX * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCuFunctionCreateInfoNVX * a_1;
    const VkAllocationCallbacks * a_2;
    VkCuFunctionNVX * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateCuFunctionNVX(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyCuModuleNVX(VkDevice a_0, VkCuModuleNVX a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkCuModuleNVX a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyCuModuleNVX(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyCuFunctionNVX(VkDevice a_0, VkCuFunctionNVX a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkCuFunctionNVX a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyCuFunctionNVX(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCuLaunchKernelNVX(VkCommandBuffer a_0, const VkCuLaunchInfoNVX * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCuLaunchInfoNVX * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCuLaunchKernelNVX(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageViewHandleNVX(VkDevice a_0, const VkImageViewHandleInfoNVX * a_1) -> uint32_t {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageViewHandleInfoNVX * a_1;
    uint32_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetImageViewHandleNVX(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageViewHandle64NVX(VkDevice a_0, const VkImageViewHandleInfoNVX * a_1) -> uint64_t {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageViewHandleInfoNVX * a_1;
    uint64_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetImageViewHandle64NVX(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageViewAddressNVX(VkDevice a_0, VkImageView a_1, VkImageViewAddressPropertiesNVX * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImageView a_1;
    VkImageViewAddressPropertiesNVX * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetImageViewAddressNVX(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndirectCountAMD(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawIndirectCountAMD(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawIndexedIndirectCountAMD(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawIndexedIndirectCountAMD(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetShaderInfoAMD(VkDevice a_0, VkPipeline a_1, VkShaderStageFlagBits a_2, VkShaderInfoTypeAMD a_3, size_t * a_4, void * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipeline a_1;
    VkShaderStageFlagBits a_2;
    VkShaderInfoTypeAMD a_3;
    size_t * a_4;
    void * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkGetShaderInfoAMD(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalImageFormatPropertiesNV(VkPhysicalDevice a_0, VkFormat a_1, VkImageType a_2, VkImageTiling a_3, VkImageUsageFlags a_4, VkImageCreateFlags a_5, VkExternalMemoryHandleTypeFlagsNV a_6, VkExternalImageFormatPropertiesNV * a_7) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkFormat a_1;
    VkImageType a_2;
    VkImageTiling a_3;
    VkImageUsageFlags a_4;
    VkImageCreateFlags a_5;
    VkExternalMemoryHandleTypeFlagsNV a_6;
    VkExternalImageFormatPropertiesNV * a_7;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalImageFormatPropertiesNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginConditionalRenderingEXT(VkCommandBuffer a_0, const VkConditionalRenderingBeginInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkConditionalRenderingBeginInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBeginConditionalRenderingEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndConditionalRenderingEXT(VkCommandBuffer a_0) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkCmdEndConditionalRenderingEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetViewportWScalingNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkViewportWScalingNV * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkViewportWScalingNV * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetViewportWScalingNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkReleaseDisplayEXT(VkPhysicalDevice a_0, VkDisplayKHR a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkDisplayKHR a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkReleaseDisplayEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSurfaceCapabilities2EXT(VkPhysicalDevice a_0, VkSurfaceKHR a_1, VkSurfaceCapabilities2EXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkSurfaceKHR a_1;
    VkSurfaceCapabilities2EXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceSurfaceCapabilities2EXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDisplayPowerControlEXT(VkDevice a_0, VkDisplayKHR a_1, const VkDisplayPowerInfoEXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDisplayKHR a_1;
    const VkDisplayPowerInfoEXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDisplayPowerControlEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkRegisterDeviceEventEXT(VkDevice a_0, const VkDeviceEventInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkFence * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceEventInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkFence * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkRegisterDeviceEventEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkRegisterDisplayEventEXT(VkDevice a_0, VkDisplayKHR a_1, const VkDisplayEventInfoEXT * a_2, const VkAllocationCallbacks * a_3, VkFence * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDisplayKHR a_1;
    const VkDisplayEventInfoEXT * a_2;
    const VkAllocationCallbacks * a_3;
    VkFence * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkRegisterDisplayEventEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSwapchainCounterEXT(VkDevice a_0, VkSwapchainKHR a_1, VkSurfaceCounterFlagBitsEXT a_2, uint64_t * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    VkSurfaceCounterFlagBitsEXT a_2;
    uint64_t * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetSwapchainCounterEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRefreshCycleDurationGOOGLE(VkDevice a_0, VkSwapchainKHR a_1, VkRefreshCycleDurationGOOGLE * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    VkRefreshCycleDurationGOOGLE * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetRefreshCycleDurationGOOGLE(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPastPresentationTimingGOOGLE(VkDevice a_0, VkSwapchainKHR a_1, uint32_t * a_2, VkPastPresentationTimingGOOGLE * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    uint32_t * a_2;
    VkPastPresentationTimingGOOGLE * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPastPresentationTimingGOOGLE(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDiscardRectangleEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkRect2D * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkRect2D * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetDiscardRectangleEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDiscardRectangleEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDiscardRectangleEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDiscardRectangleModeEXT(VkCommandBuffer a_0, VkDiscardRectangleModeEXT a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDiscardRectangleModeEXT a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDiscardRectangleModeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetHdrMetadataEXT(VkDevice a_0, uint32_t a_1, const VkSwapchainKHR * a_2, const VkHdrMetadataEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkSwapchainKHR * a_2;
    const VkHdrMetadataEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkSetHdrMetadataEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetDebugUtilsObjectNameEXT(VkDevice a_0, const VkDebugUtilsObjectNameInfoEXT * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDebugUtilsObjectNameInfoEXT * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkSetDebugUtilsObjectNameEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetDebugUtilsObjectTagEXT(VkDevice a_0, const VkDebugUtilsObjectTagInfoEXT * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDebugUtilsObjectTagInfoEXT * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkSetDebugUtilsObjectTagEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueBeginDebugUtilsLabelEXT(VkQueue a_0, const VkDebugUtilsLabelEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkQueue a_0;
    const VkDebugUtilsLabelEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkQueueBeginDebugUtilsLabelEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueEndDebugUtilsLabelEXT(VkQueue a_0) -> void {
  struct __attribute__((packed)) {
    VkQueue a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkQueueEndDebugUtilsLabelEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueInsertDebugUtilsLabelEXT(VkQueue a_0, const VkDebugUtilsLabelEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkQueue a_0;
    const VkDebugUtilsLabelEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkQueueInsertDebugUtilsLabelEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginDebugUtilsLabelEXT(VkCommandBuffer a_0, const VkDebugUtilsLabelEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDebugUtilsLabelEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBeginDebugUtilsLabelEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndDebugUtilsLabelEXT(VkCommandBuffer a_0) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkCmdEndDebugUtilsLabelEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdInsertDebugUtilsLabelEXT(VkCommandBuffer a_0, const VkDebugUtilsLabelEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDebugUtilsLabelEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdInsertDebugUtilsLabelEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDebugUtilsMessengerEXT(VkInstance a_0, const VkDebugUtilsMessengerCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkDebugUtilsMessengerEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkDebugUtilsMessengerCreateInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkDebugUtilsMessengerEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDebugUtilsMessengerEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDebugUtilsMessengerEXT(VkInstance a_0, VkDebugUtilsMessengerEXT a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkInstance a_0;
    VkDebugUtilsMessengerEXT a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDebugUtilsMessengerEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSubmitDebugUtilsMessageEXT(VkInstance a_0, VkDebugUtilsMessageSeverityFlagBitsEXT a_1, VkDebugUtilsMessageTypeFlagsEXT a_2, const VkDebugUtilsMessengerCallbackDataEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkInstance a_0;
    VkDebugUtilsMessageSeverityFlagBitsEXT a_1;
    VkDebugUtilsMessageTypeFlagsEXT a_2;
    const VkDebugUtilsMessengerCallbackDataEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkSubmitDebugUtilsMessageEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetSampleLocationsEXT(VkCommandBuffer a_0, const VkSampleLocationsInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkSampleLocationsInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetSampleLocationsEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceMultisamplePropertiesEXT(VkPhysicalDevice a_0, VkSampleCountFlagBits a_1, VkMultisamplePropertiesEXT * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    VkSampleCountFlagBits a_1;
    VkMultisamplePropertiesEXT * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceMultisamplePropertiesEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageDrmFormatModifierPropertiesEXT(VkDevice a_0, VkImage a_1, VkImageDrmFormatModifierPropertiesEXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    VkImageDrmFormatModifierPropertiesEXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetImageDrmFormatModifierPropertiesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateValidationCacheEXT(VkDevice a_0, const VkValidationCacheCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkValidationCacheEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkValidationCacheCreateInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkValidationCacheEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateValidationCacheEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyValidationCacheEXT(VkDevice a_0, VkValidationCacheEXT a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkValidationCacheEXT a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyValidationCacheEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkMergeValidationCachesEXT(VkDevice a_0, VkValidationCacheEXT a_1, uint32_t a_2, const VkValidationCacheEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkValidationCacheEXT a_1;
    uint32_t a_2;
    const VkValidationCacheEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkMergeValidationCachesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetValidationCacheDataEXT(VkDevice a_0, VkValidationCacheEXT a_1, size_t * a_2, void * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkValidationCacheEXT a_1;
    size_t * a_2;
    void * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetValidationCacheDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindShadingRateImageNV(VkCommandBuffer a_0, VkImageView a_1, VkImageLayout a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImageView a_1;
    VkImageLayout a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBindShadingRateImageNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetViewportShadingRatePaletteNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkShadingRatePaletteNV * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkShadingRatePaletteNV * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetViewportShadingRatePaletteNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCoarseSampleOrderNV(VkCommandBuffer a_0, VkCoarseSampleOrderTypeNV a_1, uint32_t a_2, const VkCoarseSampleOrderCustomNV * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCoarseSampleOrderTypeNV a_1;
    uint32_t a_2;
    const VkCoarseSampleOrderCustomNV * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetCoarseSampleOrderNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateAccelerationStructureNV(VkDevice a_0, const VkAccelerationStructureCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkAccelerationStructureNV * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAccelerationStructureCreateInfoNV * a_1;
    const VkAllocationCallbacks * a_2;
    VkAccelerationStructureNV * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateAccelerationStructureNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyAccelerationStructureNV(VkDevice a_0, VkAccelerationStructureNV a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkAccelerationStructureNV a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyAccelerationStructureNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetAccelerationStructureMemoryRequirementsNV(VkDevice a_0, const VkAccelerationStructureMemoryRequirementsInfoNV * a_1, VkMemoryRequirements2KHR * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAccelerationStructureMemoryRequirementsInfoNV * a_1;
    VkMemoryRequirements2KHR * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetAccelerationStructureMemoryRequirementsNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindAccelerationStructureMemoryNV(VkDevice a_0, uint32_t a_1, const VkBindAccelerationStructureMemoryInfoNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkBindAccelerationStructureMemoryInfoNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkBindAccelerationStructureMemoryNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBuildAccelerationStructureNV(VkCommandBuffer a_0, const VkAccelerationStructureInfoNV * a_1, VkBuffer a_2, VkDeviceSize a_3, VkBool32 a_4, VkAccelerationStructureNV a_5, VkAccelerationStructureNV a_6, VkBuffer a_7, VkDeviceSize a_8) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkAccelerationStructureInfoNV * a_1;
    VkBuffer a_2;
    VkDeviceSize a_3;
    VkBool32 a_4;
    VkAccelerationStructureNV a_5;
    VkAccelerationStructureNV a_6;
    VkBuffer a_7;
    VkDeviceSize a_8;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  args.a_8 = a_8;
  fexthunks_libvulkan_vkCmdBuildAccelerationStructureNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyAccelerationStructureNV(VkCommandBuffer a_0, VkAccelerationStructureNV a_1, VkAccelerationStructureNV a_2, VkCopyAccelerationStructureModeKHR a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkAccelerationStructureNV a_1;
    VkAccelerationStructureNV a_2;
    VkCopyAccelerationStructureModeKHR a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdCopyAccelerationStructureNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdTraceRaysNV(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, VkDeviceSize a_5, VkBuffer a_6, VkDeviceSize a_7, VkDeviceSize a_8, VkBuffer a_9, VkDeviceSize a_10, VkDeviceSize a_11, uint32_t a_12, uint32_t a_13, uint32_t a_14) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    VkDeviceSize a_5;
    VkBuffer a_6;
    VkDeviceSize a_7;
    VkDeviceSize a_8;
    VkBuffer a_9;
    VkDeviceSize a_10;
    VkDeviceSize a_11;
    uint32_t a_12;
    uint32_t a_13;
    uint32_t a_14;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  args.a_8 = a_8;
  args.a_9 = a_9;
  args.a_10 = a_10;
  args.a_11 = a_11;
  args.a_12 = a_12;
  args.a_13 = a_13;
  args.a_14 = a_14;
  fexthunks_libvulkan_vkCmdTraceRaysNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateRayTracingPipelinesNV(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkRayTracingPipelineCreateInfoNV * a_3, const VkAllocationCallbacks * a_4, VkPipeline * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipelineCache a_1;
    uint32_t a_2;
    const VkRayTracingPipelineCreateInfoNV * a_3;
    const VkAllocationCallbacks * a_4;
    VkPipeline * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCreateRayTracingPipelinesNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRayTracingShaderGroupHandlesKHR(VkDevice a_0, VkPipeline a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipeline a_1;
    uint32_t a_2;
    uint32_t a_3;
    size_t a_4;
    void * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkGetRayTracingShaderGroupHandlesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRayTracingShaderGroupHandlesNV(VkDevice a_0, VkPipeline a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipeline a_1;
    uint32_t a_2;
    uint32_t a_3;
    size_t a_4;
    void * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkGetRayTracingShaderGroupHandlesNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetAccelerationStructureHandleNV(VkDevice a_0, VkAccelerationStructureNV a_1, size_t a_2, void * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkAccelerationStructureNV a_1;
    size_t a_2;
    void * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetAccelerationStructureHandleNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteAccelerationStructuresPropertiesNV(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureNV * a_2, VkQueryType a_3, VkQueryPool a_4, uint32_t a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkAccelerationStructureNV * a_2;
    VkQueryType a_3;
    VkQueryPool a_4;
    uint32_t a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdWriteAccelerationStructuresPropertiesNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCompileDeferredNV(VkDevice a_0, VkPipeline a_1, uint32_t a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipeline a_1;
    uint32_t a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCompileDeferredNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetMemoryHostPointerPropertiesEXT(VkDevice a_0, VkExternalMemoryHandleTypeFlagBits a_1, const void * a_2, VkMemoryHostPointerPropertiesEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkExternalMemoryHandleTypeFlagBits a_1;
    const void * a_2;
    VkMemoryHostPointerPropertiesEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetMemoryHostPointerPropertiesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteBufferMarkerAMD(VkCommandBuffer a_0, VkPipelineStageFlagBits a_1, VkBuffer a_2, VkDeviceSize a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineStageFlagBits a_1;
    VkBuffer a_2;
    VkDeviceSize a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdWriteBufferMarkerAMD(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteBufferMarker2AMD(VkCommandBuffer a_0, VkPipelineStageFlags2 a_1, VkBuffer a_2, VkDeviceSize a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineStageFlags2 a_1;
    VkBuffer a_2;
    VkDeviceSize a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdWriteBufferMarker2AMD(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceCalibrateableTimeDomainsEXT(VkPhysicalDevice a_0, uint32_t * a_1, VkTimeDomainKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkTimeDomainKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceCalibrateableTimeDomainsEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetCalibratedTimestampsEXT(VkDevice a_0, uint32_t a_1, const VkCalibratedTimestampInfoKHR * a_2, uint64_t * a_3, uint64_t * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkCalibratedTimestampInfoKHR * a_2;
    uint64_t * a_3;
    uint64_t * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetCalibratedTimestampsEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMeshTasksNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdDrawMeshTasksNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMeshTasksIndirectNV(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    uint32_t a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdDrawMeshTasksIndirectNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMeshTasksIndirectCountNV(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawMeshTasksIndirectCountNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetExclusiveScissorEnableNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBool32 * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBool32 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetExclusiveScissorEnableNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetExclusiveScissorNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkRect2D * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkRect2D * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetExclusiveScissorNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCheckpointNV(VkCommandBuffer a_0, const void * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const void * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCheckpointNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetQueueCheckpointDataNV(VkQueue a_0, uint32_t * a_1, VkCheckpointDataNV * a_2) -> void {
  struct __attribute__((packed)) {
    VkQueue a_0;
    uint32_t * a_1;
    VkCheckpointDataNV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetQueueCheckpointDataNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetQueueCheckpointData2NV(VkQueue a_0, uint32_t * a_1, VkCheckpointData2NV * a_2) -> void {
  struct __attribute__((packed)) {
    VkQueue a_0;
    uint32_t * a_1;
    VkCheckpointData2NV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetQueueCheckpointData2NV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetSwapchainPresentTimingQueueSizeEXT(VkDevice a_0, VkSwapchainKHR a_1, uint32_t a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    uint32_t a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkSetSwapchainPresentTimingQueueSizeEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSwapchainTimingPropertiesEXT(VkDevice a_0, VkSwapchainKHR a_1, VkSwapchainTimingPropertiesEXT * a_2, uint64_t * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    VkSwapchainTimingPropertiesEXT * a_2;
    uint64_t * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetSwapchainTimingPropertiesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSwapchainTimeDomainPropertiesEXT(VkDevice a_0, VkSwapchainKHR a_1, VkSwapchainTimeDomainPropertiesEXT * a_2, uint64_t * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    VkSwapchainTimeDomainPropertiesEXT * a_2;
    uint64_t * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetSwapchainTimeDomainPropertiesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPastPresentationTimingEXT(VkDevice a_0, const VkPastPresentationTimingInfoEXT * a_1, VkPastPresentationTimingPropertiesEXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPastPresentationTimingInfoEXT * a_1;
    VkPastPresentationTimingPropertiesEXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPastPresentationTimingEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkInitializePerformanceApiINTEL(VkDevice a_0, const VkInitializePerformanceApiInfoINTEL * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkInitializePerformanceApiInfoINTEL * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkInitializePerformanceApiINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUninitializePerformanceApiINTEL(VkDevice a_0) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkUninitializePerformanceApiINTEL(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPerformanceMarkerINTEL(VkCommandBuffer a_0, const VkPerformanceMarkerInfoINTEL * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPerformanceMarkerInfoINTEL * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPerformanceMarkerINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPerformanceStreamMarkerINTEL(VkCommandBuffer a_0, const VkPerformanceStreamMarkerInfoINTEL * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPerformanceStreamMarkerInfoINTEL * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPerformanceStreamMarkerINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPerformanceOverrideINTEL(VkCommandBuffer a_0, const VkPerformanceOverrideInfoINTEL * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPerformanceOverrideInfoINTEL * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPerformanceOverrideINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAcquirePerformanceConfigurationINTEL(VkDevice a_0, const VkPerformanceConfigurationAcquireInfoINTEL * a_1, VkPerformanceConfigurationINTEL * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPerformanceConfigurationAcquireInfoINTEL * a_1;
    VkPerformanceConfigurationINTEL * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkAcquirePerformanceConfigurationINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkReleasePerformanceConfigurationINTEL(VkDevice a_0, VkPerformanceConfigurationINTEL a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPerformanceConfigurationINTEL a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkReleasePerformanceConfigurationINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueSetPerformanceConfigurationINTEL(VkQueue a_0, VkPerformanceConfigurationINTEL a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkQueue a_0;
    VkPerformanceConfigurationINTEL a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkQueueSetPerformanceConfigurationINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPerformanceParameterINTEL(VkDevice a_0, VkPerformanceParameterTypeINTEL a_1, VkPerformanceValueINTEL * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPerformanceParameterTypeINTEL a_1;
    VkPerformanceValueINTEL * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPerformanceParameterINTEL(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetLocalDimmingAMD(VkDevice a_0, VkSwapchainKHR a_1, VkBool32 a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    VkBool32 a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkSetLocalDimmingAMD(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferDeviceAddressEXT(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> VkDeviceAddress {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferDeviceAddressInfo * a_1;
    VkDeviceAddress rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetBufferDeviceAddressEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceToolPropertiesEXT(VkPhysicalDevice a_0, uint32_t * a_1, VkPhysicalDeviceToolProperties * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkPhysicalDeviceToolProperties * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceToolPropertiesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceCooperativeMatrixPropertiesNV(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeMatrixPropertiesNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkCooperativeMatrixPropertiesNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceCooperativeMatrixPropertiesNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceSupportedFramebufferMixedSamplesCombinationsNV(VkPhysicalDevice a_0, uint32_t * a_1, VkFramebufferMixedSamplesCombinationNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkFramebufferMixedSamplesCombinationNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceSupportedFramebufferMixedSamplesCombinationsNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateHeadlessSurfaceEXT(VkInstance a_0, const VkHeadlessSurfaceCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkHeadlessSurfaceCreateInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkSurfaceKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateHeadlessSurfaceEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLineStippleEXT(VkCommandBuffer a_0, uint32_t a_1, uint16_t a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint16_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetLineStippleEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkResetQueryPoolEXT(VkDevice a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkQueryPool a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkResetQueryPoolEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCullModeEXT(VkCommandBuffer a_0, VkCullModeFlags a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCullModeFlags a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCullModeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetFrontFaceEXT(VkCommandBuffer a_0, VkFrontFace a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkFrontFace a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetFrontFaceEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPrimitiveTopologyEXT(VkCommandBuffer a_0, VkPrimitiveTopology a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPrimitiveTopology a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPrimitiveTopologyEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetViewportWithCountEXT(VkCommandBuffer a_0, uint32_t a_1, const VkViewport * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkViewport * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetViewportWithCountEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetScissorWithCountEXT(VkCommandBuffer a_0, uint32_t a_1, const VkRect2D * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkRect2D * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetScissorWithCountEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindVertexBuffers2EXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4, const VkDeviceSize * a_5, const VkDeviceSize * a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBuffer * a_3;
    const VkDeviceSize * a_4;
    const VkDeviceSize * a_5;
    const VkDeviceSize * a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdBindVertexBuffers2EXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthTestEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthTestEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthWriteEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthWriteEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthCompareOpEXT(VkCommandBuffer a_0, VkCompareOp a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCompareOp a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthCompareOpEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthBoundsTestEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthBoundsTestEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetStencilTestEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetStencilTestEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetStencilOpEXT(VkCommandBuffer a_0, VkStencilFaceFlags a_1, VkStencilOp a_2, VkStencilOp a_3, VkStencilOp a_4, VkCompareOp a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkStencilFaceFlags a_1;
    VkStencilOp a_2;
    VkStencilOp a_3;
    VkStencilOp a_4;
    VkCompareOp a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdSetStencilOpEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyMemoryToImageEXT(VkDevice a_0, const VkCopyMemoryToImageInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCopyMemoryToImageInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCopyMemoryToImageEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyImageToMemoryEXT(VkDevice a_0, const VkCopyImageToMemoryInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCopyImageToMemoryInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCopyImageToMemoryEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyImageToImageEXT(VkDevice a_0, const VkCopyImageToImageInfo * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkCopyImageToImageInfo * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCopyImageToImageEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkTransitionImageLayoutEXT(VkDevice a_0, uint32_t a_1, const VkHostImageLayoutTransitionInfo * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkHostImageLayoutTransitionInfo * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkTransitionImageLayoutEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageSubresourceLayout2EXT(VkDevice a_0, VkImage a_1, const VkImageSubresource2 * a_2, VkSubresourceLayout2 * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkImage a_1;
    const VkImageSubresource2 * a_2;
    VkSubresourceLayout2 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetImageSubresourceLayout2EXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkReleaseSwapchainImagesEXT(VkDevice a_0, const VkReleaseSwapchainImagesInfoKHR * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkReleaseSwapchainImagesInfoKHR * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkReleaseSwapchainImagesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetGeneratedCommandsMemoryRequirementsNV(VkDevice a_0, const VkGeneratedCommandsMemoryRequirementsInfoNV * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkGeneratedCommandsMemoryRequirementsInfoNV * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetGeneratedCommandsMemoryRequirementsNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPreprocessGeneratedCommandsNV(VkCommandBuffer a_0, const VkGeneratedCommandsInfoNV * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkGeneratedCommandsInfoNV * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdPreprocessGeneratedCommandsNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdExecuteGeneratedCommandsNV(VkCommandBuffer a_0, VkBool32 a_1, const VkGeneratedCommandsInfoNV * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
    const VkGeneratedCommandsInfoNV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdExecuteGeneratedCommandsNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindPipelineShaderGroupNV(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipeline a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipeline a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdBindPipelineShaderGroupNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateIndirectCommandsLayoutNV(VkDevice a_0, const VkIndirectCommandsLayoutCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkIndirectCommandsLayoutNV * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkIndirectCommandsLayoutCreateInfoNV * a_1;
    const VkAllocationCallbacks * a_2;
    VkIndirectCommandsLayoutNV * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateIndirectCommandsLayoutNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyIndirectCommandsLayoutNV(VkDevice a_0, VkIndirectCommandsLayoutNV a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkIndirectCommandsLayoutNV a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyIndirectCommandsLayoutNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthBias2EXT(VkCommandBuffer a_0, const VkDepthBiasInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDepthBiasInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthBias2EXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAcquireDrmDisplayEXT(VkPhysicalDevice a_0, int32_t a_1, VkDisplayKHR a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    int32_t a_1;
    VkDisplayKHR a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkAcquireDrmDisplayEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDrmDisplayEXT(VkPhysicalDevice a_0, int32_t a_1, uint32_t a_2, VkDisplayKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    int32_t a_1;
    uint32_t a_2;
    VkDisplayKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDrmDisplayEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreatePrivateDataSlotEXT(VkDevice a_0, const VkPrivateDataSlotCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPrivateDataSlot * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPrivateDataSlotCreateInfo * a_1;
    const VkAllocationCallbacks * a_2;
    VkPrivateDataSlot * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreatePrivateDataSlotEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyPrivateDataSlotEXT(VkDevice a_0, VkPrivateDataSlot a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPrivateDataSlot a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyPrivateDataSlotEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetPrivateDataEXT(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkObjectType a_1;
    uint64_t a_2;
    VkPrivateDataSlot a_3;
    uint64_t a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkSetPrivateDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPrivateDataEXT(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t * a_4) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkObjectType a_1;
    uint64_t a_2;
    VkPrivateDataSlot a_3;
    uint64_t * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetPrivateDataEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDispatchTileQCOM(VkCommandBuffer a_0, const VkDispatchTileInfoQCOM * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDispatchTileInfoQCOM * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdDispatchTileQCOM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginPerTileExecutionQCOM(VkCommandBuffer a_0, const VkPerTileBeginInfoQCOM * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPerTileBeginInfoQCOM * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBeginPerTileExecutionQCOM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndPerTileExecutionQCOM(VkCommandBuffer a_0, const VkPerTileEndInfoQCOM * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkPerTileEndInfoQCOM * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdEndPerTileExecutionQCOM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDescriptorSetLayoutSizeEXT(VkDevice a_0, VkDescriptorSetLayout a_1, VkDeviceSize * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorSetLayout a_1;
    VkDeviceSize * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDescriptorSetLayoutSizeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDescriptorSetLayoutBindingOffsetEXT(VkDevice a_0, VkDescriptorSetLayout a_1, uint32_t a_2, VkDeviceSize * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorSetLayout a_1;
    uint32_t a_2;
    VkDeviceSize * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDescriptorSetLayoutBindingOffsetEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDescriptorEXT(VkDevice a_0, const VkDescriptorGetInfoEXT * a_1, size_t a_2, void * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorGetInfoEXT * a_1;
    size_t a_2;
    void * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDescriptorEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindDescriptorBuffersEXT(VkCommandBuffer a_0, uint32_t a_1, const VkDescriptorBufferBindingInfoEXT * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkDescriptorBufferBindingInfoEXT * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBindDescriptorBuffersEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDescriptorBufferOffsetsEXT(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const uint32_t * a_5, const VkDeviceSize * a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipelineLayout a_2;
    uint32_t a_3;
    uint32_t a_4;
    const uint32_t * a_5;
    const VkDeviceSize * a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdSetDescriptorBufferOffsetsEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindDescriptorBufferEmbeddedSamplersEXT(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipelineLayout a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdBindDescriptorBufferEmbeddedSamplersEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetBufferOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkBufferCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkBufferCaptureDescriptorDataInfoEXT * a_1;
    void * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetBufferOpaqueCaptureDescriptorDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkImageCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageCaptureDescriptorDataInfoEXT * a_1;
    void * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetImageOpaqueCaptureDescriptorDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetImageViewOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkImageViewCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkImageViewCaptureDescriptorDataInfoEXT * a_1;
    void * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetImageViewOpaqueCaptureDescriptorDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetSamplerOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkSamplerCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkSamplerCaptureDescriptorDataInfoEXT * a_1;
    void * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetSamplerOpaqueCaptureDescriptorDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetAccelerationStructureOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkAccelerationStructureCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAccelerationStructureCaptureDescriptorDataInfoEXT * a_1;
    void * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetAccelerationStructureOpaqueCaptureDescriptorDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetFragmentShadingRateEnumNV(VkCommandBuffer a_0, VkFragmentShadingRateNV a_1, const VkFragmentShadingRateCombinerOpKHR * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkFragmentShadingRateNV a_1;
    const VkFragmentShadingRateCombinerOpKHR * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetFragmentShadingRateEnumNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceFaultInfoEXT(VkDevice a_0, VkDeviceFaultCountsEXT * a_1, VkDeviceFaultInfoEXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeviceFaultCountsEXT * a_1;
    VkDeviceFaultInfoEXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceFaultInfoEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetVertexInputEXT(VkCommandBuffer a_0, uint32_t a_1, const VkVertexInputBindingDescription2EXT * a_2, uint32_t a_3, const VkVertexInputAttributeDescription2EXT * a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkVertexInputBindingDescription2EXT * a_2;
    uint32_t a_3;
    const VkVertexInputAttributeDescription2EXT * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdSetVertexInputEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceSubpassShadingMaxWorkgroupSizeHUAWEI(VkDevice a_0, VkRenderPass a_1, VkExtent2D * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkRenderPass a_1;
    VkExtent2D * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceSubpassShadingMaxWorkgroupSizeHUAWEI(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSubpassShadingHUAWEI(VkCommandBuffer a_0) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libvulkan_vkCmdSubpassShadingHUAWEI(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindInvocationMaskHUAWEI(VkCommandBuffer a_0, VkImageView a_1, VkImageLayout a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImageView a_1;
    VkImageLayout a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBindInvocationMaskHUAWEI(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetMemoryRemoteAddressNV(VkDevice a_0, const VkMemoryGetRemoteAddressInfoNV * a_1, VkRemoteAddressNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMemoryGetRemoteAddressInfoNV * a_1;
    VkRemoteAddressNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetMemoryRemoteAddressNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelinePropertiesEXT(VkDevice a_0, const VkPipelineInfoEXT * a_1, VkBaseOutStructure * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineInfoEXT * a_1;
    VkBaseOutStructure * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPipelinePropertiesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPatchControlPointsEXT(VkCommandBuffer a_0, uint32_t a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPatchControlPointsEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRasterizerDiscardEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRasterizerDiscardEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthBiasEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthBiasEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLogicOpEXT(VkCommandBuffer a_0, VkLogicOp a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkLogicOp a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetLogicOpEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPrimitiveRestartEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPrimitiveRestartEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetColorWriteEnableEXT(VkCommandBuffer a_0, uint32_t a_1, const VkBool32 * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkBool32 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetColorWriteEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMultiEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMultiDrawInfoEXT * a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkMultiDrawInfoEXT * a_2;
    uint32_t a_3;
    uint32_t a_4;
    uint32_t a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdDrawMultiEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMultiIndexedEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMultiDrawIndexedInfoEXT * a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5, const int32_t * a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkMultiDrawIndexedInfoEXT * a_2;
    uint32_t a_3;
    uint32_t a_4;
    uint32_t a_5;
    const int32_t * a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawMultiIndexedEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateMicromapEXT(VkDevice a_0, const VkMicromapCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkMicromapEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMicromapCreateInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkMicromapEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateMicromapEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyMicromapEXT(VkDevice a_0, VkMicromapEXT a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkMicromapEXT a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyMicromapEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBuildMicromapsEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMicromapBuildInfoEXT * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkMicromapBuildInfoEXT * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdBuildMicromapsEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBuildMicromapsEXT(VkDevice a_0, VkDeferredOperationKHR a_1, uint32_t a_2, const VkMicromapBuildInfoEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    uint32_t a_2;
    const VkMicromapBuildInfoEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkBuildMicromapsEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyMicromapEXT(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMicromapInfoEXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    const VkCopyMicromapInfoEXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCopyMicromapEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyMicromapToMemoryEXT(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMicromapToMemoryInfoEXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    const VkCopyMicromapToMemoryInfoEXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCopyMicromapToMemoryEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyMemoryToMicromapEXT(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMemoryToMicromapInfoEXT * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    const VkCopyMemoryToMicromapInfoEXT * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCopyMemoryToMicromapEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkWriteMicromapsPropertiesEXT(VkDevice a_0, uint32_t a_1, const VkMicromapEXT * a_2, VkQueryType a_3, size_t a_4, void * a_5, size_t a_6) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkMicromapEXT * a_2;
    VkQueryType a_3;
    size_t a_4;
    void * a_5;
    size_t a_6;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkWriteMicromapsPropertiesEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMicromapEXT(VkCommandBuffer a_0, const VkCopyMicromapInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyMicromapInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyMicromapEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMicromapToMemoryEXT(VkCommandBuffer a_0, const VkCopyMicromapToMemoryInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyMicromapToMemoryInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyMicromapToMemoryEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMemoryToMicromapEXT(VkCommandBuffer a_0, const VkCopyMemoryToMicromapInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyMemoryToMicromapInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyMemoryToMicromapEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteMicromapsPropertiesEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMicromapEXT * a_2, VkQueryType a_3, VkQueryPool a_4, uint32_t a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkMicromapEXT * a_2;
    VkQueryType a_3;
    VkQueryPool a_4;
    uint32_t a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdWriteMicromapsPropertiesEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceMicromapCompatibilityEXT(VkDevice a_0, const VkMicromapVersionInfoEXT * a_1, VkAccelerationStructureCompatibilityKHR * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkMicromapVersionInfoEXT * a_1;
    VkAccelerationStructureCompatibilityKHR * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceMicromapCompatibilityEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetMicromapBuildSizesEXT(VkDevice a_0, VkAccelerationStructureBuildTypeKHR a_1, const VkMicromapBuildInfoEXT * a_2, VkMicromapBuildSizesInfoEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkAccelerationStructureBuildTypeKHR a_1;
    const VkMicromapBuildInfoEXT * a_2;
    VkMicromapBuildSizesInfoEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetMicromapBuildSizesEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawClusterHUAWEI(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdDrawClusterHUAWEI(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawClusterIndirectHUAWEI(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdDrawClusterIndirectHUAWEI(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetDeviceMemoryPriorityEXT(VkDevice a_0, VkDeviceMemory a_1, float a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeviceMemory a_1;
    float a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkSetDeviceMemoryPriorityEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDescriptorSetLayoutHostMappingInfoVALVE(VkDevice a_0, const VkDescriptorSetBindingReferenceVALVE * a_1, VkDescriptorSetLayoutHostMappingInfoVALVE * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDescriptorSetBindingReferenceVALVE * a_1;
    VkDescriptorSetLayoutHostMappingInfoVALVE * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDescriptorSetLayoutHostMappingInfoVALVE(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDescriptorSetHostMappingVALVE(VkDevice a_0, VkDescriptorSet a_1, void ** a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDescriptorSet a_1;
    void ** a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDescriptorSetHostMappingVALVE(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMemoryIndirectNV(VkCommandBuffer a_0, VkDeviceAddress a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDeviceAddress a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdCopyMemoryIndirectNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMemoryToImageIndirectNV(VkCommandBuffer a_0, VkDeviceAddress a_1, uint32_t a_2, uint32_t a_3, VkImage a_4, VkImageLayout a_5, const VkImageSubresourceLayers * a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDeviceAddress a_1;
    uint32_t a_2;
    uint32_t a_3;
    VkImage a_4;
    VkImageLayout a_5;
    const VkImageSubresourceLayers * a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdCopyMemoryToImageIndirectNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDecompressMemoryNV(VkCommandBuffer a_0, uint32_t a_1, const VkDecompressMemoryRegionNV * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkDecompressMemoryRegionNV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdDecompressMemoryNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDecompressMemoryIndirectCountNV(VkCommandBuffer a_0, VkDeviceAddress a_1, VkDeviceAddress a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDeviceAddress a_1;
    VkDeviceAddress a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdDecompressMemoryIndirectCountNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineIndirectMemoryRequirementsNV(VkDevice a_0, const VkComputePipelineCreateInfo * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkComputePipelineCreateInfo * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPipelineIndirectMemoryRequirementsNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdUpdatePipelineIndirectBufferNV(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipeline a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPipelineBindPoint a_1;
    VkPipeline a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdUpdatePipelineIndirectBufferNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPipelineIndirectDeviceAddressNV(VkDevice a_0, const VkPipelineIndirectDeviceAddressInfoNV * a_1) -> VkDeviceAddress {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPipelineIndirectDeviceAddressInfoNV * a_1;
    VkDeviceAddress rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetPipelineIndirectDeviceAddressNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthClampEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthClampEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetPolygonModeEXT(VkCommandBuffer a_0, VkPolygonMode a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkPolygonMode a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetPolygonModeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRasterizationSamplesEXT(VkCommandBuffer a_0, VkSampleCountFlagBits a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkSampleCountFlagBits a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRasterizationSamplesEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetSampleMaskEXT(VkCommandBuffer a_0, VkSampleCountFlagBits a_1, const VkSampleMask * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkSampleCountFlagBits a_1;
    const VkSampleMask * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetSampleMaskEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetAlphaToCoverageEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetAlphaToCoverageEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetAlphaToOneEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetAlphaToOneEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLogicOpEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetLogicOpEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetColorBlendEnableEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBool32 * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkBool32 * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetColorBlendEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetColorBlendEquationEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkColorBlendEquationEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkColorBlendEquationEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetColorBlendEquationEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetColorWriteMaskEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkColorComponentFlags * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkColorComponentFlags * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetColorWriteMaskEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetTessellationDomainOriginEXT(VkCommandBuffer a_0, VkTessellationDomainOrigin a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkTessellationDomainOrigin a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetTessellationDomainOriginEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRasterizationStreamEXT(VkCommandBuffer a_0, uint32_t a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRasterizationStreamEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetConservativeRasterizationModeEXT(VkCommandBuffer a_0, VkConservativeRasterizationModeEXT a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkConservativeRasterizationModeEXT a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetConservativeRasterizationModeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetExtraPrimitiveOverestimationSizeEXT(VkCommandBuffer a_0, float a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    float a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetExtraPrimitiveOverestimationSizeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthClipEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthClipEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetSampleLocationsEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetSampleLocationsEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetColorBlendAdvancedEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkColorBlendAdvancedEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkColorBlendAdvancedEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetColorBlendAdvancedEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetProvokingVertexModeEXT(VkCommandBuffer a_0, VkProvokingVertexModeEXT a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkProvokingVertexModeEXT a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetProvokingVertexModeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLineRasterizationModeEXT(VkCommandBuffer a_0, VkLineRasterizationModeEXT a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkLineRasterizationModeEXT a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetLineRasterizationModeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetLineStippleEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetLineStippleEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthClipNegativeOneToOneEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetDepthClipNegativeOneToOneEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetViewportWScalingEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetViewportWScalingEnableNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetViewportSwizzleNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkViewportSwizzleNV * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    const VkViewportSwizzleNV * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdSetViewportSwizzleNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCoverageToColorEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCoverageToColorEnableNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCoverageToColorLocationNV(VkCommandBuffer a_0, uint32_t a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCoverageToColorLocationNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCoverageModulationModeNV(VkCommandBuffer a_0, VkCoverageModulationModeNV a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCoverageModulationModeNV a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCoverageModulationModeNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCoverageModulationTableEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCoverageModulationTableEnableNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCoverageModulationTableNV(VkCommandBuffer a_0, uint32_t a_1, const float * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const float * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetCoverageModulationTableNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetShadingRateImageEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetShadingRateImageEnableNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRepresentativeFragmentTestEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRepresentativeFragmentTestEnableNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetCoverageReductionModeNV(VkCommandBuffer a_0, VkCoverageReductionModeNV a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkCoverageReductionModeNV a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetCoverageReductionModeNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateTensorARM(VkDevice a_0, const VkTensorCreateInfoARM * a_1, const VkAllocationCallbacks * a_2, VkTensorARM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkTensorCreateInfoARM * a_1;
    const VkAllocationCallbacks * a_2;
    VkTensorARM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateTensorARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyTensorARM(VkDevice a_0, VkTensorARM a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkTensorARM a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyTensorARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateTensorViewARM(VkDevice a_0, const VkTensorViewCreateInfoARM * a_1, const VkAllocationCallbacks * a_2, VkTensorViewARM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkTensorViewCreateInfoARM * a_1;
    const VkAllocationCallbacks * a_2;
    VkTensorViewARM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateTensorViewARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyTensorViewARM(VkDevice a_0, VkTensorViewARM a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkTensorViewARM a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyTensorViewARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetTensorMemoryRequirementsARM(VkDevice a_0, const VkTensorMemoryRequirementsInfoARM * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkTensorMemoryRequirementsInfoARM * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetTensorMemoryRequirementsARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindTensorMemoryARM(VkDevice a_0, uint32_t a_1, const VkBindTensorMemoryInfoARM * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkBindTensorMemoryInfoARM * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkBindTensorMemoryARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceTensorMemoryRequirementsARM(VkDevice a_0, const VkDeviceTensorMemoryRequirementsARM * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDeviceTensorMemoryRequirementsARM * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceTensorMemoryRequirementsARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyTensorARM(VkCommandBuffer a_0, const VkCopyTensorInfoARM * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyTensorInfoARM * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyTensorARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceExternalTensorPropertiesARM(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalTensorInfoARM * a_1, VkExternalTensorPropertiesARM * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceExternalTensorInfoARM * a_1;
    VkExternalTensorPropertiesARM * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceExternalTensorPropertiesARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetTensorOpaqueCaptureDescriptorDataARM(VkDevice a_0, const VkTensorCaptureDescriptorDataInfoARM * a_1, void * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkTensorCaptureDescriptorDataInfoARM * a_1;
    void * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetTensorOpaqueCaptureDescriptorDataARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetTensorViewOpaqueCaptureDescriptorDataARM(VkDevice a_0, const VkTensorViewCaptureDescriptorDataInfoARM * a_1, void * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkTensorViewCaptureDescriptorDataInfoARM * a_1;
    void * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetTensorViewOpaqueCaptureDescriptorDataARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetShaderModuleIdentifierEXT(VkDevice a_0, VkShaderModule a_1, VkShaderModuleIdentifierEXT * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkShaderModule a_1;
    VkShaderModuleIdentifierEXT * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetShaderModuleIdentifierEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetShaderModuleCreateInfoIdentifierEXT(VkDevice a_0, const VkShaderModuleCreateInfo * a_1, VkShaderModuleIdentifierEXT * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkShaderModuleCreateInfo * a_1;
    VkShaderModuleIdentifierEXT * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetShaderModuleCreateInfoIdentifierEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceOpticalFlowImageFormatsNV(VkPhysicalDevice a_0, const VkOpticalFlowImageFormatInfoNV * a_1, uint32_t * a_2, VkOpticalFlowImageFormatPropertiesNV * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkOpticalFlowImageFormatInfoNV * a_1;
    uint32_t * a_2;
    VkOpticalFlowImageFormatPropertiesNV * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceOpticalFlowImageFormatsNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateOpticalFlowSessionNV(VkDevice a_0, const VkOpticalFlowSessionCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkOpticalFlowSessionNV * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkOpticalFlowSessionCreateInfoNV * a_1;
    const VkAllocationCallbacks * a_2;
    VkOpticalFlowSessionNV * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateOpticalFlowSessionNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyOpticalFlowSessionNV(VkDevice a_0, VkOpticalFlowSessionNV a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkOpticalFlowSessionNV a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyOpticalFlowSessionNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindOpticalFlowSessionImageNV(VkDevice a_0, VkOpticalFlowSessionNV a_1, VkOpticalFlowSessionBindingPointNV a_2, VkImageView a_3, VkImageLayout a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkOpticalFlowSessionNV a_1;
    VkOpticalFlowSessionBindingPointNV a_2;
    VkImageView a_3;
    VkImageLayout a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkBindOpticalFlowSessionImageNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdOpticalFlowExecuteNV(VkCommandBuffer a_0, VkOpticalFlowSessionNV a_1, const VkOpticalFlowExecuteInfoNV * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkOpticalFlowSessionNV a_1;
    const VkOpticalFlowExecuteInfoNV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdOpticalFlowExecuteNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAntiLagUpdateAMD(VkDevice a_0, const VkAntiLagDataAMD * a_1) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAntiLagDataAMD * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkAntiLagUpdateAMD(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateShadersEXT(VkDevice a_0, uint32_t a_1, const VkShaderCreateInfoEXT * a_2, const VkAllocationCallbacks * a_3, VkShaderEXT * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkShaderCreateInfoEXT * a_2;
    const VkAllocationCallbacks * a_3;
    VkShaderEXT * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCreateShadersEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyShaderEXT(VkDevice a_0, VkShaderEXT a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkShaderEXT a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyShaderEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetShaderBinaryDataEXT(VkDevice a_0, VkShaderEXT a_1, size_t * a_2, void * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkShaderEXT a_1;
    size_t * a_2;
    void * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetShaderBinaryDataEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindShadersEXT(VkCommandBuffer a_0, uint32_t a_1, const VkShaderStageFlagBits * a_2, const VkShaderEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkShaderStageFlagBits * a_2;
    const VkShaderEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdBindShadersEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetDepthClampRangeEXT(VkCommandBuffer a_0, VkDepthClampModeEXT a_1, const VkDepthClampRangeEXT * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDepthClampModeEXT a_1;
    const VkDepthClampRangeEXT * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdSetDepthClampRangeEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetFramebufferTilePropertiesQCOM(VkDevice a_0, VkFramebuffer a_1, uint32_t * a_2, VkTilePropertiesQCOM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkFramebuffer a_1;
    uint32_t * a_2;
    VkTilePropertiesQCOM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetFramebufferTilePropertiesQCOM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDynamicRenderingTilePropertiesQCOM(VkDevice a_0, const VkRenderingInfo * a_1, VkTilePropertiesQCOM * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkRenderingInfo * a_1;
    VkTilePropertiesQCOM * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDynamicRenderingTilePropertiesQCOM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceCooperativeVectorPropertiesNV(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeVectorPropertiesNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkCooperativeVectorPropertiesNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceCooperativeVectorPropertiesNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkConvertCooperativeVectorMatrixNV(VkDevice a_0, const VkConvertCooperativeVectorMatrixInfoNV * a_1) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkConvertCooperativeVectorMatrixInfoNV * a_1;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkConvertCooperativeVectorMatrixNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdConvertCooperativeVectorMatrixNV(VkCommandBuffer a_0, uint32_t a_1, const VkConvertCooperativeVectorMatrixInfoNV * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkConvertCooperativeVectorMatrixInfoNV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdConvertCooperativeVectorMatrixNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetLatencySleepModeNV(VkDevice a_0, VkSwapchainKHR a_1, const VkLatencySleepModeInfoNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    const VkLatencySleepModeInfoNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkSetLatencySleepModeNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkLatencySleepNV(VkDevice a_0, VkSwapchainKHR a_1, const VkLatencySleepInfoNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    const VkLatencySleepInfoNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkLatencySleepNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkSetLatencyMarkerNV(VkDevice a_0, VkSwapchainKHR a_1, const VkSetLatencyMarkerInfoNV * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    const VkSetLatencyMarkerInfoNV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkSetLatencyMarkerNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetLatencyTimingsNV(VkDevice a_0, VkSwapchainKHR a_1, VkGetLatencyMarkerInfoNV * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkSwapchainKHR a_1;
    VkGetLatencyMarkerInfoNV * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetLatencyTimingsNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkQueueNotifyOutOfBandNV(VkQueue a_0, const VkOutOfBandQueueTypeInfoNV * a_1) -> void {
  struct __attribute__((packed)) {
    VkQueue a_0;
    const VkOutOfBandQueueTypeInfoNV * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkQueueNotifyOutOfBandNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDataGraphPipelinesARM(VkDevice a_0, VkDeferredOperationKHR a_1, VkPipelineCache a_2, uint32_t a_3, const VkDataGraphPipelineCreateInfoARM * a_4, const VkAllocationCallbacks * a_5, VkPipeline * a_6) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    VkPipelineCache a_2;
    uint32_t a_3;
    const VkDataGraphPipelineCreateInfoARM * a_4;
    const VkAllocationCallbacks * a_5;
    VkPipeline * a_6;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCreateDataGraphPipelinesARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateDataGraphPipelineSessionARM(VkDevice a_0, const VkDataGraphPipelineSessionCreateInfoARM * a_1, const VkAllocationCallbacks * a_2, VkDataGraphPipelineSessionARM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDataGraphPipelineSessionCreateInfoARM * a_1;
    const VkAllocationCallbacks * a_2;
    VkDataGraphPipelineSessionARM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateDataGraphPipelineSessionARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDataGraphPipelineSessionBindPointRequirementsARM(VkDevice a_0, const VkDataGraphPipelineSessionBindPointRequirementsInfoARM * a_1, uint32_t * a_2, VkDataGraphPipelineSessionBindPointRequirementARM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDataGraphPipelineSessionBindPointRequirementsInfoARM * a_1;
    uint32_t * a_2;
    VkDataGraphPipelineSessionBindPointRequirementARM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDataGraphPipelineSessionBindPointRequirementsARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDataGraphPipelineSessionMemoryRequirementsARM(VkDevice a_0, const VkDataGraphPipelineSessionMemoryRequirementsInfoARM * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDataGraphPipelineSessionMemoryRequirementsInfoARM * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDataGraphPipelineSessionMemoryRequirementsARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBindDataGraphPipelineSessionMemoryARM(VkDevice a_0, uint32_t a_1, const VkBindDataGraphPipelineSessionMemoryInfoARM * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkBindDataGraphPipelineSessionMemoryInfoARM * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkBindDataGraphPipelineSessionMemoryARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyDataGraphPipelineSessionARM(VkDevice a_0, VkDataGraphPipelineSessionARM a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDataGraphPipelineSessionARM a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyDataGraphPipelineSessionARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDispatchDataGraphARM(VkCommandBuffer a_0, VkDataGraphPipelineSessionARM a_1, const VkDataGraphPipelineDispatchInfoARM * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkDataGraphPipelineSessionARM a_1;
    const VkDataGraphPipelineDispatchInfoARM * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdDispatchDataGraphARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDataGraphPipelineAvailablePropertiesARM(VkDevice a_0, const VkDataGraphPipelineInfoARM * a_1, uint32_t * a_2, VkDataGraphPipelinePropertyARM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDataGraphPipelineInfoARM * a_1;
    uint32_t * a_2;
    VkDataGraphPipelinePropertyARM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDataGraphPipelineAvailablePropertiesARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDataGraphPipelinePropertiesARM(VkDevice a_0, const VkDataGraphPipelineInfoARM * a_1, uint32_t a_2, VkDataGraphPipelinePropertyQueryResultARM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkDataGraphPipelineInfoARM * a_1;
    uint32_t a_2;
    VkDataGraphPipelinePropertyQueryResultARM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetDataGraphPipelinePropertiesARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceQueueFamilyDataGraphPropertiesARM(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkQueueFamilyDataGraphPropertiesARM * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    uint32_t * a_2;
    VkQueueFamilyDataGraphPropertiesARM * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceQueueFamilyDataGraphPropertiesARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceQueueFamilyDataGraphProcessingEnginePropertiesARM(VkPhysicalDevice a_0, const VkPhysicalDeviceQueueFamilyDataGraphProcessingEngineInfoARM * a_1, VkQueueFamilyDataGraphProcessingEnginePropertiesARM * a_2) -> void {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    const VkPhysicalDeviceQueueFamilyDataGraphProcessingEngineInfoARM * a_1;
    VkQueueFamilyDataGraphProcessingEnginePropertiesARM * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceQueueFamilyDataGraphProcessingEnginePropertiesARM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetAttachmentFeedbackLoopEnableEXT(VkCommandBuffer a_0, VkImageAspectFlags a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkImageAspectFlags a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetAttachmentFeedbackLoopEnableEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBindTileMemoryQCOM(VkCommandBuffer a_0, const VkTileMemoryBindInfoQCOM * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkTileMemoryBindInfoQCOM * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBindTileMemoryQCOM(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDecompressMemoryEXT(VkCommandBuffer a_0, const VkDecompressMemoryInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkDecompressMemoryInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdDecompressMemoryEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDecompressMemoryIndirectCountEXT(VkCommandBuffer a_0, VkMemoryDecompressionMethodFlagsEXT a_1, VkDeviceAddress a_2, VkDeviceAddress a_3, uint32_t a_4, uint32_t a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkMemoryDecompressionMethodFlagsEXT a_1;
    VkDeviceAddress a_2;
    VkDeviceAddress a_3;
    uint32_t a_4;
    uint32_t a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdDecompressMemoryIndirectCountEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateExternalComputeQueueNV(VkDevice a_0, const VkExternalComputeQueueCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkExternalComputeQueueNV * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkExternalComputeQueueCreateInfoNV * a_1;
    const VkAllocationCallbacks * a_2;
    VkExternalComputeQueueNV * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateExternalComputeQueueNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyExternalComputeQueueNV(VkDevice a_0, VkExternalComputeQueueNV a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkExternalComputeQueueNV a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyExternalComputeQueueNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetExternalComputeQueueDataNV(VkExternalComputeQueueNV a_0, VkExternalComputeQueueDataParamsNV * a_1, void * a_2) -> void {
  struct __attribute__((packed)) {
    VkExternalComputeQueueNV a_0;
    VkExternalComputeQueueDataParamsNV * a_1;
    void * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetExternalComputeQueueDataNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetClusterAccelerationStructureBuildSizesNV(VkDevice a_0, const VkClusterAccelerationStructureInputInfoNV * a_1, VkAccelerationStructureBuildSizesInfoKHR * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkClusterAccelerationStructureInputInfoNV * a_1;
    VkAccelerationStructureBuildSizesInfoKHR * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetClusterAccelerationStructureBuildSizesNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBuildClusterAccelerationStructureIndirectNV(VkCommandBuffer a_0, const VkClusterAccelerationStructureCommandsInfoNV * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkClusterAccelerationStructureCommandsInfoNV * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBuildClusterAccelerationStructureIndirectNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPartitionedAccelerationStructuresBuildSizesNV(VkDevice a_0, const VkPartitionedAccelerationStructureInstancesInputNV * a_1, VkAccelerationStructureBuildSizesInfoKHR * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkPartitionedAccelerationStructureInstancesInputNV * a_1;
    VkAccelerationStructureBuildSizesInfoKHR * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPartitionedAccelerationStructuresBuildSizesNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBuildPartitionedAccelerationStructuresNV(VkCommandBuffer a_0, const VkBuildPartitionedAccelerationStructureInfoNV * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkBuildPartitionedAccelerationStructureInfoNV * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBuildPartitionedAccelerationStructuresNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetGeneratedCommandsMemoryRequirementsEXT(VkDevice a_0, const VkGeneratedCommandsMemoryRequirementsInfoEXT * a_1, VkMemoryRequirements2 * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkGeneratedCommandsMemoryRequirementsInfoEXT * a_1;
    VkMemoryRequirements2 * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetGeneratedCommandsMemoryRequirementsEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdPreprocessGeneratedCommandsEXT(VkCommandBuffer a_0, const VkGeneratedCommandsInfoEXT * a_1, VkCommandBuffer a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkGeneratedCommandsInfoEXT * a_1;
    VkCommandBuffer a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdPreprocessGeneratedCommandsEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdExecuteGeneratedCommandsEXT(VkCommandBuffer a_0, VkBool32 a_1, const VkGeneratedCommandsInfoEXT * a_2) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBool32 a_1;
    const VkGeneratedCommandsInfoEXT * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCmdExecuteGeneratedCommandsEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateIndirectCommandsLayoutEXT(VkDevice a_0, const VkIndirectCommandsLayoutCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkIndirectCommandsLayoutEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkIndirectCommandsLayoutCreateInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkIndirectCommandsLayoutEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateIndirectCommandsLayoutEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyIndirectCommandsLayoutEXT(VkDevice a_0, VkIndirectCommandsLayoutEXT a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkIndirectCommandsLayoutEXT a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyIndirectCommandsLayoutEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateIndirectExecutionSetEXT(VkDevice a_0, const VkIndirectExecutionSetCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkIndirectExecutionSetEXT * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkIndirectExecutionSetCreateInfoEXT * a_1;
    const VkAllocationCallbacks * a_2;
    VkIndirectExecutionSetEXT * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateIndirectExecutionSetEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyIndirectExecutionSetEXT(VkDevice a_0, VkIndirectExecutionSetEXT a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkIndirectExecutionSetEXT a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyIndirectExecutionSetEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUpdateIndirectExecutionSetPipelineEXT(VkDevice a_0, VkIndirectExecutionSetEXT a_1, uint32_t a_2, const VkWriteIndirectExecutionSetPipelineEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkIndirectExecutionSetEXT a_1;
    uint32_t a_2;
    const VkWriteIndirectExecutionSetPipelineEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkUpdateIndirectExecutionSetPipelineEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkUpdateIndirectExecutionSetShaderEXT(VkDevice a_0, VkIndirectExecutionSetEXT a_1, uint32_t a_2, const VkWriteIndirectExecutionSetShaderEXT * a_3) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkIndirectExecutionSetEXT a_1;
    uint32_t a_2;
    const VkWriteIndirectExecutionSetShaderEXT * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkUpdateIndirectExecutionSetShaderEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceCooperativeMatrixFlexibleDimensionsPropertiesNV(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeMatrixFlexibleDimensionsPropertiesNV * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t * a_1;
    VkCooperativeMatrixFlexibleDimensionsPropertiesNV * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceCooperativeMatrixFlexibleDimensionsPropertiesNV(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkEnumeratePhysicalDeviceQueueFamilyPerformanceCountersByRegionARM(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkPerformanceCounterARM * a_3, VkPerformanceCounterDescriptionARM * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    uint32_t * a_2;
    VkPerformanceCounterARM * a_3;
    VkPerformanceCounterDescriptionARM * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkEnumeratePhysicalDeviceQueueFamilyPerformanceCountersByRegionARM(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdEndRendering2EXT(VkCommandBuffer a_0, const VkRenderingEndInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkRenderingEndInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdEndRendering2EXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBeginCustomResolveEXT(VkCommandBuffer a_0, const VkBeginCustomResolveInfoEXT * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkBeginCustomResolveInfoEXT * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdBeginCustomResolveEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetComputeOccupancyPriorityNV(VkCommandBuffer a_0, const VkComputeOccupancyPriorityParametersNV * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkComputeOccupancyPriorityParametersNV * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetComputeOccupancyPriorityNV(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateAccelerationStructureKHR(VkDevice a_0, const VkAccelerationStructureCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkAccelerationStructureKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAccelerationStructureCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkAccelerationStructureKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateAccelerationStructureKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkDestroyAccelerationStructureKHR(VkDevice a_0, VkAccelerationStructureKHR a_1, const VkAllocationCallbacks * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkAccelerationStructureKHR a_1;
    const VkAllocationCallbacks * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkDestroyAccelerationStructureKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBuildAccelerationStructuresKHR(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureBuildGeometryInfoKHR * a_2, const VkAccelerationStructureBuildRangeInfoKHR *const * a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkAccelerationStructureBuildGeometryInfoKHR * a_2;
    const VkAccelerationStructureBuildRangeInfoKHR *const * a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdBuildAccelerationStructuresKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdBuildAccelerationStructuresIndirectKHR(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureBuildGeometryInfoKHR * a_2, const VkDeviceAddress * a_3, const uint32_t * a_4, const uint32_t *const * a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkAccelerationStructureBuildGeometryInfoKHR * a_2;
    const VkDeviceAddress * a_3;
    const uint32_t * a_4;
    const uint32_t *const * a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdBuildAccelerationStructuresIndirectKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkBuildAccelerationStructuresKHR(VkDevice a_0, VkDeferredOperationKHR a_1, uint32_t a_2, const VkAccelerationStructureBuildGeometryInfoKHR * a_3, const VkAccelerationStructureBuildRangeInfoKHR *const * a_4) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    uint32_t a_2;
    const VkAccelerationStructureBuildGeometryInfoKHR * a_3;
    const VkAccelerationStructureBuildRangeInfoKHR *const * a_4;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkBuildAccelerationStructuresKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyAccelerationStructureKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyAccelerationStructureInfoKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    const VkCopyAccelerationStructureInfoKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCopyAccelerationStructureKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyAccelerationStructureToMemoryKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyAccelerationStructureToMemoryInfoKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    const VkCopyAccelerationStructureToMemoryInfoKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCopyAccelerationStructureToMemoryKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCopyMemoryToAccelerationStructureKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMemoryToAccelerationStructureInfoKHR * a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    const VkCopyMemoryToAccelerationStructureInfoKHR * a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkCopyMemoryToAccelerationStructureKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkWriteAccelerationStructuresPropertiesKHR(VkDevice a_0, uint32_t a_1, const VkAccelerationStructureKHR * a_2, VkQueryType a_3, size_t a_4, void * a_5, size_t a_6) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    uint32_t a_1;
    const VkAccelerationStructureKHR * a_2;
    VkQueryType a_3;
    size_t a_4;
    void * a_5;
    size_t a_6;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkWriteAccelerationStructuresPropertiesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyAccelerationStructureKHR(VkCommandBuffer a_0, const VkCopyAccelerationStructureInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyAccelerationStructureInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyAccelerationStructureKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyAccelerationStructureToMemoryKHR(VkCommandBuffer a_0, const VkCopyAccelerationStructureToMemoryInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyAccelerationStructureToMemoryInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyAccelerationStructureToMemoryKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdCopyMemoryToAccelerationStructureKHR(VkCommandBuffer a_0, const VkCopyMemoryToAccelerationStructureInfoKHR * a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkCopyMemoryToAccelerationStructureInfoKHR * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdCopyMemoryToAccelerationStructureKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetAccelerationStructureDeviceAddressKHR(VkDevice a_0, const VkAccelerationStructureDeviceAddressInfoKHR * a_1) -> VkDeviceAddress {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAccelerationStructureDeviceAddressInfoKHR * a_1;
    VkDeviceAddress rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkGetAccelerationStructureDeviceAddressKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdWriteAccelerationStructuresPropertiesKHR(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureKHR * a_2, VkQueryType a_3, VkQueryPool a_4, uint32_t a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    const VkAccelerationStructureKHR * a_2;
    VkQueryType a_3;
    VkQueryPool a_4;
    uint32_t a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdWriteAccelerationStructuresPropertiesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetDeviceAccelerationStructureCompatibilityKHR(VkDevice a_0, const VkAccelerationStructureVersionInfoKHR * a_1, VkAccelerationStructureCompatibilityKHR * a_2) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    const VkAccelerationStructureVersionInfoKHR * a_1;
    VkAccelerationStructureCompatibilityKHR * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetDeviceAccelerationStructureCompatibilityKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetAccelerationStructureBuildSizesKHR(VkDevice a_0, VkAccelerationStructureBuildTypeKHR a_1, const VkAccelerationStructureBuildGeometryInfoKHR * a_2, const uint32_t * a_3, VkAccelerationStructureBuildSizesInfoKHR * a_4) -> void {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkAccelerationStructureBuildTypeKHR a_1;
    const VkAccelerationStructureBuildGeometryInfoKHR * a_2;
    const uint32_t * a_3;
    VkAccelerationStructureBuildSizesInfoKHR * a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkGetAccelerationStructureBuildSizesKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdTraceRaysKHR(VkCommandBuffer a_0, const VkStridedDeviceAddressRegionKHR * a_1, const VkStridedDeviceAddressRegionKHR * a_2, const VkStridedDeviceAddressRegionKHR * a_3, const VkStridedDeviceAddressRegionKHR * a_4, uint32_t a_5, uint32_t a_6, uint32_t a_7) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkStridedDeviceAddressRegionKHR * a_1;
    const VkStridedDeviceAddressRegionKHR * a_2;
    const VkStridedDeviceAddressRegionKHR * a_3;
    const VkStridedDeviceAddressRegionKHR * a_4;
    uint32_t a_5;
    uint32_t a_6;
    uint32_t a_7;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libvulkan_vkCmdTraceRaysKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateRayTracingPipelinesKHR(VkDevice a_0, VkDeferredOperationKHR a_1, VkPipelineCache a_2, uint32_t a_3, const VkRayTracingPipelineCreateInfoKHR * a_4, const VkAllocationCallbacks * a_5, VkPipeline * a_6) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkDeferredOperationKHR a_1;
    VkPipelineCache a_2;
    uint32_t a_3;
    const VkRayTracingPipelineCreateInfoKHR * a_4;
    const VkAllocationCallbacks * a_5;
    VkPipeline * a_6;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCreateRayTracingPipelinesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRayTracingCaptureReplayShaderGroupHandlesKHR(VkDevice a_0, VkPipeline a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5) -> VkResult {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipeline a_1;
    uint32_t a_2;
    uint32_t a_3;
    size_t a_4;
    void * a_5;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkGetRayTracingCaptureReplayShaderGroupHandlesKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdTraceRaysIndirectKHR(VkCommandBuffer a_0, const VkStridedDeviceAddressRegionKHR * a_1, const VkStridedDeviceAddressRegionKHR * a_2, const VkStridedDeviceAddressRegionKHR * a_3, const VkStridedDeviceAddressRegionKHR * a_4, VkDeviceAddress a_5) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    const VkStridedDeviceAddressRegionKHR * a_1;
    const VkStridedDeviceAddressRegionKHR * a_2;
    const VkStridedDeviceAddressRegionKHR * a_3;
    const VkStridedDeviceAddressRegionKHR * a_4;
    VkDeviceAddress a_5;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libvulkan_vkCmdTraceRaysIndirectKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRayTracingShaderGroupStackSizeKHR(VkDevice a_0, VkPipeline a_1, uint32_t a_2, VkShaderGroupShaderKHR a_3) -> VkDeviceSize {
  struct __attribute__((packed)) {
    VkDevice a_0;
    VkPipeline a_1;
    uint32_t a_2;
    VkShaderGroupShaderKHR a_3;
    VkDeviceSize rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetRayTracingShaderGroupStackSizeKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdSetRayTracingPipelineStackSizeKHR(VkCommandBuffer a_0, uint32_t a_1) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libvulkan_vkCmdSetRayTracingPipelineStackSizeKHR(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMeshTasksEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint32_t a_3;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCmdDrawMeshTasksEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMeshTasksIndirectEXT(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    uint32_t a_3;
    uint32_t a_4;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libvulkan_vkCmdDrawMeshTasksIndirectEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCmdDrawMeshTasksIndirectCountEXT(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void {
  struct __attribute__((packed)) {
    VkCommandBuffer a_0;
    VkBuffer a_1;
    VkDeviceSize a_2;
    VkBuffer a_3;
    VkDeviceSize a_4;
    uint32_t a_5;
    uint32_t a_6;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libvulkan_vkCmdDrawMeshTasksIndirectCountEXT(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkAcquireXlibDisplayEXT(VkPhysicalDevice a_0, Display * a_1, VkDisplayKHR a_2) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    Display * a_1;
    VkDisplayKHR a_2;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkAcquireXlibDisplayEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetRandROutputDisplayEXT(VkPhysicalDevice a_0, Display * a_1, RROutput a_2, VkDisplayKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    Display * a_1;
    RROutput a_2;
    VkDisplayKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetRandROutputDisplayEXT(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateWaylandSurfaceKHR(VkInstance a_0, const VkWaylandSurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkWaylandSurfaceCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkSurfaceKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateWaylandSurfaceKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceWaylandPresentationSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, struct wl_display * a_2) -> VkBool32 {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    struct wl_display * a_2;
    VkBool32 rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libvulkan_vkGetPhysicalDeviceWaylandPresentationSupportKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateXcbSurfaceKHR(VkInstance a_0, const VkXcbSurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkXcbSurfaceCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkSurfaceKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateXcbSurfaceKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceXcbPresentationSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, xcb_connection_t * a_2, xcb_visualid_t a_3) -> VkBool32 {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    xcb_connection_t * a_2;
    xcb_visualid_t a_3;
    VkBool32 rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceXcbPresentationSupportKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkCreateXlibSurfaceKHR(VkInstance a_0, const VkXlibSurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult {
  struct __attribute__((packed)) {
    VkInstance a_0;
    const VkXlibSurfaceCreateInfoKHR * a_1;
    const VkAllocationCallbacks * a_2;
    VkSurfaceKHR * a_3;
    VkResult rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkCreateXlibSurfaceKHR(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_vkGetPhysicalDeviceXlibPresentationSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, Display * a_2, VisualID a_3) -> VkBool32 {
  struct __attribute__((packed)) {
    VkPhysicalDevice a_0;
    uint32_t a_1;
    Display * a_2;
    VisualID a_3;
    VkBool32 rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libvulkan_vkGetPhysicalDeviceXlibPresentationSupportKHR(&args);
  return args.rv;
}
}
extern "C" {
__attribute__((alias("fexfn_pack_vkCreateInstance"))) auto vkCreateInstance(const VkInstanceCreateInfo * a_0, const VkAllocationCallbacks * a_1, VkInstance * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyInstance"))) auto vkDestroyInstance(VkInstance a_0, const VkAllocationCallbacks * a_1) -> void;
__attribute__((alias("fexfn_pack_vkEnumeratePhysicalDevices"))) auto vkEnumeratePhysicalDevices(VkInstance a_0, uint32_t * a_1, VkPhysicalDevice * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceFeatures"))) auto vkGetPhysicalDeviceFeatures(VkPhysicalDevice a_0, VkPhysicalDeviceFeatures * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceFormatProperties"))) auto vkGetPhysicalDeviceFormatProperties(VkPhysicalDevice a_0, VkFormat a_1, VkFormatProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceImageFormatProperties"))) auto vkGetPhysicalDeviceImageFormatProperties(VkPhysicalDevice a_0, VkFormat a_1, VkImageType a_2, VkImageTiling a_3, VkImageUsageFlags a_4, VkImageCreateFlags a_5, VkImageFormatProperties * a_6) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceProperties"))) auto vkGetPhysicalDeviceProperties(VkPhysicalDevice a_0, VkPhysicalDeviceProperties * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceQueueFamilyProperties"))) auto vkGetPhysicalDeviceQueueFamilyProperties(VkPhysicalDevice a_0, uint32_t * a_1, VkQueueFamilyProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceMemoryProperties"))) auto vkGetPhysicalDeviceMemoryProperties(VkPhysicalDevice a_0, VkPhysicalDeviceMemoryProperties * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCreateDevice"))) auto vkCreateDevice(VkPhysicalDevice a_0, const VkDeviceCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDevice * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDevice"))) auto vkDestroyDevice(VkDevice a_0, const VkAllocationCallbacks * a_1) -> void;
__attribute__((alias("fexfn_pack_vkEnumerateInstanceExtensionProperties"))) auto vkEnumerateInstanceExtensionProperties(const char * a_0, uint32_t * a_1, VkExtensionProperties * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkEnumerateDeviceExtensionProperties"))) auto vkEnumerateDeviceExtensionProperties(VkPhysicalDevice a_0, const char * a_1, uint32_t * a_2, VkExtensionProperties * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkEnumerateInstanceLayerProperties"))) auto vkEnumerateInstanceLayerProperties(uint32_t * a_0, VkLayerProperties * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkEnumerateDeviceLayerProperties"))) auto vkEnumerateDeviceLayerProperties(VkPhysicalDevice a_0, uint32_t * a_1, VkLayerProperties * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDeviceQueue"))) auto vkGetDeviceQueue(VkDevice a_0, uint32_t a_1, uint32_t a_2, VkQueue * a_3) -> void;
__attribute__((alias("fexfn_pack_vkQueueSubmit"))) auto vkQueueSubmit(VkQueue a_0, uint32_t a_1, const VkSubmitInfo * a_2, VkFence a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkQueueWaitIdle"))) auto vkQueueWaitIdle(VkQueue a_0) -> VkResult;
__attribute__((alias("fexfn_pack_vkDeviceWaitIdle"))) auto vkDeviceWaitIdle(VkDevice a_0) -> VkResult;
__attribute__((alias("fexfn_pack_vkAllocateMemory"))) auto vkAllocateMemory(VkDevice a_0, const VkMemoryAllocateInfo * a_1, const VkAllocationCallbacks * a_2, VkDeviceMemory * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkFreeMemory"))) auto vkFreeMemory(VkDevice a_0, VkDeviceMemory a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkMapMemory"))) auto vkMapMemory(VkDevice a_0, VkDeviceMemory a_1, VkDeviceSize a_2, VkDeviceSize a_3, VkMemoryMapFlags a_4, void ** a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkUnmapMemory"))) auto vkUnmapMemory(VkDevice a_0, VkDeviceMemory a_1) -> void;
__attribute__((alias("fexfn_pack_vkFlushMappedMemoryRanges"))) auto vkFlushMappedMemoryRanges(VkDevice a_0, uint32_t a_1, const VkMappedMemoryRange * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkInvalidateMappedMemoryRanges"))) auto vkInvalidateMappedMemoryRanges(VkDevice a_0, uint32_t a_1, const VkMappedMemoryRange * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDeviceMemoryCommitment"))) auto vkGetDeviceMemoryCommitment(VkDevice a_0, VkDeviceMemory a_1, VkDeviceSize * a_2) -> void;
__attribute__((alias("fexfn_pack_vkBindBufferMemory"))) auto vkBindBufferMemory(VkDevice a_0, VkBuffer a_1, VkDeviceMemory a_2, VkDeviceSize a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkBindImageMemory"))) auto vkBindImageMemory(VkDevice a_0, VkImage a_1, VkDeviceMemory a_2, VkDeviceSize a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetBufferMemoryRequirements"))) auto vkGetBufferMemoryRequirements(VkDevice a_0, VkBuffer a_1, VkMemoryRequirements * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageMemoryRequirements"))) auto vkGetImageMemoryRequirements(VkDevice a_0, VkImage a_1, VkMemoryRequirements * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageSparseMemoryRequirements"))) auto vkGetImageSparseMemoryRequirements(VkDevice a_0, VkImage a_1, uint32_t * a_2, VkSparseImageMemoryRequirements * a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSparseImageFormatProperties"))) auto vkGetPhysicalDeviceSparseImageFormatProperties(VkPhysicalDevice a_0, VkFormat a_1, VkImageType a_2, VkSampleCountFlagBits a_3, VkImageUsageFlags a_4, VkImageTiling a_5, uint32_t * a_6, VkSparseImageFormatProperties * a_7) -> void;
__attribute__((alias("fexfn_pack_vkQueueBindSparse"))) auto vkQueueBindSparse(VkQueue a_0, uint32_t a_1, const VkBindSparseInfo * a_2, VkFence a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateFence"))) auto vkCreateFence(VkDevice a_0, const VkFenceCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkFence * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyFence"))) auto vkDestroyFence(VkDevice a_0, VkFence a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkResetFences"))) auto vkResetFences(VkDevice a_0, uint32_t a_1, const VkFence * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetFenceStatus"))) auto vkGetFenceStatus(VkDevice a_0, VkFence a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkWaitForFences"))) auto vkWaitForFences(VkDevice a_0, uint32_t a_1, const VkFence * a_2, VkBool32 a_3, uint64_t a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateSemaphore"))) auto vkCreateSemaphore(VkDevice a_0, const VkSemaphoreCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSemaphore * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroySemaphore"))) auto vkDestroySemaphore(VkDevice a_0, VkSemaphore a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateQueryPool"))) auto vkCreateQueryPool(VkDevice a_0, const VkQueryPoolCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkQueryPool * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyQueryPool"))) auto vkDestroyQueryPool(VkDevice a_0, VkQueryPool a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetQueryPoolResults"))) auto vkGetQueryPoolResults(VkDevice a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5, VkDeviceSize a_6, VkQueryResultFlags a_7) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateBuffer"))) auto vkCreateBuffer(VkDevice a_0, const VkBufferCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkBuffer * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyBuffer"))) auto vkDestroyBuffer(VkDevice a_0, VkBuffer a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateImage"))) auto vkCreateImage(VkDevice a_0, const VkImageCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkImage * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyImage"))) auto vkDestroyImage(VkDevice a_0, VkImage a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageSubresourceLayout"))) auto vkGetImageSubresourceLayout(VkDevice a_0, VkImage a_1, const VkImageSubresource * a_2, VkSubresourceLayout * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCreateImageView"))) auto vkCreateImageView(VkDevice a_0, const VkImageViewCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkImageView * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyImageView"))) auto vkDestroyImageView(VkDevice a_0, VkImageView a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateCommandPool"))) auto vkCreateCommandPool(VkDevice a_0, const VkCommandPoolCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkCommandPool * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyCommandPool"))) auto vkDestroyCommandPool(VkDevice a_0, VkCommandPool a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkResetCommandPool"))) auto vkResetCommandPool(VkDevice a_0, VkCommandPool a_1, VkCommandPoolResetFlags a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkAllocateCommandBuffers"))) auto vkAllocateCommandBuffers(VkDevice a_0, const VkCommandBufferAllocateInfo * a_1, VkCommandBuffer * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkFreeCommandBuffers"))) auto vkFreeCommandBuffers(VkDevice a_0, VkCommandPool a_1, uint32_t a_2, const VkCommandBuffer * a_3) -> void;
__attribute__((alias("fexfn_pack_vkBeginCommandBuffer"))) auto vkBeginCommandBuffer(VkCommandBuffer a_0, const VkCommandBufferBeginInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkEndCommandBuffer"))) auto vkEndCommandBuffer(VkCommandBuffer a_0) -> VkResult;
__attribute__((alias("fexfn_pack_vkResetCommandBuffer"))) auto vkResetCommandBuffer(VkCommandBuffer a_0, VkCommandBufferResetFlags a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdCopyBuffer"))) auto vkCmdCopyBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkBuffer a_2, uint32_t a_3, const VkBufferCopy * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyImage"))) auto vkCmdCopyImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkImage a_3, VkImageLayout a_4, uint32_t a_5, const VkImageCopy * a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyBufferToImage"))) auto vkCmdCopyBufferToImage(VkCommandBuffer a_0, VkBuffer a_1, VkImage a_2, VkImageLayout a_3, uint32_t a_4, const VkBufferImageCopy * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyImageToBuffer"))) auto vkCmdCopyImageToBuffer(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkBuffer a_3, uint32_t a_4, const VkBufferImageCopy * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdUpdateBuffer"))) auto vkCmdUpdateBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, const void * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdFillBuffer"))) auto vkCmdFillBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdPipelineBarrier"))) auto vkCmdPipelineBarrier(VkCommandBuffer a_0, VkPipelineStageFlags a_1, VkPipelineStageFlags a_2, VkDependencyFlags a_3, uint32_t a_4, const VkMemoryBarrier * a_5, uint32_t a_6, const VkBufferMemoryBarrier * a_7, uint32_t a_8, const VkImageMemoryBarrier * a_9) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginQuery"))) auto vkCmdBeginQuery(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, VkQueryControlFlags a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndQuery"))) auto vkCmdEndQuery(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdResetQueryPool"))) auto vkCmdResetQueryPool(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdWriteTimestamp"))) auto vkCmdWriteTimestamp(VkCommandBuffer a_0, VkPipelineStageFlagBits a_1, VkQueryPool a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyQueryPoolResults"))) auto vkCmdCopyQueryPoolResults(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3, VkBuffer a_4, VkDeviceSize a_5, VkDeviceSize a_6, VkQueryResultFlags a_7) -> void;
__attribute__((alias("fexfn_pack_vkCmdExecuteCommands"))) auto vkCmdExecuteCommands(VkCommandBuffer a_0, uint32_t a_1, const VkCommandBuffer * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateEvent"))) auto vkCreateEvent(VkDevice a_0, const VkEventCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkEvent * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyEvent"))) auto vkDestroyEvent(VkDevice a_0, VkEvent a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetEventStatus"))) auto vkGetEventStatus(VkDevice a_0, VkEvent a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkSetEvent"))) auto vkSetEvent(VkDevice a_0, VkEvent a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkResetEvent"))) auto vkResetEvent(VkDevice a_0, VkEvent a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateBufferView"))) auto vkCreateBufferView(VkDevice a_0, const VkBufferViewCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkBufferView * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyBufferView"))) auto vkDestroyBufferView(VkDevice a_0, VkBufferView a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateShaderModule"))) auto vkCreateShaderModule(VkDevice a_0, const VkShaderModuleCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkShaderModule * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyShaderModule"))) auto vkDestroyShaderModule(VkDevice a_0, VkShaderModule a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreatePipelineCache"))) auto vkCreatePipelineCache(VkDevice a_0, const VkPipelineCacheCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPipelineCache * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyPipelineCache"))) auto vkDestroyPipelineCache(VkDevice a_0, VkPipelineCache a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPipelineCacheData"))) auto vkGetPipelineCacheData(VkDevice a_0, VkPipelineCache a_1, size_t * a_2, void * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkMergePipelineCaches"))) auto vkMergePipelineCaches(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkPipelineCache * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateComputePipelines"))) auto vkCreateComputePipelines(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkComputePipelineCreateInfo * a_3, const VkAllocationCallbacks * a_4, VkPipeline * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyPipeline"))) auto vkDestroyPipeline(VkDevice a_0, VkPipeline a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreatePipelineLayout"))) auto vkCreatePipelineLayout(VkDevice a_0, const VkPipelineLayoutCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPipelineLayout * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyPipelineLayout"))) auto vkDestroyPipelineLayout(VkDevice a_0, VkPipelineLayout a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateSampler"))) auto vkCreateSampler(VkDevice a_0, const VkSamplerCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSampler * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroySampler"))) auto vkDestroySampler(VkDevice a_0, VkSampler a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateDescriptorSetLayout"))) auto vkCreateDescriptorSetLayout(VkDevice a_0, const VkDescriptorSetLayoutCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorSetLayout * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDescriptorSetLayout"))) auto vkDestroyDescriptorSetLayout(VkDevice a_0, VkDescriptorSetLayout a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateDescriptorPool"))) auto vkCreateDescriptorPool(VkDevice a_0, const VkDescriptorPoolCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorPool * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDescriptorPool"))) auto vkDestroyDescriptorPool(VkDevice a_0, VkDescriptorPool a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkResetDescriptorPool"))) auto vkResetDescriptorPool(VkDevice a_0, VkDescriptorPool a_1, VkDescriptorPoolResetFlags a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkAllocateDescriptorSets"))) auto vkAllocateDescriptorSets(VkDevice a_0, const VkDescriptorSetAllocateInfo * a_1, VkDescriptorSet * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkFreeDescriptorSets"))) auto vkFreeDescriptorSets(VkDevice a_0, VkDescriptorPool a_1, uint32_t a_2, const VkDescriptorSet * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkUpdateDescriptorSets"))) auto vkUpdateDescriptorSets(VkDevice a_0, uint32_t a_1, const VkWriteDescriptorSet * a_2, uint32_t a_3, const VkCopyDescriptorSet * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindPipeline"))) auto vkCmdBindPipeline(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipeline a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindDescriptorSets"))) auto vkCmdBindDescriptorSets(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const VkDescriptorSet * a_5, uint32_t a_6, const uint32_t * a_7) -> void;
__attribute__((alias("fexfn_pack_vkCmdClearColorImage"))) auto vkCmdClearColorImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, const VkClearColorValue * a_3, uint32_t a_4, const VkImageSubresourceRange * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdDispatch"))) auto vkCmdDispatch(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdDispatchIndirect"))) auto vkCmdDispatchIndirect(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetEvent"))) auto vkCmdSetEvent(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdResetEvent"))) auto vkCmdResetEvent(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdWaitEvents"))) auto vkCmdWaitEvents(VkCommandBuffer a_0, uint32_t a_1, const VkEvent * a_2, VkPipelineStageFlags a_3, VkPipelineStageFlags a_4, uint32_t a_5, const VkMemoryBarrier * a_6, uint32_t a_7, const VkBufferMemoryBarrier * a_8, uint32_t a_9, const VkImageMemoryBarrier * a_10) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushConstants"))) auto vkCmdPushConstants(VkCommandBuffer a_0, VkPipelineLayout a_1, VkShaderStageFlags a_2, uint32_t a_3, uint32_t a_4, const void * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCreateGraphicsPipelines"))) auto vkCreateGraphicsPipelines(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkGraphicsPipelineCreateInfo * a_3, const VkAllocationCallbacks * a_4, VkPipeline * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateFramebuffer"))) auto vkCreateFramebuffer(VkDevice a_0, const VkFramebufferCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkFramebuffer * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyFramebuffer"))) auto vkDestroyFramebuffer(VkDevice a_0, VkFramebuffer a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateRenderPass"))) auto vkCreateRenderPass(VkDevice a_0, const VkRenderPassCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkRenderPass * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyRenderPass"))) auto vkDestroyRenderPass(VkDevice a_0, VkRenderPass a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetRenderAreaGranularity"))) auto vkGetRenderAreaGranularity(VkDevice a_0, VkRenderPass a_1, VkExtent2D * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetViewport"))) auto vkCmdSetViewport(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkViewport * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetScissor"))) auto vkCmdSetScissor(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkRect2D * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetLineWidth"))) auto vkCmdSetLineWidth(VkCommandBuffer a_0, float a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthBias"))) auto vkCmdSetDepthBias(VkCommandBuffer a_0, float a_1, float a_2, float a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetBlendConstants"))) auto vkCmdSetBlendConstants(VkCommandBuffer a_0, const float * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthBounds"))) auto vkCmdSetDepthBounds(VkCommandBuffer a_0, float a_1, float a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetStencilCompareMask"))) auto vkCmdSetStencilCompareMask(VkCommandBuffer a_0, VkStencilFaceFlags a_1, uint32_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetStencilWriteMask"))) auto vkCmdSetStencilWriteMask(VkCommandBuffer a_0, VkStencilFaceFlags a_1, uint32_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetStencilReference"))) auto vkCmdSetStencilReference(VkCommandBuffer a_0, VkStencilFaceFlags a_1, uint32_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindIndexBuffer"))) auto vkCmdBindIndexBuffer(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkIndexType a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindVertexBuffers"))) auto vkCmdBindVertexBuffers(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdDraw"))) auto vkCmdDraw(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndexed"))) auto vkCmdDrawIndexed(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, int32_t a_4, uint32_t a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndirect"))) auto vkCmdDrawIndirect(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndexedIndirect"))) auto vkCmdDrawIndexedIndirect(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdBlitImage"))) auto vkCmdBlitImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkImage a_3, VkImageLayout a_4, uint32_t a_5, const VkImageBlit * a_6, VkFilter a_7) -> void;
__attribute__((alias("fexfn_pack_vkCmdClearDepthStencilImage"))) auto vkCmdClearDepthStencilImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, const VkClearDepthStencilValue * a_3, uint32_t a_4, const VkImageSubresourceRange * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdClearAttachments"))) auto vkCmdClearAttachments(VkCommandBuffer a_0, uint32_t a_1, const VkClearAttachment * a_2, uint32_t a_3, const VkClearRect * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdResolveImage"))) auto vkCmdResolveImage(VkCommandBuffer a_0, VkImage a_1, VkImageLayout a_2, VkImage a_3, VkImageLayout a_4, uint32_t a_5, const VkImageResolve * a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginRenderPass"))) auto vkCmdBeginRenderPass(VkCommandBuffer a_0, const VkRenderPassBeginInfo * a_1, VkSubpassContents a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdNextSubpass"))) auto vkCmdNextSubpass(VkCommandBuffer a_0, VkSubpassContents a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndRenderPass"))) auto vkCmdEndRenderPass(VkCommandBuffer a_0) -> void;
__attribute__((alias("fexfn_pack_vkEnumerateInstanceVersion"))) auto vkEnumerateInstanceVersion(uint32_t * a_0) -> VkResult;
__attribute__((alias("fexfn_pack_vkBindBufferMemory2"))) auto vkBindBufferMemory2(VkDevice a_0, uint32_t a_1, const VkBindBufferMemoryInfo * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkBindImageMemory2"))) auto vkBindImageMemory2(VkDevice a_0, uint32_t a_1, const VkBindImageMemoryInfo * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDeviceGroupPeerMemoryFeatures"))) auto vkGetDeviceGroupPeerMemoryFeatures(VkDevice a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, VkPeerMemoryFeatureFlags * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDeviceMask"))) auto vkCmdSetDeviceMask(VkCommandBuffer a_0, uint32_t a_1) -> void;
__attribute__((alias("fexfn_pack_vkEnumeratePhysicalDeviceGroups"))) auto vkEnumeratePhysicalDeviceGroups(VkInstance a_0, uint32_t * a_1, VkPhysicalDeviceGroupProperties * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetImageMemoryRequirements2"))) auto vkGetImageMemoryRequirements2(VkDevice a_0, const VkImageMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetBufferMemoryRequirements2"))) auto vkGetBufferMemoryRequirements2(VkDevice a_0, const VkBufferMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageSparseMemoryRequirements2"))) auto vkGetImageSparseMemoryRequirements2(VkDevice a_0, const VkImageSparseMemoryRequirementsInfo2 * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceFeatures2"))) auto vkGetPhysicalDeviceFeatures2(VkPhysicalDevice a_0, VkPhysicalDeviceFeatures2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceProperties2"))) auto vkGetPhysicalDeviceProperties2(VkPhysicalDevice a_0, VkPhysicalDeviceProperties2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceFormatProperties2"))) auto vkGetPhysicalDeviceFormatProperties2(VkPhysicalDevice a_0, VkFormat a_1, VkFormatProperties2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceImageFormatProperties2"))) auto vkGetPhysicalDeviceImageFormatProperties2(VkPhysicalDevice a_0, const VkPhysicalDeviceImageFormatInfo2 * a_1, VkImageFormatProperties2 * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceQueueFamilyProperties2"))) auto vkGetPhysicalDeviceQueueFamilyProperties2(VkPhysicalDevice a_0, uint32_t * a_1, VkQueueFamilyProperties2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceMemoryProperties2"))) auto vkGetPhysicalDeviceMemoryProperties2(VkPhysicalDevice a_0, VkPhysicalDeviceMemoryProperties2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSparseImageFormatProperties2"))) auto vkGetPhysicalDeviceSparseImageFormatProperties2(VkPhysicalDevice a_0, const VkPhysicalDeviceSparseImageFormatInfo2 * a_1, uint32_t * a_2, VkSparseImageFormatProperties2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkTrimCommandPool"))) auto vkTrimCommandPool(VkDevice a_0, VkCommandPool a_1, VkCommandPoolTrimFlags a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceQueue2"))) auto vkGetDeviceQueue2(VkDevice a_0, const VkDeviceQueueInfo2 * a_1, VkQueue * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalBufferProperties"))) auto vkGetPhysicalDeviceExternalBufferProperties(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalBufferInfo * a_1, VkExternalBufferProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalFenceProperties"))) auto vkGetPhysicalDeviceExternalFenceProperties(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalFenceInfo * a_1, VkExternalFenceProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalSemaphoreProperties"))) auto vkGetPhysicalDeviceExternalSemaphoreProperties(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalSemaphoreInfo * a_1, VkExternalSemaphoreProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdDispatchBase"))) auto vkCmdDispatchBase(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkCreateDescriptorUpdateTemplate"))) auto vkCreateDescriptorUpdateTemplate(VkDevice a_0, const VkDescriptorUpdateTemplateCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorUpdateTemplate * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDescriptorUpdateTemplate"))) auto vkDestroyDescriptorUpdateTemplate(VkDevice a_0, VkDescriptorUpdateTemplate a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkUpdateDescriptorSetWithTemplate"))) auto vkUpdateDescriptorSetWithTemplate(VkDevice a_0, VkDescriptorSet a_1, VkDescriptorUpdateTemplate a_2, const void * a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetDescriptorSetLayoutSupport"))) auto vkGetDescriptorSetLayoutSupport(VkDevice a_0, const VkDescriptorSetLayoutCreateInfo * a_1, VkDescriptorSetLayoutSupport * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateSamplerYcbcrConversion"))) auto vkCreateSamplerYcbcrConversion(VkDevice a_0, const VkSamplerYcbcrConversionCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSamplerYcbcrConversion * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroySamplerYcbcrConversion"))) auto vkDestroySamplerYcbcrConversion(VkDevice a_0, VkSamplerYcbcrConversion a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkResetQueryPool"))) auto vkResetQueryPool(VkDevice a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetSemaphoreCounterValue"))) auto vkGetSemaphoreCounterValue(VkDevice a_0, VkSemaphore a_1, uint64_t * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkWaitSemaphores"))) auto vkWaitSemaphores(VkDevice a_0, const VkSemaphoreWaitInfo * a_1, uint64_t a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkSignalSemaphore"))) auto vkSignalSemaphore(VkDevice a_0, const VkSemaphoreSignalInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetBufferDeviceAddress"))) auto vkGetBufferDeviceAddress(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> VkDeviceAddress;
__attribute__((alias("fexfn_pack_vkGetBufferOpaqueCaptureAddress"))) auto vkGetBufferOpaqueCaptureAddress(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> uint64_t;
__attribute__((alias("fexfn_pack_vkGetDeviceMemoryOpaqueCaptureAddress"))) auto vkGetDeviceMemoryOpaqueCaptureAddress(VkDevice a_0, const VkDeviceMemoryOpaqueCaptureAddressInfo * a_1) -> uint64_t;
__attribute__((alias("fexfn_pack_vkCmdDrawIndirectCount"))) auto vkCmdDrawIndirectCount(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndexedIndirectCount"))) auto vkCmdDrawIndexedIndirectCount(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkCreateRenderPass2"))) auto vkCreateRenderPass2(VkDevice a_0, const VkRenderPassCreateInfo2 * a_1, const VkAllocationCallbacks * a_2, VkRenderPass * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdBeginRenderPass2"))) auto vkCmdBeginRenderPass2(VkCommandBuffer a_0, const VkRenderPassBeginInfo * a_1, const VkSubpassBeginInfo * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdNextSubpass2"))) auto vkCmdNextSubpass2(VkCommandBuffer a_0, const VkSubpassBeginInfo * a_1, const VkSubpassEndInfo * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndRenderPass2"))) auto vkCmdEndRenderPass2(VkCommandBuffer a_0, const VkSubpassEndInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceToolProperties"))) auto vkGetPhysicalDeviceToolProperties(VkPhysicalDevice a_0, uint32_t * a_1, VkPhysicalDeviceToolProperties * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreatePrivateDataSlot"))) auto vkCreatePrivateDataSlot(VkDevice a_0, const VkPrivateDataSlotCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPrivateDataSlot * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyPrivateDataSlot"))) auto vkDestroyPrivateDataSlot(VkDevice a_0, VkPrivateDataSlot a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkSetPrivateData"))) auto vkSetPrivateData(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPrivateData"))) auto vkGetPrivateData(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdPipelineBarrier2"))) auto vkCmdPipelineBarrier2(VkCommandBuffer a_0, const VkDependencyInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdWriteTimestamp2"))) auto vkCmdWriteTimestamp2(VkCommandBuffer a_0, VkPipelineStageFlags2 a_1, VkQueryPool a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkQueueSubmit2"))) auto vkQueueSubmit2(VkQueue a_0, uint32_t a_1, const VkSubmitInfo2 * a_2, VkFence a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdCopyBuffer2"))) auto vkCmdCopyBuffer2(VkCommandBuffer a_0, const VkCopyBufferInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyImage2"))) auto vkCmdCopyImage2(VkCommandBuffer a_0, const VkCopyImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyBufferToImage2"))) auto vkCmdCopyBufferToImage2(VkCommandBuffer a_0, const VkCopyBufferToImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyImageToBuffer2"))) auto vkCmdCopyImageToBuffer2(VkCommandBuffer a_0, const VkCopyImageToBufferInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceBufferMemoryRequirements"))) auto vkGetDeviceBufferMemoryRequirements(VkDevice a_0, const VkDeviceBufferMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceImageMemoryRequirements"))) auto vkGetDeviceImageMemoryRequirements(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceImageSparseMemoryRequirements"))) auto vkGetDeviceImageSparseMemoryRequirements(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetEvent2"))) auto vkCmdSetEvent2(VkCommandBuffer a_0, VkEvent a_1, const VkDependencyInfo * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdResetEvent2"))) auto vkCmdResetEvent2(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags2 a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdWaitEvents2"))) auto vkCmdWaitEvents2(VkCommandBuffer a_0, uint32_t a_1, const VkEvent * a_2, const VkDependencyInfo * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdBlitImage2"))) auto vkCmdBlitImage2(VkCommandBuffer a_0, const VkBlitImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdResolveImage2"))) auto vkCmdResolveImage2(VkCommandBuffer a_0, const VkResolveImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginRendering"))) auto vkCmdBeginRendering(VkCommandBuffer a_0, const VkRenderingInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndRendering"))) auto vkCmdEndRendering(VkCommandBuffer a_0) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCullMode"))) auto vkCmdSetCullMode(VkCommandBuffer a_0, VkCullModeFlags a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetFrontFace"))) auto vkCmdSetFrontFace(VkCommandBuffer a_0, VkFrontFace a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetPrimitiveTopology"))) auto vkCmdSetPrimitiveTopology(VkCommandBuffer a_0, VkPrimitiveTopology a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetViewportWithCount"))) auto vkCmdSetViewportWithCount(VkCommandBuffer a_0, uint32_t a_1, const VkViewport * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetScissorWithCount"))) auto vkCmdSetScissorWithCount(VkCommandBuffer a_0, uint32_t a_1, const VkRect2D * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindVertexBuffers2"))) auto vkCmdBindVertexBuffers2(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4, const VkDeviceSize * a_5, const VkDeviceSize * a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthTestEnable"))) auto vkCmdSetDepthTestEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthWriteEnable"))) auto vkCmdSetDepthWriteEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthCompareOp"))) auto vkCmdSetDepthCompareOp(VkCommandBuffer a_0, VkCompareOp a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthBoundsTestEnable"))) auto vkCmdSetDepthBoundsTestEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetStencilTestEnable"))) auto vkCmdSetStencilTestEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetStencilOp"))) auto vkCmdSetStencilOp(VkCommandBuffer a_0, VkStencilFaceFlags a_1, VkStencilOp a_2, VkStencilOp a_3, VkStencilOp a_4, VkCompareOp a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRasterizerDiscardEnable"))) auto vkCmdSetRasterizerDiscardEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthBiasEnable"))) auto vkCmdSetDepthBiasEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetPrimitiveRestartEnable"))) auto vkCmdSetPrimitiveRestartEnable(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkMapMemory2"))) auto vkMapMemory2(VkDevice a_0, const VkMemoryMapInfo * a_1, void ** a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkUnmapMemory2"))) auto vkUnmapMemory2(VkDevice a_0, const VkMemoryUnmapInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDeviceImageSubresourceLayout"))) auto vkGetDeviceImageSubresourceLayout(VkDevice a_0, const VkDeviceImageSubresourceInfo * a_1, VkSubresourceLayout2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageSubresourceLayout2"))) auto vkGetImageSubresourceLayout2(VkDevice a_0, VkImage a_1, const VkImageSubresource2 * a_2, VkSubresourceLayout2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCopyMemoryToImage"))) auto vkCopyMemoryToImage(VkDevice a_0, const VkCopyMemoryToImageInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyImageToMemory"))) auto vkCopyImageToMemory(VkDevice a_0, const VkCopyImageToMemoryInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyImageToImage"))) auto vkCopyImageToImage(VkDevice a_0, const VkCopyImageToImageInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkTransitionImageLayout"))) auto vkTransitionImageLayout(VkDevice a_0, uint32_t a_1, const VkHostImageLayoutTransitionInfo * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSet"))) auto vkCmdPushDescriptorSet(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const VkWriteDescriptorSet * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSetWithTemplate"))) auto vkCmdPushDescriptorSetWithTemplate(VkCommandBuffer a_0, VkDescriptorUpdateTemplate a_1, VkPipelineLayout a_2, uint32_t a_3, const void * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindDescriptorSets2"))) auto vkCmdBindDescriptorSets2(VkCommandBuffer a_0, const VkBindDescriptorSetsInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushConstants2"))) auto vkCmdPushConstants2(VkCommandBuffer a_0, const VkPushConstantsInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSet2"))) auto vkCmdPushDescriptorSet2(VkCommandBuffer a_0, const VkPushDescriptorSetInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSetWithTemplate2"))) auto vkCmdPushDescriptorSetWithTemplate2(VkCommandBuffer a_0, const VkPushDescriptorSetWithTemplateInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetLineStipple"))) auto vkCmdSetLineStipple(VkCommandBuffer a_0, uint32_t a_1, uint16_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindIndexBuffer2"))) auto vkCmdBindIndexBuffer2(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, VkIndexType a_4) -> void;
__attribute__((alias("fexfn_pack_vkGetRenderingAreaGranularity"))) auto vkGetRenderingAreaGranularity(VkDevice a_0, const VkRenderingAreaInfo * a_1, VkExtent2D * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRenderingAttachmentLocations"))) auto vkCmdSetRenderingAttachmentLocations(VkCommandBuffer a_0, const VkRenderingAttachmentLocationInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRenderingInputAttachmentIndices"))) auto vkCmdSetRenderingInputAttachmentIndices(VkCommandBuffer a_0, const VkRenderingInputAttachmentIndexInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkDestroySurfaceKHR"))) auto vkDestroySurfaceKHR(VkInstance a_0, VkSurfaceKHR a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSurfaceSupportKHR"))) auto vkGetPhysicalDeviceSurfaceSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, VkSurfaceKHR a_2, VkBool32 * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSurfaceCapabilitiesKHR"))) auto vkGetPhysicalDeviceSurfaceCapabilitiesKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, VkSurfaceCapabilitiesKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSurfaceFormatsKHR"))) auto vkGetPhysicalDeviceSurfaceFormatsKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, uint32_t * a_2, VkSurfaceFormatKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSurfacePresentModesKHR"))) auto vkGetPhysicalDeviceSurfacePresentModesKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, uint32_t * a_2, VkPresentModeKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateSwapchainKHR"))) auto vkCreateSwapchainKHR(VkDevice a_0, const VkSwapchainCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSwapchainKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroySwapchainKHR"))) auto vkDestroySwapchainKHR(VkDevice a_0, VkSwapchainKHR a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetSwapchainImagesKHR"))) auto vkGetSwapchainImagesKHR(VkDevice a_0, VkSwapchainKHR a_1, uint32_t * a_2, VkImage * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkAcquireNextImageKHR"))) auto vkAcquireNextImageKHR(VkDevice a_0, VkSwapchainKHR a_1, uint64_t a_2, VkSemaphore a_3, VkFence a_4, uint32_t * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkQueuePresentKHR"))) auto vkQueuePresentKHR(VkQueue a_0, const VkPresentInfoKHR * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDeviceGroupPresentCapabilitiesKHR"))) auto vkGetDeviceGroupPresentCapabilitiesKHR(VkDevice a_0, VkDeviceGroupPresentCapabilitiesKHR * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDeviceGroupSurfacePresentModesKHR"))) auto vkGetDeviceGroupSurfacePresentModesKHR(VkDevice a_0, VkSurfaceKHR a_1, VkDeviceGroupPresentModeFlagsKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDevicePresentRectanglesKHR"))) auto vkGetPhysicalDevicePresentRectanglesKHR(VkPhysicalDevice a_0, VkSurfaceKHR a_1, uint32_t * a_2, VkRect2D * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkAcquireNextImage2KHR"))) auto vkAcquireNextImage2KHR(VkDevice a_0, const VkAcquireNextImageInfoKHR * a_1, uint32_t * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceDisplayPropertiesKHR"))) auto vkGetPhysicalDeviceDisplayPropertiesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayPropertiesKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceDisplayPlanePropertiesKHR"))) auto vkGetPhysicalDeviceDisplayPlanePropertiesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayPlanePropertiesKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDisplayPlaneSupportedDisplaysKHR"))) auto vkGetDisplayPlaneSupportedDisplaysKHR(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkDisplayKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDisplayModePropertiesKHR"))) auto vkGetDisplayModePropertiesKHR(VkPhysicalDevice a_0, VkDisplayKHR a_1, uint32_t * a_2, VkDisplayModePropertiesKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateDisplayModeKHR"))) auto vkCreateDisplayModeKHR(VkPhysicalDevice a_0, VkDisplayKHR a_1, const VkDisplayModeCreateInfoKHR * a_2, const VkAllocationCallbacks * a_3, VkDisplayModeKHR * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDisplayPlaneCapabilitiesKHR"))) auto vkGetDisplayPlaneCapabilitiesKHR(VkPhysicalDevice a_0, VkDisplayModeKHR a_1, uint32_t a_2, VkDisplayPlaneCapabilitiesKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateDisplayPlaneSurfaceKHR"))) auto vkCreateDisplayPlaneSurfaceKHR(VkInstance a_0, const VkDisplaySurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateSharedSwapchainsKHR"))) auto vkCreateSharedSwapchainsKHR(VkDevice a_0, uint32_t a_1, const VkSwapchainCreateInfoKHR * a_2, const VkAllocationCallbacks * a_3, VkSwapchainKHR * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceVideoCapabilitiesKHR"))) auto vkGetPhysicalDeviceVideoCapabilitiesKHR(VkPhysicalDevice a_0, const VkVideoProfileInfoKHR * a_1, VkVideoCapabilitiesKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceVideoFormatPropertiesKHR"))) auto vkGetPhysicalDeviceVideoFormatPropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceVideoFormatInfoKHR * a_1, uint32_t * a_2, VkVideoFormatPropertiesKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateVideoSessionKHR"))) auto vkCreateVideoSessionKHR(VkDevice a_0, const VkVideoSessionCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkVideoSessionKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyVideoSessionKHR"))) auto vkDestroyVideoSessionKHR(VkDevice a_0, VkVideoSessionKHR a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetVideoSessionMemoryRequirementsKHR"))) auto vkGetVideoSessionMemoryRequirementsKHR(VkDevice a_0, VkVideoSessionKHR a_1, uint32_t * a_2, VkVideoSessionMemoryRequirementsKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkBindVideoSessionMemoryKHR"))) auto vkBindVideoSessionMemoryKHR(VkDevice a_0, VkVideoSessionKHR a_1, uint32_t a_2, const VkBindVideoSessionMemoryInfoKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateVideoSessionParametersKHR"))) auto vkCreateVideoSessionParametersKHR(VkDevice a_0, const VkVideoSessionParametersCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkVideoSessionParametersKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkUpdateVideoSessionParametersKHR"))) auto vkUpdateVideoSessionParametersKHR(VkDevice a_0, VkVideoSessionParametersKHR a_1, const VkVideoSessionParametersUpdateInfoKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyVideoSessionParametersKHR"))) auto vkDestroyVideoSessionParametersKHR(VkDevice a_0, VkVideoSessionParametersKHR a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginVideoCodingKHR"))) auto vkCmdBeginVideoCodingKHR(VkCommandBuffer a_0, const VkVideoBeginCodingInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndVideoCodingKHR"))) auto vkCmdEndVideoCodingKHR(VkCommandBuffer a_0, const VkVideoEndCodingInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdControlVideoCodingKHR"))) auto vkCmdControlVideoCodingKHR(VkCommandBuffer a_0, const VkVideoCodingControlInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdDecodeVideoKHR"))) auto vkCmdDecodeVideoKHR(VkCommandBuffer a_0, const VkVideoDecodeInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginRenderingKHR"))) auto vkCmdBeginRenderingKHR(VkCommandBuffer a_0, const VkRenderingInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndRenderingKHR"))) auto vkCmdEndRenderingKHR(VkCommandBuffer a_0) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceFeatures2KHR"))) auto vkGetPhysicalDeviceFeatures2KHR(VkPhysicalDevice a_0, VkPhysicalDeviceFeatures2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceProperties2KHR"))) auto vkGetPhysicalDeviceProperties2KHR(VkPhysicalDevice a_0, VkPhysicalDeviceProperties2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceFormatProperties2KHR"))) auto vkGetPhysicalDeviceFormatProperties2KHR(VkPhysicalDevice a_0, VkFormat a_1, VkFormatProperties2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceImageFormatProperties2KHR"))) auto vkGetPhysicalDeviceImageFormatProperties2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceImageFormatInfo2 * a_1, VkImageFormatProperties2 * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceQueueFamilyProperties2KHR"))) auto vkGetPhysicalDeviceQueueFamilyProperties2KHR(VkPhysicalDevice a_0, uint32_t * a_1, VkQueueFamilyProperties2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceMemoryProperties2KHR"))) auto vkGetPhysicalDeviceMemoryProperties2KHR(VkPhysicalDevice a_0, VkPhysicalDeviceMemoryProperties2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSparseImageFormatProperties2KHR"))) auto vkGetPhysicalDeviceSparseImageFormatProperties2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceSparseImageFormatInfo2 * a_1, uint32_t * a_2, VkSparseImageFormatProperties2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceGroupPeerMemoryFeaturesKHR"))) auto vkGetDeviceGroupPeerMemoryFeaturesKHR(VkDevice a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, VkPeerMemoryFeatureFlags * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDeviceMaskKHR"))) auto vkCmdSetDeviceMaskKHR(VkCommandBuffer a_0, uint32_t a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdDispatchBaseKHR"))) auto vkCmdDispatchBaseKHR(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkTrimCommandPoolKHR"))) auto vkTrimCommandPoolKHR(VkDevice a_0, VkCommandPool a_1, VkCommandPoolTrimFlags a_2) -> void;
__attribute__((alias("fexfn_pack_vkEnumeratePhysicalDeviceGroupsKHR"))) auto vkEnumeratePhysicalDeviceGroupsKHR(VkInstance a_0, uint32_t * a_1, VkPhysicalDeviceGroupProperties * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalBufferPropertiesKHR"))) auto vkGetPhysicalDeviceExternalBufferPropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalBufferInfo * a_1, VkExternalBufferProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetMemoryFdKHR"))) auto vkGetMemoryFdKHR(VkDevice a_0, const VkMemoryGetFdInfoKHR * a_1, int * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetMemoryFdPropertiesKHR"))) auto vkGetMemoryFdPropertiesKHR(VkDevice a_0, VkExternalMemoryHandleTypeFlagBits a_1, int a_2, VkMemoryFdPropertiesKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalSemaphorePropertiesKHR"))) auto vkGetPhysicalDeviceExternalSemaphorePropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalSemaphoreInfo * a_1, VkExternalSemaphoreProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkImportSemaphoreFdKHR"))) auto vkImportSemaphoreFdKHR(VkDevice a_0, const VkImportSemaphoreFdInfoKHR * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetSemaphoreFdKHR"))) auto vkGetSemaphoreFdKHR(VkDevice a_0, const VkSemaphoreGetFdInfoKHR * a_1, int * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSetKHR"))) auto vkCmdPushDescriptorSetKHR(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const VkWriteDescriptorSet * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSetWithTemplateKHR"))) auto vkCmdPushDescriptorSetWithTemplateKHR(VkCommandBuffer a_0, VkDescriptorUpdateTemplate a_1, VkPipelineLayout a_2, uint32_t a_3, const void * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCreateDescriptorUpdateTemplateKHR"))) auto vkCreateDescriptorUpdateTemplateKHR(VkDevice a_0, const VkDescriptorUpdateTemplateCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkDescriptorUpdateTemplate * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDescriptorUpdateTemplateKHR"))) auto vkDestroyDescriptorUpdateTemplateKHR(VkDevice a_0, VkDescriptorUpdateTemplate a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkUpdateDescriptorSetWithTemplateKHR"))) auto vkUpdateDescriptorSetWithTemplateKHR(VkDevice a_0, VkDescriptorSet a_1, VkDescriptorUpdateTemplate a_2, const void * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCreateRenderPass2KHR"))) auto vkCreateRenderPass2KHR(VkDevice a_0, const VkRenderPassCreateInfo2 * a_1, const VkAllocationCallbacks * a_2, VkRenderPass * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdBeginRenderPass2KHR"))) auto vkCmdBeginRenderPass2KHR(VkCommandBuffer a_0, const VkRenderPassBeginInfo * a_1, const VkSubpassBeginInfo * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdNextSubpass2KHR"))) auto vkCmdNextSubpass2KHR(VkCommandBuffer a_0, const VkSubpassBeginInfo * a_1, const VkSubpassEndInfo * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndRenderPass2KHR"))) auto vkCmdEndRenderPass2KHR(VkCommandBuffer a_0, const VkSubpassEndInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetSwapchainStatusKHR"))) auto vkGetSwapchainStatusKHR(VkDevice a_0, VkSwapchainKHR a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalFencePropertiesKHR"))) auto vkGetPhysicalDeviceExternalFencePropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalFenceInfo * a_1, VkExternalFenceProperties * a_2) -> void;
__attribute__((alias("fexfn_pack_vkImportFenceFdKHR"))) auto vkImportFenceFdKHR(VkDevice a_0, const VkImportFenceFdInfoKHR * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetFenceFdKHR"))) auto vkGetFenceFdKHR(VkDevice a_0, const VkFenceGetFdInfoKHR * a_1, int * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR"))) auto vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkPerformanceCounterKHR * a_3, VkPerformanceCounterDescriptionKHR * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR"))) auto vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR(VkPhysicalDevice a_0, const VkQueryPoolPerformanceCreateInfoKHR * a_1, uint32_t * a_2) -> void;
__attribute__((alias("fexfn_pack_vkAcquireProfilingLockKHR"))) auto vkAcquireProfilingLockKHR(VkDevice a_0, const VkAcquireProfilingLockInfoKHR * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkReleaseProfilingLockKHR"))) auto vkReleaseProfilingLockKHR(VkDevice a_0) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSurfaceCapabilities2KHR"))) auto vkGetPhysicalDeviceSurfaceCapabilities2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceSurfaceInfo2KHR * a_1, VkSurfaceCapabilities2KHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSurfaceFormats2KHR"))) auto vkGetPhysicalDeviceSurfaceFormats2KHR(VkPhysicalDevice a_0, const VkPhysicalDeviceSurfaceInfo2KHR * a_1, uint32_t * a_2, VkSurfaceFormat2KHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceDisplayProperties2KHR"))) auto vkGetPhysicalDeviceDisplayProperties2KHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayProperties2KHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceDisplayPlaneProperties2KHR"))) auto vkGetPhysicalDeviceDisplayPlaneProperties2KHR(VkPhysicalDevice a_0, uint32_t * a_1, VkDisplayPlaneProperties2KHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDisplayModeProperties2KHR"))) auto vkGetDisplayModeProperties2KHR(VkPhysicalDevice a_0, VkDisplayKHR a_1, uint32_t * a_2, VkDisplayModeProperties2KHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDisplayPlaneCapabilities2KHR"))) auto vkGetDisplayPlaneCapabilities2KHR(VkPhysicalDevice a_0, const VkDisplayPlaneInfo2KHR * a_1, VkDisplayPlaneCapabilities2KHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetImageMemoryRequirements2KHR"))) auto vkGetImageMemoryRequirements2KHR(VkDevice a_0, const VkImageMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetBufferMemoryRequirements2KHR"))) auto vkGetBufferMemoryRequirements2KHR(VkDevice a_0, const VkBufferMemoryRequirementsInfo2 * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageSparseMemoryRequirements2KHR"))) auto vkGetImageSparseMemoryRequirements2KHR(VkDevice a_0, const VkImageSparseMemoryRequirementsInfo2 * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCreateSamplerYcbcrConversionKHR"))) auto vkCreateSamplerYcbcrConversionKHR(VkDevice a_0, const VkSamplerYcbcrConversionCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkSamplerYcbcrConversion * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroySamplerYcbcrConversionKHR"))) auto vkDestroySamplerYcbcrConversionKHR(VkDevice a_0, VkSamplerYcbcrConversion a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkBindBufferMemory2KHR"))) auto vkBindBufferMemory2KHR(VkDevice a_0, uint32_t a_1, const VkBindBufferMemoryInfo * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkBindImageMemory2KHR"))) auto vkBindImageMemory2KHR(VkDevice a_0, uint32_t a_1, const VkBindImageMemoryInfo * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDescriptorSetLayoutSupportKHR"))) auto vkGetDescriptorSetLayoutSupportKHR(VkDevice a_0, const VkDescriptorSetLayoutCreateInfo * a_1, VkDescriptorSetLayoutSupport * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndirectCountKHR"))) auto vkCmdDrawIndirectCountKHR(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndexedIndirectCountKHR"))) auto vkCmdDrawIndexedIndirectCountKHR(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkGetSemaphoreCounterValueKHR"))) auto vkGetSemaphoreCounterValueKHR(VkDevice a_0, VkSemaphore a_1, uint64_t * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkWaitSemaphoresKHR"))) auto vkWaitSemaphoresKHR(VkDevice a_0, const VkSemaphoreWaitInfo * a_1, uint64_t a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkSignalSemaphoreKHR"))) auto vkSignalSemaphoreKHR(VkDevice a_0, const VkSemaphoreSignalInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceFragmentShadingRatesKHR"))) auto vkGetPhysicalDeviceFragmentShadingRatesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkPhysicalDeviceFragmentShadingRateKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetFragmentShadingRateKHR"))) auto vkCmdSetFragmentShadingRateKHR(VkCommandBuffer a_0, const VkExtent2D * a_1, const VkFragmentShadingRateCombinerOpKHR * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRenderingAttachmentLocationsKHR"))) auto vkCmdSetRenderingAttachmentLocationsKHR(VkCommandBuffer a_0, const VkRenderingAttachmentLocationInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRenderingInputAttachmentIndicesKHR"))) auto vkCmdSetRenderingInputAttachmentIndicesKHR(VkCommandBuffer a_0, const VkRenderingInputAttachmentIndexInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkWaitForPresentKHR"))) auto vkWaitForPresentKHR(VkDevice a_0, VkSwapchainKHR a_1, uint64_t a_2, uint64_t a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetBufferDeviceAddressKHR"))) auto vkGetBufferDeviceAddressKHR(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> VkDeviceAddress;
__attribute__((alias("fexfn_pack_vkGetBufferOpaqueCaptureAddressKHR"))) auto vkGetBufferOpaqueCaptureAddressKHR(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> uint64_t;
__attribute__((alias("fexfn_pack_vkGetDeviceMemoryOpaqueCaptureAddressKHR"))) auto vkGetDeviceMemoryOpaqueCaptureAddressKHR(VkDevice a_0, const VkDeviceMemoryOpaqueCaptureAddressInfo * a_1) -> uint64_t;
__attribute__((alias("fexfn_pack_vkCreateDeferredOperationKHR"))) auto vkCreateDeferredOperationKHR(VkDevice a_0, const VkAllocationCallbacks * a_1, VkDeferredOperationKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDeferredOperationKHR"))) auto vkDestroyDeferredOperationKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeferredOperationMaxConcurrencyKHR"))) auto vkGetDeferredOperationMaxConcurrencyKHR(VkDevice a_0, VkDeferredOperationKHR a_1) -> uint32_t;
__attribute__((alias("fexfn_pack_vkGetDeferredOperationResultKHR"))) auto vkGetDeferredOperationResultKHR(VkDevice a_0, VkDeferredOperationKHR a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkDeferredOperationJoinKHR"))) auto vkDeferredOperationJoinKHR(VkDevice a_0, VkDeferredOperationKHR a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPipelineExecutablePropertiesKHR"))) auto vkGetPipelineExecutablePropertiesKHR(VkDevice a_0, const VkPipelineInfoKHR * a_1, uint32_t * a_2, VkPipelineExecutablePropertiesKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPipelineExecutableStatisticsKHR"))) auto vkGetPipelineExecutableStatisticsKHR(VkDevice a_0, const VkPipelineExecutableInfoKHR * a_1, uint32_t * a_2, VkPipelineExecutableStatisticKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPipelineExecutableInternalRepresentationsKHR"))) auto vkGetPipelineExecutableInternalRepresentationsKHR(VkDevice a_0, const VkPipelineExecutableInfoKHR * a_1, uint32_t * a_2, VkPipelineExecutableInternalRepresentationKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkMapMemory2KHR"))) auto vkMapMemory2KHR(VkDevice a_0, const VkMemoryMapInfo * a_1, void ** a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkUnmapMemory2KHR"))) auto vkUnmapMemory2KHR(VkDevice a_0, const VkMemoryUnmapInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceVideoEncodeQualityLevelPropertiesKHR"))) auto vkGetPhysicalDeviceVideoEncodeQualityLevelPropertiesKHR(VkPhysicalDevice a_0, const VkPhysicalDeviceVideoEncodeQualityLevelInfoKHR * a_1, VkVideoEncodeQualityLevelPropertiesKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetEncodedVideoSessionParametersKHR"))) auto vkGetEncodedVideoSessionParametersKHR(VkDevice a_0, const VkVideoEncodeSessionParametersGetInfoKHR * a_1, VkVideoEncodeSessionParametersFeedbackInfoKHR * a_2, size_t * a_3, void * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdEncodeVideoKHR"))) auto vkCmdEncodeVideoKHR(VkCommandBuffer a_0, const VkVideoEncodeInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetEvent2KHR"))) auto vkCmdSetEvent2KHR(VkCommandBuffer a_0, VkEvent a_1, const VkDependencyInfo * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdResetEvent2KHR"))) auto vkCmdResetEvent2KHR(VkCommandBuffer a_0, VkEvent a_1, VkPipelineStageFlags2 a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdWaitEvents2KHR"))) auto vkCmdWaitEvents2KHR(VkCommandBuffer a_0, uint32_t a_1, const VkEvent * a_2, const VkDependencyInfo * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdPipelineBarrier2KHR"))) auto vkCmdPipelineBarrier2KHR(VkCommandBuffer a_0, const VkDependencyInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdWriteTimestamp2KHR"))) auto vkCmdWriteTimestamp2KHR(VkCommandBuffer a_0, VkPipelineStageFlags2 a_1, VkQueryPool a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkQueueSubmit2KHR"))) auto vkQueueSubmit2KHR(VkQueue a_0, uint32_t a_1, const VkSubmitInfo2 * a_2, VkFence a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdCopyBuffer2KHR"))) auto vkCmdCopyBuffer2KHR(VkCommandBuffer a_0, const VkCopyBufferInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyImage2KHR"))) auto vkCmdCopyImage2KHR(VkCommandBuffer a_0, const VkCopyImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyBufferToImage2KHR"))) auto vkCmdCopyBufferToImage2KHR(VkCommandBuffer a_0, const VkCopyBufferToImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyImageToBuffer2KHR"))) auto vkCmdCopyImageToBuffer2KHR(VkCommandBuffer a_0, const VkCopyImageToBufferInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBlitImage2KHR"))) auto vkCmdBlitImage2KHR(VkCommandBuffer a_0, const VkBlitImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdResolveImage2KHR"))) auto vkCmdResolveImage2KHR(VkCommandBuffer a_0, const VkResolveImageInfo2 * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdTraceRaysIndirect2KHR"))) auto vkCmdTraceRaysIndirect2KHR(VkCommandBuffer a_0, VkDeviceAddress a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceBufferMemoryRequirementsKHR"))) auto vkGetDeviceBufferMemoryRequirementsKHR(VkDevice a_0, const VkDeviceBufferMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceImageMemoryRequirementsKHR"))) auto vkGetDeviceImageMemoryRequirementsKHR(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceImageSparseMemoryRequirementsKHR"))) auto vkGetDeviceImageSparseMemoryRequirementsKHR(VkDevice a_0, const VkDeviceImageMemoryRequirements * a_1, uint32_t * a_2, VkSparseImageMemoryRequirements2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindIndexBuffer2KHR"))) auto vkCmdBindIndexBuffer2KHR(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkDeviceSize a_3, VkIndexType a_4) -> void;
__attribute__((alias("fexfn_pack_vkGetRenderingAreaGranularityKHR"))) auto vkGetRenderingAreaGranularityKHR(VkDevice a_0, const VkRenderingAreaInfo * a_1, VkExtent2D * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceImageSubresourceLayoutKHR"))) auto vkGetDeviceImageSubresourceLayoutKHR(VkDevice a_0, const VkDeviceImageSubresourceInfo * a_1, VkSubresourceLayout2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageSubresourceLayout2KHR"))) auto vkGetImageSubresourceLayout2KHR(VkDevice a_0, VkImage a_1, const VkImageSubresource2 * a_2, VkSubresourceLayout2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkWaitForPresent2KHR"))) auto vkWaitForPresent2KHR(VkDevice a_0, VkSwapchainKHR a_1, const VkPresentWait2InfoKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreatePipelineBinariesKHR"))) auto vkCreatePipelineBinariesKHR(VkDevice a_0, const VkPipelineBinaryCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkPipelineBinaryHandlesInfoKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyPipelineBinaryKHR"))) auto vkDestroyPipelineBinaryKHR(VkDevice a_0, VkPipelineBinaryKHR a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPipelineKeyKHR"))) auto vkGetPipelineKeyKHR(VkDevice a_0, const VkPipelineCreateInfoKHR * a_1, VkPipelineBinaryKeyKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPipelineBinaryDataKHR"))) auto vkGetPipelineBinaryDataKHR(VkDevice a_0, const VkPipelineBinaryDataInfoKHR * a_1, VkPipelineBinaryKeyKHR * a_2, size_t * a_3, void * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkReleaseCapturedPipelineDataKHR"))) auto vkReleaseCapturedPipelineDataKHR(VkDevice a_0, const VkReleaseCapturedPipelineDataInfoKHR * a_1, const VkAllocationCallbacks * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkReleaseSwapchainImagesKHR"))) auto vkReleaseSwapchainImagesKHR(VkDevice a_0, const VkReleaseSwapchainImagesInfoKHR * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceCooperativeMatrixPropertiesKHR"))) auto vkGetPhysicalDeviceCooperativeMatrixPropertiesKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeMatrixPropertiesKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetLineStippleKHR"))) auto vkCmdSetLineStippleKHR(VkCommandBuffer a_0, uint32_t a_1, uint16_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceCalibrateableTimeDomainsKHR"))) auto vkGetPhysicalDeviceCalibrateableTimeDomainsKHR(VkPhysicalDevice a_0, uint32_t * a_1, VkTimeDomainKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetCalibratedTimestampsKHR"))) auto vkGetCalibratedTimestampsKHR(VkDevice a_0, uint32_t a_1, const VkCalibratedTimestampInfoKHR * a_2, uint64_t * a_3, uint64_t * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdBindDescriptorSets2KHR"))) auto vkCmdBindDescriptorSets2KHR(VkCommandBuffer a_0, const VkBindDescriptorSetsInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushConstants2KHR"))) auto vkCmdPushConstants2KHR(VkCommandBuffer a_0, const VkPushConstantsInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSet2KHR"))) auto vkCmdPushDescriptorSet2KHR(VkCommandBuffer a_0, const VkPushDescriptorSetInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdPushDescriptorSetWithTemplate2KHR"))) auto vkCmdPushDescriptorSetWithTemplate2KHR(VkCommandBuffer a_0, const VkPushDescriptorSetWithTemplateInfo * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDescriptorBufferOffsets2EXT"))) auto vkCmdSetDescriptorBufferOffsets2EXT(VkCommandBuffer a_0, const VkSetDescriptorBufferOffsetsInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindDescriptorBufferEmbeddedSamplers2EXT"))) auto vkCmdBindDescriptorBufferEmbeddedSamplers2EXT(VkCommandBuffer a_0, const VkBindDescriptorBufferEmbeddedSamplersInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyMemoryIndirectKHR"))) auto vkCmdCopyMemoryIndirectKHR(VkCommandBuffer a_0, const VkCopyMemoryIndirectInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyMemoryToImageIndirectKHR"))) auto vkCmdCopyMemoryToImageIndirectKHR(VkCommandBuffer a_0, const VkCopyMemoryToImageIndirectInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndRendering2KHR"))) auto vkCmdEndRendering2KHR(VkCommandBuffer a_0, const VkRenderingEndInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCreateDebugReportCallbackEXT"))) auto vkCreateDebugReportCallbackEXT(VkInstance a_0, const VkDebugReportCallbackCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkDebugReportCallbackEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDebugReportCallbackEXT"))) auto vkDestroyDebugReportCallbackEXT(VkInstance a_0, VkDebugReportCallbackEXT a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkDebugReportMessageEXT"))) auto vkDebugReportMessageEXT(VkInstance a_0, VkDebugReportFlagsEXT a_1, VkDebugReportObjectTypeEXT a_2, uint64_t a_3, size_t a_4, int32_t a_5, const char * a_6, const char * a_7) -> void;
__attribute__((alias("fexfn_pack_vkDebugMarkerSetObjectTagEXT"))) auto vkDebugMarkerSetObjectTagEXT(VkDevice a_0, const VkDebugMarkerObjectTagInfoEXT * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkDebugMarkerSetObjectNameEXT"))) auto vkDebugMarkerSetObjectNameEXT(VkDevice a_0, const VkDebugMarkerObjectNameInfoEXT * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdDebugMarkerBeginEXT"))) auto vkCmdDebugMarkerBeginEXT(VkCommandBuffer a_0, const VkDebugMarkerMarkerInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdDebugMarkerEndEXT"))) auto vkCmdDebugMarkerEndEXT(VkCommandBuffer a_0) -> void;
__attribute__((alias("fexfn_pack_vkCmdDebugMarkerInsertEXT"))) auto vkCmdDebugMarkerInsertEXT(VkCommandBuffer a_0, const VkDebugMarkerMarkerInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindTransformFeedbackBuffersEXT"))) auto vkCmdBindTransformFeedbackBuffersEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4, const VkDeviceSize * a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginTransformFeedbackEXT"))) auto vkCmdBeginTransformFeedbackEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndTransformFeedbackEXT"))) auto vkCmdEndTransformFeedbackEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginQueryIndexedEXT"))) auto vkCmdBeginQueryIndexedEXT(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, VkQueryControlFlags a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndQueryIndexedEXT"))) auto vkCmdEndQueryIndexedEXT(VkCommandBuffer a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndirectByteCountEXT"))) auto vkCmdDrawIndirectByteCountEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkCreateCuModuleNVX"))) auto vkCreateCuModuleNVX(VkDevice a_0, const VkCuModuleCreateInfoNVX * a_1, const VkAllocationCallbacks * a_2, VkCuModuleNVX * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateCuFunctionNVX"))) auto vkCreateCuFunctionNVX(VkDevice a_0, const VkCuFunctionCreateInfoNVX * a_1, const VkAllocationCallbacks * a_2, VkCuFunctionNVX * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyCuModuleNVX"))) auto vkDestroyCuModuleNVX(VkDevice a_0, VkCuModuleNVX a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkDestroyCuFunctionNVX"))) auto vkDestroyCuFunctionNVX(VkDevice a_0, VkCuFunctionNVX a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdCuLaunchKernelNVX"))) auto vkCmdCuLaunchKernelNVX(VkCommandBuffer a_0, const VkCuLaunchInfoNVX * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetImageViewHandleNVX"))) auto vkGetImageViewHandleNVX(VkDevice a_0, const VkImageViewHandleInfoNVX * a_1) -> uint32_t;
__attribute__((alias("fexfn_pack_vkGetImageViewHandle64NVX"))) auto vkGetImageViewHandle64NVX(VkDevice a_0, const VkImageViewHandleInfoNVX * a_1) -> uint64_t;
__attribute__((alias("fexfn_pack_vkGetImageViewAddressNVX"))) auto vkGetImageViewAddressNVX(VkDevice a_0, VkImageView a_1, VkImageViewAddressPropertiesNVX * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdDrawIndirectCountAMD"))) auto vkCmdDrawIndirectCountAMD(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawIndexedIndirectCountAMD"))) auto vkCmdDrawIndexedIndirectCountAMD(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkGetShaderInfoAMD"))) auto vkGetShaderInfoAMD(VkDevice a_0, VkPipeline a_1, VkShaderStageFlagBits a_2, VkShaderInfoTypeAMD a_3, size_t * a_4, void * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalImageFormatPropertiesNV"))) auto vkGetPhysicalDeviceExternalImageFormatPropertiesNV(VkPhysicalDevice a_0, VkFormat a_1, VkImageType a_2, VkImageTiling a_3, VkImageUsageFlags a_4, VkImageCreateFlags a_5, VkExternalMemoryHandleTypeFlagsNV a_6, VkExternalImageFormatPropertiesNV * a_7) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdBeginConditionalRenderingEXT"))) auto vkCmdBeginConditionalRenderingEXT(VkCommandBuffer a_0, const VkConditionalRenderingBeginInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndConditionalRenderingEXT"))) auto vkCmdEndConditionalRenderingEXT(VkCommandBuffer a_0) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetViewportWScalingNV"))) auto vkCmdSetViewportWScalingNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkViewportWScalingNV * a_3) -> void;
__attribute__((alias("fexfn_pack_vkReleaseDisplayEXT"))) auto vkReleaseDisplayEXT(VkPhysicalDevice a_0, VkDisplayKHR a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSurfaceCapabilities2EXT"))) auto vkGetPhysicalDeviceSurfaceCapabilities2EXT(VkPhysicalDevice a_0, VkSurfaceKHR a_1, VkSurfaceCapabilities2EXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkDisplayPowerControlEXT"))) auto vkDisplayPowerControlEXT(VkDevice a_0, VkDisplayKHR a_1, const VkDisplayPowerInfoEXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkRegisterDeviceEventEXT"))) auto vkRegisterDeviceEventEXT(VkDevice a_0, const VkDeviceEventInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkFence * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkRegisterDisplayEventEXT"))) auto vkRegisterDisplayEventEXT(VkDevice a_0, VkDisplayKHR a_1, const VkDisplayEventInfoEXT * a_2, const VkAllocationCallbacks * a_3, VkFence * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetSwapchainCounterEXT"))) auto vkGetSwapchainCounterEXT(VkDevice a_0, VkSwapchainKHR a_1, VkSurfaceCounterFlagBitsEXT a_2, uint64_t * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetRefreshCycleDurationGOOGLE"))) auto vkGetRefreshCycleDurationGOOGLE(VkDevice a_0, VkSwapchainKHR a_1, VkRefreshCycleDurationGOOGLE * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPastPresentationTimingGOOGLE"))) auto vkGetPastPresentationTimingGOOGLE(VkDevice a_0, VkSwapchainKHR a_1, uint32_t * a_2, VkPastPresentationTimingGOOGLE * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetDiscardRectangleEXT"))) auto vkCmdSetDiscardRectangleEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkRect2D * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDiscardRectangleEnableEXT"))) auto vkCmdSetDiscardRectangleEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDiscardRectangleModeEXT"))) auto vkCmdSetDiscardRectangleModeEXT(VkCommandBuffer a_0, VkDiscardRectangleModeEXT a_1) -> void;
__attribute__((alias("fexfn_pack_vkSetHdrMetadataEXT"))) auto vkSetHdrMetadataEXT(VkDevice a_0, uint32_t a_1, const VkSwapchainKHR * a_2, const VkHdrMetadataEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkSetDebugUtilsObjectNameEXT"))) auto vkSetDebugUtilsObjectNameEXT(VkDevice a_0, const VkDebugUtilsObjectNameInfoEXT * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkSetDebugUtilsObjectTagEXT"))) auto vkSetDebugUtilsObjectTagEXT(VkDevice a_0, const VkDebugUtilsObjectTagInfoEXT * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkQueueBeginDebugUtilsLabelEXT"))) auto vkQueueBeginDebugUtilsLabelEXT(VkQueue a_0, const VkDebugUtilsLabelEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkQueueEndDebugUtilsLabelEXT"))) auto vkQueueEndDebugUtilsLabelEXT(VkQueue a_0) -> void;
__attribute__((alias("fexfn_pack_vkQueueInsertDebugUtilsLabelEXT"))) auto vkQueueInsertDebugUtilsLabelEXT(VkQueue a_0, const VkDebugUtilsLabelEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginDebugUtilsLabelEXT"))) auto vkCmdBeginDebugUtilsLabelEXT(VkCommandBuffer a_0, const VkDebugUtilsLabelEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndDebugUtilsLabelEXT"))) auto vkCmdEndDebugUtilsLabelEXT(VkCommandBuffer a_0) -> void;
__attribute__((alias("fexfn_pack_vkCmdInsertDebugUtilsLabelEXT"))) auto vkCmdInsertDebugUtilsLabelEXT(VkCommandBuffer a_0, const VkDebugUtilsLabelEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCreateDebugUtilsMessengerEXT"))) auto vkCreateDebugUtilsMessengerEXT(VkInstance a_0, const VkDebugUtilsMessengerCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkDebugUtilsMessengerEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDebugUtilsMessengerEXT"))) auto vkDestroyDebugUtilsMessengerEXT(VkInstance a_0, VkDebugUtilsMessengerEXT a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkSubmitDebugUtilsMessageEXT"))) auto vkSubmitDebugUtilsMessageEXT(VkInstance a_0, VkDebugUtilsMessageSeverityFlagBitsEXT a_1, VkDebugUtilsMessageTypeFlagsEXT a_2, const VkDebugUtilsMessengerCallbackDataEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetSampleLocationsEXT"))) auto vkCmdSetSampleLocationsEXT(VkCommandBuffer a_0, const VkSampleLocationsInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceMultisamplePropertiesEXT"))) auto vkGetPhysicalDeviceMultisamplePropertiesEXT(VkPhysicalDevice a_0, VkSampleCountFlagBits a_1, VkMultisamplePropertiesEXT * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetImageDrmFormatModifierPropertiesEXT"))) auto vkGetImageDrmFormatModifierPropertiesEXT(VkDevice a_0, VkImage a_1, VkImageDrmFormatModifierPropertiesEXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateValidationCacheEXT"))) auto vkCreateValidationCacheEXT(VkDevice a_0, const VkValidationCacheCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkValidationCacheEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyValidationCacheEXT"))) auto vkDestroyValidationCacheEXT(VkDevice a_0, VkValidationCacheEXT a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkMergeValidationCachesEXT"))) auto vkMergeValidationCachesEXT(VkDevice a_0, VkValidationCacheEXT a_1, uint32_t a_2, const VkValidationCacheEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetValidationCacheDataEXT"))) auto vkGetValidationCacheDataEXT(VkDevice a_0, VkValidationCacheEXT a_1, size_t * a_2, void * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdBindShadingRateImageNV"))) auto vkCmdBindShadingRateImageNV(VkCommandBuffer a_0, VkImageView a_1, VkImageLayout a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetViewportShadingRatePaletteNV"))) auto vkCmdSetViewportShadingRatePaletteNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkShadingRatePaletteNV * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCoarseSampleOrderNV"))) auto vkCmdSetCoarseSampleOrderNV(VkCommandBuffer a_0, VkCoarseSampleOrderTypeNV a_1, uint32_t a_2, const VkCoarseSampleOrderCustomNV * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCreateAccelerationStructureNV"))) auto vkCreateAccelerationStructureNV(VkDevice a_0, const VkAccelerationStructureCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkAccelerationStructureNV * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyAccelerationStructureNV"))) auto vkDestroyAccelerationStructureNV(VkDevice a_0, VkAccelerationStructureNV a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetAccelerationStructureMemoryRequirementsNV"))) auto vkGetAccelerationStructureMemoryRequirementsNV(VkDevice a_0, const VkAccelerationStructureMemoryRequirementsInfoNV * a_1, VkMemoryRequirements2KHR * a_2) -> void;
__attribute__((alias("fexfn_pack_vkBindAccelerationStructureMemoryNV"))) auto vkBindAccelerationStructureMemoryNV(VkDevice a_0, uint32_t a_1, const VkBindAccelerationStructureMemoryInfoNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdBuildAccelerationStructureNV"))) auto vkCmdBuildAccelerationStructureNV(VkCommandBuffer a_0, const VkAccelerationStructureInfoNV * a_1, VkBuffer a_2, VkDeviceSize a_3, VkBool32 a_4, VkAccelerationStructureNV a_5, VkAccelerationStructureNV a_6, VkBuffer a_7, VkDeviceSize a_8) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyAccelerationStructureNV"))) auto vkCmdCopyAccelerationStructureNV(VkCommandBuffer a_0, VkAccelerationStructureNV a_1, VkAccelerationStructureNV a_2, VkCopyAccelerationStructureModeKHR a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdTraceRaysNV"))) auto vkCmdTraceRaysNV(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, VkDeviceSize a_5, VkBuffer a_6, VkDeviceSize a_7, VkDeviceSize a_8, VkBuffer a_9, VkDeviceSize a_10, VkDeviceSize a_11, uint32_t a_12, uint32_t a_13, uint32_t a_14) -> void;
__attribute__((alias("fexfn_pack_vkCreateRayTracingPipelinesNV"))) auto vkCreateRayTracingPipelinesNV(VkDevice a_0, VkPipelineCache a_1, uint32_t a_2, const VkRayTracingPipelineCreateInfoNV * a_3, const VkAllocationCallbacks * a_4, VkPipeline * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetRayTracingShaderGroupHandlesKHR"))) auto vkGetRayTracingShaderGroupHandlesKHR(VkDevice a_0, VkPipeline a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetRayTracingShaderGroupHandlesNV"))) auto vkGetRayTracingShaderGroupHandlesNV(VkDevice a_0, VkPipeline a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetAccelerationStructureHandleNV"))) auto vkGetAccelerationStructureHandleNV(VkDevice a_0, VkAccelerationStructureNV a_1, size_t a_2, void * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdWriteAccelerationStructuresPropertiesNV"))) auto vkCmdWriteAccelerationStructuresPropertiesNV(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureNV * a_2, VkQueryType a_3, VkQueryPool a_4, uint32_t a_5) -> void;
__attribute__((alias("fexfn_pack_vkCompileDeferredNV"))) auto vkCompileDeferredNV(VkDevice a_0, VkPipeline a_1, uint32_t a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetMemoryHostPointerPropertiesEXT"))) auto vkGetMemoryHostPointerPropertiesEXT(VkDevice a_0, VkExternalMemoryHandleTypeFlagBits a_1, const void * a_2, VkMemoryHostPointerPropertiesEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdWriteBufferMarkerAMD"))) auto vkCmdWriteBufferMarkerAMD(VkCommandBuffer a_0, VkPipelineStageFlagBits a_1, VkBuffer a_2, VkDeviceSize a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdWriteBufferMarker2AMD"))) auto vkCmdWriteBufferMarker2AMD(VkCommandBuffer a_0, VkPipelineStageFlags2 a_1, VkBuffer a_2, VkDeviceSize a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceCalibrateableTimeDomainsEXT"))) auto vkGetPhysicalDeviceCalibrateableTimeDomainsEXT(VkPhysicalDevice a_0, uint32_t * a_1, VkTimeDomainKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetCalibratedTimestampsEXT"))) auto vkGetCalibratedTimestampsEXT(VkDevice a_0, uint32_t a_1, const VkCalibratedTimestampInfoKHR * a_2, uint64_t * a_3, uint64_t * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdDrawMeshTasksNV"))) auto vkCmdDrawMeshTasksNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawMeshTasksIndirectNV"))) auto vkCmdDrawMeshTasksIndirectNV(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawMeshTasksIndirectCountNV"))) auto vkCmdDrawMeshTasksIndirectCountNV(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetExclusiveScissorEnableNV"))) auto vkCmdSetExclusiveScissorEnableNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBool32 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetExclusiveScissorNV"))) auto vkCmdSetExclusiveScissorNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkRect2D * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCheckpointNV"))) auto vkCmdSetCheckpointNV(VkCommandBuffer a_0, const void * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetQueueCheckpointDataNV"))) auto vkGetQueueCheckpointDataNV(VkQueue a_0, uint32_t * a_1, VkCheckpointDataNV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetQueueCheckpointData2NV"))) auto vkGetQueueCheckpointData2NV(VkQueue a_0, uint32_t * a_1, VkCheckpointData2NV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkSetSwapchainPresentTimingQueueSizeEXT"))) auto vkSetSwapchainPresentTimingQueueSizeEXT(VkDevice a_0, VkSwapchainKHR a_1, uint32_t a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetSwapchainTimingPropertiesEXT"))) auto vkGetSwapchainTimingPropertiesEXT(VkDevice a_0, VkSwapchainKHR a_1, VkSwapchainTimingPropertiesEXT * a_2, uint64_t * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetSwapchainTimeDomainPropertiesEXT"))) auto vkGetSwapchainTimeDomainPropertiesEXT(VkDevice a_0, VkSwapchainKHR a_1, VkSwapchainTimeDomainPropertiesEXT * a_2, uint64_t * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPastPresentationTimingEXT"))) auto vkGetPastPresentationTimingEXT(VkDevice a_0, const VkPastPresentationTimingInfoEXT * a_1, VkPastPresentationTimingPropertiesEXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkInitializePerformanceApiINTEL"))) auto vkInitializePerformanceApiINTEL(VkDevice a_0, const VkInitializePerformanceApiInfoINTEL * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkUninitializePerformanceApiINTEL"))) auto vkUninitializePerformanceApiINTEL(VkDevice a_0) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetPerformanceMarkerINTEL"))) auto vkCmdSetPerformanceMarkerINTEL(VkCommandBuffer a_0, const VkPerformanceMarkerInfoINTEL * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetPerformanceStreamMarkerINTEL"))) auto vkCmdSetPerformanceStreamMarkerINTEL(VkCommandBuffer a_0, const VkPerformanceStreamMarkerInfoINTEL * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetPerformanceOverrideINTEL"))) auto vkCmdSetPerformanceOverrideINTEL(VkCommandBuffer a_0, const VkPerformanceOverrideInfoINTEL * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkAcquirePerformanceConfigurationINTEL"))) auto vkAcquirePerformanceConfigurationINTEL(VkDevice a_0, const VkPerformanceConfigurationAcquireInfoINTEL * a_1, VkPerformanceConfigurationINTEL * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkReleasePerformanceConfigurationINTEL"))) auto vkReleasePerformanceConfigurationINTEL(VkDevice a_0, VkPerformanceConfigurationINTEL a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkQueueSetPerformanceConfigurationINTEL"))) auto vkQueueSetPerformanceConfigurationINTEL(VkQueue a_0, VkPerformanceConfigurationINTEL a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPerformanceParameterINTEL"))) auto vkGetPerformanceParameterINTEL(VkDevice a_0, VkPerformanceParameterTypeINTEL a_1, VkPerformanceValueINTEL * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkSetLocalDimmingAMD"))) auto vkSetLocalDimmingAMD(VkDevice a_0, VkSwapchainKHR a_1, VkBool32 a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetBufferDeviceAddressEXT"))) auto vkGetBufferDeviceAddressEXT(VkDevice a_0, const VkBufferDeviceAddressInfo * a_1) -> VkDeviceAddress;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceToolPropertiesEXT"))) auto vkGetPhysicalDeviceToolPropertiesEXT(VkPhysicalDevice a_0, uint32_t * a_1, VkPhysicalDeviceToolProperties * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceCooperativeMatrixPropertiesNV"))) auto vkGetPhysicalDeviceCooperativeMatrixPropertiesNV(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeMatrixPropertiesNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceSupportedFramebufferMixedSamplesCombinationsNV"))) auto vkGetPhysicalDeviceSupportedFramebufferMixedSamplesCombinationsNV(VkPhysicalDevice a_0, uint32_t * a_1, VkFramebufferMixedSamplesCombinationNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateHeadlessSurfaceEXT"))) auto vkCreateHeadlessSurfaceEXT(VkInstance a_0, const VkHeadlessSurfaceCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetLineStippleEXT"))) auto vkCmdSetLineStippleEXT(VkCommandBuffer a_0, uint32_t a_1, uint16_t a_2) -> void;
__attribute__((alias("fexfn_pack_vkResetQueryPoolEXT"))) auto vkResetQueryPoolEXT(VkDevice a_0, VkQueryPool a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCullModeEXT"))) auto vkCmdSetCullModeEXT(VkCommandBuffer a_0, VkCullModeFlags a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetFrontFaceEXT"))) auto vkCmdSetFrontFaceEXT(VkCommandBuffer a_0, VkFrontFace a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetPrimitiveTopologyEXT"))) auto vkCmdSetPrimitiveTopologyEXT(VkCommandBuffer a_0, VkPrimitiveTopology a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetViewportWithCountEXT"))) auto vkCmdSetViewportWithCountEXT(VkCommandBuffer a_0, uint32_t a_1, const VkViewport * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetScissorWithCountEXT"))) auto vkCmdSetScissorWithCountEXT(VkCommandBuffer a_0, uint32_t a_1, const VkRect2D * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindVertexBuffers2EXT"))) auto vkCmdBindVertexBuffers2EXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBuffer * a_3, const VkDeviceSize * a_4, const VkDeviceSize * a_5, const VkDeviceSize * a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthTestEnableEXT"))) auto vkCmdSetDepthTestEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthWriteEnableEXT"))) auto vkCmdSetDepthWriteEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthCompareOpEXT"))) auto vkCmdSetDepthCompareOpEXT(VkCommandBuffer a_0, VkCompareOp a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthBoundsTestEnableEXT"))) auto vkCmdSetDepthBoundsTestEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetStencilTestEnableEXT"))) auto vkCmdSetStencilTestEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetStencilOpEXT"))) auto vkCmdSetStencilOpEXT(VkCommandBuffer a_0, VkStencilFaceFlags a_1, VkStencilOp a_2, VkStencilOp a_3, VkStencilOp a_4, VkCompareOp a_5) -> void;
__attribute__((alias("fexfn_pack_vkCopyMemoryToImageEXT"))) auto vkCopyMemoryToImageEXT(VkDevice a_0, const VkCopyMemoryToImageInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyImageToMemoryEXT"))) auto vkCopyImageToMemoryEXT(VkDevice a_0, const VkCopyImageToMemoryInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyImageToImageEXT"))) auto vkCopyImageToImageEXT(VkDevice a_0, const VkCopyImageToImageInfo * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkTransitionImageLayoutEXT"))) auto vkTransitionImageLayoutEXT(VkDevice a_0, uint32_t a_1, const VkHostImageLayoutTransitionInfo * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetImageSubresourceLayout2EXT"))) auto vkGetImageSubresourceLayout2EXT(VkDevice a_0, VkImage a_1, const VkImageSubresource2 * a_2, VkSubresourceLayout2 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkReleaseSwapchainImagesEXT"))) auto vkReleaseSwapchainImagesEXT(VkDevice a_0, const VkReleaseSwapchainImagesInfoKHR * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetGeneratedCommandsMemoryRequirementsNV"))) auto vkGetGeneratedCommandsMemoryRequirementsNV(VkDevice a_0, const VkGeneratedCommandsMemoryRequirementsInfoNV * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdPreprocessGeneratedCommandsNV"))) auto vkCmdPreprocessGeneratedCommandsNV(VkCommandBuffer a_0, const VkGeneratedCommandsInfoNV * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdExecuteGeneratedCommandsNV"))) auto vkCmdExecuteGeneratedCommandsNV(VkCommandBuffer a_0, VkBool32 a_1, const VkGeneratedCommandsInfoNV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindPipelineShaderGroupNV"))) auto vkCmdBindPipelineShaderGroupNV(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipeline a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCreateIndirectCommandsLayoutNV"))) auto vkCreateIndirectCommandsLayoutNV(VkDevice a_0, const VkIndirectCommandsLayoutCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkIndirectCommandsLayoutNV * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyIndirectCommandsLayoutNV"))) auto vkDestroyIndirectCommandsLayoutNV(VkDevice a_0, VkIndirectCommandsLayoutNV a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthBias2EXT"))) auto vkCmdSetDepthBias2EXT(VkCommandBuffer a_0, const VkDepthBiasInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkAcquireDrmDisplayEXT"))) auto vkAcquireDrmDisplayEXT(VkPhysicalDevice a_0, int32_t a_1, VkDisplayKHR a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDrmDisplayEXT"))) auto vkGetDrmDisplayEXT(VkPhysicalDevice a_0, int32_t a_1, uint32_t a_2, VkDisplayKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreatePrivateDataSlotEXT"))) auto vkCreatePrivateDataSlotEXT(VkDevice a_0, const VkPrivateDataSlotCreateInfo * a_1, const VkAllocationCallbacks * a_2, VkPrivateDataSlot * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyPrivateDataSlotEXT"))) auto vkDestroyPrivateDataSlotEXT(VkDevice a_0, VkPrivateDataSlot a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkSetPrivateDataEXT"))) auto vkSetPrivateDataEXT(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPrivateDataEXT"))) auto vkGetPrivateDataEXT(VkDevice a_0, VkObjectType a_1, uint64_t a_2, VkPrivateDataSlot a_3, uint64_t * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdDispatchTileQCOM"))) auto vkCmdDispatchTileQCOM(VkCommandBuffer a_0, const VkDispatchTileInfoQCOM * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginPerTileExecutionQCOM"))) auto vkCmdBeginPerTileExecutionQCOM(VkCommandBuffer a_0, const VkPerTileBeginInfoQCOM * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdEndPerTileExecutionQCOM"))) auto vkCmdEndPerTileExecutionQCOM(VkCommandBuffer a_0, const VkPerTileEndInfoQCOM * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetDescriptorSetLayoutSizeEXT"))) auto vkGetDescriptorSetLayoutSizeEXT(VkDevice a_0, VkDescriptorSetLayout a_1, VkDeviceSize * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDescriptorSetLayoutBindingOffsetEXT"))) auto vkGetDescriptorSetLayoutBindingOffsetEXT(VkDevice a_0, VkDescriptorSetLayout a_1, uint32_t a_2, VkDeviceSize * a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetDescriptorEXT"))) auto vkGetDescriptorEXT(VkDevice a_0, const VkDescriptorGetInfoEXT * a_1, size_t a_2, void * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindDescriptorBuffersEXT"))) auto vkCmdBindDescriptorBuffersEXT(VkCommandBuffer a_0, uint32_t a_1, const VkDescriptorBufferBindingInfoEXT * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDescriptorBufferOffsetsEXT"))) auto vkCmdSetDescriptorBufferOffsetsEXT(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3, uint32_t a_4, const uint32_t * a_5, const VkDeviceSize * a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindDescriptorBufferEmbeddedSamplersEXT"))) auto vkCmdBindDescriptorBufferEmbeddedSamplersEXT(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipelineLayout a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetBufferOpaqueCaptureDescriptorDataEXT"))) auto vkGetBufferOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkBufferCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetImageOpaqueCaptureDescriptorDataEXT"))) auto vkGetImageOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkImageCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetImageViewOpaqueCaptureDescriptorDataEXT"))) auto vkGetImageViewOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkImageViewCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetSamplerOpaqueCaptureDescriptorDataEXT"))) auto vkGetSamplerOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkSamplerCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetAccelerationStructureOpaqueCaptureDescriptorDataEXT"))) auto vkGetAccelerationStructureOpaqueCaptureDescriptorDataEXT(VkDevice a_0, const VkAccelerationStructureCaptureDescriptorDataInfoEXT * a_1, void * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetFragmentShadingRateEnumNV"))) auto vkCmdSetFragmentShadingRateEnumNV(VkCommandBuffer a_0, VkFragmentShadingRateNV a_1, const VkFragmentShadingRateCombinerOpKHR * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceFaultInfoEXT"))) auto vkGetDeviceFaultInfoEXT(VkDevice a_0, VkDeviceFaultCountsEXT * a_1, VkDeviceFaultInfoEXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetVertexInputEXT"))) auto vkCmdSetVertexInputEXT(VkCommandBuffer a_0, uint32_t a_1, const VkVertexInputBindingDescription2EXT * a_2, uint32_t a_3, const VkVertexInputAttributeDescription2EXT * a_4) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceSubpassShadingMaxWorkgroupSizeHUAWEI"))) auto vkGetDeviceSubpassShadingMaxWorkgroupSizeHUAWEI(VkDevice a_0, VkRenderPass a_1, VkExtent2D * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSubpassShadingHUAWEI"))) auto vkCmdSubpassShadingHUAWEI(VkCommandBuffer a_0) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindInvocationMaskHUAWEI"))) auto vkCmdBindInvocationMaskHUAWEI(VkCommandBuffer a_0, VkImageView a_1, VkImageLayout a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetMemoryRemoteAddressNV"))) auto vkGetMemoryRemoteAddressNV(VkDevice a_0, const VkMemoryGetRemoteAddressInfoNV * a_1, VkRemoteAddressNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPipelinePropertiesEXT"))) auto vkGetPipelinePropertiesEXT(VkDevice a_0, const VkPipelineInfoEXT * a_1, VkBaseOutStructure * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdSetPatchControlPointsEXT"))) auto vkCmdSetPatchControlPointsEXT(VkCommandBuffer a_0, uint32_t a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRasterizerDiscardEnableEXT"))) auto vkCmdSetRasterizerDiscardEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthBiasEnableEXT"))) auto vkCmdSetDepthBiasEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetLogicOpEXT"))) auto vkCmdSetLogicOpEXT(VkCommandBuffer a_0, VkLogicOp a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetPrimitiveRestartEnableEXT"))) auto vkCmdSetPrimitiveRestartEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetColorWriteEnableEXT"))) auto vkCmdSetColorWriteEnableEXT(VkCommandBuffer a_0, uint32_t a_1, const VkBool32 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawMultiEXT"))) auto vkCmdDrawMultiEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMultiDrawInfoEXT * a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawMultiIndexedEXT"))) auto vkCmdDrawMultiIndexedEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMultiDrawIndexedInfoEXT * a_2, uint32_t a_3, uint32_t a_4, uint32_t a_5, const int32_t * a_6) -> void;
__attribute__((alias("fexfn_pack_vkCreateMicromapEXT"))) auto vkCreateMicromapEXT(VkDevice a_0, const VkMicromapCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkMicromapEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyMicromapEXT"))) auto vkDestroyMicromapEXT(VkDevice a_0, VkMicromapEXT a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBuildMicromapsEXT"))) auto vkCmdBuildMicromapsEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMicromapBuildInfoEXT * a_2) -> void;
__attribute__((alias("fexfn_pack_vkBuildMicromapsEXT"))) auto vkBuildMicromapsEXT(VkDevice a_0, VkDeferredOperationKHR a_1, uint32_t a_2, const VkMicromapBuildInfoEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyMicromapEXT"))) auto vkCopyMicromapEXT(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMicromapInfoEXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyMicromapToMemoryEXT"))) auto vkCopyMicromapToMemoryEXT(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMicromapToMemoryInfoEXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyMemoryToMicromapEXT"))) auto vkCopyMemoryToMicromapEXT(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMemoryToMicromapInfoEXT * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkWriteMicromapsPropertiesEXT"))) auto vkWriteMicromapsPropertiesEXT(VkDevice a_0, uint32_t a_1, const VkMicromapEXT * a_2, VkQueryType a_3, size_t a_4, void * a_5, size_t a_6) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdCopyMicromapEXT"))) auto vkCmdCopyMicromapEXT(VkCommandBuffer a_0, const VkCopyMicromapInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyMicromapToMemoryEXT"))) auto vkCmdCopyMicromapToMemoryEXT(VkCommandBuffer a_0, const VkCopyMicromapToMemoryInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyMemoryToMicromapEXT"))) auto vkCmdCopyMemoryToMicromapEXT(VkCommandBuffer a_0, const VkCopyMemoryToMicromapInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdWriteMicromapsPropertiesEXT"))) auto vkCmdWriteMicromapsPropertiesEXT(VkCommandBuffer a_0, uint32_t a_1, const VkMicromapEXT * a_2, VkQueryType a_3, VkQueryPool a_4, uint32_t a_5) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceMicromapCompatibilityEXT"))) auto vkGetDeviceMicromapCompatibilityEXT(VkDevice a_0, const VkMicromapVersionInfoEXT * a_1, VkAccelerationStructureCompatibilityKHR * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetMicromapBuildSizesEXT"))) auto vkGetMicromapBuildSizesEXT(VkDevice a_0, VkAccelerationStructureBuildTypeKHR a_1, const VkMicromapBuildInfoEXT * a_2, VkMicromapBuildSizesInfoEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawClusterHUAWEI"))) auto vkCmdDrawClusterHUAWEI(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawClusterIndirectHUAWEI"))) auto vkCmdDrawClusterIndirectHUAWEI(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2) -> void;
__attribute__((alias("fexfn_pack_vkSetDeviceMemoryPriorityEXT"))) auto vkSetDeviceMemoryPriorityEXT(VkDevice a_0, VkDeviceMemory a_1, float a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDescriptorSetLayoutHostMappingInfoVALVE"))) auto vkGetDescriptorSetLayoutHostMappingInfoVALVE(VkDevice a_0, const VkDescriptorSetBindingReferenceVALVE * a_1, VkDescriptorSetLayoutHostMappingInfoVALVE * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDescriptorSetHostMappingVALVE"))) auto vkGetDescriptorSetHostMappingVALVE(VkDevice a_0, VkDescriptorSet a_1, void ** a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyMemoryIndirectNV"))) auto vkCmdCopyMemoryIndirectNV(VkCommandBuffer a_0, VkDeviceAddress a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyMemoryToImageIndirectNV"))) auto vkCmdCopyMemoryToImageIndirectNV(VkCommandBuffer a_0, VkDeviceAddress a_1, uint32_t a_2, uint32_t a_3, VkImage a_4, VkImageLayout a_5, const VkImageSubresourceLayers * a_6) -> void;
__attribute__((alias("fexfn_pack_vkCmdDecompressMemoryNV"))) auto vkCmdDecompressMemoryNV(VkCommandBuffer a_0, uint32_t a_1, const VkDecompressMemoryRegionNV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdDecompressMemoryIndirectCountNV"))) auto vkCmdDecompressMemoryIndirectCountNV(VkCommandBuffer a_0, VkDeviceAddress a_1, VkDeviceAddress a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetPipelineIndirectMemoryRequirementsNV"))) auto vkGetPipelineIndirectMemoryRequirementsNV(VkDevice a_0, const VkComputePipelineCreateInfo * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdUpdatePipelineIndirectBufferNV"))) auto vkCmdUpdatePipelineIndirectBufferNV(VkCommandBuffer a_0, VkPipelineBindPoint a_1, VkPipeline a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPipelineIndirectDeviceAddressNV"))) auto vkGetPipelineIndirectDeviceAddressNV(VkDevice a_0, const VkPipelineIndirectDeviceAddressInfoNV * a_1) -> VkDeviceAddress;
__attribute__((alias("fexfn_pack_vkCmdSetDepthClampEnableEXT"))) auto vkCmdSetDepthClampEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetPolygonModeEXT"))) auto vkCmdSetPolygonModeEXT(VkCommandBuffer a_0, VkPolygonMode a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRasterizationSamplesEXT"))) auto vkCmdSetRasterizationSamplesEXT(VkCommandBuffer a_0, VkSampleCountFlagBits a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetSampleMaskEXT"))) auto vkCmdSetSampleMaskEXT(VkCommandBuffer a_0, VkSampleCountFlagBits a_1, const VkSampleMask * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetAlphaToCoverageEnableEXT"))) auto vkCmdSetAlphaToCoverageEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetAlphaToOneEnableEXT"))) auto vkCmdSetAlphaToOneEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetLogicOpEnableEXT"))) auto vkCmdSetLogicOpEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetColorBlendEnableEXT"))) auto vkCmdSetColorBlendEnableEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkBool32 * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetColorBlendEquationEXT"))) auto vkCmdSetColorBlendEquationEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkColorBlendEquationEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetColorWriteMaskEXT"))) auto vkCmdSetColorWriteMaskEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkColorComponentFlags * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetTessellationDomainOriginEXT"))) auto vkCmdSetTessellationDomainOriginEXT(VkCommandBuffer a_0, VkTessellationDomainOrigin a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRasterizationStreamEXT"))) auto vkCmdSetRasterizationStreamEXT(VkCommandBuffer a_0, uint32_t a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetConservativeRasterizationModeEXT"))) auto vkCmdSetConservativeRasterizationModeEXT(VkCommandBuffer a_0, VkConservativeRasterizationModeEXT a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetExtraPrimitiveOverestimationSizeEXT"))) auto vkCmdSetExtraPrimitiveOverestimationSizeEXT(VkCommandBuffer a_0, float a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthClipEnableEXT"))) auto vkCmdSetDepthClipEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetSampleLocationsEnableEXT"))) auto vkCmdSetSampleLocationsEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetColorBlendAdvancedEXT"))) auto vkCmdSetColorBlendAdvancedEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkColorBlendAdvancedEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetProvokingVertexModeEXT"))) auto vkCmdSetProvokingVertexModeEXT(VkCommandBuffer a_0, VkProvokingVertexModeEXT a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetLineRasterizationModeEXT"))) auto vkCmdSetLineRasterizationModeEXT(VkCommandBuffer a_0, VkLineRasterizationModeEXT a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetLineStippleEnableEXT"))) auto vkCmdSetLineStippleEnableEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthClipNegativeOneToOneEXT"))) auto vkCmdSetDepthClipNegativeOneToOneEXT(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetViewportWScalingEnableNV"))) auto vkCmdSetViewportWScalingEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetViewportSwizzleNV"))) auto vkCmdSetViewportSwizzleNV(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, const VkViewportSwizzleNV * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCoverageToColorEnableNV"))) auto vkCmdSetCoverageToColorEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCoverageToColorLocationNV"))) auto vkCmdSetCoverageToColorLocationNV(VkCommandBuffer a_0, uint32_t a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCoverageModulationModeNV"))) auto vkCmdSetCoverageModulationModeNV(VkCommandBuffer a_0, VkCoverageModulationModeNV a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCoverageModulationTableEnableNV"))) auto vkCmdSetCoverageModulationTableEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCoverageModulationTableNV"))) auto vkCmdSetCoverageModulationTableNV(VkCommandBuffer a_0, uint32_t a_1, const float * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetShadingRateImageEnableNV"))) auto vkCmdSetShadingRateImageEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetRepresentativeFragmentTestEnableNV"))) auto vkCmdSetRepresentativeFragmentTestEnableNV(VkCommandBuffer a_0, VkBool32 a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetCoverageReductionModeNV"))) auto vkCmdSetCoverageReductionModeNV(VkCommandBuffer a_0, VkCoverageReductionModeNV a_1) -> void;
__attribute__((alias("fexfn_pack_vkCreateTensorARM"))) auto vkCreateTensorARM(VkDevice a_0, const VkTensorCreateInfoARM * a_1, const VkAllocationCallbacks * a_2, VkTensorARM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyTensorARM"))) auto vkDestroyTensorARM(VkDevice a_0, VkTensorARM a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateTensorViewARM"))) auto vkCreateTensorViewARM(VkDevice a_0, const VkTensorViewCreateInfoARM * a_1, const VkAllocationCallbacks * a_2, VkTensorViewARM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyTensorViewARM"))) auto vkDestroyTensorViewARM(VkDevice a_0, VkTensorViewARM a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetTensorMemoryRequirementsARM"))) auto vkGetTensorMemoryRequirementsARM(VkDevice a_0, const VkTensorMemoryRequirementsInfoARM * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkBindTensorMemoryARM"))) auto vkBindTensorMemoryARM(VkDevice a_0, uint32_t a_1, const VkBindTensorMemoryInfoARM * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDeviceTensorMemoryRequirementsARM"))) auto vkGetDeviceTensorMemoryRequirementsARM(VkDevice a_0, const VkDeviceTensorMemoryRequirementsARM * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyTensorARM"))) auto vkCmdCopyTensorARM(VkCommandBuffer a_0, const VkCopyTensorInfoARM * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceExternalTensorPropertiesARM"))) auto vkGetPhysicalDeviceExternalTensorPropertiesARM(VkPhysicalDevice a_0, const VkPhysicalDeviceExternalTensorInfoARM * a_1, VkExternalTensorPropertiesARM * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetTensorOpaqueCaptureDescriptorDataARM"))) auto vkGetTensorOpaqueCaptureDescriptorDataARM(VkDevice a_0, const VkTensorCaptureDescriptorDataInfoARM * a_1, void * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetTensorViewOpaqueCaptureDescriptorDataARM"))) auto vkGetTensorViewOpaqueCaptureDescriptorDataARM(VkDevice a_0, const VkTensorViewCaptureDescriptorDataInfoARM * a_1, void * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetShaderModuleIdentifierEXT"))) auto vkGetShaderModuleIdentifierEXT(VkDevice a_0, VkShaderModule a_1, VkShaderModuleIdentifierEXT * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetShaderModuleCreateInfoIdentifierEXT"))) auto vkGetShaderModuleCreateInfoIdentifierEXT(VkDevice a_0, const VkShaderModuleCreateInfo * a_1, VkShaderModuleIdentifierEXT * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceOpticalFlowImageFormatsNV"))) auto vkGetPhysicalDeviceOpticalFlowImageFormatsNV(VkPhysicalDevice a_0, const VkOpticalFlowImageFormatInfoNV * a_1, uint32_t * a_2, VkOpticalFlowImageFormatPropertiesNV * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateOpticalFlowSessionNV"))) auto vkCreateOpticalFlowSessionNV(VkDevice a_0, const VkOpticalFlowSessionCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkOpticalFlowSessionNV * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyOpticalFlowSessionNV"))) auto vkDestroyOpticalFlowSessionNV(VkDevice a_0, VkOpticalFlowSessionNV a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkBindOpticalFlowSessionImageNV"))) auto vkBindOpticalFlowSessionImageNV(VkDevice a_0, VkOpticalFlowSessionNV a_1, VkOpticalFlowSessionBindingPointNV a_2, VkImageView a_3, VkImageLayout a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdOpticalFlowExecuteNV"))) auto vkCmdOpticalFlowExecuteNV(VkCommandBuffer a_0, VkOpticalFlowSessionNV a_1, const VkOpticalFlowExecuteInfoNV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkAntiLagUpdateAMD"))) auto vkAntiLagUpdateAMD(VkDevice a_0, const VkAntiLagDataAMD * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCreateShadersEXT"))) auto vkCreateShadersEXT(VkDevice a_0, uint32_t a_1, const VkShaderCreateInfoEXT * a_2, const VkAllocationCallbacks * a_3, VkShaderEXT * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyShaderEXT"))) auto vkDestroyShaderEXT(VkDevice a_0, VkShaderEXT a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetShaderBinaryDataEXT"))) auto vkGetShaderBinaryDataEXT(VkDevice a_0, VkShaderEXT a_1, size_t * a_2, void * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdBindShadersEXT"))) auto vkCmdBindShadersEXT(VkCommandBuffer a_0, uint32_t a_1, const VkShaderStageFlagBits * a_2, const VkShaderEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetDepthClampRangeEXT"))) auto vkCmdSetDepthClampRangeEXT(VkCommandBuffer a_0, VkDepthClampModeEXT a_1, const VkDepthClampRangeEXT * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetFramebufferTilePropertiesQCOM"))) auto vkGetFramebufferTilePropertiesQCOM(VkDevice a_0, VkFramebuffer a_1, uint32_t * a_2, VkTilePropertiesQCOM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDynamicRenderingTilePropertiesQCOM"))) auto vkGetDynamicRenderingTilePropertiesQCOM(VkDevice a_0, const VkRenderingInfo * a_1, VkTilePropertiesQCOM * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceCooperativeVectorPropertiesNV"))) auto vkGetPhysicalDeviceCooperativeVectorPropertiesNV(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeVectorPropertiesNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkConvertCooperativeVectorMatrixNV"))) auto vkConvertCooperativeVectorMatrixNV(VkDevice a_0, const VkConvertCooperativeVectorMatrixInfoNV * a_1) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdConvertCooperativeVectorMatrixNV"))) auto vkCmdConvertCooperativeVectorMatrixNV(VkCommandBuffer a_0, uint32_t a_1, const VkConvertCooperativeVectorMatrixInfoNV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkSetLatencySleepModeNV"))) auto vkSetLatencySleepModeNV(VkDevice a_0, VkSwapchainKHR a_1, const VkLatencySleepModeInfoNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkLatencySleepNV"))) auto vkLatencySleepNV(VkDevice a_0, VkSwapchainKHR a_1, const VkLatencySleepInfoNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkSetLatencyMarkerNV"))) auto vkSetLatencyMarkerNV(VkDevice a_0, VkSwapchainKHR a_1, const VkSetLatencyMarkerInfoNV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetLatencyTimingsNV"))) auto vkGetLatencyTimingsNV(VkDevice a_0, VkSwapchainKHR a_1, VkGetLatencyMarkerInfoNV * a_2) -> void;
__attribute__((alias("fexfn_pack_vkQueueNotifyOutOfBandNV"))) auto vkQueueNotifyOutOfBandNV(VkQueue a_0, const VkOutOfBandQueueTypeInfoNV * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCreateDataGraphPipelinesARM"))) auto vkCreateDataGraphPipelinesARM(VkDevice a_0, VkDeferredOperationKHR a_1, VkPipelineCache a_2, uint32_t a_3, const VkDataGraphPipelineCreateInfoARM * a_4, const VkAllocationCallbacks * a_5, VkPipeline * a_6) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateDataGraphPipelineSessionARM"))) auto vkCreateDataGraphPipelineSessionARM(VkDevice a_0, const VkDataGraphPipelineSessionCreateInfoARM * a_1, const VkAllocationCallbacks * a_2, VkDataGraphPipelineSessionARM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDataGraphPipelineSessionBindPointRequirementsARM"))) auto vkGetDataGraphPipelineSessionBindPointRequirementsARM(VkDevice a_0, const VkDataGraphPipelineSessionBindPointRequirementsInfoARM * a_1, uint32_t * a_2, VkDataGraphPipelineSessionBindPointRequirementARM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDataGraphPipelineSessionMemoryRequirementsARM"))) auto vkGetDataGraphPipelineSessionMemoryRequirementsARM(VkDevice a_0, const VkDataGraphPipelineSessionMemoryRequirementsInfoARM * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkBindDataGraphPipelineSessionMemoryARM"))) auto vkBindDataGraphPipelineSessionMemoryARM(VkDevice a_0, uint32_t a_1, const VkBindDataGraphPipelineSessionMemoryInfoARM * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyDataGraphPipelineSessionARM"))) auto vkDestroyDataGraphPipelineSessionARM(VkDevice a_0, VkDataGraphPipelineSessionARM a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdDispatchDataGraphARM"))) auto vkCmdDispatchDataGraphARM(VkCommandBuffer a_0, VkDataGraphPipelineSessionARM a_1, const VkDataGraphPipelineDispatchInfoARM * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetDataGraphPipelineAvailablePropertiesARM"))) auto vkGetDataGraphPipelineAvailablePropertiesARM(VkDevice a_0, const VkDataGraphPipelineInfoARM * a_1, uint32_t * a_2, VkDataGraphPipelinePropertyARM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetDataGraphPipelinePropertiesARM"))) auto vkGetDataGraphPipelinePropertiesARM(VkDevice a_0, const VkDataGraphPipelineInfoARM * a_1, uint32_t a_2, VkDataGraphPipelinePropertyQueryResultARM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceQueueFamilyDataGraphPropertiesARM"))) auto vkGetPhysicalDeviceQueueFamilyDataGraphPropertiesARM(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkQueueFamilyDataGraphPropertiesARM * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceQueueFamilyDataGraphProcessingEnginePropertiesARM"))) auto vkGetPhysicalDeviceQueueFamilyDataGraphProcessingEnginePropertiesARM(VkPhysicalDevice a_0, const VkPhysicalDeviceQueueFamilyDataGraphProcessingEngineInfoARM * a_1, VkQueueFamilyDataGraphProcessingEnginePropertiesARM * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetAttachmentFeedbackLoopEnableEXT"))) auto vkCmdSetAttachmentFeedbackLoopEnableEXT(VkCommandBuffer a_0, VkImageAspectFlags a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBindTileMemoryQCOM"))) auto vkCmdBindTileMemoryQCOM(VkCommandBuffer a_0, const VkTileMemoryBindInfoQCOM * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdDecompressMemoryEXT"))) auto vkCmdDecompressMemoryEXT(VkCommandBuffer a_0, const VkDecompressMemoryInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdDecompressMemoryIndirectCountEXT"))) auto vkCmdDecompressMemoryIndirectCountEXT(VkCommandBuffer a_0, VkMemoryDecompressionMethodFlagsEXT a_1, VkDeviceAddress a_2, VkDeviceAddress a_3, uint32_t a_4, uint32_t a_5) -> void;
__attribute__((alias("fexfn_pack_vkCreateExternalComputeQueueNV"))) auto vkCreateExternalComputeQueueNV(VkDevice a_0, const VkExternalComputeQueueCreateInfoNV * a_1, const VkAllocationCallbacks * a_2, VkExternalComputeQueueNV * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyExternalComputeQueueNV"))) auto vkDestroyExternalComputeQueueNV(VkDevice a_0, VkExternalComputeQueueNV a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetExternalComputeQueueDataNV"))) auto vkGetExternalComputeQueueDataNV(VkExternalComputeQueueNV a_0, VkExternalComputeQueueDataParamsNV * a_1, void * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetClusterAccelerationStructureBuildSizesNV"))) auto vkGetClusterAccelerationStructureBuildSizesNV(VkDevice a_0, const VkClusterAccelerationStructureInputInfoNV * a_1, VkAccelerationStructureBuildSizesInfoKHR * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBuildClusterAccelerationStructureIndirectNV"))) auto vkCmdBuildClusterAccelerationStructureIndirectNV(VkCommandBuffer a_0, const VkClusterAccelerationStructureCommandsInfoNV * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetPartitionedAccelerationStructuresBuildSizesNV"))) auto vkGetPartitionedAccelerationStructuresBuildSizesNV(VkDevice a_0, const VkPartitionedAccelerationStructureInstancesInputNV * a_1, VkAccelerationStructureBuildSizesInfoKHR * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBuildPartitionedAccelerationStructuresNV"))) auto vkCmdBuildPartitionedAccelerationStructuresNV(VkCommandBuffer a_0, const VkBuildPartitionedAccelerationStructureInfoNV * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetGeneratedCommandsMemoryRequirementsEXT"))) auto vkGetGeneratedCommandsMemoryRequirementsEXT(VkDevice a_0, const VkGeneratedCommandsMemoryRequirementsInfoEXT * a_1, VkMemoryRequirements2 * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdPreprocessGeneratedCommandsEXT"))) auto vkCmdPreprocessGeneratedCommandsEXT(VkCommandBuffer a_0, const VkGeneratedCommandsInfoEXT * a_1, VkCommandBuffer a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdExecuteGeneratedCommandsEXT"))) auto vkCmdExecuteGeneratedCommandsEXT(VkCommandBuffer a_0, VkBool32 a_1, const VkGeneratedCommandsInfoEXT * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateIndirectCommandsLayoutEXT"))) auto vkCreateIndirectCommandsLayoutEXT(VkDevice a_0, const VkIndirectCommandsLayoutCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkIndirectCommandsLayoutEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyIndirectCommandsLayoutEXT"))) auto vkDestroyIndirectCommandsLayoutEXT(VkDevice a_0, VkIndirectCommandsLayoutEXT a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCreateIndirectExecutionSetEXT"))) auto vkCreateIndirectExecutionSetEXT(VkDevice a_0, const VkIndirectExecutionSetCreateInfoEXT * a_1, const VkAllocationCallbacks * a_2, VkIndirectExecutionSetEXT * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyIndirectExecutionSetEXT"))) auto vkDestroyIndirectExecutionSetEXT(VkDevice a_0, VkIndirectExecutionSetEXT a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkUpdateIndirectExecutionSetPipelineEXT"))) auto vkUpdateIndirectExecutionSetPipelineEXT(VkDevice a_0, VkIndirectExecutionSetEXT a_1, uint32_t a_2, const VkWriteIndirectExecutionSetPipelineEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkUpdateIndirectExecutionSetShaderEXT"))) auto vkUpdateIndirectExecutionSetShaderEXT(VkDevice a_0, VkIndirectExecutionSetEXT a_1, uint32_t a_2, const VkWriteIndirectExecutionSetShaderEXT * a_3) -> void;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceCooperativeMatrixFlexibleDimensionsPropertiesNV"))) auto vkGetPhysicalDeviceCooperativeMatrixFlexibleDimensionsPropertiesNV(VkPhysicalDevice a_0, uint32_t * a_1, VkCooperativeMatrixFlexibleDimensionsPropertiesNV * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkEnumeratePhysicalDeviceQueueFamilyPerformanceCountersByRegionARM"))) auto vkEnumeratePhysicalDeviceQueueFamilyPerformanceCountersByRegionARM(VkPhysicalDevice a_0, uint32_t a_1, uint32_t * a_2, VkPerformanceCounterARM * a_3, VkPerformanceCounterDescriptionARM * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdEndRendering2EXT"))) auto vkCmdEndRendering2EXT(VkCommandBuffer a_0, const VkRenderingEndInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdBeginCustomResolveEXT"))) auto vkCmdBeginCustomResolveEXT(VkCommandBuffer a_0, const VkBeginCustomResolveInfoEXT * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdSetComputeOccupancyPriorityNV"))) auto vkCmdSetComputeOccupancyPriorityNV(VkCommandBuffer a_0, const VkComputeOccupancyPriorityParametersNV * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCreateAccelerationStructureKHR"))) auto vkCreateAccelerationStructureKHR(VkDevice a_0, const VkAccelerationStructureCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkAccelerationStructureKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkDestroyAccelerationStructureKHR"))) auto vkDestroyAccelerationStructureKHR(VkDevice a_0, VkAccelerationStructureKHR a_1, const VkAllocationCallbacks * a_2) -> void;
__attribute__((alias("fexfn_pack_vkCmdBuildAccelerationStructuresKHR"))) auto vkCmdBuildAccelerationStructuresKHR(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureBuildGeometryInfoKHR * a_2, const VkAccelerationStructureBuildRangeInfoKHR *const * a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdBuildAccelerationStructuresIndirectKHR"))) auto vkCmdBuildAccelerationStructuresIndirectKHR(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureBuildGeometryInfoKHR * a_2, const VkDeviceAddress * a_3, const uint32_t * a_4, const uint32_t *const * a_5) -> void;
__attribute__((alias("fexfn_pack_vkBuildAccelerationStructuresKHR"))) auto vkBuildAccelerationStructuresKHR(VkDevice a_0, VkDeferredOperationKHR a_1, uint32_t a_2, const VkAccelerationStructureBuildGeometryInfoKHR * a_3, const VkAccelerationStructureBuildRangeInfoKHR *const * a_4) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyAccelerationStructureKHR"))) auto vkCopyAccelerationStructureKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyAccelerationStructureInfoKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyAccelerationStructureToMemoryKHR"))) auto vkCopyAccelerationStructureToMemoryKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyAccelerationStructureToMemoryInfoKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkCopyMemoryToAccelerationStructureKHR"))) auto vkCopyMemoryToAccelerationStructureKHR(VkDevice a_0, VkDeferredOperationKHR a_1, const VkCopyMemoryToAccelerationStructureInfoKHR * a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkWriteAccelerationStructuresPropertiesKHR"))) auto vkWriteAccelerationStructuresPropertiesKHR(VkDevice a_0, uint32_t a_1, const VkAccelerationStructureKHR * a_2, VkQueryType a_3, size_t a_4, void * a_5, size_t a_6) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdCopyAccelerationStructureKHR"))) auto vkCmdCopyAccelerationStructureKHR(VkCommandBuffer a_0, const VkCopyAccelerationStructureInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyAccelerationStructureToMemoryKHR"))) auto vkCmdCopyAccelerationStructureToMemoryKHR(VkCommandBuffer a_0, const VkCopyAccelerationStructureToMemoryInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdCopyMemoryToAccelerationStructureKHR"))) auto vkCmdCopyMemoryToAccelerationStructureKHR(VkCommandBuffer a_0, const VkCopyMemoryToAccelerationStructureInfoKHR * a_1) -> void;
__attribute__((alias("fexfn_pack_vkGetAccelerationStructureDeviceAddressKHR"))) auto vkGetAccelerationStructureDeviceAddressKHR(VkDevice a_0, const VkAccelerationStructureDeviceAddressInfoKHR * a_1) -> VkDeviceAddress;
__attribute__((alias("fexfn_pack_vkCmdWriteAccelerationStructuresPropertiesKHR"))) auto vkCmdWriteAccelerationStructuresPropertiesKHR(VkCommandBuffer a_0, uint32_t a_1, const VkAccelerationStructureKHR * a_2, VkQueryType a_3, VkQueryPool a_4, uint32_t a_5) -> void;
__attribute__((alias("fexfn_pack_vkGetDeviceAccelerationStructureCompatibilityKHR"))) auto vkGetDeviceAccelerationStructureCompatibilityKHR(VkDevice a_0, const VkAccelerationStructureVersionInfoKHR * a_1, VkAccelerationStructureCompatibilityKHR * a_2) -> void;
__attribute__((alias("fexfn_pack_vkGetAccelerationStructureBuildSizesKHR"))) auto vkGetAccelerationStructureBuildSizesKHR(VkDevice a_0, VkAccelerationStructureBuildTypeKHR a_1, const VkAccelerationStructureBuildGeometryInfoKHR * a_2, const uint32_t * a_3, VkAccelerationStructureBuildSizesInfoKHR * a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdTraceRaysKHR"))) auto vkCmdTraceRaysKHR(VkCommandBuffer a_0, const VkStridedDeviceAddressRegionKHR * a_1, const VkStridedDeviceAddressRegionKHR * a_2, const VkStridedDeviceAddressRegionKHR * a_3, const VkStridedDeviceAddressRegionKHR * a_4, uint32_t a_5, uint32_t a_6, uint32_t a_7) -> void;
__attribute__((alias("fexfn_pack_vkCreateRayTracingPipelinesKHR"))) auto vkCreateRayTracingPipelinesKHR(VkDevice a_0, VkDeferredOperationKHR a_1, VkPipelineCache a_2, uint32_t a_3, const VkRayTracingPipelineCreateInfoKHR * a_4, const VkAllocationCallbacks * a_5, VkPipeline * a_6) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetRayTracingCaptureReplayShaderGroupHandlesKHR"))) auto vkGetRayTracingCaptureReplayShaderGroupHandlesKHR(VkDevice a_0, VkPipeline a_1, uint32_t a_2, uint32_t a_3, size_t a_4, void * a_5) -> VkResult;
__attribute__((alias("fexfn_pack_vkCmdTraceRaysIndirectKHR"))) auto vkCmdTraceRaysIndirectKHR(VkCommandBuffer a_0, const VkStridedDeviceAddressRegionKHR * a_1, const VkStridedDeviceAddressRegionKHR * a_2, const VkStridedDeviceAddressRegionKHR * a_3, const VkStridedDeviceAddressRegionKHR * a_4, VkDeviceAddress a_5) -> void;
__attribute__((alias("fexfn_pack_vkGetRayTracingShaderGroupStackSizeKHR"))) auto vkGetRayTracingShaderGroupStackSizeKHR(VkDevice a_0, VkPipeline a_1, uint32_t a_2, VkShaderGroupShaderKHR a_3) -> VkDeviceSize;
__attribute__((alias("fexfn_pack_vkCmdSetRayTracingPipelineStackSizeKHR"))) auto vkCmdSetRayTracingPipelineStackSizeKHR(VkCommandBuffer a_0, uint32_t a_1) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawMeshTasksEXT"))) auto vkCmdDrawMeshTasksEXT(VkCommandBuffer a_0, uint32_t a_1, uint32_t a_2, uint32_t a_3) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawMeshTasksIndirectEXT"))) auto vkCmdDrawMeshTasksIndirectEXT(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, uint32_t a_3, uint32_t a_4) -> void;
__attribute__((alias("fexfn_pack_vkCmdDrawMeshTasksIndirectCountEXT"))) auto vkCmdDrawMeshTasksIndirectCountEXT(VkCommandBuffer a_0, VkBuffer a_1, VkDeviceSize a_2, VkBuffer a_3, VkDeviceSize a_4, uint32_t a_5, uint32_t a_6) -> void;
__attribute__((alias("fexfn_pack_vkAcquireXlibDisplayEXT"))) auto vkAcquireXlibDisplayEXT(VkPhysicalDevice a_0, Display * a_1, VkDisplayKHR a_2) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetRandROutputDisplayEXT"))) auto vkGetRandROutputDisplayEXT(VkPhysicalDevice a_0, Display * a_1, RROutput a_2, VkDisplayKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkCreateWaylandSurfaceKHR"))) auto vkCreateWaylandSurfaceKHR(VkInstance a_0, const VkWaylandSurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceWaylandPresentationSupportKHR"))) auto vkGetPhysicalDeviceWaylandPresentationSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, struct wl_display * a_2) -> VkBool32;
__attribute__((alias("fexfn_pack_vkCreateXcbSurfaceKHR"))) auto vkCreateXcbSurfaceKHR(VkInstance a_0, const VkXcbSurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceXcbPresentationSupportKHR"))) auto vkGetPhysicalDeviceXcbPresentationSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, xcb_connection_t * a_2, xcb_visualid_t a_3) -> VkBool32;
__attribute__((alias("fexfn_pack_vkCreateXlibSurfaceKHR"))) auto vkCreateXlibSurfaceKHR(VkInstance a_0, const VkXlibSurfaceCreateInfoKHR * a_1, const VkAllocationCallbacks * a_2, VkSurfaceKHR * a_3) -> VkResult;
__attribute__((alias("fexfn_pack_vkGetPhysicalDeviceXlibPresentationSupportKHR"))) auto vkGetPhysicalDeviceXlibPresentationSupportKHR(VkPhysicalDevice a_0, uint32_t a_1, Display * a_2, VisualID a_3) -> VkBool32;
}
#define FOREACH_SYMBOL(EXPAND) \
  EXPAND(vkGetDeviceProcAddr, "TODO") \
  EXPAND(vkGetInstanceProcAddr, "TODO") \
  EXPAND(Vulkan_SetGuestXSync, "TODO") \
  EXPAND(Vulkan_SetGuestXGetVisualInfo, "TODO") \
  EXPAND(Vulkan_SetGuestXDisplayString, "TODO") \

#define FOREACH_internal_SYMBOL(EXPAND) \
  EXPAND(vkCreateInstance, "TODO") \
  EXPAND(vkDestroyInstance, "TODO") \
  EXPAND(vkEnumeratePhysicalDevices, "TODO") \
  EXPAND(vkGetPhysicalDeviceFeatures, "TODO") \
  EXPAND(vkGetPhysicalDeviceFormatProperties, "TODO") \
  EXPAND(vkGetPhysicalDeviceImageFormatProperties, "TODO") \
  EXPAND(vkGetPhysicalDeviceProperties, "TODO") \
  EXPAND(vkGetPhysicalDeviceQueueFamilyProperties, "TODO") \
  EXPAND(vkGetPhysicalDeviceMemoryProperties, "TODO") \
  EXPAND(vkCreateDevice, "TODO") \
  EXPAND(vkDestroyDevice, "TODO") \
  EXPAND(vkEnumerateInstanceExtensionProperties, "TODO") \
  EXPAND(vkEnumerateDeviceExtensionProperties, "TODO") \
  EXPAND(vkEnumerateInstanceLayerProperties, "TODO") \
  EXPAND(vkEnumerateDeviceLayerProperties, "TODO") \
  EXPAND(vkGetDeviceQueue, "TODO") \
  EXPAND(vkQueueSubmit, "TODO") \
  EXPAND(vkQueueWaitIdle, "TODO") \
  EXPAND(vkDeviceWaitIdle, "TODO") \
  EXPAND(vkAllocateMemory, "TODO") \
  EXPAND(vkFreeMemory, "TODO") \
  EXPAND(vkMapMemory, "TODO") \
  EXPAND(vkUnmapMemory, "TODO") \
  EXPAND(vkFlushMappedMemoryRanges, "TODO") \
  EXPAND(vkInvalidateMappedMemoryRanges, "TODO") \
  EXPAND(vkGetDeviceMemoryCommitment, "TODO") \
  EXPAND(vkBindBufferMemory, "TODO") \
  EXPAND(vkBindImageMemory, "TODO") \
  EXPAND(vkGetBufferMemoryRequirements, "TODO") \
  EXPAND(vkGetImageMemoryRequirements, "TODO") \
  EXPAND(vkGetImageSparseMemoryRequirements, "TODO") \
  EXPAND(vkGetPhysicalDeviceSparseImageFormatProperties, "TODO") \
  EXPAND(vkQueueBindSparse, "TODO") \
  EXPAND(vkCreateFence, "TODO") \
  EXPAND(vkDestroyFence, "TODO") \
  EXPAND(vkResetFences, "TODO") \
  EXPAND(vkGetFenceStatus, "TODO") \
  EXPAND(vkWaitForFences, "TODO") \
  EXPAND(vkCreateSemaphore, "TODO") \
  EXPAND(vkDestroySemaphore, "TODO") \
  EXPAND(vkCreateQueryPool, "TODO") \
  EXPAND(vkDestroyQueryPool, "TODO") \
  EXPAND(vkGetQueryPoolResults, "TODO") \
  EXPAND(vkCreateBuffer, "TODO") \
  EXPAND(vkDestroyBuffer, "TODO") \
  EXPAND(vkCreateImage, "TODO") \
  EXPAND(vkDestroyImage, "TODO") \
  EXPAND(vkGetImageSubresourceLayout, "TODO") \
  EXPAND(vkCreateImageView, "TODO") \
  EXPAND(vkDestroyImageView, "TODO") \
  EXPAND(vkCreateCommandPool, "TODO") \
  EXPAND(vkDestroyCommandPool, "TODO") \
  EXPAND(vkResetCommandPool, "TODO") \
  EXPAND(vkAllocateCommandBuffers, "TODO") \
  EXPAND(vkFreeCommandBuffers, "TODO") \
  EXPAND(vkBeginCommandBuffer, "TODO") \
  EXPAND(vkEndCommandBuffer, "TODO") \
  EXPAND(vkResetCommandBuffer, "TODO") \
  EXPAND(vkCmdCopyBuffer, "TODO") \
  EXPAND(vkCmdCopyImage, "TODO") \
  EXPAND(vkCmdCopyBufferToImage, "TODO") \
  EXPAND(vkCmdCopyImageToBuffer, "TODO") \
  EXPAND(vkCmdUpdateBuffer, "TODO") \
  EXPAND(vkCmdFillBuffer, "TODO") \
  EXPAND(vkCmdPipelineBarrier, "TODO") \
  EXPAND(vkCmdBeginQuery, "TODO") \
  EXPAND(vkCmdEndQuery, "TODO") \
  EXPAND(vkCmdResetQueryPool, "TODO") \
  EXPAND(vkCmdWriteTimestamp, "TODO") \
  EXPAND(vkCmdCopyQueryPoolResults, "TODO") \
  EXPAND(vkCmdExecuteCommands, "TODO") \
  EXPAND(vkCreateEvent, "TODO") \
  EXPAND(vkDestroyEvent, "TODO") \
  EXPAND(vkGetEventStatus, "TODO") \
  EXPAND(vkSetEvent, "TODO") \
  EXPAND(vkResetEvent, "TODO") \
  EXPAND(vkCreateBufferView, "TODO") \
  EXPAND(vkDestroyBufferView, "TODO") \
  EXPAND(vkCreateShaderModule, "TODO") \
  EXPAND(vkDestroyShaderModule, "TODO") \
  EXPAND(vkCreatePipelineCache, "TODO") \
  EXPAND(vkDestroyPipelineCache, "TODO") \
  EXPAND(vkGetPipelineCacheData, "TODO") \
  EXPAND(vkMergePipelineCaches, "TODO") \
  EXPAND(vkCreateComputePipelines, "TODO") \
  EXPAND(vkDestroyPipeline, "TODO") \
  EXPAND(vkCreatePipelineLayout, "TODO") \
  EXPAND(vkDestroyPipelineLayout, "TODO") \
  EXPAND(vkCreateSampler, "TODO") \
  EXPAND(vkDestroySampler, "TODO") \
  EXPAND(vkCreateDescriptorSetLayout, "TODO") \
  EXPAND(vkDestroyDescriptorSetLayout, "TODO") \
  EXPAND(vkCreateDescriptorPool, "TODO") \
  EXPAND(vkDestroyDescriptorPool, "TODO") \
  EXPAND(vkResetDescriptorPool, "TODO") \
  EXPAND(vkAllocateDescriptorSets, "TODO") \
  EXPAND(vkFreeDescriptorSets, "TODO") \
  EXPAND(vkUpdateDescriptorSets, "TODO") \
  EXPAND(vkCmdBindPipeline, "TODO") \
  EXPAND(vkCmdBindDescriptorSets, "TODO") \
  EXPAND(vkCmdClearColorImage, "TODO") \
  EXPAND(vkCmdDispatch, "TODO") \
  EXPAND(vkCmdDispatchIndirect, "TODO") \
  EXPAND(vkCmdSetEvent, "TODO") \
  EXPAND(vkCmdResetEvent, "TODO") \
  EXPAND(vkCmdWaitEvents, "TODO") \
  EXPAND(vkCmdPushConstants, "TODO") \
  EXPAND(vkCreateGraphicsPipelines, "TODO") \
  EXPAND(vkCreateFramebuffer, "TODO") \
  EXPAND(vkDestroyFramebuffer, "TODO") \
  EXPAND(vkCreateRenderPass, "TODO") \
  EXPAND(vkDestroyRenderPass, "TODO") \
  EXPAND(vkGetRenderAreaGranularity, "TODO") \
  EXPAND(vkCmdSetViewport, "TODO") \
  EXPAND(vkCmdSetScissor, "TODO") \
  EXPAND(vkCmdSetLineWidth, "TODO") \
  EXPAND(vkCmdSetDepthBias, "TODO") \
  EXPAND(vkCmdSetBlendConstants, "TODO") \
  EXPAND(vkCmdSetDepthBounds, "TODO") \
  EXPAND(vkCmdSetStencilCompareMask, "TODO") \
  EXPAND(vkCmdSetStencilWriteMask, "TODO") \
  EXPAND(vkCmdSetStencilReference, "TODO") \
  EXPAND(vkCmdBindIndexBuffer, "TODO") \
  EXPAND(vkCmdBindVertexBuffers, "TODO") \
  EXPAND(vkCmdDraw, "TODO") \
  EXPAND(vkCmdDrawIndexed, "TODO") \
  EXPAND(vkCmdDrawIndirect, "TODO") \
  EXPAND(vkCmdDrawIndexedIndirect, "TODO") \
  EXPAND(vkCmdBlitImage, "TODO") \
  EXPAND(vkCmdClearDepthStencilImage, "TODO") \
  EXPAND(vkCmdClearAttachments, "TODO") \
  EXPAND(vkCmdResolveImage, "TODO") \
  EXPAND(vkCmdBeginRenderPass, "TODO") \
  EXPAND(vkCmdNextSubpass, "TODO") \
  EXPAND(vkCmdEndRenderPass, "TODO") \
  EXPAND(vkEnumerateInstanceVersion, "TODO") \
  EXPAND(vkBindBufferMemory2, "TODO") \
  EXPAND(vkBindImageMemory2, "TODO") \
  EXPAND(vkGetDeviceGroupPeerMemoryFeatures, "TODO") \
  EXPAND(vkCmdSetDeviceMask, "TODO") \
  EXPAND(vkEnumeratePhysicalDeviceGroups, "TODO") \
  EXPAND(vkGetImageMemoryRequirements2, "TODO") \
  EXPAND(vkGetBufferMemoryRequirements2, "TODO") \
  EXPAND(vkGetImageSparseMemoryRequirements2, "TODO") \
  EXPAND(vkGetPhysicalDeviceFeatures2, "TODO") \
  EXPAND(vkGetPhysicalDeviceProperties2, "TODO") \
  EXPAND(vkGetPhysicalDeviceFormatProperties2, "TODO") \
  EXPAND(vkGetPhysicalDeviceImageFormatProperties2, "TODO") \
  EXPAND(vkGetPhysicalDeviceQueueFamilyProperties2, "TODO") \
  EXPAND(vkGetPhysicalDeviceMemoryProperties2, "TODO") \
  EXPAND(vkGetPhysicalDeviceSparseImageFormatProperties2, "TODO") \
  EXPAND(vkTrimCommandPool, "TODO") \
  EXPAND(vkGetDeviceQueue2, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalBufferProperties, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalFenceProperties, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalSemaphoreProperties, "TODO") \
  EXPAND(vkCmdDispatchBase, "TODO") \
  EXPAND(vkCreateDescriptorUpdateTemplate, "TODO") \
  EXPAND(vkDestroyDescriptorUpdateTemplate, "TODO") \
  EXPAND(vkUpdateDescriptorSetWithTemplate, "TODO") \
  EXPAND(vkGetDescriptorSetLayoutSupport, "TODO") \
  EXPAND(vkCreateSamplerYcbcrConversion, "TODO") \
  EXPAND(vkDestroySamplerYcbcrConversion, "TODO") \
  EXPAND(vkResetQueryPool, "TODO") \
  EXPAND(vkGetSemaphoreCounterValue, "TODO") \
  EXPAND(vkWaitSemaphores, "TODO") \
  EXPAND(vkSignalSemaphore, "TODO") \
  EXPAND(vkGetBufferDeviceAddress, "TODO") \
  EXPAND(vkGetBufferOpaqueCaptureAddress, "TODO") \
  EXPAND(vkGetDeviceMemoryOpaqueCaptureAddress, "TODO") \
  EXPAND(vkCmdDrawIndirectCount, "TODO") \
  EXPAND(vkCmdDrawIndexedIndirectCount, "TODO") \
  EXPAND(vkCreateRenderPass2, "TODO") \
  EXPAND(vkCmdBeginRenderPass2, "TODO") \
  EXPAND(vkCmdNextSubpass2, "TODO") \
  EXPAND(vkCmdEndRenderPass2, "TODO") \
  EXPAND(vkGetPhysicalDeviceToolProperties, "TODO") \
  EXPAND(vkCreatePrivateDataSlot, "TODO") \
  EXPAND(vkDestroyPrivateDataSlot, "TODO") \
  EXPAND(vkSetPrivateData, "TODO") \
  EXPAND(vkGetPrivateData, "TODO") \
  EXPAND(vkCmdPipelineBarrier2, "TODO") \
  EXPAND(vkCmdWriteTimestamp2, "TODO") \
  EXPAND(vkQueueSubmit2, "TODO") \
  EXPAND(vkCmdCopyBuffer2, "TODO") \
  EXPAND(vkCmdCopyImage2, "TODO") \
  EXPAND(vkCmdCopyBufferToImage2, "TODO") \
  EXPAND(vkCmdCopyImageToBuffer2, "TODO") \
  EXPAND(vkGetDeviceBufferMemoryRequirements, "TODO") \
  EXPAND(vkGetDeviceImageMemoryRequirements, "TODO") \
  EXPAND(vkGetDeviceImageSparseMemoryRequirements, "TODO") \
  EXPAND(vkCmdSetEvent2, "TODO") \
  EXPAND(vkCmdResetEvent2, "TODO") \
  EXPAND(vkCmdWaitEvents2, "TODO") \
  EXPAND(vkCmdBlitImage2, "TODO") \
  EXPAND(vkCmdResolveImage2, "TODO") \
  EXPAND(vkCmdBeginRendering, "TODO") \
  EXPAND(vkCmdEndRendering, "TODO") \
  EXPAND(vkCmdSetCullMode, "TODO") \
  EXPAND(vkCmdSetFrontFace, "TODO") \
  EXPAND(vkCmdSetPrimitiveTopology, "TODO") \
  EXPAND(vkCmdSetViewportWithCount, "TODO") \
  EXPAND(vkCmdSetScissorWithCount, "TODO") \
  EXPAND(vkCmdBindVertexBuffers2, "TODO") \
  EXPAND(vkCmdSetDepthTestEnable, "TODO") \
  EXPAND(vkCmdSetDepthWriteEnable, "TODO") \
  EXPAND(vkCmdSetDepthCompareOp, "TODO") \
  EXPAND(vkCmdSetDepthBoundsTestEnable, "TODO") \
  EXPAND(vkCmdSetStencilTestEnable, "TODO") \
  EXPAND(vkCmdSetStencilOp, "TODO") \
  EXPAND(vkCmdSetRasterizerDiscardEnable, "TODO") \
  EXPAND(vkCmdSetDepthBiasEnable, "TODO") \
  EXPAND(vkCmdSetPrimitiveRestartEnable, "TODO") \
  EXPAND(vkMapMemory2, "TODO") \
  EXPAND(vkUnmapMemory2, "TODO") \
  EXPAND(vkGetDeviceImageSubresourceLayout, "TODO") \
  EXPAND(vkGetImageSubresourceLayout2, "TODO") \
  EXPAND(vkCopyMemoryToImage, "TODO") \
  EXPAND(vkCopyImageToMemory, "TODO") \
  EXPAND(vkCopyImageToImage, "TODO") \
  EXPAND(vkTransitionImageLayout, "TODO") \
  EXPAND(vkCmdPushDescriptorSet, "TODO") \
  EXPAND(vkCmdPushDescriptorSetWithTemplate, "TODO") \
  EXPAND(vkCmdBindDescriptorSets2, "TODO") \
  EXPAND(vkCmdPushConstants2, "TODO") \
  EXPAND(vkCmdPushDescriptorSet2, "TODO") \
  EXPAND(vkCmdPushDescriptorSetWithTemplate2, "TODO") \
  EXPAND(vkCmdSetLineStipple, "TODO") \
  EXPAND(vkCmdBindIndexBuffer2, "TODO") \
  EXPAND(vkGetRenderingAreaGranularity, "TODO") \
  EXPAND(vkCmdSetRenderingAttachmentLocations, "TODO") \
  EXPAND(vkCmdSetRenderingInputAttachmentIndices, "TODO") \
  EXPAND(vkDestroySurfaceKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceSurfaceSupportKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceSurfaceCapabilitiesKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceSurfaceFormatsKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceSurfacePresentModesKHR, "TODO") \
  EXPAND(vkCreateSwapchainKHR, "TODO") \
  EXPAND(vkDestroySwapchainKHR, "TODO") \
  EXPAND(vkGetSwapchainImagesKHR, "TODO") \
  EXPAND(vkAcquireNextImageKHR, "TODO") \
  EXPAND(vkQueuePresentKHR, "TODO") \
  EXPAND(vkGetDeviceGroupPresentCapabilitiesKHR, "TODO") \
  EXPAND(vkGetDeviceGroupSurfacePresentModesKHR, "TODO") \
  EXPAND(vkGetPhysicalDevicePresentRectanglesKHR, "TODO") \
  EXPAND(vkAcquireNextImage2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceDisplayPropertiesKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceDisplayPlanePropertiesKHR, "TODO") \
  EXPAND(vkGetDisplayPlaneSupportedDisplaysKHR, "TODO") \
  EXPAND(vkGetDisplayModePropertiesKHR, "TODO") \
  EXPAND(vkCreateDisplayModeKHR, "TODO") \
  EXPAND(vkGetDisplayPlaneCapabilitiesKHR, "TODO") \
  EXPAND(vkCreateDisplayPlaneSurfaceKHR, "TODO") \
  EXPAND(vkCreateSharedSwapchainsKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceVideoCapabilitiesKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceVideoFormatPropertiesKHR, "TODO") \
  EXPAND(vkCreateVideoSessionKHR, "TODO") \
  EXPAND(vkDestroyVideoSessionKHR, "TODO") \
  EXPAND(vkGetVideoSessionMemoryRequirementsKHR, "TODO") \
  EXPAND(vkBindVideoSessionMemoryKHR, "TODO") \
  EXPAND(vkCreateVideoSessionParametersKHR, "TODO") \
  EXPAND(vkUpdateVideoSessionParametersKHR, "TODO") \
  EXPAND(vkDestroyVideoSessionParametersKHR, "TODO") \
  EXPAND(vkCmdBeginVideoCodingKHR, "TODO") \
  EXPAND(vkCmdEndVideoCodingKHR, "TODO") \
  EXPAND(vkCmdControlVideoCodingKHR, "TODO") \
  EXPAND(vkCmdDecodeVideoKHR, "TODO") \
  EXPAND(vkCmdBeginRenderingKHR, "TODO") \
  EXPAND(vkCmdEndRenderingKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceFeatures2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceProperties2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceFormatProperties2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceImageFormatProperties2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceQueueFamilyProperties2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceMemoryProperties2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceSparseImageFormatProperties2KHR, "TODO") \
  EXPAND(vkGetDeviceGroupPeerMemoryFeaturesKHR, "TODO") \
  EXPAND(vkCmdSetDeviceMaskKHR, "TODO") \
  EXPAND(vkCmdDispatchBaseKHR, "TODO") \
  EXPAND(vkTrimCommandPoolKHR, "TODO") \
  EXPAND(vkEnumeratePhysicalDeviceGroupsKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalBufferPropertiesKHR, "TODO") \
  EXPAND(vkGetMemoryFdKHR, "TODO") \
  EXPAND(vkGetMemoryFdPropertiesKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalSemaphorePropertiesKHR, "TODO") \
  EXPAND(vkImportSemaphoreFdKHR, "TODO") \
  EXPAND(vkGetSemaphoreFdKHR, "TODO") \
  EXPAND(vkCmdPushDescriptorSetKHR, "TODO") \
  EXPAND(vkCmdPushDescriptorSetWithTemplateKHR, "TODO") \
  EXPAND(vkCreateDescriptorUpdateTemplateKHR, "TODO") \
  EXPAND(vkDestroyDescriptorUpdateTemplateKHR, "TODO") \
  EXPAND(vkUpdateDescriptorSetWithTemplateKHR, "TODO") \
  EXPAND(vkCreateRenderPass2KHR, "TODO") \
  EXPAND(vkCmdBeginRenderPass2KHR, "TODO") \
  EXPAND(vkCmdNextSubpass2KHR, "TODO") \
  EXPAND(vkCmdEndRenderPass2KHR, "TODO") \
  EXPAND(vkGetSwapchainStatusKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalFencePropertiesKHR, "TODO") \
  EXPAND(vkImportFenceFdKHR, "TODO") \
  EXPAND(vkGetFenceFdKHR, "TODO") \
  EXPAND(vkEnumeratePhysicalDeviceQueueFamilyPerformanceQueryCountersKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceQueueFamilyPerformanceQueryPassesKHR, "TODO") \
  EXPAND(vkAcquireProfilingLockKHR, "TODO") \
  EXPAND(vkReleaseProfilingLockKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceSurfaceCapabilities2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceSurfaceFormats2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceDisplayProperties2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceDisplayPlaneProperties2KHR, "TODO") \
  EXPAND(vkGetDisplayModeProperties2KHR, "TODO") \
  EXPAND(vkGetDisplayPlaneCapabilities2KHR, "TODO") \
  EXPAND(vkGetImageMemoryRequirements2KHR, "TODO") \
  EXPAND(vkGetBufferMemoryRequirements2KHR, "TODO") \
  EXPAND(vkGetImageSparseMemoryRequirements2KHR, "TODO") \
  EXPAND(vkCreateSamplerYcbcrConversionKHR, "TODO") \
  EXPAND(vkDestroySamplerYcbcrConversionKHR, "TODO") \
  EXPAND(vkBindBufferMemory2KHR, "TODO") \
  EXPAND(vkBindImageMemory2KHR, "TODO") \
  EXPAND(vkGetDescriptorSetLayoutSupportKHR, "TODO") \
  EXPAND(vkCmdDrawIndirectCountKHR, "TODO") \
  EXPAND(vkCmdDrawIndexedIndirectCountKHR, "TODO") \
  EXPAND(vkGetSemaphoreCounterValueKHR, "TODO") \
  EXPAND(vkWaitSemaphoresKHR, "TODO") \
  EXPAND(vkSignalSemaphoreKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceFragmentShadingRatesKHR, "TODO") \
  EXPAND(vkCmdSetFragmentShadingRateKHR, "TODO") \
  EXPAND(vkCmdSetRenderingAttachmentLocationsKHR, "TODO") \
  EXPAND(vkCmdSetRenderingInputAttachmentIndicesKHR, "TODO") \
  EXPAND(vkWaitForPresentKHR, "TODO") \
  EXPAND(vkGetBufferDeviceAddressKHR, "TODO") \
  EXPAND(vkGetBufferOpaqueCaptureAddressKHR, "TODO") \
  EXPAND(vkGetDeviceMemoryOpaqueCaptureAddressKHR, "TODO") \
  EXPAND(vkCreateDeferredOperationKHR, "TODO") \
  EXPAND(vkDestroyDeferredOperationKHR, "TODO") \
  EXPAND(vkGetDeferredOperationMaxConcurrencyKHR, "TODO") \
  EXPAND(vkGetDeferredOperationResultKHR, "TODO") \
  EXPAND(vkDeferredOperationJoinKHR, "TODO") \
  EXPAND(vkGetPipelineExecutablePropertiesKHR, "TODO") \
  EXPAND(vkGetPipelineExecutableStatisticsKHR, "TODO") \
  EXPAND(vkGetPipelineExecutableInternalRepresentationsKHR, "TODO") \
  EXPAND(vkMapMemory2KHR, "TODO") \
  EXPAND(vkUnmapMemory2KHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceVideoEncodeQualityLevelPropertiesKHR, "TODO") \
  EXPAND(vkGetEncodedVideoSessionParametersKHR, "TODO") \
  EXPAND(vkCmdEncodeVideoKHR, "TODO") \
  EXPAND(vkCmdSetEvent2KHR, "TODO") \
  EXPAND(vkCmdResetEvent2KHR, "TODO") \
  EXPAND(vkCmdWaitEvents2KHR, "TODO") \
  EXPAND(vkCmdPipelineBarrier2KHR, "TODO") \
  EXPAND(vkCmdWriteTimestamp2KHR, "TODO") \
  EXPAND(vkQueueSubmit2KHR, "TODO") \
  EXPAND(vkCmdCopyBuffer2KHR, "TODO") \
  EXPAND(vkCmdCopyImage2KHR, "TODO") \
  EXPAND(vkCmdCopyBufferToImage2KHR, "TODO") \
  EXPAND(vkCmdCopyImageToBuffer2KHR, "TODO") \
  EXPAND(vkCmdBlitImage2KHR, "TODO") \
  EXPAND(vkCmdResolveImage2KHR, "TODO") \
  EXPAND(vkCmdTraceRaysIndirect2KHR, "TODO") \
  EXPAND(vkGetDeviceBufferMemoryRequirementsKHR, "TODO") \
  EXPAND(vkGetDeviceImageMemoryRequirementsKHR, "TODO") \
  EXPAND(vkGetDeviceImageSparseMemoryRequirementsKHR, "TODO") \
  EXPAND(vkCmdBindIndexBuffer2KHR, "TODO") \
  EXPAND(vkGetRenderingAreaGranularityKHR, "TODO") \
  EXPAND(vkGetDeviceImageSubresourceLayoutKHR, "TODO") \
  EXPAND(vkGetImageSubresourceLayout2KHR, "TODO") \
  EXPAND(vkWaitForPresent2KHR, "TODO") \
  EXPAND(vkCreatePipelineBinariesKHR, "TODO") \
  EXPAND(vkDestroyPipelineBinaryKHR, "TODO") \
  EXPAND(vkGetPipelineKeyKHR, "TODO") \
  EXPAND(vkGetPipelineBinaryDataKHR, "TODO") \
  EXPAND(vkReleaseCapturedPipelineDataKHR, "TODO") \
  EXPAND(vkReleaseSwapchainImagesKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceCooperativeMatrixPropertiesKHR, "TODO") \
  EXPAND(vkCmdSetLineStippleKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceCalibrateableTimeDomainsKHR, "TODO") \
  EXPAND(vkGetCalibratedTimestampsKHR, "TODO") \
  EXPAND(vkCmdBindDescriptorSets2KHR, "TODO") \
  EXPAND(vkCmdPushConstants2KHR, "TODO") \
  EXPAND(vkCmdPushDescriptorSet2KHR, "TODO") \
  EXPAND(vkCmdPushDescriptorSetWithTemplate2KHR, "TODO") \
  EXPAND(vkCmdSetDescriptorBufferOffsets2EXT, "TODO") \
  EXPAND(vkCmdBindDescriptorBufferEmbeddedSamplers2EXT, "TODO") \
  EXPAND(vkCmdCopyMemoryIndirectKHR, "TODO") \
  EXPAND(vkCmdCopyMemoryToImageIndirectKHR, "TODO") \
  EXPAND(vkCmdEndRendering2KHR, "TODO") \
  EXPAND(vkCreateDebugReportCallbackEXT, "TODO") \
  EXPAND(vkDestroyDebugReportCallbackEXT, "TODO") \
  EXPAND(vkDebugReportMessageEXT, "TODO") \
  EXPAND(vkDebugMarkerSetObjectTagEXT, "TODO") \
  EXPAND(vkDebugMarkerSetObjectNameEXT, "TODO") \
  EXPAND(vkCmdDebugMarkerBeginEXT, "TODO") \
  EXPAND(vkCmdDebugMarkerEndEXT, "TODO") \
  EXPAND(vkCmdDebugMarkerInsertEXT, "TODO") \
  EXPAND(vkCmdBindTransformFeedbackBuffersEXT, "TODO") \
  EXPAND(vkCmdBeginTransformFeedbackEXT, "TODO") \
  EXPAND(vkCmdEndTransformFeedbackEXT, "TODO") \
  EXPAND(vkCmdBeginQueryIndexedEXT, "TODO") \
  EXPAND(vkCmdEndQueryIndexedEXT, "TODO") \
  EXPAND(vkCmdDrawIndirectByteCountEXT, "TODO") \
  EXPAND(vkCreateCuModuleNVX, "TODO") \
  EXPAND(vkCreateCuFunctionNVX, "TODO") \
  EXPAND(vkDestroyCuModuleNVX, "TODO") \
  EXPAND(vkDestroyCuFunctionNVX, "TODO") \
  EXPAND(vkCmdCuLaunchKernelNVX, "TODO") \
  EXPAND(vkGetImageViewHandleNVX, "TODO") \
  EXPAND(vkGetImageViewHandle64NVX, "TODO") \
  EXPAND(vkGetImageViewAddressNVX, "TODO") \
  EXPAND(vkCmdDrawIndirectCountAMD, "TODO") \
  EXPAND(vkCmdDrawIndexedIndirectCountAMD, "TODO") \
  EXPAND(vkGetShaderInfoAMD, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalImageFormatPropertiesNV, "TODO") \
  EXPAND(vkCmdBeginConditionalRenderingEXT, "TODO") \
  EXPAND(vkCmdEndConditionalRenderingEXT, "TODO") \
  EXPAND(vkCmdSetViewportWScalingNV, "TODO") \
  EXPAND(vkReleaseDisplayEXT, "TODO") \
  EXPAND(vkGetPhysicalDeviceSurfaceCapabilities2EXT, "TODO") \
  EXPAND(vkDisplayPowerControlEXT, "TODO") \
  EXPAND(vkRegisterDeviceEventEXT, "TODO") \
  EXPAND(vkRegisterDisplayEventEXT, "TODO") \
  EXPAND(vkGetSwapchainCounterEXT, "TODO") \
  EXPAND(vkGetRefreshCycleDurationGOOGLE, "TODO") \
  EXPAND(vkGetPastPresentationTimingGOOGLE, "TODO") \
  EXPAND(vkCmdSetDiscardRectangleEXT, "TODO") \
  EXPAND(vkCmdSetDiscardRectangleEnableEXT, "TODO") \
  EXPAND(vkCmdSetDiscardRectangleModeEXT, "TODO") \
  EXPAND(vkSetHdrMetadataEXT, "TODO") \
  EXPAND(vkSetDebugUtilsObjectNameEXT, "TODO") \
  EXPAND(vkSetDebugUtilsObjectTagEXT, "TODO") \
  EXPAND(vkQueueBeginDebugUtilsLabelEXT, "TODO") \
  EXPAND(vkQueueEndDebugUtilsLabelEXT, "TODO") \
  EXPAND(vkQueueInsertDebugUtilsLabelEXT, "TODO") \
  EXPAND(vkCmdBeginDebugUtilsLabelEXT, "TODO") \
  EXPAND(vkCmdEndDebugUtilsLabelEXT, "TODO") \
  EXPAND(vkCmdInsertDebugUtilsLabelEXT, "TODO") \
  EXPAND(vkCreateDebugUtilsMessengerEXT, "TODO") \
  EXPAND(vkDestroyDebugUtilsMessengerEXT, "TODO") \
  EXPAND(vkSubmitDebugUtilsMessageEXT, "TODO") \
  EXPAND(vkCmdSetSampleLocationsEXT, "TODO") \
  EXPAND(vkGetPhysicalDeviceMultisamplePropertiesEXT, "TODO") \
  EXPAND(vkGetImageDrmFormatModifierPropertiesEXT, "TODO") \
  EXPAND(vkCreateValidationCacheEXT, "TODO") \
  EXPAND(vkDestroyValidationCacheEXT, "TODO") \
  EXPAND(vkMergeValidationCachesEXT, "TODO") \
  EXPAND(vkGetValidationCacheDataEXT, "TODO") \
  EXPAND(vkCmdBindShadingRateImageNV, "TODO") \
  EXPAND(vkCmdSetViewportShadingRatePaletteNV, "TODO") \
  EXPAND(vkCmdSetCoarseSampleOrderNV, "TODO") \
  EXPAND(vkCreateAccelerationStructureNV, "TODO") \
  EXPAND(vkDestroyAccelerationStructureNV, "TODO") \
  EXPAND(vkGetAccelerationStructureMemoryRequirementsNV, "TODO") \
  EXPAND(vkBindAccelerationStructureMemoryNV, "TODO") \
  EXPAND(vkCmdBuildAccelerationStructureNV, "TODO") \
  EXPAND(vkCmdCopyAccelerationStructureNV, "TODO") \
  EXPAND(vkCmdTraceRaysNV, "TODO") \
  EXPAND(vkCreateRayTracingPipelinesNV, "TODO") \
  EXPAND(vkGetRayTracingShaderGroupHandlesKHR, "TODO") \
  EXPAND(vkGetRayTracingShaderGroupHandlesNV, "TODO") \
  EXPAND(vkGetAccelerationStructureHandleNV, "TODO") \
  EXPAND(vkCmdWriteAccelerationStructuresPropertiesNV, "TODO") \
  EXPAND(vkCompileDeferredNV, "TODO") \
  EXPAND(vkGetMemoryHostPointerPropertiesEXT, "TODO") \
  EXPAND(vkCmdWriteBufferMarkerAMD, "TODO") \
  EXPAND(vkCmdWriteBufferMarker2AMD, "TODO") \
  EXPAND(vkGetPhysicalDeviceCalibrateableTimeDomainsEXT, "TODO") \
  EXPAND(vkGetCalibratedTimestampsEXT, "TODO") \
  EXPAND(vkCmdDrawMeshTasksNV, "TODO") \
  EXPAND(vkCmdDrawMeshTasksIndirectNV, "TODO") \
  EXPAND(vkCmdDrawMeshTasksIndirectCountNV, "TODO") \
  EXPAND(vkCmdSetExclusiveScissorEnableNV, "TODO") \
  EXPAND(vkCmdSetExclusiveScissorNV, "TODO") \
  EXPAND(vkCmdSetCheckpointNV, "TODO") \
  EXPAND(vkGetQueueCheckpointDataNV, "TODO") \
  EXPAND(vkGetQueueCheckpointData2NV, "TODO") \
  EXPAND(vkSetSwapchainPresentTimingQueueSizeEXT, "TODO") \
  EXPAND(vkGetSwapchainTimingPropertiesEXT, "TODO") \
  EXPAND(vkGetSwapchainTimeDomainPropertiesEXT, "TODO") \
  EXPAND(vkGetPastPresentationTimingEXT, "TODO") \
  EXPAND(vkInitializePerformanceApiINTEL, "TODO") \
  EXPAND(vkUninitializePerformanceApiINTEL, "TODO") \
  EXPAND(vkCmdSetPerformanceMarkerINTEL, "TODO") \
  EXPAND(vkCmdSetPerformanceStreamMarkerINTEL, "TODO") \
  EXPAND(vkCmdSetPerformanceOverrideINTEL, "TODO") \
  EXPAND(vkAcquirePerformanceConfigurationINTEL, "TODO") \
  EXPAND(vkReleasePerformanceConfigurationINTEL, "TODO") \
  EXPAND(vkQueueSetPerformanceConfigurationINTEL, "TODO") \
  EXPAND(vkGetPerformanceParameterINTEL, "TODO") \
  EXPAND(vkSetLocalDimmingAMD, "TODO") \
  EXPAND(vkGetBufferDeviceAddressEXT, "TODO") \
  EXPAND(vkGetPhysicalDeviceToolPropertiesEXT, "TODO") \
  EXPAND(vkGetPhysicalDeviceCooperativeMatrixPropertiesNV, "TODO") \
  EXPAND(vkGetPhysicalDeviceSupportedFramebufferMixedSamplesCombinationsNV, "TODO") \
  EXPAND(vkCreateHeadlessSurfaceEXT, "TODO") \
  EXPAND(vkCmdSetLineStippleEXT, "TODO") \
  EXPAND(vkResetQueryPoolEXT, "TODO") \
  EXPAND(vkCmdSetCullModeEXT, "TODO") \
  EXPAND(vkCmdSetFrontFaceEXT, "TODO") \
  EXPAND(vkCmdSetPrimitiveTopologyEXT, "TODO") \
  EXPAND(vkCmdSetViewportWithCountEXT, "TODO") \
  EXPAND(vkCmdSetScissorWithCountEXT, "TODO") \
  EXPAND(vkCmdBindVertexBuffers2EXT, "TODO") \
  EXPAND(vkCmdSetDepthTestEnableEXT, "TODO") \
  EXPAND(vkCmdSetDepthWriteEnableEXT, "TODO") \
  EXPAND(vkCmdSetDepthCompareOpEXT, "TODO") \
  EXPAND(vkCmdSetDepthBoundsTestEnableEXT, "TODO") \
  EXPAND(vkCmdSetStencilTestEnableEXT, "TODO") \
  EXPAND(vkCmdSetStencilOpEXT, "TODO") \
  EXPAND(vkCopyMemoryToImageEXT, "TODO") \
  EXPAND(vkCopyImageToMemoryEXT, "TODO") \
  EXPAND(vkCopyImageToImageEXT, "TODO") \
  EXPAND(vkTransitionImageLayoutEXT, "TODO") \
  EXPAND(vkGetImageSubresourceLayout2EXT, "TODO") \
  EXPAND(vkReleaseSwapchainImagesEXT, "TODO") \
  EXPAND(vkGetGeneratedCommandsMemoryRequirementsNV, "TODO") \
  EXPAND(vkCmdPreprocessGeneratedCommandsNV, "TODO") \
  EXPAND(vkCmdExecuteGeneratedCommandsNV, "TODO") \
  EXPAND(vkCmdBindPipelineShaderGroupNV, "TODO") \
  EXPAND(vkCreateIndirectCommandsLayoutNV, "TODO") \
  EXPAND(vkDestroyIndirectCommandsLayoutNV, "TODO") \
  EXPAND(vkCmdSetDepthBias2EXT, "TODO") \
  EXPAND(vkAcquireDrmDisplayEXT, "TODO") \
  EXPAND(vkGetDrmDisplayEXT, "TODO") \
  EXPAND(vkCreatePrivateDataSlotEXT, "TODO") \
  EXPAND(vkDestroyPrivateDataSlotEXT, "TODO") \
  EXPAND(vkSetPrivateDataEXT, "TODO") \
  EXPAND(vkGetPrivateDataEXT, "TODO") \
  EXPAND(vkCmdDispatchTileQCOM, "TODO") \
  EXPAND(vkCmdBeginPerTileExecutionQCOM, "TODO") \
  EXPAND(vkCmdEndPerTileExecutionQCOM, "TODO") \
  EXPAND(vkGetDescriptorSetLayoutSizeEXT, "TODO") \
  EXPAND(vkGetDescriptorSetLayoutBindingOffsetEXT, "TODO") \
  EXPAND(vkGetDescriptorEXT, "TODO") \
  EXPAND(vkCmdBindDescriptorBuffersEXT, "TODO") \
  EXPAND(vkCmdSetDescriptorBufferOffsetsEXT, "TODO") \
  EXPAND(vkCmdBindDescriptorBufferEmbeddedSamplersEXT, "TODO") \
  EXPAND(vkGetBufferOpaqueCaptureDescriptorDataEXT, "TODO") \
  EXPAND(vkGetImageOpaqueCaptureDescriptorDataEXT, "TODO") \
  EXPAND(vkGetImageViewOpaqueCaptureDescriptorDataEXT, "TODO") \
  EXPAND(vkGetSamplerOpaqueCaptureDescriptorDataEXT, "TODO") \
  EXPAND(vkGetAccelerationStructureOpaqueCaptureDescriptorDataEXT, "TODO") \
  EXPAND(vkCmdSetFragmentShadingRateEnumNV, "TODO") \
  EXPAND(vkGetDeviceFaultInfoEXT, "TODO") \
  EXPAND(vkCmdSetVertexInputEXT, "TODO") \
  EXPAND(vkGetDeviceSubpassShadingMaxWorkgroupSizeHUAWEI, "TODO") \
  EXPAND(vkCmdSubpassShadingHUAWEI, "TODO") \
  EXPAND(vkCmdBindInvocationMaskHUAWEI, "TODO") \
  EXPAND(vkGetMemoryRemoteAddressNV, "TODO") \
  EXPAND(vkGetPipelinePropertiesEXT, "TODO") \
  EXPAND(vkCmdSetPatchControlPointsEXT, "TODO") \
  EXPAND(vkCmdSetRasterizerDiscardEnableEXT, "TODO") \
  EXPAND(vkCmdSetDepthBiasEnableEXT, "TODO") \
  EXPAND(vkCmdSetLogicOpEXT, "TODO") \
  EXPAND(vkCmdSetPrimitiveRestartEnableEXT, "TODO") \
  EXPAND(vkCmdSetColorWriteEnableEXT, "TODO") \
  EXPAND(vkCmdDrawMultiEXT, "TODO") \
  EXPAND(vkCmdDrawMultiIndexedEXT, "TODO") \
  EXPAND(vkCreateMicromapEXT, "TODO") \
  EXPAND(vkDestroyMicromapEXT, "TODO") \
  EXPAND(vkCmdBuildMicromapsEXT, "TODO") \
  EXPAND(vkBuildMicromapsEXT, "TODO") \
  EXPAND(vkCopyMicromapEXT, "TODO") \
  EXPAND(vkCopyMicromapToMemoryEXT, "TODO") \
  EXPAND(vkCopyMemoryToMicromapEXT, "TODO") \
  EXPAND(vkWriteMicromapsPropertiesEXT, "TODO") \
  EXPAND(vkCmdCopyMicromapEXT, "TODO") \
  EXPAND(vkCmdCopyMicromapToMemoryEXT, "TODO") \
  EXPAND(vkCmdCopyMemoryToMicromapEXT, "TODO") \
  EXPAND(vkCmdWriteMicromapsPropertiesEXT, "TODO") \
  EXPAND(vkGetDeviceMicromapCompatibilityEXT, "TODO") \
  EXPAND(vkGetMicromapBuildSizesEXT, "TODO") \
  EXPAND(vkCmdDrawClusterHUAWEI, "TODO") \
  EXPAND(vkCmdDrawClusterIndirectHUAWEI, "TODO") \
  EXPAND(vkSetDeviceMemoryPriorityEXT, "TODO") \
  EXPAND(vkGetDescriptorSetLayoutHostMappingInfoVALVE, "TODO") \
  EXPAND(vkGetDescriptorSetHostMappingVALVE, "TODO") \
  EXPAND(vkCmdCopyMemoryIndirectNV, "TODO") \
  EXPAND(vkCmdCopyMemoryToImageIndirectNV, "TODO") \
  EXPAND(vkCmdDecompressMemoryNV, "TODO") \
  EXPAND(vkCmdDecompressMemoryIndirectCountNV, "TODO") \
  EXPAND(vkGetPipelineIndirectMemoryRequirementsNV, "TODO") \
  EXPAND(vkCmdUpdatePipelineIndirectBufferNV, "TODO") \
  EXPAND(vkGetPipelineIndirectDeviceAddressNV, "TODO") \
  EXPAND(vkCmdSetDepthClampEnableEXT, "TODO") \
  EXPAND(vkCmdSetPolygonModeEXT, "TODO") \
  EXPAND(vkCmdSetRasterizationSamplesEXT, "TODO") \
  EXPAND(vkCmdSetSampleMaskEXT, "TODO") \
  EXPAND(vkCmdSetAlphaToCoverageEnableEXT, "TODO") \
  EXPAND(vkCmdSetAlphaToOneEnableEXT, "TODO") \
  EXPAND(vkCmdSetLogicOpEnableEXT, "TODO") \
  EXPAND(vkCmdSetColorBlendEnableEXT, "TODO") \
  EXPAND(vkCmdSetColorBlendEquationEXT, "TODO") \
  EXPAND(vkCmdSetColorWriteMaskEXT, "TODO") \
  EXPAND(vkCmdSetTessellationDomainOriginEXT, "TODO") \
  EXPAND(vkCmdSetRasterizationStreamEXT, "TODO") \
  EXPAND(vkCmdSetConservativeRasterizationModeEXT, "TODO") \
  EXPAND(vkCmdSetExtraPrimitiveOverestimationSizeEXT, "TODO") \
  EXPAND(vkCmdSetDepthClipEnableEXT, "TODO") \
  EXPAND(vkCmdSetSampleLocationsEnableEXT, "TODO") \
  EXPAND(vkCmdSetColorBlendAdvancedEXT, "TODO") \
  EXPAND(vkCmdSetProvokingVertexModeEXT, "TODO") \
  EXPAND(vkCmdSetLineRasterizationModeEXT, "TODO") \
  EXPAND(vkCmdSetLineStippleEnableEXT, "TODO") \
  EXPAND(vkCmdSetDepthClipNegativeOneToOneEXT, "TODO") \
  EXPAND(vkCmdSetViewportWScalingEnableNV, "TODO") \
  EXPAND(vkCmdSetViewportSwizzleNV, "TODO") \
  EXPAND(vkCmdSetCoverageToColorEnableNV, "TODO") \
  EXPAND(vkCmdSetCoverageToColorLocationNV, "TODO") \
  EXPAND(vkCmdSetCoverageModulationModeNV, "TODO") \
  EXPAND(vkCmdSetCoverageModulationTableEnableNV, "TODO") \
  EXPAND(vkCmdSetCoverageModulationTableNV, "TODO") \
  EXPAND(vkCmdSetShadingRateImageEnableNV, "TODO") \
  EXPAND(vkCmdSetRepresentativeFragmentTestEnableNV, "TODO") \
  EXPAND(vkCmdSetCoverageReductionModeNV, "TODO") \
  EXPAND(vkCreateTensorARM, "TODO") \
  EXPAND(vkDestroyTensorARM, "TODO") \
  EXPAND(vkCreateTensorViewARM, "TODO") \
  EXPAND(vkDestroyTensorViewARM, "TODO") \
  EXPAND(vkGetTensorMemoryRequirementsARM, "TODO") \
  EXPAND(vkBindTensorMemoryARM, "TODO") \
  EXPAND(vkGetDeviceTensorMemoryRequirementsARM, "TODO") \
  EXPAND(vkCmdCopyTensorARM, "TODO") \
  EXPAND(vkGetPhysicalDeviceExternalTensorPropertiesARM, "TODO") \
  EXPAND(vkGetTensorOpaqueCaptureDescriptorDataARM, "TODO") \
  EXPAND(vkGetTensorViewOpaqueCaptureDescriptorDataARM, "TODO") \
  EXPAND(vkGetShaderModuleIdentifierEXT, "TODO") \
  EXPAND(vkGetShaderModuleCreateInfoIdentifierEXT, "TODO") \
  EXPAND(vkGetPhysicalDeviceOpticalFlowImageFormatsNV, "TODO") \
  EXPAND(vkCreateOpticalFlowSessionNV, "TODO") \
  EXPAND(vkDestroyOpticalFlowSessionNV, "TODO") \
  EXPAND(vkBindOpticalFlowSessionImageNV, "TODO") \
  EXPAND(vkCmdOpticalFlowExecuteNV, "TODO") \
  EXPAND(vkAntiLagUpdateAMD, "TODO") \
  EXPAND(vkCreateShadersEXT, "TODO") \
  EXPAND(vkDestroyShaderEXT, "TODO") \
  EXPAND(vkGetShaderBinaryDataEXT, "TODO") \
  EXPAND(vkCmdBindShadersEXT, "TODO") \
  EXPAND(vkCmdSetDepthClampRangeEXT, "TODO") \
  EXPAND(vkGetFramebufferTilePropertiesQCOM, "TODO") \
  EXPAND(vkGetDynamicRenderingTilePropertiesQCOM, "TODO") \
  EXPAND(vkGetPhysicalDeviceCooperativeVectorPropertiesNV, "TODO") \
  EXPAND(vkConvertCooperativeVectorMatrixNV, "TODO") \
  EXPAND(vkCmdConvertCooperativeVectorMatrixNV, "TODO") \
  EXPAND(vkSetLatencySleepModeNV, "TODO") \
  EXPAND(vkLatencySleepNV, "TODO") \
  EXPAND(vkSetLatencyMarkerNV, "TODO") \
  EXPAND(vkGetLatencyTimingsNV, "TODO") \
  EXPAND(vkQueueNotifyOutOfBandNV, "TODO") \
  EXPAND(vkCreateDataGraphPipelinesARM, "TODO") \
  EXPAND(vkCreateDataGraphPipelineSessionARM, "TODO") \
  EXPAND(vkGetDataGraphPipelineSessionBindPointRequirementsARM, "TODO") \
  EXPAND(vkGetDataGraphPipelineSessionMemoryRequirementsARM, "TODO") \
  EXPAND(vkBindDataGraphPipelineSessionMemoryARM, "TODO") \
  EXPAND(vkDestroyDataGraphPipelineSessionARM, "TODO") \
  EXPAND(vkCmdDispatchDataGraphARM, "TODO") \
  EXPAND(vkGetDataGraphPipelineAvailablePropertiesARM, "TODO") \
  EXPAND(vkGetDataGraphPipelinePropertiesARM, "TODO") \
  EXPAND(vkGetPhysicalDeviceQueueFamilyDataGraphPropertiesARM, "TODO") \
  EXPAND(vkGetPhysicalDeviceQueueFamilyDataGraphProcessingEnginePropertiesARM, "TODO") \
  EXPAND(vkCmdSetAttachmentFeedbackLoopEnableEXT, "TODO") \
  EXPAND(vkCmdBindTileMemoryQCOM, "TODO") \
  EXPAND(vkCmdDecompressMemoryEXT, "TODO") \
  EXPAND(vkCmdDecompressMemoryIndirectCountEXT, "TODO") \
  EXPAND(vkCreateExternalComputeQueueNV, "TODO") \
  EXPAND(vkDestroyExternalComputeQueueNV, "TODO") \
  EXPAND(vkGetExternalComputeQueueDataNV, "TODO") \
  EXPAND(vkGetClusterAccelerationStructureBuildSizesNV, "TODO") \
  EXPAND(vkCmdBuildClusterAccelerationStructureIndirectNV, "TODO") \
  EXPAND(vkGetPartitionedAccelerationStructuresBuildSizesNV, "TODO") \
  EXPAND(vkCmdBuildPartitionedAccelerationStructuresNV, "TODO") \
  EXPAND(vkGetGeneratedCommandsMemoryRequirementsEXT, "TODO") \
  EXPAND(vkCmdPreprocessGeneratedCommandsEXT, "TODO") \
  EXPAND(vkCmdExecuteGeneratedCommandsEXT, "TODO") \
  EXPAND(vkCreateIndirectCommandsLayoutEXT, "TODO") \
  EXPAND(vkDestroyIndirectCommandsLayoutEXT, "TODO") \
  EXPAND(vkCreateIndirectExecutionSetEXT, "TODO") \
  EXPAND(vkDestroyIndirectExecutionSetEXT, "TODO") \
  EXPAND(vkUpdateIndirectExecutionSetPipelineEXT, "TODO") \
  EXPAND(vkUpdateIndirectExecutionSetShaderEXT, "TODO") \
  EXPAND(vkGetPhysicalDeviceCooperativeMatrixFlexibleDimensionsPropertiesNV, "TODO") \
  EXPAND(vkEnumeratePhysicalDeviceQueueFamilyPerformanceCountersByRegionARM, "TODO") \
  EXPAND(vkCmdEndRendering2EXT, "TODO") \
  EXPAND(vkCmdBeginCustomResolveEXT, "TODO") \
  EXPAND(vkCmdSetComputeOccupancyPriorityNV, "TODO") \
  EXPAND(vkCreateAccelerationStructureKHR, "TODO") \
  EXPAND(vkDestroyAccelerationStructureKHR, "TODO") \
  EXPAND(vkCmdBuildAccelerationStructuresKHR, "TODO") \
  EXPAND(vkCmdBuildAccelerationStructuresIndirectKHR, "TODO") \
  EXPAND(vkBuildAccelerationStructuresKHR, "TODO") \
  EXPAND(vkCopyAccelerationStructureKHR, "TODO") \
  EXPAND(vkCopyAccelerationStructureToMemoryKHR, "TODO") \
  EXPAND(vkCopyMemoryToAccelerationStructureKHR, "TODO") \
  EXPAND(vkWriteAccelerationStructuresPropertiesKHR, "TODO") \
  EXPAND(vkCmdCopyAccelerationStructureKHR, "TODO") \
  EXPAND(vkCmdCopyAccelerationStructureToMemoryKHR, "TODO") \
  EXPAND(vkCmdCopyMemoryToAccelerationStructureKHR, "TODO") \
  EXPAND(vkGetAccelerationStructureDeviceAddressKHR, "TODO") \
  EXPAND(vkCmdWriteAccelerationStructuresPropertiesKHR, "TODO") \
  EXPAND(vkGetDeviceAccelerationStructureCompatibilityKHR, "TODO") \
  EXPAND(vkGetAccelerationStructureBuildSizesKHR, "TODO") \
  EXPAND(vkCmdTraceRaysKHR, "TODO") \
  EXPAND(vkCreateRayTracingPipelinesKHR, "TODO") \
  EXPAND(vkGetRayTracingCaptureReplayShaderGroupHandlesKHR, "TODO") \
  EXPAND(vkCmdTraceRaysIndirectKHR, "TODO") \
  EXPAND(vkGetRayTracingShaderGroupStackSizeKHR, "TODO") \
  EXPAND(vkCmdSetRayTracingPipelineStackSizeKHR, "TODO") \
  EXPAND(vkCmdDrawMeshTasksEXT, "TODO") \
  EXPAND(vkCmdDrawMeshTasksIndirectEXT, "TODO") \
  EXPAND(vkCmdDrawMeshTasksIndirectCountEXT, "TODO") \
  EXPAND(vkAcquireXlibDisplayEXT, "TODO") \
  EXPAND(vkGetRandROutputDisplayEXT, "TODO") \
  EXPAND(vkCreateWaylandSurfaceKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceWaylandPresentationSupportKHR, "TODO") \
  EXPAND(vkCreateXcbSurfaceKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceXcbPresentationSupportKHR, "TODO") \
  EXPAND(vkCreateXlibSurfaceKHR, "TODO") \
  EXPAND(vkGetPhysicalDeviceXlibPresentationSupportKHR, "TODO") \


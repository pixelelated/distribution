extern "C" {
MAKE_THUNK(libdrm, FEX_usable_size, "0x4c, 0xca, 0x14, 0x62, 0x84, 0xa7, 0xf7, 0xe7, 0x25, 0x5f, 0xe6, 0x3b, 0xd3, 0xe, 0x57, 0x52, 0x73, 0x16, 0xb4, 0x10, 0xd4, 0xc9, 0x2a, 0xbb, 0xcf, 0x38, 0x3, 0xd0, 0x7a, 0xf4, 0xa0, 0xd4")
MAKE_THUNK(libdrm, FEX_free_on_host, "0x54, 0x61, 0x52, 0x6e, 0x62, 0x35, 0x74, 0x20, 0x4b, 0x5d, 0xf, 0x60, 0x68, 0x9c, 0xbc, 0x13, 0xe5, 0x6, 0xd6, 0x5f, 0xac, 0x25, 0x75, 0xb0, 0x11, 0xc9, 0xeb, 0xa1, 0x7b, 0xf0, 0xa6, 0x48")
MAKE_THUNK(libdrm, drmIoctl, "0x2, 0x73, 0xd, 0x85, 0x3, 0xa8, 0x16, 0x9e, 0x69, 0xc3, 0x59, 0x11, 0x72, 0xae, 0x9c, 0x7c, 0xd, 0x72, 0x55, 0x9f, 0x68, 0x5, 0x2f, 0x21, 0xfe, 0x51, 0x2d, 0x51, 0x72, 0x16, 0xe2, 0x37")
MAKE_THUNK(libdrm, drmGetHashTable, "0x6c, 0xa7, 0xe8, 0x82, 0xe7, 0x12, 0xd4, 0x81, 0x4d, 0x7f, 0x53, 0xac, 0xde, 0x1, 0x4c, 0xf2, 0x66, 0x82, 0xb8, 0x59, 0x7b, 0x20, 0x24, 0x50, 0x64, 0x45, 0x99, 0xd5, 0xc0, 0x44, 0x13, 0xd0")
MAKE_THUNK(libdrm, drmGetEntry, "0x18, 0x20, 0x54, 0x7b, 0xb3, 0x22, 0x3e, 0x32, 0xe9, 0xeb, 0xec, 0xde, 0xb9, 0xde, 0xec, 0x5b, 0x71, 0x6e, 0xa, 0xe4, 0x7a, 0x5c, 0x18, 0x2, 0x20, 0xa1, 0x9e, 0x74, 0x9f, 0xad, 0xb, 0x45")
MAKE_THUNK(libdrm, drmAvailable, "0xc, 0x87, 0x65, 0x5b, 0x39, 0x8c, 0xa, 0xab, 0x85, 0x3b, 0x24, 0x2d, 0xe4, 0xea, 0xad, 0x3c, 0xa2, 0xe6, 0x7d, 0xed, 0x9f, 0x15, 0x68, 0x1, 0xac, 0xc, 0x63, 0xeb, 0x85, 0xa8, 0xb8, 0x29")
MAKE_THUNK(libdrm, drmOpen, "0xac, 0xfc, 0x57, 0x2b, 0x2b, 0x91, 0xb7, 0x82, 0xc4, 0xa4, 0xe9, 0x53, 0x35, 0xe6, 0x47, 0xfc, 0x71, 0xdc, 0x39, 0x6d, 0x2f, 0xc2, 0x99, 0xf4, 0x85, 0xba, 0x40, 0x15, 0xd1, 0xd0, 0x49, 0x99")
MAKE_THUNK(libdrm, drmOpenWithType, "0x56, 0x2e, 0xe5, 0xfb, 0x8f, 0x3b, 0x2d, 0x12, 0x3e, 0x63, 0x57, 0x52, 0xe8, 0x6b, 0x65, 0x81, 0x5, 0xd1, 0xfb, 0x7a, 0xfb, 0xa9, 0x1e, 0xd4, 0x82, 0x7f, 0x2a, 0xa5, 0x82, 0x86, 0x86, 0xe1")
MAKE_THUNK(libdrm, drmOpenControl, "0xf4, 0xae, 0x59, 0x12, 0xa0, 0xa0, 0x3f, 0x17, 0xfd, 0x88, 0x8e, 0xe0, 0x4b, 0xf7, 0xca, 0x1a, 0x2b, 0x7a, 0x7c, 0xb6, 0x34, 0xf7, 0x84, 0x9c, 0x50, 0x14, 0x6d, 0x95, 0x7e, 0x6c, 0xfd, 0xc0")
MAKE_THUNK(libdrm, drmOpenRender, "0x28, 0x54, 0xdf, 0x47, 0x6f, 0x1c, 0x6, 0x13, 0xda, 0x73, 0xb7, 0x94, 0x1d, 0xaa, 0x6, 0xf7, 0x69, 0x74, 0xcd, 0xc5, 0x5b, 0xfe, 0x49, 0xcb, 0xeb, 0x60, 0xe, 0x32, 0x45, 0xf3, 0x14, 0x47")
MAKE_THUNK(libdrm, drmClose, "0xed, 0x73, 0x1a, 0x6f, 0xd6, 0x6e, 0x32, 0xcd, 0xbc, 0xda, 0x39, 0x83, 0x42, 0xea, 0xd7, 0x58, 0x34, 0x7d, 0x88, 0xfa, 0x3d, 0x13, 0xaf, 0xd6, 0x98, 0x85, 0x88, 0xc1, 0x43, 0x9c, 0x2b, 0xf3")
MAKE_THUNK(libdrm, drmGetVersion, "0xa1, 0xbb, 0x23, 0xf4, 0xdb, 0x70, 0x25, 0x4a, 0x6e, 0xdc, 0x50, 0x8d, 0x6, 0xfc, 0x6e, 0xf0, 0x8b, 0x9e, 0x10, 0xa3, 0x98, 0x4d, 0x7f, 0xfd, 0x2e, 0xd, 0x25, 0xef, 0xf3, 0x4e, 0x14, 0xe")
MAKE_THUNK(libdrm, drmGetLibVersion, "0x73, 0xf2, 0x2d, 0xf6, 0xbe, 0xa8, 0x10, 0xf8, 0xd9, 0x96, 0xea, 0x84, 0x7f, 0x82, 0x5, 0xad, 0x55, 0x4e, 0xb5, 0x75, 0xcf, 0xf8, 0xc7, 0xed, 0xeb, 0x5a, 0x23, 0xac, 0x9d, 0xf4, 0x7a, 0xf3")
MAKE_THUNK(libdrm, drmGetCap, "0xa5, 0xfe, 0xc2, 0xd6, 0x40, 0xd5, 0x5e, 0x4f, 0xf9, 0x5d, 0x40, 0xd9, 0x3f, 0x3f, 0x8a, 0x6, 0xe9, 0x1e, 0xe6, 0xe6, 0x43, 0xa6, 0x93, 0x28, 0x4d, 0xa6, 0x78, 0x1c, 0x72, 0xcb, 0xc9, 0x24")
MAKE_THUNK(libdrm, drmFreeVersion, "0x9f, 0xf, 0x73, 0xe6, 0xf8, 0x61, 0x4e, 0x29, 0xea, 0x58, 0xb0, 0x3, 0x8a, 0x26, 0xfe, 0x13, 0x5a, 0x6c, 0x8, 0x85, 0x83, 0x99, 0x39, 0x65, 0x2f, 0x11, 0x59, 0xea, 0xb2, 0x5, 0x2c, 0x45")
MAKE_THUNK(libdrm, drmGetMagic, "0x94, 0x5b, 0x5a, 0x3f, 0xd9, 0x6d, 0x59, 0x79, 0xf8, 0x8, 0xee, 0xf3, 0x9b, 0xa, 0xf4, 0x36, 0xe9, 0xc2, 0xc7, 0xd9, 0x43, 0x60, 0x37, 0xcb, 0xf8, 0xe6, 0xda, 0xb1, 0x9a, 0x93, 0x5b, 0x1c")
MAKE_THUNK(libdrm, drmGetBusid, "0xaf, 0x94, 0x93, 0x2a, 0x1, 0xa5, 0x27, 0xc0, 0x7a, 0x5e, 0xd5, 0xcf, 0x18, 0x69, 0x9c, 0x42, 0x57, 0x17, 0x1e, 0x34, 0x18, 0xce, 0xb3, 0x89, 0x6f, 0x5, 0x62, 0xc2, 0xac, 0xfe, 0xdf, 0xd")
MAKE_THUNK(libdrm, drmGetInterruptFromBusID, "0xc7, 0xb, 0x25, 0xaa, 0x91, 0xdd, 0x51, 0xb4, 0xb, 0x66, 0x68, 0x3f, 0xcf, 0xc5, 0x5b, 0xe6, 0x71, 0x13, 0xa2, 0x98, 0x15, 0xdd, 0x8, 0x6c, 0x17, 0x87, 0x7b, 0x18, 0x4e, 0xb, 0xf5, 0x74")
MAKE_THUNK(libdrm, drmGetMap, "0xe0, 0x25, 0xa3, 0xf, 0xb3, 0x7, 0x88, 0xf1, 0xe5, 0x48, 0x9e, 0xe0, 0xdd, 0x6f, 0x7f, 0x17, 0x9c, 0x8f, 0x52, 0x7c, 0x64, 0x4a, 0xc2, 0x3a, 0xba, 0xf4, 0x95, 0x44, 0x57, 0x35, 0x71, 0xec")
MAKE_THUNK(libdrm, drmGetClient, "0xe9, 0xfd, 0x5d, 0xd5, 0xff, 0x5b, 0xf2, 0x4c, 0x9b, 0x43, 0xd8, 0x9e, 0xcd, 0xba, 0x57, 0xbc, 0x54, 0xf6, 0x3b, 0x25, 0xa5, 0xf6, 0x4e, 0x3, 0xf1, 0x4c, 0x61, 0x6d, 0x43, 0x1a, 0x7f, 0xd8")
MAKE_THUNK(libdrm, drmGetStats, "0x9d, 0xaa, 0x3c, 0x81, 0x61, 0x84, 0xd1, 0xee, 0xcc, 0x44, 0x9f, 0x7c, 0x5, 0x3, 0x89, 0x51, 0xf4, 0x6f, 0x9a, 0xd9, 0xec, 0xac, 0xc7, 0x6c, 0xea, 0xb8, 0x57, 0xa0, 0x58, 0x93, 0xc5, 0xc")
MAKE_THUNK(libdrm, drmSetInterfaceVersion, "0x6c, 0x27, 0xb8, 0xf7, 0x59, 0x35, 0xb7, 0xa1, 0x65, 0x92, 0xff, 0xde, 0x66, 0x58, 0x10, 0x26, 0xb7, 0xd1, 0x1d, 0xac, 0x43, 0x32, 0xec, 0xaf, 0xeb, 0x2c, 0xc0, 0x80, 0x8b, 0x34, 0x55, 0x3d")
MAKE_THUNK(libdrm, drmCommandNone, "0xf1, 0x14, 0x79, 0x71, 0x98, 0x0, 0x4f, 0x3f, 0x41, 0x19, 0x61, 0xf1, 0x47, 0xd4, 0xfe, 0x7, 0xba, 0xef, 0xf3, 0x2f, 0xfb, 0x7c, 0x88, 0x4a, 0x45, 0xf3, 0x8c, 0xcc, 0x9b, 0x51, 0xaa, 0x11")
MAKE_THUNK(libdrm, drmCommandRead, "0xb, 0x10, 0x79, 0xf8, 0x3e, 0x4b, 0xf3, 0x1b, 0x9d, 0x1b, 0x69, 0xe9, 0xa0, 0xdd, 0x74, 0x55, 0xbb, 0x35, 0x3f, 0x3, 0x80, 0xff, 0xb, 0x10, 0xe5, 0xfc, 0x23, 0x29, 0x56, 0x14, 0x6b, 0x86")
MAKE_THUNK(libdrm, drmCommandWrite, "0x2f, 0x60, 0x41, 0x3, 0x87, 0xb4, 0x5c, 0x36, 0xc7, 0x4f, 0x78, 0xb2, 0x1d, 0x94, 0x1e, 0xdd, 0x77, 0xac, 0x11, 0x2c, 0xb, 0xc9, 0xcc, 0x1a, 0x71, 0x6f, 0x4f, 0x20, 0xd5, 0xba, 0x7e, 0x5")
MAKE_THUNK(libdrm, drmCommandWriteRead, "0xf1, 0xa7, 0x2c, 0x82, 0x12, 0x39, 0x8f, 0xef, 0x5c, 0x9c, 0x14, 0x95, 0x8a, 0x2b, 0x22, 0x8a, 0x92, 0x71, 0x9e, 0xa2, 0x5d, 0xd6, 0x3d, 0xc4, 0xed, 0xa9, 0xe4, 0x90, 0x8a, 0x3b, 0xf1, 0xb6")
MAKE_THUNK(libdrm, drmFreeBusid, "0x34, 0xee, 0x68, 0x25, 0xe8, 0x4a, 0xc, 0xda, 0x37, 0x6a, 0xff, 0x27, 0xe0, 0x4a, 0x93, 0x2e, 0xb6, 0x58, 0xe0, 0x45, 0x4a, 0x72, 0x1b, 0xa1, 0xc3, 0x68, 0x89, 0x6f, 0x4f, 0x1c, 0x68, 0xe4")
MAKE_THUNK(libdrm, drmSetBusid, "0xc6, 0x1d, 0x9d, 0xe9, 0xac, 0x46, 0xf4, 0x53, 0x18, 0x6f, 0x61, 0xb8, 0xb6, 0xac, 0xe0, 0x77, 0x17, 0xbc, 0xbd, 0x5, 0x70, 0xdf, 0x5e, 0x8c, 0x92, 0x40, 0x48, 0xe2, 0x56, 0xcd, 0x87, 0x7c")
MAKE_THUNK(libdrm, drmAuthMagic, "0xa7, 0x1f, 0xc4, 0x7e, 0xad, 0xcd, 0xac, 0xa, 0xda, 0x8b, 0x6f, 0x66, 0x30, 0xed, 0xc7, 0x48, 0x67, 0x21, 0x2a, 0x88, 0x80, 0x30, 0x74, 0xc2, 0x4c, 0xb2, 0x43, 0x16, 0x6b, 0x23, 0xfe, 0xec")
MAKE_THUNK(libdrm, drmAddMap, "0x88, 0xee, 0x90, 0xb9, 0x41, 0xe8, 0xc7, 0x18, 0x25, 0xdc, 0x69, 0xdc, 0x4e, 0x15, 0x77, 0x59, 0xe5, 0x0, 0x67, 0x90, 0x9, 0x47, 0xcf, 0xb1, 0xb9, 0x9d, 0xaf, 0x17, 0x7c, 0xca, 0xae, 0x49")
MAKE_THUNK(libdrm, drmRmMap, "0xd, 0x1, 0xc9, 0xa5, 0xd2, 0x8a, 0x99, 0xbb, 0x89, 0x8e, 0x23, 0x15, 0xed, 0x74, 0x3b, 0x58, 0xec, 0xc7, 0x12, 0xce, 0x5c, 0x40, 0xa9, 0x40, 0xda, 0x8e, 0x58, 0xfa, 0x10, 0x52, 0xa3, 0x20")
MAKE_THUNK(libdrm, drmAddContextPrivateMapping, "0xff, 0x75, 0x46, 0xfa, 0xd7, 0x8c, 0x82, 0x1f, 0x3d, 0xe6, 0x83, 0x5b, 0x86, 0xcf, 0x55, 0xeb, 0xaa, 0x52, 0x89, 0x6b, 0xb8, 0x90, 0x83, 0x19, 0x98, 0x29, 0x2d, 0xaa, 0x5c, 0x71, 0xc6, 0x3")
MAKE_THUNK(libdrm, drmAddBufs, "0x34, 0x38, 0xbf, 0x23, 0x8, 0xaf, 0x2c, 0x21, 0x1d, 0xac, 0xcc, 0xfa, 0x3f, 0x28, 0xd4, 0x83, 0xd8, 0x1a, 0xef, 0xf3, 0xe2, 0xd1, 0xba, 0xd, 0x40, 0x13, 0xcb, 0xf5, 0xc5, 0xc3, 0x6e, 0x5a")
MAKE_THUNK(libdrm, drmMarkBufs, "0xa7, 0x86, 0xb, 0x22, 0x97, 0x53, 0xc3, 0x42, 0xac, 0x9b, 0xcb, 0xb5, 0xfb, 0x1c, 0x3d, 0xfc, 0x79, 0x63, 0x94, 0xca, 0xfd, 0x4f, 0x17, 0xd9, 0xd1, 0xf1, 0x2e, 0x7f, 0xf9, 0x77, 0x64, 0x49")
MAKE_THUNK(libdrm, drmCreateContext, "0xfb, 0xf7, 0xe, 0xc5, 0x26, 0x63, 0xcd, 0xe1, 0xc1, 0x51, 0xdf, 0x4, 0x2f, 0x78, 0x3d, 0x44, 0xc7, 0x8c, 0xf9, 0x65, 0x78, 0xe9, 0xf0, 0x67, 0x8b, 0x99, 0xd0, 0xfb, 0x6b, 0xd5, 0x62, 0x9c")
MAKE_THUNK(libdrm, drmSetContextFlags, "0x75, 0x8a, 0x39, 0x43, 0xa0, 0xe5, 0x7, 0xc5, 0xd5, 0x9c, 0xea, 0x16, 0x44, 0x42, 0x5e, 0x2d, 0xa9, 0x26, 0xfa, 0xea, 0x87, 0xe3, 0xc0, 0xf, 0x8a, 0x9d, 0x86, 0x9f, 0xe9, 0x92, 0x97, 0xcd")
MAKE_THUNK(libdrm, drmGetContextFlags, "0xc4, 0x51, 0xd8, 0xe8, 0x1d, 0x8, 0xb, 0xfd, 0xbf, 0x18, 0x8e, 0xd1, 0xa5, 0xf3, 0xb3, 0x43, 0x57, 0x2a, 0x25, 0x42, 0x56, 0x22, 0x33, 0xb1, 0x1b, 0x8a, 0xfe, 0xd2, 0x1c, 0x74, 0x89, 0xcc")
MAKE_THUNK(libdrm, drmAddContextTag, "0xc, 0x80, 0xb1, 0x5, 0xb4, 0xe3, 0xd6, 0x54, 0x4b, 0xff, 0xce, 0x41, 0xb0, 0x96, 0x5c, 0x2a, 0xca, 0x16, 0x55, 0xca, 0x54, 0x4f, 0x27, 0xf9, 0xb3, 0x39, 0xd5, 0xfd, 0x71, 0x89, 0x1c, 0xe1")
MAKE_THUNK(libdrm, drmDelContextTag, "0x4b, 0x9, 0x57, 0x23, 0xed, 0xf7, 0x7b, 0x3d, 0x2a, 0xef, 0x1e, 0x91, 0x1f, 0x12, 0x4d, 0x80, 0x7e, 0x41, 0x20, 0x3e, 0x68, 0x88, 0x1a, 0x9c, 0x77, 0x10, 0xae, 0x92, 0x26, 0xee, 0x26, 0x12")
MAKE_THUNK(libdrm, drmGetContextTag, "0x60, 0x7a, 0x2d, 0xb4, 0xa1, 0xfa, 0x46, 0xd9, 0x75, 0x48, 0x46, 0xcd, 0x99, 0x54, 0x2d, 0x97, 0x27, 0xf1, 0x8c, 0xb, 0x3f, 0x33, 0x92, 0x7e, 0x24, 0x72, 0x4a, 0x8a, 0xe3, 0x13, 0x2, 0xa8")
MAKE_THUNK(libdrm, drmGetReservedContextList, "0x95, 0x9b, 0xe8, 0x1b, 0xd3, 0xd3, 0xe1, 0xa4, 0x0, 0xca, 0x8e, 0x2c, 0x74, 0xba, 0x54, 0x41, 0x90, 0x4f, 0xbc, 0x47, 0xa4, 0xe0, 0x29, 0x68, 0xaa, 0xed, 0x9a, 0xc6, 0x3a, 0xef, 0xbe, 0x8b")
MAKE_THUNK(libdrm, drmFreeReservedContextList, "0x0, 0x1a, 0xf0, 0x63, 0x63, 0x34, 0xe6, 0x1e, 0x78, 0x1b, 0x4d, 0x6b, 0x1e, 0x90, 0x31, 0x31, 0xff, 0x13, 0x8d, 0xfd, 0xc3, 0x10, 0x8d, 0xd2, 0x12, 0xe8, 0xa9, 0x2, 0xe6, 0x2d, 0x9d, 0x81")
MAKE_THUNK(libdrm, drmSwitchToContext, "0xd7, 0x91, 0xd9, 0xf0, 0x6e, 0x85, 0xc9, 0xa1, 0x59, 0x89, 0x82, 0x6e, 0xed, 0xda, 0xef, 0x6a, 0xe, 0x77, 0xae, 0xe2, 0x73, 0x28, 0x7d, 0xb, 0x65, 0x9d, 0xa5, 0x4b, 0x74, 0xf6, 0x22, 0xd5")
MAKE_THUNK(libdrm, drmDestroyContext, "0x2d, 0x63, 0xf2, 0x6c, 0x1f, 0xb5, 0xec, 0x12, 0xff, 0x7, 0x1d, 0x91, 0xbd, 0xff, 0xbe, 0xcc, 0x1a, 0x99, 0x38, 0x57, 0x9e, 0x78, 0x3c, 0x7, 0x68, 0xa4, 0x4c, 0x47, 0xd1, 0xf0, 0x90, 0x1e")
MAKE_THUNK(libdrm, drmCreateDrawable, "0xea, 0x18, 0x44, 0x72, 0xd2, 0xdb, 0x9f, 0x93, 0x91, 0x4e, 0xcb, 0x22, 0x71, 0xff, 0x45, 0xe5, 0x75, 0x9a, 0x67, 0x51, 0xd2, 0xf3, 0x69, 0xbd, 0x87, 0xd7, 0x6f, 0xf9, 0xca, 0xd6, 0x19, 0x23")
MAKE_THUNK(libdrm, drmDestroyDrawable, "0x7c, 0x96, 0x8e, 0x1f, 0xc2, 0x51, 0x7b, 0x89, 0xc6, 0xd2, 0xc8, 0xf6, 0xbf, 0xdd, 0x2a, 0xe2, 0xe5, 0x94, 0x94, 0x34, 0xf6, 0x89, 0x9d, 0xee, 0x56, 0x34, 0x29, 0x12, 0xe7, 0xf3, 0xf8, 0x85")
MAKE_THUNK(libdrm, drmUpdateDrawableInfo, "0xe3, 0xc7, 0x57, 0x21, 0x23, 0x8d, 0x36, 0x16, 0x85, 0xfd, 0x56, 0xc8, 0x22, 0x51, 0x13, 0xcc, 0x15, 0x7f, 0x99, 0xa0, 0xe5, 0x81, 0xd0, 0x31, 0xac, 0xca, 0xbe, 0x17, 0xd5, 0xa1, 0xb7, 0x30")
MAKE_THUNK(libdrm, drmCtlInstHandler, "0xad, 0x3d, 0x35, 0x54, 0x1d, 0x8b, 0x85, 0x6a, 0xa, 0x6c, 0xd3, 0xce, 0x9e, 0x82, 0xee, 0x3e, 0x6, 0x10, 0xa0, 0x6c, 0x5e, 0x68, 0xed, 0xcf, 0xc6, 0x79, 0x83, 0x23, 0x20, 0xff, 0xa, 0xf1")
MAKE_THUNK(libdrm, drmCtlUninstHandler, "0xa1, 0x13, 0x35, 0xa3, 0x3, 0x1c, 0x79, 0xad, 0xbf, 0xde, 0xe6, 0xb3, 0xe3, 0x45, 0x5f, 0x10, 0x8f, 0x9, 0x60, 0x23, 0x11, 0x42, 0x9c, 0x32, 0xfc, 0x41, 0x1f, 0x86, 0x23, 0x42, 0x40, 0x5")
MAKE_THUNK(libdrm, drmSetClientCap, "0x18, 0x19, 0x77, 0xe6, 0x86, 0x13, 0x9e, 0xa7, 0xc0, 0x40, 0x37, 0x87, 0x4b, 0x44, 0xbc, 0x68, 0x54, 0xdc, 0xd4, 0x77, 0x84, 0xd4, 0x6, 0xc3, 0xab, 0x8a, 0xc3, 0x6a, 0x6e, 0xa0, 0x13, 0x6c")
MAKE_THUNK(libdrm, drmCrtcGetSequence, "0x8f, 0x15, 0xc0, 0x30, 0x8b, 0x99, 0xba, 0x48, 0x57, 0xc, 0x51, 0x3b, 0x44, 0x76, 0xde, 0x35, 0x5e, 0x67, 0xdf, 0xc3, 0xf9, 0xbf, 0xec, 0x8b, 0xf8, 0x21, 0x80, 0xd1, 0x3e, 0xf6, 0xb4, 0x81")
MAKE_THUNK(libdrm, drmCrtcQueueSequence, "0x85, 0xde, 0x33, 0xde, 0xc6, 0x1e, 0x9, 0x62, 0xb2, 0x66, 0xcc, 0x30, 0x3b, 0x35, 0x28, 0xcb, 0xd9, 0x9a, 0xfa, 0x96, 0x65, 0xef, 0x3c, 0x76, 0x12, 0x69, 0x99, 0xcb, 0x85, 0x97, 0x28, 0x95")
MAKE_THUNK(libdrm, drmMap, "0x5b, 0x6e, 0x4e, 0xb7, 0x37, 0x4c, 0xe1, 0x9a, 0x88, 0x58, 0xf1, 0x86, 0xb7, 0x6e, 0xe, 0xca, 0x7a, 0x9d, 0xb, 0x0, 0xa3, 0xc, 0x7d, 0x28, 0x2e, 0x77, 0xab, 0x2b, 0xa3, 0xdc, 0xc7, 0xe")
MAKE_THUNK(libdrm, drmUnmap, "0xdf, 0x46, 0x1, 0x42, 0x22, 0xf2, 0x2c, 0x1, 0x12, 0x71, 0x6f, 0xe9, 0x73, 0xae, 0x45, 0xfb, 0x2c, 0x38, 0x68, 0x2c, 0xb9, 0xcd, 0xc7, 0x9b, 0xeb, 0x73, 0xbf, 0x96, 0xc3, 0xa5, 0xe6, 0x6d")
MAKE_THUNK(libdrm, drmGetBufInfo, "0x15, 0x60, 0x43, 0x40, 0xd2, 0x85, 0x88, 0xaa, 0xff, 0x9b, 0x89, 0x97, 0xd0, 0x85, 0x4d, 0xc, 0x51, 0xde, 0x65, 0x55, 0x1b, 0xd0, 0x6f, 0x3b, 0xf1, 0xf3, 0x38, 0xf6, 0x76, 0x5a, 0xd4, 0x9")
MAKE_THUNK(libdrm, drmMapBufs, "0xa1, 0x7d, 0x1, 0x14, 0x1, 0x77, 0x33, 0x86, 0x77, 0x3b, 0x6d, 0x25, 0xa, 0xb0, 0x83, 0xd6, 0xc3, 0xd0, 0x47, 0xf5, 0x6e, 0x97, 0x4e, 0xad, 0xc, 0xda, 0x6c, 0xb8, 0x97, 0x50, 0x60, 0x9e")
MAKE_THUNK(libdrm, drmUnmapBufs, "0xa7, 0x7d, 0x14, 0xab, 0x79, 0x73, 0xe6, 0x2a, 0x8e, 0xd7, 0x97, 0x32, 0xf6, 0x30, 0x37, 0x94, 0x9, 0x7e, 0x7d, 0x2a, 0xe7, 0xd0, 0x3, 0xad, 0x8e, 0xdd, 0x94, 0xda, 0x1d, 0x4d, 0xc9, 0x18")
MAKE_THUNK(libdrm, drmDMA, "0xc6, 0xe9, 0x90, 0x5, 0xc8, 0xbe, 0xdb, 0x9, 0x25, 0x2, 0x4a, 0x6a, 0xaa, 0x5f, 0xc2, 0xe5, 0x59, 0xb5, 0x87, 0x24, 0xa0, 0xb5, 0x1c, 0xb5, 0x91, 0x6b, 0x4, 0xb3, 0xf8, 0x46, 0x8c, 0x48")
MAKE_THUNK(libdrm, drmFreeBufs, "0xf7, 0x3d, 0x2e, 0x43, 0x62, 0x93, 0xb0, 0x79, 0x6, 0x96, 0x2c, 0x5c, 0xd1, 0x24, 0xc9, 0xd5, 0x18, 0x78, 0x94, 0x81, 0xc4, 0x20, 0x9, 0x9a, 0xcc, 0x74, 0xac, 0xf, 0xb9, 0xb, 0xfd, 0xd3")
MAKE_THUNK(libdrm, drmGetLock, "0x21, 0x20, 0x3, 0x48, 0xb4, 0xd6, 0xfe, 0xde, 0x90, 0x8e, 0xf7, 0xc9, 0xe, 0xc4, 0xe5, 0x34, 0xeb, 0x80, 0x68, 0xee, 0x48, 0xb0, 0x7a, 0x1b, 0x6d, 0x18, 0x2e, 0xf5, 0xe0, 0x61, 0x2e, 0xb8")
MAKE_THUNK(libdrm, drmUnlock, "0x55, 0x4, 0xa7, 0x13, 0x92, 0x47, 0x7a, 0x88, 0xed, 0xe6, 0x13, 0xbf, 0xd0, 0xdf, 0x90, 0xf7, 0xd4, 0x8, 0x54, 0xad, 0xc7, 0xb7, 0x4a, 0x84, 0x41, 0xe, 0x93, 0x66, 0x8f, 0x35, 0x6b, 0x8")
MAKE_THUNK(libdrm, drmFinish, "0x25, 0xc4, 0xd6, 0x79, 0x5a, 0x1d, 0x17, 0xc8, 0x37, 0x8b, 0xcc, 0x8, 0x46, 0x45, 0xba, 0x4, 0x2a, 0x6, 0xb, 0x1, 0x6d, 0xf0, 0x85, 0xe3, 0x16, 0x88, 0x22, 0x9e, 0xc0, 0x44, 0x5c, 0x21")
MAKE_THUNK(libdrm, drmGetContextPrivateMapping, "0xa4, 0xd8, 0xcf, 0xba, 0x5, 0x7e, 0x72, 0x83, 0x64, 0x87, 0x1e, 0xef, 0x53, 0xf5, 0x2a, 0xe4, 0xa0, 0xfc, 0xd2, 0xb3, 0x60, 0xfc, 0xb3, 0x1b, 0x2d, 0x72, 0x50, 0x5c, 0xb7, 0xa0, 0x50, 0xf")
MAKE_THUNK(libdrm, drmScatterGatherAlloc, "0x5e, 0xa9, 0x98, 0x83, 0x21, 0x8, 0xf3, 0x36, 0x4c, 0xfe, 0x9, 0xe7, 0x93, 0xf6, 0x63, 0xd0, 0x13, 0xd2, 0xb0, 0x42, 0xe1, 0x95, 0x65, 0x41, 0x55, 0xa8, 0x1d, 0x9e, 0x99, 0xfe, 0xab, 0x7b")
MAKE_THUNK(libdrm, drmScatterGatherFree, "0x22, 0x69, 0x81, 0x46, 0x34, 0xaa, 0xd2, 0x98, 0xe1, 0x2c, 0xea, 0xda, 0x50, 0xc0, 0xb2, 0x57, 0x9b, 0x4b, 0x5a, 0x43, 0x70, 0x1a, 0x15, 0x2, 0x83, 0x8a, 0x9d, 0x80, 0xbd, 0x79, 0x38, 0x48")
MAKE_THUNK(libdrm, drmWaitVBlank, "0x8, 0x3a, 0x8d, 0xd, 0xe8, 0x48, 0x9f, 0x9e, 0x29, 0xeb, 0x89, 0x74, 0x75, 0x62, 0x9c, 0x2e, 0xc1, 0x4f, 0xc5, 0x70, 0x1b, 0xad, 0xc0, 0xe7, 0xdf, 0x6c, 0xba, 0xe7, 0x2b, 0xe1, 0x62, 0xe")
MAKE_THUNK(libdrm, drmSetServerInfo, "0xb, 0xc7, 0x66, 0x69, 0x28, 0x8a, 0x8e, 0x1b, 0xce, 0xb3, 0xe2, 0xc, 0x55, 0x34, 0x35, 0xb1, 0x2b, 0x84, 0xa4, 0xff, 0xe2, 0x99, 0xac, 0x67, 0xa8, 0x5b, 0xda, 0xe1, 0xd3, 0xe3, 0xa2, 0xa2")
MAKE_THUNK(libdrm, drmError, "0x88, 0x33, 0x6e, 0xb0, 0xff, 0x73, 0xa3, 0x58, 0x3f, 0xef, 0xfd, 0x15, 0x41, 0xea, 0x42, 0x2c, 0x0, 0xf1, 0xec, 0x7f, 0x2e, 0xbb, 0xe4, 0x3a, 0xa, 0x26, 0x8c, 0x3, 0xec, 0xbf, 0x7c, 0xce")
MAKE_THUNK(libdrm, drmMalloc, "0x70, 0x9d, 0x5f, 0x7e, 0xee, 0x91, 0x23, 0x29, 0xb3, 0xd3, 0x86, 0xfb, 0xd, 0xe5, 0x47, 0x8b, 0xa3, 0x4b, 0x63, 0x7d, 0x87, 0x55, 0x64, 0x18, 0x9a, 0x8b, 0x52, 0xd4, 0x51, 0x41, 0xc5, 0x25")
MAKE_THUNK(libdrm, drmFree, "0x95, 0x63, 0x81, 0xef, 0xe1, 0x10, 0xef, 0x73, 0x7b, 0xd3, 0x67, 0x8, 0xd6, 0xca, 0xfb, 0x77, 0x7, 0xe1, 0xae, 0x8, 0x5a, 0x3f, 0x65, 0xa0, 0x47, 0x52, 0xaf, 0x79, 0x83, 0x7f, 0x4c, 0x31")
MAKE_THUNK(libdrm, drmHashCreate, "0x6f, 0x1a, 0x0, 0xba, 0x37, 0xc, 0x52, 0xde, 0xb8, 0x77, 0x61, 0xe, 0xc0, 0x36, 0xdd, 0x2b, 0x87, 0x83, 0x72, 0x35, 0xa4, 0x10, 0x13, 0xcb, 0xd4, 0xe1, 0x25, 0x12, 0xd0, 0x98, 0xd5, 0x3")
MAKE_THUNK(libdrm, drmHashDestroy, "0xac, 0xe0, 0x16, 0xb5, 0x86, 0x82, 0x5c, 0xd2, 0xc4, 0xe2, 0xef, 0x16, 0xa0, 0x21, 0xde, 0xea, 0x65, 0x2, 0x1d, 0x2b, 0xa, 0x52, 0xdc, 0x9a, 0x2c, 0x83, 0xb9, 0x90, 0xb1, 0x3d, 0xf5, 0x13")
MAKE_THUNK(libdrm, drmHashLookup, "0xb9, 0x1e, 0x4d, 0x3d, 0x76, 0x37, 0xe, 0xfe, 0xb7, 0xfc, 0xc3, 0x3c, 0x74, 0xc9, 0xd1, 0x4c, 0x3c, 0xd2, 0xa4, 0xcf, 0x1e, 0xdc, 0x24, 0x6c, 0x55, 0x1c, 0xb8, 0x9c, 0xab, 0xe7, 0xbd, 0x7")
MAKE_THUNK(libdrm, drmHashInsert, "0xa2, 0x2d, 0x47, 0x6a, 0x61, 0x2f, 0xf0, 0x9d, 0x59, 0x44, 0xf8, 0x21, 0xe5, 0xa6, 0x79, 0xa5, 0x43, 0x90, 0x5b, 0x60, 0xa9, 0xbe, 0xb0, 0x3d, 0x6f, 0x45, 0x64, 0x98, 0xaf, 0x33, 0xc6, 0x18")
MAKE_THUNK(libdrm, drmHashDelete, "0xea, 0xd6, 0x7b, 0xdd, 0x74, 0x65, 0x91, 0x3c, 0xeb, 0x2c, 0x7f, 0xb1, 0x53, 0x4c, 0x52, 0x7e, 0x3b, 0x4f, 0x74, 0x88, 0xcc, 0xb9, 0x4c, 0x5, 0x74, 0xe, 0x69, 0x53, 0xec, 0xe6, 0x9e, 0xd2")
MAKE_THUNK(libdrm, drmHashFirst, "0xe1, 0xa2, 0x69, 0x6f, 0x82, 0x4e, 0x26, 0x95, 0xed, 0xdf, 0x59, 0x31, 0x8, 0x8, 0x90, 0xd, 0x8e, 0x9c, 0x84, 0x9d, 0x9b, 0x6d, 0x4c, 0x20, 0xc3, 0xf1, 0x1f, 0x70, 0x80, 0xab, 0xb7, 0xb")
MAKE_THUNK(libdrm, drmHashNext, "0xfc, 0x39, 0x69, 0xe5, 0xcf, 0x5e, 0x2d, 0xb7, 0x5e, 0xfc, 0x5a, 0xd, 0xc, 0x12, 0xb4, 0x14, 0x6b, 0xd9, 0xb9, 0x0, 0x82, 0x44, 0x6e, 0xac, 0x6, 0x42, 0xc6, 0xa7, 0xa1, 0x6, 0x48, 0xd4")
MAKE_THUNK(libdrm, drmRandomCreate, "0xf5, 0x73, 0x1a, 0x78, 0xae, 0xbe, 0x9d, 0xfd, 0x44, 0x1e, 0xcb, 0xd6, 0x64, 0xe8, 0xd6, 0xfb, 0x73, 0xb1, 0xa2, 0x1c, 0x52, 0x50, 0xe0, 0xb0, 0xe, 0xfa, 0x81, 0x61, 0x8e, 0xb7, 0xbc, 0xb7")
MAKE_THUNK(libdrm, drmRandomDestroy, "0x43, 0xc1, 0xd7, 0xab, 0xf9, 0xb1, 0x0, 0xf0, 0xf7, 0x9, 0x6e, 0x87, 0xa0, 0xe1, 0x82, 0xab, 0xa9, 0x47, 0xdf, 0xff, 0x3d, 0xa1, 0x17, 0x65, 0xe8, 0xed, 0x55, 0x93, 0x19, 0xe0, 0x5c, 0x3d")
MAKE_THUNK(libdrm, drmRandom, "0x6f, 0xaf, 0xd1, 0x1b, 0x99, 0x55, 0xa5, 0xbc, 0xa1, 0x88, 0x28, 0x5c, 0x30, 0xab, 0x63, 0x40, 0x15, 0xc5, 0x5, 0xc9, 0x36, 0xf4, 0x64, 0x84, 0xd4, 0x51, 0x19, 0xa3, 0x9a, 0x1a, 0x65, 0x4c")
MAKE_THUNK(libdrm, drmRandomDouble, "0x86, 0xd, 0x86, 0xd7, 0xbb, 0x64, 0xcf, 0x6d, 0x78, 0x16, 0x89, 0x52, 0x14, 0xde, 0xfc, 0xc5, 0x7b, 0xb2, 0x7e, 0xe4, 0x6a, 0xe4, 0xf6, 0xb4, 0xe3, 0xa, 0x27, 0xca, 0x5, 0x82, 0x8d, 0x15")
MAKE_THUNK(libdrm, drmSLCreate, "0x2f, 0x62, 0x65, 0x82, 0x3c, 0x18, 0xd9, 0x2e, 0xd9, 0xa, 0x7, 0x52, 0x83, 0xdb, 0x65, 0x96, 0x0, 0x77, 0x58, 0x99, 0xc7, 0x12, 0x5b, 0xda, 0xa, 0xc6, 0x30, 0xb0, 0x98, 0xda, 0x78, 0xc8")
MAKE_THUNK(libdrm, drmSLDestroy, "0x3b, 0x91, 0x49, 0xca, 0xd7, 0xf5, 0x77, 0x5d, 0xee, 0x43, 0xc6, 0x6a, 0x4a, 0x44, 0xb1, 0x17, 0x90, 0x37, 0xb3, 0xd0, 0xe0, 0x55, 0xce, 0xf4, 0xdb, 0x35, 0x29, 0xf, 0x8f, 0xd3, 0xa9, 0xc6")
MAKE_THUNK(libdrm, drmSLLookup, "0xbf, 0x0, 0x39, 0x39, 0x45, 0xc2, 0x6c, 0xb5, 0xe3, 0x46, 0xa3, 0x2d, 0x8b, 0xda, 0xd9, 0x1b, 0x55, 0x28, 0x91, 0xb7, 0xf7, 0xa3, 0x2e, 0x3e, 0x8e, 0x82, 0xca, 0x12, 0x49, 0x20, 0x46, 0xdf")
MAKE_THUNK(libdrm, drmSLInsert, "0xda, 0x62, 0x39, 0xd9, 0x52, 0xbc, 0xd0, 0xcd, 0xeb, 0x78, 0xdf, 0xe7, 0x67, 0xba, 0x7f, 0x62, 0x22, 0x8d, 0x8f, 0xfa, 0x8d, 0x20, 0xb1, 0x3e, 0xea, 0x15, 0x4c, 0xf1, 0xdc, 0x9a, 0xb2, 0x77")
MAKE_THUNK(libdrm, drmSLDelete, "0x98, 0xf6, 0x2a, 0x62, 0xa9, 0x60, 0x69, 0x28, 0xfa, 0xe2, 0xa7, 0x49, 0x6a, 0x1a, 0xe7, 0x52, 0x64, 0xa2, 0xc3, 0x79, 0x14, 0x66, 0xab, 0x75, 0x6d, 0x34, 0x1b, 0xab, 0x15, 0x6f, 0x76, 0xe1")
MAKE_THUNK(libdrm, drmSLNext, "0x0, 0xd5, 0x6e, 0x33, 0xed, 0x4d, 0x3d, 0x81, 0x56, 0x1e, 0xae, 0x9d, 0x56, 0xc5, 0x8, 0x9f, 0x4c, 0xc4, 0xcd, 0x90, 0xbd, 0xb8, 0x7d, 0x17, 0xb, 0x30, 0x87, 0x5a, 0xe9, 0xa6, 0xeb, 0xba")
MAKE_THUNK(libdrm, drmSLFirst, "0xa6, 0xd1, 0xc5, 0xf6, 0xc0, 0xe8, 0x66, 0x49, 0xe4, 0x5d, 0xd5, 0x9, 0x4d, 0x5c, 0x9d, 0x53, 0x61, 0xf1, 0x77, 0x8f, 0xec, 0x6a, 0x6c, 0x56, 0xcc, 0xbf, 0xec, 0x70, 0x49, 0x4c, 0x43, 0x53")
MAKE_THUNK(libdrm, drmSLDump, "0x17, 0xac, 0xee, 0xfc, 0x2d, 0xb4, 0x71, 0xed, 0x2e, 0x45, 0xd8, 0x78, 0xd9, 0xf4, 0xb6, 0xf1, 0xaa, 0xfe, 0x3d, 0x6e, 0x32, 0x90, 0xe1, 0x16, 0x49, 0xcc, 0x1e, 0xe1, 0x8, 0x88, 0x77, 0x32")
MAKE_THUNK(libdrm, drmSLLookupNeighbors, "0x7, 0x7, 0xd1, 0x77, 0xa1, 0x5a, 0x6d, 0xd3, 0xef, 0x52, 0x2b, 0xc2, 0x5b, 0xeb, 0xf9, 0x65, 0xc9, 0x93, 0x75, 0x1e, 0xa4, 0xa, 0x81, 0xbb, 0x25, 0x78, 0xde, 0x1f, 0x34, 0xcb, 0xd2, 0x6c")
MAKE_THUNK(libdrm, drmOpenOnce, "0xa6, 0x4, 0x1, 0x72, 0x6, 0xab, 0x6f, 0xdd, 0x6, 0x15, 0x4a, 0x8a, 0xb7, 0x45, 0x24, 0x1b, 0xea, 0x4f, 0xc3, 0x76, 0x7d, 0x0, 0x90, 0xab, 0xc2, 0xd3, 0x7d, 0xed, 0xad, 0x62, 0x3a, 0x7c")
MAKE_THUNK(libdrm, drmOpenOnceWithType, "0xe, 0x23, 0xe2, 0x15, 0xa0, 0xd, 0xa2, 0x90, 0x74, 0xea, 0xb0, 0xf6, 0x4c, 0x5c, 0xe4, 0xa5, 0x51, 0x50, 0x64, 0x20, 0x40, 0x72, 0x18, 0x7, 0xd, 0xa7, 0x1, 0xff, 0x40, 0x2f, 0x32, 0xe")
MAKE_THUNK(libdrm, drmCloseOnce, "0xbd, 0x29, 0xc6, 0xbb, 0xd1, 0x52, 0x4f, 0xa7, 0x4b, 0x88, 0x82, 0xd6, 0xbd, 0x1e, 0xd1, 0x2f, 0x50, 0x8a, 0xbd, 0xdf, 0x1c, 0xef, 0xbb, 0x7d, 0xc, 0x47, 0xc8, 0xbf, 0x5, 0x9b, 0x11, 0x63")
MAKE_THUNK(libdrm, drmSetMaster, "0x66, 0xd6, 0xb1, 0xc9, 0xf2, 0x75, 0xbc, 0xd4, 0xc7, 0x31, 0x47, 0x69, 0x70, 0x42, 0xd5, 0x80, 0xda, 0x96, 0xf1, 0x2c, 0xa, 0x97, 0x5b, 0x4e, 0x93, 0xa0, 0xc0, 0x60, 0x27, 0x60, 0xf7, 0x27")
MAKE_THUNK(libdrm, drmDropMaster, "0xbf, 0x0, 0x17, 0x81, 0x8e, 0x79, 0xac, 0xc0, 0x57, 0xd4, 0x3d, 0xb0, 0x9d, 0x3c, 0xd2, 0x82, 0x2c, 0x61, 0x6e, 0xfa, 0xbe, 0xdd, 0xb0, 0x93, 0xc4, 0x2a, 0x70, 0xbb, 0x58, 0x39, 0xf1, 0x8c")
MAKE_THUNK(libdrm, drmIsMaster, "0x99, 0x77, 0xa2, 0xcc, 0xef, 0xaf, 0x24, 0x95, 0xee, 0xe8, 0xb6, 0x8d, 0x6d, 0xeb, 0x0, 0xf0, 0x37, 0x5, 0x8, 0xd8, 0x93, 0xdf, 0x32, 0x24, 0x28, 0xd2, 0xb8, 0x36, 0x69, 0xca, 0x64, 0x7d")
MAKE_THUNK(libdrm, drmHandleEvent, "0xd8, 0x1, 0x9, 0xa8, 0x74, 0x87, 0x1d, 0x8f, 0xbc, 0xd5, 0x58, 0x63, 0x60, 0xf9, 0xb7, 0x71, 0xd0, 0xba, 0x73, 0xbc, 0xbd, 0x49, 0x75, 0x9f, 0xf2, 0x9d, 0x39, 0xc3, 0x7a, 0x73, 0x9b, 0x5f")
MAKE_THUNK(libdrm, drmGetDeviceNameFromFd, "0x18, 0xe0, 0x82, 0x49, 0x73, 0xa8, 0x5b, 0xd5, 0xea, 0xdb, 0x1c, 0xdc, 0x63, 0x99, 0x8b, 0x40, 0x95, 0xbc, 0x43, 0xfa, 0x5a, 0xb7, 0xb5, 0xd1, 0x8f, 0x11, 0xbd, 0x16, 0xe1, 0xc, 0x56, 0xd8")
MAKE_THUNK(libdrm, drmGetDeviceNameFromFd2, "0xa8, 0xf4, 0xb0, 0xdf, 0xeb, 0x1c, 0x1e, 0xc, 0x6e, 0x3f, 0x3e, 0xaf, 0x97, 0x1f, 0xb4, 0xf4, 0xb6, 0xcb, 0xeb, 0x26, 0x7d, 0xb9, 0x14, 0xce, 0x7e, 0x8f, 0x4d, 0x9e, 0x12, 0xd0, 0x6c, 0x8a")
MAKE_THUNK(libdrm, drmGetNodeTypeFromFd, "0x23, 0x1, 0xb1, 0x69, 0x25, 0xf8, 0x57, 0x2f, 0xe4, 0xdf, 0xc5, 0x96, 0xcc, 0x97, 0x40, 0xb2, 0x44, 0xae, 0xe, 0x3c, 0xf0, 0xab, 0xc5, 0x5e, 0xa8, 0x7e, 0xc0, 0x21, 0x5e, 0xf6, 0x7d, 0x52")
MAKE_THUNK(libdrm, drmPrimeHandleToFD, "0x5d, 0x3f, 0xcb, 0x8c, 0x64, 0x3, 0xdf, 0xff, 0xfb, 0x15, 0x9, 0xad, 0x91, 0xda, 0x9a, 0x49, 0xfa, 0x30, 0x1d, 0xa, 0x7c, 0x3f, 0x1, 0xa2, 0x59, 0xae, 0x35, 0x60, 0x4, 0xea, 0xab, 0xe9")
MAKE_THUNK(libdrm, drmPrimeFDToHandle, "0xde, 0xc9, 0x6b, 0x83, 0x32, 0xb8, 0x6a, 0x67, 0xa5, 0xf7, 0xb8, 0xd8, 0x74, 0x2c, 0xab, 0x2a, 0x4f, 0x8e, 0x85, 0x18, 0x73, 0xc8, 0x55, 0x26, 0xa4, 0x86, 0xe9, 0x6a, 0xe3, 0x9, 0x83, 0x75")
MAKE_THUNK(libdrm, drmGetPrimaryDeviceNameFromFd, "0x86, 0xc5, 0x93, 0x5e, 0xc3, 0xd6, 0x24, 0x2c, 0xe2, 0x19, 0x96, 0x26, 0x2a, 0x6b, 0x4a, 0x9b, 0x4e, 0x5e, 0x86, 0x93, 0x6b, 0xc4, 0x0, 0xe9, 0x77, 0x73, 0x47, 0xf6, 0x27, 0xfc, 0x16, 0x7d")
MAKE_THUNK(libdrm, drmGetRenderDeviceNameFromFd, "0x5d, 0x6a, 0x91, 0xf9, 0x23, 0x10, 0x8c, 0x43, 0x2, 0xc5, 0x69, 0x3f, 0xd9, 0xb0, 0x3e, 0x8d, 0x7f, 0x8f, 0xa1, 0xfe, 0xe7, 0xeb, 0x67, 0xe7, 0xeb, 0x3c, 0xd9, 0xa9, 0xa4, 0x68, 0xdf, 0x6")
MAKE_THUNK(libdrm, drmGetDevice, "0xd7, 0xd9, 0x7d, 0x8c, 0xdd, 0xfd, 0x75, 0xb, 0x30, 0x7d, 0xb2, 0x82, 0xfa, 0xa1, 0xe1, 0x6f, 0xbe, 0x20, 0xed, 0x39, 0xe5, 0xd6, 0xfc, 0x4a, 0x8b, 0x1b, 0x7e, 0x3c, 0x7, 0xf8, 0x4b, 0x94")
MAKE_THUNK(libdrm, drmFreeDevice, "0x8b, 0xb3, 0xb6, 0xd2, 0x26, 0xc6, 0x98, 0xd9, 0x42, 0x82, 0x2b, 0x11, 0xf0, 0x24, 0x72, 0x9a, 0xaf, 0x4e, 0x5e, 0xbf, 0x8d, 0x63, 0x50, 0xf5, 0x4a, 0xa1, 0x39, 0x81, 0xa5, 0x39, 0x18, 0x6e")
MAKE_THUNK(libdrm, drmGetDevices, "0x2a, 0xa5, 0x3d, 0x56, 0x4a, 0x8c, 0x8b, 0xc0, 0x68, 0xc5, 0xa8, 0x7f, 0x90, 0x4d, 0x89, 0xac, 0x85, 0x72, 0x8d, 0xbf, 0xdf, 0xde, 0x2, 0x9f, 0x16, 0x79, 0x12, 0x6c, 0x2e, 0xd7, 0x7e, 0xb6")
MAKE_THUNK(libdrm, drmFreeDevices, "0xdb, 0x7b, 0x6c, 0x4f, 0x37, 0xd6, 0x35, 0x28, 0xb2, 0x1c, 0x1c, 0x97, 0x72, 0x3, 0xcd, 0xe9, 0x7c, 0x52, 0x19, 0x9b, 0x94, 0x3c, 0x79, 0x94, 0x32, 0x2e, 0xa3, 0xe, 0x1f, 0x64, 0x9d, 0x69")
MAKE_THUNK(libdrm, drmGetDevice2, "0x90, 0xda, 0x3, 0xf7, 0x63, 0x7b, 0xda, 0x3d, 0x57, 0x63, 0xf7, 0x16, 0x3b, 0xb6, 0x9f, 0x45, 0xb4, 0x47, 0xd3, 0x74, 0x74, 0x9, 0x5b, 0x5, 0x70, 0xd2, 0x3a, 0x5b, 0xc2, 0x2, 0x2c, 0x9f")
MAKE_THUNK(libdrm, drmGetDevices2, "0x41, 0xf7, 0x81, 0xa3, 0xba, 0x81, 0xae, 0x84, 0x3c, 0xb4, 0xc9, 0x1d, 0x7f, 0x3f, 0x2d, 0x7a, 0x97, 0x2e, 0xc5, 0x67, 0x88, 0xea, 0xbe, 0x48, 0x5b, 0xc, 0x8c, 0x39, 0x5a, 0x59, 0x58, 0x5b")
MAKE_THUNK(libdrm, drmDevicesEqual, "0x49, 0x46, 0x1b, 0x63, 0xc4, 0xfe, 0xe0, 0x49, 0x77, 0x83, 0xe5, 0x1, 0x8d, 0xd6, 0x71, 0xb, 0x6c, 0x37, 0x44, 0x83, 0xd5, 0x74, 0xd4, 0xc8, 0x34, 0x47, 0x61, 0xa8, 0x9d, 0x67, 0x24, 0x4d")
MAKE_THUNK(libdrm, drmSyncobjCreate, "0x41, 0xbe, 0x6b, 0x2b, 0xec, 0x6a, 0xca, 0x5f, 0xa0, 0x9a, 0x19, 0x0, 0xa9, 0x77, 0x52, 0x1d, 0xda, 0x0, 0xe6, 0xa3, 0xe4, 0x6d, 0xd8, 0x60, 0x6c, 0xf7, 0x86, 0xf3, 0x3a, 0xcc, 0xe4, 0x7b")
MAKE_THUNK(libdrm, drmSyncobjDestroy, "0x3f, 0x68, 0xb8, 0x3f, 0xf6, 0x98, 0xf2, 0x7d, 0xda, 0x1a, 0x3a, 0x9a, 0x10, 0xd4, 0xf8, 0xe3, 0xee, 0x95, 0xee, 0xdf, 0x7a, 0x5d, 0xb2, 0x6, 0xcf, 0xf2, 0x53, 0x9f, 0xe0, 0x42, 0xff, 0x32")
MAKE_THUNK(libdrm, drmSyncobjHandleToFD, "0xa2, 0xa4, 0xb4, 0x6, 0x46, 0x7f, 0x9d, 0x3a, 0x60, 0x58, 0xf4, 0x52, 0x42, 0xb4, 0x4d, 0x39, 0x81, 0x27, 0x92, 0xb5, 0xf, 0x7d, 0xaf, 0x4b, 0xbc, 0xa0, 0x92, 0xd4, 0x85, 0x59, 0x25, 0xbf")
MAKE_THUNK(libdrm, drmSyncobjFDToHandle, "0x40, 0x5, 0x7a, 0x39, 0x1c, 0x27, 0xeb, 0x52, 0xdd, 0x7e, 0xfd, 0xf1, 0xd, 0xb5, 0xd1, 0x78, 0x49, 0x45, 0x42, 0x6c, 0x25, 0xe5, 0x8d, 0xf3, 0x57, 0x73, 0xc5, 0xf6, 0x37, 0xea, 0xd4, 0xfa")
MAKE_THUNK(libdrm, drmSyncobjImportSyncFile, "0xdd, 0xac, 0x97, 0x11, 0x37, 0x5f, 0xff, 0xd8, 0x25, 0x92, 0x3f, 0x51, 0x1a, 0xfc, 0x45, 0xb2, 0x45, 0x4d, 0x74, 0x3a, 0x4e, 0xea, 0xad, 0xb2, 0xb8, 0xf8, 0xec, 0xac, 0xa4, 0xbc, 0x30, 0x8d")
MAKE_THUNK(libdrm, drmSyncobjExportSyncFile, "0xbd, 0x14, 0x20, 0x21, 0x4b, 0xac, 0xc9, 0xf8, 0x51, 0x7b, 0xfd, 0x87, 0x73, 0xe2, 0x71, 0xc, 0x5d, 0xf8, 0x85, 0x59, 0xe6, 0xc9, 0x10, 0x94, 0x7a, 0x39, 0x4, 0xb9, 0x2b, 0x84, 0xa6, 0xf9")
MAKE_THUNK(libdrm, drmSyncobjWait, "0x22, 0x14, 0x16, 0xee, 0x9c, 0xfe, 0x3c, 0x1b, 0x22, 0xb1, 0xdd, 0xba, 0x29, 0x90, 0x1f, 0x95, 0xad, 0x59, 0x51, 0x8c, 0x78, 0x52, 0xde, 0x58, 0x34, 0x65, 0x6c, 0x45, 0x6, 0x31, 0x6a, 0xc0")
MAKE_THUNK(libdrm, drmSyncobjReset, "0xd5, 0x59, 0x4f, 0xa0, 0x95, 0xc5, 0x88, 0x3b, 0xa1, 0x1, 0xf, 0x15, 0x62, 0x4e, 0x36, 0x83, 0xf1, 0x5b, 0xd8, 0xc7, 0xc5, 0x2a, 0xda, 0xcb, 0x12, 0x1c, 0x58, 0x1, 0x10, 0x61, 0x72, 0xb")
MAKE_THUNK(libdrm, drmSyncobjSignal, "0xf5, 0xc1, 0xd8, 0x94, 0xb6, 0x50, 0xfe, 0xcf, 0xf, 0x22, 0x8f, 0x6d, 0x8d, 0xd6, 0x39, 0xdc, 0x9, 0x7e, 0x25, 0x69, 0x2f, 0x60, 0x8c, 0x25, 0xee, 0xd3, 0xe7, 0x64, 0xd5, 0x96, 0xf6, 0xa0")
MAKE_THUNK(libdrm, drmSyncobjTimelineSignal, "0xf1, 0xa0, 0xfb, 0x4d, 0x18, 0x8a, 0x4e, 0x1d, 0x59, 0x4c, 0x32, 0xd2, 0xf, 0x31, 0xd0, 0x33, 0x20, 0xb7, 0x48, 0xf6, 0x9d, 0xfc, 0xd4, 0xfb, 0x64, 0xf1, 0xae, 0x9, 0xd, 0x81, 0x6b, 0xe6")
MAKE_THUNK(libdrm, drmSyncobjTimelineWait, "0xd2, 0x4b, 0xd1, 0x1d, 0xe6, 0x50, 0xe0, 0x6a, 0x40, 0x27, 0x95, 0x1d, 0xe3, 0x45, 0x32, 0x30, 0x7f, 0xf2, 0xb6, 0xa1, 0xce, 0x50, 0xa4, 0x8c, 0xa0, 0x81, 0x34, 0x2f, 0x40, 0xf6, 0x33, 0xd0")
MAKE_THUNK(libdrm, drmSyncobjQuery, "0x1d, 0x8, 0x4c, 0x42, 0x1a, 0xe9, 0xc1, 0x42, 0xf0, 0xa3, 0x64, 0xa3, 0x6e, 0xfa, 0x6d, 0xe6, 0x99, 0x5c, 0xa9, 0x9, 0xfb, 0xac, 0xe6, 0x48, 0x70, 0xc, 0x9e, 0x46, 0x5e, 0xfc, 0x12, 0xc4")
MAKE_THUNK(libdrm, drmSyncobjQuery2, "0x4f, 0x7d, 0xb8, 0xdf, 0xb8, 0xc7, 0x39, 0x1, 0xfb, 0x62, 0xdc, 0x23, 0x5d, 0x2b, 0xe7, 0x7a, 0x90, 0x4a, 0x68, 0xa1, 0x21, 0x50, 0x25, 0xad, 0x22, 0xb3, 0xc2, 0xef, 0xd5, 0x4e, 0x35, 0xf7")
MAKE_THUNK(libdrm, drmSyncobjTransfer, "0xc5, 0xc9, 0x4a, 0x9b, 0xc7, 0xab, 0xb7, 0x92, 0x17, 0x4a, 0x8e, 0xe9, 0x73, 0xb4, 0x86, 0x4a, 0xa6, 0xbb, 0xd2, 0xbd, 0x9e, 0x85, 0x30, 0x32, 0xe7, 0xd7, 0x22, 0x52, 0xcf, 0xda, 0x16, 0x6e")
}
extern "C" {
FEX_PACKFN_LINKAGE auto fexfn_pack_FEX_usable_size(void * a_0) -> size_t {
  struct __attribute__((packed)) {
    void * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_FEX_usable_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_FEX_free_on_host(void * a_0) -> void {
  struct __attribute__((packed)) {
    void * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_FEX_free_on_host(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmIoctl(int a_0, unsigned long a_1, void * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    unsigned long a_1;
    void * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmIoctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetHashTable() -> void * {
  struct __attribute__((packed)) {
    void * rv;
  } args;
  fexthunks_libdrm_drmGetHashTable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetEntry(int a_0) -> drmHashEntry * {
  struct __attribute__((packed)) {
    int a_0;
    drmHashEntry * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetEntry(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmAvailable() -> int {
  struct __attribute__((packed)) {
    int rv;
  } args;
  fexthunks_libdrm_drmAvailable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmOpen(const char * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmOpen(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmOpenWithType(const char * a_0, const char * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    const char * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmOpenWithType(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmOpenControl(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmOpenControl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmOpenRender(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmOpenRender(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmClose(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmClose(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetVersion(int a_0) -> drmVersionPtr {
  struct __attribute__((packed)) {
    int a_0;
    drmVersionPtr rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetVersion(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetLibVersion(int a_0) -> drmVersionPtr {
  struct __attribute__((packed)) {
    int a_0;
    drmVersionPtr rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetLibVersion(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetCap(int a_0, uint64_t a_1, uint64_t * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint64_t a_1;
    uint64_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmGetCap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFreeVersion(drmVersionPtr a_0) -> void {
  struct __attribute__((packed)) {
    drmVersionPtr a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmFreeVersion(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetMagic(int a_0, drm_magic_t * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_magic_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmGetMagic(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetBusid(int a_0) -> char * {
  struct __attribute__((packed)) {
    int a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetBusid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetInterruptFromBusID(int a_0, int a_1, int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmGetInterruptFromBusID(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetMap(int a_0, int a_1, drm_handle_t * a_2, drmSize * a_3, drmMapType * a_4, drmMapFlags * a_5, drm_handle_t * a_6, int * a_7) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    drm_handle_t * a_2;
    drmSize * a_3;
    drmMapType * a_4;
    drmMapFlags * a_5;
    drm_handle_t * a_6;
    int * a_7;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libdrm_drmGetMap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetClient(int a_0, int a_1, int * a_2, int * a_3, int * a_4, unsigned long * a_5, unsigned long * a_6) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    int * a_2;
    int * a_3;
    int * a_4;
    unsigned long * a_5;
    unsigned long * a_6;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libdrm_drmGetClient(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetStats(int a_0, drmStatsT * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drmStatsT * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmGetStats(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSetInterfaceVersion(int a_0, drmSetVersion * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drmSetVersion * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmSetInterfaceVersion(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCommandNone(int a_0, unsigned long a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    unsigned long a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmCommandNone(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCommandRead(int a_0, unsigned long a_1, void * a_2, unsigned long a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    unsigned long a_1;
    void * a_2;
    unsigned long a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmCommandRead(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCommandWrite(int a_0, unsigned long a_1, void * a_2, unsigned long a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    unsigned long a_1;
    void * a_2;
    unsigned long a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmCommandWrite(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCommandWriteRead(int a_0, unsigned long a_1, void * a_2, unsigned long a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    unsigned long a_1;
    void * a_2;
    unsigned long a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmCommandWriteRead(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFreeBusid(const char * a_0) -> void {
  struct __attribute__((packed)) {
    const char * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmFreeBusid(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSetBusid(int a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmSetBusid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmAuthMagic(int a_0, drm_magic_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_magic_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmAuthMagic(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmAddMap(int a_0, drm_handle_t a_1, drmSize a_2, drmMapType a_3, drmMapFlags a_4, drm_handle_t * a_5) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_handle_t a_1;
    drmSize a_2;
    drmMapType a_3;
    drmMapFlags a_4;
    drm_handle_t * a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libdrm_drmAddMap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmRmMap(int a_0, drm_handle_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_handle_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmRmMap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmAddContextPrivateMapping(int a_0, drm_context_t a_1, drm_handle_t a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    drm_handle_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmAddContextPrivateMapping(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmAddBufs(int a_0, int a_1, int a_2, drmBufDescFlags a_3, int a_4) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    int a_2;
    drmBufDescFlags a_3;
    int a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libdrm_drmAddBufs(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmMarkBufs(int a_0, double a_1, double a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    double a_1;
    double a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmMarkBufs(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCreateContext(int a_0, drm_context_t * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmCreateContext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSetContextFlags(int a_0, drm_context_t a_1, drm_context_tFlags a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    drm_context_tFlags a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSetContextFlags(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetContextFlags(int a_0, drm_context_t a_1, drm_context_tFlagsPtr a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    drm_context_tFlagsPtr a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmGetContextFlags(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmAddContextTag(int a_0, drm_context_t a_1, void * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    void * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmAddContextTag(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmDelContextTag(int a_0, drm_context_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmDelContextTag(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetContextTag(int a_0, drm_context_t a_1) -> void * {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    void * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmGetContextTag(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetReservedContextList(int a_0, int * a_1) -> drm_context_t * {
  struct __attribute__((packed)) {
    int a_0;
    int * a_1;
    drm_context_t * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmGetReservedContextList(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFreeReservedContextList(drm_context_t * a_0) -> void {
  struct __attribute__((packed)) {
    drm_context_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmFreeReservedContextList(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSwitchToContext(int a_0, drm_context_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmSwitchToContext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmDestroyContext(int a_0, drm_context_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmDestroyContext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCreateDrawable(int a_0, drm_drawable_t * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_drawable_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmCreateDrawable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmDestroyDrawable(int a_0, drm_drawable_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_drawable_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmDestroyDrawable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmUpdateDrawableInfo(int a_0, drm_drawable_t a_1, drm_drawable_info_type_t a_2, unsigned int a_3, void * a_4) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_drawable_t a_1;
    drm_drawable_info_type_t a_2;
    unsigned int a_3;
    void * a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libdrm_drmUpdateDrawableInfo(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCtlInstHandler(int a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmCtlInstHandler(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCtlUninstHandler(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmCtlUninstHandler(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSetClientCap(int a_0, uint64_t a_1, uint64_t a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint64_t a_1;
    uint64_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSetClientCap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCrtcGetSequence(int a_0, uint32_t a_1, uint64_t * a_2, uint64_t * a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    uint64_t * a_2;
    uint64_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmCrtcGetSequence(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCrtcQueueSequence(int a_0, uint32_t a_1, uint32_t a_2, uint64_t a_3, uint64_t * a_4, uint64_t a_5) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    uint32_t a_2;
    uint64_t a_3;
    uint64_t * a_4;
    uint64_t a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libdrm_drmCrtcQueueSequence(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmMap(int a_0, drm_handle_t a_1, drmSize a_2, drmAddressPtr a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_handle_t a_1;
    drmSize a_2;
    drmAddressPtr a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmMap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmUnmap(drmAddress a_0, drmSize a_1) -> int {
  struct __attribute__((packed)) {
    drmAddress a_0;
    drmSize a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmUnmap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetBufInfo(int a_0) -> drmBufInfoPtr {
  struct __attribute__((packed)) {
    int a_0;
    drmBufInfoPtr rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetBufInfo(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmMapBufs(int a_0) -> drmBufMapPtr {
  struct __attribute__((packed)) {
    int a_0;
    drmBufMapPtr rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmMapBufs(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmUnmapBufs(drmBufMapPtr a_0) -> int {
  struct __attribute__((packed)) {
    drmBufMapPtr a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmUnmapBufs(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmDMA(int a_0, drmDMAReqPtr a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drmDMAReqPtr a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmDMA(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFreeBufs(int a_0, int a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmFreeBufs(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetLock(int a_0, drm_context_t a_1, drmLockFlags a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    drmLockFlags a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmGetLock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmUnlock(int a_0, drm_context_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmUnlock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFinish(int a_0, int a_1, drmLockFlags a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    drmLockFlags a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmFinish(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetContextPrivateMapping(int a_0, drm_context_t a_1, drm_handle_t * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_context_t a_1;
    drm_handle_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmGetContextPrivateMapping(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmScatterGatherAlloc(int a_0, unsigned long a_1, drm_handle_t * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    unsigned long a_1;
    drm_handle_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmScatterGatherAlloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmScatterGatherFree(int a_0, drm_handle_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drm_handle_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmScatterGatherFree(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmWaitVBlank(int a_0, drmVBlankPtr a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drmVBlankPtr a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmWaitVBlank(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSetServerInfo(drmServerInfoPtr a_0) -> void {
  struct __attribute__((packed)) {
    drmServerInfoPtr a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmSetServerInfo(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmError(int a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmError(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmMalloc(int a_0) -> void * {
  struct __attribute__((packed)) {
    int a_0;
    void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmMalloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFree(void * a_0) -> void {
  struct __attribute__((packed)) {
    void * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmFree(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHashCreate() -> void * {
  struct __attribute__((packed)) {
    void * rv;
  } args;
  fexthunks_libdrm_drmHashCreate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHashDestroy(void * a_0) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmHashDestroy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHashLookup(void * a_0, unsigned long a_1, void ** a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long a_1;
    void ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmHashLookup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHashInsert(void * a_0, unsigned long a_1, void * a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long a_1;
    void * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmHashInsert(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHashDelete(void * a_0, unsigned long a_1) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmHashDelete(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHashFirst(void * a_0, unsigned long * a_1, void ** a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long * a_1;
    void ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmHashFirst(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHashNext(void * a_0, unsigned long * a_1, void ** a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long * a_1;
    void ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmHashNext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmRandomCreate(unsigned long a_0) -> void * {
  struct __attribute__((packed)) {
    unsigned long a_0;
    void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmRandomCreate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmRandomDestroy(void * a_0) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmRandomDestroy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmRandom(void * a_0) -> unsigned long {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmRandom(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmRandomDouble(void * a_0) -> double {
  struct __attribute__((packed)) {
    void * a_0;
    double rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmRandomDouble(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLCreate() -> void * {
  struct __attribute__((packed)) {
    void * rv;
  } args;
  fexthunks_libdrm_drmSLCreate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLDestroy(void * a_0) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmSLDestroy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLLookup(void * a_0, unsigned long a_1, void ** a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long a_1;
    void ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSLLookup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLInsert(void * a_0, unsigned long a_1, void * a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long a_1;
    void * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSLInsert(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLDelete(void * a_0, unsigned long a_1) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmSLDelete(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLNext(void * a_0, unsigned long * a_1, void ** a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long * a_1;
    void ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSLNext(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLFirst(void * a_0, unsigned long * a_1, void ** a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long * a_1;
    void ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSLFirst(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLDump(void * a_0) -> void {
  struct __attribute__((packed)) {
    void * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmSLDump(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSLLookupNeighbors(void * a_0, unsigned long a_1, unsigned long * a_2, void ** a_3, unsigned long * a_4, void ** a_5) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    unsigned long a_1;
    unsigned long * a_2;
    void ** a_3;
    unsigned long * a_4;
    void ** a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libdrm_drmSLLookupNeighbors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmOpenOnce(void * a_0, const char * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    const char * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmOpenOnce(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmOpenOnceWithType(const char * a_0, int * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    int * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmOpenOnceWithType(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmCloseOnce(int a_0) -> void {
  struct __attribute__((packed)) {
    int a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmCloseOnce(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSetMaster(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmSetMaster(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmDropMaster(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmDropMaster(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmIsMaster(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmIsMaster(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmHandleEvent(int a_0, drmEventContextPtr a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drmEventContextPtr a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmHandleEvent(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetDeviceNameFromFd(int a_0) -> char * {
  struct __attribute__((packed)) {
    int a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetDeviceNameFromFd(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetDeviceNameFromFd2(int a_0) -> char * {
  struct __attribute__((packed)) {
    int a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetDeviceNameFromFd2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetNodeTypeFromFd(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetNodeTypeFromFd(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmPrimeHandleToFD(int a_0, uint32_t a_1, uint32_t a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    uint32_t a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmPrimeHandleToFD(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmPrimeFDToHandle(int a_0, int a_1, uint32_t * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    uint32_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmPrimeFDToHandle(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetPrimaryDeviceNameFromFd(int a_0) -> char * {
  struct __attribute__((packed)) {
    int a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetPrimaryDeviceNameFromFd(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetRenderDeviceNameFromFd(int a_0) -> char * {
  struct __attribute__((packed)) {
    int a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmGetRenderDeviceNameFromFd(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetDevice(int a_0, drmDevicePtr * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    drmDevicePtr * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmGetDevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFreeDevice(drmDevicePtr * a_0) -> void {
  struct __attribute__((packed)) {
    drmDevicePtr * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libdrm_drmFreeDevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetDevices(drmDevicePtr * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    drmDevicePtr * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmGetDevices(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmFreeDevices(drmDevicePtr * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    drmDevicePtr * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmFreeDevices(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetDevice2(int a_0, uint32_t a_1, drmDevicePtr * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    drmDevicePtr * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmGetDevice2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmGetDevices2(uint32_t a_0, drmDevicePtr * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    uint32_t a_0;
    drmDevicePtr * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmGetDevices2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmDevicesEqual(drmDevicePtr a_0, drmDevicePtr a_1) -> int {
  struct __attribute__((packed)) {
    drmDevicePtr a_0;
    drmDevicePtr a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmDevicesEqual(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjCreate(int a_0, uint32_t a_1, uint32_t * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    uint32_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSyncobjCreate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjDestroy(int a_0, uint32_t a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libdrm_drmSyncobjDestroy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjHandleToFD(int a_0, uint32_t a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSyncobjHandleToFD(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjFDToHandle(int a_0, int a_1, uint32_t * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    uint32_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSyncobjFDToHandle(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjImportSyncFile(int a_0, uint32_t a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSyncobjImportSyncFile(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjExportSyncFile(int a_0, uint32_t a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSyncobjExportSyncFile(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjWait(int a_0, uint32_t * a_1, unsigned int a_2, int64_t a_3, unsigned int a_4, uint32_t * a_5) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t * a_1;
    unsigned int a_2;
    int64_t a_3;
    unsigned int a_4;
    uint32_t * a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libdrm_drmSyncobjWait(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjReset(int a_0, const uint32_t * a_1, uint32_t a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    const uint32_t * a_1;
    uint32_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSyncobjReset(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjSignal(int a_0, const uint32_t * a_1, uint32_t a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    const uint32_t * a_1;
    uint32_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libdrm_drmSyncobjSignal(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjTimelineSignal(int a_0, const uint32_t * a_1, uint64_t * a_2, uint32_t a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    const uint32_t * a_1;
    uint64_t * a_2;
    uint32_t a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmSyncobjTimelineSignal(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjTimelineWait(int a_0, uint32_t * a_1, uint64_t * a_2, unsigned int a_3, int64_t a_4, unsigned int a_5, uint32_t * a_6) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t * a_1;
    uint64_t * a_2;
    unsigned int a_3;
    int64_t a_4;
    unsigned int a_5;
    uint32_t * a_6;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libdrm_drmSyncobjTimelineWait(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjQuery(int a_0, uint32_t * a_1, uint64_t * a_2, uint32_t a_3) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t * a_1;
    uint64_t * a_2;
    uint32_t a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libdrm_drmSyncobjQuery(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjQuery2(int a_0, uint32_t * a_1, uint64_t * a_2, uint32_t a_3, uint32_t a_4) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t * a_1;
    uint64_t * a_2;
    uint32_t a_3;
    uint32_t a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libdrm_drmSyncobjQuery2(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_drmSyncobjTransfer(int a_0, uint32_t a_1, uint64_t a_2, uint32_t a_3, uint64_t a_4, uint32_t a_5) -> int {
  struct __attribute__((packed)) {
    int a_0;
    uint32_t a_1;
    uint64_t a_2;
    uint32_t a_3;
    uint64_t a_4;
    uint32_t a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libdrm_drmSyncobjTransfer(&args);
  return args.rv;
}
}
extern "C" {
__attribute__((alias("fexfn_pack_drmIoctl"))) auto drmIoctl(int a_0, unsigned long a_1, void * a_2) -> int;
__attribute__((alias("fexfn_pack_drmGetHashTable"))) auto drmGetHashTable() -> void *;
__attribute__((alias("fexfn_pack_drmGetEntry"))) auto drmGetEntry(int a_0) -> drmHashEntry *;
__attribute__((alias("fexfn_pack_drmAvailable"))) auto drmAvailable() -> int;
__attribute__((alias("fexfn_pack_drmOpen"))) auto drmOpen(const char * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_drmOpenWithType"))) auto drmOpenWithType(const char * a_0, const char * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_drmOpenControl"))) auto drmOpenControl(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmOpenRender"))) auto drmOpenRender(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmClose"))) auto drmClose(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmGetVersion"))) auto drmGetVersion(int a_0) -> drmVersionPtr;
__attribute__((alias("fexfn_pack_drmGetLibVersion"))) auto drmGetLibVersion(int a_0) -> drmVersionPtr;
__attribute__((alias("fexfn_pack_drmGetCap"))) auto drmGetCap(int a_0, uint64_t a_1, uint64_t * a_2) -> int;
__attribute__((alias("fexfn_pack_drmFreeVersion"))) auto drmFreeVersion(drmVersionPtr a_0) -> void;
__attribute__((alias("fexfn_pack_drmGetMagic"))) auto drmGetMagic(int a_0, drm_magic_t * a_1) -> int;
__attribute__((alias("fexfn_pack_drmGetBusid"))) auto drmGetBusid(int a_0) -> char *;
__attribute__((alias("fexfn_pack_drmGetInterruptFromBusID"))) auto drmGetInterruptFromBusID(int a_0, int a_1, int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_drmGetMap"))) auto drmGetMap(int a_0, int a_1, drm_handle_t * a_2, drmSize * a_3, drmMapType * a_4, drmMapFlags * a_5, drm_handle_t * a_6, int * a_7) -> int;
__attribute__((alias("fexfn_pack_drmGetClient"))) auto drmGetClient(int a_0, int a_1, int * a_2, int * a_3, int * a_4, unsigned long * a_5, unsigned long * a_6) -> int;
__attribute__((alias("fexfn_pack_drmGetStats"))) auto drmGetStats(int a_0, drmStatsT * a_1) -> int;
__attribute__((alias("fexfn_pack_drmSetInterfaceVersion"))) auto drmSetInterfaceVersion(int a_0, drmSetVersion * a_1) -> int;
__attribute__((alias("fexfn_pack_drmCommandNone"))) auto drmCommandNone(int a_0, unsigned long a_1) -> int;
__attribute__((alias("fexfn_pack_drmCommandRead"))) auto drmCommandRead(int a_0, unsigned long a_1, void * a_2, unsigned long a_3) -> int;
__attribute__((alias("fexfn_pack_drmCommandWrite"))) auto drmCommandWrite(int a_0, unsigned long a_1, void * a_2, unsigned long a_3) -> int;
__attribute__((alias("fexfn_pack_drmCommandWriteRead"))) auto drmCommandWriteRead(int a_0, unsigned long a_1, void * a_2, unsigned long a_3) -> int;
__attribute__((alias("fexfn_pack_drmFreeBusid"))) auto drmFreeBusid(const char * a_0) -> void;
__attribute__((alias("fexfn_pack_drmSetBusid"))) auto drmSetBusid(int a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_drmAuthMagic"))) auto drmAuthMagic(int a_0, drm_magic_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmAddMap"))) auto drmAddMap(int a_0, drm_handle_t a_1, drmSize a_2, drmMapType a_3, drmMapFlags a_4, drm_handle_t * a_5) -> int;
__attribute__((alias("fexfn_pack_drmRmMap"))) auto drmRmMap(int a_0, drm_handle_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmAddContextPrivateMapping"))) auto drmAddContextPrivateMapping(int a_0, drm_context_t a_1, drm_handle_t a_2) -> int;
__attribute__((alias("fexfn_pack_drmAddBufs"))) auto drmAddBufs(int a_0, int a_1, int a_2, drmBufDescFlags a_3, int a_4) -> int;
__attribute__((alias("fexfn_pack_drmMarkBufs"))) auto drmMarkBufs(int a_0, double a_1, double a_2) -> int;
__attribute__((alias("fexfn_pack_drmCreateContext"))) auto drmCreateContext(int a_0, drm_context_t * a_1) -> int;
__attribute__((alias("fexfn_pack_drmSetContextFlags"))) auto drmSetContextFlags(int a_0, drm_context_t a_1, drm_context_tFlags a_2) -> int;
__attribute__((alias("fexfn_pack_drmGetContextFlags"))) auto drmGetContextFlags(int a_0, drm_context_t a_1, drm_context_tFlagsPtr a_2) -> int;
__attribute__((alias("fexfn_pack_drmAddContextTag"))) auto drmAddContextTag(int a_0, drm_context_t a_1, void * a_2) -> int;
__attribute__((alias("fexfn_pack_drmDelContextTag"))) auto drmDelContextTag(int a_0, drm_context_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmGetContextTag"))) auto drmGetContextTag(int a_0, drm_context_t a_1) -> void *;
__attribute__((alias("fexfn_pack_drmGetReservedContextList"))) auto drmGetReservedContextList(int a_0, int * a_1) -> drm_context_t *;
__attribute__((alias("fexfn_pack_drmFreeReservedContextList"))) auto drmFreeReservedContextList(drm_context_t * a_0) -> void;
__attribute__((alias("fexfn_pack_drmSwitchToContext"))) auto drmSwitchToContext(int a_0, drm_context_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmDestroyContext"))) auto drmDestroyContext(int a_0, drm_context_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmCreateDrawable"))) auto drmCreateDrawable(int a_0, drm_drawable_t * a_1) -> int;
__attribute__((alias("fexfn_pack_drmDestroyDrawable"))) auto drmDestroyDrawable(int a_0, drm_drawable_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmUpdateDrawableInfo"))) auto drmUpdateDrawableInfo(int a_0, drm_drawable_t a_1, drm_drawable_info_type_t a_2, unsigned int a_3, void * a_4) -> int;
__attribute__((alias("fexfn_pack_drmCtlInstHandler"))) auto drmCtlInstHandler(int a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_drmCtlUninstHandler"))) auto drmCtlUninstHandler(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmSetClientCap"))) auto drmSetClientCap(int a_0, uint64_t a_1, uint64_t a_2) -> int;
__attribute__((alias("fexfn_pack_drmCrtcGetSequence"))) auto drmCrtcGetSequence(int a_0, uint32_t a_1, uint64_t * a_2, uint64_t * a_3) -> int;
__attribute__((alias("fexfn_pack_drmCrtcQueueSequence"))) auto drmCrtcQueueSequence(int a_0, uint32_t a_1, uint32_t a_2, uint64_t a_3, uint64_t * a_4, uint64_t a_5) -> int;
__attribute__((alias("fexfn_pack_drmMap"))) auto drmMap(int a_0, drm_handle_t a_1, drmSize a_2, drmAddressPtr a_3) -> int;
__attribute__((alias("fexfn_pack_drmUnmap"))) auto drmUnmap(drmAddress a_0, drmSize a_1) -> int;
__attribute__((alias("fexfn_pack_drmGetBufInfo"))) auto drmGetBufInfo(int a_0) -> drmBufInfoPtr;
__attribute__((alias("fexfn_pack_drmMapBufs"))) auto drmMapBufs(int a_0) -> drmBufMapPtr;
__attribute__((alias("fexfn_pack_drmUnmapBufs"))) auto drmUnmapBufs(drmBufMapPtr a_0) -> int;
__attribute__((alias("fexfn_pack_drmDMA"))) auto drmDMA(int a_0, drmDMAReqPtr a_1) -> int;
__attribute__((alias("fexfn_pack_drmFreeBufs"))) auto drmFreeBufs(int a_0, int a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_drmGetLock"))) auto drmGetLock(int a_0, drm_context_t a_1, drmLockFlags a_2) -> int;
__attribute__((alias("fexfn_pack_drmUnlock"))) auto drmUnlock(int a_0, drm_context_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmFinish"))) auto drmFinish(int a_0, int a_1, drmLockFlags a_2) -> int;
__attribute__((alias("fexfn_pack_drmGetContextPrivateMapping"))) auto drmGetContextPrivateMapping(int a_0, drm_context_t a_1, drm_handle_t * a_2) -> int;
__attribute__((alias("fexfn_pack_drmScatterGatherAlloc"))) auto drmScatterGatherAlloc(int a_0, unsigned long a_1, drm_handle_t * a_2) -> int;
__attribute__((alias("fexfn_pack_drmScatterGatherFree"))) auto drmScatterGatherFree(int a_0, drm_handle_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmWaitVBlank"))) auto drmWaitVBlank(int a_0, drmVBlankPtr a_1) -> int;
__attribute__((alias("fexfn_pack_drmSetServerInfo"))) auto drmSetServerInfo(drmServerInfoPtr a_0) -> void;
__attribute__((alias("fexfn_pack_drmError"))) auto drmError(int a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_drmMalloc"))) auto drmMalloc(int a_0) -> void *;
__attribute__((alias("fexfn_pack_drmFree"))) auto drmFree(void * a_0) -> void;
__attribute__((alias("fexfn_pack_drmHashCreate"))) auto drmHashCreate() -> void *;
__attribute__((alias("fexfn_pack_drmHashDestroy"))) auto drmHashDestroy(void * a_0) -> int;
__attribute__((alias("fexfn_pack_drmHashLookup"))) auto drmHashLookup(void * a_0, unsigned long a_1, void ** a_2) -> int;
__attribute__((alias("fexfn_pack_drmHashInsert"))) auto drmHashInsert(void * a_0, unsigned long a_1, void * a_2) -> int;
__attribute__((alias("fexfn_pack_drmHashDelete"))) auto drmHashDelete(void * a_0, unsigned long a_1) -> int;
__attribute__((alias("fexfn_pack_drmHashFirst"))) auto drmHashFirst(void * a_0, unsigned long * a_1, void ** a_2) -> int;
__attribute__((alias("fexfn_pack_drmHashNext"))) auto drmHashNext(void * a_0, unsigned long * a_1, void ** a_2) -> int;
__attribute__((alias("fexfn_pack_drmRandomCreate"))) auto drmRandomCreate(unsigned long a_0) -> void *;
__attribute__((alias("fexfn_pack_drmRandomDestroy"))) auto drmRandomDestroy(void * a_0) -> int;
__attribute__((alias("fexfn_pack_drmRandom"))) auto drmRandom(void * a_0) -> unsigned long;
__attribute__((alias("fexfn_pack_drmRandomDouble"))) auto drmRandomDouble(void * a_0) -> double;
__attribute__((alias("fexfn_pack_drmSLCreate"))) auto drmSLCreate() -> void *;
__attribute__((alias("fexfn_pack_drmSLDestroy"))) auto drmSLDestroy(void * a_0) -> int;
__attribute__((alias("fexfn_pack_drmSLLookup"))) auto drmSLLookup(void * a_0, unsigned long a_1, void ** a_2) -> int;
__attribute__((alias("fexfn_pack_drmSLInsert"))) auto drmSLInsert(void * a_0, unsigned long a_1, void * a_2) -> int;
__attribute__((alias("fexfn_pack_drmSLDelete"))) auto drmSLDelete(void * a_0, unsigned long a_1) -> int;
__attribute__((alias("fexfn_pack_drmSLNext"))) auto drmSLNext(void * a_0, unsigned long * a_1, void ** a_2) -> int;
__attribute__((alias("fexfn_pack_drmSLFirst"))) auto drmSLFirst(void * a_0, unsigned long * a_1, void ** a_2) -> int;
__attribute__((alias("fexfn_pack_drmSLDump"))) auto drmSLDump(void * a_0) -> void;
__attribute__((alias("fexfn_pack_drmSLLookupNeighbors"))) auto drmSLLookupNeighbors(void * a_0, unsigned long a_1, unsigned long * a_2, void ** a_3, unsigned long * a_4, void ** a_5) -> int;
__attribute__((alias("fexfn_pack_drmOpenOnce"))) auto drmOpenOnce(void * a_0, const char * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_drmOpenOnceWithType"))) auto drmOpenOnceWithType(const char * a_0, int * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_drmCloseOnce"))) auto drmCloseOnce(int a_0) -> void;
__attribute__((alias("fexfn_pack_drmSetMaster"))) auto drmSetMaster(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmDropMaster"))) auto drmDropMaster(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmIsMaster"))) auto drmIsMaster(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmHandleEvent"))) auto drmHandleEvent(int a_0, drmEventContextPtr a_1) -> int;
__attribute__((alias("fexfn_pack_drmGetNodeTypeFromFd"))) auto drmGetNodeTypeFromFd(int a_0) -> int;
__attribute__((alias("fexfn_pack_drmPrimeHandleToFD"))) auto drmPrimeHandleToFD(int a_0, uint32_t a_1, uint32_t a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_drmPrimeFDToHandle"))) auto drmPrimeFDToHandle(int a_0, int a_1, uint32_t * a_2) -> int;
__attribute__((alias("fexfn_pack_drmGetDevice"))) auto drmGetDevice(int a_0, drmDevicePtr * a_1) -> int;
__attribute__((alias("fexfn_pack_drmFreeDevice"))) auto drmFreeDevice(drmDevicePtr * a_0) -> void;
__attribute__((alias("fexfn_pack_drmGetDevices"))) auto drmGetDevices(drmDevicePtr * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_drmFreeDevices"))) auto drmFreeDevices(drmDevicePtr * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_drmGetDevice2"))) auto drmGetDevice2(int a_0, uint32_t a_1, drmDevicePtr * a_2) -> int;
__attribute__((alias("fexfn_pack_drmGetDevices2"))) auto drmGetDevices2(uint32_t a_0, drmDevicePtr * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_drmDevicesEqual"))) auto drmDevicesEqual(drmDevicePtr a_0, drmDevicePtr a_1) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjCreate"))) auto drmSyncobjCreate(int a_0, uint32_t a_1, uint32_t * a_2) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjDestroy"))) auto drmSyncobjDestroy(int a_0, uint32_t a_1) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjHandleToFD"))) auto drmSyncobjHandleToFD(int a_0, uint32_t a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjFDToHandle"))) auto drmSyncobjFDToHandle(int a_0, int a_1, uint32_t * a_2) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjImportSyncFile"))) auto drmSyncobjImportSyncFile(int a_0, uint32_t a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjExportSyncFile"))) auto drmSyncobjExportSyncFile(int a_0, uint32_t a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjWait"))) auto drmSyncobjWait(int a_0, uint32_t * a_1, unsigned int a_2, int64_t a_3, unsigned int a_4, uint32_t * a_5) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjReset"))) auto drmSyncobjReset(int a_0, const uint32_t * a_1, uint32_t a_2) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjSignal"))) auto drmSyncobjSignal(int a_0, const uint32_t * a_1, uint32_t a_2) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjTimelineSignal"))) auto drmSyncobjTimelineSignal(int a_0, const uint32_t * a_1, uint64_t * a_2, uint32_t a_3) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjTimelineWait"))) auto drmSyncobjTimelineWait(int a_0, uint32_t * a_1, uint64_t * a_2, unsigned int a_3, int64_t a_4, unsigned int a_5, uint32_t * a_6) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjQuery"))) auto drmSyncobjQuery(int a_0, uint32_t * a_1, uint64_t * a_2, uint32_t a_3) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjQuery2"))) auto drmSyncobjQuery2(int a_0, uint32_t * a_1, uint64_t * a_2, uint32_t a_3, uint32_t a_4) -> int;
__attribute__((alias("fexfn_pack_drmSyncobjTransfer"))) auto drmSyncobjTransfer(int a_0, uint32_t a_1, uint64_t a_2, uint32_t a_3, uint64_t a_4, uint32_t a_5) -> int;
}
#define FOREACH_SYMBOL(EXPAND) \
  EXPAND(FEX_usable_size, "TODO") \
  EXPAND(FEX_free_on_host, "TODO") \
  EXPAND(drmIoctl, "TODO") \
  EXPAND(drmGetHashTable, "TODO") \
  EXPAND(drmGetEntry, "TODO") \
  EXPAND(drmAvailable, "TODO") \
  EXPAND(drmOpen, "TODO") \
  EXPAND(drmOpenWithType, "TODO") \
  EXPAND(drmOpenControl, "TODO") \
  EXPAND(drmOpenRender, "TODO") \
  EXPAND(drmClose, "TODO") \
  EXPAND(drmGetVersion, "TODO") \
  EXPAND(drmGetLibVersion, "TODO") \
  EXPAND(drmGetCap, "TODO") \
  EXPAND(drmFreeVersion, "TODO") \
  EXPAND(drmGetMagic, "TODO") \
  EXPAND(drmGetBusid, "TODO") \
  EXPAND(drmGetInterruptFromBusID, "TODO") \
  EXPAND(drmGetMap, "TODO") \
  EXPAND(drmGetClient, "TODO") \
  EXPAND(drmGetStats, "TODO") \
  EXPAND(drmSetInterfaceVersion, "TODO") \
  EXPAND(drmCommandNone, "TODO") \
  EXPAND(drmCommandRead, "TODO") \
  EXPAND(drmCommandWrite, "TODO") \
  EXPAND(drmCommandWriteRead, "TODO") \
  EXPAND(drmFreeBusid, "TODO") \
  EXPAND(drmSetBusid, "TODO") \
  EXPAND(drmAuthMagic, "TODO") \
  EXPAND(drmAddMap, "TODO") \
  EXPAND(drmRmMap, "TODO") \
  EXPAND(drmAddContextPrivateMapping, "TODO") \
  EXPAND(drmAddBufs, "TODO") \
  EXPAND(drmMarkBufs, "TODO") \
  EXPAND(drmCreateContext, "TODO") \
  EXPAND(drmSetContextFlags, "TODO") \
  EXPAND(drmGetContextFlags, "TODO") \
  EXPAND(drmAddContextTag, "TODO") \
  EXPAND(drmDelContextTag, "TODO") \
  EXPAND(drmGetContextTag, "TODO") \
  EXPAND(drmGetReservedContextList, "TODO") \
  EXPAND(drmFreeReservedContextList, "TODO") \
  EXPAND(drmSwitchToContext, "TODO") \
  EXPAND(drmDestroyContext, "TODO") \
  EXPAND(drmCreateDrawable, "TODO") \
  EXPAND(drmDestroyDrawable, "TODO") \
  EXPAND(drmUpdateDrawableInfo, "TODO") \
  EXPAND(drmCtlInstHandler, "TODO") \
  EXPAND(drmCtlUninstHandler, "TODO") \
  EXPAND(drmSetClientCap, "TODO") \
  EXPAND(drmCrtcGetSequence, "TODO") \
  EXPAND(drmCrtcQueueSequence, "TODO") \
  EXPAND(drmMap, "TODO") \
  EXPAND(drmUnmap, "TODO") \
  EXPAND(drmGetBufInfo, "TODO") \
  EXPAND(drmMapBufs, "TODO") \
  EXPAND(drmUnmapBufs, "TODO") \
  EXPAND(drmDMA, "TODO") \
  EXPAND(drmFreeBufs, "TODO") \
  EXPAND(drmGetLock, "TODO") \
  EXPAND(drmUnlock, "TODO") \
  EXPAND(drmFinish, "TODO") \
  EXPAND(drmGetContextPrivateMapping, "TODO") \
  EXPAND(drmScatterGatherAlloc, "TODO") \
  EXPAND(drmScatterGatherFree, "TODO") \
  EXPAND(drmWaitVBlank, "TODO") \
  EXPAND(drmSetServerInfo, "TODO") \
  EXPAND(drmError, "TODO") \
  EXPAND(drmMalloc, "TODO") \
  EXPAND(drmFree, "TODO") \
  EXPAND(drmHashCreate, "TODO") \
  EXPAND(drmHashDestroy, "TODO") \
  EXPAND(drmHashLookup, "TODO") \
  EXPAND(drmHashInsert, "TODO") \
  EXPAND(drmHashDelete, "TODO") \
  EXPAND(drmHashFirst, "TODO") \
  EXPAND(drmHashNext, "TODO") \
  EXPAND(drmRandomCreate, "TODO") \
  EXPAND(drmRandomDestroy, "TODO") \
  EXPAND(drmRandom, "TODO") \
  EXPAND(drmRandomDouble, "TODO") \
  EXPAND(drmSLCreate, "TODO") \
  EXPAND(drmSLDestroy, "TODO") \
  EXPAND(drmSLLookup, "TODO") \
  EXPAND(drmSLInsert, "TODO") \
  EXPAND(drmSLDelete, "TODO") \
  EXPAND(drmSLNext, "TODO") \
  EXPAND(drmSLFirst, "TODO") \
  EXPAND(drmSLDump, "TODO") \
  EXPAND(drmSLLookupNeighbors, "TODO") \
  EXPAND(drmOpenOnce, "TODO") \
  EXPAND(drmOpenOnceWithType, "TODO") \
  EXPAND(drmCloseOnce, "TODO") \
  EXPAND(drmSetMaster, "TODO") \
  EXPAND(drmDropMaster, "TODO") \
  EXPAND(drmIsMaster, "TODO") \
  EXPAND(drmHandleEvent, "TODO") \
  EXPAND(drmGetDeviceNameFromFd, "TODO") \
  EXPAND(drmGetDeviceNameFromFd2, "TODO") \
  EXPAND(drmGetNodeTypeFromFd, "TODO") \
  EXPAND(drmPrimeHandleToFD, "TODO") \
  EXPAND(drmPrimeFDToHandle, "TODO") \
  EXPAND(drmGetPrimaryDeviceNameFromFd, "TODO") \
  EXPAND(drmGetRenderDeviceNameFromFd, "TODO") \
  EXPAND(drmGetDevice, "TODO") \
  EXPAND(drmFreeDevice, "TODO") \
  EXPAND(drmGetDevices, "TODO") \
  EXPAND(drmFreeDevices, "TODO") \
  EXPAND(drmGetDevice2, "TODO") \
  EXPAND(drmGetDevices2, "TODO") \
  EXPAND(drmDevicesEqual, "TODO") \
  EXPAND(drmSyncobjCreate, "TODO") \
  EXPAND(drmSyncobjDestroy, "TODO") \
  EXPAND(drmSyncobjHandleToFD, "TODO") \
  EXPAND(drmSyncobjFDToHandle, "TODO") \
  EXPAND(drmSyncobjImportSyncFile, "TODO") \
  EXPAND(drmSyncobjExportSyncFile, "TODO") \
  EXPAND(drmSyncobjWait, "TODO") \
  EXPAND(drmSyncobjReset, "TODO") \
  EXPAND(drmSyncobjSignal, "TODO") \
  EXPAND(drmSyncobjTimelineSignal, "TODO") \
  EXPAND(drmSyncobjTimelineWait, "TODO") \
  EXPAND(drmSyncobjQuery, "TODO") \
  EXPAND(drmSyncobjQuery2, "TODO") \
  EXPAND(drmSyncobjTransfer, "TODO") \


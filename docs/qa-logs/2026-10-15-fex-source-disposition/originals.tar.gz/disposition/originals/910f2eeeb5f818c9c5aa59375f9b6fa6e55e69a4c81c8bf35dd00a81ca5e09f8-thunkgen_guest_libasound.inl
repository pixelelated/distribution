extern "C" {
MAKE_THUNK(libasound, snd_asoundlib_version, "0x71, 0xb4, 0x21, 0x60, 0x65, 0x21, 0xc4, 0xdb, 0xc5, 0x7e, 0x4e, 0x60, 0xaa, 0xe5, 0x2b, 0x26, 0xe6, 0x87, 0x32, 0xdb, 0xaf, 0xc5, 0x26, 0xab, 0x86, 0x58, 0xd4, 0x91, 0x95, 0xb5, 0x10, 0xb9")
MAKE_THUNK(libasound, snd_dlpath, "0x2d, 0x95, 0xca, 0xd3, 0x94, 0x38, 0x99, 0x7e, 0x35, 0xa6, 0x26, 0x94, 0x56, 0xc7, 0xec, 0x39, 0xae, 0xe1, 0x64, 0x42, 0x9a, 0x49, 0x36, 0x97, 0x66, 0xfb, 0x19, 0xde, 0x25, 0x2c, 0x89, 0xb6")
MAKE_THUNK(libasound, snd_dlopen, "0xa, 0xec, 0x7a, 0xfe, 0xc5, 0x46, 0x1c, 0xbf, 0xdc, 0x78, 0x5e, 0xf3, 0xd1, 0x66, 0x16, 0xaa, 0x13, 0x94, 0x6d, 0xb2, 0x4a, 0x82, 0xfd, 0x8e, 0x7c, 0xa9, 0xa, 0x58, 0x1e, 0x4b, 0xf, 0x3f")
MAKE_THUNK(libasound, snd_dlsym, "0x0, 0x66, 0x68, 0x1e, 0x26, 0x6e, 0x68, 0x8a, 0xc6, 0x32, 0x34, 0xef, 0x57, 0x63, 0xef, 0x92, 0x6d, 0xc1, 0xdb, 0x40, 0x7b, 0x96, 0x77, 0xb3, 0xc0, 0x9e, 0x65, 0xd3, 0xf2, 0xf2, 0x5a, 0xfd")
MAKE_THUNK(libasound, snd_dlclose, "0x19, 0x32, 0xfa, 0xa2, 0xe3, 0x50, 0xf8, 0xf, 0x6a, 0x4f, 0x15, 0xc4, 0xdd, 0xa0, 0x21, 0x8, 0x45, 0xf2, 0x7b, 0x9d, 0xe, 0xf0, 0x9d, 0x8f, 0x8, 0x56, 0xe6, 0x17, 0x1c, 0xcb, 0xbc, 0x62")
MAKE_THUNK(libasound, snd_shm_area_create, "0x46, 0x1b, 0x73, 0x90, 0xdd, 0x36, 0xab, 0xe9, 0x63, 0xa1, 0x8e, 0xf0, 0x66, 0xa2, 0xad, 0xdf, 0xea, 0xc, 0x68, 0x99, 0xbc, 0x8b, 0x6f, 0xf3, 0x31, 0xa7, 0x2c, 0x7f, 0x77, 0x9e, 0x31, 0x2f")
MAKE_THUNK(libasound, snd_shm_area_share, "0x65, 0x85, 0xda, 0xf4, 0x74, 0x6c, 0x2, 0x77, 0x5c, 0xbb, 0x28, 0x0, 0xaa, 0xe0, 0x45, 0xec, 0x6b, 0x36, 0x40, 0xec, 0x4d, 0xbc, 0xa2, 0xb1, 0xfc, 0x6a, 0xbe, 0xe4, 0x37, 0x91, 0x60, 0x22")
MAKE_THUNK(libasound, snd_shm_area_destroy, "0x2c, 0x3c, 0x37, 0x82, 0x5f, 0x62, 0x3f, 0x22, 0x4d, 0xde, 0x9, 0xf9, 0xe9, 0xee, 0x4a, 0x31, 0x6b, 0xa2, 0x8b, 0x74, 0xf5, 0xbf, 0xb0, 0xcc, 0x9d, 0x7e, 0x79, 0xd5, 0x6e, 0x8b, 0x3, 0xbc")
MAKE_THUNK(libasound, snd_user_file, "0x21, 0x8e, 0x23, 0xec, 0xae, 0x6, 0xe0, 0x65, 0x7d, 0x5, 0xca, 0x2, 0x59, 0x42, 0xf0, 0xa2, 0xf2, 0xe0, 0xb0, 0xd, 0x1b, 0x54, 0xdb, 0x99, 0x25, 0x7d, 0x57, 0x1f, 0xad, 0x43, 0x13, 0x1a")
MAKE_THUNK(libasound, snd_input_stdio_open, "0x8, 0x27, 0x85, 0xfd, 0xdd, 0xd1, 0xa0, 0x29, 0x47, 0x45, 0xa1, 0x62, 0xe8, 0xcd, 0x85, 0x4d, 0xfe, 0x8d, 0xc2, 0x2, 0xa5, 0x71, 0x7, 0x6b, 0x7, 0x24, 0x9c, 0x3d, 0x62, 0x46, 0xe8, 0xd6")
MAKE_THUNK(libasound, snd_input_stdio_attach, "0x3f, 0x28, 0xaf, 0x18, 0x57, 0x3f, 0x8e, 0x5a, 0x1d, 0x57, 0xe1, 0xb0, 0x63, 0x1, 0x91, 0x25, 0xaa, 0xe1, 0x2b, 0x5a, 0x27, 0x16, 0x8c, 0x4a, 0xf9, 0xe6, 0xbb, 0x40, 0xc7, 0x79, 0x1a, 0xad")
MAKE_THUNK(libasound, snd_input_buffer_open, "0x1b, 0x9f, 0xc9, 0xae, 0x46, 0x98, 0x93, 0x1d, 0xb0, 0x9, 0x15, 0xe0, 0x37, 0x79, 0x38, 0x5a, 0xbc, 0xe6, 0x79, 0x31, 0xdf, 0x3, 0x9f, 0x5, 0x97, 0xb3, 0x59, 0x7b, 0x9f, 0x97, 0x2d, 0xdf")
MAKE_THUNK(libasound, snd_input_close, "0x62, 0xa7, 0x3c, 0x5a, 0xa9, 0x6e, 0x44, 0x6c, 0xc8, 0xaa, 0x42, 0x38, 0xaa, 0xe1, 0xcb, 0x78, 0xf, 0xf, 0x5e, 0x3e, 0x80, 0x59, 0x74, 0x2f, 0x27, 0xf9, 0x71, 0x8, 0x7, 0x15, 0x4a, 0x52")
MAKE_THUNK(libasound, snd_input_gets, "0x6c, 0xfc, 0x30, 0xcc, 0x78, 0xf1, 0x89, 0x58, 0xba, 0x20, 0xbe, 0x45, 0xe9, 0xa3, 0xb7, 0x2b, 0x96, 0x69, 0x97, 0x33, 0x88, 0x8d, 0x79, 0xcd, 0xd0, 0x64, 0x9c, 0xd, 0xac, 0xe3, 0xa3, 0xa5")
MAKE_THUNK(libasound, snd_input_getc, "0x9b, 0xa9, 0x0, 0x3b, 0x8b, 0xeb, 0x37, 0x2a, 0xa6, 0xe7, 0x6b, 0x17, 0x6c, 0x98, 0xf2, 0xff, 0x36, 0xb6, 0xa8, 0x25, 0x84, 0xf5, 0x34, 0x43, 0xfa, 0x71, 0xb9, 0xda, 0xdc, 0x47, 0xd6, 0x6a")
MAKE_THUNK(libasound, snd_input_ungetc, "0x17, 0xc5, 0xd4, 0xc1, 0x26, 0x17, 0xec, 0xc0, 0x30, 0xcf, 0x56, 0xb0, 0x41, 0x81, 0xe1, 0xfc, 0x71, 0xdf, 0x6c, 0x65, 0x59, 0x36, 0x28, 0x7a, 0xf4, 0x2d, 0xe2, 0xcb, 0x46, 0xac, 0xf2, 0xf")
MAKE_THUNK(libasound, snd_output_stdio_open, "0x7b, 0x4f, 0x1d, 0x59, 0xed, 0xf, 0x79, 0x67, 0x4d, 0x49, 0x22, 0xb6, 0xa0, 0x3c, 0xd, 0x80, 0x4c, 0x22, 0x9, 0x33, 0x18, 0xa9, 0xad, 0x34, 0xd2, 0x25, 0x97, 0xe0, 0x5, 0x61, 0x80, 0x11")
MAKE_THUNK(libasound, snd_output_stdio_attach, "0xd3, 0x3b, 0x63, 0x82, 0xe8, 0x54, 0x50, 0x30, 0xac, 0x82, 0x3e, 0xfc, 0xdc, 0x15, 0x5, 0x76, 0xc9, 0x93, 0x6c, 0x78, 0xd2, 0x46, 0x27, 0xa5, 0xda, 0x17, 0xc7, 0x3d, 0x15, 0x41, 0x86, 0x98")
MAKE_THUNK(libasound, snd_output_buffer_open, "0xe5, 0x4a, 0xf, 0xad, 0x20, 0x17, 0xc6, 0x60, 0x12, 0x14, 0x39, 0x45, 0xd8, 0x7b, 0xde, 0x5a, 0x9a, 0x8c, 0x59, 0x68, 0xbe, 0x24, 0xeb, 0xa, 0x33, 0x3e, 0xe, 0x53, 0xd6, 0xc7, 0xfa, 0xe4")
MAKE_THUNK(libasound, snd_output_buffer_string, "0x20, 0xb9, 0xd5, 0x30, 0x52, 0x9d, 0xc1, 0x9b, 0xf6, 0x3f, 0x53, 0x4b, 0xc7, 0x7e, 0xe9, 0x1, 0x15, 0xd6, 0xc9, 0xa7, 0x1a, 0xc, 0x74, 0x81, 0x5e, 0x3e, 0x7, 0xd6, 0x67, 0xb2, 0x8a, 0xb4")
MAKE_THUNK(libasound, snd_output_close, "0xca, 0xb3, 0x94, 0xd7, 0xd8, 0x31, 0xec, 0x46, 0x9f, 0xcf, 0x57, 0x6f, 0xaa, 0x88, 0xce, 0x3c, 0xd4, 0xb3, 0x8f, 0x76, 0xcd, 0xb9, 0x59, 0xe9, 0x75, 0xa0, 0xc2, 0x52, 0xaa, 0x74, 0xe4, 0x1b")
MAKE_THUNK(libasound, snd_output_puts, "0xb2, 0xaf, 0x63, 0x57, 0x51, 0x5a, 0xf6, 0x50, 0x39, 0xaf, 0x87, 0x25, 0x93, 0x48, 0xa6, 0xf, 0xf8, 0xf5, 0x1e, 0x60, 0x62, 0x18, 0xd6, 0xf4, 0x32, 0xba, 0x1f, 0x7, 0xdd, 0x29, 0xf4, 0xb7")
MAKE_THUNK(libasound, snd_output_putc, "0xe5, 0x34, 0x46, 0x11, 0xd2, 0x9f, 0x48, 0xf9, 0x7e, 0x11, 0x5d, 0xef, 0xfb, 0xdd, 0x25, 0x28, 0xa5, 0xed, 0xe7, 0xf, 0x8d, 0x3f, 0xc7, 0x59, 0x2d, 0x8b, 0x15, 0xe8, 0x9, 0x3d, 0x6b, 0xe5")
MAKE_THUNK(libasound, snd_output_flush, "0x98, 0xe6, 0xfb, 0x54, 0x22, 0xc0, 0x89, 0x7d, 0x5e, 0x1a, 0xf8, 0x5f, 0x8, 0x45, 0xad, 0xb8, 0x17, 0x2b, 0xcb, 0x74, 0xe4, 0x41, 0x69, 0xa1, 0x24, 0x2c, 0x9b, 0xec, 0x8, 0xfa, 0x64, 0x93")
MAKE_THUNK(libasound, snd_strerror, "0x96, 0x2d, 0x30, 0xc5, 0xa1, 0x79, 0x80, 0xb9, 0x84, 0x4e, 0x73, 0xae, 0xfe, 0x53, 0x4, 0xe7, 0x37, 0xcc, 0x27, 0x2b, 0x98, 0x2f, 0x73, 0xae, 0x84, 0x0, 0x5c, 0x75, 0x24, 0xc2, 0x4a, 0xb1")
MAKE_THUNK(libasound, snd_lib_error_set_handler, "0x3f, 0xe5, 0x3e, 0x6a, 0x1f, 0xc0, 0x25, 0xf6, 0xd, 0x42, 0x9, 0xf2, 0x87, 0xb0, 0x62, 0x97, 0xde, 0x67, 0x4c, 0x41, 0xfe, 0x59, 0xb7, 0x1b, 0x17, 0xeb, 0x86, 0xc0, 0xf5, 0xcb, 0x3, 0xcb")
MAKE_THUNK(libasound, snd_config_topdir, "0xba, 0xd2, 0x51, 0x17, 0x29, 0x9d, 0x5d, 0x36, 0x50, 0x5f, 0x1c, 0x12, 0x87, 0x3f, 0xd9, 0xf4, 0x35, 0xcb, 0xa6, 0x5b, 0xac, 0xc8, 0x83, 0xc0, 0xa, 0x55, 0xa, 0x46, 0x51, 0xc8, 0x8b, 0x54")
MAKE_THUNK(libasound, snd_config_top, "0xfb, 0xe0, 0x58, 0x55, 0xa9, 0x42, 0xc9, 0xa2, 0xcd, 0x9, 0xe5, 0x8c, 0x9a, 0x60, 0x8f, 0xe2, 0x66, 0x55, 0xa8, 0x7f, 0x6a, 0xaa, 0xda, 0x2a, 0xe5, 0x1b, 0xb4, 0x91, 0x31, 0xf9, 0x53, 0xf3")
MAKE_THUNK(libasound, snd_config_load, "0xd1, 0x2d, 0xcf, 0x6f, 0x79, 0xf5, 0x0, 0x31, 0x9c, 0xb7, 0xce, 0x41, 0x9b, 0x75, 0x5, 0x1e, 0x3a, 0xc9, 0x46, 0xeb, 0xb9, 0x50, 0xd, 0xe6, 0x29, 0x6b, 0xb9, 0xca, 0x1d, 0x98, 0xf8, 0x16")
MAKE_THUNK(libasound, snd_config_load_override, "0x4, 0x1d, 0x3d, 0xb7, 0xcc, 0xc3, 0x26, 0x75, 0x8b, 0x87, 0xce, 0x74, 0xde, 0x20, 0x77, 0x69, 0x99, 0x41, 0x2d, 0x98, 0x66, 0x1f, 0xbc, 0x49, 0xf8, 0xec, 0xe1, 0xd2, 0x1a, 0x90, 0x83, 0x6c")
MAKE_THUNK(libasound, snd_config_save, "0xad, 0xf0, 0xf, 0x13, 0x62, 0xcf, 0x1f, 0x8d, 0x6f, 0xad, 0x6, 0x16, 0x90, 0xe7, 0x97, 0x10, 0x1e, 0x83, 0x39, 0xf4, 0xc4, 0xc, 0xde, 0xa8, 0xaf, 0x7a, 0x10, 0xc, 0xc5, 0x6, 0xe3, 0xb")
MAKE_THUNK(libasound, snd_config_update, "0x23, 0x17, 0x7, 0x64, 0xcf, 0xf6, 0x5d, 0x23, 0x88, 0x13, 0x1f, 0xaa, 0xc6, 0xcb, 0x70, 0x65, 0xf, 0x81, 0x1, 0xcf, 0x51, 0x50, 0x88, 0x94, 0xec, 0xd7, 0x7e, 0x8f, 0xbc, 0x9c, 0x6d, 0x75")
MAKE_THUNK(libasound, snd_config_update_r, "0x5b, 0x91, 0xf1, 0xe3, 0x16, 0xb4, 0x5, 0xe3, 0x4b, 0x9f, 0x9e, 0x22, 0x69, 0x3b, 0xd7, 0x87, 0xd0, 0x53, 0xc8, 0xc8, 0x3d, 0xe7, 0xf3, 0x70, 0x92, 0xe8, 0xcf, 0x27, 0x5b, 0xc8, 0x2a, 0xe6")
MAKE_THUNK(libasound, snd_config_update_free, "0x75, 0xae, 0xe7, 0xac, 0x5b, 0xfd, 0x0, 0xff, 0xf0, 0xb, 0xd5, 0x80, 0xae, 0xe8, 0x7, 0x24, 0xd0, 0x11, 0x89, 0xc, 0x36, 0x70, 0xaf, 0x65, 0xd8, 0x83, 0x40, 0xc3, 0x48, 0x25, 0xa3, 0x56")
MAKE_THUNK(libasound, snd_config_update_free_global, "0x37, 0xe0, 0x1c, 0xdb, 0xa8, 0x70, 0x49, 0x3a, 0x35, 0xb8, 0x63, 0x4d, 0x40, 0x76, 0x8d, 0xf6, 0xc2, 0xce, 0x94, 0x2e, 0x33, 0xca, 0x74, 0x95, 0x53, 0x88, 0x60, 0x43, 0x9a, 0x35, 0xb, 0x5")
MAKE_THUNK(libasound, snd_config_update_ref, "0x2c, 0xb1, 0x59, 0xd2, 0x40, 0x60, 0xc1, 0x0, 0xa1, 0x28, 0x1d, 0x94, 0xd1, 0x8e, 0xb6, 0x65, 0x40, 0x32, 0x1c, 0xc8, 0x78, 0xa, 0xe0, 0x4e, 0xc1, 0xb8, 0x28, 0x66, 0xd2, 0xdc, 0x61, 0xa0")
MAKE_THUNK(libasound, snd_config_ref, "0x6d, 0x78, 0x26, 0xbf, 0x14, 0x2f, 0x3a, 0x26, 0xb8, 0x59, 0x85, 0x1f, 0xca, 0x8a, 0x4f, 0x38, 0x3d, 0xf3, 0x48, 0x34, 0x6e, 0x72, 0x39, 0x62, 0x74, 0x13, 0x5, 0xa2, 0x85, 0x91, 0x1f, 0xe4")
MAKE_THUNK(libasound, snd_config_unref, "0x92, 0xaf, 0x56, 0x2c, 0x7b, 0x85, 0xfa, 0xae, 0xec, 0xaa, 0x2f, 0x2e, 0x7, 0xaf, 0x92, 0x3f, 0xe4, 0xca, 0xf6, 0x20, 0xd5, 0x2f, 0x69, 0xe9, 0xbd, 0x75, 0xd0, 0x5a, 0x77, 0x14, 0xb5, 0x7b")
MAKE_THUNK(libasound, snd_config_search, "0xd6, 0x7c, 0x2d, 0x64, 0xcf, 0xfd, 0x22, 0x1b, 0x50, 0xf0, 0x88, 0xe2, 0x97, 0xcc, 0x6c, 0xac, 0xf8, 0x10, 0xdf, 0x96, 0x21, 0xf1, 0x3b, 0x50, 0x5d, 0x1a, 0x97, 0xc5, 0x61, 0x97, 0x4c, 0x54")
MAKE_THUNK(libasound, snd_config_search_definition, "0xeb, 0xf0, 0xd, 0xb8, 0x4, 0x64, 0xd9, 0x23, 0xcf, 0x31, 0x68, 0x97, 0x67, 0x9f, 0xfc, 0x3a, 0x59, 0xa9, 0x7c, 0x26, 0x26, 0xb6, 0xb1, 0x66, 0xfa, 0xca, 0xce, 0xfa, 0xda, 0x3b, 0x52, 0xd0")
MAKE_THUNK(libasound, snd_config_expand, "0x94, 0x85, 0x2c, 0x6, 0x92, 0xc0, 0xb8, 0x2c, 0x92, 0x9e, 0xf5, 0x76, 0x8a, 0x1, 0xfd, 0x38, 0x7e, 0x14, 0xe3, 0x4f, 0xf0, 0x15, 0x2b, 0xd, 0x72, 0x48, 0xf0, 0x5d, 0xa4, 0xc4, 0x5e, 0x63")
MAKE_THUNK(libasound, snd_config_evaluate, "0x59, 0x45, 0x93, 0xc0, 0xe3, 0x37, 0x17, 0x91, 0x7a, 0xfd, 0x85, 0x50, 0x4b, 0x11, 0x80, 0xac, 0x3c, 0x87, 0x5, 0x65, 0x10, 0x82, 0xc1, 0x53, 0x7a, 0x49, 0x13, 0x44, 0xb5, 0x7, 0xd7, 0x1e")
MAKE_THUNK(libasound, snd_config_add, "0x21, 0x58, 0xc2, 0xf1, 0x16, 0x67, 0xb9, 0xd9, 0xc3, 0x1d, 0x17, 0x96, 0x8, 0x8, 0x2c, 0x42, 0x39, 0x25, 0x44, 0x15, 0xf9, 0x2a, 0x31, 0x4e, 0xce, 0x24, 0xd4, 0xf9, 0xc7, 0x48, 0x46, 0x5b")
MAKE_THUNK(libasound, snd_config_add_before, "0x9f, 0xc9, 0x72, 0x59, 0xb1, 0x44, 0x26, 0xe0, 0xfd, 0xb1, 0xce, 0x77, 0x5, 0x86, 0xde, 0xbd, 0x56, 0xd6, 0x81, 0x21, 0x90, 0x42, 0x20, 0xf3, 0xf1, 0xe9, 0xa7, 0xf4, 0xc8, 0xa8, 0xbc, 0x49")
MAKE_THUNK(libasound, snd_config_add_after, "0x8c, 0x5e, 0x9e, 0x38, 0x1f, 0x15, 0x3, 0xde, 0x32, 0x5f, 0x7d, 0x16, 0xac, 0x3b, 0x62, 0x25, 0x67, 0x5d, 0xef, 0xae, 0xe0, 0x47, 0xec, 0x15, 0x41, 0xbe, 0x66, 0xf6, 0xcd, 0xc8, 0x42, 0x24")
MAKE_THUNK(libasound, snd_config_remove, "0x7c, 0x5a, 0x99, 0x7, 0xb2, 0xb2, 0x48, 0x5a, 0xe7, 0x1e, 0x21, 0xb5, 0x6c, 0xed, 0x50, 0xf1, 0xbf, 0xa0, 0xb7, 0x79, 0xd7, 0xf7, 0x18, 0xf8, 0x48, 0xae, 0x1f, 0xdb, 0x1, 0xa0, 0xec, 0x15")
MAKE_THUNK(libasound, snd_config_delete, "0xfd, 0x93, 0x24, 0xeb, 0xaa, 0x45, 0x16, 0xe6, 0x72, 0x64, 0x4b, 0x1c, 0x7e, 0xda, 0xb7, 0x4f, 0x57, 0x91, 0x5, 0xe9, 0xce, 0xae, 0x7e, 0x94, 0x76, 0x6f, 0xf7, 0xd6, 0xb3, 0xa8, 0xdb, 0x42")
MAKE_THUNK(libasound, snd_config_delete_compound_members, "0x4a, 0x4c, 0x9f, 0x8a, 0x55, 0xa0, 0x64, 0xc9, 0xa3, 0xa7, 0x7b, 0x69, 0x4a, 0x1f, 0x2a, 0xef, 0x9e, 0x4a, 0xd0, 0x64, 0x31, 0x71, 0x56, 0x10, 0x90, 0x9c, 0xa3, 0x5b, 0xf2, 0xfe, 0x21, 0x90")
MAKE_THUNK(libasound, snd_config_copy, "0xd6, 0xc, 0x84, 0x47, 0xee, 0xee, 0xed, 0xc9, 0xc8, 0x8a, 0xbb, 0xe7, 0x64, 0x16, 0x27, 0xf9, 0xa4, 0x6b, 0xc4, 0x70, 0x27, 0x5f, 0x4b, 0xf4, 0x24, 0x36, 0xbe, 0xcc, 0x81, 0xfa, 0xba, 0x2c")
MAKE_THUNK(libasound, snd_config_make, "0xfd, 0x61, 0x18, 0x76, 0x84, 0xcd, 0x91, 0x8, 0x3b, 0x42, 0xf2, 0xc, 0x6b, 0xaa, 0x9d, 0xa4, 0x49, 0x69, 0xa4, 0x75, 0x27, 0xdf, 0x57, 0x14, 0xc9, 0xb5, 0x9d, 0x54, 0xd, 0x9a, 0x64, 0xe")
MAKE_THUNK(libasound, snd_config_make_integer, "0x50, 0xb5, 0x6c, 0x80, 0xda, 0x7a, 0xb1, 0xd1, 0xae, 0x6, 0x3b, 0xb0, 0xe0, 0x4e, 0xf9, 0xfb, 0xb0, 0xbf, 0x10, 0x5a, 0x9, 0xfb, 0x25, 0xe0, 0x48, 0xbd, 0xd5, 0x2a, 0x6d, 0xef, 0xec, 0xaa")
MAKE_THUNK(libasound, snd_config_make_integer64, "0x6, 0x89, 0xfe, 0x93, 0xb0, 0x77, 0xb8, 0x9f, 0xb, 0xf3, 0x9d, 0x9b, 0x1e, 0xcf, 0x6b, 0x87, 0x3d, 0xf1, 0x13, 0x43, 0xb0, 0x64, 0x28, 0x64, 0x37, 0x9b, 0x80, 0x56, 0x7c, 0xf3, 0xd7, 0x93")
MAKE_THUNK(libasound, snd_config_make_real, "0xb5, 0xbe, 0xf7, 0x29, 0xd8, 0x85, 0x57, 0xae, 0x73, 0x53, 0x6d, 0x30, 0xaa, 0x16, 0xaa, 0x16, 0x8f, 0x13, 0x4e, 0x8f, 0x90, 0xcf, 0xce, 0x63, 0xdf, 0xe0, 0xa7, 0x28, 0xdc, 0x66, 0xf, 0x4")
MAKE_THUNK(libasound, snd_config_make_string, "0xa9, 0x7f, 0x18, 0xca, 0xec, 0x2c, 0xd0, 0xaf, 0xb3, 0x1e, 0xb3, 0x6c, 0xd8, 0x33, 0x7, 0x1b, 0x41, 0xe0, 0xae, 0x5c, 0xe3, 0x85, 0x39, 0x33, 0xae, 0xbf, 0x10, 0xb6, 0xab, 0xd1, 0x82, 0x61")
MAKE_THUNK(libasound, snd_config_make_pointer, "0x9b, 0x11, 0x45, 0xc1, 0x2c, 0xb0, 0xde, 0xd7, 0x51, 0x84, 0xa, 0xcf, 0xeb, 0xcd, 0x7a, 0x14, 0xf3, 0x44, 0xb5, 0xcf, 0x49, 0x8, 0x28, 0x1, 0x90, 0x6b, 0x14, 0x5c, 0xf5, 0xb3, 0xce, 0x3c")
MAKE_THUNK(libasound, snd_config_make_compound, "0x21, 0x80, 0x75, 0x48, 0x56, 0xba, 0xf2, 0xc2, 0x8e, 0xa9, 0xd1, 0x31, 0x12, 0xdc, 0xa1, 0x9, 0xf1, 0x9f, 0x6f, 0x1, 0x4a, 0x26, 0x8e, 0x8, 0xca, 0xcd, 0x3a, 0x13, 0x4, 0xd4, 0xfd, 0xbb")
MAKE_THUNK(libasound, snd_config_imake_string, "0x3b, 0xca, 0x81, 0x3f, 0xca, 0x9a, 0x7b, 0x61, 0x97, 0xcb, 0x30, 0x9c, 0xfa, 0x64, 0x11, 0x63, 0xfa, 0x5c, 0xe1, 0xac, 0x6a, 0x41, 0xc2, 0x4c, 0x8f, 0x41, 0xd, 0x8a, 0x8f, 0x2b, 0x6f, 0x5e")
MAKE_THUNK(libasound, snd_config_imake_safe_string, "0xe9, 0x5e, 0x49, 0x8e, 0x81, 0xcd, 0xd1, 0x12, 0x11, 0x43, 0x89, 0x39, 0xce, 0xca, 0x5e, 0xe0, 0xad, 0x7e, 0x14, 0x75, 0x68, 0x2b, 0x7d, 0x65, 0xea, 0xd4, 0x4c, 0x5e, 0x12, 0x90, 0xc2, 0xc7")
MAKE_THUNK(libasound, snd_config_imake_pointer, "0x78, 0x2d, 0xb8, 0x6b, 0x85, 0xb2, 0x36, 0x43, 0x1, 0x30, 0x89, 0xf0, 0xfa, 0x67, 0x90, 0xfb, 0x4b, 0xc1, 0xf9, 0x86, 0x37, 0x93, 0x13, 0x72, 0xbc, 0xc5, 0xd, 0x86, 0x49, 0x7d, 0x8c, 0xf4")
MAKE_THUNK(libasound, snd_config_get_type, "0x6c, 0x27, 0xb8, 0x17, 0xc4, 0xf5, 0x52, 0x78, 0x40, 0x8a, 0x9a, 0x10, 0xa2, 0x5c, 0x79, 0x48, 0x8f, 0x12, 0xce, 0x2, 0x5, 0x7c, 0x14, 0xc7, 0xe6, 0x96, 0xcf, 0x57, 0xaf, 0x4e, 0x6f, 0xa8")
MAKE_THUNK(libasound, snd_config_is_array, "0x8a, 0x82, 0xc0, 0x8e, 0x1c, 0x41, 0xa, 0x26, 0xd7, 0xd5, 0x37, 0xbb, 0x8, 0x91, 0xa5, 0xa3, 0xd8, 0xeb, 0x69, 0x29, 0xeb, 0xe0, 0xbc, 0x4b, 0x64, 0xf4, 0x7e, 0xa5, 0xa4, 0x4, 0x1e, 0x22")
MAKE_THUNK(libasound, snd_config_set_id, "0x5b, 0x95, 0x64, 0xf8, 0xff, 0x69, 0xad, 0xb9, 0x1c, 0xd9, 0x11, 0x48, 0x68, 0xeb, 0xbd, 0xe, 0x1a, 0x99, 0x18, 0xb5, 0xb4, 0x2b, 0x60, 0x52, 0xb9, 0x24, 0xdd, 0x6e, 0xb, 0xf, 0x1e, 0x63")
MAKE_THUNK(libasound, snd_config_set_integer, "0x61, 0xd5, 0x2c, 0x5d, 0x11, 0x6f, 0x72, 0x60, 0xa0, 0xe3, 0xe6, 0x11, 0x5e, 0xcd, 0xc4, 0x69, 0x8f, 0xef, 0x31, 0x89, 0xfe, 0xcc, 0xe4, 0x6d, 0xe1, 0x34, 0xbf, 0xa0, 0x11, 0x2b, 0x62, 0x66")
MAKE_THUNK(libasound, snd_config_set_integer64, "0x29, 0x5a, 0xa2, 0xf7, 0x4c, 0x3d, 0x94, 0xfe, 0x8f, 0x7f, 0xfb, 0x2, 0xe9, 0xcb, 0x6, 0xcd, 0x3d, 0x2a, 0xff, 0x1e, 0x2b, 0x90, 0xe0, 0xe, 0x4b, 0x37, 0x41, 0x28, 0x91, 0x31, 0x98, 0x35")
MAKE_THUNK(libasound, snd_config_set_real, "0xec, 0x0, 0x43, 0x80, 0x33, 0xde, 0x3a, 0xc3, 0x6d, 0xfa, 0x7c, 0x10, 0x0, 0xd5, 0xfe, 0xec, 0x4a, 0xb6, 0x69, 0x36, 0xa7, 0x26, 0x8b, 0x8e, 0x6f, 0xb0, 0x9, 0x73, 0x41, 0xd5, 0x33, 0x25")
MAKE_THUNK(libasound, snd_config_set_string, "0xef, 0x3b, 0xa2, 0x52, 0x49, 0x3a, 0x96, 0x4f, 0x7e, 0x21, 0xae, 0xce, 0x5a, 0x40, 0x16, 0x54, 0x60, 0x4a, 0xb0, 0xeb, 0xd1, 0x11, 0x61, 0x7a, 0x8d, 0xf8, 0x36, 0x78, 0x53, 0x1, 0xb4, 0x86")
MAKE_THUNK(libasound, snd_config_set_ascii, "0x49, 0xe9, 0x17, 0x77, 0x5e, 0x7e, 0x39, 0x32, 0x1, 0x3a, 0x1, 0x89, 0xc, 0x70, 0x25, 0x3f, 0x96, 0xce, 0xf5, 0x16, 0x2d, 0x6e, 0xb9, 0x35, 0x4e, 0x52, 0x2d, 0x94, 0xe5, 0x3c, 0x82, 0xb1")
MAKE_THUNK(libasound, snd_config_set_pointer, "0x63, 0x31, 0x9e, 0x29, 0xa5, 0x91, 0xa7, 0x88, 0xc0, 0x39, 0xca, 0xfc, 0x1b, 0x88, 0x79, 0x8a, 0x25, 0x63, 0xd6, 0x29, 0x7c, 0x24, 0x18, 0x64, 0xd3, 0xaf, 0x47, 0xdb, 0x5e, 0x1e, 0x86, 0x8")
MAKE_THUNK(libasound, snd_config_get_id, "0xbe, 0xf3, 0xeb, 0x0, 0x48, 0xdf, 0x32, 0x1b, 0x9b, 0x9, 0x99, 0xe7, 0x2, 0x3e, 0x55, 0x9c, 0x37, 0xfe, 0x36, 0xc9, 0x5e, 0x8e, 0x90, 0xe8, 0xb0, 0xfc, 0x62, 0x3f, 0xd2, 0xa9, 0xad, 0x93")
MAKE_THUNK(libasound, snd_config_get_integer, "0x93, 0xbf, 0x7e, 0x48, 0xd, 0xd5, 0xe1, 0x3d, 0x26, 0xed, 0xcf, 0xb0, 0x68, 0x4, 0x47, 0x94, 0x2e, 0x50, 0x12, 0xfd, 0xf3, 0xef, 0xb5, 0x83, 0xc6, 0x87, 0xe5, 0x87, 0xf, 0x21, 0x20, 0x93")
MAKE_THUNK(libasound, snd_config_get_integer64, "0xce, 0x2, 0xb5, 0x8d, 0xe5, 0x96, 0x5, 0x3c, 0xb0, 0xb2, 0x80, 0x1e, 0xee, 0x42, 0xa0, 0x5e, 0xc7, 0x6d, 0x53, 0x27, 0x8e, 0xdf, 0x73, 0x7c, 0x9d, 0x24, 0x8a, 0x8e, 0x6b, 0xcd, 0x54, 0x53")
MAKE_THUNK(libasound, snd_config_get_real, "0xd0, 0x88, 0x20, 0x64, 0x92, 0x60, 0xac, 0x3f, 0x26, 0x48, 0x28, 0x92, 0x30, 0x7e, 0x89, 0xcc, 0x62, 0xc6, 0x1, 0xaa, 0x8e, 0x56, 0xd9, 0x3f, 0xd5, 0x67, 0x5f, 0x9, 0x43, 0x18, 0xe7, 0xcc")
MAKE_THUNK(libasound, snd_config_get_ireal, "0xab, 0x44, 0x16, 0xb8, 0x19, 0xab, 0x22, 0x77, 0x48, 0x10, 0x20, 0xe4, 0x6, 0x87, 0x40, 0x34, 0x35, 0xb, 0xe9, 0x6b, 0x9c, 0xc5, 0x3a, 0xfd, 0x31, 0xb2, 0xed, 0x56, 0xdf, 0x8c, 0x91, 0x4b")
MAKE_THUNK(libasound, snd_config_get_string, "0x94, 0x5e, 0x24, 0x7b, 0xe8, 0x48, 0x1a, 0xd5, 0xa7, 0xc3, 0xdd, 0x31, 0x95, 0xa, 0x82, 0x80, 0x30, 0xdd, 0xb5, 0x38, 0x62, 0xd5, 0xf0, 0x2d, 0xe1, 0xac, 0x73, 0x9a, 0xcb, 0x41, 0xec, 0xa6")
MAKE_THUNK(libasound, snd_config_get_ascii, "0x86, 0xe8, 0xd7, 0x48, 0x9e, 0xc9, 0x1a, 0x1c, 0xd5, 0x77, 0x2c, 0x6, 0x4f, 0x68, 0x89, 0xae, 0xf7, 0x8, 0x59, 0xc2, 0xdd, 0xe3, 0xb0, 0x96, 0xb7, 0x9, 0xae, 0x45, 0x39, 0x2e, 0xaf, 0x51")
MAKE_THUNK(libasound, snd_config_get_pointer, "0x31, 0xcd, 0x1f, 0x19, 0xd9, 0x44, 0x9d, 0xf5, 0xca, 0x3d, 0xa4, 0x99, 0x6f, 0x99, 0xa0, 0x88, 0xdf, 0xb6, 0x70, 0x7d, 0x15, 0xfd, 0xca, 0x94, 0x6, 0xb8, 0xcb, 0x4c, 0x2e, 0xa4, 0x55, 0xd7")
MAKE_THUNK(libasound, snd_config_test_id, "0x1e, 0xfe, 0x35, 0x88, 0xda, 0x21, 0xc0, 0xc7, 0xc8, 0x2c, 0xab, 0xac, 0x4d, 0x41, 0x63, 0x1d, 0x15, 0x75, 0x13, 0xa1, 0x21, 0x17, 0x16, 0xee, 0xd, 0x94, 0x1e, 0x83, 0xad, 0x5b, 0xd9, 0xa1")
MAKE_THUNK(libasound, snd_config_iterator_first, "0x7d, 0xf3, 0xa9, 0x96, 0xdf, 0xea, 0xe9, 0x19, 0x3c, 0x56, 0xf4, 0x6, 0x6f, 0x4e, 0xb5, 0xfd, 0xd1, 0x85, 0x10, 0x44, 0xa0, 0xe3, 0x3a, 0xb6, 0xdd, 0x78, 0xd, 0x49, 0x39, 0xdb, 0xc3, 0x1b")
MAKE_THUNK(libasound, snd_config_iterator_end, "0x5f, 0x6a, 0x69, 0x62, 0x6f, 0x3a, 0xcb, 0x46, 0xc6, 0xa9, 0x93, 0x73, 0x5e, 0xba, 0x83, 0xa0, 0x3, 0x8d, 0x10, 0xe3, 0x8e, 0x8, 0x63, 0x12, 0x35, 0xa5, 0x36, 0x72, 0x1a, 0x4c, 0xb9, 0xd2")
MAKE_THUNK(libasound, snd_config_get_bool_ascii, "0xe9, 0x2b, 0x13, 0x7f, 0x29, 0xa2, 0xd7, 0xc3, 0x73, 0xa5, 0xa, 0x64, 0xa4, 0x1b, 0xd3, 0x7, 0x56, 0xde, 0x7e, 0x3b, 0x95, 0xfb, 0xde, 0xf, 0x88, 0x2e, 0xd5, 0x6, 0xd0, 0xcb, 0x7f, 0x46")
MAKE_THUNK(libasound, snd_config_get_bool, "0xf5, 0x18, 0x4, 0x96, 0x26, 0xd4, 0x19, 0x27, 0x94, 0x90, 0x64, 0x8, 0xa9, 0xd9, 0x4c, 0xd9, 0x74, 0xf1, 0x65, 0xde, 0xc5, 0xe1, 0xa, 0x50, 0x16, 0x46, 0xe5, 0x71, 0xdc, 0x0, 0x81, 0xcf")
MAKE_THUNK(libasound, snd_config_get_ctl_iface_ascii, "0xfd, 0xbc, 0x78, 0x8c, 0x99, 0x7, 0xe, 0x87, 0x2c, 0x4, 0xba, 0x1b, 0xb5, 0x91, 0x44, 0x13, 0x5b, 0xef, 0xb0, 0xb4, 0x2f, 0x95, 0x9f, 0x6, 0x50, 0x7f, 0x95, 0x89, 0xa5, 0xc5, 0xa5, 0xa8")
MAKE_THUNK(libasound, snd_config_get_ctl_iface, "0x85, 0xa1, 0x17, 0x4a, 0x7a, 0xe9, 0xb2, 0x9a, 0x93, 0xa5, 0xd9, 0x4b, 0x17, 0xe3, 0x43, 0x80, 0x28, 0x4b, 0xcc, 0x26, 0x34, 0x77, 0x5b, 0xb2, 0xe8, 0xc5, 0x55, 0xa, 0x92, 0xf9, 0x5f, 0x1e")
MAKE_THUNK(libasound, snd_names_list, "0xf7, 0xbd, 0x9d, 0x54, 0x28, 0xca, 0xd, 0x78, 0x87, 0xd1, 0x6a, 0xd4, 0x4e, 0xef, 0xa6, 0x46, 0xb8, 0x32, 0x37, 0x7d, 0x5d, 0x43, 0x94, 0x7c, 0x87, 0x43, 0xd1, 0xd8, 0x6d, 0xdc, 0x49, 0xdf")
MAKE_THUNK(libasound, snd_names_list_free, "0x86, 0x9f, 0x69, 0x50, 0xe2, 0x30, 0x47, 0xc9, 0x6b, 0xaf, 0x28, 0xf8, 0xf6, 0x53, 0x5c, 0x66, 0x93, 0x52, 0x5, 0x23, 0xba, 0xf5, 0xdf, 0x36, 0x5d, 0xf6, 0x79, 0x44, 0x49, 0xab, 0x2, 0x9a")
MAKE_THUNK(libasound, snd_pcm_open, "0xa8, 0x21, 0x56, 0x22, 0xef, 0x66, 0x5f, 0xe5, 0xe5, 0x61, 0x83, 0x99, 0xdb, 0x7, 0x5, 0xc5, 0xbc, 0x7e, 0x6a, 0x3f, 0xf8, 0xb5, 0x7f, 0x35, 0x50, 0x64, 0x1d, 0x86, 0x3e, 0xaf, 0x58, 0xc6")
MAKE_THUNK(libasound, snd_pcm_open_lconf, "0x57, 0xe0, 0xe1, 0x73, 0x67, 0x90, 0xcd, 0xa4, 0x2f, 0x38, 0x9a, 0x47, 0xc1, 0x5e, 0xf6, 0xa7, 0x81, 0xf2, 0xa0, 0xa2, 0x11, 0x8a, 0x74, 0x60, 0x34, 0xa4, 0xed, 0x15, 0xa, 0x62, 0xef, 0x89")
MAKE_THUNK(libasound, snd_pcm_open_fallback, "0x4a, 0xbb, 0xdb, 0x5f, 0xec, 0x1e, 0xd4, 0x58, 0x1c, 0x6c, 0x79, 0xbf, 0x20, 0x43, 0x99, 0x4b, 0x96, 0xf6, 0x19, 0xf0, 0x7, 0x8b, 0x4, 0x4b, 0x80, 0xf1, 0xa8, 0x8f, 0xa5, 0xec, 0xfe, 0x3a")
MAKE_THUNK(libasound, snd_pcm_close, "0x34, 0x43, 0x63, 0x1b, 0x58, 0x33, 0xa3, 0xfa, 0xfb, 0x89, 0xfa, 0x24, 0x51, 0xa3, 0xc1, 0x78, 0xaa, 0xc9, 0x6f, 0xb3, 0x85, 0x4e, 0xef, 0xc2, 0x27, 0x6d, 0x11, 0x5, 0xc, 0x54, 0x46, 0xf2")
MAKE_THUNK(libasound, snd_pcm_name, "0x7f, 0x36, 0x47, 0x56, 0x76, 0xcd, 0xee, 0xa0, 0xad, 0x67, 0xaf, 0xdb, 0x73, 0x86, 0xb0, 0x6a, 0xe2, 0x1a, 0x4b, 0xa2, 0x2c, 0x33, 0x5c, 0x83, 0x3b, 0x24, 0x2f, 0xc5, 0x6a, 0x4b, 0x1e, 0xf6")
MAKE_THUNK(libasound, snd_pcm_type, "0x51, 0xd8, 0x48, 0x59, 0x6b, 0x42, 0x4a, 0xb7, 0xb8, 0x3c, 0xd1, 0xb, 0xa, 0xbe, 0xbe, 0x38, 0x82, 0x9, 0xa1, 0x4b, 0xe3, 0x9d, 0xf2, 0x8e, 0xc5, 0xce, 0xd4, 0xd8, 0x47, 0xf5, 0x41, 0x7c")
MAKE_THUNK(libasound, snd_pcm_stream, "0xb4, 0xcb, 0xfc, 0x42, 0xcd, 0x56, 0xc7, 0xc0, 0x8, 0x15, 0xbf, 0xbb, 0xef, 0x9b, 0xc, 0x40, 0x36, 0x8d, 0x4b, 0x6e, 0x9a, 0x15, 0x14, 0x3e, 0xdc, 0x91, 0xe1, 0x69, 0x70, 0x56, 0x61, 0x61")
MAKE_THUNK(libasound, snd_pcm_poll_descriptors_count, "0x5, 0xc, 0x19, 0xe4, 0xb2, 0x5a, 0x77, 0x4, 0x12, 0x6e, 0x35, 0x20, 0xab, 0x66, 0xf4, 0xec, 0x2b, 0x3b, 0xe5, 0x94, 0x2a, 0x5, 0xa5, 0xc6, 0xa7, 0x63, 0xa9, 0x41, 0x5e, 0x19, 0xa6, 0x9f")
MAKE_THUNK(libasound, snd_pcm_poll_descriptors, "0x67, 0x67, 0xf4, 0x85, 0x66, 0x8b, 0x9f, 0x57, 0x49, 0xc0, 0x11, 0x33, 0xd2, 0x5, 0x81, 0xd9, 0x5a, 0x37, 0x1b, 0x21, 0xc5, 0x8f, 0x91, 0xa0, 0x34, 0x80, 0xdd, 0x5e, 0xb0, 0xc5, 0xed, 0x95")
MAKE_THUNK(libasound, snd_pcm_poll_descriptors_revents, "0xe8, 0x3b, 0xc2, 0xcd, 0x2d, 0xcd, 0xe0, 0xcf, 0xe2, 0xd5, 0x46, 0x3, 0x7a, 0xb8, 0x63, 0x0, 0xcc, 0xbc, 0xc6, 0x6f, 0xf9, 0x31, 0x5a, 0x33, 0x92, 0x36, 0x1, 0xe1, 0x20, 0x5f, 0xed, 0x92")
MAKE_THUNK(libasound, snd_pcm_nonblock, "0x80, 0x80, 0x86, 0x23, 0x54, 0xc9, 0xc8, 0xea, 0x35, 0x92, 0xfb, 0xc8, 0x68, 0x40, 0x2f, 0x6, 0xbb, 0xf9, 0xd2, 0x8e, 0x9, 0x82, 0x92, 0x2f, 0x69, 0xa, 0xf9, 0x2d, 0xb6, 0xae, 0xc3, 0x6f")
MAKE_THUNK(libasound, snd_async_handler_get_pcm, "0x9b, 0xc1, 0xb2, 0xdd, 0xb3, 0x88, 0x87, 0x1f, 0x2a, 0xfc, 0x9a, 0xf4, 0x25, 0x3, 0x7e, 0x7a, 0x53, 0xeb, 0x99, 0x22, 0xbd, 0x84, 0x20, 0x87, 0xcb, 0xff, 0x1e, 0x4, 0x83, 0x32, 0x86, 0xfc")
MAKE_THUNK(libasound, snd_pcm_info, "0xc5, 0xfd, 0xf2, 0x49, 0x70, 0x91, 0x7e, 0xcc, 0xd, 0x42, 0xd, 0x20, 0xa, 0x63, 0x11, 0x51, 0x8e, 0x95, 0x5e, 0x13, 0x9f, 0x3f, 0x6a, 0xe7, 0xd3, 0x55, 0x22, 0x76, 0xa7, 0xe4, 0xb5, 0x62")
MAKE_THUNK(libasound, snd_pcm_hw_params_current, "0x6, 0xa9, 0xae, 0x44, 0x35, 0xd5, 0x15, 0x24, 0xff, 0x75, 0x1e, 0x1e, 0x12, 0xa3, 0x25, 0x24, 0xdb, 0x8b, 0xcd, 0x72, 0x15, 0x50, 0xf5, 0xff, 0xd4, 0x85, 0xd8, 0x61, 0xec, 0x7, 0xb0, 0x9c")
MAKE_THUNK(libasound, snd_pcm_hw_params, "0x1b, 0x10, 0x30, 0xa8, 0xd8, 0xd2, 0xc2, 0x41, 0x45, 0xc2, 0xb0, 0xee, 0x96, 0xa2, 0x97, 0x99, 0xbe, 0xa1, 0xfe, 0x87, 0xc, 0x50, 0x29, 0x37, 0xd7, 0xd0, 0x74, 0xc1, 0x67, 0x2f, 0x5, 0x21")
MAKE_THUNK(libasound, snd_pcm_hw_free, "0xb8, 0xdb, 0x80, 0x10, 0x3f, 0xad, 0x9b, 0xc0, 0x3c, 0x10, 0x4f, 0x91, 0x5b, 0x91, 0xe6, 0x9e, 0x9a, 0x81, 0x4e, 0xd8, 0xf5, 0x18, 0xc2, 0x62, 0x23, 0x9b, 0x9f, 0xe6, 0x1a, 0xc9, 0xb2, 0x62")
MAKE_THUNK(libasound, snd_pcm_sw_params_current, "0xf4, 0xe6, 0xcc, 0xdc, 0x7a, 0x2, 0xab, 0x1b, 0xaf, 0x7c, 0xf5, 0x62, 0x19, 0xc, 0x42, 0x88, 0x1d, 0xab, 0x36, 0xc1, 0xdb, 0x5f, 0xaa, 0xb1, 0x4c, 0xd9, 0x8b, 0xb0, 0xd, 0x6e, 0xab, 0x67")
MAKE_THUNK(libasound, snd_pcm_sw_params, "0x7f, 0x19, 0xa1, 0x3a, 0x8a, 0xa0, 0xd8, 0xf1, 0xd7, 0xc2, 0x42, 0x2d, 0x92, 0x7a, 0x26, 0x3b, 0x9e, 0xd3, 0xb9, 0x5, 0xd7, 0x5b, 0x33, 0xd9, 0x98, 0x81, 0x2a, 0x2e, 0xc5, 0xc0, 0x2f, 0x7c")
MAKE_THUNK(libasound, snd_pcm_prepare, "0xcd, 0x49, 0x22, 0x28, 0x4c, 0xac, 0xbb, 0x87, 0x50, 0x20, 0xef, 0xfb, 0x47, 0x98, 0xf5, 0x31, 0x32, 0x92, 0x86, 0xa3, 0xf1, 0xe2, 0x76, 0xb5, 0x12, 0x3a, 0xc9, 0x68, 0xc3, 0xc2, 0x1f, 0xf1")
MAKE_THUNK(libasound, snd_pcm_reset, "0x95, 0xee, 0x5, 0xf7, 0x66, 0x85, 0x83, 0x6e, 0xc8, 0xf9, 0x41, 0x57, 0x4a, 0xa1, 0xf4, 0xa9, 0xa1, 0x95, 0x82, 0x51, 0xb9, 0x22, 0x1f, 0x41, 0xb1, 0x64, 0x6a, 0xef, 0xf9, 0x7a, 0x13, 0xd")
MAKE_THUNK(libasound, snd_pcm_status, "0xb4, 0x22, 0xd8, 0xf2, 0xc0, 0x7c, 0xf3, 0xa0, 0x14, 0xa9, 0x80, 0x71, 0x5, 0xb7, 0xa3, 0x2a, 0x9b, 0x21, 0xc5, 0xa5, 0x29, 0xea, 0x4f, 0x7a, 0xd0, 0x5, 0xd1, 0xce, 0x54, 0xee, 0xc2, 0xef")
MAKE_THUNK(libasound, snd_pcm_start, "0xf6, 0xdc, 0xc0, 0x2e, 0xe6, 0x6a, 0x48, 0x17, 0xe1, 0x24, 0xc, 0xa3, 0x8d, 0x94, 0x8f, 0x61, 0x25, 0x79, 0xc3, 0xc4, 0x6, 0x9f, 0x41, 0x52, 0xbf, 0xc8, 0x2d, 0xd6, 0x55, 0x8e, 0xef, 0x2e")
MAKE_THUNK(libasound, snd_pcm_drop, "0xe9, 0x6f, 0x4d, 0xcc, 0x67, 0xd9, 0xc2, 0x58, 0x91, 0x96, 0xd5, 0xd, 0x60, 0xf0, 0xc6, 0xd1, 0xd6, 0x2, 0x6c, 0x57, 0xa1, 0x37, 0x19, 0x84, 0xa1, 0xe6, 0xc8, 0x35, 0xda, 0xaf, 0xeb, 0x7f")
MAKE_THUNK(libasound, snd_pcm_drain, "0xf6, 0xb3, 0x76, 0x37, 0xc0, 0x4e, 0x5f, 0x94, 0x5d, 0xf9, 0x65, 0xad, 0xc0, 0x93, 0x42, 0xe7, 0xa4, 0x3c, 0x36, 0x2e, 0x30, 0x63, 0xed, 0x62, 0x53, 0x2a, 0xdd, 0xd7, 0xd6, 0x2a, 0xf7, 0x19")
MAKE_THUNK(libasound, snd_pcm_pause, "0xd7, 0x45, 0x7c, 0xad, 0x19, 0x60, 0x7, 0x31, 0x6, 0x31, 0xfc, 0xf1, 0xae, 0x9b, 0x4d, 0x27, 0x29, 0xca, 0xae, 0x24, 0xee, 0x1c, 0xed, 0xe0, 0x68, 0xf3, 0xc3, 0xbd, 0x2e, 0x20, 0x63, 0x17")
MAKE_THUNK(libasound, snd_pcm_state, "0x29, 0x4c, 0x98, 0x78, 0xd6, 0x75, 0xbb, 0x49, 0xb3, 0x93, 0xa4, 0xb6, 0xf2, 0xed, 0x1e, 0xcd, 0x91, 0x0, 0xe9, 0x66, 0x9e, 0xbe, 0x4e, 0x84, 0xe7, 0xa7, 0xd, 0x76, 0xf6, 0xfc, 0x3d, 0xb")
MAKE_THUNK(libasound, snd_pcm_hwsync, "0x48, 0xb6, 0xcc, 0x45, 0x31, 0xa4, 0xf3, 0xb9, 0x77, 0xc7, 0x48, 0x0, 0x15, 0x10, 0x8a, 0x8a, 0x79, 0xc2, 0x93, 0x5b, 0xc1, 0x8, 0x1d, 0xe3, 0xd2, 0x61, 0x1c, 0xbd, 0x22, 0x4, 0xa9, 0x9d")
MAKE_THUNK(libasound, snd_pcm_delay, "0x98, 0x3e, 0x1f, 0x57, 0xae, 0x1a, 0x8b, 0xbb, 0x49, 0xbf, 0xaf, 0xc5, 0x29, 0x2e, 0xc0, 0x2b, 0x1b, 0xc7, 0xd, 0xa4, 0xab, 0x8a, 0x9d, 0xcf, 0x5d, 0x71, 0x4f, 0x83, 0xe8, 0x27, 0x88, 0x15")
MAKE_THUNK(libasound, snd_pcm_resume, "0x88, 0xbc, 0xc4, 0x89, 0x93, 0x1b, 0x4a, 0xaf, 0x55, 0xb6, 0xf1, 0x97, 0x86, 0x43, 0x8b, 0x9d, 0xf6, 0x15, 0x56, 0xe3, 0x9a, 0xd8, 0x29, 0xf6, 0xb8, 0xf1, 0x1b, 0x62, 0xdf, 0xad, 0xa4, 0xdf")
MAKE_THUNK(libasound, snd_pcm_htimestamp, "0xcc, 0x76, 0x54, 0xa9, 0x5e, 0x27, 0x44, 0xd3, 0xc6, 0xdc, 0xec, 0x8f, 0xb2, 0xfe, 0x6d, 0x4f, 0x8d, 0xc8, 0xc9, 0x6f, 0x88, 0xa7, 0xc6, 0xa7, 0xfc, 0x37, 0xe4, 0x2, 0x28, 0xef, 0xaf, 0x24")
MAKE_THUNK(libasound, snd_pcm_avail, "0x25, 0x5a, 0xe2, 0x2c, 0xfb, 0x41, 0x6a, 0xe, 0x41, 0xd, 0xce, 0x80, 0x53, 0xdc, 0xc6, 0xc9, 0x8d, 0xdc, 0x95, 0xbb, 0x94, 0x3, 0xd4, 0xd5, 0x1d, 0x27, 0x8a, 0xd4, 0xb3, 0x4f, 0x2c, 0xaf")
MAKE_THUNK(libasound, snd_pcm_avail_update, "0xb3, 0xb5, 0xad, 0x35, 0xda, 0x74, 0xb9, 0xea, 0xba, 0xb9, 0xac, 0xbe, 0x5a, 0x28, 0x12, 0x9a, 0xda, 0xf1, 0xc, 0xa5, 0xe8, 0xd7, 0xb3, 0xb, 0x22, 0x79, 0xfb, 0xe, 0x7e, 0xe4, 0xe5, 0xa6")
MAKE_THUNK(libasound, snd_pcm_avail_delay, "0x46, 0xbb, 0x94, 0xbc, 0x80, 0xa1, 0x41, 0x23, 0xfc, 0x83, 0x8d, 0x8a, 0x47, 0xa4, 0xde, 0xb7, 0x6, 0x91, 0x73, 0xc8, 0x42, 0x1b, 0x69, 0x49, 0xb2, 0xab, 0xc7, 0xf8, 0x43, 0x79, 0xd7, 0x7")
MAKE_THUNK(libasound, snd_pcm_rewindable, "0x28, 0xd3, 0xf6, 0x13, 0x88, 0xba, 0xf, 0xc8, 0x1f, 0x3a, 0x91, 0x38, 0xc9, 0xf2, 0x1e, 0x5a, 0xaa, 0x1, 0x4, 0x64, 0x3c, 0xc6, 0x8, 0x4d, 0x2b, 0x6c, 0x21, 0x88, 0x83, 0xe, 0x60, 0x26")
MAKE_THUNK(libasound, snd_pcm_rewind, "0xbf, 0xc6, 0x7e, 0x89, 0xa6, 0xfa, 0xf6, 0x1d, 0x6c, 0x88, 0x73, 0x3d, 0xdf, 0x28, 0xb6, 0x11, 0xc6, 0x17, 0xe4, 0x62, 0x5c, 0x1, 0x7b, 0x4f, 0xde, 0xf0, 0x85, 0x45, 0x15, 0xb0, 0xe4, 0x1d")
MAKE_THUNK(libasound, snd_pcm_forwardable, "0x37, 0x84, 0x7a, 0x7, 0xae, 0x97, 0x14, 0x7e, 0xd5, 0xfc, 0x4b, 0x57, 0x6, 0xe, 0x70, 0x3a, 0x15, 0xb0, 0x28, 0x94, 0xc9, 0x7f, 0xf9, 0xaa, 0x57, 0x6f, 0xf7, 0xc7, 0x22, 0x8f, 0x71, 0xba")
MAKE_THUNK(libasound, snd_pcm_forward, "0x4b, 0x6e, 0x2e, 0x77, 0x56, 0x88, 0xca, 0x26, 0x20, 0x21, 0xcb, 0x6e, 0xc9, 0x64, 0x73, 0x27, 0x24, 0x22, 0x40, 0x75, 0x23, 0x7e, 0xae, 0x44, 0xe, 0xac, 0x30, 0xc3, 0xdf, 0x11, 0x3f, 0xd4")
MAKE_THUNK(libasound, snd_pcm_writei, "0x47, 0x77, 0xac, 0xa0, 0x99, 0xe2, 0x76, 0x6b, 0x74, 0x4e, 0x61, 0x14, 0xa4, 0x3b, 0x26, 0xd2, 0x50, 0x40, 0x5c, 0x26, 0xb4, 0x70, 0xce, 0xcf, 0xd, 0x42, 0x7e, 0x77, 0x9e, 0x85, 0x86, 0x33")
MAKE_THUNK(libasound, snd_pcm_readi, "0x44, 0xcc, 0xfa, 0x9, 0x65, 0x94, 0xef, 0x2a, 0x31, 0xde, 0x64, 0xe1, 0x28, 0x44, 0xbd, 0x84, 0x7a, 0x1f, 0x13, 0xb9, 0x56, 0x1e, 0x6d, 0xe5, 0x1f, 0x95, 0x4e, 0x35, 0xe0, 0xf9, 0x95, 0xdd")
MAKE_THUNK(libasound, snd_pcm_writen, "0x9d, 0x4f, 0xc6, 0x90, 0xab, 0x88, 0x21, 0xfe, 0xd5, 0x6a, 0x6d, 0x81, 0x23, 0x0, 0x6d, 0xd3, 0x94, 0xcd, 0xb5, 0xd1, 0xaa, 0x43, 0x30, 0x86, 0x32, 0xe, 0x94, 0x3d, 0x8b, 0x41, 0x1f, 0xf2")
MAKE_THUNK(libasound, snd_pcm_readn, "0xc0, 0x51, 0x7b, 0xd1, 0x17, 0xba, 0x19, 0x9e, 0x22, 0xe0, 0xa3, 0xf6, 0xae, 0xab, 0x96, 0x62, 0x55, 0xb7, 0x5e, 0x49, 0x65, 0xef, 0x76, 0x4f, 0x6b, 0xf2, 0xce, 0x8c, 0x9, 0xb, 0x13, 0x48")
MAKE_THUNK(libasound, snd_pcm_wait, "0x92, 0xd9, 0xbd, 0xff, 0xbe, 0x98, 0x49, 0x8, 0x4e, 0xc3, 0x9b, 0x80, 0xb8, 0x6f, 0x7d, 0x4a, 0x43, 0xea, 0xed, 0x87, 0x52, 0xcc, 0x53, 0xc6, 0xc5, 0x73, 0xee, 0xab, 0xd4, 0x82, 0x12, 0x23")
MAKE_THUNK(libasound, snd_pcm_link, "0x82, 0xf7, 0xf4, 0x92, 0x4c, 0xcc, 0x29, 0x7f, 0xab, 0x60, 0xb9, 0x6, 0x7d, 0xa0, 0x5, 0x47, 0xa1, 0x91, 0xf9, 0x25, 0x58, 0xb4, 0x9d, 0x55, 0x5e, 0x99, 0xec, 0xc9, 0xd0, 0x24, 0x10, 0xe4")
MAKE_THUNK(libasound, snd_pcm_unlink, "0x65, 0x71, 0xfa, 0x3f, 0xe0, 0xe9, 0x8c, 0xc9, 0xc7, 0xbd, 0xfb, 0x69, 0x44, 0x6, 0xe8, 0xb9, 0x8f, 0xcd, 0x42, 0xa7, 0xcd, 0x91, 0xe9, 0x48, 0xc1, 0xd1, 0x98, 0x18, 0x51, 0x4c, 0x65, 0xf1")
MAKE_THUNK(libasound, snd_pcm_query_chmaps, "0xce, 0xd4, 0x8b, 0xc5, 0x64, 0xad, 0x4, 0x88, 0xdc, 0x93, 0x8a, 0x4f, 0x36, 0xd1, 0xc5, 0x18, 0x62, 0x6a, 0x3, 0x66, 0xa4, 0x3d, 0xe1, 0x65, 0x5f, 0x74, 0x36, 0x1c, 0xf2, 0x55, 0x2b, 0xe7")
MAKE_THUNK(libasound, snd_pcm_query_chmaps_from_hw, "0x1b, 0x6f, 0x87, 0x43, 0x2c, 0xd7, 0x26, 0x2d, 0xcc, 0xb7, 0x59, 0x56, 0x1f, 0xa0, 0xe9, 0xa8, 0x3e, 0xdc, 0x80, 0x3b, 0x2, 0xc5, 0xbd, 0x97, 0x7b, 0xf6, 0x25, 0xe5, 0x3d, 0xac, 0xac, 0x51")
MAKE_THUNK(libasound, snd_pcm_free_chmaps, "0x45, 0x26, 0xa5, 0xb5, 0xff, 0x2c, 0x37, 0x4c, 0x5c, 0x1f, 0xc0, 0x62, 0xba, 0xd, 0x7, 0xfe, 0xbe, 0xfd, 0x7c, 0x42, 0xdc, 0xf6, 0x9a, 0x5, 0x30, 0xc9, 0x59, 0x37, 0x66, 0x3e, 0x7, 0x9f")
MAKE_THUNK(libasound, snd_pcm_get_chmap, "0xfe, 0xc3, 0x7e, 0xf9, 0xac, 0x65, 0x66, 0x65, 0xf4, 0x77, 0x50, 0xc9, 0xdd, 0x83, 0xfa, 0x25, 0x49, 0x9c, 0x58, 0x8d, 0x96, 0x89, 0xd8, 0x1d, 0x9b, 0x60, 0x41, 0x7c, 0xe3, 0xe5, 0xa3, 0xfb")
MAKE_THUNK(libasound, snd_pcm_set_chmap, "0x53, 0x19, 0x2b, 0xec, 0xe0, 0xdd, 0x89, 0xc6, 0x3f, 0xf3, 0xe9, 0x97, 0xa1, 0x56, 0xe3, 0x84, 0x84, 0x9a, 0xcf, 0x2d, 0x9a, 0x3a, 0x5c, 0xaf, 0x7a, 0x52, 0x93, 0xb6, 0xa9, 0xd9, 0xc0, 0xec")
MAKE_THUNK(libasound, snd_pcm_chmap_type_name, "0xc6, 0xf, 0x48, 0x1e, 0xaa, 0x63, 0x38, 0x62, 0xd4, 0xea, 0xe8, 0x7b, 0xfe, 0x79, 0xc3, 0x8, 0x66, 0x67, 0x14, 0xa9, 0x9c, 0xf2, 0xdf, 0xbb, 0xaa, 0x5d, 0x44, 0xb7, 0xa3, 0x73, 0x26, 0x8f")
MAKE_THUNK(libasound, snd_pcm_chmap_name, "0xdc, 0x4f, 0x2, 0xfb, 0x7d, 0xbb, 0x72, 0xd6, 0x36, 0x14, 0x60, 0x6b, 0xc0, 0x7d, 0xd, 0xda, 0xcf, 0x30, 0x77, 0x29, 0x4c, 0xd9, 0x46, 0xa0, 0x6a, 0xa1, 0x75, 0x77, 0xbe, 0x36, 0x3b, 0x48")
MAKE_THUNK(libasound, snd_pcm_chmap_long_name, "0xdb, 0x2, 0x64, 0xed, 0xff, 0x64, 0x63, 0x66, 0xe1, 0x5, 0x71, 0xb6, 0x1e, 0xca, 0x80, 0xd9, 0x70, 0x9, 0x54, 0xab, 0x6d, 0xc8, 0x34, 0x9c, 0x38, 0x8e, 0xa, 0x76, 0x66, 0x3f, 0xa0, 0x3b")
MAKE_THUNK(libasound, snd_pcm_chmap_print, "0x7d, 0xb8, 0xb8, 0x7c, 0x26, 0xb4, 0x89, 0xb8, 0x9c, 0x35, 0x81, 0x7b, 0xef, 0x24, 0xc, 0x71, 0xe8, 0x45, 0x23, 0xe1, 0xf3, 0x5a, 0xe3, 0x19, 0x28, 0x94, 0x60, 0xae, 0xa8, 0xfb, 0x85, 0xd2")
MAKE_THUNK(libasound, snd_pcm_chmap_from_string, "0x18, 0x9f, 0xb0, 0xd8, 0x6f, 0x30, 0x9c, 0x1f, 0xd2, 0x4f, 0x28, 0x71, 0x30, 0x30, 0x58, 0xad, 0x91, 0xa7, 0x38, 0xbd, 0x92, 0xa5, 0x52, 0x21, 0x9, 0x84, 0xc9, 0x82, 0x9b, 0x51, 0xba, 0x34")
MAKE_THUNK(libasound, snd_pcm_chmap_parse_string, "0x52, 0x1d, 0xc4, 0x69, 0x7e, 0x37, 0x7, 0x2e, 0x99, 0xbb, 0x55, 0xac, 0xc8, 0xf0, 0xea, 0xe4, 0xf7, 0x2a, 0xe7, 0xad, 0xa9, 0xd4, 0x1d, 0x95, 0x35, 0xa6, 0x39, 0x3a, 0x80, 0x81, 0x7a, 0x84")
MAKE_THUNK(libasound, snd_pcm_recover, "0xc4, 0xc0, 0xbd, 0x8e, 0xd3, 0x7c, 0xf3, 0x88, 0xda, 0x18, 0x1e, 0x7c, 0xbf, 0x62, 0x2b, 0xf1, 0x1c, 0xe5, 0x17, 0x2c, 0x6b, 0xb4, 0xf, 0x11, 0x47, 0x2d, 0x6b, 0xf0, 0x33, 0x2a, 0xd5, 0x8b")
MAKE_THUNK(libasound, snd_pcm_set_params, "0xcb, 0xb5, 0xc6, 0x31, 0xd5, 0x32, 0x5, 0x3b, 0x91, 0xf, 0x52, 0x59, 0x37, 0xf, 0x8b, 0x7, 0x50, 0x9c, 0xd8, 0xfe, 0xd9, 0xb5, 0xd0, 0xd8, 0xf0, 0xaa, 0xa0, 0x40, 0x61, 0xb2, 0x4b, 0x34")
MAKE_THUNK(libasound, snd_pcm_get_params, "0x67, 0x0, 0x40, 0x80, 0x76, 0x4e, 0x92, 0x33, 0x82, 0x6b, 0xf1, 0x88, 0xa1, 0x29, 0x36, 0xba, 0x58, 0x76, 0x4f, 0x94, 0xce, 0x28, 0xe1, 0x23, 0xf1, 0x4e, 0x8d, 0x61, 0x3a, 0xdc, 0x8f, 0xc2")
MAKE_THUNK(libasound, snd_pcm_info_sizeof, "0x9, 0xd7, 0xaa, 0xd2, 0x5a, 0x76, 0x7e, 0xec, 0xd6, 0x1, 0x97, 0x7c, 0x96, 0x64, 0xbb, 0x7e, 0x21, 0x58, 0x63, 0xbb, 0x3c, 0x9a, 0xa9, 0x41, 0xa6, 0x40, 0x6f, 0xe9, 0x47, 0xd7, 0x5a, 0x0")
MAKE_THUNK(libasound, snd_pcm_info_malloc, "0x7c, 0x66, 0xe4, 0xd0, 0xae, 0x4e, 0xf3, 0x6c, 0x10, 0xa6, 0x14, 0xb, 0x12, 0xcc, 0xfe, 0xd6, 0x78, 0x5f, 0xeb, 0x63, 0x21, 0xeb, 0x8e, 0x3b, 0x60, 0x84, 0x22, 0x17, 0xb, 0x93, 0x8a, 0x7e")
MAKE_THUNK(libasound, snd_pcm_info_free, "0xab, 0x18, 0xe4, 0xe8, 0x32, 0x7b, 0x6f, 0xc4, 0x11, 0x7a, 0x12, 0x5f, 0x6b, 0x80, 0x7e, 0xf4, 0xfb, 0xef, 0xac, 0xc7, 0x91, 0x3c, 0xa1, 0xa5, 0xcd, 0x52, 0xe8, 0x74, 0x94, 0x26, 0x42, 0x6c")
MAKE_THUNK(libasound, snd_pcm_info_copy, "0xef, 0x45, 0xea, 0x3f, 0x39, 0x31, 0x80, 0x43, 0x42, 0x91, 0x3c, 0x8e, 0xa7, 0x92, 0x83, 0x93, 0x57, 0xc1, 0x12, 0x10, 0x60, 0x91, 0xbc, 0x96, 0xc5, 0x33, 0xbd, 0x32, 0x9e, 0x66, 0x53, 0x4c")
MAKE_THUNK(libasound, snd_pcm_info_get_device, "0x83, 0xfc, 0x19, 0xfa, 0xa0, 0xb3, 0x82, 0x57, 0x8a, 0xb1, 0x2b, 0x98, 0x59, 0x4b, 0xd0, 0xa9, 0x7c, 0x88, 0x35, 0x51, 0x19, 0x4f, 0xba, 0xb7, 0x21, 0xea, 0x3, 0xb6, 0xf3, 0xfa, 0xda, 0xe6")
MAKE_THUNK(libasound, snd_pcm_info_get_subdevice, "0x10, 0xfb, 0x58, 0x5, 0x15, 0xfd, 0x9c, 0x58, 0xf3, 0x37, 0xfa, 0xcd, 0x77, 0xc8, 0x5c, 0x61, 0x77, 0x66, 0x56, 0x39, 0x0, 0x69, 0x2a, 0x3b, 0x20, 0x9e, 0xb9, 0xd3, 0x24, 0x3f, 0x31, 0x8a")
MAKE_THUNK(libasound, snd_pcm_info_get_stream, "0x1b, 0x3c, 0x49, 0x62, 0x7f, 0x38, 0x8e, 0xd4, 0xd5, 0xe4, 0x71, 0xa, 0x15, 0xaa, 0x72, 0xe0, 0x97, 0x8c, 0x1a, 0xaf, 0x8c, 0x81, 0xd7, 0xe1, 0xd7, 0x9d, 0x11, 0xd6, 0x46, 0xa0, 0x2, 0x90")
MAKE_THUNK(libasound, snd_pcm_info_get_card, "0x7e, 0x8, 0xd5, 0x75, 0x6c, 0xd0, 0x39, 0xb7, 0x71, 0x6, 0xcd, 0x96, 0x55, 0xf3, 0x3e, 0x8f, 0x6a, 0x2, 0xb, 0x81, 0xea, 0x8a, 0x72, 0xc6, 0xc6, 0x58, 0x88, 0x67, 0x56, 0x8a, 0xda, 0x2f")
MAKE_THUNK(libasound, snd_pcm_info_get_id, "0xd3, 0xc7, 0xd4, 0x3e, 0x6c, 0x65, 0x2, 0x94, 0xfa, 0x66, 0xde, 0xf0, 0xff, 0x4f, 0x68, 0xf9, 0x17, 0xa8, 0xb8, 0xb2, 0x6e, 0x33, 0xb4, 0x3d, 0x27, 0xc9, 0xf6, 0xb2, 0x86, 0xd5, 0xdf, 0x15")
MAKE_THUNK(libasound, snd_pcm_info_get_name, "0xb2, 0x9b, 0x26, 0x8a, 0xc4, 0xb5, 0x72, 0xdc, 0x8c, 0xaf, 0xd6, 0x6b, 0xf7, 0xff, 0x76, 0x94, 0x2a, 0xd0, 0xbc, 0xc, 0x76, 0xe4, 0x77, 0x74, 0x52, 0xde, 0x37, 0x27, 0xa0, 0x2e, 0xbc, 0x9f")
MAKE_THUNK(libasound, snd_pcm_info_get_subdevice_name, "0xe4, 0xfc, 0x68, 0xc9, 0x39, 0x85, 0x45, 0xa6, 0x88, 0x59, 0x66, 0xd3, 0xfb, 0x62, 0x41, 0x68, 0x21, 0x3, 0x4a, 0x1d, 0xb5, 0xce, 0xc1, 0x4f, 0xa5, 0x5, 0x8c, 0x17, 0xde, 0x18, 0x7b, 0xc3")
MAKE_THUNK(libasound, snd_pcm_info_get_class, "0x8b, 0xc0, 0x1f, 0xdd, 0x53, 0xaa, 0xf4, 0x32, 0x93, 0xe3, 0x6f, 0xbd, 0xc9, 0xe0, 0x42, 0xe6, 0xb2, 0x6e, 0x9e, 0x64, 0x44, 0x3d, 0x0, 0xf6, 0x72, 0x8b, 0x1a, 0xec, 0x2f, 0xac, 0xff, 0x4")
MAKE_THUNK(libasound, snd_pcm_info_get_subclass, "0x97, 0x7c, 0x46, 0x10, 0x33, 0x32, 0xde, 0x65, 0x90, 0xfa, 0x23, 0x79, 0xbd, 0xe6, 0x10, 0xb1, 0xba, 0xc5, 0xce, 0x5, 0x7a, 0xe4, 0x15, 0x1f, 0xdb, 0xfb, 0x99, 0x7d, 0x7f, 0x8e, 0x68, 0x5d")
MAKE_THUNK(libasound, snd_pcm_info_get_subdevices_count, "0x57, 0x79, 0xa4, 0xb5, 0xe2, 0x6c, 0xd9, 0x6, 0x63, 0xd0, 0xb, 0x8a, 0xd2, 0x94, 0xfc, 0x3f, 0x3, 0xeb, 0x50, 0xe6, 0xcf, 0x42, 0x61, 0x20, 0x5b, 0x50, 0x69, 0x42, 0xab, 0x2b, 0x63, 0x74")
MAKE_THUNK(libasound, snd_pcm_info_get_subdevices_avail, "0xd5, 0xf3, 0xe1, 0x9f, 0xf0, 0x22, 0xbf, 0xf, 0x45, 0x3c, 0x7b, 0x31, 0xd8, 0xe4, 0xec, 0xd4, 0xcd, 0xb3, 0xb1, 0x89, 0x82, 0x6c, 0x8b, 0x71, 0xbc, 0xab, 0x81, 0x67, 0x84, 0x90, 0xa4, 0x74")
MAKE_THUNK(libasound, snd_pcm_info_get_sync, "0x31, 0x96, 0x86, 0x1a, 0xd, 0x8d, 0xfd, 0xc6, 0x57, 0x56, 0x5a, 0xc7, 0x7c, 0xda, 0x3d, 0x52, 0xa4, 0xf7, 0x77, 0x3e, 0xce, 0x1c, 0xa6, 0xf1, 0xbb, 0x9f, 0x83, 0x44, 0x66, 0xcc, 0x85, 0xd6")
MAKE_THUNK(libasound, snd_pcm_info_set_device, "0x73, 0x6d, 0x2c, 0x25, 0x10, 0x38, 0x12, 0xb2, 0x49, 0x28, 0xa1, 0x50, 0x65, 0x64, 0x7, 0x61, 0x60, 0xbd, 0x51, 0x2b, 0x26, 0xf1, 0xb3, 0x73, 0xa3, 0x14, 0x19, 0xcc, 0xb1, 0x1d, 0x74, 0x3f")
MAKE_THUNK(libasound, snd_pcm_info_set_subdevice, "0xbc, 0x43, 0x52, 0x60, 0xb6, 0xf4, 0x70, 0x8f, 0x70, 0xda, 0x3d, 0xe1, 0xb, 0xfe, 0x4a, 0x7d, 0x4c, 0xd0, 0xb, 0xe2, 0xb1, 0xa2, 0xfd, 0x4e, 0xd0, 0x1d, 0xbf, 0x16, 0xba, 0x6a, 0xcb, 0x7")
MAKE_THUNK(libasound, snd_pcm_info_set_stream, "0x4b, 0xfb, 0xc, 0x4d, 0x73, 0xed, 0x46, 0xeb, 0x9b, 0x5d, 0xc1, 0xa8, 0x31, 0x89, 0x2c, 0xa3, 0x26, 0x81, 0x83, 0x59, 0x4e, 0xd0, 0x6, 0x94, 0x2a, 0x5e, 0x2e, 0x1a, 0x76, 0xd4, 0x6b, 0x7")
MAKE_THUNK(libasound, snd_pcm_hw_params_any, "0x14, 0x1c, 0x26, 0x5a, 0xac, 0x2a, 0xd2, 0x6b, 0xa6, 0x3d, 0xb4, 0xf4, 0x97, 0x9a, 0xf1, 0x84, 0x94, 0x66, 0x9e, 0x7a, 0xce, 0x59, 0x7d, 0xe8, 0xe6, 0xdf, 0xc1, 0x59, 0x4c, 0x9e, 0xc5, 0xdd")
MAKE_THUNK(libasound, snd_pcm_hw_params_can_mmap_sample_resolution, "0xb6, 0x4f, 0x87, 0x5b, 0x79, 0x10, 0x19, 0x8f, 0x82, 0x40, 0x92, 0x15, 0xf3, 0x82, 0x1e, 0xd5, 0x16, 0x79, 0xb5, 0x1e, 0xd5, 0xb1, 0x99, 0xac, 0x5b, 0x8c, 0xdf, 0xa9, 0x23, 0x9b, 0xb7, 0x52")
MAKE_THUNK(libasound, snd_pcm_hw_params_is_double, "0x79, 0x20, 0xf2, 0x1c, 0x58, 0xf7, 0x1b, 0xb2, 0xef, 0xef, 0x28, 0x81, 0x2e, 0x3d, 0x5d, 0x97, 0x6d, 0xd5, 0x1f, 0x19, 0xb1, 0xfa, 0xdf, 0xea, 0xb7, 0x74, 0x29, 0x3f, 0xf0, 0x8, 0x10, 0x1d")
MAKE_THUNK(libasound, snd_pcm_hw_params_is_batch, "0x4a, 0x57, 0x3c, 0x63, 0x59, 0xe, 0x8, 0xe1, 0xeb, 0x3d, 0x78, 0x94, 0x4c, 0xde, 0xb1, 0x84, 0x8, 0xc8, 0xd6, 0xb6, 0xf1, 0xf0, 0xe7, 0x14, 0x80, 0x3a, 0x9, 0x76, 0x6c, 0x13, 0xd3, 0x78")
MAKE_THUNK(libasound, snd_pcm_hw_params_is_block_transfer, "0xa0, 0x28, 0x5, 0x5b, 0x95, 0x3c, 0x75, 0x85, 0x4a, 0x94, 0xba, 0xe2, 0x8f, 0xe8, 0x17, 0x9f, 0xe, 0x37, 0xda, 0x93, 0x54, 0x26, 0x47, 0x7c, 0x23, 0x10, 0xea, 0x32, 0x11, 0xbd, 0xa0, 0xbe")
MAKE_THUNK(libasound, snd_pcm_hw_params_is_monotonic, "0xce, 0x42, 0x56, 0x15, 0xbe, 0xb2, 0x65, 0x8f, 0xd8, 0x57, 0xcb, 0x9f, 0x5, 0x3b, 0xee, 0x8f, 0x81, 0x22, 0x44, 0x1b, 0xc8, 0x11, 0x6c, 0xa3, 0xf5, 0xbb, 0xc9, 0xdf, 0x28, 0xab, 0xbb, 0x39")
MAKE_THUNK(libasound, snd_pcm_hw_params_can_overrange, "0x2d, 0x91, 0x65, 0x27, 0xcc, 0xa8, 0x22, 0xb1, 0x15, 0x76, 0x9e, 0xd5, 0x4b, 0xa9, 0xe3, 0xa0, 0xbd, 0xb0, 0x1f, 0xcf, 0x6, 0x3d, 0x1e, 0x34, 0xff, 0x4d, 0xd3, 0x75, 0xf, 0xaf, 0x5a, 0xd9")
MAKE_THUNK(libasound, snd_pcm_hw_params_can_pause, "0xff, 0x6d, 0xab, 0xbd, 0x9c, 0xc4, 0xb9, 0xc8, 0xcd, 0x7d, 0x54, 0x22, 0x78, 0x83, 0xa6, 0xc9, 0xef, 0xd8, 0x3d, 0x9b, 0x3f, 0x56, 0x66, 0xc2, 0x9f, 0xa0, 0x71, 0xfb, 0xc4, 0xf0, 0xae, 0x94")
MAKE_THUNK(libasound, snd_pcm_hw_params_can_resume, "0xf3, 0x6d, 0x28, 0x6c, 0xed, 0xee, 0xea, 0xb9, 0x4e, 0xff, 0x99, 0x6b, 0x1, 0x99, 0xc8, 0x6d, 0xbd, 0x12, 0xec, 0xfb, 0x95, 0x19, 0xe3, 0x13, 0xcf, 0x24, 0x82, 0x1a, 0xa6, 0x2c, 0x82, 0xe8")
MAKE_THUNK(libasound, snd_pcm_hw_params_is_half_duplex, "0x6, 0x4d, 0x13, 0x9e, 0x51, 0x4f, 0x5e, 0x4, 0x17, 0x68, 0x17, 0xb2, 0x8b, 0xc7, 0xb, 0xfe, 0x92, 0xe6, 0x88, 0x8e, 0x70, 0xe, 0x7d, 0x88, 0x8d, 0x27, 0xb, 0xf5, 0x2d, 0x73, 0xac, 0xa3")
MAKE_THUNK(libasound, snd_pcm_hw_params_is_joint_duplex, "0xbc, 0xc4, 0x84, 0x5b, 0x79, 0x7b, 0x26, 0x14, 0x41, 0x4a, 0x47, 0xf3, 0xee, 0x34, 0xa, 0x1d, 0x6f, 0xf3, 0x64, 0x2c, 0x60, 0x8d, 0xf9, 0x95, 0x9f, 0x6, 0x61, 0x5b, 0x9f, 0xa7, 0xe3, 0xa2")
MAKE_THUNK(libasound, snd_pcm_hw_params_can_sync_start, "0x32, 0xae, 0x18, 0xc0, 0x61, 0xc7, 0xeb, 0x2c, 0xe, 0x9e, 0x69, 0x4e, 0x34, 0xd7, 0x13, 0x1b, 0x4f, 0xa8, 0x8a, 0x5c, 0xdb, 0xd2, 0x76, 0x6a, 0x49, 0x10, 0xf6, 0x86, 0xca, 0xab, 0x51, 0x33")
MAKE_THUNK(libasound, snd_pcm_hw_params_can_disable_period_wakeup, "0x1d, 0x2c, 0xb3, 0xa1, 0x77, 0x11, 0xb8, 0x99, 0x9a, 0x9b, 0xaf, 0xca, 0x15, 0xa3, 0x2f, 0xba, 0x3b, 0x17, 0xd4, 0x7c, 0x76, 0xb6, 0xde, 0xec, 0xe4, 0x43, 0xc7, 0xeb, 0x74, 0xd6, 0x98, 0xc4")
MAKE_THUNK(libasound, snd_pcm_hw_params_supports_audio_wallclock_ts, "0xc8, 0xa9, 0x48, 0x61, 0x7f, 0x7e, 0xd0, 0xef, 0x1a, 0xec, 0x8c, 0x62, 0xd9, 0xb, 0x6a, 0x4e, 0x69, 0x76, 0xe8, 0xcf, 0x32, 0x37, 0xe4, 0xe6, 0x5b, 0x95, 0x19, 0xae, 0xbf, 0xf8, 0xfa, 0xa0")
MAKE_THUNK(libasound, snd_pcm_hw_params_supports_audio_ts_type, "0xe6, 0xeb, 0x15, 0xdc, 0x40, 0x80, 0x89, 0x12, 0x98, 0xfb, 0xdb, 0x2d, 0x66, 0x5, 0x21, 0x9b, 0x7c, 0x16, 0xbc, 0x46, 0xb2, 0xba, 0x8a, 0xab, 0x3, 0x1f, 0xf8, 0x3b, 0x71, 0x7a, 0x3b, 0x66")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_rate_numden, "0x97, 0x58, 0x5a, 0x32, 0xb1, 0x8e, 0x34, 0x35, 0xda, 0x80, 0xb2, 0x82, 0x8e, 0xca, 0x37, 0xeb, 0xe7, 0x24, 0xf7, 0x6c, 0x6b, 0xc6, 0x7f, 0xe5, 0x7c, 0xda, 0x47, 0x10, 0xf3, 0xd6, 0xa2, 0x50")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_sbits, "0x9a, 0xb5, 0xe1, 0xe6, 0x39, 0x6a, 0xc6, 0xc4, 0xbd, 0x22, 0x7, 0x75, 0x8a, 0xcc, 0xc3, 0x2a, 0xa7, 0xba, 0x27, 0x16, 0x90, 0xa1, 0x3b, 0x8d, 0x53, 0x2a, 0x86, 0x63, 0x5c, 0x62, 0x4b, 0x47")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_fifo_size, "0xf8, 0x32, 0x5d, 0x34, 0xb4, 0x71, 0xb9, 0xbc, 0x41, 0xab, 0x6, 0x74, 0xa3, 0x9e, 0x3, 0x50, 0x39, 0x51, 0x70, 0x4f, 0xb8, 0x7f, 0xec, 0x3a, 0x64, 0x55, 0xbd, 0x8b, 0x9b, 0xe4, 0x18, 0x17")
MAKE_THUNK(libasound, snd_pcm_hw_params_sizeof, "0xc0, 0xa7, 0x17, 0xe, 0x16, 0xa3, 0x54, 0xbd, 0x59, 0x4, 0xc2, 0x64, 0xed, 0x44, 0x78, 0xb9, 0x23, 0x74, 0x99, 0x6a, 0xe1, 0x91, 0xe5, 0x1e, 0x7d, 0xcf, 0x7, 0xe1, 0xe2, 0x20, 0x6a, 0xfd")
MAKE_THUNK(libasound, snd_pcm_hw_params_malloc, "0x58, 0x5e, 0x3b, 0xf2, 0xd5, 0x99, 0xed, 0x91, 0x18, 0x1a, 0xa7, 0x85, 0xea, 0x7d, 0x41, 0x6a, 0xe3, 0xde, 0xcf, 0xce, 0x15, 0xa3, 0x4d, 0x51, 0xf4, 0xc2, 0x42, 0x89, 0x84, 0x12, 0x15, 0xa6")
MAKE_THUNK(libasound, snd_pcm_hw_params_free, "0xd7, 0x92, 0xba, 0x55, 0xa0, 0xe5, 0x11, 0x12, 0x61, 0x33, 0x47, 0x57, 0x20, 0xea, 0x5d, 0xe1, 0xe, 0x43, 0x59, 0xa4, 0x99, 0x2b, 0x2a, 0x5c, 0x48, 0xdf, 0x4b, 0xa2, 0xe0, 0x88, 0xf5, 0xa6")
MAKE_THUNK(libasound, snd_pcm_hw_params_copy, "0x2, 0x6e, 0xe6, 0x66, 0x70, 0xd2, 0x2f, 0x82, 0xe1, 0x59, 0xf1, 0x83, 0x51, 0xc8, 0x95, 0xd1, 0x2e, 0x44, 0x5c, 0xb1, 0x55, 0x6d, 0x1e, 0xeb, 0xa9, 0x3b, 0xca, 0x73, 0x7c, 0x51, 0x97, 0xbc")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_access, "0x5c, 0xcf, 0x2a, 0x4a, 0xac, 0xaf, 0x73, 0x88, 0xfb, 0xf6, 0xfd, 0xd, 0x5f, 0x6b, 0x77, 0x0, 0xeb, 0xb8, 0x94, 0x7f, 0xdf, 0xaa, 0xb6, 0x35, 0xc4, 0x24, 0x28, 0xea, 0x74, 0xd4, 0x18, 0xc3")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_access, "0x32, 0x3e, 0xf4, 0xce, 0x1f, 0x59, 0x86, 0x3d, 0xdd, 0x6f, 0x1b, 0xd6, 0xc, 0x13, 0x52, 0xda, 0xe1, 0x1c, 0xa2, 0xba, 0xb, 0x9f, 0xb8, 0x1, 0xb3, 0x73, 0xf2, 0x25, 0xa9, 0x4c, 0xbf, 0xfa")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_access, "0x1c, 0xa8, 0x95, 0x46, 0x41, 0xa9, 0x60, 0xfc, 0x35, 0x13, 0x6a, 0xde, 0xed, 0xb1, 0x42, 0x82, 0xc3, 0xf1, 0x21, 0x46, 0x55, 0xd1, 0xa, 0xfa, 0x18, 0x53, 0x36, 0x78, 0x40, 0x33, 0x7d, 0xfe")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_access_first, "0xc3, 0xa8, 0x38, 0xef, 0xb0, 0x69, 0x42, 0x79, 0x9e, 0x41, 0x5, 0xa3, 0xb, 0x87, 0x88, 0x4f, 0x6d, 0xed, 0x44, 0x7c, 0xf2, 0xab, 0x50, 0xe1, 0xda, 0xb8, 0x5b, 0x9, 0xf5, 0xad, 0xb8, 0xff")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_access_last, "0xe0, 0x9a, 0x75, 0x7e, 0xc0, 0x3b, 0x5d, 0xc1, 0x82, 0x57, 0x92, 0xcb, 0x39, 0x8, 0x14, 0xbe, 0xc4, 0x8e, 0x8f, 0x43, 0xe1, 0x57, 0x6f, 0xcb, 0x73, 0x97, 0x20, 0xe5, 0x4f, 0xdf, 0x4b, 0xfe")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_access_mask, "0x8d, 0xf1, 0x6b, 0x7a, 0x50, 0x83, 0xbe, 0x3c, 0xfe, 0x80, 0xe0, 0x72, 0x49, 0x2a, 0xe7, 0x78, 0x72, 0xb6, 0xec, 0xde, 0x94, 0xa2, 0x1a, 0x83, 0x78, 0x35, 0xb8, 0xde, 0x7b, 0xfb, 0xc8, 0xb3")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_access_mask, "0x9e, 0x27, 0x36, 0xc8, 0xfc, 0x44, 0x78, 0xc0, 0xf3, 0xd1, 0xd9, 0x3d, 0xa1, 0x69, 0x1b, 0x53, 0x48, 0xfd, 0xb9, 0x5e, 0x15, 0xf5, 0xad, 0xbd, 0xe3, 0xbb, 0xd1, 0xdc, 0xac, 0xf8, 0xc2, 0x93")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_format, "0x97, 0x55, 0xbc, 0x42, 0xf5, 0x1e, 0xac, 0x27, 0xc5, 0x99, 0x4b, 0xdc, 0xf3, 0xa9, 0x7c, 0x76, 0xb3, 0xb1, 0xc5, 0xc3, 0x62, 0x47, 0x7f, 0xcb, 0xb8, 0x27, 0x45, 0x19, 0x66, 0xfc, 0x8e, 0x54")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_format, "0xd4, 0xfa, 0x5e, 0x5a, 0xe6, 0x99, 0x4d, 0xc1, 0xa1, 0x8e, 0x2a, 0xd9, 0x4, 0x7, 0xf9, 0xf8, 0xe5, 0x1, 0x86, 0xe1, 0x21, 0x47, 0x87, 0x4c, 0x4d, 0xe3, 0x30, 0x88, 0x30, 0x1f, 0xc6, 0xa6")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_format, "0x1, 0x19, 0x89, 0x8f, 0x3f, 0x82, 0x9f, 0x82, 0xbe, 0x11, 0x24, 0xdd, 0xfe, 0xe2, 0x25, 0x9a, 0xd3, 0x94, 0x53, 0x45, 0x79, 0x9, 0x35, 0x40, 0x4f, 0xe, 0x38, 0x29, 0x13, 0xd2, 0xbd, 0x79")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_format_first, "0x97, 0xbf, 0x8a, 0xbb, 0x1b, 0xc3, 0x2, 0xde, 0x2c, 0x35, 0x6b, 0xe5, 0xec, 0xb, 0xdc, 0x26, 0x37, 0x75, 0x95, 0x6, 0x9a, 0xad, 0x7a, 0xef, 0x6e, 0xdc, 0xf1, 0x19, 0xc0, 0xab, 0xb9, 0x7f")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_format_last, "0xbe, 0x19, 0x15, 0x7c, 0x5, 0xc5, 0xb9, 0xcb, 0xeb, 0x6d, 0xd1, 0x1, 0x82, 0x21, 0xbd, 0x16, 0xee, 0x2b, 0xaf, 0x89, 0xa8, 0xe3, 0x5e, 0xd8, 0xca, 0xf4, 0x54, 0x72, 0x9a, 0xa4, 0xa9, 0xb5")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_format_mask, "0x39, 0xb9, 0x36, 0x37, 0x95, 0xc5, 0x42, 0x58, 0x31, 0x93, 0xaa, 0x6c, 0xa, 0xe0, 0x3a, 0x63, 0xe5, 0x48, 0x2b, 0x58, 0x56, 0xc6, 0xe7, 0x5c, 0xa4, 0x94, 0x2f, 0xb3, 0x15, 0xcb, 0x9b, 0x6")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_format_mask, "0xa3, 0x2d, 0xe5, 0xca, 0xf9, 0x27, 0x25, 0x84, 0x15, 0xc7, 0x94, 0x81, 0x7b, 0xbe, 0xa4, 0x95, 0x52, 0x13, 0x6, 0x3a, 0xc6, 0x54, 0x31, 0x26, 0x7d, 0xc4, 0x8b, 0x62, 0xb6, 0xb7, 0x2a, 0x83")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_subformat, "0xb1, 0x3a, 0x45, 0xd7, 0xbe, 0x2c, 0x8c, 0x32, 0x27, 0x67, 0x41, 0x92, 0x17, 0x53, 0x2e, 0xa3, 0x1f, 0xb5, 0xca, 0x78, 0x1, 0x16, 0xcf, 0xce, 0x1f, 0x28, 0x4b, 0xde, 0x52, 0x62, 0x0, 0x10")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_subformat, "0x96, 0x7d, 0x9c, 0xb8, 0xcf, 0xcc, 0x74, 0xfd, 0x75, 0x8c, 0xeb, 0x74, 0xb1, 0x1a, 0x97, 0xd7, 0xbe, 0x36, 0x70, 0x82, 0x53, 0xe9, 0x84, 0x9b, 0x2, 0xe0, 0xbd, 0x49, 0x22, 0xc0, 0x92, 0xa9")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_subformat, "0xad, 0x37, 0x9d, 0xcd, 0xa8, 0x3b, 0x7b, 0x4b, 0x9d, 0xa1, 0xce, 0x1d, 0x33, 0xa, 0x76, 0xc4, 0x13, 0x40, 0x68, 0x9f, 0xe5, 0xf0, 0xdb, 0x56, 0xaf, 0x39, 0xdd, 0x4, 0xb5, 0xff, 0xc6, 0x4f")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_subformat_first, "0xb2, 0x3c, 0x4f, 0x7a, 0x95, 0xe6, 0x85, 0x93, 0x67, 0x1a, 0xe8, 0x42, 0xd8, 0x4f, 0x43, 0xe6, 0x6f, 0xaa, 0xd3, 0xa8, 0x58, 0xc7, 0xcc, 0x4c, 0xe, 0xf6, 0x95, 0x55, 0x97, 0x7, 0xad, 0x1e")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_subformat_last, "0x6d, 0x72, 0x90, 0x66, 0xc7, 0x37, 0x89, 0x65, 0xd5, 0xbd, 0x80, 0x9, 0xd6, 0x80, 0xf, 0xe8, 0x76, 0x86, 0xc, 0x25, 0xab, 0x8f, 0x26, 0x81, 0x83, 0xcd, 0x35, 0x64, 0xda, 0x7d, 0x1d, 0xad")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_subformat_mask, "0x3, 0x98, 0x2f, 0x77, 0x41, 0xff, 0xba, 0x36, 0xab, 0x79, 0xe0, 0x0, 0x88, 0x85, 0x53, 0xf, 0x1f, 0xa4, 0x48, 0xa7, 0x77, 0xc2, 0x14, 0x89, 0xd8, 0x45, 0xda, 0xdd, 0x10, 0xb8, 0x2d, 0x5f")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_subformat_mask, "0x92, 0xc3, 0x3e, 0x3d, 0x78, 0x93, 0x9c, 0xc4, 0xbb, 0x89, 0x61, 0xa7, 0xcb, 0x8c, 0x9a, 0xa4, 0xda, 0x74, 0xd1, 0x99, 0xfb, 0x11, 0x9, 0x4f, 0x8, 0x6f, 0x9, 0x2c, 0xa7, 0xb9, 0x54, 0xfc")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_channels, "0xa, 0xcb, 0x84, 0xd3, 0xfc, 0xab, 0x6d, 0x6b, 0xb4, 0x29, 0x21, 0x47, 0x4e, 0xde, 0x80, 0x81, 0xd7, 0xcc, 0xc3, 0x4b, 0xaf, 0xe4, 0xff, 0x68, 0x25, 0x2c, 0x9b, 0x11, 0xcb, 0xc1, 0x31, 0xfd")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_channels_min, "0xd, 0x29, 0xb5, 0xd7, 0xe4, 0x93, 0x77, 0xed, 0x3, 0x3a, 0xf8, 0xf6, 0xc3, 0x1a, 0x51, 0xae, 0xe9, 0x8c, 0x3f, 0xcb, 0xf3, 0x1, 0x24, 0x79, 0x61, 0xa6, 0xb4, 0x76, 0xfe, 0x49, 0xb0, 0xf9")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_channels_max, "0x10, 0xb8, 0x3a, 0x24, 0x7, 0x31, 0x98, 0xf3, 0xdf, 0xa7, 0x6, 0xf2, 0xaa, 0x8, 0x32, 0x7e, 0x4d, 0x2c, 0xb8, 0xda, 0x65, 0x96, 0x74, 0xb5, 0x18, 0x5c, 0x7a, 0x82, 0x49, 0x10, 0xf1, 0xa")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_channels, "0x64, 0xc7, 0x42, 0x0, 0xbe, 0xde, 0xa6, 0xb3, 0x9, 0xdf, 0xb3, 0xc7, 0xec, 0xbd, 0xa9, 0xe2, 0xfc, 0x44, 0x65, 0x73, 0x9a, 0xc8, 0xbc, 0xe6, 0x8e, 0xfd, 0xcc, 0x18, 0x54, 0xf1, 0xde, 0x25")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_channels, "0x2d, 0x11, 0xa2, 0xc7, 0xd6, 0xc9, 0x81, 0xe5, 0x17, 0xce, 0x8a, 0xaf, 0x12, 0x7d, 0x1a, 0xf8, 0x67, 0x95, 0x7a, 0x84, 0x29, 0xd7, 0x3e, 0xca, 0x26, 0xa7, 0x42, 0xa3, 0xd7, 0x8c, 0x7c, 0xc5")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_channels_min, "0x1f, 0xa9, 0x23, 0xb7, 0xf2, 0xbf, 0x21, 0xbe, 0x2a, 0xd9, 0xe6, 0xd5, 0x60, 0xb, 0x7f, 0xf7, 0x9d, 0xe6, 0x88, 0x4, 0x55, 0xb1, 0x6e, 0x4, 0x89, 0x5a, 0x35, 0xcf, 0x35, 0x3, 0x55, 0xb4")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_channels_max, "0x2, 0x56, 0x20, 0x4a, 0x8e, 0x17, 0xd8, 0xac, 0x80, 0x2a, 0xd6, 0xe6, 0x19, 0x2b, 0x7e, 0xa7, 0x14, 0x19, 0x74, 0x6b, 0x94, 0x3c, 0x78, 0x5, 0x76, 0x93, 0x4c, 0x9c, 0xbd, 0xf4, 0xac, 0xbc")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_channels_minmax, "0x93, 0xe2, 0xd0, 0x3b, 0xa7, 0x94, 0x15, 0x6a, 0x5e, 0xc3, 0xa0, 0x4d, 0x38, 0x8f, 0x6, 0x8a, 0xc5, 0x97, 0x1c, 0x4, 0x9b, 0xde, 0x1d, 0x17, 0x67, 0x16, 0x1f, 0x59, 0xef, 0x55, 0xb1, 0xcf")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_channels_near, "0x7f, 0x80, 0x5e, 0x52, 0xf6, 0xdb, 0xea, 0xbe, 0xe9, 0xd2, 0xf6, 0xb3, 0x37, 0x2b, 0xb2, 0x7b, 0x27, 0xd, 0x7c, 0x24, 0x28, 0xd2, 0x46, 0xa3, 0xeb, 0x44, 0x1d, 0x8e, 0x3e, 0x44, 0x78, 0x71")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_channels_first, "0xc0, 0x7f, 0xe0, 0x6c, 0x15, 0x2c, 0x88, 0xff, 0x82, 0xda, 0x9, 0x1f, 0x3b, 0xfa, 0x48, 0xe6, 0xdc, 0x97, 0x9d, 0x94, 0xe9, 0x8b, 0x93, 0x5f, 0x1a, 0x94, 0x2, 0x6, 0x1a, 0xe7, 0xe7, 0x3c")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_channels_last, "0xe8, 0x18, 0x7d, 0x88, 0x1e, 0xea, 0xb9, 0xc8, 0x7f, 0xd6, 0xac, 0xb6, 0x74, 0xb9, 0x70, 0x66, 0x40, 0xff, 0x62, 0xc9, 0xdd, 0x10, 0xe2, 0x55, 0x34, 0x5d, 0x3a, 0xee, 0xa4, 0x32, 0xdd, 0xfd")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_rate, "0x34, 0xd1, 0x38, 0x34, 0x23, 0x20, 0x7b, 0x76, 0x41, 0x64, 0xec, 0xf9, 0x8c, 0x85, 0x66, 0xdd, 0xb1, 0x93, 0xba, 0x35, 0x45, 0x69, 0x45, 0x8d, 0x23, 0xfe, 0x2b, 0x46, 0xf6, 0x8d, 0xd8, 0x66")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_rate_min, "0xd8, 0x46, 0x30, 0xd3, 0x0, 0x8, 0x67, 0x4b, 0xd0, 0xd, 0x9e, 0xe3, 0x85, 0x85, 0x91, 0xfa, 0xe8, 0x9c, 0x7c, 0x49, 0x80, 0xe3, 0xb4, 0xe0, 0xa0, 0x1, 0x2d, 0xb, 0xe7, 0x3, 0x5f, 0x20")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_rate_max, "0x30, 0xec, 0x66, 0x17, 0xb6, 0x53, 0x60, 0xa4, 0x49, 0x85, 0x94, 0xe7, 0x8f, 0x65, 0x95, 0x5c, 0x8e, 0x5c, 0x3, 0xfe, 0x59, 0x40, 0x27, 0xb6, 0x1d, 0xa7, 0xdf, 0xf8, 0xc4, 0x2a, 0x4c, 0x69")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_rate, "0x46, 0xa2, 0x2c, 0x63, 0x4a, 0xfc, 0xc6, 0x69, 0x97, 0x30, 0xb6, 0xed, 0x34, 0x6a, 0xf3, 0xdc, 0x63, 0xa6, 0xd6, 0x96, 0x24, 0xf6, 0xb2, 0xc1, 0x7f, 0x64, 0xe3, 0xba, 0xc8, 0xd3, 0x76, 0x6a")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate, "0x80, 0xc2, 0x7f, 0xdc, 0x6f, 0x7c, 0xc8, 0x6e, 0x43, 0xaf, 0x1c, 0x43, 0xe4, 0xd6, 0xa9, 0x96, 0x84, 0x20, 0xf2, 0x7f, 0xd7, 0xd9, 0x5a, 0x6e, 0x8e, 0x59, 0x5c, 0x26, 0x7c, 0x8d, 0x88, 0xfc")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate_min, "0xc, 0x3d, 0x71, 0xd1, 0xf0, 0xed, 0x69, 0x84, 0xf8, 0x96, 0x59, 0x20, 0xf8, 0xba, 0x1c, 0xf1, 0x81, 0x57, 0x4, 0x59, 0xec, 0x79, 0xc1, 0xb9, 0x9b, 0xf, 0x63, 0xd4, 0x79, 0xe0, 0x9a, 0x4b")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate_max, "0xa0, 0x69, 0x4b, 0xea, 0x59, 0x6b, 0x77, 0x77, 0xc, 0x2f, 0x84, 0xfa, 0x61, 0x8, 0x1c, 0xab, 0x26, 0x2a, 0x30, 0xbb, 0x23, 0xda, 0x7b, 0x66, 0x5b, 0xb5, 0x47, 0x1, 0x4b, 0x4, 0x24, 0xbe")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate_minmax, "0xe1, 0x9e, 0xb5, 0xe4, 0xd7, 0xf1, 0x56, 0x4d, 0xaa, 0x7f, 0x99, 0xbf, 0xc2, 0x17, 0x67, 0x80, 0xa7, 0xfb, 0x24, 0xfa, 0xfe, 0xdc, 0x70, 0xed, 0x8c, 0x0, 0x6a, 0x78, 0x77, 0xc4, 0x75, 0xd")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate_near, "0xbf, 0x66, 0xe4, 0xb0, 0x6d, 0xf1, 0x7d, 0x12, 0xc, 0x8a, 0xf1, 0x5f, 0xac, 0x4, 0x1c, 0xa9, 0x5e, 0xca, 0x94, 0x76, 0xb9, 0x4b, 0xfb, 0xf1, 0xf6, 0xf8, 0x77, 0x85, 0xe0, 0x39, 0xe1, 0xa1")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate_first, "0x57, 0xb0, 0xa3, 0xb7, 0xaa, 0x65, 0x2f, 0xc8, 0x7, 0xba, 0x5b, 0xef, 0xcb, 0x1, 0xd1, 0xb7, 0xb6, 0xe0, 0xe2, 0xf5, 0xce, 0x1, 0x16, 0x7, 0x67, 0x18, 0xde, 0x4a, 0x4e, 0x1, 0xe, 0xdd")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate_last, "0xd, 0x87, 0xd, 0xf2, 0x12, 0x9d, 0xbb, 0x2a, 0xb, 0x47, 0xd1, 0xe8, 0xb1, 0xb4, 0xbf, 0x40, 0x8c, 0xd2, 0xf1, 0xe0, 0x19, 0x8d, 0x4f, 0xa9, 0x25, 0xba, 0x59, 0x38, 0x4b, 0xcb, 0x51, 0xad")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_rate_resample, "0x61, 0x68, 0x51, 0x86, 0x4d, 0xc3, 0x33, 0x1e, 0x4f, 0x73, 0xc1, 0xb3, 0x7d, 0x18, 0x5c, 0x50, 0xba, 0x3c, 0x44, 0xe1, 0x80, 0xe1, 0xf6, 0x39, 0x58, 0x3a, 0x90, 0x9c, 0x43, 0xe9, 0xd9, 0x3e")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_rate_resample, "0x7a, 0x6f, 0x7e, 0xe9, 0xd3, 0x57, 0xad, 0x6f, 0xe7, 0x84, 0xef, 0xaa, 0xb4, 0x97, 0xf5, 0xa1, 0xe2, 0xc8, 0x52, 0x39, 0x59, 0xfc, 0xc8, 0x50, 0xcc, 0xe6, 0x54, 0x62, 0xfd, 0x63, 0xca, 0x7d")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_export_buffer, "0x13, 0x3f, 0x67, 0xd0, 0xed, 0x95, 0xb9, 0xfb, 0x29, 0x5a, 0x1b, 0xc6, 0x13, 0x5, 0x60, 0x4b, 0xe7, 0x24, 0xf3, 0x7d, 0xf2, 0xee, 0xb6, 0xac, 0xeb, 0x2d, 0x3f, 0xfd, 0xb8, 0xb7, 0xa2, 0x87")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_export_buffer, "0xf9, 0x59, 0x8c, 0x57, 0xb3, 0xe9, 0x38, 0x8, 0x33, 0xa8, 0x67, 0x8d, 0x37, 0x14, 0xd7, 0x19, 0x1a, 0xdf, 0xa, 0x65, 0x4f, 0xf2, 0x53, 0xdb, 0xae, 0xd1, 0x28, 0xbe, 0xf2, 0x41, 0xa5, 0x7d")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_wakeup, "0xde, 0x68, 0x63, 0xea, 0xd7, 0xc, 0xdf, 0x4e, 0xe2, 0xc7, 0x9e, 0xb1, 0x1c, 0xf1, 0xe8, 0x68, 0x0, 0x2a, 0x87, 0x35, 0x57, 0x4, 0xfe, 0x42, 0x54, 0x3e, 0x7e, 0x70, 0x56, 0x3, 0xfd, 0x4")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_period_wakeup, "0x3c, 0x25, 0x73, 0x98, 0xd2, 0xbe, 0xb6, 0xb3, 0x4d, 0x2, 0xbd, 0xf5, 0x8c, 0x6f, 0x69, 0xd9, 0xad, 0xfd, 0x5, 0x73, 0x5b, 0x3f, 0x35, 0x4a, 0xfa, 0x84, 0x91, 0x96, 0xca, 0x95, 0x34, 0x32")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_period_time, "0xff, 0x7f, 0xab, 0x17, 0x80, 0xed, 0x76, 0x20, 0xc6, 0xb1, 0x0, 0xfa, 0x0, 0x38, 0xa1, 0xb2, 0xe0, 0x4e, 0x88, 0x8, 0xc2, 0x15, 0x86, 0x6e, 0xd4, 0x40, 0x8, 0x6f, 0x74, 0x20, 0x5f, 0xb3")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_period_time_min, "0xb6, 0xb0, 0x2c, 0x2, 0x81, 0x4e, 0x72, 0x2a, 0x61, 0x67, 0xdc, 0xe5, 0xf1, 0xb1, 0x80, 0xcc, 0xf4, 0xa7, 0x24, 0x7d, 0x75, 0x8e, 0xd5, 0x71, 0xc9, 0x58, 0x51, 0xc1, 0x48, 0x55, 0x9f, 0x3c")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_period_time_max, "0x7e, 0x58, 0x94, 0x10, 0x78, 0xe8, 0xa7, 0x3b, 0x7d, 0x2b, 0x93, 0x3d, 0xba, 0x49, 0xf5, 0xa2, 0xe2, 0x4f, 0xb0, 0xff, 0x96, 0x60, 0x86, 0xe, 0x90, 0xb2, 0x7e, 0xa4, 0x69, 0x9c, 0xbf, 0x25")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_period_time, "0x23, 0x2d, 0x70, 0xcb, 0x72, 0x97, 0x82, 0x48, 0xbb, 0x87, 0x87, 0xd, 0xe3, 0x24, 0x83, 0x6d, 0x92, 0x2a, 0x70, 0x10, 0x61, 0xe6, 0x50, 0x1b, 0x92, 0x5f, 0xb2, 0xf7, 0x26, 0x11, 0xc0, 0x34")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_time, "0xe1, 0xa9, 0x69, 0x39, 0xaf, 0x5f, 0xb3, 0x5b, 0x19, 0x3a, 0x5c, 0x31, 0xe1, 0xb5, 0x17, 0x36, 0xbe, 0x61, 0xf, 0x60, 0x17, 0xc5, 0x66, 0xf1, 0x7d, 0xc9, 0xdf, 0x21, 0x6d, 0x8a, 0x4e, 0xb6")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_time_min, "0x6c, 0x51, 0x4e, 0x99, 0x69, 0x55, 0x85, 0x78, 0x63, 0x2, 0x70, 0x12, 0x5e, 0x17, 0x92, 0xe, 0xf1, 0x90, 0x55, 0x60, 0x2e, 0x19, 0x57, 0xe8, 0xa1, 0xfa, 0x41, 0x31, 0xe0, 0xf2, 0xa, 0xdb")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_time_max, "0x1b, 0x91, 0x25, 0x2d, 0xd, 0x95, 0x8b, 0x84, 0x65, 0xc0, 0x62, 0xa1, 0xc8, 0x62, 0xa1, 0xca, 0x17, 0xef, 0x21, 0xa0, 0xc4, 0x22, 0x89, 0x67, 0xc2, 0x4, 0xbe, 0xba, 0x8b, 0x32, 0x84, 0xc1")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_time_minmax, "0x3b, 0xea, 0x79, 0x53, 0x6b, 0x6d, 0xbe, 0x2d, 0x54, 0x81, 0x40, 0xe7, 0x50, 0x90, 0x3e, 0x82, 0x5e, 0x3b, 0x64, 0xba, 0x42, 0xfd, 0x8d, 0x8d, 0xdf, 0xc9, 0x87, 0x5e, 0xf7, 0x78, 0xe3, 0x84")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_time_near, "0xd7, 0x29, 0xa9, 0x1c, 0x88, 0x85, 0x57, 0xd, 0x27, 0xb5, 0x6e, 0x8e, 0xfc, 0xe, 0x8e, 0x51, 0xad, 0x5d, 0xd0, 0x2a, 0xda, 0xe0, 0x14, 0x9a, 0x20, 0xea, 0xe, 0x2b, 0x5c, 0xc7, 0x18, 0x5d")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_time_first, "0xbb, 0x33, 0x6e, 0x54, 0x67, 0xad, 0x10, 0x9, 0x9, 0xad, 0xb3, 0x4e, 0xec, 0xbd, 0x86, 0xf2, 0xb1, 0xa8, 0x7c, 0xad, 0x9b, 0xdd, 0x52, 0x8a, 0x75, 0xea, 0x86, 0x94, 0x7f, 0x89, 0xcd, 0x48")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_time_last, "0x34, 0x14, 0x74, 0x62, 0x9, 0x85, 0xaa, 0xd8, 0x7e, 0xd5, 0xc6, 0x62, 0x39, 0x26, 0xbe, 0xb1, 0x3e, 0x76, 0xfe, 0xc5, 0x27, 0x77, 0x24, 0xe5, 0x3, 0x3f, 0x34, 0x85, 0x4e, 0xe1, 0xef, 0x82")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_period_size, "0xcf, 0xe1, 0xb1, 0xa1, 0x46, 0x42, 0xf6, 0x97, 0x50, 0x5d, 0xaa, 0x17, 0xe9, 0x7a, 0xda, 0x84, 0xee, 0x7c, 0x96, 0xcf, 0xaf, 0x67, 0x4e, 0xd2, 0x84, 0x79, 0xf3, 0x47, 0x3, 0x32, 0xac, 0x34")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_period_size_min, "0xb3, 0x3f, 0x31, 0x22, 0x9f, 0x85, 0x60, 0x76, 0xe3, 0x7a, 0x78, 0xf9, 0x3d, 0xdf, 0x99, 0x83, 0x36, 0x2c, 0xf5, 0x85, 0xe, 0x39, 0xc8, 0x76, 0x32, 0xe1, 0x93, 0x4f, 0x75, 0xc3, 0xfa, 0x10")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_period_size_max, "0x92, 0x19, 0x55, 0x4c, 0xfb, 0x19, 0xbd, 0xa2, 0xf8, 0xcc, 0xa8, 0xbe, 0x36, 0x4b, 0x49, 0x9a, 0x8, 0x47, 0x9e, 0xb0, 0xde, 0x3e, 0x21, 0xac, 0x84, 0xe5, 0xd7, 0x34, 0xf8, 0x4a, 0xc5, 0xc4")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_period_size, "0x5c, 0x12, 0xb, 0x3e, 0xb2, 0x3, 0x38, 0x66, 0xf6, 0x87, 0xdc, 0x90, 0x9c, 0x9, 0xfb, 0x12, 0xa9, 0x90, 0xb, 0x8b, 0x57, 0x6e, 0x19, 0x14, 0xe8, 0x73, 0x3f, 0x39, 0x66, 0x7e, 0x57, 0xbb")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size, "0xbc, 0x4b, 0x39, 0x53, 0xe, 0xc5, 0x64, 0x28, 0x2a, 0x1e, 0xa4, 0x40, 0x4a, 0x40, 0x6a, 0xe, 0x8b, 0xce, 0xad, 0x54, 0x79, 0xa3, 0x4d, 0x6a, 0x7f, 0x1b, 0x48, 0xc0, 0x9a, 0xfa, 0x9f, 0x5a")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size_min, "0xaf, 0xd2, 0x6, 0x15, 0xe5, 0x22, 0xa8, 0xcf, 0x51, 0xea, 0x56, 0xd8, 0xcb, 0x99, 0x92, 0xe4, 0xe0, 0xdf, 0x17, 0x8, 0x59, 0x4f, 0xb6, 0x3a, 0x5, 0x4a, 0x77, 0x16, 0xd6, 0xec, 0xa3, 0x68")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size_max, "0x4a, 0x58, 0x45, 0x98, 0xf7, 0x38, 0xff, 0x5f, 0x81, 0x3e, 0x96, 0x6, 0x4e, 0x71, 0xae, 0xe1, 0xa1, 0x99, 0xd7, 0xb4, 0xd4, 0x66, 0x28, 0xbc, 0x99, 0xe4, 0xbe, 0xc8, 0x4b, 0xeb, 0x2a, 0xa7")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size_minmax, "0x30, 0xa1, 0x4b, 0x87, 0x84, 0xc5, 0x63, 0x7b, 0xf9, 0x56, 0xfa, 0xbc, 0xdf, 0x4a, 0xcf, 0x60, 0xba, 0xb1, 0x25, 0xd3, 0x31, 0xba, 0x82, 0x15, 0xa6, 0x80, 0x26, 0x52, 0xd8, 0xd, 0x89, 0x85")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size_near, "0x8b, 0x17, 0xdb, 0x9e, 0x2e, 0x16, 0x5a, 0xfb, 0x9b, 0x91, 0xb4, 0xbf, 0x6a, 0xcd, 0xf8, 0x76, 0xd4, 0x87, 0xbe, 0x92, 0xca, 0x85, 0x34, 0x22, 0x57, 0x49, 0x88, 0x8, 0xc7, 0xfd, 0x1d, 0x92")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size_first, "0x4f, 0x81, 0xeb, 0x64, 0x4d, 0x30, 0x98, 0x63, 0x64, 0x46, 0x47, 0x34, 0x85, 0xc4, 0xa5, 0x15, 0x3a, 0xe1, 0x2b, 0x85, 0x1, 0x9a, 0x1f, 0xef, 0x45, 0xad, 0x9f, 0xf9, 0xfa, 0xfa, 0x69, 0x88")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size_last, "0x6, 0x1c, 0x14, 0x1c, 0x32, 0xcf, 0x82, 0x3, 0xdd, 0x4c, 0x8f, 0xf7, 0x2d, 0x96, 0xd7, 0x5c, 0x19, 0xe, 0x40, 0xe6, 0x9e, 0x3a, 0xc8, 0xc, 0x5d, 0xfa, 0x9a, 0x52, 0x49, 0xc9, 0xd8, 0xa6")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_period_size_integer, "0x7d, 0x16, 0x6c, 0x3a, 0x43, 0x6b, 0x4f, 0x8c, 0xb8, 0x53, 0x22, 0xaf, 0x4a, 0x19, 0xe0, 0x21, 0x81, 0x62, 0x8e, 0x75, 0x2a, 0x19, 0x98, 0x3d, 0x4c, 0x61, 0x5e, 0x33, 0xff, 0xbb, 0xb3, 0x88")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_periods, "0x7a, 0xb3, 0xfb, 0x78, 0xf6, 0xcf, 0xa3, 0x77, 0xb8, 0x25, 0x84, 0x85, 0xbd, 0x35, 0xa4, 0xed, 0xa0, 0xdb, 0x3f, 0x60, 0xfc, 0x75, 0xed, 0xbc, 0x2c, 0x2e, 0xcb, 0x9b, 0x6b, 0x16, 0xef, 0x10")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_periods_min, "0xf3, 0x27, 0xee, 0xf9, 0x47, 0x1, 0xe7, 0x26, 0x3f, 0x39, 0x42, 0xda, 0xc2, 0x99, 0x8e, 0x88, 0x6f, 0x92, 0xd4, 0x94, 0x25, 0x1c, 0xe6, 0x37, 0xac, 0x6e, 0xae, 0xc3, 0x2d, 0xc6, 0x31, 0xc3")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_periods_max, "0x61, 0x9, 0xe2, 0x28, 0x5b, 0x65, 0x7b, 0x76, 0x24, 0x86, 0x27, 0x14, 0xdd, 0x2b, 0x9f, 0xf4, 0x3c, 0xb9, 0xe7, 0x96, 0xc, 0x22, 0x8, 0xa8, 0x3, 0x6a, 0xa8, 0xdb, 0x34, 0xae, 0xb1, 0x80")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_periods, "0xba, 0xf0, 0x87, 0x8f, 0xc3, 0x21, 0xff, 0xdf, 0x30, 0x17, 0x5b, 0xab, 0x2c, 0xe1, 0x60, 0x79, 0x3d, 0xf, 0xe3, 0x4e, 0x7d, 0x14, 0xf4, 0x5b, 0xef, 0x5c, 0xf2, 0xa3, 0x78, 0x20, 0x48, 0xf6")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods, "0x7d, 0x73, 0x6c, 0xcb, 0xec, 0xda, 0xba, 0xd5, 0xe, 0x9b, 0x10, 0x88, 0x92, 0x1f, 0xa3, 0x97, 0x5f, 0x92, 0x4a, 0xca, 0xbe, 0x8f, 0xdf, 0x74, 0x18, 0xf0, 0x5e, 0x7b, 0xf7, 0x31, 0x8a, 0xa")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods_min, "0xac, 0xd4, 0x8a, 0x74, 0x67, 0xa8, 0x64, 0x7a, 0xca, 0x36, 0x63, 0x77, 0x62, 0x17, 0xe4, 0x5a, 0xa7, 0x95, 0x5f, 0xed, 0x33, 0x42, 0xd5, 0x5f, 0x8b, 0xbb, 0x9b, 0xef, 0xc0, 0x2a, 0x10, 0xa6")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods_max, "0x82, 0x9, 0x1d, 0xd, 0x6b, 0x94, 0x84, 0xdf, 0x34, 0x47, 0x82, 0x8, 0xc1, 0x76, 0x74, 0x8c, 0x4e, 0xe7, 0x67, 0xa3, 0xd8, 0xff, 0xe0, 0x37, 0x7d, 0x93, 0x79, 0xd4, 0x3d, 0x41, 0x9, 0xe3")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods_minmax, "0x44, 0xe0, 0xd5, 0xe2, 0x6e, 0x6f, 0x45, 0xfa, 0x72, 0x70, 0x8f, 0x8b, 0x2b, 0xa2, 0x61, 0xe0, 0xe9, 0x81, 0x1, 0x83, 0xc5, 0x45, 0x50, 0xee, 0xe0, 0x6, 0x66, 0xe, 0x59, 0x93, 0xdb, 0xe1")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods_near, "0xf, 0xab, 0x76, 0x54, 0x95, 0xb8, 0x1d, 0x4e, 0xbd, 0x26, 0x51, 0xf7, 0xa8, 0xf6, 0xb1, 0x95, 0x44, 0x80, 0x81, 0x0, 0x50, 0xed, 0xb1, 0xf4, 0x3b, 0xce, 0xe8, 0x33, 0x67, 0xc2, 0x27, 0xfa")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods_first, "0x39, 0x6f, 0x1d, 0x39, 0xae, 0x1d, 0xeb, 0x4f, 0x70, 0xaf, 0x5f, 0xcd, 0xdf, 0x64, 0x2e, 0x4b, 0x76, 0x2, 0x71, 0xc2, 0x8a, 0x1b, 0x41, 0x48, 0x47, 0xa4, 0x5d, 0xe2, 0xd, 0xdb, 0xa3, 0x25")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods_last, "0x6e, 0x3, 0xea, 0x5e, 0x65, 0xc5, 0x97, 0xa2, 0xcb, 0x5d, 0xd3, 0x52, 0x8c, 0x1e, 0x82, 0xba, 0xe0, 0x4, 0xc, 0x18, 0x81, 0xc3, 0xdc, 0x21, 0x76, 0xb1, 0x92, 0x82, 0xdc, 0x1f, 0xdc, 0xa3")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_periods_integer, "0x1, 0xc0, 0x8d, 0x52, 0xde, 0x68, 0x7a, 0x8d, 0xab, 0xdd, 0xaf, 0x3d, 0x86, 0x60, 0xa7, 0x9e, 0xc6, 0xca, 0x79, 0x9f, 0x8e, 0xfb, 0x71, 0xe0, 0xe8, 0x95, 0x6b, 0x9, 0x6a, 0x90, 0x9d, 0x1a")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_buffer_time, "0x6e, 0x98, 0x84, 0xbc, 0x2a, 0xe5, 0x72, 0xfe, 0xca, 0xdd, 0xb6, 0xb3, 0x1c, 0x42, 0x94, 0xca, 0x3e, 0x38, 0x8c, 0x69, 0xb5, 0xf1, 0x80, 0xda, 0x8d, 0xba, 0xdd, 0xb5, 0x29, 0x8e, 0xe1, 0x2c")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_buffer_time_min, "0xac, 0xab, 0x98, 0x60, 0xf6, 0xeb, 0xad, 0xc9, 0xce, 0x2a, 0x25, 0x6c, 0x0, 0x11, 0xc, 0xb6, 0x20, 0x36, 0xc6, 0x8a, 0x67, 0x6, 0xf2, 0xf6, 0x45, 0xd1, 0x71, 0xc1, 0x9e, 0x37, 0x25, 0xba")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_buffer_time_max, "0x82, 0xbf, 0xdf, 0x6b, 0x76, 0x69, 0x6a, 0x48, 0x66, 0x9, 0xaf, 0xc, 0x86, 0x4f, 0x2e, 0x77, 0x8e, 0x4f, 0x3b, 0x7f, 0xb0, 0x67, 0xf7, 0xa5, 0x7d, 0x37, 0x8d, 0x1c, 0xc7, 0x2f, 0xd7, 0xd3")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_buffer_time, "0xf7, 0x21, 0xf8, 0xc4, 0xf0, 0x6b, 0x1f, 0x8f, 0xf1, 0xdd, 0xae, 0x98, 0xf, 0x75, 0xb5, 0x32, 0xd1, 0xde, 0x5, 0x5a, 0x64, 0xac, 0x31, 0x2e, 0x59, 0x21, 0x50, 0x66, 0xdb, 0xe4, 0xba, 0x72")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_time, "0xd0, 0x47, 0x4a, 0xcd, 0xc2, 0x53, 0x40, 0xb2, 0xdd, 0x69, 0x14, 0xa2, 0xb8, 0x33, 0x63, 0xf2, 0x5, 0x73, 0x8e, 0xe1, 0x68, 0x83, 0x1c, 0x61, 0x46, 0xc1, 0x96, 0xc0, 0x72, 0xe3, 0x99, 0x16")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_time_min, "0xb, 0xf2, 0xd8, 0x96, 0xd9, 0x44, 0x4f, 0xe3, 0xa5, 0x29, 0xab, 0x98, 0x3, 0x22, 0x10, 0x21, 0x97, 0x71, 0xaf, 0x8b, 0xea, 0x3e, 0xb9, 0x3b, 0xd, 0x5f, 0xa, 0xc0, 0xdb, 0x8d, 0x98, 0xb6")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_time_max, "0x22, 0x41, 0xff, 0x17, 0xe2, 0xc5, 0x6, 0x94, 0xcd, 0xe4, 0x96, 0x21, 0xd3, 0x9, 0x8, 0xf, 0x20, 0xb7, 0xbf, 0xe6, 0x6a, 0x77, 0x6, 0x76, 0x71, 0x65, 0xe9, 0x3f, 0x58, 0x53, 0xc, 0xa8")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_time_minmax, "0x38, 0x37, 0x77, 0x49, 0x65, 0x8b, 0x61, 0x52, 0x3, 0x8d, 0xac, 0x9c, 0xd0, 0xb6, 0xb0, 0xfc, 0x31, 0x85, 0xe3, 0x3, 0x63, 0x37, 0x52, 0xe3, 0xf1, 0x51, 0x20, 0x6b, 0xd9, 0xa7, 0x5f, 0x21")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_time_near, "0x71, 0x78, 0x62, 0xf, 0x57, 0x92, 0xe0, 0x8a, 0xb9, 0x22, 0x88, 0xfd, 0xd5, 0x63, 0x8a, 0x80, 0x24, 0x80, 0x73, 0xe5, 0x65, 0xef, 0xed, 0x4c, 0x8d, 0xc6, 0xc4, 0xf9, 0xd9, 0x14, 0xf2, 0x8")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_time_first, "0x69, 0x58, 0x87, 0x35, 0xa9, 0xe6, 0x11, 0x46, 0x98, 0xd7, 0x62, 0xf5, 0x29, 0xf7, 0xa0, 0xd5, 0x90, 0xce, 0xaf, 0x4c, 0xf5, 0x3, 0x2b, 0x71, 0x3b, 0x72, 0x56, 0xfd, 0x9f, 0x18, 0xd4, 0x8c")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_time_last, "0xbc, 0xb1, 0x64, 0x28, 0xbe, 0x20, 0x2, 0x5b, 0xd6, 0x69, 0xd3, 0x3d, 0x35, 0x3b, 0x95, 0xc7, 0x8d, 0x2f, 0xb3, 0x4f, 0x5c, 0x1f, 0x4c, 0x5f, 0x74, 0x4f, 0x42, 0x33, 0x7e, 0xa3, 0xaa, 0xd5")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_buffer_size, "0x49, 0x2a, 0xae, 0x62, 0xb2, 0x9b, 0x44, 0xac, 0x4b, 0x8d, 0x20, 0x7e, 0xc8, 0xe4, 0x8f, 0xfc, 0x93, 0x15, 0xc5, 0xee, 0x86, 0xa1, 0x68, 0xce, 0x70, 0x5, 0x42, 0x70, 0x47, 0x44, 0x91, 0x21")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_buffer_size_min, "0xe9, 0xaf, 0xd1, 0x45, 0xa3, 0x30, 0x3, 0x98, 0x46, 0x7f, 0xd7, 0x93, 0x9f, 0x4e, 0x15, 0xf3, 0x39, 0xde, 0xa2, 0x47, 0xf6, 0xe7, 0xb3, 0x6b, 0xd3, 0xa1, 0xf7, 0x47, 0x93, 0xf7, 0xc0, 0x96")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_buffer_size_max, "0x39, 0xd7, 0x10, 0xc5, 0x71, 0xa6, 0x79, 0x8d, 0x9e, 0x24, 0x62, 0xe7, 0x2f, 0x64, 0x89, 0x70, 0xd9, 0x9, 0x52, 0x1c, 0x79, 0xe0, 0xae, 0xe, 0x96, 0xa9, 0xde, 0xa4, 0x93, 0x2f, 0x72, 0x8d")
MAKE_THUNK(libasound, snd_pcm_hw_params_test_buffer_size, "0x83, 0xb3, 0xec, 0x91, 0xf8, 0xd8, 0xcf, 0xb6, 0x11, 0x5b, 0x50, 0x4a, 0x93, 0x2a, 0x39, 0x30, 0x60, 0xe7, 0xa5, 0x3d, 0xe6, 0xf5, 0xf4, 0x5f, 0x48, 0xfb, 0x30, 0x59, 0x49, 0x3a, 0xc4, 0xab")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_size, "0x24, 0xcd, 0x89, 0x7b, 0x93, 0x74, 0xff, 0x65, 0x53, 0x5c, 0x2f, 0x55, 0x43, 0xed, 0xc8, 0x5d, 0x44, 0xa, 0xec, 0x2a, 0xcb, 0x2a, 0x5e, 0x44, 0x38, 0x60, 0x51, 0x4c, 0xd0, 0x7b, 0xfb, 0x42")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_size_min, "0x9d, 0x9b, 0xe, 0xc0, 0xaa, 0xb2, 0x52, 0x50, 0x8e, 0x87, 0x39, 0xad, 0x50, 0xe0, 0xbf, 0xc5, 0x68, 0x86, 0x80, 0x46, 0xfb, 0x64, 0xaf, 0x8d, 0x6, 0x27, 0x98, 0x37, 0xf8, 0x7a, 0x37, 0x93")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_size_max, "0xc3, 0x29, 0x2c, 0xe5, 0x1f, 0x79, 0x8f, 0x2b, 0x1b, 0x2, 0x73, 0x8, 0x4f, 0x29, 0x39, 0x14, 0xe4, 0xbd, 0xb4, 0x51, 0x5, 0x1b, 0xe9, 0x5, 0xdd, 0xac, 0x60, 0x39, 0xb4, 0xa7, 0x3a, 0xaf")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_size_minmax, "0x3b, 0x59, 0x1c, 0x56, 0xdd, 0xa, 0xae, 0x7c, 0x3f, 0x12, 0x64, 0x6d, 0x4b, 0xf2, 0xbf, 0xe7, 0xde, 0xb9, 0xb0, 0xfd, 0xdf, 0x32, 0xa6, 0xc5, 0xef, 0xa4, 0xc, 0xaa, 0x6c, 0x24, 0x2c, 0xf0")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_size_near, "0x96, 0x3, 0x35, 0x4, 0x99, 0xa5, 0xc, 0x4, 0xb9, 0x36, 0x5c, 0xec, 0x0, 0xdf, 0x3, 0x1f, 0xb1, 0xfb, 0xba, 0xc, 0x96, 0x8d, 0x7d, 0xad, 0x3b, 0xd1, 0x6b, 0x2c, 0xfb, 0x16, 0xc1, 0x47")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_size_first, "0x56, 0x83, 0x4b, 0x3f, 0x76, 0xe4, 0x43, 0xad, 0x28, 0x2b, 0x6d, 0xf6, 0xb9, 0x8c, 0x45, 0x97, 0x6a, 0x7c, 0x63, 0xa4, 0x65, 0x86, 0xff, 0x3c, 0x9f, 0xfd, 0x3a, 0xc5, 0xc5, 0x60, 0xfb, 0x78")
MAKE_THUNK(libasound, snd_pcm_hw_params_set_buffer_size_last, "0x7f, 0x98, 0xe, 0xe9, 0x13, 0xd0, 0x78, 0x75, 0x5b, 0x2, 0xeb, 0x9a, 0x57, 0x45, 0xa, 0x76, 0xb4, 0x16, 0x7a, 0xc9, 0x2a, 0x97, 0x3d, 0xcb, 0xd4, 0xac, 0x1b, 0x1e, 0xca, 0x2b, 0x45, 0xd8")
MAKE_THUNK(libasound, snd_pcm_hw_params_get_min_align, "0xe8, 0xf4, 0x98, 0x4, 0x90, 0xa2, 0x88, 0x69, 0xbe, 0x90, 0x3e, 0x98, 0xd, 0x25, 0xc4, 0x9, 0x41, 0xbf, 0x8e, 0x52, 0x5a, 0xda, 0x77, 0x64, 0x3e, 0x33, 0x21, 0x41, 0x7f, 0xe8, 0xad, 0x79")
MAKE_THUNK(libasound, snd_pcm_sw_params_sizeof, "0x59, 0x98, 0xd7, 0x19, 0xdc, 0x37, 0x22, 0xa9, 0xd8, 0x74, 0xc1, 0xad, 0x67, 0x5, 0x21, 0xc4, 0x20, 0x34, 0x1c, 0x63, 0x15, 0xa3, 0xfc, 0x2f, 0x4f, 0x72, 0xca, 0x73, 0x1c, 0x7e, 0x71, 0xae")
MAKE_THUNK(libasound, snd_pcm_sw_params_malloc, "0xeb, 0x6, 0x16, 0x3e, 0xdd, 0x82, 0xd0, 0x48, 0x6f, 0x48, 0x43, 0x8b, 0x49, 0x7b, 0xe5, 0x31, 0xc2, 0xca, 0x35, 0x7f, 0xc8, 0xe1, 0x71, 0x37, 0x54, 0x31, 0xc6, 0xdd, 0xc8, 0xe1, 0xd2, 0x3b")
MAKE_THUNK(libasound, snd_pcm_sw_params_free, "0x6a, 0xc1, 0x5c, 0xfe, 0x8e, 0xc1, 0x94, 0x2e, 0xf4, 0x12, 0x2, 0x53, 0xc6, 0x88, 0xa2, 0x69, 0x7a, 0x33, 0x59, 0xd9, 0x46, 0xe1, 0x5a, 0x62, 0xcc, 0x4e, 0x56, 0xcc, 0x81, 0xaf, 0x1e, 0xf5")
MAKE_THUNK(libasound, snd_pcm_sw_params_copy, "0x63, 0x76, 0xd8, 0x84, 0xb9, 0xf1, 0x2d, 0xc1, 0xe4, 0x58, 0x12, 0x12, 0xf5, 0xd7, 0xf7, 0xac, 0xca, 0xbb, 0xed, 0x90, 0xd5, 0xca, 0x1e, 0x79, 0x62, 0xe6, 0xeb, 0x4a, 0x1f, 0xa2, 0x13, 0x53")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_boundary, "0x51, 0x16, 0xe2, 0x51, 0x6e, 0x53, 0x27, 0x3d, 0x70, 0xde, 0xf1, 0x49, 0xeb, 0xbf, 0xd7, 0x5b, 0xe0, 0xf5, 0x26, 0x79, 0xe9, 0x7, 0x2d, 0x5a, 0xca, 0x39, 0xc2, 0x78, 0xb2, 0x68, 0x7d, 0x25")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_tstamp_mode, "0xae, 0x39, 0xf9, 0xd1, 0x88, 0xf0, 0xd4, 0x40, 0x4d, 0x1d, 0x56, 0xdf, 0x56, 0xc3, 0x5c, 0x91, 0xe0, 0xf9, 0xa7, 0x96, 0xc7, 0x2b, 0x2a, 0x33, 0x10, 0x2c, 0x7c, 0xe5, 0x69, 0x28, 0x8c, 0x50")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_tstamp_mode, "0x2f, 0xa2, 0x83, 0x5b, 0xf6, 0xec, 0x32, 0x27, 0xf9, 0xff, 0x25, 0x99, 0x68, 0xf3, 0x9d, 0x2b, 0x73, 0x64, 0xff, 0x69, 0x1c, 0x5e, 0x5b, 0x53, 0x65, 0x8b, 0x15, 0xba, 0x5b, 0x44, 0xe6, 0x96")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_tstamp_type, "0x3f, 0xa7, 0xd3, 0x13, 0x7b, 0x25, 0xb7, 0x16, 0x65, 0x5c, 0x41, 0xf1, 0xfc, 0xaa, 0x4c, 0x35, 0x96, 0xfb, 0x93, 0x40, 0xb4, 0xd4, 0xc6, 0xaf, 0x72, 0xc5, 0x1a, 0xb, 0x47, 0x8, 0x82, 0x0")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_tstamp_type, "0x3a, 0x15, 0xd6, 0x25, 0x46, 0x99, 0x30, 0x23, 0x4c, 0x94, 0xc1, 0x22, 0x3c, 0xc9, 0x44, 0x55, 0xd1, 0x2, 0x8e, 0xeb, 0x93, 0x7e, 0x3a, 0xa7, 0x3b, 0xa2, 0xbe, 0xa3, 0x53, 0x5a, 0x21, 0x77")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_avail_min, "0x16, 0x45, 0x63, 0x4e, 0xea, 0x25, 0x65, 0x4b, 0x31, 0x2f, 0xc3, 0x96, 0xf4, 0x73, 0x79, 0xe4, 0xdd, 0xda, 0x28, 0xf3, 0x28, 0x3e, 0x29, 0x26, 0x7e, 0x56, 0xe2, 0xb0, 0xaa, 0x45, 0x92, 0x81")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_avail_min, "0x3b, 0x18, 0x55, 0x10, 0xa, 0x9d, 0xac, 0x97, 0x55, 0x4a, 0xea, 0xf9, 0x19, 0x3c, 0x7d, 0x77, 0xee, 0xf3, 0xe5, 0x5a, 0xf5, 0xea, 0x90, 0x71, 0x30, 0x9, 0xdc, 0xbb, 0x99, 0x31, 0x8, 0x9")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_period_event, "0xb8, 0x26, 0xac, 0xa7, 0xfa, 0x49, 0xcc, 0xe8, 0xc5, 0xc, 0x98, 0xc4, 0x1c, 0xbe, 0x23, 0x85, 0x7e, 0x30, 0xf2, 0x3b, 0xe, 0x11, 0x29, 0xb6, 0xec, 0xc4, 0xaf, 0x27, 0x23, 0xb8, 0x70, 0x69")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_period_event, "0xb9, 0x6, 0xe2, 0x8c, 0xa3, 0xfa, 0xa7, 0xef, 0x4e, 0x4b, 0x8e, 0xc9, 0x36, 0xf9, 0x49, 0xf2, 0x50, 0xe2, 0x7, 0x3b, 0x6c, 0xdc, 0xa, 0xb6, 0x6c, 0x1, 0x36, 0x31, 0x68, 0x1e, 0x34, 0x29")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_start_threshold, "0xe7, 0x75, 0xcf, 0x76, 0x98, 0x49, 0x1a, 0xb5, 0x77, 0xb1, 0x57, 0x8d, 0x82, 0xf, 0x11, 0x32, 0x58, 0xe6, 0x0, 0x29, 0xda, 0x7b, 0x3, 0x13, 0xe0, 0x62, 0x99, 0xdf, 0xba, 0xbf, 0xa3, 0x24")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_start_threshold, "0x82, 0x60, 0x6c, 0xd8, 0xe0, 0xcd, 0x63, 0x3a, 0xde, 0x70, 0xf1, 0xec, 0x27, 0x5a, 0x22, 0xa7, 0x2e, 0xd5, 0xfe, 0x7e, 0x64, 0x74, 0xee, 0xd0, 0x49, 0xf2, 0x97, 0x1a, 0x40, 0xde, 0x64, 0xa0")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_stop_threshold, "0xf8, 0xa0, 0xdc, 0xb9, 0xdf, 0xc0, 0x16, 0x94, 0x51, 0x2f, 0x9f, 0x70, 0x30, 0xb7, 0xb9, 0x42, 0x74, 0x3c, 0xc1, 0x51, 0x9, 0x72, 0xad, 0x75, 0x37, 0x6d, 0x1a, 0x13, 0x39, 0x17, 0x0, 0xf4")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_stop_threshold, "0x9e, 0x72, 0x83, 0x89, 0x6d, 0xa3, 0xb9, 0x52, 0x1d, 0xe7, 0xd0, 0xaa, 0xd2, 0xde, 0x10, 0xf0, 0x51, 0xb, 0xd, 0xe1, 0x68, 0x7a, 0x4a, 0x5a, 0xfd, 0x29, 0xde, 0x91, 0xc, 0x40, 0x35, 0x9e")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_silence_threshold, "0x9b, 0x9e, 0xad, 0x82, 0x21, 0x43, 0x9, 0xa8, 0x2, 0x67, 0x38, 0x3, 0x56, 0x12, 0x62, 0xea, 0xd9, 0x58, 0xc7, 0xce, 0x53, 0xcf, 0x6a, 0xe8, 0x27, 0x26, 0x81, 0x14, 0x53, 0x81, 0x87, 0x17")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_silence_threshold, "0xcb, 0xc5, 0xe2, 0x46, 0x31, 0xbd, 0xb, 0xff, 0x36, 0xf4, 0xdf, 0x87, 0x3e, 0x39, 0x84, 0x3e, 0x6d, 0x6e, 0xaf, 0xfc, 0x7b, 0x5a, 0xb6, 0xd2, 0xe2, 0x23, 0xdc, 0xe2, 0xa7, 0xa5, 0xe, 0xbd")
MAKE_THUNK(libasound, snd_pcm_sw_params_set_silence_size, "0x77, 0x1c, 0x98, 0x7c, 0xd3, 0xff, 0xa0, 0x2e, 0xc7, 0x84, 0x6, 0xce, 0xf2, 0xe0, 0x9e, 0x8d, 0x29, 0x76, 0xdc, 0x2c, 0xe7, 0x75, 0x9f, 0x33, 0x45, 0x29, 0xf8, 0xa9, 0xd5, 0x13, 0xe, 0x25")
MAKE_THUNK(libasound, snd_pcm_sw_params_get_silence_size, "0x74, 0x58, 0x76, 0x7b, 0x87, 0xec, 0xfc, 0xa5, 0x9d, 0x62, 0x9e, 0xce, 0x5c, 0x71, 0xe5, 0x7c, 0xa3, 0x38, 0xa2, 0x5e, 0x37, 0xcf, 0x22, 0xe2, 0xe3, 0x48, 0xf6, 0x5b, 0xce, 0x27, 0x24, 0x36")
MAKE_THUNK(libasound, snd_pcm_access_mask_sizeof, "0x14, 0xc4, 0x22, 0x2f, 0x57, 0xcc, 0x4e, 0xf1, 0x66, 0xd6, 0x22, 0x8d, 0x89, 0x8b, 0x60, 0x2, 0x7c, 0xcf, 0x61, 0xb7, 0xfd, 0xad, 0x22, 0xda, 0x90, 0x8, 0xf7, 0x2, 0x66, 0xcd, 0xd, 0xa3")
MAKE_THUNK(libasound, snd_pcm_access_mask_malloc, "0x5b, 0xc5, 0x5c, 0x36, 0x44, 0x28, 0x4f, 0xe5, 0x4b, 0x5c, 0x2c, 0x6d, 0x8f, 0x3, 0x8f, 0xf3, 0xaf, 0x8a, 0xce, 0x35, 0x28, 0x62, 0x6d, 0xb8, 0x2a, 0x57, 0xbc, 0x6f, 0x28, 0x43, 0xf0, 0x62")
MAKE_THUNK(libasound, snd_pcm_access_mask_free, "0x77, 0xbb, 0x97, 0x8f, 0xb, 0x1e, 0xb6, 0xd, 0x49, 0x32, 0x14, 0xbb, 0x5, 0x1e, 0xc7, 0xac, 0x7c, 0xfe, 0x6c, 0xb8, 0xdc, 0xd0, 0x5, 0x8c, 0x5c, 0xd6, 0x23, 0x53, 0xf9, 0xdd, 0x5c, 0xbe")
MAKE_THUNK(libasound, snd_pcm_access_mask_copy, "0x83, 0x20, 0xaa, 0x77, 0xd8, 0xb6, 0xb7, 0xf0, 0x80, 0x5c, 0x96, 0x82, 0x47, 0x1d, 0x2a, 0xa9, 0xad, 0x65, 0xf7, 0x93, 0x85, 0x30, 0xb8, 0xca, 0x20, 0xfa, 0x32, 0xc9, 0x1d, 0x26, 0x1e, 0x48")
MAKE_THUNK(libasound, snd_pcm_access_mask_none, "0x9a, 0xba, 0xb7, 0x60, 0xa7, 0x8b, 0xe3, 0xca, 0xdf, 0xc4, 0x9b, 0x18, 0x19, 0xef, 0xac, 0xf0, 0xe8, 0x2e, 0x88, 0x5b, 0xd4, 0x45, 0x2f, 0xba, 0x27, 0xeb, 0x44, 0x5a, 0xba, 0x8e, 0xc9, 0x0")
MAKE_THUNK(libasound, snd_pcm_access_mask_any, "0xa1, 0xe9, 0x1a, 0x76, 0x6e, 0x99, 0xc1, 0x54, 0xde, 0xad, 0xe3, 0xc8, 0x2a, 0x7, 0xc9, 0x4, 0xb0, 0xd0, 0x3b, 0x4a, 0x95, 0x2d, 0xc5, 0x8d, 0xf4, 0xe7, 0x2e, 0xf5, 0x2b, 0xa7, 0x73, 0xef")
MAKE_THUNK(libasound, snd_pcm_access_mask_test, "0xd0, 0x30, 0x70, 0x94, 0x53, 0xa7, 0xb2, 0x54, 0xff, 0xd, 0x76, 0x48, 0x3f, 0xf7, 0x78, 0x7c, 0x44, 0x6c, 0x39, 0xf, 0x10, 0x31, 0x7, 0x95, 0x88, 0x98, 0xa, 0x66, 0x58, 0x51, 0x7a, 0x4")
MAKE_THUNK(libasound, snd_pcm_access_mask_empty, "0xbe, 0x4a, 0x8e, 0xf4, 0xa0, 0x88, 0xbd, 0x5c, 0xa, 0xa3, 0x41, 0xc4, 0x32, 0x51, 0xb, 0xd6, 0x2, 0xd0, 0xf9, 0x9f, 0x9, 0xe1, 0xb5, 0xd6, 0xc1, 0xbd, 0x9e, 0x62, 0x1f, 0x79, 0x8f, 0xbd")
MAKE_THUNK(libasound, snd_pcm_access_mask_set, "0x8c, 0xac, 0xfd, 0x5b, 0x73, 0xa6, 0xf4, 0x39, 0x88, 0x1b, 0xb5, 0x11, 0x23, 0x1e, 0xab, 0x65, 0xb2, 0x1f, 0xf7, 0x3d, 0x8c, 0x8f, 0xae, 0x9e, 0x19, 0x2b, 0xd2, 0xb4, 0x5, 0x9, 0x7b, 0x65")
MAKE_THUNK(libasound, snd_pcm_access_mask_reset, "0xd7, 0xf, 0x82, 0x7e, 0x25, 0x52, 0x8b, 0x3d, 0x8, 0x7b, 0xb1, 0x24, 0xe9, 0xd0, 0x47, 0x45, 0xed, 0x58, 0x97, 0x8a, 0x91, 0x6d, 0xc6, 0x3d, 0xd, 0xbc, 0xda, 0x4a, 0xa9, 0x42, 0x9c, 0x66")
MAKE_THUNK(libasound, snd_pcm_format_mask_sizeof, "0xdd, 0x86, 0x63, 0x5e, 0x9d, 0x88, 0xa2, 0x25, 0x8f, 0xa4, 0x27, 0x41, 0x28, 0x7, 0x4d, 0xcb, 0xcb, 0x3e, 0xda, 0xa6, 0x34, 0x13, 0x65, 0x2d, 0xa5, 0xd1, 0x95, 0x36, 0x10, 0x37, 0xbf, 0x7d")
MAKE_THUNK(libasound, snd_pcm_format_mask_malloc, "0x58, 0x97, 0x30, 0x97, 0x11, 0xb1, 0x8c, 0x97, 0x96, 0x7c, 0x4d, 0xd4, 0x15, 0xe, 0xe3, 0xac, 0x1d, 0xe3, 0xea, 0x4, 0x9d, 0x71, 0xa3, 0xcb, 0x33, 0x37, 0x9, 0x54, 0x58, 0x49, 0x44, 0x98")
MAKE_THUNK(libasound, snd_pcm_format_mask_free, "0x51, 0xa8, 0x4e, 0x34, 0x7c, 0x56, 0x3d, 0xc8, 0xc1, 0x8e, 0x11, 0xd1, 0x4b, 0x71, 0x32, 0x3, 0x23, 0x49, 0x3e, 0xa4, 0x3d, 0x30, 0x8b, 0x4b, 0xe9, 0xb1, 0x7b, 0x50, 0x5a, 0x80, 0xf8, 0x29")
MAKE_THUNK(libasound, snd_pcm_format_mask_copy, "0x87, 0xe8, 0x4a, 0xa9, 0x74, 0xfa, 0xe6, 0xe9, 0x4f, 0x94, 0x97, 0x82, 0x1e, 0x1d, 0x70, 0x23, 0xd, 0xcf, 0xa8, 0x2d, 0x67, 0xda, 0xc4, 0xf, 0x8f, 0x78, 0x75, 0xbb, 0x4e, 0x5a, 0x1b, 0x2")
MAKE_THUNK(libasound, snd_pcm_format_mask_none, "0xae, 0x39, 0xde, 0x4a, 0xa9, 0x82, 0x7f, 0xfa, 0x35, 0xa6, 0x5b, 0xae, 0x8, 0x47, 0x2f, 0xc0, 0x51, 0x3, 0xb, 0x39, 0x34, 0x7f, 0x42, 0x5d, 0xa0, 0xf1, 0xee, 0xa9, 0x4e, 0x73, 0x39, 0x86")
MAKE_THUNK(libasound, snd_pcm_format_mask_any, "0x3, 0x8e, 0x10, 0x93, 0x4e, 0x79, 0xaa, 0x82, 0x85, 0xf2, 0x9f, 0xa9, 0x81, 0x7e, 0x75, 0x43, 0xbb, 0x3d, 0x1b, 0x99, 0xf7, 0x38, 0x84, 0x44, 0x38, 0xea, 0x89, 0x9e, 0x42, 0xf4, 0x80, 0xb6")
MAKE_THUNK(libasound, snd_pcm_format_mask_test, "0xe0, 0x61, 0x4b, 0x73, 0xff, 0x12, 0x71, 0xff, 0xe8, 0x3c, 0x30, 0x4b, 0x69, 0xc8, 0xe7, 0x89, 0xb0, 0x4e, 0xfb, 0xc5, 0x45, 0x37, 0x18, 0x7d, 0x6f, 0xb3, 0x73, 0x94, 0x9d, 0x9d, 0xa6, 0xf0")
MAKE_THUNK(libasound, snd_pcm_format_mask_empty, "0x11, 0x54, 0xf8, 0xeb, 0xc4, 0x76, 0x37, 0x23, 0x5, 0x6, 0xb2, 0xd8, 0x24, 0xcd, 0x27, 0x5d, 0x24, 0xa7, 0xf5, 0x4e, 0x78, 0x78, 0xdf, 0xa1, 0xba, 0xe, 0xec, 0x9, 0xaa, 0x61, 0x99, 0xe0")
MAKE_THUNK(libasound, snd_pcm_format_mask_set, "0x39, 0x7, 0x70, 0x20, 0xbc, 0x2e, 0x71, 0x6d, 0xa4, 0x43, 0x6c, 0xde, 0x9e, 0x71, 0xe2, 0x66, 0xcc, 0x46, 0x9, 0xa3, 0xd2, 0x85, 0x77, 0x4c, 0x3e, 0xb, 0xf9, 0xea, 0xb3, 0x42, 0xfb, 0x68")
MAKE_THUNK(libasound, snd_pcm_format_mask_reset, "0xe5, 0x48, 0x55, 0x91, 0xe5, 0x8f, 0x45, 0x9b, 0xd3, 0xa5, 0x93, 0x87, 0x8f, 0x96, 0x18, 0xd8, 0xee, 0x87, 0x78, 0xac, 0x6c, 0x2d, 0xba, 0x32, 0xf3, 0x42, 0x0, 0xb8, 0x2c, 0x72, 0x1b, 0x43")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_sizeof, "0x9b, 0x41, 0x7, 0x51, 0xbd, 0xe2, 0x2f, 0x77, 0x8d, 0xda, 0xa9, 0x34, 0xac, 0xb1, 0xb0, 0x3b, 0xa4, 0x91, 0x2c, 0x93, 0x19, 0x74, 0xc7, 0xd6, 0x2f, 0xa0, 0xf5, 0x56, 0x62, 0xd3, 0x24, 0xb1")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_malloc, "0x2b, 0xd0, 0xd2, 0x98, 0x1, 0xa3, 0xab, 0xc3, 0x27, 0x75, 0xf2, 0xb3, 0x70, 0xbf, 0x85, 0x4e, 0x8a, 0xc8, 0x19, 0x51, 0xd8, 0xf, 0x7f, 0x9b, 0x87, 0xcd, 0x24, 0x97, 0xc4, 0x8c, 0x96, 0x39")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_free, "0xc9, 0x6a, 0x82, 0x8b, 0x94, 0x57, 0x8e, 0xdf, 0x9f, 0x92, 0x2a, 0xc8, 0x42, 0xce, 0xb5, 0x5b, 0xb1, 0x4e, 0x17, 0x2c, 0x6a, 0xe2, 0x35, 0xaf, 0x9, 0xb9, 0x1f, 0x3b, 0x4f, 0x56, 0x89, 0xa6")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_copy, "0xc6, 0xd0, 0xe3, 0x82, 0xa, 0x1b, 0xb0, 0x34, 0x46, 0xb6, 0x29, 0x13, 0xbd, 0xc6, 0x7c, 0x95, 0xbb, 0x8f, 0x7e, 0x81, 0x4d, 0xda, 0x4d, 0x77, 0x6a, 0x62, 0xba, 0xd2, 0x4, 0xa4, 0x1, 0x5f")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_none, "0xa6, 0xdf, 0x84, 0x1d, 0x38, 0x1b, 0x36, 0xed, 0xbc, 0x30, 0x37, 0xb9, 0x8d, 0x5f, 0xa7, 0x7a, 0xd0, 0x64, 0xa7, 0x4a, 0x77, 0xf3, 0xb5, 0x4d, 0x16, 0xee, 0xb9, 0xbd, 0x98, 0x43, 0x55, 0xbd")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_any, "0xa1, 0x8d, 0x10, 0x5, 0x54, 0x31, 0xac, 0xfc, 0x4a, 0x72, 0x27, 0x51, 0x28, 0x8c, 0xd6, 0x2d, 0x8f, 0x21, 0x0, 0x84, 0x32, 0xf5, 0x3d, 0x52, 0x96, 0xb8, 0xaf, 0x79, 0x7a, 0x5, 0x57, 0xb8")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_test, "0x67, 0x38, 0x19, 0x6f, 0xbf, 0x91, 0x47, 0xd5, 0x8f, 0xd4, 0xda, 0x5c, 0x56, 0x37, 0xf3, 0x31, 0xf7, 0x49, 0x3, 0x96, 0x4, 0x9b, 0x3f, 0xb4, 0x6c, 0x63, 0x5, 0xc9, 0xde, 0xee, 0xf7, 0x5")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_empty, "0xf2, 0x8, 0x29, 0xe2, 0xc, 0xfa, 0x72, 0x96, 0xac, 0x5d, 0x2c, 0xbe, 0x46, 0xc9, 0xbb, 0x39, 0xeb, 0x19, 0xb8, 0xde, 0xea, 0x3a, 0xd8, 0x1a, 0xf9, 0xf2, 0xed, 0xf2, 0xbe, 0x40, 0x32, 0x5")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_set, "0x24, 0xfb, 0xf8, 0x8f, 0x28, 0x54, 0x7a, 0x50, 0x11, 0xe2, 0x6, 0x1, 0x8d, 0xa5, 0x20, 0x90, 0x7, 0xb8, 0x38, 0x8, 0x76, 0x3b, 0xe4, 0xe3, 0xd5, 0x15, 0xbb, 0x86, 0x65, 0x9d, 0xe, 0xea")
MAKE_THUNK(libasound, snd_pcm_subformat_mask_reset, "0x20, 0x9, 0x8b, 0xe3, 0xe5, 0xb5, 0x86, 0x21, 0x65, 0xb8, 0x93, 0xe8, 0x3a, 0x3, 0xb8, 0x71, 0xa3, 0xe1, 0x8, 0x22, 0x1e, 0xe1, 0x37, 0xa7, 0x15, 0xe8, 0x4, 0x1a, 0x5b, 0xb8, 0xf6, 0x44")
MAKE_THUNK(libasound, snd_pcm_status_sizeof, "0x17, 0xb9, 0x9a, 0x8f, 0xcb, 0x5, 0xb6, 0x75, 0x40, 0xc9, 0x5a, 0x10, 0xf8, 0x43, 0xb2, 0xd6, 0x27, 0x7, 0xa9, 0x2, 0xfe, 0xca, 0x8c, 0x90, 0x3b, 0xf8, 0xbe, 0x6c, 0xaa, 0xca, 0xb6, 0x5b")
MAKE_THUNK(libasound, snd_pcm_status_malloc, "0xe1, 0x68, 0x5b, 0x60, 0x1, 0x79, 0x2, 0x50, 0x30, 0xc1, 0x71, 0x89, 0x80, 0xdb, 0x76, 0x28, 0x4a, 0xda, 0xd4, 0xfd, 0x73, 0x1e, 0x0, 0x9e, 0x74, 0xc1, 0x5b, 0x47, 0x9d, 0xa5, 0xbe, 0xe6")
MAKE_THUNK(libasound, snd_pcm_status_free, "0x50, 0x95, 0x5f, 0xe9, 0x22, 0x28, 0x91, 0x74, 0x31, 0x50, 0x75, 0x96, 0x42, 0x5e, 0x8d, 0x5c, 0x67, 0xdb, 0x45, 0x3f, 0x47, 0xa8, 0x54, 0xff, 0x40, 0x76, 0xc7, 0xc, 0x7d, 0x54, 0x3b, 0x81")
MAKE_THUNK(libasound, snd_pcm_status_copy, "0x77, 0x13, 0xd2, 0x5d, 0xb2, 0xae, 0x9b, 0xcd, 0x1b, 0x31, 0x45, 0x21, 0x35, 0xaf, 0x4b, 0x77, 0xf0, 0xdd, 0xc2, 0x91, 0xc0, 0x25, 0xc0, 0x11, 0xc8, 0xd, 0xb7, 0x5f, 0x27, 0x5a, 0x4f, 0xba")
MAKE_THUNK(libasound, snd_pcm_status_get_state, "0xa1, 0xfb, 0xdd, 0xa5, 0x77, 0x11, 0x1e, 0xf, 0x5b, 0x7b, 0xf4, 0x5, 0xfc, 0x7e, 0x3f, 0x76, 0xf1, 0xcd, 0xb4, 0xde, 0x28, 0xc4, 0x3, 0xa7, 0x77, 0x4e, 0x5b, 0x7d, 0x19, 0xd1, 0x79, 0x17")
MAKE_THUNK(libasound, snd_pcm_status_get_trigger_tstamp, "0xa4, 0x38, 0x5, 0x78, 0xea, 0xc7, 0xf1, 0x65, 0x3d, 0x7a, 0x9a, 0xa3, 0xea, 0x88, 0xdd, 0xbf, 0x6, 0xbd, 0xc9, 0x4, 0xad, 0x25, 0x36, 0x49, 0x61, 0xfc, 0x61, 0xb0, 0x72, 0xc3, 0xc1, 0xe7")
MAKE_THUNK(libasound, snd_pcm_status_get_trigger_htstamp, "0x89, 0x72, 0xa5, 0x81, 0xd2, 0xfd, 0x1d, 0x3c, 0x3a, 0x2c, 0x56, 0xc5, 0x1a, 0xa0, 0x6, 0x8, 0x3, 0x3c, 0x14, 0x0, 0x1f, 0xb4, 0xdc, 0x92, 0xfe, 0x6e, 0xcf, 0xa9, 0x43, 0xda, 0xf7, 0x6")
MAKE_THUNK(libasound, snd_pcm_status_get_tstamp, "0xf6, 0x20, 0x36, 0xd3, 0xee, 0x47, 0x40, 0x22, 0x45, 0x65, 0x21, 0xd0, 0x34, 0x44, 0x15, 0x20, 0xc6, 0x65, 0x87, 0x51, 0x74, 0x70, 0xa5, 0x5f, 0x69, 0x73, 0x97, 0x0, 0xa8, 0xad, 0x91, 0x33")
MAKE_THUNK(libasound, snd_pcm_status_get_htstamp, "0xb8, 0xb6, 0x32, 0xd7, 0xa8, 0xfa, 0xa9, 0x21, 0x13, 0x33, 0x3a, 0xcf, 0xb, 0x5e, 0x6, 0x69, 0xe4, 0x3b, 0x23, 0x30, 0x83, 0x7b, 0x0, 0xed, 0xfb, 0x9d, 0x39, 0x35, 0x5, 0x14, 0xf5, 0xf")
MAKE_THUNK(libasound, snd_pcm_status_get_audio_htstamp, "0x2, 0xf, 0x25, 0xf2, 0x21, 0x57, 0x9d, 0xde, 0xc5, 0x41, 0x4, 0x59, 0xb9, 0x4b, 0x2d, 0xb3, 0xb2, 0x4b, 0x7d, 0xf2, 0x33, 0x16, 0x87, 0xbc, 0x87, 0xeb, 0xee, 0xac, 0x91, 0xf7, 0x45, 0x2a")
MAKE_THUNK(libasound, snd_pcm_status_get_driver_htstamp, "0xd4, 0x91, 0x3d, 0x2f, 0x60, 0x83, 0x84, 0xeb, 0x2, 0x5a, 0x78, 0x35, 0x47, 0xe2, 0x7a, 0xcb, 0x12, 0x69, 0xa2, 0x9, 0xf1, 0x2d, 0x9d, 0xa9, 0xb1, 0xa6, 0x50, 0x6, 0x29, 0x8c, 0xc3, 0x40")
MAKE_THUNK(libasound, snd_pcm_status_get_audio_htstamp_report, "0x5c, 0xd1, 0x4c, 0x89, 0xc3, 0xe2, 0x30, 0x40, 0x18, 0xc0, 0x5b, 0x3f, 0x58, 0xc, 0x65, 0x5a, 0xfd, 0xf4, 0x53, 0x77, 0x67, 0xae, 0x2, 0x5e, 0x3e, 0x2c, 0xce, 0x3c, 0x6b, 0x70, 0x68, 0xf4")
MAKE_THUNK(libasound, snd_pcm_status_set_audio_htstamp_config, "0x5d, 0x94, 0x4, 0x9a, 0xda, 0xd, 0xc5, 0x38, 0x5e, 0x90, 0xd, 0xf2, 0x27, 0x86, 0x9, 0x73, 0xf4, 0xc7, 0xa2, 0xa4, 0xf5, 0xf2, 0x4c, 0xe3, 0x1d, 0xba, 0xcf, 0x50, 0xc7, 0x8d, 0x98, 0xe")
MAKE_THUNK(libasound, snd_pcm_status_get_delay, "0x7, 0xeb, 0x72, 0xa1, 0xa5, 0xd8, 0xe3, 0xbf, 0xca, 0x7, 0xcd, 0x7a, 0xf5, 0xd9, 0x4b, 0x34, 0x2e, 0x28, 0xad, 0x6f, 0x1e, 0x12, 0x54, 0xf2, 0x7, 0x20, 0x69, 0x6c, 0x22, 0x12, 0xf7, 0xfd")
MAKE_THUNK(libasound, snd_pcm_status_get_avail, "0x4d, 0x7e, 0x12, 0xbd, 0xb8, 0x20, 0xf1, 0xe1, 0xda, 0xf1, 0x56, 0xdb, 0xaa, 0x48, 0x3a, 0xc0, 0x71, 0xd0, 0x4, 0x75, 0xc, 0x60, 0x26, 0x7e, 0xb, 0x39, 0x37, 0xd4, 0x9, 0x61, 0x83, 0x2c")
MAKE_THUNK(libasound, snd_pcm_status_get_avail_max, "0x6f, 0xa2, 0x20, 0xb3, 0xeb, 0x8, 0x9e, 0x54, 0xfd, 0xfb, 0x3c, 0xa6, 0x19, 0xbf, 0xc0, 0x94, 0xbf, 0xd8, 0x4, 0x28, 0x31, 0x58, 0x13, 0x86, 0x2c, 0x0, 0x68, 0xa5, 0x84, 0x1a, 0x97, 0x8e")
MAKE_THUNK(libasound, snd_pcm_status_get_overrange, "0x40, 0xc6, 0x5c, 0xd0, 0x75, 0xbf, 0xcd, 0x73, 0xd3, 0x9b, 0x5c, 0x51, 0x4c, 0xde, 0x2c, 0x7f, 0x98, 0xf2, 0x9c, 0x84, 0x27, 0x64, 0x2, 0x74, 0xb2, 0xb3, 0x99, 0xb0, 0xe2, 0x98, 0x8f, 0x34")
MAKE_THUNK(libasound, snd_pcm_type_name, "0xa6, 0xf8, 0x95, 0x60, 0xb1, 0xba, 0xdd, 0x6f, 0xfb, 0x27, 0xeb, 0xab, 0x1f, 0x6e, 0x18, 0xd5, 0x23, 0x66, 0x14, 0xf7, 0x7e, 0x44, 0x12, 0x51, 0x58, 0x7b, 0x2a, 0x9b, 0x70, 0xfe, 0x77, 0x27")
MAKE_THUNK(libasound, snd_pcm_stream_name, "0xd8, 0x44, 0x83, 0x4e, 0x3e, 0x61, 0x25, 0x90, 0x3d, 0x80, 0x20, 0x2c, 0xa0, 0xcb, 0xf9, 0x40, 0x2a, 0xb2, 0xf3, 0xae, 0x37, 0x5e, 0x7f, 0x95, 0x4c, 0x13, 0x85, 0x8c, 0x6a, 0x7, 0x97, 0xf3")
MAKE_THUNK(libasound, snd_pcm_access_name, "0xff, 0x96, 0x4d, 0xa2, 0x5, 0xb8, 0x8a, 0xa1, 0x56, 0xcf, 0x6c, 0xe2, 0xfc, 0x90, 0xc9, 0xce, 0x8e, 0xa8, 0x4d, 0x32, 0xa6, 0x5a, 0xbc, 0x8e, 0x11, 0xe3, 0xfa, 0x3d, 0x8e, 0x6d, 0x7e, 0xf4")
MAKE_THUNK(libasound, snd_pcm_format_name, "0xbe, 0x5a, 0xa, 0x16, 0x41, 0x9e, 0xa8, 0xe3, 0x84, 0xb, 0xcd, 0xf, 0x2f, 0x45, 0xb9, 0x87, 0xbb, 0xf0, 0xef, 0xc1, 0xc0, 0x61, 0x3b, 0xb9, 0x9d, 0xbe, 0xbc, 0x25, 0xb6, 0x1a, 0x6c, 0xbd")
MAKE_THUNK(libasound, snd_pcm_format_description, "0xec, 0x27, 0x7f, 0x9a, 0x9a, 0x55, 0x77, 0xda, 0x33, 0x65, 0x94, 0xae, 0xa, 0xf6, 0xc0, 0x2b, 0xbe, 0xd8, 0xe5, 0x83, 0x28, 0xef, 0xdc, 0xb8, 0x3f, 0xd1, 0x48, 0xe7, 0x5c, 0x7b, 0x2a, 0x9e")
MAKE_THUNK(libasound, snd_pcm_subformat_name, "0xc2, 0x18, 0x7c, 0xfd, 0xbf, 0xcc, 0x90, 0x47, 0x25, 0x72, 0x69, 0x84, 0x60, 0x85, 0xf3, 0xe4, 0x33, 0x7c, 0x84, 0xb2, 0xf0, 0x6, 0x4a, 0x6b, 0x9e, 0xc2, 0xa2, 0x3b, 0xb2, 0xe8, 0x19, 0xa0")
MAKE_THUNK(libasound, snd_pcm_subformat_description, "0x63, 0x41, 0x18, 0xb2, 0xe6, 0x88, 0x4, 0x26, 0xf2, 0xb2, 0x9c, 0x83, 0xce, 0xd2, 0x2e, 0x60, 0x4d, 0x4f, 0x30, 0xb0, 0xc4, 0x78, 0x7c, 0xdd, 0x51, 0x3e, 0xd1, 0xfc, 0x60, 0x54, 0xcd, 0xda")
MAKE_THUNK(libasound, snd_pcm_format_value, "0xef, 0x29, 0x39, 0x67, 0x55, 0xae, 0x4d, 0x8b, 0x8a, 0x96, 0x7a, 0x1b, 0x68, 0x9b, 0x5b, 0x11, 0x37, 0x89, 0x28, 0x35, 0x36, 0xa3, 0xa9, 0x70, 0x42, 0xe5, 0x39, 0xfa, 0xe2, 0xe4, 0xe4, 0x37")
MAKE_THUNK(libasound, snd_pcm_dump, "0x14, 0xe1, 0xa9, 0xd7, 0x70, 0x44, 0xb4, 0xa8, 0x1, 0x9b, 0x68, 0xa6, 0x4d, 0x43, 0xa8, 0x42, 0x52, 0xb9, 0x6e, 0x5b, 0x67, 0x4, 0x93, 0x5e, 0x84, 0xaf, 0xd, 0x56, 0x2c, 0xa6, 0x4f, 0x5a")
MAKE_THUNK(libasound, snd_pcm_dump_hw_setup, "0x27, 0x25, 0x34, 0x89, 0x23, 0xdf, 0x44, 0x64, 0xb0, 0xb4, 0x34, 0x26, 0x1e, 0xde, 0xcf, 0xbe, 0x6e, 0xaf, 0xd2, 0x1b, 0xc0, 0x2c, 0xbd, 0x78, 0x15, 0xd4, 0xc, 0x62, 0xa3, 0x28, 0x13, 0x93")
MAKE_THUNK(libasound, snd_pcm_dump_sw_setup, "0xa9, 0xaf, 0x94, 0x40, 0xd5, 0x1f, 0xe0, 0x63, 0x5e, 0x62, 0x3e, 0x49, 0xce, 0x70, 0xad, 0x80, 0x8e, 0xc6, 0xc0, 0x1, 0x60, 0x70, 0x14, 0x24, 0x1e, 0x2c, 0x71, 0xb2, 0x2c, 0x23, 0x48, 0x94")
MAKE_THUNK(libasound, snd_pcm_dump_setup, "0xbe, 0xdf, 0xba, 0x40, 0x11, 0xa3, 0x75, 0x2a, 0x2c, 0xef, 0x45, 0x36, 0xa4, 0xc9, 0xe1, 0xe2, 0xb, 0x3, 0x4b, 0xd3, 0xb4, 0xf6, 0x2c, 0x58, 0x3b, 0x34, 0x20, 0x3e, 0x67, 0xa4, 0x7d, 0x25")
MAKE_THUNK(libasound, snd_pcm_hw_params_dump, "0xa5, 0x5f, 0xb3, 0x89, 0x9a, 0x57, 0x40, 0xf8, 0xd4, 0x8c, 0x32, 0xac, 0x20, 0x45, 0xa8, 0x7a, 0xbc, 0x68, 0xe4, 0x87, 0x1d, 0x79, 0xa0, 0xb2, 0x22, 0x81, 0xa9, 0xa2, 0xc9, 0x88, 0x4, 0x58")
MAKE_THUNK(libasound, snd_pcm_sw_params_dump, "0x67, 0xc5, 0x3f, 0x8d, 0xb8, 0x19, 0x50, 0x53, 0x61, 0x13, 0xd0, 0x29, 0x62, 0x32, 0x9e, 0x9, 0x20, 0x2, 0xda, 0xce, 0x19, 0x24, 0x51, 0x59, 0xb2, 0xc, 0x29, 0xc8, 0x93, 0x2e, 0x66, 0xe7")
MAKE_THUNK(libasound, snd_pcm_status_dump, "0x5d, 0xc7, 0x77, 0x34, 0x58, 0x41, 0xfb, 0x3e, 0x67, 0x43, 0x8e, 0x83, 0xf8, 0x2e, 0xd, 0x53, 0xdb, 0x49, 0xcb, 0x59, 0x63, 0xa3, 0x99, 0x7e, 0x81, 0x2e, 0xc2, 0x6f, 0xdd, 0xc6, 0x1f, 0x61")
MAKE_THUNK(libasound, snd_pcm_mmap_begin, "0x72, 0xc3, 0x8, 0x4e, 0xbf, 0x26, 0xc7, 0x33, 0x6c, 0x5e, 0x75, 0x55, 0x1c, 0x75, 0x55, 0xc8, 0x66, 0x9b, 0xe3, 0x6a, 0xc3, 0x96, 0x23, 0x7b, 0xd4, 0xad, 0xc4, 0x8c, 0x82, 0x4f, 0x45, 0x8b")
MAKE_THUNK(libasound, snd_pcm_mmap_commit, "0x42, 0xa, 0x8f, 0x1d, 0xb, 0x60, 0xd2, 0x2a, 0x62, 0x12, 0x4, 0x98, 0xac, 0xfb, 0xb2, 0x96, 0xa2, 0x4d, 0xf9, 0xeb, 0xbb, 0xe6, 0x2b, 0x21, 0x51, 0x4e, 0xfc, 0x4e, 0x37, 0x2c, 0xd8, 0x21")
MAKE_THUNK(libasound, snd_pcm_mmap_writei, "0x28, 0xc0, 0xd4, 0x85, 0x33, 0xd4, 0xb6, 0xe3, 0xa3, 0x26, 0x96, 0xf7, 0x8b, 0x7a, 0x2d, 0xad, 0x5d, 0x31, 0xb9, 0xf5, 0xc3, 0xd8, 0xf1, 0xee, 0x37, 0xe0, 0xe0, 0x2d, 0xd4, 0x9d, 0x32, 0x29")
MAKE_THUNK(libasound, snd_pcm_mmap_readi, "0xcd, 0xbf, 0xf0, 0x70, 0x0, 0x42, 0x58, 0x36, 0xf9, 0xa0, 0xcb, 0x65, 0x0, 0xe5, 0xf8, 0xd1, 0xf5, 0xf8, 0x42, 0x96, 0xa4, 0x16, 0x4a, 0x85, 0x52, 0x6c, 0xce, 0xfd, 0x2c, 0xcc, 0xa9, 0xec")
MAKE_THUNK(libasound, snd_pcm_mmap_writen, "0x57, 0xc6, 0x1b, 0xe, 0x83, 0x61, 0x88, 0x92, 0x6b, 0x7b, 0xaa, 0x80, 0x5f, 0x6b, 0xe3, 0xc4, 0xf2, 0x25, 0xa4, 0xe, 0xaa, 0x9c, 0x1f, 0x91, 0xf6, 0x1c, 0xdb, 0xff, 0xa, 0x25, 0x6f, 0x84")
MAKE_THUNK(libasound, snd_pcm_mmap_readn, "0x66, 0x56, 0x4f, 0x12, 0xb0, 0x58, 0x20, 0x9d, 0x69, 0x96, 0x6e, 0xe1, 0xdd, 0xa2, 0xb0, 0x63, 0xf8, 0x1d, 0xe5, 0x66, 0xce, 0x72, 0xcd, 0x80, 0x36, 0xc9, 0x9f, 0x4d, 0xab, 0xa, 0xbb, 0x9f")
MAKE_THUNK(libasound, snd_pcm_format_signed, "0x11, 0x62, 0xed, 0x9, 0xab, 0x9a, 0x5c, 0x31, 0x3f, 0x3e, 0x81, 0xaf, 0x81, 0x8, 0xfd, 0x63, 0x2, 0x0, 0x23, 0x28, 0xf7, 0x71, 0xf6, 0x34, 0x66, 0x1c, 0x2f, 0xc1, 0x20, 0x86, 0x8a, 0xf5")
MAKE_THUNK(libasound, snd_pcm_format_unsigned, "0x5b, 0xea, 0x65, 0x68, 0xea, 0xed, 0xd0, 0xf9, 0x9e, 0x8a, 0xd, 0xb6, 0x84, 0xa0, 0x4, 0x7, 0x92, 0x12, 0x79, 0x2e, 0x31, 0xaf, 0x86, 0x6e, 0x98, 0xd, 0xd6, 0xa9, 0x16, 0xbd, 0x63, 0xf5")
MAKE_THUNK(libasound, snd_pcm_format_linear, "0xed, 0xc2, 0x63, 0xca, 0x3e, 0x76, 0xd8, 0xea, 0x21, 0xe1, 0x6e, 0x91, 0x66, 0x99, 0x84, 0xd4, 0x3, 0x85, 0x40, 0xc8, 0x27, 0xa4, 0x7a, 0xcc, 0xc3, 0x8c, 0x45, 0xc1, 0x33, 0x6c, 0xbf, 0x32")
MAKE_THUNK(libasound, snd_pcm_format_float, "0xda, 0x2a, 0x29, 0xb, 0x6c, 0x95, 0x94, 0xa0, 0x81, 0x9c, 0x62, 0x2b, 0x9a, 0x6d, 0xbd, 0x2f, 0x7, 0x44, 0xf9, 0x23, 0x30, 0xb6, 0x2e, 0x7b, 0xf0, 0x40, 0x53, 0x3e, 0x91, 0xb4, 0xef, 0x1f")
MAKE_THUNK(libasound, snd_pcm_format_little_endian, "0xfa, 0x25, 0x1c, 0xa0, 0x97, 0x61, 0xd8, 0xb1, 0xde, 0xc2, 0xb1, 0x18, 0x81, 0xbf, 0xf0, 0xb0, 0xb5, 0xf0, 0xbe, 0x88, 0x4b, 0xc6, 0x2a, 0x5d, 0xb6, 0xd, 0x89, 0xe6, 0x2, 0x75, 0x84, 0x4d")
MAKE_THUNK(libasound, snd_pcm_format_big_endian, "0x41, 0x7f, 0x98, 0x99, 0xc3, 0xee, 0xe8, 0x36, 0x92, 0xf4, 0xb9, 0x23, 0xd8, 0x6, 0x6f, 0x1d, 0x67, 0x55, 0x52, 0x2b, 0x34, 0x7f, 0xe2, 0x6f, 0x33, 0x56, 0x0, 0xe9, 0x37, 0x82, 0x22, 0x6a")
MAKE_THUNK(libasound, snd_pcm_format_cpu_endian, "0x54, 0xad, 0x18, 0x1d, 0xfd, 0xf1, 0x10, 0x7e, 0xf1, 0xe6, 0x8f, 0x5c, 0x70, 0x29, 0xa6, 0xc3, 0xfb, 0x83, 0x6, 0xfd, 0x15, 0xdb, 0xb9, 0xdc, 0x88, 0xc9, 0x56, 0x68, 0xbe, 0x9, 0x38, 0x78")
MAKE_THUNK(libasound, snd_pcm_format_width, "0x6, 0xac, 0x12, 0x40, 0x84, 0x1f, 0xd4, 0x10, 0x67, 0x6, 0xc0, 0x22, 0x44, 0x57, 0xd2, 0x86, 0x18, 0xd1, 0x84, 0xe9, 0xd2, 0x19, 0x5b, 0x9f, 0xdb, 0x7a, 0x4d, 0xc4, 0x16, 0x17, 0xee, 0x37")
MAKE_THUNK(libasound, snd_pcm_format_physical_width, "0xd1, 0x45, 0xc2, 0xe7, 0xb4, 0xeb, 0x79, 0x66, 0xf3, 0xfe, 0xad, 0x86, 0xf, 0xae, 0xae, 0xed, 0x8d, 0x1d, 0x4b, 0xf4, 0xe0, 0x72, 0xe4, 0x26, 0x1d, 0x72, 0x81, 0x75, 0x5f, 0x87, 0xd7, 0x62")
MAKE_THUNK(libasound, snd_pcm_build_linear_format, "0xbe, 0x84, 0x62, 0x3b, 0xfb, 0x47, 0x2f, 0x56, 0x12, 0xb8, 0x38, 0x73, 0x57, 0xf4, 0x99, 0x6, 0x26, 0xcd, 0x74, 0xf, 0x83, 0xc, 0x59, 0x2f, 0x4b, 0x8, 0x5d, 0x1d, 0x1e, 0xf6, 0x8e, 0x45")
MAKE_THUNK(libasound, snd_pcm_format_size, "0x5c, 0x7b, 0x9b, 0x85, 0x17, 0x9f, 0x12, 0xcf, 0x26, 0x1, 0x81, 0x73, 0x7a, 0x20, 0xca, 0xd8, 0xca, 0xb5, 0xf0, 0xac, 0xa, 0x9a, 0x59, 0xe5, 0xb4, 0x9b, 0xea, 0xcf, 0xd5, 0x8a, 0x1f, 0xab")
MAKE_THUNK(libasound, snd_pcm_format_silence, "0xae, 0xed, 0x50, 0x6f, 0x6a, 0x73, 0x62, 0xf8, 0x6f, 0x6a, 0x88, 0xc5, 0xd, 0xd9, 0x37, 0xd0, 0x15, 0xd7, 0x55, 0x33, 0x19, 0xd6, 0x46, 0xc9, 0x8, 0xd7, 0x3c, 0xbe, 0x45, 0x35, 0x83, 0xa4")
MAKE_THUNK(libasound, snd_pcm_format_silence_16, "0x6d, 0x4, 0x77, 0x53, 0xd6, 0xc7, 0x70, 0x3, 0x68, 0xd5, 0xb0, 0xd7, 0xc1, 0x4e, 0x44, 0x8e, 0xe2, 0xcc, 0x89, 0xbb, 0x0, 0xb5, 0x96, 0x67, 0x57, 0xa2, 0x3, 0x4, 0xfe, 0xb0, 0x87, 0x73")
MAKE_THUNK(libasound, snd_pcm_format_silence_32, "0xb1, 0x44, 0x52, 0x30, 0xc4, 0xd2, 0x6f, 0x95, 0xa, 0x6a, 0x0, 0x3b, 0x59, 0xce, 0x13, 0xd, 0x6d, 0xb1, 0xdf, 0xab, 0xc3, 0xa3, 0x39, 0xb5, 0x80, 0x89, 0xf1, 0x9d, 0x83, 0xc6, 0xc5, 0x9c")
MAKE_THUNK(libasound, snd_pcm_format_silence_64, "0x1b, 0x18, 0x9a, 0x7d, 0x4, 0xc1, 0x51, 0xea, 0xda, 0xe4, 0x6a, 0x15, 0x1b, 0xd9, 0x38, 0x77, 0x67, 0xf8, 0x98, 0x35, 0xaf, 0x3d, 0x3b, 0x66, 0x83, 0x31, 0xc5, 0xc8, 0xa6, 0x61, 0xa5, 0xad")
MAKE_THUNK(libasound, snd_pcm_format_set_silence, "0xd8, 0x96, 0xb3, 0x22, 0x5b, 0x7d, 0xd2, 0x9, 0x54, 0x2f, 0xee, 0xe6, 0x70, 0x7, 0x35, 0xf4, 0xad, 0x85, 0x6e, 0x96, 0x8d, 0x2a, 0x8e, 0x10, 0xdb, 0xbf, 0xff, 0x3a, 0x72, 0x16, 0x3f, 0x41")
MAKE_THUNK(libasound, snd_pcm_bytes_to_frames, "0x1c, 0x88, 0x27, 0xa4, 0xb2, 0x40, 0x85, 0xc3, 0x1d, 0xc1, 0x85, 0xf5, 0x8, 0x87, 0x7b, 0x4a, 0x43, 0x2d, 0x9a, 0xc1, 0x9c, 0x8, 0xde, 0x41, 0xac, 0x2f, 0x25, 0x6f, 0xa, 0xf8, 0x9b, 0x6b")
MAKE_THUNK(libasound, snd_pcm_frames_to_bytes, "0x8f, 0x61, 0x7e, 0x1a, 0xb4, 0x9, 0x84, 0x78, 0xa3, 0x34, 0x98, 0x9a, 0x6f, 0x9, 0xc1, 0x35, 0x68, 0x6b, 0xf3, 0x1d, 0x63, 0xac, 0x6c, 0xa4, 0x6c, 0x4f, 0x3c, 0xb7, 0xc1, 0xf3, 0x80, 0x9e")
MAKE_THUNK(libasound, snd_pcm_bytes_to_samples, "0x6c, 0x34, 0xfb, 0xd6, 0x5b, 0x27, 0x9d, 0x8, 0x11, 0x43, 0xec, 0xfb, 0xe4, 0x79, 0x13, 0x52, 0xcd, 0xc3, 0xbe, 0x4, 0xb0, 0xf1, 0xd9, 0xaa, 0xd0, 0xd8, 0x2a, 0x7f, 0x96, 0x4, 0xa3, 0xf6")
MAKE_THUNK(libasound, snd_pcm_samples_to_bytes, "0x82, 0x8, 0xa3, 0x86, 0x16, 0x9f, 0xd8, 0x35, 0x83, 0x62, 0xe1, 0x80, 0x4, 0xfa, 0xfe, 0xa7, 0x80, 0xa2, 0x9d, 0x86, 0x98, 0x9d, 0x6b, 0x3b, 0x8, 0x68, 0x7a, 0xf3, 0xd3, 0xd, 0xbf, 0xc9")
MAKE_THUNK(libasound, snd_pcm_area_silence, "0xa7, 0x4a, 0xb5, 0x7f, 0x5a, 0xb8, 0xb1, 0xb2, 0x36, 0xd6, 0xf4, 0x3f, 0xe8, 0x1c, 0x25, 0x5b, 0xe5, 0xfa, 0x2a, 0x56, 0xe7, 0xa4, 0xf8, 0x81, 0x26, 0x45, 0xa1, 0xd0, 0x3b, 0xaa, 0x7c, 0x76")
MAKE_THUNK(libasound, snd_pcm_areas_silence, "0x19, 0x54, 0x60, 0xda, 0x9e, 0xdb, 0x66, 0xc7, 0xcf, 0x62, 0x95, 0x95, 0x71, 0x8e, 0xb1, 0xbe, 0x47, 0x5f, 0xe1, 0x3d, 0xbc, 0x2b, 0x26, 0x8b, 0x8d, 0x74, 0x7e, 0x0, 0xa5, 0x2e, 0xd9, 0x10")
MAKE_THUNK(libasound, snd_pcm_area_copy, "0xd8, 0xe8, 0xc2, 0x6, 0x99, 0x8e, 0x5f, 0xba, 0x85, 0x7f, 0xb1, 0x8b, 0x42, 0x59, 0x48, 0x0, 0x1e, 0x20, 0x8e, 0xcc, 0x42, 0xa5, 0x31, 0x14, 0xa4, 0x43, 0xd6, 0x53, 0xf5, 0x61, 0x51, 0x10")
MAKE_THUNK(libasound, snd_pcm_areas_copy, "0x8, 0x5a, 0xd7, 0x83, 0x30, 0x5a, 0xe3, 0x7f, 0x55, 0xf7, 0xde, 0x16, 0x4b, 0xf7, 0xa7, 0xbb, 0xe2, 0xff, 0xc5, 0xf0, 0xeb, 0x29, 0x6e, 0xd6, 0x98, 0x54, 0x48, 0x2d, 0x93, 0x1a, 0x3a, 0x97")
MAKE_THUNK(libasound, snd_pcm_meter_get_bufsize, "0xf6, 0x12, 0xff, 0x75, 0x91, 0xe, 0x22, 0x2b, 0xeb, 0xe4, 0xf2, 0x36, 0x73, 0xc8, 0x32, 0x5b, 0x58, 0x9f, 0x85, 0xc6, 0xfc, 0x88, 0xef, 0xa8, 0xf0, 0x72, 0x9b, 0xfc, 0x7e, 0xc4, 0x0, 0x1e")
MAKE_THUNK(libasound, snd_pcm_meter_get_channels, "0x68, 0x66, 0x2a, 0xf3, 0xb6, 0x1a, 0x0, 0x95, 0x55, 0x6b, 0x99, 0xfe, 0xef, 0x5d, 0xf9, 0x20, 0x58, 0xca, 0xa7, 0xf5, 0x44, 0x3, 0xea, 0xc2, 0xb8, 0x6d, 0xed, 0x11, 0xa, 0x5e, 0x5, 0x7")
MAKE_THUNK(libasound, snd_pcm_meter_get_rate, "0x85, 0xb9, 0x55, 0x6d, 0x12, 0x7d, 0xdd, 0xca, 0x1f, 0x47, 0xdb, 0x89, 0xf2, 0xd7, 0x64, 0x22, 0x6a, 0x3, 0x13, 0x4b, 0x55, 0x45, 0xd4, 0xab, 0xe0, 0xaa, 0x4c, 0xe2, 0x62, 0xe5, 0xea, 0x7")
MAKE_THUNK(libasound, snd_pcm_meter_get_now, "0x3d, 0x8, 0xaa, 0x5a, 0x2e, 0x5f, 0xce, 0xaf, 0x2b, 0xdc, 0x65, 0x9, 0x2d, 0xff, 0x60, 0xc5, 0x0, 0x97, 0x30, 0xcd, 0x7c, 0x2e, 0x47, 0x5e, 0xde, 0x9, 0xf4, 0x7d, 0xe9, 0xf0, 0x4e, 0xc7")
MAKE_THUNK(libasound, snd_pcm_meter_get_boundary, "0x78, 0x65, 0x82, 0x18, 0x9c, 0x99, 0x46, 0x26, 0xbf, 0x97, 0x34, 0x9e, 0x2, 0x37, 0x3e, 0xca, 0xa1, 0x61, 0x5, 0x1e, 0x54, 0xd, 0x9e, 0x5b, 0x58, 0xc7, 0x86, 0xab, 0x98, 0x62, 0x21, 0x46")
MAKE_THUNK(libasound, snd_pcm_meter_add_scope, "0xce, 0xfb, 0x68, 0x76, 0xa8, 0x30, 0x5b, 0xd1, 0x58, 0xcf, 0x2e, 0x74, 0x88, 0xb, 0x92, 0x33, 0xef, 0x47, 0x89, 0x55, 0x79, 0xa6, 0xb2, 0xec, 0xbf, 0xf9, 0x4c, 0x8a, 0xd4, 0x4f, 0x84, 0xb0")
MAKE_THUNK(libasound, snd_pcm_meter_search_scope, "0xec, 0x65, 0xc2, 0x2e, 0xaa, 0x8e, 0x2b, 0x77, 0xd0, 0x3a, 0xa7, 0x59, 0xfd, 0xb9, 0xe6, 0x63, 0x59, 0xf7, 0x31, 0x24, 0x8, 0xca, 0x48, 0xe1, 0xef, 0x6, 0x20, 0x4b, 0xbe, 0xd1, 0xae, 0xfb")
MAKE_THUNK(libasound, snd_pcm_scope_malloc, "0xda, 0xd7, 0x76, 0x0, 0x5b, 0xbe, 0x0, 0xf4, 0xca, 0x66, 0xa8, 0x22, 0x16, 0x76, 0x82, 0xc6, 0x51, 0xc8, 0xf, 0xcc, 0x0, 0xf5, 0x7c, 0x44, 0xb8, 0xb5, 0xa2, 0xe0, 0xcb, 0x1d, 0x5d, 0xb9")
MAKE_THUNK(libasound, snd_pcm_scope_set_ops, "0x82, 0xf7, 0xa1, 0xad, 0xf9, 0x60, 0x49, 0xa5, 0xd1, 0xa8, 0xc9, 0x6d, 0xb2, 0xa, 0xc3, 0x15, 0xa0, 0xa6, 0xfa, 0xd9, 0xa3, 0x44, 0x71, 0x67, 0xc5, 0x1e, 0xaf, 0x2d, 0x7a, 0x4, 0x5b, 0xb5")
MAKE_THUNK(libasound, snd_pcm_scope_set_name, "0xe2, 0xd0, 0x48, 0x7d, 0x22, 0x3b, 0x58, 0xa2, 0x19, 0xb, 0x21, 0x57, 0xde, 0x5f, 0x17, 0x1, 0xdd, 0x5e, 0xc6, 0xb0, 0x63, 0x8b, 0x38, 0xd6, 0xa, 0x87, 0x24, 0x98, 0x76, 0x43, 0xed, 0xad")
MAKE_THUNK(libasound, snd_pcm_scope_get_name, "0x43, 0x5b, 0x8b, 0x5e, 0x8c, 0xbb, 0xdf, 0x2, 0x5a, 0xd6, 0x3a, 0xb8, 0x1b, 0x5d, 0x5b, 0xb4, 0x77, 0x4f, 0x63, 0xa0, 0x2b, 0xc, 0xeb, 0xc, 0xe8, 0x86, 0xe3, 0x8a, 0x7a, 0x59, 0x88, 0xea")
MAKE_THUNK(libasound, snd_pcm_scope_get_callback_private, "0x71, 0xac, 0xc3, 0x44, 0x7c, 0xdd, 0xf8, 0x8e, 0xb, 0xe2, 0x76, 0xca, 0x1d, 0xd5, 0x4f, 0xae, 0x34, 0x58, 0x79, 0x85, 0xd5, 0x6e, 0x85, 0x53, 0x30, 0xd2, 0x8d, 0x7f, 0x10, 0x46, 0xe3, 0x96")
MAKE_THUNK(libasound, snd_pcm_scope_set_callback_private, "0xc3, 0x42, 0xe0, 0x81, 0x6f, 0xf3, 0xfb, 0xe7, 0xfd, 0x0, 0x39, 0x29, 0xc1, 0xbf, 0x97, 0xf3, 0x52, 0xc3, 0xef, 0xd1, 0x97, 0xe3, 0xbc, 0x33, 0x26, 0x83, 0x82, 0xe, 0x92, 0xf3, 0x7d, 0x7")
MAKE_THUNK(libasound, snd_pcm_scope_s16_open, "0x36, 0xcb, 0xc3, 0x81, 0x4a, 0x1b, 0x63, 0x3b, 0x14, 0xb0, 0x51, 0x99, 0x4e, 0xa9, 0x1e, 0x31, 0xca, 0x2e, 0xda, 0xa, 0xe4, 0xd, 0xfd, 0xf3, 0x3c, 0x68, 0xd8, 0x26, 0xdd, 0xc8, 0x7f, 0x35")
MAKE_THUNK(libasound, snd_pcm_scope_s16_get_channel_buffer, "0xf8, 0x72, 0x34, 0x40, 0xf3, 0xe1, 0x9e, 0x75, 0x68, 0x2d, 0x5e, 0x26, 0x3d, 0xca, 0x3c, 0xff, 0x85, 0x2c, 0x47, 0x13, 0xe7, 0x88, 0x5c, 0x9c, 0xf9, 0x77, 0x2a, 0x28, 0x46, 0xd, 0x15, 0x2f")
MAKE_THUNK(libasound, snd_spcm_init, "0xa8, 0x8e, 0x93, 0x7d, 0x61, 0x3b, 0xac, 0x40, 0x8e, 0xe6, 0x1e, 0x4e, 0xd8, 0xad, 0x43, 0x52, 0x43, 0x9b, 0x7a, 0x1f, 0xc0, 0x54, 0x5d, 0x5, 0x54, 0x79, 0x9, 0x79, 0x62, 0x3b, 0x58, 0x7c")
MAKE_THUNK(libasound, snd_spcm_init_duplex, "0x88, 0xfb, 0xcf, 0x80, 0x26, 0x98, 0xb6, 0x6d, 0x80, 0x46, 0xf, 0x81, 0x40, 0xb8, 0xdc, 0x2, 0x83, 0x88, 0xb, 0xad, 0xc7, 0x9e, 0x50, 0x1c, 0xaf, 0xc8, 0xb7, 0x17, 0xd1, 0x87, 0xe9, 0xf9")
MAKE_THUNK(libasound, snd_spcm_init_get_params, "0xdc, 0xd3, 0x3a, 0xbe, 0xa9, 0xd, 0x79, 0x9f, 0xb2, 0x57, 0x35, 0xfc, 0x86, 0xb6, 0xd0, 0x46, 0xd2, 0xe7, 0x54, 0x69, 0x5f, 0xae, 0x42, 0x43, 0x4, 0x19, 0xa3, 0x5a, 0x6b, 0x5, 0x50, 0x8a")
MAKE_THUNK(libasound, snd_rawmidi_open, "0x67, 0x13, 0x61, 0xbf, 0xbb, 0x60, 0x1f, 0xb0, 0xe3, 0x88, 0x2f, 0x51, 0xef, 0x8e, 0xdc, 0xd1, 0x57, 0xd4, 0xd, 0xfa, 0x31, 0x55, 0xb0, 0x2a, 0x7a, 0x80, 0x5c, 0x9d, 0xf0, 0x8e, 0xd0, 0x62")
MAKE_THUNK(libasound, snd_rawmidi_open_lconf, "0xdf, 0xa4, 0x1b, 0x50, 0x99, 0xeb, 0x74, 0x7e, 0x93, 0xc5, 0x63, 0x6f, 0x38, 0xda, 0xad, 0x82, 0xe8, 0x2c, 0x60, 0x1c, 0x34, 0x33, 0xd2, 0xa7, 0x37, 0xa0, 0x7f, 0x1a, 0x7d, 0x45, 0x5a, 0x18")
MAKE_THUNK(libasound, snd_rawmidi_close, "0xbe, 0x51, 0x21, 0x5b, 0xc1, 0xb4, 0x15, 0xa6, 0xe, 0x93, 0x6e, 0xab, 0x37, 0x13, 0x49, 0x7f, 0x6, 0xc5, 0x17, 0x8c, 0x81, 0x21, 0x93, 0x41, 0x4e, 0xf4, 0xb9, 0xeb, 0xd8, 0xde, 0xe1, 0x7")
MAKE_THUNK(libasound, snd_rawmidi_poll_descriptors_count, "0xbe, 0xf, 0x78, 0xd8, 0x7f, 0x5, 0xa2, 0xb, 0x1d, 0x87, 0xc8, 0x7d, 0xd5, 0x61, 0xe2, 0x69, 0x69, 0x82, 0xbd, 0x2b, 0x6c, 0xb9, 0xd0, 0xee, 0x88, 0x10, 0x5e, 0x2e, 0x93, 0xad, 0x92, 0x80")
MAKE_THUNK(libasound, snd_rawmidi_poll_descriptors, "0x79, 0xcf, 0xc, 0xba, 0x28, 0xc, 0x7a, 0x13, 0xd1, 0xb5, 0xd7, 0xdb, 0x32, 0xbc, 0xec, 0x5a, 0x54, 0x89, 0x1e, 0x98, 0x8f, 0x5b, 0x4d, 0x45, 0x6a, 0x10, 0x3c, 0xda, 0xc5, 0x3c, 0x9f, 0xd9")
MAKE_THUNK(libasound, snd_rawmidi_poll_descriptors_revents, "0xda, 0x7, 0x6, 0xae, 0xd3, 0xb7, 0xa5, 0x2f, 0x99, 0xe7, 0xa0, 0xe3, 0xae, 0xa2, 0xfb, 0xbd, 0x50, 0x77, 0x56, 0x26, 0xa, 0xdb, 0xd9, 0x12, 0xe6, 0x23, 0xf7, 0xca, 0x85, 0x31, 0xb3, 0xbf")
MAKE_THUNK(libasound, snd_rawmidi_nonblock, "0xb7, 0xae, 0x9d, 0xdc, 0xb3, 0xec, 0x40, 0x28, 0x6e, 0x9b, 0x1c, 0xc9, 0x8b, 0x9f, 0x31, 0x4a, 0x19, 0xe8, 0xb4, 0xf4, 0x2f, 0x87, 0xbb, 0x18, 0x41, 0xf2, 0x33, 0x4a, 0x51, 0x26, 0xd2, 0xf")
MAKE_THUNK(libasound, snd_rawmidi_info_sizeof, "0xfa, 0x79, 0x43, 0xbe, 0x51, 0x3e, 0xe3, 0x18, 0x4b, 0xa3, 0x29, 0x1a, 0x43, 0xb1, 0xe9, 0x61, 0xd7, 0xf5, 0x9f, 0xbb, 0xb2, 0x23, 0x43, 0x14, 0xef, 0x46, 0x69, 0x78, 0x29, 0xaa, 0x7b, 0xc8")
MAKE_THUNK(libasound, snd_rawmidi_info_malloc, "0x13, 0x33, 0x95, 0xe7, 0x60, 0xee, 0xda, 0x79, 0x63, 0x13, 0xce, 0xf, 0x9a, 0x18, 0x85, 0xfd, 0x64, 0x39, 0x94, 0xe0, 0xed, 0x12, 0x17, 0x29, 0x58, 0xec, 0x53, 0xd3, 0xc3, 0xd7, 0xca, 0xa3")
MAKE_THUNK(libasound, snd_rawmidi_info_free, "0x35, 0x81, 0x8a, 0xaf, 0x2, 0xae, 0xe1, 0x2, 0x22, 0xd4, 0x64, 0x82, 0x72, 0x95, 0xeb, 0x4a, 0x83, 0x99, 0x7e, 0x85, 0x10, 0xbc, 0xd, 0x2f, 0x3, 0x4b, 0x5e, 0x51, 0x69, 0x91, 0x7a, 0x72")
MAKE_THUNK(libasound, snd_rawmidi_info_copy, "0xb4, 0x30, 0xff, 0x11, 0x27, 0x71, 0x41, 0x25, 0xc0, 0x7f, 0xbb, 0x95, 0xbe, 0x44, 0x45, 0x14, 0x8, 0x50, 0xb3, 0xde, 0xed, 0x92, 0x61, 0x2, 0xdd, 0x68, 0xed, 0x71, 0x16, 0xd2, 0x1b, 0xd9")
MAKE_THUNK(libasound, snd_rawmidi_info_get_device, "0xd0, 0xb9, 0x5e, 0x2a, 0xa1, 0xf6, 0x1f, 0x56, 0xfb, 0x87, 0xe7, 0x43, 0xb0, 0x9, 0xf0, 0x4, 0x9f, 0x45, 0x10, 0x33, 0x32, 0xc0, 0x4b, 0x79, 0xcd, 0xc, 0xf9, 0x88, 0xdb, 0xf5, 0x65, 0x36")
MAKE_THUNK(libasound, snd_rawmidi_info_get_subdevice, "0x4e, 0x63, 0xc7, 0xd4, 0x9e, 0xc, 0xf9, 0xa5, 0xd8, 0x7e, 0x26, 0xe3, 0x45, 0xd, 0x73, 0xd3, 0xaf, 0x41, 0xeb, 0x8b, 0x8c, 0x2c, 0x2a, 0x1b, 0xa0, 0x74, 0x35, 0x6d, 0x1, 0x98, 0x3b, 0x84")
MAKE_THUNK(libasound, snd_rawmidi_info_get_stream, "0xec, 0x1b, 0x81, 0x1f, 0x33, 0x14, 0x4, 0xb2, 0xe4, 0xc5, 0x21, 0xb, 0xcc, 0x8, 0x1b, 0x57, 0xf5, 0x33, 0x6e, 0x6c, 0xaa, 0x38, 0x85, 0xb, 0x9e, 0xa5, 0x79, 0x39, 0x4c, 0x23, 0xde, 0xcb")
MAKE_THUNK(libasound, snd_rawmidi_info_get_card, "0x22, 0x21, 0xe3, 0xe, 0xfb, 0x3f, 0x87, 0xe8, 0x94, 0x90, 0xd7, 0x3b, 0x22, 0xbe, 0xbe, 0xca, 0x9c, 0x45, 0xc7, 0x8f, 0x93, 0x55, 0x98, 0xe5, 0x44, 0x69, 0xc, 0x5b, 0x1d, 0x71, 0x3c, 0xcb")
MAKE_THUNK(libasound, snd_rawmidi_info_get_flags, "0x92, 0x30, 0x2f, 0x44, 0x72, 0x66, 0x3f, 0x59, 0xdc, 0xba, 0x2b, 0x28, 0x28, 0x1e, 0x6e, 0x8, 0xb1, 0x12, 0x62, 0x45, 0xb6, 0x4c, 0xb4, 0xaf, 0x2, 0xd5, 0x65, 0x51, 0x53, 0x5f, 0x3d, 0xc6")
MAKE_THUNK(libasound, snd_rawmidi_info_get_id, "0x24, 0x38, 0x46, 0xc7, 0x16, 0xb6, 0x22, 0x7, 0x5a, 0x55, 0x23, 0xcd, 0x77, 0x44, 0x1a, 0x15, 0x7d, 0x4a, 0x82, 0xad, 0x49, 0x69, 0x1e, 0x2f, 0xe7, 0xb1, 0x89, 0x6d, 0x4e, 0x47, 0x40, 0x9d")
MAKE_THUNK(libasound, snd_rawmidi_info_get_name, "0x5d, 0xb, 0x69, 0x52, 0x88, 0xe0, 0x70, 0x78, 0x93, 0xfc, 0x8d, 0xb5, 0xd4, 0xb7, 0x53, 0x48, 0xa4, 0xd1, 0x27, 0x4e, 0xd8, 0x65, 0xbd, 0x24, 0x2a, 0xeb, 0x90, 0xc4, 0x9f, 0x17, 0x9c, 0xee")
MAKE_THUNK(libasound, snd_rawmidi_info_get_subdevice_name, "0xa6, 0xb2, 0xea, 0x9b, 0x27, 0xaf, 0x27, 0x4b, 0xe, 0x15, 0x13, 0x92, 0x9d, 0x65, 0x34, 0xfe, 0x27, 0xea, 0xe5, 0x7a, 0xc2, 0xfc, 0xe8, 0xa9, 0x5c, 0xd1, 0x88, 0xb6, 0xb0, 0xbc, 0xa0, 0x69")
MAKE_THUNK(libasound, snd_rawmidi_info_get_subdevices_count, "0x1e, 0xa6, 0x77, 0x60, 0xb8, 0x76, 0xb5, 0x7e, 0x56, 0xc9, 0xf1, 0xca, 0x5b, 0x18, 0xdb, 0x89, 0x8e, 0xc1, 0x92, 0x3e, 0xd8, 0x60, 0xcf, 0xc8, 0xbb, 0xad, 0x84, 0x62, 0x14, 0xb9, 0x1f, 0x15")
MAKE_THUNK(libasound, snd_rawmidi_info_get_subdevices_avail, "0xeb, 0x9a, 0x3a, 0x7, 0x9c, 0xb2, 0x5b, 0x91, 0x80, 0x91, 0xd0, 0xac, 0x7d, 0xc9, 0x74, 0xb3, 0x2a, 0xbe, 0x76, 0xb9, 0x5c, 0x26, 0xda, 0x27, 0x2, 0x81, 0x4d, 0x35, 0xfe, 0xc9, 0xc7, 0x8a")
MAKE_THUNK(libasound, snd_rawmidi_info_set_device, "0x33, 0xde, 0x23, 0x9e, 0x59, 0xdb, 0x1c, 0xeb, 0x22, 0x8e, 0x78, 0xe1, 0xf3, 0x16, 0x26, 0x5a, 0xc, 0x3, 0xab, 0xcd, 0x11, 0x1b, 0x1b, 0x8a, 0xc4, 0xd6, 0x37, 0x22, 0xf2, 0x92, 0xe1, 0x18")
MAKE_THUNK(libasound, snd_rawmidi_info_set_subdevice, "0x10, 0xa3, 0xc1, 0x76, 0x43, 0xbb, 0x7a, 0x6d, 0xd0, 0xbf, 0x44, 0xf1, 0x70, 0x87, 0x80, 0xf7, 0xa1, 0x9c, 0xdf, 0x91, 0x5f, 0xd3, 0x1e, 0x1b, 0xdc, 0x1, 0x4a, 0xff, 0x19, 0x5b, 0xfe, 0xda")
MAKE_THUNK(libasound, snd_rawmidi_info_set_stream, "0x4a, 0x7e, 0x69, 0x2e, 0x27, 0xd6, 0xfa, 0x81, 0x9a, 0xa9, 0x9d, 0xa1, 0x4f, 0x11, 0xa2, 0x3c, 0x39, 0x26, 0xf0, 0xef, 0x6f, 0xad, 0xc1, 0xa8, 0x3d, 0xde, 0x8a, 0x37, 0x29, 0xb0, 0xe5, 0xe4")
MAKE_THUNK(libasound, snd_rawmidi_info, "0x3, 0x28, 0xa1, 0x81, 0x36, 0xf4, 0x81, 0x87, 0x1, 0x45, 0x51, 0x15, 0x62, 0x32, 0xa7, 0x63, 0xcb, 0x37, 0x5e, 0xbc, 0xc7, 0x1c, 0x87, 0x4e, 0xce, 0x71, 0xa8, 0x53, 0x50, 0x7c, 0x5a, 0xd5")
MAKE_THUNK(libasound, snd_rawmidi_params_sizeof, "0x26, 0xca, 0xd0, 0x8b, 0xef, 0x10, 0x9b, 0x41, 0x47, 0xf1, 0xff, 0x7c, 0x49, 0xbe, 0x22, 0x25, 0xcb, 0xa5, 0x29, 0x41, 0x1c, 0x16, 0x6d, 0xb4, 0xe7, 0xed, 0x35, 0x47, 0x3c, 0x76, 0xbe, 0xdd")
MAKE_THUNK(libasound, snd_rawmidi_params_malloc, "0x42, 0x5e, 0xfb, 0x91, 0xb8, 0xfe, 0x79, 0x27, 0x7f, 0x1b, 0xce, 0x56, 0xed, 0x1b, 0xc9, 0x5, 0xe9, 0x5a, 0xea, 0x39, 0xa, 0xb0, 0x46, 0xc5, 0x59, 0x3a, 0xa3, 0x25, 0xb2, 0xa5, 0x21, 0xf7")
MAKE_THUNK(libasound, snd_rawmidi_params_free, "0xde, 0xb7, 0xcd, 0xf1, 0x32, 0x64, 0x63, 0x32, 0xa9, 0xdb, 0xc4, 0xdc, 0x7f, 0x2b, 0xc1, 0x84, 0xff, 0x32, 0xcc, 0xcb, 0xd0, 0x95, 0x89, 0x26, 0xe2, 0xb0, 0x6f, 0x2d, 0x63, 0x8f, 0xe9, 0x33")
MAKE_THUNK(libasound, snd_rawmidi_params_copy, "0x73, 0xcf, 0x9a, 0xde, 0xa9, 0xe7, 0xa4, 0x12, 0x73, 0x71, 0xda, 0x59, 0x10, 0x2c, 0x8, 0xa7, 0x7c, 0x53, 0x8f, 0x47, 0x22, 0x3e, 0xa0, 0xf0, 0x43, 0x13, 0x74, 0xcc, 0xe6, 0xd8, 0xba, 0xa7")
MAKE_THUNK(libasound, snd_rawmidi_params_set_buffer_size, "0xc, 0xa8, 0x9, 0x17, 0x10, 0xe8, 0x23, 0x9a, 0x5b, 0x9f, 0x27, 0xac, 0x56, 0xc5, 0xb1, 0x78, 0x70, 0xa, 0x8c, 0x22, 0xfe, 0x80, 0x79, 0xad, 0xe2, 0x8c, 0x71, 0x24, 0xcb, 0x88, 0x2c, 0xb7")
MAKE_THUNK(libasound, snd_rawmidi_params_get_buffer_size, "0xc7, 0x16, 0x2a, 0x7e, 0x4f, 0x51, 0x21, 0x9b, 0xcf, 0x58, 0x7b, 0xb5, 0xb6, 0x14, 0xa4, 0xf, 0x73, 0xbc, 0x15, 0x8a, 0x9a, 0x71, 0x56, 0xc1, 0x44, 0x70, 0xa5, 0xe0, 0xbe, 0x12, 0x41, 0x40")
MAKE_THUNK(libasound, snd_rawmidi_params_set_avail_min, "0x8c, 0x66, 0x1, 0xb, 0x1d, 0xf9, 0xb1, 0x9b, 0x2a, 0x9f, 0xd2, 0x75, 0x41, 0x8c, 0x8c, 0x9e, 0x6b, 0xb8, 0xea, 0xd4, 0x4f, 0x74, 0xc6, 0xa5, 0x1a, 0x60, 0x97, 0x59, 0xbb, 0xd5, 0x64, 0x9c")
MAKE_THUNK(libasound, snd_rawmidi_params_get_avail_min, "0x9, 0xfe, 0xca, 0xaf, 0xe2, 0xb9, 0xe2, 0x8, 0x99, 0x41, 0x68, 0xb9, 0xb5, 0x5c, 0xbe, 0x35, 0xaa, 0xa9, 0xf8, 0xca, 0xb8, 0xf5, 0x89, 0x23, 0x3f, 0xc9, 0xbe, 0x67, 0x44, 0xdb, 0x52, 0xdf")
MAKE_THUNK(libasound, snd_rawmidi_params_set_no_active_sensing, "0x49, 0x1d, 0x94, 0x59, 0xb8, 0xfe, 0xbf, 0x4f, 0x1d, 0xa8, 0xaf, 0x9d, 0xe, 0x7f, 0x94, 0xde, 0x9e, 0x1e, 0xbe, 0x59, 0xef, 0x32, 0xc0, 0x8d, 0x78, 0xbe, 0x89, 0x72, 0x72, 0x5d, 0x57, 0xb3")
MAKE_THUNK(libasound, snd_rawmidi_params_get_no_active_sensing, "0x78, 0x29, 0xc7, 0xfd, 0x4e, 0x3f, 0xc8, 0xc6, 0xd1, 0xb8, 0x44, 0xe1, 0x37, 0xb2, 0x49, 0x49, 0xd8, 0x82, 0x97, 0x3, 0x40, 0x55, 0x8a, 0xe9, 0xd8, 0x84, 0x7e, 0xaa, 0xe1, 0xfa, 0xdd, 0xb1")
MAKE_THUNK(libasound, snd_rawmidi_params, "0x34, 0x17, 0xa0, 0xb5, 0xda, 0x80, 0x46, 0xa2, 0x8f, 0x56, 0xc5, 0xe3, 0xc7, 0xfb, 0xb, 0xb9, 0xab, 0x3a, 0xce, 0xaa, 0x1, 0xf, 0x59, 0x16, 0xd0, 0x7f, 0x7a, 0x62, 0x84, 0x2b, 0xb0, 0x8d")
MAKE_THUNK(libasound, snd_rawmidi_params_current, "0xe6, 0x1f, 0xf5, 0xf4, 0xf9, 0xc9, 0xbe, 0xa6, 0x7a, 0x88, 0x6a, 0x47, 0x36, 0x1a, 0x1, 0x28, 0xfd, 0xd3, 0x2f, 0x4b, 0x19, 0x65, 0x6e, 0x76, 0x2a, 0xb1, 0x33, 0x28, 0x2, 0xe4, 0x2, 0x19")
MAKE_THUNK(libasound, snd_rawmidi_status_sizeof, "0x53, 0x1c, 0x8b, 0xb4, 0xed, 0x35, 0xfc, 0x36, 0x9c, 0x48, 0x85, 0xf2, 0x35, 0xd9, 0x9d, 0xf4, 0x9a, 0x7b, 0x53, 0x21, 0xc6, 0xda, 0x25, 0x6e, 0x66, 0xb3, 0x1, 0xac, 0x4f, 0xa8, 0xaa, 0xfa")
MAKE_THUNK(libasound, snd_rawmidi_status_malloc, "0xa, 0x5b, 0x4, 0x8f, 0x5b, 0x23, 0xa, 0xff, 0x59, 0x86, 0xc2, 0x6d, 0xcd, 0xc1, 0xa2, 0x8b, 0xf3, 0x62, 0xe, 0x61, 0x34, 0xea, 0x87, 0x15, 0x30, 0x90, 0x1a, 0xf2, 0x1f, 0xda, 0x44, 0x83")
MAKE_THUNK(libasound, snd_rawmidi_status_free, "0xb9, 0x3, 0x95, 0xc9, 0x55, 0x49, 0x80, 0x3f, 0x4, 0x5, 0xc9, 0x15, 0x4, 0xbc, 0x12, 0xda, 0x3a, 0x59, 0xcc, 0x4e, 0x97, 0x24, 0x46, 0x9d, 0x6, 0xd5, 0xfc, 0x7, 0xda, 0xb4, 0x5c, 0x3b")
MAKE_THUNK(libasound, snd_rawmidi_status_copy, "0x12, 0xfb, 0x73, 0x64, 0x4b, 0x5, 0xd9, 0x96, 0x1a, 0xbc, 0x69, 0xa3, 0xe6, 0x37, 0x19, 0x3d, 0xe0, 0x77, 0xd, 0xb1, 0xf7, 0xf9, 0x14, 0xdc, 0x15, 0x7c, 0x2e, 0xfd, 0x4c, 0xf1, 0x18, 0xa0")
MAKE_THUNK(libasound, snd_rawmidi_status_get_tstamp, "0x5a, 0x39, 0xd, 0xe8, 0x5c, 0xaf, 0x11, 0x56, 0xee, 0x93, 0xc9, 0xbb, 0x6b, 0x2, 0xe9, 0x70, 0x3e, 0x1f, 0xed, 0x70, 0x9c, 0x6d, 0x57, 0x2d, 0x79, 0x1a, 0x89, 0x3a, 0x7f, 0x1a, 0x90, 0xa0")
MAKE_THUNK(libasound, snd_rawmidi_status_get_avail, "0xcc, 0xe5, 0xa7, 0xaf, 0x67, 0x4c, 0xbc, 0x78, 0x57, 0xd4, 0x1b, 0xf5, 0x38, 0x14, 0x4b, 0x5f, 0x2, 0x63, 0x1, 0x1b, 0x4e, 0xe6, 0x63, 0x3, 0x71, 0x12, 0xb2, 0x2d, 0x29, 0x7a, 0xd7, 0x4f")
MAKE_THUNK(libasound, snd_rawmidi_status_get_xruns, "0x10, 0xf7, 0xee, 0x6d, 0x2c, 0x45, 0xbe, 0xbf, 0x62, 0xfb, 0x2, 0x14, 0x4d, 0x2b, 0x17, 0xe7, 0x64, 0x25, 0x57, 0xed, 0x74, 0xef, 0x4a, 0xe9, 0xce, 0xbf, 0x3e, 0x5d, 0x88, 0xdb, 0x70, 0xca")
MAKE_THUNK(libasound, snd_rawmidi_status, "0x15, 0x40, 0xc1, 0xc1, 0x44, 0xf9, 0xcb, 0xe4, 0xf0, 0x81, 0xc5, 0x72, 0x72, 0x4a, 0x44, 0x97, 0xcd, 0x47, 0x92, 0x3b, 0x64, 0x10, 0x22, 0x44, 0x5c, 0x89, 0x2a, 0x45, 0x34, 0x2c, 0x7, 0x64")
MAKE_THUNK(libasound, snd_rawmidi_drain, "0x8f, 0x31, 0x3c, 0x35, 0x5f, 0xe1, 0x4c, 0x13, 0xcc, 0x4a, 0x72, 0x36, 0x9a, 0x88, 0x77, 0xeb, 0x62, 0x6a, 0xba, 0xc0, 0xe1, 0x42, 0x13, 0xd6, 0xdd, 0xdd, 0xa, 0x1a, 0x0, 0xfb, 0xa9, 0x9a")
MAKE_THUNK(libasound, snd_rawmidi_drop, "0x7d, 0xae, 0x1a, 0xe4, 0x66, 0xa0, 0x3d, 0x87, 0x5e, 0xdf, 0x54, 0xed, 0x18, 0x6b, 0x9, 0xab, 0x9b, 0x9a, 0x9b, 0x83, 0x86, 0x66, 0x5a, 0xf5, 0xe2, 0x77, 0x1e, 0xe9, 0x39, 0xce, 0xf9, 0xe")
MAKE_THUNK(libasound, snd_rawmidi_write, "0x1c, 0xa, 0x7f, 0xb, 0xbc, 0x4f, 0x15, 0x56, 0x2c, 0xb4, 0x15, 0xa3, 0x2a, 0xb4, 0xab, 0x48, 0xc2, 0xc, 0xa, 0x29, 0x22, 0x42, 0x3, 0x34, 0x18, 0xa, 0x22, 0xc0, 0x41, 0x89, 0xd8, 0x62")
MAKE_THUNK(libasound, snd_rawmidi_read, "0x48, 0x7e, 0xbd, 0x91, 0xd1, 0xb, 0x90, 0x62, 0xc8, 0x93, 0xf1, 0x62, 0x21, 0xfc, 0xca, 0xe6, 0x50, 0xb6, 0xe6, 0x1, 0x2c, 0x1, 0x5b, 0x82, 0x3d, 0x3c, 0x50, 0x54, 0x30, 0x21, 0x2, 0x25")
MAKE_THUNK(libasound, snd_rawmidi_name, "0x4f, 0x4d, 0x2a, 0x17, 0xb7, 0x3, 0xd6, 0xff, 0xff, 0xbb, 0xee, 0xab, 0x68, 0xdc, 0x41, 0x22, 0x5a, 0xd9, 0x80, 0x94, 0x10, 0x1b, 0x73, 0x6c, 0x27, 0xe3, 0xb2, 0x13, 0x6c, 0x93, 0xa4, 0x82")
MAKE_THUNK(libasound, snd_rawmidi_type, "0x7c, 0x7b, 0xf8, 0x99, 0x8a, 0xde, 0x4e, 0x7a, 0x8c, 0xdd, 0x3c, 0x63, 0xf0, 0x4e, 0xe4, 0x55, 0xa6, 0xd5, 0x69, 0x4d, 0x72, 0xcd, 0x55, 0x7f, 0xcf, 0x6a, 0x67, 0xf0, 0xa6, 0xab, 0xc8, 0xe7")
MAKE_THUNK(libasound, snd_rawmidi_stream, "0x5b, 0xf4, 0xda, 0xa6, 0xeb, 0x6b, 0xc7, 0x38, 0x30, 0x10, 0xe6, 0xb, 0x53, 0xd2, 0xbd, 0xbf, 0x49, 0xb9, 0xd6, 0x27, 0xb4, 0xce, 0x95, 0x31, 0xa3, 0xb8, 0x8d, 0x6e, 0x57, 0x20, 0x5f, 0xe0")
MAKE_THUNK(libasound, snd_timer_query_open, "0x5a, 0x5f, 0x20, 0xfe, 0x86, 0x8b, 0x97, 0xd7, 0x21, 0xb4, 0xe6, 0x77, 0xf1, 0xbf, 0xd6, 0x59, 0x17, 0xa2, 0x53, 0x93, 0xa3, 0x8d, 0x10, 0x98, 0xfc, 0xcf, 0x71, 0x6, 0xdb, 0x44, 0xdd, 0x46")
MAKE_THUNK(libasound, snd_timer_query_open_lconf, "0x27, 0x61, 0xda, 0x6a, 0xe3, 0x1f, 0x5d, 0xfe, 0xe4, 0xdb, 0x5e, 0x77, 0x51, 0xae, 0x6b, 0x6a, 0xaa, 0x7d, 0xd9, 0x21, 0xcd, 0x88, 0x27, 0xdb, 0xa0, 0x71, 0x14, 0x47, 0x95, 0xe6, 0x6a, 0x6a")
MAKE_THUNK(libasound, snd_timer_query_close, "0x8d, 0xa7, 0x2, 0x97, 0x9c, 0x30, 0x7f, 0x63, 0xa6, 0x75, 0x4e, 0xc8, 0xfc, 0x4d, 0xcf, 0xd2, 0x83, 0x38, 0x3, 0xf3, 0x59, 0xf2, 0x3a, 0xfa, 0xf5, 0x4, 0xa2, 0x76, 0xc6, 0xe3, 0x43, 0x58")
MAKE_THUNK(libasound, snd_timer_query_next_device, "0x18, 0x7c, 0xb9, 0x27, 0xae, 0x98, 0xd6, 0x6e, 0x22, 0x72, 0xeb, 0xfb, 0x3a, 0xf9, 0xc8, 0xc0, 0x94, 0xc3, 0x2c, 0x14, 0x1b, 0xb9, 0x3e, 0x80, 0xb2, 0x4c, 0xb, 0x47, 0xa4, 0x59, 0x6c, 0x2a")
MAKE_THUNK(libasound, snd_timer_query_info, "0xde, 0xca, 0x6, 0xd3, 0xcb, 0x94, 0x82, 0xfe, 0xba, 0x28, 0x61, 0x94, 0xa, 0xab, 0xa1, 0xb2, 0x3c, 0x2d, 0xa0, 0x9a, 0x1, 0x8a, 0xaf, 0x3f, 0xce, 0xd7, 0x1, 0x66, 0x4b, 0x5b, 0x6d, 0xb1")
MAKE_THUNK(libasound, snd_timer_query_params, "0x32, 0x1b, 0xdf, 0xab, 0x40, 0xa9, 0x84, 0xe9, 0x28, 0x77, 0x77, 0xf0, 0x17, 0xc1, 0x73, 0x16, 0xc8, 0xee, 0xe7, 0x19, 0xe3, 0x7f, 0x4a, 0xea, 0xdd, 0xd5, 0xf8, 0xe8, 0x74, 0x93, 0x63, 0x83")
MAKE_THUNK(libasound, snd_timer_query_status, "0x6e, 0x4c, 0x69, 0xe9, 0x93, 0xd, 0x7d, 0x4a, 0x42, 0x20, 0xa4, 0x8a, 0xb3, 0x6d, 0xe8, 0xe1, 0xdd, 0x2a, 0xf8, 0x50, 0x5d, 0xdc, 0x91, 0xe3, 0x68, 0x6, 0xd7, 0x11, 0xe8, 0x9b, 0xec, 0xff")
MAKE_THUNK(libasound, snd_timer_open, "0x9f, 0x37, 0xb8, 0x9, 0xa7, 0xda, 0xa0, 0x5c, 0xc2, 0x7e, 0xf6, 0x22, 0xbb, 0x78, 0xcc, 0xb5, 0x44, 0x1d, 0xb8, 0xa9, 0x45, 0x5f, 0x9b, 0x58, 0x6, 0x21, 0xda, 0x43, 0x46, 0x79, 0xc, 0xac")
MAKE_THUNK(libasound, snd_timer_open_lconf, "0xc8, 0xe2, 0x79, 0x96, 0x54, 0x99, 0x75, 0x78, 0xf3, 0xd9, 0xbe, 0x34, 0xf0, 0x55, 0xbf, 0xe1, 0xf2, 0xc1, 0x5a, 0x99, 0xd1, 0xbf, 0xa4, 0xcd, 0xbe, 0x14, 0x24, 0x8f, 0xf0, 0xbf, 0xd9, 0xb3")
MAKE_THUNK(libasound, snd_timer_close, "0xb, 0x1e, 0x90, 0x20, 0xa1, 0x32, 0xb2, 0x71, 0x71, 0x8a, 0xef, 0xa2, 0xd, 0xa4, 0xb9, 0x95, 0x11, 0x2c, 0x43, 0x7d, 0xec, 0xee, 0x7f, 0x76, 0xd7, 0x43, 0x47, 0xde, 0x99, 0x45, 0xe3, 0xea")
MAKE_THUNK(libasound, snd_timer_poll_descriptors_count, "0x3d, 0x96, 0xee, 0x5b, 0x4, 0x8e, 0x37, 0x20, 0xc7, 0xa2, 0x6a, 0xbe, 0xa4, 0xdd, 0xc1, 0xce, 0x3b, 0x75, 0x49, 0x31, 0x19, 0xbb, 0x8a, 0xa7, 0x83, 0x72, 0xde, 0x1e, 0x4c, 0x16, 0x89, 0xbd")
MAKE_THUNK(libasound, snd_timer_poll_descriptors, "0x7f, 0xea, 0x68, 0xe4, 0xf9, 0x9a, 0x63, 0xa5, 0xcb, 0x64, 0x58, 0xd6, 0xad, 0xc, 0x49, 0x6, 0x6f, 0xf, 0x3d, 0xf1, 0xf8, 0xbe, 0x74, 0x8f, 0xfc, 0x4a, 0x43, 0x26, 0xcc, 0x94, 0xb9, 0xda")
MAKE_THUNK(libasound, snd_timer_poll_descriptors_revents, "0x12, 0x92, 0x15, 0x34, 0x48, 0xd4, 0xf6, 0x9c, 0x8f, 0x54, 0x4, 0x7e, 0x3c, 0x9c, 0x7f, 0xa, 0x93, 0x26, 0xc7, 0x54, 0xec, 0x16, 0x70, 0x77, 0xef, 0xe0, 0xc2, 0xb8, 0x88, 0x58, 0xc8, 0x7b")
MAKE_THUNK(libasound, snd_timer_info, "0x51, 0x8f, 0x2d, 0x21, 0x29, 0xaf, 0xdb, 0xa, 0x77, 0x6c, 0xa0, 0xa1, 0x19, 0x7, 0x0, 0xb3, 0x8c, 0xf5, 0x1f, 0xcb, 0xae, 0x21, 0x94, 0x18, 0xa3, 0xc3, 0xbb, 0x1, 0xaf, 0x9e, 0x7b, 0x12")
MAKE_THUNK(libasound, snd_timer_params, "0x2c, 0x89, 0xe5, 0xf4, 0x7f, 0xeb, 0x57, 0x3e, 0xc1, 0xdb, 0x7f, 0x34, 0x9c, 0xf1, 0xf7, 0x58, 0x1c, 0x82, 0x8e, 0xbb, 0x4, 0xf5, 0xc, 0x7a, 0xb9, 0xf1, 0x8c, 0x32, 0x63, 0x0, 0x4e, 0x8a")
MAKE_THUNK(libasound, snd_timer_status, "0xe4, 0xd5, 0xe9, 0xa5, 0x14, 0x9d, 0xb5, 0x2e, 0x7f, 0x42, 0x7e, 0x51, 0x92, 0x90, 0xee, 0x6e, 0xbe, 0x36, 0x61, 0x10, 0xd9, 0x21, 0x49, 0x9a, 0x26, 0x95, 0xc0, 0xfb, 0xca, 0x24, 0x22, 0x6c")
MAKE_THUNK(libasound, snd_timer_start, "0xe, 0xda, 0xd8, 0x71, 0x9f, 0x94, 0x79, 0x36, 0xf9, 0xd4, 0xb4, 0xf3, 0x63, 0x74, 0x2d, 0x4f, 0x3c, 0x42, 0xea, 0x34, 0xab, 0x8a, 0xb6, 0xe7, 0x60, 0xbb, 0x6f, 0x3a, 0xa5, 0xa0, 0x22, 0x42")
MAKE_THUNK(libasound, snd_timer_stop, "0x6f, 0x25, 0x5a, 0x2e, 0x2c, 0x31, 0xe2, 0xaa, 0x2d, 0xd2, 0xa9, 0x64, 0x20, 0x47, 0x0, 0xf, 0x4d, 0x1d, 0xf8, 0xd6, 0xc7, 0x4b, 0xa6, 0x87, 0x10, 0x2b, 0x7c, 0x4e, 0xca, 0xfd, 0x8b, 0x64")
MAKE_THUNK(libasound, snd_timer_continue, "0x70, 0x33, 0x92, 0x5b, 0x53, 0xbf, 0x43, 0x64, 0x64, 0x7, 0x32, 0xbe, 0xba, 0xda, 0x40, 0xf4, 0x4, 0x7, 0xff, 0x63, 0xd8, 0x6f, 0x5b, 0x21, 0xc0, 0x8c, 0x5d, 0xfd, 0xd6, 0xc1, 0x7c, 0x3e")
MAKE_THUNK(libasound, snd_timer_read, "0x3f, 0x73, 0xaf, 0x74, 0xf2, 0xed, 0x19, 0xd3, 0xc2, 0x22, 0xb3, 0xbb, 0xf9, 0x12, 0xe, 0xa8, 0xfd, 0xcb, 0xf6, 0xfc, 0xb9, 0xda, 0xf2, 0x23, 0x27, 0x55, 0x14, 0x82, 0x39, 0x80, 0x99, 0x7a")
MAKE_THUNK(libasound, snd_timer_id_sizeof, "0xa1, 0xa3, 0x58, 0xb0, 0x95, 0xe7, 0xa, 0xe6, 0xb9, 0x1d, 0x4c, 0x43, 0xd9, 0xf3, 0xc3, 0x81, 0x76, 0xd1, 0xdb, 0x4f, 0x13, 0x5d, 0x61, 0xa1, 0xe2, 0xa2, 0x2a, 0xe3, 0x61, 0x79, 0x7b, 0xee")
MAKE_THUNK(libasound, snd_timer_id_malloc, "0x33, 0xe5, 0xb9, 0x2e, 0xe2, 0x52, 0x7f, 0x8c, 0xf8, 0x8b, 0xa2, 0x1a, 0x19, 0xec, 0x8c, 0xdd, 0xe8, 0xf7, 0x94, 0x48, 0xf, 0xde, 0x8, 0x11, 0xf6, 0x5b, 0x51, 0x4, 0x6f, 0xdd, 0x3b, 0x2f")
MAKE_THUNK(libasound, snd_timer_id_free, "0x1f, 0xff, 0xe, 0x29, 0x87, 0xf5, 0x52, 0x2, 0xef, 0x3d, 0x6b, 0x25, 0xc8, 0xcf, 0xb8, 0x16, 0xa2, 0x80, 0x10, 0xcb, 0x4d, 0x30, 0xf, 0xab, 0x7f, 0xb1, 0x1, 0xe7, 0x73, 0xf7, 0x6f, 0x96")
MAKE_THUNK(libasound, snd_timer_id_copy, "0xb4, 0x9f, 0xaf, 0x3c, 0xcb, 0x9f, 0x9e, 0x69, 0x16, 0xf5, 0xd, 0xc1, 0xee, 0xf, 0x15, 0x83, 0xee, 0xed, 0xe3, 0x59, 0xdf, 0xec, 0x20, 0xfd, 0xce, 0x42, 0xc0, 0x65, 0x92, 0x8f, 0xd8, 0x46")
MAKE_THUNK(libasound, snd_timer_id_set_class, "0xfa, 0x6c, 0xa2, 0xfb, 0xb6, 0xc6, 0xdc, 0xdb, 0xc4, 0xbc, 0xf6, 0xa9, 0xd4, 0xc0, 0xc1, 0x21, 0xdf, 0x78, 0xa0, 0x3a, 0x49, 0xbb, 0x54, 0xea, 0xb3, 0x4b, 0xe7, 0x86, 0x3e, 0x6a, 0xea, 0xde")
MAKE_THUNK(libasound, snd_timer_id_get_class, "0x2a, 0x50, 0x52, 0x37, 0x19, 0x21, 0x8b, 0x7a, 0x7d, 0x22, 0x4a, 0x2d, 0x2b, 0xb8, 0xbf, 0x66, 0x3a, 0x7c, 0x51, 0x9, 0x30, 0x58, 0x71, 0xda, 0xc2, 0x48, 0x2f, 0x25, 0xb0, 0x66, 0x43, 0xe7")
MAKE_THUNK(libasound, snd_timer_id_set_sclass, "0xf5, 0x24, 0x37, 0x7c, 0x96, 0x46, 0xe9, 0x87, 0x1a, 0x82, 0xe5, 0xe4, 0xb2, 0x40, 0xca, 0x2f, 0xbc, 0xc6, 0xd0, 0xf3, 0x10, 0xb8, 0x41, 0xbc, 0xf9, 0x22, 0xd2, 0xed, 0x8a, 0x59, 0xd8, 0x76")
MAKE_THUNK(libasound, snd_timer_id_get_sclass, "0xd3, 0x61, 0x76, 0x1b, 0x73, 0xe5, 0xbf, 0x42, 0xcb, 0xa6, 0x91, 0x5, 0xe0, 0x76, 0xa6, 0x6e, 0xf5, 0xd1, 0xd7, 0xbe, 0xbc, 0xe8, 0x1, 0xdb, 0xd2, 0x84, 0x62, 0xa, 0x8f, 0xa7, 0xfb, 0x3")
MAKE_THUNK(libasound, snd_timer_id_set_card, "0xe, 0x52, 0xd3, 0x64, 0xe, 0x51, 0x9a, 0x46, 0x78, 0x90, 0xb1, 0x74, 0xa, 0xa2, 0xfa, 0xcd, 0xc6, 0xa0, 0xb4, 0xfc, 0x19, 0xda, 0x3, 0x5f, 0xb0, 0x8b, 0x7, 0xa8, 0x76, 0x83, 0xf0, 0x75")
MAKE_THUNK(libasound, snd_timer_id_get_card, "0xa2, 0x1a, 0xb8, 0x58, 0x22, 0xa, 0xf2, 0x0, 0x80, 0x65, 0x27, 0x3e, 0xd1, 0xaf, 0x41, 0x57, 0x13, 0x95, 0xa9, 0xa4, 0x98, 0x40, 0xe0, 0xaa, 0x25, 0x80, 0x98, 0x41, 0xfe, 0x9e, 0x97, 0x38")
MAKE_THUNK(libasound, snd_timer_id_set_device, "0x99, 0x14, 0xd8, 0x74, 0xdc, 0x1f, 0x2d, 0xa6, 0x27, 0x63, 0x66, 0x19, 0xed, 0x7a, 0x6e, 0x61, 0x3a, 0xf, 0xd5, 0xe2, 0x34, 0x7, 0xda, 0x65, 0x83, 0xe9, 0xc6, 0x95, 0xff, 0x58, 0x44, 0xef")
MAKE_THUNK(libasound, snd_timer_id_get_device, "0x70, 0x95, 0xc0, 0x1, 0x68, 0xbd, 0xcc, 0x36, 0xe9, 0x3b, 0x44, 0xf, 0xe7, 0xd1, 0xb9, 0x16, 0x80, 0x3a, 0x9, 0xda, 0x4, 0x12, 0xb, 0x45, 0x23, 0x97, 0x21, 0x65, 0xdb, 0x13, 0xe7, 0xce")
MAKE_THUNK(libasound, snd_timer_id_set_subdevice, "0xd7, 0x2a, 0x34, 0xff, 0xe9, 0x3d, 0x11, 0x3c, 0x74, 0xc1, 0x91, 0x73, 0x6f, 0xab, 0x3e, 0xfe, 0xbd, 0x90, 0x86, 0xd3, 0xd4, 0x9e, 0x46, 0xec, 0xb7, 0xf3, 0x20, 0x3c, 0xad, 0xf2, 0xd0, 0x2a")
MAKE_THUNK(libasound, snd_timer_id_get_subdevice, "0x67, 0x3, 0x76, 0x85, 0x65, 0xe6, 0xc2, 0x53, 0x3e, 0xe2, 0xe4, 0x60, 0x18, 0x9, 0xcb, 0xbc, 0xf9, 0x78, 0xbb, 0xc8, 0x4d, 0x21, 0x2a, 0x65, 0x58, 0xd9, 0xea, 0x9c, 0x15, 0x5e, 0x15, 0xd3")
MAKE_THUNK(libasound, snd_timer_ginfo_sizeof, "0xd0, 0xef, 0x6, 0x3, 0x4c, 0x71, 0x7f, 0x90, 0xa7, 0x58, 0x56, 0xd9, 0x8c, 0x9a, 0x19, 0x92, 0x7e, 0xa4, 0x86, 0x5d, 0x1d, 0x3d, 0x4d, 0xa6, 0x44, 0xdd, 0x69, 0xff, 0x8d, 0x52, 0xe9, 0x29")
MAKE_THUNK(libasound, snd_timer_ginfo_malloc, "0x25, 0x3c, 0xb8, 0x6a, 0x3c, 0x19, 0x19, 0x56, 0x80, 0x81, 0x94, 0x99, 0xcb, 0xf8, 0x79, 0x31, 0x4c, 0x33, 0x14, 0xa6, 0xe9, 0x19, 0x46, 0x94, 0x68, 0xa3, 0x17, 0xeb, 0xb3, 0x7c, 0x94, 0x34")
MAKE_THUNK(libasound, snd_timer_ginfo_free, "0x9d, 0xe2, 0xbb, 0x71, 0x6a, 0x11, 0xac, 0xc5, 0xd8, 0x14, 0x97, 0xac, 0xcb, 0xc3, 0xc8, 0x33, 0x6f, 0xe5, 0xd5, 0xfc, 0xf5, 0xba, 0xb9, 0xd0, 0xea, 0x12, 0x5e, 0x37, 0xc3, 0x7a, 0x3b, 0xc9")
MAKE_THUNK(libasound, snd_timer_ginfo_copy, "0xb9, 0xf9, 0x98, 0xba, 0x74, 0x85, 0x55, 0x10, 0xb5, 0xba, 0x9b, 0xae, 0x8c, 0x57, 0x97, 0xe4, 0x5b, 0xfb, 0x45, 0x48, 0xc1, 0xb6, 0x55, 0xd3, 0x5, 0x36, 0x95, 0x54, 0x7f, 0xd4, 0x1, 0x75")
MAKE_THUNK(libasound, snd_timer_ginfo_set_tid, "0xb2, 0x8, 0x82, 0x99, 0xc4, 0x21, 0x81, 0x27, 0xa6, 0xb7, 0x42, 0x2f, 0xbb, 0xec, 0xb6, 0x40, 0xac, 0x7a, 0xc9, 0xfa, 0x2f, 0x31, 0x8, 0x77, 0x4f, 0x1f, 0x27, 0x7d, 0xb, 0x42, 0x97, 0x37")
MAKE_THUNK(libasound, snd_timer_ginfo_get_tid, "0xab, 0x70, 0xf4, 0x17, 0x24, 0x7a, 0xd3, 0x36, 0x74, 0xb9, 0x9a, 0xce, 0xf9, 0xcb, 0x9, 0xd2, 0x86, 0x64, 0xe9, 0x6, 0x33, 0x39, 0xd5, 0x3d, 0x98, 0xd5, 0x36, 0x6b, 0x27, 0x31, 0xbe, 0x2")
MAKE_THUNK(libasound, snd_timer_ginfo_get_flags, "0x1e, 0xcf, 0xa8, 0xc0, 0xce, 0xa5, 0x24, 0x5d, 0x3e, 0x86, 0x29, 0x72, 0x96, 0x42, 0x27, 0x5d, 0xc9, 0x8, 0x89, 0x16, 0xee, 0x73, 0xa, 0xa4, 0x22, 0xe2, 0x8f, 0x35, 0xba, 0x29, 0xb6, 0xcb")
MAKE_THUNK(libasound, snd_timer_ginfo_get_card, "0xa5, 0x36, 0x9f, 0x14, 0xa9, 0x8f, 0x7b, 0xc3, 0xa4, 0x50, 0xcd, 0xa2, 0x42, 0x9f, 0x43, 0x66, 0x94, 0x99, 0x26, 0xf2, 0x73, 0x10, 0x82, 0x88, 0x1d, 0xc6, 0x11, 0xca, 0xfd, 0xf3, 0xe3, 0x17")
MAKE_THUNK(libasound, snd_timer_ginfo_get_id, "0x33, 0x9f, 0x5b, 0xdc, 0x45, 0xaa, 0x1a, 0xe2, 0xa3, 0x1d, 0xd4, 0xe4, 0x28, 0x19, 0x69, 0xed, 0xc3, 0xa4, 0xa3, 0x52, 0x40, 0xe4, 0xe0, 0xb1, 0xe1, 0x58, 0xd3, 0xf4, 0xcc, 0x20, 0x65, 0x55")
MAKE_THUNK(libasound, snd_timer_ginfo_get_name, "0xfd, 0xa6, 0x9a, 0xe4, 0x34, 0xcc, 0xdb, 0x4a, 0x13, 0xc3, 0x9c, 0x74, 0xc0, 0x1d, 0x36, 0x39, 0xe5, 0xc3, 0x99, 0x1, 0xae, 0x99, 0x55, 0xf3, 0xc7, 0xf9, 0x53, 0x7f, 0xd2, 0xe3, 0xed, 0x54")
MAKE_THUNK(libasound, snd_timer_ginfo_get_resolution, "0xfa, 0x3a, 0x3a, 0xb8, 0x3c, 0xce, 0xcd, 0x9e, 0x6d, 0x86, 0xea, 0x93, 0x2e, 0x30, 0xc2, 0x93, 0x7d, 0x11, 0x41, 0x2c, 0x2c, 0x67, 0x73, 0xbd, 0xf8, 0xda, 0xc1, 0xcc, 0x9b, 0x53, 0xa8, 0x79")
MAKE_THUNK(libasound, snd_timer_ginfo_get_resolution_min, "0xbe, 0x9e, 0xc4, 0x98, 0x8, 0xb3, 0x8, 0xfd, 0xb2, 0x76, 0x40, 0xc9, 0xd7, 0xe7, 0xba, 0xa7, 0x9b, 0x27, 0xb7, 0xb7, 0x97, 0x7e, 0x7a, 0x7a, 0x30, 0x6a, 0x44, 0x1, 0x6c, 0x90, 0x7b, 0xb7")
MAKE_THUNK(libasound, snd_timer_ginfo_get_resolution_max, "0x30, 0x91, 0x68, 0xad, 0x6a, 0x9f, 0x1e, 0x12, 0xc3, 0x6f, 0x10, 0x3a, 0x3c, 0x79, 0x54, 0x80, 0x89, 0x1f, 0x8e, 0x9b, 0x35, 0xeb, 0x53, 0xa0, 0xb7, 0x1, 0x37, 0xf3, 0xcf, 0x80, 0x27, 0x15")
MAKE_THUNK(libasound, snd_timer_ginfo_get_clients, "0xdd, 0x2b, 0x77, 0xe6, 0x39, 0xa7, 0x26, 0xd4, 0xee, 0xee, 0x45, 0xdc, 0x70, 0x7c, 0xe0, 0xcc, 0xe3, 0x22, 0xf8, 0xd, 0x29, 0xe8, 0xe8, 0x26, 0xee, 0xe9, 0xd3, 0xfe, 0xab, 0x3b, 0xd, 0x77")
MAKE_THUNK(libasound, snd_timer_info_sizeof, "0x65, 0xa8, 0x8, 0xbd, 0x32, 0x73, 0xa6, 0x92, 0xff, 0x6c, 0xab, 0xc9, 0xbd, 0x28, 0x91, 0x57, 0x6f, 0xac, 0xe6, 0xb5, 0x16, 0x4c, 0xa1, 0xbe, 0x6b, 0x93, 0x33, 0xcf, 0xee, 0x84, 0xcb, 0x23")
MAKE_THUNK(libasound, snd_timer_info_malloc, "0xc3, 0x7f, 0x52, 0x3f, 0x24, 0xe8, 0xff, 0xbd, 0x65, 0xae, 0x39, 0x7b, 0x92, 0x4b, 0x69, 0x5b, 0x4, 0xbd, 0xb4, 0x16, 0x86, 0xe, 0x75, 0x65, 0x83, 0xca, 0xf0, 0x70, 0xeb, 0x9b, 0xf5, 0xf6")
MAKE_THUNK(libasound, snd_timer_info_free, "0xdb, 0xab, 0x9, 0x94, 0xb, 0x94, 0x35, 0x33, 0x2, 0xae, 0x62, 0xbb, 0x91, 0x75, 0x53, 0xd, 0xd3, 0xd1, 0x7b, 0x65, 0x16, 0x94, 0xe0, 0x1f, 0x26, 0xbc, 0x99, 0xab, 0x2e, 0xea, 0xfe, 0xba")
MAKE_THUNK(libasound, snd_timer_info_copy, "0x1b, 0xa0, 0x68, 0x99, 0x9c, 0xb0, 0xe1, 0xeb, 0x38, 0xa9, 0x8a, 0x4d, 0x9f, 0xd6, 0x24, 0xb7, 0x62, 0x7d, 0xed, 0xb8, 0xd3, 0xf6, 0x39, 0x24, 0xee, 0x50, 0xdb, 0xa6, 0x6b, 0xa3, 0x32, 0x6c")
MAKE_THUNK(libasound, snd_timer_info_is_slave, "0xa9, 0x83, 0xad, 0x24, 0xa3, 0xdd, 0x9, 0x8e, 0x98, 0x68, 0xd8, 0xb0, 0x93, 0xaf, 0xd6, 0x54, 0x20, 0xe1, 0xfc, 0x89, 0xf9, 0x77, 0x60, 0x19, 0x1, 0x22, 0xee, 0x77, 0xb1, 0xca, 0x11, 0x28")
MAKE_THUNK(libasound, snd_timer_info_get_card, "0x6d, 0x35, 0x9c, 0xa7, 0xd5, 0x6a, 0x13, 0x81, 0x76, 0x3e, 0x2e, 0xbd, 0xb9, 0x56, 0xd5, 0x46, 0xaa, 0xa4, 0x9c, 0x8a, 0xa3, 0x37, 0x9, 0xed, 0x4b, 0x0, 0x7b, 0x54, 0x41, 0x20, 0xef, 0x1c")
MAKE_THUNK(libasound, snd_timer_info_get_id, "0x32, 0x34, 0x83, 0x5b, 0xca, 0x9a, 0x15, 0x69, 0x79, 0xd2, 0xe5, 0x68, 0x9, 0x2e, 0xdf, 0xc2, 0xc, 0x63, 0x78, 0x37, 0x9a, 0x24, 0x1c, 0xdd, 0x7b, 0xba, 0xea, 0xe1, 0xdb, 0x8, 0xde, 0xa6")
MAKE_THUNK(libasound, snd_timer_info_get_name, "0x6c, 0x3b, 0x8a, 0x9f, 0xc4, 0x26, 0x70, 0x91, 0xc2, 0x6, 0xd2, 0xe1, 0x8b, 0x66, 0x49, 0x7c, 0x4a, 0xe1, 0xb8, 0x9f, 0x5b, 0xbe, 0x8b, 0x9d, 0xb, 0xc5, 0x24, 0x90, 0x39, 0x98, 0xe, 0x3d")
MAKE_THUNK(libasound, snd_timer_info_get_resolution, "0xce, 0x16, 0x0, 0x5f, 0x58, 0xa3, 0xeb, 0x8a, 0x76, 0xb5, 0x6f, 0xca, 0xa1, 0xf2, 0xe9, 0xb9, 0xb8, 0x4, 0xe3, 0x5f, 0x42, 0x17, 0xb3, 0x31, 0x7f, 0x5c, 0x54, 0xd8, 0xef, 0x5d, 0x6f, 0xff")
MAKE_THUNK(libasound, snd_timer_params_sizeof, "0x38, 0xd8, 0x9b, 0xe1, 0x59, 0x2, 0x43, 0xe7, 0xa1, 0x58, 0xf7, 0xb9, 0xd, 0xc3, 0x2f, 0x1f, 0xd7, 0x16, 0x7, 0x0, 0xcf, 0xa7, 0xf8, 0x8d, 0x65, 0xf0, 0x9a, 0x13, 0x27, 0x6b, 0xc9, 0x9a")
MAKE_THUNK(libasound, snd_timer_params_malloc, "0xfd, 0xda, 0x75, 0x71, 0xf5, 0x29, 0x40, 0x30, 0xa7, 0x43, 0xe7, 0xa2, 0xb6, 0xa7, 0x2e, 0x8b, 0x8b, 0xcd, 0x17, 0x15, 0x9c, 0x73, 0xa1, 0x8e, 0x26, 0xb3, 0x7f, 0x29, 0xb1, 0xf3, 0x7, 0xc2")
MAKE_THUNK(libasound, snd_timer_params_free, "0x97, 0xd2, 0xa9, 0x56, 0x5e, 0xe0, 0xf7, 0x40, 0x54, 0x1d, 0x3, 0x85, 0x49, 0x14, 0xd1, 0x5d, 0x8a, 0x24, 0x97, 0xf0, 0x6c, 0x32, 0x79, 0x67, 0xf6, 0xe0, 0x64, 0x3d, 0x32, 0x6c, 0x85, 0x86")
MAKE_THUNK(libasound, snd_timer_params_copy, "0x51, 0xd9, 0xb2, 0x58, 0x97, 0xcb, 0xd8, 0x30, 0xdd, 0x47, 0x11, 0xa8, 0x3f, 0xa0, 0x41, 0x34, 0xb2, 0x37, 0x4f, 0x46, 0x96, 0x30, 0xff, 0x1b, 0xf, 0xec, 0x23, 0x59, 0xb5, 0x73, 0x6, 0xdc")
MAKE_THUNK(libasound, snd_timer_params_set_auto_start, "0x95, 0xc0, 0xe3, 0x1b, 0x40, 0xa3, 0x31, 0x5f, 0xe0, 0xe6, 0x29, 0x8a, 0x3, 0x9e, 0xbe, 0x65, 0x7, 0x3e, 0x77, 0x4d, 0x82, 0xcd, 0x6e, 0xe9, 0x20, 0xbd, 0xb8, 0xd3, 0xbe, 0x16, 0x48, 0xb7")
MAKE_THUNK(libasound, snd_timer_params_get_auto_start, "0x75, 0xd5, 0xcc, 0xc2, 0x85, 0xfe, 0xf9, 0x92, 0x6c, 0xc0, 0x40, 0xcd, 0xe8, 0x59, 0x1c, 0xb6, 0x6b, 0x6e, 0x3e, 0x7f, 0x18, 0x37, 0x7b, 0xfc, 0x8d, 0x3f, 0x28, 0xd, 0xe4, 0xf2, 0xe9, 0x50")
MAKE_THUNK(libasound, snd_timer_params_set_exclusive, "0x70, 0xe2, 0xc6, 0x8d, 0x93, 0xca, 0xf9, 0x24, 0x23, 0xab, 0x67, 0x43, 0xfe, 0x2d, 0x60, 0x6d, 0xe8, 0xd1, 0x13, 0xb, 0xb9, 0x5d, 0x2e, 0x24, 0xbb, 0x3, 0x7a, 0x18, 0xd0, 0x95, 0x22, 0x2b")
MAKE_THUNK(libasound, snd_timer_params_get_exclusive, "0x8d, 0x76, 0x32, 0x63, 0x6f, 0xb8, 0x77, 0xb0, 0x40, 0x3a, 0xa, 0x9, 0x56, 0x9, 0xbc, 0x8c, 0xd8, 0x6c, 0x20, 0x21, 0x9b, 0xa1, 0x73, 0xf0, 0xf7, 0x19, 0x4d, 0x82, 0xa6, 0xcf, 0x72, 0xd2")
MAKE_THUNK(libasound, snd_timer_params_set_early_event, "0x12, 0xf1, 0xb2, 0x1, 0x46, 0xca, 0x88, 0xae, 0xaf, 0x71, 0x6b, 0x18, 0x8d, 0x19, 0x85, 0x79, 0xd9, 0x66, 0x59, 0x3f, 0x5e, 0x7e, 0x18, 0xd4, 0x93, 0x5, 0x12, 0xdf, 0x11, 0x36, 0x6d, 0x86")
MAKE_THUNK(libasound, snd_timer_params_get_early_event, "0x2b, 0xb3, 0x72, 0x94, 0xce, 0x90, 0x55, 0x90, 0x87, 0x8d, 0x7f, 0x5a, 0x3d, 0xa6, 0x4c, 0x41, 0xc5, 0xc6, 0xa2, 0x99, 0x11, 0xee, 0x84, 0x15, 0x65, 0xc, 0xc2, 0x70, 0x65, 0x29, 0x5f, 0xb0")
MAKE_THUNK(libasound, snd_timer_params_set_ticks, "0x3e, 0x72, 0xbf, 0xc9, 0x96, 0x8b, 0x61, 0x45, 0x1f, 0x2f, 0x93, 0x7d, 0x48, 0x91, 0x71, 0x18, 0x79, 0x63, 0x10, 0xc6, 0xf7, 0x5d, 0x3b, 0x98, 0x1a, 0x1f, 0x95, 0xa7, 0x38, 0x20, 0xcc, 0x8e")
MAKE_THUNK(libasound, snd_timer_params_get_ticks, "0xbd, 0x8c, 0xf4, 0x40, 0xa4, 0xf7, 0x64, 0x20, 0xb1, 0x3, 0x22, 0x12, 0xfa, 0x6b, 0x41, 0x0, 0x38, 0xb7, 0x1, 0x42, 0x8d, 0x84, 0x53, 0x79, 0x74, 0xeb, 0x34, 0x57, 0xab, 0x25, 0xad, 0x35")
MAKE_THUNK(libasound, snd_timer_params_set_queue_size, "0xf7, 0x81, 0x72, 0x6e, 0xa, 0x1d, 0x40, 0x27, 0x0, 0xc4, 0xc0, 0x9e, 0xc8, 0xf3, 0x77, 0x2b, 0x3b, 0x46, 0x7b, 0x36, 0x1a, 0x1b, 0x1c, 0x89, 0x98, 0x97, 0xa6, 0x4e, 0x8a, 0x1d, 0x65, 0xbe")
MAKE_THUNK(libasound, snd_timer_params_get_queue_size, "0x45, 0x19, 0x43, 0xb1, 0xa2, 0x22, 0xb, 0x96, 0xc3, 0x3d, 0xca, 0xea, 0x6f, 0xd8, 0xc6, 0xb4, 0xd6, 0x40, 0x11, 0xc3, 0x4d, 0x53, 0xec, 0xb5, 0xf6, 0xa8, 0x48, 0x79, 0x6d, 0xbd, 0xf5, 0xb3")
MAKE_THUNK(libasound, snd_timer_params_set_filter, "0x22, 0x9d, 0xb5, 0x85, 0x20, 0x69, 0xb2, 0x51, 0xd8, 0x4d, 0x4e, 0xf6, 0x7c, 0x7f, 0x34, 0xa3, 0x10, 0xca, 0x2d, 0xe9, 0xfb, 0x55, 0xee, 0x91, 0x76, 0x3e, 0x16, 0xb6, 0xe9, 0x88, 0x9f, 0x78")
MAKE_THUNK(libasound, snd_timer_params_get_filter, "0x5a, 0xb2, 0x31, 0x8b, 0x64, 0xf0, 0xf3, 0x6, 0x5, 0x5a, 0x28, 0x14, 0x45, 0x73, 0xf2, 0xaf, 0x91, 0x35, 0x39, 0xd, 0xf, 0xc3, 0x68, 0x34, 0x88, 0x8b, 0x59, 0x77, 0x1b, 0xd4, 0x73, 0xe")
MAKE_THUNK(libasound, snd_timer_status_sizeof, "0xc5, 0x24, 0x2a, 0xc, 0xb6, 0x2d, 0xbe, 0xc2, 0xf4, 0x29, 0x1, 0x90, 0x3b, 0x22, 0x17, 0x25, 0x8a, 0xec, 0x45, 0xf5, 0xb, 0x30, 0x8e, 0xad, 0x67, 0x5d, 0x4d, 0x2b, 0x8b, 0x9a, 0xaa, 0xfa")
MAKE_THUNK(libasound, snd_timer_status_malloc, "0x80, 0x35, 0xa5, 0x7d, 0x6d, 0xb1, 0x71, 0xe4, 0xf6, 0x7a, 0x61, 0x34, 0x26, 0x1c, 0x5d, 0x1e, 0x4e, 0x7a, 0xf, 0x59, 0x80, 0x9f, 0x76, 0xf0, 0x40, 0x9a, 0x86, 0x3b, 0xdf, 0xd5, 0xa1, 0x89")
MAKE_THUNK(libasound, snd_timer_status_free, "0x4e, 0x92, 0xa8, 0xd4, 0xc0, 0x3e, 0x71, 0x96, 0x9, 0x88, 0x4f, 0x9a, 0xed, 0xea, 0x97, 0x4b, 0x11, 0x36, 0x5c, 0xfe, 0x3e, 0x85, 0xf4, 0xbe, 0xb0, 0x18, 0xf9, 0xec, 0x47, 0x2c, 0xf5, 0xcf")
MAKE_THUNK(libasound, snd_timer_status_copy, "0x78, 0x6e, 0xaf, 0x2e, 0x4f, 0x29, 0xc9, 0x40, 0x9e, 0x23, 0xfd, 0xb7, 0x85, 0x91, 0x88, 0xed, 0xda, 0x7, 0xcf, 0x6c, 0x29, 0x8f, 0xd0, 0xfb, 0x12, 0xa7, 0xe6, 0x78, 0xf1, 0x88, 0x89, 0xe1")
MAKE_THUNK(libasound, snd_timer_status_get_timestamp, "0xc, 0x78, 0xbb, 0xb0, 0x6, 0x88, 0xfa, 0x4f, 0x1f, 0x75, 0xb6, 0xb, 0xbc, 0x4e, 0xc7, 0xe, 0xaa, 0x86, 0x61, 0xeb, 0x7f, 0x3f, 0xff, 0xf8, 0xe0, 0xf2, 0x3f, 0x56, 0x84, 0x2d, 0xc4, 0xc5")
MAKE_THUNK(libasound, snd_timer_status_get_resolution, "0x75, 0x35, 0x3f, 0x8f, 0xa7, 0xf7, 0x10, 0xa8, 0x81, 0x9e, 0x53, 0xee, 0x50, 0xa2, 0xe5, 0x68, 0x34, 0xf7, 0x21, 0xf3, 0x59, 0xed, 0x1c, 0xb1, 0xd8, 0xdb, 0x90, 0xc0, 0xf, 0x67, 0xd8, 0xf5")
MAKE_THUNK(libasound, snd_timer_status_get_lost, "0x90, 0x58, 0x2, 0x14, 0x6a, 0x69, 0x58, 0x82, 0xb6, 0x79, 0x76, 0xbb, 0x91, 0x7a, 0xdb, 0x4a, 0x9d, 0x64, 0xb6, 0xa8, 0x73, 0x2f, 0xe8, 0x14, 0x8f, 0x66, 0x8, 0x7d, 0xa, 0xd1, 0x90, 0xb1")
MAKE_THUNK(libasound, snd_timer_status_get_overrun, "0x5e, 0xae, 0xf6, 0xe5, 0x8, 0x44, 0x50, 0xe9, 0x9d, 0xe3, 0x58, 0x98, 0x55, 0xda, 0x9b, 0xd, 0x74, 0x79, 0xf3, 0xd5, 0x54, 0xa2, 0x10, 0x16, 0xe4, 0xc9, 0x7d, 0xa7, 0x18, 0x85, 0x45, 0xb8")
MAKE_THUNK(libasound, snd_timer_status_get_queue, "0xf6, 0x4e, 0xd9, 0xad, 0xdd, 0xb8, 0x0, 0x8c, 0xc9, 0xe7, 0x7b, 0x5a, 0x52, 0xac, 0xc6, 0x8d, 0xdf, 0x11, 0x9c, 0x18, 0xd7, 0x92, 0x54, 0xd1, 0x7f, 0x4e, 0xc7, 0x92, 0xa9, 0xfd, 0x78, 0x51")
MAKE_THUNK(libasound, snd_timer_info_get_ticks, "0x71, 0xc6, 0x25, 0x3a, 0xc3, 0x82, 0xb1, 0xfb, 0xde, 0xf6, 0x63, 0x55, 0x59, 0x9a, 0xec, 0xc5, 0xd9, 0x7d, 0x37, 0x50, 0xcb, 0x74, 0x48, 0xba, 0x20, 0x24, 0x87, 0x3c, 0x7b, 0xa, 0xec, 0x51")
MAKE_THUNK(libasound, snd_hwdep_open, "0x54, 0x2a, 0x19, 0xf7, 0x8b, 0x72, 0xbe, 0x54, 0x82, 0x4d, 0xa8, 0x77, 0x9, 0x34, 0xa6, 0xc7, 0x30, 0x32, 0xa8, 0xee, 0xeb, 0x2a, 0x27, 0x19, 0xfc, 0x6e, 0xdc, 0x30, 0x7e, 0xb, 0xdf, 0x65")
MAKE_THUNK(libasound, snd_hwdep_close, "0x71, 0x54, 0xcd, 0x88, 0x5, 0x2, 0x89, 0x5c, 0xb2, 0x58, 0x26, 0xc0, 0x26, 0xe0, 0x23, 0x8b, 0x2b, 0x6d, 0xe7, 0x89, 0xdb, 0xee, 0x40, 0xd4, 0xbd, 0x75, 0xcb, 0xb8, 0x83, 0xdc, 0x8b, 0xd5")
MAKE_THUNK(libasound, snd_hwdep_poll_descriptors, "0x65, 0x94, 0x94, 0xc0, 0xa5, 0xdd, 0xae, 0x3, 0x9d, 0xc2, 0x36, 0x2d, 0x44, 0xcd, 0x46, 0x6e, 0x98, 0x46, 0xd1, 0xab, 0x35, 0x70, 0x9b, 0xd3, 0xc0, 0xc5, 0x60, 0x2a, 0x31, 0x38, 0xd9, 0xee")
MAKE_THUNK(libasound, snd_hwdep_poll_descriptors_count, "0x2e, 0xa7, 0x4d, 0x8f, 0x66, 0xaf, 0x7, 0x8d, 0x50, 0x89, 0x4f, 0xde, 0x7f, 0x28, 0xee, 0xcd, 0xcb, 0x1d, 0x95, 0x5a, 0x56, 0xec, 0x46, 0xeb, 0x60, 0x4c, 0xeb, 0x7f, 0x29, 0x64, 0x31, 0xe2")
MAKE_THUNK(libasound, snd_hwdep_poll_descriptors_revents, "0xe9, 0xaa, 0x3f, 0x2c, 0x9, 0xb2, 0x52, 0x47, 0x29, 0x19, 0x77, 0xdb, 0x9c, 0x52, 0x9d, 0x72, 0x44, 0x89, 0x94, 0x45, 0x59, 0x1e, 0xba, 0x35, 0xf5, 0xf9, 0xb7, 0xb9, 0xee, 0x36, 0x33, 0x1d")
MAKE_THUNK(libasound, snd_hwdep_nonblock, "0x58, 0x23, 0xca, 0x7d, 0xca, 0x54, 0xa8, 0x83, 0xbb, 0x38, 0xe7, 0x9f, 0x42, 0xdc, 0x58, 0x27, 0x2e, 0xe, 0xd1, 0x8f, 0x1d, 0x15, 0x6f, 0xa5, 0xa5, 0x7f, 0x79, 0x15, 0xee, 0xf0, 0x4c, 0x7a")
MAKE_THUNK(libasound, snd_hwdep_info, "0x3e, 0x66, 0x9b, 0x27, 0x87, 0xa1, 0xac, 0x32, 0x87, 0x44, 0xfe, 0x9c, 0x41, 0x2c, 0x30, 0xc1, 0xa4, 0x3c, 0x28, 0x11, 0x2, 0x65, 0x9, 0xf0, 0xbc, 0x32, 0x24, 0x42, 0x6, 0xee, 0x78, 0xc1")
MAKE_THUNK(libasound, snd_hwdep_dsp_status, "0xa9, 0x62, 0x19, 0x87, 0x70, 0xfe, 0xd8, 0x1a, 0xae, 0x53, 0xdd, 0xa4, 0xa0, 0xa6, 0x19, 0x77, 0x99, 0xb2, 0x75, 0x96, 0x8b, 0x35, 0xa7, 0x8b, 0xf7, 0x41, 0x5, 0xa3, 0x1c, 0x50, 0x69, 0x76")
MAKE_THUNK(libasound, snd_hwdep_dsp_load, "0xc0, 0xd8, 0x11, 0xd3, 0xa7, 0x95, 0x6d, 0xd9, 0x62, 0x89, 0xc4, 0x8c, 0x8e, 0xc9, 0xf6, 0x22, 0xaa, 0x66, 0x90, 0x67, 0xaf, 0xaa, 0xb1, 0x7f, 0x39, 0x14, 0x2f, 0x80, 0x51, 0x5f, 0x4a, 0x35")
MAKE_THUNK(libasound, snd_hwdep_ioctl, "0xf6, 0x91, 0x60, 0x60, 0x3d, 0x7a, 0x8d, 0x9f, 0xe3, 0x64, 0x6d, 0x1, 0x7a, 0xbb, 0x30, 0xf0, 0x6a, 0x55, 0x2e, 0x9, 0x92, 0x71, 0x41, 0xbd, 0x6, 0x20, 0xe5, 0x96, 0xc6, 0xed, 0x33, 0x5e")
MAKE_THUNK(libasound, snd_hwdep_write, "0x9, 0x50, 0x94, 0xd6, 0xb9, 0x3d, 0x8d, 0xc7, 0xa5, 0x90, 0x35, 0x1e, 0x26, 0xc7, 0x6f, 0xb9, 0xdd, 0xb2, 0xb6, 0x3c, 0xe5, 0x2, 0xdb, 0x79, 0xf3, 0x62, 0x6c, 0x61, 0x5e, 0x1a, 0x61, 0x29")
MAKE_THUNK(libasound, snd_hwdep_read, "0xd0, 0x6a, 0xf5, 0x43, 0xba, 0xcf, 0xe6, 0x71, 0x6e, 0xe8, 0x29, 0x15, 0x6a, 0x28, 0x23, 0x93, 0xee, 0x51, 0xff, 0xa0, 0x91, 0x6e, 0xf6, 0x71, 0xd6, 0x1e, 0x72, 0x95, 0xe4, 0x74, 0x48, 0x96")
MAKE_THUNK(libasound, snd_hwdep_info_sizeof, "0x21, 0xe3, 0x5d, 0x4b, 0x8f, 0xb1, 0x7f, 0xb7, 0x61, 0xf0, 0x65, 0x5e, 0x36, 0x88, 0x51, 0x3c, 0x20, 0xf3, 0xe2, 0x4a, 0xf8, 0xbb, 0x8e, 0xed, 0x68, 0x82, 0x4d, 0xeb, 0x24, 0xa2, 0xb7, 0x56")
MAKE_THUNK(libasound, snd_hwdep_info_malloc, "0xbd, 0xc7, 0xf0, 0xb0, 0x95, 0xbf, 0x41, 0xab, 0xce, 0x1e, 0x64, 0x4c, 0x87, 0xf5, 0x20, 0x9, 0x7b, 0x4, 0xd4, 0xae, 0xc5, 0xb9, 0x33, 0xe2, 0x99, 0xa0, 0x45, 0x12, 0xca, 0x8f, 0xd, 0x14")
MAKE_THUNK(libasound, snd_hwdep_info_free, "0x6a, 0xb7, 0x49, 0x40, 0x7c, 0x55, 0xa8, 0x4, 0x22, 0x53, 0xc0, 0x55, 0xb5, 0x5f, 0x3b, 0x94, 0xfb, 0x78, 0x18, 0x51, 0x75, 0xac, 0xe, 0x5d, 0x33, 0x38, 0x8a, 0x4d, 0xea, 0x2, 0xdd, 0x88")
MAKE_THUNK(libasound, snd_hwdep_info_copy, "0x84, 0x6f, 0x24, 0xb7, 0xfb, 0x77, 0x66, 0x21, 0xe4, 0xde, 0xf5, 0x51, 0x53, 0xf0, 0x1d, 0xc3, 0x72, 0x12, 0xf3, 0x90, 0x20, 0x40, 0x4b, 0x80, 0x6d, 0x23, 0xf6, 0x8, 0xb8, 0x74, 0x7f, 0x50")
MAKE_THUNK(libasound, snd_hwdep_info_get_device, "0xfa, 0x3d, 0xf8, 0x62, 0x66, 0x73, 0xc1, 0x61, 0xb1, 0x94, 0x51, 0xa5, 0x95, 0x16, 0xb1, 0x32, 0xef, 0x4d, 0x92, 0xde, 0x48, 0xe2, 0x66, 0xda, 0xe9, 0x0, 0xe3, 0x35, 0xed, 0xbd, 0x74, 0xf0")
MAKE_THUNK(libasound, snd_hwdep_info_get_card, "0xec, 0x41, 0xc7, 0xc0, 0xa8, 0xed, 0xe6, 0xcd, 0x34, 0xfd, 0xbc, 0xb4, 0x80, 0x6f, 0x3, 0x68, 0xbe, 0x51, 0x4b, 0xdd, 0xbe, 0xfd, 0x75, 0x4e, 0x26, 0xe0, 0xe6, 0xef, 0xb6, 0x9, 0x8f, 0xba")
MAKE_THUNK(libasound, snd_hwdep_info_get_id, "0xfa, 0x4d, 0x27, 0xa9, 0x5, 0xc1, 0x44, 0xd0, 0xc0, 0x5f, 0x38, 0xfd, 0x40, 0xc1, 0x28, 0x6b, 0x30, 0x8a, 0x66, 0xdd, 0xff, 0x15, 0x11, 0x61, 0xc9, 0x58, 0xf4, 0x17, 0x9d, 0x3d, 0x20, 0x23")
MAKE_THUNK(libasound, snd_hwdep_info_get_name, "0x1c, 0xfa, 0x8, 0x31, 0xcb, 0xf3, 0xba, 0x3c, 0x9, 0xaa, 0x7e, 0xb4, 0x6d, 0x9f, 0x6e, 0x7b, 0xb3, 0x31, 0xb9, 0x1e, 0x35, 0xf1, 0xba, 0xe6, 0x63, 0x95, 0x1b, 0xc, 0x7a, 0x5c, 0xf, 0xaf")
MAKE_THUNK(libasound, snd_hwdep_info_get_iface, "0x9c, 0xc3, 0xa7, 0x50, 0x4a, 0xad, 0xcc, 0x5c, 0x8f, 0xf7, 0xf6, 0xbb, 0x6a, 0x28, 0x3f, 0x6e, 0x3, 0x44, 0xae, 0x47, 0x13, 0x14, 0xdb, 0x5d, 0xc3, 0xe9, 0x2d, 0x39, 0xb8, 0xb7, 0x60, 0xed")
MAKE_THUNK(libasound, snd_hwdep_info_set_device, "0x2d, 0x55, 0xe0, 0x2b, 0xc3, 0x6, 0x91, 0xaf, 0x7a, 0x18, 0x49, 0x6a, 0xa2, 0x62, 0x39, 0xa8, 0xdc, 0x80, 0xf9, 0x77, 0x65, 0x98, 0x73, 0x8c, 0x5, 0xb5, 0xaa, 0x41, 0xe, 0xc0, 0x6c, 0x22")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_sizeof, "0x3a, 0x7a, 0x60, 0x33, 0xb, 0x6d, 0xd7, 0x61, 0xa3, 0x3d, 0xf5, 0xc4, 0x8b, 0xac, 0x87, 0xa6, 0x45, 0x92, 0x53, 0x17, 0x72, 0xb8, 0x2b, 0xc1, 0xf4, 0x7a, 0x57, 0x13, 0xe6, 0x14, 0x84, 0x17")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_malloc, "0x6c, 0xb4, 0x0, 0x84, 0x36, 0x65, 0xbc, 0x75, 0xca, 0x67, 0x6d, 0x16, 0xd0, 0x74, 0x21, 0x0, 0x0, 0xa9, 0xb7, 0x18, 0xc6, 0x61, 0x4c, 0x73, 0x15, 0x93, 0xe9, 0x79, 0xb0, 0xcd, 0x5b, 0x61")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_free, "0x84, 0xfc, 0x7, 0x3c, 0x72, 0x8a, 0x3a, 0x1d, 0x21, 0x78, 0xe9, 0xce, 0x71, 0x12, 0x42, 0xbe, 0x7e, 0xbe, 0x6e, 0x18, 0x84, 0x2b, 0x9e, 0x8c, 0xfb, 0x2c, 0x9f, 0xa3, 0x6b, 0xed, 0x32, 0x9")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_copy, "0xcd, 0x24, 0x89, 0x69, 0x19, 0x42, 0x34, 0x30, 0x75, 0x79, 0xfd, 0x26, 0xf3, 0x24, 0x5b, 0x62, 0x24, 0x57, 0xb9, 0xd9, 0x21, 0x30, 0x0, 0xa4, 0xe6, 0x72, 0xe7, 0xa8, 0x2b, 0x1e, 0x3e, 0xae")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_get_version, "0x94, 0xe1, 0xf3, 0x6b, 0xb1, 0x4c, 0x5, 0xd5, 0x9a, 0xef, 0x3b, 0x60, 0xf8, 0x11, 0x65, 0x84, 0x21, 0x58, 0x82, 0x40, 0x80, 0x6f, 0xf3, 0x30, 0xaa, 0x99, 0x93, 0x38, 0x7f, 0x92, 0x75, 0x25")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_get_id, "0x8d, 0xa7, 0xd5, 0x29, 0x87, 0x5, 0x5f, 0x6c, 0xef, 0x7, 0x8a, 0x9f, 0x2f, 0x84, 0x1d, 0xcb, 0xc5, 0x32, 0xf5, 0x36, 0xd9, 0x23, 0x6a, 0xcc, 0xd5, 0xee, 0xc1, 0x4a, 0x7f, 0xf4, 0x16, 0x70")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_get_num_dsps, "0x63, 0x61, 0xe1, 0xb6, 0x82, 0x1, 0x47, 0x76, 0xce, 0x5f, 0x8d, 0x8d, 0x1e, 0x8, 0x73, 0x20, 0xec, 0x9, 0x49, 0x68, 0x1b, 0xf2, 0xfc, 0x21, 0x52, 0x2a, 0x6e, 0x29, 0xdc, 0x6b, 0x0, 0xc0")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_get_dsp_loaded, "0x4f, 0x66, 0x33, 0x9e, 0xf3, 0x67, 0xe7, 0x18, 0xe4, 0x60, 0x54, 0x10, 0xc6, 0xf4, 0x76, 0xc1, 0x9c, 0xe0, 0x62, 0x8b, 0xf1, 0xd8, 0x55, 0x32, 0xa9, 0x16, 0xfb, 0x5e, 0x2b, 0x72, 0xd5, 0x66")
MAKE_THUNK(libasound, snd_hwdep_dsp_status_get_chip_ready, "0x25, 0xf3, 0xe1, 0xa4, 0xdf, 0xdd, 0x55, 0x14, 0x7e, 0xc7, 0x46, 0xfc, 0x23, 0x51, 0xd8, 0xea, 0xdb, 0xb6, 0x7e, 0x3f, 0xd4, 0xa0, 0xa1, 0x9d, 0xe5, 0xaf, 0x7f, 0x54, 0xc9, 0x84, 0xdb, 0xae")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_sizeof, "0xc7, 0xce, 0x3c, 0x4, 0x97, 0x81, 0x11, 0x42, 0x2c, 0xbe, 0x6a, 0x29, 0x20, 0xdf, 0xb7, 0x1c, 0x58, 0x94, 0xdb, 0x4, 0x29, 0xe2, 0x77, 0x9e, 0xb9, 0x9e, 0xc9, 0xc0, 0x99, 0x79, 0xdb, 0xfe")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_malloc, "0xc1, 0xb8, 0xc9, 0x5f, 0xed, 0xae, 0x60, 0x9, 0x9f, 0x24, 0xaf, 0x5f, 0xdd, 0x7e, 0x90, 0xa, 0xfc, 0x38, 0x24, 0x6d, 0x3a, 0x39, 0x4f, 0x93, 0xe3, 0x2f, 0x26, 0x4c, 0xe, 0xbb, 0xfb, 0x62")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_free, "0x69, 0xd3, 0xf5, 0x73, 0xee, 0x65, 0x6a, 0xb7, 0x41, 0x28, 0x35, 0xa8, 0xf0, 0xb3, 0x33, 0x30, 0x60, 0x9, 0xde, 0x3a, 0x56, 0x83, 0x86, 0xbc, 0x98, 0xb1, 0xac, 0x44, 0x5c, 0xd6, 0x51, 0xe3")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_copy, "0x44, 0x1f, 0x83, 0x39, 0x91, 0x50, 0x6, 0x97, 0x2, 0x38, 0x68, 0x63, 0xac, 0x93, 0x96, 0x80, 0x17, 0x26, 0xab, 0x83, 0x97, 0xc4, 0x46, 0xb1, 0x64, 0x72, 0x5e, 0xa9, 0xdc, 0x46, 0xda, 0x8")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_get_index, "0x1a, 0x61, 0xfa, 0x5f, 0x53, 0xdf, 0x36, 0x81, 0x9e, 0x97, 0xd8, 0x2b, 0xb4, 0x3f, 0x94, 0xf2, 0x0, 0x68, 0xdd, 0xf6, 0x53, 0xf4, 0xf1, 0x70, 0xdd, 0xc2, 0x71, 0x56, 0x97, 0x4f, 0x1a, 0x42")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_get_name, "0xe8, 0x25, 0xd5, 0x0, 0x40, 0x5, 0x8a, 0xce, 0x64, 0x1d, 0xe3, 0xf8, 0x83, 0xcb, 0x20, 0xce, 0x2e, 0xb1, 0xee, 0x94, 0xad, 0xbf, 0x8a, 0xd7, 0x66, 0xf, 0xc0, 0xff, 0xf4, 0x81, 0xcf, 0x2c")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_get_image, "0xb1, 0x8e, 0xac, 0x27, 0x8b, 0x68, 0x9c, 0xd2, 0xe7, 0x98, 0xdf, 0xa, 0x98, 0xf1, 0x47, 0x5e, 0x27, 0xb9, 0x52, 0xfc, 0x9, 0x8c, 0x9a, 0x0, 0x29, 0x24, 0x83, 0xcc, 0xc2, 0x9b, 0x1, 0x8a")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_get_length, "0xd2, 0x68, 0x67, 0x97, 0x79, 0x94, 0x4e, 0x11, 0x1, 0x47, 0xa8, 0x94, 0xbc, 0x7e, 0x7, 0xfa, 0xed, 0x5b, 0x20, 0x32, 0xdd, 0x4, 0x70, 0x73, 0x69, 0x69, 0x44, 0xc5, 0xb7, 0xe6, 0x3, 0xef")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_set_index, "0x15, 0x22, 0x2b, 0x72, 0x91, 0xcf, 0x49, 0xcb, 0x43, 0x7f, 0xa8, 0xa4, 0x46, 0xe3, 0xa, 0x2f, 0x7, 0x74, 0x17, 0xa, 0x35, 0xcd, 0xfd, 0x35, 0xc7, 0x40, 0x49, 0xf9, 0x5, 0x78, 0xb5, 0x73")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_set_name, "0xe6, 0xe, 0x63, 0x77, 0x21, 0x2e, 0x73, 0xd, 0xff, 0x36, 0xe, 0xb, 0x30, 0x4a, 0x7b, 0xb, 0xa5, 0x58, 0x36, 0xbb, 0xca, 0x85, 0x8e, 0x89, 0x67, 0xb, 0x34, 0xd9, 0x3f, 0x30, 0x14, 0x4d")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_set_image, "0x57, 0x36, 0x22, 0xb2, 0x94, 0x7a, 0x13, 0xda, 0x8f, 0xd1, 0xcb, 0x5c, 0x2, 0xd1, 0x78, 0x96, 0xe4, 0xa0, 0xdd, 0xb4, 0xb9, 0xd1, 0xbd, 0x3c, 0x6e, 0x47, 0x2a, 0xbd, 0x7e, 0x79, 0x58, 0xde")
MAKE_THUNK(libasound, snd_hwdep_dsp_image_set_length, "0x19, 0xc0, 0x2d, 0x75, 0x78, 0xca, 0xb, 0x7a, 0xdd, 0xd, 0xd2, 0x1f, 0x99, 0x9d, 0xe1, 0xdf, 0x7d, 0x99, 0x4f, 0x6, 0x19, 0xe1, 0xa3, 0x49, 0x6, 0x3e, 0x22, 0x9, 0x2, 0x8c, 0xb6, 0xf2")
MAKE_THUNK(libasound, snd_card_load, "0x11, 0x61, 0x68, 0x33, 0x8, 0x5b, 0xe5, 0x2d, 0x98, 0x87, 0xb, 0x3b, 0x5, 0x1d, 0x3b, 0x98, 0xf, 0x7b, 0x67, 0x2e, 0xf8, 0x14, 0xfc, 0x3d, 0x32, 0x76, 0x87, 0x5e, 0xcc, 0x30, 0x7d, 0x72")
MAKE_THUNK(libasound, snd_card_next, "0x5, 0x50, 0x77, 0xe1, 0x59, 0x67, 0xf7, 0x87, 0xcb, 0x91, 0x43, 0x88, 0x22, 0x66, 0xec, 0x72, 0x4a, 0xc8, 0xce, 0x97, 0x23, 0xf6, 0xf0, 0xe7, 0xbc, 0xd3, 0xf2, 0x95, 0xfd, 0x54, 0x86, 0xec")
MAKE_THUNK(libasound, snd_card_get_index, "0xa9, 0x51, 0xc9, 0x1e, 0xb7, 0xd7, 0x19, 0xa4, 0x0, 0x79, 0x2f, 0x58, 0xb0, 0xc4, 0x4b, 0x57, 0x1a, 0xed, 0x9, 0xb6, 0x5e, 0x84, 0xe4, 0xcc, 0xc7, 0x4c, 0x41, 0xdc, 0x8b, 0xe4, 0xc5, 0x44")
MAKE_THUNK(libasound, snd_card_get_name, "0xdd, 0xce, 0x23, 0x82, 0x88, 0xf3, 0xf1, 0xfe, 0x5, 0x3a, 0xdf, 0xca, 0x67, 0x77, 0x3f, 0x5e, 0x76, 0xab, 0xe, 0x23, 0xf3, 0x52, 0x49, 0x4b, 0x8e, 0x41, 0x7a, 0xdf, 0x3a, 0x1d, 0xbe, 0xf7")
MAKE_THUNK(libasound, snd_card_get_longname, "0x68, 0x3d, 0xbd, 0x56, 0x93, 0x11, 0x24, 0x7a, 0x40, 0x51, 0x5e, 0x15, 0x58, 0x46, 0x19, 0x22, 0x85, 0x6b, 0x26, 0x68, 0x62, 0x8d, 0x27, 0x14, 0x49, 0x97, 0x9b, 0x20, 0x81, 0x6c, 0x2b, 0xf9")
MAKE_THUNK(libasound, snd_device_name_hint, "0x1e, 0xae, 0x25, 0x56, 0xd8, 0x85, 0xf5, 0xdb, 0x8b, 0x10, 0x65, 0xc9, 0x5c, 0x38, 0xf, 0x34, 0xe2, 0x2d, 0x9e, 0x9d, 0x1b, 0x98, 0x36, 0x8, 0xc8, 0x11, 0x8e, 0xd, 0x7a, 0x8d, 0xc0, 0xb3")
MAKE_THUNK(libasound, snd_device_name_free_hint, "0xfd, 0xfc, 0xff, 0xb6, 0x87, 0xa8, 0xa0, 0x32, 0x7d, 0xab, 0x8f, 0x89, 0xb7, 0x5a, 0x78, 0xb9, 0x48, 0x89, 0x95, 0x90, 0x42, 0xce, 0x4, 0xf1, 0xa1, 0x2, 0xb9, 0x9e, 0xb3, 0xaa, 0x2b, 0x99")
MAKE_THUNK(libasound, snd_device_name_get_hint, "0x2c, 0x43, 0x53, 0x70, 0xf0, 0xb2, 0x17, 0x9e, 0x85, 0x1c, 0x3d, 0x89, 0x96, 0x8, 0xf4, 0x39, 0x6c, 0xb0, 0x63, 0x84, 0x4e, 0x94, 0xc7, 0xcf, 0xca, 0xb2, 0x7d, 0x79, 0x14, 0xef, 0xa2, 0x97")
MAKE_THUNK(libasound, snd_ctl_open, "0x8d, 0x80, 0x8e, 0x2c, 0xe0, 0xcf, 0xb8, 0xab, 0x77, 0xef, 0x0, 0xaa, 0xfb, 0x87, 0x7b, 0xb9, 0x41, 0x7, 0x98, 0xa0, 0x39, 0x7, 0x35, 0x13, 0xd, 0x66, 0xcf, 0x3, 0xe3, 0x9c, 0xaa, 0x68")
MAKE_THUNK(libasound, snd_ctl_open_lconf, "0x49, 0x82, 0x85, 0xa5, 0x1f, 0x4b, 0x33, 0xb2, 0x6b, 0x2e, 0xa9, 0xb2, 0x57, 0x5f, 0xc9, 0xf5, 0xe3, 0x98, 0x4e, 0x25, 0x4b, 0xa2, 0xc8, 0xc8, 0xe7, 0x19, 0x38, 0x91, 0x39, 0xbf, 0xc7, 0x69")
MAKE_THUNK(libasound, snd_ctl_open_fallback, "0x5f, 0x49, 0x4d, 0x36, 0xe8, 0xe1, 0xef, 0xf8, 0x49, 0xc1, 0x93, 0x88, 0x6c, 0x8f, 0xa9, 0xa1, 0x24, 0x82, 0x51, 0x5e, 0xf9, 0x77, 0xdf, 0x33, 0x6, 0x22, 0x39, 0x76, 0x8b, 0xd2, 0xc6, 0x5b")
MAKE_THUNK(libasound, snd_ctl_close, "0x6e, 0x35, 0xe3, 0x77, 0x7, 0x60, 0x93, 0xfa, 0xdf, 0x6f, 0x2a, 0xe5, 0x8d, 0x66, 0x69, 0xd3, 0x7c, 0x58, 0xfa, 0xbc, 0xff, 0xa0, 0x85, 0x26, 0xd2, 0xab, 0x18, 0x5d, 0xcc, 0x28, 0x67, 0xf1")
MAKE_THUNK(libasound, snd_ctl_nonblock, "0x33, 0x3a, 0xae, 0xd6, 0xa1, 0xc0, 0xc5, 0x18, 0xfe, 0x27, 0xaa, 0x2e, 0x59, 0xa2, 0xf2, 0x1c, 0x17, 0x73, 0x5, 0x38, 0x29, 0x59, 0x29, 0x67, 0x12, 0x55, 0xe7, 0xe8, 0xd5, 0xd0, 0xba, 0xa2")
MAKE_THUNK(libasound, snd_ctl_poll_descriptors_count, "0xaf, 0xc6, 0xe7, 0xf1, 0xf1, 0x23, 0x48, 0xa9, 0xc0, 0xf2, 0x98, 0xef, 0x92, 0xbe, 0x47, 0x29, 0x57, 0xa2, 0xca, 0x11, 0x9a, 0x9, 0x67, 0x2c, 0xd9, 0x90, 0xb8, 0x29, 0xa0, 0x82, 0xc1, 0x95")
MAKE_THUNK(libasound, snd_ctl_poll_descriptors, "0x12, 0xcc, 0xb3, 0x42, 0x43, 0x49, 0x28, 0x47, 0xf4, 0x62, 0x4b, 0x18, 0x17, 0x5c, 0x8c, 0x2b, 0xc6, 0xb9, 0x22, 0x1b, 0x46, 0xe9, 0x2f, 0x1b, 0x8d, 0xa8, 0x42, 0xca, 0x24, 0x1e, 0x17, 0x25")
MAKE_THUNK(libasound, snd_ctl_poll_descriptors_revents, "0xd2, 0x50, 0x23, 0x47, 0xe2, 0x3, 0xe, 0xe0, 0xf0, 0x76, 0xf4, 0xd9, 0x17, 0x79, 0x55, 0x3a, 0x2c, 0xe2, 0x9e, 0xaa, 0x46, 0x61, 0x9d, 0xdc, 0xc4, 0x1, 0x19, 0x3f, 0x89, 0x31, 0x52, 0xdf")
MAKE_THUNK(libasound, snd_ctl_subscribe_events, "0x6c, 0xf1, 0x39, 0x2b, 0x58, 0xa6, 0xc5, 0x99, 0x52, 0x16, 0x6d, 0xc2, 0xc7, 0xac, 0xb0, 0x98, 0x9a, 0xd8, 0x8e, 0xcc, 0x71, 0x69, 0x31, 0x91, 0x88, 0x40, 0xf7, 0xde, 0x25, 0x3, 0x74, 0xb3")
MAKE_THUNK(libasound, snd_ctl_card_info, "0x1f, 0x8e, 0x56, 0xe2, 0x33, 0x86, 0x36, 0x5f, 0x4e, 0x19, 0x9e, 0x3, 0xb6, 0x5e, 0xf0, 0x1, 0xe6, 0x68, 0x7e, 0x1e, 0x52, 0xaa, 0x51, 0x9c, 0xe2, 0x88, 0x2c, 0xd9, 0x6a, 0xa5, 0xbc, 0xcc")
MAKE_THUNK(libasound, snd_ctl_elem_list, "0xe0, 0xba, 0xd5, 0xee, 0xa8, 0x5a, 0xfa, 0xbd, 0xff, 0x98, 0x7e, 0x58, 0x4d, 0xb5, 0x7b, 0x63, 0xdf, 0xc9, 0x67, 0x3a, 0xcc, 0x32, 0xf1, 0x84, 0xa1, 0xa2, 0x2e, 0x1f, 0x2f, 0x94, 0x34, 0x86")
MAKE_THUNK(libasound, snd_ctl_elem_info, "0x23, 0x7f, 0xc8, 0xd8, 0xa2, 0x30, 0x94, 0x83, 0xb6, 0x58, 0xe6, 0xd7, 0x2, 0xea, 0xa1, 0x16, 0xdc, 0x96, 0x6e, 0x9, 0xea, 0xf, 0x6b, 0x6b, 0xb1, 0xd, 0x90, 0xa4, 0x15, 0x9e, 0xfa, 0xa8")
MAKE_THUNK(libasound, snd_ctl_elem_read, "0x7f, 0x4f, 0xa5, 0x69, 0xfd, 0x2a, 0x85, 0x7b, 0x0, 0xc3, 0x2f, 0x5d, 0x6d, 0x98, 0x3d, 0x88, 0x7f, 0x29, 0x86, 0xee, 0x67, 0x5, 0xe7, 0xa1, 0x3, 0x9e, 0x7c, 0xb, 0x2a, 0x63, 0xdc, 0x70")
MAKE_THUNK(libasound, snd_ctl_elem_write, "0xe3, 0x2e, 0xe1, 0xb5, 0x8c, 0xa2, 0xb5, 0x29, 0x6, 0x9d, 0xe4, 0x20, 0xd7, 0x3f, 0xba, 0x89, 0xbb, 0xf8, 0xbe, 0x1a, 0xd3, 0x14, 0x30, 0xf0, 0x75, 0xa6, 0x17, 0x7, 0x88, 0x7c, 0x58, 0xff")
MAKE_THUNK(libasound, snd_ctl_elem_lock, "0xad, 0xd3, 0xb0, 0xfb, 0x1, 0xbb, 0xd0, 0x1, 0x2c, 0xee, 0x35, 0xb8, 0x1, 0xc1, 0x6a, 0x7a, 0x71, 0x4b, 0xeb, 0x5a, 0x57, 0xff, 0x3b, 0xd2, 0x5c, 0xbb, 0x7a, 0x51, 0x6f, 0xd, 0xbc, 0xeb")
MAKE_THUNK(libasound, snd_ctl_elem_unlock, "0x73, 0x17, 0xc8, 0x3d, 0xd, 0x17, 0xf, 0xfa, 0xfa, 0xad, 0x6, 0xd2, 0x6d, 0xf2, 0x20, 0x19, 0x83, 0xbc, 0xdd, 0xeb, 0x70, 0x4, 0x43, 0xe2, 0x15, 0xb3, 0x5e, 0xe3, 0xf5, 0x24, 0xe6, 0x26")
MAKE_THUNK(libasound, snd_ctl_elem_tlv_read, "0x97, 0x4d, 0x57, 0x37, 0x28, 0x96, 0x55, 0xb8, 0xb1, 0x22, 0x63, 0xf7, 0x4a, 0xc6, 0x9d, 0x59, 0x6d, 0x6, 0x6d, 0x8b, 0x3f, 0x2, 0x1, 0x46, 0xf6, 0x74, 0x9c, 0x3, 0x50, 0x5e, 0xf2, 0xb7")
MAKE_THUNK(libasound, snd_ctl_elem_tlv_write, "0x4a, 0x93, 0x21, 0x29, 0x5c, 0x4, 0x3b, 0x51, 0x71, 0xed, 0xf7, 0xa7, 0xc2, 0x5b, 0xa7, 0xc3, 0x23, 0x34, 0x2b, 0x45, 0x3f, 0x1b, 0x67, 0xc1, 0xa0, 0xdc, 0xb3, 0x58, 0x93, 0x14, 0x7d, 0xb3")
MAKE_THUNK(libasound, snd_ctl_elem_tlv_command, "0x46, 0x90, 0x1c, 0x13, 0xa7, 0xe0, 0xb5, 0xb8, 0x9a, 0xcf, 0xd7, 0x1e, 0x35, 0x95, 0xa6, 0xd9, 0x31, 0x12, 0x7b, 0x4c, 0x19, 0x56, 0x67, 0x3c, 0x3f, 0x4f, 0x68, 0x9a, 0x54, 0x26, 0xdd, 0x36")
MAKE_THUNK(libasound, snd_ctl_hwdep_next_device, "0x13, 0x84, 0x28, 0xb6, 0xc2, 0x6b, 0xe9, 0xa2, 0xc1, 0x3d, 0x49, 0xbd, 0x1c, 0xf0, 0x65, 0x6c, 0x94, 0x9f, 0x46, 0x84, 0xaa, 0xbb, 0xb5, 0x48, 0xb2, 0xd2, 0x7f, 0xec, 0x4d, 0x4a, 0x5c, 0xd7")
MAKE_THUNK(libasound, snd_ctl_hwdep_info, "0xdf, 0xff, 0x13, 0x1b, 0x9, 0x8a, 0x8e, 0x18, 0x41, 0x83, 0x86, 0x2a, 0x15, 0x57, 0xfa, 0x3f, 0x25, 0xb3, 0x5e, 0xc2, 0x2f, 0xf8, 0xd9, 0xc4, 0xe5, 0x26, 0xcc, 0xa3, 0xe1, 0xbe, 0x9a, 0xcb")
MAKE_THUNK(libasound, snd_ctl_pcm_next_device, "0x4e, 0xb7, 0xa0, 0xe6, 0xb6, 0xba, 0x75, 0xd5, 0x6, 0xee, 0x64, 0xaa, 0x16, 0xaf, 0xb4, 0xcd, 0x63, 0x4c, 0x2a, 0xfe, 0xcb, 0x9d, 0x49, 0x93, 0x20, 0xa0, 0x6c, 0x80, 0x94, 0x3e, 0xaf, 0x91")
MAKE_THUNK(libasound, snd_ctl_pcm_info, "0x8e, 0xd, 0x73, 0x5c, 0x67, 0xef, 0xd8, 0x38, 0x2f, 0x28, 0xbd, 0x5e, 0x24, 0xe3, 0xd8, 0x61, 0xd7, 0x16, 0xbc, 0x8c, 0x92, 0xc6, 0xbd, 0x2e, 0xbe, 0xe3, 0xe4, 0x88, 0x95, 0xc4, 0xc8, 0xe9")
MAKE_THUNK(libasound, snd_ctl_pcm_prefer_subdevice, "0xbc, 0x45, 0x81, 0x2f, 0xa1, 0x7, 0x9a, 0x92, 0xd8, 0xff, 0xc8, 0x6a, 0xd6, 0x4d, 0x32, 0x34, 0x8e, 0xf4, 0x7e, 0xe6, 0x12, 0x41, 0xd4, 0x9e, 0xab, 0x2e, 0x8, 0x53, 0xc9, 0x62, 0x25, 0x6f")
MAKE_THUNK(libasound, snd_ctl_rawmidi_next_device, "0xf4, 0x6f, 0x3d, 0x91, 0x89, 0xf4, 0x5, 0x71, 0x63, 0xdd, 0xbf, 0x7, 0xec, 0xb7, 0x5c, 0xdf, 0xe6, 0x9b, 0x69, 0x38, 0xb1, 0xb2, 0x76, 0x1c, 0x13, 0x8b, 0x1a, 0x8e, 0x15, 0x5c, 0x37, 0x1e")
MAKE_THUNK(libasound, snd_ctl_rawmidi_info, "0xe4, 0xdf, 0x9a, 0x41, 0xa0, 0x7e, 0x3b, 0xd9, 0x1a, 0x7a, 0xc8, 0x68, 0xfd, 0xcc, 0x1a, 0x7b, 0x8, 0xc3, 0xbe, 0x40, 0x74, 0x5a, 0xf9, 0xee, 0xd6, 0x5b, 0x20, 0x26, 0x73, 0x24, 0xde, 0x2b")
MAKE_THUNK(libasound, snd_ctl_rawmidi_prefer_subdevice, "0xe7, 0xc4, 0x88, 0xe9, 0x8, 0x1b, 0xac, 0x21, 0xb2, 0xe3, 0x6, 0xe5, 0x81, 0xad, 0xf5, 0x8c, 0xad, 0xcc, 0xde, 0x24, 0x31, 0x77, 0x57, 0xb3, 0xa, 0x10, 0x5c, 0x25, 0x8f, 0xda, 0xe5, 0xd0")
MAKE_THUNK(libasound, snd_ctl_set_power_state, "0xda, 0xcb, 0x1f, 0x80, 0xd, 0x4c, 0x79, 0x4f, 0xc3, 0x27, 0x1, 0x6f, 0xb2, 0x69, 0x2c, 0x94, 0x4b, 0xe0, 0x4a, 0x31, 0xdf, 0xdd, 0xc2, 0xf1, 0x23, 0x98, 0x50, 0xd9, 0xb7, 0xb9, 0x82, 0x6d")
MAKE_THUNK(libasound, snd_ctl_get_power_state, "0xbc, 0xf4, 0xb5, 0x85, 0x61, 0x3e, 0xe4, 0x7a, 0x5c, 0xfa, 0x46, 0x97, 0x6f, 0x4a, 0x8e, 0x77, 0x4, 0x98, 0xfa, 0x22, 0xb8, 0x4, 0xe7, 0x76, 0xbb, 0x3f, 0xf2, 0x65, 0xb, 0xfe, 0xcc, 0xfa")
MAKE_THUNK(libasound, snd_ctl_read, "0xa8, 0x1c, 0x7d, 0x96, 0x18, 0x0, 0x82, 0xd6, 0x73, 0x7b, 0x49, 0xf6, 0x7a, 0x98, 0xa7, 0x2d, 0xc0, 0xdf, 0x6a, 0xd7, 0x50, 0xeb, 0xb8, 0x98, 0x19, 0x4a, 0x61, 0x44, 0x8f, 0xdb, 0x46, 0xe")
MAKE_THUNK(libasound, snd_ctl_wait, "0x10, 0xde, 0xc9, 0x5c, 0x2f, 0x19, 0xab, 0x46, 0x73, 0xe5, 0xa2, 0x5d, 0x68, 0xc8, 0x63, 0x60, 0xaa, 0xa0, 0x2b, 0x40, 0x31, 0xa9, 0xe9, 0xfa, 0xe4, 0xa2, 0xac, 0xf1, 0xb6, 0xa, 0x2c, 0xcc")
MAKE_THUNK(libasound, snd_ctl_name, "0x3f, 0xbd, 0x9b, 0x3f, 0xfc, 0x46, 0x25, 0xe9, 0x2f, 0xcc, 0x5f, 0x6b, 0x64, 0x5b, 0xbf, 0xaf, 0xb2, 0x5, 0xde, 0x5b, 0x43, 0xcb, 0x28, 0x4, 0x9d, 0xab, 0x35, 0xa3, 0x9d, 0x40, 0xb8, 0xdd")
MAKE_THUNK(libasound, snd_ctl_type, "0xf1, 0xde, 0xfd, 0x90, 0x93, 0xa2, 0xcf, 0x63, 0x9a, 0xd6, 0x6a, 0xf4, 0x9f, 0xda, 0xc2, 0xb7, 0xd1, 0xd7, 0x1a, 0x37, 0xf3, 0x17, 0x39, 0x70, 0xe1, 0xe9, 0x56, 0x98, 0xb6, 0x9, 0x43, 0xb4")
MAKE_THUNK(libasound, snd_ctl_elem_type_name, "0x7a, 0xca, 0x16, 0xb6, 0x5, 0xad, 0xf2, 0x1b, 0xdf, 0x3b, 0xe2, 0x5d, 0xf1, 0xf2, 0xc, 0x53, 0x1b, 0x3c, 0xc7, 0xc, 0x1c, 0x3b, 0x6a, 0xf9, 0xf0, 0xac, 0x14, 0xc8, 0x3d, 0xe9, 0xa8, 0x70")
MAKE_THUNK(libasound, snd_ctl_elem_iface_name, "0x3e, 0x3c, 0xe0, 0x3d, 0xd, 0x82, 0x84, 0x55, 0x24, 0xa6, 0x16, 0x48, 0x3a, 0x5a, 0x42, 0x99, 0x7f, 0x20, 0x32, 0x8e, 0xe5, 0x92, 0x52, 0x18, 0x81, 0x1c, 0x5c, 0xaf, 0x67, 0x30, 0xad, 0x21")
MAKE_THUNK(libasound, snd_ctl_event_type_name, "0xfd, 0xe2, 0xa6, 0x2d, 0x5c, 0xdf, 0x86, 0x82, 0x92, 0x9d, 0x24, 0xc7, 0xe6, 0xe2, 0xd1, 0x38, 0xba, 0xaa, 0xc9, 0xd2, 0x5, 0x4b, 0x1b, 0xc9, 0x61, 0x93, 0xb5, 0x6f, 0x7f, 0x37, 0x6, 0x6e")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_mask, "0xf5, 0x75, 0x1b, 0x65, 0xf1, 0x94, 0xe4, 0xad, 0x8c, 0x9d, 0xf7, 0x55, 0x21, 0x4c, 0x50, 0xc5, 0xba, 0xf4, 0x50, 0x6d, 0x86, 0x4b, 0xdb, 0x46, 0xb5, 0x3c, 0xe4, 0xcd, 0xcb, 0x55, 0x93, 0x3d")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_numid, "0x9, 0xc0, 0xdb, 0x2b, 0x75, 0x39, 0x44, 0xad, 0xda, 0xa8, 0xa4, 0x3a, 0x76, 0x36, 0x18, 0xfe, 0xe4, 0x71, 0xd1, 0x10, 0x8c, 0x9f, 0xbb, 0x85, 0x95, 0x6c, 0x97, 0x4b, 0x1d, 0x95, 0x40, 0xd3")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_id, "0x13, 0x75, 0x35, 0xf3, 0x88, 0x23, 0x75, 0xe8, 0x9c, 0x21, 0x35, 0x31, 0xf0, 0x0, 0xb1, 0xd7, 0x29, 0x1b, 0x93, 0xa1, 0xfe, 0xb6, 0x6f, 0xdc, 0x75, 0x75, 0xdc, 0xf0, 0xae, 0x4d, 0xa6, 0x91")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_interface, "0x9a, 0xe8, 0x7, 0xe5, 0x12, 0xed, 0x65, 0x69, 0xd0, 0x99, 0xd0, 0xb1, 0xae, 0xdd, 0x8f, 0x6f, 0xb2, 0x3c, 0x86, 0x48, 0xa3, 0xeb, 0x1f, 0xd5, 0xf4, 0x9, 0x27, 0xd9, 0xda, 0xdc, 0xfb, 0x21")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_device, "0x2e, 0x75, 0x21, 0xb7, 0x1a, 0x37, 0x10, 0x85, 0x4e, 0xae, 0x4e, 0x46, 0x8, 0x50, 0x93, 0x53, 0x84, 0x35, 0xa8, 0xb, 0xcc, 0x87, 0x93, 0x8, 0xd1, 0xa0, 0x97, 0x40, 0x40, 0x37, 0x66, 0x5f")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_subdevice, "0x8f, 0x22, 0xac, 0xf2, 0xac, 0x41, 0xe4, 0xf1, 0xce, 0x2, 0x48, 0xe4, 0x24, 0x98, 0x6, 0xf4, 0x55, 0x59, 0xc1, 0xdc, 0x29, 0x14, 0x44, 0x8b, 0x8b, 0xa0, 0x60, 0x4b, 0xe, 0x11, 0x95, 0x47")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_name, "0x77, 0x7d, 0x29, 0xb9, 0xef, 0x7f, 0xea, 0x98, 0x89, 0xf2, 0xbe, 0x21, 0xbb, 0xb3, 0x21, 0xf2, 0xc8, 0x68, 0x84, 0x36, 0x25, 0xd6, 0x82, 0x1b, 0x75, 0x3d, 0xa5, 0x57, 0x90, 0x5f, 0x24, 0x35")
MAKE_THUNK(libasound, snd_ctl_event_elem_get_index, "0x67, 0x1e, 0x43, 0x46, 0xa3, 0x21, 0x5e, 0x3d, 0x71, 0xd9, 0x31, 0x65, 0x83, 0xce, 0xd1, 0xb3, 0x67, 0x40, 0x10, 0xdf, 0x57, 0xd9, 0x93, 0x27, 0xac, 0xaa, 0x5a, 0x4f, 0xdf, 0xe8, 0x29, 0x13")
MAKE_THUNK(libasound, snd_ctl_elem_list_alloc_space, "0xf0, 0xa3, 0x3a, 0xd, 0x25, 0xe8, 0xc7, 0xca, 0xfa, 0x3f, 0x3a, 0xbf, 0xc0, 0xcd, 0x24, 0xfa, 0x75, 0xa2, 0x8c, 0xa3, 0x7f, 0x2c, 0xb7, 0x17, 0xb3, 0x69, 0x1a, 0x6, 0xb7, 0xf3, 0x2d, 0xd")
MAKE_THUNK(libasound, snd_ctl_elem_list_free_space, "0x90, 0x90, 0x34, 0x95, 0xa6, 0x29, 0x7e, 0x8d, 0x86, 0xfb, 0x63, 0x8, 0xc4, 0xbf, 0xf3, 0x8a, 0x65, 0x77, 0x17, 0x80, 0x97, 0x54, 0xa9, 0x38, 0x9d, 0x5c, 0xe5, 0x65, 0x4a, 0x51, 0xe7, 0x5")
MAKE_THUNK(libasound, snd_ctl_ascii_elem_id_get, "0x1b, 0x37, 0xb7, 0xc5, 0xe1, 0xaf, 0x7, 0x6f, 0x38, 0xcf, 0x39, 0x20, 0x6d, 0xde, 0xb0, 0x8c, 0x7f, 0x15, 0x1b, 0x5d, 0x95, 0x37, 0x4f, 0xf5, 0xe4, 0x70, 0x65, 0x86, 0x48, 0xf, 0x6f, 0x58")
MAKE_THUNK(libasound, snd_ctl_ascii_elem_id_parse, "0x6b, 0x4b, 0x94, 0x63, 0x55, 0xb7, 0xd4, 0xde, 0xbc, 0x9, 0x7a, 0x73, 0xcc, 0x4d, 0x30, 0x41, 0x21, 0x79, 0xcc, 0xa1, 0x59, 0xe, 0xa, 0x24, 0xbd, 0xd4, 0x80, 0x9d, 0xf1, 0x69, 0xae, 0x61")
MAKE_THUNK(libasound, snd_ctl_ascii_value_parse, "0x74, 0x4c, 0x7d, 0x42, 0x75, 0xcc, 0x54, 0x3b, 0xd4, 0xfc, 0xcd, 0x18, 0x2, 0x1d, 0x4, 0x7e, 0x3a, 0xa1, 0xe2, 0xef, 0xd8, 0x43, 0x77, 0x8f, 0xc6, 0x25, 0xa4, 0x20, 0xfb, 0xdf, 0x3e, 0x75")
MAKE_THUNK(libasound, snd_ctl_elem_id_sizeof, "0x59, 0x47, 0x58, 0xae, 0x53, 0xb, 0xc8, 0x86, 0xe7, 0xee, 0x2b, 0xe7, 0x2c, 0x58, 0xe7, 0xa7, 0x41, 0x4e, 0xbd, 0x1, 0x89, 0x76, 0x2e, 0x56, 0xac, 0xb1, 0xfd, 0xd1, 0xb5, 0x4d, 0xf1, 0x95")
MAKE_THUNK(libasound, snd_ctl_elem_id_malloc, "0x2a, 0x32, 0x20, 0xc6, 0xf4, 0x61, 0x4c, 0x7d, 0x20, 0x75, 0x1f, 0xc8, 0xde, 0x29, 0x47, 0xab, 0xba, 0x74, 0x87, 0xa2, 0xe, 0x91, 0xb7, 0xc2, 0xe7, 0xe3, 0x33, 0x87, 0x41, 0xd2, 0xa0, 0xa3")
MAKE_THUNK(libasound, snd_ctl_elem_id_free, "0x65, 0xef, 0xc1, 0x31, 0x41, 0xc5, 0xd4, 0x2a, 0xff, 0x22, 0x29, 0xf9, 0x1b, 0x51, 0xd, 0xa, 0x34, 0x9c, 0x8, 0xab, 0xc6, 0x4, 0x34, 0x2, 0x2d, 0x4f, 0xba, 0x7a, 0x1f, 0xb3, 0xc9, 0xa")
MAKE_THUNK(libasound, snd_ctl_elem_id_clear, "0x10, 0x4b, 0x93, 0xe9, 0xab, 0x7f, 0x59, 0x6a, 0x96, 0xf7, 0xfa, 0xab, 0xbb, 0x8c, 0x36, 0x3d, 0xca, 0x28, 0x60, 0xe2, 0x52, 0x24, 0xec, 0x75, 0x5d, 0x3b, 0x50, 0x27, 0xd2, 0x56, 0x8b, 0x70")
MAKE_THUNK(libasound, snd_ctl_elem_id_copy, "0x46, 0x25, 0x9, 0x46, 0x83, 0x4a, 0xe9, 0xfa, 0x86, 0xbb, 0x7d, 0x23, 0x8b, 0x4d, 0x7f, 0x7a, 0xc, 0xfa, 0xc8, 0xce, 0x6c, 0x52, 0xb7, 0x9, 0xeb, 0x8d, 0x49, 0xdc, 0xab, 0x25, 0x7c, 0x2f")
MAKE_THUNK(libasound, snd_ctl_elem_id_get_numid, "0x5c, 0x22, 0xc2, 0x56, 0xed, 0x9d, 0x64, 0x61, 0x4e, 0x52, 0xae, 0xf0, 0x89, 0x4, 0x97, 0xb7, 0x11, 0xe8, 0x86, 0x75, 0xa, 0x9d, 0xad, 0x38, 0xbc, 0xe8, 0x6c, 0x5a, 0xd5, 0xda, 0x85, 0xfc")
MAKE_THUNK(libasound, snd_ctl_elem_id_get_interface, "0x18, 0xf5, 0xf0, 0xde, 0x94, 0x90, 0x11, 0x6f, 0x5f, 0x8c, 0x6d, 0xa0, 0x32, 0x5d, 0x9d, 0xe5, 0xb7, 0x71, 0x29, 0xb5, 0x3a, 0x20, 0xe9, 0x8c, 0x4b, 0xbe, 0x95, 0xe, 0xb5, 0xb7, 0x6c, 0x47")
MAKE_THUNK(libasound, snd_ctl_elem_id_get_device, "0x52, 0x3b, 0x97, 0x2, 0x34, 0x5f, 0x61, 0x23, 0x24, 0xf5, 0x71, 0x79, 0x22, 0xc, 0x15, 0x56, 0xc0, 0x23, 0xab, 0xb0, 0x15, 0x55, 0x8f, 0xb8, 0x93, 0xec, 0x78, 0x7c, 0x57, 0xbd, 0xe7, 0x3b")
MAKE_THUNK(libasound, snd_ctl_elem_id_get_subdevice, "0x2d, 0xf4, 0x8c, 0xb9, 0x9e, 0x66, 0x3e, 0x62, 0x3d, 0xdd, 0xf7, 0xbc, 0xcb, 0xf2, 0x97, 0x38, 0x69, 0xd7, 0xaf, 0xa3, 0x36, 0x56, 0xc2, 0x30, 0xfa, 0x4d, 0x59, 0x6c, 0x6c, 0x2c, 0x1a, 0x23")
MAKE_THUNK(libasound, snd_ctl_elem_id_get_name, "0xa1, 0x0, 0xff, 0x7c, 0x29, 0x4, 0xf2, 0x75, 0xb0, 0x42, 0x76, 0x5a, 0x8f, 0x41, 0x25, 0xbd, 0x30, 0xa3, 0x2b, 0xf, 0x72, 0xa5, 0xa1, 0xff, 0xd0, 0x18, 0xf2, 0x62, 0xfc, 0x2c, 0x96, 0x7c")
MAKE_THUNK(libasound, snd_ctl_elem_id_get_index, "0xf0, 0xfe, 0xc4, 0x88, 0xab, 0x5b, 0xe9, 0x5a, 0x1b, 0x13, 0x5d, 0x46, 0x4c, 0xa5, 0x16, 0x3, 0x97, 0x6b, 0xcf, 0x4e, 0x3f, 0x28, 0xbd, 0xdd, 0xba, 0x27, 0x6f, 0x24, 0x81, 0xe0, 0xfa, 0xe9")
MAKE_THUNK(libasound, snd_ctl_elem_id_set_numid, "0x21, 0xd8, 0x4c, 0xe6, 0x40, 0x99, 0x39, 0xab, 0xc2, 0x15, 0x75, 0xe3, 0x1e, 0x86, 0x58, 0x6, 0x2, 0xed, 0x65, 0x85, 0x7, 0x85, 0x48, 0x74, 0x1b, 0xad, 0x19, 0xbc, 0x41, 0x39, 0x3d, 0x2f")
MAKE_THUNK(libasound, snd_ctl_elem_id_set_interface, "0x62, 0xb6, 0xda, 0x38, 0x57, 0xcb, 0xa2, 0xeb, 0x66, 0x2e, 0x70, 0x34, 0x6e, 0x9b, 0xda, 0xdc, 0xba, 0x7d, 0xbb, 0x29, 0xaf, 0x94, 0x7a, 0x21, 0x91, 0x30, 0x5a, 0x3f, 0xb6, 0xe3, 0xc1, 0x56")
MAKE_THUNK(libasound, snd_ctl_elem_id_set_device, "0x33, 0x77, 0xc2, 0x6d, 0x37, 0xec, 0xf2, 0xb0, 0x3, 0x8e, 0x1b, 0xe0, 0xd8, 0xf5, 0x65, 0x55, 0x81, 0x6b, 0x1a, 0xa3, 0x40, 0x30, 0xb3, 0x98, 0x3d, 0xea, 0x84, 0x17, 0x92, 0xc3, 0xcb, 0x3b")
MAKE_THUNK(libasound, snd_ctl_elem_id_set_subdevice, "0x60, 0x43, 0x68, 0xdd, 0x57, 0x33, 0x55, 0x4, 0xf9, 0x74, 0xa9, 0xf9, 0x55, 0x9, 0x38, 0x2a, 0x9f, 0x81, 0x74, 0x5b, 0x37, 0x7, 0x71, 0x2e, 0xb0, 0xdf, 0xc2, 0xae, 0x5, 0xfd, 0xe7, 0xfa")
MAKE_THUNK(libasound, snd_ctl_elem_id_set_name, "0x60, 0x84, 0x8a, 0xdc, 0x2e, 0x4e, 0x3d, 0x7e, 0x8a, 0x69, 0xc2, 0x61, 0x35, 0xac, 0x25, 0x68, 0xf4, 0x70, 0x2f, 0xab, 0x59, 0xd0, 0x9b, 0xa6, 0x3d, 0xe9, 0x75, 0xaa, 0x0, 0xd8, 0x6d, 0x43")
MAKE_THUNK(libasound, snd_ctl_elem_id_set_index, "0x6c, 0xae, 0xee, 0xcb, 0x5b, 0xf1, 0xbd, 0xb5, 0xdc, 0x17, 0x2e, 0x94, 0xfb, 0xba, 0x8d, 0xc2, 0x88, 0xfe, 0xb8, 0x18, 0x74, 0xcc, 0x8d, 0xca, 0xcf, 0x76, 0x45, 0x60, 0xd6, 0x5b, 0xf9, 0x84")
MAKE_THUNK(libasound, snd_ctl_card_info_sizeof, "0x26, 0x59, 0x1a, 0x62, 0xff, 0x59, 0xf0, 0x53, 0x9d, 0x37, 0x9e, 0xdb, 0xc7, 0xe, 0x5b, 0xd7, 0x7d, 0x45, 0xd5, 0x43, 0xa2, 0x7b, 0xfd, 0xe8, 0xf5, 0xd5, 0x2e, 0xc, 0x89, 0x99, 0x88, 0xe2")
MAKE_THUNK(libasound, snd_ctl_card_info_malloc, "0x2b, 0x5d, 0x65, 0x45, 0x61, 0x5e, 0x86, 0x1f, 0xfc, 0xb2, 0x4a, 0x11, 0x4f, 0x57, 0xb, 0xe0, 0xbe, 0x9f, 0xdd, 0xf2, 0x12, 0x9c, 0x8b, 0x2c, 0xa9, 0x7d, 0x9e, 0xb6, 0xc6, 0x1f, 0xf, 0x7b")
MAKE_THUNK(libasound, snd_ctl_card_info_free, "0x48, 0xe8, 0x83, 0xc3, 0x32, 0x58, 0xe8, 0x59, 0xa0, 0x16, 0x7a, 0x4b, 0x4e, 0xfb, 0x56, 0xa1, 0xb0, 0xa0, 0x55, 0xbc, 0x74, 0xcf, 0xb0, 0xdc, 0xb5, 0x9, 0xc0, 0xce, 0x62, 0xcc, 0xee, 0xcf")
MAKE_THUNK(libasound, snd_ctl_card_info_clear, "0x29, 0x3b, 0xa6, 0x11, 0xec, 0xf9, 0x88, 0x30, 0x19, 0x97, 0xc1, 0x1d, 0xdc, 0xdf, 0xda, 0xcc, 0xb1, 0x77, 0x96, 0x51, 0x81, 0xc8, 0x0, 0xaa, 0x75, 0xa2, 0x74, 0x9, 0xff, 0x1b, 0x13, 0x72")
MAKE_THUNK(libasound, snd_ctl_card_info_copy, "0x3c, 0xcb, 0xec, 0x54, 0x17, 0xfb, 0x9, 0xd6, 0xdb, 0xf0, 0x86, 0x56, 0x1e, 0x35, 0x30, 0xcb, 0x60, 0x91, 0xd6, 0x7d, 0xff, 0xf6, 0x2f, 0x6f, 0x7f, 0xb3, 0xb1, 0x21, 0x2f, 0x7d, 0xd9, 0xb8")
MAKE_THUNK(libasound, snd_ctl_card_info_get_card, "0x95, 0xee, 0x9b, 0x56, 0x6b, 0x86, 0x17, 0x13, 0xe0, 0x6b, 0x31, 0x9, 0x86, 0x6b, 0x50, 0xe0, 0xe7, 0x24, 0xf, 0xbf, 0xa7, 0x4f, 0xc7, 0x91, 0x77, 0x22, 0x2d, 0xa8, 0xf6, 0x75, 0xd6, 0x45")
MAKE_THUNK(libasound, snd_ctl_card_info_get_id, "0xbf, 0x80, 0x76, 0x20, 0x1e, 0x41, 0x4c, 0xf0, 0x32, 0x65, 0x9b, 0x4c, 0x3b, 0xa0, 0xde, 0xb2, 0xe, 0xac, 0x23, 0xb6, 0xd1, 0x13, 0x7, 0x4b, 0x73, 0x3, 0xd3, 0x7a, 0x7a, 0x9f, 0xad, 0xdc")
MAKE_THUNK(libasound, snd_ctl_card_info_get_driver, "0x9d, 0x21, 0x8f, 0x43, 0xfe, 0x99, 0x76, 0x2e, 0xd9, 0xb7, 0x1d, 0x5, 0xfc, 0x5f, 0xca, 0x80, 0x9a, 0xeb, 0x92, 0x92, 0xe1, 0xd1, 0xde, 0x9d, 0xbd, 0x79, 0x44, 0x61, 0xd8, 0x4b, 0x4d, 0x6f")
MAKE_THUNK(libasound, snd_ctl_card_info_get_name, "0x35, 0xe1, 0xec, 0x24, 0x2f, 0xb9, 0xb9, 0x98, 0x7a, 0x7c, 0xdd, 0x7d, 0x1f, 0x8d, 0xd3, 0x9a, 0x78, 0x74, 0xcc, 0xde, 0x41, 0x0, 0xd, 0xf4, 0x11, 0xe9, 0x2f, 0x54, 0x9f, 0xbf, 0xfd, 0x7f")
MAKE_THUNK(libasound, snd_ctl_card_info_get_longname, "0x31, 0xab, 0xb0, 0x2e, 0x6b, 0xfa, 0xb0, 0x46, 0x8, 0x1c, 0x55, 0xb, 0x73, 0xfa, 0xf5, 0x43, 0x2, 0x3b, 0xa, 0x8b, 0x16, 0x4c, 0x24, 0x51, 0xaf, 0x5c, 0xe4, 0x87, 0x89, 0x15, 0x8, 0x52")
MAKE_THUNK(libasound, snd_ctl_card_info_get_mixername, "0xc6, 0x91, 0x97, 0x21, 0x87, 0x2a, 0x9d, 0x8f, 0xda, 0xe2, 0xd9, 0x28, 0x5c, 0x4, 0x12, 0x92, 0xe1, 0x73, 0xfa, 0x4a, 0x91, 0x3, 0x4d, 0x88, 0xfa, 0xd9, 0x90, 0xe, 0x22, 0x7b, 0x71, 0x6a")
MAKE_THUNK(libasound, snd_ctl_card_info_get_components, "0xb, 0x1d, 0xf1, 0x32, 0x89, 0x5, 0x5b, 0x9, 0xdf, 0x59, 0x94, 0x25, 0xf2, 0xeb, 0x61, 0xb7, 0x6a, 0xf8, 0x6, 0x10, 0x91, 0xb6, 0x4b, 0xde, 0x5, 0xfd, 0xe, 0xd0, 0x2b, 0x35, 0x28, 0x77")
MAKE_THUNK(libasound, snd_ctl_event_sizeof, "0x46, 0x12, 0x9e, 0xec, 0xcb, 0xdf, 0xf9, 0x4a, 0x3a, 0x8a, 0x78, 0x67, 0xa6, 0xfd, 0xbb, 0xb0, 0x8d, 0x93, 0x7, 0x62, 0xa1, 0x14, 0x7f, 0x18, 0x93, 0x9a, 0xc6, 0x1, 0x4b, 0x8e, 0xbb, 0xa8")
MAKE_THUNK(libasound, snd_ctl_event_malloc, "0x91, 0x61, 0xa2, 0xd7, 0xcc, 0xdc, 0xf4, 0x99, 0x6c, 0xd3, 0x86, 0xab, 0x53, 0x96, 0x60, 0x53, 0x12, 0xca, 0xc9, 0x9e, 0x72, 0x1a, 0x4c, 0xaf, 0x5, 0xf8, 0xa7, 0x83, 0xb9, 0x1f, 0xe7, 0x62")
MAKE_THUNK(libasound, snd_ctl_event_free, "0x84, 0x4f, 0x9e, 0xf4, 0xaf, 0xe5, 0x80, 0x1d, 0xee, 0xe6, 0xa6, 0x0, 0x35, 0x4d, 0xa4, 0xa8, 0xf7, 0xea, 0xe1, 0x38, 0x7, 0x1b, 0x71, 0x1b, 0x85, 0xda, 0x16, 0x17, 0x28, 0x6, 0xb5, 0x6a")
MAKE_THUNK(libasound, snd_ctl_event_clear, "0xdd, 0xf2, 0xdf, 0xb9, 0x47, 0x5a, 0xe6, 0x51, 0x17, 0xb, 0x16, 0xe1, 0x4f, 0xc8, 0x2d, 0x1e, 0x32, 0x34, 0x48, 0x3e, 0xb8, 0x33, 0x72, 0x95, 0xb2, 0xf7, 0x8a, 0x92, 0x6f, 0xef, 0xfa, 0x9")
MAKE_THUNK(libasound, snd_ctl_event_copy, "0x17, 0xe3, 0xed, 0x4d, 0xf1, 0xfc, 0x42, 0x8a, 0x31, 0x6, 0x7a, 0x15, 0x64, 0xfc, 0xaa, 0xc3, 0xb6, 0xa4, 0x21, 0x5b, 0x90, 0xf, 0x6a, 0x8, 0x39, 0xdd, 0x1e, 0xf3, 0x5b, 0xc0, 0xfb, 0xc5")
MAKE_THUNK(libasound, snd_ctl_event_get_type, "0x55, 0xd7, 0xa5, 0xe3, 0x22, 0x9b, 0xf3, 0xf3, 0x6f, 0x1c, 0xc1, 0xd4, 0x8f, 0x6f, 0x65, 0xf, 0xd, 0x68, 0x7d, 0x5f, 0x47, 0xbc, 0xb3, 0xf1, 0x5c, 0x6f, 0x2d, 0x49, 0xe2, 0x8b, 0x13, 0x3")
MAKE_THUNK(libasound, snd_ctl_elem_list_sizeof, "0x2b, 0x5b, 0x34, 0xa9, 0xd8, 0x18, 0x1b, 0xc9, 0x67, 0x3e, 0x76, 0x95, 0x52, 0xab, 0x40, 0x15, 0x32, 0x40, 0x27, 0xa4, 0xb7, 0xf9, 0xad, 0xa8, 0x76, 0x6b, 0x7f, 0xb0, 0x9f, 0xc9, 0xe5, 0xec")
MAKE_THUNK(libasound, snd_ctl_elem_list_malloc, "0xdc, 0x39, 0x61, 0x9d, 0xb5, 0x31, 0xbb, 0x38, 0xe5, 0x89, 0x41, 0xe0, 0x20, 0x9a, 0x88, 0x42, 0x1f, 0xfd, 0x8c, 0x42, 0x31, 0xc9, 0x4b, 0xe5, 0xe1, 0xa, 0x3a, 0x76, 0x2d, 0x88, 0xb6, 0xee")
MAKE_THUNK(libasound, snd_ctl_elem_list_free, "0xcd, 0xf4, 0xf0, 0xa, 0xe8, 0xb4, 0x94, 0x90, 0xbc, 0x51, 0x32, 0x13, 0x4f, 0xf, 0x5f, 0x55, 0x41, 0xf4, 0xcd, 0x7c, 0x5f, 0x0, 0x4a, 0x52, 0x9b, 0xe, 0xb8, 0x26, 0x7c, 0xc2, 0x7d, 0x82")
MAKE_THUNK(libasound, snd_ctl_elem_list_clear, "0xea, 0x4f, 0xa1, 0x67, 0x49, 0x9, 0xf, 0x1, 0xb2, 0xb7, 0x8b, 0x4b, 0xc0, 0x1b, 0x1c, 0xdd, 0x7f, 0xa9, 0x3c, 0xcc, 0x1, 0xda, 0x46, 0xf9, 0x9c, 0x2b, 0x4d, 0x76, 0x9, 0x79, 0x15, 0xfb")
MAKE_THUNK(libasound, snd_ctl_elem_list_copy, "0x5c, 0x84, 0xf, 0x6a, 0xa6, 0x37, 0x35, 0x30, 0x85, 0xa9, 0x2e, 0xbb, 0x36, 0xc2, 0x3a, 0xea, 0xfa, 0x20, 0xbf, 0x9d, 0x3f, 0x83, 0xeb, 0x33, 0x3c, 0xbf, 0xb, 0x34, 0xe8, 0x18, 0x42, 0x5a")
MAKE_THUNK(libasound, snd_ctl_elem_list_set_offset, "0x93, 0xee, 0x6a, 0xa5, 0xa7, 0x4c, 0x8c, 0x47, 0x23, 0x59, 0xed, 0x43, 0x20, 0x22, 0x68, 0xe, 0x17, 0xb4, 0x7f, 0xdb, 0xb5, 0xf0, 0x90, 0x79, 0xb3, 0x3b, 0xd0, 0x85, 0x3e, 0x10, 0x46, 0xb3")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_used, "0x5e, 0xd4, 0x61, 0x90, 0xc1, 0x27, 0x6c, 0xd9, 0x32, 0x59, 0x66, 0xbf, 0xe2, 0x7e, 0x46, 0x38, 0x16, 0x77, 0xad, 0x93, 0xb9, 0xca, 0x78, 0xa1, 0x50, 0x8, 0xf, 0x7d, 0xe3, 0xea, 0xe5, 0x73")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_count, "0xe5, 0xbe, 0x3b, 0xbb, 0xe, 0x25, 0xd0, 0x53, 0xca, 0xc9, 0x74, 0xc4, 0xb, 0x4e, 0x1f, 0x8c, 0xf7, 0x1d, 0x19, 0x40, 0xa8, 0x16, 0x6f, 0x18, 0x46, 0x79, 0xc8, 0x10, 0x90, 0xb0, 0xfa, 0xc")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_id, "0xa6, 0xc6, 0xf4, 0xd7, 0xc9, 0xc3, 0x57, 0xcf, 0xc9, 0xc6, 0x39, 0x56, 0x18, 0xac, 0xa9, 0x45, 0x6b, 0xd7, 0xad, 0x41, 0x7, 0x97, 0xfc, 0x6d, 0xe, 0x37, 0x92, 0x8c, 0x2c, 0xae, 0x48, 0xda")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_numid, "0xfa, 0x56, 0x5b, 0x4c, 0x57, 0x2a, 0x37, 0x89, 0x73, 0x96, 0x4d, 0x24, 0xcd, 0x27, 0xed, 0x85, 0x79, 0xb4, 0x4b, 0xfd, 0x27, 0x17, 0x9a, 0x27, 0x94, 0x8e, 0x6d, 0x5, 0x76, 0x28, 0x61, 0x10")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_interface, "0x99, 0x54, 0x5a, 0x8a, 0xdc, 0x6b, 0x99, 0x6c, 0x7c, 0x23, 0x1e, 0x4d, 0x0, 0x14, 0x0, 0xa4, 0x2f, 0x9e, 0x80, 0x5, 0xe3, 0xbd, 0x1e, 0xb8, 0x49, 0x86, 0x19, 0x3c, 0x86, 0x2f, 0x23, 0x82")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_device, "0x43, 0xed, 0xed, 0xa9, 0x6b, 0x2f, 0x30, 0x8b, 0xcb, 0x6e, 0x15, 0xd7, 0xc9, 0xdf, 0xf2, 0x70, 0x1e, 0x9b, 0x6, 0x6e, 0x5a, 0x93, 0x8f, 0x55, 0x1d, 0x84, 0x7d, 0xd6, 0x8f, 0x2a, 0xaa, 0x18")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_subdevice, "0x60, 0x3b, 0xd4, 0xd4, 0x5a, 0x65, 0x91, 0xd3, 0x10, 0x25, 0xbe, 0x63, 0x1a, 0x73, 0xbb, 0x62, 0xfa, 0x6, 0x1c, 0x69, 0xcb, 0x6, 0xc5, 0x3e, 0x63, 0xf2, 0x8, 0xec, 0x6a, 0x96, 0xd6, 0x91")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_name, "0xca, 0xea, 0x67, 0xc0, 0xa1, 0x79, 0xd6, 0x3, 0xc6, 0xcb, 0x66, 0xf2, 0xd1, 0x40, 0x5a, 0x53, 0x6d, 0xd9, 0x99, 0xf9, 0xa3, 0x7b, 0xa8, 0x25, 0xb0, 0xa8, 0xc, 0x91, 0xcf, 0xca, 0x78, 0x80")
MAKE_THUNK(libasound, snd_ctl_elem_list_get_index, "0x45, 0xa2, 0xb1, 0x62, 0xf1, 0xb0, 0x2c, 0xa1, 0x1b, 0xf1, 0x21, 0x54, 0xe6, 0xfa, 0x3d, 0xbb, 0xea, 0xa1, 0xa7, 0xa5, 0xbf, 0x66, 0x90, 0x52, 0x49, 0x2b, 0xd3, 0x2b, 0xbc, 0xb0, 0x3, 0xde")
MAKE_THUNK(libasound, snd_ctl_elem_info_sizeof, "0x41, 0x20, 0x9f, 0xb5, 0x1, 0xd, 0x57, 0x66, 0xc2, 0x41, 0xd0, 0x70, 0xb4, 0x5a, 0xff, 0x9d, 0x7f, 0x4e, 0xda, 0x7d, 0x12, 0x54, 0xe1, 0x58, 0xf1, 0xf3, 0xc9, 0x8, 0x4a, 0xe9, 0xa6, 0xec")
MAKE_THUNK(libasound, snd_ctl_elem_info_malloc, "0xf3, 0x4e, 0x1, 0x13, 0x31, 0xb0, 0x87, 0xf6, 0xaf, 0xc2, 0x3c, 0xf2, 0xa6, 0x93, 0xd7, 0x1d, 0x79, 0x19, 0xfd, 0x2e, 0x55, 0xbe, 0x2a, 0x1c, 0xbd, 0x69, 0x7f, 0x22, 0xab, 0x7a, 0x65, 0xf6")
MAKE_THUNK(libasound, snd_ctl_elem_info_free, "0x30, 0xd6, 0x82, 0xe2, 0x7c, 0xfb, 0xd6, 0xd3, 0x98, 0xda, 0xae, 0xa8, 0x13, 0x7c, 0x9b, 0xd9, 0x46, 0x91, 0x43, 0x1f, 0xd6, 0x9f, 0x6b, 0x14, 0xcc, 0x36, 0xd, 0x44, 0x8c, 0xf0, 0x64, 0x3")
MAKE_THUNK(libasound, snd_ctl_elem_info_clear, "0x1c, 0x12, 0xce, 0xdf, 0xa, 0xbd, 0x1d, 0x3, 0x94, 0x8b, 0xd5, 0x99, 0x7c, 0x19, 0xa5, 0x6a, 0xee, 0xf8, 0x64, 0xb5, 0x35, 0x10, 0x5d, 0x8a, 0x73, 0xad, 0x8e, 0xf8, 0x3, 0x8, 0xf3, 0xd0")
MAKE_THUNK(libasound, snd_ctl_elem_info_copy, "0x5b, 0x9d, 0xb4, 0x52, 0xdb, 0xf6, 0xb2, 0xf8, 0xd1, 0x61, 0xab, 0x98, 0xbc, 0xc0, 0xd, 0x33, 0x9f, 0x1d, 0x4e, 0x74, 0xbd, 0x4f, 0xab, 0x8e, 0x6f, 0xd3, 0x2e, 0xe1, 0xd, 0x25, 0x18, 0x62")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_type, "0xcf, 0xd8, 0x91, 0x31, 0xaa, 0x85, 0x5c, 0xd, 0xa0, 0x4e, 0x2e, 0x10, 0x52, 0x66, 0x35, 0xc, 0x8a, 0x2, 0x91, 0x3, 0xc0, 0x18, 0xaa, 0xfb, 0xf6, 0xcb, 0xb9, 0x85, 0xbc, 0x7, 0x84, 0x28")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_readable, "0x8e, 0xd3, 0x76, 0xc3, 0x92, 0x39, 0x55, 0xb8, 0x2e, 0xaf, 0x7d, 0x4d, 0xa5, 0x94, 0xeb, 0xf1, 0x28, 0x80, 0xe8, 0x8b, 0x65, 0xd2, 0x38, 0x62, 0xc2, 0xaa, 0xd, 0x29, 0x27, 0xa9, 0x6e, 0x52")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_writable, "0x7e, 0xfb, 0x85, 0x1e, 0x70, 0x51, 0xa9, 0xdb, 0x57, 0x29, 0xd9, 0x70, 0x2c, 0x4a, 0xc1, 0x14, 0x73, 0x49, 0x2d, 0x26, 0xbe, 0xee, 0xeb, 0xa3, 0x1e, 0x7, 0x2e, 0xa2, 0x23, 0x94, 0x57, 0x83")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_volatile, "0xdd, 0xc6, 0xd8, 0x11, 0x3b, 0x1e, 0xa5, 0xfc, 0xd2, 0x8c, 0x8a, 0xa9, 0xcb, 0x22, 0x78, 0x1e, 0xe5, 0x2, 0xcf, 0x57, 0xd4, 0x7c, 0x2e, 0x57, 0xf4, 0x4a, 0x25, 0x37, 0x3a, 0x77, 0x58, 0xc7")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_inactive, "0xbd, 0xc0, 0xe5, 0x3c, 0x61, 0x72, 0xeb, 0x4, 0x2a, 0xc9, 0xa0, 0xff, 0xb, 0x5b, 0x53, 0xbc, 0x2, 0xec, 0x3b, 0x8f, 0xfd, 0x4b, 0xe2, 0x7, 0x68, 0xdf, 0x4d, 0xfb, 0x57, 0x79, 0x59, 0x4b")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_locked, "0x99, 0x69, 0x5a, 0x8b, 0xff, 0x99, 0x1d, 0x26, 0x8c, 0xbe, 0xfd, 0xd5, 0xaf, 0xf7, 0x87, 0x8e, 0xc7, 0xc8, 0x66, 0xd8, 0x39, 0xcc, 0x27, 0xec, 0x64, 0xea, 0x5, 0x32, 0x4a, 0x49, 0x3d, 0xd9")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_tlv_readable, "0x9d, 0x18, 0xc9, 0x6f, 0xee, 0x2f, 0x4b, 0xe, 0x43, 0xf3, 0xb1, 0xc, 0xd6, 0xb8, 0xf0, 0x1d, 0xc4, 0x4e, 0x39, 0x3d, 0x1a, 0x95, 0xc2, 0x71, 0x13, 0x26, 0x2c, 0xef, 0x51, 0xef, 0x7, 0x52")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_tlv_writable, "0x19, 0xb7, 0x37, 0xb0, 0xd5, 0xcc, 0x50, 0xfb, 0xd1, 0x43, 0x24, 0x45, 0x10, 0xe9, 0x29, 0x8b, 0x2f, 0x3b, 0x14, 0xc8, 0xb1, 0x44, 0xd1, 0x59, 0x5c, 0xfa, 0x36, 0x91, 0x51, 0x64, 0xcd, 0x3d")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_tlv_commandable, "0x6a, 0x8e, 0xe5, 0xcf, 0x87, 0x7e, 0x3b, 0xe6, 0xac, 0xe7, 0xdb, 0xb1, 0x76, 0x9d, 0xb0, 0x3c, 0x91, 0xe4, 0x9c, 0xf1, 0x25, 0xe0, 0xb1, 0xb1, 0xfb, 0xf, 0xba, 0xf2, 0x23, 0xbe, 0x87, 0x3")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_owner, "0xa, 0x5c, 0xcd, 0xe, 0x3, 0x63, 0x29, 0x7a, 0xd5, 0x8a, 0xe7, 0x3, 0x73, 0x65, 0x2e, 0xb6, 0x4a, 0xe0, 0xf1, 0xb8, 0x2, 0x84, 0x39, 0xc4, 0x2f, 0x4b, 0xca, 0xf7, 0x71, 0x77, 0x19, 0xb")
MAKE_THUNK(libasound, snd_ctl_elem_info_is_user, "0x19, 0x17, 0x63, 0x13, 0xb6, 0xcf, 0xb2, 0x61, 0xf1, 0xd2, 0x2e, 0x73, 0x67, 0x11, 0x44, 0x6a, 0xfe, 0x49, 0x87, 0x28, 0xd6, 0xdc, 0x66, 0x64, 0xde, 0xaa, 0x6c, 0x46, 0x65, 0x7d, 0x6f, 0xb1")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_owner, "0x78, 0xa, 0xeb, 0xf2, 0x40, 0xdf, 0xe8, 0xea, 0xe5, 0x1, 0xde, 0xce, 0x9a, 0xbe, 0xd3, 0xeb, 0x4, 0x35, 0x26, 0x76, 0x7, 0xcd, 0x8, 0x23, 0x6d, 0x9b, 0x94, 0x1c, 0x71, 0xd, 0x56, 0x29")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_count, "0xc3, 0xa8, 0xa9, 0x9, 0xf0, 0x3d, 0x36, 0xbf, 0xa, 0xc4, 0xf2, 0xd1, 0x0, 0x4, 0x66, 0x35, 0x1, 0xe2, 0xd5, 0xc0, 0xb6, 0xf1, 0x45, 0xff, 0x46, 0x38, 0x30, 0xc5, 0x7d, 0xbd, 0x4e, 0x21")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_min, "0x7c, 0x7a, 0xc2, 0x4b, 0xfe, 0x4d, 0xa0, 0x5f, 0xba, 0x89, 0xeb, 0xbc, 0x88, 0xca, 0xc5, 0xc0, 0xfb, 0x10, 0x13, 0x31, 0xf5, 0x67, 0x70, 0x78, 0x7, 0xf7, 0x9, 0x88, 0xd7, 0x98, 0xdd, 0x4f")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_max, "0xf, 0xab, 0x32, 0x14, 0x8b, 0x74, 0x5a, 0x8, 0x65, 0x6f, 0xc0, 0xb9, 0x3e, 0xb4, 0x4f, 0x7a, 0x0, 0xcd, 0x11, 0x3e, 0xde, 0x2a, 0x37, 0x8e, 0x6, 0xa7, 0xa, 0xc3, 0xf4, 0x93, 0xcf, 0x18")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_step, "0x8c, 0xcc, 0xf9, 0xc7, 0xf5, 0x6a, 0x80, 0x45, 0x21, 0x5, 0x42, 0xf9, 0xf, 0x4e, 0x39, 0xb3, 0xf0, 0x6f, 0x7d, 0x4, 0x20, 0xf4, 0xa9, 0x13, 0x56, 0x1d, 0x6e, 0x3f, 0x81, 0x26, 0x27, 0x8a")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_min64, "0x5e, 0xb8, 0x6f, 0xc7, 0xd3, 0xd9, 0x9, 0xbd, 0x3, 0x1d, 0x65, 0x64, 0x1a, 0x5a, 0x51, 0xa3, 0x5a, 0x32, 0xcd, 0xda, 0x6a, 0x2b, 0x79, 0x9f, 0xba, 0x9a, 0x2f, 0xb6, 0x85, 0xf6, 0x9e, 0xcd")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_max64, "0x9c, 0xe8, 0xba, 0xb8, 0xef, 0xe, 0x9, 0x43, 0x8c, 0x2d, 0x87, 0xfc, 0x8e, 0xea, 0x4, 0x2c, 0x59, 0xb0, 0x84, 0x84, 0xf8, 0x92, 0x7a, 0xdf, 0xac, 0x1e, 0x3b, 0x70, 0x97, 0x8c, 0xae, 0x58")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_step64, "0x37, 0x1, 0x9d, 0x9e, 0xf5, 0x2c, 0xc6, 0x71, 0xa8, 0x38, 0xb9, 0xea, 0x1c, 0xa0, 0x4e, 0xbf, 0xfe, 0x4e, 0xd3, 0xa3, 0xe6, 0x91, 0xeb, 0x62, 0x62, 0x13, 0x7b, 0x5c, 0xd, 0x6, 0x79, 0xbf")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_items, "0xb8, 0xc1, 0xd2, 0xd0, 0x7f, 0x58, 0x1d, 0x76, 0xad, 0x40, 0xee, 0xe0, 0x8c, 0xc6, 0x2f, 0x71, 0xae, 0xd7, 0x62, 0x54, 0xa3, 0xc8, 0xbd, 0xca, 0x77, 0x43, 0xb5, 0x56, 0xb7, 0x4c, 0xc8, 0x5e")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_item, "0xf7, 0x16, 0xd3, 0x67, 0x4e, 0x47, 0xbe, 0x40, 0x7f, 0x73, 0x4c, 0x6b, 0x7c, 0x6c, 0x16, 0x97, 0x9c, 0x8e, 0x6, 0xda, 0xdb, 0xe8, 0xe2, 0xc6, 0xb1, 0x9b, 0x6, 0xfc, 0x14, 0x46, 0x86, 0xb2")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_item_name, "0x38, 0x48, 0x25, 0xe0, 0xa9, 0x56, 0x5c, 0x9d, 0x30, 0x84, 0xce, 0xf9, 0xe7, 0xac, 0x1e, 0x77, 0x65, 0x5f, 0x8, 0xa7, 0x37, 0x25, 0x1b, 0x14, 0xc6, 0xad, 0xfc, 0xf9, 0x41, 0x5c, 0x90, 0x6c")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_dimensions, "0xfa, 0xbf, 0x94, 0x94, 0x48, 0x81, 0x59, 0x83, 0x32, 0x3a, 0xe7, 0xbf, 0x99, 0xcf, 0xd0, 0xf7, 0x3, 0x83, 0xff, 0x52, 0xc2, 0xfc, 0x6a, 0xd2, 0x2a, 0xef, 0xdf, 0x1, 0x80, 0x78, 0xee, 0xb1")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_dimension, "0xbc, 0xed, 0x27, 0xed, 0x15, 0x28, 0xf4, 0x84, 0x6f, 0xdc, 0x34, 0x69, 0x36, 0xf5, 0xb1, 0x86, 0xd8, 0x61, 0x52, 0xac, 0x13, 0x29, 0x12, 0x11, 0x24, 0xb6, 0x46, 0xaf, 0xf8, 0x3a, 0x44, 0x6f")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_id, "0xb3, 0xf0, 0xb0, 0x79, 0x7a, 0x90, 0x1, 0x8, 0x1a, 0x21, 0xe0, 0xdc, 0xfb, 0x65, 0x3a, 0x2a, 0xc2, 0x18, 0xb1, 0x83, 0xe, 0x47, 0x21, 0x82, 0xbf, 0xde, 0xe3, 0x92, 0xf8, 0xbf, 0x1c, 0x9d")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_numid, "0xa9, 0x63, 0x66, 0xff, 0x6f, 0x7a, 0x77, 0xd3, 0x65, 0xda, 0x48, 0x1e, 0x9b, 0x3b, 0xf8, 0xa4, 0x4e, 0xd4, 0x5f, 0xae, 0x27, 0x6f, 0xf4, 0xb3, 0x60, 0xb2, 0x33, 0x4a, 0x31, 0x1c, 0x5f, 0x61")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_interface, "0x84, 0xee, 0xb6, 0xdb, 0xa2, 0x40, 0x5b, 0xc9, 0x2e, 0xf2, 0x1e, 0xb9, 0x0, 0xd3, 0xc8, 0x24, 0xd4, 0x23, 0xe0, 0x67, 0xd6, 0xf1, 0x6d, 0x8f, 0x9, 0xc3, 0x17, 0x8c, 0xbf, 0x24, 0xbc, 0xfe")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_device, "0x6d, 0x93, 0xe, 0xe3, 0x40, 0x7, 0x84, 0x9d, 0x15, 0x64, 0x2d, 0x9f, 0x25, 0xd1, 0x10, 0xe5, 0x3b, 0xcd, 0xc1, 0x4f, 0xcd, 0xa3, 0xb0, 0xa7, 0x58, 0x59, 0xd8, 0xc, 0xc6, 0xe9, 0x36, 0x1a")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_subdevice, "0xbc, 0x33, 0xd, 0x4e, 0x56, 0xc3, 0xd3, 0xaf, 0xad, 0xf0, 0xb8, 0x2e, 0x83, 0x83, 0xdb, 0xe2, 0x92, 0xd9, 0xe9, 0x31, 0xb7, 0x11, 0x38, 0xf8, 0x11, 0x48, 0x62, 0xe8, 0x8b, 0xef, 0x6a, 0x0")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_name, "0xd7, 0xdc, 0xdc, 0xbc, 0xd, 0x77, 0x5d, 0x8b, 0xd5, 0xe, 0xe7, 0x6, 0x58, 0x8a, 0x59, 0x4, 0x77, 0xa1, 0xd3, 0x21, 0x3, 0xf2, 0x74, 0x14, 0xa0, 0x18, 0x5e, 0xcf, 0xac, 0x4e, 0x64, 0x9a")
MAKE_THUNK(libasound, snd_ctl_elem_info_get_index, "0xa7, 0xae, 0xaa, 0x46, 0xb1, 0xf6, 0xc, 0x8d, 0x92, 0xd3, 0x4, 0x89, 0x45, 0xcc, 0x3f, 0x1, 0xd3, 0xa8, 0x63, 0x68, 0xc8, 0xbb, 0x8a, 0x5e, 0x3e, 0xc4, 0x29, 0xa7, 0xf5, 0x2e, 0xcf, 0xaa")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_id, "0x4d, 0x67, 0x30, 0x6f, 0x33, 0xe7, 0x6a, 0xa3, 0xd7, 0x49, 0x86, 0x8f, 0xcd, 0xfa, 0x52, 0xd2, 0xa0, 0x85, 0x4a, 0xcc, 0xf6, 0x89, 0x95, 0x61, 0x80, 0x3e, 0xd8, 0x8e, 0x5b, 0x70, 0x32, 0x98")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_numid, "0x77, 0x38, 0xaa, 0x0, 0x6c, 0x58, 0x78, 0xec, 0xf8, 0xdb, 0x5e, 0x17, 0x27, 0x40, 0x9e, 0x7f, 0x52, 0x90, 0xbc, 0xfc, 0x6e, 0xe0, 0x9b, 0x89, 0x64, 0xdc, 0xc3, 0x89, 0x89, 0x84, 0x26, 0x5")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_interface, "0x47, 0xd5, 0xa2, 0x70, 0xa5, 0x5f, 0x69, 0x8, 0xd3, 0x95, 0x9c, 0xe1, 0x3f, 0xb8, 0xe3, 0x86, 0x43, 0x31, 0xbc, 0xf9, 0x20, 0xa, 0x8d, 0xf7, 0xcf, 0x4, 0xe7, 0x2b, 0x32, 0x4, 0xd3, 0xdb")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_device, "0xed, 0xa7, 0xf8, 0x2f, 0x99, 0x61, 0x8e, 0xcd, 0x67, 0x55, 0x1, 0x6, 0xd5, 0x6f, 0x11, 0x2b, 0xa2, 0xa0, 0x60, 0x95, 0xd0, 0x2f, 0x8f, 0x49, 0x16, 0xfe, 0x15, 0x47, 0x29, 0x97, 0xbd, 0xd4")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_subdevice, "0xd3, 0x34, 0x84, 0x1a, 0xfe, 0xd0, 0xc2, 0xc2, 0x8f, 0xfe, 0xd4, 0xac, 0xd8, 0xae, 0x8, 0xbe, 0x28, 0xe6, 0x4a, 0xf, 0xc4, 0xe0, 0x60, 0x79, 0xb2, 0x22, 0xb2, 0x3, 0x8b, 0xf7, 0xaf, 0xab")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_name, "0xeb, 0xe1, 0xdd, 0x14, 0x50, 0x5b, 0xa4, 0xdc, 0x1b, 0x6e, 0x50, 0x89, 0xb1, 0x54, 0x4e, 0x3d, 0x17, 0x92, 0xd1, 0x18, 0x31, 0xbd, 0x57, 0xfc, 0xe3, 0xe2, 0x6c, 0xba, 0x1c, 0x99, 0xbc, 0x6a")
MAKE_THUNK(libasound, snd_ctl_elem_info_set_index, "0xa9, 0x39, 0x8d, 0x46, 0x7f, 0x10, 0x42, 0x2c, 0xb0, 0xe8, 0x4f, 0x7d, 0x78, 0xec, 0xe0, 0x36, 0xa8, 0xff, 0x94, 0x83, 0x2b, 0x90, 0x5, 0x63, 0x84, 0xa7, 0x27, 0x94, 0x37, 0x70, 0x3a, 0xf")
MAKE_THUNK(libasound, snd_ctl_add_integer_elem_set, "0xef, 0x5a, 0x71, 0xfa, 0x17, 0x46, 0xd1, 0xd5, 0x5, 0x5e, 0xda, 0x47, 0x5, 0xd5, 0x63, 0x42, 0x74, 0xeb, 0x50, 0x8d, 0xf5, 0xd2, 0x77, 0x64, 0xe4, 0xb4, 0xbe, 0x2d, 0x89, 0xc8, 0xfc, 0xe")
MAKE_THUNK(libasound, snd_ctl_add_integer64_elem_set, "0xfc, 0x54, 0xd, 0x74, 0x41, 0xec, 0x2c, 0x75, 0x1a, 0xc9, 0xfa, 0xec, 0x68, 0x6b, 0x41, 0x97, 0xd1, 0x95, 0xf1, 0xa5, 0x49, 0xa5, 0x93, 0x73, 0x9c, 0x8, 0xa2, 0x33, 0x15, 0x92, 0xc3, 0xf7")
MAKE_THUNK(libasound, snd_ctl_add_boolean_elem_set, "0x72, 0xb2, 0x35, 0xf5, 0x2e, 0x1a, 0xd6, 0x76, 0xa, 0xf1, 0xc1, 0xcc, 0x9d, 0x42, 0x45, 0x51, 0xcb, 0xa0, 0x69, 0xa6, 0xe, 0x60, 0x82, 0xba, 0x64, 0xf2, 0xf1, 0x99, 0xb4, 0xb8, 0x7f, 0x99")
MAKE_THUNK(libasound, snd_ctl_add_bytes_elem_set, "0xd6, 0x8b, 0xe, 0x4a, 0x4f, 0xa6, 0xb5, 0xcf, 0x55, 0xe4, 0xbb, 0xf0, 0x59, 0xa1, 0xf3, 0xc4, 0xbe, 0x22, 0xfc, 0x4e, 0x8e, 0x9e, 0x83, 0xd4, 0x92, 0xc4, 0x98, 0x60, 0x93, 0x6f, 0x11, 0xfc")
MAKE_THUNK(libasound, snd_ctl_elem_add_integer, "0x55, 0x60, 0x7c, 0x0, 0x20, 0xe8, 0x22, 0x2a, 0xad, 0x8c, 0x14, 0x92, 0xf5, 0x3f, 0xa7, 0x92, 0x41, 0x14, 0x8f, 0xa5, 0x67, 0x8f, 0x92, 0x90, 0xb4, 0xea, 0x61, 0x31, 0x22, 0xe9, 0x65, 0x74")
MAKE_THUNK(libasound, snd_ctl_elem_add_integer64, "0x73, 0x5e, 0x12, 0x79, 0x50, 0x2f, 0xe2, 0xd4, 0x1d, 0x17, 0x6c, 0x40, 0x94, 0x2e, 0x69, 0x97, 0xb5, 0x8c, 0x3e, 0x6c, 0xa2, 0xad, 0x8b, 0x5f, 0xa3, 0x98, 0x23, 0xa6, 0xe7, 0x47, 0xb9, 0x7f")
MAKE_THUNK(libasound, snd_ctl_elem_add_boolean, "0x37, 0x7, 0x4e, 0xb7, 0xc8, 0x1f, 0xec, 0x9b, 0x82, 0x66, 0xfc, 0x38, 0x73, 0xa5, 0x16, 0x8f, 0x46, 0x88, 0xdd, 0x0, 0x4c, 0x52, 0xb3, 0x6d, 0xcf, 0x40, 0xa0, 0x23, 0xc2, 0x62, 0x4f, 0xc")
MAKE_THUNK(libasound, snd_ctl_elem_add_iec958, "0x69, 0xa8, 0xba, 0x96, 0x4d, 0x32, 0xd2, 0x7d, 0x88, 0x3e, 0x3c, 0xb6, 0x66, 0x0, 0xbf, 0x4b, 0xc4, 0x47, 0xcb, 0x59, 0x68, 0x3e, 0xc7, 0x29, 0x90, 0x92, 0xcc, 0xf7, 0xc7, 0x9a, 0xad, 0x10")
MAKE_THUNK(libasound, snd_ctl_elem_remove, "0x9e, 0xf2, 0x62, 0x6a, 0x6f, 0xaf, 0x8c, 0x5, 0x81, 0x9a, 0x4f, 0x24, 0xe8, 0x47, 0x47, 0x2e, 0x3d, 0x9d, 0xe, 0x83, 0x14, 0x50, 0x49, 0x7a, 0x57, 0xb0, 0x85, 0x9f, 0x32, 0xe9, 0x85, 0xd7")
MAKE_THUNK(libasound, snd_ctl_elem_value_sizeof, "0x9d, 0xd, 0x8d, 0xc4, 0x9b, 0x5, 0x95, 0x5, 0x21, 0xb3, 0xa3, 0x37, 0x3f, 0x62, 0xa, 0x4d, 0x0, 0x40, 0x6a, 0xc7, 0xc3, 0x11, 0x9c, 0x23, 0xd, 0xc7, 0xe2, 0x33, 0xe0, 0x74, 0x9a, 0x70")
MAKE_THUNK(libasound, snd_ctl_elem_value_malloc, "0xab, 0x2f, 0x80, 0x44, 0x6a, 0x42, 0x13, 0x3c, 0xdc, 0x38, 0x23, 0x1c, 0x53, 0x5f, 0xfa, 0x81, 0xc8, 0x23, 0xa9, 0xf7, 0xc2, 0xd9, 0x95, 0x6a, 0x20, 0x4d, 0xe8, 0x64, 0x89, 0x85, 0xac, 0xe5")
MAKE_THUNK(libasound, snd_ctl_elem_value_free, "0xf4, 0x4b, 0xa7, 0x6d, 0xef, 0xab, 0xd1, 0x90, 0x4b, 0x9c, 0x4f, 0xbb, 0xa3, 0xcd, 0x4d, 0x12, 0xc8, 0xae, 0x58, 0xd3, 0xf, 0x31, 0x2d, 0xb1, 0x1c, 0x45, 0xff, 0xd7, 0xbc, 0x85, 0x49, 0xe6")
MAKE_THUNK(libasound, snd_ctl_elem_value_clear, "0x9f, 0x53, 0xee, 0x3d, 0x9, 0xa4, 0xd4, 0x11, 0xda, 0x4b, 0x56, 0x15, 0x4f, 0x82, 0x36, 0x80, 0x65, 0x2c, 0xea, 0x82, 0x16, 0x53, 0x9e, 0x9, 0xb7, 0xb0, 0x43, 0xd7, 0x51, 0x1, 0xf9, 0x69")
MAKE_THUNK(libasound, snd_ctl_elem_value_copy, "0xd1, 0xd, 0x53, 0xec, 0xd3, 0x64, 0x15, 0x1e, 0x1, 0xe4, 0x5c, 0x86, 0xc, 0x56, 0xd6, 0x72, 0x9c, 0xae, 0x28, 0xb1, 0xd, 0x5e, 0x3, 0xa3, 0xb4, 0x2a, 0xf1, 0xef, 0x2, 0x84, 0x56, 0x13")
MAKE_THUNK(libasound, snd_ctl_elem_value_compare, "0x7f, 0x5f, 0x8b, 0x1f, 0xd2, 0x8d, 0x39, 0x90, 0x5, 0x14, 0xc8, 0xdc, 0xe4, 0xa7, 0x2e, 0x61, 0x21, 0x84, 0x11, 0x8e, 0x6f, 0xf2, 0x29, 0xa6, 0x93, 0xf4, 0x59, 0x76, 0x99, 0xe9, 0x8c, 0xb3")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_id, "0x0, 0x66, 0x81, 0xd2, 0x39, 0x83, 0xe8, 0x26, 0xed, 0x90, 0x4f, 0x8a, 0x27, 0x7b, 0x21, 0xb, 0x59, 0x2b, 0xb2, 0x41, 0xb3, 0x64, 0xe9, 0x4d, 0x54, 0x10, 0xd5, 0x4c, 0x1, 0x1f, 0xe4, 0x76")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_numid, "0xdf, 0xa7, 0x23, 0x1c, 0xde, 0x97, 0xee, 0x8c, 0xca, 0xe7, 0x1d, 0x99, 0x46, 0x6a, 0x3d, 0xa8, 0x95, 0x8b, 0x1d, 0xb8, 0x14, 0x4c, 0x91, 0x6e, 0x6b, 0x81, 0xe6, 0x18, 0x92, 0xed, 0x91, 0x87")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_interface, "0xd8, 0x4b, 0x2b, 0x6c, 0x5, 0xa0, 0xb4, 0x81, 0xe4, 0xaf, 0x22, 0x71, 0x52, 0x4e, 0x17, 0x6f, 0x57, 0x3a, 0x2c, 0x4e, 0x9f, 0x95, 0xa6, 0x4c, 0x88, 0x16, 0xe2, 0x6, 0x90, 0x3d, 0x31, 0xf")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_device, "0x95, 0xc9, 0xc, 0x6d, 0x94, 0x6a, 0x5f, 0x8f, 0x67, 0x88, 0x50, 0x2f, 0xa8, 0x3a, 0x2f, 0x73, 0xda, 0xd9, 0x37, 0xbf, 0x94, 0x7d, 0x71, 0x5d, 0xc5, 0xbc, 0x82, 0x18, 0x4, 0x39, 0xf6, 0xf3")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_subdevice, "0x9d, 0x24, 0xf2, 0xac, 0xe2, 0x90, 0x3c, 0xf1, 0xff, 0x0, 0xea, 0x12, 0x58, 0xd4, 0x6b, 0x96, 0xa9, 0xb1, 0x15, 0x86, 0x83, 0x96, 0x98, 0x47, 0xdd, 0x7, 0xa2, 0xbf, 0x9f, 0x70, 0xc0, 0x1e")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_name, "0x3, 0x4d, 0x8e, 0xf2, 0xb0, 0x10, 0x47, 0x3f, 0xd9, 0x36, 0x95, 0xae, 0x6b, 0xb8, 0x77, 0x24, 0x2f, 0x5a, 0x8a, 0xdc, 0xfa, 0x36, 0x3a, 0xd9, 0x20, 0x59, 0x75, 0xc8, 0xa4, 0x31, 0xdd, 0x4e")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_index, "0xb0, 0xcb, 0x26, 0x5d, 0xf1, 0x1f, 0x48, 0xa4, 0x3b, 0x71, 0xed, 0xba, 0xe2, 0xb0, 0x65, 0x7d, 0x8c, 0x6b, 0xb0, 0x5c, 0x46, 0x74, 0x62, 0xc3, 0x58, 0xf3, 0x66, 0x76, 0x98, 0x99, 0x38, 0x31")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_id, "0xdb, 0xd4, 0x15, 0xe8, 0x5d, 0x61, 0xf2, 0xa0, 0x63, 0x64, 0xb3, 0xa2, 0xe6, 0x2b, 0x7e, 0x8c, 0x22, 0x52, 0x84, 0x13, 0xc4, 0x6a, 0x91, 0x28, 0xe4, 0xe4, 0x7f, 0x55, 0x70, 0xc7, 0x20, 0xc0")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_numid, "0x57, 0x3e, 0xe4, 0x7d, 0xe5, 0x2d, 0xa0, 0x2, 0x5e, 0x18, 0x19, 0x41, 0xf1, 0x8e, 0xa7, 0x65, 0x79, 0x4c, 0x7b, 0x3a, 0x91, 0x27, 0xf7, 0xd7, 0xd1, 0xdd, 0xe2, 0xac, 0x23, 0xe5, 0xd1, 0x89")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_interface, "0x3b, 0xd, 0x69, 0x72, 0x28, 0x41, 0xfc, 0x6b, 0x49, 0x1b, 0xc6, 0x4b, 0x4d, 0x86, 0x83, 0xf, 0x9a, 0xf7, 0xd8, 0x1e, 0x5d, 0x26, 0x41, 0x4b, 0x89, 0x6e, 0xb3, 0xc0, 0x71, 0x73, 0x71, 0xba")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_device, "0x8e, 0x5, 0xbf, 0x71, 0x57, 0xfe, 0x70, 0xb1, 0xc4, 0x8, 0x35, 0xd6, 0xb6, 0x7, 0x81, 0xcc, 0x61, 0x49, 0x69, 0x87, 0x81, 0x2f, 0xec, 0x76, 0x30, 0x92, 0x6a, 0xd6, 0xb4, 0x72, 0x6, 0xfa")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_subdevice, "0xa5, 0xa0, 0x1c, 0x2f, 0x24, 0xcb, 0xb5, 0xea, 0x19, 0x1d, 0x2e, 0x40, 0xc1, 0x3a, 0xa4, 0xee, 0x99, 0xb5, 0x67, 0xa9, 0x77, 0xa9, 0xc7, 0x61, 0xe0, 0xee, 0xba, 0x70, 0x8a, 0xf8, 0x1b, 0x7d")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_name, "0x5, 0x40, 0x98, 0x76, 0x52, 0x71, 0x24, 0x68, 0xc4, 0x46, 0x74, 0x65, 0x5d, 0x53, 0xc3, 0x67, 0x9a, 0x53, 0xff, 0xa3, 0x45, 0x83, 0xed, 0xed, 0x37, 0x55, 0x1e, 0x6f, 0x8, 0xe0, 0x15, 0x0")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_index, "0x66, 0x84, 0x24, 0x1f, 0x86, 0xee, 0x7c, 0x4a, 0x9a, 0x40, 0x1b, 0x1e, 0x0, 0xce, 0x5c, 0x1, 0xf4, 0xc5, 0x81, 0x7e, 0xc4, 0x97, 0x1f, 0x24, 0xa2, 0xab, 0xaa, 0x88, 0x10, 0x1a, 0xcd, 0x70")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_boolean, "0x5a, 0xd4, 0x50, 0xe4, 0x38, 0x1d, 0x86, 0xf4, 0xaa, 0x14, 0x3e, 0x73, 0xd6, 0x90, 0x70, 0x4a, 0x33, 0x96, 0x3e, 0xa6, 0x39, 0x22, 0x25, 0xaa, 0xd, 0xfb, 0x79, 0x42, 0xc9, 0x9a, 0x28, 0x67")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_integer, "0xae, 0x4b, 0x2d, 0x39, 0x7d, 0x76, 0xa3, 0x3b, 0x82, 0xc5, 0xa6, 0xa1, 0x36, 0xe4, 0x14, 0x47, 0x8f, 0xc6, 0x70, 0x11, 0xb6, 0xd, 0x2a, 0x70, 0xe5, 0xf0, 0x8a, 0x8f, 0xd4, 0xa5, 0x4b, 0xef")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_integer64, "0x5d, 0x84, 0x5d, 0x4, 0xcf, 0x3b, 0x88, 0x3d, 0xa1, 0x13, 0x89, 0xc3, 0xf5, 0x38, 0x85, 0x2e, 0x3c, 0xab, 0xb9, 0x27, 0x15, 0xc8, 0xce, 0x63, 0x3a, 0x5e, 0xb, 0x86, 0xe5, 0xdb, 0xe3, 0xb9")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_enumerated, "0x64, 0x89, 0x89, 0x80, 0x5e, 0xb, 0x79, 0xdd, 0x0, 0x57, 0x71, 0x8b, 0x4b, 0xe9, 0x7e, 0x92, 0x96, 0xe3, 0x6d, 0xaa, 0xc1, 0xbd, 0x84, 0x4e, 0x52, 0x4e, 0x4d, 0xee, 0x74, 0xa0, 0x6a, 0xda")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_byte, "0xa7, 0xf3, 0xe8, 0x7, 0x1c, 0x15, 0xc7, 0xa4, 0x1c, 0x4, 0xbc, 0xc0, 0x5c, 0xd7, 0x6c, 0xa8, 0xc3, 0xe9, 0xef, 0x10, 0x48, 0xf3, 0x31, 0x19, 0x9f, 0x5b, 0xd4, 0xf0, 0x7d, 0xb2, 0x88, 0x20")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_boolean, "0xc5, 0x22, 0x6c, 0x68, 0x48, 0xfa, 0x55, 0xd9, 0xd2, 0xb, 0x1c, 0x74, 0x50, 0x7e, 0xf5, 0x9d, 0x20, 0x7f, 0x2c, 0xb1, 0x20, 0x49, 0x6e, 0xb9, 0xac, 0xe4, 0xc6, 0xcc, 0x42, 0xcc, 0x2e, 0x1a")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_integer, "0x75, 0xd8, 0xcf, 0x89, 0x63, 0xc9, 0xcd, 0x69, 0xdd, 0x86, 0x4b, 0xda, 0x83, 0xed, 0x50, 0xb0, 0xb, 0xaa, 0x12, 0xc4, 0x29, 0xa, 0x15, 0x5f, 0x70, 0xb9, 0x5f, 0x1a, 0x5e, 0x47, 0x7f, 0x8e")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_integer64, "0xec, 0x36, 0x98, 0xa4, 0x25, 0x21, 0x29, 0x0, 0x8b, 0x2e, 0xe0, 0x95, 0x41, 0x19, 0x51, 0xe0, 0x43, 0xf8, 0xc2, 0x4b, 0x45, 0x0, 0x73, 0x2c, 0x8, 0x54, 0x82, 0xda, 0xb9, 0x53, 0xb8, 0x9e")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_enumerated, "0x62, 0xd4, 0xdf, 0x2a, 0xac, 0xc1, 0x9c, 0xd5, 0xfa, 0x41, 0xed, 0x77, 0x0, 0xe7, 0x33, 0x34, 0x49, 0x83, 0x37, 0x62, 0xa7, 0x89, 0x27, 0x81, 0xc2, 0x3e, 0x5, 0x35, 0x6f, 0xcc, 0xd8, 0x32")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_byte, "0x46, 0xfe, 0x59, 0xd3, 0x63, 0x22, 0xeb, 0x48, 0xc5, 0xeb, 0x2b, 0xdd, 0x8d, 0x7, 0x89, 0xf7, 0xed, 0xa, 0x34, 0x85, 0xcb, 0x47, 0x17, 0x39, 0x6f, 0xb1, 0x1d, 0xa5, 0x7b, 0x68, 0x16, 0x17")
MAKE_THUNK(libasound, snd_ctl_elem_set_bytes, "0xf5, 0x87, 0x27, 0x58, 0xb3, 0xb8, 0xd5, 0xd7, 0x58, 0x3b, 0x90, 0x6e, 0xc6, 0x53, 0x6e, 0xd7, 0x6f, 0x23, 0xda, 0x1c, 0xaa, 0x60, 0xe7, 0xb8, 0xd7, 0x76, 0xe, 0x37, 0xd9, 0x5b, 0xeb, 0x9e")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_bytes, "0x35, 0xd, 0xc0, 0x3e, 0xbc, 0x51, 0xbe, 0xeb, 0x15, 0x1e, 0xf7, 0xf, 0x8f, 0x2b, 0xd4, 0x8a, 0xcd, 0x27, 0xf3, 0x5d, 0x40, 0xb8, 0xef, 0xc1, 0x6, 0x10, 0xdb, 0x71, 0xaa, 0x97, 0x78, 0x27")
MAKE_THUNK(libasound, snd_ctl_elem_value_get_iec958, "0x2, 0x3d, 0x13, 0x24, 0x4a, 0x77, 0x52, 0x6b, 0xe8, 0x46, 0x2, 0xd4, 0x13, 0x8b, 0x60, 0x87, 0x64, 0x3d, 0xd8, 0x7f, 0xfb, 0x24, 0x34, 0xda, 0x3a, 0x9b, 0x21, 0x3c, 0x8b, 0x85, 0xcf, 0x55")
MAKE_THUNK(libasound, snd_ctl_elem_value_set_iec958, "0x94, 0x21, 0x25, 0xd9, 0x65, 0x41, 0x29, 0xec, 0xea, 0x97, 0x79, 0x4, 0xc9, 0xdf, 0xf6, 0x53, 0xa5, 0x4f, 0xde, 0x53, 0x49, 0x24, 0xa1, 0x68, 0xad, 0xa0, 0xfa, 0xc1, 0x84, 0xd4, 0x79, 0xf9")
MAKE_THUNK(libasound, snd_tlv_parse_dB_info, "0xba, 0x50, 0x96, 0x6a, 0xbd, 0x61, 0xe4, 0xb4, 0x60, 0xd, 0xe9, 0x37, 0x38, 0x7a, 0x63, 0xb5, 0xf3, 0x79, 0x18, 0xd4, 0xa3, 0xf7, 0x1c, 0x1d, 0xa6, 0x12, 0x37, 0xf0, 0xb1, 0xd, 0xbc, 0x53")
MAKE_THUNK(libasound, snd_tlv_get_dB_range, "0x69, 0xb5, 0x1a, 0xbf, 0x10, 0xe4, 0x21, 0x37, 0x3a, 0x0, 0xcd, 0xe6, 0x15, 0x7, 0xe9, 0xb0, 0xa7, 0xd, 0xd, 0xf7, 0x19, 0xf2, 0x9a, 0x9e, 0x97, 0x59, 0x3e, 0x58, 0x7f, 0x5e, 0x6e, 0x2")
MAKE_THUNK(libasound, snd_tlv_convert_to_dB, "0xbc, 0xf8, 0x1a, 0x59, 0x4c, 0xf, 0xc1, 0xbf, 0x5d, 0x29, 0xc7, 0x9, 0x50, 0x0, 0x59, 0x2a, 0x78, 0x43, 0x71, 0xf0, 0xa, 0xf7, 0xa0, 0x88, 0xc2, 0x27, 0x46, 0x37, 0xff, 0x2d, 0x26, 0x4b")
MAKE_THUNK(libasound, snd_tlv_convert_from_dB, "0xdb, 0x75, 0x9c, 0xcd, 0xe8, 0xeb, 0x0, 0xdf, 0x9, 0xfe, 0x32, 0x91, 0x8, 0xf5, 0x72, 0xf8, 0xd1, 0x51, 0x5b, 0xe9, 0x76, 0xe6, 0xb7, 0xba, 0xb, 0xae, 0xe4, 0xe1, 0x66, 0x34, 0xbb, 0x6c")
MAKE_THUNK(libasound, snd_ctl_get_dB_range, "0x25, 0x7a, 0x2a, 0x8b, 0xbb, 0x5a, 0x45, 0xa8, 0xc9, 0xd9, 0x9d, 0xf3, 0xd7, 0xe9, 0xf1, 0x33, 0xb8, 0x39, 0x97, 0x6a, 0xce, 0x54, 0xf4, 0x6f, 0x6, 0x42, 0x84, 0xd0, 0xc9, 0x59, 0x8f, 0xfe")
MAKE_THUNK(libasound, snd_ctl_convert_to_dB, "0xa1, 0x8, 0xa0, 0xe2, 0xcb, 0xa4, 0x9b, 0x1b, 0x8f, 0x71, 0xd0, 0xb8, 0xf7, 0x64, 0x9c, 0x9, 0xf2, 0x31, 0x51, 0x5f, 0x3b, 0x5a, 0x86, 0x15, 0x5a, 0x8f, 0x7e, 0x18, 0xe2, 0x1f, 0x75, 0x56")
MAKE_THUNK(libasound, snd_ctl_convert_from_dB, "0xc6, 0x47, 0x19, 0xe8, 0xec, 0x7, 0x8f, 0x9, 0xd, 0x95, 0x73, 0xd2, 0x15, 0x13, 0x62, 0x54, 0x35, 0xfd, 0xb5, 0xbd, 0xa2, 0x98, 0xbb, 0x0, 0x4a, 0x37, 0xcb, 0x76, 0xd2, 0xba, 0x33, 0x2d")
MAKE_THUNK(libasound, snd_hctl_compare_fast, "0xc8, 0x88, 0xc0, 0x97, 0xb4, 0x7e, 0xbb, 0xc1, 0xf4, 0x3, 0x9c, 0xd3, 0x7e, 0xaf, 0x62, 0x81, 0xbc, 0x3e, 0x2, 0xcf, 0xe, 0xf8, 0xd2, 0x59, 0x82, 0xe1, 0xd6, 0x7b, 0xb7, 0x12, 0x34, 0x91")
MAKE_THUNK(libasound, snd_hctl_open, "0xe4, 0xdd, 0x44, 0x3d, 0xf6, 0xb0, 0x58, 0xba, 0x19, 0x9a, 0xf5, 0x13, 0x9, 0x56, 0xaa, 0xd4, 0x8e, 0x2, 0xe5, 0x36, 0x3b, 0xaa, 0x4f, 0x9c, 0xeb, 0x8a, 0xa3, 0xa1, 0x1d, 0x17, 0xe3, 0xa6")
MAKE_THUNK(libasound, snd_hctl_open_ctl, "0xcb, 0x7b, 0x2c, 0x8f, 0xc1, 0xdb, 0x51, 0x3a, 0xc5, 0xea, 0xa2, 0x86, 0xcd, 0x84, 0x1c, 0x34, 0xc4, 0x44, 0x3, 0x27, 0x95, 0xc6, 0xcd, 0x68, 0x87, 0x14, 0xeb, 0x5e, 0x77, 0x5d, 0x35, 0x1a")
MAKE_THUNK(libasound, snd_hctl_close, "0x3e, 0xbd, 0x9, 0x89, 0x35, 0xdb, 0x58, 0x22, 0x9f, 0x5b, 0xae, 0xe9, 0xea, 0xae, 0xa9, 0xed, 0x6a, 0x0, 0x1e, 0xe0, 0x5, 0xbb, 0x21, 0x50, 0x2a, 0xd1, 0x70, 0xcf, 0xaa, 0x73, 0xbe, 0xd9")
MAKE_THUNK(libasound, snd_hctl_nonblock, "0xb6, 0x5e, 0xf6, 0xd5, 0x9c, 0x5c, 0xd0, 0xe6, 0x34, 0x80, 0x59, 0x83, 0x63, 0x2b, 0xe9, 0xfb, 0xcf, 0x13, 0x37, 0xdd, 0x8, 0xe8, 0x43, 0x74, 0x8f, 0x6, 0x92, 0x9d, 0x3e, 0xbb, 0xb5, 0x99")
MAKE_THUNK(libasound, snd_hctl_poll_descriptors_count, "0xdc, 0xce, 0x6b, 0xd9, 0xfe, 0x9c, 0x29, 0x87, 0xcd, 0x2a, 0x2b, 0xb9, 0xb1, 0xd5, 0xf7, 0x7f, 0x6a, 0xe, 0xe9, 0x6c, 0xd2, 0x50, 0x7a, 0xf8, 0x41, 0x14, 0x5d, 0xe2, 0x7f, 0xd6, 0xd4, 0xa6")
MAKE_THUNK(libasound, snd_hctl_poll_descriptors, "0x5a, 0xf5, 0xfa, 0x84, 0x14, 0x56, 0xd2, 0x57, 0x6f, 0x78, 0xc4, 0xe1, 0x8, 0xc9, 0x7f, 0xf4, 0xdd, 0x80, 0x9e, 0xb, 0x93, 0x5b, 0x56, 0x5c, 0xcc, 0x7c, 0x17, 0x66, 0x2b, 0x5c, 0x76, 0x95")
MAKE_THUNK(libasound, snd_hctl_poll_descriptors_revents, "0x5c, 0xab, 0xc, 0xab, 0xb9, 0xbd, 0x3d, 0x3c, 0x32, 0x44, 0x7d, 0x54, 0xa0, 0xf, 0xc1, 0xcd, 0xdb, 0x3, 0x98, 0x7, 0x4a, 0xcf, 0x3d, 0x3f, 0xbd, 0xbd, 0x67, 0xb2, 0xb4, 0x64, 0xf9, 0x1e")
MAKE_THUNK(libasound, snd_hctl_get_count, "0x52, 0x34, 0x3f, 0x14, 0x15, 0x4c, 0xa7, 0xc0, 0x5a, 0xba, 0xef, 0xda, 0xdd, 0xf3, 0x11, 0xe0, 0x1f, 0x21, 0x28, 0xba, 0x7, 0x16, 0x3f, 0x39, 0x1c, 0xad, 0xd0, 0xa7, 0xf3, 0x2c, 0x56, 0xce")
MAKE_THUNK(libasound, snd_hctl_first_elem, "0xd6, 0x9d, 0xbe, 0x41, 0x76, 0xa3, 0x9c, 0xe0, 0xa9, 0x85, 0x63, 0x50, 0x3b, 0xcf, 0x87, 0xa2, 0x51, 0x59, 0xee, 0x28, 0xab, 0x34, 0x37, 0x70, 0x66, 0x4e, 0x87, 0xd8, 0x7a, 0xbc, 0x8d, 0x1d")
MAKE_THUNK(libasound, snd_hctl_last_elem, "0xa0, 0x1c, 0x8f, 0xe7, 0x7d, 0x2, 0xef, 0x4f, 0xb1, 0xce, 0x2f, 0x3d, 0x9, 0x20, 0x85, 0x5f, 0x7d, 0xbf, 0x33, 0xca, 0x88, 0x64, 0xc0, 0x71, 0x1b, 0x5e, 0xdb, 0x90, 0xe2, 0xce, 0x73, 0xf9")
MAKE_THUNK(libasound, snd_hctl_find_elem, "0xd5, 0xe2, 0xb6, 0xb5, 0xa, 0xee, 0xbf, 0xd5, 0x80, 0x7c, 0xc8, 0x18, 0xe5, 0x6a, 0x94, 0xb3, 0xd2, 0xdb, 0xda, 0xe3, 0x30, 0x5d, 0x47, 0x67, 0x7e, 0x14, 0x93, 0x18, 0x31, 0x27, 0xf4, 0x5d")
MAKE_THUNK(libasound, snd_hctl_load, "0xd7, 0x17, 0x7, 0x6e, 0xdd, 0x85, 0xdb, 0x79, 0x46, 0xb3, 0x3, 0x71, 0x8, 0xb5, 0xcd, 0x18, 0x8f, 0xeb, 0x62, 0x1b, 0x43, 0x8f, 0x93, 0xf4, 0xf1, 0x1b, 0xb4, 0x8d, 0xfe, 0x52, 0xc4, 0x5e")
MAKE_THUNK(libasound, snd_hctl_free, "0x78, 0xea, 0xee, 0x8a, 0x91, 0x12, 0x6, 0x5f, 0x2b, 0xdf, 0xe7, 0x22, 0x24, 0xf7, 0x4c, 0x5e, 0x48, 0x17, 0x16, 0x94, 0xc1, 0x5e, 0xa9, 0xa8, 0x12, 0xc7, 0xc4, 0x15, 0x8c, 0x9a, 0x6d, 0x14")
MAKE_THUNK(libasound, snd_hctl_handle_events, "0x19, 0x69, 0x51, 0xd4, 0x7a, 0xf8, 0x46, 0x50, 0x89, 0xbe, 0x3d, 0x76, 0x8c, 0x2, 0x1f, 0x4b, 0xc0, 0x8a, 0x7d, 0x6a, 0x66, 0xcd, 0xfe, 0x47, 0x44, 0xca, 0x50, 0x3a, 0x6c, 0xc3, 0xa, 0x5c")
MAKE_THUNK(libasound, snd_hctl_name, "0xdd, 0x8a, 0x6e, 0x33, 0xe0, 0x96, 0xa9, 0xa8, 0x94, 0xf2, 0x78, 0xe6, 0x11, 0x3c, 0x5e, 0x3c, 0x92, 0xd1, 0x16, 0xc3, 0xde, 0xc1, 0x7a, 0xc, 0xee, 0x2f, 0xad, 0x8d, 0x6e, 0xd9, 0xed, 0x80")
MAKE_THUNK(libasound, snd_hctl_wait, "0x29, 0xf5, 0xe7, 0x6b, 0x57, 0x3e, 0x85, 0x7c, 0x97, 0x31, 0x33, 0xe5, 0xc2, 0xe1, 0x22, 0x88, 0x27, 0xc3, 0x4e, 0x2, 0x93, 0xef, 0x81, 0x7e, 0xa6, 0x98, 0xa3, 0xa6, 0x27, 0x9f, 0x94, 0x5c")
MAKE_THUNK(libasound, snd_hctl_ctl, "0x97, 0x21, 0x5a, 0x67, 0xbe, 0x94, 0xa0, 0x4a, 0x41, 0x2d, 0x9d, 0xa6, 0x39, 0x4, 0x4, 0xbd, 0xb1, 0xed, 0x1f, 0x4b, 0xd3, 0x75, 0x16, 0x43, 0xfc, 0x81, 0x8c, 0xf9, 0xae, 0x84, 0xfb, 0x57")
MAKE_THUNK(libasound, snd_hctl_elem_next, "0xf6, 0xd8, 0xbf, 0xd2, 0x19, 0xff, 0xee, 0x22, 0x16, 0x33, 0xf9, 0xc8, 0x7a, 0xd7, 0xad, 0xc8, 0x4c, 0x83, 0xdd, 0x23, 0xdd, 0x73, 0xfb, 0xc1, 0x25, 0xf3, 0xd3, 0x81, 0x0, 0x3b, 0x7d, 0xca")
MAKE_THUNK(libasound, snd_hctl_elem_prev, "0xa0, 0x5f, 0xc4, 0x1e, 0x21, 0x8, 0x14, 0xaf, 0xc4, 0xf7, 0x90, 0x94, 0x7, 0xf2, 0xbf, 0xdb, 0x60, 0x86, 0x3f, 0x40, 0xab, 0xfe, 0x6a, 0x6e, 0x35, 0xc3, 0xef, 0xf8, 0xcb, 0x56, 0xc7, 0xfd")
MAKE_THUNK(libasound, snd_hctl_elem_info, "0xa, 0x84, 0x82, 0xf0, 0xe0, 0xeb, 0x77, 0x30, 0xe5, 0x19, 0x1c, 0x7, 0x54, 0xf, 0xa6, 0x8c, 0xe, 0x7, 0x2d, 0x38, 0x57, 0xb9, 0x48, 0xb4, 0xc0, 0x46, 0x93, 0x78, 0x70, 0xa4, 0xbf, 0x60")
MAKE_THUNK(libasound, snd_hctl_elem_read, "0x6b, 0x97, 0xfd, 0xd3, 0xd0, 0x7e, 0x1e, 0x81, 0x6b, 0x56, 0xeb, 0x65, 0x4a, 0x1a, 0x43, 0x4c, 0x85, 0x17, 0xf9, 0xa5, 0x45, 0xbb, 0x95, 0x57, 0xfe, 0x8e, 0xa9, 0x7e, 0xf7, 0x6e, 0x36, 0x53")
MAKE_THUNK(libasound, snd_hctl_elem_write, "0xc8, 0x65, 0x42, 0xfc, 0xd7, 0xbe, 0x47, 0xf5, 0xc8, 0x83, 0x56, 0x60, 0x9d, 0xa4, 0x33, 0xb8, 0xcf, 0xbd, 0x41, 0x9c, 0xac, 0x45, 0xe0, 0xe, 0x54, 0x7a, 0xbe, 0x56, 0x20, 0xea, 0xc6, 0xb7")
MAKE_THUNK(libasound, snd_hctl_elem_tlv_read, "0x54, 0xc2, 0xe2, 0x7d, 0xcd, 0xf0, 0xbb, 0xe5, 0x3f, 0x4d, 0x7, 0x23, 0xd6, 0xfe, 0x92, 0xe6, 0x29, 0xf6, 0x28, 0x0, 0x72, 0x38, 0x3c, 0xf0, 0xed, 0xd3, 0x4e, 0x4, 0xdb, 0x62, 0x55, 0x10")
MAKE_THUNK(libasound, snd_hctl_elem_tlv_write, "0xc5, 0x57, 0xb8, 0xde, 0x60, 0x23, 0x0, 0xe1, 0x65, 0x3b, 0xe1, 0xbb, 0x1d, 0xcc, 0xd2, 0x2d, 0x86, 0x33, 0x5d, 0xce, 0x47, 0x51, 0x12, 0x8b, 0x46, 0x1a, 0xad, 0x52, 0xc6, 0x6e, 0xfe, 0xf7")
MAKE_THUNK(libasound, snd_hctl_elem_tlv_command, "0x77, 0x3d, 0x6e, 0xa6, 0x70, 0xa2, 0xbd, 0x24, 0xdd, 0x5d, 0xea, 0x7a, 0x6a, 0x6d, 0x88, 0xde, 0x4f, 0x10, 0x64, 0xfe, 0x98, 0xa, 0xab, 0x3, 0x8a, 0xc0, 0x8e, 0x2f, 0x45, 0x56, 0x3a, 0x7b")
MAKE_THUNK(libasound, snd_hctl_elem_get_hctl, "0xa, 0xf0, 0xe4, 0xd3, 0x6d, 0xb2, 0xc9, 0x71, 0x5f, 0xec, 0x6c, 0x8, 0x9d, 0x60, 0x54, 0x6, 0xa, 0x85, 0xd8, 0xa1, 0x52, 0xa3, 0x5d, 0xe5, 0x84, 0x6a, 0xc2, 0xbf, 0xf9, 0xb8, 0x41, 0x91")
MAKE_THUNK(libasound, snd_hctl_elem_get_id, "0x60, 0x4f, 0x38, 0x72, 0x8f, 0x1d, 0xdf, 0x2, 0x17, 0xed, 0x14, 0x95, 0x38, 0x51, 0xff, 0x54, 0x7a, 0x29, 0xda, 0xab, 0x5c, 0x7a, 0xe1, 0x45, 0xac, 0x87, 0x77, 0xbd, 0x96, 0xf6, 0xde, 0xa4")
MAKE_THUNK(libasound, snd_hctl_elem_get_numid, "0x22, 0x93, 0x56, 0x68, 0xa0, 0x84, 0x61, 0xb4, 0x9d, 0x76, 0x6b, 0xb3, 0xa8, 0x5a, 0x41, 0x65, 0x47, 0x6a, 0x42, 0x2d, 0xb4, 0x6, 0x52, 0xa, 0xe3, 0x1b, 0x8, 0xa4, 0x8f, 0x3c, 0x97, 0x74")
MAKE_THUNK(libasound, snd_hctl_elem_get_interface, "0x4e, 0x8b, 0xc9, 0xa9, 0x66, 0xfc, 0x26, 0xe2, 0xf1, 0x53, 0x84, 0x1c, 0x30, 0xb7, 0x74, 0xc4, 0x7d, 0x1c, 0x98, 0x54, 0xa8, 0x4a, 0x36, 0x96, 0x9c, 0x9d, 0xd, 0x61, 0x21, 0xc6, 0xe9, 0xf4")
MAKE_THUNK(libasound, snd_hctl_elem_get_device, "0x48, 0x50, 0xd8, 0xe3, 0x94, 0x7b, 0x3c, 0x9c, 0xfc, 0x98, 0x52, 0x69, 0x48, 0x35, 0xbb, 0xbe, 0x77, 0x39, 0xc, 0xa5, 0x67, 0x70, 0x22, 0x26, 0xa2, 0x7f, 0x1f, 0xb4, 0xf4, 0x99, 0xd6, 0x8c")
MAKE_THUNK(libasound, snd_hctl_elem_get_subdevice, "0x30, 0xc9, 0x8e, 0xa4, 0x57, 0xb2, 0xb4, 0xf9, 0x96, 0x23, 0xb8, 0x2b, 0x71, 0xc5, 0xc6, 0xac, 0x5c, 0xf0, 0x88, 0xab, 0x9f, 0xb5, 0x47, 0x3a, 0xa2, 0x50, 0x5f, 0xf0, 0x46, 0x4, 0xeb, 0xde")
MAKE_THUNK(libasound, snd_hctl_elem_get_name, "0x2a, 0xdf, 0xb9, 0x20, 0x58, 0x77, 0x13, 0x7b, 0x16, 0x36, 0xfe, 0x5, 0x94, 0x77, 0x60, 0xa3, 0xbf, 0xb0, 0xdc, 0xa1, 0x4f, 0xa9, 0xa, 0xc2, 0xf3, 0x64, 0x75, 0xc2, 0x4d, 0xf6, 0xb0, 0xf0")
MAKE_THUNK(libasound, snd_hctl_elem_get_index, "0xd, 0x29, 0x74, 0xf8, 0xe9, 0xf, 0x16, 0xcc, 0x8a, 0x74, 0x2a, 0x17, 0x95, 0xe0, 0x3a, 0xb1, 0xbc, 0xc6, 0x42, 0xb5, 0xbc, 0xcb, 0xfe, 0x65, 0x9c, 0xec, 0xfc, 0x9b, 0xe7, 0x20, 0xa0, 0x77")
MAKE_THUNK(libasound, snd_sctl_build, "0x57, 0xb3, 0x4b, 0x7c, 0xc4, 0x36, 0x79, 0xda, 0x40, 0xc0, 0xe, 0x18, 0x41, 0x27, 0x4d, 0x89, 0xf3, 0x12, 0xe, 0x1c, 0xa3, 0x1d, 0x27, 0x72, 0x33, 0x52, 0x13, 0x7c, 0xc1, 0x8, 0xe5, 0x6a")
MAKE_THUNK(libasound, snd_sctl_free, "0x5d, 0xac, 0x50, 0xb5, 0x1a, 0xdb, 0x3d, 0x5e, 0x8d, 0xfa, 0xd4, 0xe, 0xa4, 0xee, 0x3d, 0x86, 0xda, 0xc7, 0x99, 0x8d, 0x22, 0x60, 0xd, 0xb8, 0xde, 0xd5, 0xe2, 0x1d, 0xcf, 0x8a, 0x8, 0x77")
MAKE_THUNK(libasound, snd_sctl_install, "0xf2, 0x44, 0xf0, 0x71, 0xcd, 0x3c, 0x5f, 0x1c, 0xe8, 0x9e, 0xf3, 0xfc, 0x5a, 0xc, 0xea, 0xcd, 0xb0, 0xab, 0x7d, 0xb2, 0x44, 0xc9, 0xbb, 0x64, 0x35, 0x3d, 0x8b, 0x60, 0x60, 0x92, 0xb6, 0xed")
MAKE_THUNK(libasound, snd_sctl_remove, "0xe8, 0x34, 0x3f, 0xd8, 0xdc, 0x47, 0xb2, 0x7b, 0x93, 0x2e, 0x53, 0xb4, 0x33, 0xe7, 0x9, 0xaf, 0xb0, 0x80, 0x50, 0x65, 0x1b, 0xe7, 0x3c, 0xc8, 0xc0, 0xa3, 0x5c, 0xb4, 0x4a, 0x1b, 0xef, 0x68")
MAKE_THUNK(libasound, snd_mixer_open, "0x8f, 0x36, 0x62, 0x83, 0xbb, 0x4a, 0xb4, 0x32, 0x12, 0x7e, 0x4, 0xe7, 0xb6, 0xae, 0x63, 0xa6, 0xf3, 0xc5, 0x23, 0x46, 0x77, 0x80, 0xc, 0x21, 0x22, 0x67, 0x69, 0x43, 0x74, 0x94, 0x93, 0xf")
MAKE_THUNK(libasound, snd_mixer_close, "0x51, 0x35, 0x32, 0x7e, 0xa2, 0x89, 0xc, 0x48, 0x8c, 0xa9, 0x61, 0x70, 0x69, 0x92, 0x3d, 0x3e, 0x53, 0x32, 0xed, 0xf9, 0x21, 0xf2, 0x3a, 0xad, 0x15, 0x1c, 0xcb, 0x27, 0x32, 0xea, 0xb9, 0x7b")
MAKE_THUNK(libasound, snd_mixer_first_elem, "0x2a, 0x89, 0xe9, 0x94, 0xa1, 0xa5, 0x42, 0x9f, 0xe3, 0x12, 0xbc, 0x38, 0x8e, 0xa6, 0x65, 0xe3, 0x8b, 0xd8, 0x2b, 0xdf, 0x13, 0xe9, 0xcc, 0x50, 0x24, 0xe4, 0x8, 0x37, 0x28, 0xdb, 0x94, 0x88")
MAKE_THUNK(libasound, snd_mixer_last_elem, "0x5, 0x50, 0xb9, 0x9b, 0xd4, 0xf3, 0x5e, 0x70, 0x92, 0x8b, 0x7b, 0x1b, 0x4, 0x1b, 0x20, 0x8, 0xf0, 0x3c, 0x50, 0xad, 0x7a, 0x5, 0xdd, 0x8e, 0xcc, 0x95, 0xec, 0xe8, 0x54, 0xf, 0x60, 0x5d")
MAKE_THUNK(libasound, snd_mixer_handle_events, "0x54, 0x23, 0x32, 0x6f, 0x3, 0x90, 0xbc, 0xea, 0x6, 0x2c, 0x2, 0x93, 0x2e, 0x34, 0x55, 0x44, 0xe4, 0x5e, 0x53, 0xf5, 0xac, 0x3f, 0xb4, 0xd, 0xed, 0x81, 0x32, 0xf6, 0xf7, 0xcb, 0xb2, 0x28")
MAKE_THUNK(libasound, snd_mixer_attach, "0x28, 0x3b, 0x59, 0x7f, 0x76, 0xbe, 0x8f, 0x87, 0xb7, 0x9f, 0x72, 0x6c, 0xbd, 0x4a, 0x67, 0x8b, 0x88, 0xbe, 0x8f, 0xcb, 0x3d, 0x52, 0xcf, 0x8e, 0x4f, 0x66, 0x52, 0x13, 0x1a, 0xb, 0x37, 0x67")
MAKE_THUNK(libasound, snd_mixer_attach_hctl, "0x7d, 0x61, 0x2e, 0xe1, 0x51, 0x4, 0x1a, 0xac, 0x1f, 0x80, 0x3c, 0x57, 0x22, 0x5c, 0x7f, 0x9b, 0x2f, 0x97, 0xf3, 0x60, 0x73, 0x2a, 0x8e, 0x8d, 0xb6, 0x9d, 0x2e, 0x93, 0x44, 0x81, 0xe6, 0xf7")
MAKE_THUNK(libasound, snd_mixer_detach, "0x8e, 0x2, 0x6d, 0xb0, 0xad, 0x9d, 0xe6, 0x4e, 0xff, 0x7b, 0xab, 0x88, 0xab, 0x87, 0x6e, 0xaf, 0x86, 0x81, 0xc4, 0x67, 0x60, 0xc5, 0x97, 0x9b, 0xfa, 0x88, 0x4, 0x66, 0xa1, 0xe0, 0x12, 0xde")
MAKE_THUNK(libasound, snd_mixer_detach_hctl, "0x12, 0x2e, 0x2, 0x59, 0x95, 0xde, 0x9c, 0xa6, 0xf2, 0x65, 0x34, 0xb7, 0x6a, 0xd, 0xad, 0xc8, 0xfc, 0xaa, 0xa6, 0x6e, 0x63, 0x6a, 0x2b, 0x8e, 0x85, 0x77, 0xb2, 0x41, 0x96, 0x46, 0xd9, 0x4")
MAKE_THUNK(libasound, snd_mixer_get_hctl, "0x47, 0x29, 0x76, 0xa0, 0xb8, 0x24, 0x8f, 0x94, 0x78, 0xae, 0x31, 0x85, 0xaf, 0xbb, 0xd2, 0x2d, 0xa1, 0x50, 0x57, 0xa, 0xf0, 0x96, 0x9e, 0x93, 0x5b, 0xff, 0x1, 0xd5, 0xc2, 0x22, 0x37, 0x5d")
MAKE_THUNK(libasound, snd_mixer_poll_descriptors_count, "0xd9, 0x9, 0xb9, 0x78, 0x57, 0xbf, 0x54, 0xc5, 0x29, 0x7f, 0x94, 0xeb, 0x20, 0x45, 0x80, 0xc9, 0x75, 0xf7, 0x5d, 0x69, 0xa1, 0xc3, 0x78, 0xeb, 0x19, 0x2d, 0x49, 0xf0, 0x8b, 0xf, 0x4b, 0x72")
MAKE_THUNK(libasound, snd_mixer_poll_descriptors, "0xf9, 0x7b, 0x7e, 0x88, 0x6b, 0x75, 0x53, 0xca, 0x93, 0xc0, 0x7d, 0x5, 0x33, 0xb6, 0xdb, 0x1d, 0xb, 0xa3, 0x86, 0x38, 0xaf, 0xb7, 0x2e, 0xdb, 0x4a, 0x57, 0x4a, 0x22, 0xac, 0xf3, 0x18, 0xb7")
MAKE_THUNK(libasound, snd_mixer_poll_descriptors_revents, "0x6f, 0x7c, 0x95, 0xec, 0xb8, 0x6b, 0x4f, 0x56, 0x93, 0x54, 0x7f, 0x58, 0xff, 0x7c, 0x84, 0xc6, 0xc0, 0x70, 0x34, 0xfc, 0x14, 0x62, 0x80, 0x78, 0xae, 0x9a, 0xd2, 0xe, 0xc6, 0xfa, 0xa3, 0x56")
MAKE_THUNK(libasound, snd_mixer_load, "0x6e, 0x7e, 0x67, 0x65, 0xdc, 0x70, 0xb, 0xb5, 0xf2, 0xbc, 0x3d, 0x87, 0x31, 0x8d, 0xbb, 0xf6, 0x20, 0x37, 0x84, 0x38, 0x96, 0x26, 0x31, 0x23, 0xf3, 0xe5, 0xcf, 0x20, 0x7d, 0x8a, 0xf8, 0x8")
MAKE_THUNK(libasound, snd_mixer_free, "0x79, 0x60, 0x19, 0xd, 0xa2, 0x7e, 0xbb, 0x55, 0x92, 0xd1, 0xdf, 0x77, 0xca, 0x2c, 0xa0, 0x8c, 0x5a, 0xfb, 0x28, 0x12, 0xc4, 0x49, 0xbd, 0x46, 0x2c, 0xbe, 0x7e, 0x8b, 0x38, 0x3b, 0x50, 0xf7")
MAKE_THUNK(libasound, snd_mixer_wait, "0x8d, 0x83, 0xc8, 0x90, 0x19, 0x65, 0x8f, 0x49, 0xad, 0x19, 0xb8, 0xaa, 0xd9, 0x2a, 0xd0, 0x28, 0x80, 0x52, 0x6c, 0x70, 0xd, 0x40, 0xb6, 0xfe, 0x87, 0x92, 0xdc, 0x2c, 0xec, 0xfe, 0x58, 0x6e")
MAKE_THUNK(libasound, snd_mixer_get_count, "0xd3, 0xc2, 0x6f, 0x95, 0x28, 0x1c, 0xe, 0x8a, 0x2f, 0xdf, 0xc3, 0x36, 0x45, 0xb, 0x70, 0x1b, 0x9, 0x37, 0x24, 0xea, 0x77, 0x69, 0xe4, 0x45, 0x12, 0x43, 0x49, 0xa6, 0x10, 0xa9, 0xfd, 0xb2")
MAKE_THUNK(libasound, snd_mixer_class_unregister, "0x7e, 0xdb, 0x5c, 0x53, 0xba, 0xc, 0x39, 0xae, 0xda, 0xcd, 0xb4, 0xb6, 0xa8, 0x87, 0x8d, 0xaa, 0xd9, 0xe8, 0xb3, 0x27, 0x99, 0xd9, 0x8e, 0xbf, 0xe0, 0xcd, 0xe8, 0x49, 0x3f, 0xe2, 0xcb, 0xa1")
MAKE_THUNK(libasound, snd_mixer_elem_next, "0xc, 0x5b, 0x9, 0x47, 0x9, 0xbf, 0xc, 0xb3, 0x18, 0x74, 0x9, 0x2e, 0x66, 0xb8, 0x63, 0x2c, 0x1f, 0xfe, 0x6a, 0x0, 0xe4, 0xef, 0xe7, 0xc3, 0x89, 0x38, 0x89, 0x3b, 0x4a, 0x6e, 0xda, 0x63")
MAKE_THUNK(libasound, snd_mixer_elem_prev, "0x9c, 0xc2, 0xd6, 0xf7, 0x2a, 0x1d, 0x8f, 0xc4, 0x26, 0xd5, 0xee, 0xd4, 0x79, 0x88, 0xdd, 0xfb, 0x3e, 0x49, 0xd7, 0xb9, 0xad, 0xd, 0xd, 0xa3, 0x1a, 0xef, 0xb2, 0x37, 0x39, 0xb9, 0xd8, 0xed")
MAKE_THUNK(libasound, snd_mixer_elem_get_callback_private, "0xd, 0x10, 0x28, 0x1c, 0x99, 0x1c, 0x4d, 0x5f, 0xaa, 0xbd, 0x4, 0xed, 0xc5, 0x9, 0x8c, 0x47, 0x34, 0x91, 0xe4, 0xf2, 0x23, 0xf, 0x3b, 0x7f, 0xf7, 0x83, 0xa4, 0xe6, 0xf4, 0x7a, 0xf4, 0x94")
MAKE_THUNK(libasound, snd_mixer_elem_get_type, "0x8f, 0x85, 0xcb, 0x7, 0x47, 0x49, 0x94, 0xc6, 0x54, 0xd2, 0x3, 0x57, 0x2a, 0x58, 0x1b, 0xaf, 0xfc, 0x9a, 0xa8, 0xd6, 0xf1, 0xee, 0x25, 0xcf, 0x9f, 0xa3, 0x89, 0x5, 0x61, 0x41, 0x3b, 0x88")
MAKE_THUNK(libasound, snd_mixer_class_register, "0x5, 0xad, 0x62, 0x2, 0x1b, 0x2e, 0x3a, 0x50, 0x50, 0x5a, 0x6a, 0x29, 0x72, 0xff, 0x87, 0x2e, 0xf5, 0x72, 0x8c, 0x9b, 0x3b, 0xd7, 0x80, 0x26, 0x78, 0x64, 0xad, 0x7c, 0xad, 0x30, 0x99, 0x26")
MAKE_THUNK(libasound, snd_mixer_elem_add, "0x7a, 0x9e, 0x52, 0x74, 0xe5, 0x51, 0x3c, 0xb, 0xf6, 0xa5, 0x23, 0x83, 0x38, 0xa4, 0x15, 0x87, 0x29, 0x51, 0x6c, 0x80, 0x76, 0xc6, 0x7a, 0x13, 0xb, 0x6b, 0x72, 0x6e, 0x9f, 0x5e, 0x16, 0x2a")
MAKE_THUNK(libasound, snd_mixer_elem_remove, "0xf2, 0x6b, 0x7b, 0x7d, 0x6, 0x47, 0x4, 0xdc, 0xf, 0x26, 0x21, 0x4, 0x68, 0xf0, 0x12, 0xf3, 0x7a, 0xd5, 0xd0, 0xb2, 0xb3, 0xb0, 0xf7, 0xb1, 0xc7, 0x85, 0x47, 0x48, 0xc0, 0xa6, 0x53, 0x7")
MAKE_THUNK(libasound, snd_mixer_elem_free, "0x75, 0x97, 0x3a, 0xde, 0xc5, 0x3, 0xec, 0x16, 0x5d, 0xe9, 0x57, 0x94, 0x6f, 0xeb, 0x71, 0x9f, 0xc7, 0xa7, 0x66, 0xa, 0x56, 0xb2, 0xee, 0xc5, 0x2c, 0xd4, 0xfa, 0x8b, 0x40, 0xbb, 0xa9, 0x39")
MAKE_THUNK(libasound, snd_mixer_elem_info, "0x4e, 0x46, 0xd2, 0xe9, 0x47, 0x7e, 0x6, 0x9b, 0x7a, 0x12, 0xf9, 0xe5, 0xd7, 0xce, 0xca, 0x39, 0x49, 0x74, 0x23, 0x63, 0xa6, 0x22, 0x82, 0x1f, 0xfb, 0xa7, 0x34, 0x5c, 0xee, 0x57, 0x4b, 0x45")
MAKE_THUNK(libasound, snd_mixer_elem_value, "0x82, 0x7, 0xc7, 0x15, 0x16, 0x4f, 0x3f, 0x58, 0x8, 0xc5, 0xf7, 0xb4, 0xd8, 0x9a, 0x12, 0xf9, 0x32, 0x45, 0xc8, 0x7f, 0xec, 0xaf, 0x4a, 0xb8, 0xf3, 0x38, 0x16, 0x6b, 0xb3, 0xe, 0x73, 0xcf")
MAKE_THUNK(libasound, snd_mixer_elem_attach, "0x86, 0x54, 0x2c, 0xc3, 0xa7, 0x3a, 0x35, 0x4e, 0x58, 0xa1, 0x66, 0x88, 0xd8, 0xe9, 0x90, 0xd8, 0xdd, 0x1e, 0x0, 0xb8, 0xbb, 0xd1, 0x8e, 0x14, 0x9f, 0xa0, 0x19, 0x8, 0x30, 0x78, 0x44, 0x44")
MAKE_THUNK(libasound, snd_mixer_elem_detach, "0xd7, 0x45, 0x57, 0xac, 0xd9, 0x3e, 0xcf, 0x67, 0xa, 0x69, 0xf7, 0x95, 0x22, 0x87, 0xf4, 0xd, 0x33, 0x4a, 0x2e, 0x5c, 0x21, 0xda, 0x2a, 0x38, 0x5e, 0x44, 0x3a, 0xbd, 0xc4, 0x3a, 0xe, 0x70")
MAKE_THUNK(libasound, snd_mixer_elem_empty, "0xd7, 0x9d, 0xe6, 0x30, 0x1, 0xd6, 0xe3, 0x4a, 0x18, 0xb6, 0x9b, 0x5f, 0xfe, 0xc0, 0xb, 0x5d, 0x2e, 0x36, 0x30, 0xa5, 0xce, 0x7c, 0x95, 0xa2, 0x63, 0x77, 0xc2, 0x47, 0xe7, 0x34, 0x0, 0x86")
MAKE_THUNK(libasound, snd_mixer_elem_get_private, "0xc3, 0xb5, 0x72, 0x30, 0x69, 0x72, 0xaa, 0xc3, 0xdc, 0x6f, 0x8d, 0x16, 0x4f, 0xb3, 0xa, 0xe3, 0x53, 0xc9, 0xd8, 0x1d, 0x8e, 0xf, 0xe3, 0xbf, 0xb, 0xc7, 0x82, 0xc5, 0xb, 0x85, 0x45, 0x47")
MAKE_THUNK(libasound, snd_mixer_class_sizeof, "0xa4, 0x68, 0xf9, 0x40, 0x7b, 0x20, 0x19, 0x15, 0x6b, 0x7b, 0xf8, 0x76, 0xee, 0xf3, 0x83, 0xd1, 0xf1, 0x82, 0x11, 0x14, 0x8b, 0x66, 0x4, 0x2d, 0x68, 0x7c, 0x94, 0x5, 0xd6, 0x36, 0xb9, 0x83")
MAKE_THUNK(libasound, snd_mixer_class_malloc, "0x62, 0xea, 0xd6, 0x4c, 0x16, 0x64, 0xb9, 0xda, 0x6c, 0xc5, 0xbf, 0xe5, 0xb, 0x18, 0xba, 0x3a, 0x73, 0xf6, 0xf9, 0xa8, 0xeb, 0xb0, 0x8f, 0x52, 0xed, 0x5d, 0x83, 0x89, 0x1a, 0x33, 0x96, 0xb5")
MAKE_THUNK(libasound, snd_mixer_class_free, "0xf, 0x1d, 0x73, 0xc4, 0x93, 0xae, 0x14, 0x2c, 0xde, 0xe6, 0x99, 0x40, 0x8c, 0x95, 0x71, 0xe7, 0x6a, 0xcc, 0xff, 0xc9, 0xbf, 0x86, 0x25, 0x93, 0x16, 0x87, 0x69, 0xa8, 0x9e, 0x56, 0xd7, 0xfc")
MAKE_THUNK(libasound, snd_mixer_class_copy, "0xce, 0x19, 0xe6, 0x29, 0x7c, 0x8c, 0x7d, 0xb0, 0x9b, 0x20, 0x33, 0x10, 0x86, 0xa5, 0x9, 0x41, 0x66, 0x16, 0xc2, 0x48, 0x2c, 0xf2, 0x97, 0xfc, 0xab, 0x3b, 0x26, 0xc, 0x3b, 0xbe, 0xf4, 0x2d")
MAKE_THUNK(libasound, snd_mixer_selem_channel_name, "0xe1, 0x58, 0x6a, 0xbc, 0x6d, 0x8a, 0x2c, 0x8, 0x10, 0xe, 0x59, 0x9d, 0x49, 0x81, 0x34, 0xe, 0xf9, 0xb7, 0x2d, 0x77, 0x6a, 0xee, 0x97, 0x5d, 0x6c, 0x26, 0x70, 0xa5, 0xb6, 0xd2, 0xf9, 0xef")
MAKE_THUNK(libasound, snd_mixer_selem_register, "0x25, 0xfb, 0x1e, 0xb8, 0x34, 0x51, 0x5, 0x12, 0xee, 0x2, 0x64, 0xab, 0x2f, 0xa6, 0xc4, 0x11, 0x89, 0xb8, 0x16, 0xcc, 0x10, 0xd6, 0x10, 0x3c, 0x2a, 0x33, 0xac, 0x8c, 0xac, 0xe7, 0xab, 0x79")
MAKE_THUNK(libasound, snd_mixer_selem_get_id, "0xa3, 0x88, 0x2f, 0x7f, 0xd3, 0x9f, 0x0, 0x7e, 0xed, 0x80, 0xb8, 0x35, 0xfe, 0x22, 0xbb, 0x1, 0x31, 0x3, 0x5f, 0x25, 0x27, 0x94, 0x6, 0x1a, 0xc8, 0x3a, 0xf4, 0x83, 0x71, 0xeb, 0x63, 0x2f")
MAKE_THUNK(libasound, snd_mixer_selem_get_name, "0xf3, 0x40, 0xe, 0xe6, 0x60, 0xe1, 0x80, 0x1a, 0xb5, 0x2a, 0x58, 0x58, 0x20, 0x73, 0xbb, 0xfe, 0x50, 0x93, 0xac, 0x2b, 0xd1, 0x42, 0xdb, 0x9b, 0x7f, 0x5f, 0xd8, 0x75, 0x99, 0x8, 0xf6, 0x69")
MAKE_THUNK(libasound, snd_mixer_selem_get_index, "0xe5, 0x9a, 0xa7, 0x71, 0x1f, 0x29, 0x4d, 0x49, 0xbd, 0xee, 0x47, 0x19, 0x85, 0x40, 0x83, 0xbc, 0x9, 0x6f, 0x1d, 0xd2, 0xac, 0xff, 0x39, 0x27, 0x7f, 0x67, 0x20, 0x4f, 0x99, 0x63, 0x8b, 0x79")
MAKE_THUNK(libasound, snd_mixer_find_selem, "0x2b, 0xaa, 0xbb, 0x72, 0x8c, 0x4e, 0x89, 0x97, 0x6b, 0xee, 0x40, 0x1c, 0x6b, 0x2b, 0x2b, 0x30, 0xa2, 0xaf, 0x3, 0x80, 0x2a, 0x71, 0xca, 0xc1, 0xb3, 0x61, 0x5b, 0xf6, 0x71, 0xca, 0x1e, 0x92")
MAKE_THUNK(libasound, snd_mixer_selem_is_active, "0xd, 0xe1, 0x71, 0x23, 0x91, 0x5b, 0x8e, 0x56, 0x6a, 0x5, 0xb, 0x9d, 0x3a, 0x30, 0xcf, 0xc8, 0x1c, 0x39, 0x50, 0xf6, 0x8f, 0x8, 0x9c, 0xc2, 0x5f, 0x2c, 0xf2, 0x2f, 0x25, 0x5b, 0xe3, 0xf9")
MAKE_THUNK(libasound, snd_mixer_selem_is_playback_mono, "0xe7, 0x78, 0x20, 0x40, 0x61, 0xc9, 0xef, 0xc9, 0xb2, 0x2d, 0x3a, 0x7f, 0x98, 0x5d, 0xe2, 0x66, 0x3f, 0x6a, 0x8e, 0x1, 0xae, 0x33, 0x34, 0xf5, 0x91, 0xe7, 0x37, 0x98, 0x5f, 0x8e, 0xc0, 0xf4")
MAKE_THUNK(libasound, snd_mixer_selem_has_playback_channel, "0x5b, 0x20, 0x4b, 0xdc, 0x26, 0xd7, 0x3d, 0xf2, 0x1a, 0x8a, 0xe2, 0x44, 0xa, 0x9c, 0x9c, 0xe8, 0xc0, 0x9a, 0x7d, 0x19, 0x71, 0x51, 0x42, 0x29, 0x88, 0x17, 0x49, 0xbd, 0x8f, 0x59, 0xea, 0x14")
MAKE_THUNK(libasound, snd_mixer_selem_is_capture_mono, "0x2f, 0x83, 0xf7, 0xe0, 0x2e, 0xa, 0xb6, 0xe9, 0x53, 0x3b, 0x47, 0x8e, 0x21, 0x8f, 0xf1, 0xfc, 0xf4, 0xb8, 0x87, 0xbb, 0x4f, 0x7b, 0x70, 0xa3, 0x1d, 0x8, 0x6b, 0x6, 0xcd, 0x8a, 0xfc, 0xcd")
MAKE_THUNK(libasound, snd_mixer_selem_has_capture_channel, "0xbb, 0x9a, 0x16, 0xdd, 0x4d, 0xba, 0x78, 0x44, 0xa4, 0x49, 0x86, 0xc7, 0xc9, 0xaf, 0xba, 0xf0, 0x4f, 0x28, 0xfe, 0xeb, 0x7e, 0x37, 0xf1, 0x1b, 0x22, 0x8b, 0x68, 0x40, 0x97, 0xaf, 0xea, 0x74")
MAKE_THUNK(libasound, snd_mixer_selem_get_capture_group, "0x64, 0x2b, 0xbb, 0x40, 0x38, 0xd8, 0x5, 0x3b, 0x20, 0x4, 0x3, 0x9b, 0xd8, 0x53, 0x36, 0x41, 0x53, 0x9c, 0xd, 0x14, 0xd5, 0x78, 0xcd, 0xd3, 0x17, 0x9d, 0x63, 0x15, 0x4a, 0x8d, 0x2c, 0x6a")
MAKE_THUNK(libasound, snd_mixer_selem_has_common_volume, "0x1, 0xd2, 0x99, 0x59, 0xbb, 0x73, 0x3e, 0xdb, 0xc4, 0xcf, 0xf9, 0xfb, 0x5b, 0xba, 0x27, 0x50, 0xbc, 0xae, 0xb5, 0xdb, 0x3b, 0xa1, 0x36, 0x97, 0x6e, 0xc8, 0x30, 0xbd, 0x6c, 0x72, 0xcb, 0x2f")
MAKE_THUNK(libasound, snd_mixer_selem_has_playback_volume, "0xc4, 0x65, 0x3e, 0x15, 0x20, 0x59, 0x67, 0x38, 0xda, 0x83, 0x20, 0xee, 0x64, 0x90, 0x44, 0xe6, 0x51, 0x6c, 0xd6, 0xf6, 0xa1, 0x30, 0x23, 0xbb, 0x7f, 0xea, 0x8b, 0xe5, 0xe3, 0x70, 0xf7, 0x27")
MAKE_THUNK(libasound, snd_mixer_selem_has_playback_volume_joined, "0x1b, 0xe4, 0x69, 0x6a, 0xbc, 0x33, 0xaa, 0x6b, 0xa, 0x2d, 0xa, 0xc6, 0xb7, 0x19, 0x5, 0xb, 0xef, 0x9b, 0x29, 0x70, 0x5e, 0x62, 0x8b, 0xbd, 0x82, 0xd1, 0xd7, 0xa1, 0xd2, 0x36, 0xe1, 0xe2")
MAKE_THUNK(libasound, snd_mixer_selem_has_capture_volume, "0x3c, 0xaa, 0xdd, 0x70, 0xe7, 0xe, 0xa5, 0x42, 0xce, 0x6c, 0x24, 0x19, 0x46, 0x61, 0xef, 0x25, 0x84, 0xd4, 0x6e, 0xa1, 0x11, 0xc6, 0xa8, 0xa3, 0x68, 0x68, 0xfc, 0xd9, 0x72, 0x1b, 0xc4, 0xc6")
MAKE_THUNK(libasound, snd_mixer_selem_has_capture_volume_joined, "0x95, 0x89, 0x1, 0xc7, 0xb, 0x6c, 0xe6, 0x54, 0x12, 0x4d, 0x62, 0x2a, 0x6d, 0xd4, 0x3a, 0x62, 0x8e, 0x83, 0x25, 0x7d, 0x1a, 0xbe, 0xf1, 0x3f, 0x97, 0x5e, 0xce, 0xd2, 0x61, 0xe2, 0x52, 0xf6")
MAKE_THUNK(libasound, snd_mixer_selem_has_common_switch, "0x78, 0xcb, 0x8a, 0xe9, 0x13, 0x85, 0xf3, 0xd7, 0xd9, 0x27, 0xfe, 0xb6, 0x8, 0xcb, 0x7c, 0x7f, 0xa9, 0xb4, 0x86, 0xe3, 0xc5, 0xce, 0xfd, 0x80, 0x36, 0x14, 0xd1, 0xf6, 0xc7, 0xe8, 0xd8, 0xd8")
MAKE_THUNK(libasound, snd_mixer_selem_has_playback_switch, "0xfc, 0xf0, 0xb0, 0x36, 0x41, 0xf4, 0x2b, 0x67, 0xca, 0x4b, 0x86, 0xd5, 0xeb, 0x27, 0x32, 0x1f, 0x5, 0x8, 0x2, 0xd, 0xfd, 0x25, 0xf, 0xa6, 0xb5, 0x34, 0x22, 0x4, 0x5a, 0x5, 0xe4, 0xbd")
MAKE_THUNK(libasound, snd_mixer_selem_has_playback_switch_joined, "0x89, 0x7c, 0x6, 0x11, 0xf9, 0x9e, 0x34, 0x69, 0xd, 0x2, 0x4a, 0x87, 0x1d, 0x66, 0x2f, 0x3d, 0x97, 0x7e, 0x8b, 0xa6, 0xb0, 0x13, 0x92, 0x93, 0x2, 0xee, 0x43, 0xbe, 0x20, 0x9f, 0x35, 0x4c")
MAKE_THUNK(libasound, snd_mixer_selem_has_capture_switch, "0x3, 0x52, 0xb5, 0x5, 0x68, 0x40, 0x6, 0x34, 0x7, 0x1, 0x93, 0x66, 0x1c, 0x44, 0x1, 0x86, 0xd2, 0xbf, 0x1d, 0xa9, 0x4d, 0xa5, 0xa6, 0xef, 0x6a, 0x7c, 0x87, 0x63, 0xe3, 0x8e, 0x55, 0xc8")
MAKE_THUNK(libasound, snd_mixer_selem_has_capture_switch_joined, "0xcd, 0x5d, 0xe2, 0xcb, 0x79, 0x76, 0xc2, 0x20, 0xdb, 0x4e, 0x80, 0x9, 0x7d, 0x6e, 0xc6, 0xb9, 0x6, 0x2c, 0x1b, 0x3a, 0xd, 0x23, 0x19, 0x14, 0xea, 0xdb, 0xa3, 0x55, 0x68, 0x44, 0x4e, 0x93")
MAKE_THUNK(libasound, snd_mixer_selem_has_capture_switch_exclusive, "0x64, 0xe3, 0x8, 0x11, 0x46, 0xc2, 0xe2, 0x2d, 0x6b, 0xd7, 0x53, 0xb8, 0xc4, 0x5d, 0x92, 0x0, 0xc, 0xe, 0xc6, 0xec, 0x18, 0x8b, 0xf4, 0xe8, 0x0, 0xdc, 0x8a, 0xae, 0x12, 0x44, 0xcf, 0x95")
MAKE_THUNK(libasound, snd_mixer_selem_ask_playback_vol_dB, "0x84, 0xff, 0xce, 0x87, 0x20, 0x6, 0xb2, 0x44, 0x6e, 0x5a, 0x95, 0x61, 0xb7, 0x3b, 0x38, 0x44, 0x17, 0x80, 0x69, 0x18, 0xaa, 0xf2, 0x0, 0x3d, 0x39, 0xc0, 0x70, 0x47, 0x5f, 0xeb, 0xac, 0xe3")
MAKE_THUNK(libasound, snd_mixer_selem_ask_capture_vol_dB, "0x83, 0x21, 0x38, 0x31, 0xe6, 0xb0, 0x1c, 0xff, 0x47, 0x15, 0x30, 0xc4, 0x65, 0x8f, 0xac, 0x42, 0xf1, 0x6a, 0x9, 0xdd, 0x6b, 0x3d, 0x48, 0x3c, 0x6b, 0xcf, 0x86, 0x58, 0x15, 0xeb, 0xba, 0x2")
MAKE_THUNK(libasound, snd_mixer_selem_ask_playback_dB_vol, "0x74, 0x84, 0x94, 0xb6, 0x38, 0xe8, 0xe9, 0x78, 0x74, 0x64, 0x67, 0x7a, 0x8, 0x69, 0xc1, 0x8e, 0x11, 0xe7, 0x53, 0x18, 0x0, 0x67, 0xf1, 0xa3, 0xb, 0x17, 0xee, 0x4, 0x9e, 0xf8, 0x27, 0xec")
MAKE_THUNK(libasound, snd_mixer_selem_ask_capture_dB_vol, "0x29, 0xe3, 0xb, 0x70, 0x22, 0x39, 0x1c, 0x30, 0x53, 0x90, 0xb3, 0x1c, 0x36, 0x11, 0x3e, 0xa7, 0xa5, 0x8d, 0xc7, 0xab, 0x5b, 0x73, 0x16, 0xf7, 0xe4, 0xfb, 0x93, 0x2, 0x44, 0xd, 0x2f, 0x64")
MAKE_THUNK(libasound, snd_mixer_selem_get_playback_volume, "0x8b, 0x55, 0xd8, 0xa1, 0x42, 0x22, 0x26, 0x92, 0xd4, 0x33, 0xa8, 0x62, 0x60, 0x25, 0xb6, 0x18, 0x10, 0x2a, 0xdf, 0xf6, 0xed, 0x63, 0xda, 0x6d, 0x90, 0x38, 0xa5, 0x4e, 0xd0, 0xee, 0xb6, 0xf4")
MAKE_THUNK(libasound, snd_mixer_selem_get_capture_volume, "0x69, 0xb5, 0xb2, 0x30, 0xb8, 0xd2, 0x5b, 0x5, 0xa1, 0x5e, 0x80, 0xc0, 0x4, 0x5b, 0xdf, 0x0, 0xd3, 0xe1, 0xd5, 0xc1, 0x58, 0xe3, 0xe4, 0x13, 0x9c, 0x3f, 0xa2, 0xb7, 0xd8, 0x1f, 0xc9, 0x8e")
MAKE_THUNK(libasound, snd_mixer_selem_get_playback_dB, "0xaa, 0x29, 0xdd, 0xe5, 0xb0, 0x34, 0xba, 0x56, 0x4c, 0xd0, 0x7c, 0x5b, 0x45, 0x5c, 0xe1, 0xbf, 0xe2, 0xbf, 0x93, 0xd4, 0x5d, 0x8a, 0xab, 0x1b, 0x5d, 0x1c, 0x2d, 0x1f, 0x79, 0x7, 0xc, 0x5c")
MAKE_THUNK(libasound, snd_mixer_selem_get_capture_dB, "0xa, 0xb7, 0xe9, 0xfb, 0x1a, 0xca, 0xd5, 0x4a, 0xf4, 0xc, 0xe7, 0xc8, 0x9b, 0x5, 0xe0, 0x73, 0x21, 0x14, 0x5a, 0xdf, 0xa7, 0x7a, 0x6c, 0x69, 0x74, 0x66, 0xe0, 0x75, 0x3a, 0x86, 0x21, 0xd3")
MAKE_THUNK(libasound, snd_mixer_selem_get_playback_switch, "0x3f, 0xf5, 0x6e, 0xcb, 0x1b, 0xb1, 0x36, 0x73, 0x36, 0xb6, 0xe6, 0x70, 0x2f, 0xe9, 0xdf, 0x8a, 0x3, 0xab, 0x2b, 0x73, 0x55, 0x53, 0x78, 0xba, 0x6, 0xc5, 0x4c, 0xd9, 0x94, 0xc1, 0x3f, 0xef")
MAKE_THUNK(libasound, snd_mixer_selem_get_capture_switch, "0x84, 0x4e, 0x3e, 0x7a, 0x16, 0xbb, 0x3d, 0xb7, 0x7b, 0xe3, 0x6d, 0x74, 0xad, 0x27, 0x11, 0xae, 0x30, 0x9c, 0x77, 0x8a, 0x1d, 0xaa, 0x20, 0x27, 0xc9, 0x91, 0xb4, 0xcc, 0xec, 0xd4, 0x3f, 0x94")
MAKE_THUNK(libasound, snd_mixer_selem_set_playback_volume, "0x60, 0x7d, 0xea, 0x36, 0x1a, 0x59, 0x91, 0x3e, 0x1a, 0xae, 0x9a, 0x63, 0x9c, 0xe3, 0xb3, 0x52, 0x85, 0x7b, 0xed, 0x6b, 0xd3, 0x64, 0xfd, 0x9e, 0xfc, 0x4, 0xc5, 0x3d, 0x22, 0xcf, 0x54, 0xef")
MAKE_THUNK(libasound, snd_mixer_selem_set_capture_volume, "0x0, 0xb4, 0x78, 0xc8, 0x14, 0x41, 0x1d, 0x98, 0xc, 0x9, 0xe8, 0xa7, 0xb6, 0x93, 0x5e, 0xba, 0x14, 0x95, 0x5b, 0xe8, 0x1f, 0x9f, 0x49, 0x28, 0x7d, 0x84, 0x21, 0x92, 0xf, 0xcd, 0xcb, 0x33")
MAKE_THUNK(libasound, snd_mixer_selem_set_playback_dB, "0x55, 0xa9, 0xd9, 0x29, 0xfc, 0xaa, 0xe1, 0x24, 0x8, 0x9f, 0xd0, 0x10, 0xf9, 0xd9, 0xf9, 0x65, 0xb9, 0x8, 0xfb, 0xcb, 0x6, 0x98, 0xe2, 0x2c, 0xe6, 0x34, 0x6a, 0x48, 0x86, 0xcb, 0x84, 0x3f")
MAKE_THUNK(libasound, snd_mixer_selem_set_capture_dB, "0x52, 0xd2, 0x22, 0xe0, 0x18, 0xbf, 0xc5, 0xa6, 0x82, 0x45, 0xbe, 0xb1, 0xb5, 0x71, 0xd1, 0x63, 0x33, 0xef, 0xd5, 0x6a, 0x43, 0x69, 0x27, 0xaf, 0x0, 0x99, 0x44, 0xdf, 0xa4, 0x12, 0x27, 0x1e")
MAKE_THUNK(libasound, snd_mixer_selem_set_playback_volume_all, "0xbf, 0x1c, 0x14, 0xea, 0x5c, 0x5, 0xd1, 0x26, 0x45, 0xb4, 0xd6, 0x1f, 0xc0, 0xda, 0x90, 0xbf, 0xb1, 0x21, 0xe5, 0xf5, 0x89, 0xa3, 0xc9, 0x85, 0xc4, 0x8f, 0xde, 0xaa, 0xe, 0x45, 0x79, 0xae")
MAKE_THUNK(libasound, snd_mixer_selem_set_capture_volume_all, "0xec, 0x10, 0x44, 0x95, 0x7e, 0x90, 0x73, 0x71, 0xb7, 0x69, 0x5b, 0xf, 0x50, 0x69, 0xc8, 0xde, 0x7, 0x7b, 0xbd, 0xdd, 0xb8, 0xac, 0xec, 0x6c, 0x29, 0x3b, 0x2e, 0xf4, 0x9f, 0x21, 0xad, 0xe")
MAKE_THUNK(libasound, snd_mixer_selem_set_playback_dB_all, "0xf3, 0x2a, 0xf, 0xae, 0xfc, 0x95, 0xeb, 0xca, 0xb, 0xf5, 0xf5, 0x86, 0x72, 0xa6, 0x29, 0x4, 0xf2, 0x3a, 0x33, 0xe6, 0xcf, 0xc9, 0x1c, 0xd9, 0xae, 0xdb, 0xf4, 0x8c, 0xa5, 0x90, 0x1b, 0xd3")
MAKE_THUNK(libasound, snd_mixer_selem_set_capture_dB_all, "0xdf, 0xbb, 0x3f, 0x2a, 0x7c, 0x2e, 0x80, 0xf2, 0xed, 0xa3, 0xd6, 0x7e, 0xa5, 0xf2, 0x97, 0x35, 0x68, 0x5c, 0x9c, 0x52, 0x6, 0x8c, 0x9e, 0x64, 0x7, 0xfb, 0xa2, 0x5e, 0xd9, 0x8, 0xc3, 0xa3")
MAKE_THUNK(libasound, snd_mixer_selem_set_playback_switch, "0x35, 0xaa, 0x58, 0xe3, 0x7d, 0x8d, 0xfb, 0xd0, 0xda, 0x74, 0xd5, 0x7a, 0x55, 0xe9, 0x81, 0x65, 0xb2, 0x28, 0x8c, 0x35, 0xae, 0x85, 0x41, 0xad, 0xdc, 0xa4, 0xb4, 0x4e, 0x67, 0xbd, 0x7e, 0x4e")
MAKE_THUNK(libasound, snd_mixer_selem_set_capture_switch, "0x3f, 0x14, 0xcd, 0x41, 0x67, 0x21, 0xa5, 0x6c, 0x3b, 0xc7, 0x42, 0x42, 0xbb, 0xed, 0x1a, 0xf8, 0x49, 0x2a, 0xd6, 0x9, 0x55, 0xd7, 0x38, 0x74, 0xdb, 0x91, 0x30, 0xef, 0x1b, 0x33, 0x63, 0x8f")
MAKE_THUNK(libasound, snd_mixer_selem_set_playback_switch_all, "0xb, 0x70, 0xa9, 0xf2, 0xf5, 0x32, 0x35, 0x60, 0xd7, 0x93, 0xbf, 0x82, 0x82, 0x79, 0xcb, 0x20, 0x2d, 0x4a, 0x83, 0xd3, 0xb9, 0xe1, 0x78, 0xb8, 0x42, 0x9b, 0x61, 0xf5, 0x3c, 0xea, 0x50, 0x19")
MAKE_THUNK(libasound, snd_mixer_selem_set_capture_switch_all, "0xa8, 0xf1, 0xf2, 0x2f, 0x7f, 0xf7, 0x46, 0xd7, 0x4a, 0x38, 0xb, 0xfe, 0xc, 0x1d, 0x6c, 0x83, 0x56, 0x38, 0xd, 0x7f, 0xab, 0xb, 0x37, 0x3b, 0x59, 0xc3, 0x6a, 0xd, 0xfa, 0xed, 0x7f, 0x0")
MAKE_THUNK(libasound, snd_mixer_selem_get_playback_volume_range, "0x27, 0xab, 0x96, 0xd4, 0x34, 0x44, 0x2f, 0x77, 0x2a, 0x5b, 0x15, 0xde, 0x81, 0x1e, 0xcf, 0x7f, 0x44, 0xbc, 0x7a, 0x72, 0x1d, 0x4a, 0xab, 0xa5, 0x55, 0xe9, 0x3a, 0x8c, 0xe, 0x8d, 0xc7, 0x98")
MAKE_THUNK(libasound, snd_mixer_selem_get_playback_dB_range, "0x30, 0x3c, 0x51, 0x85, 0x9, 0x1f, 0xa1, 0xf6, 0x1e, 0x51, 0x43, 0xb3, 0x51, 0x19, 0x87, 0xa6, 0x77, 0x1b, 0x79, 0xda, 0xa2, 0x5e, 0x2e, 0xd, 0xe9, 0xec, 0x8b, 0xc3, 0xa5, 0x30, 0x2c, 0x0")
MAKE_THUNK(libasound, snd_mixer_selem_set_playback_volume_range, "0x28, 0xd9, 0xf6, 0xe9, 0x1, 0x6d, 0x7, 0xe, 0x80, 0x94, 0x2b, 0xee, 0xf0, 0x3e, 0x94, 0xda, 0x39, 0x29, 0xf0, 0xd2, 0x8, 0x89, 0x48, 0xff, 0x36, 0x31, 0x1, 0x9b, 0x73, 0x83, 0x2c, 0x9a")
MAKE_THUNK(libasound, snd_mixer_selem_get_capture_volume_range, "0x20, 0xf7, 0x20, 0x27, 0x6f, 0x7a, 0x71, 0x7d, 0xc5, 0xc7, 0x69, 0xda, 0xff, 0xc0, 0x42, 0x72, 0x9e, 0xdb, 0x7c, 0x8c, 0x55, 0x18, 0x9d, 0x12, 0x20, 0xb4, 0xa9, 0x43, 0xcc, 0x11, 0x55, 0xcb")
MAKE_THUNK(libasound, snd_mixer_selem_get_capture_dB_range, "0x15, 0x4, 0x47, 0x96, 0x4c, 0xbe, 0x8e, 0xe, 0xc4, 0xeb, 0x67, 0xde, 0xa6, 0xe6, 0x4f, 0x4a, 0x42, 0xd6, 0xc3, 0xb, 0x29, 0xc, 0x36, 0x8d, 0x53, 0xfc, 0x48, 0xa, 0x86, 0x13, 0xb0, 0x53")
MAKE_THUNK(libasound, snd_mixer_selem_set_capture_volume_range, "0x5d, 0xab, 0x3d, 0x60, 0xe1, 0xd1, 0x1, 0x4f, 0x9b, 0xae, 0x5c, 0x1a, 0xe0, 0xb9, 0xe8, 0x24, 0xf1, 0x25, 0x86, 0xa5, 0xc9, 0x41, 0x62, 0x92, 0x86, 0xe8, 0x9a, 0x71, 0xe6, 0xb6, 0xcd, 0xf6")
MAKE_THUNK(libasound, snd_mixer_selem_is_enumerated, "0xc6, 0x6, 0x2, 0x4a, 0x45, 0xe3, 0xa1, 0xd9, 0xf0, 0x9e, 0x4b, 0x30, 0x27, 0xea, 0x24, 0xad, 0xa2, 0x71, 0x54, 0x75, 0x55, 0xa, 0x45, 0xcb, 0x74, 0x45, 0xbb, 0xfa, 0x45, 0xf3, 0xa9, 0x6c")
MAKE_THUNK(libasound, snd_mixer_selem_is_enum_playback, "0x7, 0xa8, 0xd9, 0x44, 0x10, 0x2d, 0xaf, 0x42, 0xb, 0x30, 0xef, 0xdc, 0x46, 0x66, 0xf2, 0x15, 0x5f, 0xa4, 0x16, 0x6e, 0xbb, 0x9b, 0xca, 0x4d, 0xa6, 0xa1, 0xdf, 0xc3, 0xca, 0xb, 0x58, 0x89")
MAKE_THUNK(libasound, snd_mixer_selem_is_enum_capture, "0xc4, 0xb, 0xb4, 0x7a, 0x85, 0xf1, 0x8a, 0xad, 0x6, 0x70, 0x3f, 0x2b, 0x68, 0x25, 0x9c, 0xb5, 0x8b, 0xa4, 0x6e, 0xaa, 0x72, 0x4, 0xb4, 0x53, 0x59, 0x78, 0x9d, 0x67, 0x89, 0x20, 0xde, 0xdb")
MAKE_THUNK(libasound, snd_mixer_selem_get_enum_items, "0x78, 0xb7, 0x57, 0x9a, 0xd8, 0x82, 0xfc, 0x47, 0x25, 0xb7, 0x20, 0xda, 0x4, 0x33, 0x78, 0xf, 0x4d, 0x46, 0x11, 0x1b, 0x3e, 0x83, 0x62, 0x80, 0xe9, 0x92, 0xfd, 0xe1, 0xb6, 0x89, 0xae, 0x92")
MAKE_THUNK(libasound, snd_mixer_selem_get_enum_item_name, "0xb5, 0x5d, 0x70, 0x7a, 0x5a, 0xe1, 0x9a, 0x32, 0xb, 0x9, 0xcf, 0x83, 0xdf, 0x47, 0xc8, 0xed, 0x52, 0xe1, 0xc7, 0x30, 0x9d, 0x37, 0x4f, 0xdf, 0x6d, 0x85, 0x9d, 0xfd, 0xe, 0xa1, 0xb3, 0x68")
MAKE_THUNK(libasound, snd_mixer_selem_get_enum_item, "0xc5, 0x7d, 0xed, 0xe9, 0x8d, 0xd5, 0xc5, 0x7f, 0x40, 0xc9, 0x26, 0xd9, 0x5f, 0x29, 0x8b, 0xac, 0x34, 0x14, 0x39, 0xe4, 0x3c, 0x32, 0x61, 0x67, 0x69, 0xee, 0x59, 0x62, 0xb2, 0x52, 0x86, 0xef")
MAKE_THUNK(libasound, snd_mixer_selem_set_enum_item, "0x18, 0x25, 0x5a, 0x61, 0x38, 0x45, 0x10, 0x1d, 0x7c, 0xb2, 0xda, 0xf9, 0xf0, 0xe3, 0x6e, 0x1b, 0xb6, 0x47, 0x2d, 0xa4, 0xec, 0xe0, 0x83, 0xf, 0x9c, 0xd7, 0x27, 0x95, 0x79, 0x61, 0x64, 0x80")
MAKE_THUNK(libasound, snd_mixer_selem_id_sizeof, "0x13, 0xf3, 0xed, 0x1c, 0x1f, 0x93, 0xb5, 0xa0, 0xde, 0xb4, 0x9c, 0x8c, 0xea, 0xbe, 0x38, 0x43, 0x7, 0xf0, 0x9a, 0xd9, 0x90, 0xd2, 0x8a, 0x2d, 0x24, 0xa0, 0x2c, 0xb8, 0x14, 0x75, 0x97, 0x93")
MAKE_THUNK(libasound, snd_mixer_selem_id_malloc, "0x7a, 0x58, 0x1a, 0x8a, 0xe5, 0x98, 0x4a, 0xec, 0xda, 0xa9, 0x94, 0x9d, 0xb6, 0x14, 0xf, 0xc3, 0x88, 0xd9, 0x4a, 0x5a, 0xa6, 0xe0, 0x48, 0x57, 0x81, 0x97, 0x2e, 0x7a, 0x3b, 0xb1, 0x83, 0x25")
MAKE_THUNK(libasound, snd_mixer_selem_id_free, "0xff, 0x23, 0x66, 0xa8, 0x67, 0x9d, 0xf0, 0x85, 0xc0, 0xb8, 0x93, 0x8a, 0xd8, 0xac, 0xd6, 0x89, 0x3a, 0xaf, 0x2f, 0x2e, 0xdd, 0x33, 0x95, 0x90, 0xa0, 0x5, 0x49, 0xc7, 0x6b, 0xe3, 0x6b, 0xbd")
MAKE_THUNK(libasound, snd_mixer_selem_id_copy, "0x2d, 0x5d, 0xdd, 0x2a, 0xcd, 0x32, 0xc1, 0xe4, 0x85, 0x5d, 0x6b, 0xba, 0xf4, 0xd8, 0xac, 0xd5, 0x77, 0xdf, 0x2e, 0x5, 0x5d, 0x49, 0xd1, 0x6f, 0xed, 0x54, 0x40, 0xe1, 0x5b, 0x40, 0xf, 0x3f")
MAKE_THUNK(libasound, snd_mixer_selem_id_get_name, "0xa1, 0x75, 0xfd, 0x6c, 0xb2, 0x23, 0x18, 0x81, 0x2c, 0x18, 0xed, 0xa2, 0x68, 0xbb, 0x32, 0xf, 0x77, 0x5d, 0xa6, 0x37, 0xd3, 0x6f, 0x99, 0xf7, 0xc, 0xe8, 0x20, 0x26, 0xe7, 0xe6, 0xa2, 0xe0")
MAKE_THUNK(libasound, snd_mixer_selem_id_get_index, "0x7f, 0xe7, 0x1f, 0xc4, 0x24, 0x99, 0x39, 0xe5, 0xd3, 0x53, 0xcf, 0x9, 0x85, 0xa5, 0xd9, 0x42, 0x8a, 0x4a, 0x6b, 0xd1, 0xf6, 0x63, 0x32, 0xcb, 0xf9, 0xa8, 0xa1, 0xb3, 0x5e, 0xd4, 0xc2, 0x95")
MAKE_THUNK(libasound, snd_mixer_selem_id_set_name, "0xd2, 0x9b, 0x73, 0x68, 0x2f, 0x3f, 0xa6, 0xc7, 0x46, 0x16, 0x60, 0x20, 0x9f, 0x21, 0x61, 0x98, 0xdb, 0xdc, 0xac, 0x6d, 0x14, 0xb3, 0xde, 0x47, 0x12, 0xbb, 0xde, 0x80, 0xf7, 0x7d, 0x59, 0x2e")
MAKE_THUNK(libasound, snd_mixer_selem_id_set_index, "0x72, 0x63, 0xb1, 0xdf, 0x34, 0x86, 0x9a, 0x6a, 0x7b, 0x91, 0x86, 0x8c, 0x80, 0xb9, 0xff, 0xd, 0xcb, 0x2f, 0x40, 0xfc, 0xa8, 0xbf, 0x82, 0xb7, 0x1f, 0xcc, 0xd2, 0xdc, 0xa6, 0x97, 0xf, 0xe3")
MAKE_THUNK(libasound, snd_mixer_selem_id_parse, "0xc7, 0x4c, 0xcc, 0x47, 0xce, 0x8, 0x1e, 0xc8, 0x60, 0xc, 0x9d, 0x63, 0x98, 0x43, 0xd2, 0xed, 0x22, 0x7a, 0x86, 0x3b, 0x24, 0xd7, 0x55, 0xec, 0x40, 0xc7, 0x81, 0x50, 0xb7, 0xde, 0xb8, 0x2a")
MAKE_THUNK(libasound, snd_seq_open, "0x50, 0x7f, 0xa7, 0xe, 0xa7, 0x74, 0x4d, 0x35, 0xd7, 0x47, 0x95, 0xa9, 0xeb, 0xb0, 0x17, 0xe5, 0x10, 0x19, 0xfb, 0xcc, 0xc7, 0x94, 0x86, 0xc8, 0x65, 0xc5, 0xc3, 0x37, 0x8e, 0xb6, 0xac, 0x6b")
MAKE_THUNK(libasound, snd_seq_open_lconf, "0x73, 0xd, 0xe1, 0xeb, 0x6d, 0x58, 0x70, 0x1b, 0x31, 0xbb, 0x2e, 0x5a, 0xa3, 0x71, 0x9e, 0xbb, 0xd6, 0x50, 0xbc, 0x38, 0xe5, 0x40, 0x8d, 0xef, 0xdd, 0x7f, 0x61, 0xb4, 0x69, 0xdc, 0xfb, 0x73")
MAKE_THUNK(libasound, snd_seq_name, "0xc, 0xff, 0xcb, 0x2e, 0x61, 0xb4, 0xc7, 0xa5, 0xf8, 0xed, 0x3a, 0x40, 0x30, 0xed, 0x68, 0xf5, 0x33, 0x40, 0xdf, 0xd8, 0xd7, 0x5e, 0xa2, 0x3f, 0x7, 0x16, 0xf5, 0x6f, 0xdd, 0x53, 0xed, 0x9f")
MAKE_THUNK(libasound, snd_seq_type, "0x1, 0x50, 0xb7, 0x48, 0xa5, 0x79, 0x95, 0x67, 0xc, 0xac, 0x43, 0x56, 0x6e, 0x3, 0x6f, 0x5a, 0xe7, 0x3e, 0xa0, 0x92, 0x87, 0x85, 0x33, 0x3e, 0x29, 0xf0, 0xf6, 0x65, 0x60, 0xb3, 0x86, 0x6")
MAKE_THUNK(libasound, snd_seq_close, "0xae, 0x18, 0xda, 0xf3, 0xe8, 0xc2, 0xb6, 0x94, 0x12, 0xc5, 0x63, 0x4f, 0x9b, 0x19, 0x75, 0x28, 0x4c, 0x4e, 0xe9, 0x31, 0xc7, 0x2d, 0xa3, 0x5b, 0x4b, 0x8e, 0xbc, 0x43, 0x3b, 0x8b, 0x25, 0x84")
MAKE_THUNK(libasound, snd_seq_poll_descriptors_count, "0xf1, 0x88, 0xb1, 0xcf, 0xbe, 0xf8, 0x4f, 0x54, 0xfe, 0xf, 0x35, 0xdd, 0x76, 0xe0, 0xf1, 0xd0, 0x7e, 0x2d, 0x69, 0xdb, 0x2, 0xa0, 0x9c, 0xd4, 0xbd, 0x41, 0xd0, 0x59, 0xf9, 0x7, 0x4, 0xc")
MAKE_THUNK(libasound, snd_seq_poll_descriptors, "0x3, 0xed, 0xbf, 0xf6, 0x8d, 0x7a, 0xac, 0xc3, 0xc8, 0x5b, 0x48, 0x6f, 0xbc, 0xd0, 0xb1, 0xd2, 0xf1, 0x2e, 0xb2, 0x59, 0x19, 0xd9, 0x8a, 0xf5, 0xde, 0x74, 0xcb, 0x42, 0xe5, 0x16, 0x93, 0x2b")
MAKE_THUNK(libasound, snd_seq_poll_descriptors_revents, "0xa6, 0x45, 0x80, 0x53, 0x33, 0x1d, 0xe9, 0x21, 0xde, 0x4c, 0x35, 0xc2, 0x80, 0x90, 0x3e, 0x7e, 0x44, 0x54, 0x55, 0xe, 0xd, 0xd0, 0x8f, 0x50, 0xc2, 0xa3, 0x7d, 0x86, 0xe3, 0x5e, 0x59, 0xf7")
MAKE_THUNK(libasound, snd_seq_nonblock, "0x36, 0x4e, 0xfe, 0xf0, 0xfd, 0xdb, 0x1, 0x3, 0xd7, 0xa7, 0x84, 0xe4, 0xe5, 0x23, 0x42, 0x6b, 0x33, 0x27, 0x5c, 0xe2, 0x65, 0x51, 0xd4, 0xba, 0xdc, 0xc7, 0xa, 0xd6, 0x51, 0xe0, 0x39, 0x4b")
MAKE_THUNK(libasound, snd_seq_client_id, "0xc5, 0xce, 0xd1, 0xd3, 0xe0, 0xdf, 0xe1, 0x35, 0xbd, 0xed, 0x63, 0xb9, 0xdd, 0xee, 0x46, 0xc6, 0x5f, 0xc7, 0x23, 0x5, 0xa7, 0xee, 0xf6, 0xc2, 0x74, 0x1a, 0xf8, 0xc7, 0xc5, 0xc4, 0x7e, 0x9a")
MAKE_THUNK(libasound, snd_seq_get_output_buffer_size, "0xa7, 0xc9, 0xcb, 0x58, 0x71, 0xfd, 0x41, 0x1a, 0x2d, 0xa, 0xd, 0x7e, 0x2d, 0xa2, 0x26, 0x84, 0x29, 0x6e, 0x37, 0xe5, 0x83, 0x81, 0xba, 0xda, 0xcf, 0xf5, 0x12, 0xd6, 0x97, 0x45, 0x7c, 0xdf")
MAKE_THUNK(libasound, snd_seq_get_input_buffer_size, "0xe2, 0xd5, 0xbe, 0xa6, 0x77, 0xe3, 0xe0, 0x45, 0xbf, 0x5c, 0x4e, 0x2e, 0xe1, 0x77, 0x19, 0x2b, 0x1a, 0xe2, 0x8f, 0x9b, 0xa5, 0x37, 0x60, 0x60, 0x8d, 0x64, 0xe3, 0x55, 0xa9, 0x71, 0x1f, 0xed")
MAKE_THUNK(libasound, snd_seq_set_output_buffer_size, "0x2a, 0xd7, 0x8f, 0x1b, 0xf3, 0xbb, 0xad, 0x4c, 0x9a, 0x3b, 0xd7, 0x24, 0x77, 0x48, 0x43, 0x9a, 0xc6, 0x62, 0xb5, 0xd1, 0x1, 0x7a, 0xec, 0x27, 0x14, 0x13, 0x25, 0xa0, 0xc7, 0x30, 0xc8, 0x8f")
MAKE_THUNK(libasound, snd_seq_set_input_buffer_size, "0x9d, 0xe2, 0x3, 0xac, 0x83, 0x2c, 0x5f, 0xeb, 0xbd, 0x7c, 0xc3, 0xe1, 0xfd, 0x4a, 0x4c, 0x3a, 0x19, 0xc6, 0xcb, 0xe0, 0x30, 0xf5, 0xc9, 0x66, 0xa4, 0x1b, 0x0, 0x42, 0xb2, 0xf0, 0xb6, 0xf7")
MAKE_THUNK(libasound, snd_seq_system_info_sizeof, "0xe2, 0xef, 0x70, 0x33, 0x8e, 0xc9, 0xaf, 0x7d, 0x1d, 0xd7, 0x93, 0x54, 0xb8, 0xac, 0xd6, 0x6a, 0xc3, 0x74, 0xd4, 0x5e, 0x9a, 0x12, 0xd2, 0x57, 0xdd, 0x6, 0x28, 0x92, 0x41, 0x78, 0x52, 0x10")
MAKE_THUNK(libasound, snd_seq_system_info_malloc, "0xcd, 0x98, 0xc7, 0x2, 0xb3, 0x23, 0x32, 0xaa, 0xb0, 0x20, 0xf4, 0xd3, 0x69, 0x1e, 0xd, 0x3, 0x24, 0xbc, 0xec, 0x87, 0xf2, 0xf7, 0xe0, 0x20, 0xfd, 0xff, 0x48, 0xa4, 0x90, 0x7e, 0x18, 0x63")
MAKE_THUNK(libasound, snd_seq_system_info_free, "0xf0, 0x65, 0xde, 0x5f, 0x14, 0x69, 0xf7, 0xa8, 0xdd, 0xe3, 0xa0, 0x10, 0x1f, 0xdf, 0xb5, 0xc0, 0xf2, 0xdb, 0x9f, 0x5c, 0x4d, 0xed, 0xcc, 0x59, 0xcd, 0xc6, 0x36, 0xa8, 0xb2, 0x68, 0x87, 0x21")
MAKE_THUNK(libasound, snd_seq_system_info_copy, "0x6b, 0x1a, 0xf8, 0x1f, 0x62, 0xd5, 0x92, 0x57, 0xd7, 0x79, 0x5, 0x6d, 0xc6, 0xde, 0x6a, 0x7b, 0x84, 0xdd, 0x35, 0xcc, 0x47, 0x19, 0x8c, 0xf, 0x28, 0xe8, 0xc0, 0xf5, 0xa8, 0x9c, 0x85, 0x69")
MAKE_THUNK(libasound, snd_seq_system_info_get_queues, "0x3d, 0x6a, 0x44, 0x88, 0xc4, 0x5b, 0xa1, 0x0, 0x1c, 0x51, 0x52, 0xdc, 0xdc, 0xf0, 0xd7, 0xf0, 0x35, 0x32, 0x32, 0x8c, 0x6b, 0x8b, 0x36, 0x95, 0xea, 0x1e, 0xf7, 0x7f, 0xd, 0xb8, 0xa, 0x6e")
MAKE_THUNK(libasound, snd_seq_system_info_get_clients, "0x5c, 0x1a, 0x32, 0xe1, 0xf0, 0xcb, 0xfb, 0xfe, 0x28, 0x9d, 0x57, 0x75, 0x1e, 0xa7, 0xc2, 0xfb, 0xcf, 0xde, 0xfa, 0xe5, 0x22, 0x56, 0x88, 0xe, 0xaf, 0x3f, 0x3f, 0x6e, 0x72, 0x3d, 0xce, 0x1f")
MAKE_THUNK(libasound, snd_seq_system_info_get_ports, "0x6a, 0x2, 0xd, 0x5b, 0xec, 0xed, 0xb8, 0x43, 0x0, 0x19, 0x76, 0x69, 0x93, 0x92, 0x6b, 0xcc, 0x5e, 0x6b, 0x3d, 0x1c, 0x6b, 0x6, 0x95, 0xe0, 0x53, 0xe4, 0x58, 0x88, 0x25, 0xfc, 0xba, 0x9a")
MAKE_THUNK(libasound, snd_seq_system_info_get_channels, "0xfa, 0x71, 0x76, 0xa, 0x97, 0x8e, 0x83, 0xa6, 0x9a, 0x32, 0x12, 0x80, 0x4a, 0x8c, 0x38, 0x48, 0x2d, 0x9d, 0xea, 0x8b, 0xa3, 0x33, 0x7e, 0x9, 0x83, 0x18, 0xbb, 0x99, 0x13, 0x8a, 0xb3, 0x63")
MAKE_THUNK(libasound, snd_seq_system_info_get_cur_clients, "0x10, 0x2d, 0xae, 0x3f, 0xf, 0x10, 0xe6, 0x7c, 0xce, 0xb6, 0xf1, 0x6, 0xb6, 0xdb, 0xe9, 0x89, 0xfd, 0x37, 0xe5, 0x9d, 0x5d, 0xea, 0xf5, 0x38, 0xa6, 0xfb, 0x46, 0x84, 0x5b, 0xf3, 0xa9, 0xb8")
MAKE_THUNK(libasound, snd_seq_system_info_get_cur_queues, "0x96, 0x8c, 0x5c, 0xf8, 0xa7, 0x0, 0x4c, 0xe6, 0xe, 0x7f, 0x4e, 0xc4, 0x36, 0xe, 0x5e, 0x7c, 0xc6, 0x71, 0xc7, 0x9e, 0x3a, 0xd5, 0x8f, 0xe8, 0xbd, 0xd6, 0x73, 0x75, 0x39, 0x4b, 0x48, 0xdf")
MAKE_THUNK(libasound, snd_seq_system_info, "0xcc, 0x50, 0x3, 0x75, 0x4a, 0x14, 0x3f, 0xe7, 0x3d, 0xf0, 0xe4, 0x43, 0x53, 0xa2, 0xb6, 0x1e, 0xcf, 0x98, 0xff, 0xbc, 0x64, 0x69, 0x80, 0x73, 0x4b, 0xd0, 0x71, 0x75, 0xee, 0x9, 0xaa, 0x3")
MAKE_THUNK(libasound, snd_seq_client_info_sizeof, "0x4b, 0xbd, 0xad, 0xfd, 0x6e, 0x29, 0xf4, 0x9f, 0x72, 0x5d, 0xd9, 0x25, 0xc2, 0x7b, 0x81, 0xfc, 0x37, 0x57, 0xfb, 0x99, 0xd4, 0xc0, 0xb6, 0x76, 0x16, 0x89, 0xc4, 0xd6, 0x3c, 0x4a, 0x1f, 0xca")
MAKE_THUNK(libasound, snd_seq_client_info_malloc, "0x5d, 0xaf, 0xcf, 0x64, 0x18, 0x46, 0xfb, 0x93, 0x85, 0xa0, 0x58, 0x78, 0x18, 0x21, 0x8d, 0x86, 0xb1, 0xcd, 0xfe, 0xae, 0xb2, 0x44, 0x6e, 0x4d, 0x84, 0x51, 0x88, 0xb7, 0x9f, 0xd1, 0x2e, 0x82")
MAKE_THUNK(libasound, snd_seq_client_info_free, "0x21, 0xc8, 0xb5, 0xc4, 0xbb, 0xde, 0x5d, 0x2a, 0x50, 0x65, 0x93, 0x8, 0x87, 0x81, 0x84, 0x13, 0xa3, 0xf1, 0xd4, 0x34, 0x3f, 0x5c, 0x77, 0x67, 0xbb, 0x94, 0x1d, 0x7f, 0x88, 0xa0, 0x70, 0xc0")
MAKE_THUNK(libasound, snd_seq_client_info_copy, "0x3, 0x4e, 0xfe, 0x82, 0x94, 0x6, 0xa2, 0x5c, 0x80, 0xd, 0x14, 0xd9, 0x40, 0xca, 0xd5, 0xf7, 0x14, 0xd7, 0x6d, 0xae, 0xef, 0xf5, 0x3a, 0x40, 0x60, 0x98, 0xd1, 0xfb, 0x7a, 0xdb, 0xe1, 0xa6")
MAKE_THUNK(libasound, snd_seq_client_info_get_client, "0x9a, 0x5c, 0x1b, 0x3c, 0x8a, 0x89, 0xbf, 0xd4, 0xee, 0xf8, 0xb1, 0x71, 0xec, 0xa6, 0x2f, 0x65, 0x91, 0xb6, 0x2c, 0x9c, 0x75, 0x2c, 0xfd, 0xca, 0xf5, 0x2f, 0x38, 0x1a, 0xe9, 0xd2, 0xc5, 0x15")
MAKE_THUNK(libasound, snd_seq_client_info_get_type, "0x99, 0x66, 0x1b, 0x25, 0xe4, 0x47, 0x80, 0xe3, 0x1b, 0xd7, 0xdf, 0x87, 0xcf, 0x59, 0xab, 0x31, 0xb5, 0x11, 0xf1, 0x53, 0xd8, 0x44, 0x16, 0x7a, 0xf4, 0x81, 0x51, 0x27, 0x6a, 0xf9, 0xfd, 0x42")
MAKE_THUNK(libasound, snd_seq_client_info_get_name, "0x8b, 0x9b, 0x85, 0x69, 0x68, 0x21, 0xd3, 0xe2, 0xe8, 0x4a, 0x10, 0x4, 0x37, 0x63, 0x3d, 0xe7, 0x19, 0x98, 0xd8, 0xb6, 0x9e, 0x5a, 0xb, 0xa4, 0xd1, 0x69, 0x6c, 0x96, 0x82, 0x87, 0xd4, 0x67")
MAKE_THUNK(libasound, snd_seq_client_info_get_broadcast_filter, "0x17, 0xb5, 0x23, 0x31, 0xe4, 0x5d, 0xb2, 0x5c, 0x20, 0x66, 0x58, 0x12, 0x9c, 0xdd, 0x1b, 0x35, 0x41, 0xcb, 0x3e, 0x6f, 0xc0, 0x97, 0xb8, 0x6b, 0x4a, 0x70, 0x5a, 0x29, 0xd3, 0x39, 0xbe, 0xbe")
MAKE_THUNK(libasound, snd_seq_client_info_get_error_bounce, "0xb1, 0x4c, 0x32, 0x7f, 0x73, 0x58, 0x4c, 0x10, 0xac, 0x1, 0x52, 0x30, 0x34, 0x82, 0xa9, 0xfa, 0x83, 0xcb, 0x6, 0xcb, 0x6f, 0x59, 0x3a, 0xe5, 0x98, 0x7a, 0xcd, 0x9e, 0x60, 0xf6, 0x10, 0x2e")
MAKE_THUNK(libasound, snd_seq_client_info_get_card, "0xf, 0xa7, 0x63, 0x1e, 0x68, 0xcc, 0x66, 0x41, 0x4b, 0x5c, 0x1f, 0xa, 0x3b, 0xc1, 0x44, 0x6d, 0x1a, 0x38, 0x96, 0x87, 0xc8, 0x1c, 0xe0, 0x2b, 0x9a, 0xe8, 0xcb, 0x56, 0x7f, 0xd6, 0x43, 0x86")
MAKE_THUNK(libasound, snd_seq_client_info_get_pid, "0x53, 0xeb, 0x76, 0x75, 0xb0, 0xf7, 0x1c, 0xbf, 0xa9, 0x66, 0xf0, 0xa, 0x6c, 0xe, 0x31, 0x21, 0xcf, 0xe2, 0xcf, 0x31, 0xc, 0x4e, 0x2e, 0x19, 0x49, 0x9b, 0xa4, 0xfc, 0xad, 0x3, 0xd9, 0x11")
MAKE_THUNK(libasound, snd_seq_client_info_get_event_filter, "0xc7, 0xe7, 0x41, 0xf4, 0x8c, 0xef, 0xc6, 0x99, 0x5c, 0x57, 0x3, 0x29, 0x74, 0x54, 0xc5, 0xd4, 0xc7, 0xc5, 0x81, 0x92, 0x60, 0x8a, 0x39, 0xfe, 0xfa, 0xf1, 0xf5, 0x4, 0x85, 0x0, 0x46, 0x53")
MAKE_THUNK(libasound, snd_seq_client_info_get_num_ports, "0xd6, 0xff, 0x24, 0x89, 0x3c, 0x4e, 0xac, 0xc9, 0xef, 0xe0, 0xeb, 0xbc, 0xcf, 0x39, 0xeb, 0xf6, 0x48, 0xe3, 0xaa, 0x4b, 0x39, 0xfb, 0x2c, 0xa6, 0x29, 0x58, 0xce, 0xc1, 0xc, 0x7c, 0xff, 0xa2")
MAKE_THUNK(libasound, snd_seq_client_info_get_event_lost, "0x6c, 0x25, 0x12, 0xaf, 0x1f, 0x44, 0x7, 0xc9, 0xe, 0x5c, 0xd9, 0xcc, 0x62, 0x8a, 0x53, 0xe7, 0x4a, 0xb5, 0xc7, 0xba, 0x8d, 0xec, 0xda, 0x2b, 0xd4, 0x9d, 0x54, 0xb1, 0x20, 0x8f, 0x3d, 0xa")
MAKE_THUNK(libasound, snd_seq_client_info_set_client, "0xda, 0x48, 0x80, 0xa4, 0xd1, 0xde, 0xf6, 0x81, 0x27, 0xca, 0xde, 0x8f, 0x9e, 0x4, 0x52, 0x38, 0xc9, 0x7e, 0xdf, 0x78, 0xa8, 0x79, 0xa7, 0xd5, 0x8a, 0xd6, 0x5b, 0xa0, 0x58, 0x30, 0x8, 0x8a")
MAKE_THUNK(libasound, snd_seq_client_info_set_name, "0xa9, 0x4b, 0x60, 0x26, 0x65, 0xbb, 0xe0, 0xe, 0x3c, 0x4b, 0x76, 0xc8, 0x6d, 0x73, 0x48, 0xfb, 0xf1, 0x71, 0xdb, 0x94, 0xfe, 0xca, 0x52, 0x1b, 0xcc, 0x12, 0x81, 0x40, 0xd0, 0xea, 0xe7, 0x92")
MAKE_THUNK(libasound, snd_seq_client_info_set_broadcast_filter, "0x26, 0xd1, 0x28, 0x26, 0x6, 0xa8, 0x91, 0x54, 0xb4, 0xa, 0x4a, 0x38, 0xa6, 0x99, 0xdb, 0x9e, 0x70, 0x1, 0x14, 0xad, 0x8b, 0x19, 0xe, 0x30, 0x77, 0x34, 0xa0, 0xd4, 0x9b, 0x50, 0xbd, 0x19")
MAKE_THUNK(libasound, snd_seq_client_info_set_error_bounce, "0x3a, 0xa, 0xcb, 0xce, 0x50, 0xad, 0x4d, 0x45, 0x28, 0x14, 0x27, 0xc8, 0x65, 0x5d, 0x83, 0x93, 0x25, 0x21, 0x28, 0x23, 0x37, 0x5f, 0x52, 0x18, 0x6f, 0xc6, 0x83, 0xa9, 0xed, 0x98, 0x4d, 0x83")
MAKE_THUNK(libasound, snd_seq_client_info_set_event_filter, "0x7, 0xf7, 0xb6, 0xf3, 0x22, 0x6d, 0xe4, 0x40, 0x78, 0x9c, 0x97, 0x5f, 0x5e, 0xed, 0xde, 0x55, 0x40, 0xda, 0xf4, 0x83, 0x23, 0x9a, 0x6f, 0xf7, 0x86, 0x7a, 0x34, 0x1b, 0x11, 0x27, 0xb2, 0xac")
MAKE_THUNK(libasound, snd_seq_client_info_event_filter_clear, "0x5d, 0xa1, 0x7c, 0x5c, 0xd9, 0x44, 0x78, 0x7f, 0x6e, 0x99, 0xa3, 0xf4, 0x86, 0x18, 0x36, 0xfa, 0x23, 0x6b, 0x21, 0x15, 0x48, 0xd9, 0x91, 0xc5, 0x4, 0x95, 0xab, 0x23, 0xc3, 0x53, 0xc, 0x46")
MAKE_THUNK(libasound, snd_seq_client_info_event_filter_add, "0x78, 0x10, 0xdf, 0x3e, 0xf4, 0x74, 0x24, 0xda, 0x1a, 0x45, 0x4d, 0x9a, 0x81, 0x3d, 0xf7, 0xa8, 0x5a, 0xc2, 0x3f, 0x10, 0x8c, 0xde, 0x8b, 0xbd, 0xff, 0x5d, 0x8c, 0x58, 0x10, 0x42, 0x9, 0xd9")
MAKE_THUNK(libasound, snd_seq_client_info_event_filter_del, "0xb0, 0xb0, 0x13, 0x20, 0x6d, 0x68, 0x94, 0x76, 0xa3, 0x19, 0x88, 0x2e, 0xb3, 0x91, 0x65, 0xbd, 0xc9, 0x40, 0xa1, 0x9a, 0x52, 0xa8, 0x6f, 0x1d, 0x72, 0x5d, 0xad, 0xaf, 0x85, 0xbd, 0x33, 0x80")
MAKE_THUNK(libasound, snd_seq_client_info_event_filter_check, "0x3f, 0xa6, 0xd3, 0x8b, 0x32, 0xe9, 0x0, 0xb9, 0xa9, 0xf9, 0xe8, 0x6e, 0x35, 0xc2, 0x92, 0x57, 0x85, 0x5d, 0xa2, 0x80, 0x85, 0xfe, 0xd3, 0xf, 0x79, 0x10, 0xaf, 0xf1, 0x53, 0xf7, 0x3f, 0xb5")
MAKE_THUNK(libasound, snd_seq_get_client_info, "0xf0, 0xc1, 0xe5, 0x7c, 0x5b, 0x22, 0x9b, 0x66, 0x52, 0x36, 0xd8, 0x44, 0xec, 0x30, 0x56, 0x13, 0xbc, 0x72, 0xe, 0x49, 0xca, 0xf6, 0xed, 0x72, 0xbf, 0x7e, 0x4d, 0x5d, 0x63, 0x76, 0x48, 0x98")
MAKE_THUNK(libasound, snd_seq_get_any_client_info, "0x93, 0x9e, 0xf9, 0x7e, 0xc1, 0xa7, 0x45, 0x66, 0x59, 0xa9, 0xa9, 0xa9, 0xd8, 0xe2, 0xec, 0x70, 0xbf, 0x77, 0x3c, 0x3f, 0x19, 0x66, 0x55, 0x24, 0xd5, 0x5c, 0x8, 0xfd, 0x3f, 0x6a, 0xf4, 0x17")
MAKE_THUNK(libasound, snd_seq_set_client_info, "0x2b, 0xce, 0x5, 0xc5, 0x36, 0xdd, 0x6c, 0x42, 0xe, 0x16, 0x62, 0x7b, 0xc2, 0x56, 0xcb, 0x2a, 0xf7, 0xa0, 0xa4, 0xa6, 0x2f, 0xb1, 0x63, 0xe2, 0x2f, 0xec, 0x6c, 0xb7, 0xc2, 0x58, 0x9f, 0x1e")
MAKE_THUNK(libasound, snd_seq_query_next_client, "0x6c, 0x63, 0x1, 0xbf, 0x13, 0x7a, 0x99, 0xce, 0x68, 0xfb, 0xce, 0x7c, 0x20, 0x22, 0x4f, 0x46, 0x29, 0x57, 0xa2, 0xe, 0x61, 0xd0, 0x8c, 0x88, 0x3e, 0xf5, 0xe5, 0xd1, 0x91, 0xb6, 0x86, 0x4d")
MAKE_THUNK(libasound, snd_seq_client_pool_sizeof, "0x4a, 0xb9, 0xa5, 0x15, 0x65, 0x7a, 0x52, 0xc4, 0x15, 0x7b, 0xa1, 0xe3, 0x19, 0x1b, 0x6a, 0x67, 0x67, 0x2d, 0x64, 0xbf, 0x47, 0x24, 0xa3, 0xfe, 0x37, 0x6e, 0xba, 0x1b, 0xf3, 0x6d, 0xc9, 0x48")
MAKE_THUNK(libasound, snd_seq_client_pool_malloc, "0x84, 0xc2, 0xde, 0x82, 0xdf, 0x13, 0xb7, 0x98, 0x49, 0x8a, 0xb1, 0x49, 0x5, 0xa7, 0x4b, 0x58, 0x19, 0x63, 0xf6, 0x51, 0x95, 0x69, 0x45, 0x58, 0x8c, 0x23, 0x12, 0x34, 0xcc, 0x1, 0xa2, 0x71")
MAKE_THUNK(libasound, snd_seq_client_pool_free, "0x4e, 0x45, 0xf6, 0xff, 0x31, 0xf2, 0x9a, 0xb8, 0x6c, 0xbc, 0x22, 0xc4, 0xdb, 0x86, 0xed, 0x51, 0x48, 0x0, 0x95, 0x22, 0x36, 0x89, 0x9a, 0xef, 0x6b, 0x33, 0x20, 0xac, 0xba, 0x1d, 0x36, 0xf5")
MAKE_THUNK(libasound, snd_seq_client_pool_copy, "0xab, 0x33, 0x38, 0xbb, 0xe7, 0x5c, 0xea, 0xed, 0x61, 0xe, 0x76, 0x4, 0x3f, 0x8, 0xb, 0x74, 0x6e, 0x67, 0x84, 0x7c, 0xe8, 0xa0, 0xd0, 0x65, 0xb4, 0x5c, 0x41, 0xbf, 0xf9, 0x83, 0xf, 0xc1")
MAKE_THUNK(libasound, snd_seq_client_pool_get_client, "0xbd, 0xe4, 0xe7, 0xb7, 0xa5, 0x25, 0x99, 0x77, 0x3b, 0x31, 0xc, 0xb8, 0x18, 0x43, 0x52, 0x11, 0xb0, 0xb8, 0x7b, 0x38, 0x39, 0x40, 0xe1, 0xb2, 0x2d, 0xcd, 0x71, 0xfe, 0xb3, 0x94, 0x4, 0xeb")
MAKE_THUNK(libasound, snd_seq_client_pool_get_output_pool, "0x94, 0xd3, 0x81, 0x6c, 0xc0, 0xa, 0x1, 0x4, 0xfb, 0xff, 0x63, 0x5, 0x2a, 0xd5, 0x71, 0x8e, 0x80, 0x2b, 0x24, 0x97, 0x66, 0x2d, 0x2, 0x38, 0xca, 0x3e, 0x48, 0x88, 0x4, 0x88, 0x43, 0xd3")
MAKE_THUNK(libasound, snd_seq_client_pool_get_input_pool, "0xde, 0x93, 0xe1, 0x4f, 0x15, 0xdd, 0xb8, 0x47, 0x91, 0xd8, 0x4d, 0x5a, 0xd9, 0xd6, 0x9a, 0x1, 0xd, 0xf3, 0xf1, 0xeb, 0x22, 0xc9, 0xe2, 0x73, 0x31, 0xec, 0x40, 0x54, 0x8e, 0x2e, 0x32, 0xff")
MAKE_THUNK(libasound, snd_seq_client_pool_get_output_room, "0x8a, 0x6, 0x3d, 0xfc, 0x1d, 0xc8, 0x75, 0xe2, 0x70, 0xb7, 0x79, 0x4, 0xe4, 0x60, 0xa1, 0x3e, 0x41, 0xd3, 0x26, 0xf, 0x4e, 0xe0, 0x56, 0xcc, 0xda, 0xa4, 0x3e, 0xd4, 0xfb, 0xde, 0xaa, 0xa8")
MAKE_THUNK(libasound, snd_seq_client_pool_get_output_free, "0xe2, 0x1c, 0x6f, 0xa3, 0xe7, 0xda, 0xfc, 0x42, 0x38, 0x3e, 0x41, 0xeb, 0x33, 0xf3, 0xc2, 0x29, 0x2, 0x55, 0x97, 0xaa, 0xc7, 0x58, 0xda, 0xf4, 0xb3, 0x9e, 0x80, 0xd, 0x84, 0x48, 0x4e, 0x4e")
MAKE_THUNK(libasound, snd_seq_client_pool_get_input_free, "0xcb, 0x33, 0x1f, 0x19, 0xf2, 0x9d, 0xcc, 0x79, 0x87, 0xa7, 0x2, 0x5a, 0x2a, 0xc7, 0x9d, 0xbf, 0x20, 0x35, 0xd1, 0xe5, 0x94, 0xb8, 0x8b, 0xe3, 0x5c, 0x4d, 0xe4, 0xd, 0x6c, 0xb7, 0xaf, 0x64")
MAKE_THUNK(libasound, snd_seq_client_pool_set_output_pool, "0xd4, 0xf3, 0x19, 0xb4, 0xb5, 0x5a, 0x6d, 0x68, 0x55, 0x4f, 0xd, 0x4a, 0x34, 0x48, 0x18, 0x92, 0xbc, 0xa9, 0x7e, 0x9e, 0xa0, 0x8a, 0xcc, 0x83, 0xbb, 0x3c, 0xec, 0x6a, 0x4d, 0xe6, 0x33, 0x17")
MAKE_THUNK(libasound, snd_seq_client_pool_set_input_pool, "0x9d, 0xee, 0xe4, 0x13, 0x3, 0x4d, 0x9a, 0xfc, 0x60, 0xd, 0x4d, 0x36, 0x8f, 0xb0, 0xd, 0xfb, 0xef, 0xa4, 0xf2, 0xf7, 0x16, 0x14, 0x2, 0x1f, 0x42, 0xa1, 0xbc, 0xd9, 0x35, 0x7d, 0x1c, 0x72")
MAKE_THUNK(libasound, snd_seq_client_pool_set_output_room, "0x26, 0xe8, 0x9d, 0xae, 0x3d, 0x84, 0xbe, 0xa5, 0x73, 0x60, 0x4d, 0x9b, 0x8, 0xcc, 0xdf, 0x8f, 0x3d, 0xe6, 0x3c, 0xea, 0x91, 0x12, 0xd0, 0x59, 0x87, 0x9c, 0x12, 0x57, 0x38, 0x95, 0x5, 0x5c")
MAKE_THUNK(libasound, snd_seq_get_client_pool, "0x75, 0xcf, 0x48, 0x9f, 0xe6, 0xa6, 0x73, 0xb7, 0x3f, 0xc6, 0xac, 0x95, 0xe, 0x19, 0xab, 0x5f, 0x42, 0xad, 0x38, 0x96, 0x15, 0x4c, 0xb3, 0x39, 0xd0, 0xf4, 0xf2, 0x30, 0xd0, 0xdb, 0x44, 0xcc")
MAKE_THUNK(libasound, snd_seq_set_client_pool, "0x2, 0x21, 0x3c, 0x96, 0x33, 0x71, 0x66, 0x96, 0xba, 0x2c, 0xe9, 0xd6, 0xa7, 0xcf, 0xa4, 0x90, 0xb8, 0xae, 0xcb, 0xb8, 0x5e, 0xad, 0x89, 0x4d, 0x56, 0x37, 0x99, 0xd, 0x3c, 0x2c, 0xdd, 0xae")
MAKE_THUNK(libasound, snd_seq_port_info_sizeof, "0x9d, 0x2b, 0xf1, 0xd8, 0x57, 0x9d, 0xe, 0x8, 0xe0, 0x20, 0x5a, 0xd1, 0xaf, 0xd5, 0xcb, 0x22, 0x28, 0x95, 0x3, 0x45, 0x80, 0xf3, 0xa5, 0x6b, 0x75, 0x9e, 0x4f, 0x93, 0xd1, 0x6d, 0x29, 0x32")
MAKE_THUNK(libasound, snd_seq_port_info_malloc, "0x6, 0x80, 0x8b, 0xca, 0x9, 0x2, 0xd1, 0xe1, 0xe0, 0x70, 0x6d, 0xc1, 0x23, 0x2f, 0x1e, 0x67, 0xf1, 0x8e, 0xa4, 0x40, 0x23, 0x15, 0x64, 0x2a, 0xf2, 0xc4, 0x4e, 0x72, 0x7, 0xf2, 0x43, 0x22")
MAKE_THUNK(libasound, snd_seq_port_info_free, "0x72, 0x4f, 0xa8, 0xb8, 0xdd, 0xa8, 0x78, 0xb6, 0xd1, 0xfd, 0x84, 0x2c, 0xe1, 0x8c, 0x1a, 0x15, 0x22, 0x68, 0xb7, 0xae, 0x8d, 0x41, 0xaa, 0x37, 0x4f, 0x14, 0xc1, 0x7e, 0xa4, 0x76, 0xe1, 0x10")
MAKE_THUNK(libasound, snd_seq_port_info_copy, "0xba, 0x2, 0x44, 0xb3, 0x2a, 0x5a, 0xda, 0xff, 0xdf, 0xcd, 0x7a, 0x52, 0x3d, 0xfb, 0x12, 0x75, 0x67, 0x27, 0x7c, 0xe0, 0x55, 0x70, 0x41, 0xf5, 0x7, 0x37, 0xd2, 0x94, 0x7e, 0xf4, 0x95, 0x5f")
MAKE_THUNK(libasound, snd_seq_port_info_get_client, "0x53, 0x91, 0x64, 0x3d, 0xea, 0x6, 0xb1, 0x74, 0x56, 0xad, 0x42, 0x88, 0xa4, 0xbb, 0x44, 0x7b, 0x3b, 0xc3, 0xda, 0xec, 0xda, 0x5, 0x5f, 0x25, 0xd, 0x90, 0xe0, 0x86, 0x8e, 0xd, 0x83, 0xfb")
MAKE_THUNK(libasound, snd_seq_port_info_get_port, "0xea, 0x7b, 0x4d, 0xc6, 0x19, 0x5c, 0x25, 0x61, 0xda, 0x97, 0x9e, 0xf6, 0x35, 0x1d, 0x28, 0x92, 0x5, 0x46, 0xfd, 0x4b, 0xe0, 0x5a, 0x8a, 0xe, 0xc1, 0x2a, 0x67, 0x9b, 0x0, 0x65, 0x82, 0x3d")
MAKE_THUNK(libasound, snd_seq_port_info_get_addr, "0x64, 0xd6, 0x6b, 0x90, 0x49, 0xc4, 0xf7, 0x4a, 0x44, 0x17, 0xf1, 0x71, 0x9e, 0x86, 0xb7, 0x18, 0x37, 0xff, 0x69, 0x6, 0xd7, 0x9c, 0xe9, 0x5d, 0x51, 0xef, 0xf5, 0x8d, 0x90, 0xa4, 0xb0, 0x7b")
MAKE_THUNK(libasound, snd_seq_port_info_get_name, "0x89, 0x4e, 0x3f, 0x93, 0x7e, 0x43, 0xa7, 0xef, 0x90, 0x52, 0x24, 0xf6, 0xf1, 0x66, 0x3f, 0x88, 0xdf, 0xd5, 0x1, 0x2d, 0x69, 0x5a, 0xf1, 0xf8, 0x46, 0xf7, 0x4e, 0xd9, 0xa0, 0x83, 0xe4, 0x9b")
MAKE_THUNK(libasound, snd_seq_port_info_get_capability, "0xa8, 0x30, 0x2f, 0xa8, 0xe4, 0xfb, 0x3a, 0x7f, 0x36, 0x62, 0xad, 0x4c, 0x4, 0xee, 0x5f, 0xcf, 0xd0, 0x92, 0xbd, 0x5e, 0x76, 0x25, 0xd, 0xc4, 0x8f, 0xf, 0x79, 0xef, 0x8c, 0xba, 0x54, 0x4a")
MAKE_THUNK(libasound, snd_seq_port_info_get_type, "0xb4, 0x72, 0xcf, 0x2e, 0xa9, 0xff, 0x80, 0xf8, 0xda, 0xca, 0xe5, 0x3d, 0xe6, 0xc1, 0x58, 0xc3, 0xbb, 0xc2, 0x84, 0xe8, 0x8a, 0x4f, 0x20, 0x7b, 0x13, 0xb3, 0xaa, 0xfd, 0x95, 0xea, 0x6e, 0x1")
MAKE_THUNK(libasound, snd_seq_port_info_get_midi_channels, "0x55, 0x74, 0xff, 0xc4, 0x1a, 0x30, 0x12, 0xac, 0x1b, 0x73, 0xef, 0x47, 0xce, 0x64, 0xca, 0xec, 0xf3, 0x42, 0x73, 0x46, 0x10, 0xdb, 0x1f, 0x85, 0xd6, 0xc8, 0xc7, 0xf, 0xc, 0xd0, 0x1e, 0x92")
MAKE_THUNK(libasound, snd_seq_port_info_get_midi_voices, "0x45, 0xca, 0x61, 0xeb, 0x99, 0xec, 0x50, 0x6a, 0x1f, 0xdd, 0xaf, 0x5b, 0xbf, 0x58, 0x43, 0x30, 0x2, 0xab, 0x10, 0x32, 0x1c, 0xe7, 0xca, 0xea, 0x24, 0x6, 0x1e, 0xfc, 0xe3, 0x49, 0xf3, 0x47")
MAKE_THUNK(libasound, snd_seq_port_info_get_synth_voices, "0x2b, 0x75, 0xb7, 0xdb, 0x82, 0x66, 0xaa, 0xea, 0xad, 0xdb, 0xa6, 0xb8, 0x24, 0x76, 0x22, 0x5d, 0xeb, 0xa2, 0x89, 0x6, 0x4c, 0x93, 0x99, 0x26, 0xa7, 0xb8, 0x97, 0x15, 0x43, 0x4, 0x87, 0x4c")
MAKE_THUNK(libasound, snd_seq_port_info_get_read_use, "0x51, 0x7a, 0xae, 0x90, 0xa2, 0xea, 0x0, 0x70, 0x95, 0x9d, 0xf5, 0xc9, 0x1, 0xab, 0x0, 0x36, 0x6b, 0xda, 0x5f, 0x79, 0xbf, 0x99, 0x1d, 0x55, 0xf, 0x44, 0x27, 0xe, 0xda, 0xe2, 0x60, 0xba")
MAKE_THUNK(libasound, snd_seq_port_info_get_write_use, "0x72, 0x59, 0xfa, 0x59, 0x23, 0x30, 0x32, 0xf, 0xc6, 0xc3, 0x3, 0x74, 0xfd, 0x86, 0x7e, 0x9e, 0x88, 0xbe, 0xa2, 0x7d, 0xbf, 0x5, 0x31, 0xed, 0x3a, 0x51, 0x8, 0x27, 0x7b, 0x99, 0xfc, 0xc5")
MAKE_THUNK(libasound, snd_seq_port_info_get_port_specified, "0x1c, 0x78, 0x2a, 0xbf, 0xbd, 0xe4, 0x87, 0x2, 0xd6, 0x9, 0x13, 0x1c, 0x29, 0x44, 0x73, 0x7f, 0x26, 0x40, 0x2a, 0x4e, 0x9e, 0x4e, 0xa2, 0x51, 0x3a, 0x7d, 0x3d, 0x64, 0x5f, 0x5b, 0x9c, 0xa3")
MAKE_THUNK(libasound, snd_seq_port_info_get_timestamping, "0x42, 0xe7, 0x1d, 0x40, 0x35, 0xa3, 0xc7, 0xd2, 0xe5, 0x52, 0xc3, 0x10, 0x29, 0xc7, 0x7d, 0x85, 0xd, 0x99, 0xcb, 0x9, 0x97, 0xf5, 0xeb, 0x7c, 0xb, 0xfb, 0xd0, 0x67, 0x27, 0xda, 0xff, 0x5e")
MAKE_THUNK(libasound, snd_seq_port_info_get_timestamp_real, "0x98, 0xc0, 0x1, 0xd9, 0x45, 0x4c, 0x8e, 0xf5, 0x5c, 0xfa, 0x20, 0x55, 0xf9, 0x91, 0xae, 0x3a, 0x61, 0x29, 0x84, 0x28, 0xe9, 0xea, 0x4c, 0x37, 0x2, 0x95, 0x1d, 0x94, 0xcd, 0x77, 0xd3, 0x1")
MAKE_THUNK(libasound, snd_seq_port_info_get_timestamp_queue, "0x91, 0x4, 0xa, 0x36, 0x65, 0xeb, 0x3b, 0xf6, 0x26, 0x45, 0x8f, 0xb9, 0xbd, 0x84, 0xab, 0x5f, 0xdd, 0x24, 0x22, 0x7b, 0x11, 0xb9, 0xa1, 0x22, 0x51, 0xbf, 0x1c, 0xc6, 0x29, 0xe4, 0x97, 0x59")
MAKE_THUNK(libasound, snd_seq_port_info_set_client, "0x6a, 0xaa, 0xe5, 0x59, 0xd3, 0x81, 0xc, 0xdb, 0xba, 0x91, 0x70, 0x7, 0x17, 0x7b, 0x68, 0xe0, 0xb1, 0x4e, 0xda, 0xcd, 0xa1, 0xa0, 0x6f, 0xcc, 0x57, 0x9d, 0x14, 0xe0, 0xcc, 0xbd, 0xad, 0x7f")
MAKE_THUNK(libasound, snd_seq_port_info_set_port, "0xcd, 0xda, 0x88, 0x76, 0x9, 0x63, 0x1c, 0x2b, 0xd4, 0x46, 0x2a, 0x9d, 0x4e, 0xad, 0x8f, 0x81, 0x25, 0x30, 0xe2, 0xb, 0xf3, 0x74, 0xed, 0x19, 0x7c, 0xa4, 0x6b, 0xa, 0x9, 0x46, 0xf1, 0x64")
MAKE_THUNK(libasound, snd_seq_port_info_set_addr, "0x68, 0x8f, 0x6f, 0xda, 0x13, 0xc7, 0xf7, 0x8f, 0x21, 0x64, 0x33, 0x28, 0x82, 0x9f, 0x37, 0x91, 0x37, 0x2e, 0xd7, 0x45, 0x3, 0xcf, 0x61, 0x8b, 0xab, 0xf, 0xa5, 0x18, 0x5a, 0xd8, 0x4d, 0x9a")
MAKE_THUNK(libasound, snd_seq_port_info_set_name, "0x17, 0xf4, 0xd2, 0x19, 0x5d, 0xa6, 0x59, 0xaa, 0xb2, 0xfc, 0x39, 0x53, 0xa6, 0x49, 0x87, 0x6d, 0xd8, 0x23, 0x32, 0xf4, 0x56, 0xc6, 0x63, 0x58, 0xb0, 0xd7, 0xbb, 0x0, 0x28, 0x6, 0xcf, 0xa0")
MAKE_THUNK(libasound, snd_seq_port_info_set_capability, "0xf2, 0x87, 0x26, 0x51, 0x38, 0xd8, 0xbd, 0xc0, 0xd5, 0x77, 0xfe, 0x85, 0xe8, 0x91, 0xe, 0x86, 0x15, 0xf8, 0x5f, 0x8b, 0xbe, 0x7c, 0x71, 0x43, 0xa3, 0x9d, 0xba, 0xf4, 0x65, 0xc0, 0xe, 0x21")
MAKE_THUNK(libasound, snd_seq_port_info_set_type, "0x90, 0xcd, 0x54, 0x31, 0xd5, 0xc2, 0x23, 0xb2, 0x8e, 0x9b, 0xc9, 0x1e, 0x47, 0xba, 0x1d, 0xfc, 0x65, 0x75, 0x50, 0x7, 0x2d, 0x42, 0xb1, 0x9e, 0x9b, 0x16, 0x2d, 0x75, 0x2d, 0xf4, 0xf5, 0xab")
MAKE_THUNK(libasound, snd_seq_port_info_set_midi_channels, "0x3b, 0x4d, 0x75, 0xcc, 0x72, 0x6, 0x1b, 0xb7, 0xcf, 0x58, 0x41, 0x1d, 0xfa, 0x24, 0x6a, 0x57, 0x56, 0xb6, 0x61, 0xce, 0x1e, 0x36, 0x0, 0xb1, 0xc1, 0x61, 0xc1, 0x10, 0xe5, 0xa6, 0xeb, 0xb4")
MAKE_THUNK(libasound, snd_seq_port_info_set_midi_voices, "0x83, 0x39, 0xd4, 0x82, 0xae, 0x75, 0x80, 0xd6, 0x3f, 0x46, 0x97, 0x61, 0xd7, 0xdf, 0xc3, 0x5d, 0x99, 0x72, 0x8b, 0x53, 0xeb, 0x4f, 0x3f, 0x49, 0x24, 0xc9, 0x31, 0xe9, 0xb6, 0x91, 0x42, 0xe0")
MAKE_THUNK(libasound, snd_seq_port_info_set_synth_voices, "0x4, 0x4f, 0x6e, 0xcc, 0x1f, 0xc6, 0x86, 0x93, 0x3b, 0xd3, 0x4a, 0xc, 0x92, 0x34, 0x56, 0xe4, 0x8, 0xdc, 0xa6, 0xb4, 0xbe, 0xba, 0xe5, 0x25, 0x21, 0xe, 0x97, 0x3a, 0x19, 0x6a, 0xfc, 0xd8")
MAKE_THUNK(libasound, snd_seq_port_info_set_port_specified, "0xba, 0x30, 0xc9, 0xeb, 0x39, 0x45, 0xe4, 0x61, 0xa7, 0x19, 0xe2, 0xa5, 0x44, 0x88, 0x50, 0xd6, 0x87, 0xc2, 0x68, 0xf, 0x39, 0xe6, 0x46, 0xf3, 0xe5, 0x90, 0x8a, 0xd0, 0x38, 0xe0, 0x55, 0x58")
MAKE_THUNK(libasound, snd_seq_port_info_set_timestamping, "0x1f, 0xa7, 0x83, 0x1c, 0xc0, 0x5e, 0x4, 0xba, 0xfc, 0x79, 0x2c, 0x21, 0x5e, 0x66, 0xd2, 0x9e, 0xb2, 0x57, 0xf6, 0x97, 0x68, 0x5f, 0x13, 0x87, 0x6b, 0xe7, 0x3e, 0x60, 0x47, 0xb3, 0xad, 0xcf")
MAKE_THUNK(libasound, snd_seq_port_info_set_timestamp_real, "0x45, 0x43, 0x67, 0xef, 0x47, 0x25, 0xfb, 0xcb, 0x87, 0x80, 0x86, 0xdb, 0xe, 0xc9, 0x38, 0x20, 0x5e, 0xa0, 0x49, 0xb, 0x6a, 0x29, 0xd, 0x38, 0xe, 0x9f, 0x93, 0xd2, 0x9f, 0x37, 0xd, 0x5a")
MAKE_THUNK(libasound, snd_seq_port_info_set_timestamp_queue, "0xa7, 0x44, 0xa9, 0x76, 0xd9, 0x91, 0x3d, 0xb1, 0x77, 0x38, 0xcb, 0xef, 0x40, 0x72, 0x6e, 0x64, 0xe4, 0x25, 0x55, 0xd3, 0x4, 0x6b, 0xa4, 0xda, 0x6c, 0xeb, 0x31, 0x95, 0x29, 0x35, 0xb5, 0x7a")
MAKE_THUNK(libasound, snd_seq_create_port, "0x12, 0x6e, 0x8e, 0x65, 0x9a, 0x9a, 0xe6, 0x2d, 0xbd, 0xf4, 0x4a, 0x14, 0xb, 0x9e, 0xa5, 0xa, 0x4e, 0x91, 0x8d, 0x1, 0xa7, 0x2d, 0x2e, 0x8e, 0xe1, 0x61, 0xf2, 0xbc, 0xda, 0xe0, 0xd0, 0x8b")
MAKE_THUNK(libasound, snd_seq_delete_port, "0x38, 0x16, 0xc7, 0x3b, 0xd5, 0xa7, 0xf7, 0x2c, 0x89, 0xe9, 0x47, 0x97, 0xe, 0x35, 0xd8, 0x27, 0x7b, 0xda, 0xbb, 0x22, 0xbe, 0x93, 0x83, 0x1, 0x5b, 0xc4, 0xb2, 0xdb, 0x13, 0x31, 0x54, 0xe3")
MAKE_THUNK(libasound, snd_seq_get_port_info, "0xab, 0x68, 0x8, 0x4d, 0x92, 0x5f, 0xdc, 0x3a, 0x99, 0x47, 0x9a, 0x44, 0xe1, 0x5b, 0x95, 0x94, 0xbd, 0x73, 0x8, 0xbb, 0x9a, 0xf5, 0xf4, 0x50, 0xd3, 0x6, 0xad, 0x23, 0xd2, 0xa9, 0x8c, 0x63")
MAKE_THUNK(libasound, snd_seq_get_any_port_info, "0x40, 0x0, 0x1d, 0xf, 0x73, 0x46, 0x2d, 0xc1, 0xba, 0xd5, 0x5c, 0x3e, 0xb3, 0x58, 0x98, 0xb5, 0xb, 0xfa, 0x3a, 0x19, 0x5e, 0xe9, 0xda, 0x88, 0xe2, 0x62, 0x7, 0xad, 0xce, 0x28, 0xc9, 0x1f")
MAKE_THUNK(libasound, snd_seq_set_port_info, "0x31, 0x27, 0xf, 0x7e, 0xc2, 0xee, 0xbc, 0x76, 0xce, 0x21, 0xa3, 0x1e, 0x72, 0x74, 0x55, 0x80, 0xe5, 0x2b, 0xba, 0x7, 0x13, 0x83, 0x93, 0x20, 0x16, 0xf1, 0x88, 0xca, 0x6d, 0x6f, 0x71, 0x12")
MAKE_THUNK(libasound, snd_seq_query_next_port, "0x8d, 0xb5, 0x17, 0x84, 0x9f, 0x19, 0x2b, 0x60, 0xcc, 0xcb, 0xac, 0x1d, 0x15, 0xc, 0xf6, 0x8b, 0xd9, 0x21, 0xd5, 0x76, 0x6b, 0xbe, 0xb6, 0x1d, 0x78, 0x80, 0xf9, 0x7f, 0xd, 0x6f, 0xab, 0xf9")
MAKE_THUNK(libasound, snd_seq_port_subscribe_sizeof, "0xa8, 0xac, 0x6a, 0xb2, 0x4c, 0x6a, 0x67, 0xc7, 0x22, 0x14, 0xa5, 0xf9, 0x57, 0xf6, 0x99, 0xd9, 0x96, 0xff, 0x5, 0x6c, 0xc5, 0x86, 0x72, 0x7, 0xf9, 0xc9, 0x39, 0x4f, 0xd5, 0x25, 0xe4, 0x49")
MAKE_THUNK(libasound, snd_seq_port_subscribe_malloc, "0x56, 0x41, 0x60, 0xea, 0x51, 0xde, 0xd8, 0x48, 0x5c, 0x25, 0x73, 0x5e, 0xf4, 0x4, 0xa2, 0x6c, 0xff, 0x2f, 0x32, 0xca, 0xc1, 0x5d, 0x6, 0x92, 0x51, 0xea, 0x2a, 0xfa, 0x7e, 0xf6, 0xdf, 0x1f")
MAKE_THUNK(libasound, snd_seq_port_subscribe_free, "0xc9, 0x9e, 0x98, 0xb2, 0x8f, 0xc5, 0x35, 0x3b, 0xc4, 0xf, 0xfe, 0x97, 0xca, 0xd3, 0x87, 0x2b, 0x1f, 0x17, 0xd1, 0xc0, 0xa9, 0xd4, 0x29, 0xa4, 0x20, 0x9a, 0x6d, 0xe1, 0xe2, 0x89, 0x99, 0xf5")
MAKE_THUNK(libasound, snd_seq_port_subscribe_copy, "0x5e, 0xd9, 0xff, 0x86, 0x7f, 0xd7, 0x51, 0x8a, 0x51, 0xa4, 0x1b, 0x8b, 0x60, 0xf3, 0x8f, 0x71, 0x2b, 0x6f, 0x65, 0x67, 0x1, 0xdc, 0x54, 0x16, 0xc, 0x17, 0x36, 0xb5, 0x4, 0x1a, 0xbd, 0x4e")
MAKE_THUNK(libasound, snd_seq_port_subscribe_get_sender, "0x57, 0xdc, 0x70, 0xb1, 0xb2, 0xe5, 0x39, 0x7f, 0xc3, 0xeb, 0x2c, 0x5d, 0x76, 0xff, 0xe2, 0x1c, 0x84, 0x8c, 0x7, 0x8f, 0xeb, 0xc4, 0x59, 0x6, 0x3c, 0x98, 0xad, 0xcc, 0xcb, 0x38, 0xa2, 0x97")
MAKE_THUNK(libasound, snd_seq_port_subscribe_get_dest, "0x96, 0xe3, 0xdc, 0x30, 0xd8, 0x99, 0xa8, 0x74, 0x7f, 0x43, 0x4b, 0x1e, 0x1c, 0xc0, 0xf7, 0xd4, 0x85, 0xeb, 0x81, 0x7c, 0xcb, 0xdc, 0x53, 0x64, 0xe, 0x5f, 0x57, 0x56, 0x1b, 0x29, 0xb9, 0x38")
MAKE_THUNK(libasound, snd_seq_port_subscribe_get_queue, "0x27, 0xcd, 0x6f, 0x45, 0xd9, 0x85, 0xe4, 0x29, 0x4e, 0xb2, 0xcd, 0x78, 0xc2, 0x7d, 0xf0, 0x6d, 0xaf, 0x13, 0xda, 0x9, 0x86, 0xf8, 0xb7, 0x6c, 0x26, 0x9c, 0x79, 0x7e, 0x63, 0xb8, 0x94, 0x21")
MAKE_THUNK(libasound, snd_seq_port_subscribe_get_exclusive, "0x40, 0x3c, 0x2b, 0x74, 0x23, 0xb3, 0xf6, 0xac, 0xf3, 0x37, 0xe3, 0x2, 0xf7, 0x91, 0x72, 0xd, 0xe4, 0x36, 0x39, 0x9c, 0x9, 0x20, 0x56, 0x11, 0x77, 0x64, 0xf3, 0x38, 0x13, 0x59, 0xf0, 0x2a")
MAKE_THUNK(libasound, snd_seq_port_subscribe_get_time_update, "0x89, 0x30, 0x47, 0xea, 0x7c, 0xd4, 0xd9, 0xaa, 0x2f, 0x42, 0x7a, 0xa5, 0x56, 0x21, 0xf6, 0xec, 0x8a, 0xe3, 0x92, 0xe9, 0xfa, 0xe4, 0x7b, 0xca, 0x56, 0xd6, 0x59, 0x72, 0xf5, 0x38, 0x33, 0xf1")
MAKE_THUNK(libasound, snd_seq_port_subscribe_get_time_real, "0xbc, 0xd7, 0x6b, 0xfa, 0xbb, 0xd0, 0x7d, 0x1e, 0xb9, 0xef, 0xe0, 0x21, 0xa6, 0xcd, 0xdc, 0x7, 0x99, 0x3c, 0x96, 0x9c, 0x51, 0x5a, 0x11, 0x1f, 0x7a, 0x23, 0x30, 0x76, 0xe1, 0xe5, 0x70, 0x5")
MAKE_THUNK(libasound, snd_seq_port_subscribe_set_sender, "0x43, 0x43, 0xa0, 0xe6, 0xb, 0x89, 0xbb, 0x78, 0x55, 0x1, 0x77, 0xc3, 0x51, 0x50, 0xdd, 0x2, 0x54, 0x4, 0xe6, 0x4, 0x57, 0x93, 0xf9, 0xd7, 0x3, 0xd2, 0xa1, 0xd2, 0xe4, 0x93, 0xd, 0x0")
MAKE_THUNK(libasound, snd_seq_port_subscribe_set_dest, "0xe6, 0x21, 0x9f, 0xb, 0xd9, 0x2e, 0x2d, 0x85, 0xfd, 0xab, 0xce, 0xa8, 0xc, 0x77, 0x74, 0x50, 0xc4, 0x7d, 0x4c, 0x8, 0x1e, 0x91, 0x46, 0x9b, 0xf1, 0x1e, 0x89, 0x54, 0xb7, 0x49, 0xe6, 0xcf")
MAKE_THUNK(libasound, snd_seq_port_subscribe_set_queue, "0xaf, 0x55, 0x81, 0x59, 0x92, 0xe5, 0x48, 0xf9, 0x4d, 0x61, 0xa7, 0x1, 0xe7, 0xe4, 0x24, 0x85, 0x8, 0x0, 0x12, 0x81, 0xdb, 0xf, 0x86, 0x7a, 0xae, 0xdf, 0x70, 0x65, 0x9f, 0x10, 0xda, 0xb4")
MAKE_THUNK(libasound, snd_seq_port_subscribe_set_exclusive, "0x7, 0x98, 0xb3, 0x3f, 0x5e, 0x14, 0xf1, 0xd2, 0x4a, 0xec, 0x34, 0xe2, 0x4c, 0xce, 0x3c, 0x6f, 0x3f, 0xb3, 0x0, 0xf2, 0x37, 0x8, 0x6a, 0x5a, 0x56, 0x97, 0xc6, 0x46, 0x2, 0x9f, 0x9b, 0x17")
MAKE_THUNK(libasound, snd_seq_port_subscribe_set_time_update, "0xc, 0x27, 0x64, 0xbd, 0x91, 0x53, 0x60, 0xe8, 0x62, 0x8, 0x20, 0x50, 0x3c, 0xe7, 0x90, 0xb4, 0xb5, 0xa0, 0xa1, 0x74, 0x86, 0xb0, 0x96, 0xef, 0x26, 0xe8, 0xc2, 0x60, 0x4e, 0xc4, 0x7f, 0x92")
MAKE_THUNK(libasound, snd_seq_port_subscribe_set_time_real, "0x3d, 0xa, 0xa6, 0x3, 0xff, 0x93, 0x68, 0xd1, 0xf8, 0x96, 0xf5, 0x41, 0x73, 0x23, 0x39, 0xd0, 0x3f, 0xed, 0x5d, 0x8a, 0xa9, 0xd5, 0xe, 0x2, 0x83, 0xff, 0x12, 0x87, 0xb6, 0x55, 0x54, 0xd2")
MAKE_THUNK(libasound, snd_seq_get_port_subscription, "0x56, 0xca, 0x24, 0x2f, 0xf0, 0x4b, 0x55, 0x19, 0x1, 0x6c, 0x82, 0x81, 0x36, 0x34, 0x7f, 0x6b, 0x80, 0xd3, 0xfb, 0x28, 0x27, 0x48, 0xa1, 0x67, 0xb1, 0x51, 0x61, 0x77, 0xef, 0xd2, 0x4d, 0xa6")
MAKE_THUNK(libasound, snd_seq_subscribe_port, "0xb2, 0x78, 0xf8, 0x9b, 0x6, 0x1a, 0x93, 0x93, 0x31, 0x8, 0x6c, 0x49, 0x2d, 0xef, 0x85, 0xc5, 0xa0, 0x4, 0xa9, 0x7e, 0x79, 0xec, 0xa9, 0xde, 0x23, 0x31, 0x5, 0x16, 0x6b, 0xbf, 0x25, 0xc")
MAKE_THUNK(libasound, snd_seq_unsubscribe_port, "0x62, 0xc8, 0x60, 0x6a, 0xaf, 0x25, 0xb, 0x8a, 0xff, 0xcf, 0xc8, 0x7a, 0x4d, 0x4e, 0x6e, 0x9b, 0x60, 0xb2, 0x12, 0xbf, 0x34, 0x3e, 0xf4, 0x7c, 0xb1, 0x47, 0x83, 0x30, 0x7e, 0x10, 0x99, 0xd3")
MAKE_THUNK(libasound, snd_seq_query_subscribe_sizeof, "0x15, 0x3f, 0xb6, 0x9c, 0x35, 0x51, 0x8a, 0xdb, 0x38, 0xdd, 0xb9, 0x7b, 0x10, 0x6e, 0xc8, 0x28, 0x86, 0x5d, 0x41, 0x0, 0xb8, 0x13, 0xf8, 0xa6, 0x82, 0xa0, 0xc1, 0x1b, 0xb4, 0x6f, 0xc2, 0xba")
MAKE_THUNK(libasound, snd_seq_query_subscribe_malloc, "0x83, 0x1e, 0x69, 0x20, 0xe7, 0xdd, 0x58, 0x33, 0xc2, 0x49, 0x86, 0xfd, 0xa9, 0xce, 0x6f, 0xa0, 0x94, 0x7, 0x5c, 0x2a, 0x9f, 0x7a, 0x60, 0x82, 0xd6, 0xa, 0xa0, 0xd5, 0xbf, 0x83, 0xeb, 0x5f")
MAKE_THUNK(libasound, snd_seq_query_subscribe_free, "0x4d, 0x5f, 0x3b, 0xae, 0x94, 0x7a, 0xde, 0x55, 0xf9, 0x2c, 0xda, 0xe6, 0xc0, 0xba, 0x9f, 0xf6, 0xbc, 0x1b, 0xae, 0x59, 0xa, 0x22, 0x90, 0x6e, 0xf2, 0x61, 0x8f, 0x57, 0x9d, 0xf1, 0x52, 0x30")
MAKE_THUNK(libasound, snd_seq_query_subscribe_copy, "0x25, 0xf, 0x59, 0x8c, 0x39, 0xff, 0x53, 0x29, 0x62, 0xd5, 0x60, 0x43, 0xb4, 0x18, 0x78, 0xf0, 0xfd, 0x44, 0x2c, 0x42, 0x79, 0x6f, 0x5f, 0xe6, 0xf2, 0x82, 0x6b, 0x39, 0xc, 0x20, 0xad, 0x43")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_client, "0xc3, 0x16, 0x8c, 0x63, 0xcb, 0xd8, 0x33, 0x51, 0x42, 0x83, 0xf6, 0x5d, 0xdb, 0x4c, 0xef, 0xf1, 0xd8, 0x49, 0xae, 0xb, 0xbc, 0xb4, 0xb0, 0x7a, 0xe4, 0x5c, 0x7b, 0x41, 0xc0, 0xf9, 0xcc, 0x5f")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_port, "0xdd, 0x9e, 0x39, 0x57, 0x78, 0x9b, 0x7c, 0xbb, 0x1f, 0xab, 0xca, 0x73, 0x19, 0x10, 0xab, 0x8b, 0xe6, 0xf4, 0xc0, 0x73, 0x8c, 0xe4, 0xdb, 0x27, 0x85, 0x1e, 0xb5, 0x6, 0x6d, 0x22, 0xe2, 0x2d")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_root, "0xd5, 0xcf, 0x92, 0x1f, 0x7e, 0xad, 0xa6, 0xd7, 0x55, 0x56, 0xea, 0xcd, 0xc0, 0x4, 0x6a, 0xc2, 0xb5, 0x49, 0xc9, 0x4c, 0x68, 0xa8, 0xdf, 0xdd, 0x2f, 0xda, 0x3d, 0x13, 0xcc, 0x58, 0xc1, 0x15")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_type, "0x4d, 0x16, 0x5d, 0xe8, 0x37, 0xaa, 0x7, 0xfe, 0x9d, 0xc4, 0xa0, 0xb3, 0xb8, 0x9, 0x7f, 0xdd, 0x84, 0xd8, 0x45, 0x4b, 0x57, 0x67, 0xaa, 0x84, 0xd3, 0x4c, 0xa5, 0xdc, 0x13, 0x4e, 0x8e, 0x11")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_index, "0x19, 0xbc, 0x9a, 0xad, 0x73, 0x9a, 0x5b, 0x2f, 0x4, 0xb9, 0xe7, 0xe1, 0x52, 0x36, 0x41, 0x14, 0x7e, 0xd0, 0xd3, 0xfd, 0x1e, 0xd4, 0xc7, 0xe4, 0x8d, 0x4e, 0x28, 0x75, 0x8b, 0x14, 0x78, 0xd3")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_num_subs, "0xa8, 0x67, 0xab, 0xda, 0x49, 0xa4, 0xcf, 0x5a, 0x85, 0xcf, 0xaf, 0x7b, 0xbf, 0x28, 0x44, 0x84, 0x8a, 0x42, 0x2e, 0x17, 0x5a, 0xab, 0x51, 0x75, 0x62, 0x68, 0xd1, 0x92, 0x37, 0x3b, 0xc8, 0x5f")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_addr, "0x7, 0xb5, 0x6c, 0x31, 0x7b, 0x45, 0x26, 0x1, 0x46, 0xce, 0xd1, 0xa3, 0xab, 0xaf, 0x18, 0x17, 0x50, 0x52, 0x1c, 0xf8, 0x4, 0x33, 0xc4, 0x9a, 0xe6, 0x8d, 0x32, 0x3e, 0x7a, 0xec, 0x3a, 0x8f")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_queue, "0x7c, 0xcb, 0x21, 0xe3, 0x19, 0x55, 0x3c, 0x73, 0x2d, 0x4e, 0xfb, 0x43, 0x59, 0x45, 0x7d, 0x91, 0x1b, 0x87, 0x32, 0xde, 0xc, 0xa4, 0xa, 0x3, 0x3a, 0xf4, 0x45, 0x97, 0xc1, 0xfa, 0x7e, 0xca")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_exclusive, "0x0, 0xd1, 0x97, 0x1b, 0xe5, 0x35, 0xc7, 0xbc, 0x33, 0x21, 0x7a, 0xca, 0x86, 0xcb, 0x96, 0x1f, 0xc, 0xf7, 0x27, 0x5d, 0xc5, 0x2a, 0x47, 0x6f, 0x13, 0xfa, 0x61, 0x45, 0xa3, 0x97, 0x4e, 0xe2")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_time_update, "0x5c, 0xb8, 0xa0, 0x40, 0x3a, 0xc7, 0xbd, 0x75, 0x80, 0x72, 0x84, 0x1a, 0x48, 0x32, 0xb8, 0x36, 0x27, 0x66, 0xd, 0x7e, 0x3c, 0x13, 0x7b, 0x9f, 0xea, 0x75, 0xc9, 0x90, 0xc4, 0x90, 0x8f, 0xe4")
MAKE_THUNK(libasound, snd_seq_query_subscribe_get_time_real, "0xd, 0x6, 0x30, 0xbe, 0x1, 0xef, 0xbf, 0x18, 0x51, 0x4c, 0xde, 0x2b, 0x5c, 0x10, 0x41, 0x87, 0x45, 0xe2, 0x5d, 0x8e, 0x41, 0xe0, 0x6f, 0x7e, 0x7e, 0xb6, 0x91, 0xb4, 0x8b, 0xe2, 0x2d, 0x6")
MAKE_THUNK(libasound, snd_seq_query_subscribe_set_client, "0xe, 0xc9, 0x4a, 0xbe, 0x78, 0xc7, 0x88, 0x97, 0xea, 0x7b, 0xee, 0x29, 0x31, 0xdc, 0x3, 0xdd, 0x4f, 0x35, 0xfb, 0xc7, 0x95, 0xb6, 0xef, 0xe8, 0xf0, 0xbc, 0xf7, 0x16, 0xed, 0xaa, 0xf2, 0xc2")
MAKE_THUNK(libasound, snd_seq_query_subscribe_set_port, "0x81, 0xc4, 0x6c, 0xef, 0xcd, 0x1c, 0xce, 0x35, 0x48, 0x70, 0xc5, 0x1c, 0xaa, 0xad, 0xc9, 0x94, 0x75, 0xe7, 0xc6, 0x9a, 0xb3, 0x93, 0xc4, 0x79, 0xb8, 0xd0, 0x35, 0xdb, 0x43, 0xf8, 0xe6, 0xb9")
MAKE_THUNK(libasound, snd_seq_query_subscribe_set_root, "0x44, 0x2a, 0xcf, 0xc8, 0x54, 0x2e, 0x36, 0x3e, 0xe2, 0x35, 0xb9, 0x7e, 0xef, 0x8a, 0x16, 0xfe, 0xfa, 0xd8, 0x1c, 0x9a, 0x1d, 0xc4, 0x97, 0x6c, 0x7d, 0x25, 0x7e, 0x8f, 0x8c, 0xe5, 0xc0, 0x91")
MAKE_THUNK(libasound, snd_seq_query_subscribe_set_type, "0x50, 0x8d, 0x3a, 0x41, 0x9c, 0x4d, 0x53, 0xf9, 0x6e, 0x7, 0xd3, 0xd1, 0x6, 0x57, 0x41, 0xa4, 0x34, 0xd1, 0x6a, 0x13, 0x14, 0xb9, 0x11, 0xec, 0x65, 0xe1, 0x85, 0x89, 0xef, 0x52, 0x26, 0xc1")
MAKE_THUNK(libasound, snd_seq_query_subscribe_set_index, "0x98, 0x55, 0xdc, 0xc1, 0x79, 0x7b, 0x9e, 0xe3, 0x93, 0xc1, 0x3e, 0xcf, 0x4, 0x69, 0x13, 0x6f, 0x72, 0x57, 0x6d, 0xb2, 0x8, 0x5d, 0x81, 0x2, 0xbd, 0xec, 0x3d, 0x92, 0xdc, 0x7d, 0xf6, 0x8c")
MAKE_THUNK(libasound, snd_seq_query_port_subscribers, "0x32, 0x84, 0xa6, 0xd0, 0x56, 0xb7, 0xb6, 0x87, 0x66, 0xb4, 0x24, 0x55, 0x9e, 0xcb, 0x2a, 0xb3, 0x58, 0xf5, 0xcf, 0xb8, 0x8a, 0xf, 0x9d, 0x77, 0x6d, 0xfd, 0xce, 0xc6, 0xb5, 0x99, 0xe6, 0x6a")
MAKE_THUNK(libasound, snd_seq_queue_info_sizeof, "0x39, 0x3, 0xcb, 0xfc, 0xe8, 0x43, 0xcb, 0x8a, 0xb, 0xed, 0xf, 0x33, 0xd5, 0xa, 0xcf, 0x8b, 0xfe, 0xb3, 0x5f, 0xbc, 0xb3, 0x3f, 0x20, 0x5a, 0x9, 0x35, 0x12, 0xce, 0x62, 0xa7, 0x7c, 0xe3")
MAKE_THUNK(libasound, snd_seq_queue_info_malloc, "0xd, 0x28, 0xa9, 0xb5, 0x77, 0x7b, 0xa1, 0x69, 0x8f, 0xb2, 0x1d, 0xba, 0xae, 0xaf, 0xad, 0x4a, 0x69, 0xc4, 0x78, 0xa9, 0x66, 0x13, 0xad, 0x28, 0x2a, 0x30, 0x71, 0xd7, 0x87, 0x98, 0x59, 0xe2")
MAKE_THUNK(libasound, snd_seq_queue_info_free, "0x28, 0x76, 0x88, 0x16, 0xc0, 0xca, 0x23, 0x67, 0x3e, 0xec, 0x14, 0x2a, 0x40, 0x12, 0xde, 0xee, 0x23, 0xda, 0x4c, 0xc3, 0x98, 0xf0, 0x4b, 0xaf, 0x64, 0x73, 0x96, 0xf6, 0xfd, 0xc0, 0xdd, 0x9d")
MAKE_THUNK(libasound, snd_seq_queue_info_copy, "0x4c, 0x81, 0xd9, 0x69, 0xc2, 0x49, 0x2a, 0xaf, 0xf3, 0x1f, 0x44, 0x17, 0x41, 0xba, 0x73, 0xbe, 0xd2, 0xd2, 0xb7, 0x14, 0x39, 0x44, 0x9, 0xb4, 0x88, 0x14, 0xc9, 0x42, 0x2d, 0xbe, 0xd9, 0xed")
MAKE_THUNK(libasound, snd_seq_queue_info_get_queue, "0xd6, 0x94, 0x51, 0x21, 0xb, 0x8d, 0xdf, 0xd6, 0xee, 0x9, 0xcd, 0xa1, 0x24, 0xc8, 0x4, 0x27, 0x1b, 0x37, 0x8a, 0xb2, 0xa7, 0x3, 0x2b, 0xf7, 0xfb, 0xe8, 0xd5, 0xdb, 0xa8, 0xc, 0x8e, 0x23")
MAKE_THUNK(libasound, snd_seq_queue_info_get_name, "0x6f, 0x3b, 0x7b, 0xf8, 0x58, 0x49, 0x92, 0xe7, 0xfe, 0x54, 0x7d, 0x9c, 0xe3, 0xe4, 0x1, 0x2a, 0xbf, 0x84, 0x7a, 0x13, 0x1, 0x81, 0xd8, 0x1d, 0xca, 0x22, 0xaa, 0x55, 0xa, 0xff, 0xa2, 0xa8")
MAKE_THUNK(libasound, snd_seq_queue_info_get_owner, "0x70, 0x61, 0x98, 0xfd, 0xc4, 0x64, 0xa2, 0x9e, 0xb4, 0xf5, 0x49, 0x1c, 0x9c, 0x47, 0x3a, 0xc8, 0x8a, 0x18, 0x9d, 0xc8, 0xeb, 0x93, 0xa1, 0xeb, 0x96, 0x37, 0x35, 0x32, 0xe0, 0x24, 0x97, 0x38")
MAKE_THUNK(libasound, snd_seq_queue_info_get_locked, "0x65, 0xbc, 0xa3, 0x22, 0xe2, 0xdc, 0xab, 0x99, 0x9e, 0x5b, 0x4d, 0x92, 0x5d, 0xba, 0x55, 0xee, 0x92, 0x17, 0xf1, 0x44, 0xf0, 0x3c, 0xe7, 0xba, 0x7c, 0x73, 0xdb, 0x7f, 0xd0, 0x2, 0x77, 0x57")
MAKE_THUNK(libasound, snd_seq_queue_info_get_flags, "0x31, 0x2d, 0x55, 0xb1, 0xe4, 0xd, 0xb6, 0x46, 0x68, 0x3e, 0x61, 0xc9, 0x91, 0x12, 0x5f, 0xf2, 0x7c, 0xb5, 0x97, 0x6d, 0x3a, 0xb3, 0xe1, 0x5f, 0x11, 0x9e, 0x51, 0x8a, 0xb5, 0xd9, 0x52, 0x5f")
MAKE_THUNK(libasound, snd_seq_queue_info_set_name, "0x5d, 0xc, 0xbb, 0xd9, 0x48, 0x55, 0xe7, 0x8e, 0x36, 0xf9, 0x7d, 0x61, 0x64, 0xfc, 0x47, 0xb6, 0x49, 0x89, 0xf1, 0xbd, 0x29, 0x19, 0x16, 0x11, 0xc6, 0x2, 0x12, 0xa, 0xc9, 0xd7, 0x72, 0x4d")
MAKE_THUNK(libasound, snd_seq_queue_info_set_owner, "0xf0, 0x1c, 0xc1, 0x80, 0x4f, 0xcc, 0x68, 0x33, 0x95, 0x11, 0xec, 0xa8, 0x39, 0x13, 0xfd, 0x24, 0xfd, 0xf, 0x99, 0x5a, 0xbc, 0xa3, 0x27, 0xac, 0xe9, 0xc2, 0xed, 0x19, 0x34, 0xc2, 0x88, 0x76")
MAKE_THUNK(libasound, snd_seq_queue_info_set_locked, "0x62, 0xfb, 0x91, 0x43, 0x43, 0xf1, 0x59, 0xb1, 0xe8, 0xe9, 0xd, 0x92, 0xe5, 0x5b, 0x6d, 0x97, 0xf7, 0x2a, 0xe1, 0x70, 0x77, 0x4d, 0x15, 0x2, 0xf8, 0x77, 0x62, 0x6a, 0x2a, 0x83, 0x65, 0x37")
MAKE_THUNK(libasound, snd_seq_queue_info_set_flags, "0x78, 0xd8, 0x44, 0xcd, 0x62, 0x72, 0x7f, 0xd3, 0xbc, 0x23, 0xd2, 0x2a, 0x7e, 0xca, 0x2e, 0x93, 0x97, 0x63, 0x65, 0x11, 0xea, 0xdc, 0x6b, 0xd6, 0x81, 0x58, 0x27, 0x12, 0x69, 0xda, 0x92, 0xa4")
MAKE_THUNK(libasound, snd_seq_create_queue, "0x32, 0x6e, 0xa, 0x73, 0xaf, 0x59, 0x7d, 0x33, 0xcd, 0xfe, 0xfa, 0x40, 0xaf, 0xb0, 0x24, 0xa0, 0x21, 0x9e, 0xce, 0x4c, 0x83, 0xf3, 0x5c, 0x9, 0xf5, 0xea, 0x2c, 0x3d, 0xdf, 0x5, 0xce, 0xb8")
MAKE_THUNK(libasound, snd_seq_alloc_named_queue, "0x4d, 0x2, 0x3f, 0x66, 0x19, 0x84, 0x45, 0xd4, 0x6f, 0xed, 0x3, 0x4a, 0x7d, 0xf8, 0xa6, 0xde, 0xad, 0x41, 0x16, 0x34, 0x14, 0xa9, 0x5d, 0xa5, 0xaa, 0x81, 0x1f, 0x93, 0xb6, 0x4b, 0x6e, 0x89")
MAKE_THUNK(libasound, snd_seq_alloc_queue, "0x28, 0xcc, 0xae, 0xf6, 0x4e, 0xd3, 0xe3, 0xe1, 0x6c, 0x66, 0xe2, 0x77, 0x60, 0x4e, 0x33, 0xb1, 0x16, 0xb0, 0x22, 0x94, 0x2e, 0xdb, 0x38, 0x69, 0x78, 0x5d, 0x3d, 0x70, 0x95, 0x5a, 0x3e, 0xa8")
MAKE_THUNK(libasound, snd_seq_free_queue, "0xc6, 0x57, 0xcd, 0x19, 0xf1, 0xd4, 0x69, 0x47, 0x81, 0x98, 0x8c, 0x8e, 0xe3, 0xbe, 0x1e, 0xa6, 0xbe, 0xaf, 0xb8, 0x5e, 0xf2, 0xf8, 0xb9, 0x47, 0x23, 0xa7, 0x26, 0xd1, 0xa1, 0x93, 0x94, 0xa0")
MAKE_THUNK(libasound, snd_seq_get_queue_info, "0xfc, 0x9d, 0xe5, 0x3e, 0x7a, 0x7a, 0x65, 0xa7, 0x7, 0x56, 0xcc, 0xcf, 0xe7, 0x43, 0x62, 0x82, 0x70, 0x45, 0x3c, 0x58, 0xf6, 0xb4, 0xa, 0x6a, 0x85, 0x36, 0x92, 0x19, 0xac, 0x4, 0x8, 0xa1")
MAKE_THUNK(libasound, snd_seq_set_queue_info, "0x73, 0xf4, 0xa0, 0x82, 0x1a, 0xcc, 0xa0, 0x99, 0xab, 0x1b, 0x95, 0x12, 0x30, 0x20, 0x5c, 0x2a, 0xe5, 0x8, 0x13, 0x75, 0xe7, 0xc2, 0x67, 0x40, 0x48, 0x9d, 0xe5, 0x15, 0x6, 0xed, 0xfd, 0xe3")
MAKE_THUNK(libasound, snd_seq_query_named_queue, "0xbf, 0x4c, 0x61, 0x85, 0x55, 0x95, 0xe8, 0x1d, 0x76, 0x86, 0x46, 0xdf, 0xb7, 0x2b, 0xaf, 0x50, 0xc6, 0x53, 0xd1, 0xa3, 0x23, 0x47, 0xb2, 0x2f, 0xe7, 0x5c, 0xe8, 0x90, 0x3e, 0xb5, 0x90, 0x2")
MAKE_THUNK(libasound, snd_seq_get_queue_usage, "0x4e, 0xf0, 0xb4, 0xba, 0xae, 0xd8, 0x10, 0x49, 0xba, 0x0, 0xf3, 0xf8, 0xa8, 0x3a, 0xaf, 0x3d, 0xfe, 0x22, 0x75, 0x4f, 0xa3, 0x2b, 0xb6, 0xce, 0xc4, 0xde, 0x9a, 0x39, 0xe7, 0x2a, 0xe6, 0x76")
MAKE_THUNK(libasound, snd_seq_set_queue_usage, "0xe3, 0xec, 0x1b, 0xcb, 0xe4, 0x22, 0x5b, 0xfd, 0x6f, 0xbe, 0x9a, 0xe0, 0xc, 0xf3, 0xcc, 0x9d, 0x6f, 0xd, 0x14, 0xba, 0xaa, 0x28, 0xd2, 0x1f, 0xd8, 0xa2, 0x73, 0x9b, 0x47, 0x41, 0x9, 0x7c")
MAKE_THUNK(libasound, snd_seq_queue_status_sizeof, "0x2d, 0x7, 0xd0, 0x37, 0xb0, 0xb5, 0x7a, 0x11, 0x2f, 0x56, 0xef, 0x5, 0xbb, 0x90, 0x63, 0x88, 0x89, 0xc, 0x9a, 0x65, 0x91, 0x94, 0x0, 0xea, 0x5, 0xa3, 0x70, 0xf, 0xa0, 0xde, 0xc, 0x31")
MAKE_THUNK(libasound, snd_seq_queue_status_malloc, "0xd3, 0xd1, 0xf0, 0x35, 0x96, 0x26, 0x65, 0x4a, 0xf6, 0x54, 0xce, 0x19, 0xf2, 0x80, 0x92, 0xcc, 0x18, 0x35, 0xe8, 0x48, 0xcb, 0xf0, 0x28, 0xfb, 0xf, 0xde, 0x97, 0x31, 0x4e, 0x5c, 0x65, 0xb6")
MAKE_THUNK(libasound, snd_seq_queue_status_free, "0x91, 0x5e, 0x73, 0xd9, 0x53, 0x9b, 0x39, 0xc5, 0x51, 0xab, 0x97, 0xd9, 0x2c, 0x1e, 0xda, 0xfc, 0x14, 0x5a, 0x55, 0x64, 0x3f, 0xc0, 0xd2, 0x33, 0x5a, 0x13, 0x69, 0xdc, 0xe2, 0xa9, 0x9b, 0xc4")
MAKE_THUNK(libasound, snd_seq_queue_status_copy, "0xcd, 0x3a, 0xed, 0xb9, 0x95, 0xff, 0x3a, 0x2f, 0x9f, 0xd0, 0x5a, 0xb9, 0x47, 0x1a, 0xa9, 0xf, 0xb8, 0x15, 0xce, 0x36, 0x96, 0x55, 0x5d, 0x94, 0x22, 0xf2, 0x62, 0xe6, 0x21, 0xf4, 0xab, 0x63")
MAKE_THUNK(libasound, snd_seq_queue_status_get_queue, "0x92, 0x77, 0xc6, 0x64, 0x4f, 0x7a, 0x43, 0x6e, 0x3f, 0x2b, 0x7d, 0x72, 0x58, 0xb0, 0x62, 0xb0, 0x1c, 0x50, 0xf0, 0x6c, 0x6f, 0x1b, 0xc7, 0x7c, 0x3b, 0xe5, 0x2c, 0x8c, 0x6c, 0x2d, 0xf7, 0x5f")
MAKE_THUNK(libasound, snd_seq_queue_status_get_events, "0x9b, 0x45, 0x37, 0xc8, 0x88, 0x72, 0x6e, 0xa1, 0x32, 0x78, 0x85, 0x80, 0x1f, 0x98, 0xd5, 0xe7, 0x78, 0x23, 0x49, 0x65, 0x38, 0xa4, 0xb1, 0xa, 0x45, 0x14, 0xf3, 0x5d, 0xfb, 0x49, 0xfb, 0xf7")
MAKE_THUNK(libasound, snd_seq_queue_status_get_tick_time, "0x8b, 0xbb, 0x6f, 0x31, 0x4a, 0x36, 0x29, 0x1e, 0xa5, 0xe9, 0x8c, 0x3e, 0x1d, 0xb3, 0xf2, 0x7a, 0x48, 0x90, 0xea, 0x3c, 0x72, 0x4d, 0x7b, 0xce, 0x7f, 0x57, 0x98, 0x79, 0xbf, 0x2, 0x39, 0x74")
MAKE_THUNK(libasound, snd_seq_queue_status_get_real_time, "0x42, 0xd9, 0x46, 0xc0, 0x63, 0x7c, 0x74, 0xa5, 0xfd, 0x1f, 0x90, 0xd7, 0xd4, 0x54, 0x3f, 0x91, 0x80, 0x77, 0x54, 0x4e, 0xb7, 0xa9, 0x15, 0x83, 0x6a, 0x90, 0xf8, 0xc, 0x7c, 0x16, 0x7, 0x4a")
MAKE_THUNK(libasound, snd_seq_queue_status_get_status, "0x9a, 0x9c, 0x5b, 0x8d, 0x59, 0xa5, 0x49, 0x22, 0x64, 0x82, 0x5f, 0x1a, 0x3, 0x49, 0x5, 0x5, 0x6b, 0xe0, 0x86, 0xf4, 0x56, 0x7e, 0xdc, 0x16, 0xf1, 0xc9, 0x91, 0x63, 0x1, 0x71, 0xf8, 0xa7")
MAKE_THUNK(libasound, snd_seq_get_queue_status, "0x70, 0x2b, 0x4f, 0x39, 0xaf, 0x8c, 0xe2, 0x4b, 0xdb, 0x30, 0x9, 0x73, 0xe, 0xc6, 0x33, 0x22, 0x3d, 0x20, 0x5c, 0x15, 0xcf, 0x99, 0x16, 0xe, 0xbe, 0x5, 0xa3, 0x43, 0x1, 0xb1, 0xa1, 0xb4")
MAKE_THUNK(libasound, snd_seq_queue_tempo_sizeof, "0x69, 0xdd, 0x9e, 0x79, 0x69, 0xac, 0x32, 0x92, 0x86, 0x36, 0xf1, 0xc2, 0x7b, 0xd0, 0xf3, 0xe9, 0x5f, 0x9b, 0xeb, 0xc9, 0x20, 0xdc, 0xef, 0x18, 0xb8, 0x90, 0xfa, 0x93, 0x9d, 0xae, 0x60, 0xcf")
MAKE_THUNK(libasound, snd_seq_queue_tempo_malloc, "0x5b, 0x62, 0x2c, 0x9f, 0xa, 0x1c, 0xe9, 0x18, 0x91, 0x55, 0x7d, 0xdc, 0x55, 0x4f, 0x17, 0x8f, 0x31, 0x4d, 0x56, 0x1d, 0xeb, 0x85, 0xc6, 0xe4, 0xf4, 0x8, 0x5a, 0x8c, 0x54, 0xe6, 0x33, 0xaf")
MAKE_THUNK(libasound, snd_seq_queue_tempo_free, "0x28, 0x7c, 0x46, 0xda, 0xa2, 0xa0, 0x8b, 0x85, 0x42, 0x3c, 0x1f, 0x5e, 0x24, 0x70, 0x4, 0xeb, 0xc6, 0xc6, 0xe4, 0xda, 0x8d, 0x61, 0x93, 0xad, 0x17, 0x1b, 0xec, 0x34, 0x27, 0x66, 0xa, 0x4b")
MAKE_THUNK(libasound, snd_seq_queue_tempo_copy, "0xd3, 0x65, 0xbc, 0x6c, 0x90, 0xb9, 0x6e, 0x34, 0xee, 0x92, 0x85, 0x61, 0x19, 0x70, 0xd7, 0xe5, 0x8e, 0x26, 0xc0, 0x74, 0x16, 0x81, 0x22, 0x62, 0x2f, 0x5d, 0xf2, 0x28, 0x4f, 0x37, 0x3f, 0x3e")
MAKE_THUNK(libasound, snd_seq_queue_tempo_get_queue, "0x9a, 0x39, 0x3d, 0x84, 0xcf, 0x77, 0xe9, 0x8b, 0x78, 0x19, 0x6f, 0x2d, 0x56, 0x78, 0x6b, 0x9, 0x3e, 0xc7, 0x55, 0x65, 0x82, 0x70, 0x5d, 0x0, 0x2b, 0x51, 0xa, 0x56, 0x2a, 0xdb, 0xc9, 0x76")
MAKE_THUNK(libasound, snd_seq_queue_tempo_get_tempo, "0x4e, 0xda, 0xf1, 0xad, 0xef, 0xec, 0xff, 0x8b, 0x24, 0xb0, 0xf3, 0xfc, 0xab, 0xc7, 0x5f, 0x1f, 0x52, 0xd2, 0x18, 0x19, 0x5b, 0xce, 0xba, 0xac, 0x7, 0x2b, 0xfc, 0x56, 0x9, 0x45, 0x83, 0x1d")
MAKE_THUNK(libasound, snd_seq_queue_tempo_get_ppq, "0x94, 0x9d, 0xf7, 0x91, 0xb4, 0x4, 0xf6, 0x47, 0xa0, 0x1f, 0xc7, 0x31, 0x7d, 0x89, 0x23, 0x43, 0xd9, 0x4b, 0xed, 0xc7, 0x34, 0x9b, 0x40, 0x96, 0xbc, 0x3f, 0x7a, 0xfd, 0x8e, 0xa2, 0xf3, 0x2")
MAKE_THUNK(libasound, snd_seq_queue_tempo_get_skew, "0xaf, 0x77, 0x6e, 0xc9, 0x36, 0xfd, 0x93, 0xc4, 0x26, 0xee, 0x2b, 0x48, 0x6d, 0x73, 0x5b, 0x30, 0x38, 0x16, 0xfc, 0xb9, 0xc0, 0xbd, 0x76, 0x3a, 0x87, 0xea, 0x67, 0xbf, 0x15, 0x73, 0x2d, 0x28")
MAKE_THUNK(libasound, snd_seq_queue_tempo_get_skew_base, "0x8a, 0x26, 0xab, 0x2e, 0xd7, 0x81, 0x13, 0xb8, 0xb4, 0x55, 0xc7, 0xf9, 0xb3, 0x3a, 0xfa, 0x5f, 0x28, 0x6e, 0xc5, 0x5d, 0xbd, 0x59, 0x18, 0x2b, 0xa7, 0x39, 0x6c, 0x8d, 0x5e, 0xf6, 0xba, 0x82")
MAKE_THUNK(libasound, snd_seq_queue_tempo_set_tempo, "0x3a, 0xfd, 0x84, 0xeb, 0x2f, 0x6e, 0x27, 0x60, 0x1d, 0x10, 0x80, 0xdf, 0x15, 0xc7, 0x5d, 0x95, 0xd8, 0x57, 0x2e, 0x44, 0x5b, 0xe2, 0x85, 0x61, 0x2c, 0x9f, 0xe1, 0x4c, 0xe7, 0x7a, 0xae, 0x18")
MAKE_THUNK(libasound, snd_seq_queue_tempo_set_ppq, "0x32, 0x6d, 0xde, 0x2, 0xbb, 0xbc, 0x70, 0xd, 0xba, 0x30, 0x61, 0xf7, 0xa, 0x31, 0x80, 0x4b, 0x92, 0x38, 0x7b, 0x15, 0x18, 0xef, 0x40, 0x9c, 0x2e, 0xac, 0xd8, 0xc0, 0x7b, 0x8a, 0x2a, 0xaa")
MAKE_THUNK(libasound, snd_seq_queue_tempo_set_skew, "0x4d, 0xe8, 0x1d, 0x96, 0x60, 0x9c, 0xdc, 0xa6, 0xc0, 0xfb, 0x44, 0x17, 0x65, 0x89, 0x4d, 0x2f, 0x8a, 0x1b, 0x39, 0x88, 0xac, 0x7b, 0x9e, 0x60, 0x57, 0x24, 0x14, 0x4, 0x3d, 0x9c, 0x6d, 0x4b")
MAKE_THUNK(libasound, snd_seq_queue_tempo_set_skew_base, "0xf2, 0x2b, 0x70, 0x98, 0xe5, 0x61, 0xd0, 0x7f, 0x6f, 0x69, 0x8d, 0x48, 0xfd, 0x78, 0x99, 0x8b, 0xbc, 0xe3, 0x53, 0x2b, 0x2a, 0x45, 0x36, 0x5e, 0x9a, 0x36, 0x42, 0x6, 0x52, 0x97, 0xac, 0x0")
MAKE_THUNK(libasound, snd_seq_get_queue_tempo, "0x43, 0x46, 0x3f, 0xd1, 0xe4, 0x42, 0xa6, 0x1f, 0x47, 0xd2, 0x16, 0x7e, 0xd4, 0xff, 0xe5, 0x3a, 0x12, 0x7a, 0x26, 0x40, 0x1f, 0x93, 0xd4, 0x13, 0x56, 0x14, 0x66, 0x45, 0x24, 0x71, 0xbe, 0x22")
MAKE_THUNK(libasound, snd_seq_set_queue_tempo, "0xa9, 0xbb, 0x42, 0xbc, 0x53, 0xc1, 0x96, 0xd7, 0xa, 0x80, 0xb9, 0x7e, 0xbc, 0xce, 0xb9, 0xb8, 0xb9, 0x3b, 0x4e, 0xb5, 0xfa, 0x2b, 0xf1, 0x9d, 0xa4, 0x12, 0x8a, 0x17, 0xdb, 0x83, 0x5e, 0x0")
MAKE_THUNK(libasound, snd_seq_queue_timer_sizeof, "0x72, 0xad, 0x90, 0x8a, 0x7b, 0x9d, 0x1b, 0x5e, 0x46, 0xd4, 0xdb, 0x11, 0xf6, 0x63, 0x67, 0x4f, 0x76, 0x5c, 0xa9, 0xa4, 0x53, 0x81, 0x96, 0xd8, 0xe1, 0xda, 0x17, 0xeb, 0xf8, 0x4c, 0x9c, 0x61")
MAKE_THUNK(libasound, snd_seq_queue_timer_malloc, "0x59, 0xa3, 0x97, 0x15, 0xb1, 0x36, 0xdd, 0x93, 0x9e, 0x7c, 0xa3, 0x73, 0x58, 0x5c, 0xfa, 0xbf, 0x2f, 0x33, 0xd8, 0xa, 0x17, 0x6a, 0x3f, 0xea, 0x15, 0xe7, 0x5, 0x78, 0xc, 0xa9, 0x1b, 0xee")
MAKE_THUNK(libasound, snd_seq_queue_timer_free, "0x6e, 0x2d, 0x4a, 0x3c, 0x45, 0x38, 0x6, 0x1f, 0x65, 0x65, 0xc5, 0x2e, 0x4f, 0x85, 0xc0, 0x2c, 0x61, 0x9b, 0xf0, 0x27, 0x6b, 0x8e, 0xe4, 0xa2, 0x73, 0xae, 0xd1, 0xea, 0x22, 0x76, 0x66, 0xa3")
MAKE_THUNK(libasound, snd_seq_queue_timer_copy, "0x9, 0x7f, 0x79, 0xb6, 0x37, 0x3a, 0x99, 0xc8, 0xfe, 0xa1, 0xfe, 0x90, 0x74, 0x1f, 0x49, 0x7f, 0x67, 0x90, 0xb1, 0xf0, 0xa1, 0xa3, 0x4f, 0x1b, 0x88, 0xbb, 0xa2, 0x73, 0x82, 0x3, 0x55, 0xbe")
MAKE_THUNK(libasound, snd_seq_queue_timer_get_queue, "0x6f, 0x96, 0x95, 0x9e, 0xb3, 0x13, 0x94, 0x73, 0xd0, 0x61, 0x4f, 0x26, 0xb7, 0x43, 0xc5, 0x9b, 0xe8, 0x1e, 0xf4, 0x5a, 0xd1, 0x9b, 0xa1, 0x1c, 0xef, 0xfa, 0x62, 0x8b, 0x25, 0xbc, 0x20, 0x8c")
MAKE_THUNK(libasound, snd_seq_queue_timer_get_type, "0xc5, 0xc1, 0xb8, 0xb6, 0x9c, 0x5e, 0x35, 0xe5, 0xeb, 0x6d, 0x57, 0x57, 0x47, 0x9c, 0x63, 0x7b, 0xfb, 0xac, 0xe3, 0x11, 0xb1, 0x17, 0x23, 0xad, 0xf9, 0xcb, 0x2a, 0x8d, 0xfc, 0xc6, 0x6c, 0x7f")
MAKE_THUNK(libasound, snd_seq_queue_timer_get_id, "0x8b, 0x34, 0x2c, 0x3b, 0x55, 0x33, 0x1a, 0xea, 0x85, 0x1e, 0xd8, 0x3b, 0x8d, 0x8c, 0xc2, 0x2b, 0x9b, 0xc5, 0x9f, 0x61, 0x42, 0x54, 0x42, 0xf1, 0xa6, 0xea, 0x48, 0xc3, 0xcb, 0x6, 0x80, 0x30")
MAKE_THUNK(libasound, snd_seq_queue_timer_get_resolution, "0x7f, 0xf3, 0x77, 0xf0, 0x13, 0xf8, 0x13, 0x3d, 0x95, 0x99, 0xdc, 0xc7, 0x16, 0xc8, 0xb1, 0x9a, 0x46, 0x51, 0xab, 0xeb, 0x71, 0x33, 0x68, 0x8, 0x65, 0xe9, 0x6c, 0x5, 0xbf, 0x3b, 0x97, 0xa3")
MAKE_THUNK(libasound, snd_seq_queue_timer_set_type, "0xe7, 0xed, 0x7e, 0x85, 0x42, 0xfd, 0xb5, 0xbf, 0xcb, 0x46, 0x9c, 0xe9, 0x4e, 0x41, 0x6b, 0x13, 0xdb, 0xe1, 0xae, 0xe6, 0x17, 0x66, 0xb6, 0xff, 0x89, 0xdc, 0xd, 0xa4, 0x9c, 0x38, 0x21, 0xf8")
MAKE_THUNK(libasound, snd_seq_queue_timer_set_id, "0x23, 0xb5, 0x66, 0x4c, 0x1c, 0x90, 0x42, 0x99, 0xde, 0x99, 0xd6, 0x48, 0xdf, 0xc, 0x92, 0xcb, 0x98, 0xfc, 0x56, 0x95, 0x7d, 0xb, 0x50, 0xac, 0xf1, 0x7f, 0xe0, 0x66, 0xb9, 0x5, 0xf4, 0x97")
MAKE_THUNK(libasound, snd_seq_queue_timer_set_resolution, "0x97, 0x7f, 0x96, 0x27, 0x2b, 0xa2, 0x97, 0xda, 0x32, 0x71, 0xfb, 0x93, 0x41, 0x35, 0xb6, 0xbd, 0xd0, 0x48, 0xa0, 0x51, 0xb3, 0xa1, 0x18, 0xe, 0x11, 0x29, 0x34, 0x2c, 0x98, 0xa2, 0xba, 0x46")
MAKE_THUNK(libasound, snd_seq_get_queue_timer, "0x64, 0x96, 0x9b, 0x8c, 0xeb, 0xb7, 0x47, 0x82, 0xae, 0x5d, 0xcb, 0x50, 0x64, 0xe3, 0xae, 0xcd, 0xfd, 0xb5, 0x5e, 0x56, 0x67, 0xc6, 0x83, 0xf2, 0xb3, 0xfe, 0x5d, 0x63, 0x35, 0x67, 0x81, 0xac")
MAKE_THUNK(libasound, snd_seq_set_queue_timer, "0x7d, 0xed, 0xf4, 0xf1, 0xa6, 0x36, 0x97, 0x5e, 0x27, 0xe3, 0xbb, 0xc3, 0xe9, 0x10, 0xab, 0x93, 0x4d, 0xc1, 0x6a, 0x38, 0x9e, 0xf2, 0xa8, 0x4, 0xcc, 0xdd, 0xa6, 0xd0, 0xa6, 0xa9, 0x6e, 0x9b")
MAKE_THUNK(libasound, snd_seq_free_event, "0x59, 0xa8, 0x60, 0x38, 0x13, 0x14, 0x97, 0xb1, 0x2, 0x73, 0xb, 0xd8, 0xed, 0xca, 0x5a, 0xd1, 0x82, 0x9b, 0x5b, 0x72, 0x30, 0x9c, 0xc7, 0x48, 0x23, 0x1, 0xcf, 0x8d, 0x99, 0xc, 0x8c, 0xba")
MAKE_THUNK(libasound, snd_seq_event_length, "0x91, 0xd7, 0x8, 0xb0, 0x46, 0xb6, 0x68, 0x4d, 0x35, 0xc1, 0xe3, 0x17, 0xce, 0x9c, 0x5, 0x4f, 0xd5, 0x48, 0x57, 0xd9, 0x14, 0x68, 0x3d, 0x2f, 0x46, 0xff, 0x3, 0x7b, 0xf1, 0x72, 0xcb, 0xc5")
MAKE_THUNK(libasound, snd_seq_event_output, "0x56, 0x78, 0x66, 0xb7, 0xa9, 0x36, 0x7b, 0x81, 0xe9, 0xae, 0xa8, 0x27, 0x28, 0xb6, 0x94, 0xad, 0x72, 0xe1, 0xd0, 0x9f, 0xa1, 0xdd, 0xf1, 0x94, 0x45, 0x9a, 0x39, 0xec, 0x7e, 0x2b, 0x43, 0xea")
MAKE_THUNK(libasound, snd_seq_event_output_buffer, "0x87, 0x9f, 0x8e, 0xfe, 0x8e, 0x62, 0xad, 0x29, 0x52, 0xee, 0x91, 0xf1, 0xc1, 0x62, 0x75, 0xcc, 0x93, 0xd0, 0x18, 0x85, 0x96, 0x86, 0x78, 0xd2, 0xe7, 0x26, 0x97, 0x96, 0x42, 0xdb, 0x5f, 0x45")
MAKE_THUNK(libasound, snd_seq_event_output_direct, "0xb2, 0xd0, 0x43, 0x45, 0x2e, 0x33, 0xeb, 0xb8, 0x9, 0x3, 0xef, 0x5, 0xf7, 0x26, 0xbb, 0xc1, 0x40, 0x9, 0xb1, 0xb1, 0x18, 0x96, 0x6d, 0xfc, 0xcd, 0xc, 0x9a, 0x23, 0x40, 0xd6, 0xd6, 0xfe")
MAKE_THUNK(libasound, snd_seq_event_input, "0x21, 0x49, 0xc3, 0x1e, 0x41, 0xc, 0xbf, 0x70, 0xcf, 0x32, 0xef, 0x48, 0x8, 0x49, 0xb1, 0x2c, 0x37, 0x42, 0xdb, 0x57, 0x64, 0x86, 0xff, 0x78, 0xa3, 0xe8, 0x59, 0x8b, 0xf0, 0x75, 0x6b, 0x26")
MAKE_THUNK(libasound, snd_seq_event_input_pending, "0x2e, 0x14, 0x88, 0x23, 0x13, 0x4b, 0x36, 0x3f, 0x24, 0x7f, 0xb, 0x75, 0x7, 0xce, 0x30, 0xf7, 0xc0, 0xca, 0x68, 0x79, 0x5e, 0x7, 0x6c, 0x19, 0x7f, 0xc4, 0xc2, 0xa, 0xda, 0x28, 0x65, 0x80")
MAKE_THUNK(libasound, snd_seq_drain_output, "0xfc, 0xbd, 0x5a, 0x99, 0xef, 0x63, 0x31, 0xd, 0xa4, 0xc, 0xbd, 0x95, 0xf5, 0x2a, 0x50, 0x94, 0x4f, 0x99, 0xa8, 0xfa, 0x81, 0x2, 0xaa, 0xae, 0xfd, 0xe, 0x10, 0x3f, 0x1a, 0x9a, 0x75, 0x6b")
MAKE_THUNK(libasound, snd_seq_event_output_pending, "0xa4, 0x49, 0xf2, 0x5d, 0x4a, 0xc7, 0xbb, 0xf4, 0x86, 0xa7, 0xed, 0x23, 0x66, 0xa3, 0xf3, 0xa1, 0x8b, 0x32, 0x9, 0x27, 0xbe, 0x4c, 0x36, 0x8a, 0xae, 0x2b, 0xd, 0xf0, 0x10, 0x23, 0xfb, 0x34")
MAKE_THUNK(libasound, snd_seq_extract_output, "0x12, 0x4e, 0x1c, 0xe2, 0x8a, 0x28, 0x5e, 0x38, 0x36, 0xfc, 0xa1, 0x6d, 0xce, 0x22, 0x39, 0x99, 0x79, 0x97, 0xb2, 0xc8, 0xfe, 0x8, 0x72, 0xb3, 0x5e, 0x75, 0xc5, 0xed, 0x53, 0x95, 0xe, 0xe")
MAKE_THUNK(libasound, snd_seq_drop_output, "0x17, 0xcd, 0xfe, 0x0, 0xf0, 0x54, 0xe3, 0xcc, 0xde, 0x9d, 0xf5, 0x21, 0x76, 0x9c, 0x89, 0x91, 0xb8, 0xb8, 0xcb, 0x9a, 0x94, 0x6b, 0xa3, 0x69, 0xf3, 0x15, 0x58, 0x98, 0x70, 0xa3, 0x1e, 0x7b")
MAKE_THUNK(libasound, snd_seq_drop_output_buffer, "0x6d, 0x17, 0x48, 0xe9, 0xae, 0x9, 0xe9, 0x85, 0x7e, 0x15, 0xf4, 0x3f, 0xd1, 0xcd, 0xd7, 0x59, 0x7e, 0x0, 0x65, 0x8b, 0xfa, 0xf5, 0x30, 0x52, 0xb2, 0x8e, 0x1d, 0xd3, 0xdb, 0x7, 0x1f, 0x3a")
MAKE_THUNK(libasound, snd_seq_drop_input, "0x9b, 0x6e, 0x38, 0x59, 0x17, 0xf1, 0xa6, 0x70, 0xf0, 0x7, 0x92, 0x7f, 0xfd, 0xe7, 0x9e, 0x5, 0x48, 0xd, 0x84, 0x36, 0x7a, 0x4f, 0xa4, 0x5d, 0x25, 0xa1, 0x29, 0xf6, 0xfd, 0xcd, 0xb, 0xc5")
MAKE_THUNK(libasound, snd_seq_drop_input_buffer, "0xc, 0x33, 0x6f, 0x21, 0x37, 0xa2, 0x2a, 0x6d, 0x91, 0xbc, 0x85, 0xb6, 0x41, 0xee, 0xe0, 0x5a, 0x8d, 0xaa, 0x2f, 0xc6, 0xcd, 0xc5, 0xe4, 0x9e, 0x53, 0xd8, 0x40, 0xa2, 0xd5, 0x45, 0x14, 0xdd")
MAKE_THUNK(libasound, snd_seq_remove_events_sizeof, "0x24, 0xbf, 0xf0, 0x5a, 0x45, 0x3a, 0x3e, 0xdb, 0xcb, 0x55, 0x15, 0x7, 0x5, 0x4f, 0xd6, 0xae, 0xda, 0x50, 0x19, 0x4e, 0x8c, 0x65, 0xbe, 0x8c, 0x28, 0xf1, 0x90, 0x38, 0xf8, 0x2b, 0xf2, 0xe3")
MAKE_THUNK(libasound, snd_seq_remove_events_malloc, "0x17, 0x95, 0x61, 0x21, 0xde, 0x58, 0x5f, 0x83, 0x67, 0x91, 0x94, 0x2e, 0x76, 0xbe, 0x99, 0xf4, 0xa8, 0xaa, 0x2d, 0x4b, 0xfd, 0x80, 0xf0, 0x32, 0x15, 0xe9, 0x83, 0xa3, 0x20, 0x75, 0x0, 0x67")
MAKE_THUNK(libasound, snd_seq_remove_events_free, "0xcd, 0x20, 0xaa, 0x10, 0x3c, 0xab, 0xed, 0x4, 0xfe, 0x46, 0x58, 0xfc, 0x5f, 0xc7, 0xd1, 0xf3, 0x63, 0x50, 0xee, 0x47, 0xeb, 0x93, 0xc0, 0x5e, 0x6f, 0xa8, 0x4, 0xbd, 0x35, 0x3a, 0xf5, 0x2b")
MAKE_THUNK(libasound, snd_seq_remove_events_copy, "0xb, 0x98, 0xe3, 0x45, 0xfa, 0x84, 0xcd, 0x42, 0xf6, 0xf2, 0x44, 0xe1, 0x63, 0xc8, 0x5e, 0x2e, 0x86, 0xd3, 0x15, 0xbe, 0x6e, 0x1b, 0x30, 0xf3, 0x51, 0xb, 0x65, 0xf0, 0x94, 0xd5, 0xb3, 0xf5")
MAKE_THUNK(libasound, snd_seq_remove_events_get_condition, "0xa0, 0x83, 0x6e, 0x78, 0x8c, 0xd1, 0x4b, 0x94, 0xae, 0xd0, 0x92, 0x1d, 0x7e, 0x50, 0x3a, 0x1d, 0x8d, 0x98, 0x8f, 0xb7, 0xc, 0x49, 0x2f, 0xc6, 0x49, 0xd, 0x3f, 0x45, 0xc6, 0x47, 0xe4, 0xd0")
MAKE_THUNK(libasound, snd_seq_remove_events_get_queue, "0x8, 0xdb, 0x95, 0x35, 0x84, 0x1a, 0xc6, 0x24, 0x3f, 0x9e, 0x2c, 0xc3, 0x4c, 0x2d, 0x6a, 0xb5, 0x8f, 0x57, 0x87, 0x97, 0xc7, 0x2c, 0x0, 0x44, 0x33, 0x85, 0x31, 0x35, 0x64, 0x31, 0xd6, 0xb")
MAKE_THUNK(libasound, snd_seq_remove_events_get_time, "0x1, 0xca, 0x5f, 0xf4, 0x5e, 0x46, 0x7b, 0x47, 0x31, 0x76, 0x13, 0x23, 0x8, 0x9a, 0x6d, 0x16, 0xb4, 0x11, 0x80, 0x56, 0x1d, 0xe4, 0x83, 0x39, 0x6c, 0x2, 0x62, 0x6b, 0x69, 0x0, 0x6f, 0x46")
MAKE_THUNK(libasound, snd_seq_remove_events_get_dest, "0xe4, 0xa, 0xb7, 0x17, 0xc8, 0xaa, 0x90, 0xd, 0xf9, 0xed, 0xc0, 0x93, 0x37, 0xe7, 0xf2, 0xb1, 0xbc, 0xa7, 0x16, 0x5, 0x0, 0x38, 0x8f, 0x5f, 0xb8, 0x4f, 0x79, 0x6b, 0x45, 0x22, 0x5, 0x4f")
MAKE_THUNK(libasound, snd_seq_remove_events_get_channel, "0x35, 0x82, 0x40, 0xd7, 0x70, 0x92, 0x83, 0x1a, 0x6d, 0xe6, 0x53, 0xa0, 0xb6, 0xa1, 0xa3, 0x94, 0xc6, 0x1d, 0x36, 0x69, 0x76, 0x80, 0x34, 0x2, 0x2, 0xf9, 0x7b, 0xb5, 0xd, 0xb9, 0xe0, 0xa5")
MAKE_THUNK(libasound, snd_seq_remove_events_get_event_type, "0x81, 0x4a, 0xbe, 0x8c, 0x32, 0xb6, 0x62, 0x4b, 0xb8, 0x3d, 0xd3, 0x7f, 0xef, 0xc6, 0x21, 0x51, 0x58, 0x12, 0x45, 0x9e, 0x6, 0x81, 0x18, 0xac, 0x7c, 0xe7, 0x2b, 0x5d, 0x6, 0x41, 0xc6, 0x36")
MAKE_THUNK(libasound, snd_seq_remove_events_get_tag, "0x21, 0x54, 0x6a, 0x72, 0xea, 0x5, 0x2, 0x64, 0xf7, 0x6d, 0xcc, 0xfb, 0xb5, 0xb2, 0x98, 0x32, 0x37, 0xd, 0x2f, 0xa0, 0x23, 0xb7, 0x21, 0x86, 0xe9, 0x8d, 0x28, 0x31, 0xa4, 0xb1, 0xad, 0x48")
MAKE_THUNK(libasound, snd_seq_remove_events_set_condition, "0xa9, 0x65, 0xf9, 0x43, 0x7b, 0x53, 0x3d, 0x82, 0x89, 0x22, 0xcb, 0x24, 0x0, 0x8, 0x9d, 0x30, 0x3, 0xaf, 0xce, 0x6f, 0x45, 0x43, 0xb2, 0xe9, 0xff, 0x8d, 0xf8, 0x3c, 0xa2, 0x2f, 0x13, 0x44")
MAKE_THUNK(libasound, snd_seq_remove_events_set_queue, "0x3a, 0x4a, 0x6c, 0x5a, 0xac, 0x19, 0x1f, 0x1a, 0x24, 0x5b, 0x5c, 0x6b, 0xd4, 0xe, 0x64, 0x85, 0x36, 0xfc, 0x62, 0x5b, 0x6, 0xe7, 0x80, 0xe6, 0xbd, 0x5e, 0xaa, 0x9b, 0xea, 0xed, 0xe5, 0x9b")
MAKE_THUNK(libasound, snd_seq_remove_events_set_time, "0x60, 0x34, 0xd8, 0xc0, 0x11, 0x78, 0x26, 0x10, 0x79, 0x43, 0x23, 0xb5, 0x20, 0x6f, 0x65, 0xde, 0x69, 0xa6, 0xfd, 0xc0, 0x9, 0xb2, 0x25, 0x38, 0xca, 0x60, 0xbc, 0x3e, 0xc6, 0xda, 0xd3, 0x6")
MAKE_THUNK(libasound, snd_seq_remove_events_set_dest, "0xb, 0x2b, 0x86, 0xd4, 0x7, 0xa1, 0x95, 0x66, 0x1f, 0x2d, 0x5c, 0xbf, 0x23, 0xf5, 0xa6, 0x6d, 0x26, 0x82, 0xbe, 0x73, 0x2d, 0xa6, 0x45, 0x48, 0x25, 0xeb, 0xdf, 0x76, 0x0, 0x6d, 0x8c, 0x46")
MAKE_THUNK(libasound, snd_seq_remove_events_set_channel, "0x5, 0x0, 0xad, 0xf0, 0x5d, 0x7a, 0xf6, 0x8, 0x31, 0x57, 0x17, 0x9c, 0xa1, 0x14, 0x96, 0x9d, 0x6, 0xe2, 0x78, 0x8f, 0x22, 0x4b, 0xd7, 0x7e, 0xe5, 0xe0, 0xdc, 0xe8, 0x56, 0x7a, 0x8a, 0x1a")
MAKE_THUNK(libasound, snd_seq_remove_events_set_event_type, "0x41, 0xb0, 0x56, 0xe9, 0x80, 0x83, 0xd8, 0x1f, 0xf1, 0x3e, 0x57, 0xd3, 0x7d, 0xe5, 0x4f, 0x87, 0xb6, 0x7a, 0xba, 0xc7, 0x3, 0x8d, 0x1f, 0xf, 0x5a, 0xa2, 0x1b, 0x84, 0x9d, 0x43, 0xa8, 0x77")
MAKE_THUNK(libasound, snd_seq_remove_events_set_tag, "0xbc, 0x39, 0xe5, 0x28, 0x7d, 0xf, 0xc3, 0x16, 0x2c, 0x87, 0xf4, 0x2, 0xb0, 0xdf, 0x3e, 0xea, 0xf7, 0x3b, 0x47, 0x88, 0xc9, 0xe5, 0xd1, 0xb0, 0x16, 0x1f, 0xeb, 0x0, 0x3d, 0xd0, 0x9, 0xf1")
MAKE_THUNK(libasound, snd_seq_remove_events, "0x6c, 0x23, 0xac, 0x91, 0x72, 0x59, 0xe0, 0xfc, 0xe6, 0xf4, 0x42, 0xdb, 0x18, 0xf2, 0xdb, 0x70, 0x0, 0x1, 0xd2, 0x2c, 0x49, 0xca, 0xe0, 0xd3, 0x4, 0xa3, 0xa1, 0x7, 0x65, 0x83, 0x5b, 0x20")
MAKE_THUNK(libasound, snd_seq_set_bit, "0xd9, 0xa9, 0x0, 0x4f, 0x2c, 0x98, 0xb4, 0xb1, 0x4c, 0x3c, 0x7c, 0xb7, 0x8, 0x18, 0x38, 0xe9, 0x74, 0x22, 0x67, 0xa6, 0x18, 0x39, 0x52, 0xed, 0xb3, 0xc2, 0x99, 0xc7, 0x3c, 0xa2, 0xb0, 0xe0")
MAKE_THUNK(libasound, snd_seq_unset_bit, "0x24, 0xee, 0xd1, 0xb1, 0xb0, 0x2e, 0xd1, 0x9e, 0xc3, 0x73, 0x79, 0xba, 0x9c, 0xe1, 0xe2, 0x37, 0x3f, 0xf2, 0xf1, 0x9, 0xd8, 0x32, 0xed, 0xe8, 0xe1, 0xaf, 0xe2, 0x70, 0xf9, 0x3c, 0x51, 0xad")
MAKE_THUNK(libasound, snd_seq_change_bit, "0xc2, 0xa6, 0x8f, 0xa, 0xc5, 0x89, 0x10, 0x85, 0x69, 0x8e, 0xe3, 0x8, 0x8b, 0x2b, 0x8f, 0x35, 0xbf, 0x1f, 0x9, 0x6, 0x89, 0x72, 0x20, 0xba, 0x9c, 0xd1, 0x53, 0x47, 0xb5, 0x33, 0xf3, 0x7a")
MAKE_THUNK(libasound, snd_seq_get_bit, "0xf1, 0x96, 0x5f, 0x2b, 0x5a, 0x6f, 0xa9, 0x1, 0xdd, 0x13, 0x18, 0x68, 0x28, 0x27, 0x58, 0x4, 0x72, 0x39, 0x7c, 0x3, 0x13, 0x57, 0x7a, 0xe2, 0x55, 0xa6, 0xc7, 0x17, 0x25, 0x8d, 0xf, 0x97")
MAKE_THUNK(libasound, snd_seq_control_queue, "0x82, 0x1a, 0xde, 0x52, 0xff, 0x71, 0x83, 0x47, 0xe3, 0x6, 0xc5, 0x20, 0x21, 0x18, 0xea, 0x7a, 0xf3, 0x6e, 0xa1, 0xad, 0xf3, 0x8, 0x10, 0x52, 0xad, 0xe2, 0x8d, 0x69, 0x2d, 0xc9, 0x36, 0xb0")
MAKE_THUNK(libasound, snd_seq_create_simple_port, "0x57, 0xde, 0xde, 0xe3, 0xc9, 0xf, 0x25, 0x7e, 0x41, 0xad, 0x27, 0xa7, 0xe, 0x6, 0xc4, 0xf8, 0x17, 0xa8, 0x1a, 0x11, 0xcf, 0x7a, 0xf6, 0x81, 0xbe, 0x3c, 0x2a, 0x8c, 0x20, 0x69, 0x9f, 0x50")
MAKE_THUNK(libasound, snd_seq_delete_simple_port, "0x3e, 0x32, 0xcc, 0x6a, 0xe3, 0xc4, 0x4, 0xbc, 0xe9, 0xb3, 0x25, 0x95, 0x5d, 0x7f, 0xfd, 0x3b, 0x10, 0xef, 0xe9, 0xc, 0x26, 0xaa, 0xd, 0x3a, 0xac, 0x73, 0x3f, 0x89, 0xa7, 0x31, 0x17, 0x5")
MAKE_THUNK(libasound, snd_seq_connect_from, "0x8a, 0xfb, 0x2d, 0x6a, 0x94, 0x9f, 0x70, 0x2a, 0x62, 0x26, 0x5d, 0x6e, 0x90, 0x71, 0xe7, 0x15, 0x60, 0xc2, 0xc9, 0x1e, 0x32, 0x91, 0xb5, 0x32, 0x1, 0x5b, 0xb1, 0x9f, 0x4c, 0xe7, 0x55, 0x93")
MAKE_THUNK(libasound, snd_seq_connect_to, "0x81, 0x5f, 0x10, 0x39, 0xbb, 0xd6, 0x59, 0x9d, 0xd6, 0x1a, 0x5f, 0x45, 0x41, 0xe6, 0x35, 0x1f, 0xe6, 0x2d, 0xa0, 0xf7, 0xc7, 0x3b, 0xac, 0x33, 0x35, 0xc8, 0x50, 0xa1, 0x93, 0x7e, 0x5e, 0x50")
MAKE_THUNK(libasound, snd_seq_disconnect_from, "0x12, 0x43, 0x4c, 0x60, 0xe6, 0x42, 0xde, 0xac, 0xa3, 0xf3, 0xa4, 0xbb, 0x27, 0x7, 0x66, 0xc7, 0x46, 0x9b, 0x6e, 0x1e, 0x87, 0xe3, 0x8, 0x9, 0x40, 0xf9, 0xca, 0xf2, 0x48, 0xf3, 0x77, 0xc9")
MAKE_THUNK(libasound, snd_seq_disconnect_to, "0xbd, 0x0, 0x40, 0xcd, 0x28, 0x7f, 0xa4, 0x86, 0x95, 0xd1, 0xdd, 0x99, 0x42, 0xd5, 0x8f, 0x68, 0x51, 0xda, 0x7e, 0x3a, 0x45, 0x3e, 0x29, 0x12, 0x8c, 0xea, 0xd9, 0x81, 0x63, 0xa2, 0x4d, 0x98")
MAKE_THUNK(libasound, snd_seq_set_client_name, "0xc1, 0x4c, 0x80, 0x1c, 0x9, 0x31, 0x69, 0x4b, 0x12, 0xec, 0xee, 0xba, 0x41, 0xcb, 0xe1, 0xcc, 0xf3, 0xdb, 0xbd, 0x9e, 0xcb, 0xb2, 0x9a, 0x89, 0x9, 0x45, 0x81, 0x8, 0x1c, 0x90, 0x7b, 0x6c")
MAKE_THUNK(libasound, snd_seq_set_client_event_filter, "0x61, 0x83, 0x4a, 0x98, 0x3d, 0x55, 0x9b, 0xb2, 0x75, 0x9b, 0x94, 0xd1, 0xde, 0xac, 0xe3, 0x3d, 0xb4, 0xd7, 0xa8, 0x59, 0x80, 0x56, 0x3c, 0x6b, 0xa2, 0x93, 0xe, 0x4c, 0x82, 0xec, 0xdd, 0x40")
MAKE_THUNK(libasound, snd_seq_set_client_pool_output, "0x74, 0x16, 0xb9, 0xcf, 0x6c, 0xb6, 0xa3, 0x14, 0x3f, 0x57, 0xe6, 0x0, 0x15, 0x7c, 0x9d, 0xec, 0xd8, 0x6f, 0xb7, 0x3c, 0xce, 0x22, 0xbd, 0x9a, 0x3f, 0x8c, 0xa, 0x36, 0x5c, 0x9d, 0x29, 0x86")
MAKE_THUNK(libasound, snd_seq_set_client_pool_output_room, "0x31, 0x40, 0x9c, 0xd5, 0x89, 0x26, 0xf4, 0xc5, 0xb2, 0xfd, 0xbe, 0x89, 0x67, 0x49, 0xbd, 0xcb, 0x2e, 0xf2, 0xf3, 0x80, 0xe4, 0x9b, 0xc8, 0xc9, 0x71, 0xce, 0x70, 0x5a, 0xee, 0xa, 0x6b, 0xd1")
MAKE_THUNK(libasound, snd_seq_set_client_pool_input, "0x22, 0xda, 0xb8, 0x5b, 0x1f, 0xc3, 0xd5, 0x46, 0xc, 0x27, 0xfc, 0x77, 0xfa, 0x4b, 0xbc, 0xd3, 0xbf, 0x96, 0x15, 0x0, 0xf6, 0x85, 0x7b, 0x4c, 0xe9, 0xda, 0xd3, 0x4d, 0x62, 0x5a, 0x6b, 0x2")
MAKE_THUNK(libasound, snd_seq_sync_output_queue, "0xe4, 0xe, 0xaf, 0x2c, 0xb, 0x1c, 0xd4, 0xd6, 0xaa, 0x1a, 0x35, 0x93, 0x2, 0x6, 0x22, 0x6, 0x3, 0x12, 0x91, 0x56, 0xaf, 0xeb, 0x5c, 0x4b, 0x43, 0x62, 0x32, 0xe3, 0x81, 0x6d, 0x4c, 0xfb")
MAKE_THUNK(libasound, snd_seq_parse_address, "0x9d, 0x95, 0x6c, 0x8d, 0x6b, 0x5, 0x59, 0xdc, 0xf, 0x54, 0x68, 0xb5, 0x6f, 0x2d, 0x5a, 0x4, 0xba, 0x86, 0x9, 0x56, 0x4e, 0x51, 0x26, 0xb9, 0xc2, 0x7f, 0x6b, 0xa6, 0x41, 0xd1, 0xd4, 0x8b")
MAKE_THUNK(libasound, snd_seq_reset_pool_output, "0xd9, 0xf9, 0x85, 0x1d, 0xe, 0x78, 0xc3, 0x8c, 0x71, 0xe8, 0x49, 0xa7, 0x7c, 0x2f, 0x0, 0x4f, 0x15, 0xda, 0xd9, 0x4f, 0xa, 0x72, 0x3, 0xe9, 0xd2, 0x7b, 0x30, 0xa4, 0x72, 0x47, 0xc5, 0xf9")
MAKE_THUNK(libasound, snd_seq_reset_pool_input, "0x31, 0xc9, 0x77, 0x1c, 0x23, 0xe7, 0x2f, 0x6f, 0x84, 0xd, 0xb4, 0x85, 0xa0, 0x4a, 0xa, 0xbd, 0xee, 0x2, 0x44, 0x1a, 0x2, 0xc1, 0x2a, 0x5c, 0x24, 0x63, 0x32, 0xb5, 0x2d, 0x74, 0x56, 0x5d")
MAKE_THUNK(libasound, snd_midi_event_new, "0xea, 0x90, 0x24, 0x19, 0x11, 0x87, 0xa3, 0x1d, 0xe1, 0x17, 0xed, 0x1b, 0xc7, 0xdb, 0x73, 0xdd, 0x78, 0x88, 0x4c, 0x6, 0xcf, 0xb2, 0x42, 0xa4, 0xd6, 0xbd, 0x30, 0x3f, 0x61, 0xf6, 0x6f, 0xc7")
MAKE_THUNK(libasound, snd_midi_event_resize_buffer, "0xf8, 0xf2, 0xa0, 0x8e, 0xd1, 0x60, 0x9d, 0xbd, 0xb1, 0x4e, 0x96, 0x6c, 0xaa, 0xff, 0xc6, 0xbd, 0x5a, 0x71, 0xf3, 0x1b, 0x51, 0x5b, 0xd1, 0x2b, 0x6, 0x14, 0x26, 0xc5, 0x9, 0x1, 0x75, 0x98")
MAKE_THUNK(libasound, snd_midi_event_free, "0x26, 0x5f, 0x66, 0x9d, 0x26, 0xf3, 0x10, 0x2a, 0xf9, 0x91, 0x79, 0x13, 0x81, 0x3a, 0x18, 0xa2, 0xb6, 0x64, 0xbd, 0x99, 0x24, 0x12, 0xe4, 0x80, 0xcf, 0x97, 0x3b, 0x78, 0x3d, 0x5, 0xb0, 0xd")
MAKE_THUNK(libasound, snd_midi_event_init, "0x5b, 0x24, 0x5b, 0xa4, 0x3c, 0xd0, 0x95, 0x5f, 0x33, 0x84, 0x61, 0x67, 0xc1, 0xcd, 0xe, 0x1c, 0x7f, 0xd, 0x7d, 0xf5, 0x88, 0x19, 0x46, 0xfd, 0xcd, 0xb1, 0x2a, 0x18, 0xfd, 0xcf, 0x1f, 0x1b")
MAKE_THUNK(libasound, snd_midi_event_reset_encode, "0x6b, 0xb5, 0xbb, 0x24, 0xec, 0xbc, 0x87, 0xd1, 0x9, 0x3c, 0xd8, 0xaf, 0x90, 0xee, 0x30, 0x91, 0x32, 0x75, 0x4e, 0x96, 0xa1, 0x56, 0x4f, 0xbc, 0xf9, 0xa9, 0x13, 0x1c, 0xb2, 0x17, 0xdf, 0x2d")
MAKE_THUNK(libasound, snd_midi_event_reset_decode, "0x3b, 0xfa, 0x8e, 0x1, 0xeb, 0x95, 0xa6, 0xec, 0x37, 0x74, 0x76, 0x6a, 0x3e, 0x94, 0x58, 0xc7, 0x21, 0xfc, 0x5b, 0xa6, 0xa9, 0x7c, 0xbe, 0xb1, 0x37, 0x57, 0x32, 0x7b, 0x22, 0xa5, 0x5, 0x22")
MAKE_THUNK(libasound, snd_midi_event_no_status, "0x67, 0x0, 0xfe, 0xe8, 0xb, 0x7f, 0x1e, 0x9a, 0x6d, 0xd5, 0x6e, 0x56, 0x35, 0xb8, 0x28, 0x6a, 0x9, 0x4b, 0x6b, 0xc9, 0xc7, 0x44, 0xe0, 0x98, 0xe, 0x89, 0xdf, 0xfc, 0x78, 0x91, 0x61, 0xdb")
MAKE_THUNK(libasound, snd_midi_event_encode, "0x2c, 0xac, 0xbc, 0xfb, 0x55, 0xc7, 0x8d, 0x0, 0xaa, 0x12, 0x95, 0xa5, 0x4, 0x2a, 0x3c, 0xa6, 0x7c, 0x25, 0x76, 0x9d, 0xdb, 0xbe, 0x40, 0xe2, 0xd0, 0x63, 0xba, 0x3a, 0x32, 0x3a, 0x80, 0x40")
MAKE_THUNK(libasound, snd_midi_event_encode_byte, "0xf, 0xae, 0xc8, 0x9, 0x9d, 0xdb, 0x61, 0xe9, 0xb6, 0xac, 0xbf, 0xbd, 0xfb, 0x1b, 0x3e, 0x6f, 0x6a, 0xf8, 0xad, 0x28, 0xb6, 0x82, 0xfe, 0xa6, 0xc4, 0x92, 0xe0, 0x63, 0x91, 0xc0, 0x2a, 0xd3")
MAKE_THUNK(libasound, snd_midi_event_decode, "0xa4, 0x4f, 0x8d, 0xf2, 0x40, 0xdb, 0xce, 0x37, 0x48, 0x49, 0xce, 0xe1, 0x1f, 0x4a, 0x88, 0xa0, 0x4a, 0xec, 0x18, 0xcf, 0x7c, 0xb6, 0x3b, 0x92, 0xab, 0xc7, 0x3f, 0xd5, 0xa5, 0x70, 0x89, 0x80")
}
extern "C" {
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_asoundlib_version() -> const char * {
  struct __attribute__((packed)) {
    const char * rv;
  } args;
  fexthunks_libasound_snd_asoundlib_version(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_dlpath(char * a_0, size_t a_1, const char * a_2) -> int {
  struct __attribute__((packed)) {
    char * a_0;
    size_t a_1;
    const char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_dlpath(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_dlopen(const char * a_0, int a_1, char * a_2, size_t a_3) -> void * {
  struct __attribute__((packed)) {
    const char * a_0;
    int a_1;
    char * a_2;
    size_t a_3;
    void * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_dlopen(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_dlsym(void * a_0, const char * a_1, const char * a_2) -> void * {
  struct __attribute__((packed)) {
    void * a_0;
    const char * a_1;
    const char * a_2;
    void * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_dlsym(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_dlclose(void * a_0) -> int {
  struct __attribute__((packed)) {
    void * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_dlclose(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_shm_area_create(int a_0, void * a_1) -> struct snd_shm_area * {
  struct __attribute__((packed)) {
    int a_0;
    void * a_1;
    struct snd_shm_area * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_shm_area_create(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_shm_area_share(struct snd_shm_area * a_0) -> struct snd_shm_area * {
  struct __attribute__((packed)) {
    struct snd_shm_area * a_0;
    struct snd_shm_area * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_shm_area_share(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_shm_area_destroy(struct snd_shm_area * a_0) -> int {
  struct __attribute__((packed)) {
    struct snd_shm_area * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_shm_area_destroy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_user_file(const char * a_0, char ** a_1) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    char ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_user_file(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_input_stdio_open(snd_input_t ** a_0, const char * a_1, const char * a_2) -> int {
  struct __attribute__((packed)) {
    snd_input_t ** a_0;
    const char * a_1;
    const char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_input_stdio_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_input_stdio_attach(snd_input_t ** a_0, FILE * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_input_t ** a_0;
    FILE * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_input_stdio_attach(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_input_buffer_open(snd_input_t ** a_0, const char * a_1, ssize_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_input_t ** a_0;
    const char * a_1;
    ssize_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_input_buffer_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_input_close(snd_input_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_input_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_input_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_input_gets(snd_input_t * a_0, char * a_1, size_t a_2) -> char * {
  struct __attribute__((packed)) {
    snd_input_t * a_0;
    char * a_1;
    size_t a_2;
    char * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_input_gets(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_input_getc(snd_input_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_input_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_input_getc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_input_ungetc(snd_input_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_input_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_input_ungetc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_stdio_open(snd_output_t ** a_0, const char * a_1, const char * a_2) -> int {
  struct __attribute__((packed)) {
    snd_output_t ** a_0;
    const char * a_1;
    const char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_output_stdio_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_stdio_attach(snd_output_t ** a_0, FILE * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_output_t ** a_0;
    FILE * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_output_stdio_attach(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_buffer_open(snd_output_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_output_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_output_buffer_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_buffer_string(snd_output_t * a_0, char ** a_1) -> size_t {
  struct __attribute__((packed)) {
    snd_output_t * a_0;
    char ** a_1;
    size_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_output_buffer_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_close(snd_output_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_output_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_output_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_puts(snd_output_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_output_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_output_puts(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_putc(snd_output_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_output_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_output_putc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_output_flush(snd_output_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_output_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_output_flush(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_strerror(int a_0) -> const char * {
  struct __attribute__((packed)) {
    int a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_strerror(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_lib_error_set_handler(snd_lib_error_handler_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_lib_error_handler_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_lib_error_set_handler(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_topdir() -> const char * {
  struct __attribute__((packed)) {
    const char * rv;
  } args;
  fexthunks_libasound_snd_config_topdir(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_top(snd_config_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_top(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_load(snd_config_t * a_0, snd_input_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_input_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_load(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_load_override(snd_config_t * a_0, snd_input_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_input_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_load_override(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_save(snd_config_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_save(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_update() -> int {
  struct __attribute__((packed)) {
    int rv;
  } args;
  fexthunks_libasound_snd_config_update(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_update_r(snd_config_t ** a_0, snd_config_update_t ** a_1, const char * a_2) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    snd_config_update_t ** a_1;
    const char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_config_update_r(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_update_free(snd_config_update_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_config_update_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_update_free(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_update_free_global() -> int {
  struct __attribute__((packed)) {
    int rv;
  } args;
  fexthunks_libasound_snd_config_update_free_global(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_update_ref(snd_config_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_update_ref(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_ref(snd_config_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_ref(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_unref(snd_config_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_unref(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_search(snd_config_t * a_0, const char * a_1, snd_config_t ** a_2) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    const char * a_1;
    snd_config_t ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_config_search(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_search_definition(snd_config_t * a_0, const char * a_1, const char * a_2, snd_config_t ** a_3) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    const char * a_1;
    const char * a_2;
    snd_config_t ** a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_config_search_definition(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_expand(snd_config_t * a_0, snd_config_t * a_1, const char * a_2, snd_config_t * a_3, snd_config_t ** a_4) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_config_t * a_1;
    const char * a_2;
    snd_config_t * a_3;
    snd_config_t ** a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_config_expand(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_evaluate(snd_config_t * a_0, snd_config_t * a_1, snd_config_t * a_2, snd_config_t ** a_3) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_config_t * a_1;
    snd_config_t * a_2;
    snd_config_t ** a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_config_evaluate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_add(snd_config_t * a_0, snd_config_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_config_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_add(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_add_before(snd_config_t * a_0, snd_config_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_config_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_add_before(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_add_after(snd_config_t * a_0, snd_config_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    snd_config_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_add_after(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_remove(snd_config_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_remove(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_delete(snd_config_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_delete(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_delete_compound_members(const snd_config_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_delete_compound_members(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_copy(snd_config_t ** a_0, snd_config_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    snd_config_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_copy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_make(snd_config_t ** a_0, const char * a_1, snd_config_type_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    snd_config_type_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_config_make(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_make_integer(snd_config_t ** a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_make_integer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_make_integer64(snd_config_t ** a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_make_integer64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_make_real(snd_config_t ** a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_make_real(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_make_string(snd_config_t ** a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_make_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_make_pointer(snd_config_t ** a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_make_pointer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_make_compound(snd_config_t ** a_0, const char * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_config_make_compound(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_imake_string(snd_config_t ** a_0, const char * a_1, const char * a_2) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    const char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_config_imake_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_imake_safe_string(snd_config_t ** a_0, const char * a_1, const char * a_2) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    const char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_config_imake_safe_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_imake_pointer(snd_config_t ** a_0, const char * a_1, const void * a_2) -> int {
  struct __attribute__((packed)) {
    snd_config_t ** a_0;
    const char * a_1;
    const void * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_config_imake_pointer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_type(const snd_config_t * a_0) -> snd_config_type_t {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    snd_config_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_is_array(const snd_config_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_is_array(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_set_id(snd_config_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_set_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_set_integer(snd_config_t * a_0, long a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    long a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_set_integer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_set_integer64(snd_config_t * a_0, long long a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    long long a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_set_integer64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_set_real(snd_config_t * a_0, double a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    double a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_set_real(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_set_string(snd_config_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_set_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_set_ascii(snd_config_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_set_ascii(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_set_pointer(snd_config_t * a_0, const void * a_1) -> int {
  struct __attribute__((packed)) {
    snd_config_t * a_0;
    const void * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_set_pointer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_id(const snd_config_t * a_0, const char ** a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    const char ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_integer(const snd_config_t * a_0, long * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    long * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_integer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_integer64(const snd_config_t * a_0, long long * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    long long * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_integer64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_real(const snd_config_t * a_0, double * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    double * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_real(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_ireal(const snd_config_t * a_0, double * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    double * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_ireal(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_string(const snd_config_t * a_0, const char ** a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    const char ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_ascii(const snd_config_t * a_0, char ** a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    char ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_ascii(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_pointer(const snd_config_t * a_0, const void ** a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    const void ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_get_pointer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_test_id(const snd_config_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_config_test_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_iterator_first(const snd_config_t * a_0) -> snd_config_iterator_t {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    snd_config_iterator_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_iterator_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_iterator_end(const snd_config_t * a_0) -> snd_config_iterator_t {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    snd_config_iterator_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_iterator_end(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_bool_ascii(const char * a_0) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_get_bool_ascii(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_bool(const snd_config_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_get_bool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_ctl_iface_ascii(const char * a_0) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_get_ctl_iface_ascii(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_config_get_ctl_iface(const snd_config_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_config_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_config_get_ctl_iface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_names_list(const char * a_0, snd_devname_t ** a_1) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    snd_devname_t ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_names_list(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_names_list_free(snd_devname_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_devname_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_names_list_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_open(snd_pcm_t ** a_0, const char * a_1, snd_pcm_stream_t a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t ** a_0;
    const char * a_1;
    snd_pcm_stream_t a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_open_lconf(snd_pcm_t ** a_0, const char * a_1, snd_pcm_stream_t a_2, int a_3, snd_config_t * a_4) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t ** a_0;
    const char * a_1;
    snd_pcm_stream_t a_2;
    int a_3;
    snd_config_t * a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_pcm_open_lconf(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_open_fallback(snd_pcm_t ** a_0, snd_config_t * a_1, const char * a_2, const char * a_3, snd_pcm_stream_t a_4, int a_5) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t ** a_0;
    snd_config_t * a_1;
    const char * a_2;
    const char * a_3;
    snd_pcm_stream_t a_4;
    int a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_pcm_open_fallback(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_close(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_name(snd_pcm_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_type(snd_pcm_t * a_0) -> snd_pcm_type_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_stream(snd_pcm_t * a_0) -> snd_pcm_stream_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_stream_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_stream(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_poll_descriptors_count(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_poll_descriptors(snd_pcm_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_poll_descriptors_revents(snd_pcm_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_nonblock(snd_pcm_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_nonblock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_async_handler_get_pcm(snd_async_handler_t * a_0) -> snd_pcm_t * {
  struct __attribute__((packed)) {
    snd_async_handler_t * a_0;
    snd_pcm_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_async_handler_get_pcm(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info(snd_pcm_t * a_0, snd_pcm_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_current(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_current(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_free(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_free(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_current(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_current(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_prepare(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_prepare(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_reset(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_reset(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status(snd_pcm_t * a_0, snd_pcm_status_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_status_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_start(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_start(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_drop(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_drop(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_drain(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_drain(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_pause(snd_pcm_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_pause(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_state(snd_pcm_t * a_0) -> snd_pcm_state_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_state_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_state(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hwsync(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hwsync(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_delay(snd_pcm_t * a_0, snd_pcm_sframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_delay(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_resume(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_resume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_htimestamp(snd_pcm_t * a_0, snd_pcm_uframes_t * a_1, snd_htimestamp_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t * a_1;
    snd_htimestamp_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_htimestamp(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_avail(snd_pcm_t * a_0) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_avail(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_avail_update(snd_pcm_t * a_0) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_avail_update(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_avail_delay(snd_pcm_t * a_0, snd_pcm_sframes_t * a_1, snd_pcm_sframes_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sframes_t * a_1;
    snd_pcm_sframes_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_avail_delay(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_rewindable(snd_pcm_t * a_0) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_rewindable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_rewind(snd_pcm_t * a_0, snd_pcm_uframes_t a_1) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t a_1;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_rewind(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_forwardable(snd_pcm_t * a_0) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_forwardable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_forward(snd_pcm_t * a_0, snd_pcm_uframes_t a_1) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t a_1;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_forward(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_writei(snd_pcm_t * a_0, const void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    const void * a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_writei(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_readi(snd_pcm_t * a_0, void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    void * a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_readi(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_writen(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    void ** a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_writen(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_readn(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    void ** a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_readn(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_wait(snd_pcm_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_wait(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_link(snd_pcm_t * a_0, snd_pcm_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_link(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_unlink(snd_pcm_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_unlink(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_query_chmaps(snd_pcm_t * a_0) -> snd_pcm_chmap_query_t ** {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_chmap_query_t ** rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_query_chmaps(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_query_chmaps_from_hw(int a_0, int a_1, int a_2, snd_pcm_stream_t a_3) -> snd_pcm_chmap_query_t ** {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    int a_2;
    snd_pcm_stream_t a_3;
    snd_pcm_chmap_query_t ** rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_query_chmaps_from_hw(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_free_chmaps(snd_pcm_chmap_query_t ** a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_chmap_query_t ** a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_free_chmaps(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_get_chmap(snd_pcm_t * a_0) -> snd_pcm_chmap_t * {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_chmap_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_get_chmap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_set_chmap(snd_pcm_t * a_0, const snd_pcm_chmap_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    const snd_pcm_chmap_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_set_chmap(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_chmap_type_name(enum snd_pcm_chmap_type a_0) -> const char * {
  struct __attribute__((packed)) {
    enum snd_pcm_chmap_type a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_chmap_type_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_chmap_name(enum snd_pcm_chmap_position a_0) -> const char * {
  struct __attribute__((packed)) {
    enum snd_pcm_chmap_position a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_chmap_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_chmap_long_name(enum snd_pcm_chmap_position a_0) -> const char * {
  struct __attribute__((packed)) {
    enum snd_pcm_chmap_position a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_chmap_long_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_chmap_print(const snd_pcm_chmap_t * a_0, size_t a_1, char * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_chmap_t * a_0;
    size_t a_1;
    char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_chmap_print(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_chmap_from_string(const char * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const char * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_chmap_from_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_chmap_parse_string(const char * a_0) -> snd_pcm_chmap_t * {
  struct __attribute__((packed)) {
    const char * a_0;
    snd_pcm_chmap_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_chmap_parse_string(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_recover(snd_pcm_t * a_0, int a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    int a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_recover(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_set_params(snd_pcm_t * a_0, snd_pcm_format_t a_1, snd_pcm_access_t a_2, unsigned int a_3, unsigned int a_4, int a_5, unsigned int a_6) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_format_t a_1;
    snd_pcm_access_t a_2;
    unsigned int a_3;
    unsigned int a_4;
    int a_5;
    unsigned int a_6;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libasound_snd_pcm_set_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_get_params(snd_pcm_t * a_0, snd_pcm_uframes_t * a_1, snd_pcm_uframes_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t * a_1;
    snd_pcm_uframes_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_get_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_pcm_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_malloc(snd_pcm_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_free(snd_pcm_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_copy(snd_pcm_info_t * a_0, const snd_pcm_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_info_t * a_0;
    const snd_pcm_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_device(const snd_pcm_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_subdevice(const snd_pcm_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_stream(const snd_pcm_info_t * a_0) -> snd_pcm_stream_t {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    snd_pcm_stream_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_stream(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_card(const snd_pcm_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_id(const snd_pcm_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_name(const snd_pcm_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_subdevice_name(const snd_pcm_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_subdevice_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_class(const snd_pcm_info_t * a_0) -> snd_pcm_class_t {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    snd_pcm_class_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_class(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_subclass(const snd_pcm_info_t * a_0) -> snd_pcm_subclass_t {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    snd_pcm_subclass_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_subclass(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_subdevices_count(const snd_pcm_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_subdevices_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_subdevices_avail(const snd_pcm_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_subdevices_avail(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_get_sync(const snd_pcm_info_t * a_0) -> snd_pcm_sync_id_t {
  struct __attribute__((packed)) {
    const snd_pcm_info_t * a_0;
    snd_pcm_sync_id_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_info_get_sync(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_set_device(snd_pcm_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_info_set_device(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_set_subdevice(snd_pcm_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_info_set_subdevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_info_set_stream(snd_pcm_info_t * a_0, snd_pcm_stream_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_info_t * a_0;
    snd_pcm_stream_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_info_set_stream(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_any(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_any(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_can_mmap_sample_resolution(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_can_mmap_sample_resolution(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_is_double(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_is_double(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_is_batch(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_is_batch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_is_block_transfer(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_is_block_transfer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_is_monotonic(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_is_monotonic(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_can_overrange(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_can_overrange(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_can_pause(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_can_pause(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_can_resume(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_can_resume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_is_half_duplex(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_is_half_duplex(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_is_joint_duplex(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_is_joint_duplex(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_can_sync_start(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_can_sync_start(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_can_disable_period_wakeup(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_can_disable_period_wakeup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_supports_audio_wallclock_ts(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_supports_audio_wallclock_ts(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_supports_audio_ts_type(const snd_pcm_hw_params_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_supports_audio_ts_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_rate_numden(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_rate_numden(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_sbits(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_get_sbits(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_fifo_size(const snd_pcm_hw_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_get_fifo_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_pcm_hw_params_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_malloc(snd_pcm_hw_params_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_hw_params_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_free(snd_pcm_hw_params_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_hw_params_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_hw_params_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_copy(snd_pcm_hw_params_t * a_0, const snd_pcm_hw_params_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_hw_params_t * a_0;
    const snd_pcm_hw_params_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_access(const snd_pcm_hw_params_t * a_0, snd_pcm_access_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_access_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_access(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_access(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_access_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_test_access(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_access(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_access_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_access(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_access_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_access_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_access_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_access_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_access_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_access_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_access_mask(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_mask_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_access_mask_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_access_mask(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_access_mask(snd_pcm_hw_params_t * a_0, snd_pcm_access_mask_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_hw_params_t * a_0;
    snd_pcm_access_mask_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_access_mask(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_format(const snd_pcm_hw_params_t * a_0, snd_pcm_format_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_format_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_format(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_format(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_format_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_test_format(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_format(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_format_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_format(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_format_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_format_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_format_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_format_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_format_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_format_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_format_mask(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_mask_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_format_mask_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_format_mask(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_format_mask(snd_pcm_hw_params_t * a_0, snd_pcm_format_mask_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_hw_params_t * a_0;
    snd_pcm_format_mask_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_format_mask(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_subformat(const snd_pcm_hw_params_t * a_0, snd_pcm_subformat_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_subformat_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_subformat(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_subformat(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_subformat_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_test_subformat(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_subformat(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_subformat_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_subformat(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_subformat_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_subformat_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_subformat_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_subformat_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_subformat_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_subformat_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_subformat_mask(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_mask_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_subformat_mask_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_subformat_mask(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_subformat_mask(snd_pcm_hw_params_t * a_0, snd_pcm_subformat_mask_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_hw_params_t * a_0;
    snd_pcm_subformat_mask_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_subformat_mask(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_channels(const snd_pcm_hw_params_t * a_0, unsigned int * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_channels(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_channels_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_channels_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_channels_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_channels_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_channels(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_test_channels(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_channels(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_channels(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_channels_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_channels_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_channels_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_channels_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_channels_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, unsigned int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    unsigned int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_channels_minmax(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_channels_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_channels_near(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_channels_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_channels_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_channels_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_channels_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_rate(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_rate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_rate_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_rate_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_rate_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_rate_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_rate(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_test_rate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_rate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_rate_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_rate_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    unsigned int * a_4;
    int * a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_pcm_hw_params_set_rate_minmax(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_rate_near(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_rate_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_rate_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_rate_resample(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_rate_resample(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_rate_resample(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_rate_resample(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_export_buffer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_export_buffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_export_buffer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_export_buffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_wakeup(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_period_wakeup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_period_wakeup(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_period_wakeup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_period_time(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_period_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_period_time_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_period_time_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_period_time_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_period_time_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_period_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_test_period_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_time_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_time_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_time_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_time_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_time_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    unsigned int * a_4;
    int * a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_pcm_hw_params_set_period_time_minmax(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_time_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_time_near(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_time_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_time_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_time_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_time_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_period_size(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_period_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_period_size_min(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_period_size_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_period_size_max(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_period_size_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_period_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_test_period_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3, snd_pcm_uframes_t * a_4, int * a_5) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int * a_3;
    snd_pcm_uframes_t * a_4;
    int * a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size_minmax(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size_near(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_period_size_integer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_set_period_size_integer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_periods(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_periods(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_periods_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_periods_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_periods_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_periods_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_periods(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_test_periods(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_periods(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_periods_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_periods_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    unsigned int * a_4;
    int * a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_pcm_hw_params_set_periods_minmax(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_periods_near(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_periods_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_periods_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_periods_integer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_set_periods_integer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_buffer_time(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_buffer_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_buffer_time_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_buffer_time_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_buffer_time_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    unsigned int * a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_get_buffer_time_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_buffer_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_test_buffer_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_time_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_time_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_time_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_time_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_time_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    unsigned int * a_4;
    int * a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_time_minmax(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_time_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_time_near(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_time_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_time_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_time_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    unsigned int * a_2;
    int * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_time_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_buffer_size(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_buffer_size_min(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_buffer_size_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_buffer_size_max(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_buffer_size_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_test_buffer_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_test_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_size_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_size_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_size_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_size_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_size_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, snd_pcm_uframes_t * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    snd_pcm_uframes_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_size_minmax(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_size_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_size_near(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_size_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_size_first(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_set_buffer_size_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_hw_params_t * a_1;
    snd_pcm_uframes_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_hw_params_set_buffer_size_last(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_get_min_align(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_hw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_get_min_align(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_pcm_sw_params_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_malloc(snd_pcm_sw_params_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_sw_params_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_sw_params_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_free(snd_pcm_sw_params_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_sw_params_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_sw_params_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_copy(snd_pcm_sw_params_t * a_0, const snd_pcm_sw_params_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_sw_params_t * a_0;
    const snd_pcm_sw_params_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_boundary(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_boundary(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_tstamp_mode(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_tstamp_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    snd_pcm_tstamp_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_tstamp_mode(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_tstamp_mode(const snd_pcm_sw_params_t * a_0, snd_pcm_tstamp_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_tstamp_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_tstamp_mode(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_tstamp_type(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_tstamp_type_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    snd_pcm_tstamp_type_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_tstamp_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_tstamp_type(const snd_pcm_sw_params_t * a_0, snd_pcm_tstamp_type_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_tstamp_type_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_tstamp_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_avail_min(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_avail_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_avail_min(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_avail_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_period_event(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_period_event(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_period_event(const snd_pcm_sw_params_t * a_0, int * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_period_event(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_start_threshold(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_start_threshold(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_start_threshold(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_start_threshold(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_stop_threshold(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_stop_threshold(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_stop_threshold(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_stop_threshold(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_silence_threshold(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_silence_threshold(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_silence_threshold(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_silence_threshold(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_set_silence_size(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sw_params_t * a_1;
    snd_pcm_uframes_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_sw_params_set_silence_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_get_silence_size(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_sw_params_t * a_0;
    snd_pcm_uframes_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_get_silence_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_pcm_access_mask_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_malloc(snd_pcm_access_mask_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_access_mask_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_access_mask_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_free(snd_pcm_access_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_access_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_access_mask_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_copy(snd_pcm_access_mask_t * a_0, const snd_pcm_access_mask_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_access_mask_t * a_0;
    const snd_pcm_access_mask_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_access_mask_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_none(snd_pcm_access_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_access_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_access_mask_none(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_any(snd_pcm_access_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_access_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_access_mask_any(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_test(const snd_pcm_access_mask_t * a_0, snd_pcm_access_t a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_access_mask_t * a_0;
    snd_pcm_access_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_access_mask_test(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_empty(const snd_pcm_access_mask_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_access_mask_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_access_mask_empty(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_set(snd_pcm_access_mask_t * a_0, snd_pcm_access_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_access_mask_t * a_0;
    snd_pcm_access_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_access_mask_set(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_mask_reset(snd_pcm_access_mask_t * a_0, snd_pcm_access_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_access_mask_t * a_0;
    snd_pcm_access_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_access_mask_reset(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_pcm_format_mask_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_malloc(snd_pcm_format_mask_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_mask_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_mask_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_free(snd_pcm_format_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_format_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_mask_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_copy(snd_pcm_format_mask_t * a_0, const snd_pcm_format_mask_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_format_mask_t * a_0;
    const snd_pcm_format_mask_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_format_mask_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_none(snd_pcm_format_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_format_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_mask_none(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_any(snd_pcm_format_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_format_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_mask_any(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_test(const snd_pcm_format_mask_t * a_0, snd_pcm_format_t a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_format_mask_t * a_0;
    snd_pcm_format_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_format_mask_test(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_empty(const snd_pcm_format_mask_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_format_mask_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_mask_empty(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_set(snd_pcm_format_mask_t * a_0, snd_pcm_format_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_format_mask_t * a_0;
    snd_pcm_format_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_format_mask_set(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_mask_reset(snd_pcm_format_mask_t * a_0, snd_pcm_format_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_format_mask_t * a_0;
    snd_pcm_format_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_format_mask_reset(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_pcm_subformat_mask_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_malloc(snd_pcm_subformat_mask_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_subformat_mask_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_subformat_mask_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_free(snd_pcm_subformat_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_subformat_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_subformat_mask_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_copy(snd_pcm_subformat_mask_t * a_0, const snd_pcm_subformat_mask_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_subformat_mask_t * a_0;
    const snd_pcm_subformat_mask_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_subformat_mask_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_none(snd_pcm_subformat_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_subformat_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_subformat_mask_none(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_any(snd_pcm_subformat_mask_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_subformat_mask_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_subformat_mask_any(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_test(const snd_pcm_subformat_mask_t * a_0, snd_pcm_subformat_t a_1) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_subformat_mask_t * a_0;
    snd_pcm_subformat_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_subformat_mask_test(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_empty(const snd_pcm_subformat_mask_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_subformat_mask_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_subformat_mask_empty(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_set(snd_pcm_subformat_mask_t * a_0, snd_pcm_subformat_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_subformat_mask_t * a_0;
    snd_pcm_subformat_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_subformat_mask_set(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_mask_reset(snd_pcm_subformat_mask_t * a_0, snd_pcm_subformat_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_subformat_mask_t * a_0;
    snd_pcm_subformat_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_subformat_mask_reset(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_pcm_status_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_malloc(snd_pcm_status_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_status_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_status_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_free(snd_pcm_status_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_pcm_status_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_status_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_copy(snd_pcm_status_t * a_0, const snd_pcm_status_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_status_t * a_0;
    const snd_pcm_status_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_state(const snd_pcm_status_t * a_0) -> snd_pcm_state_t {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_pcm_state_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_status_get_state(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_trigger_tstamp(const snd_pcm_status_t * a_0, snd_timestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_timestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_get_trigger_tstamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_trigger_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_htimestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_get_trigger_htstamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_tstamp(const snd_pcm_status_t * a_0, snd_timestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_timestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_get_tstamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_htimestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_get_htstamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_audio_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_htimestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_get_audio_htstamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_driver_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_htimestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_get_driver_htstamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_audio_htstamp_report(const snd_pcm_status_t * a_0, snd_pcm_audio_tstamp_report_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_pcm_audio_tstamp_report_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_get_audio_htstamp_report(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_set_audio_htstamp_config(snd_pcm_status_t * a_0, snd_pcm_audio_tstamp_config_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_status_t * a_0;
    snd_pcm_audio_tstamp_config_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_set_audio_htstamp_config(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_delay(const snd_pcm_status_t * a_0) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_status_get_delay(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_avail(const snd_pcm_status_t * a_0) -> snd_pcm_uframes_t {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_pcm_uframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_status_get_avail(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_avail_max(const snd_pcm_status_t * a_0) -> snd_pcm_uframes_t {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_pcm_uframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_status_get_avail_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_get_overrange(const snd_pcm_status_t * a_0) -> snd_pcm_uframes_t {
  struct __attribute__((packed)) {
    const snd_pcm_status_t * a_0;
    snd_pcm_uframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_status_get_overrange(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_type_name(snd_pcm_type_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_type_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_type_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_stream_name(const snd_pcm_stream_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_stream_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_stream_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_access_name(const snd_pcm_access_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_access_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_access_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_name(const snd_pcm_format_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_description(const snd_pcm_format_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_description(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_name(const snd_pcm_subformat_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_subformat_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_subformat_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_subformat_description(const snd_pcm_subformat_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_subformat_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_subformat_description(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_value(const char * a_0) -> snd_pcm_format_t {
  struct __attribute__((packed)) {
    const char * a_0;
    snd_pcm_format_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_value(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_dump(snd_pcm_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_dump(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_dump_hw_setup(snd_pcm_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_dump_hw_setup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_dump_sw_setup(snd_pcm_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_dump_sw_setup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_dump_setup(snd_pcm_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_dump_setup(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_hw_params_dump(snd_pcm_hw_params_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_hw_params_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_hw_params_dump(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_sw_params_dump(snd_pcm_sw_params_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_sw_params_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_sw_params_dump(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_status_dump(snd_pcm_status_t * a_0, snd_output_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_status_t * a_0;
    snd_output_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_status_dump(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_mmap_begin(snd_pcm_t * a_0, const snd_pcm_channel_area_t ** a_1, snd_pcm_uframes_t * a_2, snd_pcm_uframes_t * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    const snd_pcm_channel_area_t ** a_1;
    snd_pcm_uframes_t * a_2;
    snd_pcm_uframes_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_mmap_begin(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_mmap_commit(snd_pcm_t * a_0, snd_pcm_uframes_t a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_mmap_commit(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_mmap_writei(snd_pcm_t * a_0, const void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    const void * a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_mmap_writei(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_mmap_readi(snd_pcm_t * a_0, void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    void * a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_mmap_readi(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_mmap_writen(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    void ** a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_mmap_writen(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_mmap_readn(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    void ** a_1;
    snd_pcm_uframes_t a_2;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_mmap_readn(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_signed(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_signed(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_unsigned(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_unsigned(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_linear(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_linear(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_float(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_float(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_little_endian(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_little_endian(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_big_endian(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_big_endian(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_cpu_endian(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_cpu_endian(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_width(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_width(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_physical_width(snd_pcm_format_t a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_physical_width(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_build_linear_format(int a_0, int a_1, int a_2, int a_3) -> snd_pcm_format_t {
  struct __attribute__((packed)) {
    int a_0;
    int a_1;
    int a_2;
    int a_3;
    snd_pcm_format_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_build_linear_format(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_size(snd_pcm_format_t a_0, size_t a_1) -> ssize_t {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    size_t a_1;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_format_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_silence(snd_pcm_format_t a_0) -> uint8_t {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    uint8_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_silence(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_silence_16(snd_pcm_format_t a_0) -> uint16_t {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    uint16_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_silence_16(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_silence_32(snd_pcm_format_t a_0) -> uint32_t {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    uint32_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_silence_32(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_silence_64(snd_pcm_format_t a_0) -> uint64_t {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    uint64_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_format_silence_64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_format_set_silence(snd_pcm_format_t a_0, void * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_format_t a_0;
    void * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_format_set_silence(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_bytes_to_frames(snd_pcm_t * a_0, ssize_t a_1) -> snd_pcm_sframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    ssize_t a_1;
    snd_pcm_sframes_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_bytes_to_frames(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_frames_to_bytes(snd_pcm_t * a_0, snd_pcm_sframes_t a_1) -> ssize_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_sframes_t a_1;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_frames_to_bytes(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_bytes_to_samples(snd_pcm_t * a_0, ssize_t a_1) -> long {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    ssize_t a_1;
    long rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_bytes_to_samples(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_samples_to_bytes(snd_pcm_t * a_0, long a_1) -> ssize_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    long a_1;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_samples_to_bytes(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_area_silence(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, unsigned int a_2, snd_pcm_format_t a_3) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_channel_area_t * a_0;
    snd_pcm_uframes_t a_1;
    unsigned int a_2;
    snd_pcm_format_t a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_pcm_area_silence(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_areas_silence(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, unsigned int a_2, snd_pcm_uframes_t a_3, snd_pcm_format_t a_4) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_channel_area_t * a_0;
    snd_pcm_uframes_t a_1;
    unsigned int a_2;
    snd_pcm_uframes_t a_3;
    snd_pcm_format_t a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_pcm_areas_silence(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_area_copy(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, const snd_pcm_channel_area_t * a_2, snd_pcm_uframes_t a_3, unsigned int a_4, snd_pcm_format_t a_5) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_channel_area_t * a_0;
    snd_pcm_uframes_t a_1;
    const snd_pcm_channel_area_t * a_2;
    snd_pcm_uframes_t a_3;
    unsigned int a_4;
    snd_pcm_format_t a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_pcm_area_copy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_areas_copy(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, const snd_pcm_channel_area_t * a_2, snd_pcm_uframes_t a_3, unsigned int a_4, snd_pcm_uframes_t a_5, snd_pcm_format_t a_6) -> int {
  struct __attribute__((packed)) {
    const snd_pcm_channel_area_t * a_0;
    snd_pcm_uframes_t a_1;
    const snd_pcm_channel_area_t * a_2;
    snd_pcm_uframes_t a_3;
    unsigned int a_4;
    snd_pcm_uframes_t a_5;
    snd_pcm_format_t a_6;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libasound_snd_pcm_areas_copy(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_meter_get_bufsize(snd_pcm_t * a_0) -> snd_pcm_uframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_meter_get_bufsize(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_meter_get_channels(snd_pcm_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_meter_get_channels(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_meter_get_rate(snd_pcm_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_meter_get_rate(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_meter_get_now(snd_pcm_t * a_0) -> snd_pcm_uframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_meter_get_now(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_meter_get_boundary(snd_pcm_t * a_0) -> snd_pcm_uframes_t {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_uframes_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_meter_get_boundary(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_meter_add_scope(snd_pcm_t * a_0, snd_pcm_scope_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_scope_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_meter_add_scope(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_meter_search_scope(snd_pcm_t * a_0, const char * a_1) -> snd_pcm_scope_t * {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    const char * a_1;
    snd_pcm_scope_t * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_meter_search_scope(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_malloc(snd_pcm_scope_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_pcm_scope_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_scope_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_set_ops(snd_pcm_scope_t * a_0, const snd_pcm_scope_ops_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_scope_t * a_0;
    const snd_pcm_scope_ops_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_scope_set_ops(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_set_name(snd_pcm_scope_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_scope_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_scope_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_get_name(snd_pcm_scope_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_pcm_scope_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_scope_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_get_callback_private(snd_pcm_scope_t * a_0) -> void * {
  struct __attribute__((packed)) {
    snd_pcm_scope_t * a_0;
    void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_pcm_scope_get_callback_private(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_set_callback_private(snd_pcm_scope_t * a_0, void * a_1) -> void {
  struct __attribute__((packed)) {
    snd_pcm_scope_t * a_0;
    void * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_scope_set_callback_private(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_s16_open(snd_pcm_t * a_0, const char * a_1, snd_pcm_scope_t ** a_2) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    const char * a_1;
    snd_pcm_scope_t ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_pcm_scope_s16_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_pcm_scope_s16_get_channel_buffer(snd_pcm_scope_t * a_0, unsigned int a_1) -> int16_t * {
  struct __attribute__((packed)) {
    snd_pcm_scope_t * a_0;
    unsigned int a_1;
    int16_t * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_pcm_scope_s16_get_channel_buffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_spcm_init(snd_pcm_t * a_0, unsigned int a_1, unsigned int a_2, snd_pcm_format_t a_3, snd_pcm_subformat_t a_4, snd_spcm_latency_t a_5, snd_pcm_access_t a_6, snd_spcm_xrun_type_t a_7) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    unsigned int a_1;
    unsigned int a_2;
    snd_pcm_format_t a_3;
    snd_pcm_subformat_t a_4;
    snd_spcm_latency_t a_5;
    snd_pcm_access_t a_6;
    snd_spcm_xrun_type_t a_7;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  fexthunks_libasound_snd_spcm_init(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_spcm_init_duplex(snd_pcm_t * a_0, snd_pcm_t * a_1, unsigned int a_2, unsigned int a_3, snd_pcm_format_t a_4, snd_pcm_subformat_t a_5, snd_spcm_latency_t a_6, snd_pcm_access_t a_7, snd_spcm_xrun_type_t a_8, snd_spcm_duplex_type_t a_9) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    snd_pcm_t * a_1;
    unsigned int a_2;
    unsigned int a_3;
    snd_pcm_format_t a_4;
    snd_pcm_subformat_t a_5;
    snd_spcm_latency_t a_6;
    snd_pcm_access_t a_7;
    snd_spcm_xrun_type_t a_8;
    snd_spcm_duplex_type_t a_9;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  args.a_7 = a_7;
  args.a_8 = a_8;
  args.a_9 = a_9;
  fexthunks_libasound_snd_spcm_init_duplex(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_spcm_init_get_params(snd_pcm_t * a_0, unsigned int * a_1, snd_pcm_uframes_t * a_2, snd_pcm_uframes_t * a_3) -> int {
  struct __attribute__((packed)) {
    snd_pcm_t * a_0;
    unsigned int * a_1;
    snd_pcm_uframes_t * a_2;
    snd_pcm_uframes_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_spcm_init_get_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_open(snd_rawmidi_t ** a_0, snd_rawmidi_t ** a_1, const char * a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t ** a_0;
    snd_rawmidi_t ** a_1;
    const char * a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_rawmidi_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_open_lconf(snd_rawmidi_t ** a_0, snd_rawmidi_t ** a_1, const char * a_2, int a_3, snd_config_t * a_4) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t ** a_0;
    snd_rawmidi_t ** a_1;
    const char * a_2;
    int a_3;
    snd_config_t * a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_rawmidi_open_lconf(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_close(snd_rawmidi_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_poll_descriptors_count(snd_rawmidi_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_poll_descriptors(snd_rawmidi_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_rawmidi_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_poll_descriptors_revents(snd_rawmidi_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_rawmidi_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_nonblock(snd_rawmidi_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_nonblock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_rawmidi_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_malloc(snd_rawmidi_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_free(snd_rawmidi_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_copy(snd_rawmidi_info_t * a_0, const snd_rawmidi_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_info_t * a_0;
    const snd_rawmidi_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_device(const snd_rawmidi_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_subdevice(const snd_rawmidi_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_stream(const snd_rawmidi_info_t * a_0) -> snd_rawmidi_stream_t {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    snd_rawmidi_stream_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_stream(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_card(const snd_rawmidi_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_flags(const snd_rawmidi_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_flags(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_id(const snd_rawmidi_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_name(const snd_rawmidi_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_subdevice_name(const snd_rawmidi_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_subdevice_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_subdevices_count(const snd_rawmidi_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_subdevices_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_get_subdevices_avail(const snd_rawmidi_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_rawmidi_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_info_get_subdevices_avail(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_set_device(snd_rawmidi_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_info_set_device(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_set_subdevice(snd_rawmidi_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_info_set_subdevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info_set_stream(snd_rawmidi_info_t * a_0, snd_rawmidi_stream_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_info_t * a_0;
    snd_rawmidi_stream_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_info_set_stream(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_info(snd_rawmidi_t * a_0, snd_rawmidi_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_rawmidi_params_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_malloc(snd_rawmidi_params_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_params_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_params_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_free(snd_rawmidi_params_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_params_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_params_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_copy(snd_rawmidi_params_t * a_0, const snd_rawmidi_params_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_params_t * a_0;
    const snd_rawmidi_params_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_params_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_set_buffer_size(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1, size_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_params_t * a_1;
    size_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_rawmidi_params_set_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_get_buffer_size(const snd_rawmidi_params_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_rawmidi_params_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_params_get_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_set_avail_min(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1, size_t a_2) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_params_t * a_1;
    size_t a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_rawmidi_params_set_avail_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_get_avail_min(const snd_rawmidi_params_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_rawmidi_params_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_params_get_avail_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_set_no_active_sensing(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_params_t * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_rawmidi_params_set_no_active_sensing(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_get_no_active_sensing(const snd_rawmidi_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_rawmidi_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_params_get_no_active_sensing(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_params_current(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_params_current(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_rawmidi_status_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status_malloc(snd_rawmidi_status_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_status_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_status_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status_free(snd_rawmidi_status_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_status_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_status_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status_copy(snd_rawmidi_status_t * a_0, const snd_rawmidi_status_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_rawmidi_status_t * a_0;
    const snd_rawmidi_status_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_status_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status_get_tstamp(const snd_rawmidi_status_t * a_0, snd_htimestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_rawmidi_status_t * a_0;
    snd_htimestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_status_get_tstamp(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status_get_avail(const snd_rawmidi_status_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_rawmidi_status_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_status_get_avail(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status_get_xruns(const snd_rawmidi_status_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_rawmidi_status_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_status_get_xruns(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_status(snd_rawmidi_t * a_0, snd_rawmidi_status_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_status_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_rawmidi_status(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_drain(snd_rawmidi_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_drain(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_drop(snd_rawmidi_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_drop(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_write(snd_rawmidi_t * a_0, const void * a_1, size_t a_2) -> ssize_t {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    const void * a_1;
    size_t a_2;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_rawmidi_write(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_read(snd_rawmidi_t * a_0, void * a_1, size_t a_2) -> ssize_t {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    void * a_1;
    size_t a_2;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_rawmidi_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_name(snd_rawmidi_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_type(snd_rawmidi_t * a_0) -> snd_rawmidi_type_t {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_rawmidi_stream(snd_rawmidi_t * a_0) -> snd_rawmidi_stream_t {
  struct __attribute__((packed)) {
    snd_rawmidi_t * a_0;
    snd_rawmidi_stream_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_rawmidi_stream(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_query_open(snd_timer_query_t ** a_0, const char * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_timer_query_t ** a_0;
    const char * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_timer_query_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_query_open_lconf(snd_timer_query_t ** a_0, const char * a_1, int a_2, snd_config_t * a_3) -> int {
  struct __attribute__((packed)) {
    snd_timer_query_t ** a_0;
    const char * a_1;
    int a_2;
    snd_config_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_timer_query_open_lconf(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_query_close(snd_timer_query_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_query_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_query_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_query_next_device(snd_timer_query_t * a_0, snd_timer_id_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_query_t * a_0;
    snd_timer_id_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_query_next_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_query_info(snd_timer_query_t * a_0, snd_timer_ginfo_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_query_t * a_0;
    snd_timer_ginfo_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_query_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_query_params(snd_timer_query_t * a_0, snd_timer_gparams_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_query_t * a_0;
    snd_timer_gparams_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_query_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_query_status(snd_timer_query_t * a_0, snd_timer_gstatus_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_query_t * a_0;
    snd_timer_gstatus_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_query_status(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_open(snd_timer_t ** a_0, const char * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_timer_t ** a_0;
    const char * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_timer_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_open_lconf(snd_timer_t ** a_0, const char * a_1, int a_2, snd_config_t * a_3) -> int {
  struct __attribute__((packed)) {
    snd_timer_t ** a_0;
    const char * a_1;
    int a_2;
    snd_config_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_timer_open_lconf(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_close(snd_timer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_poll_descriptors_count(snd_timer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_poll_descriptors(snd_timer_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_timer_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_poll_descriptors_revents(snd_timer_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_timer_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info(snd_timer_t * a_0, snd_timer_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    snd_timer_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params(snd_timer_t * a_0, snd_timer_params_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    snd_timer_params_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status(snd_timer_t * a_0, snd_timer_status_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    snd_timer_status_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_status(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_start(snd_timer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_start(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_stop(snd_timer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_stop(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_continue(snd_timer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_continue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_read(snd_timer_t * a_0, void * a_1, size_t a_2) -> ssize_t {
  struct __attribute__((packed)) {
    snd_timer_t * a_0;
    void * a_1;
    size_t a_2;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_timer_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_timer_id_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_malloc(snd_timer_id_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_id_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_id_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_free(snd_timer_id_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_id_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_copy(snd_timer_id_t * a_0, const snd_timer_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    const snd_timer_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_id_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_set_class(snd_timer_id_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_id_set_class(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_get_class(snd_timer_id_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_id_get_class(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_set_sclass(snd_timer_id_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_id_set_sclass(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_get_sclass(snd_timer_id_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_id_get_sclass(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_set_card(snd_timer_id_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_id_set_card(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_get_card(snd_timer_id_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_id_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_set_device(snd_timer_id_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_id_set_device(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_get_device(snd_timer_id_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_id_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_set_subdevice(snd_timer_id_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_id_set_subdevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_id_get_subdevice(snd_timer_id_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_id_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_id_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_timer_ginfo_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_malloc(snd_timer_ginfo_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_free(snd_timer_ginfo_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_copy(snd_timer_ginfo_t * a_0, const snd_timer_ginfo_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    const snd_timer_ginfo_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_ginfo_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_set_tid(snd_timer_ginfo_t * a_0, snd_timer_id_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    snd_timer_id_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_ginfo_set_tid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_tid(snd_timer_ginfo_t * a_0) -> snd_timer_id_t * {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    snd_timer_id_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_tid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_flags(snd_timer_ginfo_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_flags(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_card(snd_timer_ginfo_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_id(snd_timer_ginfo_t * a_0) -> char * {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_name(snd_timer_ginfo_t * a_0) -> char * {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_resolution(snd_timer_ginfo_t * a_0) -> unsigned long {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    unsigned long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_resolution(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_resolution_min(snd_timer_ginfo_t * a_0) -> unsigned long {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    unsigned long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_resolution_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_resolution_max(snd_timer_ginfo_t * a_0) -> unsigned long {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    unsigned long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_resolution_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_ginfo_get_clients(snd_timer_ginfo_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    snd_timer_ginfo_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_ginfo_get_clients(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_timer_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_malloc(snd_timer_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_free(snd_timer_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_copy(snd_timer_info_t * a_0, const snd_timer_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
    const snd_timer_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_is_slave(snd_timer_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_is_slave(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_get_card(snd_timer_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_get_id(snd_timer_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_get_name(snd_timer_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_get_resolution(snd_timer_info_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_get_resolution(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_timer_params_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_malloc(snd_timer_params_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_params_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_free(snd_timer_params_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_copy(snd_timer_params_t * a_0, const snd_timer_params_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    const snd_timer_params_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_set_auto_start(snd_timer_params_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params_set_auto_start(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_get_auto_start(snd_timer_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_get_auto_start(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_set_exclusive(snd_timer_params_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params_set_exclusive(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_get_exclusive(snd_timer_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_get_exclusive(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_set_early_event(snd_timer_params_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params_set_early_event(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_get_early_event(snd_timer_params_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_get_early_event(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_set_ticks(snd_timer_params_t * a_0, long a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    long a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params_set_ticks(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_get_ticks(snd_timer_params_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_get_ticks(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_set_queue_size(snd_timer_params_t * a_0, long a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    long a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params_set_queue_size(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_get_queue_size(snd_timer_params_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_get_queue_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_set_filter(snd_timer_params_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_params_set_filter(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_params_get_filter(snd_timer_params_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    snd_timer_params_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_params_get_filter(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_timer_status_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_malloc(snd_timer_status_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_timer_status_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_status_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_free(snd_timer_status_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_timer_status_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_status_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_copy(snd_timer_status_t * a_0, const snd_timer_status_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_timer_status_t * a_0;
    const snd_timer_status_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_timer_status_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_get_timestamp(snd_timer_status_t * a_0) -> snd_htimestamp_t {
  struct __attribute__((packed)) {
    snd_timer_status_t * a_0;
    snd_htimestamp_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_status_get_timestamp(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_get_resolution(snd_timer_status_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_status_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_status_get_resolution(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_get_lost(snd_timer_status_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_status_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_status_get_lost(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_get_overrun(snd_timer_status_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_status_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_status_get_overrun(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_status_get_queue(snd_timer_status_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_status_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_status_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_timer_info_get_ticks(snd_timer_info_t * a_0) -> long {
  struct __attribute__((packed)) {
    snd_timer_info_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_timer_info_get_ticks(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_open(snd_hwdep_t ** a_0, const char * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t ** a_0;
    const char * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hwdep_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_close(snd_hwdep_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_poll_descriptors(snd_hwdep_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hwdep_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_poll_descriptors_count(snd_hwdep_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_poll_descriptors_revents(snd_hwdep_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_hwdep_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_nonblock(snd_hwdep_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_nonblock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info(snd_hwdep_t * a_0, snd_hwdep_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    snd_hwdep_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status(snd_hwdep_t * a_0, snd_hwdep_dsp_status_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    snd_hwdep_dsp_status_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_status(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_load(snd_hwdep_t * a_0, snd_hwdep_dsp_image_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    snd_hwdep_dsp_image_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_load(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_ioctl(snd_hwdep_t * a_0, unsigned int a_1, void * a_2) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    unsigned int a_1;
    void * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hwdep_ioctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_write(snd_hwdep_t * a_0, const void * a_1, size_t a_2) -> ssize_t {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    const void * a_1;
    size_t a_2;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hwdep_write(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_read(snd_hwdep_t * a_0, void * a_1, size_t a_2) -> ssize_t {
  struct __attribute__((packed)) {
    snd_hwdep_t * a_0;
    void * a_1;
    size_t a_2;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hwdep_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_hwdep_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_malloc(snd_hwdep_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_free(snd_hwdep_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_copy(snd_hwdep_info_t * a_0, const snd_hwdep_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_info_t * a_0;
    const snd_hwdep_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_get_device(const snd_hwdep_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hwdep_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_info_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_get_card(const snd_hwdep_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_hwdep_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_info_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_get_id(const snd_hwdep_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_hwdep_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_info_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_get_name(const snd_hwdep_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_hwdep_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_get_iface(const snd_hwdep_info_t * a_0) -> snd_hwdep_iface_t {
  struct __attribute__((packed)) {
    const snd_hwdep_info_t * a_0;
    snd_hwdep_iface_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_info_get_iface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_info_set_device(snd_hwdep_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_info_set_device(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_hwdep_dsp_status_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_malloc(snd_hwdep_dsp_status_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_status_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_status_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_free(snd_hwdep_dsp_status_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_status_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_status_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_copy(snd_hwdep_dsp_status_t * a_0, const snd_hwdep_dsp_status_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_status_t * a_0;
    const snd_hwdep_dsp_status_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_status_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_get_version(const snd_hwdep_dsp_status_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_status_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_status_get_version(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_get_id(const snd_hwdep_dsp_status_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_status_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_status_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_get_num_dsps(const snd_hwdep_dsp_status_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_status_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_status_get_num_dsps(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_get_dsp_loaded(const snd_hwdep_dsp_status_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_status_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_status_get_dsp_loaded(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_status_get_chip_ready(const snd_hwdep_dsp_status_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_status_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_status_get_chip_ready(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_hwdep_dsp_image_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_malloc(snd_hwdep_dsp_image_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_image_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_image_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_free(snd_hwdep_dsp_image_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_image_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_image_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_copy(snd_hwdep_dsp_image_t * a_0, const snd_hwdep_dsp_image_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_image_t * a_0;
    const snd_hwdep_dsp_image_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_image_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_get_index(const snd_hwdep_dsp_image_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_image_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_image_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_get_name(const snd_hwdep_dsp_image_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_image_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_image_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_get_image(const snd_hwdep_dsp_image_t * a_0) -> const void * {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_image_t * a_0;
    const void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_image_get_image(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_get_length(const snd_hwdep_dsp_image_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_hwdep_dsp_image_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hwdep_dsp_image_get_length(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_set_index(snd_hwdep_dsp_image_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_image_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_image_set_index(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_set_name(snd_hwdep_dsp_image_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_image_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_image_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_set_image(snd_hwdep_dsp_image_t * a_0, void * a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_image_t * a_0;
    void * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_image_set_image(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hwdep_dsp_image_set_length(snd_hwdep_dsp_image_t * a_0, size_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_hwdep_dsp_image_t * a_0;
    size_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hwdep_dsp_image_set_length(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_card_load(int a_0) -> int {
  struct __attribute__((packed)) {
    int a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_card_load(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_card_next(int * a_0) -> int {
  struct __attribute__((packed)) {
    int * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_card_next(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_card_get_index(const char * a_0) -> int {
  struct __attribute__((packed)) {
    const char * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_card_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_card_get_name(int a_0, char ** a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    char ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_card_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_card_get_longname(int a_0, char ** a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    char ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_card_get_longname(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_device_name_hint(int a_0, const char * a_1, void *** a_2) -> int {
  struct __attribute__((packed)) {
    int a_0;
    const char * a_1;
    void *** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_device_name_hint(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_device_name_free_hint(void ** a_0) -> int {
  struct __attribute__((packed)) {
    void ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_device_name_free_hint(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_device_name_get_hint(const void * a_0, const char * a_1) -> char * {
  struct __attribute__((packed)) {
    const void * a_0;
    const char * a_1;
    char * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_device_name_get_hint(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_open(snd_ctl_t ** a_0, const char * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t ** a_0;
    const char * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_open_lconf(snd_ctl_t ** a_0, const char * a_1, int a_2, snd_config_t * a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t ** a_0;
    const char * a_1;
    int a_2;
    snd_config_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_open_lconf(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_open_fallback(snd_ctl_t ** a_0, snd_config_t * a_1, const char * a_2, const char * a_3, int a_4) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t ** a_0;
    snd_config_t * a_1;
    const char * a_2;
    const char * a_3;
    int a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_ctl_open_fallback(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_close(snd_ctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_nonblock(snd_ctl_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_nonblock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_poll_descriptors_count(snd_ctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_poll_descriptors(snd_ctl_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_poll_descriptors_revents(snd_ctl_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_subscribe_events(snd_ctl_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_subscribe_events(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info(snd_ctl_t * a_0, snd_ctl_card_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_card_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_card_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list(snd_ctl_t * a_0, snd_ctl_elem_list_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_list_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_read(snd_ctl_t * a_0, snd_ctl_elem_value_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_value_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_write(snd_ctl_t * a_0, snd_ctl_elem_value_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_value_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_write(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_lock(snd_ctl_t * a_0, snd_ctl_elem_id_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_id_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_lock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_unlock(snd_ctl_t * a_0, snd_ctl_elem_id_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_id_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_unlock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_tlv_read(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int * a_2, unsigned int a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    unsigned int * a_2;
    unsigned int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_elem_tlv_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_tlv_write(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, const unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    const unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_tlv_write(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_tlv_command(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, const unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    const unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_tlv_command(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_hwdep_next_device(snd_ctl_t * a_0, int * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_hwdep_next_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_hwdep_info(snd_ctl_t * a_0, snd_hwdep_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_hwdep_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_hwdep_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_pcm_next_device(snd_ctl_t * a_0, int * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_pcm_next_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_pcm_info(snd_ctl_t * a_0, snd_pcm_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_pcm_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_pcm_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_pcm_prefer_subdevice(snd_ctl_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_pcm_prefer_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_rawmidi_next_device(snd_ctl_t * a_0, int * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_rawmidi_next_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_rawmidi_info(snd_ctl_t * a_0, snd_rawmidi_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_rawmidi_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_rawmidi_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_rawmidi_prefer_subdevice(snd_ctl_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_rawmidi_prefer_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_set_power_state(snd_ctl_t * a_0, unsigned int a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    unsigned int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_set_power_state(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_get_power_state(snd_ctl_t * a_0, unsigned int * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    unsigned int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_get_power_state(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_read(snd_ctl_t * a_0, snd_ctl_event_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_event_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_wait(snd_ctl_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_wait(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_name(snd_ctl_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_type(snd_ctl_t * a_0) -> snd_ctl_type_t {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_type_name(snd_ctl_elem_type_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_ctl_elem_type_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_type_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_iface_name(snd_ctl_elem_iface_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_ctl_elem_iface_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_iface_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_type_name(snd_ctl_event_type_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_ctl_event_type_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_type_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_mask(const snd_ctl_event_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_elem_get_mask(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_numid(const snd_ctl_event_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_elem_get_numid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_id(const snd_ctl_event_t * a_0, snd_ctl_elem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    snd_ctl_elem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_event_elem_get_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_interface(const snd_ctl_event_t * a_0) -> snd_ctl_elem_iface_t {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    snd_ctl_elem_iface_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_elem_get_interface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_device(const snd_ctl_event_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_elem_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_subdevice(const snd_ctl_event_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_elem_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_name(const snd_ctl_event_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_elem_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_elem_get_index(const snd_ctl_event_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_elem_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_alloc_space(snd_ctl_elem_list_t * a_0, unsigned int a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_alloc_space(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_free_space(snd_ctl_elem_list_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_list_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_list_free_space(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_ascii_elem_id_get(snd_ctl_elem_id_t * a_0) -> char * {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_ascii_elem_id_get(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_ascii_elem_id_parse(snd_ctl_elem_id_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_ascii_elem_id_parse(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_ascii_value_parse(snd_ctl_t * a_0, snd_ctl_elem_value_t * a_1, snd_ctl_elem_info_t * a_2, const char * a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_value_t * a_1;
    snd_ctl_elem_info_t * a_2;
    const char * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_ascii_value_parse(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_ctl_elem_id_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_malloc(snd_ctl_elem_id_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_free(snd_ctl_elem_id_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_clear(snd_ctl_elem_id_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_clear(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_copy(snd_ctl_elem_id_t * a_0, const snd_ctl_elem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    const snd_ctl_elem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_id_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_get_numid(const snd_ctl_elem_id_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_id_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_get_numid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_get_interface(const snd_ctl_elem_id_t * a_0) -> snd_ctl_elem_iface_t {
  struct __attribute__((packed)) {
    const snd_ctl_elem_id_t * a_0;
    snd_ctl_elem_iface_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_get_interface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_get_device(const snd_ctl_elem_id_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_id_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_get_subdevice(const snd_ctl_elem_id_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_id_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_get_name(const snd_ctl_elem_id_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_elem_id_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_get_index(const snd_ctl_elem_id_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_id_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_id_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_set_numid(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_id_set_numid(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_set_interface(snd_ctl_elem_id_t * a_0, snd_ctl_elem_iface_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    snd_ctl_elem_iface_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_id_set_interface(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_set_device(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_id_set_device(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_set_subdevice(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_id_set_subdevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_set_name(snd_ctl_elem_id_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_id_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_id_set_index(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_id_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_id_set_index(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_ctl_card_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_malloc(snd_ctl_card_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_card_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_free(snd_ctl_card_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_card_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_clear(snd_ctl_card_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_card_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_clear(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_copy(snd_ctl_card_info_t * a_0, const snd_ctl_card_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_card_info_t * a_0;
    const snd_ctl_card_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_card_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_get_card(const snd_ctl_card_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_card_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_get_id(const snd_ctl_card_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_card_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_get_driver(const snd_ctl_card_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_card_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_get_driver(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_get_name(const snd_ctl_card_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_card_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_get_longname(const snd_ctl_card_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_card_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_get_longname(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_get_mixername(const snd_ctl_card_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_card_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_get_mixername(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_card_info_get_components(const snd_ctl_card_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_card_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_card_info_get_components(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_ctl_event_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_malloc(snd_ctl_event_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_event_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_free(snd_ctl_event_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_event_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_clear(snd_ctl_event_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_event_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_clear(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_copy(snd_ctl_event_t * a_0, const snd_ctl_event_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_event_t * a_0;
    const snd_ctl_event_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_event_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_event_get_type(const snd_ctl_event_t * a_0) -> snd_ctl_event_type_t {
  struct __attribute__((packed)) {
    const snd_ctl_event_t * a_0;
    snd_ctl_event_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_event_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_ctl_elem_list_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_malloc(snd_ctl_elem_list_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_elem_list_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_list_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_free(snd_ctl_elem_list_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_list_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_list_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_clear(snd_ctl_elem_list_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_list_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_list_clear(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_copy(snd_ctl_elem_list_t * a_0, const snd_ctl_elem_list_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_list_t * a_0;
    const snd_ctl_elem_list_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_set_offset(snd_ctl_elem_list_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_set_offset(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_used(const snd_ctl_elem_list_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_list_get_used(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_count(const snd_ctl_elem_list_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_list_get_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_id(const snd_ctl_elem_list_t * a_0, unsigned int a_1, snd_ctl_elem_id_t * a_2) -> void {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    snd_ctl_elem_id_t * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_list_get_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_numid(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_get_numid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_interface(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> snd_ctl_elem_iface_t {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    snd_ctl_elem_iface_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_get_interface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_device(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_subdevice(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_name(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    const char * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_list_get_index(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_list_t * a_0;
    unsigned int a_1;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_list_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_ctl_elem_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_malloc(snd_ctl_elem_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_free(snd_ctl_elem_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_clear(snd_ctl_elem_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_clear(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_copy(snd_ctl_elem_info_t * a_0, const snd_ctl_elem_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    const snd_ctl_elem_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_type(const snd_ctl_elem_info_t * a_0) -> snd_ctl_elem_type_t {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    snd_ctl_elem_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_readable(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_readable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_writable(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_writable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_volatile(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_volatile(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_inactive(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_inactive(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_locked(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_locked(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_tlv_readable(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_tlv_readable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_tlv_writable(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_tlv_writable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_tlv_commandable(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_tlv_commandable(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_owner(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_owner(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_is_user(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_is_user(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_owner(const snd_ctl_elem_info_t * a_0) -> pid_t {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    pid_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_owner(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_count(const snd_ctl_elem_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_min(const snd_ctl_elem_info_t * a_0) -> long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_min(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_max(const snd_ctl_elem_info_t * a_0) -> long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_max(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_step(const snd_ctl_elem_info_t * a_0) -> long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_step(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_min64(const snd_ctl_elem_info_t * a_0) -> long long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    long long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_min64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_max64(const snd_ctl_elem_info_t * a_0) -> long long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    long long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_max64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_step64(const snd_ctl_elem_info_t * a_0) -> long long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    long long rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_step64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_items(const snd_ctl_elem_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_items(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_item(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_item(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_item_name(const snd_ctl_elem_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_item_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_dimensions(const snd_ctl_elem_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_dimensions(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_dimension(const snd_ctl_elem_info_t * a_0, unsigned int a_1) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    unsigned int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_get_dimension(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_id(const snd_ctl_elem_info_t * a_0, snd_ctl_elem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    snd_ctl_elem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_get_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_numid(const snd_ctl_elem_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_numid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_interface(const snd_ctl_elem_info_t * a_0) -> snd_ctl_elem_iface_t {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    snd_ctl_elem_iface_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_interface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_device(const snd_ctl_elem_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_subdevice(const snd_ctl_elem_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_name(const snd_ctl_elem_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_get_index(const snd_ctl_elem_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_info_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_id(snd_ctl_elem_info_t * a_0, const snd_ctl_elem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    const snd_ctl_elem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_numid(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_numid(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_interface(snd_ctl_elem_info_t * a_0, snd_ctl_elem_iface_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    snd_ctl_elem_iface_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_interface(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_device(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_device(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_subdevice(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_subdevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_name(snd_ctl_elem_info_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_info_set_index(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_info_set_index(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_add_integer_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3, long a_4, long a_5, long a_6) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_info_t * a_1;
    unsigned int a_2;
    unsigned int a_3;
    long a_4;
    long a_5;
    long a_6;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libasound_snd_ctl_add_integer_elem_set(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_add_integer64_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3, long long a_4, long long a_5, long long a_6) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_info_t * a_1;
    unsigned int a_2;
    unsigned int a_3;
    long long a_4;
    long long a_5;
    long long a_6;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  args.a_6 = a_6;
  fexthunks_libasound_snd_ctl_add_integer64_elem_set(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_add_boolean_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_info_t * a_1;
    unsigned int a_2;
    unsigned int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_add_boolean_elem_set(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_add_bytes_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_info_t * a_1;
    unsigned int a_2;
    unsigned int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_add_bytes_elem_set(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_add_integer(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int a_2, long a_3, long a_4, long a_5) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    unsigned int a_2;
    long a_3;
    long a_4;
    long a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_ctl_elem_add_integer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_add_integer64(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int a_2, long long a_3, long long a_4, long long a_5) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    unsigned int a_2;
    long long a_3;
    long long a_4;
    long long a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_ctl_elem_add_integer64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_add_boolean(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_add_boolean(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_add_iec958(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_add_iec958(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_remove(snd_ctl_t * a_0, snd_ctl_elem_id_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    snd_ctl_elem_id_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_remove(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_ctl_elem_value_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_malloc(snd_ctl_elem_value_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_free(snd_ctl_elem_value_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_clear(snd_ctl_elem_value_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_clear(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_copy(snd_ctl_elem_value_t * a_0, const snd_ctl_elem_value_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    const snd_ctl_elem_value_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_compare(snd_ctl_elem_value_t * a_0, const snd_ctl_elem_value_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    const snd_ctl_elem_value_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_compare(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_id(const snd_ctl_elem_value_t * a_0, snd_ctl_elem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    snd_ctl_elem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_get_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_numid(const snd_ctl_elem_value_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_get_numid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_interface(const snd_ctl_elem_value_t * a_0) -> snd_ctl_elem_iface_t {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    snd_ctl_elem_iface_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_get_interface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_device(const snd_ctl_elem_value_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_subdevice(const snd_ctl_elem_value_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_name(const snd_ctl_elem_value_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_index(const snd_ctl_elem_value_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_id(snd_ctl_elem_value_t * a_0, const snd_ctl_elem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    const snd_ctl_elem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_numid(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_numid(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_interface(snd_ctl_elem_value_t * a_0, snd_ctl_elem_iface_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    snd_ctl_elem_iface_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_interface(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_device(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_device(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_subdevice(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_subdevice(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_name(snd_ctl_elem_value_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_index(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_index(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_boolean(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_get_boolean(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_integer(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    long rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_get_integer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_integer64(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> long long {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    long long rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_get_integer64(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_enumerated(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_get_enumerated(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_byte(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> unsigned char {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    unsigned char rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_get_byte(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_boolean(snd_ctl_elem_value_t * a_0, unsigned int a_1, long a_2) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    long a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_value_set_boolean(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_integer(snd_ctl_elem_value_t * a_0, unsigned int a_1, long a_2) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    long a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_value_set_integer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_integer64(snd_ctl_elem_value_t * a_0, unsigned int a_1, long long a_2) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    long long a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_value_set_integer64(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_enumerated(snd_ctl_elem_value_t * a_0, unsigned int a_1, unsigned int a_2) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    unsigned int a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_value_set_enumerated(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_byte(snd_ctl_elem_value_t * a_0, unsigned int a_1, unsigned char a_2) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    unsigned int a_1;
    unsigned char a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_value_set_byte(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_set_bytes(snd_ctl_elem_value_t * a_0, void * a_1, size_t a_2) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    void * a_1;
    size_t a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_ctl_elem_set_bytes(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_bytes(const snd_ctl_elem_value_t * a_0) -> const void * {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    const void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_ctl_elem_value_get_bytes(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_get_iec958(const snd_ctl_elem_value_t * a_0, snd_aes_iec958_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_ctl_elem_value_t * a_0;
    snd_aes_iec958_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_get_iec958(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_elem_value_set_iec958(snd_ctl_elem_value_t * a_0, const snd_aes_iec958_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_ctl_elem_value_t * a_0;
    const snd_aes_iec958_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_ctl_elem_value_set_iec958(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_tlv_parse_dB_info(unsigned int * a_0, unsigned int a_1, unsigned int ** a_2) -> int {
  struct __attribute__((packed)) {
    unsigned int * a_0;
    unsigned int a_1;
    unsigned int ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_tlv_parse_dB_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_tlv_get_dB_range(unsigned int * a_0, long a_1, long a_2, long * a_3, long * a_4) -> int {
  struct __attribute__((packed)) {
    unsigned int * a_0;
    long a_1;
    long a_2;
    long * a_3;
    long * a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_tlv_get_dB_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_tlv_convert_to_dB(unsigned int * a_0, long a_1, long a_2, long a_3, long * a_4) -> int {
  struct __attribute__((packed)) {
    unsigned int * a_0;
    long a_1;
    long a_2;
    long a_3;
    long * a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_tlv_convert_to_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_tlv_convert_from_dB(unsigned int * a_0, long a_1, long a_2, long a_3, long * a_4, int a_5) -> int {
  struct __attribute__((packed)) {
    unsigned int * a_0;
    long a_1;
    long a_2;
    long a_3;
    long * a_4;
    int a_5;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libasound_snd_tlv_convert_from_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_get_dB_range(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, long * a_2, long * a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    long * a_2;
    long * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_get_dB_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_convert_to_dB(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, long a_2, long * a_3) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    long a_2;
    long * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_ctl_convert_to_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_ctl_convert_from_dB(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, long a_2, long * a_3, int a_4) -> int {
  struct __attribute__((packed)) {
    snd_ctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    long a_2;
    long * a_3;
    int a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_ctl_convert_from_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_compare_fast(const snd_hctl_elem_t * a_0, const snd_hctl_elem_t * a_1) -> int {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    const snd_hctl_elem_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_compare_fast(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_open(snd_hctl_t ** a_0, const char * a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t ** a_0;
    const char * a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hctl_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_open_ctl(snd_hctl_t ** a_0, snd_ctl_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t ** a_0;
    snd_ctl_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_open_ctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_close(snd_hctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_nonblock(snd_hctl_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_nonblock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_poll_descriptors_count(snd_hctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_poll_descriptors(snd_hctl_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hctl_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_poll_descriptors_revents(snd_hctl_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_hctl_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_get_count(snd_hctl_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_get_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_first_elem(snd_hctl_t * a_0) -> snd_hctl_elem_t * {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    snd_hctl_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_first_elem(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_last_elem(snd_hctl_t * a_0) -> snd_hctl_elem_t * {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    snd_hctl_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_last_elem(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_find_elem(snd_hctl_t * a_0, const snd_ctl_elem_id_t * a_1) -> snd_hctl_elem_t * {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    const snd_ctl_elem_id_t * a_1;
    snd_hctl_elem_t * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_find_elem(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_load(snd_hctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_load(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_free(snd_hctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_free(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_handle_events(snd_hctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_handle_events(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_name(snd_hctl_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_wait(snd_hctl_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_wait(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_ctl(snd_hctl_t * a_0) -> snd_ctl_t * {
  struct __attribute__((packed)) {
    snd_hctl_t * a_0;
    snd_ctl_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_ctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_next(snd_hctl_elem_t * a_0) -> snd_hctl_elem_t * {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    snd_hctl_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_next(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_prev(snd_hctl_elem_t * a_0) -> snd_hctl_elem_t * {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    snd_hctl_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_prev(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_info(snd_hctl_elem_t * a_0, snd_ctl_elem_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    snd_ctl_elem_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_elem_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_read(snd_hctl_elem_t * a_0, snd_ctl_elem_value_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    snd_ctl_elem_value_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_elem_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_write(snd_hctl_elem_t * a_0, snd_ctl_elem_value_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    snd_ctl_elem_value_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_elem_write(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_tlv_read(snd_hctl_elem_t * a_0, unsigned int * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    unsigned int * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_hctl_elem_tlv_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_tlv_write(snd_hctl_elem_t * a_0, const unsigned int * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    const unsigned int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_elem_tlv_write(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_tlv_command(snd_hctl_elem_t * a_0, const unsigned int * a_1) -> int {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    const unsigned int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_elem_tlv_command(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_hctl(snd_hctl_elem_t * a_0) -> snd_hctl_t * {
  struct __attribute__((packed)) {
    snd_hctl_elem_t * a_0;
    snd_hctl_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_get_hctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_id(const snd_hctl_elem_t * a_0, snd_ctl_elem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    snd_ctl_elem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_hctl_elem_get_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_numid(const snd_hctl_elem_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_get_numid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_interface(const snd_hctl_elem_t * a_0) -> snd_ctl_elem_iface_t {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    snd_ctl_elem_iface_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_get_interface(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_device(const snd_hctl_elem_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_get_device(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_subdevice(const snd_hctl_elem_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_get_subdevice(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_name(const snd_hctl_elem_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_hctl_elem_get_index(const snd_hctl_elem_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_hctl_elem_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_hctl_elem_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_sctl_build(snd_sctl_t ** a_0, snd_ctl_t * a_1, snd_config_t * a_2, snd_config_t * a_3, int a_4) -> int {
  struct __attribute__((packed)) {
    snd_sctl_t ** a_0;
    snd_ctl_t * a_1;
    snd_config_t * a_2;
    snd_config_t * a_3;
    int a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_sctl_build(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_sctl_free(snd_sctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_sctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_sctl_free(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_sctl_install(snd_sctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_sctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_sctl_install(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_sctl_remove(snd_sctl_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_sctl_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_sctl_remove(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_open(snd_mixer_t ** a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t ** a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_close(snd_mixer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_first_elem(snd_mixer_t * a_0) -> snd_mixer_elem_t * {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    snd_mixer_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_first_elem(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_last_elem(snd_mixer_t * a_0) -> snd_mixer_elem_t * {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    snd_mixer_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_last_elem(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_handle_events(snd_mixer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_handle_events(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_attach(snd_mixer_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_attach(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_attach_hctl(snd_mixer_t * a_0, snd_hctl_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    snd_hctl_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_attach_hctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_detach(snd_mixer_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_detach(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_detach_hctl(snd_mixer_t * a_0, snd_hctl_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    snd_hctl_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_detach_hctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_get_hctl(snd_mixer_t * a_0, const char * a_1, snd_hctl_t ** a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    const char * a_1;
    snd_hctl_t ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_get_hctl(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_poll_descriptors_count(snd_mixer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_poll_descriptors(snd_mixer_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_poll_descriptors_revents(snd_mixer_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_mixer_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_load(snd_mixer_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_load(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_free(snd_mixer_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_wait(snd_mixer_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_wait(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_get_count(const snd_mixer_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_mixer_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_get_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_class_unregister(snd_mixer_class_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_class_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_class_unregister(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_next(snd_mixer_elem_t * a_0) -> snd_mixer_elem_t * {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_next(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_prev(snd_mixer_elem_t * a_0) -> snd_mixer_elem_t * {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_elem_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_prev(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_get_callback_private(const snd_mixer_elem_t * a_0) -> void * {
  struct __attribute__((packed)) {
    const snd_mixer_elem_t * a_0;
    void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_get_callback_private(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_get_type(const snd_mixer_elem_t * a_0) -> snd_mixer_elem_type_t {
  struct __attribute__((packed)) {
    const snd_mixer_elem_t * a_0;
    snd_mixer_elem_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_class_register(snd_mixer_class_t * a_0, snd_mixer_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_class_t * a_0;
    snd_mixer_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_class_register(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_add(snd_mixer_elem_t * a_0, snd_mixer_class_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_class_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_elem_add(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_remove(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_remove(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_free(snd_mixer_elem_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_info(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_value(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_value(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_attach(snd_mixer_elem_t * a_0, snd_hctl_elem_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_hctl_elem_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_elem_attach(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_detach(snd_mixer_elem_t * a_0, snd_hctl_elem_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_hctl_elem_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_elem_detach(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_empty(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_empty(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_elem_get_private(const snd_mixer_elem_t * a_0) -> void * {
  struct __attribute__((packed)) {
    const snd_mixer_elem_t * a_0;
    void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_elem_get_private(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_class_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_mixer_class_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_class_malloc(snd_mixer_class_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_class_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_class_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_class_free(snd_mixer_class_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_mixer_class_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_class_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_class_copy(snd_mixer_class_t * a_0, const snd_mixer_class_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_mixer_class_t * a_0;
    const snd_mixer_class_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_class_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_channel_name(snd_mixer_selem_channel_id_t a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_mixer_selem_channel_id_t a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_channel_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_register(snd_mixer_t * a_0, struct snd_mixer_selem_regopt * a_1, snd_mixer_class_t ** a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    struct snd_mixer_selem_regopt * a_1;
    snd_mixer_class_t ** a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_register(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_id(snd_mixer_elem_t * a_0, snd_mixer_selem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_get_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_name(snd_mixer_elem_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_index(snd_mixer_elem_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_find_selem(snd_mixer_t * a_0, const snd_mixer_selem_id_t * a_1) -> snd_mixer_elem_t * {
  struct __attribute__((packed)) {
    snd_mixer_t * a_0;
    const snd_mixer_selem_id_t * a_1;
    snd_mixer_elem_t * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_find_selem(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_is_active(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_is_active(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_is_playback_mono(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_is_playback_mono(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_playback_channel(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_has_playback_channel(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_is_capture_mono(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_is_capture_mono(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_capture_channel(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_has_capture_channel(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_capture_group(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_get_capture_group(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_common_volume(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_common_volume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_playback_volume(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_playback_volume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_playback_volume_joined(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_playback_volume_joined(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_capture_volume(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_capture_volume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_capture_volume_joined(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_capture_volume_joined(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_common_switch(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_common_switch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_playback_switch(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_playback_switch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_playback_switch_joined(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_playback_switch_joined(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_capture_switch(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_capture_switch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_capture_switch_joined(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_capture_switch_joined(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_has_capture_switch_exclusive(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_has_capture_switch_exclusive(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_ask_playback_vol_dB(snd_mixer_elem_t * a_0, long a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_ask_playback_vol_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_ask_capture_vol_dB(snd_mixer_elem_t * a_0, long a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_ask_capture_vol_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_ask_playback_dB_vol(snd_mixer_elem_t * a_0, long a_1, int a_2, long * a_3) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    int a_2;
    long * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_mixer_selem_ask_playback_dB_vol(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_ask_capture_dB_vol(snd_mixer_elem_t * a_0, long a_1, int a_2, long * a_3) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    int a_2;
    long * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_mixer_selem_ask_capture_dB_vol(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_playback_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_playback_volume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_capture_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_capture_volume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_playback_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_playback_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_capture_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_capture_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_playback_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_playback_switch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_capture_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_capture_switch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_playback_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_playback_volume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_capture_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_capture_volume(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_playback_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_mixer_selem_set_playback_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_capture_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    long a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_mixer_selem_set_capture_dB(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_playback_volume_all(snd_mixer_elem_t * a_0, long a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_set_playback_volume_all(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_capture_volume_all(snd_mixer_elem_t * a_0, long a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_set_capture_volume_all(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_playback_dB_all(snd_mixer_elem_t * a_0, long a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_playback_dB_all(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_capture_dB_all(snd_mixer_elem_t * a_0, long a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_capture_dB_all(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_playback_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_playback_switch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_capture_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_capture_switch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_playback_switch_all(snd_mixer_elem_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_set_playback_switch_all(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_capture_switch_all(snd_mixer_elem_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_set_capture_switch_all(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_playback_volume_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long * a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_playback_volume_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_playback_dB_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long * a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_playback_dB_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_playback_volume_range(snd_mixer_elem_t * a_0, long a_1, long a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    long a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_playback_volume_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_capture_volume_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long * a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_capture_volume_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_capture_dB_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long * a_1;
    long * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_capture_dB_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_capture_volume_range(snd_mixer_elem_t * a_0, long a_1, long a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    long a_1;
    long a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_capture_volume_range(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_is_enumerated(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_is_enumerated(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_is_enum_playback(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_is_enum_playback(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_is_enum_capture(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_is_enum_capture(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_enum_items(snd_mixer_elem_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_get_enum_items(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_enum_item_name(snd_mixer_elem_t * a_0, unsigned int a_1, size_t a_2, char * a_3) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    unsigned int a_1;
    size_t a_2;
    char * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_mixer_selem_get_enum_item_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_get_enum_item(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, unsigned int * a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    unsigned int * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_get_enum_item(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_set_enum_item(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, unsigned int a_2) -> int {
  struct __attribute__((packed)) {
    snd_mixer_elem_t * a_0;
    snd_mixer_selem_channel_id_t a_1;
    unsigned int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_mixer_selem_set_enum_item(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_mixer_selem_id_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_malloc(snd_mixer_selem_id_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_mixer_selem_id_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_id_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_free(snd_mixer_selem_id_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_mixer_selem_id_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_id_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_copy(snd_mixer_selem_id_t * a_0, const snd_mixer_selem_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_mixer_selem_id_t * a_0;
    const snd_mixer_selem_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_id_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_get_name(const snd_mixer_selem_id_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_mixer_selem_id_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_id_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_get_index(const snd_mixer_selem_id_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_mixer_selem_id_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_mixer_selem_id_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_set_name(snd_mixer_selem_id_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_mixer_selem_id_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_id_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_set_index(snd_mixer_selem_id_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_mixer_selem_id_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_id_set_index(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_mixer_selem_id_parse(snd_mixer_selem_id_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_mixer_selem_id_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_mixer_selem_id_parse(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_open(snd_seq_t ** a_0, const char * a_1, int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t ** a_0;
    const char * a_1;
    int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_open(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_open_lconf(snd_seq_t ** a_0, const char * a_1, int a_2, int a_3, snd_config_t * a_4) -> int {
  struct __attribute__((packed)) {
    snd_seq_t ** a_0;
    const char * a_1;
    int a_2;
    int a_3;
    snd_config_t * a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_seq_open_lconf(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_name(snd_seq_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_type(snd_seq_t * a_0) -> snd_seq_type_t {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_close(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_close(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_poll_descriptors_count(snd_seq_t * a_0, short a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    short a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_poll_descriptors_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_poll_descriptors(snd_seq_t * a_0, struct pollfd * a_1, unsigned int a_2, short a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    short a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_poll_descriptors(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_poll_descriptors_revents(snd_seq_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    struct pollfd * a_1;
    unsigned int a_2;
    unsigned short * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_poll_descriptors_revents(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_nonblock(snd_seq_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_nonblock(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_id(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_output_buffer_size(snd_seq_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_get_output_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_input_buffer_size(snd_seq_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_get_input_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_output_buffer_size(snd_seq_t * a_0, size_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    size_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_output_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_input_buffer_size(snd_seq_t * a_0, size_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    size_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_input_buffer_size(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_system_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_malloc(snd_seq_system_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_system_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_free(snd_seq_system_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_system_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_copy(snd_seq_system_info_t * a_0, const snd_seq_system_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_system_info_t * a_0;
    const snd_seq_system_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_system_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_get_queues(const snd_seq_system_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_system_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_get_queues(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_get_clients(const snd_seq_system_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_system_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_get_clients(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_get_ports(const snd_seq_system_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_system_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_get_ports(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_get_channels(const snd_seq_system_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_system_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_get_channels(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_get_cur_clients(const snd_seq_system_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_system_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_get_cur_clients(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info_get_cur_queues(const snd_seq_system_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_system_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_system_info_get_cur_queues(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_system_info(snd_seq_t * a_0, snd_seq_system_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_system_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_system_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_client_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_malloc(snd_seq_client_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_client_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_free(snd_seq_client_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_copy(snd_seq_client_info_t * a_0, const snd_seq_client_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    const snd_seq_client_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_client(const snd_seq_client_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_client(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_type(const snd_seq_client_info_t * a_0) -> snd_seq_client_type_t {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    snd_seq_client_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_name(snd_seq_client_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_broadcast_filter(const snd_seq_client_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_broadcast_filter(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_error_bounce(const snd_seq_client_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_error_bounce(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_card(const snd_seq_client_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_card(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_pid(const snd_seq_client_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_pid(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_event_filter(const snd_seq_client_info_t * a_0) -> const unsigned char * {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    const unsigned char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_event_filter(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_num_ports(const snd_seq_client_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_num_ports(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_get_event_lost(const snd_seq_client_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_get_event_lost(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_set_client(snd_seq_client_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_set_client(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_set_name(snd_seq_client_info_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_set_broadcast_filter(snd_seq_client_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_set_broadcast_filter(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_set_error_bounce(snd_seq_client_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_set_error_bounce(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_set_event_filter(snd_seq_client_info_t * a_0, unsigned char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    unsigned char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_set_event_filter(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_event_filter_clear(snd_seq_client_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_info_event_filter_clear(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_event_filter_add(snd_seq_client_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_event_filter_add(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_event_filter_del(snd_seq_client_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_event_filter_del(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_info_event_filter_check(snd_seq_client_info_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_client_info_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_info_event_filter_check(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_client_info(snd_seq_t * a_0, snd_seq_client_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_client_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_get_client_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_any_client_info(snd_seq_t * a_0, int a_1, snd_seq_client_info_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_client_info_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_get_any_client_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_client_info(snd_seq_t * a_0, snd_seq_client_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_client_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_client_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_next_client(snd_seq_t * a_0, snd_seq_client_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_client_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_next_client(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_client_pool_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_malloc(snd_seq_client_pool_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_client_pool_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_free(snd_seq_client_pool_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_pool_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_copy(snd_seq_client_pool_t * a_0, const snd_seq_client_pool_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_pool_t * a_0;
    const snd_seq_client_pool_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_pool_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_get_client(const snd_seq_client_pool_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_client_pool_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_get_client(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_get_output_pool(const snd_seq_client_pool_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_seq_client_pool_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_get_output_pool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_get_input_pool(const snd_seq_client_pool_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_seq_client_pool_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_get_input_pool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_get_output_room(const snd_seq_client_pool_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_seq_client_pool_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_get_output_room(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_get_output_free(const snd_seq_client_pool_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_seq_client_pool_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_get_output_free(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_get_input_free(const snd_seq_client_pool_t * a_0) -> size_t {
  struct __attribute__((packed)) {
    const snd_seq_client_pool_t * a_0;
    size_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_client_pool_get_input_free(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_set_output_pool(snd_seq_client_pool_t * a_0, size_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_pool_t * a_0;
    size_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_pool_set_output_pool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_set_input_pool(snd_seq_client_pool_t * a_0, size_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_pool_t * a_0;
    size_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_pool_set_input_pool(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_client_pool_set_output_room(snd_seq_client_pool_t * a_0, size_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_client_pool_t * a_0;
    size_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_client_pool_set_output_room(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_client_pool(snd_seq_t * a_0, snd_seq_client_pool_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_client_pool_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_get_client_pool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_client_pool(snd_seq_t * a_0, snd_seq_client_pool_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_client_pool_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_client_pool(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_port_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_malloc(snd_seq_port_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_port_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_free(snd_seq_port_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_copy(snd_seq_port_info_t * a_0, const snd_seq_port_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    const snd_seq_port_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_client(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_client(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_port(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_addr(const snd_seq_port_info_t * a_0) -> const snd_seq_addr_t * {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    const snd_seq_addr_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_addr(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_name(const snd_seq_port_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_capability(const snd_seq_port_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_capability(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_type(const snd_seq_port_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_midi_channels(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_midi_channels(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_midi_voices(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_midi_voices(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_synth_voices(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_synth_voices(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_read_use(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_read_use(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_write_use(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_write_use(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_port_specified(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_port_specified(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_timestamping(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_timestamping(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_timestamp_real(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_timestamp_real(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_get_timestamp_queue(const snd_seq_port_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_info_get_timestamp_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_client(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_client(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_port(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_port(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_addr(snd_seq_port_info_t * a_0, const snd_seq_addr_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    const snd_seq_addr_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_addr(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_name(snd_seq_port_info_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_capability(snd_seq_port_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_capability(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_type(snd_seq_port_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_type(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_midi_channels(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_midi_channels(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_midi_voices(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_midi_voices(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_synth_voices(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_synth_voices(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_port_specified(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_port_specified(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_timestamping(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_timestamping(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_timestamp_real(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_timestamp_real(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_info_set_timestamp_queue(snd_seq_port_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_info_set_timestamp_queue(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_create_port(snd_seq_t * a_0, snd_seq_port_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_port_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_create_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_delete_port(snd_seq_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_delete_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_port_info(snd_seq_t * a_0, int a_1, snd_seq_port_info_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_port_info_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_get_port_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_any_port_info(snd_seq_t * a_0, int a_1, int a_2, snd_seq_port_info_t * a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int a_2;
    snd_seq_port_info_t * a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_get_any_port_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_port_info(snd_seq_t * a_0, int a_1, snd_seq_port_info_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_port_info_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_set_port_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_next_port(snd_seq_t * a_0, snd_seq_port_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_port_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_next_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_port_subscribe_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_malloc(snd_seq_port_subscribe_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_free(snd_seq_port_subscribe_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_copy(snd_seq_port_subscribe_t * a_0, const snd_seq_port_subscribe_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
    const snd_seq_port_subscribe_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_subscribe_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_get_sender(const snd_seq_port_subscribe_t * a_0) -> const snd_seq_addr_t * {
  struct __attribute__((packed)) {
    const snd_seq_port_subscribe_t * a_0;
    const snd_seq_addr_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_get_sender(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_get_dest(const snd_seq_port_subscribe_t * a_0) -> const snd_seq_addr_t * {
  struct __attribute__((packed)) {
    const snd_seq_port_subscribe_t * a_0;
    const snd_seq_addr_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_get_dest(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_get_queue(const snd_seq_port_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_get_exclusive(const snd_seq_port_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_get_exclusive(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_get_time_update(const snd_seq_port_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_get_time_update(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_get_time_real(const snd_seq_port_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_port_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_port_subscribe_get_time_real(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_set_sender(snd_seq_port_subscribe_t * a_0, const snd_seq_addr_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
    const snd_seq_addr_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_subscribe_set_sender(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_set_dest(snd_seq_port_subscribe_t * a_0, const snd_seq_addr_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
    const snd_seq_addr_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_subscribe_set_dest(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_set_queue(snd_seq_port_subscribe_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_subscribe_set_queue(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_set_exclusive(snd_seq_port_subscribe_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_subscribe_set_exclusive(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_set_time_update(snd_seq_port_subscribe_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_subscribe_set_time_update(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_port_subscribe_set_time_real(snd_seq_port_subscribe_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_port_subscribe_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_port_subscribe_set_time_real(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_port_subscription(snd_seq_t * a_0, snd_seq_port_subscribe_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_port_subscribe_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_get_port_subscription(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_subscribe_port(snd_seq_t * a_0, snd_seq_port_subscribe_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_port_subscribe_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_subscribe_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_unsubscribe_port(snd_seq_t * a_0, snd_seq_port_subscribe_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_port_subscribe_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_unsubscribe_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_query_subscribe_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_malloc(snd_seq_query_subscribe_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_free(snd_seq_query_subscribe_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_copy(snd_seq_query_subscribe_t * a_0, const snd_seq_query_subscribe_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t * a_0;
    const snd_seq_query_subscribe_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_subscribe_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_client(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_client(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_port(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_root(const snd_seq_query_subscribe_t * a_0) -> const snd_seq_addr_t * {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    const snd_seq_addr_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_root(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_type(const snd_seq_query_subscribe_t * a_0) -> snd_seq_query_subs_type_t {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    snd_seq_query_subs_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_index(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_index(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_num_subs(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_num_subs(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_addr(const snd_seq_query_subscribe_t * a_0) -> const snd_seq_addr_t * {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    const snd_seq_addr_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_addr(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_queue(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_exclusive(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_exclusive(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_time_update(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_time_update(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_get_time_real(const snd_seq_query_subscribe_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_query_subscribe_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_query_subscribe_get_time_real(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_set_client(snd_seq_query_subscribe_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_subscribe_set_client(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_set_port(snd_seq_query_subscribe_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_subscribe_set_port(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_set_root(snd_seq_query_subscribe_t * a_0, const snd_seq_addr_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t * a_0;
    const snd_seq_addr_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_subscribe_set_root(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_set_type(snd_seq_query_subscribe_t * a_0, snd_seq_query_subs_type_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t * a_0;
    snd_seq_query_subs_type_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_subscribe_set_type(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_subscribe_set_index(snd_seq_query_subscribe_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_query_subscribe_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_subscribe_set_index(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_port_subscribers(snd_seq_t * a_0, snd_seq_query_subscribe_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_query_subscribe_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_port_subscribers(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_queue_info_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_malloc(snd_seq_queue_info_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_queue_info_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_info_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_free(snd_seq_queue_info_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_info_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_info_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_copy(snd_seq_queue_info_t * a_0, const snd_seq_queue_info_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_info_t * a_0;
    const snd_seq_queue_info_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_info_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_get_queue(const snd_seq_queue_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_info_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_get_name(const snd_seq_queue_info_t * a_0) -> const char * {
  struct __attribute__((packed)) {
    const snd_seq_queue_info_t * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_info_get_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_get_owner(const snd_seq_queue_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_info_get_owner(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_get_locked(const snd_seq_queue_info_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_info_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_info_get_locked(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_get_flags(const snd_seq_queue_info_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_queue_info_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_info_get_flags(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_set_name(snd_seq_queue_info_t * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_info_t * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_info_set_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_set_owner(snd_seq_queue_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_info_set_owner(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_set_locked(snd_seq_queue_info_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_info_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_info_set_locked(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_info_set_flags(snd_seq_queue_info_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_info_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_info_set_flags(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_create_queue(snd_seq_t * a_0, snd_seq_queue_info_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_queue_info_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_create_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_alloc_named_queue(snd_seq_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_alloc_named_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_alloc_queue(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_alloc_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_free_queue(snd_seq_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_free_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_queue_info(snd_seq_t * a_0, int a_1, snd_seq_queue_info_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_queue_info_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_get_queue_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_queue_info(snd_seq_t * a_0, int a_1, snd_seq_queue_info_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_queue_info_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_set_queue_info(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_query_named_queue(snd_seq_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_query_named_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_queue_usage(snd_seq_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_get_queue_usage(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_queue_usage(snd_seq_t * a_0, int a_1, int a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_set_queue_usage(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_queue_status_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_malloc(snd_seq_queue_status_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_queue_status_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_status_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_free(snd_seq_queue_status_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_status_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_status_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_copy(snd_seq_queue_status_t * a_0, const snd_seq_queue_status_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_status_t * a_0;
    const snd_seq_queue_status_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_status_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_get_queue(const snd_seq_queue_status_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_status_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_status_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_get_events(const snd_seq_queue_status_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_status_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_status_get_events(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_get_tick_time(const snd_seq_queue_status_t * a_0) -> snd_seq_tick_time_t {
  struct __attribute__((packed)) {
    const snd_seq_queue_status_t * a_0;
    snd_seq_tick_time_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_status_get_tick_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_get_real_time(const snd_seq_queue_status_t * a_0) -> const snd_seq_real_time_t * {
  struct __attribute__((packed)) {
    const snd_seq_queue_status_t * a_0;
    const snd_seq_real_time_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_status_get_real_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_status_get_status(const snd_seq_queue_status_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_queue_status_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_status_get_status(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_queue_status(snd_seq_t * a_0, int a_1, snd_seq_queue_status_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_queue_status_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_get_queue_status(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_queue_tempo_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_malloc(snd_seq_queue_tempo_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_queue_tempo_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_tempo_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_free(snd_seq_queue_tempo_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_tempo_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_tempo_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_copy(snd_seq_queue_tempo_t * a_0, const snd_seq_queue_tempo_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_tempo_t * a_0;
    const snd_seq_queue_tempo_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_tempo_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_get_queue(const snd_seq_queue_tempo_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_tempo_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_tempo_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_get_tempo(const snd_seq_queue_tempo_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_queue_tempo_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_tempo_get_tempo(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_get_ppq(const snd_seq_queue_tempo_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_tempo_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_tempo_get_ppq(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_get_skew(const snd_seq_queue_tempo_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_queue_tempo_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_tempo_get_skew(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_get_skew_base(const snd_seq_queue_tempo_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_queue_tempo_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_tempo_get_skew_base(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_set_tempo(snd_seq_queue_tempo_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_tempo_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_tempo_set_tempo(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_set_ppq(snd_seq_queue_tempo_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_tempo_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_tempo_set_ppq(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_set_skew(snd_seq_queue_tempo_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_tempo_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_tempo_set_skew(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_tempo_set_skew_base(snd_seq_queue_tempo_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_tempo_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_tempo_set_skew_base(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_queue_tempo(snd_seq_t * a_0, int a_1, snd_seq_queue_tempo_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_queue_tempo_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_get_queue_tempo(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_queue_tempo(snd_seq_t * a_0, int a_1, snd_seq_queue_tempo_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_queue_tempo_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_set_queue_tempo(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_queue_timer_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_malloc(snd_seq_queue_timer_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_queue_timer_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_timer_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_free(snd_seq_queue_timer_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_timer_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_timer_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_copy(snd_seq_queue_timer_t * a_0, const snd_seq_queue_timer_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_timer_t * a_0;
    const snd_seq_queue_timer_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_timer_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_get_queue(const snd_seq_queue_timer_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_queue_timer_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_timer_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_get_type(const snd_seq_queue_timer_t * a_0) -> snd_seq_queue_timer_type_t {
  struct __attribute__((packed)) {
    const snd_seq_queue_timer_t * a_0;
    snd_seq_queue_timer_type_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_timer_get_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_get_id(const snd_seq_queue_timer_t * a_0) -> const snd_timer_id_t * {
  struct __attribute__((packed)) {
    const snd_seq_queue_timer_t * a_0;
    const snd_timer_id_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_timer_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_get_resolution(const snd_seq_queue_timer_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_queue_timer_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_queue_timer_get_resolution(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_set_type(snd_seq_queue_timer_t * a_0, snd_seq_queue_timer_type_t a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_timer_t * a_0;
    snd_seq_queue_timer_type_t a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_timer_set_type(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_set_id(snd_seq_queue_timer_t * a_0, const snd_timer_id_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_timer_t * a_0;
    const snd_timer_id_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_timer_set_id(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_queue_timer_set_resolution(snd_seq_queue_timer_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_queue_timer_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_queue_timer_set_resolution(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_queue_timer(snd_seq_t * a_0, int a_1, snd_seq_queue_timer_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_queue_timer_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_get_queue_timer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_queue_timer(snd_seq_t * a_0, int a_1, snd_seq_queue_timer_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    snd_seq_queue_timer_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_set_queue_timer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_free_event(snd_seq_event_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_event_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_free_event(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_event_length(snd_seq_event_t * a_0) -> ssize_t {
  struct __attribute__((packed)) {
    snd_seq_event_t * a_0;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_event_length(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_event_output(snd_seq_t * a_0, snd_seq_event_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_event_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_event_output(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_event_output_buffer(snd_seq_t * a_0, snd_seq_event_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_event_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_event_output_buffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_event_output_direct(snd_seq_t * a_0, snd_seq_event_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_event_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_event_output_direct(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_event_input(snd_seq_t * a_0, snd_seq_event_t ** a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_event_t ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_event_input(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_event_input_pending(snd_seq_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_event_input_pending(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_drain_output(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_drain_output(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_event_output_pending(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_event_output_pending(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_extract_output(snd_seq_t * a_0, snd_seq_event_t ** a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_event_t ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_extract_output(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_drop_output(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_drop_output(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_drop_output_buffer(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_drop_output_buffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_drop_input(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_drop_input(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_drop_input_buffer(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_drop_input_buffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_sizeof() -> size_t {
  struct __attribute__((packed)) {
    size_t rv;
  } args;
  fexthunks_libasound_snd_seq_remove_events_sizeof(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_malloc(snd_seq_remove_events_t ** a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t ** a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_malloc(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_free(snd_seq_remove_events_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_copy(snd_seq_remove_events_t * a_0, const snd_seq_remove_events_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    const snd_seq_remove_events_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_copy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_get_condition(const snd_seq_remove_events_t * a_0) -> unsigned int {
  struct __attribute__((packed)) {
    const snd_seq_remove_events_t * a_0;
    unsigned int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_get_condition(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_get_queue(const snd_seq_remove_events_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_remove_events_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_get_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_get_time(const snd_seq_remove_events_t * a_0) -> const snd_seq_timestamp_t * {
  struct __attribute__((packed)) {
    const snd_seq_remove_events_t * a_0;
    const snd_seq_timestamp_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_get_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_get_dest(const snd_seq_remove_events_t * a_0) -> const snd_seq_addr_t * {
  struct __attribute__((packed)) {
    const snd_seq_remove_events_t * a_0;
    const snd_seq_addr_t * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_get_dest(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_get_channel(const snd_seq_remove_events_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_remove_events_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_get_channel(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_get_event_type(const snd_seq_remove_events_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_remove_events_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_get_event_type(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_get_tag(const snd_seq_remove_events_t * a_0) -> int {
  struct __attribute__((packed)) {
    const snd_seq_remove_events_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_remove_events_get_tag(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_set_condition(snd_seq_remove_events_t * a_0, unsigned int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    unsigned int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_set_condition(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_set_queue(snd_seq_remove_events_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_set_queue(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_set_time(snd_seq_remove_events_t * a_0, const snd_seq_timestamp_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    const snd_seq_timestamp_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_set_time(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_set_dest(snd_seq_remove_events_t * a_0, const snd_seq_addr_t * a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    const snd_seq_addr_t * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_set_dest(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_set_channel(snd_seq_remove_events_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_set_channel(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_set_event_type(snd_seq_remove_events_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_set_event_type(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events_set_tag(snd_seq_remove_events_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_seq_remove_events_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events_set_tag(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_remove_events(snd_seq_t * a_0, snd_seq_remove_events_t * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_remove_events_t * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_remove_events(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_bit(int a_0, void * a_1) -> void {
  struct __attribute__((packed)) {
    int a_0;
    void * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_bit(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_unset_bit(int a_0, void * a_1) -> void {
  struct __attribute__((packed)) {
    int a_0;
    void * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_unset_bit(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_change_bit(int a_0, void * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    void * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_change_bit(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_get_bit(int a_0, void * a_1) -> int {
  struct __attribute__((packed)) {
    int a_0;
    void * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_get_bit(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_control_queue(snd_seq_t * a_0, int a_1, int a_2, int a_3, snd_seq_event_t * a_4) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int a_2;
    int a_3;
    snd_seq_event_t * a_4;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libasound_snd_seq_control_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_create_simple_port(snd_seq_t * a_0, const char * a_1, unsigned int a_2, unsigned int a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    const char * a_1;
    unsigned int a_2;
    unsigned int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_create_simple_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_delete_simple_port(snd_seq_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_delete_simple_port(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_connect_from(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_connect_from(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_connect_to(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_connect_to(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_disconnect_from(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_disconnect_from(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_disconnect_to(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int a_2;
    int a_3;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_seq_disconnect_to(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_client_name(snd_seq_t * a_0, const char * a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    const char * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_client_name(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_client_event_filter(snd_seq_t * a_0, int a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_client_event_filter(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_client_pool_output(snd_seq_t * a_0, size_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    size_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_client_pool_output(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_client_pool_output_room(snd_seq_t * a_0, size_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    size_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_client_pool_output_room(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_set_client_pool_input(snd_seq_t * a_0, size_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    size_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_seq_set_client_pool_input(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_sync_output_queue(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_sync_output_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_parse_address(snd_seq_t * a_0, snd_seq_addr_t * a_1, const char * a_2) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    snd_seq_addr_t * a_1;
    const char * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_seq_parse_address(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_reset_pool_output(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_reset_pool_output(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_seq_reset_pool_input(snd_seq_t * a_0) -> int {
  struct __attribute__((packed)) {
    snd_seq_t * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_seq_reset_pool_input(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_new(size_t a_0, snd_midi_event_t ** a_1) -> int {
  struct __attribute__((packed)) {
    size_t a_0;
    snd_midi_event_t ** a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_midi_event_new(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_resize_buffer(snd_midi_event_t * a_0, size_t a_1) -> int {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
    size_t a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_midi_event_resize_buffer(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_free(snd_midi_event_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_midi_event_free(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_init(snd_midi_event_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_midi_event_init(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_reset_encode(snd_midi_event_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_midi_event_reset_encode(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_reset_decode(snd_midi_event_t * a_0) -> void {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libasound_snd_midi_event_reset_decode(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_no_status(snd_midi_event_t * a_0, int a_1) -> void {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
    int a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libasound_snd_midi_event_no_status(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_encode(snd_midi_event_t * a_0, const unsigned char * a_1, long a_2, snd_seq_event_t * a_3) -> long {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
    const unsigned char * a_1;
    long a_2;
    snd_seq_event_t * a_3;
    long rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_midi_event_encode(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_encode_byte(snd_midi_event_t * a_0, int a_1, snd_seq_event_t * a_2) -> int {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
    int a_1;
    snd_seq_event_t * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libasound_snd_midi_event_encode_byte(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_snd_midi_event_decode(snd_midi_event_t * a_0, unsigned char * a_1, long a_2, const snd_seq_event_t * a_3) -> long {
  struct __attribute__((packed)) {
    snd_midi_event_t * a_0;
    unsigned char * a_1;
    long a_2;
    const snd_seq_event_t * a_3;
    long rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libasound_snd_midi_event_decode(&args);
  return args.rv;
}
}
extern "C" {
__attribute__((alias("fexfn_pack_snd_asoundlib_version"))) auto snd_asoundlib_version() -> const char *;
__attribute__((alias("fexfn_pack_snd_dlpath"))) auto snd_dlpath(char * a_0, size_t a_1, const char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_dlopen"))) auto snd_dlopen(const char * a_0, int a_1, char * a_2, size_t a_3) -> void *;
__attribute__((alias("fexfn_pack_snd_dlsym"))) auto snd_dlsym(void * a_0, const char * a_1, const char * a_2) -> void *;
__attribute__((alias("fexfn_pack_snd_dlclose"))) auto snd_dlclose(void * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_shm_area_create"))) auto snd_shm_area_create(int a_0, void * a_1) -> struct snd_shm_area *;
__attribute__((alias("fexfn_pack_snd_shm_area_share"))) auto snd_shm_area_share(struct snd_shm_area * a_0) -> struct snd_shm_area *;
__attribute__((alias("fexfn_pack_snd_shm_area_destroy"))) auto snd_shm_area_destroy(struct snd_shm_area * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_user_file"))) auto snd_user_file(const char * a_0, char ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_input_stdio_open"))) auto snd_input_stdio_open(snd_input_t ** a_0, const char * a_1, const char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_input_stdio_attach"))) auto snd_input_stdio_attach(snd_input_t ** a_0, FILE * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_input_buffer_open"))) auto snd_input_buffer_open(snd_input_t ** a_0, const char * a_1, ssize_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_input_close"))) auto snd_input_close(snd_input_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_input_gets"))) auto snd_input_gets(snd_input_t * a_0, char * a_1, size_t a_2) -> char *;
__attribute__((alias("fexfn_pack_snd_input_getc"))) auto snd_input_getc(snd_input_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_input_ungetc"))) auto snd_input_ungetc(snd_input_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_output_stdio_open"))) auto snd_output_stdio_open(snd_output_t ** a_0, const char * a_1, const char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_output_stdio_attach"))) auto snd_output_stdio_attach(snd_output_t ** a_0, FILE * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_output_buffer_open"))) auto snd_output_buffer_open(snd_output_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_output_buffer_string"))) auto snd_output_buffer_string(snd_output_t * a_0, char ** a_1) -> size_t;
__attribute__((alias("fexfn_pack_snd_output_close"))) auto snd_output_close(snd_output_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_output_puts"))) auto snd_output_puts(snd_output_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_output_putc"))) auto snd_output_putc(snd_output_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_output_flush"))) auto snd_output_flush(snd_output_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_strerror"))) auto snd_strerror(int a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_lib_error_set_handler"))) auto snd_lib_error_set_handler(snd_lib_error_handler_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_topdir"))) auto snd_config_topdir() -> const char *;
__attribute__((alias("fexfn_pack_snd_config_top"))) auto snd_config_top(snd_config_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_load"))) auto snd_config_load(snd_config_t * a_0, snd_input_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_load_override"))) auto snd_config_load_override(snd_config_t * a_0, snd_input_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_save"))) auto snd_config_save(snd_config_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_update"))) auto snd_config_update() -> int;
__attribute__((alias("fexfn_pack_snd_config_update_r"))) auto snd_config_update_r(snd_config_t ** a_0, snd_config_update_t ** a_1, const char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_config_update_free"))) auto snd_config_update_free(snd_config_update_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_update_free_global"))) auto snd_config_update_free_global() -> int;
__attribute__((alias("fexfn_pack_snd_config_update_ref"))) auto snd_config_update_ref(snd_config_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_ref"))) auto snd_config_ref(snd_config_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_config_unref"))) auto snd_config_unref(snd_config_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_config_search"))) auto snd_config_search(snd_config_t * a_0, const char * a_1, snd_config_t ** a_2) -> int;
__attribute__((alias("fexfn_pack_snd_config_search_definition"))) auto snd_config_search_definition(snd_config_t * a_0, const char * a_1, const char * a_2, snd_config_t ** a_3) -> int;
__attribute__((alias("fexfn_pack_snd_config_expand"))) auto snd_config_expand(snd_config_t * a_0, snd_config_t * a_1, const char * a_2, snd_config_t * a_3, snd_config_t ** a_4) -> int;
__attribute__((alias("fexfn_pack_snd_config_evaluate"))) auto snd_config_evaluate(snd_config_t * a_0, snd_config_t * a_1, snd_config_t * a_2, snd_config_t ** a_3) -> int;
__attribute__((alias("fexfn_pack_snd_config_add"))) auto snd_config_add(snd_config_t * a_0, snd_config_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_add_before"))) auto snd_config_add_before(snd_config_t * a_0, snd_config_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_add_after"))) auto snd_config_add_after(snd_config_t * a_0, snd_config_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_remove"))) auto snd_config_remove(snd_config_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_delete"))) auto snd_config_delete(snd_config_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_delete_compound_members"))) auto snd_config_delete_compound_members(const snd_config_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_copy"))) auto snd_config_copy(snd_config_t ** a_0, snd_config_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_make"))) auto snd_config_make(snd_config_t ** a_0, const char * a_1, snd_config_type_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_config_make_integer"))) auto snd_config_make_integer(snd_config_t ** a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_make_integer64"))) auto snd_config_make_integer64(snd_config_t ** a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_make_real"))) auto snd_config_make_real(snd_config_t ** a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_make_string"))) auto snd_config_make_string(snd_config_t ** a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_make_pointer"))) auto snd_config_make_pointer(snd_config_t ** a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_make_compound"))) auto snd_config_make_compound(snd_config_t ** a_0, const char * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_config_imake_string"))) auto snd_config_imake_string(snd_config_t ** a_0, const char * a_1, const char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_config_imake_safe_string"))) auto snd_config_imake_safe_string(snd_config_t ** a_0, const char * a_1, const char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_config_imake_pointer"))) auto snd_config_imake_pointer(snd_config_t ** a_0, const char * a_1, const void * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_type"))) auto snd_config_get_type(const snd_config_t * a_0) -> snd_config_type_t;
__attribute__((alias("fexfn_pack_snd_config_is_array"))) auto snd_config_is_array(const snd_config_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_set_id"))) auto snd_config_set_id(snd_config_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_set_integer"))) auto snd_config_set_integer(snd_config_t * a_0, long a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_set_integer64"))) auto snd_config_set_integer64(snd_config_t * a_0, long long a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_set_real"))) auto snd_config_set_real(snd_config_t * a_0, double a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_set_string"))) auto snd_config_set_string(snd_config_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_set_ascii"))) auto snd_config_set_ascii(snd_config_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_set_pointer"))) auto snd_config_set_pointer(snd_config_t * a_0, const void * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_id"))) auto snd_config_get_id(const snd_config_t * a_0, const char ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_integer"))) auto snd_config_get_integer(const snd_config_t * a_0, long * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_integer64"))) auto snd_config_get_integer64(const snd_config_t * a_0, long long * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_real"))) auto snd_config_get_real(const snd_config_t * a_0, double * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_ireal"))) auto snd_config_get_ireal(const snd_config_t * a_0, double * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_string"))) auto snd_config_get_string(const snd_config_t * a_0, const char ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_ascii"))) auto snd_config_get_ascii(const snd_config_t * a_0, char ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_pointer"))) auto snd_config_get_pointer(const snd_config_t * a_0, const void ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_test_id"))) auto snd_config_test_id(const snd_config_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_config_iterator_first"))) auto snd_config_iterator_first(const snd_config_t * a_0) -> snd_config_iterator_t;
__attribute__((alias("fexfn_pack_snd_config_iterator_end"))) auto snd_config_iterator_end(const snd_config_t * a_0) -> snd_config_iterator_t;
__attribute__((alias("fexfn_pack_snd_config_get_bool_ascii"))) auto snd_config_get_bool_ascii(const char * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_bool"))) auto snd_config_get_bool(const snd_config_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_ctl_iface_ascii"))) auto snd_config_get_ctl_iface_ascii(const char * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_config_get_ctl_iface"))) auto snd_config_get_ctl_iface(const snd_config_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_names_list"))) auto snd_names_list(const char * a_0, snd_devname_t ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_names_list_free"))) auto snd_names_list_free(snd_devname_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_open"))) auto snd_pcm_open(snd_pcm_t ** a_0, const char * a_1, snd_pcm_stream_t a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_open_lconf"))) auto snd_pcm_open_lconf(snd_pcm_t ** a_0, const char * a_1, snd_pcm_stream_t a_2, int a_3, snd_config_t * a_4) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_open_fallback"))) auto snd_pcm_open_fallback(snd_pcm_t ** a_0, snd_config_t * a_1, const char * a_2, const char * a_3, snd_pcm_stream_t a_4, int a_5) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_close"))) auto snd_pcm_close(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_name"))) auto snd_pcm_name(snd_pcm_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_type"))) auto snd_pcm_type(snd_pcm_t * a_0) -> snd_pcm_type_t;
__attribute__((alias("fexfn_pack_snd_pcm_stream"))) auto snd_pcm_stream(snd_pcm_t * a_0) -> snd_pcm_stream_t;
__attribute__((alias("fexfn_pack_snd_pcm_poll_descriptors_count"))) auto snd_pcm_poll_descriptors_count(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_poll_descriptors"))) auto snd_pcm_poll_descriptors(snd_pcm_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_poll_descriptors_revents"))) auto snd_pcm_poll_descriptors_revents(snd_pcm_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_nonblock"))) auto snd_pcm_nonblock(snd_pcm_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_async_handler_get_pcm"))) auto snd_async_handler_get_pcm(snd_async_handler_t * a_0) -> snd_pcm_t *;
__attribute__((alias("fexfn_pack_snd_pcm_info"))) auto snd_pcm_info(snd_pcm_t * a_0, snd_pcm_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_current"))) auto snd_pcm_hw_params_current(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params"))) auto snd_pcm_hw_params(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_free"))) auto snd_pcm_hw_free(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_current"))) auto snd_pcm_sw_params_current(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params"))) auto snd_pcm_sw_params(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_prepare"))) auto snd_pcm_prepare(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_reset"))) auto snd_pcm_reset(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_status"))) auto snd_pcm_status(snd_pcm_t * a_0, snd_pcm_status_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_start"))) auto snd_pcm_start(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_drop"))) auto snd_pcm_drop(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_drain"))) auto snd_pcm_drain(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_pause"))) auto snd_pcm_pause(snd_pcm_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_state"))) auto snd_pcm_state(snd_pcm_t * a_0) -> snd_pcm_state_t;
__attribute__((alias("fexfn_pack_snd_pcm_hwsync"))) auto snd_pcm_hwsync(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_delay"))) auto snd_pcm_delay(snd_pcm_t * a_0, snd_pcm_sframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_resume"))) auto snd_pcm_resume(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_htimestamp"))) auto snd_pcm_htimestamp(snd_pcm_t * a_0, snd_pcm_uframes_t * a_1, snd_htimestamp_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_avail"))) auto snd_pcm_avail(snd_pcm_t * a_0) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_avail_update"))) auto snd_pcm_avail_update(snd_pcm_t * a_0) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_avail_delay"))) auto snd_pcm_avail_delay(snd_pcm_t * a_0, snd_pcm_sframes_t * a_1, snd_pcm_sframes_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_rewindable"))) auto snd_pcm_rewindable(snd_pcm_t * a_0) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_rewind"))) auto snd_pcm_rewind(snd_pcm_t * a_0, snd_pcm_uframes_t a_1) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_forwardable"))) auto snd_pcm_forwardable(snd_pcm_t * a_0) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_forward"))) auto snd_pcm_forward(snd_pcm_t * a_0, snd_pcm_uframes_t a_1) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_writei"))) auto snd_pcm_writei(snd_pcm_t * a_0, const void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_readi"))) auto snd_pcm_readi(snd_pcm_t * a_0, void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_writen"))) auto snd_pcm_writen(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_readn"))) auto snd_pcm_readn(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_wait"))) auto snd_pcm_wait(snd_pcm_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_link"))) auto snd_pcm_link(snd_pcm_t * a_0, snd_pcm_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_unlink"))) auto snd_pcm_unlink(snd_pcm_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_query_chmaps"))) auto snd_pcm_query_chmaps(snd_pcm_t * a_0) -> snd_pcm_chmap_query_t **;
__attribute__((alias("fexfn_pack_snd_pcm_query_chmaps_from_hw"))) auto snd_pcm_query_chmaps_from_hw(int a_0, int a_1, int a_2, snd_pcm_stream_t a_3) -> snd_pcm_chmap_query_t **;
__attribute__((alias("fexfn_pack_snd_pcm_free_chmaps"))) auto snd_pcm_free_chmaps(snd_pcm_chmap_query_t ** a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_get_chmap"))) auto snd_pcm_get_chmap(snd_pcm_t * a_0) -> snd_pcm_chmap_t *;
__attribute__((alias("fexfn_pack_snd_pcm_set_chmap"))) auto snd_pcm_set_chmap(snd_pcm_t * a_0, const snd_pcm_chmap_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_chmap_type_name"))) auto snd_pcm_chmap_type_name(enum snd_pcm_chmap_type a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_chmap_name"))) auto snd_pcm_chmap_name(enum snd_pcm_chmap_position a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_chmap_long_name"))) auto snd_pcm_chmap_long_name(enum snd_pcm_chmap_position a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_chmap_print"))) auto snd_pcm_chmap_print(const snd_pcm_chmap_t * a_0, size_t a_1, char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_chmap_from_string"))) auto snd_pcm_chmap_from_string(const char * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_pcm_chmap_parse_string"))) auto snd_pcm_chmap_parse_string(const char * a_0) -> snd_pcm_chmap_t *;
__attribute__((alias("fexfn_pack_snd_pcm_recover"))) auto snd_pcm_recover(snd_pcm_t * a_0, int a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_set_params"))) auto snd_pcm_set_params(snd_pcm_t * a_0, snd_pcm_format_t a_1, snd_pcm_access_t a_2, unsigned int a_3, unsigned int a_4, int a_5, unsigned int a_6) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_get_params"))) auto snd_pcm_get_params(snd_pcm_t * a_0, snd_pcm_uframes_t * a_1, snd_pcm_uframes_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_info_sizeof"))) auto snd_pcm_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_pcm_info_malloc"))) auto snd_pcm_info_malloc(snd_pcm_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_info_free"))) auto snd_pcm_info_free(snd_pcm_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_info_copy"))) auto snd_pcm_info_copy(snd_pcm_info_t * a_0, const snd_pcm_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_device"))) auto snd_pcm_info_get_device(const snd_pcm_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_subdevice"))) auto snd_pcm_info_get_subdevice(const snd_pcm_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_stream"))) auto snd_pcm_info_get_stream(const snd_pcm_info_t * a_0) -> snd_pcm_stream_t;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_card"))) auto snd_pcm_info_get_card(const snd_pcm_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_id"))) auto snd_pcm_info_get_id(const snd_pcm_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_name"))) auto snd_pcm_info_get_name(const snd_pcm_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_subdevice_name"))) auto snd_pcm_info_get_subdevice_name(const snd_pcm_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_class"))) auto snd_pcm_info_get_class(const snd_pcm_info_t * a_0) -> snd_pcm_class_t;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_subclass"))) auto snd_pcm_info_get_subclass(const snd_pcm_info_t * a_0) -> snd_pcm_subclass_t;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_subdevices_count"))) auto snd_pcm_info_get_subdevices_count(const snd_pcm_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_subdevices_avail"))) auto snd_pcm_info_get_subdevices_avail(const snd_pcm_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_pcm_info_get_sync"))) auto snd_pcm_info_get_sync(const snd_pcm_info_t * a_0) -> snd_pcm_sync_id_t;
__attribute__((alias("fexfn_pack_snd_pcm_info_set_device"))) auto snd_pcm_info_set_device(snd_pcm_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_info_set_subdevice"))) auto snd_pcm_info_set_subdevice(snd_pcm_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_info_set_stream"))) auto snd_pcm_info_set_stream(snd_pcm_info_t * a_0, snd_pcm_stream_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_any"))) auto snd_pcm_hw_params_any(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_can_mmap_sample_resolution"))) auto snd_pcm_hw_params_can_mmap_sample_resolution(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_is_double"))) auto snd_pcm_hw_params_is_double(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_is_batch"))) auto snd_pcm_hw_params_is_batch(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_is_block_transfer"))) auto snd_pcm_hw_params_is_block_transfer(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_is_monotonic"))) auto snd_pcm_hw_params_is_monotonic(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_can_overrange"))) auto snd_pcm_hw_params_can_overrange(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_can_pause"))) auto snd_pcm_hw_params_can_pause(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_can_resume"))) auto snd_pcm_hw_params_can_resume(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_is_half_duplex"))) auto snd_pcm_hw_params_is_half_duplex(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_is_joint_duplex"))) auto snd_pcm_hw_params_is_joint_duplex(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_can_sync_start"))) auto snd_pcm_hw_params_can_sync_start(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_can_disable_period_wakeup"))) auto snd_pcm_hw_params_can_disable_period_wakeup(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_supports_audio_wallclock_ts"))) auto snd_pcm_hw_params_supports_audio_wallclock_ts(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_supports_audio_ts_type"))) auto snd_pcm_hw_params_supports_audio_ts_type(const snd_pcm_hw_params_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_rate_numden"))) auto snd_pcm_hw_params_get_rate_numden(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_sbits"))) auto snd_pcm_hw_params_get_sbits(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_fifo_size"))) auto snd_pcm_hw_params_get_fifo_size(const snd_pcm_hw_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_sizeof"))) auto snd_pcm_hw_params_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_malloc"))) auto snd_pcm_hw_params_malloc(snd_pcm_hw_params_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_free"))) auto snd_pcm_hw_params_free(snd_pcm_hw_params_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_copy"))) auto snd_pcm_hw_params_copy(snd_pcm_hw_params_t * a_0, const snd_pcm_hw_params_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_access"))) auto snd_pcm_hw_params_get_access(const snd_pcm_hw_params_t * a_0, snd_pcm_access_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_access"))) auto snd_pcm_hw_params_test_access(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_access"))) auto snd_pcm_hw_params_set_access(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_access_first"))) auto snd_pcm_hw_params_set_access_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_access_last"))) auto snd_pcm_hw_params_set_access_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_access_mask"))) auto snd_pcm_hw_params_set_access_mask(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_access_mask_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_access_mask"))) auto snd_pcm_hw_params_get_access_mask(snd_pcm_hw_params_t * a_0, snd_pcm_access_mask_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_format"))) auto snd_pcm_hw_params_get_format(const snd_pcm_hw_params_t * a_0, snd_pcm_format_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_format"))) auto snd_pcm_hw_params_test_format(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_format"))) auto snd_pcm_hw_params_set_format(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_format_first"))) auto snd_pcm_hw_params_set_format_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_format_last"))) auto snd_pcm_hw_params_set_format_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_format_mask"))) auto snd_pcm_hw_params_set_format_mask(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_format_mask_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_format_mask"))) auto snd_pcm_hw_params_get_format_mask(snd_pcm_hw_params_t * a_0, snd_pcm_format_mask_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_subformat"))) auto snd_pcm_hw_params_get_subformat(const snd_pcm_hw_params_t * a_0, snd_pcm_subformat_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_subformat"))) auto snd_pcm_hw_params_test_subformat(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_subformat"))) auto snd_pcm_hw_params_set_subformat(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_subformat_first"))) auto snd_pcm_hw_params_set_subformat_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_subformat_last"))) auto snd_pcm_hw_params_set_subformat_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_subformat_mask"))) auto snd_pcm_hw_params_set_subformat_mask(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_subformat_mask_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_subformat_mask"))) auto snd_pcm_hw_params_get_subformat_mask(snd_pcm_hw_params_t * a_0, snd_pcm_subformat_mask_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_channels"))) auto snd_pcm_hw_params_get_channels(const snd_pcm_hw_params_t * a_0, unsigned int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_channels_min"))) auto snd_pcm_hw_params_get_channels_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_channels_max"))) auto snd_pcm_hw_params_get_channels_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_channels"))) auto snd_pcm_hw_params_test_channels(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_channels"))) auto snd_pcm_hw_params_set_channels(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_channels_min"))) auto snd_pcm_hw_params_set_channels_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_channels_max"))) auto snd_pcm_hw_params_set_channels_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_channels_minmax"))) auto snd_pcm_hw_params_set_channels_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, unsigned int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_channels_near"))) auto snd_pcm_hw_params_set_channels_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_channels_first"))) auto snd_pcm_hw_params_set_channels_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_channels_last"))) auto snd_pcm_hw_params_set_channels_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_rate"))) auto snd_pcm_hw_params_get_rate(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_rate_min"))) auto snd_pcm_hw_params_get_rate_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_rate_max"))) auto snd_pcm_hw_params_get_rate_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_rate"))) auto snd_pcm_hw_params_test_rate(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate"))) auto snd_pcm_hw_params_set_rate(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate_min"))) auto snd_pcm_hw_params_set_rate_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate_max"))) auto snd_pcm_hw_params_set_rate_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate_minmax"))) auto snd_pcm_hw_params_set_rate_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate_near"))) auto snd_pcm_hw_params_set_rate_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate_first"))) auto snd_pcm_hw_params_set_rate_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate_last"))) auto snd_pcm_hw_params_set_rate_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_rate_resample"))) auto snd_pcm_hw_params_set_rate_resample(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_rate_resample"))) auto snd_pcm_hw_params_get_rate_resample(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_export_buffer"))) auto snd_pcm_hw_params_set_export_buffer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_export_buffer"))) auto snd_pcm_hw_params_get_export_buffer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_wakeup"))) auto snd_pcm_hw_params_set_period_wakeup(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_period_wakeup"))) auto snd_pcm_hw_params_get_period_wakeup(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_period_time"))) auto snd_pcm_hw_params_get_period_time(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_period_time_min"))) auto snd_pcm_hw_params_get_period_time_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_period_time_max"))) auto snd_pcm_hw_params_get_period_time_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_period_time"))) auto snd_pcm_hw_params_test_period_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_time"))) auto snd_pcm_hw_params_set_period_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_time_min"))) auto snd_pcm_hw_params_set_period_time_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_time_max"))) auto snd_pcm_hw_params_set_period_time_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_time_minmax"))) auto snd_pcm_hw_params_set_period_time_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_time_near"))) auto snd_pcm_hw_params_set_period_time_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_time_first"))) auto snd_pcm_hw_params_set_period_time_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_time_last"))) auto snd_pcm_hw_params_set_period_time_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_period_size"))) auto snd_pcm_hw_params_get_period_size(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_period_size_min"))) auto snd_pcm_hw_params_get_period_size_min(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_period_size_max"))) auto snd_pcm_hw_params_get_period_size_max(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_period_size"))) auto snd_pcm_hw_params_test_period_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size"))) auto snd_pcm_hw_params_set_period_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size_min"))) auto snd_pcm_hw_params_set_period_size_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size_max"))) auto snd_pcm_hw_params_set_period_size_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size_minmax"))) auto snd_pcm_hw_params_set_period_size_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3, snd_pcm_uframes_t * a_4, int * a_5) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size_near"))) auto snd_pcm_hw_params_set_period_size_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size_first"))) auto snd_pcm_hw_params_set_period_size_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size_last"))) auto snd_pcm_hw_params_set_period_size_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_period_size_integer"))) auto snd_pcm_hw_params_set_period_size_integer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_periods"))) auto snd_pcm_hw_params_get_periods(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_periods_min"))) auto snd_pcm_hw_params_get_periods_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_periods_max"))) auto snd_pcm_hw_params_get_periods_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_periods"))) auto snd_pcm_hw_params_test_periods(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods"))) auto snd_pcm_hw_params_set_periods(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods_min"))) auto snd_pcm_hw_params_set_periods_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods_max"))) auto snd_pcm_hw_params_set_periods_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods_minmax"))) auto snd_pcm_hw_params_set_periods_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods_near"))) auto snd_pcm_hw_params_set_periods_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods_first"))) auto snd_pcm_hw_params_set_periods_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods_last"))) auto snd_pcm_hw_params_set_periods_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_periods_integer"))) auto snd_pcm_hw_params_set_periods_integer(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_buffer_time"))) auto snd_pcm_hw_params_get_buffer_time(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_buffer_time_min"))) auto snd_pcm_hw_params_get_buffer_time_min(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_buffer_time_max"))) auto snd_pcm_hw_params_get_buffer_time_max(const snd_pcm_hw_params_t * a_0, unsigned int * a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_buffer_time"))) auto snd_pcm_hw_params_test_buffer_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_time"))) auto snd_pcm_hw_params_set_buffer_time(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_time_min"))) auto snd_pcm_hw_params_set_buffer_time_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_time_max"))) auto snd_pcm_hw_params_set_buffer_time_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_time_minmax"))) auto snd_pcm_hw_params_set_buffer_time_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3, unsigned int * a_4, int * a_5) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_time_near"))) auto snd_pcm_hw_params_set_buffer_time_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_time_first"))) auto snd_pcm_hw_params_set_buffer_time_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_time_last"))) auto snd_pcm_hw_params_set_buffer_time_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, unsigned int * a_2, int * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_buffer_size"))) auto snd_pcm_hw_params_get_buffer_size(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_buffer_size_min"))) auto snd_pcm_hw_params_get_buffer_size_min(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_buffer_size_max"))) auto snd_pcm_hw_params_get_buffer_size_max(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_test_buffer_size"))) auto snd_pcm_hw_params_test_buffer_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_size"))) auto snd_pcm_hw_params_set_buffer_size(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_size_min"))) auto snd_pcm_hw_params_set_buffer_size_min(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_size_max"))) auto snd_pcm_hw_params_set_buffer_size_max(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_size_minmax"))) auto snd_pcm_hw_params_set_buffer_size_minmax(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2, snd_pcm_uframes_t * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_size_near"))) auto snd_pcm_hw_params_set_buffer_size_near(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_size_first"))) auto snd_pcm_hw_params_set_buffer_size_first(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_set_buffer_size_last"))) auto snd_pcm_hw_params_set_buffer_size_last(snd_pcm_t * a_0, snd_pcm_hw_params_t * a_1, snd_pcm_uframes_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_get_min_align"))) auto snd_pcm_hw_params_get_min_align(const snd_pcm_hw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_sizeof"))) auto snd_pcm_sw_params_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_malloc"))) auto snd_pcm_sw_params_malloc(snd_pcm_sw_params_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_free"))) auto snd_pcm_sw_params_free(snd_pcm_sw_params_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_copy"))) auto snd_pcm_sw_params_copy(snd_pcm_sw_params_t * a_0, const snd_pcm_sw_params_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_boundary"))) auto snd_pcm_sw_params_get_boundary(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_tstamp_mode"))) auto snd_pcm_sw_params_set_tstamp_mode(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_tstamp_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_tstamp_mode"))) auto snd_pcm_sw_params_get_tstamp_mode(const snd_pcm_sw_params_t * a_0, snd_pcm_tstamp_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_tstamp_type"))) auto snd_pcm_sw_params_set_tstamp_type(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_tstamp_type_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_tstamp_type"))) auto snd_pcm_sw_params_get_tstamp_type(const snd_pcm_sw_params_t * a_0, snd_pcm_tstamp_type_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_avail_min"))) auto snd_pcm_sw_params_set_avail_min(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_avail_min"))) auto snd_pcm_sw_params_get_avail_min(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_period_event"))) auto snd_pcm_sw_params_set_period_event(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_period_event"))) auto snd_pcm_sw_params_get_period_event(const snd_pcm_sw_params_t * a_0, int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_start_threshold"))) auto snd_pcm_sw_params_set_start_threshold(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_start_threshold"))) auto snd_pcm_sw_params_get_start_threshold(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_stop_threshold"))) auto snd_pcm_sw_params_set_stop_threshold(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_stop_threshold"))) auto snd_pcm_sw_params_get_stop_threshold(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_silence_threshold"))) auto snd_pcm_sw_params_set_silence_threshold(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_silence_threshold"))) auto snd_pcm_sw_params_get_silence_threshold(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_set_silence_size"))) auto snd_pcm_sw_params_set_silence_size(snd_pcm_t * a_0, snd_pcm_sw_params_t * a_1, snd_pcm_uframes_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_get_silence_size"))) auto snd_pcm_sw_params_get_silence_size(const snd_pcm_sw_params_t * a_0, snd_pcm_uframes_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_sizeof"))) auto snd_pcm_access_mask_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_malloc"))) auto snd_pcm_access_mask_malloc(snd_pcm_access_mask_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_free"))) auto snd_pcm_access_mask_free(snd_pcm_access_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_copy"))) auto snd_pcm_access_mask_copy(snd_pcm_access_mask_t * a_0, const snd_pcm_access_mask_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_none"))) auto snd_pcm_access_mask_none(snd_pcm_access_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_any"))) auto snd_pcm_access_mask_any(snd_pcm_access_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_test"))) auto snd_pcm_access_mask_test(const snd_pcm_access_mask_t * a_0, snd_pcm_access_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_empty"))) auto snd_pcm_access_mask_empty(const snd_pcm_access_mask_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_set"))) auto snd_pcm_access_mask_set(snd_pcm_access_mask_t * a_0, snd_pcm_access_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_access_mask_reset"))) auto snd_pcm_access_mask_reset(snd_pcm_access_mask_t * a_0, snd_pcm_access_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_sizeof"))) auto snd_pcm_format_mask_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_malloc"))) auto snd_pcm_format_mask_malloc(snd_pcm_format_mask_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_free"))) auto snd_pcm_format_mask_free(snd_pcm_format_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_copy"))) auto snd_pcm_format_mask_copy(snd_pcm_format_mask_t * a_0, const snd_pcm_format_mask_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_none"))) auto snd_pcm_format_mask_none(snd_pcm_format_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_any"))) auto snd_pcm_format_mask_any(snd_pcm_format_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_test"))) auto snd_pcm_format_mask_test(const snd_pcm_format_mask_t * a_0, snd_pcm_format_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_empty"))) auto snd_pcm_format_mask_empty(const snd_pcm_format_mask_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_set"))) auto snd_pcm_format_mask_set(snd_pcm_format_mask_t * a_0, snd_pcm_format_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_format_mask_reset"))) auto snd_pcm_format_mask_reset(snd_pcm_format_mask_t * a_0, snd_pcm_format_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_sizeof"))) auto snd_pcm_subformat_mask_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_malloc"))) auto snd_pcm_subformat_mask_malloc(snd_pcm_subformat_mask_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_free"))) auto snd_pcm_subformat_mask_free(snd_pcm_subformat_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_copy"))) auto snd_pcm_subformat_mask_copy(snd_pcm_subformat_mask_t * a_0, const snd_pcm_subformat_mask_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_none"))) auto snd_pcm_subformat_mask_none(snd_pcm_subformat_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_any"))) auto snd_pcm_subformat_mask_any(snd_pcm_subformat_mask_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_test"))) auto snd_pcm_subformat_mask_test(const snd_pcm_subformat_mask_t * a_0, snd_pcm_subformat_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_empty"))) auto snd_pcm_subformat_mask_empty(const snd_pcm_subformat_mask_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_set"))) auto snd_pcm_subformat_mask_set(snd_pcm_subformat_mask_t * a_0, snd_pcm_subformat_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_mask_reset"))) auto snd_pcm_subformat_mask_reset(snd_pcm_subformat_mask_t * a_0, snd_pcm_subformat_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_sizeof"))) auto snd_pcm_status_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_pcm_status_malloc"))) auto snd_pcm_status_malloc(snd_pcm_status_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_status_free"))) auto snd_pcm_status_free(snd_pcm_status_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_copy"))) auto snd_pcm_status_copy(snd_pcm_status_t * a_0, const snd_pcm_status_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_state"))) auto snd_pcm_status_get_state(const snd_pcm_status_t * a_0) -> snd_pcm_state_t;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_trigger_tstamp"))) auto snd_pcm_status_get_trigger_tstamp(const snd_pcm_status_t * a_0, snd_timestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_trigger_htstamp"))) auto snd_pcm_status_get_trigger_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_tstamp"))) auto snd_pcm_status_get_tstamp(const snd_pcm_status_t * a_0, snd_timestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_htstamp"))) auto snd_pcm_status_get_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_audio_htstamp"))) auto snd_pcm_status_get_audio_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_driver_htstamp"))) auto snd_pcm_status_get_driver_htstamp(const snd_pcm_status_t * a_0, snd_htimestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_audio_htstamp_report"))) auto snd_pcm_status_get_audio_htstamp_report(const snd_pcm_status_t * a_0, snd_pcm_audio_tstamp_report_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_set_audio_htstamp_config"))) auto snd_pcm_status_set_audio_htstamp_config(snd_pcm_status_t * a_0, snd_pcm_audio_tstamp_config_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_delay"))) auto snd_pcm_status_get_delay(const snd_pcm_status_t * a_0) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_avail"))) auto snd_pcm_status_get_avail(const snd_pcm_status_t * a_0) -> snd_pcm_uframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_avail_max"))) auto snd_pcm_status_get_avail_max(const snd_pcm_status_t * a_0) -> snd_pcm_uframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_status_get_overrange"))) auto snd_pcm_status_get_overrange(const snd_pcm_status_t * a_0) -> snd_pcm_uframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_type_name"))) auto snd_pcm_type_name(snd_pcm_type_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_stream_name"))) auto snd_pcm_stream_name(const snd_pcm_stream_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_access_name"))) auto snd_pcm_access_name(const snd_pcm_access_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_format_name"))) auto snd_pcm_format_name(const snd_pcm_format_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_format_description"))) auto snd_pcm_format_description(const snd_pcm_format_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_name"))) auto snd_pcm_subformat_name(const snd_pcm_subformat_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_subformat_description"))) auto snd_pcm_subformat_description(const snd_pcm_subformat_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_format_value"))) auto snd_pcm_format_value(const char * a_0) -> snd_pcm_format_t;
__attribute__((alias("fexfn_pack_snd_pcm_dump"))) auto snd_pcm_dump(snd_pcm_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_dump_hw_setup"))) auto snd_pcm_dump_hw_setup(snd_pcm_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_dump_sw_setup"))) auto snd_pcm_dump_sw_setup(snd_pcm_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_dump_setup"))) auto snd_pcm_dump_setup(snd_pcm_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_hw_params_dump"))) auto snd_pcm_hw_params_dump(snd_pcm_hw_params_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_sw_params_dump"))) auto snd_pcm_sw_params_dump(snd_pcm_sw_params_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_status_dump"))) auto snd_pcm_status_dump(snd_pcm_status_t * a_0, snd_output_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_mmap_begin"))) auto snd_pcm_mmap_begin(snd_pcm_t * a_0, const snd_pcm_channel_area_t ** a_1, snd_pcm_uframes_t * a_2, snd_pcm_uframes_t * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_mmap_commit"))) auto snd_pcm_mmap_commit(snd_pcm_t * a_0, snd_pcm_uframes_t a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_mmap_writei"))) auto snd_pcm_mmap_writei(snd_pcm_t * a_0, const void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_mmap_readi"))) auto snd_pcm_mmap_readi(snd_pcm_t * a_0, void * a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_mmap_writen"))) auto snd_pcm_mmap_writen(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_mmap_readn"))) auto snd_pcm_mmap_readn(snd_pcm_t * a_0, void ** a_1, snd_pcm_uframes_t a_2) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_signed"))) auto snd_pcm_format_signed(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_unsigned"))) auto snd_pcm_format_unsigned(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_linear"))) auto snd_pcm_format_linear(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_float"))) auto snd_pcm_format_float(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_little_endian"))) auto snd_pcm_format_little_endian(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_big_endian"))) auto snd_pcm_format_big_endian(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_cpu_endian"))) auto snd_pcm_format_cpu_endian(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_width"))) auto snd_pcm_format_width(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_format_physical_width"))) auto snd_pcm_format_physical_width(snd_pcm_format_t a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_build_linear_format"))) auto snd_pcm_build_linear_format(int a_0, int a_1, int a_2, int a_3) -> snd_pcm_format_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_size"))) auto snd_pcm_format_size(snd_pcm_format_t a_0, size_t a_1) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_silence"))) auto snd_pcm_format_silence(snd_pcm_format_t a_0) -> uint8_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_silence_16"))) auto snd_pcm_format_silence_16(snd_pcm_format_t a_0) -> uint16_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_silence_32"))) auto snd_pcm_format_silence_32(snd_pcm_format_t a_0) -> uint32_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_silence_64"))) auto snd_pcm_format_silence_64(snd_pcm_format_t a_0) -> uint64_t;
__attribute__((alias("fexfn_pack_snd_pcm_format_set_silence"))) auto snd_pcm_format_set_silence(snd_pcm_format_t a_0, void * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_bytes_to_frames"))) auto snd_pcm_bytes_to_frames(snd_pcm_t * a_0, ssize_t a_1) -> snd_pcm_sframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_frames_to_bytes"))) auto snd_pcm_frames_to_bytes(snd_pcm_t * a_0, snd_pcm_sframes_t a_1) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_pcm_bytes_to_samples"))) auto snd_pcm_bytes_to_samples(snd_pcm_t * a_0, ssize_t a_1) -> long;
__attribute__((alias("fexfn_pack_snd_pcm_samples_to_bytes"))) auto snd_pcm_samples_to_bytes(snd_pcm_t * a_0, long a_1) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_pcm_area_silence"))) auto snd_pcm_area_silence(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, unsigned int a_2, snd_pcm_format_t a_3) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_areas_silence"))) auto snd_pcm_areas_silence(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, unsigned int a_2, snd_pcm_uframes_t a_3, snd_pcm_format_t a_4) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_area_copy"))) auto snd_pcm_area_copy(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, const snd_pcm_channel_area_t * a_2, snd_pcm_uframes_t a_3, unsigned int a_4, snd_pcm_format_t a_5) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_areas_copy"))) auto snd_pcm_areas_copy(const snd_pcm_channel_area_t * a_0, snd_pcm_uframes_t a_1, const snd_pcm_channel_area_t * a_2, snd_pcm_uframes_t a_3, unsigned int a_4, snd_pcm_uframes_t a_5, snd_pcm_format_t a_6) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_meter_get_bufsize"))) auto snd_pcm_meter_get_bufsize(snd_pcm_t * a_0) -> snd_pcm_uframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_meter_get_channels"))) auto snd_pcm_meter_get_channels(snd_pcm_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_pcm_meter_get_rate"))) auto snd_pcm_meter_get_rate(snd_pcm_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_pcm_meter_get_now"))) auto snd_pcm_meter_get_now(snd_pcm_t * a_0) -> snd_pcm_uframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_meter_get_boundary"))) auto snd_pcm_meter_get_boundary(snd_pcm_t * a_0) -> snd_pcm_uframes_t;
__attribute__((alias("fexfn_pack_snd_pcm_meter_add_scope"))) auto snd_pcm_meter_add_scope(snd_pcm_t * a_0, snd_pcm_scope_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_meter_search_scope"))) auto snd_pcm_meter_search_scope(snd_pcm_t * a_0, const char * a_1) -> snd_pcm_scope_t *;
__attribute__((alias("fexfn_pack_snd_pcm_scope_malloc"))) auto snd_pcm_scope_malloc(snd_pcm_scope_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_scope_set_ops"))) auto snd_pcm_scope_set_ops(snd_pcm_scope_t * a_0, const snd_pcm_scope_ops_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_scope_set_name"))) auto snd_pcm_scope_set_name(snd_pcm_scope_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_scope_get_name"))) auto snd_pcm_scope_get_name(snd_pcm_scope_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_pcm_scope_get_callback_private"))) auto snd_pcm_scope_get_callback_private(snd_pcm_scope_t * a_0) -> void *;
__attribute__((alias("fexfn_pack_snd_pcm_scope_set_callback_private"))) auto snd_pcm_scope_set_callback_private(snd_pcm_scope_t * a_0, void * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_pcm_scope_s16_open"))) auto snd_pcm_scope_s16_open(snd_pcm_t * a_0, const char * a_1, snd_pcm_scope_t ** a_2) -> int;
__attribute__((alias("fexfn_pack_snd_pcm_scope_s16_get_channel_buffer"))) auto snd_pcm_scope_s16_get_channel_buffer(snd_pcm_scope_t * a_0, unsigned int a_1) -> int16_t *;
__attribute__((alias("fexfn_pack_snd_spcm_init"))) auto snd_spcm_init(snd_pcm_t * a_0, unsigned int a_1, unsigned int a_2, snd_pcm_format_t a_3, snd_pcm_subformat_t a_4, snd_spcm_latency_t a_5, snd_pcm_access_t a_6, snd_spcm_xrun_type_t a_7) -> int;
__attribute__((alias("fexfn_pack_snd_spcm_init_duplex"))) auto snd_spcm_init_duplex(snd_pcm_t * a_0, snd_pcm_t * a_1, unsigned int a_2, unsigned int a_3, snd_pcm_format_t a_4, snd_pcm_subformat_t a_5, snd_spcm_latency_t a_6, snd_pcm_access_t a_7, snd_spcm_xrun_type_t a_8, snd_spcm_duplex_type_t a_9) -> int;
__attribute__((alias("fexfn_pack_snd_spcm_init_get_params"))) auto snd_spcm_init_get_params(snd_pcm_t * a_0, unsigned int * a_1, snd_pcm_uframes_t * a_2, snd_pcm_uframes_t * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_open"))) auto snd_rawmidi_open(snd_rawmidi_t ** a_0, snd_rawmidi_t ** a_1, const char * a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_open_lconf"))) auto snd_rawmidi_open_lconf(snd_rawmidi_t ** a_0, snd_rawmidi_t ** a_1, const char * a_2, int a_3, snd_config_t * a_4) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_close"))) auto snd_rawmidi_close(snd_rawmidi_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_poll_descriptors_count"))) auto snd_rawmidi_poll_descriptors_count(snd_rawmidi_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_poll_descriptors"))) auto snd_rawmidi_poll_descriptors(snd_rawmidi_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_poll_descriptors_revents"))) auto snd_rawmidi_poll_descriptors_revents(snd_rawmidi_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_nonblock"))) auto snd_rawmidi_nonblock(snd_rawmidi_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_sizeof"))) auto snd_rawmidi_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_malloc"))) auto snd_rawmidi_info_malloc(snd_rawmidi_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_free"))) auto snd_rawmidi_info_free(snd_rawmidi_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_copy"))) auto snd_rawmidi_info_copy(snd_rawmidi_info_t * a_0, const snd_rawmidi_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_device"))) auto snd_rawmidi_info_get_device(const snd_rawmidi_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_subdevice"))) auto snd_rawmidi_info_get_subdevice(const snd_rawmidi_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_stream"))) auto snd_rawmidi_info_get_stream(const snd_rawmidi_info_t * a_0) -> snd_rawmidi_stream_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_card"))) auto snd_rawmidi_info_get_card(const snd_rawmidi_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_flags"))) auto snd_rawmidi_info_get_flags(const snd_rawmidi_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_id"))) auto snd_rawmidi_info_get_id(const snd_rawmidi_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_name"))) auto snd_rawmidi_info_get_name(const snd_rawmidi_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_subdevice_name"))) auto snd_rawmidi_info_get_subdevice_name(const snd_rawmidi_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_subdevices_count"))) auto snd_rawmidi_info_get_subdevices_count(const snd_rawmidi_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_get_subdevices_avail"))) auto snd_rawmidi_info_get_subdevices_avail(const snd_rawmidi_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_set_device"))) auto snd_rawmidi_info_set_device(snd_rawmidi_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_set_subdevice"))) auto snd_rawmidi_info_set_subdevice(snd_rawmidi_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_info_set_stream"))) auto snd_rawmidi_info_set_stream(snd_rawmidi_info_t * a_0, snd_rawmidi_stream_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_info"))) auto snd_rawmidi_info(snd_rawmidi_t * a_0, snd_rawmidi_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_sizeof"))) auto snd_rawmidi_params_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_malloc"))) auto snd_rawmidi_params_malloc(snd_rawmidi_params_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_free"))) auto snd_rawmidi_params_free(snd_rawmidi_params_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_copy"))) auto snd_rawmidi_params_copy(snd_rawmidi_params_t * a_0, const snd_rawmidi_params_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_set_buffer_size"))) auto snd_rawmidi_params_set_buffer_size(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1, size_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_get_buffer_size"))) auto snd_rawmidi_params_get_buffer_size(const snd_rawmidi_params_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_set_avail_min"))) auto snd_rawmidi_params_set_avail_min(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1, size_t a_2) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_get_avail_min"))) auto snd_rawmidi_params_get_avail_min(const snd_rawmidi_params_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_set_no_active_sensing"))) auto snd_rawmidi_params_set_no_active_sensing(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_get_no_active_sensing"))) auto snd_rawmidi_params_get_no_active_sensing(const snd_rawmidi_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_params"))) auto snd_rawmidi_params(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_params_current"))) auto snd_rawmidi_params_current(snd_rawmidi_t * a_0, snd_rawmidi_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_status_sizeof"))) auto snd_rawmidi_status_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_status_malloc"))) auto snd_rawmidi_status_malloc(snd_rawmidi_status_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_status_free"))) auto snd_rawmidi_status_free(snd_rawmidi_status_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_status_copy"))) auto snd_rawmidi_status_copy(snd_rawmidi_status_t * a_0, const snd_rawmidi_status_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_status_get_tstamp"))) auto snd_rawmidi_status_get_tstamp(const snd_rawmidi_status_t * a_0, snd_htimestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_rawmidi_status_get_avail"))) auto snd_rawmidi_status_get_avail(const snd_rawmidi_status_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_status_get_xruns"))) auto snd_rawmidi_status_get_xruns(const snd_rawmidi_status_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_status"))) auto snd_rawmidi_status(snd_rawmidi_t * a_0, snd_rawmidi_status_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_drain"))) auto snd_rawmidi_drain(snd_rawmidi_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_drop"))) auto snd_rawmidi_drop(snd_rawmidi_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_rawmidi_write"))) auto snd_rawmidi_write(snd_rawmidi_t * a_0, const void * a_1, size_t a_2) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_read"))) auto snd_rawmidi_read(snd_rawmidi_t * a_0, void * a_1, size_t a_2) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_name"))) auto snd_rawmidi_name(snd_rawmidi_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_rawmidi_type"))) auto snd_rawmidi_type(snd_rawmidi_t * a_0) -> snd_rawmidi_type_t;
__attribute__((alias("fexfn_pack_snd_rawmidi_stream"))) auto snd_rawmidi_stream(snd_rawmidi_t * a_0) -> snd_rawmidi_stream_t;
__attribute__((alias("fexfn_pack_snd_timer_query_open"))) auto snd_timer_query_open(snd_timer_query_t ** a_0, const char * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_timer_query_open_lconf"))) auto snd_timer_query_open_lconf(snd_timer_query_t ** a_0, const char * a_1, int a_2, snd_config_t * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_timer_query_close"))) auto snd_timer_query_close(snd_timer_query_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_query_next_device"))) auto snd_timer_query_next_device(snd_timer_query_t * a_0, snd_timer_id_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_query_info"))) auto snd_timer_query_info(snd_timer_query_t * a_0, snd_timer_ginfo_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_query_params"))) auto snd_timer_query_params(snd_timer_query_t * a_0, snd_timer_gparams_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_query_status"))) auto snd_timer_query_status(snd_timer_query_t * a_0, snd_timer_gstatus_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_open"))) auto snd_timer_open(snd_timer_t ** a_0, const char * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_timer_open_lconf"))) auto snd_timer_open_lconf(snd_timer_t ** a_0, const char * a_1, int a_2, snd_config_t * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_timer_close"))) auto snd_timer_close(snd_timer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_poll_descriptors_count"))) auto snd_timer_poll_descriptors_count(snd_timer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_poll_descriptors"))) auto snd_timer_poll_descriptors(snd_timer_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_timer_poll_descriptors_revents"))) auto snd_timer_poll_descriptors_revents(snd_timer_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_timer_info"))) auto snd_timer_info(snd_timer_t * a_0, snd_timer_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params"))) auto snd_timer_params(snd_timer_t * a_0, snd_timer_params_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_status"))) auto snd_timer_status(snd_timer_t * a_0, snd_timer_status_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_start"))) auto snd_timer_start(snd_timer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_stop"))) auto snd_timer_stop(snd_timer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_continue"))) auto snd_timer_continue(snd_timer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_read"))) auto snd_timer_read(snd_timer_t * a_0, void * a_1, size_t a_2) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_timer_id_sizeof"))) auto snd_timer_id_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_timer_id_malloc"))) auto snd_timer_id_malloc(snd_timer_id_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_id_free"))) auto snd_timer_id_free(snd_timer_id_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_timer_id_copy"))) auto snd_timer_id_copy(snd_timer_id_t * a_0, const snd_timer_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_id_set_class"))) auto snd_timer_id_set_class(snd_timer_id_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_id_get_class"))) auto snd_timer_id_get_class(snd_timer_id_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_id_set_sclass"))) auto snd_timer_id_set_sclass(snd_timer_id_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_id_get_sclass"))) auto snd_timer_id_get_sclass(snd_timer_id_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_id_set_card"))) auto snd_timer_id_set_card(snd_timer_id_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_id_get_card"))) auto snd_timer_id_get_card(snd_timer_id_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_id_set_device"))) auto snd_timer_id_set_device(snd_timer_id_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_id_get_device"))) auto snd_timer_id_get_device(snd_timer_id_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_id_set_subdevice"))) auto snd_timer_id_set_subdevice(snd_timer_id_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_id_get_subdevice"))) auto snd_timer_id_get_subdevice(snd_timer_id_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_sizeof"))) auto snd_timer_ginfo_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_malloc"))) auto snd_timer_ginfo_malloc(snd_timer_ginfo_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_free"))) auto snd_timer_ginfo_free(snd_timer_ginfo_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_copy"))) auto snd_timer_ginfo_copy(snd_timer_ginfo_t * a_0, const snd_timer_ginfo_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_set_tid"))) auto snd_timer_ginfo_set_tid(snd_timer_ginfo_t * a_0, snd_timer_id_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_tid"))) auto snd_timer_ginfo_get_tid(snd_timer_ginfo_t * a_0) -> snd_timer_id_t *;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_flags"))) auto snd_timer_ginfo_get_flags(snd_timer_ginfo_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_card"))) auto snd_timer_ginfo_get_card(snd_timer_ginfo_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_id"))) auto snd_timer_ginfo_get_id(snd_timer_ginfo_t * a_0) -> char *;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_name"))) auto snd_timer_ginfo_get_name(snd_timer_ginfo_t * a_0) -> char *;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_resolution"))) auto snd_timer_ginfo_get_resolution(snd_timer_ginfo_t * a_0) -> unsigned long;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_resolution_min"))) auto snd_timer_ginfo_get_resolution_min(snd_timer_ginfo_t * a_0) -> unsigned long;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_resolution_max"))) auto snd_timer_ginfo_get_resolution_max(snd_timer_ginfo_t * a_0) -> unsigned long;
__attribute__((alias("fexfn_pack_snd_timer_ginfo_get_clients"))) auto snd_timer_ginfo_get_clients(snd_timer_ginfo_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_timer_info_sizeof"))) auto snd_timer_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_timer_info_malloc"))) auto snd_timer_info_malloc(snd_timer_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_info_free"))) auto snd_timer_info_free(snd_timer_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_timer_info_copy"))) auto snd_timer_info_copy(snd_timer_info_t * a_0, const snd_timer_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_info_is_slave"))) auto snd_timer_info_is_slave(snd_timer_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_info_get_card"))) auto snd_timer_info_get_card(snd_timer_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_info_get_id"))) auto snd_timer_info_get_id(snd_timer_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_timer_info_get_name"))) auto snd_timer_info_get_name(snd_timer_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_timer_info_get_resolution"))) auto snd_timer_info_get_resolution(snd_timer_info_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_timer_params_sizeof"))) auto snd_timer_params_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_timer_params_malloc"))) auto snd_timer_params_malloc(snd_timer_params_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params_free"))) auto snd_timer_params_free(snd_timer_params_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_timer_params_copy"))) auto snd_timer_params_copy(snd_timer_params_t * a_0, const snd_timer_params_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_params_set_auto_start"))) auto snd_timer_params_set_auto_start(snd_timer_params_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params_get_auto_start"))) auto snd_timer_params_get_auto_start(snd_timer_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params_set_exclusive"))) auto snd_timer_params_set_exclusive(snd_timer_params_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params_get_exclusive"))) auto snd_timer_params_get_exclusive(snd_timer_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params_set_early_event"))) auto snd_timer_params_set_early_event(snd_timer_params_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params_get_early_event"))) auto snd_timer_params_get_early_event(snd_timer_params_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_params_set_ticks"))) auto snd_timer_params_set_ticks(snd_timer_params_t * a_0, long a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_params_get_ticks"))) auto snd_timer_params_get_ticks(snd_timer_params_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_timer_params_set_queue_size"))) auto snd_timer_params_set_queue_size(snd_timer_params_t * a_0, long a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_params_get_queue_size"))) auto snd_timer_params_get_queue_size(snd_timer_params_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_timer_params_set_filter"))) auto snd_timer_params_set_filter(snd_timer_params_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_params_get_filter"))) auto snd_timer_params_get_filter(snd_timer_params_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_timer_status_sizeof"))) auto snd_timer_status_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_timer_status_malloc"))) auto snd_timer_status_malloc(snd_timer_status_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_timer_status_free"))) auto snd_timer_status_free(snd_timer_status_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_timer_status_copy"))) auto snd_timer_status_copy(snd_timer_status_t * a_0, const snd_timer_status_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_timer_status_get_timestamp"))) auto snd_timer_status_get_timestamp(snd_timer_status_t * a_0) -> snd_htimestamp_t;
__attribute__((alias("fexfn_pack_snd_timer_status_get_resolution"))) auto snd_timer_status_get_resolution(snd_timer_status_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_timer_status_get_lost"))) auto snd_timer_status_get_lost(snd_timer_status_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_timer_status_get_overrun"))) auto snd_timer_status_get_overrun(snd_timer_status_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_timer_status_get_queue"))) auto snd_timer_status_get_queue(snd_timer_status_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_timer_info_get_ticks"))) auto snd_timer_info_get_ticks(snd_timer_info_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_hwdep_open"))) auto snd_hwdep_open(snd_hwdep_t ** a_0, const char * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_close"))) auto snd_hwdep_close(snd_hwdep_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_poll_descriptors"))) auto snd_hwdep_poll_descriptors(snd_hwdep_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_poll_descriptors_count"))) auto snd_hwdep_poll_descriptors_count(snd_hwdep_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_poll_descriptors_revents"))) auto snd_hwdep_poll_descriptors_revents(snd_hwdep_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_nonblock"))) auto snd_hwdep_nonblock(snd_hwdep_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_info"))) auto snd_hwdep_info(snd_hwdep_t * a_0, snd_hwdep_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status"))) auto snd_hwdep_dsp_status(snd_hwdep_t * a_0, snd_hwdep_dsp_status_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_load"))) auto snd_hwdep_dsp_load(snd_hwdep_t * a_0, snd_hwdep_dsp_image_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_ioctl"))) auto snd_hwdep_ioctl(snd_hwdep_t * a_0, unsigned int a_1, void * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_write"))) auto snd_hwdep_write(snd_hwdep_t * a_0, const void * a_1, size_t a_2) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_hwdep_read"))) auto snd_hwdep_read(snd_hwdep_t * a_0, void * a_1, size_t a_2) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_hwdep_info_sizeof"))) auto snd_hwdep_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_hwdep_info_malloc"))) auto snd_hwdep_info_malloc(snd_hwdep_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_info_free"))) auto snd_hwdep_info_free(snd_hwdep_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_info_copy"))) auto snd_hwdep_info_copy(snd_hwdep_info_t * a_0, const snd_hwdep_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_info_get_device"))) auto snd_hwdep_info_get_device(const snd_hwdep_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hwdep_info_get_card"))) auto snd_hwdep_info_get_card(const snd_hwdep_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_info_get_id"))) auto snd_hwdep_info_get_id(const snd_hwdep_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_hwdep_info_get_name"))) auto snd_hwdep_info_get_name(const snd_hwdep_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_hwdep_info_get_iface"))) auto snd_hwdep_info_get_iface(const snd_hwdep_info_t * a_0) -> snd_hwdep_iface_t;
__attribute__((alias("fexfn_pack_snd_hwdep_info_set_device"))) auto snd_hwdep_info_set_device(snd_hwdep_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_sizeof"))) auto snd_hwdep_dsp_status_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_malloc"))) auto snd_hwdep_dsp_status_malloc(snd_hwdep_dsp_status_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_free"))) auto snd_hwdep_dsp_status_free(snd_hwdep_dsp_status_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_copy"))) auto snd_hwdep_dsp_status_copy(snd_hwdep_dsp_status_t * a_0, const snd_hwdep_dsp_status_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_get_version"))) auto snd_hwdep_dsp_status_get_version(const snd_hwdep_dsp_status_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_get_id"))) auto snd_hwdep_dsp_status_get_id(const snd_hwdep_dsp_status_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_get_num_dsps"))) auto snd_hwdep_dsp_status_get_num_dsps(const snd_hwdep_dsp_status_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_get_dsp_loaded"))) auto snd_hwdep_dsp_status_get_dsp_loaded(const snd_hwdep_dsp_status_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_status_get_chip_ready"))) auto snd_hwdep_dsp_status_get_chip_ready(const snd_hwdep_dsp_status_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_sizeof"))) auto snd_hwdep_dsp_image_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_malloc"))) auto snd_hwdep_dsp_image_malloc(snd_hwdep_dsp_image_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_free"))) auto snd_hwdep_dsp_image_free(snd_hwdep_dsp_image_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_copy"))) auto snd_hwdep_dsp_image_copy(snd_hwdep_dsp_image_t * a_0, const snd_hwdep_dsp_image_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_get_index"))) auto snd_hwdep_dsp_image_get_index(const snd_hwdep_dsp_image_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_get_name"))) auto snd_hwdep_dsp_image_get_name(const snd_hwdep_dsp_image_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_get_image"))) auto snd_hwdep_dsp_image_get_image(const snd_hwdep_dsp_image_t * a_0) -> const void *;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_get_length"))) auto snd_hwdep_dsp_image_get_length(const snd_hwdep_dsp_image_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_set_index"))) auto snd_hwdep_dsp_image_set_index(snd_hwdep_dsp_image_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_set_name"))) auto snd_hwdep_dsp_image_set_name(snd_hwdep_dsp_image_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_set_image"))) auto snd_hwdep_dsp_image_set_image(snd_hwdep_dsp_image_t * a_0, void * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hwdep_dsp_image_set_length"))) auto snd_hwdep_dsp_image_set_length(snd_hwdep_dsp_image_t * a_0, size_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_card_load"))) auto snd_card_load(int a_0) -> int;
__attribute__((alias("fexfn_pack_snd_card_next"))) auto snd_card_next(int * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_card_get_index"))) auto snd_card_get_index(const char * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_card_get_name"))) auto snd_card_get_name(int a_0, char ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_card_get_longname"))) auto snd_card_get_longname(int a_0, char ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_device_name_hint"))) auto snd_device_name_hint(int a_0, const char * a_1, void *** a_2) -> int;
__attribute__((alias("fexfn_pack_snd_device_name_free_hint"))) auto snd_device_name_free_hint(void ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_device_name_get_hint"))) auto snd_device_name_get_hint(const void * a_0, const char * a_1) -> char *;
__attribute__((alias("fexfn_pack_snd_ctl_open"))) auto snd_ctl_open(snd_ctl_t ** a_0, const char * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_open_lconf"))) auto snd_ctl_open_lconf(snd_ctl_t ** a_0, const char * a_1, int a_2, snd_config_t * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_open_fallback"))) auto snd_ctl_open_fallback(snd_ctl_t ** a_0, snd_config_t * a_1, const char * a_2, const char * a_3, int a_4) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_close"))) auto snd_ctl_close(snd_ctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_nonblock"))) auto snd_ctl_nonblock(snd_ctl_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_poll_descriptors_count"))) auto snd_ctl_poll_descriptors_count(snd_ctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_poll_descriptors"))) auto snd_ctl_poll_descriptors(snd_ctl_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_poll_descriptors_revents"))) auto snd_ctl_poll_descriptors_revents(snd_ctl_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_subscribe_events"))) auto snd_ctl_subscribe_events(snd_ctl_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_card_info"))) auto snd_ctl_card_info(snd_ctl_t * a_0, snd_ctl_card_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list"))) auto snd_ctl_elem_list(snd_ctl_t * a_0, snd_ctl_elem_list_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info"))) auto snd_ctl_elem_info(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_read"))) auto snd_ctl_elem_read(snd_ctl_t * a_0, snd_ctl_elem_value_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_write"))) auto snd_ctl_elem_write(snd_ctl_t * a_0, snd_ctl_elem_value_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_lock"))) auto snd_ctl_elem_lock(snd_ctl_t * a_0, snd_ctl_elem_id_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_unlock"))) auto snd_ctl_elem_unlock(snd_ctl_t * a_0, snd_ctl_elem_id_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_tlv_read"))) auto snd_ctl_elem_tlv_read(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int * a_2, unsigned int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_tlv_write"))) auto snd_ctl_elem_tlv_write(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, const unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_tlv_command"))) auto snd_ctl_elem_tlv_command(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, const unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_hwdep_next_device"))) auto snd_ctl_hwdep_next_device(snd_ctl_t * a_0, int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_hwdep_info"))) auto snd_ctl_hwdep_info(snd_ctl_t * a_0, snd_hwdep_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_pcm_next_device"))) auto snd_ctl_pcm_next_device(snd_ctl_t * a_0, int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_pcm_info"))) auto snd_ctl_pcm_info(snd_ctl_t * a_0, snd_pcm_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_pcm_prefer_subdevice"))) auto snd_ctl_pcm_prefer_subdevice(snd_ctl_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_rawmidi_next_device"))) auto snd_ctl_rawmidi_next_device(snd_ctl_t * a_0, int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_rawmidi_info"))) auto snd_ctl_rawmidi_info(snd_ctl_t * a_0, snd_rawmidi_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_rawmidi_prefer_subdevice"))) auto snd_ctl_rawmidi_prefer_subdevice(snd_ctl_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_set_power_state"))) auto snd_ctl_set_power_state(snd_ctl_t * a_0, unsigned int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_get_power_state"))) auto snd_ctl_get_power_state(snd_ctl_t * a_0, unsigned int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_read"))) auto snd_ctl_read(snd_ctl_t * a_0, snd_ctl_event_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_wait"))) auto snd_ctl_wait(snd_ctl_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_name"))) auto snd_ctl_name(snd_ctl_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_type"))) auto snd_ctl_type(snd_ctl_t * a_0) -> snd_ctl_type_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_type_name"))) auto snd_ctl_elem_type_name(snd_ctl_elem_type_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_elem_iface_name"))) auto snd_ctl_elem_iface_name(snd_ctl_elem_iface_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_event_type_name"))) auto snd_ctl_event_type_name(snd_ctl_event_type_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_mask"))) auto snd_ctl_event_elem_get_mask(const snd_ctl_event_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_numid"))) auto snd_ctl_event_elem_get_numid(const snd_ctl_event_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_id"))) auto snd_ctl_event_elem_get_id(const snd_ctl_event_t * a_0, snd_ctl_elem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_interface"))) auto snd_ctl_event_elem_get_interface(const snd_ctl_event_t * a_0) -> snd_ctl_elem_iface_t;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_device"))) auto snd_ctl_event_elem_get_device(const snd_ctl_event_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_subdevice"))) auto snd_ctl_event_elem_get_subdevice(const snd_ctl_event_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_name"))) auto snd_ctl_event_elem_get_name(const snd_ctl_event_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_event_elem_get_index"))) auto snd_ctl_event_elem_get_index(const snd_ctl_event_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_alloc_space"))) auto snd_ctl_elem_list_alloc_space(snd_ctl_elem_list_t * a_0, unsigned int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_free_space"))) auto snd_ctl_elem_list_free_space(snd_ctl_elem_list_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_ascii_elem_id_get"))) auto snd_ctl_ascii_elem_id_get(snd_ctl_elem_id_t * a_0) -> char *;
__attribute__((alias("fexfn_pack_snd_ctl_ascii_elem_id_parse"))) auto snd_ctl_ascii_elem_id_parse(snd_ctl_elem_id_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_ascii_value_parse"))) auto snd_ctl_ascii_value_parse(snd_ctl_t * a_0, snd_ctl_elem_value_t * a_1, snd_ctl_elem_info_t * a_2, const char * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_sizeof"))) auto snd_ctl_elem_id_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_malloc"))) auto snd_ctl_elem_id_malloc(snd_ctl_elem_id_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_free"))) auto snd_ctl_elem_id_free(snd_ctl_elem_id_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_clear"))) auto snd_ctl_elem_id_clear(snd_ctl_elem_id_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_copy"))) auto snd_ctl_elem_id_copy(snd_ctl_elem_id_t * a_0, const snd_ctl_elem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_get_numid"))) auto snd_ctl_elem_id_get_numid(const snd_ctl_elem_id_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_get_interface"))) auto snd_ctl_elem_id_get_interface(const snd_ctl_elem_id_t * a_0) -> snd_ctl_elem_iface_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_get_device"))) auto snd_ctl_elem_id_get_device(const snd_ctl_elem_id_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_get_subdevice"))) auto snd_ctl_elem_id_get_subdevice(const snd_ctl_elem_id_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_get_name"))) auto snd_ctl_elem_id_get_name(const snd_ctl_elem_id_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_get_index"))) auto snd_ctl_elem_id_get_index(const snd_ctl_elem_id_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_set_numid"))) auto snd_ctl_elem_id_set_numid(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_set_interface"))) auto snd_ctl_elem_id_set_interface(snd_ctl_elem_id_t * a_0, snd_ctl_elem_iface_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_set_device"))) auto snd_ctl_elem_id_set_device(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_set_subdevice"))) auto snd_ctl_elem_id_set_subdevice(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_set_name"))) auto snd_ctl_elem_id_set_name(snd_ctl_elem_id_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_id_set_index"))) auto snd_ctl_elem_id_set_index(snd_ctl_elem_id_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_sizeof"))) auto snd_ctl_card_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_malloc"))) auto snd_ctl_card_info_malloc(snd_ctl_card_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_free"))) auto snd_ctl_card_info_free(snd_ctl_card_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_clear"))) auto snd_ctl_card_info_clear(snd_ctl_card_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_copy"))) auto snd_ctl_card_info_copy(snd_ctl_card_info_t * a_0, const snd_ctl_card_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_get_card"))) auto snd_ctl_card_info_get_card(const snd_ctl_card_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_get_id"))) auto snd_ctl_card_info_get_id(const snd_ctl_card_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_get_driver"))) auto snd_ctl_card_info_get_driver(const snd_ctl_card_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_get_name"))) auto snd_ctl_card_info_get_name(const snd_ctl_card_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_get_longname"))) auto snd_ctl_card_info_get_longname(const snd_ctl_card_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_get_mixername"))) auto snd_ctl_card_info_get_mixername(const snd_ctl_card_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_card_info_get_components"))) auto snd_ctl_card_info_get_components(const snd_ctl_card_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_event_sizeof"))) auto snd_ctl_event_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_ctl_event_malloc"))) auto snd_ctl_event_malloc(snd_ctl_event_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_event_free"))) auto snd_ctl_event_free(snd_ctl_event_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_event_clear"))) auto snd_ctl_event_clear(snd_ctl_event_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_event_copy"))) auto snd_ctl_event_copy(snd_ctl_event_t * a_0, const snd_ctl_event_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_event_get_type"))) auto snd_ctl_event_get_type(const snd_ctl_event_t * a_0) -> snd_ctl_event_type_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_sizeof"))) auto snd_ctl_elem_list_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_malloc"))) auto snd_ctl_elem_list_malloc(snd_ctl_elem_list_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_free"))) auto snd_ctl_elem_list_free(snd_ctl_elem_list_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_clear"))) auto snd_ctl_elem_list_clear(snd_ctl_elem_list_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_copy"))) auto snd_ctl_elem_list_copy(snd_ctl_elem_list_t * a_0, const snd_ctl_elem_list_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_set_offset"))) auto snd_ctl_elem_list_set_offset(snd_ctl_elem_list_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_used"))) auto snd_ctl_elem_list_get_used(const snd_ctl_elem_list_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_count"))) auto snd_ctl_elem_list_get_count(const snd_ctl_elem_list_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_id"))) auto snd_ctl_elem_list_get_id(const snd_ctl_elem_list_t * a_0, unsigned int a_1, snd_ctl_elem_id_t * a_2) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_numid"))) auto snd_ctl_elem_list_get_numid(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_interface"))) auto snd_ctl_elem_list_get_interface(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> snd_ctl_elem_iface_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_device"))) auto snd_ctl_elem_list_get_device(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_subdevice"))) auto snd_ctl_elem_list_get_subdevice(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_name"))) auto snd_ctl_elem_list_get_name(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_elem_list_get_index"))) auto snd_ctl_elem_list_get_index(const snd_ctl_elem_list_t * a_0, unsigned int a_1) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_sizeof"))) auto snd_ctl_elem_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_malloc"))) auto snd_ctl_elem_info_malloc(snd_ctl_elem_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_free"))) auto snd_ctl_elem_info_free(snd_ctl_elem_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_clear"))) auto snd_ctl_elem_info_clear(snd_ctl_elem_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_copy"))) auto snd_ctl_elem_info_copy(snd_ctl_elem_info_t * a_0, const snd_ctl_elem_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_type"))) auto snd_ctl_elem_info_get_type(const snd_ctl_elem_info_t * a_0) -> snd_ctl_elem_type_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_readable"))) auto snd_ctl_elem_info_is_readable(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_writable"))) auto snd_ctl_elem_info_is_writable(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_volatile"))) auto snd_ctl_elem_info_is_volatile(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_inactive"))) auto snd_ctl_elem_info_is_inactive(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_locked"))) auto snd_ctl_elem_info_is_locked(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_tlv_readable"))) auto snd_ctl_elem_info_is_tlv_readable(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_tlv_writable"))) auto snd_ctl_elem_info_is_tlv_writable(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_tlv_commandable"))) auto snd_ctl_elem_info_is_tlv_commandable(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_owner"))) auto snd_ctl_elem_info_is_owner(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_is_user"))) auto snd_ctl_elem_info_is_user(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_owner"))) auto snd_ctl_elem_info_get_owner(const snd_ctl_elem_info_t * a_0) -> pid_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_count"))) auto snd_ctl_elem_info_get_count(const snd_ctl_elem_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_min"))) auto snd_ctl_elem_info_get_min(const snd_ctl_elem_info_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_max"))) auto snd_ctl_elem_info_get_max(const snd_ctl_elem_info_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_step"))) auto snd_ctl_elem_info_get_step(const snd_ctl_elem_info_t * a_0) -> long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_min64"))) auto snd_ctl_elem_info_get_min64(const snd_ctl_elem_info_t * a_0) -> long long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_max64"))) auto snd_ctl_elem_info_get_max64(const snd_ctl_elem_info_t * a_0) -> long long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_step64"))) auto snd_ctl_elem_info_get_step64(const snd_ctl_elem_info_t * a_0) -> long long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_items"))) auto snd_ctl_elem_info_get_items(const snd_ctl_elem_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_item"))) auto snd_ctl_elem_info_set_item(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_item_name"))) auto snd_ctl_elem_info_get_item_name(const snd_ctl_elem_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_dimensions"))) auto snd_ctl_elem_info_get_dimensions(const snd_ctl_elem_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_dimension"))) auto snd_ctl_elem_info_get_dimension(const snd_ctl_elem_info_t * a_0, unsigned int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_id"))) auto snd_ctl_elem_info_get_id(const snd_ctl_elem_info_t * a_0, snd_ctl_elem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_numid"))) auto snd_ctl_elem_info_get_numid(const snd_ctl_elem_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_interface"))) auto snd_ctl_elem_info_get_interface(const snd_ctl_elem_info_t * a_0) -> snd_ctl_elem_iface_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_device"))) auto snd_ctl_elem_info_get_device(const snd_ctl_elem_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_subdevice"))) auto snd_ctl_elem_info_get_subdevice(const snd_ctl_elem_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_name"))) auto snd_ctl_elem_info_get_name(const snd_ctl_elem_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_get_index"))) auto snd_ctl_elem_info_get_index(const snd_ctl_elem_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_id"))) auto snd_ctl_elem_info_set_id(snd_ctl_elem_info_t * a_0, const snd_ctl_elem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_numid"))) auto snd_ctl_elem_info_set_numid(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_interface"))) auto snd_ctl_elem_info_set_interface(snd_ctl_elem_info_t * a_0, snd_ctl_elem_iface_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_device"))) auto snd_ctl_elem_info_set_device(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_subdevice"))) auto snd_ctl_elem_info_set_subdevice(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_name"))) auto snd_ctl_elem_info_set_name(snd_ctl_elem_info_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_info_set_index"))) auto snd_ctl_elem_info_set_index(snd_ctl_elem_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_add_integer_elem_set"))) auto snd_ctl_add_integer_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3, long a_4, long a_5, long a_6) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_add_integer64_elem_set"))) auto snd_ctl_add_integer64_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3, long long a_4, long long a_5, long long a_6) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_add_boolean_elem_set"))) auto snd_ctl_add_boolean_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_add_bytes_elem_set"))) auto snd_ctl_add_bytes_elem_set(snd_ctl_t * a_0, snd_ctl_elem_info_t * a_1, unsigned int a_2, unsigned int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_add_integer"))) auto snd_ctl_elem_add_integer(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int a_2, long a_3, long a_4, long a_5) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_add_integer64"))) auto snd_ctl_elem_add_integer64(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int a_2, long long a_3, long long a_4, long long a_5) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_add_boolean"))) auto snd_ctl_elem_add_boolean(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_add_iec958"))) auto snd_ctl_elem_add_iec958(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_remove"))) auto snd_ctl_elem_remove(snd_ctl_t * a_0, snd_ctl_elem_id_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_sizeof"))) auto snd_ctl_elem_value_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_malloc"))) auto snd_ctl_elem_value_malloc(snd_ctl_elem_value_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_free"))) auto snd_ctl_elem_value_free(snd_ctl_elem_value_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_clear"))) auto snd_ctl_elem_value_clear(snd_ctl_elem_value_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_copy"))) auto snd_ctl_elem_value_copy(snd_ctl_elem_value_t * a_0, const snd_ctl_elem_value_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_compare"))) auto snd_ctl_elem_value_compare(snd_ctl_elem_value_t * a_0, const snd_ctl_elem_value_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_id"))) auto snd_ctl_elem_value_get_id(const snd_ctl_elem_value_t * a_0, snd_ctl_elem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_numid"))) auto snd_ctl_elem_value_get_numid(const snd_ctl_elem_value_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_interface"))) auto snd_ctl_elem_value_get_interface(const snd_ctl_elem_value_t * a_0) -> snd_ctl_elem_iface_t;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_device"))) auto snd_ctl_elem_value_get_device(const snd_ctl_elem_value_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_subdevice"))) auto snd_ctl_elem_value_get_subdevice(const snd_ctl_elem_value_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_name"))) auto snd_ctl_elem_value_get_name(const snd_ctl_elem_value_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_index"))) auto snd_ctl_elem_value_get_index(const snd_ctl_elem_value_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_id"))) auto snd_ctl_elem_value_set_id(snd_ctl_elem_value_t * a_0, const snd_ctl_elem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_numid"))) auto snd_ctl_elem_value_set_numid(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_interface"))) auto snd_ctl_elem_value_set_interface(snd_ctl_elem_value_t * a_0, snd_ctl_elem_iface_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_device"))) auto snd_ctl_elem_value_set_device(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_subdevice"))) auto snd_ctl_elem_value_set_subdevice(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_name"))) auto snd_ctl_elem_value_set_name(snd_ctl_elem_value_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_index"))) auto snd_ctl_elem_value_set_index(snd_ctl_elem_value_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_boolean"))) auto snd_ctl_elem_value_get_boolean(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_integer"))) auto snd_ctl_elem_value_get_integer(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_integer64"))) auto snd_ctl_elem_value_get_integer64(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> long long;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_enumerated"))) auto snd_ctl_elem_value_get_enumerated(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_byte"))) auto snd_ctl_elem_value_get_byte(const snd_ctl_elem_value_t * a_0, unsigned int a_1) -> unsigned char;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_boolean"))) auto snd_ctl_elem_value_set_boolean(snd_ctl_elem_value_t * a_0, unsigned int a_1, long a_2) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_integer"))) auto snd_ctl_elem_value_set_integer(snd_ctl_elem_value_t * a_0, unsigned int a_1, long a_2) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_integer64"))) auto snd_ctl_elem_value_set_integer64(snd_ctl_elem_value_t * a_0, unsigned int a_1, long long a_2) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_enumerated"))) auto snd_ctl_elem_value_set_enumerated(snd_ctl_elem_value_t * a_0, unsigned int a_1, unsigned int a_2) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_byte"))) auto snd_ctl_elem_value_set_byte(snd_ctl_elem_value_t * a_0, unsigned int a_1, unsigned char a_2) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_set_bytes"))) auto snd_ctl_elem_set_bytes(snd_ctl_elem_value_t * a_0, void * a_1, size_t a_2) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_bytes"))) auto snd_ctl_elem_value_get_bytes(const snd_ctl_elem_value_t * a_0) -> const void *;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_get_iec958"))) auto snd_ctl_elem_value_get_iec958(const snd_ctl_elem_value_t * a_0, snd_aes_iec958_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_ctl_elem_value_set_iec958"))) auto snd_ctl_elem_value_set_iec958(snd_ctl_elem_value_t * a_0, const snd_aes_iec958_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_tlv_parse_dB_info"))) auto snd_tlv_parse_dB_info(unsigned int * a_0, unsigned int a_1, unsigned int ** a_2) -> int;
__attribute__((alias("fexfn_pack_snd_tlv_get_dB_range"))) auto snd_tlv_get_dB_range(unsigned int * a_0, long a_1, long a_2, long * a_3, long * a_4) -> int;
__attribute__((alias("fexfn_pack_snd_tlv_convert_to_dB"))) auto snd_tlv_convert_to_dB(unsigned int * a_0, long a_1, long a_2, long a_3, long * a_4) -> int;
__attribute__((alias("fexfn_pack_snd_tlv_convert_from_dB"))) auto snd_tlv_convert_from_dB(unsigned int * a_0, long a_1, long a_2, long a_3, long * a_4, int a_5) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_get_dB_range"))) auto snd_ctl_get_dB_range(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, long * a_2, long * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_convert_to_dB"))) auto snd_ctl_convert_to_dB(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, long a_2, long * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_ctl_convert_from_dB"))) auto snd_ctl_convert_from_dB(snd_ctl_t * a_0, const snd_ctl_elem_id_t * a_1, long a_2, long * a_3, int a_4) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_compare_fast"))) auto snd_hctl_compare_fast(const snd_hctl_elem_t * a_0, const snd_hctl_elem_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_open"))) auto snd_hctl_open(snd_hctl_t ** a_0, const char * a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_open_ctl"))) auto snd_hctl_open_ctl(snd_hctl_t ** a_0, snd_ctl_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_close"))) auto snd_hctl_close(snd_hctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_nonblock"))) auto snd_hctl_nonblock(snd_hctl_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_poll_descriptors_count"))) auto snd_hctl_poll_descriptors_count(snd_hctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_poll_descriptors"))) auto snd_hctl_poll_descriptors(snd_hctl_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_poll_descriptors_revents"))) auto snd_hctl_poll_descriptors_revents(snd_hctl_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_get_count"))) auto snd_hctl_get_count(snd_hctl_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hctl_first_elem"))) auto snd_hctl_first_elem(snd_hctl_t * a_0) -> snd_hctl_elem_t *;
__attribute__((alias("fexfn_pack_snd_hctl_last_elem"))) auto snd_hctl_last_elem(snd_hctl_t * a_0) -> snd_hctl_elem_t *;
__attribute__((alias("fexfn_pack_snd_hctl_find_elem"))) auto snd_hctl_find_elem(snd_hctl_t * a_0, const snd_ctl_elem_id_t * a_1) -> snd_hctl_elem_t *;
__attribute__((alias("fexfn_pack_snd_hctl_load"))) auto snd_hctl_load(snd_hctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_free"))) auto snd_hctl_free(snd_hctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_handle_events"))) auto snd_hctl_handle_events(snd_hctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_name"))) auto snd_hctl_name(snd_hctl_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_hctl_wait"))) auto snd_hctl_wait(snd_hctl_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_ctl"))) auto snd_hctl_ctl(snd_hctl_t * a_0) -> snd_ctl_t *;
__attribute__((alias("fexfn_pack_snd_hctl_elem_next"))) auto snd_hctl_elem_next(snd_hctl_elem_t * a_0) -> snd_hctl_elem_t *;
__attribute__((alias("fexfn_pack_snd_hctl_elem_prev"))) auto snd_hctl_elem_prev(snd_hctl_elem_t * a_0) -> snd_hctl_elem_t *;
__attribute__((alias("fexfn_pack_snd_hctl_elem_info"))) auto snd_hctl_elem_info(snd_hctl_elem_t * a_0, snd_ctl_elem_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_read"))) auto snd_hctl_elem_read(snd_hctl_elem_t * a_0, snd_ctl_elem_value_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_write"))) auto snd_hctl_elem_write(snd_hctl_elem_t * a_0, snd_ctl_elem_value_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_tlv_read"))) auto snd_hctl_elem_tlv_read(snd_hctl_elem_t * a_0, unsigned int * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_tlv_write"))) auto snd_hctl_elem_tlv_write(snd_hctl_elem_t * a_0, const unsigned int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_tlv_command"))) auto snd_hctl_elem_tlv_command(snd_hctl_elem_t * a_0, const unsigned int * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_hctl"))) auto snd_hctl_elem_get_hctl(snd_hctl_elem_t * a_0) -> snd_hctl_t *;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_id"))) auto snd_hctl_elem_get_id(const snd_hctl_elem_t * a_0, snd_ctl_elem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_numid"))) auto snd_hctl_elem_get_numid(const snd_hctl_elem_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_interface"))) auto snd_hctl_elem_get_interface(const snd_hctl_elem_t * a_0) -> snd_ctl_elem_iface_t;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_device"))) auto snd_hctl_elem_get_device(const snd_hctl_elem_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_subdevice"))) auto snd_hctl_elem_get_subdevice(const snd_hctl_elem_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_name"))) auto snd_hctl_elem_get_name(const snd_hctl_elem_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_hctl_elem_get_index"))) auto snd_hctl_elem_get_index(const snd_hctl_elem_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_sctl_build"))) auto snd_sctl_build(snd_sctl_t ** a_0, snd_ctl_t * a_1, snd_config_t * a_2, snd_config_t * a_3, int a_4) -> int;
__attribute__((alias("fexfn_pack_snd_sctl_free"))) auto snd_sctl_free(snd_sctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_sctl_install"))) auto snd_sctl_install(snd_sctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_sctl_remove"))) auto snd_sctl_remove(snd_sctl_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_open"))) auto snd_mixer_open(snd_mixer_t ** a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_close"))) auto snd_mixer_close(snd_mixer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_first_elem"))) auto snd_mixer_first_elem(snd_mixer_t * a_0) -> snd_mixer_elem_t *;
__attribute__((alias("fexfn_pack_snd_mixer_last_elem"))) auto snd_mixer_last_elem(snd_mixer_t * a_0) -> snd_mixer_elem_t *;
__attribute__((alias("fexfn_pack_snd_mixer_handle_events"))) auto snd_mixer_handle_events(snd_mixer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_attach"))) auto snd_mixer_attach(snd_mixer_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_attach_hctl"))) auto snd_mixer_attach_hctl(snd_mixer_t * a_0, snd_hctl_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_detach"))) auto snd_mixer_detach(snd_mixer_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_detach_hctl"))) auto snd_mixer_detach_hctl(snd_mixer_t * a_0, snd_hctl_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_get_hctl"))) auto snd_mixer_get_hctl(snd_mixer_t * a_0, const char * a_1, snd_hctl_t ** a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_poll_descriptors_count"))) auto snd_mixer_poll_descriptors_count(snd_mixer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_poll_descriptors"))) auto snd_mixer_poll_descriptors(snd_mixer_t * a_0, struct pollfd * a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_poll_descriptors_revents"))) auto snd_mixer_poll_descriptors_revents(snd_mixer_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_load"))) auto snd_mixer_load(snd_mixer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_free"))) auto snd_mixer_free(snd_mixer_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_wait"))) auto snd_mixer_wait(snd_mixer_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_get_count"))) auto snd_mixer_get_count(const snd_mixer_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_mixer_class_unregister"))) auto snd_mixer_class_unregister(snd_mixer_class_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_next"))) auto snd_mixer_elem_next(snd_mixer_elem_t * a_0) -> snd_mixer_elem_t *;
__attribute__((alias("fexfn_pack_snd_mixer_elem_prev"))) auto snd_mixer_elem_prev(snd_mixer_elem_t * a_0) -> snd_mixer_elem_t *;
__attribute__((alias("fexfn_pack_snd_mixer_elem_get_callback_private"))) auto snd_mixer_elem_get_callback_private(const snd_mixer_elem_t * a_0) -> void *;
__attribute__((alias("fexfn_pack_snd_mixer_elem_get_type"))) auto snd_mixer_elem_get_type(const snd_mixer_elem_t * a_0) -> snd_mixer_elem_type_t;
__attribute__((alias("fexfn_pack_snd_mixer_class_register"))) auto snd_mixer_class_register(snd_mixer_class_t * a_0, snd_mixer_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_add"))) auto snd_mixer_elem_add(snd_mixer_elem_t * a_0, snd_mixer_class_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_remove"))) auto snd_mixer_elem_remove(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_free"))) auto snd_mixer_elem_free(snd_mixer_elem_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_elem_info"))) auto snd_mixer_elem_info(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_value"))) auto snd_mixer_elem_value(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_attach"))) auto snd_mixer_elem_attach(snd_mixer_elem_t * a_0, snd_hctl_elem_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_detach"))) auto snd_mixer_elem_detach(snd_mixer_elem_t * a_0, snd_hctl_elem_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_empty"))) auto snd_mixer_elem_empty(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_elem_get_private"))) auto snd_mixer_elem_get_private(const snd_mixer_elem_t * a_0) -> void *;
__attribute__((alias("fexfn_pack_snd_mixer_class_sizeof"))) auto snd_mixer_class_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_mixer_class_malloc"))) auto snd_mixer_class_malloc(snd_mixer_class_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_class_free"))) auto snd_mixer_class_free(snd_mixer_class_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_class_copy"))) auto snd_mixer_class_copy(snd_mixer_class_t * a_0, const snd_mixer_class_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_selem_channel_name"))) auto snd_mixer_selem_channel_name(snd_mixer_selem_channel_id_t a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_mixer_selem_register"))) auto snd_mixer_selem_register(snd_mixer_t * a_0, struct snd_mixer_selem_regopt * a_1, snd_mixer_class_t ** a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_id"))) auto snd_mixer_selem_get_id(snd_mixer_elem_t * a_0, snd_mixer_selem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_name"))) auto snd_mixer_selem_get_name(snd_mixer_elem_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_index"))) auto snd_mixer_selem_get_index(snd_mixer_elem_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_mixer_find_selem"))) auto snd_mixer_find_selem(snd_mixer_t * a_0, const snd_mixer_selem_id_t * a_1) -> snd_mixer_elem_t *;
__attribute__((alias("fexfn_pack_snd_mixer_selem_is_active"))) auto snd_mixer_selem_is_active(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_is_playback_mono"))) auto snd_mixer_selem_is_playback_mono(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_playback_channel"))) auto snd_mixer_selem_has_playback_channel(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_is_capture_mono"))) auto snd_mixer_selem_is_capture_mono(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_capture_channel"))) auto snd_mixer_selem_has_capture_channel(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_capture_group"))) auto snd_mixer_selem_get_capture_group(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_common_volume"))) auto snd_mixer_selem_has_common_volume(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_playback_volume"))) auto snd_mixer_selem_has_playback_volume(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_playback_volume_joined"))) auto snd_mixer_selem_has_playback_volume_joined(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_capture_volume"))) auto snd_mixer_selem_has_capture_volume(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_capture_volume_joined"))) auto snd_mixer_selem_has_capture_volume_joined(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_common_switch"))) auto snd_mixer_selem_has_common_switch(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_playback_switch"))) auto snd_mixer_selem_has_playback_switch(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_playback_switch_joined"))) auto snd_mixer_selem_has_playback_switch_joined(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_capture_switch"))) auto snd_mixer_selem_has_capture_switch(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_capture_switch_joined"))) auto snd_mixer_selem_has_capture_switch_joined(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_has_capture_switch_exclusive"))) auto snd_mixer_selem_has_capture_switch_exclusive(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_ask_playback_vol_dB"))) auto snd_mixer_selem_ask_playback_vol_dB(snd_mixer_elem_t * a_0, long a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_ask_capture_vol_dB"))) auto snd_mixer_selem_ask_capture_vol_dB(snd_mixer_elem_t * a_0, long a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_ask_playback_dB_vol"))) auto snd_mixer_selem_ask_playback_dB_vol(snd_mixer_elem_t * a_0, long a_1, int a_2, long * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_ask_capture_dB_vol"))) auto snd_mixer_selem_ask_capture_dB_vol(snd_mixer_elem_t * a_0, long a_1, int a_2, long * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_playback_volume"))) auto snd_mixer_selem_get_playback_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_capture_volume"))) auto snd_mixer_selem_get_capture_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_playback_dB"))) auto snd_mixer_selem_get_playback_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_capture_dB"))) auto snd_mixer_selem_get_capture_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_playback_switch"))) auto snd_mixer_selem_get_playback_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_capture_switch"))) auto snd_mixer_selem_get_capture_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_playback_volume"))) auto snd_mixer_selem_set_playback_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_capture_volume"))) auto snd_mixer_selem_set_capture_volume(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_playback_dB"))) auto snd_mixer_selem_set_playback_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_capture_dB"))) auto snd_mixer_selem_set_capture_dB(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, long a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_playback_volume_all"))) auto snd_mixer_selem_set_playback_volume_all(snd_mixer_elem_t * a_0, long a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_capture_volume_all"))) auto snd_mixer_selem_set_capture_volume_all(snd_mixer_elem_t * a_0, long a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_playback_dB_all"))) auto snd_mixer_selem_set_playback_dB_all(snd_mixer_elem_t * a_0, long a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_capture_dB_all"))) auto snd_mixer_selem_set_capture_dB_all(snd_mixer_elem_t * a_0, long a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_playback_switch"))) auto snd_mixer_selem_set_playback_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_capture_switch"))) auto snd_mixer_selem_set_capture_switch(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_playback_switch_all"))) auto snd_mixer_selem_set_playback_switch_all(snd_mixer_elem_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_capture_switch_all"))) auto snd_mixer_selem_set_capture_switch_all(snd_mixer_elem_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_playback_volume_range"))) auto snd_mixer_selem_get_playback_volume_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_playback_dB_range"))) auto snd_mixer_selem_get_playback_dB_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_playback_volume_range"))) auto snd_mixer_selem_set_playback_volume_range(snd_mixer_elem_t * a_0, long a_1, long a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_capture_volume_range"))) auto snd_mixer_selem_get_capture_volume_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_capture_dB_range"))) auto snd_mixer_selem_get_capture_dB_range(snd_mixer_elem_t * a_0, long * a_1, long * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_capture_volume_range"))) auto snd_mixer_selem_set_capture_volume_range(snd_mixer_elem_t * a_0, long a_1, long a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_is_enumerated"))) auto snd_mixer_selem_is_enumerated(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_is_enum_playback"))) auto snd_mixer_selem_is_enum_playback(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_is_enum_capture"))) auto snd_mixer_selem_is_enum_capture(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_enum_items"))) auto snd_mixer_selem_get_enum_items(snd_mixer_elem_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_enum_item_name"))) auto snd_mixer_selem_get_enum_item_name(snd_mixer_elem_t * a_0, unsigned int a_1, size_t a_2, char * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_get_enum_item"))) auto snd_mixer_selem_get_enum_item(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, unsigned int * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_set_enum_item"))) auto snd_mixer_selem_set_enum_item(snd_mixer_elem_t * a_0, snd_mixer_selem_channel_id_t a_1, unsigned int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_sizeof"))) auto snd_mixer_selem_id_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_malloc"))) auto snd_mixer_selem_id_malloc(snd_mixer_selem_id_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_free"))) auto snd_mixer_selem_id_free(snd_mixer_selem_id_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_copy"))) auto snd_mixer_selem_id_copy(snd_mixer_selem_id_t * a_0, const snd_mixer_selem_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_get_name"))) auto snd_mixer_selem_id_get_name(const snd_mixer_selem_id_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_get_index"))) auto snd_mixer_selem_id_get_index(const snd_mixer_selem_id_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_set_name"))) auto snd_mixer_selem_id_set_name(snd_mixer_selem_id_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_set_index"))) auto snd_mixer_selem_id_set_index(snd_mixer_selem_id_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_mixer_selem_id_parse"))) auto snd_mixer_selem_id_parse(snd_mixer_selem_id_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_open"))) auto snd_seq_open(snd_seq_t ** a_0, const char * a_1, int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_open_lconf"))) auto snd_seq_open_lconf(snd_seq_t ** a_0, const char * a_1, int a_2, int a_3, snd_config_t * a_4) -> int;
__attribute__((alias("fexfn_pack_snd_seq_name"))) auto snd_seq_name(snd_seq_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_seq_type"))) auto snd_seq_type(snd_seq_t * a_0) -> snd_seq_type_t;
__attribute__((alias("fexfn_pack_snd_seq_close"))) auto snd_seq_close(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_poll_descriptors_count"))) auto snd_seq_poll_descriptors_count(snd_seq_t * a_0, short a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_poll_descriptors"))) auto snd_seq_poll_descriptors(snd_seq_t * a_0, struct pollfd * a_1, unsigned int a_2, short a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_poll_descriptors_revents"))) auto snd_seq_poll_descriptors_revents(snd_seq_t * a_0, struct pollfd * a_1, unsigned int a_2, unsigned short * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_nonblock"))) auto snd_seq_nonblock(snd_seq_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_id"))) auto snd_seq_client_id(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_output_buffer_size"))) auto snd_seq_get_output_buffer_size(snd_seq_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_get_input_buffer_size"))) auto snd_seq_get_input_buffer_size(snd_seq_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_set_output_buffer_size"))) auto snd_seq_set_output_buffer_size(snd_seq_t * a_0, size_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_input_buffer_size"))) auto snd_seq_set_input_buffer_size(snd_seq_t * a_0, size_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info_sizeof"))) auto snd_seq_system_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_system_info_malloc"))) auto snd_seq_system_info_malloc(snd_seq_system_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info_free"))) auto snd_seq_system_info_free(snd_seq_system_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_system_info_copy"))) auto snd_seq_system_info_copy(snd_seq_system_info_t * a_0, const snd_seq_system_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_system_info_get_queues"))) auto snd_seq_system_info_get_queues(const snd_seq_system_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info_get_clients"))) auto snd_seq_system_info_get_clients(const snd_seq_system_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info_get_ports"))) auto snd_seq_system_info_get_ports(const snd_seq_system_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info_get_channels"))) auto snd_seq_system_info_get_channels(const snd_seq_system_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info_get_cur_clients"))) auto snd_seq_system_info_get_cur_clients(const snd_seq_system_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info_get_cur_queues"))) auto snd_seq_system_info_get_cur_queues(const snd_seq_system_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_system_info"))) auto snd_seq_system_info(snd_seq_t * a_0, snd_seq_system_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_sizeof"))) auto snd_seq_client_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_client_info_malloc"))) auto snd_seq_client_info_malloc(snd_seq_client_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_free"))) auto snd_seq_client_info_free(snd_seq_client_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_copy"))) auto snd_seq_client_info_copy(snd_seq_client_info_t * a_0, const snd_seq_client_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_client"))) auto snd_seq_client_info_get_client(const snd_seq_client_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_type"))) auto snd_seq_client_info_get_type(const snd_seq_client_info_t * a_0) -> snd_seq_client_type_t;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_name"))) auto snd_seq_client_info_get_name(snd_seq_client_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_broadcast_filter"))) auto snd_seq_client_info_get_broadcast_filter(const snd_seq_client_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_error_bounce"))) auto snd_seq_client_info_get_error_bounce(const snd_seq_client_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_card"))) auto snd_seq_client_info_get_card(const snd_seq_client_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_pid"))) auto snd_seq_client_info_get_pid(const snd_seq_client_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_event_filter"))) auto snd_seq_client_info_get_event_filter(const snd_seq_client_info_t * a_0) -> const unsigned char *;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_num_ports"))) auto snd_seq_client_info_get_num_ports(const snd_seq_client_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_get_event_lost"))) auto snd_seq_client_info_get_event_lost(const snd_seq_client_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_info_set_client"))) auto snd_seq_client_info_set_client(snd_seq_client_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_set_name"))) auto snd_seq_client_info_set_name(snd_seq_client_info_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_set_broadcast_filter"))) auto snd_seq_client_info_set_broadcast_filter(snd_seq_client_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_set_error_bounce"))) auto snd_seq_client_info_set_error_bounce(snd_seq_client_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_set_event_filter"))) auto snd_seq_client_info_set_event_filter(snd_seq_client_info_t * a_0, unsigned char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_event_filter_clear"))) auto snd_seq_client_info_event_filter_clear(snd_seq_client_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_event_filter_add"))) auto snd_seq_client_info_event_filter_add(snd_seq_client_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_event_filter_del"))) auto snd_seq_client_info_event_filter_del(snd_seq_client_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_info_event_filter_check"))) auto snd_seq_client_info_event_filter_check(snd_seq_client_info_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_client_info"))) auto snd_seq_get_client_info(snd_seq_t * a_0, snd_seq_client_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_any_client_info"))) auto snd_seq_get_any_client_info(snd_seq_t * a_0, int a_1, snd_seq_client_info_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_client_info"))) auto snd_seq_set_client_info(snd_seq_t * a_0, snd_seq_client_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_next_client"))) auto snd_seq_query_next_client(snd_seq_t * a_0, snd_seq_client_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_sizeof"))) auto snd_seq_client_pool_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_malloc"))) auto snd_seq_client_pool_malloc(snd_seq_client_pool_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_free"))) auto snd_seq_client_pool_free(snd_seq_client_pool_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_copy"))) auto snd_seq_client_pool_copy(snd_seq_client_pool_t * a_0, const snd_seq_client_pool_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_get_client"))) auto snd_seq_client_pool_get_client(const snd_seq_client_pool_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_get_output_pool"))) auto snd_seq_client_pool_get_output_pool(const snd_seq_client_pool_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_get_input_pool"))) auto snd_seq_client_pool_get_input_pool(const snd_seq_client_pool_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_get_output_room"))) auto snd_seq_client_pool_get_output_room(const snd_seq_client_pool_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_get_output_free"))) auto snd_seq_client_pool_get_output_free(const snd_seq_client_pool_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_get_input_free"))) auto snd_seq_client_pool_get_input_free(const snd_seq_client_pool_t * a_0) -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_set_output_pool"))) auto snd_seq_client_pool_set_output_pool(snd_seq_client_pool_t * a_0, size_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_set_input_pool"))) auto snd_seq_client_pool_set_input_pool(snd_seq_client_pool_t * a_0, size_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_client_pool_set_output_room"))) auto snd_seq_client_pool_set_output_room(snd_seq_client_pool_t * a_0, size_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_get_client_pool"))) auto snd_seq_get_client_pool(snd_seq_t * a_0, snd_seq_client_pool_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_client_pool"))) auto snd_seq_set_client_pool(snd_seq_t * a_0, snd_seq_client_pool_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_sizeof"))) auto snd_seq_port_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_port_info_malloc"))) auto snd_seq_port_info_malloc(snd_seq_port_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_free"))) auto snd_seq_port_info_free(snd_seq_port_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_copy"))) auto snd_seq_port_info_copy(snd_seq_port_info_t * a_0, const snd_seq_port_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_client"))) auto snd_seq_port_info_get_client(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_port"))) auto snd_seq_port_info_get_port(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_addr"))) auto snd_seq_port_info_get_addr(const snd_seq_port_info_t * a_0) -> const snd_seq_addr_t *;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_name"))) auto snd_seq_port_info_get_name(const snd_seq_port_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_capability"))) auto snd_seq_port_info_get_capability(const snd_seq_port_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_type"))) auto snd_seq_port_info_get_type(const snd_seq_port_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_midi_channels"))) auto snd_seq_port_info_get_midi_channels(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_midi_voices"))) auto snd_seq_port_info_get_midi_voices(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_synth_voices"))) auto snd_seq_port_info_get_synth_voices(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_read_use"))) auto snd_seq_port_info_get_read_use(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_write_use"))) auto snd_seq_port_info_get_write_use(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_port_specified"))) auto snd_seq_port_info_get_port_specified(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_timestamping"))) auto snd_seq_port_info_get_timestamping(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_timestamp_real"))) auto snd_seq_port_info_get_timestamp_real(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_get_timestamp_queue"))) auto snd_seq_port_info_get_timestamp_queue(const snd_seq_port_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_client"))) auto snd_seq_port_info_set_client(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_port"))) auto snd_seq_port_info_set_port(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_addr"))) auto snd_seq_port_info_set_addr(snd_seq_port_info_t * a_0, const snd_seq_addr_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_name"))) auto snd_seq_port_info_set_name(snd_seq_port_info_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_capability"))) auto snd_seq_port_info_set_capability(snd_seq_port_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_type"))) auto snd_seq_port_info_set_type(snd_seq_port_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_midi_channels"))) auto snd_seq_port_info_set_midi_channels(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_midi_voices"))) auto snd_seq_port_info_set_midi_voices(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_synth_voices"))) auto snd_seq_port_info_set_synth_voices(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_port_specified"))) auto snd_seq_port_info_set_port_specified(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_timestamping"))) auto snd_seq_port_info_set_timestamping(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_timestamp_real"))) auto snd_seq_port_info_set_timestamp_real(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_info_set_timestamp_queue"))) auto snd_seq_port_info_set_timestamp_queue(snd_seq_port_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_create_port"))) auto snd_seq_create_port(snd_seq_t * a_0, snd_seq_port_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_delete_port"))) auto snd_seq_delete_port(snd_seq_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_port_info"))) auto snd_seq_get_port_info(snd_seq_t * a_0, int a_1, snd_seq_port_info_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_any_port_info"))) auto snd_seq_get_any_port_info(snd_seq_t * a_0, int a_1, int a_2, snd_seq_port_info_t * a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_port_info"))) auto snd_seq_set_port_info(snd_seq_t * a_0, int a_1, snd_seq_port_info_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_next_port"))) auto snd_seq_query_next_port(snd_seq_t * a_0, snd_seq_port_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_sizeof"))) auto snd_seq_port_subscribe_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_malloc"))) auto snd_seq_port_subscribe_malloc(snd_seq_port_subscribe_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_free"))) auto snd_seq_port_subscribe_free(snd_seq_port_subscribe_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_copy"))) auto snd_seq_port_subscribe_copy(snd_seq_port_subscribe_t * a_0, const snd_seq_port_subscribe_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_get_sender"))) auto snd_seq_port_subscribe_get_sender(const snd_seq_port_subscribe_t * a_0) -> const snd_seq_addr_t *;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_get_dest"))) auto snd_seq_port_subscribe_get_dest(const snd_seq_port_subscribe_t * a_0) -> const snd_seq_addr_t *;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_get_queue"))) auto snd_seq_port_subscribe_get_queue(const snd_seq_port_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_get_exclusive"))) auto snd_seq_port_subscribe_get_exclusive(const snd_seq_port_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_get_time_update"))) auto snd_seq_port_subscribe_get_time_update(const snd_seq_port_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_get_time_real"))) auto snd_seq_port_subscribe_get_time_real(const snd_seq_port_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_set_sender"))) auto snd_seq_port_subscribe_set_sender(snd_seq_port_subscribe_t * a_0, const snd_seq_addr_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_set_dest"))) auto snd_seq_port_subscribe_set_dest(snd_seq_port_subscribe_t * a_0, const snd_seq_addr_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_set_queue"))) auto snd_seq_port_subscribe_set_queue(snd_seq_port_subscribe_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_set_exclusive"))) auto snd_seq_port_subscribe_set_exclusive(snd_seq_port_subscribe_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_set_time_update"))) auto snd_seq_port_subscribe_set_time_update(snd_seq_port_subscribe_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_port_subscribe_set_time_real"))) auto snd_seq_port_subscribe_set_time_real(snd_seq_port_subscribe_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_get_port_subscription"))) auto snd_seq_get_port_subscription(snd_seq_t * a_0, snd_seq_port_subscribe_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_subscribe_port"))) auto snd_seq_subscribe_port(snd_seq_t * a_0, snd_seq_port_subscribe_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_unsubscribe_port"))) auto snd_seq_unsubscribe_port(snd_seq_t * a_0, snd_seq_port_subscribe_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_sizeof"))) auto snd_seq_query_subscribe_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_malloc"))) auto snd_seq_query_subscribe_malloc(snd_seq_query_subscribe_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_free"))) auto snd_seq_query_subscribe_free(snd_seq_query_subscribe_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_copy"))) auto snd_seq_query_subscribe_copy(snd_seq_query_subscribe_t * a_0, const snd_seq_query_subscribe_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_client"))) auto snd_seq_query_subscribe_get_client(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_port"))) auto snd_seq_query_subscribe_get_port(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_root"))) auto snd_seq_query_subscribe_get_root(const snd_seq_query_subscribe_t * a_0) -> const snd_seq_addr_t *;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_type"))) auto snd_seq_query_subscribe_get_type(const snd_seq_query_subscribe_t * a_0) -> snd_seq_query_subs_type_t;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_index"))) auto snd_seq_query_subscribe_get_index(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_num_subs"))) auto snd_seq_query_subscribe_get_num_subs(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_addr"))) auto snd_seq_query_subscribe_get_addr(const snd_seq_query_subscribe_t * a_0) -> const snd_seq_addr_t *;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_queue"))) auto snd_seq_query_subscribe_get_queue(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_exclusive"))) auto snd_seq_query_subscribe_get_exclusive(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_time_update"))) auto snd_seq_query_subscribe_get_time_update(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_get_time_real"))) auto snd_seq_query_subscribe_get_time_real(const snd_seq_query_subscribe_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_set_client"))) auto snd_seq_query_subscribe_set_client(snd_seq_query_subscribe_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_set_port"))) auto snd_seq_query_subscribe_set_port(snd_seq_query_subscribe_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_set_root"))) auto snd_seq_query_subscribe_set_root(snd_seq_query_subscribe_t * a_0, const snd_seq_addr_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_set_type"))) auto snd_seq_query_subscribe_set_type(snd_seq_query_subscribe_t * a_0, snd_seq_query_subs_type_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_query_subscribe_set_index"))) auto snd_seq_query_subscribe_set_index(snd_seq_query_subscribe_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_query_port_subscribers"))) auto snd_seq_query_port_subscribers(snd_seq_t * a_0, snd_seq_query_subscribe_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_sizeof"))) auto snd_seq_queue_info_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_malloc"))) auto snd_seq_queue_info_malloc(snd_seq_queue_info_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_free"))) auto snd_seq_queue_info_free(snd_seq_queue_info_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_copy"))) auto snd_seq_queue_info_copy(snd_seq_queue_info_t * a_0, const snd_seq_queue_info_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_get_queue"))) auto snd_seq_queue_info_get_queue(const snd_seq_queue_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_get_name"))) auto snd_seq_queue_info_get_name(const snd_seq_queue_info_t * a_0) -> const char *;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_get_owner"))) auto snd_seq_queue_info_get_owner(const snd_seq_queue_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_get_locked"))) auto snd_seq_queue_info_get_locked(const snd_seq_queue_info_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_get_flags"))) auto snd_seq_queue_info_get_flags(const snd_seq_queue_info_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_set_name"))) auto snd_seq_queue_info_set_name(snd_seq_queue_info_t * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_set_owner"))) auto snd_seq_queue_info_set_owner(snd_seq_queue_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_set_locked"))) auto snd_seq_queue_info_set_locked(snd_seq_queue_info_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_info_set_flags"))) auto snd_seq_queue_info_set_flags(snd_seq_queue_info_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_create_queue"))) auto snd_seq_create_queue(snd_seq_t * a_0, snd_seq_queue_info_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_alloc_named_queue"))) auto snd_seq_alloc_named_queue(snd_seq_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_alloc_queue"))) auto snd_seq_alloc_queue(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_free_queue"))) auto snd_seq_free_queue(snd_seq_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_queue_info"))) auto snd_seq_get_queue_info(snd_seq_t * a_0, int a_1, snd_seq_queue_info_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_queue_info"))) auto snd_seq_set_queue_info(snd_seq_t * a_0, int a_1, snd_seq_queue_info_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_query_named_queue"))) auto snd_seq_query_named_queue(snd_seq_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_queue_usage"))) auto snd_seq_get_queue_usage(snd_seq_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_queue_usage"))) auto snd_seq_set_queue_usage(snd_seq_t * a_0, int a_1, int a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_sizeof"))) auto snd_seq_queue_status_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_malloc"))) auto snd_seq_queue_status_malloc(snd_seq_queue_status_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_free"))) auto snd_seq_queue_status_free(snd_seq_queue_status_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_copy"))) auto snd_seq_queue_status_copy(snd_seq_queue_status_t * a_0, const snd_seq_queue_status_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_get_queue"))) auto snd_seq_queue_status_get_queue(const snd_seq_queue_status_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_get_events"))) auto snd_seq_queue_status_get_events(const snd_seq_queue_status_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_get_tick_time"))) auto snd_seq_queue_status_get_tick_time(const snd_seq_queue_status_t * a_0) -> snd_seq_tick_time_t;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_get_real_time"))) auto snd_seq_queue_status_get_real_time(const snd_seq_queue_status_t * a_0) -> const snd_seq_real_time_t *;
__attribute__((alias("fexfn_pack_snd_seq_queue_status_get_status"))) auto snd_seq_queue_status_get_status(const snd_seq_queue_status_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_get_queue_status"))) auto snd_seq_get_queue_status(snd_seq_t * a_0, int a_1, snd_seq_queue_status_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_sizeof"))) auto snd_seq_queue_tempo_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_malloc"))) auto snd_seq_queue_tempo_malloc(snd_seq_queue_tempo_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_free"))) auto snd_seq_queue_tempo_free(snd_seq_queue_tempo_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_copy"))) auto snd_seq_queue_tempo_copy(snd_seq_queue_tempo_t * a_0, const snd_seq_queue_tempo_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_get_queue"))) auto snd_seq_queue_tempo_get_queue(const snd_seq_queue_tempo_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_get_tempo"))) auto snd_seq_queue_tempo_get_tempo(const snd_seq_queue_tempo_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_get_ppq"))) auto snd_seq_queue_tempo_get_ppq(const snd_seq_queue_tempo_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_get_skew"))) auto snd_seq_queue_tempo_get_skew(const snd_seq_queue_tempo_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_get_skew_base"))) auto snd_seq_queue_tempo_get_skew_base(const snd_seq_queue_tempo_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_set_tempo"))) auto snd_seq_queue_tempo_set_tempo(snd_seq_queue_tempo_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_set_ppq"))) auto snd_seq_queue_tempo_set_ppq(snd_seq_queue_tempo_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_set_skew"))) auto snd_seq_queue_tempo_set_skew(snd_seq_queue_tempo_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_tempo_set_skew_base"))) auto snd_seq_queue_tempo_set_skew_base(snd_seq_queue_tempo_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_get_queue_tempo"))) auto snd_seq_get_queue_tempo(snd_seq_t * a_0, int a_1, snd_seq_queue_tempo_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_queue_tempo"))) auto snd_seq_set_queue_tempo(snd_seq_t * a_0, int a_1, snd_seq_queue_tempo_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_sizeof"))) auto snd_seq_queue_timer_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_malloc"))) auto snd_seq_queue_timer_malloc(snd_seq_queue_timer_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_free"))) auto snd_seq_queue_timer_free(snd_seq_queue_timer_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_copy"))) auto snd_seq_queue_timer_copy(snd_seq_queue_timer_t * a_0, const snd_seq_queue_timer_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_get_queue"))) auto snd_seq_queue_timer_get_queue(const snd_seq_queue_timer_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_get_type"))) auto snd_seq_queue_timer_get_type(const snd_seq_queue_timer_t * a_0) -> snd_seq_queue_timer_type_t;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_get_id"))) auto snd_seq_queue_timer_get_id(const snd_seq_queue_timer_t * a_0) -> const snd_timer_id_t *;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_get_resolution"))) auto snd_seq_queue_timer_get_resolution(const snd_seq_queue_timer_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_set_type"))) auto snd_seq_queue_timer_set_type(snd_seq_queue_timer_t * a_0, snd_seq_queue_timer_type_t a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_set_id"))) auto snd_seq_queue_timer_set_id(snd_seq_queue_timer_t * a_0, const snd_timer_id_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_queue_timer_set_resolution"))) auto snd_seq_queue_timer_set_resolution(snd_seq_queue_timer_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_get_queue_timer"))) auto snd_seq_get_queue_timer(snd_seq_t * a_0, int a_1, snd_seq_queue_timer_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_queue_timer"))) auto snd_seq_set_queue_timer(snd_seq_t * a_0, int a_1, snd_seq_queue_timer_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_free_event"))) auto snd_seq_free_event(snd_seq_event_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_event_length"))) auto snd_seq_event_length(snd_seq_event_t * a_0) -> ssize_t;
__attribute__((alias("fexfn_pack_snd_seq_event_output"))) auto snd_seq_event_output(snd_seq_t * a_0, snd_seq_event_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_event_output_buffer"))) auto snd_seq_event_output_buffer(snd_seq_t * a_0, snd_seq_event_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_event_output_direct"))) auto snd_seq_event_output_direct(snd_seq_t * a_0, snd_seq_event_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_event_input"))) auto snd_seq_event_input(snd_seq_t * a_0, snd_seq_event_t ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_event_input_pending"))) auto snd_seq_event_input_pending(snd_seq_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_drain_output"))) auto snd_seq_drain_output(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_event_output_pending"))) auto snd_seq_event_output_pending(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_extract_output"))) auto snd_seq_extract_output(snd_seq_t * a_0, snd_seq_event_t ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_drop_output"))) auto snd_seq_drop_output(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_drop_output_buffer"))) auto snd_seq_drop_output_buffer(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_drop_input"))) auto snd_seq_drop_input(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_drop_input_buffer"))) auto snd_seq_drop_input_buffer(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_sizeof"))) auto snd_seq_remove_events_sizeof() -> size_t;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_malloc"))) auto snd_seq_remove_events_malloc(snd_seq_remove_events_t ** a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_free"))) auto snd_seq_remove_events_free(snd_seq_remove_events_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_copy"))) auto snd_seq_remove_events_copy(snd_seq_remove_events_t * a_0, const snd_seq_remove_events_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_get_condition"))) auto snd_seq_remove_events_get_condition(const snd_seq_remove_events_t * a_0) -> unsigned int;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_get_queue"))) auto snd_seq_remove_events_get_queue(const snd_seq_remove_events_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_get_time"))) auto snd_seq_remove_events_get_time(const snd_seq_remove_events_t * a_0) -> const snd_seq_timestamp_t *;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_get_dest"))) auto snd_seq_remove_events_get_dest(const snd_seq_remove_events_t * a_0) -> const snd_seq_addr_t *;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_get_channel"))) auto snd_seq_remove_events_get_channel(const snd_seq_remove_events_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_get_event_type"))) auto snd_seq_remove_events_get_event_type(const snd_seq_remove_events_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_get_tag"))) auto snd_seq_remove_events_get_tag(const snd_seq_remove_events_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_set_condition"))) auto snd_seq_remove_events_set_condition(snd_seq_remove_events_t * a_0, unsigned int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_set_queue"))) auto snd_seq_remove_events_set_queue(snd_seq_remove_events_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_set_time"))) auto snd_seq_remove_events_set_time(snd_seq_remove_events_t * a_0, const snd_seq_timestamp_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_set_dest"))) auto snd_seq_remove_events_set_dest(snd_seq_remove_events_t * a_0, const snd_seq_addr_t * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_set_channel"))) auto snd_seq_remove_events_set_channel(snd_seq_remove_events_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_set_event_type"))) auto snd_seq_remove_events_set_event_type(snd_seq_remove_events_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events_set_tag"))) auto snd_seq_remove_events_set_tag(snd_seq_remove_events_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_remove_events"))) auto snd_seq_remove_events(snd_seq_t * a_0, snd_seq_remove_events_t * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_bit"))) auto snd_seq_set_bit(int a_0, void * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_unset_bit"))) auto snd_seq_unset_bit(int a_0, void * a_1) -> void;
__attribute__((alias("fexfn_pack_snd_seq_change_bit"))) auto snd_seq_change_bit(int a_0, void * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_get_bit"))) auto snd_seq_get_bit(int a_0, void * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_control_queue"))) auto snd_seq_control_queue(snd_seq_t * a_0, int a_1, int a_2, int a_3, snd_seq_event_t * a_4) -> int;
__attribute__((alias("fexfn_pack_snd_seq_create_simple_port"))) auto snd_seq_create_simple_port(snd_seq_t * a_0, const char * a_1, unsigned int a_2, unsigned int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_delete_simple_port"))) auto snd_seq_delete_simple_port(snd_seq_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_connect_from"))) auto snd_seq_connect_from(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_connect_to"))) auto snd_seq_connect_to(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_disconnect_from"))) auto snd_seq_disconnect_from(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_disconnect_to"))) auto snd_seq_disconnect_to(snd_seq_t * a_0, int a_1, int a_2, int a_3) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_client_name"))) auto snd_seq_set_client_name(snd_seq_t * a_0, const char * a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_client_event_filter"))) auto snd_seq_set_client_event_filter(snd_seq_t * a_0, int a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_client_pool_output"))) auto snd_seq_set_client_pool_output(snd_seq_t * a_0, size_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_client_pool_output_room"))) auto snd_seq_set_client_pool_output_room(snd_seq_t * a_0, size_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_set_client_pool_input"))) auto snd_seq_set_client_pool_input(snd_seq_t * a_0, size_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_seq_sync_output_queue"))) auto snd_seq_sync_output_queue(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_parse_address"))) auto snd_seq_parse_address(snd_seq_t * a_0, snd_seq_addr_t * a_1, const char * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_seq_reset_pool_output"))) auto snd_seq_reset_pool_output(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_seq_reset_pool_input"))) auto snd_seq_reset_pool_input(snd_seq_t * a_0) -> int;
__attribute__((alias("fexfn_pack_snd_midi_event_new"))) auto snd_midi_event_new(size_t a_0, snd_midi_event_t ** a_1) -> int;
__attribute__((alias("fexfn_pack_snd_midi_event_resize_buffer"))) auto snd_midi_event_resize_buffer(snd_midi_event_t * a_0, size_t a_1) -> int;
__attribute__((alias("fexfn_pack_snd_midi_event_free"))) auto snd_midi_event_free(snd_midi_event_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_midi_event_init"))) auto snd_midi_event_init(snd_midi_event_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_midi_event_reset_encode"))) auto snd_midi_event_reset_encode(snd_midi_event_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_midi_event_reset_decode"))) auto snd_midi_event_reset_decode(snd_midi_event_t * a_0) -> void;
__attribute__((alias("fexfn_pack_snd_midi_event_no_status"))) auto snd_midi_event_no_status(snd_midi_event_t * a_0, int a_1) -> void;
__attribute__((alias("fexfn_pack_snd_midi_event_encode"))) auto snd_midi_event_encode(snd_midi_event_t * a_0, const unsigned char * a_1, long a_2, snd_seq_event_t * a_3) -> long;
__attribute__((alias("fexfn_pack_snd_midi_event_encode_byte"))) auto snd_midi_event_encode_byte(snd_midi_event_t * a_0, int a_1, snd_seq_event_t * a_2) -> int;
__attribute__((alias("fexfn_pack_snd_midi_event_decode"))) auto snd_midi_event_decode(snd_midi_event_t * a_0, unsigned char * a_1, long a_2, const snd_seq_event_t * a_3) -> long;
}
#define FOREACH_SYMBOL(EXPAND) \
  EXPAND(snd_asoundlib_version, "TODO") \
  EXPAND(snd_dlpath, "TODO") \
  EXPAND(snd_dlopen, "TODO") \
  EXPAND(snd_dlsym, "TODO") \
  EXPAND(snd_dlclose, "TODO") \
  EXPAND(snd_shm_area_create, "TODO") \
  EXPAND(snd_shm_area_share, "TODO") \
  EXPAND(snd_shm_area_destroy, "TODO") \
  EXPAND(snd_user_file, "TODO") \
  EXPAND(snd_input_stdio_open, "TODO") \
  EXPAND(snd_input_stdio_attach, "TODO") \
  EXPAND(snd_input_buffer_open, "TODO") \
  EXPAND(snd_input_close, "TODO") \
  EXPAND(snd_input_gets, "TODO") \
  EXPAND(snd_input_getc, "TODO") \
  EXPAND(snd_input_ungetc, "TODO") \
  EXPAND(snd_output_stdio_open, "TODO") \
  EXPAND(snd_output_stdio_attach, "TODO") \
  EXPAND(snd_output_buffer_open, "TODO") \
  EXPAND(snd_output_buffer_string, "TODO") \
  EXPAND(snd_output_close, "TODO") \
  EXPAND(snd_output_puts, "TODO") \
  EXPAND(snd_output_putc, "TODO") \
  EXPAND(snd_output_flush, "TODO") \
  EXPAND(snd_strerror, "TODO") \
  EXPAND(snd_lib_error_set_handler, "TODO") \
  EXPAND(snd_config_topdir, "TODO") \
  EXPAND(snd_config_top, "TODO") \
  EXPAND(snd_config_load, "TODO") \
  EXPAND(snd_config_load_override, "TODO") \
  EXPAND(snd_config_save, "TODO") \
  EXPAND(snd_config_update, "TODO") \
  EXPAND(snd_config_update_r, "TODO") \
  EXPAND(snd_config_update_free, "TODO") \
  EXPAND(snd_config_update_free_global, "TODO") \
  EXPAND(snd_config_update_ref, "TODO") \
  EXPAND(snd_config_ref, "TODO") \
  EXPAND(snd_config_unref, "TODO") \
  EXPAND(snd_config_search, "TODO") \
  EXPAND(snd_config_search_definition, "TODO") \
  EXPAND(snd_config_expand, "TODO") \
  EXPAND(snd_config_evaluate, "TODO") \
  EXPAND(snd_config_add, "TODO") \
  EXPAND(snd_config_add_before, "TODO") \
  EXPAND(snd_config_add_after, "TODO") \
  EXPAND(snd_config_remove, "TODO") \
  EXPAND(snd_config_delete, "TODO") \
  EXPAND(snd_config_delete_compound_members, "TODO") \
  EXPAND(snd_config_copy, "TODO") \
  EXPAND(snd_config_make, "TODO") \
  EXPAND(snd_config_make_integer, "TODO") \
  EXPAND(snd_config_make_integer64, "TODO") \
  EXPAND(snd_config_make_real, "TODO") \
  EXPAND(snd_config_make_string, "TODO") \
  EXPAND(snd_config_make_pointer, "TODO") \
  EXPAND(snd_config_make_compound, "TODO") \
  EXPAND(snd_config_imake_string, "TODO") \
  EXPAND(snd_config_imake_safe_string, "TODO") \
  EXPAND(snd_config_imake_pointer, "TODO") \
  EXPAND(snd_config_get_type, "TODO") \
  EXPAND(snd_config_is_array, "TODO") \
  EXPAND(snd_config_set_id, "TODO") \
  EXPAND(snd_config_set_integer, "TODO") \
  EXPAND(snd_config_set_integer64, "TODO") \
  EXPAND(snd_config_set_real, "TODO") \
  EXPAND(snd_config_set_string, "TODO") \
  EXPAND(snd_config_set_ascii, "TODO") \
  EXPAND(snd_config_set_pointer, "TODO") \
  EXPAND(snd_config_get_id, "TODO") \
  EXPAND(snd_config_get_integer, "TODO") \
  EXPAND(snd_config_get_integer64, "TODO") \
  EXPAND(snd_config_get_real, "TODO") \
  EXPAND(snd_config_get_ireal, "TODO") \
  EXPAND(snd_config_get_string, "TODO") \
  EXPAND(snd_config_get_ascii, "TODO") \
  EXPAND(snd_config_get_pointer, "TODO") \
  EXPAND(snd_config_test_id, "TODO") \
  EXPAND(snd_config_iterator_first, "TODO") \
  EXPAND(snd_config_iterator_end, "TODO") \
  EXPAND(snd_config_get_bool_ascii, "TODO") \
  EXPAND(snd_config_get_bool, "TODO") \
  EXPAND(snd_config_get_ctl_iface_ascii, "TODO") \
  EXPAND(snd_config_get_ctl_iface, "TODO") \
  EXPAND(snd_names_list, "TODO") \
  EXPAND(snd_names_list_free, "TODO") \
  EXPAND(snd_pcm_open, "TODO") \
  EXPAND(snd_pcm_open_lconf, "TODO") \
  EXPAND(snd_pcm_open_fallback, "TODO") \
  EXPAND(snd_pcm_close, "TODO") \
  EXPAND(snd_pcm_name, "TODO") \
  EXPAND(snd_pcm_type, "TODO") \
  EXPAND(snd_pcm_stream, "TODO") \
  EXPAND(snd_pcm_poll_descriptors_count, "TODO") \
  EXPAND(snd_pcm_poll_descriptors, "TODO") \
  EXPAND(snd_pcm_poll_descriptors_revents, "TODO") \
  EXPAND(snd_pcm_nonblock, "TODO") \
  EXPAND(snd_async_handler_get_pcm, "TODO") \
  EXPAND(snd_pcm_info, "TODO") \
  EXPAND(snd_pcm_hw_params_current, "TODO") \
  EXPAND(snd_pcm_hw_params, "TODO") \
  EXPAND(snd_pcm_hw_free, "TODO") \
  EXPAND(snd_pcm_sw_params_current, "TODO") \
  EXPAND(snd_pcm_sw_params, "TODO") \
  EXPAND(snd_pcm_prepare, "TODO") \
  EXPAND(snd_pcm_reset, "TODO") \
  EXPAND(snd_pcm_status, "TODO") \
  EXPAND(snd_pcm_start, "TODO") \
  EXPAND(snd_pcm_drop, "TODO") \
  EXPAND(snd_pcm_drain, "TODO") \
  EXPAND(snd_pcm_pause, "TODO") \
  EXPAND(snd_pcm_state, "TODO") \
  EXPAND(snd_pcm_hwsync, "TODO") \
  EXPAND(snd_pcm_delay, "TODO") \
  EXPAND(snd_pcm_resume, "TODO") \
  EXPAND(snd_pcm_htimestamp, "TODO") \
  EXPAND(snd_pcm_avail, "TODO") \
  EXPAND(snd_pcm_avail_update, "TODO") \
  EXPAND(snd_pcm_avail_delay, "TODO") \
  EXPAND(snd_pcm_rewindable, "TODO") \
  EXPAND(snd_pcm_rewind, "TODO") \
  EXPAND(snd_pcm_forwardable, "TODO") \
  EXPAND(snd_pcm_forward, "TODO") \
  EXPAND(snd_pcm_writei, "TODO") \
  EXPAND(snd_pcm_readi, "TODO") \
  EXPAND(snd_pcm_writen, "TODO") \
  EXPAND(snd_pcm_readn, "TODO") \
  EXPAND(snd_pcm_wait, "TODO") \
  EXPAND(snd_pcm_link, "TODO") \
  EXPAND(snd_pcm_unlink, "TODO") \
  EXPAND(snd_pcm_query_chmaps, "TODO") \
  EXPAND(snd_pcm_query_chmaps_from_hw, "TODO") \
  EXPAND(snd_pcm_free_chmaps, "TODO") \
  EXPAND(snd_pcm_get_chmap, "TODO") \
  EXPAND(snd_pcm_set_chmap, "TODO") \
  EXPAND(snd_pcm_chmap_type_name, "TODO") \
  EXPAND(snd_pcm_chmap_name, "TODO") \
  EXPAND(snd_pcm_chmap_long_name, "TODO") \
  EXPAND(snd_pcm_chmap_print, "TODO") \
  EXPAND(snd_pcm_chmap_from_string, "TODO") \
  EXPAND(snd_pcm_chmap_parse_string, "TODO") \
  EXPAND(snd_pcm_recover, "TODO") \
  EXPAND(snd_pcm_set_params, "TODO") \
  EXPAND(snd_pcm_get_params, "TODO") \
  EXPAND(snd_pcm_info_sizeof, "TODO") \
  EXPAND(snd_pcm_info_malloc, "TODO") \
  EXPAND(snd_pcm_info_free, "TODO") \
  EXPAND(snd_pcm_info_copy, "TODO") \
  EXPAND(snd_pcm_info_get_device, "TODO") \
  EXPAND(snd_pcm_info_get_subdevice, "TODO") \
  EXPAND(snd_pcm_info_get_stream, "TODO") \
  EXPAND(snd_pcm_info_get_card, "TODO") \
  EXPAND(snd_pcm_info_get_id, "TODO") \
  EXPAND(snd_pcm_info_get_name, "TODO") \
  EXPAND(snd_pcm_info_get_subdevice_name, "TODO") \
  EXPAND(snd_pcm_info_get_class, "TODO") \
  EXPAND(snd_pcm_info_get_subclass, "TODO") \
  EXPAND(snd_pcm_info_get_subdevices_count, "TODO") \
  EXPAND(snd_pcm_info_get_subdevices_avail, "TODO") \
  EXPAND(snd_pcm_info_get_sync, "TODO") \
  EXPAND(snd_pcm_info_set_device, "TODO") \
  EXPAND(snd_pcm_info_set_subdevice, "TODO") \
  EXPAND(snd_pcm_info_set_stream, "TODO") \
  EXPAND(snd_pcm_hw_params_any, "TODO") \
  EXPAND(snd_pcm_hw_params_can_mmap_sample_resolution, "TODO") \
  EXPAND(snd_pcm_hw_params_is_double, "TODO") \
  EXPAND(snd_pcm_hw_params_is_batch, "TODO") \
  EXPAND(snd_pcm_hw_params_is_block_transfer, "TODO") \
  EXPAND(snd_pcm_hw_params_is_monotonic, "TODO") \
  EXPAND(snd_pcm_hw_params_can_overrange, "TODO") \
  EXPAND(snd_pcm_hw_params_can_pause, "TODO") \
  EXPAND(snd_pcm_hw_params_can_resume, "TODO") \
  EXPAND(snd_pcm_hw_params_is_half_duplex, "TODO") \
  EXPAND(snd_pcm_hw_params_is_joint_duplex, "TODO") \
  EXPAND(snd_pcm_hw_params_can_sync_start, "TODO") \
  EXPAND(snd_pcm_hw_params_can_disable_period_wakeup, "TODO") \
  EXPAND(snd_pcm_hw_params_supports_audio_wallclock_ts, "TODO") \
  EXPAND(snd_pcm_hw_params_supports_audio_ts_type, "TODO") \
  EXPAND(snd_pcm_hw_params_get_rate_numden, "TODO") \
  EXPAND(snd_pcm_hw_params_get_sbits, "TODO") \
  EXPAND(snd_pcm_hw_params_get_fifo_size, "TODO") \
  EXPAND(snd_pcm_hw_params_sizeof, "TODO") \
  EXPAND(snd_pcm_hw_params_malloc, "TODO") \
  EXPAND(snd_pcm_hw_params_free, "TODO") \
  EXPAND(snd_pcm_hw_params_copy, "TODO") \
  EXPAND(snd_pcm_hw_params_get_access, "TODO") \
  EXPAND(snd_pcm_hw_params_test_access, "TODO") \
  EXPAND(snd_pcm_hw_params_set_access, "TODO") \
  EXPAND(snd_pcm_hw_params_set_access_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_access_last, "TODO") \
  EXPAND(snd_pcm_hw_params_set_access_mask, "TODO") \
  EXPAND(snd_pcm_hw_params_get_access_mask, "TODO") \
  EXPAND(snd_pcm_hw_params_get_format, "TODO") \
  EXPAND(snd_pcm_hw_params_test_format, "TODO") \
  EXPAND(snd_pcm_hw_params_set_format, "TODO") \
  EXPAND(snd_pcm_hw_params_set_format_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_format_last, "TODO") \
  EXPAND(snd_pcm_hw_params_set_format_mask, "TODO") \
  EXPAND(snd_pcm_hw_params_get_format_mask, "TODO") \
  EXPAND(snd_pcm_hw_params_get_subformat, "TODO") \
  EXPAND(snd_pcm_hw_params_test_subformat, "TODO") \
  EXPAND(snd_pcm_hw_params_set_subformat, "TODO") \
  EXPAND(snd_pcm_hw_params_set_subformat_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_subformat_last, "TODO") \
  EXPAND(snd_pcm_hw_params_set_subformat_mask, "TODO") \
  EXPAND(snd_pcm_hw_params_get_subformat_mask, "TODO") \
  EXPAND(snd_pcm_hw_params_get_channels, "TODO") \
  EXPAND(snd_pcm_hw_params_get_channels_min, "TODO") \
  EXPAND(snd_pcm_hw_params_get_channels_max, "TODO") \
  EXPAND(snd_pcm_hw_params_test_channels, "TODO") \
  EXPAND(snd_pcm_hw_params_set_channels, "TODO") \
  EXPAND(snd_pcm_hw_params_set_channels_min, "TODO") \
  EXPAND(snd_pcm_hw_params_set_channels_max, "TODO") \
  EXPAND(snd_pcm_hw_params_set_channels_minmax, "TODO") \
  EXPAND(snd_pcm_hw_params_set_channels_near, "TODO") \
  EXPAND(snd_pcm_hw_params_set_channels_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_channels_last, "TODO") \
  EXPAND(snd_pcm_hw_params_get_rate, "TODO") \
  EXPAND(snd_pcm_hw_params_get_rate_min, "TODO") \
  EXPAND(snd_pcm_hw_params_get_rate_max, "TODO") \
  EXPAND(snd_pcm_hw_params_test_rate, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate_min, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate_max, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate_minmax, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate_near, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate_last, "TODO") \
  EXPAND(snd_pcm_hw_params_set_rate_resample, "TODO") \
  EXPAND(snd_pcm_hw_params_get_rate_resample, "TODO") \
  EXPAND(snd_pcm_hw_params_set_export_buffer, "TODO") \
  EXPAND(snd_pcm_hw_params_get_export_buffer, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_wakeup, "TODO") \
  EXPAND(snd_pcm_hw_params_get_period_wakeup, "TODO") \
  EXPAND(snd_pcm_hw_params_get_period_time, "TODO") \
  EXPAND(snd_pcm_hw_params_get_period_time_min, "TODO") \
  EXPAND(snd_pcm_hw_params_get_period_time_max, "TODO") \
  EXPAND(snd_pcm_hw_params_test_period_time, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_time, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_time_min, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_time_max, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_time_minmax, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_time_near, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_time_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_time_last, "TODO") \
  EXPAND(snd_pcm_hw_params_get_period_size, "TODO") \
  EXPAND(snd_pcm_hw_params_get_period_size_min, "TODO") \
  EXPAND(snd_pcm_hw_params_get_period_size_max, "TODO") \
  EXPAND(snd_pcm_hw_params_test_period_size, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size_min, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size_max, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size_minmax, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size_near, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size_last, "TODO") \
  EXPAND(snd_pcm_hw_params_set_period_size_integer, "TODO") \
  EXPAND(snd_pcm_hw_params_get_periods, "TODO") \
  EXPAND(snd_pcm_hw_params_get_periods_min, "TODO") \
  EXPAND(snd_pcm_hw_params_get_periods_max, "TODO") \
  EXPAND(snd_pcm_hw_params_test_periods, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods_min, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods_max, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods_minmax, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods_near, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods_last, "TODO") \
  EXPAND(snd_pcm_hw_params_set_periods_integer, "TODO") \
  EXPAND(snd_pcm_hw_params_get_buffer_time, "TODO") \
  EXPAND(snd_pcm_hw_params_get_buffer_time_min, "TODO") \
  EXPAND(snd_pcm_hw_params_get_buffer_time_max, "TODO") \
  EXPAND(snd_pcm_hw_params_test_buffer_time, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_time, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_time_min, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_time_max, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_time_minmax, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_time_near, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_time_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_time_last, "TODO") \
  EXPAND(snd_pcm_hw_params_get_buffer_size, "TODO") \
  EXPAND(snd_pcm_hw_params_get_buffer_size_min, "TODO") \
  EXPAND(snd_pcm_hw_params_get_buffer_size_max, "TODO") \
  EXPAND(snd_pcm_hw_params_test_buffer_size, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_size, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_size_min, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_size_max, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_size_minmax, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_size_near, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_size_first, "TODO") \
  EXPAND(snd_pcm_hw_params_set_buffer_size_last, "TODO") \
  EXPAND(snd_pcm_hw_params_get_min_align, "TODO") \
  EXPAND(snd_pcm_sw_params_sizeof, "TODO") \
  EXPAND(snd_pcm_sw_params_malloc, "TODO") \
  EXPAND(snd_pcm_sw_params_free, "TODO") \
  EXPAND(snd_pcm_sw_params_copy, "TODO") \
  EXPAND(snd_pcm_sw_params_get_boundary, "TODO") \
  EXPAND(snd_pcm_sw_params_set_tstamp_mode, "TODO") \
  EXPAND(snd_pcm_sw_params_get_tstamp_mode, "TODO") \
  EXPAND(snd_pcm_sw_params_set_tstamp_type, "TODO") \
  EXPAND(snd_pcm_sw_params_get_tstamp_type, "TODO") \
  EXPAND(snd_pcm_sw_params_set_avail_min, "TODO") \
  EXPAND(snd_pcm_sw_params_get_avail_min, "TODO") \
  EXPAND(snd_pcm_sw_params_set_period_event, "TODO") \
  EXPAND(snd_pcm_sw_params_get_period_event, "TODO") \
  EXPAND(snd_pcm_sw_params_set_start_threshold, "TODO") \
  EXPAND(snd_pcm_sw_params_get_start_threshold, "TODO") \
  EXPAND(snd_pcm_sw_params_set_stop_threshold, "TODO") \
  EXPAND(snd_pcm_sw_params_get_stop_threshold, "TODO") \
  EXPAND(snd_pcm_sw_params_set_silence_threshold, "TODO") \
  EXPAND(snd_pcm_sw_params_get_silence_threshold, "TODO") \
  EXPAND(snd_pcm_sw_params_set_silence_size, "TODO") \
  EXPAND(snd_pcm_sw_params_get_silence_size, "TODO") \
  EXPAND(snd_pcm_access_mask_sizeof, "TODO") \
  EXPAND(snd_pcm_access_mask_malloc, "TODO") \
  EXPAND(snd_pcm_access_mask_free, "TODO") \
  EXPAND(snd_pcm_access_mask_copy, "TODO") \
  EXPAND(snd_pcm_access_mask_none, "TODO") \
  EXPAND(snd_pcm_access_mask_any, "TODO") \
  EXPAND(snd_pcm_access_mask_test, "TODO") \
  EXPAND(snd_pcm_access_mask_empty, "TODO") \
  EXPAND(snd_pcm_access_mask_set, "TODO") \
  EXPAND(snd_pcm_access_mask_reset, "TODO") \
  EXPAND(snd_pcm_format_mask_sizeof, "TODO") \
  EXPAND(snd_pcm_format_mask_malloc, "TODO") \
  EXPAND(snd_pcm_format_mask_free, "TODO") \
  EXPAND(snd_pcm_format_mask_copy, "TODO") \
  EXPAND(snd_pcm_format_mask_none, "TODO") \
  EXPAND(snd_pcm_format_mask_any, "TODO") \
  EXPAND(snd_pcm_format_mask_test, "TODO") \
  EXPAND(snd_pcm_format_mask_empty, "TODO") \
  EXPAND(snd_pcm_format_mask_set, "TODO") \
  EXPAND(snd_pcm_format_mask_reset, "TODO") \
  EXPAND(snd_pcm_subformat_mask_sizeof, "TODO") \
  EXPAND(snd_pcm_subformat_mask_malloc, "TODO") \
  EXPAND(snd_pcm_subformat_mask_free, "TODO") \
  EXPAND(snd_pcm_subformat_mask_copy, "TODO") \
  EXPAND(snd_pcm_subformat_mask_none, "TODO") \
  EXPAND(snd_pcm_subformat_mask_any, "TODO") \
  EXPAND(snd_pcm_subformat_mask_test, "TODO") \
  EXPAND(snd_pcm_subformat_mask_empty, "TODO") \
  EXPAND(snd_pcm_subformat_mask_set, "TODO") \
  EXPAND(snd_pcm_subformat_mask_reset, "TODO") \
  EXPAND(snd_pcm_status_sizeof, "TODO") \
  EXPAND(snd_pcm_status_malloc, "TODO") \
  EXPAND(snd_pcm_status_free, "TODO") \
  EXPAND(snd_pcm_status_copy, "TODO") \
  EXPAND(snd_pcm_status_get_state, "TODO") \
  EXPAND(snd_pcm_status_get_trigger_tstamp, "TODO") \
  EXPAND(snd_pcm_status_get_trigger_htstamp, "TODO") \
  EXPAND(snd_pcm_status_get_tstamp, "TODO") \
  EXPAND(snd_pcm_status_get_htstamp, "TODO") \
  EXPAND(snd_pcm_status_get_audio_htstamp, "TODO") \
  EXPAND(snd_pcm_status_get_driver_htstamp, "TODO") \
  EXPAND(snd_pcm_status_get_audio_htstamp_report, "TODO") \
  EXPAND(snd_pcm_status_set_audio_htstamp_config, "TODO") \
  EXPAND(snd_pcm_status_get_delay, "TODO") \
  EXPAND(snd_pcm_status_get_avail, "TODO") \
  EXPAND(snd_pcm_status_get_avail_max, "TODO") \
  EXPAND(snd_pcm_status_get_overrange, "TODO") \
  EXPAND(snd_pcm_type_name, "TODO") \
  EXPAND(snd_pcm_stream_name, "TODO") \
  EXPAND(snd_pcm_access_name, "TODO") \
  EXPAND(snd_pcm_format_name, "TODO") \
  EXPAND(snd_pcm_format_description, "TODO") \
  EXPAND(snd_pcm_subformat_name, "TODO") \
  EXPAND(snd_pcm_subformat_description, "TODO") \
  EXPAND(snd_pcm_format_value, "TODO") \
  EXPAND(snd_pcm_dump, "TODO") \
  EXPAND(snd_pcm_dump_hw_setup, "TODO") \
  EXPAND(snd_pcm_dump_sw_setup, "TODO") \
  EXPAND(snd_pcm_dump_setup, "TODO") \
  EXPAND(snd_pcm_hw_params_dump, "TODO") \
  EXPAND(snd_pcm_sw_params_dump, "TODO") \
  EXPAND(snd_pcm_status_dump, "TODO") \
  EXPAND(snd_pcm_mmap_begin, "TODO") \
  EXPAND(snd_pcm_mmap_commit, "TODO") \
  EXPAND(snd_pcm_mmap_writei, "TODO") \
  EXPAND(snd_pcm_mmap_readi, "TODO") \
  EXPAND(snd_pcm_mmap_writen, "TODO") \
  EXPAND(snd_pcm_mmap_readn, "TODO") \
  EXPAND(snd_pcm_format_signed, "TODO") \
  EXPAND(snd_pcm_format_unsigned, "TODO") \
  EXPAND(snd_pcm_format_linear, "TODO") \
  EXPAND(snd_pcm_format_float, "TODO") \
  EXPAND(snd_pcm_format_little_endian, "TODO") \
  EXPAND(snd_pcm_format_big_endian, "TODO") \
  EXPAND(snd_pcm_format_cpu_endian, "TODO") \
  EXPAND(snd_pcm_format_width, "TODO") \
  EXPAND(snd_pcm_format_physical_width, "TODO") \
  EXPAND(snd_pcm_build_linear_format, "TODO") \
  EXPAND(snd_pcm_format_size, "TODO") \
  EXPAND(snd_pcm_format_silence, "TODO") \
  EXPAND(snd_pcm_format_silence_16, "TODO") \
  EXPAND(snd_pcm_format_silence_32, "TODO") \
  EXPAND(snd_pcm_format_silence_64, "TODO") \
  EXPAND(snd_pcm_format_set_silence, "TODO") \
  EXPAND(snd_pcm_bytes_to_frames, "TODO") \
  EXPAND(snd_pcm_frames_to_bytes, "TODO") \
  EXPAND(snd_pcm_bytes_to_samples, "TODO") \
  EXPAND(snd_pcm_samples_to_bytes, "TODO") \
  EXPAND(snd_pcm_area_silence, "TODO") \
  EXPAND(snd_pcm_areas_silence, "TODO") \
  EXPAND(snd_pcm_area_copy, "TODO") \
  EXPAND(snd_pcm_areas_copy, "TODO") \
  EXPAND(snd_pcm_meter_get_bufsize, "TODO") \
  EXPAND(snd_pcm_meter_get_channels, "TODO") \
  EXPAND(snd_pcm_meter_get_rate, "TODO") \
  EXPAND(snd_pcm_meter_get_now, "TODO") \
  EXPAND(snd_pcm_meter_get_boundary, "TODO") \
  EXPAND(snd_pcm_meter_add_scope, "TODO") \
  EXPAND(snd_pcm_meter_search_scope, "TODO") \
  EXPAND(snd_pcm_scope_malloc, "TODO") \
  EXPAND(snd_pcm_scope_set_ops, "TODO") \
  EXPAND(snd_pcm_scope_set_name, "TODO") \
  EXPAND(snd_pcm_scope_get_name, "TODO") \
  EXPAND(snd_pcm_scope_get_callback_private, "TODO") \
  EXPAND(snd_pcm_scope_set_callback_private, "TODO") \
  EXPAND(snd_pcm_scope_s16_open, "TODO") \
  EXPAND(snd_pcm_scope_s16_get_channel_buffer, "TODO") \
  EXPAND(snd_spcm_init, "TODO") \
  EXPAND(snd_spcm_init_duplex, "TODO") \
  EXPAND(snd_spcm_init_get_params, "TODO") \
  EXPAND(snd_rawmidi_open, "TODO") \
  EXPAND(snd_rawmidi_open_lconf, "TODO") \
  EXPAND(snd_rawmidi_close, "TODO") \
  EXPAND(snd_rawmidi_poll_descriptors_count, "TODO") \
  EXPAND(snd_rawmidi_poll_descriptors, "TODO") \
  EXPAND(snd_rawmidi_poll_descriptors_revents, "TODO") \
  EXPAND(snd_rawmidi_nonblock, "TODO") \
  EXPAND(snd_rawmidi_info_sizeof, "TODO") \
  EXPAND(snd_rawmidi_info_malloc, "TODO") \
  EXPAND(snd_rawmidi_info_free, "TODO") \
  EXPAND(snd_rawmidi_info_copy, "TODO") \
  EXPAND(snd_rawmidi_info_get_device, "TODO") \
  EXPAND(snd_rawmidi_info_get_subdevice, "TODO") \
  EXPAND(snd_rawmidi_info_get_stream, "TODO") \
  EXPAND(snd_rawmidi_info_get_card, "TODO") \
  EXPAND(snd_rawmidi_info_get_flags, "TODO") \
  EXPAND(snd_rawmidi_info_get_id, "TODO") \
  EXPAND(snd_rawmidi_info_get_name, "TODO") \
  EXPAND(snd_rawmidi_info_get_subdevice_name, "TODO") \
  EXPAND(snd_rawmidi_info_get_subdevices_count, "TODO") \
  EXPAND(snd_rawmidi_info_get_subdevices_avail, "TODO") \
  EXPAND(snd_rawmidi_info_set_device, "TODO") \
  EXPAND(snd_rawmidi_info_set_subdevice, "TODO") \
  EXPAND(snd_rawmidi_info_set_stream, "TODO") \
  EXPAND(snd_rawmidi_info, "TODO") \
  EXPAND(snd_rawmidi_params_sizeof, "TODO") \
  EXPAND(snd_rawmidi_params_malloc, "TODO") \
  EXPAND(snd_rawmidi_params_free, "TODO") \
  EXPAND(snd_rawmidi_params_copy, "TODO") \
  EXPAND(snd_rawmidi_params_set_buffer_size, "TODO") \
  EXPAND(snd_rawmidi_params_get_buffer_size, "TODO") \
  EXPAND(snd_rawmidi_params_set_avail_min, "TODO") \
  EXPAND(snd_rawmidi_params_get_avail_min, "TODO") \
  EXPAND(snd_rawmidi_params_set_no_active_sensing, "TODO") \
  EXPAND(snd_rawmidi_params_get_no_active_sensing, "TODO") \
  EXPAND(snd_rawmidi_params, "TODO") \
  EXPAND(snd_rawmidi_params_current, "TODO") \
  EXPAND(snd_rawmidi_status_sizeof, "TODO") \
  EXPAND(snd_rawmidi_status_malloc, "TODO") \
  EXPAND(snd_rawmidi_status_free, "TODO") \
  EXPAND(snd_rawmidi_status_copy, "TODO") \
  EXPAND(snd_rawmidi_status_get_tstamp, "TODO") \
  EXPAND(snd_rawmidi_status_get_avail, "TODO") \
  EXPAND(snd_rawmidi_status_get_xruns, "TODO") \
  EXPAND(snd_rawmidi_status, "TODO") \
  EXPAND(snd_rawmidi_drain, "TODO") \
  EXPAND(snd_rawmidi_drop, "TODO") \
  EXPAND(snd_rawmidi_write, "TODO") \
  EXPAND(snd_rawmidi_read, "TODO") \
  EXPAND(snd_rawmidi_name, "TODO") \
  EXPAND(snd_rawmidi_type, "TODO") \
  EXPAND(snd_rawmidi_stream, "TODO") \
  EXPAND(snd_timer_query_open, "TODO") \
  EXPAND(snd_timer_query_open_lconf, "TODO") \
  EXPAND(snd_timer_query_close, "TODO") \
  EXPAND(snd_timer_query_next_device, "TODO") \
  EXPAND(snd_timer_query_info, "TODO") \
  EXPAND(snd_timer_query_params, "TODO") \
  EXPAND(snd_timer_query_status, "TODO") \
  EXPAND(snd_timer_open, "TODO") \
  EXPAND(snd_timer_open_lconf, "TODO") \
  EXPAND(snd_timer_close, "TODO") \
  EXPAND(snd_timer_poll_descriptors_count, "TODO") \
  EXPAND(snd_timer_poll_descriptors, "TODO") \
  EXPAND(snd_timer_poll_descriptors_revents, "TODO") \
  EXPAND(snd_timer_info, "TODO") \
  EXPAND(snd_timer_params, "TODO") \
  EXPAND(snd_timer_status, "TODO") \
  EXPAND(snd_timer_start, "TODO") \
  EXPAND(snd_timer_stop, "TODO") \
  EXPAND(snd_timer_continue, "TODO") \
  EXPAND(snd_timer_read, "TODO") \
  EXPAND(snd_timer_id_sizeof, "TODO") \
  EXPAND(snd_timer_id_malloc, "TODO") \
  EXPAND(snd_timer_id_free, "TODO") \
  EXPAND(snd_timer_id_copy, "TODO") \
  EXPAND(snd_timer_id_set_class, "TODO") \
  EXPAND(snd_timer_id_get_class, "TODO") \
  EXPAND(snd_timer_id_set_sclass, "TODO") \
  EXPAND(snd_timer_id_get_sclass, "TODO") \
  EXPAND(snd_timer_id_set_card, "TODO") \
  EXPAND(snd_timer_id_get_card, "TODO") \
  EXPAND(snd_timer_id_set_device, "TODO") \
  EXPAND(snd_timer_id_get_device, "TODO") \
  EXPAND(snd_timer_id_set_subdevice, "TODO") \
  EXPAND(snd_timer_id_get_subdevice, "TODO") \
  EXPAND(snd_timer_ginfo_sizeof, "TODO") \
  EXPAND(snd_timer_ginfo_malloc, "TODO") \
  EXPAND(snd_timer_ginfo_free, "TODO") \
  EXPAND(snd_timer_ginfo_copy, "TODO") \
  EXPAND(snd_timer_ginfo_set_tid, "TODO") \
  EXPAND(snd_timer_ginfo_get_tid, "TODO") \
  EXPAND(snd_timer_ginfo_get_flags, "TODO") \
  EXPAND(snd_timer_ginfo_get_card, "TODO") \
  EXPAND(snd_timer_ginfo_get_id, "TODO") \
  EXPAND(snd_timer_ginfo_get_name, "TODO") \
  EXPAND(snd_timer_ginfo_get_resolution, "TODO") \
  EXPAND(snd_timer_ginfo_get_resolution_min, "TODO") \
  EXPAND(snd_timer_ginfo_get_resolution_max, "TODO") \
  EXPAND(snd_timer_ginfo_get_clients, "TODO") \
  EXPAND(snd_timer_info_sizeof, "TODO") \
  EXPAND(snd_timer_info_malloc, "TODO") \
  EXPAND(snd_timer_info_free, "TODO") \
  EXPAND(snd_timer_info_copy, "TODO") \
  EXPAND(snd_timer_info_is_slave, "TODO") \
  EXPAND(snd_timer_info_get_card, "TODO") \
  EXPAND(snd_timer_info_get_id, "TODO") \
  EXPAND(snd_timer_info_get_name, "TODO") \
  EXPAND(snd_timer_info_get_resolution, "TODO") \
  EXPAND(snd_timer_params_sizeof, "TODO") \
  EXPAND(snd_timer_params_malloc, "TODO") \
  EXPAND(snd_timer_params_free, "TODO") \
  EXPAND(snd_timer_params_copy, "TODO") \
  EXPAND(snd_timer_params_set_auto_start, "TODO") \
  EXPAND(snd_timer_params_get_auto_start, "TODO") \
  EXPAND(snd_timer_params_set_exclusive, "TODO") \
  EXPAND(snd_timer_params_get_exclusive, "TODO") \
  EXPAND(snd_timer_params_set_early_event, "TODO") \
  EXPAND(snd_timer_params_get_early_event, "TODO") \
  EXPAND(snd_timer_params_set_ticks, "TODO") \
  EXPAND(snd_timer_params_get_ticks, "TODO") \
  EXPAND(snd_timer_params_set_queue_size, "TODO") \
  EXPAND(snd_timer_params_get_queue_size, "TODO") \
  EXPAND(snd_timer_params_set_filter, "TODO") \
  EXPAND(snd_timer_params_get_filter, "TODO") \
  EXPAND(snd_timer_status_sizeof, "TODO") \
  EXPAND(snd_timer_status_malloc, "TODO") \
  EXPAND(snd_timer_status_free, "TODO") \
  EXPAND(snd_timer_status_copy, "TODO") \
  EXPAND(snd_timer_status_get_timestamp, "TODO") \
  EXPAND(snd_timer_status_get_resolution, "TODO") \
  EXPAND(snd_timer_status_get_lost, "TODO") \
  EXPAND(snd_timer_status_get_overrun, "TODO") \
  EXPAND(snd_timer_status_get_queue, "TODO") \
  EXPAND(snd_timer_info_get_ticks, "TODO") \
  EXPAND(snd_hwdep_open, "TODO") \
  EXPAND(snd_hwdep_close, "TODO") \
  EXPAND(snd_hwdep_poll_descriptors, "TODO") \
  EXPAND(snd_hwdep_poll_descriptors_count, "TODO") \
  EXPAND(snd_hwdep_poll_descriptors_revents, "TODO") \
  EXPAND(snd_hwdep_nonblock, "TODO") \
  EXPAND(snd_hwdep_info, "TODO") \
  EXPAND(snd_hwdep_dsp_status, "TODO") \
  EXPAND(snd_hwdep_dsp_load, "TODO") \
  EXPAND(snd_hwdep_ioctl, "TODO") \
  EXPAND(snd_hwdep_write, "TODO") \
  EXPAND(snd_hwdep_read, "TODO") \
  EXPAND(snd_hwdep_info_sizeof, "TODO") \
  EXPAND(snd_hwdep_info_malloc, "TODO") \
  EXPAND(snd_hwdep_info_free, "TODO") \
  EXPAND(snd_hwdep_info_copy, "TODO") \
  EXPAND(snd_hwdep_info_get_device, "TODO") \
  EXPAND(snd_hwdep_info_get_card, "TODO") \
  EXPAND(snd_hwdep_info_get_id, "TODO") \
  EXPAND(snd_hwdep_info_get_name, "TODO") \
  EXPAND(snd_hwdep_info_get_iface, "TODO") \
  EXPAND(snd_hwdep_info_set_device, "TODO") \
  EXPAND(snd_hwdep_dsp_status_sizeof, "TODO") \
  EXPAND(snd_hwdep_dsp_status_malloc, "TODO") \
  EXPAND(snd_hwdep_dsp_status_free, "TODO") \
  EXPAND(snd_hwdep_dsp_status_copy, "TODO") \
  EXPAND(snd_hwdep_dsp_status_get_version, "TODO") \
  EXPAND(snd_hwdep_dsp_status_get_id, "TODO") \
  EXPAND(snd_hwdep_dsp_status_get_num_dsps, "TODO") \
  EXPAND(snd_hwdep_dsp_status_get_dsp_loaded, "TODO") \
  EXPAND(snd_hwdep_dsp_status_get_chip_ready, "TODO") \
  EXPAND(snd_hwdep_dsp_image_sizeof, "TODO") \
  EXPAND(snd_hwdep_dsp_image_malloc, "TODO") \
  EXPAND(snd_hwdep_dsp_image_free, "TODO") \
  EXPAND(snd_hwdep_dsp_image_copy, "TODO") \
  EXPAND(snd_hwdep_dsp_image_get_index, "TODO") \
  EXPAND(snd_hwdep_dsp_image_get_name, "TODO") \
  EXPAND(snd_hwdep_dsp_image_get_image, "TODO") \
  EXPAND(snd_hwdep_dsp_image_get_length, "TODO") \
  EXPAND(snd_hwdep_dsp_image_set_index, "TODO") \
  EXPAND(snd_hwdep_dsp_image_set_name, "TODO") \
  EXPAND(snd_hwdep_dsp_image_set_image, "TODO") \
  EXPAND(snd_hwdep_dsp_image_set_length, "TODO") \
  EXPAND(snd_card_load, "TODO") \
  EXPAND(snd_card_next, "TODO") \
  EXPAND(snd_card_get_index, "TODO") \
  EXPAND(snd_card_get_name, "TODO") \
  EXPAND(snd_card_get_longname, "TODO") \
  EXPAND(snd_device_name_hint, "TODO") \
  EXPAND(snd_device_name_free_hint, "TODO") \
  EXPAND(snd_device_name_get_hint, "TODO") \
  EXPAND(snd_ctl_open, "TODO") \
  EXPAND(snd_ctl_open_lconf, "TODO") \
  EXPAND(snd_ctl_open_fallback, "TODO") \
  EXPAND(snd_ctl_close, "TODO") \
  EXPAND(snd_ctl_nonblock, "TODO") \
  EXPAND(snd_ctl_poll_descriptors_count, "TODO") \
  EXPAND(snd_ctl_poll_descriptors, "TODO") \
  EXPAND(snd_ctl_poll_descriptors_revents, "TODO") \
  EXPAND(snd_ctl_subscribe_events, "TODO") \
  EXPAND(snd_ctl_card_info, "TODO") \
  EXPAND(snd_ctl_elem_list, "TODO") \
  EXPAND(snd_ctl_elem_info, "TODO") \
  EXPAND(snd_ctl_elem_read, "TODO") \
  EXPAND(snd_ctl_elem_write, "TODO") \
  EXPAND(snd_ctl_elem_lock, "TODO") \
  EXPAND(snd_ctl_elem_unlock, "TODO") \
  EXPAND(snd_ctl_elem_tlv_read, "TODO") \
  EXPAND(snd_ctl_elem_tlv_write, "TODO") \
  EXPAND(snd_ctl_elem_tlv_command, "TODO") \
  EXPAND(snd_ctl_hwdep_next_device, "TODO") \
  EXPAND(snd_ctl_hwdep_info, "TODO") \
  EXPAND(snd_ctl_pcm_next_device, "TODO") \
  EXPAND(snd_ctl_pcm_info, "TODO") \
  EXPAND(snd_ctl_pcm_prefer_subdevice, "TODO") \
  EXPAND(snd_ctl_rawmidi_next_device, "TODO") \
  EXPAND(snd_ctl_rawmidi_info, "TODO") \
  EXPAND(snd_ctl_rawmidi_prefer_subdevice, "TODO") \
  EXPAND(snd_ctl_set_power_state, "TODO") \
  EXPAND(snd_ctl_get_power_state, "TODO") \
  EXPAND(snd_ctl_read, "TODO") \
  EXPAND(snd_ctl_wait, "TODO") \
  EXPAND(snd_ctl_name, "TODO") \
  EXPAND(snd_ctl_type, "TODO") \
  EXPAND(snd_ctl_elem_type_name, "TODO") \
  EXPAND(snd_ctl_elem_iface_name, "TODO") \
  EXPAND(snd_ctl_event_type_name, "TODO") \
  EXPAND(snd_ctl_event_elem_get_mask, "TODO") \
  EXPAND(snd_ctl_event_elem_get_numid, "TODO") \
  EXPAND(snd_ctl_event_elem_get_id, "TODO") \
  EXPAND(snd_ctl_event_elem_get_interface, "TODO") \
  EXPAND(snd_ctl_event_elem_get_device, "TODO") \
  EXPAND(snd_ctl_event_elem_get_subdevice, "TODO") \
  EXPAND(snd_ctl_event_elem_get_name, "TODO") \
  EXPAND(snd_ctl_event_elem_get_index, "TODO") \
  EXPAND(snd_ctl_elem_list_alloc_space, "TODO") \
  EXPAND(snd_ctl_elem_list_free_space, "TODO") \
  EXPAND(snd_ctl_ascii_elem_id_get, "TODO") \
  EXPAND(snd_ctl_ascii_elem_id_parse, "TODO") \
  EXPAND(snd_ctl_ascii_value_parse, "TODO") \
  EXPAND(snd_ctl_elem_id_sizeof, "TODO") \
  EXPAND(snd_ctl_elem_id_malloc, "TODO") \
  EXPAND(snd_ctl_elem_id_free, "TODO") \
  EXPAND(snd_ctl_elem_id_clear, "TODO") \
  EXPAND(snd_ctl_elem_id_copy, "TODO") \
  EXPAND(snd_ctl_elem_id_get_numid, "TODO") \
  EXPAND(snd_ctl_elem_id_get_interface, "TODO") \
  EXPAND(snd_ctl_elem_id_get_device, "TODO") \
  EXPAND(snd_ctl_elem_id_get_subdevice, "TODO") \
  EXPAND(snd_ctl_elem_id_get_name, "TODO") \
  EXPAND(snd_ctl_elem_id_get_index, "TODO") \
  EXPAND(snd_ctl_elem_id_set_numid, "TODO") \
  EXPAND(snd_ctl_elem_id_set_interface, "TODO") \
  EXPAND(snd_ctl_elem_id_set_device, "TODO") \
  EXPAND(snd_ctl_elem_id_set_subdevice, "TODO") \
  EXPAND(snd_ctl_elem_id_set_name, "TODO") \
  EXPAND(snd_ctl_elem_id_set_index, "TODO") \
  EXPAND(snd_ctl_card_info_sizeof, "TODO") \
  EXPAND(snd_ctl_card_info_malloc, "TODO") \
  EXPAND(snd_ctl_card_info_free, "TODO") \
  EXPAND(snd_ctl_card_info_clear, "TODO") \
  EXPAND(snd_ctl_card_info_copy, "TODO") \
  EXPAND(snd_ctl_card_info_get_card, "TODO") \
  EXPAND(snd_ctl_card_info_get_id, "TODO") \
  EXPAND(snd_ctl_card_info_get_driver, "TODO") \
  EXPAND(snd_ctl_card_info_get_name, "TODO") \
  EXPAND(snd_ctl_card_info_get_longname, "TODO") \
  EXPAND(snd_ctl_card_info_get_mixername, "TODO") \
  EXPAND(snd_ctl_card_info_get_components, "TODO") \
  EXPAND(snd_ctl_event_sizeof, "TODO") \
  EXPAND(snd_ctl_event_malloc, "TODO") \
  EXPAND(snd_ctl_event_free, "TODO") \
  EXPAND(snd_ctl_event_clear, "TODO") \
  EXPAND(snd_ctl_event_copy, "TODO") \
  EXPAND(snd_ctl_event_get_type, "TODO") \
  EXPAND(snd_ctl_elem_list_sizeof, "TODO") \
  EXPAND(snd_ctl_elem_list_malloc, "TODO") \
  EXPAND(snd_ctl_elem_list_free, "TODO") \
  EXPAND(snd_ctl_elem_list_clear, "TODO") \
  EXPAND(snd_ctl_elem_list_copy, "TODO") \
  EXPAND(snd_ctl_elem_list_set_offset, "TODO") \
  EXPAND(snd_ctl_elem_list_get_used, "TODO") \
  EXPAND(snd_ctl_elem_list_get_count, "TODO") \
  EXPAND(snd_ctl_elem_list_get_id, "TODO") \
  EXPAND(snd_ctl_elem_list_get_numid, "TODO") \
  EXPAND(snd_ctl_elem_list_get_interface, "TODO") \
  EXPAND(snd_ctl_elem_list_get_device, "TODO") \
  EXPAND(snd_ctl_elem_list_get_subdevice, "TODO") \
  EXPAND(snd_ctl_elem_list_get_name, "TODO") \
  EXPAND(snd_ctl_elem_list_get_index, "TODO") \
  EXPAND(snd_ctl_elem_info_sizeof, "TODO") \
  EXPAND(snd_ctl_elem_info_malloc, "TODO") \
  EXPAND(snd_ctl_elem_info_free, "TODO") \
  EXPAND(snd_ctl_elem_info_clear, "TODO") \
  EXPAND(snd_ctl_elem_info_copy, "TODO") \
  EXPAND(snd_ctl_elem_info_get_type, "TODO") \
  EXPAND(snd_ctl_elem_info_is_readable, "TODO") \
  EXPAND(snd_ctl_elem_info_is_writable, "TODO") \
  EXPAND(snd_ctl_elem_info_is_volatile, "TODO") \
  EXPAND(snd_ctl_elem_info_is_inactive, "TODO") \
  EXPAND(snd_ctl_elem_info_is_locked, "TODO") \
  EXPAND(snd_ctl_elem_info_is_tlv_readable, "TODO") \
  EXPAND(snd_ctl_elem_info_is_tlv_writable, "TODO") \
  EXPAND(snd_ctl_elem_info_is_tlv_commandable, "TODO") \
  EXPAND(snd_ctl_elem_info_is_owner, "TODO") \
  EXPAND(snd_ctl_elem_info_is_user, "TODO") \
  EXPAND(snd_ctl_elem_info_get_owner, "TODO") \
  EXPAND(snd_ctl_elem_info_get_count, "TODO") \
  EXPAND(snd_ctl_elem_info_get_min, "TODO") \
  EXPAND(snd_ctl_elem_info_get_max, "TODO") \
  EXPAND(snd_ctl_elem_info_get_step, "TODO") \
  EXPAND(snd_ctl_elem_info_get_min64, "TODO") \
  EXPAND(snd_ctl_elem_info_get_max64, "TODO") \
  EXPAND(snd_ctl_elem_info_get_step64, "TODO") \
  EXPAND(snd_ctl_elem_info_get_items, "TODO") \
  EXPAND(snd_ctl_elem_info_set_item, "TODO") \
  EXPAND(snd_ctl_elem_info_get_item_name, "TODO") \
  EXPAND(snd_ctl_elem_info_get_dimensions, "TODO") \
  EXPAND(snd_ctl_elem_info_get_dimension, "TODO") \
  EXPAND(snd_ctl_elem_info_get_id, "TODO") \
  EXPAND(snd_ctl_elem_info_get_numid, "TODO") \
  EXPAND(snd_ctl_elem_info_get_interface, "TODO") \
  EXPAND(snd_ctl_elem_info_get_device, "TODO") \
  EXPAND(snd_ctl_elem_info_get_subdevice, "TODO") \
  EXPAND(snd_ctl_elem_info_get_name, "TODO") \
  EXPAND(snd_ctl_elem_info_get_index, "TODO") \
  EXPAND(snd_ctl_elem_info_set_id, "TODO") \
  EXPAND(snd_ctl_elem_info_set_numid, "TODO") \
  EXPAND(snd_ctl_elem_info_set_interface, "TODO") \
  EXPAND(snd_ctl_elem_info_set_device, "TODO") \
  EXPAND(snd_ctl_elem_info_set_subdevice, "TODO") \
  EXPAND(snd_ctl_elem_info_set_name, "TODO") \
  EXPAND(snd_ctl_elem_info_set_index, "TODO") \
  EXPAND(snd_ctl_add_integer_elem_set, "TODO") \
  EXPAND(snd_ctl_add_integer64_elem_set, "TODO") \
  EXPAND(snd_ctl_add_boolean_elem_set, "TODO") \
  EXPAND(snd_ctl_add_bytes_elem_set, "TODO") \
  EXPAND(snd_ctl_elem_add_integer, "TODO") \
  EXPAND(snd_ctl_elem_add_integer64, "TODO") \
  EXPAND(snd_ctl_elem_add_boolean, "TODO") \
  EXPAND(snd_ctl_elem_add_iec958, "TODO") \
  EXPAND(snd_ctl_elem_remove, "TODO") \
  EXPAND(snd_ctl_elem_value_sizeof, "TODO") \
  EXPAND(snd_ctl_elem_value_malloc, "TODO") \
  EXPAND(snd_ctl_elem_value_free, "TODO") \
  EXPAND(snd_ctl_elem_value_clear, "TODO") \
  EXPAND(snd_ctl_elem_value_copy, "TODO") \
  EXPAND(snd_ctl_elem_value_compare, "TODO") \
  EXPAND(snd_ctl_elem_value_get_id, "TODO") \
  EXPAND(snd_ctl_elem_value_get_numid, "TODO") \
  EXPAND(snd_ctl_elem_value_get_interface, "TODO") \
  EXPAND(snd_ctl_elem_value_get_device, "TODO") \
  EXPAND(snd_ctl_elem_value_get_subdevice, "TODO") \
  EXPAND(snd_ctl_elem_value_get_name, "TODO") \
  EXPAND(snd_ctl_elem_value_get_index, "TODO") \
  EXPAND(snd_ctl_elem_value_set_id, "TODO") \
  EXPAND(snd_ctl_elem_value_set_numid, "TODO") \
  EXPAND(snd_ctl_elem_value_set_interface, "TODO") \
  EXPAND(snd_ctl_elem_value_set_device, "TODO") \
  EXPAND(snd_ctl_elem_value_set_subdevice, "TODO") \
  EXPAND(snd_ctl_elem_value_set_name, "TODO") \
  EXPAND(snd_ctl_elem_value_set_index, "TODO") \
  EXPAND(snd_ctl_elem_value_get_boolean, "TODO") \
  EXPAND(snd_ctl_elem_value_get_integer, "TODO") \
  EXPAND(snd_ctl_elem_value_get_integer64, "TODO") \
  EXPAND(snd_ctl_elem_value_get_enumerated, "TODO") \
  EXPAND(snd_ctl_elem_value_get_byte, "TODO") \
  EXPAND(snd_ctl_elem_value_set_boolean, "TODO") \
  EXPAND(snd_ctl_elem_value_set_integer, "TODO") \
  EXPAND(snd_ctl_elem_value_set_integer64, "TODO") \
  EXPAND(snd_ctl_elem_value_set_enumerated, "TODO") \
  EXPAND(snd_ctl_elem_value_set_byte, "TODO") \
  EXPAND(snd_ctl_elem_set_bytes, "TODO") \
  EXPAND(snd_ctl_elem_value_get_bytes, "TODO") \
  EXPAND(snd_ctl_elem_value_get_iec958, "TODO") \
  EXPAND(snd_ctl_elem_value_set_iec958, "TODO") \
  EXPAND(snd_tlv_parse_dB_info, "TODO") \
  EXPAND(snd_tlv_get_dB_range, "TODO") \
  EXPAND(snd_tlv_convert_to_dB, "TODO") \
  EXPAND(snd_tlv_convert_from_dB, "TODO") \
  EXPAND(snd_ctl_get_dB_range, "TODO") \
  EXPAND(snd_ctl_convert_to_dB, "TODO") \
  EXPAND(snd_ctl_convert_from_dB, "TODO") \
  EXPAND(snd_hctl_compare_fast, "TODO") \
  EXPAND(snd_hctl_open, "TODO") \
  EXPAND(snd_hctl_open_ctl, "TODO") \
  EXPAND(snd_hctl_close, "TODO") \
  EXPAND(snd_hctl_nonblock, "TODO") \
  EXPAND(snd_hctl_poll_descriptors_count, "TODO") \
  EXPAND(snd_hctl_poll_descriptors, "TODO") \
  EXPAND(snd_hctl_poll_descriptors_revents, "TODO") \
  EXPAND(snd_hctl_get_count, "TODO") \
  EXPAND(snd_hctl_first_elem, "TODO") \
  EXPAND(snd_hctl_last_elem, "TODO") \
  EXPAND(snd_hctl_find_elem, "TODO") \
  EXPAND(snd_hctl_load, "TODO") \
  EXPAND(snd_hctl_free, "TODO") \
  EXPAND(snd_hctl_handle_events, "TODO") \
  EXPAND(snd_hctl_name, "TODO") \
  EXPAND(snd_hctl_wait, "TODO") \
  EXPAND(snd_hctl_ctl, "TODO") \
  EXPAND(snd_hctl_elem_next, "TODO") \
  EXPAND(snd_hctl_elem_prev, "TODO") \
  EXPAND(snd_hctl_elem_info, "TODO") \
  EXPAND(snd_hctl_elem_read, "TODO") \
  EXPAND(snd_hctl_elem_write, "TODO") \
  EXPAND(snd_hctl_elem_tlv_read, "TODO") \
  EXPAND(snd_hctl_elem_tlv_write, "TODO") \
  EXPAND(snd_hctl_elem_tlv_command, "TODO") \
  EXPAND(snd_hctl_elem_get_hctl, "TODO") \
  EXPAND(snd_hctl_elem_get_id, "TODO") \
  EXPAND(snd_hctl_elem_get_numid, "TODO") \
  EXPAND(snd_hctl_elem_get_interface, "TODO") \
  EXPAND(snd_hctl_elem_get_device, "TODO") \
  EXPAND(snd_hctl_elem_get_subdevice, "TODO") \
  EXPAND(snd_hctl_elem_get_name, "TODO") \
  EXPAND(snd_hctl_elem_get_index, "TODO") \
  EXPAND(snd_sctl_build, "TODO") \
  EXPAND(snd_sctl_free, "TODO") \
  EXPAND(snd_sctl_install, "TODO") \
  EXPAND(snd_sctl_remove, "TODO") \
  EXPAND(snd_mixer_open, "TODO") \
  EXPAND(snd_mixer_close, "TODO") \
  EXPAND(snd_mixer_first_elem, "TODO") \
  EXPAND(snd_mixer_last_elem, "TODO") \
  EXPAND(snd_mixer_handle_events, "TODO") \
  EXPAND(snd_mixer_attach, "TODO") \
  EXPAND(snd_mixer_attach_hctl, "TODO") \
  EXPAND(snd_mixer_detach, "TODO") \
  EXPAND(snd_mixer_detach_hctl, "TODO") \
  EXPAND(snd_mixer_get_hctl, "TODO") \
  EXPAND(snd_mixer_poll_descriptors_count, "TODO") \
  EXPAND(snd_mixer_poll_descriptors, "TODO") \
  EXPAND(snd_mixer_poll_descriptors_revents, "TODO") \
  EXPAND(snd_mixer_load, "TODO") \
  EXPAND(snd_mixer_free, "TODO") \
  EXPAND(snd_mixer_wait, "TODO") \
  EXPAND(snd_mixer_get_count, "TODO") \
  EXPAND(snd_mixer_class_unregister, "TODO") \
  EXPAND(snd_mixer_elem_next, "TODO") \
  EXPAND(snd_mixer_elem_prev, "TODO") \
  EXPAND(snd_mixer_elem_get_callback_private, "TODO") \
  EXPAND(snd_mixer_elem_get_type, "TODO") \
  EXPAND(snd_mixer_class_register, "TODO") \
  EXPAND(snd_mixer_elem_add, "TODO") \
  EXPAND(snd_mixer_elem_remove, "TODO") \
  EXPAND(snd_mixer_elem_free, "TODO") \
  EXPAND(snd_mixer_elem_info, "TODO") \
  EXPAND(snd_mixer_elem_value, "TODO") \
  EXPAND(snd_mixer_elem_attach, "TODO") \
  EXPAND(snd_mixer_elem_detach, "TODO") \
  EXPAND(snd_mixer_elem_empty, "TODO") \
  EXPAND(snd_mixer_elem_get_private, "TODO") \
  EXPAND(snd_mixer_class_sizeof, "TODO") \
  EXPAND(snd_mixer_class_malloc, "TODO") \
  EXPAND(snd_mixer_class_free, "TODO") \
  EXPAND(snd_mixer_class_copy, "TODO") \
  EXPAND(snd_mixer_selem_channel_name, "TODO") \
  EXPAND(snd_mixer_selem_register, "TODO") \
  EXPAND(snd_mixer_selem_get_id, "TODO") \
  EXPAND(snd_mixer_selem_get_name, "TODO") \
  EXPAND(snd_mixer_selem_get_index, "TODO") \
  EXPAND(snd_mixer_find_selem, "TODO") \
  EXPAND(snd_mixer_selem_is_active, "TODO") \
  EXPAND(snd_mixer_selem_is_playback_mono, "TODO") \
  EXPAND(snd_mixer_selem_has_playback_channel, "TODO") \
  EXPAND(snd_mixer_selem_is_capture_mono, "TODO") \
  EXPAND(snd_mixer_selem_has_capture_channel, "TODO") \
  EXPAND(snd_mixer_selem_get_capture_group, "TODO") \
  EXPAND(snd_mixer_selem_has_common_volume, "TODO") \
  EXPAND(snd_mixer_selem_has_playback_volume, "TODO") \
  EXPAND(snd_mixer_selem_has_playback_volume_joined, "TODO") \
  EXPAND(snd_mixer_selem_has_capture_volume, "TODO") \
  EXPAND(snd_mixer_selem_has_capture_volume_joined, "TODO") \
  EXPAND(snd_mixer_selem_has_common_switch, "TODO") \
  EXPAND(snd_mixer_selem_has_playback_switch, "TODO") \
  EXPAND(snd_mixer_selem_has_playback_switch_joined, "TODO") \
  EXPAND(snd_mixer_selem_has_capture_switch, "TODO") \
  EXPAND(snd_mixer_selem_has_capture_switch_joined, "TODO") \
  EXPAND(snd_mixer_selem_has_capture_switch_exclusive, "TODO") \
  EXPAND(snd_mixer_selem_ask_playback_vol_dB, "TODO") \
  EXPAND(snd_mixer_selem_ask_capture_vol_dB, "TODO") \
  EXPAND(snd_mixer_selem_ask_playback_dB_vol, "TODO") \
  EXPAND(snd_mixer_selem_ask_capture_dB_vol, "TODO") \
  EXPAND(snd_mixer_selem_get_playback_volume, "TODO") \
  EXPAND(snd_mixer_selem_get_capture_volume, "TODO") \
  EXPAND(snd_mixer_selem_get_playback_dB, "TODO") \
  EXPAND(snd_mixer_selem_get_capture_dB, "TODO") \
  EXPAND(snd_mixer_selem_get_playback_switch, "TODO") \
  EXPAND(snd_mixer_selem_get_capture_switch, "TODO") \
  EXPAND(snd_mixer_selem_set_playback_volume, "TODO") \
  EXPAND(snd_mixer_selem_set_capture_volume, "TODO") \
  EXPAND(snd_mixer_selem_set_playback_dB, "TODO") \
  EXPAND(snd_mixer_selem_set_capture_dB, "TODO") \
  EXPAND(snd_mixer_selem_set_playback_volume_all, "TODO") \
  EXPAND(snd_mixer_selem_set_capture_volume_all, "TODO") \
  EXPAND(snd_mixer_selem_set_playback_dB_all, "TODO") \
  EXPAND(snd_mixer_selem_set_capture_dB_all, "TODO") \
  EXPAND(snd_mixer_selem_set_playback_switch, "TODO") \
  EXPAND(snd_mixer_selem_set_capture_switch, "TODO") \
  EXPAND(snd_mixer_selem_set_playback_switch_all, "TODO") \
  EXPAND(snd_mixer_selem_set_capture_switch_all, "TODO") \
  EXPAND(snd_mixer_selem_get_playback_volume_range, "TODO") \
  EXPAND(snd_mixer_selem_get_playback_dB_range, "TODO") \
  EXPAND(snd_mixer_selem_set_playback_volume_range, "TODO") \
  EXPAND(snd_mixer_selem_get_capture_volume_range, "TODO") \
  EXPAND(snd_mixer_selem_get_capture_dB_range, "TODO") \
  EXPAND(snd_mixer_selem_set_capture_volume_range, "TODO") \
  EXPAND(snd_mixer_selem_is_enumerated, "TODO") \
  EXPAND(snd_mixer_selem_is_enum_playback, "TODO") \
  EXPAND(snd_mixer_selem_is_enum_capture, "TODO") \
  EXPAND(snd_mixer_selem_get_enum_items, "TODO") \
  EXPAND(snd_mixer_selem_get_enum_item_name, "TODO") \
  EXPAND(snd_mixer_selem_get_enum_item, "TODO") \
  EXPAND(snd_mixer_selem_set_enum_item, "TODO") \
  EXPAND(snd_mixer_selem_id_sizeof, "TODO") \
  EXPAND(snd_mixer_selem_id_malloc, "TODO") \
  EXPAND(snd_mixer_selem_id_free, "TODO") \
  EXPAND(snd_mixer_selem_id_copy, "TODO") \
  EXPAND(snd_mixer_selem_id_get_name, "TODO") \
  EXPAND(snd_mixer_selem_id_get_index, "TODO") \
  EXPAND(snd_mixer_selem_id_set_name, "TODO") \
  EXPAND(snd_mixer_selem_id_set_index, "TODO") \
  EXPAND(snd_mixer_selem_id_parse, "TODO") \
  EXPAND(snd_seq_open, "TODO") \
  EXPAND(snd_seq_open_lconf, "TODO") \
  EXPAND(snd_seq_name, "TODO") \
  EXPAND(snd_seq_type, "TODO") \
  EXPAND(snd_seq_close, "TODO") \
  EXPAND(snd_seq_poll_descriptors_count, "TODO") \
  EXPAND(snd_seq_poll_descriptors, "TODO") \
  EXPAND(snd_seq_poll_descriptors_revents, "TODO") \
  EXPAND(snd_seq_nonblock, "TODO") \
  EXPAND(snd_seq_client_id, "TODO") \
  EXPAND(snd_seq_get_output_buffer_size, "TODO") \
  EXPAND(snd_seq_get_input_buffer_size, "TODO") \
  EXPAND(snd_seq_set_output_buffer_size, "TODO") \
  EXPAND(snd_seq_set_input_buffer_size, "TODO") \
  EXPAND(snd_seq_system_info_sizeof, "TODO") \
  EXPAND(snd_seq_system_info_malloc, "TODO") \
  EXPAND(snd_seq_system_info_free, "TODO") \
  EXPAND(snd_seq_system_info_copy, "TODO") \
  EXPAND(snd_seq_system_info_get_queues, "TODO") \
  EXPAND(snd_seq_system_info_get_clients, "TODO") \
  EXPAND(snd_seq_system_info_get_ports, "TODO") \
  EXPAND(snd_seq_system_info_get_channels, "TODO") \
  EXPAND(snd_seq_system_info_get_cur_clients, "TODO") \
  EXPAND(snd_seq_system_info_get_cur_queues, "TODO") \
  EXPAND(snd_seq_system_info, "TODO") \
  EXPAND(snd_seq_client_info_sizeof, "TODO") \
  EXPAND(snd_seq_client_info_malloc, "TODO") \
  EXPAND(snd_seq_client_info_free, "TODO") \
  EXPAND(snd_seq_client_info_copy, "TODO") \
  EXPAND(snd_seq_client_info_get_client, "TODO") \
  EXPAND(snd_seq_client_info_get_type, "TODO") \
  EXPAND(snd_seq_client_info_get_name, "TODO") \
  EXPAND(snd_seq_client_info_get_broadcast_filter, "TODO") \
  EXPAND(snd_seq_client_info_get_error_bounce, "TODO") \
  EXPAND(snd_seq_client_info_get_card, "TODO") \
  EXPAND(snd_seq_client_info_get_pid, "TODO") \
  EXPAND(snd_seq_client_info_get_event_filter, "TODO") \
  EXPAND(snd_seq_client_info_get_num_ports, "TODO") \
  EXPAND(snd_seq_client_info_get_event_lost, "TODO") \
  EXPAND(snd_seq_client_info_set_client, "TODO") \
  EXPAND(snd_seq_client_info_set_name, "TODO") \
  EXPAND(snd_seq_client_info_set_broadcast_filter, "TODO") \
  EXPAND(snd_seq_client_info_set_error_bounce, "TODO") \
  EXPAND(snd_seq_client_info_set_event_filter, "TODO") \
  EXPAND(snd_seq_client_info_event_filter_clear, "TODO") \
  EXPAND(snd_seq_client_info_event_filter_add, "TODO") \
  EXPAND(snd_seq_client_info_event_filter_del, "TODO") \
  EXPAND(snd_seq_client_info_event_filter_check, "TODO") \
  EXPAND(snd_seq_get_client_info, "TODO") \
  EXPAND(snd_seq_get_any_client_info, "TODO") \
  EXPAND(snd_seq_set_client_info, "TODO") \
  EXPAND(snd_seq_query_next_client, "TODO") \
  EXPAND(snd_seq_client_pool_sizeof, "TODO") \
  EXPAND(snd_seq_client_pool_malloc, "TODO") \
  EXPAND(snd_seq_client_pool_free, "TODO") \
  EXPAND(snd_seq_client_pool_copy, "TODO") \
  EXPAND(snd_seq_client_pool_get_client, "TODO") \
  EXPAND(snd_seq_client_pool_get_output_pool, "TODO") \
  EXPAND(snd_seq_client_pool_get_input_pool, "TODO") \
  EXPAND(snd_seq_client_pool_get_output_room, "TODO") \
  EXPAND(snd_seq_client_pool_get_output_free, "TODO") \
  EXPAND(snd_seq_client_pool_get_input_free, "TODO") \
  EXPAND(snd_seq_client_pool_set_output_pool, "TODO") \
  EXPAND(snd_seq_client_pool_set_input_pool, "TODO") \
  EXPAND(snd_seq_client_pool_set_output_room, "TODO") \
  EXPAND(snd_seq_get_client_pool, "TODO") \
  EXPAND(snd_seq_set_client_pool, "TODO") \
  EXPAND(snd_seq_port_info_sizeof, "TODO") \
  EXPAND(snd_seq_port_info_malloc, "TODO") \
  EXPAND(snd_seq_port_info_free, "TODO") \
  EXPAND(snd_seq_port_info_copy, "TODO") \
  EXPAND(snd_seq_port_info_get_client, "TODO") \
  EXPAND(snd_seq_port_info_get_port, "TODO") \
  EXPAND(snd_seq_port_info_get_addr, "TODO") \
  EXPAND(snd_seq_port_info_get_name, "TODO") \
  EXPAND(snd_seq_port_info_get_capability, "TODO") \
  EXPAND(snd_seq_port_info_get_type, "TODO") \
  EXPAND(snd_seq_port_info_get_midi_channels, "TODO") \
  EXPAND(snd_seq_port_info_get_midi_voices, "TODO") \
  EXPAND(snd_seq_port_info_get_synth_voices, "TODO") \
  EXPAND(snd_seq_port_info_get_read_use, "TODO") \
  EXPAND(snd_seq_port_info_get_write_use, "TODO") \
  EXPAND(snd_seq_port_info_get_port_specified, "TODO") \
  EXPAND(snd_seq_port_info_get_timestamping, "TODO") \
  EXPAND(snd_seq_port_info_get_timestamp_real, "TODO") \
  EXPAND(snd_seq_port_info_get_timestamp_queue, "TODO") \
  EXPAND(snd_seq_port_info_set_client, "TODO") \
  EXPAND(snd_seq_port_info_set_port, "TODO") \
  EXPAND(snd_seq_port_info_set_addr, "TODO") \
  EXPAND(snd_seq_port_info_set_name, "TODO") \
  EXPAND(snd_seq_port_info_set_capability, "TODO") \
  EXPAND(snd_seq_port_info_set_type, "TODO") \
  EXPAND(snd_seq_port_info_set_midi_channels, "TODO") \
  EXPAND(snd_seq_port_info_set_midi_voices, "TODO") \
  EXPAND(snd_seq_port_info_set_synth_voices, "TODO") \
  EXPAND(snd_seq_port_info_set_port_specified, "TODO") \
  EXPAND(snd_seq_port_info_set_timestamping, "TODO") \
  EXPAND(snd_seq_port_info_set_timestamp_real, "TODO") \
  EXPAND(snd_seq_port_info_set_timestamp_queue, "TODO") \
  EXPAND(snd_seq_create_port, "TODO") \
  EXPAND(snd_seq_delete_port, "TODO") \
  EXPAND(snd_seq_get_port_info, "TODO") \
  EXPAND(snd_seq_get_any_port_info, "TODO") \
  EXPAND(snd_seq_set_port_info, "TODO") \
  EXPAND(snd_seq_query_next_port, "TODO") \
  EXPAND(snd_seq_port_subscribe_sizeof, "TODO") \
  EXPAND(snd_seq_port_subscribe_malloc, "TODO") \
  EXPAND(snd_seq_port_subscribe_free, "TODO") \
  EXPAND(snd_seq_port_subscribe_copy, "TODO") \
  EXPAND(snd_seq_port_subscribe_get_sender, "TODO") \
  EXPAND(snd_seq_port_subscribe_get_dest, "TODO") \
  EXPAND(snd_seq_port_subscribe_get_queue, "TODO") \
  EXPAND(snd_seq_port_subscribe_get_exclusive, "TODO") \
  EXPAND(snd_seq_port_subscribe_get_time_update, "TODO") \
  EXPAND(snd_seq_port_subscribe_get_time_real, "TODO") \
  EXPAND(snd_seq_port_subscribe_set_sender, "TODO") \
  EXPAND(snd_seq_port_subscribe_set_dest, "TODO") \
  EXPAND(snd_seq_port_subscribe_set_queue, "TODO") \
  EXPAND(snd_seq_port_subscribe_set_exclusive, "TODO") \
  EXPAND(snd_seq_port_subscribe_set_time_update, "TODO") \
  EXPAND(snd_seq_port_subscribe_set_time_real, "TODO") \
  EXPAND(snd_seq_get_port_subscription, "TODO") \
  EXPAND(snd_seq_subscribe_port, "TODO") \
  EXPAND(snd_seq_unsubscribe_port, "TODO") \
  EXPAND(snd_seq_query_subscribe_sizeof, "TODO") \
  EXPAND(snd_seq_query_subscribe_malloc, "TODO") \
  EXPAND(snd_seq_query_subscribe_free, "TODO") \
  EXPAND(snd_seq_query_subscribe_copy, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_client, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_port, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_root, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_type, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_index, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_num_subs, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_addr, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_queue, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_exclusive, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_time_update, "TODO") \
  EXPAND(snd_seq_query_subscribe_get_time_real, "TODO") \
  EXPAND(snd_seq_query_subscribe_set_client, "TODO") \
  EXPAND(snd_seq_query_subscribe_set_port, "TODO") \
  EXPAND(snd_seq_query_subscribe_set_root, "TODO") \
  EXPAND(snd_seq_query_subscribe_set_type, "TODO") \
  EXPAND(snd_seq_query_subscribe_set_index, "TODO") \
  EXPAND(snd_seq_query_port_subscribers, "TODO") \
  EXPAND(snd_seq_queue_info_sizeof, "TODO") \
  EXPAND(snd_seq_queue_info_malloc, "TODO") \
  EXPAND(snd_seq_queue_info_free, "TODO") \
  EXPAND(snd_seq_queue_info_copy, "TODO") \
  EXPAND(snd_seq_queue_info_get_queue, "TODO") \
  EXPAND(snd_seq_queue_info_get_name, "TODO") \
  EXPAND(snd_seq_queue_info_get_owner, "TODO") \
  EXPAND(snd_seq_queue_info_get_locked, "TODO") \
  EXPAND(snd_seq_queue_info_get_flags, "TODO") \
  EXPAND(snd_seq_queue_info_set_name, "TODO") \
  EXPAND(snd_seq_queue_info_set_owner, "TODO") \
  EXPAND(snd_seq_queue_info_set_locked, "TODO") \
  EXPAND(snd_seq_queue_info_set_flags, "TODO") \
  EXPAND(snd_seq_create_queue, "TODO") \
  EXPAND(snd_seq_alloc_named_queue, "TODO") \
  EXPAND(snd_seq_alloc_queue, "TODO") \
  EXPAND(snd_seq_free_queue, "TODO") \
  EXPAND(snd_seq_get_queue_info, "TODO") \
  EXPAND(snd_seq_set_queue_info, "TODO") \
  EXPAND(snd_seq_query_named_queue, "TODO") \
  EXPAND(snd_seq_get_queue_usage, "TODO") \
  EXPAND(snd_seq_set_queue_usage, "TODO") \
  EXPAND(snd_seq_queue_status_sizeof, "TODO") \
  EXPAND(snd_seq_queue_status_malloc, "TODO") \
  EXPAND(snd_seq_queue_status_free, "TODO") \
  EXPAND(snd_seq_queue_status_copy, "TODO") \
  EXPAND(snd_seq_queue_status_get_queue, "TODO") \
  EXPAND(snd_seq_queue_status_get_events, "TODO") \
  EXPAND(snd_seq_queue_status_get_tick_time, "TODO") \
  EXPAND(snd_seq_queue_status_get_real_time, "TODO") \
  EXPAND(snd_seq_queue_status_get_status, "TODO") \
  EXPAND(snd_seq_get_queue_status, "TODO") \
  EXPAND(snd_seq_queue_tempo_sizeof, "TODO") \
  EXPAND(snd_seq_queue_tempo_malloc, "TODO") \
  EXPAND(snd_seq_queue_tempo_free, "TODO") \
  EXPAND(snd_seq_queue_tempo_copy, "TODO") \
  EXPAND(snd_seq_queue_tempo_get_queue, "TODO") \
  EXPAND(snd_seq_queue_tempo_get_tempo, "TODO") \
  EXPAND(snd_seq_queue_tempo_get_ppq, "TODO") \
  EXPAND(snd_seq_queue_tempo_get_skew, "TODO") \
  EXPAND(snd_seq_queue_tempo_get_skew_base, "TODO") \
  EXPAND(snd_seq_queue_tempo_set_tempo, "TODO") \
  EXPAND(snd_seq_queue_tempo_set_ppq, "TODO") \
  EXPAND(snd_seq_queue_tempo_set_skew, "TODO") \
  EXPAND(snd_seq_queue_tempo_set_skew_base, "TODO") \
  EXPAND(snd_seq_get_queue_tempo, "TODO") \
  EXPAND(snd_seq_set_queue_tempo, "TODO") \
  EXPAND(snd_seq_queue_timer_sizeof, "TODO") \
  EXPAND(snd_seq_queue_timer_malloc, "TODO") \
  EXPAND(snd_seq_queue_timer_free, "TODO") \
  EXPAND(snd_seq_queue_timer_copy, "TODO") \
  EXPAND(snd_seq_queue_timer_get_queue, "TODO") \
  EXPAND(snd_seq_queue_timer_get_type, "TODO") \
  EXPAND(snd_seq_queue_timer_get_id, "TODO") \
  EXPAND(snd_seq_queue_timer_get_resolution, "TODO") \
  EXPAND(snd_seq_queue_timer_set_type, "TODO") \
  EXPAND(snd_seq_queue_timer_set_id, "TODO") \
  EXPAND(snd_seq_queue_timer_set_resolution, "TODO") \
  EXPAND(snd_seq_get_queue_timer, "TODO") \
  EXPAND(snd_seq_set_queue_timer, "TODO") \
  EXPAND(snd_seq_free_event, "TODO") \
  EXPAND(snd_seq_event_length, "TODO") \
  EXPAND(snd_seq_event_output, "TODO") \
  EXPAND(snd_seq_event_output_buffer, "TODO") \
  EXPAND(snd_seq_event_output_direct, "TODO") \
  EXPAND(snd_seq_event_input, "TODO") \
  EXPAND(snd_seq_event_input_pending, "TODO") \
  EXPAND(snd_seq_drain_output, "TODO") \
  EXPAND(snd_seq_event_output_pending, "TODO") \
  EXPAND(snd_seq_extract_output, "TODO") \
  EXPAND(snd_seq_drop_output, "TODO") \
  EXPAND(snd_seq_drop_output_buffer, "TODO") \
  EXPAND(snd_seq_drop_input, "TODO") \
  EXPAND(snd_seq_drop_input_buffer, "TODO") \
  EXPAND(snd_seq_remove_events_sizeof, "TODO") \
  EXPAND(snd_seq_remove_events_malloc, "TODO") \
  EXPAND(snd_seq_remove_events_free, "TODO") \
  EXPAND(snd_seq_remove_events_copy, "TODO") \
  EXPAND(snd_seq_remove_events_get_condition, "TODO") \
  EXPAND(snd_seq_remove_events_get_queue, "TODO") \
  EXPAND(snd_seq_remove_events_get_time, "TODO") \
  EXPAND(snd_seq_remove_events_get_dest, "TODO") \
  EXPAND(snd_seq_remove_events_get_channel, "TODO") \
  EXPAND(snd_seq_remove_events_get_event_type, "TODO") \
  EXPAND(snd_seq_remove_events_get_tag, "TODO") \
  EXPAND(snd_seq_remove_events_set_condition, "TODO") \
  EXPAND(snd_seq_remove_events_set_queue, "TODO") \
  EXPAND(snd_seq_remove_events_set_time, "TODO") \
  EXPAND(snd_seq_remove_events_set_dest, "TODO") \
  EXPAND(snd_seq_remove_events_set_channel, "TODO") \
  EXPAND(snd_seq_remove_events_set_event_type, "TODO") \
  EXPAND(snd_seq_remove_events_set_tag, "TODO") \
  EXPAND(snd_seq_remove_events, "TODO") \
  EXPAND(snd_seq_set_bit, "TODO") \
  EXPAND(snd_seq_unset_bit, "TODO") \
  EXPAND(snd_seq_change_bit, "TODO") \
  EXPAND(snd_seq_get_bit, "TODO") \
  EXPAND(snd_seq_control_queue, "TODO") \
  EXPAND(snd_seq_create_simple_port, "TODO") \
  EXPAND(snd_seq_delete_simple_port, "TODO") \
  EXPAND(snd_seq_connect_from, "TODO") \
  EXPAND(snd_seq_connect_to, "TODO") \
  EXPAND(snd_seq_disconnect_from, "TODO") \
  EXPAND(snd_seq_disconnect_to, "TODO") \
  EXPAND(snd_seq_set_client_name, "TODO") \
  EXPAND(snd_seq_set_client_event_filter, "TODO") \
  EXPAND(snd_seq_set_client_pool_output, "TODO") \
  EXPAND(snd_seq_set_client_pool_output_room, "TODO") \
  EXPAND(snd_seq_set_client_pool_input, "TODO") \
  EXPAND(snd_seq_sync_output_queue, "TODO") \
  EXPAND(snd_seq_parse_address, "TODO") \
  EXPAND(snd_seq_reset_pool_output, "TODO") \
  EXPAND(snd_seq_reset_pool_input, "TODO") \
  EXPAND(snd_midi_event_new, "TODO") \
  EXPAND(snd_midi_event_resize_buffer, "TODO") \
  EXPAND(snd_midi_event_free, "TODO") \
  EXPAND(snd_midi_event_init, "TODO") \
  EXPAND(snd_midi_event_reset_encode, "TODO") \
  EXPAND(snd_midi_event_reset_decode, "TODO") \
  EXPAND(snd_midi_event_no_status, "TODO") \
  EXPAND(snd_midi_event_encode, "TODO") \
  EXPAND(snd_midi_event_encode_byte, "TODO") \
  EXPAND(snd_midi_event_decode, "TODO") \


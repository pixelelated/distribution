extern "C" {
MAKE_THUNK(libwayland_client, wl_proxy_destroy, "0xbc, 0xce, 0x2d, 0xd1, 0xe0, 0xff, 0xf7, 0x53, 0xc8, 0x16, 0xfe, 0x93, 0x92, 0x88, 0x25, 0x73, 0x56, 0xc0, 0xbb, 0xa2, 0x6e, 0x30, 0x68, 0xda, 0x2f, 0xdd, 0x99, 0x7a, 0xb7, 0x34, 0x8d, 0xf9")
MAKE_THUNK(libwayland_client, wl_display_connect, "0x4e, 0xb7, 0x12, 0x6f, 0x9a, 0x57, 0x1f, 0xc9, 0xb, 0x11, 0xf, 0x22, 0xf2, 0xb3, 0x6f, 0xec, 0x38, 0x6f, 0x32, 0xc, 0xed, 0x1b, 0xad, 0xc0, 0xbe, 0x52, 0x75, 0x68, 0xb2, 0x34, 0xad, 0x9e")
MAKE_THUNK(libwayland_client, wl_display_flush, "0xeb, 0xa7, 0x99, 0xb3, 0xe1, 0xae, 0xcb, 0xad, 0xf0, 0x2, 0x57, 0xaf, 0x6a, 0xb9, 0x29, 0x8, 0x9a, 0x1a, 0x98, 0x7b, 0xc, 0x71, 0x10, 0x9e, 0xdd, 0x98, 0xf0, 0x13, 0x71, 0xd1, 0x11, 0xdf")
MAKE_THUNK(libwayland_client, wl_display_cancel_read, "0xef, 0xe3, 0x92, 0x33, 0x0, 0x4a, 0xf9, 0xe3, 0x3f, 0x52, 0x22, 0xea, 0x9, 0xd4, 0x2b, 0x81, 0xfd, 0x74, 0xb7, 0x55, 0xef, 0xd9, 0x5c, 0x62, 0x71, 0x9a, 0x3c, 0xfa, 0x4, 0xc3, 0xa9, 0x6a")
MAKE_THUNK(libwayland_client, wl_display_create_queue, "0xa3, 0x4b, 0x75, 0xd, 0xa2, 0x58, 0xbd, 0xd0, 0x42, 0xaf, 0x53, 0xf3, 0x21, 0xf1, 0xd1, 0xaf, 0x9f, 0x71, 0xef, 0x5a, 0x12, 0xb3, 0x96, 0x16, 0x19, 0xb8, 0xb4, 0xb4, 0x4a, 0xf1, 0x88, 0x59")
MAKE_THUNK(libwayland_client, wl_display_disconnect, "0x0, 0xff, 0x4f, 0x3b, 0x93, 0x31, 0x5e, 0x0, 0x53, 0x9e, 0x85, 0x87, 0xaa, 0x2f, 0x28, 0x8b, 0x4d, 0xcd, 0xd7, 0x2c, 0x1d, 0xee, 0x21, 0xe5, 0x78, 0x96, 0x58, 0x7b, 0x69, 0x8, 0x1f, 0xe3")
MAKE_THUNK(libwayland_client, wl_display_dispatch, "0x28, 0xaf, 0x72, 0x5, 0xd0, 0xa7, 0xdd, 0x47, 0x74, 0xf1, 0x4b, 0xf8, 0xef, 0x76, 0x5f, 0xf3, 0x83, 0xb1, 0x82, 0xc6, 0x53, 0xd8, 0xf0, 0x4e, 0x9f, 0x86, 0x9b, 0x89, 0xc6, 0x59, 0xc3, 0x4d")
MAKE_THUNK(libwayland_client, wl_display_dispatch_pending, "0x9e, 0x5b, 0x59, 0x8a, 0xfb, 0xf2, 0x3d, 0x64, 0xda, 0xd1, 0xa3, 0x9d, 0x79, 0x1a, 0x81, 0xac, 0xf0, 0xe3, 0x63, 0x38, 0xae, 0xb9, 0x72, 0x93, 0x6c, 0xb3, 0xb1, 0x67, 0xdd, 0xce, 0x17, 0x33")
MAKE_THUNK(libwayland_client, wl_display_dispatch_queue, "0x78, 0xa2, 0xfc, 0xa1, 0x93, 0x92, 0x24, 0x9d, 0x7a, 0x9f, 0x15, 0x9f, 0x64, 0xa0, 0x4e, 0x2f, 0xdf, 0xba, 0x90, 0x29, 0xb0, 0x13, 0xbc, 0xe7, 0x6b, 0xa6, 0xb6, 0x77, 0x11, 0x89, 0xa0, 0xa7")
MAKE_THUNK(libwayland_client, wl_display_dispatch_queue_pending, "0x41, 0x97, 0x5b, 0x4, 0x2e, 0x8, 0xe0, 0xe3, 0xb2, 0x86, 0x9, 0x5b, 0x22, 0x63, 0x41, 0xb, 0x75, 0x97, 0xcf, 0xaf, 0xc9, 0x20, 0xfa, 0x7, 0x52, 0x2c, 0x84, 0x2a, 0x73, 0x86, 0xb, 0xb1")
MAKE_THUNK(libwayland_client, wl_display_get_error, "0x8a, 0x16, 0xcf, 0xe3, 0xc0, 0x2f, 0x37, 0x58, 0x18, 0x5b, 0x6a, 0x68, 0xca, 0x95, 0xe9, 0xbd, 0x3b, 0x85, 0xc, 0xae, 0x3f, 0xc2, 0xa9, 0xe2, 0x2d, 0x8c, 0x1c, 0xd2, 0x6b, 0x52, 0x81, 0x16")
MAKE_THUNK(libwayland_client, wl_display_prepare_read, "0x89, 0x6b, 0x9b, 0xe8, 0x16, 0x3a, 0x39, 0x37, 0x8b, 0xad, 0x26, 0xad, 0x21, 0xe, 0xc4, 0x3b, 0x15, 0xe9, 0x75, 0x13, 0x76, 0x60, 0x24, 0x9d, 0xad, 0x1e, 0x34, 0x9c, 0x90, 0x16, 0xf4, 0x58")
MAKE_THUNK(libwayland_client, wl_display_prepare_read_queue, "0x66, 0x4e, 0x6c, 0x2c, 0x2f, 0xe7, 0xac, 0xbb, 0xf4, 0xcd, 0xc3, 0xd0, 0x4, 0xdf, 0x54, 0x2f, 0xfd, 0x2c, 0xa8, 0xf1, 0x0, 0x9c, 0xde, 0x83, 0x32, 0x7f, 0x3a, 0xd6, 0xf7, 0xa0, 0xb1, 0xc2")
MAKE_THUNK(libwayland_client, wl_display_read_events, "0x4d, 0xb5, 0x80, 0x9f, 0xf4, 0xa2, 0x42, 0x56, 0xb, 0x5f, 0x24, 0xa6, 0xee, 0x43, 0x42, 0xb9, 0x88, 0x8b, 0xda, 0x1, 0x2f, 0xab, 0x3e, 0x7, 0x7, 0x90, 0x65, 0x2, 0x14, 0xea, 0x27, 0x59")
MAKE_THUNK(libwayland_client, wl_display_roundtrip, "0xf5, 0xf, 0x40, 0x2e, 0x4, 0x93, 0xd5, 0xa7, 0xe8, 0x82, 0xd1, 0xd7, 0xc1, 0xd6, 0xa7, 0x4a, 0xe6, 0xbd, 0x35, 0x87, 0x6, 0xfb, 0x12, 0x1, 0x7e, 0xb0, 0xab, 0x90, 0x57, 0x68, 0xc3, 0x9f")
MAKE_THUNK(libwayland_client, wl_display_roundtrip_queue, "0x7c, 0xf0, 0x4a, 0xb6, 0xb7, 0x21, 0xad, 0x89, 0x3a, 0x35, 0x20, 0xf8, 0x45, 0xe, 0x25, 0x6f, 0xe0, 0xfa, 0x26, 0x75, 0xc2, 0xc6, 0xe9, 0xad, 0x2a, 0xf8, 0xf6, 0x7d, 0xde, 0xa, 0x31, 0x59")
MAKE_THUNK(libwayland_client, wl_display_connect_to_fd, "0x98, 0x4f, 0xf1, 0xdb, 0x7, 0xd5, 0x8b, 0xc6, 0x5f, 0x47, 0x3f, 0x26, 0x41, 0xfe, 0x45, 0x34, 0x77, 0x9f, 0x73, 0xf8, 0x50, 0x8, 0xf0, 0xf5, 0x17, 0x77, 0x93, 0x8f, 0x8, 0xdf, 0xad, 0x41")
MAKE_THUNK(libwayland_client, wl_display_get_fd, "0xbb, 0x35, 0x63, 0xa, 0xd3, 0x5a, 0x63, 0xe0, 0xbe, 0x46, 0xd0, 0x1d, 0xa0, 0x6, 0xa1, 0xe0, 0xa5, 0x6d, 0xe5, 0xd1, 0x60, 0xef, 0x62, 0x74, 0x14, 0xa6, 0xe5, 0xec, 0x5d, 0x1, 0x10, 0x10")
MAKE_THUNK(libwayland_client, wl_event_queue_destroy, "0xc, 0xb0, 0x85, 0x3a, 0xd2, 0x9b, 0x62, 0x58, 0x31, 0x6b, 0x4f, 0xd0, 0x8e, 0x7b, 0x44, 0x58, 0x99, 0xea, 0xdb, 0xbc, 0x13, 0xef, 0x24, 0xba, 0xa, 0x80, 0x43, 0xaf, 0xe1, 0x3c, 0x2f, 0x2a")
MAKE_THUNK(libwayland_client, wl_proxy_add_listener, "0x3e, 0x8c, 0x53, 0xa6, 0x3b, 0xad, 0x20, 0x6, 0x39, 0xb4, 0x94, 0xab, 0x81, 0x90, 0x84, 0x4c, 0x3c, 0xc5, 0x8a, 0x90, 0x8a, 0xc1, 0x94, 0xba, 0x40, 0x8, 0xae, 0x5c, 0x16, 0x58, 0x7e, 0xeb")
MAKE_THUNK(libwayland_client, wl_proxy_create, "0xdf, 0x6f, 0x1c, 0x4b, 0x34, 0x82, 0xd5, 0xe7, 0x6d, 0x9d, 0x1, 0x76, 0xc9, 0xde, 0x36, 0x9d, 0x46, 0x64, 0x0, 0xaa, 0x64, 0x76, 0xc, 0x67, 0xf1, 0x39, 0xbe, 0x20, 0x3, 0x26, 0x30, 0x78")
MAKE_THUNK(libwayland_client, wl_proxy_create_wrapper, "0x5d, 0xea, 0xf8, 0x36, 0x54, 0xd7, 0x4d, 0x5c, 0x51, 0x79, 0x72, 0x48, 0x13, 0x33, 0x9e, 0x3, 0x82, 0x6, 0x71, 0xdc, 0x94, 0xe6, 0x6d, 0xd7, 0xbb, 0xa0, 0x24, 0x5, 0x41, 0xd2, 0x90, 0xe6")
MAKE_THUNK(libwayland_client, wl_proxy_get_class, "0xca, 0xcc, 0xc, 0xce, 0xdf, 0x7e, 0xb6, 0xe2, 0x96, 0x2b, 0x79, 0x7f, 0xee, 0x5d, 0x48, 0xd3, 0xc6, 0xdc, 0x48, 0x26, 0xbc, 0xe7, 0xc7, 0x64, 0xa0, 0xed, 0x71, 0x99, 0xef, 0x35, 0xe3, 0x19")
MAKE_THUNK(libwayland_client, wl_proxy_get_id, "0x3b, 0x9b, 0xd6, 0x7, 0x80, 0x24, 0x14, 0x12, 0x21, 0x39, 0x8, 0x4f, 0x1d, 0x6f, 0x9f, 0x1c, 0x53, 0x87, 0x73, 0x0, 0xed, 0xf2, 0xe1, 0x88, 0x7d, 0x39, 0xd8, 0xdb, 0xcf, 0x54, 0xb5, 0xcc")
MAKE_THUNK(libwayland_client, wl_proxy_get_listener, "0x51, 0x36, 0x8d, 0x72, 0x59, 0xcb, 0x3c, 0x3c, 0xec, 0x95, 0xd5, 0xfb, 0x30, 0x64, 0xaf, 0x90, 0x6, 0xd3, 0x14, 0x35, 0xf5, 0xaf, 0xd1, 0xb1, 0x48, 0xad, 0xcf, 0x35, 0xac, 0x8c, 0x43, 0x5")
MAKE_THUNK(libwayland_client, wl_proxy_get_tag, "0x96, 0xdc, 0x8, 0x97, 0xdd, 0x4b, 0x55, 0x36, 0xd4, 0x47, 0xfe, 0xc8, 0xff, 0x11, 0x9d, 0xac, 0xc7, 0x6c, 0x3a, 0xa4, 0x4f, 0x7, 0xc, 0x32, 0x96, 0x54, 0xc2, 0x58, 0x87, 0x82, 0xb1, 0x9f")
MAKE_THUNK(libwayland_client, wl_proxy_get_user_data, "0x91, 0xb8, 0xfb, 0x86, 0x66, 0x3, 0xdb, 0x32, 0x45, 0x1d, 0x64, 0xfc, 0x5f, 0x28, 0x93, 0x9f, 0x2a, 0xe4, 0xa9, 0xc5, 0x59, 0x5e, 0x3b, 0x54, 0xf5, 0x9e, 0x48, 0x9b, 0x82, 0x4c, 0x60, 0x12")
MAKE_THUNK(libwayland_client, wl_proxy_get_version, "0xc7, 0x2e, 0x6e, 0x4c, 0x9, 0xfc, 0x57, 0x5f, 0xb2, 0x8a, 0x72, 0xc3, 0x77, 0xf2, 0x1b, 0xdf, 0x1a, 0xc3, 0xd7, 0xbe, 0x49, 0xf5, 0xfd, 0x75, 0x19, 0x20, 0x74, 0x77, 0x22, 0xb4, 0x92, 0xe1")
MAKE_THUNK(libwayland_client, wl_proxy_set_queue, "0x3b, 0x7a, 0x52, 0x1, 0xb1, 0x62, 0xe1, 0xa5, 0x8f, 0xc7, 0xc, 0xfa, 0xbe, 0x56, 0x25, 0xcd, 0x89, 0xd, 0x82, 0xb2, 0x56, 0x5d, 0xe2, 0x5d, 0xc7, 0x7b, 0x52, 0xff, 0x34, 0x37, 0x33, 0x1c")
MAKE_THUNK(libwayland_client, wl_proxy_set_tag, "0x79, 0x3b, 0x1d, 0xae, 0x92, 0x98, 0x11, 0x82, 0x68, 0x67, 0x9, 0xe8, 0x77, 0x38, 0x56, 0x1d, 0x96, 0xe6, 0x9, 0x96, 0x60, 0xcf, 0xca, 0xba, 0xe5, 0xca, 0x39, 0x2d, 0xf1, 0x44, 0x6f, 0x64")
MAKE_THUNK(libwayland_client, wl_proxy_set_user_data, "0x28, 0xc7, 0xa5, 0x2e, 0xf2, 0xd7, 0xd0, 0xf8, 0xc9, 0xb, 0xc3, 0x26, 0x77, 0x2d, 0xb4, 0xa8, 0xca, 0x30, 0x50, 0x80, 0xfa, 0x9, 0xee, 0x8f, 0x73, 0x3c, 0x1d, 0x57, 0xef, 0xf6, 0xfe, 0xb7")
MAKE_THUNK(libwayland_client, wl_proxy_wrapper_destroy, "0x92, 0xc2, 0x1f, 0x48, 0xc1, 0x76, 0x7, 0xc3, 0x2, 0x7e, 0x3f, 0x7a, 0xd5, 0xff, 0x84, 0x45, 0x1, 0xb4, 0x3f, 0xd6, 0x48, 0x1f, 0x3b, 0x94, 0xa6, 0xb2, 0x4a, 0xd6, 0xbc, 0x11, 0xb4, 0xbd")
MAKE_THUNK(libwayland_client, wl_proxy_marshal_array, "0xfa, 0x9f, 0x5c, 0x36, 0x60, 0x3a, 0xc5, 0x9c, 0xd9, 0x65, 0xc8, 0xb8, 0x54, 0x5f, 0xad, 0xdf, 0xfd, 0x5, 0xac, 0x93, 0xe9, 0x9e, 0xd6, 0x24, 0x77, 0x1c, 0x7, 0xb4, 0x68, 0x4b, 0x2e, 0x48")
MAKE_THUNK(libwayland_client, wl_proxy_marshal_array_constructor, "0x69, 0x2c, 0xb, 0xbf, 0x9e, 0xbd, 0xc8, 0x32, 0xa5, 0x9b, 0x23, 0x15, 0x50, 0x6, 0x0, 0x70, 0x35, 0xe1, 0x3c, 0x41, 0x42, 0xd5, 0xe1, 0xa2, 0xbc, 0x50, 0x78, 0x4b, 0x9b, 0x70, 0xa2, 0x8e")
MAKE_THUNK(libwayland_client, wl_proxy_marshal_array_constructor_versioned, "0x71, 0x8d, 0xfb, 0xcc, 0x49, 0x87, 0x8e, 0xd0, 0x23, 0x1e, 0xd1, 0xbe, 0x34, 0x83, 0x7e, 0x2c, 0xa4, 0x71, 0x9b, 0x76, 0xc1, 0x99, 0xb6, 0xd1, 0xb, 0x6c, 0xa7, 0x3, 0x75, 0xd5, 0xe5, 0xd1")
MAKE_THUNK(libwayland_client, wl_proxy_marshal_array_flags, "0x27, 0x3a, 0x9a, 0x47, 0xae, 0xa8, 0x46, 0xe9, 0xc6, 0x44, 0x8a, 0x85, 0x6f, 0x56, 0x5f, 0x92, 0xe2, 0x7a, 0xa5, 0xa6, 0x19, 0x5b, 0xa4, 0xf4, 0x52, 0x17, 0x9c, 0xc, 0xe1, 0x86, 0x7c, 0x6c")
MAKE_THUNK(libwayland_client, fex_wl_exchange_interface_pointer, "0xd5, 0x4, 0x44, 0x34, 0x1a, 0xc8, 0x64, 0xef, 0x71, 0x25, 0x68, 0x36, 0xd1, 0x90, 0x2a, 0x82, 0xf, 0xb4, 0xe6, 0x5d, 0x93, 0xe2, 0x70, 0x89, 0xf, 0xd4, 0x99, 0xdc, 0xe3, 0xca, 0xba, 0xeb")
MAKE_THUNK(libwayland_client, fex_wl_get_method_signature, "0xce, 0xc6, 0xd2, 0x11, 0xb4, 0x89, 0xd3, 0x30, 0x48, 0x4f, 0xe0, 0xf7, 0x62, 0x2a, 0x17, 0x5, 0x88, 0x6c, 0xb2, 0x62, 0xf, 0x4a, 0x4a, 0x34, 0x27, 0xfe, 0xc1, 0x74, 0xd0, 0xf7, 0x71, 0x5b")
MAKE_THUNK(libwayland_client, fex_wl_get_interface_event_count, "0xc6, 0x62, 0x98, 0xd3, 0x1f, 0x90, 0x68, 0xa8, 0x45, 0xd1, 0xa6, 0x9a, 0x33, 0x5e, 0x62, 0xfd, 0xb6, 0xaa, 0x16, 0xf3, 0x4a, 0x8f, 0x29, 0xc6, 0x5b, 0xdb, 0x5b, 0xd9, 0x98, 0xff, 0x19, 0x7d")
MAKE_THUNK(libwayland_client, fex_wl_get_interface_event_name, "0x8c, 0x96, 0x9b, 0xf0, 0xc7, 0xc8, 0xc, 0xe7, 0xde, 0x1e, 0x66, 0xd, 0x14, 0xbc, 0x93, 0x86, 0xbf, 0xf0, 0x2c, 0xf8, 0xeb, 0xa4, 0xdf, 0x56, 0x78, 0x3e, 0x1f, 0x31, 0x52, 0x8f, 0x6b, 0xad")
MAKE_THUNK(libwayland_client, fex_wl_get_interface_event_signature, "0x9d, 0xf3, 0xdc, 0xb, 0xf3, 0x36, 0x2c, 0x15, 0xfa, 0xd7, 0xd2, 0xf2, 0xa8, 0xfd, 0x6d, 0x50, 0xd, 0xd0, 0xec, 0xa8, 0xa, 0x82, 0x6c, 0x1, 0x66, 0xed, 0x6b, 0x3b, 0xc9, 0xa3, 0x37, 0x70")
}
extern "C" {
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_destroy(struct wl_proxy * a_0) -> void {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_destroy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_connect(const char * a_0) -> struct wl_display * {
  struct __attribute__((packed)) {
    const char * a_0;
    struct wl_display * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_connect(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_flush(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_flush(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_cancel_read(struct wl_display * a_0) -> void {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_cancel_read(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_create_queue(struct wl_display * a_0) -> struct wl_event_queue * {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    struct wl_event_queue * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_create_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_disconnect(struct wl_display * a_0) -> void {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_disconnect(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_dispatch(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_dispatch(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_dispatch_pending(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_dispatch_pending(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_dispatch_queue(struct wl_display * a_0, struct wl_event_queue * a_1) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    struct wl_event_queue * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_display_dispatch_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_dispatch_queue_pending(struct wl_display * a_0, struct wl_event_queue * a_1) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    struct wl_event_queue * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_display_dispatch_queue_pending(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_get_error(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_get_error(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_prepare_read(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_prepare_read(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_prepare_read_queue(struct wl_display * a_0, struct wl_event_queue * a_1) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    struct wl_event_queue * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_display_prepare_read_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_read_events(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_read_events(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_roundtrip(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_roundtrip(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_roundtrip_queue(struct wl_display * a_0, struct wl_event_queue * a_1) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    struct wl_event_queue * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_display_roundtrip_queue(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_connect_to_fd(int a_0) -> struct wl_display * {
  struct __attribute__((packed)) {
    int a_0;
    struct wl_display * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_connect_to_fd(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_display_get_fd(struct wl_display * a_0) -> int {
  struct __attribute__((packed)) {
    struct wl_display * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_display_get_fd(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_event_queue_destroy(struct wl_event_queue * a_0) -> void {
  struct __attribute__((packed)) {
    struct wl_event_queue * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_event_queue_destroy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_add_listener(struct wl_proxy * a_0, void (**a_1)(void), void * a_2) -> int {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    void (**a_1)(void);
    void * a_2;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libwayland_client_wl_proxy_add_listener(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_create(struct wl_proxy * a_0, const struct wl_interface * a_1) -> struct wl_proxy * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    const struct wl_interface * a_1;
    struct wl_proxy * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_proxy_create(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_create_wrapper(void * a_0) -> void * {
  struct __attribute__((packed)) {
    void * a_0;
    void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_create_wrapper(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_get_class(struct wl_proxy * a_0) -> const char * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    const char * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_get_class(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_get_id(struct wl_proxy * a_0) -> uint32_t {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    uint32_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_get_id(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_get_listener(struct wl_proxy * a_0) -> const void * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    const void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_get_listener(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_get_tag(struct wl_proxy * a_0) -> const char *const * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    const char *const * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_get_tag(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_get_user_data(struct wl_proxy * a_0) -> void * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    void * rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_get_user_data(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_get_version(struct wl_proxy * a_0) -> uint32_t {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    uint32_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_get_version(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_set_queue(struct wl_proxy * a_0, struct wl_event_queue * a_1) -> void {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    struct wl_event_queue * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_proxy_set_queue(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_set_tag(struct wl_proxy * a_0, const char *const * a_1) -> void {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    const char *const * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_proxy_set_tag(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_set_user_data(struct wl_proxy * a_0, void * a_1) -> void {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    void * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_wl_proxy_set_user_data(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_wrapper_destroy(void * a_0) -> void {
  struct __attribute__((packed)) {
    void * a_0;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_wl_proxy_wrapper_destroy(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_marshal_array(struct wl_proxy * a_0, uint32_t a_1, union wl_argument * a_2) -> void {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    uint32_t a_1;
    union wl_argument * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libwayland_client_wl_proxy_marshal_array(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_marshal_array_constructor(struct wl_proxy * a_0, uint32_t a_1, union wl_argument * a_2, const struct wl_interface * a_3) -> struct wl_proxy * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    uint32_t a_1;
    union wl_argument * a_2;
    const struct wl_interface * a_3;
    struct wl_proxy * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  fexthunks_libwayland_client_wl_proxy_marshal_array_constructor(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_marshal_array_constructor_versioned(struct wl_proxy * a_0, uint32_t a_1, union wl_argument * a_2, const struct wl_interface * a_3, uint32_t a_4) -> struct wl_proxy * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    uint32_t a_1;
    union wl_argument * a_2;
    const struct wl_interface * a_3;
    uint32_t a_4;
    struct wl_proxy * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libwayland_client_wl_proxy_marshal_array_constructor_versioned(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_wl_proxy_marshal_array_flags(struct wl_proxy * a_0, uint32_t a_1, const struct wl_interface * a_2, uint32_t a_3, uint32_t a_4, union wl_argument * a_5) -> struct wl_proxy * {
  struct __attribute__((packed)) {
    struct wl_proxy * a_0;
    uint32_t a_1;
    const struct wl_interface * a_2;
    uint32_t a_3;
    uint32_t a_4;
    union wl_argument * a_5;
    struct wl_proxy * rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  args.a_5 = a_5;
  fexthunks_libwayland_client_wl_proxy_marshal_array_flags(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_fex_wl_exchange_interface_pointer(wl_interface * a_0, const char * a_1) -> void {
  struct __attribute__((packed)) {
    wl_interface * a_0;
    const char * a_1;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libwayland_client_fex_wl_exchange_interface_pointer(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_fex_wl_get_method_signature(wl_proxy * a_0, uint32_t a_1, char * a_2) -> void {
  struct __attribute__((packed)) {
    wl_proxy * a_0;
    uint32_t a_1;
    char * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libwayland_client_fex_wl_get_method_signature(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_fex_wl_get_interface_event_count(wl_proxy * a_0) -> int {
  struct __attribute__((packed)) {
    wl_proxy * a_0;
    int rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libwayland_client_fex_wl_get_interface_event_count(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_fex_wl_get_interface_event_name(wl_proxy * a_0, int a_1, char * a_2) -> void {
  struct __attribute__((packed)) {
    wl_proxy * a_0;
    int a_1;
    char * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libwayland_client_fex_wl_get_interface_event_name(&args);
}
FEX_PACKFN_LINKAGE auto fexfn_pack_fex_wl_get_interface_event_signature(wl_proxy * a_0, int a_1, char * a_2) -> void {
  struct __attribute__((packed)) {
    wl_proxy * a_0;
    int a_1;
    char * a_2;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  fexthunks_libwayland_client_fex_wl_get_interface_event_signature(&args);
}
}
extern "C" {
__attribute__((alias("fexfn_pack_wl_display_connect"))) auto wl_display_connect(const char * a_0) -> struct wl_display *;
__attribute__((alias("fexfn_pack_wl_display_flush"))) auto wl_display_flush(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_display_cancel_read"))) auto wl_display_cancel_read(struct wl_display * a_0) -> void;
__attribute__((alias("fexfn_pack_wl_display_create_queue"))) auto wl_display_create_queue(struct wl_display * a_0) -> struct wl_event_queue *;
__attribute__((alias("fexfn_pack_wl_display_disconnect"))) auto wl_display_disconnect(struct wl_display * a_0) -> void;
__attribute__((alias("fexfn_pack_wl_display_dispatch"))) auto wl_display_dispatch(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_display_dispatch_pending"))) auto wl_display_dispatch_pending(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_display_dispatch_queue"))) auto wl_display_dispatch_queue(struct wl_display * a_0, struct wl_event_queue * a_1) -> int;
__attribute__((alias("fexfn_pack_wl_display_dispatch_queue_pending"))) auto wl_display_dispatch_queue_pending(struct wl_display * a_0, struct wl_event_queue * a_1) -> int;
__attribute__((alias("fexfn_pack_wl_display_get_error"))) auto wl_display_get_error(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_display_prepare_read"))) auto wl_display_prepare_read(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_display_prepare_read_queue"))) auto wl_display_prepare_read_queue(struct wl_display * a_0, struct wl_event_queue * a_1) -> int;
__attribute__((alias("fexfn_pack_wl_display_read_events"))) auto wl_display_read_events(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_display_roundtrip"))) auto wl_display_roundtrip(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_display_roundtrip_queue"))) auto wl_display_roundtrip_queue(struct wl_display * a_0, struct wl_event_queue * a_1) -> int;
__attribute__((alias("fexfn_pack_wl_display_connect_to_fd"))) auto wl_display_connect_to_fd(int a_0) -> struct wl_display *;
__attribute__((alias("fexfn_pack_wl_display_get_fd"))) auto wl_display_get_fd(struct wl_display * a_0) -> int;
__attribute__((alias("fexfn_pack_wl_event_queue_destroy"))) auto wl_event_queue_destroy(struct wl_event_queue * a_0) -> void;
__attribute__((alias("fexfn_pack_wl_proxy_create"))) auto wl_proxy_create(struct wl_proxy * a_0, const struct wl_interface * a_1) -> struct wl_proxy *;
__attribute__((alias("fexfn_pack_wl_proxy_create_wrapper"))) auto wl_proxy_create_wrapper(void * a_0) -> void *;
__attribute__((alias("fexfn_pack_wl_proxy_get_class"))) auto wl_proxy_get_class(struct wl_proxy * a_0) -> const char *;
__attribute__((alias("fexfn_pack_wl_proxy_get_id"))) auto wl_proxy_get_id(struct wl_proxy * a_0) -> uint32_t;
__attribute__((alias("fexfn_pack_wl_proxy_get_listener"))) auto wl_proxy_get_listener(struct wl_proxy * a_0) -> const void *;
__attribute__((alias("fexfn_pack_wl_proxy_get_tag"))) auto wl_proxy_get_tag(struct wl_proxy * a_0) -> const char *const *;
__attribute__((alias("fexfn_pack_wl_proxy_get_user_data"))) auto wl_proxy_get_user_data(struct wl_proxy * a_0) -> void *;
__attribute__((alias("fexfn_pack_wl_proxy_get_version"))) auto wl_proxy_get_version(struct wl_proxy * a_0) -> uint32_t;
__attribute__((alias("fexfn_pack_wl_proxy_set_queue"))) auto wl_proxy_set_queue(struct wl_proxy * a_0, struct wl_event_queue * a_1) -> void;
__attribute__((alias("fexfn_pack_wl_proxy_set_tag"))) auto wl_proxy_set_tag(struct wl_proxy * a_0, const char *const * a_1) -> void;
__attribute__((alias("fexfn_pack_wl_proxy_set_user_data"))) auto wl_proxy_set_user_data(struct wl_proxy * a_0, void * a_1) -> void;
__attribute__((alias("fexfn_pack_wl_proxy_wrapper_destroy"))) auto wl_proxy_wrapper_destroy(void * a_0) -> void;
__attribute__((alias("fexfn_pack_wl_proxy_marshal_array"))) auto wl_proxy_marshal_array(struct wl_proxy * a_0, uint32_t a_1, union wl_argument * a_2) -> void;
__attribute__((alias("fexfn_pack_wl_proxy_marshal_array_constructor"))) auto wl_proxy_marshal_array_constructor(struct wl_proxy * a_0, uint32_t a_1, union wl_argument * a_2, const struct wl_interface * a_3) -> struct wl_proxy *;
__attribute__((alias("fexfn_pack_wl_proxy_marshal_array_constructor_versioned"))) auto wl_proxy_marshal_array_constructor_versioned(struct wl_proxy * a_0, uint32_t a_1, union wl_argument * a_2, const struct wl_interface * a_3, uint32_t a_4) -> struct wl_proxy *;
__attribute__((alias("fexfn_pack_wl_proxy_marshal_array_flags"))) auto wl_proxy_marshal_array_flags(struct wl_proxy * a_0, uint32_t a_1, const struct wl_interface * a_2, uint32_t a_3, uint32_t a_4, union wl_argument * a_5) -> struct wl_proxy *;
__attribute__((alias("fexfn_pack_fex_wl_exchange_interface_pointer"))) auto fex_wl_exchange_interface_pointer(wl_interface * a_0, const char * a_1) -> void;
__attribute__((alias("fexfn_pack_fex_wl_get_method_signature"))) auto fex_wl_get_method_signature(wl_proxy * a_0, uint32_t a_1, char * a_2) -> void;
__attribute__((alias("fexfn_pack_fex_wl_get_interface_event_count"))) auto fex_wl_get_interface_event_count(wl_proxy * a_0) -> int;
__attribute__((alias("fexfn_pack_fex_wl_get_interface_event_name"))) auto fex_wl_get_interface_event_name(wl_proxy * a_0, int a_1, char * a_2) -> void;
__attribute__((alias("fexfn_pack_fex_wl_get_interface_event_signature"))) auto fex_wl_get_interface_event_signature(wl_proxy * a_0, int a_1, char * a_2) -> void;
}
#define FOREACH_SYMBOL(EXPAND) \
  EXPAND(wl_proxy_destroy, "TODO") \
  EXPAND(wl_display_connect, "TODO") \
  EXPAND(wl_display_flush, "TODO") \
  EXPAND(wl_display_cancel_read, "TODO") \
  EXPAND(wl_display_create_queue, "TODO") \
  EXPAND(wl_display_disconnect, "TODO") \
  EXPAND(wl_display_dispatch, "TODO") \
  EXPAND(wl_display_dispatch_pending, "TODO") \
  EXPAND(wl_display_dispatch_queue, "TODO") \
  EXPAND(wl_display_dispatch_queue_pending, "TODO") \
  EXPAND(wl_display_get_error, "TODO") \
  EXPAND(wl_display_prepare_read, "TODO") \
  EXPAND(wl_display_prepare_read_queue, "TODO") \
  EXPAND(wl_display_read_events, "TODO") \
  EXPAND(wl_display_roundtrip, "TODO") \
  EXPAND(wl_display_roundtrip_queue, "TODO") \
  EXPAND(wl_display_connect_to_fd, "TODO") \
  EXPAND(wl_display_get_fd, "TODO") \
  EXPAND(wl_event_queue_destroy, "TODO") \
  EXPAND(wl_proxy_add_listener, "TODO") \
  EXPAND(wl_proxy_create, "TODO") \
  EXPAND(wl_proxy_create_wrapper, "TODO") \
  EXPAND(wl_proxy_get_class, "TODO") \
  EXPAND(wl_proxy_get_id, "TODO") \
  EXPAND(wl_proxy_get_listener, "TODO") \
  EXPAND(wl_proxy_get_tag, "TODO") \
  EXPAND(wl_proxy_get_user_data, "TODO") \
  EXPAND(wl_proxy_get_version, "TODO") \
  EXPAND(wl_proxy_set_queue, "TODO") \
  EXPAND(wl_proxy_set_tag, "TODO") \
  EXPAND(wl_proxy_set_user_data, "TODO") \
  EXPAND(wl_proxy_wrapper_destroy, "TODO") \
  EXPAND(wl_proxy_marshal_array, "TODO") \
  EXPAND(wl_proxy_marshal_array_constructor, "TODO") \
  EXPAND(wl_proxy_marshal_array_constructor_versioned, "TODO") \
  EXPAND(wl_proxy_marshal_array_flags, "TODO") \
  EXPAND(fex_wl_exchange_interface_pointer, "TODO") \
  EXPAND(fex_wl_get_method_signature, "TODO") \
  EXPAND(fex_wl_get_interface_event_count, "TODO") \
  EXPAND(fex_wl_get_interface_event_name, "TODO") \
  EXPAND(fex_wl_get_interface_event_signature, "TODO") \


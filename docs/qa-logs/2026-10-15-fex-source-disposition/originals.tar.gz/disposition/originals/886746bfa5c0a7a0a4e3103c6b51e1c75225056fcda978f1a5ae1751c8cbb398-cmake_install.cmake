# Install script for directory: /workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/ThunkLibs/GuestLibs

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "RELEASE")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/toolchain/bin/llvm-objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libwayland-client-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libwayland-client-guest.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libwayland-client-guest.so"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/usr/share/fex-emu/GuestThunks_32/libwayland-client-guest.so")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/usr/share/fex-emu/GuestThunks_32" TYPE SHARED_LIBRARY FILES "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/libwayland-client-guest.so")
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libwayland-client-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libwayland-client-guest.so")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/toolchain/bin/llvm-strip" "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libwayland-client-guest.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  include("/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/CMakeFiles/wayland-client-guest.dir/install-cxx-module-bmi-RELEASE.cmake" OPTIONAL)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libVDSO-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libVDSO-guest.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libVDSO-guest.so"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/usr/share/fex-emu/GuestThunks_32/libVDSO-guest.so")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/usr/share/fex-emu/GuestThunks_32" TYPE SHARED_LIBRARY FILES "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/libVDSO-guest.so")
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libVDSO-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libVDSO-guest.so")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/toolchain/bin/llvm-strip" "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libVDSO-guest.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  include("/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/CMakeFiles/VDSO-guest.dir/install-cxx-module-bmi-RELEASE.cmake" OPTIONAL)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libGL-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libGL-guest.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libGL-guest.so"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/usr/share/fex-emu/GuestThunks_32/libGL-guest.so")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/usr/share/fex-emu/GuestThunks_32" TYPE SHARED_LIBRARY FILES "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/libGL-guest.so")
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libGL-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libGL-guest.so")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libGL-guest.so"
         OLD_RPATH "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/toolchain/bin/llvm-strip" "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libGL-guest.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  include("/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/CMakeFiles/GL-guest.dir/install-cxx-module-bmi-RELEASE.cmake" OPTIONAL)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/usr/share/fex-emu/GuestThunks_32" TYPE SHARED_LIBRARY FILES "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/libEGL-guest.so")
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so"
         OLD_RPATH "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/toolchain/bin/llvm-strip" "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libEGL-guest.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  include("/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/CMakeFiles/EGL-guest.dir/install-cxx-module-bmi-RELEASE.cmake" OPTIONAL)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libcuda-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libcuda-guest.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libcuda-guest.so"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/usr/share/fex-emu/GuestThunks_32/libcuda-guest.so")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/usr/share/fex-emu/GuestThunks_32" TYPE SHARED_LIBRARY FILES "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/libcuda-guest.so")
  if(EXISTS "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libcuda-guest.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libcuda-guest.so")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/toolchain/bin/llvm-strip" "$ENV{DESTDIR}/usr/share/fex-emu/GuestThunks_32/libcuda-guest.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  include("/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/CMakeFiles/cuda-guest.dir/install-cxx-module-bmi-RELEASE.cmake" OPTIONAL)
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-01/build.pixelelated-SM8550.aarch64/build/fex-emu-e869aa644a16e4332cdc15c1ea0b4d13d482385d/.aarch64-rocknix-linux-gnu/Guest_32/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()

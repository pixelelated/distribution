extern "C" {
MAKE_THUNK(libVDSO, time, "0x37, 0x63, 0x46, 0xb0, 0x79, 0x6, 0x5f, 0x9d, 0x0, 0xb6, 0x8d, 0xfd, 0x9e, 0x4a, 0x62, 0xcd, 0x1e, 0x6c, 0xcc, 0x22, 0xcd, 0xb2, 0xc0, 0x17, 0x7d, 0x42, 0x6a, 0x40, 0xd1, 0xeb, 0xfa, 0xe0")
MAKE_THUNK(libVDSO, gettimeofday, "0x77, 0x2a, 0xde, 0x1c, 0x13, 0x2d, 0xe9, 0x48, 0xaf, 0xe0, 0xba, 0xcc, 0x6a, 0x89, 0xff, 0xca, 0x4a, 0xdc, 0xd5, 0x63, 0x2c, 0xc5, 0x62, 0x8b, 0x5d, 0xde, 0xb, 0x15, 0x35, 0xc6, 0xc7, 0x14")
MAKE_THUNK(libVDSO, clock_gettime, "0x3c, 0x96, 0x9b, 0x2d, 0xc3, 0xad, 0x2b, 0x3b, 0x9c, 0x4e, 0x4d, 0xca, 0x1c, 0xe8, 0x18, 0x4a, 0x12, 0x8a, 0xe4, 0xc1, 0x56, 0x92, 0x73, 0xce, 0x65, 0x85, 0x5f, 0x65, 0x7e, 0x94, 0x26, 0xbe")
MAKE_THUNK(libVDSO, clock_getres, "0xe4, 0xa1, 0xf6, 0x23, 0x35, 0xae, 0xb7, 0xb6, 0xb0, 0x37, 0xc5, 0xc3, 0xa3, 0xfd, 0xbf, 0xa2, 0xa1, 0xc8, 0x95, 0x78, 0xe5, 0x76, 0x86, 0xdb, 0x3e, 0x6c, 0x54, 0xd5, 0x2, 0x60, 0xd8, 0x6d")
MAKE_THUNK(libVDSO, getcpu, "0x39, 0x83, 0x39, 0x36, 0xf, 0x68, 0xd6, 0xfc, 0xc2, 0x3a, 0x97, 0x11, 0x85, 0x9, 0xc7, 0x25, 0xbb, 0x50, 0x49, 0x55, 0x6b, 0xc, 0x9f, 0x50, 0x37, 0xf5, 0x9d, 0xb0, 0x38, 0x58, 0x57, 0x12")
MAKE_THUNK(libVDSO, getrandom, "0xf8, 0x3, 0xe2, 0x70, 0xe3, 0xf1, 0xbb, 0xc1, 0x7d, 0xa7, 0x8b, 0xb3, 0x1f, 0x3e, 0xbd, 0xc6, 0x8a, 0x50, 0xd3, 0x4a, 0x1f, 0xb3, 0x4b, 0x7e, 0x32, 0xcb, 0x1e, 0x18, 0x3b, 0x7c, 0xeb, 0x4b")
}
extern "C" {
FEX_PACKFN_LINKAGE auto fexfn_pack_time(time_t * a_0) -> time_t {
  struct __attribute__((packed)) {
    time_t * a_0;
    time_t rv;
  } args;
  args.a_0 = a_0;
  fexthunks_libVDSO_time(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_gettimeofday(struct timeval *__restrict a_0, void *__restrict a_1) -> int {
  struct __attribute__((packed)) {
    struct timeval * a_0;
    void * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libVDSO_gettimeofday(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_clock_gettime(clockid_t a_0, struct timespec * a_1) -> int {
  struct __attribute__((packed)) {
    clockid_t a_0;
    struct timespec * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libVDSO_clock_gettime(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_clock_getres(clockid_t a_0, struct timespec * a_1) -> int {
  struct __attribute__((packed)) {
    clockid_t a_0;
    struct timespec * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libVDSO_clock_getres(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_getcpu(unsigned int * a_0, unsigned int * a_1) -> int {
  struct __attribute__((packed)) {
    unsigned int * a_0;
    unsigned int * a_1;
    int rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  fexthunks_libVDSO_getcpu(&args);
  return args.rv;
}
FEX_PACKFN_LINKAGE auto fexfn_pack_getrandom(void * a_0, size_t a_1, uint32_t a_2, void * a_3, size_t a_4) -> ssize_t {
  struct __attribute__((packed)) {
    void * a_0;
    size_t a_1;
    uint32_t a_2;
    void * a_3;
    size_t a_4;
    ssize_t rv;
  } args;
  args.a_0 = a_0;
  args.a_1 = a_1;
  args.a_2 = a_2;
  args.a_3 = a_3;
  args.a_4 = a_4;
  fexthunks_libVDSO_getrandom(&args);
  return args.rv;
}
}
extern "C" {
__attribute__((alias("fexfn_pack_time"))) auto time(time_t * a_0) -> time_t;
__attribute__((alias("fexfn_pack_gettimeofday"))) auto gettimeofday(struct timeval *__restrict a_0, void *__restrict a_1) -> int;
__attribute__((alias("fexfn_pack_clock_gettime"))) auto clock_gettime(clockid_t a_0, struct timespec * a_1) -> int;
__attribute__((alias("fexfn_pack_clock_getres"))) auto clock_getres(clockid_t a_0, struct timespec * a_1) -> int;
__attribute__((alias("fexfn_pack_getcpu"))) auto getcpu(unsigned int * a_0, unsigned int * a_1) -> int;
__attribute__((alias("fexfn_pack_getrandom"))) auto getrandom(void * a_0, size_t a_1, uint32_t a_2, void * a_3, size_t a_4) -> ssize_t;
}
#define FOREACH_SYMBOL(EXPAND) \
  EXPAND(time, "TODO") \
  EXPAND(gettimeofday, "TODO") \
  EXPAND(clock_gettime, "TODO") \
  EXPAND(clock_getres, "TODO") \
  EXPAND(getcpu, "TODO") \
  EXPAND(getrandom, "TODO") \


#!/usr/bin/env python3
"""UNRUN. Four actual Dolphin startup observations in an allocated no-NIC guest."""
import hashlib,http.server,json,os,shutil,signal,struct,subprocess,sys,threading,time,urllib.parse
from pathlib import Path
R=Path('/run/pix-installed-native');PACKET=Path(__file__).resolve().parent;INPUTS=PACKET.parent/'inputs'
USER='m7_synthetic_only';TOKEN='m7_synthetic_invalid';PORT=8080

def require(ok,why):
 if not ok:raise AssertionError(why)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def identity(pid):
 p=Path('/proc')/str(pid);s=(p/'stat').read_text().rsplit(')',1)[1].split()
 return {'pid':pid,'start_ticks':int(s[19]),'exe':os.readlink(p/'exe'),'exe_sha256':sha(p/'exe'),'cpu_ticks':int(s[11])+int(s[12]),'tasks':[{'tid':int(t.name),'comm':(t/'comm').read_text().strip()} for t in sorted((p/'task').iterdir())]}
def census():
 out=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   exe=os.readlink(p/'exe')
   if Path(exe).name.startswith('dolphin-emu'):out.append(identity(int(p.name)))
  except (FileNotFoundError,ProcessLookupError):continue
 return out
class Endpoint(http.server.HTTPServer):
 allow_reuse_address=True
 def __init__(self):
  super().__init__(('127.0.0.1',PORT),Handler);self.timeout=.1;self.records=[];self.errors=[];self.stop=threading.Event();self.thread=threading.Thread(target=self.loop,name='synthetic-loopback')
 def loop(self):
  try:
   while not self.stop.is_set():self.handle_request()
  except BaseException as e:self.errors.append(repr(e))
 def close(self):
  self.stop.set();self.thread.join(timeout=3);require(not self.thread.is_alive(),'endpoint thread survived');self.server_close()
class Handler(http.server.BaseHTTPRequestHandler):
 def setup(self):super().setup();self.connection.settimeout(2)
 def log_message(self,*args):pass
 def do_POST(self):
  try:
   n=int(self.headers.get('Content-Length','0'));require(0<n<=8192,'request size')
   body=self.rfile.read(n);require(len(body)==n,'short request')
   form=urllib.parse.parse_qs(body.decode('ascii'),strict_parsing=True)
   self.server.records.append({'path':self.path,'method':'POST','host':self.headers.get('Host'),'form':form,'peer':self.client_address[0],'monotonic':time.monotonic()})
   require(len(self.server.records)<=4,'unexpected request storm')
   data=b'{"Success":false,"Error":"Synthetic endpoint only"}'
   self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  except BaseException as e:self.server.errors.append(repr(e));self.close_connection=True

def observe(name,binary,enabled,badboot=False):
 case=R/name;case.mkdir();user=case/'user';config=user/'Config';config.mkdir(parents=True)
 (config/'RetroAchievements.ini').write_text('[Achievements]\nEnabled = '+str(enabled)+'\nHostUrl = 127.0.0.1:8080\nUsername = '+USER+'\nApiToken = '+TOKEN+'\nHardcoreEnabled = False\n')
 (config/'Logger.ini').write_text('[Options]\nWriteToFile = True\nWriteToConsole = True\nVerbosity = 4\n[Logs]\nRetroAchievements = True\nBOOT = True\nCORE = True\nCONSOLE = True\n')
 (config/'Dolphin.ini').write_text('[Core]\nCPUThread = True\nCPUCore = 0\nSlotA = 255\nSlotB = 255\n[Analytics]\nEnabled = False\nPermissionAsked = True\n[DSP]\nBackend = No Audio Output\n')
 before={str(p.relative_to(user)):sha(p) for p in config.iterdir()};write(case/'config-before.json',before)
 game=R/('absent-file.iso' if badboot else 'loop.dol');require(not game.exists() if badboot else game.exists(),'wrong boot fixture')
 argv=[str(binary),'-p','headless','-v','Null','-a','HLE','-u',str(user),'-e',str(game)]
 row={'case':name,'status':'FAIL','argv':argv,'binary_sha256':sha(binary),'enabled':enabled,'badboot':badboot,'signals':[],'original_exit':None}
 server=None;child=None;pidfd=None;started=time.monotonic()
 try:
  require(census()==[],'Dolphin already running');server=Endpoint();server.thread.start()
  with (case/'stdout').open('xb') as out,(case/'stderr').open('xb') as err:
   child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
   pidfd=os.pidfd_open(child.pid);row['pid']=child.pid
   if badboot:
    row['original_exit']=child.wait(timeout=8)
   else:
    deadline=time.monotonic()+15;live=None
    while time.monotonic()<deadline:
     require(child.poll() is None,'Dolphin exited before running')
     live=identity(child.pid)
     if any(t['comm']=='CPU thread' for t in live['tasks']):break
     time.sleep(.1)
    require(live and any(t['comm']=='CPU thread' for t in live['tasks']),'no successful CPU thread')
    row['running_before']=live
    # Positive running interval also bounds the disabled/baseline absence observations.
    until=time.monotonic()+2
    while time.monotonic()<until:
     require(child.poll() is None,'Dolphin exited during running observation');time.sleep(.1)
    row['running_after']=identity(child.pid)
    require(row['running_after']['start_ticks']==live['start_ticks'] and row['running_after']['exe_sha256']==row['binary_sha256'],'process/executable changed')
    require(row['running_after']['cpu_ticks']>live['cpu_ticks'],'CPU time did not advance')
    require(not server.errors,'endpoint failed')
    signal.pidfd_send_signal(pidfd,signal.SIGTERM);row['signals'].append('normal SIGTERM');row['original_exit']=child.wait(timeout=8)
  text=(case/'stderr').read_text(errors='replace')+(case/'stdout').read_text(errors='replace')
  row['initialized']=text.count('Achievement Manager Initialized')
  row['shutdown']=text.count('Achievement Manager shut down.')
  row['boot_error']='Could not boot the specified file' in text
  row['requests']=server.records
  require(row['original_exit']==(1 if badboot else 0),'unexpected original exit')
  if name=='baseline-enabled':
   require(not row['initialized'] and not row['shutdown'] and not row['requests'],'baseline differs from diagnosed source')
   row['observation']='KNOWN_DEFECT_REPRODUCED'
  elif enabled:
   require(row['initialized']==row['shutdown']==1,'missing or duplicate lifecycle')
   if badboot:require(row['boot_error'],'not the BootCore failure path')
   else:require(len(row['requests'])==1,'expected one synthetic startup login')
   # Failed boot can cancel the queued login before dispatch; lifecycle, not an HTTP count, is its criterion.
   require(len(row['requests'])<=1,'duplicate startup request')
   for req in row['requests']:
    require(req['method']=='POST' and req['path']=='/dorequest.php' and req['host']=='127.0.0.1:8080' and req['peer']=='127.0.0.1','wrong HTTP destination')
    require(req['form'].get('r')==['login2'] and req['form'].get('u')==[USER] and req['form'].get('t')==[TOKEN],'wrong synthetic login')
  else:require(not row['initialized'] and not row['shutdown'] and not row['requests'],'disabled achievements started')
  row['status']='PASS'
 except BaseException as e:row['error']=repr(e)
 finally:
  if child and child.poll() is None:
   row['status']='FAIL';row['signals'].append('forced SIGKILL cleanup')
   if pidfd is not None:signal.pidfd_send_signal(pidfd,signal.SIGKILL)
   else:child.kill()
   row['original_exit']=child.wait(timeout=3)
  if pidfd is not None:os.close(pidfd)
  if server:
   row['requests']=server.records;row['endpoint_errors']=server.errors
   try:server.close()
   except BaseException as e:row['status']='FAIL';row['endpoint_close_error']=repr(e)
   if server.errors:row['status']='FAIL'
  row['remaining_dolphin']=census()
  if row['remaining_dolphin']:row['status']='FAIL'
  row['elapsed_seconds']=time.monotonic()-started;write(case/'result.json',row)
 return row

def main():
 result={'status':'FAIL','rows':[],'runtime_claim':'Actual installed baseline and source-bound relink candidate; not candidate installed-image proof'}
 try:
  require(len(sys.argv)==2,'final image verification SHA required')
  require(os.geteuid()==0 and sorted(p.name for p in Path('/sys/class/net').iterdir())==['lo'],'root no-NIC guest required')
  require(os.statvfs(PACKET).f_flag&os.ST_RDONLY,'read-only input required')
  for line in (PACKET/'SHA256SUMS').read_text().splitlines():
   digest,name=line.split('  ',1);require(sha(PACKET/name)==digest,'packet changed')
  final=PACKET.parent/'final-image-result.json';require(sha(final)==sys.argv[1],'image verification changed')
  readback=json.loads(final.read_text());installed=Path('/usr/bin/dolphin-emu-nogui')
  require(readback['status']=='PASS','final image receipt failed')
  expected=readback['products']['usr/bin/dolphin-emu-nogui'];require(sha(installed)==expected['sha256'] and installed.stat().st_size==expected['bytes'],'installed baseline changed')
  bindings=json.loads((PACKET/'inputs.json').read_text())
  for name,row in bindings['staged'].items():require(sha(INPUTS/name)==row['sha256'] and (INPUTS/name).stat().st_size==row['bytes'],'staged candidate binding changed')
  artifact=json.loads((INPUTS/'target-artifact.json').read_text());build=json.loads((INPUTS/'build-result.json').read_text())
  require(build['status']=='PASS' and build['original_attach_exit']==build['original_container_exit']==build['watchdog_original_exit']==0,'build owner failed')
  require(artifact['plan_sha256']==bindings['build_plan_sha256'] and artifact['candidate_source_sha256']==bindings['candidate_source_sha256'],'candidate source provenance differs')
  candidate=R/'dolphin-emu-nogui';shutil.copyfile(INPUTS/'dolphin-emu-nogui',candidate);candidate.chmod(0o700)
  require(sha(candidate)==artifact['sha256'],'candidate bytes differ');result['candidate']=artifact;result['installed_baseline']=expected
  # Self-authored four-byte GameCube branch-to-self. No external game, BIOS or account.
  dol=bytearray(0x104)
  for off,value in [(0,0x100),(0x48,0x80003100),(0x90,4),(0xe0,0x80003100),(0x100,0x48000000)]:struct.pack_into('>I',dol,off,value)
  (R/'loop.dol').write_bytes(dol);result['fixture_sha256']=sha(R/'loop.dol')
  for args in [('baseline-enabled',installed,True,False),('candidate-enabled',candidate,True,False),('candidate-disabled',candidate,False,False),('candidate-failed-boot',candidate,True,True)]:
   row=observe(*args);result['rows'].append(row);require(row['status']=='PASS','original case failed; no retry')
  result['status']='PASS'
 except BaseException as e:result['error']=repr(e)
 finally:write(R/'result.json',result)
 return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())

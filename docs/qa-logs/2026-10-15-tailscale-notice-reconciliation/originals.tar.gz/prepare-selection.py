from pathlib import Path
import json,re,hashlib,shutil
P=Path(__file__).resolve().parent;S=Path('/tmp/pix-m7-prebuilt-source-disposition-20261015')
def put(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for n in ['tailscale-notice-map.json','dependency-tag-comparison.json','module-inventory.json']:shutil.copy2(S/n,P/'originals'/n)
shutil.copy2(S/'upstream/tailscale-notices.md',P/'originals/tailscale-notices.md')
old=json.loads((S/'tailscale-notice-map.json').read_text());mods={r['module']:r for r in old['rows']};entries={e['line']:e for r in old['rows'] for e in r['upstream_notice_matches']}
rows=[]
for module,r in mods.items():
 applicable=[]
 for e in entries.values():
  candidates=[m for m in mods if e['path']==m or e['path'].startswith(m+'/')]
  if not candidates or max(candidates,key=len)!=module:continue
  x=dict(e);version=r['version'];m=re.search(r'-(?:0\.)?\d{14}-([0-9a-f]{12})(?:\+incompatible)?$',version)
  token=m.group(1) if m else version
  x['corrected_selected_version_token']=token;x['corrected_selected_token_in_url']=token in e['license_url'];applicable.append(x)
 rows.append(dict(module=module,version=r['version'],sum=r['sum'],notice_rows=applicable))
put(P/'corrected-map.json',dict(rows=rows,scope='Longest selected module prefix plus valid Go pseudo-version commit suffix. Corrects historical lexical mapping only, not notice applicability or text completeness.'))
exceptions=json.loads((S/'dependency-tag-comparison.json').read_text())['tailscale_unique_exceptions']
def esc(s):return ''.join('!'+c.lower() if c.isupper() else c for c in s)
requests=[dict(name='exception-'+str(i)+'.json',url='https://proxy.golang.org/'+esc(r['module'])+'/@v/'+esc(r['selected_version'])+'.info',module=r['module'],version=r['selected_version'],embedded_h1=r['selected_checksum'],purpose='Exact selected exception version origin metadata') for i,r in enumerate(exceptions,1)]
for i in range(0,len(requests),3):put(P/f'batch-info-{i//3+1}.json',requests[i:i+3])
put(P/'selection-summary.json',dict(selected_modules=len(rows),historical_no_token_count=21,corrected_no_token_count=sum(bool(r['notice_rows']) and not any(e['corrected_selected_token_in_url'] for e in r['notice_rows']) for r in rows),omitted_count=sum(not r['notice_rows'] for r in rows),exceptions=exceptions))
print(json.dumps(json.loads((P/'selection-summary.json').read_text()) | {'exceptions':len(exceptions)}))

from pathlib import Path
import base64,hashlib,json,re,shutil,datetime
P=Path(__file__).resolve().parent
R=Path('/workspace/tmp/pix-m7-prebuilt-source-collection-20261015-01')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
requests=json.loads((P/'requests.json').read_text());mapping=json.loads((P/'corrected-map.json').read_text())['rows'];historical=json.loads((P/'originals/tailscale-notice-map.json').read_text());exceptions=json.loads((P/'originals/dependency-tag-comparison.json').read_text())['tailscale_unique_exceptions']
assert len(requests)==40 and sum(r['bytes'] for r in requests)<8*1024**2
assert all(r['bytes']<=512*1024 and r['elapsed_seconds']<=15 for r in requests)
for r in requests:assert sha(Path(r['body_path']))==r['sha256']
origins={r['selection']['module']:dict(request=r,metadata=json.loads(Path(r['body_path']).read_text())) for r in requests if r['status']==200 and r['selection']['purpose']=='Exact selected exception version origin metadata'}
assert len(origins)==18
for module,o in origins.items():
 assert o['metadata']['Version']==o['request']['selection']['version']
 assert re.fullmatch('[0-9a-f]{40}',o['metadata']['Origin']['Hash'])
notices={}
for r in requests:
 if not r['selection'].get('notice_relative_path') or r['status']!=200:continue
 data=Path(r['body_path']).read_bytes();out=Path(r['body_path'])
 if r['selection']['encoding']=='base64-gitiles':
  data=base64.b64decode(data,validate=True);out=P/'responses'/(Path(r['body_path']).name+'.decoded');out.write_bytes(data)
 data.decode('utf-8')
 notices.setdefault(r['selection']['module'],[]).append(dict(url=r['selection']['url'],origin=r['selection']['origin'],module=r['selection']['module'],selected_version=r['selection']['version'],embedded_h1=r['selection']['embedded_h1'],relative_path=r['selection']['notice_relative_path'],body_path=str(out),sha256=sha(out),bytes=len(data),request_body_sha256=r['sha256'],metadata_sha256=r['selection']['metadata_sha256'],license_completeness=False))
accepted=json.loads((R/'collection-result.json').read_text());by={(r['selection']['module'],r['selection']['version'],r['selection']['go_h1']):r for r in accepted['rows']};rows=[]
for r in mapping:
 key=(r['module'],r['version'],r['sum']);reuse=[]
 if key in by:
  assert by[key]['exact_selected_version']is True
  for n in by[key]['notice_candidates']:
   p=Path(n['retained_path']);assert sha(p)==n['sha256']
   reuse.append(dict(path=str(p),sha256=n['sha256'],bytes=n['bytes'],archive=n['archive'],archive_member=n['member'],durable_archive='docs/qa-logs/2026-10-15-prebuilt-source-collection/originals.tar.gz',durable_member='owner/'+str(p.relative_to(R)),source_result_sha256=sha(R/'collection-result.json')))
 r=dict(r,primary_origin=origins.get(r['module']),new_notice_texts=notices.get(r['module'],[]),reused_notice_candidates=reuse,selected_notice_candidates_retained=bool(reuse or notices.get(r['module'])),publication_clearance=False)
 rows.append(r)
remaining=[r for r in rows if not r['selected_notice_candidates_retained']]
old_unmatched=set(historical['unmatched_modules']);exception_names={e['module'] for e in exceptions}
summary=dict(status='BOUNDED_TEXT_RECONCILIATION_WITH_REMAINING_GAPS',attempt_cap=40,attempts=len(requests),sandbox_dns_failures=sum(r['status']is None for r in requests),http_requests=sum(r['status']is not None for r in requests),http_200=sum(r['status']==200 for r in requests),http_404=sum(r['status']==404 for r in requests),response_body_bytes=sum(r['bytes'] for r in requests),largest_response_bytes=max(r['bytes'] for r in requests),maximum_request_seconds=max(r['elapsed_seconds'] for r in requests),selected_module_count=len(rows),exact_exception_origins_retained=len(origins),new_notice_text_files=sum(len(v) for v in notices.values()),new_modules_with_notice_text=len(notices),reused_rclone_modules=sum(bool(r['reused_notice_candidates']) for r in rows),selected_modules_with_notice_candidates=sum(r['selected_notice_candidates_retained'] for r in rows),remaining_modules=len(remaining),exceptions_with_notice_candidates=sum(r['selected_notice_candidates_retained'] for r in rows if r['module'] in exception_names),historical_omissions_with_new_notice_candidates=[r['module'] for r in rows if r['module']in old_unmatched and r['selected_notice_candidates_retained']],remaining_historical_omissions=[r['module'] for r in remaining if r['module']in old_unmatched],historical_unmatched_token_count=21,corrected_unmatched_token_count=sum(bool(r['notice_rows'])and not any(e['corrected_selected_token_in_url'] for e in r['notice_rows']) for r in rows),no_archives_downloaded=True,no_module_zip_h1_revalidation=True,no_cryptographic_signature_verification=True,no_source_or_target_execution=True,no_legal_or_publication_clearance=True)
put(P/'reconciliation.json',dict(summary=summary,rows=rows))
# Next source locators only: no request is executed after the cap.
def esc(s):return ''.join('!'+c.lower() if c.isupper() else c for c in s)
nextrows=[]
for r in remaining:
 kind='missing-upstream-notice-row' if not r['notice_rows'] else 'selected-token-not-bound' if not any(e['corrected_selected_token_in_url'] for e in r['notice_rows']) else 'existing-pinned-text-not-retained'
 if r['module']=='github.com/jsimonetti/rtnetlink':
  o=r['primary_origin']['metadata']['Origin'];action=dict(url='https://raw.githubusercontent.com/jsimonetti/rtnetlink/'+o['Hash']+'/LICENSE.md',purpose='Next single candidate after actual LICENSE404; no claim until read. A source-tree listing at exact commit is the alternative if candidate is absent.')
 else:action=dict(url='https://proxy.golang.org/'+esc(r['module'])+'/@v/'+esc(r['version'])+'.info',purpose='Resolve selected-version Origin before collecting missing/stale notice text; existing exact-token URL may be retained directly where sufficient.')
 nextrows.append(dict(module=r['module'],version=r['version'],embedded_h1=r['sum'],priority=0 if r['module']=='github.com/jsimonetti/rtnetlink' else 1 if not r['notice_rows'] else 2 if kind=='selected-token-not-bound' else 3,kind=kind,next_action=action,existing_notice_locators=r['notice_rows']))
nextrows.sort(key=lambda r:(r['priority'],r['module']))
put(P/'remaining-plan.json',dict(status='UNRUN_REQUIRES_NEW_ROOT_ALLOCATION_CAP',count=len(nextrows),next_rows=nextrows,smallest_next_action=nextrows[0],no_new_gate='Continue exact selected-source/notice retention; no universal rebuild, generator or module execution required.'))
print(json.dumps(summary,indent=2))

#!/usr/bin/env python3
"""Root-authorized bounded public text observations only; no redirects/auth/proxy."""
from pathlib import Path
import datetime,hashlib,json,signal,sys,time,urllib.request,urllib.error,urllib.parse
P=Path(__file__).resolve().parent
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):raise urllib.error.HTTPError(req.full_url,code,'redirect not followed',headers,fp)
def deadline(sig,frame):raise TimeoutError('15-second request deadline')
signal.signal(signal.SIGALRM,deadline)
ops=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
journal=P/'requests.json';rows=json.loads(journal.read_text()) if journal.exists() else []
requests=json.loads(Path(sys.argv[1]).read_text())
for item in requests:
 assert len(rows)<40
 url=item['url'];u=urllib.parse.urlsplit(url);assert u.scheme=='https' and u.hostname in ['proxy.golang.org','raw.githubusercontent.com','go.googlesource.com'] and not u.username and not u.password
 name=f'{len(rows)+1:02d}-'+item['name'];dest=P/'responses'/name;assert not dest.exists()
 row=dict(selection=item,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=None,error=None,body_path=str(dest),bytes=0,sha256=None,redirect_followed=False,auth_supplied=False,proxy_enabled=False)
 rows.append(row);journal.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
 start=time.monotonic();data=bytearray()
 try:
  signal.alarm(15)
  req=urllib.request.Request(url,headers={'User-Agent':'pixelelated-source-evidence','Accept':'text/plain,application/json'})
  try:response=ops.open(req,timeout=15)
  except urllib.error.HTTPError as e:response=e
  with response:
   row['status']=response.status
   while True:
    b=response.read(min(65536,524289-len(data)))
    if not b:break
    data.extend(b)
    assert len(data)<=524288,'512KiB file cap'
    assert sum(x['bytes'] for x in rows[:-1])+len(data)<=8*1024**2,'8MiB aggregate cap'
 except BaseException as e:row['error']=type(e).__name__+': '+str(e)[:2000]
 finally:
  signal.alarm(0);row['elapsed_seconds']=time.monotonic()-start
  with dest.open('xb') as f:f.write(data)
  row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  journal.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:row[k] for k in ['status','error','body_path','bytes','elapsed_seconds']}))

# Shader distribution disposition — source-only handoff

Read `disposition.md`. This applies settled D-WORKFLOW-084/097/131 and the actual scope of D-INFRA-016 to the accepted 68-member shader list and four Koko JPEGs. It corrects the prior proposal's unnecessary invitation to re-decide noncommercial scope. No prior sealed file is changed.

The 68 members are inclusion-ready for the existing noncommercial release with complete source/notices; this packet supplies exact member and accepted-observation links. Koko's four JPEGs use conservative supplied GPL subproject inclusion, with separate third-party sidecars preserved. Actual preferred editing-source custody and the single uncertain MAME adaptation remain explicit.

Exactly three official Creative Commons pages were read: the 3.0 and 4.0 BY-NC-SA legalcodes and CC FAQ. All three returned HTTP 200; full raw bodies total 340,147 bytes. `official-read-index.json` retains retrieval dates, URLs, response headers, hashes and sizes. No source archive, binary, image, collector, target or service was downloaded or executed. Document/evidence grouping and custody reads are source preparation, not tests or runtime qualification.

`settled-decisions.json` binds the exact existing register rows and full-file hash. `evidence-references.json` binds prior immutable source/disposition evidence without duplicating the large inputs. `member-inclusion.json` carries exact source/notice actions; `member-inclusion.tsv` is the compact index. `accepted-member-observation-links.json` preserves the existing 118 physical observations for these 68 members, without claiming a new independent SYSTEM extraction.

No product, tracker, shared record or original evidence was edited. Notice-bundle materialization and all remaining #528 custody/publication criteria retain their existing status. This is a scoped engineering disposition, not a broad legal guarantee.

## Observed failure

During M7's corrected-image qualification (fac608ff89940ce358ea9b8a95e9a08a6fe26568 / ES3178b832), the original standard suite reports seven host-script failures. Six concern stopped helper liveness; one concerns the phone page's waiting text. The original failed aggregate remains failed.

Actual host /proc identifies four named failed helpers as zombies adopted by the new owner process1332854, with zero memory. The owner establishes subreaper status but does not reap adopted exited children during its active command loop. The fixtures use kill -0, which sees those exited children. Separately, PL-016 reads #state.textContent, although accepted #571 moved status prose into #status-message and retained #state as the status icon/button. These are harness defects; no product regression is established by these failures.

The previous #550/#551 corrections addressed compiler scratch quota and an obsolete upgrade-readiness extractor. The current script is byte-identical to that accepted version; these failures have different causes.

Can this be done on the VM? Yes. Use the existing standard VM owner with synthetic local backends. The liveness cause is host supervisor behavior and needs actual-host process readback; no handheld or real provider is needed.

## Scope and acceptance criteria

- [x] Preserve the original seven failures and exact source/process evidence in a compact published packet; identify exited adopted children separately from live work.
- [x] Correct observation-time reaping without consuming the active Popen wait or signaling live descendants; preserve original adopted wait statuses and normal cleanup evidence.
- [x] Read PL-016 waiting prose from the current status-message element with the historical-template fallback; retain the assertion that the text is nonempty and does not name an absent button.
- [x] Run the existing scripts row on the same frozen image under a fresh watched owner; retain its original PASS result and actual owner cleanup. Carry the other successful same-image standard rows without repeating them. Complete the separately pending SFTP and local S3 rows under #344.

Already written: only synthetic QA state and original failed evidence were produced; no owner device, credentials, saves, or provider data changed. The in-flight owner and frozen firmware are unchanged. Corrected source is staged separately and will run only after the active standard owner exits.

Upstream disposition: these helpers and the owned lifecycle are fork-specific QA infrastructure. No component or ROCKNIX product patch is warranted. This issue was filed during diagnosis, before correction integration or execution.


## Accepted criterion reconciliation — October 15, 2026

All four criteria are now supported by [preserved failures and correction source](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-qualification-followups/README.md) and [original scripts/SFTP/S3 outcomes](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-baseline-continuation/README.md). The source correction is `37d26a203e348fb42f251977aaad123604d7347a`; subsequent qualification records are published in `9aaaaa0f642b97ebf722c2e1aeedb7e4d00bcbdc` and retained in the final M7 record.

The seven original failures remain failed. Four named helpers have original host `/proc` zombie evidence; the other two helper assertions are attributed to the same mechanism without a PID-specific snapshot. The corrected observer uses nonblocking waits only for adopted direct children and explicitly excludes the active Popen child. Its original71 observation receipts retain statuses including `-9`, `-15`, `143` and `255`; they are not rewritten to zero. None of their PIDs overlaps an active command PID. The current PL-016 selector reads `status-message` with the historical `state` fallback, retaining both nonempty-text and absent-button assertions.

Fresh same-image run `20261015T000858Z-720211a2` completed on fac608ff/ES3178: scripts PASS521s, SFTP PASS67s and local S3 PASS111s. All seven original outer channels are0; original cleanup errors, remaining children, surviving owned processes and live QEMU lists are empty. The scripts log retains one historical feature group as not applicable, not PASS. The other13 original successful standard rows were carried without repeating them. The old failed aggregate and its separate screenshot failure remain unchanged; #591 owns the later frame comparison. These are synthetic/local protocol proofs, not a real provider or physical-device claim.

## Code trace and already-written state

The retained `baseline-correction/run.py.diff` changes `observe(active)` to use `waitpid(..., WNOHANG)` after skipping `active.pid`; original wait status is recorded before the existing liveness checks. `last-good-scripts-test.diff` changes only the current waiting-message selection and preserves its assertions. Both are in the correction archive linked above.

Already written: only synthetic QA state and original failed evidence existed before this correction. The observer/selector fix performs no device-data migration and does not alter firmware, owner credentials, saves or provider data. Original failed evidence is retained; completed guest/configuration and owned backend cleanup remain separately recorded.

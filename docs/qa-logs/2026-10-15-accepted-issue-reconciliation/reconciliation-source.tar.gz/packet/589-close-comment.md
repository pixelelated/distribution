Completed: all four original acceptance criteria are now checked against the retained original source/result evidence.

## Accepted criterion reconciliation — October 15, 2026

All four criteria are now supported by [preserved failures and correction source](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-qualification-followups/README.md) and [original scripts/SFTP/S3 outcomes](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-baseline-continuation/README.md). The source correction is `37d26a203e348fb42f251977aaad123604d7347a`; subsequent qualification records are published in `9aaaaa0f642b97ebf722c2e1aeedb7e4d00bcbdc` and retained in the final M7 record.

The seven original failures remain failed. Four named helpers have original host `/proc` zombie evidence; the other two helper assertions are attributed to the same mechanism without a PID-specific snapshot. The corrected observer uses nonblocking waits only for adopted direct children and explicitly excludes the active Popen child. Its original71 observation receipts retain statuses including `-9`, `-15`, `143` and `255`; they are not rewritten to zero. None of their PIDs overlaps an active command PID. The current PL-016 selector reads `status-message` with the historical `state` fallback, retaining both nonempty-text and absent-button assertions.

Fresh same-image run `20261015T000858Z-720211a2` completed on fac608ff/ES3178: scripts PASS521s, SFTP PASS67s and local S3 PASS111s. All seven original outer channels are0; original cleanup errors, remaining children, surviving owned processes and live QEMU lists are empty. The scripts log retains one historical feature group as not applicable, not PASS. The other13 original successful standard rows were carried without repeating them. The old failed aggregate and its separate screenshot failure remain unchanged; #591 owns the later frame comparison. These are synthetic/local protocol proofs, not a real provider or physical-device claim.

## Code trace and already-written state

The retained `baseline-correction/run.py.diff` changes `observe(active)` to use `waitpid(..., WNOHANG)` after skipping `active.pid`; original wait status is recorded before the existing liveness checks. `last-good-scripts-test.diff` changes only the current waiting-message selection and preserves its assertions. Both are in the correction archive linked above.

Already written: only synthetic QA state and original failed evidence existed before this correction. The observer/selector fix performs no device-data migration and does not alter firmware, owner credentials, saves or provider data. Original failed evidence is retained; completed guest/configuration and owned backend cleanup remain separately recorded.

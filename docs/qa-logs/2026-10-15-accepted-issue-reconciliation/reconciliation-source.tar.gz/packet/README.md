# Accepted issue reconciliation — root publication proposals

#589 and #591 meet all their current acceptance criteria. Their proposed bodies preserve the exact criteria, mark only supported outcomes, add source/result links and retain original failures. Matching close comments are ready for root review and completed closure.

#577 has five supported product criteria. Its sixth remains unchecked until the exact public setup-documentation follow-up is added to #511 and linked back with verified live readback. `511-proposed-followup-section.md` is the small append; the full proposed body retains the fetched issue history. `577-proposed-body-pending-followup.md` adds the source-backed Already written line and leaves that dependency open. No #577 closure comment has been prepared.

See `criterion-map.md` for each exact requirement and its artifact/disposition. `original-evidence-readback.json` records selected original result/source checks; `evidence-references.json` hashes their existing durable locators without duplicating archives. Live issue snapshots and their tool observations are retained. `proposal-checks.json` verifies exact criterion preservation, checkbox counts, the untouched #511 history and immutable Git evidence links.

No tests, candidate helpers, process gates, device activity, shared records or tracker changes were executed. Website guide delivery, upstream docs preparation and publication remain separately owned; this packet does not declare those tasks completed. Root must compare the live body hashes before applying proposals to avoid overwriting a concurrent update.

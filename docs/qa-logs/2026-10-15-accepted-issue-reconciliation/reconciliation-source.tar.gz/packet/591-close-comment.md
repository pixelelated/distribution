Completed: all four original acceptance criteria are now checked against the retained original source/result evidence.

## Accepted criterion reconciliation — October 15, 2026

All four criteria are supported by [retained comparison and control evidence](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-frame-claims/README.md), [independent original-frame readback](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/audits/2026_10_14-milestone-m7-next-candidate/frame-claims-supplement-readback.md) and the updated [canonical flow and frame reference](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/es-menu-map.md). Comparator/claim integration is published in `9aaaaa0f642b97ebf722c2e1aeedb7e4d00bcbdc`.

The source diagnosis binds #578's default collection correction, the unchanged theme pin, all78 exact before/after frame hashes and348 narrow added background claims. Representative before/after pairs were visually reviewed; this is not a claim that every pair was manually inspected. The pixel inventory supplies the complete pair/changed-region mapping. Existing masks and the original baseline were not replaced, and no new foreground interior or whole-screen mask was accepted.

Watched continuation `20261015T002234Z-faf6a7c9` retained an old-checker adjacent-claim child exit1, expected by its wrapper, followed by20 successful candidate control outcomes. Negative cases retain failure for a single uncovered connector, bounding gaps, stale/wrong-screen claims, missing frames, size changes and uncovered foreground. All three original continuation stages returned0 without timeout; command/monitor/runner were0/0/0. The corrected comparison over the original78 pairs reports389 claimed regions,0 unclaimed and0 missing. The original65-unclaimed report remains failed.

## Code trace and already-written state

`frame-diff-591.patch` in the original packet assigns only actual changed pixels to live screen-matching claims before clustering the remaining uncovered pixels. Overlap is counted once; bounding-box union does not accept uncovered gaps. Missing/NEW, stale-build and dimension rules retain their separate refusals. Candidate checker SHA256 is `49cdaf5275dceef5ae3bfa06f71c4adb7f35a3b285abf9b1200f0323fec57330`; original mask SHA256 is `64c817d443a15585e194451772424e89ffcb7ad64f83aa3d2b799f0ecbb63a00`.

Already written: the host already held the original failed report, captured VM frames and accepted baseline. This correction preserves those bytes and emits a separately named continuation report; it migrates no device or cloud state and establishes no new-image, physical-device or public-documentation qualification.

# Finite accepted-issue reconciliation

Read-only live snapshots retained for #589/#591/#577 and supporting #511. Reference commit `dd38444c303cbfcd3c125c2e789b3ff4781baf41` contains the accepted evidence. No test, candidate helper, process gate or tracker mutation ran.

**Disposition:** #589 and #591 are ready for completed closure after root applies their exact evidence-backed body updates. #577 remains open until the precise linked public-doc follow-up is recorded and verified. No #577 closure text is prepared before that dependency is met.

## #589

Live title: M7.P5: Correct adopted-process and phone-status QA checks. State: OPEN; updated 2026-10-15T00:08:51Z.

1. **SUPPORTED** — Preserve the original seven failures and exact source/process evidence in a compact published packet; identify exited adopted children separately from live work.

   Evidence/disposition: Seven exact failed log rows in baseline-correction/failure-map.json and original log; four actual host Z snapshots; two unnamed-helper attributions stay inferred. [preserved failures and correction source](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-qualification-followups/README.md)

2. **SUPPORTED** — Correct observation-time reaping without consuming the active Popen wait or signaling live descendants; preserve original adopted wait statuses and normal cleanup evidence.

   Evidence/disposition: observe(active) excludes active.pid and uses WNOHANG only; original71 adopted-exit rows retain actual wait codes; no active command PID is reaped; original cleanup lists empty. [original scripts/SFTP/S3 outcomes](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-baseline-continuation/README.md)

3. **SUPPORTED** — Read PL-016 waiting prose from the current status-message element with the historical-template fallback; retain the assertion that the text is nonempty and does not name an absent button.

   Evidence/disposition: Exact status-message || state patch; existing nonempty/absent-button assertion retained; original scripts log contains its PASS line. [original scripts/SFTP/S3 outcomes](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-baseline-continuation/README.md)

4. **SUPPORTED** — Run the existing scripts row on the same frozen image under a fresh watched owner; retain its original PASS result and actual owner cleanup. Carry the other successful same-image standard rows without repeating them. Complete the separately pending SFTP and local S3 rows under #344.

   Evidence/disposition: Original same-image scripts521s/SFTP67s/S3 111s PASS, seven outer0 channels;13 prior successful standard rows carried, not rerun. [original scripts/SFTP/S3 outcomes](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-baseline-continuation/README.md)

Already written: The live body already contains this line; proposal adds an explicit code trace and preserves its historical scope.

## #591

Live title: M7.P5: Recognize adjoining screenshot claims without broad masks. State: OPEN; updated 2026-10-15T00:22:32Z.

1. **SUPPORTED** — Exact source and before/after frames explain every new claim; update the canonical flow/frame reference without erasing historical evidence.

   Evidence/disposition: Complete78-pair hash/pixel inventory, source/theme trace,348 narrow claims, reviewed representative pairs; canonical Last Played backdrop reference updated. No every-pair manual-view claim. [retained comparison and control evidence](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-frame-claims/README.md); [canonical flow and frame reference](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/es-menu-map.md)

2. **SUPPORTED** — Adjacent independently claimed regions pass while a single uncovered changed pixel, stale claim, missing screen or unclaimed dimension change still fails; retain original control outputs.

   Evidence/disposition: Old adjacent child1 reproduced;20 candidate controls retain positive and exact negative outcomes, including a single uncovered pixel, stale identity, MISSING and size mismatch. [retained comparison and control evidence](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-frame-claims/README.md)

3. **SUPPORTED** — The original78 retained VM frame pairs pass the corrected comparison with narrow documented claims and no new blanket mask or baseline replacement; original failure stays unchanged.

   Evidence/disposition: Separate original continuation compares all78 retained pairs:389 claimed,0 unclaimed,0 missing; old65-unclaimed report remains failed. [retained comparison and control evidence](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-frame-claims/README.md)

4. **SUPPORTED** — Record the actual matcher/claim/source identities, original result channels and remaining limits in M7 qualification evidence.

   Evidence/disposition: Exact matcher/claims/masks/input hashes, stage0/0/0 and runner0/0/0 retained; audit independently read originals; no new firmware/physical claim. [independent original-frame readback](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/audits/2026_10_14-milestone-m7-next-candidate/frame-claims-supplement-readback.md)

Already written: The live body already contains this line; proposal adds an explicit code trace and preserves its historical scope.

## #577

Live title: M7.P5: Keep the Wi-Fi picker visible while networks refresh. State: OPEN; updated 2026-10-15T00:30:24Z.

1. **SUPPORTED** — Same-source VM frame sequences show unchanged dialog/list/footer bounds before, during and after initial/refresh scans, with search status within the list area; cover 640×480 and 1280×800, English and French.

   Evidence/disposition: Prior exact-source EN/FR640/1280 fixed geometry/search frames; later French hint correction; final source-bound unchanged-presentation carry and actual installed clean/retained frames. [four locale/size setup matrix](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-13-setup-qualification/installed/README.md); [canonical flow and frame reference](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/es-menu-map.md)

2. **SUPPORTED** — The delayed initial scan has an in-list searching state; a delayed refresh preserves the last list and safe focus. Completed zero results and failed scans have distinct outcomes and an actionable retry, proved by fixture transcript and reviewed branch frames.

   Evidence/disposition: Delayed initial/search/refresh/empty/failure/retry matrix plus actual installed backend exits0/8/0, empty failed stdout and retained3 rows. [four locale/size setup matrix](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-13-setup-qualification/installed/README.md); [installed backend and missing-route proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-remaining-result/README.md)

3. **SUPPORTED** — A long list scrolls within the stable viewport without clipping the buttons; repeat refresh preserves the selected network when present and deterministically selects a valid row when it disappears, proved by input walk and frames.

   Evidence/disposition: Long36-row scroll/same-result refresh matrix; missing selected third network falls back to QA network02, confirmed by next security query and reviewed frames. [four locale/size setup matrix](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-13-setup-qualification/installed/README.md); [installed backend and missing-route proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-remaining-result/README.md)

4. **SUPPORTED** — Repeated refresh, back/exit during a pending scan, late completion and retry do not duplicate jobs, access a destroyed screen or activate stale rows; bounded fixture transcript records the outcome and all worker exits.

   Evidence/disposition: Repeated/Back/reopen/late completion accepted matrix; later explicit baseline orphans versus candidate join and final clean57.909324ms/retained57.258077ms Back with one enumeration and normal SIGINT join. SIGTERM/fatal residual explicit. [Back/reopen and normal-exit proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-normal-exit-result/README.md); [final clean installed proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-final-engineering-result/clean/README.md); [final retained-update proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-final-engineering-result/retained/README.md)

5. **SUPPORTED** — Saved/connected/open/protected/unknown/manual-input/profile-choice/forget flows retain their behavior in the VM regression transcript, including no password prompt for confirmed open networks.

   Evidence/disposition: Original completed open-connect subcase preserved within failed owner; corrected protected/unknown/manual/saved/profile cases; final connected join and forget cancel/confirm/sibling preservation with27 completed backend invocations. [four locale/size setup matrix](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-13-setup-qualification/installed/README.md); [installed backend and missing-route proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-remaining-result/README.md)

6. **PARTIAL_UNTIL_LINKED_FOLLOWUP_READBACK** — Canonical flow/reference and reviewed exact-source happy/branch frame index accompany the final source; syntax checks and affected VM checks pass before pin promotion. Public setup documentation receives the corresponding follow-up.

   Evidence/disposition: Source/flow/frames/syntax before pin are supported. The corresponding public setup-doc task is not yet live. Proposed #511 addition plus #577 backlink can satisfy recorded-follow-up requirement after exact readback; guide delivery/publication remains separate. [canonical flow and frame reference](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/es-menu-map.md); [exact ES16dbac syntax/link originals](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/audits/2026_10_14-milestone-m7-next-candidate/wifi-compiler-result-readback.md)

Already written: No literal Already written line exists in the current live body. The proposal adds the source-backed state treatment before closure.

## Interpretation of the documentation clause

Exact AC6 wording is quoted above. It asks for a corresponding follow-up, not an already published page or an opened/merged public PR. The current documentation-accuracy rule allows an update “or open a docs follow-up and link it”; the previous remaining-criteria review explicitly calls for tracking/documenting this work without a live-site prerequisite. Therefore a precise task on existing #511 plus the verified #577 backlink satisfies that limited recording requirement. It does not satisfy the new guide-delivery checkboxes or waive preparation of matching public docs before an eventual upstream feature submission. Until the live update is verified, the checkbox remains open.

## Root handoff

- Apply 589-proposed-body.md and591-proposed-body.md after rechecking their current body hashes, then use the matching close-comment files and close completed. Original failed outcomes remain preserved.
- Apply511-proposed-body.md only if the saved current body still matches; it appends the scoped follow-up without rewriting prior site history. Use511-proposed-followup-section.md if concurrent changes require a fresh append.
- Apply577-proposed-body-pending-followup.md for product/state reconciliation. After exact #511 live follow-up and #577 backlink readbacks, AC6 can be checked and a final closure comment prepared. Do not close it from this pending packet alone.
- No runtime, website source change, new issue, deployment, upstream posting or new release gate is requested.

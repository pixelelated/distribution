from pathlib import Path
import json,re,hashlib,datetime
P=Path(__file__).resolve().parent
PIN='dd38444c303cbfcd3c125c2e789b3ff4781baf41'
ROOT='https://github.com/pixelelated/distribution/blob/'+PIN+'/'
def link(name,path):return '['+name+']('+ROOT+path+')'
issues={n:json.loads((P/f'{n}-live.json').read_text()) for n in [589,591,577]}
criteria={n:re.findall(r'^- \[[ x]\] (.+)$',j['body'],re.M) for n,j in issues.items()}
assert [len(criteria[n]) for n in [589,591,577]]==[4,4,6]
base=link('original scripts/SFTP/S3 outcomes','docs/qa-logs/2026-10-15-baseline-continuation/README.md')
fail=link('preserved failures and correction source','docs/qa-logs/2026-10-15-qualification-followups/README.md')
frame=link('retained comparison and control evidence','docs/qa-logs/2026-10-15-frame-claims/README.md')
frread=link('independent original-frame readback','docs/audits/2026_10_14-milestone-m7-next-candidate/frame-claims-supplement-readback.md')
menu=link('canonical flow and frame reference','docs/es-menu-map.md')
setup=link('four locale/size setup matrix','docs/qa-logs/2026-10-13-setup-qualification/installed/README.md')
remaining=link('installed backend and missing-route proof','docs/qa-logs/2026-10-15-wifi-remaining-result/README.md')
normal=link('Back/reopen and normal-exit proof','docs/qa-logs/2026-10-15-wifi-normal-exit-result/README.md')
clean=link('final clean installed proof','docs/qa-logs/2026-10-15-final-engineering-result/clean/README.md')
retained=link('final retained-update proof','docs/qa-logs/2026-10-15-final-engineering-result/retained/README.md')
syntax=link('exact ES16dbac syntax/link originals','docs/audits/2026_10_14-milestone-m7-next-candidate/wifi-compiler-result-readback.md')

resolved589=f'''## Accepted criterion reconciliation — October 15, 2026

All four criteria are now supported by {fail} and {base}. The source correction is `37d26a203e348fb42f251977aaad123604d7347a`; subsequent qualification records are published in `9aaaaa0f642b97ebf722c2e1aeedb7e4d00bcbdc` and retained in the final M7 record.

The seven original failures remain failed. Four named helpers have original host `/proc` zombie evidence; the other two helper assertions are attributed to the same mechanism without a PID-specific snapshot. The corrected observer uses nonblocking waits only for adopted direct children and explicitly excludes the active Popen child. Its original71 observation receipts retain statuses including `-9`, `-15`, `143` and `255`; they are not rewritten to zero. None of their PIDs overlaps an active command PID. The current PL-016 selector reads `status-message` with the historical `state` fallback, retaining both nonempty-text and absent-button assertions.

Fresh same-image run `20261015T000858Z-720211a2` completed on fac608ff/ES3178: scripts PASS521s, SFTP PASS67s and local S3 PASS111s. All seven original outer channels are0; original cleanup errors, remaining children, surviving owned processes and live QEMU lists are empty. The scripts log retains one historical feature group as not applicable, not PASS. The other13 original successful standard rows were carried without repeating them. The old failed aggregate and its separate screenshot failure remain unchanged; #591 owns the later frame comparison. These are synthetic/local protocol proofs, not a real provider or physical-device claim.

## Code trace and already-written state

The retained `baseline-correction/run.py.diff` changes `observe(active)` to use `waitpid(..., WNOHANG)` after skipping `active.pid`; original wait status is recorded before the existing liveness checks. `last-good-scripts-test.diff` changes only the current waiting-message selection and preserves its assertions. Both are in the correction archive linked above.

Already written: only synthetic QA state and original failed evidence existed before this correction. The observer/selector fix performs no device-data migration and does not alter firmware, owner credentials, saves or provider data. Original failed evidence is retained; completed guest/configuration and owned backend cleanup remain separately recorded.
'''
resolved591=f'''## Accepted criterion reconciliation — October 15, 2026

All four criteria are supported by {frame}, {frread} and the updated {menu}. Comparator/claim integration is published in `9aaaaa0f642b97ebf722c2e1aeedb7e4d00bcbdc`.

The source diagnosis binds #578's default collection correction, the unchanged theme pin, all78 exact before/after frame hashes and348 narrow added background claims. Representative before/after pairs were visually reviewed; this is not a claim that every pair was manually inspected. The pixel inventory supplies the complete pair/changed-region mapping. Existing masks and the original baseline were not replaced, and no new foreground interior or whole-screen mask was accepted.

Watched continuation `20261015T002234Z-faf6a7c9` retained an old-checker adjacent-claim child exit1, expected by its wrapper, followed by20 successful candidate control outcomes. Negative cases retain failure for a single uncovered connector, bounding gaps, stale/wrong-screen claims, missing frames, size changes and uncovered foreground. All three original continuation stages returned0 without timeout; command/monitor/runner were0/0/0. The corrected comparison over the original78 pairs reports389 claimed regions,0 unclaimed and0 missing. The original65-unclaimed report remains failed.

## Code trace and already-written state

`frame-diff-591.patch` in the original packet assigns only actual changed pixels to live screen-matching claims before clustering the remaining uncovered pixels. Overlap is counted once; bounding-box union does not accept uncovered gaps. Missing/NEW, stale-build and dimension rules retain their separate refusals. Candidate checker SHA256 is `49cdaf5275dceef5ae3bfa06f71c4adb7f35a3b285abf9b1200f0323fec57330`; original mask SHA256 is `64c817d443a15585e194451772424e89ffcb7ad64f83aa3d2b799f0ecbb63a00`.

Already written: the host already held the original failed report, captured VM frames and accepted baseline. This correction preserves those bytes and emits a separately named continuation report; it migrates no device or cloud state and establishes no new-image, physical-device or public-documentation qualification.
'''
for n,text in [(589,resolved589),(591,resolved591)]:
 body=issues[n]['body'].replace('- [ ]','- [x]')+'\n\n'+text
 (P/f'{n}-proposed-body.md').write_text(body.rstrip()+'\n')
 (P/f'{n}-close-comment.md').write_text(('Completed: all four original acceptance criteria are now checked against the retained original source/result evidence.\n\n'+text).rstrip()+'\n')

followup=f'''## Linked M7 Wi-Fi setup-guide follow-up — #577

This is the corresponding public setup-documentation follow-up for #577's final criterion. Its software proof is complete; guide delivery remains owned here in the existing website lane. Recording this task does not claim a published guide change or authorize deployment, an upstream submission, a new live URL, or physical-device testing. Website delivery remains parallel and does not add a firmware build/RC gate. Relevant upstream public documentation must still be prepared alongside its eventual feature submission under #585.

Use the existing setup-guide source or a linked Wi-Fi section; choose its actual destination in the website lane rather than inventing a route. Describe the qualified behavior:

- Open **Network Settings → Wi-Fi Network**. The network list keeps a stable viewport and scrolls for longer results. Initial searching appears inside the list area.
- **Refresh** keeps the last usable results visible while checking. A completed empty scan and a failed scan have distinct outcomes; on failure, retain the previous results and use **Refresh** to try again. Do not describe a failed enumeration as proof that no network exists.
- **Back** closes the picker during a scan. A bounded read can finish after the picker closes; reopening attaches to the pending read rather than starting a second scan. Do not promise immediate cancellation or universal service/fatal-exit containment.
- Preserve saved/connected marks and existing connection routes: confirmed open networks do not ask for a key, protected/unknown networks use the key editor, multiple saved profiles require an explicit choice, and **Forget** requires confirmation and affects the selected profile. Cancellation preserves it and sibling profiles remain.

Agent-verifiable delivery within this existing docs work:

- [ ] A retained guide-source commit/diff updates the setup instructions for the behaviors above, with a source-to-prose mapping to ES `16dbac5211eea7e70db7394372033be2be7df829` and the current canonical reference. Existing guide build/prose/link checks and reviewed chosen screenshots substantiate the change; no owner credential or live network is required.
- [ ] The website lane links that exact guide change and its existing validation receipts back to #577/#511. Any eventual public URL, publication status or upstream docs PR is recorded from its actual result; no placeholder destination or deployment claim is substituted.

Evidence: {menu}; {setup}; {remaining}; {normal}; {clean}; {retained}. The product evidence uses synthetic enumeration/profile transport, not a physical radio or real credentials. The installed final image proof is f863/ES16dbac; older component and failed-original scopes remain explicitly retained.
'''
j511=json.loads((P/'511-context-live.json').read_text())
(P/'511-proposed-followup-section.md').write_text(followup)
(P/'511-proposed-body.md').write_text(j511['body'].rstrip()+'\n\n'+followup)

state577=f'''## Current criterion reconciliation — October 15, 2026

The first five product criteria are supported by the source-bound component matrix, the previously missing installed-backend/selection/connected/forget continuation, and final f863/ES16dbac clean and retained flows. Earlier sections below retain intake and intermediate history; they do not erase these later outcomes. Evidence: {setup}, {remaining}, {normal}, {clean}, {retained}.

The sixth criterion's source/flow/frame/syntax requirements are supported by {menu} and {syntax}. Its public-doc follow-up is pending a precise live linked task in #511; leave this criterion unchecked until that body update and backlink are verified. This records a follow-up, not delivered guide source, website publication or an upstream PR. No new runtime is required by this reconciliation.

## Code trace and already-written state

Current `GuiWifi.cpp` at ES16dbac retains scan results/focus, prevents duplicate scan activation, blocks stale-row actions while loading and reuses a pending process-owned scan after Back/reopen. Normal frontend exit requests stop and joins the worker. The accepted source and frames explicitly exclude SIGTERM/fatal containment and physical-radio guarantees.

Already written: previous builds could leave saved NetworkManager profiles, selected network settings and retained user configuration. The picker layout/search change introduces no persistent-format migration or automatic profile deletion; existing connect/join actions remain explicit and Forget still requires confirmation of one selected profile. The installed continuation proves cancel/no deletion and confirmed deletion with a sibling profile preserved; final retained update preserves its eight specifically selected state files. This does not claim every arbitrary storage file or the adjacent es_settings.cfg.backup was inventoried.

'''
body=issues[577]['body']
for ac in criteria[577][:5]:body=body.replace('- [ ] '+ac,'- [x] '+ac,1)
(P/'577-proposed-body-pending-followup.md').write_text(state577+body.rstrip()+'\n')
(P/'577-progress-comment.md').write_text(state577)

mapping={589:[
 ('SUPPORTED','Seven exact failed log rows in baseline-correction/failure-map.json and original log; four actual host Z snapshots; two unnamed-helper attributions stay inferred.',fail),
 ('SUPPORTED','observe(active) excludes active.pid and uses WNOHANG only; original71 adopted-exit rows retain actual wait codes; no active command PID is reaped; original cleanup lists empty.',base),
 ('SUPPORTED','Exact status-message || state patch; existing nonempty/absent-button assertion retained; original scripts log contains its PASS line.',base),
 ('SUPPORTED','Original same-image scripts521s/SFTP67s/S3 111s PASS, seven outer0 channels;13 prior successful standard rows carried, not rerun.',base)],591:[
 ('SUPPORTED','Complete78-pair hash/pixel inventory, source/theme trace,348 narrow claims, reviewed representative pairs; canonical Last Played backdrop reference updated. No every-pair manual-view claim.',frame+'; '+menu),
 ('SUPPORTED','Old adjacent child1 reproduced;20 candidate controls retain positive and exact negative outcomes, including a single uncovered pixel, stale identity, MISSING and size mismatch.',frame),
 ('SUPPORTED','Separate original continuation compares all78 retained pairs:389 claimed,0 unclaimed,0 missing; old65-unclaimed report remains failed.',frame),
 ('SUPPORTED','Exact matcher/claims/masks/input hashes, stage0/0/0 and runner0/0/0 retained; audit independently read originals; no new firmware/physical claim.',frread)],577:[
 ('SUPPORTED','Prior exact-source EN/FR640/1280 fixed geometry/search frames; later French hint correction; final source-bound unchanged-presentation carry and actual installed clean/retained frames.',setup+'; '+menu),
 ('SUPPORTED','Delayed initial/search/refresh/empty/failure/retry matrix plus actual installed backend exits0/8/0, empty failed stdout and retained3 rows.',setup+'; '+remaining),
 ('SUPPORTED','Long36-row scroll/same-result refresh matrix; missing selected third network falls back to QA network02, confirmed by next security query and reviewed frames.',setup+'; '+remaining),
 ('SUPPORTED','Repeated/Back/reopen/late completion accepted matrix; later explicit baseline orphans versus candidate join and final clean57.909324ms/retained57.258077ms Back with one enumeration and normal SIGINT join. SIGTERM/fatal residual explicit.',normal+'; '+clean+'; '+retained),
 ('SUPPORTED','Original completed open-connect subcase preserved within failed owner; corrected protected/unknown/manual/saved/profile cases; final connected join and forget cancel/confirm/sibling preservation with27 completed backend invocations.',setup+'; '+remaining),
 ('PARTIAL_UNTIL_LINKED_FOLLOWUP_READBACK','Source/flow/frames/syntax before pin are supported. The corresponding public setup-doc task is not yet live. Proposed #511 addition plus #577 backlink can satisfy recorded-follow-up requirement after exact readback; guide delivery/publication remains separate.',menu+'; '+syntax)]}
lines=['# Finite accepted-issue reconciliation','',f'Read-only live snapshots retained for #589/#591/#577 and supporting #511. Reference commit `{PIN}` contains the accepted evidence. No test, candidate helper, process gate or tracker mutation ran.','',
'**Disposition:** #589 and #591 are ready for completed closure after root applies their exact evidence-backed body updates. #577 remains open until the precise linked public-doc follow-up is recorded and verified. No #577 closure text is prepared before that dependency is met.','']
for n in [589,591,577]:
 lines+=['## #'+str(n),'',f'Live title: {issues[n]["title"]}. State: {issues[n]["state"]}; updated {issues[n]["updatedAt"]}.','']
 for i,(criterion,(status,why,evidence)) in enumerate(zip(criteria[n],mapping[n]),1):
  lines += [f'{i}. **{status}** — {criterion}','',f'   Evidence/disposition: {why} {evidence}','']
 lines += ['Already written: '+('The live body already contains this line; proposal adds an explicit code trace and preserves its historical scope.' if n in [589,591] else 'No literal Already written line exists in the current live body. The proposal adds the source-backed state treatment before closure.'),'']
lines += ['## Interpretation of the documentation clause','',
'Exact AC6 wording is quoted above. It asks for a corresponding follow-up, not an already published page or an opened/merged public PR. The current documentation-accuracy rule allows an update “or open a docs follow-up and link it”; the previous remaining-criteria review explicitly calls for tracking/documenting this work without a live-site prerequisite. Therefore a precise task on existing #511 plus the verified #577 backlink satisfies that limited recording requirement. It does not satisfy the new guide-delivery checkboxes or waive preparation of matching public docs before an eventual upstream feature submission. Until the live update is verified, the checkbox remains open.','',
'## Root handoff','',
'- Apply 589-proposed-body.md and591-proposed-body.md after rechecking their current body hashes, then use the matching close-comment files and close completed. Original failed outcomes remain preserved.','- Apply511-proposed-body.md only if the saved current body still matches; it appends the scoped follow-up without rewriting prior site history. Use511-proposed-followup-section.md if concurrent changes require a fresh append.','- Apply577-proposed-body-pending-followup.md for product/state reconciliation. After exact #511 live follow-up and #577 backlink readbacks, AC6 can be checked and a final closure comment prepared. Do not close it from this pending packet alone.','- No runtime, website source change, new issue, deployment, upstream posting or new release gate is requested.','']
(P/'criterion-map.md').write_text('\n'.join(lines))
receipt={'read_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_reference_commit':PIN,'tracker_mutations':False,'runtime_executed':False,'observations':{}}
for n,f,chunk in [(589,'589-live.json','8519c1'),(591,'591-live.json','3ee417'),(577,'577-live.json','826cd7'),(511,'511-context-live.json','3541f6')]:
 j=json.loads((P/f).read_text());receipt['observations'][str(n)]={'file':f,'sha256':hashlib.sha256((P/f).read_bytes()).hexdigest(),'body_sha256':hashlib.sha256(j['body'].encode()).hexdigest(),'updated_at':j['updatedAt'],'state':j['state'],'tool_chunk':chunk,'original_exec_exit':0}
(P/'live-readback-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Prepared exact proposals; #577 remains pending live follow-up readback.')

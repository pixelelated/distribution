## Current criterion reconciliation — October 15, 2026

The first five product criteria are supported by the source-bound component matrix, the previously missing installed-backend/selection/connected/forget continuation, and final f863/ES16dbac clean and retained flows. Earlier sections below retain intake and intermediate history; they do not erase these later outcomes. Evidence: [four locale/size setup matrix](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-13-setup-qualification/installed/README.md), [installed backend and missing-route proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-remaining-result/README.md), [Back/reopen and normal-exit proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-wifi-normal-exit-result/README.md), [final clean installed proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-final-engineering-result/clean/README.md), [final retained-update proof](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/qa-logs/2026-10-15-final-engineering-result/retained/README.md).

The sixth criterion's source/flow/frame/syntax requirements are supported by [canonical flow and frame reference](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/es-menu-map.md) and [exact ES16dbac syntax/link originals](https://github.com/pixelelated/distribution/blob/dd38444c303cbfcd3c125c2e789b3ff4781baf41/docs/audits/2026_10_14-milestone-m7-next-candidate/wifi-compiler-result-readback.md). Its public-doc follow-up is now recorded in the linked [#511 Wi-Fi setup-guide task](https://github.com/pixelelated/distribution/issues/511), with exact live body readback verified on October 15. The task carries the qualified behavior, source/frame references and agent-verifiable guide-source/check receipts. This fulfills the corresponding-follow-up requirement; actual guide delivery, website publication and upstream docs preparation remain owned by #511/#585 and are not claimed complete. No new runtime was required by this reconciliation.

## Code trace and already-written state

Current `GuiWifi.cpp` at ES16dbac retains scan results/focus, prevents duplicate scan activation, blocks stale-row actions while loading and reuses a pending process-owned scan after Back/reopen. Normal frontend exit requests stop and joins the worker. The accepted source and frames explicitly exclude SIGTERM/fatal containment and physical-radio guarantees.

Already written: previous builds could leave saved NetworkManager profiles, selected network settings and retained user configuration. The picker layout/search change introduces no persistent-format migration or automatic profile deletion; existing connect/join actions remain explicit and Forget still requires confirmation of one selected profile. The installed continuation proves cancel/no deletion and confirmed deletion with a sibling profile preserved; final retained update preserves its eight specifically selected state files. This does not claim every arbitrary storage file or the adjacent es_settings.cfg.backup was inventoried.

## Reconciled October14 status

The staged persistent picker now has passing EN/FR640/1280 initial/search/refresh/error/empty/scroll and connection-route observations.74 separate actual-script controls cover enumeration error propagation. Subsequent compiled French hint frames are retained in the library VM packet; the old untranslated-hint observation remains historical.

Remaining: execute the corrected backend through the final UI composition and assembled-image/retained checks. Synthetic enumeration is not a radio measurement. The former “no implementation yet” paragraphs below describe intake/baseline time, not current status. Evidence: local installed setup, library VM and exact frame indexes. Prior rows remaining dimmed during refresh is still the corrected baseline finding; do not revive the disproved disappearance claim.

This is a scoped readiness update under #585; all broader unproved acceptance criteria remain open. Earlier sections below retain their dated source/evidence history.

## Earlier intake and evidence history

## Owner report — October 13, 2026

> A couple of things I've also found:
> - When doing a search for Wi-Fi networks, the list of networks disappears. You should have a fixed-height modal with scroll that remains persistent while the refresh is going on. Otherwise, it looks odd.
> - Wi-Fi networks are at the top, and the refresh input is manually actuated directly below it, but there is no content yet while it's currently searching. It should be showing the search inside of it.

## Current behavior and scope

Accepted ES source `c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78`, `es-app/src/guis/GuiWifi.cpp`: construction posts an initial load before adding any network rows; `onRefresh()` pushes a separate `GuiLoading<Answer>`; `load()` clears/rebuilds the list and calls `mMenu.updateSize()`. There is no reserved stable list viewport or search status within it. This source trace supports the reported layout problem; the October13 runtime baseline below now records the actual behavior.

Keep the Wi-Fi picker visible at a stable screen-relative height during initial search and later refresh, with scrolling for longer results and search status inside the list area. Keep the last list visible during refresh and preserve focus/scroll where its selected network survives. The empty first search must show that a search is in progress, not premature no-networks copy. Retain connected/saved marks, open-network routing, manual input, profile choice and explicit forget behavior from #201/#318/#535. This is not captive-portal work (#158).

Changing the overlay means rechecking asynchronous lifetime and input ownership: prevent duplicate scans and stale callbacks, handle exit safely, and ensure a refresh cannot inadvertently activate an old row or mutate network settings. Distinguish a completed empty scan from failure; keep retry available without throwing away usable previous results.

Upstream check, October 13: the official ROCKNIX ES history for this file still ends at `cada856d86e3115fbbf0bce09dd761b0ee8fa9fd` (September 28), already integrated through #318. No later fix for this file was found; the distribution's Issues feature is disabled. This is a bounded source-history check, not a claim that no upstream report exists anywhere.

## Implementation and proof order

Can this be done on the VM? **Yes.** Use deterministic delayed/success/empty/failure Wi-Fi command fixtures and real ES rendering; no physical radio, owner's network credentials or device mutation is needed to prove layout, focus, input and lifetime behavior.

1. Capture the accepted-source initial/refresh layout, then implement in an isolated ES branch from the accepted pin using the native menu/busy components.
2. Update `docs/es-menu-map.md` and its flow branches, player copy/French, and exact-source frame index in the same change. D-WORKFLOW-155/156 applies; intended behavior is not a shipped screenshot.
3. Qualify the affected lifecycle, input and existing Wi-Fi behavior on the VM; run `tools/es-syntax-check` before any pin promotion. Integrate with M7's setup-interface repairs before renewed candidate qualification.

## Acceptance criteria

- [x] Same-source VM frame sequences show unchanged dialog/list/footer bounds before, during and after initial/refresh scans, with search status within the list area; cover 640×480 and 1280×800, English and French.
- [x] The delayed initial scan has an in-list searching state; a delayed refresh preserves the last list and safe focus. Completed zero results and failed scans have distinct outcomes and an actionable retry, proved by fixture transcript and reviewed branch frames.
- [x] A long list scrolls within the stable viewport without clipping the buttons; repeat refresh preserves the selected network when present and deterministically selects a valid row when it disappears, proved by input walk and frames.
- [x] Repeated refresh, back/exit during a pending scan, late completion and retry do not duplicate jobs, access a destroyed screen or activate stale rows; bounded fixture transcript records the outcome and all worker exits.
- [x] Saved/connected/open/protected/unknown/manual-input/profile-choice/forget flows retain their behavior in the VM regression transcript, including no password prompt for confirmed open networks.
- [x] Canonical flow/reference and reviewed exact-source happy/branch frame index accompany the final source; syntax checks and affected VM checks pass before pin promotion. Public setup documentation receives the corresponding follow-up.

Parent M7/#344, phase P5; planned with #571 setup-interface work. No product implementation, screenshot proof or owner-device operation is claimed by this intake.


## October13 accepted-source baseline and correction

Twelve reviewed English frames at640×480/1280×800: blank initial list with separate search overlay; on large screens the short initial dialog grows and its footer moves when results arrive; successful empty scan and failed scan(exit2) have byte-identical NO WI-FI NETWORKS FOUND completion frames.

**Correction to the preliminary plan comment:** existing rows remain visible, dimmed behind the overlay during populated refresh. The baseline does not reproduce their disappearance; the earlier statement that the overlay hides the entire list was incorrect. Keep results visible during the fix, but target the observed initial geometry, external status and missing failure distinction. [Reviewed exact-source frame index](https://github.com/pixelelated/distribution/blob/4d5c26807d92e0535b8a5e796c8e6446aab47c6c/docs/qa-logs/2026-10-13-library-wifi-baseline/frame-index.json), [transcript and limits](https://github.com/pixelelated/distribution/blob/4d5c26807d92e0535b8a5e796c8e6446aab47c6c/docs/qa-logs/2026-10-13-library-wifi-baseline/README.md).

The synthetic command never joins a real network. All test jobs ended; guest enumeration restored, exact VM stopped and its disk/UEFI/keys retired. No fixed-source, French, long-list/focus/lifetime or saved/open/forget regression acceptance yet; implementation remains open.

# Installed UI loader evidence correction — revision04, UNRUN

Source-only derivative of revision03 (`5fa354ba…`) and its unchanged original
inner smoke (`c46457c6…`). Both original directories/seals remain untouched.
The original UI owner01 stays failed. This is fixture evidence handling; the
libgstnet product recipe fix is separate and must be in a newly completed image.

Exactly five executable source files change:

- `smoke/guest-preflight.py`: keep each original stdout/stderr as raw files and
  write its original wait/timeout/exception receipt before any rc/warning
  assertion. Always write loader-result.json on normal Python exceptions.
  Fresh-result refusal occurs before the handled block, preserving old originals.
  The three existing loader commands, limits, RTLD_NOW loads, rc0 and strict
  “Failed to load plugin”/“External plugin loader failed” refusals are retained.
- `smoke/run.py`: a finally around the loader stage exports the original
  loader result, per-command JSON/raw streams and fresh registry before seam
  provisioning or ordinary cleanup, even when that stage fails. Selected files
  only; no credentials/configuration archives. Export failures stay failures and
  are separately recorded; original SSH stage stdout/stderr/wait remain intact.
- `smoke/prepare.py`: require explicit source/ES IDs matched against the
  completed verifier instead of old hardcoded IDs; add
  `usr/lib/libgstnet-1.0.so.0` to the existing installed byte/mode readback set.
- `lifecycle/prepare.py`: bind current verifier source/ES to the exact frozen
  checkout HEAD and distribution ES package pin. Require the new libgstnet
  verifier member before preparing an owner. No assumed final hash. Updated
  inner seal/archive constants select only this corrected derivative.
- `lifecycle/vm-lifecycle.py`: pass those bound explicit IDs to inner prepare.
  Existing boot/clean/SSH/owner/census/cleanup behavior is unchanged.

The next completed image verifier must include libgstnet's actual final
install→SYSTEM bytes, mode and rooted link chain. All other installed member
requirements are unchanged. No verifier report may be hand-edited to invent
that entry. Earlier source/frame acceptance stays historical evidence for
unchanged flow sources; new image identities and loader execution remain UNRUN.

Prepare only after the coordinator names the next frozen checkout and completed
readback. These shell variables are explicit inputs, not predicted image names:

```bash
TASK_SOURCE=/tmp/pix-m7-installed-ui-lifecycle-20261014-revision04
TASK_COORD=/workspace/repos/rocknix.worktrees/m7-player-setup
# Set TASK_TREE to the next frozen build checkout and TASK_VERIFY to its
# completed artifacts/result.json. Preparation checks both identities.
: "${TASK_TREE:?set next frozen build checkout}"
: "${TASK_VERIFY:?set next completed image verification result.json}"
TASK_OWNER=/workspace/tmp/pix-m7-installed-ui-20261014-02

python3 -I -B "$TASK_SOURCE/lifecycle/prepare.py" \
  --checkout "$TASK_TREE" --clean-checkout "$TASK_COORD" \
  --verification "$TASK_VERIFY" --archive "$TASK_SOURCE/smoke-originals.tar.gz" \
  --owner "$TASK_OWNER" --ssh-port 10618 --vnc 118
cd "$TASK_TREE"
tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" \
  --output "$TASK_OWNER/retention-report.json"
tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" \
  --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --admission "$TASK_OWNER/admission.json" --activity-dir "$TASK_OWNER" --recursive-activity -- \
  python3 -I -B "$TASK_OWNER/vm-lifecycle.py"
```

The existing allocation remains one normal networked8GiB/4CPU guest, 1800s work
plus90s cleanup and900s original smoke. Port availability is checked at launch.
Qualified subreaper/pidfd/census and process stop are byte-unchanged. The owner
must actively supervise and deliver original completion. After it ends:

```bash
TASK_RUN=$(cat "$TASK_OWNER/run.path")
TASK_EXPORT=/workspace/tmp/pix-m7-installed-ui-export-20261014-02
python3 -I -B "$TASK_OWNER/close.py" \
  --owner "$TASK_OWNER" --run "$TASK_RUN" --output "$TASK_EXPORT"
# Review original command receipts and restoration/owner results first.
tools/host-maintenance/build-admission consume --run "$TASK_RUN" \
  --evidence "$TASK_EXPORT/consumption-draft.json"
```

Close/export remains unchanged and includes the new small `smoke/loader-evidence`
subdirectory automatically. Original expected failures remain failures.
Coordinator alone consumes/retires. No runtime was run during preparation.

The optional stopped-registry readback note is separate and not needed now:
retained diagnostic recovered all four missing-libgstnet warnings and its exact
registry. Do not start a FUSE reader merely because the note exists.

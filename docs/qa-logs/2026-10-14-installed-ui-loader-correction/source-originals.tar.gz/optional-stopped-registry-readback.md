# Optional read-only export route — identified, not executed or needed now

The root-owned retained diagnostic recovered the exact four missing-libgstnet
warnings and its registry. Do not allocate this extra reader now. This note
only answers how the original failed UI registry could be recovered cheaply
if its own bytes later become necessary.

Existing host tools: `/usr/bin/qemu-storage-daemon`10.2.1 links
`libfuse3.so.4`, `/dev/fuse` is present in the actual host namespace,
`/usr/sbin/debugfs` and `fusermount3` exist. The installed QEMU man page and
QMP reference describe FUSE exports with writable=off, a preexisting regular
file mountpoint, and raw block-node offset. No new tool/build is needed.
No NBD kernel device is needed. No guest VM boots and no full raw disk or
partition is copied. A bounded owned QSD process services only requested
qcow2 blocks; debugfs never receives `-w` and does not replay a journal.

If separately allocated, first verify the original UI owner is stopped and
preserve original disk identity/stat/hash custody under that reader's owner.
Read only the first34 512-byte sectors using `qemu-img dd -f qcow2 bs=512
count=34` into a17KiB private header file. Validate its GPT header/partition
entry CRCs and obtain STORAGE's actual starting LBA, rather than assuming the
resized partition end. The completed d6a verifier's original start is8396800
sectors (4299161600bytes), but actual stopped-disk GPT must match before use.

The existing-tool argv, with private absolute paths and verified offset:

```text
qemu-storage-daemon
  --blockdev driver=file,node-name=file,filename=STOPPED_QCOW2,read-only=on
  --blockdev driver=qcow2,node-name=disk,file=file,read-only=on
  --blockdev driver=raw,node-name=storage,file=disk,offset=VERIFIED_BYTES,read-only=on
  --export type=fuse,id=registry-read,node-name=storage,mountpoint=PRIVATE_EMPTY_FILE,writable=off,growable=off,allow-other=off
  --pidfile PRIVATE_PIDFILE
```

Run in the foreground under the already-qualified owner/census, with actual
Popen status retained and a short clock. Wait for its pidfile and verify the
FUSE file mount before a bounded reader:

```text
debugfs -R 'stat /qa570flows/gst-registry.bin' PRIVATE_FUSE_FILE
debugfs -R 'dump /qa570flows/gst-registry.bin PRIVATE_OUTPUT' PRIVATE_FUSE_FILE
```

Capture every original stdout/stderr/status; cap the selected output using
its stat size before dump and verify actual output hash/size. Normal cleanup:
`fusermount3 -u PRIVATE_FUSE_FILE`, then an identity-checked SIGTERM to the owned
foreground QSD (documented normal shutdown), original wait, actual process and
mount absence. A pidfd avoids PID reuse; the qualified census handles any
adopted child. Preserve before/after base equality. A forced stop or missing
readback is a failed reader, never rewritten as successful evidence.

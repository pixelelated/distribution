# Installed UI outer lifecycle — revision04, UNRUN

See ../README.md for exact next-image commands. Source derives from unchanged
revision03 seal5fa354ba9d8e2cba268d0293e97078dfcd20be31524c17c06ad447c03f07dd81.
The original directory remains untouched; original-SHA256SUMS records it.

Only prepare.py identity/seal binding and vm-lifecycle.py's two explicit inner
prepare identity arguments change. Current completed verifier source and ES
must equal frozen checkout HEAD and its literal ES package pin. libgstnet's
actual verified member is required, with no assumed final hash. Original
clean-checkout option, one normal8GiB/4CPU networked guest, 1800+90s clocks,
900s case ceiling, source-only bind, real products, explicit allowed seams,
subreaper/pidfd cleanup and compact original export are unchanged. close.py,
guest-postcheck.py and census.py are byte-identical to revision03.

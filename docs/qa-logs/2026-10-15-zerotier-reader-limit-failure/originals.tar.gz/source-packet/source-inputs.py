#!/usr/bin/env python3
"""Reader-only exact completed ZeroTier02 source/dependency readback. No source body is executed."""
import hashlib,json,os,shlex,stat
from pathlib import Path
READ_BYTES=0

def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def digest(p):
 global READ_BYTES
 size=Path(p).stat().st_size
 need(size<=128*1024**2 and READ_BYTES+size<=3*1024**3,'bounded named read budget exceeded')
 READ_BYTES+=size
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def put(p,v):
 data=(json.dumps(v,indent=2)+'\n').encode();need(len(data)<=16*1024**2,'receipt exceeds assigned file limit')
 with Path(p).open('xb') as f:f.write(data)
def base():return json.loads(Path('/plan/build-plan.json').read_text())
def depnames(path,cwd):
 need(path.stat().st_size<=4*1024**2,'dependency text too large')
 text=path.read_text();need(len(text)<=4*1024**2,'dependency text too large')
 logical=text.replace('\\\n','').splitlines()[0];need(':' in logical,'dependency rule absent')
 # All selected filenames are without whitespace; shlex handles GCC backslash escaping.
 names=shlex.split(logical.split(':',1)[1]);need(names,'empty dependency rule')
 return [(Path(x) if Path(x).is_absolute() else cwd/x) for x in names]
def verify():
 b=base();root=Path('/work/source');before=json.loads(Path(b['reader_originals']['source_before']).read_text());need(not (root/'nonfree').exists() and not (root/'nonfree').is_symlink(),'nonfree appeared')
 for r in before['files']:
  p=root/r['path'];need(p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and digest(p)==r['sha256'] and stat.S_IMODE(p.stat().st_mode)==r['mode'],'source changed: '+r['path'])
 for r in before['links']:need(os.readlink(root/r['path'])==r['target'],'source link changed')
 dependency_files=sorted(root.rglob('*.d'));need(10<len(dependency_files)<300,'missing/excess dependency files')
 context=json.loads(Path('/plan/dependency-context.json').read_text());mapping={r['dependency_file']:r for r in context['bindings']}
 need([str(p.relative_to(root)) for p in dependency_files]==sorted(mapping),'dependency file set changed')
 need(len(mapping)==89 and sum(r['dependency_bytes'] for r in mapping.values())==6585633,'dependency mapping totals changed')
 names=[];units=[];used=[];raw=Path('/receipts/dependency-raw');raw.mkdir()
 for i,path in enumerate(dependency_files):
  r=mapping[str(path.relative_to(root))];need(path.stat().st_size==r['dependency_bytes'] and digest(path)==r['dependency_sha256'],'dependency original changed')
  need(r['cwd'] in ('/work/source','/work/source/ext/libnatpmp'),'unbound compiler cwd')
  logical=path.read_text().replace('\\\n','').splitlines()[0];target,prerequisites=logical.split(':',1)
  need(shlex.split(target)==[r['object_argument']] and shlex.split(prerequisites)[0]==r['source_argument'],'dependency target/source differs from last original compile command')
  need((Path(r['cwd'])/r['object_argument']).resolve()==root/r['object'],'compile target/cwd mapping differs')
  names+=depnames(path,Path(r['cwd']));used.append(r)
  data=path.read_bytes();need(len(data)==r['dependency_bytes'],'dependency changed before copy')
  with (raw/(str(i).zfill(3)+'.d')).open('xb') as f:f.write(data)
  need(hashlib.sha256(data).hexdigest()==r['dependency_sha256'],'dependency copied hash differs')
 put('/receipts/dependency-context-used.json',{'bindings':used,'raw_names':'dependency-raw/<zero-based sorted index>.d','original_recipe_stdout_sha256':context['original_recipe_stdout_sha256']})
 # All 89 final objects have explicit original compiler commands and -MD outputs.
 objects={r['object']:r for r in mapping.values()}
 need(sorted(str(p.relative_to(root)) for p in root.rglob('*.o'))==sorted(objects),'object set differs from original compiler commands')
 for relative,r in sorted(objects.items()):
  obj=root/relative;src=root/r['source']
  need(src.is_file() and not src.is_symlink() and obj.with_suffix('.d').is_file(),'recorded compile source/dependency missing')
  names.append(src);units.append({'object':str(obj.relative_to(root)),'source':str(src.relative_to(root)),'object_sha256':digest(obj)})
 need(any(x['source']=='service/OneService.cpp' for x in units),'candidate object not built')
 link=Path(b['reader_originals']['link']);need(link.is_file(),'actual link dependency list absent');names+=depnames(link,root)
 toolroot=Path(b['container_root'])/b['build_relative']/'toolchain';unique={};unique_bytes=0
 for p in names:
  if str(p) in unique:continue
  resolved=p.resolve();need('nonfree' not in p.parts and 'nonfree' not in resolved.parts,'nonfree dependency consumed')
  need(resolved.is_relative_to(root) or resolved.is_relative_to(toolroot),'dependency outside private source/frozen toolchain: '+str(p))
  need(resolved.is_file(),'dependency missing: '+str(p))
  size=resolved.stat().st_size;unique_bytes+=size
  need(len(unique)<9999 and unique_bytes<1024**3,'dependency inventory bound before hashing')
  unique[str(p)]={'path':str(p),'resolved':str(resolved),'bytes':size,'sha256':digest(resolved)}
 need(len(unique)<10000 and sum(x['bytes'] for x in unique.values())<1024**3,'dependency inventory bound')
 artifact=root/'zerotier-one'
 with artifact.open('rb') as f:head=f.read(20)
 need(head[:6]==b'\x7fELF\x02\x01' and int.from_bytes(head[18:20],'little')==62,'not target x86-64 ELF')
 for n in ['zerotier-cli','zerotier-idtool']:need(os.readlink(root/n)=='zerotier-one','one target link absent')
 for row in unique.values():need(digest(row['resolved'])==row['sha256'],'dependency changed during readback')
 put('/receipts/consumed-dependencies.json',{'units':units,'dependency_files':[str(p.relative_to(root)) for p in dependency_files]+[str(link)],'files':list(unique.values()),'nonfree_dependencies':[]})
 put('/receipts/target-artifact.json',{'path':str(artifact),'bytes':artifact.stat().st_size,'sha256':digest(artifact),'source_archive_sha256':b['archive_sha256'],'candidate_sha256':b['candidate_sha256'],'patch_sha256':b['patch_sha256'],'distribution_commit':b['distribution_commit'],'nonfree_present':False,'nonfree_dependencies':[],'scope':'Reader-only readback of successful original ZeroTier02 GENERIC_X64 one recipe. Target NOT EXECUTED; no firmware or legal/publication qualification.'})
if __name__=='__main__':
 import sys
 need(len(sys.argv)==2 and sys.argv[1]=='verify','reader-only phase required')
 verify()

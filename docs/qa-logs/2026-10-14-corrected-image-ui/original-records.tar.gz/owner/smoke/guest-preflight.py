#!/usr/bin/python3
"""Installed loader readback, with original command receipts before assertions."""
import ctypes,hashlib,json,os,signal,subprocess,sys,stat,time,traceback
from pathlib import Path
ROOT=Path('/storage/qa570flows');RESULT=ROOT/'loader-result.json'
# A repeated invocation must not overwrite any original.
assert not RESULT.exists() and not any(ROOT.glob('loader-command-*')),'fresh loader result required'
rows={};checks=[];result={'status':'FAIL','members':rows,'checks':checks,'started':time.time()}
def write_result():
 tmp=ROOT/'loader-result.json.new';tmp.write_text(json.dumps(result,indent=2)+'\n');os.replace(tmp,RESULT)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def command(args,seconds,env=None):
 index=len(checks);stem=ROOT/('loader-command-%02d'%index);row={'argv':args,'timeout_seconds':seconds,'original_returncode':None,'timed_out':False};checks.append(row);write_result();child=None
 try:
  with Path(str(stem)+'.stdout').open('xb') as out,Path(str(stem)+'.stderr').open('xb') as err:
   child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env,start_new_session=True)
   try:row['original_returncode']=child.wait(timeout=seconds)
   except subprocess.TimeoutExpired:
    row['timed_out']=True;os.killpg(child.pid,signal.SIGKILL);row['original_returncode']=child.wait(timeout=5)
 except BaseException as error:
  row['exception']=type(error).__name__+': '+str(error)
  if child:
   if child.poll() is None:os.killpg(child.pid,signal.SIGKILL)
   row['original_returncode']=child.wait(timeout=5)
  raise
 finally:
  # Persist raw bytes and original wait before interpreting rc or warning text.
  # Also retain a per-command receipt if an exception interrupts normal flow.
  for name in ['stdout','stderr']:
   f=Path(str(stem)+'.'+name)
   if f.exists():
    row[name+'_bytes']=f.stat().st_size;row[name+'_sha256']=sha(f)
    row[name]=f.read_bytes()[:2*1024**2].decode(errors='replace')
    if f.stat().st_size>2*1024**2:row['output_guard']=True
  Path(str(stem)+'.json').write_text(json.dumps(row,indent=2)+'\n');write_result()
 assert not row['timed_out'] and not row.get('output_guard') and row['original_returncode']==0,args
 return row
try:
 binding=json.loads((ROOT/'binding.json').read_text())
 for rel,expected in binding['members'].items():
  p=Path('/')/rel;assert p.is_file() and sha(p)==expected['sha256'] and stat.filemode(p.stat().st_mode)==expected['mode'],rel
  rows[rel]={'sha256':sha(p),'realpath':str(p.resolve()),'mode':oct(p.stat().st_mode&0o777)}
 for target in ['/usr/bin/emulationstation','/usr/bin/cloud_oauth','/usr/bin/cloud-signin-window','/usr/bin/rclone','/usr/bin/wifictl','/usr/lib/gstreamer-1.0/gst-plugin-scanner','/usr/lib/libgstcontroller-1.0.so.0','/usr/lib/libgstnet-1.0.so.0']:
  assert not any(line.split()[4]==target for line in Path('/proc/self/mountinfo').read_text().splitlines()),'pre-existing bind: '+target
 for lang in ['fr','en_GB']:
  rel='usr/config/locale/'+lang+'/LC_MESSAGES/emulationstation2.mo'
  assert sha(Path('/storage/.config/locale')/lang/'LC_MESSAGES/emulationstation2.mo')==binding['members'][rel]['sha256'],'active catalog mismatch'
 # Same original installed dependency calls; libgstnet is additionally byte-bound
 # above because the new product fix retains it. No fabricated library hash.
 for lib in ['libgstcontroller-1.0.so.0','libgstreamer-1.0.so.0','/usr/lib/gstreamer-1.0/libgstopengl.so']:ctypes.CDLL(lib,mode=os.RTLD_NOW)
 for target in ['/usr/bin/cloud-signin-window','/usr/lib/gstreamer-1.0/gst-plugin-scanner']:
  row=command(['ldd',target],15);assert 'not found' not in row['stdout']+row['stderr'],target
 registry=ROOT/'gst-registry.bin';assert not registry.exists()
 env=dict(os.environ,GST_REGISTRY=str(registry))
 for key in ['GST_PLUGIN_SCANNER','GST_PLUGIN_PATH','GST_PLUGIN_SYSTEM_PATH','GST_REGISTRY_FORK']:env.pop(key,None)
 row=command(['/usr/bin/gst-inspect-1.0','opengl'],30,env)
 assert registry.is_file()
 assert 'Failed to load plugin' not in row['stderr'] and 'External plugin loader failed' not in row['stderr']
 result.update(status='PASS',scanner_scope='installed executable/default registry and ldd closure; no separate scanner child-exec trace claimed')
except BaseException as error:result['error']=type(error).__name__+': '+str(error);traceback.print_exc()
finally:
 registry=ROOT/'gst-registry.bin'
 if registry.is_file():result['registry']={'bytes':registry.stat().st_size,'sha256':sha(registry)}
 result['ended']=time.time();write_result()
raise SystemExit(0 if result['status']=='PASS' else 1)

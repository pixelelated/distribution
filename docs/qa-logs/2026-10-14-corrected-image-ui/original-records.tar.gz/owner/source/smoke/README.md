# Corrected installed UI smoke source — UNRUN

Derivative of original c46457c66881e965ba4d5c078a9082aa341fba4dac7679c60665de391e9b1b35.
The original source/seal at /tmp/pix-m7-installed-ui-smoke-20261014 is untouched.
`original-SHA256SUMS` preserves its membership; this directory has its own seal.

Use the parent revision04 README and outer lifecycle for execution. Inner
prepare now requires --expected-source and --expected-es, passed from the
completed verified image and matching frozen package pin. The next verifier
must include actual libgstnet final bytes/mode/link chain. No hardcoded future
hash or old image identity is accepted.

Only prepare.py, guest-preflight.py and run.py change: dynamic exact-image
binding, added libgstnet identity, original loader command evidence before
assertions and failure-safe host export. Browser/phone/Wi-Fi/Recent cases,
accepted seams, original timers and cleanup/restoration are unchanged. Existing
applicability/catalog/dependency records here describe the inherited accepted
source evidence, not a completed new-image execution. All runtime is UNRUN.

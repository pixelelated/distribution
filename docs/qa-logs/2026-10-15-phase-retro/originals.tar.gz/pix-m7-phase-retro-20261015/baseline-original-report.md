# vm-qa on fac608ff89

started 2026-10-14 23:20 UTC, guest a at :10022, cloud webdav (port 9010, hash=none modtime=no commit=partial bucket=no), image /workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02/target/pixelelated-GENERIC_X64.x86_64-0.0.1-dev+20261014T230300Z.gfac608ff8994-from-ROCKNIX.img.gz, display: GL through virgl on /dev/dri/renderD128

| suite | result | time | log |
| --- | --- | --- | --- |
| scripts | FAIL (1) | 560s | `scripts.log` |
| lifetime | PASS | 1s | `lifetime.log` |
| wrapper | PASS | 0s | `wrapper.log` |
| vocabulary | PASS | 0s | `vocabulary.log` |
| french | PASS | 0s | `french.log` |
| quoting | PASS | 0s | `quoting.log` |
| menumap | PASS | 1s | `menumap.log` |
| register | PASS | 1s | `register.log` |
| pair-identity | PASS | 1s | `pair-identity.log` |
| fresh | PASS | 1s | `fresh.log` |
| round-trip | PASS | 87s | `round-trip.log` |
| exit | PASS | 27s | `exit.log` |
| time-to-play | PASS | 71s | `time-to-play.log` |
| walks | PASS | 1023s | `walks.log` |
| frame-diff | FAIL (1) | 8s | `frame-diff.log` |

**FAILED** -- 2 suite(s) failed; see the logs beside this file.

finished 2026-10-14 23:50 UTC

## time to play -- fac608ff89 on webdav

2026-10-14 23:32 UTC, guest at :10022, cloud `webdav`, payload `full`, 1 repeat(s).

Host state: **vm-qa on serval, guest a**. SSH round trip 5 ms (the launch POST goes over it); one screendump 64 ms, which is the resolution of every frame-derived number below.

Seconds, as median / mean / max.

### UI to game, at rest

| from the press to | median / mean / max | n |
| --- | --- | --- |
| the screen leaving the carousel | 0.09 / 0.09 / 0.09 | 1 |
| the handover (a black screen) | 0.09 / 0.09 / 0.09 | 1 |
| RetroArch existing | 0.55 / 0.55 / 0.55 | 1 |
| **the game's first frame** | **0.69 / 0.69 / 0.69** | 1 |
| RetroArch drawing (200 CPU ticks, or 30 four seconds on) | 4.60 / 4.60 / 4.60 | 1 |

### The exit sync, on its own

| from execute_kill to | median / mean / max | n |
| --- | --- | --- |
| the emulator gone | 0.16 / 0.16 / 0.16 | 1 |
| **the last-sync-exit stamp** | **1.47 / 1.47 / 1.47** | 1 |
| the card gone from the screen | 3.52 / 3.52 / 3.52 | 1 |

Outcomes: completed x1. Payload seeded 616 KiB (RetroArch rewrites the auto-state on exit, so what moves is a little less; the log's rclone line has the bytes).

### Game to game, with the exit sync in flight

| from execute_kill to | median / mean / max | n |
| --- | --- | --- |
| the emulator gone | 0.15 / 0.15 / 0.15 | 1 |
| the relaunch sent | 0.16 / 0.16 / 0.16 | 1 |
| the question answered (STOP IT AND PLAY, D-CLOUD-130) | 1.37 / 1.37 / 1.37 | 1 |
| **the next game's first frame** | **1.01 / 1.01 / 1.01** | 1 |
| the exit sync's stamp | - | 1 |

What the launch did to the sync, from the stamp's token: `?` x1.


renderer: virgl (Mesa Intel(R) Graphics (ARL)). -- the guest's Mesa, from the launch log; display: GL through virgl on /dev/dri/renderD128

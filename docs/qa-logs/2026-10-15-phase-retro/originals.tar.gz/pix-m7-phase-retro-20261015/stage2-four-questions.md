# Initial four-question draft — before scoped checks

## What worked well?

The audit kept the frozen 115-criterion score separate from later remediation. Independent source review and blind/refutation review found six bounded defects; installed fresh/retained and native-state originals then qualified the fixes. Original failed attempts remained available. The build reporting collision was recovered without fabricating launcher success or rebuilding completed packages.

## What was harder than expected?

The work repeatedly reached a different fixture precondition or UI branch than intended: optional proc interfaces, a conditional network row, a protected config mount, serialized Off settings, and package substitutions. Outer success, a dialog exit code, or a scene label alone was insufficient. Submission success was also confused with ownership of a producer's completion receipt, causing the #597 launcher collision.

## What did we discover?

The highest-value proofs cross ownership boundaries: ES page versus application lifetime, helper versus actual launcher, native automatic state versus global frontend setting, and command completion versus launcher reporting. A precise old-negative/corrected-positive continuation can resolve the missing fact while preserving earlier acceptance and the historical failure.

## What adjustments are needed?

Carry exact source/tool/installed transformations and existing negative controls into #555. Preserve the nonqualifying build reporting failure and separately qualified artifact reader. Keep hardware, ARM-specific behavior, publication and release-candidate gates in #555/#344/#528. Use existing fixed tooling and rules; add no new rule unless the scoped checks expose a remaining gap. Prepare tracker propagation for root; do not post it or claim milestone completion.

# Root-only commands after review — unrun

Do not run while another allocated host/VM/build operation is active. The
source packet is immutable; both proposed owners must be fresh. Root first
records the bounded host-source rationale in#528 and confirms the80MiB storage
envelope. This is the established non-compiling record-only route; it does not
claim an admission receipt or reuse a build admission.

```bash
TASK_PACKET=/tmp/pix-m7-fex-full-notices-plan-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-03
TASK_OWNER=/workspace/tmp/pix-m7-fex-full-notices-20261015-01
TASK_LAUNCHER=/workspace/tmp/pix-m7-fex-full-notices-launcher-20261015-01
mkdir -m 700 "$TASK_LAUNCHER"
cd "$TASK_TREE"
tools/watch-build-submit --owner "$TASK_LAUNCHER" -- \
  --record-only --activity-dir "$TASK_LAUNCHER" -- \
  taskset -c 0,1 prlimit --as=1073741824 --fsize=8388608 -- \
  timeout --signal=TERM --kill-after=15s 300s \
  /usr/bin/python3 -I -S -B "$TASK_PACKET/collect.py" --owner "$TASK_OWNER"
```

The collector creates its own owner; do not precreate it. Root supervises at
intervals no longer than60s using the original launcher paths. Submission
success is not collection success. Preserve original launcher/tool-wrapper,
command, monitor and runner exits, elapsed time and any termination outcome.
After the launcher is complete, read the exact generated `result.json` and
`notice-members.json`, verify the packet/inputs/destination hashes and original
watcher channels. No second reader run is needed to improve paperwork.

Success is `COLLECTED_FOR_REVIEW`, original collector0, outer0 and all original
watcher/launcher channels0. Missing candidate/required texts remain explicit in
`gaps`; they cannot be turned into a completeness or publication claim. A failure
retains the partial owner and original receipt for ordinary investigation.
There is no automatic retry, fallback input, network step or cap widening.

# FEX full-notice materialization — source only, unrun

This prepares one bounded, offline data-reader operation. No archive payload,
source cache, Nix tree, target program, collector or guest was read or executed
during preparation. Root reviews and allocates the command in `commands.md`.
The output is a reviewable notice packet, not a licence-compatibility decision.

The inputs are **12 exact already-held archives, 272,972,622 compressed bytes**,
and **21 exact retained notice/header contexts, 889,216 bytes**. Eight archives
come from the accepted source-assembly supplement; ALSA, libxcb, libXrender and
libglvnd reuse historical release-source custody. All flat hashes and byte
lengths are in `collection-plan.json`. No completed acquisition is repeated.
Libglvnd's accepted recursive NAR identity remains separate from its archive's
flat hash; this operation does not recompute that settled equivalence.

The existing main FEX MIT, Vulkan licence map/Apache/MIT, Khronos GL header,
FEX CUDA header/interface and Nixpkgs COPYING are reused from retained copies.
The thirteen development-header contexts come from the completed 39-file source
supplement, not their former Nix-store paths. Their full original notices remain
intact; they are not replaced with generic licence labels. Eight main contexts
plus thirteen selected headers account for the21 named files above.

| Exact source | Bounded notice discovery/retention |
| --- | --- |
| GCC14.3.0 | Root notices and immediate libstdc++-v3 notices; require observed COPYING3 and COPYING.RUNTIME among retained text. The preserved functional header also retains its Silicon Graphics notice. No other compiler language/runtime closure is collected. |
| glibc2.40 | Root full texts, including candidate COPYING.LIB and LICENSES. The selected2.40-224 patch series is already held separately; nativeglibc2.41 is not substituted. |
| ALSA1.2.14 | Root full texts, including candidate COPYING; the two selected Nix patches are already held. |
| Linux6.16.7 UAPI | Root notices and exactly the candidate LICENSES/preferred/GPL-2.0 and LICENSES/exceptions/Linux-syscall-note. This is header attribution, not a second shipped kernel. |
| libdrm2.4.129, libglvnd1.7.0 | Root notice files and bounded root LICENSES text; retain the existing complete DRM/GLX header notices alongside them. |
| Wayland1.24.0 | Root notices plus candidate protocol/wayland.xml, which can retain the protocol's complete embedded notice without running a generator. |
| libX11.8.12, libXrandr1.5.4, libXrender0.9.12, xorgproto2024.1 | Root notice files, including compound COPYING names, and bounded root LICENSES text. Complete selected headers retain original supporting-documentation/name-use clauses. |
| libxcb1.17.0 | Root notices plus candidate src/xcb.h and src/xproto.h; absence of a generated protocol candidate is an explicit discovery gap, not an invented source path or an automatic download. |

**Inner archive member names are not yet verified.** The names above are explicit
discovery candidates. The reader strips the one root it actually observes,
walks only each named archive's metadata stream, and retains selected regular
text members. It records the exact observed root, original member name, byte
length, flat SHA256, mode, uid/gid and mtime. It records missing candidate names,
required basenames, and selected links/special members as gaps. It never follows
an archive link. A completed discovery exits0 with `COLLECTED_FOR_REVIEW` even
when explicit gaps require a subsequent root decision; it never claims all
licence texts complete. Hash mismatch, unsafe name, duplicate member, exceeded
bound or decoder error exits1 and keeps original partial output.

`collect.py` is a small derivative of the accepted prebuilt source notice
reader, retained verbatim as `reused-reader.py` for comparison. It reuses bounded
streaming tar iteration, canonical member names, regular nonsparse selected
members, content-addressed notice retention, exact original metadata, complete
decoder drain and before/after input hashes. Changes are named held inputs,
xz/bzip2 support, focused notice selectors, explicit missing-member reporting
and finite limits for the two larger upstream archives. There is no download,
source execution, extraction into a source tree, child process or new supervisor.
The existing frozen watch-build-submit/watch-build/watch-job lifecycle records
the original command/monitor/runner outcomes. Root alone supervises and reviews.

The collector writes only its fresh `/workspace/tmp/pix-m7-fex-full-notices-20261015-01`
owner: `plan.json`, content-addressed `texts/*.txt`, `notice-members.json` and the
original `result.json`. Reused texts are copied and hashed as exact data; every
destination text is independently reread before success. The collector compares
each source archive's complete flat hash and file identity before and after
streaming it. All nine source/notice custody metadata receipts are hash-bound.
Original cache locations in older metadata are provenance only, never inputs.

Bounds are fixed: two CPUs,1GiB address space,280s soft deadline,300s outer
timeout and15s forced-stop allowance. No automatic retry or widened budget is
allowed. Physical file reads have a2GiB aggregate cap, comfortably above two
full archive hash passes, one compressed decode pass, context copies and output
rereads. Decoded tar is capped at3GiB for Linux,2GiB for GCC,256MiB for the other
archives except64MiB for libglvnd, and6GiB combined. These are conservative
finite caps, not claims about unmeasured decoded sizes. Decoding is streamed;
these bytes are never written as an unpacked tree or held as a full buffer.

At most300,000 entries per archive/500,000 overall are inspected; member names
are at most1,024 bytes/depth64 and32MiB aggregate per archive. At most256 selected
rows,2MiB per text and32MiB unique retained text are allowed. The exact context
set consumes only889,216 bytes; the remaining allowance covers licence files
and selected protocol context without broad source-tree extraction. Metadata
files are at most8MiB; writes stop before the48MiB normal owner ceiling, leaving
16MiB of the64MiB hard owner limit reserved. The original result/failure receipt
is at most1MiB and remains writable after a time/read refusal. The owner has only
two directories and at most384 files. The existing launcher's separate small
originals retain a16MiB margin in the proposed80MiB combined storage envelope;
the collector prints only one small result row. No host disk/process scan occurs
inside this reader.

Can this be done on the VM? This is host custody of exact existing source
archives, with no target behaviour or physical fact. Use the established
record-only watcher route after root records this rationale under#528. The
packet has no build entrypoint or compilation. Preparation has only parsed its
source and checked named metadata; no guard/test or data-reader run is claimed.

After the run, root checks every original exit and cleanup result, then reviews
the discovered full texts and explicit gaps. The member index is the bounded
integration seam for the existing source/notice deliverable. Generated output
coverage and final native-image mappings remain bound to their accepted input
maps; no full preprocessing trace, whole81-row Nix closure or guessed guest-rootfs
provider acquisition is added. Nixpkgs NAR and all22 patches are already retained.
Settled shader terms are unchanged. ABL/MAME responses, final-image mapping,
public retrieval, offhost custody and release clearance remain separate.

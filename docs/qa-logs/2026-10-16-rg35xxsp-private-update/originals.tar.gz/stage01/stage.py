#!/usr/bin/env python3
"""Issue #344: exact authorized H700 transfer via a loopback-only SSH tunnel."""
from pathlib import Path
import datetime, hashlib, http.server, json, os, re, shutil, subprocess, threading, time
OWNER = Path('/tmp/pix-m7-h700-rg35xxsp-deploy-20261016-01/stage01')
TREE = Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
BUNDLE = Path('/workspace/artifacts/pixelelated-candidates/sha256/a808df3dbffc6281b0bf698fbbbd97a526f16211d1195bcf13ebd5fccb7e3e5f')
NAME = 'pixelelated-H700.aarch64-0.0.1-dev+20261015T161744Z.g077197e6cd3e-from-ROCKNIX.tar'
SHA = 'e68f5c21b38b298e307fa1f00f87762a9aaeb2348aa91a9d43d940ce11da35dd'
ARTIFACT = BUNDLE / NAME
REMOTE = '/storage/.cache/' + NAME + '.m7-344-20261016.part'
QUEUE = '/storage/.update/' + NAME
SSH=['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', '-o', 'Hostname=100.74.205.40', '-o', 'HostKeyAlias=192.168.1.81', '-o', 'StrictHostKeyChecking=yes', '-o', 'UserKnownHostsFile=/home/max/.ssh/known_hosts', '-o', 'HostKeyAlgorithms=ssh-ed25519', 'rg35xxsp']
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def record(name, value):
    with (OWNER / name).open('x') as f: json.dump(value, f, indent=2); f.write('\n')
def filtered(data): return '\n'.join(s for s in data.splitlines() if not re.search('key|pass|token|user|psk',s,re.I))+'\n'
def readback(name, command):
    r=subprocess.run(SSH+[command],capture_output=True,text=True,timeout=40)
    (OWNER/name).write_text(filtered(r.stdout+r.stderr))
    if r.returncode: raise RuntimeError('readback failed: '+name)
    return r.stdout
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_GET(self):
        if self.path != '/firmware.tar': self.send_error(404); return
        self.send_response(200);self.send_header('Content-Length',str(ARTIFACT.stat().st_size));self.end_headers()
        total=0;last=time.monotonic()
        with ARTIFACT.open('rb') as src:
            while block:=src.read(1024*1024):
                self.wfile.write(block);total+=len(block)
                if time.monotonic()-last>=30:
                    print(now(),'transfer_bytes',total,'/',ARTIFACT.stat().st_size,flush=True);last=time.monotonic()
        print(now(),'transfer_stream_complete',total,flush=True)
server=None;rc=1
try:
    (OWNER/'run.path').write_text(str(TREE/os.environ['RASTERATOPS_BUILD_RUN'])+'\n')
    record('start.json',{'utc':now(),'pid':os.getpid(),'issue':344,'scope':'authorized transfer and checksum-gated queue only'})
    with ARTIFACT.open('rb') as f: actual=hashlib.file_digest(f,'sha256').hexdigest()
    assert actual==SHA and ARTIFACT.stat().st_size==1321697280
    acceptance=json.loads(Path('/workspace/tmp/pix-m7-zerotier-h700-readback-20261015-01/artifacts/acceptance.json').read_text())
    assert acceptance['result']=='PASS' and acceptance['bundle']==str(BUNDLE)
    pre=readback('preflight.txt', '''set -e
printf 'boot_id='; cat /proc/sys/kernel/random/boot_id
cat /etc/os-release
printf 'model='; tr '\\000' '\\n' </proc/device-tree/model
printf 'dt_id='; tr '\\000' '\\n' </proc/device-tree/rocknix-dt-id
for p in /sys/class/regulator/*; do if [ "$(cat "$p/name" 2>/dev/null)" = vdd-dram ]; then printf 'dram_microvolts='; cat "$p/microvolts"; fi; done
printf 'battery_capacity='; cat /sys/class/power_supply/battery/capacity
printf 'battery_status='; cat /sys/class/power_supply/battery/status
printf 'external_power='; cat /sys/class/power_supply/axp20x-usb/online
df -k /storage /flash
mount | grep -E ' on /storage | on /flash | on /storage/roms '
ls -la /storage/.update
ps -eo pid,comm | grep -E 'retroarch|rclone|cloud|scrape|emulation' || true
''')
    assert 'Anbernic RG35XX SP' in pre and 'dram_microvolts=1100000' in pre and 'external_power=1' in pre
    assert 'BUILD_ID="bc9dfe8141d9561dc1d8502313d00a84c4566ee8"' in pre
    record('input.json',{'utc':now(),'artifact':str(ARTIFACT),'sha256':SHA,'bytes':ARTIFACT.stat().st_size,'remote_partial':REMOTE,'remote_queue':QUEUE,'expected_build_id':acceptance['distribution_commit']})
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    port=server.server_address[1];threading.Thread(target=server.serve_forever,daemon=True).start()
    env=dict(os.environ,DEVICE_ACTIONS_LOG=str(OWNER/'device-actions.log'),DEVICE_ACT_TIMEOUT='2400',DEVICE_ACT_SSH_OPTS=f'-o Hostname=100.74.205.40 -o HostKeyAlias=192.168.1.81 -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/home/max/.ssh/known_hosts -o HostKeyAlgorithms=ssh-ed25519 -o ExitOnForwardFailure=yes -R 127.0.0.1:{port}:127.0.0.1:{port}')
    guard_command='python3 -B -I -c \'import base64,hashlib,json\nn={\'"\'"\'__name__\'"\'"\':\'"\'"\'read344\'"\'"\'}\nexec(base64.b64decode(\'"\'"\'IyEvdXNyL2Jpbi9lbnYgcHl0aG9uMwoiIiJSZWFkLW9ubHkgYmluZGluZyBjb2xsZWN0b3IgZm9yIHRoZSBvbmUtdGltZSAjNTE5IG93bmVyIG9wZXJhdGlvbi4KCk5ldmVyIHByaW50cyBjb25maWd1cmF0aW9uIHZhbHVlcyBvciBwYXlsb2FkIGJ5dGVzLiBJdHMgY29tcGxldGUgSlNPTiBzdGlsbApjb250YWlucyBwZXJzb25hbCBwYXRocyBhbmQgbXVzdCBiZSByZXRhaW5lZCBwcml2YXRlbHksIG5vdCBjb21taXR0ZWQuCiIiIgppbXBvcnQgaGFzaGxpYixqc29uLG9zLHBhdGhsaWIsc3RhdCxzdWJwcm9jZXNzLHRpbWUKUD1wYXRobGliLlBhdGgKRklMRVM9WwogJy9ldGMvb3MtcmVsZWFzZScsJy91c3IvYmluL2VtdWxhdGlvbnN0YXRpb24nLCcvdXNyL2Jpbi9jbG91ZF9taWdyYXRlX2xheW91dCcsCiAnL3Vzci9iaW4vY2xvdWRfc2NhbicsJy91c3IvYmluL2Nsb3VkX3N5bmNfaGVscGVyJywnL3Vzci9iaW4vY2hrc3lzY29uZmlnJywKICcvdXNyL2Jpbi9zdGFydF9lcy5zaCcsJy9ldGMvcHJvZmlsZS5kLzAwMS1mdW5jdGlvbnMnLAogJy91c3IvbGliL3N5c3RlbWQvc3lzdGVtL2VtdXN0YXRpb24uc2VydmljZScsJy91c3IvbGliL3N5c3RlbWQvc3lzdGVtL2Vzc3dheS5zZXJ2aWNlJywKICcvdXNyL2xpYi9hdXRvc3RhcnQvY29tbW9uLzAwMS1zZXR1cCcsJy91c3IvbGliL2F1dG9zdGFydC9jb21tb24vMTExLXN3YXktaW5pdCcsCiAnL3N0b3JhZ2UvLmNvbmZpZy9jbG91ZF9zeW5jLmNvbmYnLCcvc3RvcmFnZS8uY29uZmlnL2Nsb3VkX3N5bmMuY29uZi5iYWsnLAogJy9zdG9yYWdlLy5jb25maWcvY2xvdWRfc3luYy5jb25mLmRlZmF1bHRzJywnL3N0b3JhZ2UvLmNvbmZpZy9jbG91ZF9zeW5jLmNvbmYucHJlLWNvbnRlbnRwYXRoLWZpeCcsCiAnL3N0b3JhZ2UvLmNvbmZpZy9jbG91ZF9zeW5jLXJ1bGVzLnR4dCcsJy9zdG9yYWdlLy5jb25maWcvcmNsb25lL3JjbG9uZS5jb25mJywKICcvc3RvcmFnZS8uY29uZmlnL3N5c3RlbS9jb25maWdzL3N5c3RlbS5jZmcnLCcvc3RvcmFnZS8uY29uZmlnL3N5c3RlbS9jb25maWdzL3N5c3RlbS5jZmcuYmFja3VwJywKICcvc3RvcmFnZS8uY29uZmlnL2Nsb3VkLWxheW91dC1taWdyYXRpb24uanNvbiddCk1BUktFUlM9Wycvc3RvcmFnZS8uY29uZmlnLy5yZXN0b3JlLWluLXByb2dyZXNzJywnL3N0b3JhZ2UvLmNvbmZpZy8ucmVzdG9yZS1yZXZlcnRlZCcsCiAnL3N0b3JhZ2UvLmNvbmZpZy8ucmVzdG9yZS1maW5pc2gtcGVuZGluZycsJy9zdG9yYWdlLy5jb25maWcvLmNsb3VkLWpvdXJuZXktcGVuZGluZycsCiAnL3N0b3JhZ2UvLmNhY2hlL2Nsb3VkX3N5bmMvam91cm5leS10aWVycycsJy90bXAvLnN5c3RlbS5jZmcubG9jayddCkhPT0tTPVsnL3N0b3JhZ2UvLmNvbmZpZy9hdXRvc3RhcnQnLCcvc3RvcmFnZS8uY29uZmlnL2VtdWxhdGlvbnN0YXRpb24vc2NyaXB0cycsCiAnL3Vzci9iaW4vc2NyaXB0cycsJy92YXIvcnVuL2VtdWxhdGlvbnN0YXRpb24vc2NyaXB0cyddCgpkZWYgZGlnZXN0KHApOgogaD1oYXNobGliLnNoYTI1NigpCiB3aXRoIHAub3BlbigncmInKSBhcyBmOgogIGZvciBiIGluIGl0ZXIobGFtYmRhOmYucmVhZCgxMDI0KjEwMjQpLGInJyk6aC51cGRhdGUoYikKIHJldHVybiBoLmhleGRpZ2VzdCgpCmRlZiBtZXRhZGF0YShwKToKIGlmIHAuaXNfc3ltbGluaygpOnJldHVybiB7J2tpbmQnOidzeW1saW5rJywndGFyZ2V0Jzpvcy5yZWFkbGluayhwKX0KIGlmIG5vdCBwLmV4aXN0cygpOnJldHVybiB7J2tpbmQnOidhYnNlbnQnfQogcz1wLnN0YXQoKTtyPXsnbW9kZSc6c3RhdC5TX0lNT0RFKHMuc3RfbW9kZSksJ3VpZCc6cy5zdF91aWQsJ2dpZCc6cy5zdF9naWR9CiBpZiBwLmlzX2ZpbGUoKTpyLnVwZGF0ZShraW5kPSdmaWxlJyxieXRlcz1zLnN0X3NpemUsc2hhMjU2PWRpZ2VzdChwKSkKIGVsaWYgcC5pc19kaXIoKTpyLnVwZGF0ZShraW5kPSdkaXJlY3RvcnknKQogZWxzZTpyLnVwZGF0ZShraW5kPSdvdGhlcicpCiByZXR1cm4gcgpkZWYgdHJlZShwLGxpbWl0PTEyOCoxMDI0KjEwMjQsYWxsb3dfc3ltbGlua3M9RmFsc2UpOgogaWYgbm90IHAuZXhpc3RzKCk6cmV0dXJuIHsncm9vdCc6bWV0YWRhdGEocCksJ2VudHJpZXMnOnt9fQogYXNzZXJ0IHAuaXNfZGlyKCkgYW5kIG5vdCBwLmlzX3N5bWxpbmsoKSxzdHIocCkKIGVudHJpZXM9e307c2l6ZT0wCiBmb3IgZiBpbiBzb3J0ZWQocC5yZ2xvYignKicpKToKICBhc3NlcnQgbGVuKGVudHJpZXMpPDIwMDAwLCdlbnVtZXJhdGlvbiBib3VuZCcKICBhc3NlcnQgYWxsb3dfc3ltbGlua3Mgb3Igbm90IGYuaXNfc3ltbGluaygpLCd1bmNsYXNzaWZpZWQgc3ltbGluayAnK3N0cihmKQogIGlmIGYuaXNfZmlsZSgpIGFuZCBub3QgZi5pc19zeW1saW5rKCk6c2l6ZSs9Zi5zdGF0KCkuc3Rfc2l6ZQogIGFzc2VydCBzaXplPD1saW1pdCwnYnl0ZSBib3VuZCcKICBlbnRyaWVzW3N0cihmLnJlbGF0aXZlX3RvKHApKV09bWV0YWRhdGEoZikKIHJldHVybiB7J3Jvb3QnOm1ldGFkYXRhKHApLCdlbnRyaWVzJzplbnRyaWVzfQpkZWYgcnVuKGEpOnJldHVybiBzdWJwcm9jZXNzLmNoZWNrX291dHB1dChhLHRleHQ9VHJ1ZSxzdGRlcnI9c3VicHJvY2Vzcy5QSVBFLHRpbWVvdXQ9MjUpCmRlZiBzZXR0aW5ncygpOgogdGV4dD1QKCcvc3RvcmFnZS8uY29uZmlnL3N5c3RlbS9jb25maWdzL3N5c3RlbS5jZmcnKS5yZWFkX3RleHQoKTthc3NlcnQgdGV4dC5lbmRzd2l0aCgnXG4nKQogcGFpcnM9W2wuc3BsaXQoJz0nLDEpIGZvciBsIGluIHRleHQuc3BsaXRsaW5lcygpIGlmICc9JyBpbiBsIGFuZCBub3QgbC5sc3RyaXAoKS5zdGFydHN3aXRoKCcjJyldCiBhdXRvPXtrOlt2IGZvciBhLHYgaW4gcGFpcnMgaWYgYT09a10gZm9yIGsgaW4gWydjbG91ZHNhdmVzLnN0YXJ0dXAnLCdjbG91ZHNhdmVzLmdhbWVleGl0J119CiBib290Z2FtZT1hbnkoYm9vbCh2KSBmb3Igayx2IGluIHBhaXJzIGlmIGsgaW4gWydnbG9iYWwuYm9vdGdhbWUucGF0aCcsJ2dsb2JhbC5ib290Z2FtZS5jbWQnXSkKIHJldHVybiB7J2F1dG9tYXRpY19zeW5jJzphdXRvLCdzdGFydHVwX2dhbWVfY29uZmlndXJlZCc6Ym9vdGdhbWV9CmRlZiBjb2xsZWN0KGZyb250ZW5kPVRydWUpOgogYXNzZXJ0IG9zLmdldGV1aWQoKT09MAogc3RhcnQ9dGltZS5tb25vdG9uaWMoKTtiZWZvcmU9UCgnL3Byb2Mvc3lzL2tlcm5lbC9yYW5kb20vYm9vdF9pZCcpLnJlYWRfdGV4dCgpLnN0cmlwKCkKIGZpbGVzPXtmOm1ldGFkYXRhKFAoZikpIGZvciBmIGluIEZJTEVTfQogIyBGb3JjZSBsb2NhbC1vbmx5IGVudW1lcmF0aW9uLCBpbmRlcGVuZGVudCBvZiBwZXJzb25hbCByZW1vdGUgY3JlZGVudGlhbHMuCiBlbnRyaWVzPWpzb24ubG9hZHMocnVuKFsnL3Vzci9iaW4vcmNsb25lJywnbHNqc29uJywnL3N0b3JhZ2Uvcm9tcycsJy0tcmVjdXJzaXZlJywnLS1maWxlcy1vbmx5JywnLS1maWx0ZXItZnJvbScsJy9zdG9yYWdlLy5jb25maWcvY2xvdWRfc3luYy1ydWxlcy50eHQnLCctLWNvbmZpZycsJy9kZXYvbnVsbCddKSkKIGFzc2VydCBsZW4oZW50cmllcyk8PTIwMDAwIGFuZCBzdW0oeFsnU2l6ZSddIGZvciB4IGluIGVudHJpZXMpPD0xMjgqMTAyNCoxMDI0CiBwYXlsb2FkPXt9CiBmb3IgZSBpbiBzb3J0ZWQoZW50cmllcyxrZXk9bGFtYmRhIGU6ZVsnUGF0aCddKToKICByZWw9UChlWydQYXRoJ10pO2Fzc2VydCBub3QgcmVsLmlzX2Fic29sdXRlKCkgYW5kICcuLicgbm90IGluIHJlbC5wYXJ0cwogIHA9UCgnL3N0b3JhZ2Uvcm9tcycpL3JlbDthc3NlcnQgcC5pc19maWxlKCkgYW5kIG5vdCBwLmlzX3N5bWxpbmsoKQogIHBheWxvYWRbZVsnUGF0aCddXT1tZXRhZGF0YShwKQogaG9va3M9e3A6dHJlZShQKHApLDgqMTAyNCoxMDI0KSBmb3IgcCBpbiBIT09LU30KIHVuaXRzPXt9CiBmb3IgdSBpbiBbJ2VtdXN0YXRpb24uc2VydmljZScsJ2Vzc3dheS5zZXJ2aWNlJ106CiAgdGV4dD1ydW4oWydzeXN0ZW1jdGwnLCdzaG93Jyx1LCctcCcsJ0FjdGl2ZVN0YXRlJywnLXAnLCdTdWJTdGF0ZScsJy1wJywnTWFpblBJRCcsJy1wJywnVW5pdEZpbGVTdGF0ZScsJy1wJywnS2lsbE1vZGUnLCctcCcsJ1Jlc3RhcnQnLCctcCcsJ0ZyYWdtZW50UGF0aCcsJy1wJywnRHJvcEluUGF0aHMnXSkKICB1bml0c1t1XT1kaWN0KGwuc3BsaXQoJz0nLDEpIGZvciBsIGluIHRleHQuc3BsaXRsaW5lcygpIGlmICc9JyBpbiBsKQogYnVzeT1bXQogZm9yIHAgaW4gUCgnL3Byb2MnKS5nbG9iKCdbMC05XSonKToKICB0cnk6CiAgIGNvbW09KHAvJ2NvbW0nKS5yZWFkX3RleHQoKS5zdHJpcCgpO2NtZD0ocC8nY21kbGluZScpLnJlYWRfYnl0ZXMoKS5yZXBsYWNlKGInXDAnLGInICcpLmRlY29kZShlcnJvcnM9J3JlcGxhY2UnKQogICBpZiBpbnQocC5uYW1lKT09b3MuZ2V0cGlkKCk6Y29udGludWUKICAgaWYgY29tbT09J3JjbG9uZScgb3IgYW55KHQgaW4gY21kIGZvciB0IGluIFsnL3Vzci9iaW4vY2xvdWRfYmFja3VwJywnL3Vzci9iaW4vY2xvdWRfcmVzdG9yZScsJy91c3IvYmluL2Nsb3VkX2NhcHR1cmUnLCcvdXNyL2Jpbi9jbG91ZF9zY2FuJywnL3Vzci9iaW4vY2xvdWRfbWlncmF0ZV9sYXlvdXQnLCcvdXNyL2Jpbi9jbG91ZF9jb250ZW50XyddKToKICAgIGJ1c3kuYXBwZW5kKHsncGlkJzppbnQocC5uYW1lKSwnY29tbSc6Y29tbSwnYXJndl9zaGEyNTYnOmhhc2hsaWIuc2hhMjU2KGNtZC5lbmNvZGUoKSkuaGV4ZGlnZXN0KCl9KQogIGV4Y2VwdCAoRmlsZU5vdEZvdW5kRXJyb3IsUHJvY2Vzc0xvb2t1cEVycm9yKTpjb250aW51ZQogbWFya2Vycz17cDptZXRhZGF0YShQKHApKSBmb3IgcCBpbiBNQVJLRVJTfQogdGVtcG9yYXJpZXM9e30KIGZvciBwYXJlbnQscHJlZml4ZXMgaW4gWygnL3N0b3JhZ2UvLmNvbmZpZycsWydjbG91ZF9zeW5jLmNvbmYuJywnY2xvdWQtbGF5b3V0LW1pZ3JhdGlvbi4nXSksKCcvc3RvcmFnZS8uY29uZmlnL3N5c3RlbS9jb25maWdzJyxbJ3N5c3RlbS5jZmcuJ10pXToKICBmb3IgcCBpbiBQKHBhcmVudCkuaXRlcmRpcigpOgogICBpZiBhbnkocC5uYW1lLnN0YXJ0c3dpdGgobikgZm9yIG4gaW4gcHJlZml4ZXMpOnRlbXBvcmFyaWVzW3N0cihwKV09bWV0YWRhdGEocCkKIGFzc2VydCBiZWZvcmU9PVAoJy9wcm9jL3N5cy9rZXJuZWwvcmFuZG9tL2Jvb3RfaWQnKS5yZWFkX3RleHQoKS5zdHJpcCgpLCdib290IGNoYW5nZWQnCiBhc3NlcnQgZmlsZXM9PXtmOm1ldGFkYXRhKFAoZikpIGZvciBmIGluIEZJTEVTfSwnY29uZmlndXJhdGlvbi9zb3VyY2UgY2hhbmdlZCBkdXJpbmcgY29sbGVjdGlvbicKIGlkbGU9anNvbi5sb2FkcyhydW4oWydjdXJsJywnLWZzUycsJy0tbWF4LXRpbWUnLCcyJywnaHR0cDovLzEyNy4wLjAuMToxMjM0L2lzSWRsZSddKSkgaWYgZnJvbnRlbmQgZWxzZSBOb25lCiByZXR1cm4geydzY2hlbWEnOjEsJ3JlYWRfb25seSc6VHJ1ZSwnYm9vdF9pZCc6YmVmb3JlLCdmaWxlcyc6ZmlsZXMsJ3NldHRpbmdzJzpzZXR0aW5ncygpLCdzYWZlX3BheWxvYWQnOnBheWxvYWQsJ2xvY2FsX3JlY292ZXJ5Jzp0cmVlKFAoJy9zdG9yYWdlLy5jYWNoZS9jbG91ZF9zeW5jL3JlcGxhY2VkJykpLCdob29rcyc6aG9va3MsJ3VuaXRfb3ZlcnJpZGVzJzp0cmVlKFAoJy9zdG9yYWdlLy5jb25maWcvc3lzdGVtLmQnKSw4KjEwMjQqMTAyNCxUcnVlKSwndW5pdHMnOnVuaXRzLCdidXN5X2Nsb3VkX3Byb2Nlc3Nlcyc6YnVzeSwnZnJvbnRlbmRfaWRsZSc6aWRsZSwnbWFya2Vycyc6bWFya2VycywndGVtcG9yYXJpZXMnOnRlbXBvcmFyaWVzLCdzY2FuJzp0cmVlKFAoJy9zdG9yYWdlLy5jYWNoZS9jbG91ZF9zeW5jL3NjYW4nKSwxMDI0KjEwMjQpLCdlbGFwc2VkX3NlY29uZHMnOnJvdW5kKHRpbWUubW9ub3RvbmljKCktc3RhcnQsMyl9CmlmIF9fbmFtZV9fPT0nX19tYWluX18nOnByaW50KGpzb24uZHVtcHMoY29sbGVjdCgpLGluZGVudD0yKSkK\'"\'"\'),n)\nx=n[\'"\'"\'collect\'"\'"\']()\nv={k:y for k,y in x.items() if k!=\'"\'"\'elapsed_seconds\'"\'"\'}\nassert hashlib.sha256(json.dumps(v,sort_keys=True,separators=(\'"\'"\',\'"\'"\',\'"\'"\':\'"\'"\')).encode()).hexdigest()==\'"\'"\'0dd1c3dfec5d069de93711c2c7f18c34660aad7717d5b3096f66d1c4439d026b\'"\'"\',\'"\'"\'current state drift\'"\'"\'\nprint(\'"\'"\'CURRENT_STATE_STILL_VALID\'"\'"\')\''
    command=f'''set -e
{guard_command}
[ "$(tr -d '\\000' </proc/device-tree/rocknix-dt-id)" = sun50i-h700-anbernic-rg35xx-sp ]
[ "$(cat /sys/class/power_supply/axp20x-usb/online)" = 1 ]
[ "$(cat /sys/class/power_supply/battery/capacity)" -ge 10 ]
[ -z "$(find /storage/.update -mindepth 1 -maxdepth 1 -print -quit)" ]
[ ! -e '{REMOTE}' ]
[ "$(df -Pk /storage | tail -1 | awk '{{print $4}}')" -gt 3000000 ]
if ps -eo comm | grep -E '^(retroarch.*|rclone|cloud_.*|scraper)$'; then echo 'REFUSED active game or cloud process'; exit 20; fi
if [ -e /var/run/cloud_sync.lock ]; then flock -n /var/run/cloud_sync.lock true; fi
curl --fail --silent --show-error --max-time 1800 'http://127.0.0.1:{port}/firmware.tar' --output '{REMOTE}'
printf 'download_bytes='; stat -c %s '{REMOTE}'
actual=$(sha256sum '{REMOTE}' | cut -d ' ' -f1)
printf 'device_sha256=%s\\n' "$actual"
[ "$actual" = '{SHA}' ]
[ "$(cat /sys/class/power_supply/battery/capacity)" -ge 10 ]
[ -z "$(find /storage/.update -mindepth 1 -maxdepth 1 -print -quit)" ]
{guard_command}
mv '{REMOTE}' '{QUEUE}'
sync
printf 'STAGED verified update\\n'
printf 'battery_capacity='; cat /sys/class/power_supply/battery/capacity
printf 'battery_status='; cat /sys/class/power_supply/battery/status
printf 'external_power='; cat /sys/class/power_supply/axp20x-usb/online
'''
    r=subprocess.run([str(TREE/'tools/device-act'),'rg35xxsp','M7 #344 approved transfer and checksum-gated queue H700 077197e6cd3e','--',command],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    record('transfer-command-result.json',{'utc':now(),'returncode':r.returncode})
    output=filtered(r.stdout);(OWNER/'transfer.log').write_text(output);print(output,flush=True)
    assert r.returncode==0 and 'STAGED verified update' in output and 'device_sha256='+SHA in output
    record('stage-result.json',{'utc':now(),'result':'PASS','remote_sha256':SHA,'queue':QUEUE,'rebooted':False})
    rc=0
except Exception as error:
    record('stage-error.json',{'utc':now(),'type':type(error).__name__,'message':str(error)})
    print(type(error).__name__,str(error),flush=True)
finally:
    if server:server.shutdown();server.server_close()
    for name in ['inner.rc','outer.rc']:(OWNER/name).write_text(str(rc)+'\n')
raise SystemExit(rc)

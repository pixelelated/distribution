from pathlib import Path
import json,os,hashlib,xml.etree.ElementTree as ET
P=Path
r={'boot_id':P('/proc/sys/kernel/random/boot_id').read_text().strip(),'os_release':P('/etc/os-release').read_text(),'model':P('/proc/device-tree/model').read_bytes().rstrip(b'\0').decode(),'dt_id':P('/proc/device-tree/rocknix-dt-id').read_bytes().rstrip(b'\0').decode(),'power':{},'dram':[],'storage_free':os.statvfs('/storage').f_bavail*os.statvfs('/storage').f_frsize,'mounts':P('/proc/mounts').read_text(),'update_queue':[x.name for x in P('/storage/.update').iterdir()],'system_configs':[],'configuration':{},'games':[]}
for d in P('/sys/class/power_supply').glob('*'):
 r['power'][d.name]={k:(d/k).read_text().strip() for k in ['status','capacity','online'] if (d/k).exists()}
for d in P('/sys/class/regulator').glob('*'):
 if (d/'name').exists() and (d/'name').read_text().strip()=='vdd-dram':r['dram'].append((d/'microvolts').read_text().strip())
paths=set()
for parent in ['/storage/.config/emulationstation','/usr/bin','/etc/emulationstation']:
 paths.update(P(parent).glob('es_systems*.cfg'))
assert len(paths)<50
for f in sorted(paths):
 if not f.exists():
  r['system_configs'].append({'path':str(f),'kind':'broken-symlink' if f.is_symlink() else 'absent','target':os.readlink(f) if f.is_symlink() else None});continue
 assert f.stat().st_size<2*1024*1024
 b=f.read_bytes();root=ET.fromstring(b);names=[n.findtext('name','') for n in root.findall('system')]
 bad=[n.findtext('name','') for n in root.findall('system') if any(t in ' '.join([n.findtext('name',''),n.findtext('platform',''),n.findtext('fullname','')]).lower() for t in ['gamecube','dolphin','steam','triforce']) or n.findtext('name','').lower() in ['gc','wii','wiiware']]
 r['system_configs'].append({'path':str(f),'resolved':str(f.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'system_count':len(names),'affected_mapping_names':bad,'is_storage_override':str(f).startswith('/storage/')})
for n in ['/storage/.config/system/configs/system.cfg','/storage/.config/system/configs/system.cfg.backup','/storage/.config/cloud_sync.conf','/storage/.config/cloud_sync.conf.defaults','/storage/.config/cloud_sync-rules.txt']:
 f=P(n)
 if f.exists():assert f.stat().st_size<2*1024*1024;r['configuration'][n]=f.read_text()
for p in P('/proc').glob('[0-9]*'):
 try:
  name=(p/'comm').read_text().strip()
  if name.startswith(('retroarch','dolphin','flycast','ppsspp','mupen64','duckstation')):r['games'].append({'pid':int(p.name),'comm':name})
 except (FileNotFoundError,ProcessLookupError):pass
assert r['boot_id']==P('/proc/sys/kernel/random/boot_id').read_text().strip()
print(json.dumps(r))

from pathlib import Path
import datetime,hashlib,json,subprocess
P=Path(__file__).resolve().parent
ssh=['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=8','-o','Hostname=100.74.205.40','-o','HostKeyAlias=192.168.1.81','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile=/home/max/.ssh/known_hosts','-o','HostKeyAlgorithms=ssh-ed25519','rg35xxsp','python3 -B -I -']
assert json.loads((P/'reboot01/acceptance.json').read_text())['result']=='PASS'
code=(P/'inspect.py').read_text();q=subprocess.run(ssh,input=code,capture_output=True,text=True,timeout=120);(P/'binding-after-private.json').write_text(q.stdout);(P/'binding-after.stderr').write_text(q.stderr);(P/'binding-after.rc').write_text(str(q.returncode)+'\n');assert q.returncode==0,'read-only collector failed'
a=json.loads((P/'binding-before-private.json').read_text());b=json.loads(q.stdout)
assert b['boot_id']!=a['boot_id'];assert b['settings']==a['settings'];assert not b['busy_cloud_processes'];assert all(v['kind']=='absent' for v in b['markers'].values())
for k in ['safe_payload','local_recovery','hooks','unit_overrides']:assert b[k]==a[k],k+' changed; investigate private evidence'
protected=['/storage/.config/rclone/rclone.conf','/storage/.config/cloud_sync.conf','/storage/.config/cloud_sync.conf.bak','/storage/.config/cloud_sync.conf.pre-contentpath-fix','/storage/.config/cloud-layout-migration.json']
for k in protected:assert b['files'][k]==a['files'][k],k+' changed; investigate private evidence'
for u in ['essway.service','emustation.service']:
 for k in ['ActiveState','SubState','UnitFileState','KillMode','Restart','FragmentPath','DropInPaths']:assert b['units'][u][k]==a['units'][u][k],u+' '+k
code="from pathlib import Path\nimport json\nnames=['/storage/.config/system/configs/system.cfg','/storage/.config/system/configs/system.cfg.backup','/storage/.config/cloud_sync.conf','/storage/.config/cloud_sync.conf.defaults','/storage/.config/cloud_sync-rules.txt']\nprint(json.dumps({n:Path(n).read_text() for n in names if Path(n).exists()}))\n"
q=subprocess.run(ssh,input=code,capture_output=True,text=True,timeout=30);assert q.returncode==0;(P/'configs-after-private.json').write_text(q.stdout)
c=json.loads((P/'extra-before02-private.json').read_text())['configuration'];d=json.loads(q.stdout)
def parse(text):
 out={}
 for l in text.splitlines():
  if '=' in l and not l.lstrip().startswith('#'):
   k,v=l.split('=',1);out.setdefault(k,[]).append(v)
 return out
semantic=[]
for n in ['/storage/.config/system/configs/system.cfg','/storage/.config/system/configs/system.cfg.backup']:
 assert parse(c[n])==parse(d[n]),'settings values changed; inspect privately'
 assert {k:v for k,v in a['files'][n].items() if k not in ['sha256','bytes']}=={k:v for k,v in b['files'][n].items() if k not in ['sha256','bytes']}
 semantic.append({'file':Path(n).name,'all_values_and_duplicate_order_preserved':True,'byte_identical':c[n]==d[n]})
config_changes={n:{'before_sha256':hashlib.sha256(c[n].encode()).hexdigest(),'after_sha256':hashlib.sha256(d[n].encode()).hexdigest()} for n in c if c[n]!=d[n]}
for n in ['/storage/.config/cloud_sync.conf','/storage/.config/cloud_sync.conf.defaults','/storage/.config/cloud_sync-rules.txt']:assert c[n]==d[n],n+' changed; compare qualified defaults before acceptance'
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'PASS','issue':344,'old_boot_id':a['boot_id'],'new_boot_id':b['boot_id'],'protected_payload_count':len(b['safe_payload']),'protected_payload_bytes':sum(v['bytes'] for v in b['safe_payload'].values()),'all_payload_hashes_and_modes_preserved':True,'recovery_entries':len(b['local_recovery']['entries']),'credentials_and_selected_paths_unchanged':True,'automatic_sync_unchanged_and_off':True,'hooks_and_service_overrides_unchanged':True,'pending_recovery_markers':False,'settings_semantics':semantic,'changed_config_files':config_changes,'cloud_operations':False,'screenshots':False}
(P/'preservation-summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))

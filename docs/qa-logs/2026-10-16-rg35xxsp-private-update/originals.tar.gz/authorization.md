Owner authorization, October16: "If we're ready, you have my permission to transfer the H700 image to the RG35XX SP and to also reboot it."

Can this be done on the VM? No for this step: the physical H700 board/DDR4 update path, retained device storage, real tailnet and post-reboot native services must be confirmed on the actual RG35XX SP. Artifact and fresh/retained VM qualification plus #603 audit are already accepted; do not repeat them.

First read installed identity, custom GameCube mappings, update queue, storage/power/activity and cloud-automation state; preserve configuration/save manifests without exposing credentials. Then transfer only the exact accepted077197 H700 tar outside the updater queue, verify its complete device-side SHA256, atomically stage it and perform one authorized reboot. Verify changed boot/build, board/DTB/mounts, current binaries and selected state preservation. No game launch, screenshot, input, cloud command or unrelated settings change is included.

The owner provided this named transfer/reboot permission after the read-only host-key limitation was explained. Use the authenticated named Tailnet node and record a host-specific known-host key on first contact, then require strict matching for transfer/reboot; do not continue after any mismatch. Public source/licence and website work remain separate under D-WORKFLOW-168.

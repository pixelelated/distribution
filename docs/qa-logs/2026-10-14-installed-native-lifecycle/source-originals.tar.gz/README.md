# Installed native case: complete allocated lifecycle — UNRUN

This additive outer packet makes the sealed native continuation directly
allocatable after final image readback and the separate clean/#588 closure.
It adds no case or criterion. The native case stays byte-identical at seal
`0ad09832537aaaf3035194c062cb0edff216c27ae309755f29ad9105a046f67f` in
`/tmp/m7-installed-native-smoke-20261014`. Root also preserved that case in
`docs/qa-logs/2026-10-14-installed-native-smoke/source-originals.tar.gz`
(archive SHA `c7b666a64a09ad2312ec557d7a64e57341b5874db4e4f06b125761714bde5caf`).
This lifecycle does not replay clean588, component controls, gameplay or saves.

Source preparation only: AST parsing and source/hash inspection were performed;
no preparer, native input writer, converter, case, VM, process owner, compiler,
container, service or allocation ran. Source paths and original byte identities
are bound in `derivation.json`. `accepted-vm-basis.txt` is the accepted #566 route05
host owner; `guest-owner-basis.txt` is the accepted native #584 descendant owner.
Existing media/serial/QEMU/stop patterns are retained. The reviewed retained-state
adapter contributes its host subreaper finalizer. `census.py` remains exactly
`600f1a59149864396730d8bcae6a86b6fa6f8347f99c729c18e14cd7307f62b2`.

## One owner, one native case

The source preparer reads actual final verifier `inputs.json` and PASS
`result.json`. It selects the sole declared `.img.gz`; no final filename/hash is
predicted. The selected source must be d6a87f05, with matching final ES pin.
It copies only small source/receipt files and checks input metadata. Full image
and43MiB tool/input hashing, media construction and sparse image inflation occur
inside the later admitted watcher. The preparation creates `logs`, `records`,
`vm`, `scan`, `source` and submission-owner directories before submission.

The watcher-owned lifecycle then:

1. Verifies frozen helper/profile/tools, source packet, final receipt and actual
   image bytes. Stages the case, its13 exact public input/tool files with original
   declared modes, final verifier receipt and small guest owner into a read-only
   256MiB ext4 input medium. A separate256MiB output medium retains evidence.
2. Inflates the exact final image, converts it to a fresh16GiB qcow2, and starts
   the accepted helper's8GiB/4CPU/no-NIC640x480 guest. Actual generated and live
   QEMU argv, PID/start ticks, boot ID and final BUILD_ID are recorded. No kernel,
   boot-file, product overlay or default-service change is made.
3. Mounts input read-only, output writable, and one dedicated executable256MiB
   tmpfs at `/run/pix-installed-native`. Runs the unchanged case under the
   adapted #584 subreaper. The case prepares one CHD using accepted tools and
   then runs the four installed native hash calls through real installed bytecode.
4. Preserves the original case and preparation/hash exits. PID/start/PPID census
   and pidfd cleanup cover direct and adopted descendants. Any forced signal,
   unexpected reaped child, timeout, census error or remaining child fails the
   guest owner. No timeout is translated to a synthetic zero.
5. After the case has exited and descendants are reaped, copies compact scratch
   evidence, all actual authoring/hash channels and the consumed tiny CHD into
   output media. The unchanged writer's unused32MiB GC/helper payloads are omitted
   from compact evidence; they remain disposable scratch, not extra proof.
   After the guest owner exits, its actual rc/stdout/stderr are included in the
   final guest manifest. Sync/unmount, then stop the exact QEMU by pidfile/disk.
6. Once the watcher/runner/launcher and QEMU have actually exited, `close.py`
   reads the stopped output medium with the existing debugfs route, verifies the
   guest manifest, checks original channels and archives/re-hashes all host
   originals. It records failures too, including readback/validation failure
   separately. It never consumes admission or deletes media.

The host lifecycle exclusively holds `OWNER/serial.lock` for the whole run.
There is no visual/input operator or second serial reader. After a transport
failure the host subreaper closes direct/adopted transport descendants before
final serial flush. QEMU is excluded from that cleanup and stopped separately.
An interrupted case whose guest receipt is incomplete stays failed/unknown;
QEMU stop ends the guest. No success is inferred from a stopped VM alone.

## Prospective bounds

Full owner: **1200s work +120s cleanup**. Guest case: original180s; guest owner
allows10s descendant cleanup and20s compact export,210s total. Host serial gives
that operation240s and retains a255s original transport bound. Normal boot has
240s readiness/260s transport. Existing case preparation has30s per author,
75s+5s outer; installed check has60s alarm and70s+5s outer. Those case limits are
unchanged. Guest input/output media are256MiB each, scratch256MiB. The VM retains
8GiB RAM and4CPUs; no unobserved host cgroup memory cap is claimed.

Retention conservatively reserves16GiB raw inflation,16GiB guest virtual disk,
512MiB media and64MiB transient input staging. The scratch's unused writer data
retire with the guest; original evidence and the tiny CHD survive compact export.
Host command streams are observed with8MiB bounds. Output export is bounded at
208MiB, allowing original64MiB-per-file authoring diagnostics on failure; normal
evidence is small. An export overflow fails rather than discarding originals
and claiming success. Disk/media remain until root reviews and consumes.

## Concrete preparation, admission and launch

Root records that the test is VM-capable in the existing issue/allocation and
selects an observed-free VNC display. Example130 is only a proposed value; the
lifecycle rechecks the port before boot. All host operations use the actual
host namespace and the authorized `/workspace` access, with no concurrent runtime.
Set `TASK_VERIFY` to the completed root image-verification directory.

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-01
TASK_PACKET=/tmp/m7-installed-native-lifecycle-20261014
TASK_CASE=/tmp/m7-installed-native-smoke-20261014
TASK_OWNER=/workspace/tmp/pix-m7-installed-native-20261014-01
python3 -I -S -B "$TASK_PACKET/prepare.py" \
  --checkout "$TASK_TREE" --verification "$TASK_VERIFY" \
  --case-packet "$TASK_CASE" --owner "$TASK_OWNER" --vnc 130
cd "$TASK_TREE"
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/records" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

Root actively supervises the returned watched run and reports the original
result. `prepare.py` does not reserve or launch; admission is acquired by the
watcher. Any failure ends this allocation without automatic replay.

After original watcher/runner/launcher completion, use its actual run path:

```bash
TASK_RUN="$TASK_TREE/.build-runs/ACTUAL_RETURNED_RUN_ID"
TASK_EXPORT=/workspace/tmp/pix-m7-installed-native-evidence-20261014-01
python3 -I -S -B "$TASK_OWNER/close.py" \
  --owner "$TASK_OWNER" --run "$TASK_RUN" --packet "$TASK_EXPORT"
```

Success requires original writer0/converter0, preparation0, installed0/four exact
answers, case0, guest-owner0 with empty census/cleanup, lifecycle0, watcher0,
runner0 and launcher0. The exact final verifier receipt/SYSTEM, module origins,
native maps and recreated CHD are retained. Root reviews those originals before
consuming. The existing coordinator `2026-10-14-chd-native-runtime/coordinator/consume-vm.py`
accepts this export's `host-exits.json`, `export-result.json`, `guest-manifest.json`,
`original-records.json` and `analysis.json`; it remains root-owned:

```bash
python3 -I -S -B /workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-14-chd-native-runtime/coordinator/consume-vm.py \
  --owner "$TASK_OWNER" --run "$TASK_RUN" --packet "$TASK_EXPORT" --expected 0
```

Use `--expected 1` only after investigating an actual failed lifecycle, with its
original failure/readback status preserved. This final command consumes the
specific admission then removes only the owned `vm/` directory. The outer packet
never runs it automatically. This continuation is installed native hash/codec
evidence only; the existing legitimate homebrew launcher/save allocation remains
separate, and no installed DolphinTool requirement is introduced.

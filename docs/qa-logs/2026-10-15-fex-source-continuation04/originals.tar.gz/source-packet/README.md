# FEX phase-A continuation 04 — source only, unrun

This packet acquires the **five still-missing archives**, in order: Wayland 1.24.0, libX11 1.8.12, xorgproto 2024.1, libXrandr 1.5.4, then libdrm 2.4.129. It reuses the three exact completed source archives below without downloading or copying them again. The combined five-new/three-reused URL provenance and flat-hash tuples must match all eight original source identities exactly, without overlap.

| Reused archive | Original owner | Bytes | Expected flat SHA-256 |
| --- | --- | ---: | --- |
| Linux 6.16.7 | 01 | 152,673,392 | `5be3daa1f9427b1bdb34c4894d9c1adfac38cff674376fe0611a3065729a1a81` |
| glibc 2.40 | 03 | 18,752,204 | `19a890175e9263d748f627993de6f4b1af9cd21e03f080e4bfb3a1fac10205a2` |
| GCC 14.3.0 | 03 | 95,212,220 | `e0dc77297625631ac8e50fa92fffefe899a4eb702592da5c32ef04e2293aca3a` |

Each reuse binds its original successful archive receipt, original curl wait and HTTP 200 receipt, and the containing run's failed-investigation acceptance. The collector's existing before/after digest loop checks **all three** bodies and their recorded file identities. The consumer independently hashes each under **its own owning archives directory**, rather than assuming one prior owner. Overall failed runs remain failed; their completed individual source receipts are reused explicitly.

## One precise Wayland route addition

Wayland's canonical GitLab release URL and expected flat SHA-256 `82892487a01ad67b334eca83b54317a7c86a03a89cfadacfef5211f11a5d0536` are unchanged. Its only allowed hosts are now:

- `gitlab.freedesktop.org`
- `fsn1.your-objectstorage.com`

The second hostname is the exact HTTPS destination observed in owner 03's second original HTTP 302 receipt. The coordinator authorized this hostname specifically. `wayland_route_revision` binds that safe receipt's digest, the full redirect URL's digest and the redacted origin; binding validation parses the origin and requires exact hostname, HTTPS, no userinfo, no explicit port, no query and no fragment. The transport validates every actual future URL with the unchanged HTTPS/authority rules. Only Wayland gets this hostname; all other allowlists are explicitly checked unchanged.

The signed URL itself is **not copied into this packet or public receipts**. The original private curl stream remains in owner 03. Future requests start again at the unchanged canonical release URL and follow only the bounded, validated redirects they receive. This does not reuse an expired signed URL, trust an arbitrary storage host or add a retry/fallback transport.

## Preserved outcomes and limits

Three consumed failed-investigated originals are bound:

1. Owner 01 / `20261015T132811Z-4942e582`: Linux completed; libdrm curl 35 / HTTP 0 / zero body.
2. Owner 02 / `20261015T134634Z-fc71de07`: glibc's unapproved mirror redirect was refused before contact; **166 body bytes**, no completed archive.
3. Owner 03 / `20261015T135604Z-3268d507`: glibc and GCC completed with original curl 0 / HTTP 200; Wayland's two 302 bodies were **173 + 727 = 900 bytes**, and the newly observed storage host was not contacted.

All three overall outcomes remain 1/0/1 with accepted failure consumption. The new response-body allowance is **136,014,302 bytes**:

`266,637,816 held successful archive bytes + 1,066 prior redirect bytes + 136,014,302 new response bytes = 402,653,184 bytes (384 MiB)`.

Five logical downloads permit four redirects each: **at most 25 actual HTTP requests**. Every new redirect body and failed partial counts. Individual bodies retain the 192 MiB upper bound, while the effective cap shrinks with remaining aggregate and owner capacity. There are no automatic retries, exception suppression or source-specific fallback. Any failure stops and preserves all originals.

The unchanged limits are: 1 GiB fresh owner; 2 GiB retention reservation; 16 MiB normal receipt reserve; bounded failure/supervisor/completion receipts; full body-plus-both-log reservations before writes; 580-second soft collector deadline, 600-second supervisor deadline and 630+15-second outer timeout; 120 seconds per logical download shared across redirects; 10-second connection cap; two CPUs; 2 GiB address space; 4 GiB streamed-read limit. Maximum 25 fixed six-file request groups plus five archive receipts and finite lifecycle files remain below 512 files / 16 directories. Sources are neither extracted nor executed.

The request/redirect/reservation functions and the process-identity helper are unchanged. Supervisor edits are limited to exact success counts and scope. The focused 48-case guard source only tightens its request-count boundary from 35 to 25; the base write controls are unchanged. `changes.diff`, `changed-lines.json`, `source-provenance.json` and `static-review.json` contain the exact delta and finite syntax/source checks. **No new guard, preparer or collector has run.** No prior archive body was reread during source preparation.

Historical ALSA/libxcb/libXrender references remain unchanged. Phase B is paused. Source acquisition still does not confer notice, independent retrieval, offhost or publication clearance. All raw curl stdout/stderr remain private and excluded from Git.

## Ready coordinator commands

The default fresh owner is `/workspace/tmp/pix-m7-fex-source-acquisition-20261015-04`, with guard report suffix 04. Both are uncreated. Execute each step only after coordinator allocation and review of the preceding original receipts:

```bash
bash /tmp/pix-m7-fex-source-acquisition-continuation04-20261015/commands.sh guards
# Export TASK_GUARD_RUN, TASK_CURL_PATH and TASK_CURL_SHA256 from the original guard run and resolved host curl.
bash /tmp/pix-m7-fex-source-acquisition-continuation04-20261015/commands.sh prepare
bash /tmp/pix-m7-fex-source-acquisition-continuation04-20261015/commands.sh preflight
bash /tmp/pix-m7-fex-source-acquisition-continuation04-20261015/commands.sh report
bash /tmp/pix-m7-fex-source-acquisition-continuation04-20261015/commands.sh admit
bash /tmp/pix-m7-fex-source-acquisition-continuation04-20261015/commands.sh launch
# Root supervises the original run at intervals no longer than 60 seconds.
# After all original channels, exact source identities and process custody qualify:
bash /tmp/pix-m7-fex-source-acquisition-continuation04-20261015/commands.sh consume
```

Failure uses normal failed-investigation consumption. Never rerun a used owner, redownload completed sources, widen bounds or publish signed redirects. Frozen control tools and serialized admission remain unchanged.

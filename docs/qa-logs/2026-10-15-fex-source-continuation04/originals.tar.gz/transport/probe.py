from pathlib import Path
import subprocess,os,resource,json,datetime,hashlib
P=Path(__file__).resolve().parent
assert hashlib.sha256(Path('/usr/bin/curl').read_bytes()).hexdigest()=='7abff479a2c8bd06ace2d82522a8bf2b102ae917ab2a2cbfa0fc52a2178a48a6'
plan=[('xorg-ipv4','-4','https://xorg.freedesktop.org/releases/individual/lib/libX11-1.8.12.tar.xz'),('xorg-ipv6','-6','https://xorg.freedesktop.org/releases/individual/lib/libX11-1.8.12.tar.xz'),('ftp-xorg-ipv4','-4','https://ftp.x.org/archive/individual/lib/libX11-1.8.12.tar.xz'),('dri-ipv4','-4','https://dri.freedesktop.org/libdrm/libdrm-2.4.129.tar.xz'),('dri-ipv6','-6','https://dri.freedesktop.org/libdrm/libdrm-2.4.129.tar.xz')]
rows=[]
def limits():
 resource.setrlimit(resource.RLIMIT_FSIZE,(262144,262144));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));resource.setrlimit(resource.RLIMIT_CPU,(10,10))
for name,family,url in plan:
 argv=['/usr/bin/curl','-q',family,'--head','--proto','=https','--connect-timeout','5','--max-time','8','--retry','0','--verbose','--output','/dev/null','--write-out','%{http_code} %{remote_ip} %{time_connect} %{time_appconnect} %{time_total}\n',url]
 a=P/(name+'.stdout');b=P/(name+'.stderr');started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with a.open('xb') as out,b.open('xb') as err:
  child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},preexec_fn=limits)
  try:rc=child.wait(timeout=12)
  except subprocess.TimeoutExpired:child.kill();rc=child.wait();raise RuntimeError('probe required outer kill')
 text=b.read_text(errors='replace');safe=dict(name=name,url=url,argv=argv,started=started,original_curl_exit=rc,wait_observed=True,summary=a.read_text().strip(),stderr_sha256=hashlib.sha256(b.read_bytes()).hexdigest(),stderr_bytes=b.stat().st_size,categories=[x for x in ['Connection reset','Network is unreachable','Could not resolve','Failed to connect','Connection refused','SSL connection using','certificate verify ok','timed out'] if x.lower() in text.lower()])
 rows.append(safe);(P/(name+'.json')).write_text(json.dumps(safe,indent=2)+'\n');print(json.dumps(safe),flush=True)
(P/'result.json').write_text(json.dumps(dict(result='DIAGNOSTIC_COMPLETED_ORIGINAL_PROBE_RESULTS_RETAINED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),requests=5,head_only=True,redirects_followed=False,source_bodies_downloaded=False,rows=rows),indent=2)+'\n')

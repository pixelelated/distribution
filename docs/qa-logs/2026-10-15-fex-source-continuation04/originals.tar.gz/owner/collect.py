#!/usr/bin/env python3
"""Acquire five missing exact full source archives and verify three held prior archives as data; no extraction or source execution."""
from pathlib import Path
import datetime,hashlib,json,os,resource,runpy,stat,subprocess,sys,time,urllib.parse
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());RESOURCES=json.loads((O/'resources.json').read_text())
initial_files=[p for p in O.rglob('*') if p.is_file()]
assert len(initial_files)<=512 and all(not p.is_symlink() for p in initial_files)
INITIAL_OUTPUT_BYTES=sum(p.stat().st_size for p in initial_files)
OUTPUT_BYTES=INITIAL_OUTPUT_BYTES
start=time.monotonic();read_bytes=0;retained_bytes=0;metadata_bytes=0;compressed_bytes=0
rows=[];archive_receipts=[];downloads=[];payload_reservations=[];log_reservations=[];gaps=[];selected=[];counts={};rc=1
def account_output(size, failure=False):
    global OUTPUT_BYTES
    assert type(size)is int and 0<=size<=RESOURCES['per_file_bytes'], 'retained output exceeds existing per-file resource bound'
    policy=PLAN['owner_output_enforcement']
    if failure:assert size<=policy['failure_receipt_budget_bytes'], 'failure receipt exceeds its bounded reserve share'
    reserve=policy['supervisor_receipt_margin_bytes'] if failure else policy['supervisor_receipt_reserve_bytes']
    assert OUTPUT_BYTES+size<=RESOURCES['owner_output_ceiling_bytes']-reserve, 'retained owner-output budget exceeded before write'
    OUTPUT_BYTES+=size

def write(path, value):
    assert not path.exists() and not path.is_symlink(), 'refuse retained output overwrite: '+str(path)
    raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
    account_output(len(raw),failure=path.name=='collection-failure.json')
    with path.open('xb') as f:f.write(raw)

def identity(p):
    assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),p
    s=p.stat();assert stat.S_ISREG(s.st_mode),p
    return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)

def release_log_reservation(row,stdout_bytes,stderr_bytes,wait_observed):
    global OUTPUT_BYTES
    assert wait_observed is True and row['original_wait_observed'] is False
    assert row['released_bytes']==0 and row['reserved_bytes']==2*row['per_stream_limit']
    assert type(stdout_bytes)is int and type(stderr_bytes)is int
    assert 0<=stdout_bytes<=row['per_stream_limit'] and 0<=stderr_bytes<=row['per_stream_limit']
    used=stdout_bytes+stderr_bytes
    release=row['reserved_bytes']-used
    assert OUTPUT_BYTES>=release
    OUTPUT_BYTES-=release
    row.update(released_bytes=release,actual_bytes=used,original_wait_observed=True)


def budget(n):
    global read_bytes
    read_bytes+=n
    assert read_bytes<=RESOURCES['named_read_ceiling_bytes'] and time.monotonic()-start<RESOURCES['collector_soft_seconds'],'named read/time bound'


def digest(path,cap):
    before=identity(path);assert before['bytes']<=cap
    h=hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1024**2),b''):budget(len(data));h.update(data)
    assert identity(path)==before,'input changed'
    return dict(before,sha256=h.hexdigest())


def put(path,value):
    global metadata_bytes
    size=len((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode())
    assert size<=RESOURCES['max_json_bytes'] and metadata_bytes+size<=RESOURCES['max_retained_metadata_bytes'],'metadata aggregate bound'
    metadata_bytes+=size
    write(path,value)


def effective_request_cap():
    remaining_body=RESOURCES['compressed_archive_aggregate_bytes']-compressed_bytes
    remaining_owner=RESOURCES['owner_output_ceiling_bytes']-PLAN['owner_output_enforcement']['supervisor_receipt_reserve_bytes']-OUTPUT_BYTES-RESOURCES['request_metadata_reserve_bytes']
    # All three streams receive this same actual RLIMIT_FSIZE. Reserve their
    # complete bound before starting curl. A smaller remainder never widens caps.
    cap=min(RESOURCES['compressed_archive_per_file_bytes'],remaining_body,remaining_owner//3)
    assert type(cap)is int and cap>0,'no remaining request capacity'
    return cap


def reserve_payload(path,cap):
    global compressed_bytes
    assert 0<cap<=RESOURCES['compressed_archive_per_file_bytes']
    assert compressed_bytes+cap<=RESOURCES['compressed_archive_aggregate_bytes'],'compressed aggregate before-write bound'
    account_output(cap);compressed_bytes+=cap
    row=dict(path=str(path),reserved_bytes=cap,actual_bytes=None,released_bytes=0,original_wait_observed=False)
    payload_reservations.append(row)
    return row


def release_payload(row,actual,wait_observed):
    global OUTPUT_BYTES,compressed_bytes
    assert wait_observed is True and row['original_wait_observed']is False and row['released_bytes']==0
    assert type(actual)is int and 0<=actual<=row['reserved_bytes']
    unused=row['reserved_bytes']-actual
    assert OUTPUT_BYTES>=unused and compressed_bytes>=unused
    OUTPUT_BYTES-=unused;compressed_bytes-=unused
    row.update(actual_bytes=actual,released_bytes=unused,original_wait_observed=True)


def validate_request_url(url,selection,hop):
    assert type(url)is str and len(url.encode('utf-8'))<=8192
    assert not any(ord(c)<33 or ord(c)==127 for c in url),'URL control character refused'
    u=urllib.parse.urlsplit(url)
    assert u.scheme=='https' and u.hostname in selection['allowed_redirect_hosts'],'HTTPS host outside explicit route'
    assert u.netloc==u.hostname and u.username is None and u.password is None and not u.fragment,'URL authority/fragment refused'
    if hop==0:assert url==selection['canonical_url'] and not u.query,'initial URL differs from exact source'


def public_url(url):
    # Redirect paths as well as queries can carry signed access material. Only
    # raw private curl streams retain them; other records use origin plus digest.
    try:
        u=urllib.parse.urlsplit(url)
        if u.scheme=='https' and u.hostname and u.netloc==u.hostname:
            return 'https://'+u.hostname+'/[redacted]'
    except ValueError:
        pass
    return '[invalid-or-redacted-url]'


def curl_argv(curl,url,path,cap,remaining):
    assert remaining>0 and cap>0
    return [curl,'-q','--fail','--proto','=https','--connect-timeout',str(RESOURCES['request_connect_seconds']),
            '--max-time',str(min(remaining,RESOURCES['logical_download_seconds'])),
            '--max-filesize',str(cap),'--retry','0','--silent','--show-error',
            '--output',str(path),'--write-out','%{http_code}\n%{redirect_url}\n',url]


def check_request_count(hop):
    assert len(downloads)<RESOURCES['max_http_requests_including_redirects'],'actual request budget exhausted'
    assert 0<=hop<=RESOURCES['max_redirects_per_download'],'redirect budget exhausted'


def request(selection,url,hop,curl,deadline):
    budget(0)
    check_request_count(hop)
    validate_request_url(url,selection,hop)
    key=selection['key']+'-'+str(hop);cap=effective_request_cap()
    path=O/'archives'/(key+'.body');stdout=O/'collection'/(key+'.curl.stdout');stderr=O/'collection'/(key+'.curl.stderr')
    assert not path.exists() and not path.is_symlink()
    reservation=reserve_payload(path,cap)
    log=dict(asset=key,per_stream_limit=cap,reserved_bytes=2*cap,released_bytes=0,original_wait_observed=False)
    account_output(cap);account_output(cap);log_reservations.append(log)
    before=digest(Path(curl['path']),16*1024**2);assert before==curl['identity'],'host curl identity changed'
    remaining=min(deadline-time.monotonic(),RESOURCES['collector_soft_seconds']-(time.monotonic()-start))
    argv=curl_argv(curl['path'],url,path,cap,remaining)
    shown=selection['canonical_url'] if hop==0 else public_url(url)
    row=dict(key=key,asset=selection['key'],hop=hop,url=shown,url_sha256=hashlib.sha256(url.encode()).hexdigest(),
             argv=argv[:-1]+[shown],argv_url_redacted=hop!=0,original_curl_returncode=None,wait_observed=False,effective_body_and_stream_cap=cap)
    downloads.append(row)
    with path.open('xb'):pass
    with stdout.open('xb') as so,stderr.open('xb') as se:
        process=subprocess.run(argv,stdout=so,stderr=se,cwd=O/'archives',
            env={'PATH':'/usr/bin:/bin','HOME':str(O/'empty-home'),'LC_ALL':'C'},
            preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(cap,cap)))
    row.update(original_curl_returncode=process.returncode,wait_observed=True)
    put(O/'collection'/(key+'.curl.wait.json'),row)
    row.update(stdout=digest(stdout,cap),stderr=digest(stderr,cap),body=digest(path,cap))
    release_log_reservation(log,row['stdout']['bytes'],row['stderr']['bytes'],True)
    release_payload(reservation,row['body']['bytes'],True)
    put(O/'collection'/(key+'.reservations.json'),dict(payload=reservation,logs=log))
    assert digest(Path(curl['path']),16*1024**2)==before,'host curl changed'
    assert row['stdout']['bytes']<=RESOURCES['http_stdout_parse_bytes'],'HTTP metadata parse bound'
    raw=stdout.read_bytes();budget(len(raw))
    fields=raw.decode('utf-8',errors='strict').splitlines()
    assert len(fields)==2 and len(fields[0])==3 and fields[0].isdigit(),'invalid HTTP metadata'
    redirect=fields[1]
    assert len(redirect.encode('utf-8'))<=RESOURCES['max_url_bytes'],'redirect URL bound'
    row.update(http_status=int(fields[0]),redirect_url=public_url(redirect) if redirect else '',
        redirect_url_sha256=hashlib.sha256(redirect.encode()).hexdigest() if redirect else None)
    put(O/'collection'/(key+'.http.json'),row)
    return row,redirect


def download(selection,curl):
    deadline=min(time.monotonic()+RESOURCES['logical_download_seconds'],start+RESOURCES['collector_soft_seconds'])
    url=selection['canonical_url'];seen=set()
    for hop in range(RESOURCES['max_redirects_per_download']+1):
        assert url not in seen,'redirect loop refused';seen.add(url)
        row,redirect=request(selection,url,hop,curl,deadline)
        assert type(row['original_curl_returncode'])is int and row['original_curl_returncode']==0,'original curl failure; no retry'
        if row['http_status'] in [301,302,303,307,308]:
            assert hop<RESOURCES['max_redirects_per_download'],'redirect budget exhausted'
            validate_request_url(redirect,selection,hop+1)
            url=redirect
            continue
        assert row['http_status']==200 and not redirect,'non-success response; no fallback'
        assert row['body']['sha256']==selection['sha256'],'exact source SHA256 mismatch; stop'
        return row
    raise AssertionError('logical download did not terminate')


try:
    os.umask(0o077)
    assert INITIAL_OUTPUT_BYTES<=RESOURCES['initial_owner_maximum_bytes'];account_output(0)
    assert len(PLAN['selected_archives'])==5 and PLAN['logical_downloads']==5
    assert len({r['sha256'] for r in PLAN['selected_archives']})==5
    assert len({r['key'] for r in PLAN['selected_archives']})==5
    tools=json.loads((O/'host-tools.json').read_text());assert set(tools)=={'curl'}
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h,'bound original changed'
    assert len(PLAN['reused_prior_archives'])==3
    for prior in PLAN['reused_prior_archives']:
        assert digest(Path(prior['archive']['path']),RESOURCES['compressed_archive_per_file_bytes'])==prior['archive'],'held prior archive identity changed'
    for name in ['archives','collection','empty-home']:(O/name).mkdir(mode=0o700)
    for selection in PLAN['selected_archives']:
        budget(0);http=download(selection,tools['curl'])
        row=dict(selection=selection,archive=http['body'],original_request_key=http['key'],
                 exact_flat_sha256_verified=True,source_archive_extracted=False,license_clearance=False)
        dest=O/'collection'/(selection['key']+'.archive.json');put(dest,row);rows.append(row)
        archive_receipts.append(dict(key=selection['key'],path=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
    for name,h in PLAN['binding_refs'].items():assert digest(Path(name),8*1024**2)['sha256']==h,'bound original changed'
    for prior in PLAN['reused_prior_archives']:
        assert digest(Path(prior['archive']['path']),RESOURCES['compressed_archive_per_file_bytes'])==prior['archive'],'held prior archive changed during continuation'
    report=dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,downloads=downloads,
        payload_reservations=payload_reservations,log_reservations=log_reservations,
        logical_downloads=5,actual_http_requests=len(downloads),compressed_bytes=compressed_bytes,
        named_bytes_read=read_bytes,elapsed_seconds=time.monotonic()-start,initial_owner_bytes=INITIAL_OUTPUT_BYTES,
        accounted_owner_bytes_before_report=OUTPUT_BYTES,owner_output_enforcement=PLAN['owner_output_enforcement'],
        reused_historical_archives=PLAN['reused_historical_archives'],historical_archive_payloads_rehashed=False,
        reused_prior_archives=PLAN['reused_prior_archives'],prior_archive_payload_revalidated=True,
        phase_A_response_body_accounting=PLAN['phase_A_response_body_accounting'],
        phase_B_unperformed=PLAN['phase_B'],target_execution=False,source_execution=False,archive_extraction=False,
        network_used=True,source_rebuild=False,independent_SYSTEM_relation_established=False,
        publication_clearance=False,source_bundle_complete=False,outputs_held=True,deleted_bytes=0,
        private_raw_stream_policy='All .curl.stdout/.curl.stderr remain owner-held and must not enter Git; signed redirect paths/queries may be present. Other receipts redact both.')
    put(O/'collection-result.json',report);rc=0
except BaseException as error:
    # Error messages can include URLs. Keep type only; original private curl
    # streams and immutable waits provide diagnosis without leaking redirects.
    write(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,
        error_type=type(error).__name__,error_details_policy='Inspect private original streams under owner custody; do not publish raw redirects',
        completed_archives=len(rows),completed_archive_receipts=archive_receipts,
        collection_plan_sha256=hashlib.sha256((O/'collection-plan.json').read_bytes()).hexdigest(),
        initial_owner_bytes=INITIAL_OUTPUT_BYTES,accounted_owner_bytes_before_failure=OUTPUT_BYTES,
        named_bytes_read=read_bytes,elapsed_seconds=time.monotonic()-start,
        original_download_statuses=[dict(key=r['key'],original_curl_returncode=r['original_curl_returncode'],wait_observed=r['wait_observed']) for r in downloads],
        payload_reservations=payload_reservations,log_reservations=log_reservations,
        continuation_policy='Stop, preserve all partial bodies/waits and consume the original failure. Root may separately review a fresh continuation for missing sources only. No automatic retries, owner reuse or limit widening.',
        publication_clearance=False,outputs_held=True,deleted_bytes=0))
sys.exit(rc)


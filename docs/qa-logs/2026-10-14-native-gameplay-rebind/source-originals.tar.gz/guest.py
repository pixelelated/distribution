#!/usr/bin/env python3
"""UNRUN normal installed ES/native handoff, operated only through owned serial."""
import argparse,configparser,hashlib,json,os,re,shlex,shutil,signal,subprocess,time,urllib.request,uuid,xml.etree.ElementTree as ET
from pathlib import Path
HERE=Path(__file__).resolve().parent;R=Path('/tmp/pix-output/gameplay');INPUT=Path('/tmp/pix-input/gameplay')
ROMS={'wii':'/storage/roms/wii/SuDokuL-Wii.dol','tetris2':'/storage/roms/dreamcast/Tetris2-M7.cdi'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):
 t=p.with_suffix('.pending');t.write_text(json.dumps(x,indent=2)+'\n');os.replace(t,p)
def identity(pid):
 p=Path('/proc',str(pid));f=(p/'stat').read_text().rsplit(')',1)[1].split()
 return {'pid':pid,'start_ticks':int(f[19]),'state':f[0],'argv':[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x]}
def natives():
 result=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   row=identity(int(p.name))
   if row['argv'] and Path(row['argv'][0]).name in ('flycast','dolphin-emu-nogui','dolphin-emu'):result.append(row)
  except (FileNotFoundError,ProcessLookupError):pass
 return result
def run(label,args,seconds=30):
 stem=R/(label+'-'+uuid.uuid4().hex[:8]);row={'argv':list(map(str,args)),'original_returncode':None,'timed_out':False}
 with Path(str(stem)+'.stdout').open('xb') as out,Path(str(stem)+'.stderr').open('xb') as err:
  child=subprocess.Popen(row['argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:row['original_returncode']=child.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   row['timed_out']=True;os.killpg(child.pid,signal.SIGKILL);row['original_returncode']=child.wait(timeout=5)
 save(Path(str(stem)+'.json'),row);assert row['original_returncode']==0 and not row['timed_out'],label
 return Path(str(stem)+'.stdout').read_text()
def api(path,data=None):
 before=time.monotonic();req=urllib.request.Request('http://127.0.0.1:1234'+path,data=data.encode() if data else None,headers={'Content-Type':'text/plain'})
 with urllib.request.urlopen(req,timeout=5) as response:row={'path':path,'http_status':response.status,'body':response.read(1024*1024).decode(),'before_monotonic':before,'after_monotonic':time.monotonic()}
 save(R/('http-'+uuid.uuid4().hex+'.json'),row);assert row['http_status'] in (200,201);return row
def pad(buttons=None,milliseconds=120,quit=False):
 q={'id':uuid.uuid4().hex,'operation':'quit' if quit else 'press','buttons':buttons,'milliseconds':milliseconds};save(R/('pad-claim-'+q['id']+'.json'),q)
 fd=os.open(R/'pad.commands',os.O_WRONLY|os.O_NONBLOCK)
 try:assert os.write(fd,(json.dumps(q)+'\n').encode())>0
 finally:os.close(fd)
 if quit:return q
 end=time.monotonic()+3
 while not (R/('pad-ack-'+q['id']+'.json')).exists():
  assert time.monotonic()<end,'ambiguous pad action: retain claim, never replay';time.sleep(.05)
 return json.loads((R/('pad-ack-'+q['id']+'.json')).read_text())
def snapshot(label,copy_sd=False):
 assert re.fullmatch('[a-z0-9-]{1,60}',label);dest=R/'snapshots'/label;dest.mkdir(parents=True)
 paths=[Path('/storage/.config/dolphin-emu'),Path('/storage/.config/flycast'),Path('/storage/roms/savestates/wii'),Path('/storage/roms/bios/dc'),Path('/var/log/exec.log'),Path('/var/log/es_log.txt'),Path('/var/log/es_log.txt.bak'),Path('/storage/.config/gptokeyb/control.ini')]
 rows=[]
 for root in paths:
  if not root.exists():continue
  for f in ([root] if root.is_file() else sorted(root.rglob('*'))):
   if f.is_symlink():rows.append({'path':str(f),'link':os.readlink(f),'resolved':str(f.resolve())});continue
   if not f.is_file():continue
   assert f.stat().st_size<=128*1024**2
   target=dest/str(f).lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
   rows.append({'path':str(f),'bytes':target.stat().st_size,'sha256':sha(target),'copied':str(target.relative_to(R)),'live_source_may_advance':bool(natives())})
 if copy_sd:
  assert not natives(),'copy only quiescent SD';f=Path('/storage/qa-m7-homebrew/sd.raw');shutil.copy2(f,dest/'sd.raw');rows.append({'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f),'copied':str((dest/'sd.raw').relative_to(R))})
 save(dest/'inventory.json',{'rows':rows,'native_processes':natives(),'native_exit_status':'unknown: no engine shim or wait-status observer','time':time.time()});return str(dest)
def provision(remaining):
 assert not R.exists();R.mkdir();(R/'snapshots').mkdir();end=time.monotonic()+90
 manifest=json.loads((INPUT/'input-files.json').read_text())
 for name,row in manifest.items():assert sha(INPUT/name)==row['sha256'] and (INPUT/name).stat().st_size==row['bytes']
 verification=json.loads((INPUT/'final-image-result.json').read_text());assert verification['status']=='PASS'
 installed={}
 for name in (HERE/'consumed-paths.txt').read_text().splitlines():
  if not name or name.startswith('#'):continue
  f=Path('/'+name);assert f.is_file(),name
  row={'bytes':f.stat().st_size,'sha256':sha(f),'resolved':str(f.resolve()),'mode':f.stat().st_mode&0o777}
  if name in verification['products']:
   expected=verification['products'][name];assert row['bytes']==expected['bytes'] and row['sha256']==expected['sha256'];row['comparison']='existing final verifier row matched'
  else:row['comparison']='actual installed bytes; final image/SYSTEM/BUILD_ID bound, no unlisted source-to-final equality claim'
  installed[name]=row
 for name,expected in json.loads((HERE/'frozen-config-bindings.json').read_text()).items():
  assert installed[name]['sha256']==expected['expected_installed_sha256'];installed[name]['frozen_source_comparison']=expected
 save(R/'installed-inputs.json',{'system':verification['payload']['SYSTEM'],'source':verification['source'],'products':installed})
 while True:
  displays=[p for p in Path('/run/0-runtime-dir').glob('wayland-*') if p.is_socket()];sway=[p for p in Path('/run/0-runtime-dir').glob('sway-ipc.*.sock') if p.is_socket()]
  if len(displays)==len(sway)==1 and Path('/storage/.config/emulationstation/es_input.cfg').is_file():
   out=run('display-outputs',['swaymsg','-s',sway[0],'-t','get_outputs','-r'],3);active=[r for r in json.loads(out) if r.get('active')]
   if len(active)==1:break
  assert time.monotonic()<end,'display/input readiness';time.sleep(1)
 assert not natives();run('stop-es',['systemctl','stop','essway.service'])
 originals=R/'originals';originals.mkdir()
 for path in ['/storage/.config/system/configs/system.cfg','/storage/.config/emulationstation/es_input.cfg']:
  f=Path(path)
  if f.is_file():shutil.copy2(f,originals/f.name)
 for game,rom in ROMS.items():
  src=INPUT/('SuDokuL-Wii.dol' if game=='wii' else 'Tetris2-M7.cdi');target=Path(rom);assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target);assert sha(src)==sha(target)
 q=Path('/storage/qa-m7-homebrew');q.mkdir();shutil.copy2(INPUT/'sd.raw',q/'sd.raw');shutil.copy2(INPUT/'Tetris2-M7.cdi.sha256',q/'Tetris2-M7.cdi.sha256')
 run('wii-fixture',['bash',HERE/'fixture/prepare-wii-guest.sh',R/'wii-preparation'])
 if not Path('/storage/.config/flycast').exists():shutil.copytree('/usr/config/flycast','/storage/.config/flycast')
 run('flycast-fixture',['python3','-I','-S','-B',HERE/'fixture/configure-flycast.py','--expected-ini-sha256',sha(Path('/storage/.config/flycast/emu.cfg'))])
 script='. /etc/profile; cp -p "$J_CONF" '+shlex.quote(str(originals/'system-before-settings.cfg'))+'; '+ '; '.join('set_setting '+shlex.quote(key)+' '+shlex.quote(value) for key,value in [('wii["SuDokuL-Wii.dol"].emulator','dolphin'),('wii["SuDokuL-Wii.dol"].core','dolphin-sa-wii'),('dreamcast["Tetris2-M7.cdi"].emulator','flycast'),('dreamcast["Tetris2-M7.cdi"].core','flycast-sa'),('dreamcast["Tetris2-M7.cdi"].graphics_backend','opengl'),('global.autosave','0'),('system.loglevel','verbose')])
 run('fixture-settings',['bash','-ec',script])
 with (R/'supervisor.stdout').open('xb') as out,(R/'supervisor.stderr').open('xb') as err:
  child=subprocess.Popen(['python3','-I','-S','-B',str(HERE/'supervisor.py'),str(remaining)],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);save(R/'supervisor.json',identity(child.pid))
 limit=time.monotonic()+10
 while not (R/'pad-ready.json').exists():assert time.monotonic()<limit;time.sleep(.1)
 # Use the normal installed producer; retain its actual GUID/name and generated file.
 run('control-gen',['/usr/bin/control-gen_init.sh']);shutil.copy2('/storage/.config/gptokeyb/control.ini',R/'control.ini')
 text=(R/'control.ini').read_text();assert 'get_controls()' in text and 'QA521 Synthetic Xbox 360 Controller' in text
 config=Path('/storage/.config/emulationstation/es_input.cfg');keyboard=ET.fromstring(config.read_bytes()).find("inputConfig[@type='keyboard']");assert keyboard is not None
 key_names={13:'ret',27:'esc',32:'spc',8:'backspace',1073741906:'up',1073741905:'down',1073741904:'left',1073741903:'right',1073742049:'shift',1073742053:'shift_r'}
 mapping={}
 for x in keyboard.findall('input'):
  if x.get('type')=='key':
   number=int(x.get('id'));key=key_names.get(number) or (chr(number) if 97<=number<=122 else None)
   if key:mapping[x.get('name')]=key
 run('start-es',['systemctl','start','essway.service'])
 limit=time.monotonic()+25
 while True:
  try:systems=api('/systems');break
  except (OSError,TimeoutError):assert time.monotonic()<limit;time.sleep(1)
 value={'rc':0,'input_keys':mapping,'panel':active,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'control_sha256':sha(R/'control.ini'),'api_port':1234,'native_exit_status':'unknown unless existing original logs expose it'};save(R/'provision.json',value);return value
def main():
 p=argparse.ArgumentParser();p.add_argument('operation',choices=['provision','status','launch','pad','snapshot','global-auto','native-auto','score-start','score-end','first-frame','finish','abort']);p.add_argument('--remaining',type=int);p.add_argument('--game',choices=ROMS);p.add_argument('--buttons');p.add_argument('--milliseconds',type=int,default=120);p.add_argument('--label');p.add_argument('--copy-sd',action='store_true');p.add_argument('--value',choices=['0','1']);a=p.parse_args()
 if a.operation=='provision':assert 60<a.remaining<=1800;result=provision(a.remaining)
 else:
  assert R.is_dir()
  if a.operation=='status':result={'native_processes':natives(),'pad':json.loads((R/'pad-ready.json').read_text()),'supervisor_result':json.loads((R/'supervisor-result.json').read_text()) if (R/'supervisor-result.json').exists() else None,'running_game':api('/runningGame')}
  elif a.operation=='pad':
   if (R/'score-clock.json').exists() and not (R/'score-result.json').exists():assert time.monotonic()<=json.loads((R/'score-clock.json').read_text())['deadline_monotonic'],'earned-score input window ended; record score-end, do not continue scoring'
   result=pad(a.buttons.split(','),a.milliseconds)
  elif a.operation=='launch':
   assert a.game and not natives();result=api('/launch',ROMS[a.game]);result['game']=a.game;result['id']=uuid.uuid4().hex;save(R/('launch-'+result['id']+'.json'),result);save(R/'active-launch.json',result)
  elif a.operation=='snapshot':result={'snapshot':snapshot(a.label,a.copy_sd)}
  elif a.operation in ('global-auto','native-auto'):
   assert not natives() and a.value is not None
   snapshot(a.operation+'-before-'+uuid.uuid4().hex[:8])
   if a.operation=='global-auto':
    run('stop-es-setting',['systemctl','stop','essway.service']);run('global-auto',['bash','-ec','. /etc/profile; set_setting global.autosave '+a.value+'; get_setting global.autosave']);run('start-es-setting',['systemctl','start','essway.service'])
   else:
    f=Path('/storage/.config/flycast/emu.cfg');c=configparser.ConfigParser(interpolation=None);c.optionxform=str;c.read(f)
    for k in ['Dreamcast.AutoSaveState','Dreamcast.AutoLoadState']:c['config'][k]='yes' if a.value=='1' else 'no'
    with f.open('w') as stream:c.write(stream)
   result={'setting':a.operation,'value':a.value}
  elif a.operation=='first-frame':
   launch=json.loads((R/'active-launch.json').read_text());result={'launch_id':launch['id'],'label':a.label,'elapsed_seconds':time.monotonic()-launch['before_monotonic'],'capture_only':True};assert result['elapsed_seconds']<=120;save(R/('first-frame-'+launch['id']+'.json'),result)
  elif a.operation=='score-start':
   assert not (R/'score-clock.json').exists();result={'start_monotonic':time.monotonic(),'deadline_monotonic':time.monotonic()+360};save(R/'score-clock.json',result)
  elif a.operation=='score-end':
   result=json.loads((R/'score-clock.json').read_text());result['end_monotonic']=time.monotonic();result['within_360s']=result['end_monotonic']<=result['deadline_monotonic'];save(R/'score-result.json',result)
  elif a.operation=='abort':save(R/'abort.json',{'reason':a.label or 'operator abort','time':time.time()});result={'abort_requested':True}
  elif a.operation=='finish':
   assert not natives();snapshot('final',True);save(R/'finish.json',{'time':time.time()});limit=time.monotonic()+15
   while not (R/'supervisor-result.json').exists():assert time.monotonic()<limit;time.sleep(.1)
   supervisor=json.loads((R/'supervisor.json').read_text())
   while Path('/proc',str(supervisor['pid'])).exists():assert time.monotonic()<limit;time.sleep(.05)
   result=json.loads((R/'supervisor-result.json').read_text());assert result['rc']==0 and result['pad_original_returncode']==0
   run('sync',['sync']);rows=[{'path':str(f.relative_to(R.parent)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(R.parent.rglob('*')) if f.is_file() and f.name!='guest-export-manifest.json'];assert sum(r['bytes'] for r in rows)<=448*1024**2;save(R.parent/'guest-export-manifest.json',rows)
  else:raise AssertionError(a.operation)
 print('PIX_GAMEPLAY_JSON='+json.dumps(result))
if __name__=='__main__':main()

Completed in `7ef32024bd7b7801187fd3f870b8343f6f693b43`, published to `next` and the feature branch.

Code trace: revision02 `scope.py:selected_payload` checks every same-relative notice against the selected member, including its full retained-text reference; only equal records coalesce. `collect.py:notice_id` retains each record hash, row and notice ordinal and refuses conflicting references. The retained revision01→02 diff is in the accepted source packet. No firmware or historical input was modified.

Already written: the original failed analysis left local partial receipts only. Its original command/monitor/runner results remain 1/0/1 and its admission remains consumed as failed-investigated. Correction used a fresh sealed source and output owner; nothing was relabelled.

Acceptance evidence:
1. All 25 focused controls passed, including identical duplicates, direct-reference duplicates, conflicting hashes/paths/sizes/full references, and original ordinal retention.
2. Actual run `20261015T125930Z-f1d74762` completed all eight records and 18,523 physical mappings. Original command/monitor/runner/launcher results are 0; no cleanup errors or owned survivors, and ordinary admission `cd3d5b0a41da4375a869839b8eea88ba` is consumed. This is notice analysis, not permission or publication clearance.
3. Both source/control/success and original failure packets are published. #528 and M7's live current-work section refer to the result; timestamped work and friction records explain the original missed shape and late issue separation.

[Accepted source, controls and runtime originals](https://github.com/pixelelated/distribution/tree/7ef32024bd7b7801187fd3f870b8343f6f693b43/docs/qa-logs/2026-10-15-shader-attribution-accepted), [original failure](https://github.com/pixelelated/distribution/tree/7ef32024bd7b7801187fd3f870b8343f6f693b43/docs/qa-logs/2026-10-15-shader-attribution-failure), [verified tracker readbacks](https://github.com/pixelelated/distribution/tree/7ef32024bd7b7801187fd3f870b8343f6f693b43/docs/qa-logs/2026-10-15-source-tracker-followup).

The independent #603 audit remains pending its separate transfer approval and review; this later helper correction is not silently added to that frozen packet.

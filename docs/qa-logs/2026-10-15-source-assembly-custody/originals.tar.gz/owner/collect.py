#!/usr/bin/env python3
"""Offline immutable-copy custody; execution requires root's separate admission."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,stat,sys,time
O=Path(__file__).resolve().parent
PLAN=json.loads((O/'collection-plan.json').read_text());R=json.loads((O/'resources.json').read_text())
D=Path(json.loads((O/'destination.json').read_text())['path'])
START=time.monotonic();READ=0;WRITES={};DIRS=set();OUTPUT={str(O):0,str(D):0};rc=1
def tick(n=0):
 global READ
 assert n>=0;READ+=n
 assert READ<=R['total_read_bytes'] and time.monotonic()-START<R['soft_seconds'],'read/time ceiling'
def safe(name):
 assert isinstance(name,str) and name and len(os.fsencode(name))<=R['path_bytes'] and '\0' not in name and '\\' not in name
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p)==name and '.git' not in p.parts,name
 return name

def ident(p,regular=True):
 p=Path(p);assert p.is_absolute() and not p.is_symlink() and p.resolve(strict=True)==p,p
 s=p.stat();assert not regular or stat.S_ISREG(s.st_mode),p
 return dict(path=str(p),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns)
def digest(p,cap=268435456):
 before=ident(p);assert before['bytes']<=cap
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));h.update(b)
 assert ident(p)==before,'input changed while hashing'
 return dict(before,sha256=h.hexdigest())
def root_for(p):
 for root in [O,D]:
  if p.is_relative_to(root):return root
 raise AssertionError('write outside owned roots')
def mkdir(p):
 root=root_for(p);assert len(DIRS)<R['output_directories'];assert not p.exists() and not p.is_symlink()
 assert p.parent.resolve(strict=True)==p.parent and not p.parent.is_symlink();p.mkdir(mode=0o700);DIRS.add(str(p))
def reserve(p,n,failure=False):
 tick();root=root_for(p);cap=R['custody_output_ceiling_bytes'] if root==D else R['owner_output_ceiling_bytes']-R['supervisor_reserve_bytes']
 if failure:assert root==O and n<=R['failure_receipt_budget_bytes'];cap+=R['failure_receipt_budget_bytes']
 assert n>=0 and OUTPUT[str(root)]+n<=cap,'aggregate before-write ceiling'
 assert WRITES[str(p)]+n<=R['per_file_bytes'],'individual before-write ceiling'
 OUTPUT[str(root)]+=n;WRITES[str(p)]+=n
class Writer:
 def __init__(self,p,failure=False):
  self.p=Path(p);root_for(self.p);safe(str(self.p.relative_to(root_for(self.p))))
  assert len(WRITES)<R['output_files'] and str(self.p) not in WRITES
  assert self.p.parent.resolve(strict=True)==self.p.parent and not self.p.exists() and not self.p.is_symlink()
  WRITES[str(self.p)]=0;self.failure=failure;self.f=self.p.open('xb')
 def write(self,b):reserve(self.p,len(b),self.failure);return self.f.write(b)
 def flush(self):self.f.flush()
 def tell(self):return self.f.tell()
 def close(self):self.f.close()
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
def put(p,obj,failure=False):
 raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
 if failure:assert len(raw)<=R['failure_receipt_budget_bytes']
 with Writer(p,failure) as f:f.write(raw)
def rawput(p,b):
 with Writer(p) as f:f.write(b)
def load(p):
 before=ident(p);assert before['bytes']<16*1024**2
 raw=Path(p).read_bytes();tick(len(raw));assert ident(p)==before;return json.loads(raw)

def copy_file(spec,member):
 safe(member);p=Path(spec['path']);before=digest(p,R['per_file_bytes'])
 assert before['bytes']==spec['bytes'] and before['sha256']==spec['sha256']
 if 'held_identity' in spec:assert before==spec['held_identity']
 target=D/member
 with p.open('rb') as f,Writer(target) as out:
  while True:
   b=f.read(1024**2)
   if not b:break
   tick(len(b));out.write(b)
 after=digest(target,R['per_file_bytes']);assert after['sha256']==before['sha256'] and after['bytes']==before['bytes']
 assert (after['device'],after['inode'])!=(before['device'],before['inode']) and digest(p,R['per_file_bytes'])==before
 return dict(member=member,bytes=after['bytes'],sha256=after['sha256'],source_identity=before,independent_copy=True)

def selected_maps():
 rows=PLAN['files'];assert len(rows)==39 and sum(r['bytes'] for r in rows)==293582752
 assert len({r['destination_member'] for r in rows})==39
 mapped=[]
 for row in rows:
  spec=dict(path=row['source_path'],bytes=row['bytes'],sha256=row['sha256'])
  item=copy_file(spec,row['destination_member'])
  mapped.append(dict(item,kind=row['kind'],scope='Exact held bytes copied; archive payloads are not decoded or attributed to a new image by this run.'))
 assert len(mapped)==39 and sum(r['bytes'] for r in mapped)==293582752
 J=Path(PLAN['join']['owner'])
 index=copy_file(dict(path=str(J/'source-assembly-index.json'),bytes=(J/'source-assembly-index.json').stat().st_size,sha256=PLAN['join']['index_sha256']),'source-assembly-index.json')
 work=copy_file(dict(path=str(J/'missing-custody-worklist.json'),bytes=(J/'missing-custody-worklist.json').stat().st_size,sha256=PLAN['join']['worklist_sha256']),'metadata/original-copy-worklist.json')
 put(D/'payload-member-index.json',mapped)
 status=dict(join=PLAN['join'],original_runner=load(Path(PLAN['join']['run'])/'runner-result.json'),original_join_result=load(J/'result.json'),scope='Successful record-only metadata join; not an admission or source-publication qualification.')
 put(D/'metadata/original-status.json',status)
 return mapped,index,work

try:
 assert D==Path('/workspace/artifacts/pixelelated-release-sources/m7-source-assembly-supplement-20261015-01') and not D.exists() and not D.is_symlink()
 for p in O.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():OUTPUT[str(O)]+=p.stat().st_size
 assert OUTPUT[str(O)]<8*1024**2
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 mkdir(D)
 for n in ['fex','fex/archives','fex/generated','fex/header-notices','zerotier','metadata']:mkdir(D/n)
 mapped,index,work=selected_maps()
 manifest=dict(schema=1,scope=PLAN['scope'],binding_refs=PLAN['binding_refs'],join=PLAN['join'],payload_files=39,payload_bytes=293582752,
  payload_index_sha256=digest(D/'payload-member-index.json')['sha256'],assembly_index_sha256=index['sha256'],original_worklist_sha256=work['sha256'],
  original_status_sha256=digest(D/'metadata/original-status.json')['sha256'],component_rows=2366,
  final_image_mapping=PLAN['final_image_mapping'],publication_bundle_complete=False,publication_clearance=False,unresolved=PLAN['unresolved'])
 put(D/'manifest.json',manifest)
 for p,h in PLAN['binding_refs'].items():assert digest(p,16*1024**2)['sha256']==h
 # copy_file already fully read back each copied destination. Retain that exact digest; consumer and ordinary admission each rehash it later.
 copied={str(D/r['member']):r['sha256'] for r in [*mapped,index,work]}
 files=[dict(path=p,bytes=n,sha256=copied[p] if p in copied else digest(p,R['per_file_bytes'])['sha256']) for p,n in WRITES.items() if Path(p).is_relative_to(D)]
 assert len(files)==44 and sum(r['bytes'] for r in files)<=R['custody_output_ceiling_bytes']
 for item in files:Path(item['path']).chmod(0o444)
 for p in sorted([Path(p) for p in DIRS if Path(p).is_relative_to(D)],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
 manifest_hash=digest(D/'manifest.json')['sha256']
 put(O/'collection-result.json',dict(result='COLLECTED_WITH_EXPLICIT_GAPS',original_collector_exit=0,custody_path=str(D),manifest_sha256=manifest_hash,files=files,
  payload_files=39,payload_bytes=293582752,component_rows=2366,metadata_files=5,
  network_used=False,target_execution=False,source_execution=False,source_rebuild=False,archive_decode=False,regeneration_performed=False,
  publication_clearance=False,publication_bundle_complete=False,outputs_held=True,deleted_bytes=0,accounted_output_bytes=OUTPUT,
  read_bytes=READ,collector_read_limit_bytes=R['total_read_bytes'],consumer_read_reserve_bytes=R['consumer_read_bytes'],admission_read_reserve_bytes=R['admission_read_reserve_bytes'],
  combined_copy_and_consumer_read_limit_bytes=R['combined_copy_and_consumer_read_bytes'],elapsed_seconds=time.monotonic()-START,
  final_image_mapping=PLAN['final_image_mapping'],unresolved=PLAN['unresolved']))
 rc=0
except BaseException as exc:
 try:put(O/'collection-failure.json',dict(result='COLLECTION_FAILED',original_collector_exit=1,error=type(exc).__name__+': '+str(exc)[:4096],accounted_output_bytes=OUTPUT,written_files=len(WRITES),publication_bundle_complete=False,outputs_held=True,deleted_bytes=0),failure=True)
 except BaseException as receipt_error:print('Failure receipt refused: '+type(receipt_error).__name__,file=sys.stderr)
sys.exit(rc)

#!/usr/bin/env python3
"""Consume exact original success channels only; retention does not clear publication."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent;B=runpy.run_path(str(O/'bindings.py'));B['set_read_limit'](384*1024**2);plan=B['verify'](O)
assert Path.cwd()==B['VM_TREE'];load,sha=B['load'],B['sha'];run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs';B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert p.read_text().strip()=='0',p
result,cleanup=load(O/'result.json'),load(O/'cleanup.json');assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established']is False
assert result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0
assert child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');R=load(O/'resources.json')
assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit'])is int and report['original_collector_exit']==0
assert report['payload_files']==39 and report['payload_bytes']==293582752 and report['component_rows']==2366 and report['metadata_files']==5
assert all(report[k]is False for k in ['source_execution','source_rebuild','archive_decode','regeneration_performed','publication_clearance','publication_bundle_complete','network_used','target_execution'])
assert report['final_image_mapping']==plan['final_image_mapping'] and report['unresolved']==plan['unresolved']
assert report['read_bytes']<=R['total_read_bytes']==1280*1024**2 and R['consumer_read_bytes']==384*1024**2 and R['admission_read_reserve_bytes']==384*1024**2
assert R['combined_copy_and_consumer_read_bytes']==2*1024**3
assert not (O/'collection-failure.json').exists();D=Path(load(O/'destination.json')['path']);assert report['custody_path']==str(D)
assert len(report['files'])==44 and len({r['path'] for r in report['files']})==44
verified={}
for r in report['files']:
 p=Path(r['path']);assert p.is_relative_to(D) and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size==r['bytes']
 h=sha(p);assert h==r['sha256'];verified[str(p)]=h
assert set(verified)=={str(p) for p in D.rglob('*') if p.is_file()}
assert sum(r['bytes'] for r in report['files'])<=384*1024**2 and verified[str(D/'manifest.json')]==report['manifest_sha256']
manifest=load(D/'manifest.json');assert manifest['publication_bundle_complete']is False and manifest['publication_clearance']is False
assert manifest['binding_refs']==plan['binding_refs'] and manifest['join']==plan['join'] and manifest['unresolved']==plan['unresolved']
assert manifest['payload_files']==39 and manifest['payload_bytes']==293582752 and manifest['component_rows']==2366
assert manifest['final_image_mapping']==plan['final_image_mapping']
for name,key in [('payload-member-index.json','payload_index_sha256'),('source-assembly-index.json','assembly_index_sha256'),('metadata/original-copy-worklist.json','original_worklist_sha256'),('metadata/original-status.json','original_status_sha256')]:assert verified[str(D/name)]==manifest[key]
assert manifest['assembly_index_sha256']==plan['join']['index_sha256'] and manifest['original_worklist_sha256']==plan['join']['worklist_sha256']
objects=load(D/'payload-member-index.json');assert len(objects)==39
for spec,obj in zip(plan['files'],objects):
 assert obj['member']==spec['destination_member'] and obj['bytes']==spec['bytes'] and obj['sha256']==spec['sha256'] and obj['kind']==spec['kind']
 assert obj['independent_copy']is True and obj['source_identity']['path']==spec['source_path'] and obj['source_identity']['sha256']==spec['sha256']
 st=(D/obj['member']).stat();assert (st.st_dev,st.st_ino)!=(obj['source_identity']['device'],obj['source_identity']['inode'])
 assert verified[str(D/obj['member'])]==obj['sha256']
 # Originals were hashed before/after copying by the collector. Preserve their final identity; do not silently accept replacement.
 original=Path(spec['source_path']);assert original.resolve(strict=True)==original and not original.is_symlink();s=original.stat()
 import stat
 actual=dict(path=str(original),bytes=s.st_size,device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,sha256=spec['sha256'])
 assert obj['source_identity']==actual
expected={r['destination_member'] for r in plan['files']}|{'manifest.json','payload-member-index.json','source-assembly-index.json','metadata/original-copy-worklist.json','metadata/original-status.json'}
assert len(expected)==44 and {str(Path(r['path']).relative_to(D)) for r in report['files']}==expected
import stat
assert all(stat.S_IMODE(p.lstat().st_mode)==(0o555 if p.is_dir() else 0o444) and not p.is_symlink() for p in [D,*D.rglob('*')])
assert cleanup['all_recorded_identities_absent']is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped']is False
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']();keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']};supervisor=cleanup['supervisor_identity'];assert supervisor is not None;keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in keys];parents={r['pid'] for r in matching};descendants=[]
while parents:
 children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants];descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[p for p in O.rglob('*') if p.is_file()]+[run/'runner-result.json',run/'build.rc']
assert len(files)+len(verified)<=1024 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=64*1024**2
for p in files:verified[str(p)]=sha(p)
# Ordinary admission rehashes every evidence file. Reserve both pending receipts plus16MiB bounded control metadata, rather than excluding that pass.
admission_read_upper=sum(Path(p).stat().st_size for p in verified)+18*1024**2
assert admission_read_upper<=R['admission_read_reserve_bytes']
assert B['read_count']()<=R['consumer_read_bytes'] and report['read_bytes']+B['read_count']()+admission_read_upper<=R['combined_copy_and_consumer_read_bytes']
readback=O/'custody-readback.json'
value=dict(status='PASS_EXACT39_LOCAL_CUSTODY_WITH_GAPS',collector_accounted_read_bytes=report['read_bytes'],consumer_accounted_read_bytes=B['read_count'](),admission_read_upper_bytes=admission_read_upper,combined_read_upper_bytes=report['read_bytes']+B['read_count']()+admission_read_upper,combined_limit_bytes=2*1024**3,payload_files=39,payload_bytes=293582752,destination_files=44,destination_bytes=sum(r['bytes'] for r in report['files']),publication_bundle_complete=False,publication_clearance=False)
raw=(json.dumps(value,indent=2)+'\n').encode();assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=64*1024**2
with readback.open('xb') as f:f.write(raw)
verified[str(readback)]=__import__('hashlib').sha256(raw).hexdigest()
out=O/'admission-completion-evidence.json';evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=p,sha256=h) for p,h in verified.items()],scope='Exact39 held source/notice files plus accepted historical metadata index local custody only. No archive decoding, complete source bundle, new-image attribution, publication clearance, independent retrieval or offhost proof. Prior producers unchanged.')
raw=(json.dumps(evidence,indent=2)+'\n').encode();assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=64*1024**2
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed exact39 local source custody; image/publication gaps retained')

"""Exact frozen control and completed metadata-join bindings; no payload reads at import."""
from pathlib import Path
import hashlib,json,os,re,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
ASSEMBLY_SHA='ca2008ab4926a25202657f93ee99b96432bef66f8feb190a6fa24c10b5e20564'
ACTUAL_JOIN={'owner': '/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01', 'run': '/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T162920Z-33308c8a', 'index_sha256': 'a42af9af00d7b1da894253a59ba8b745ba4c67a03fe6e829ef7cf10d6dc25bed', 'worklist_sha256': 'cb6fa010bc3138d7bca3ed42a91466f14302438e97c8818b4cfd2bf283aa782e', 'result_sha256': 'e75f04342b9b2ab163d11f2961464d7d57495df0cc1ebf433a3b69342d3768fc'}
ACTUAL_JOIN_REFS={'/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01/source-assembly-index.json': 'a42af9af00d7b1da894253a59ba8b745ba4c67a03fe6e829ef7cf10d6dc25bed', '/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01/missing-custody-worklist.json': 'cb6fa010bc3138d7bca3ed42a91466f14302438e97c8818b4cfd2bf283aa782e', '/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01/result.json': 'e75f04342b9b2ab163d11f2961464d7d57495df0cc1ebf433a3b69342d3768fc', '/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T162920Z-33308c8a/runner-result.json': 'b6327a9247d677f9fdeff8b5acae1437a06ebdc91dfcde20d8b1026a3fbe7afa', '/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T162920Z-33308c8a/build.rc': '9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa'}
READ_BYTES=0
READ_LIMIT=128*1024**2

def set_read_limit(n):
 global READ_LIMIT
 assert n==384*1024**2 and READ_BYTES<=n
 READ_LIMIT=n

def read_count():return READ_BYTES

def account(n):
 global READ_BYTES
 assert n>=0 and READ_BYTES+n<=READ_LIMIT,'bounded verification reads'
 READ_BYTES+=n

def sha(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p
 assert p.stat().st_size<=192*1024**2
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):
   account(len(block));h.update(block)
 return h.hexdigest()

def raw(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 data=p.read_bytes();account(len(data));return data

def load(path):return json.loads(raw(path))

def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def prerequisites(plan):
 assembly=load(plan['assembly_plan_path'])
 assert sha(plan['assembly_plan_path'])==ASSEMBLY_SHA
 assert plan['files']==assembly['copy_worklist'] and len(plan['files'])==39 and sum(r['bytes'] for r in plan['files'])==293582752
 assert len({r['destination_member'] for r in plan['files']})==39
 assert plan['metadata_refs']==assembly['refs'] and plan['final_image_mapping']==assembly['final_image_mapping']
 assert plan['unresolved']==assembly['pending_source_questions']
 join=plan['join'];assert join==ACTUAL_JOIN
 assert all(plan['binding_refs'][p]==h for p,h in ACTUAL_JOIN_REFS.items())
 J=Path(join['owner']);run=Path(join['run'])
 assert re.fullmatch('/workspace/tmp/pix-m7-final-source-assembly-index-20261015-[0-9]{2}',str(J))
 assert run.parent==Path('/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs') and re.fullmatch('[0-9]{8}T[0-9]{6}Z-[0-9a-f]{8}',run.name)
 result=load(J/'result.json');runner=load(run/'runner-result.json')
 assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc']) and raw(run/'build.rc')==b'0\n'
 assert result['status']=='PASS_METADATA_ONLY' and result['publication_bundle_complete']is False
 assert result['source_payloads_opened']==result['archives_opened']==0 and result['network_used']is False and result['source_execution']is False
 assert result['component_rows']==2366 and (result['shared_source_rows'],result['shared_source_edges'],result['arm_companion_edges'])==(12,16,2)
 assert result['metadata_bytes_read']==30449146 and 0<=result['elapsed_seconds']<=30 and result['output_bytes_before_receipt']<=15*1024**2
 expected=['source-assembly-index.json','missing-custody-worklist.json']
 assert [r['name'] for r in result['outputs']]==expected
 for row in result['outputs']:
  assert row['sha256']==plan['binding_refs'][str(J/row['name'])] and (J/row['name']).stat().st_size==row['bytes']
 index=load(J/expected[0]);work=load(J/expected[1])
 assert index['result']=='ASSEMBLY_METADATA_JOIN_WITH_EXPLICIT_PENDING_INPUTS' and index['publication_bundle_complete']is False
 assert index['component_rows']==2366 and index['profiles']==assembly['profiles'] and index['final_image_mapping']==assembly['final_image_mapping']
 assert index['base_component_index']==assembly['refs']['base_components'] and index['base_manifest']==assembly['refs']['base_manifest']
 base=load(assembly['refs']['base_components']['path'])
 assert [r['original_component'] for r in index['components']]==base
 assert work==dict(status='PROPOSED_NOT_COPIED',files=plan['files'],bytes=293582752,destination=assembly['copy_destination_proposed'],bounds=assembly['bounds'])
 assert plan['binding_refs'][str(J/'result.json')]==join['result_sha256']
 assert plan['binding_refs'][str(J/expected[0])]==join['index_sha256']
 assert plan['binding_refs'][str(J/expected[1])]==join['worklist_sha256']
 assert len(plan['binding_refs'])==40 and sum(Path(p).stat().st_size for p in plan['binding_refs'])<=32*1024**2
 return index

def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 plan=load(O/'collection-plan.json')
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h,name
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-source-assembly-supplement-20261015-01'
 prerequisites(plan)
 return plan

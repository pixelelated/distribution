# Exact39 source-custody successor — #528, SOURCE ONLY / UNRUN

This is a narrow derivative of the accepted Koko/Tailscale immutable copier. No preparer, collector, consumer, admission, runtime, payload hash/copy, archive reader, download, source generator, compiler or target was run during preparation. Only named metadata and source scripts were read. The source-file generation and static syntax/AST observations are recorded separately; those do not qualify this successor.

The reviewed metadata plan seal is773dff622bd42731ac2b19040c84dcac609fedc008ae1c5587b5ba06edc59d4e. Root subsequently completed its record-only join at coordinator run20261015T162920Z-33308c8a, all original command/monitor/runner0, helper PASS_METADATA_ONLY in0.336955s. Its exact result/index/worklist and watcher originals are bound in actual-join-binding.json. That run is not an admitted payload-copy run and has no invented consumption receipt. It wrote metadata only.

The fresh owner is `/workspace/tmp/pix-m7-source-assembly-custody-20261015-01`. The fresh destination is `/workspace/artifacts/pixelelated-release-sources/m7-source-assembly-supplement-20261015-01`. Both must be absent. The exact39 payload files total293,582,752 bytes: eight held FEX archives,13 already retained generated source files,13 selected header/notice contexts, and five ZeroTier filtered-source deliverables. Every source path, expected size/SHA256 and destination member is the unchanged copy_worklist in assembly-plan.json. No broad filesystem or source-cache inventory is needed. Source archives are copied as opaque bytes, never opened as archives. No header excerpt is represented as a complete missing licence text.

The copier adds five metadata files: the exact accepted source-assembly-index.json, exact original worklist, payload-member-index.json, metadata/original-status.json and manifest.json. Therefore success requires44 complete destination files. All39 payloads and both copied metadata files use the unchanged copy_file function: source digest before, streamed independent copy, copied digest, source digest after, with later independent consumer and admission destination verification. Source stat identities remain stable; copied inodes must differ. Full file modes become0444 and directories0555 only after the successful original copy/readback. Failure preserves original partial output and receipts; no automatic overwrite, cleanup deletion, retry or limit increase exists.

All2,366 original component rows remain byte-equivalent data in the copied historical index. The ZeroTier tar is only a pending new-image selection; it is not attributed to the old binaries. New GENERIC/H700/SM8550 image/input/inventory/acceptance mappings and a current distribution snapshot remain required. The old f863/9aa7 maps, FEX flat/NAR/patch identities, original producer failures and source-notice scope remain intact. ABL implementation/access, one MAME adaptation and named complete FEX licence texts remain explicit unresolved work; this copier does not create new permission or publication claims.

The accepted supervisor's process identity, signal masking, pidfd signaling, original wait capture, pipe draining, cleanup and receipt functions are unchanged. The process-identity helper is byte-identical. Only the profile label,39-file result checks and explanatory scope change in run.py. The existing outer runner changes only its per-file RLIMIT_FSIZE from64MiB to192MiB, necessary for the known152,673,392-byte held archive. The collector's copy_file/Writer and common writing/identity primitives remain AST-identical. No new runtime framework or controls are added.

Resource contract:384MiB destination;64MiB owner with48MiB normal collector share,16MiB supervisor reserve and at most1MiB failure receipt drawn from that reserve;192MiB per file;64 output files;16 directories;4KiB paths;512MiB retention reservation. The child work bound stays300s, soft270s; outer330s plus15s kill allowance, two CPU affinity slots and2GiB address space are unchanged. Larger per-file RLIMIT does not expand either aggregate allowance: the copier accounts before each write, supervisor JSON is bounded to8MiB total and each child stream to256KiB.

The2GiB accounted copy/readback allowance is split into1280MiB collector reads,384MiB success-consumer reads and384MiB for the ordinary admission evidence rehash. The collector retains copy_file's just-verified destination digest instead of adding a redundant fifth payload pass; its before/copy/after/source-after checks are unchanged. The consumer hashes each destination once and reuses that digest in evidence; ordinary build-admission then independently hashes those files again. The receipt includes the admission evidence-byte upper bound, two pending receipt allowances and16MiB control-metadata margin. Preparation checks a conservative collector upper bound using the actual join sizes and refuses above1280MiB. Preparers and supervisor inspect bounded metadata separately; no archive body is read there. The joined index remains separate from the39 source/notice payload count.

Use the same frozen f863 control checkout and its exact ordinary tool digests as accepted Koko custody: `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02`. This is the execution-control identity, not the future product-image identity. No build-cache content is needed from that checkout. The successor cannot run while another admission remains unconsumed. The coordinator's newer tool must not substitute for the frozen ordinary admission tool, and #597 recovery is not used.

After root review and serialized allocation, supply the actual join inputs explicitly:

```bash
export TASK_JOIN_OWNER=/workspace/tmp/pix-m7-final-source-assembly-index-20261015-01
export TASK_JOIN_RUN=/workspace/repos/rocknix.worktrees/m7-player-setup/.build-runs/20261015T162920Z-33308c8a
export TASK_JOIN_INDEX_SHA=a42af9af00d7b1da894253a59ba8b745ba4c67a03fe6e829ef7cf10d6dc25bed
export TASK_JOIN_WORKLIST_SHA=cb6fa010bc3138d7bca3ed42a91466f14302438e97c8818b4cfd2bf283aa782e
export TASK_JOIN_RESULT_SHA=e75f04342b9b2ab163d11f2961464d7d57495df0cc1ebf433a3b69342d3768fc
bash /tmp/pix-m7-source-assembly-custody-plan-20261015/commands.sh prepare
bash /tmp/pix-m7-source-assembly-custody-plan-20261015/commands.sh preflight
bash /tmp/pix-m7-source-assembly-custody-plan-20261015/commands.sh report
# Root reads preparation/preflight/retention results before admission.
bash /tmp/pix-m7-source-assembly-custody-plan-20261015/commands.sh admit
bash /tmp/pix-m7-source-assembly-custody-plan-20261015/commands.sh launch
# Only after original completion and inspection:
bash /tmp/pix-m7-source-assembly-custody-plan-20261015/commands.sh consume
```

These known join hashes are also fixed in the bindings; arbitrary caller values cannot select another result. Preparation requires the actual original successful watcher result, exact pending-copy worklist and complete original component-row equality. Root supervises at most60seconds apart. Submission is not completion; missing/nonzero channels, signals, timeouts, failed cleanup or survivors refuse success. Failed work retains its originals and requires ordinary investigated disposition.

Success is a local independent copy with explicit gaps, not a final source bundle, independent retrieval, off-host transfer/restore, legal clearance, target execution or release-candidate designation. The39 payload files will be newly read only during the separately admitted copy; no payload or archive body was inspected while writing this proposal.

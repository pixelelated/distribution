#!/usr/bin/env python3
"""Prepare the exact39-file successor after the original metadata join; never read payload bodies."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy
P=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 q=argparse.ArgumentParser(description=__doc__)
 q.add_argument('--owner',type=Path,required=True)
 q.add_argument('--join-owner',type=Path,required=True)
 q.add_argument('--join-run',type=Path,required=True)
 for n in ['index','worklist','result']:q.add_argument('--join-'+n+'-sha256',required=True)
 a=q.parse_args();names=[]
 for line in (P/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);p=P/n;assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h;names.append(n)
 assert len(names)<=128 and sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
 B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']();assert Path.cwd()==B['VM_TREE']
 O=a.owner;assert O==Path('/workspace/tmp/pix-m7-source-assembly-custody-20261015-01') and O.parent.resolve(strict=True)==O.parent
 assert not O.exists() and not O.is_symlink()
 D=Path('/workspace/artifacts/pixelelated-release-sources/m7-source-assembly-supplement-20261015-01');assert D.parent.resolve(strict=True)==D.parent and not D.exists() and not D.is_symlink()
 J=a.join_owner;run=a.join_run
 assert J.resolve(strict=True)==J and not J.is_symlink() and run.resolve(strict=True)==run and not run.is_symlink()
 for value in [a.join_index_sha256,a.join_worklist_sha256,a.join_result_sha256]:assert re.fullmatch('[0-9a-f]{64}',value)
 assert dict(owner=str(J),run=str(run),index_sha256=a.join_index_sha256,worklist_sha256=a.join_worklist_sha256,result_sha256=a.join_result_sha256)==B['ACTUAL_JOIN']
 assembly=json.loads((P/'assembly-plan.json').read_text())
 refs={r['path']:r['sha256'] for r in assembly['refs'].values()};assert len(refs)==35
 expected={J/'source-assembly-index.json':a.join_index_sha256,J/'missing-custody-worklist.json':a.join_worklist_sha256,J/'result.json':a.join_result_sha256}
 for p,h in expected.items():assert p.is_file() and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h
 for p in [run/'runner-result.json',run/'build.rc']:
  assert p.is_file() and not p.is_symlink() and p.stat().st_size<1024**2;expected[p]=sha(p)
 refs.update({str(p):h for p,h in expected.items()});assert len(refs)==40
 for name,h in refs.items():
  p=Path(name);assert p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<16*1024**2 and sha(p)==h
 assert sum(Path(n).stat().st_size for n in refs)<=32*1024**2
 metadata_copies=sum((J/n).stat().st_size for n in ['source-assembly-index.json','missing-custody-worklist.json'])
 scheduled_read_upper=4*(293582752+metadata_copies)+2*sum(Path(n).stat().st_size for n in refs)+8*1024**2
 resources=json.loads((P/'resources.json').read_text());assert scheduled_read_upper<=resources['total_read_bytes'],'actual join exceeds1280MiB collector share; no automatic increase'
 plan=dict(schema=1,scope='Exact39 held files and completed historical metadata join, independently copied without archive opening, new-image attribution or publication clearance.',
  assembly_plan_path=str(P/'assembly-plan.json'),files=assembly['copy_worklist'],metadata_refs=assembly['refs'],binding_refs=refs,
  join=dict(owner=str(J),run=str(run),index_sha256=a.join_index_sha256,worklist_sha256=a.join_worklist_sha256,result_sha256=a.join_result_sha256),
  final_image_mapping=assembly['final_image_mapping'],unresolved=assembly['pending_source_questions'],scheduled_collector_read_upper_bytes=scheduled_read_upper)
 B['prerequisites'](plan)
 O.mkdir(mode=0o700);(O/'stage').mkdir(mode=0o700);(O/'empty-retention-scan').mkdir(mode=0o700)
 written=0;count=0
 def raw(n,b):
  nonlocal written,count
  assert len(b)<=4*1024**2 and written+len(b)<=8*1024**2 and count<64 and not (O/n).exists();written+=len(b);count+=1
  with (O/n).open('xb') as f:f.write(b)
 def put(n,obj):raw(n,(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode())
 for p in sorted((P/'templates').iterdir()):raw(p.name,p.read_bytes())
 for n in ['resources.json','frozen-tools.json','assembly-plan.json']:raw(n,(P/n).read_bytes())
 plan['assembly_plan_path']=str(O/'assembly-plan.json')
 put('collection-plan.json',plan);put('destination.json',dict(path=str(D)))
 put('preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),pid_namespace=os.readlink('/proc/self/ns/pid'),user_namespace=os.readlink('/proc/self/ns/user'),uid_map=Path('/proc/self/uid_map').read_text(),gid_map=Path('/proc/self/gid_map').read_text(),join=plan['join'],collector_executed=False,payload_bodies_read=False,publication_clearance=False))
 put('retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=['/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources','/workspace/artifacts/pixelelated-build-inputs',str(J),*[r['source_path'] for r in plan['files']]],candidates=[],builds=[dict(name='m7-source-assembly-custody',terms_bytes={'exact39_custody_and_margin':512*1024**2},basis='384MiB destination plus64MiB owner within512MiB retention reservation;39 held inputs293582752B. No archive/cache scan, acquisition, deletion or new image claim.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json')),dict(path=str(O/'collection-plan.json'),sha256=sha(O/'collection-plan.json'))])]))
 put('admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-source-assembly-custody',profiles=[dict(PROJECT='ROCKNIX',DEVICE='GENERIC_X64',ARCH='x86_64')],outputs=[dict(path=str(path),kind='qa-scratch',issue=528,release_when='Only after original run consumption and explicit independent custody/retrieval disposition; never delete corresponding-source originals automatically.') for path in [O,D]]))
 put('seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()});B['verify'](O)
 print(json.dumps(dict(owner=str(O),custody=str(D),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),scheduled_collector_read_upper_bytes=scheduled_read_upper,publication_clearance=False)))
if __name__=='__main__':main()

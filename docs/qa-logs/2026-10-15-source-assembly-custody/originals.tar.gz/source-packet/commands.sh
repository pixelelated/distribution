#!/bin/bash
# UNRUN. Root reviews the seal and supplies exact completed join originals.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-source-assembly-custody-plan-20261015
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=/workspace/tmp/pix-m7-source-assembly-custody-20261015-01
cd "$TASK_TREE"
case "${1:?prepare, preflight, report, admit, launch, or consume}" in
 prepare)
  : "${TASK_JOIN_OWNER:?actual completed metadata-join owner}"
  : "${TASK_JOIN_RUN:?actual original record-only watcher run}"
  : "${TASK_JOIN_INDEX_SHA:?actual source-assembly-index SHA256}"
  : "${TASK_JOIN_WORKLIST_SHA:?actual missing-custody-worklist SHA256}"
  : "${TASK_JOIN_RESULT_SHA:?actual original result SHA256}"
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-owner.py" --owner "$TASK_OWNER" --join-owner "$TASK_JOIN_OWNER" --join-run "$TASK_JOIN_RUN" --join-index-sha256 "$TASK_JOIN_INDEX_SHA" --join-worklist-sha256 "$TASK_JOIN_WORKLIST_SHA" --join-result-sha256 "$TASK_JOIN_RESULT_SHA" ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json" ;;
 admit) python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json" ;;
 launch) env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh" ;;
 consume) python3 -I "$TASK_OWNER/consume.py" ;;
 *) exit 2 ;;
esac
# Root reviews preparation/preflight/report before admission and supervises <=60s.
# Submission is not completion. Failures retain originals and require investigation.

from pathlib import Path
import hashlib,json,datetime
O=Path('/workspace/tmp/pix-m7-source-assembly-custody-20261015-01')
P=Path('/tmp/pix-m7-source-assembly-custody-plan-20261015')
R=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T163942Z-6041fb99')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
j=lambda p:json.loads(Path(p).read_text())
assert h(P/'SHA256SUMS')=='bcf550ae1250d2f5b199f17fcc16b603467162ca80ec0c74c6ee5169c9c7206c'
source_count=0
for line in (P/'SHA256SUMS').read_text().splitlines():
 sha,name=line.split('  ',1);assert h(P/name)==sha;source_count+=1
for path,digest in j(O/'seal.json').items():assert Path(path).is_relative_to(O) and h(path)==digest
for name in ['bindings.py','collect.py','consume.py','process-identity.py','run.py','run.sh']:assert h(O/name)==h(P/'templates'/name)
rr=j(R/'runner-result.json');cons=j(R/'admission-consumed.json');ev=j(O/'admission-completion-evidence.json');result=j(O/'result.json');cr=j(O/'collection-result.json');read=j(O/'custody-readback.json');clean=j(O/'cleanup.json');child=j(O/'stage/association.result.json')
assert (rr['command_rc'],rr['monitor_rc'],rr['runner_rc'])==(0,0,0)
assert cons['original_result']==rr and cons['state']=='consumed' and cons['id']=='7f9891f258114e748581402347d7eaae' and cons['source']['head']=='f8636de1d105275dbf9420bbabbbc26f79abb10f' and cons['pid_namespace']==4026531836
assert cons['evidence_sha256']==h(O/'admission-completion-evidence.json') and cons['run']==str(R) and cons['submission_owner']==str(O)
assert j(O/'launcher-result.json')['runner_returncode']==0
for p in [O/'tool-wrapper.rc',O/'inner.rc',O/'outer.rc',O/'stage/association.exit',R/'build.rc']:assert p.read_text()=='0\n'
assert child['original_child_returncode']==0 and child['wait_observed'] and child['qualification'] and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
assert clean['all_recorded_identities_absent'] and not clean['direct_child_unreaped'] and all(not clean[k] for k in ['errors','receipt_errors','recorded_identities_still_present','signals_sent','survivors_after_cleanup'])
assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['execution_error'] is None and all(not result[k] for k in ['cleanup_errors','interrupted_signals','receipt_errors','publication_bundle_complete','independent_SYSTEM_relation_established'])
assert cr['payload_files']==39 and cr['metadata_files']==5 and cr['payload_bytes']==293582752 and len(cr['files'])==44
assert sum(x['bytes'] for x in cr['files'][:39])==293582752
assert cr['original_collector_exit']==0 and cr['read_bytes']==1231633932 and cr['manifest_sha256']=='022b44b19fc23da08b2a158f3ba92689f494581118f1726ff6d39e60ea04bea0'
assert read['status']=='PASS_EXACT39_LOCAL_CUSTODY_WITH_GAPS' and read['destination_files']==44 and read['combined_read_upper_bytes']<=read['combined_limit_bytes']
dest=Path(cr['custody_path']);skipped=[];verified=[]
for e in ev['evidence']:
 p=Path(e['path'])
 if p.is_relative_to(dest):skipped.append(e);continue
 assert p.is_file() and p.stat().st_size<8*1024**2 and h(p)==e['sha256'];verified.append(e)
assert len(skipped)==44
by_path={x['path']:x['sha256'] for x in cr['files']};assert all(by_path[e['path']]==e['sha256'] for e in skipped)
prior=[]
for name in ['20261015T163840Z-28976996','20261015T163905Z-ae6e38b2']:
 r=R.parent/name;x=j(r/'runner-result.json');assert (x['command_rc'],x['monitor_rc'],x['runner_rc'])==(0,0,0) and (r/'build.rc').read_text()=='0\n';prior.append({'run':str(r),'original_result':x})
receipt={'status':'PASS_COMPACT_ORIGINAL_RECORDS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_seal':h(P/'SHA256SUMS'),'source_payloads':source_count,'run':str(R),'original_result':rr,'launcher_returncode':0,'consumed_sha256':h(R/'admission-consumed.json'),'consumed_id':cons['id'],'preparation_and_retention_runs':prior,'verified_compact_evidence':verified,'destination_payload_evidence_not_rehashed_here':skipped,'source_archive_or_destination_payloads_opened':0,'manifest_sha256_recorded':cr['manifest_sha256'],'scope':result['scope'],'publication_bundle_complete':False,'publication_clearance':False}
(Path(__file__).parent/'record-readback.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'verified_compact_references':len(verified),'held_destination_files_excluded':len(skipped),'receipt_sha256':h(Path(__file__).parent/'record-readback.json')}))

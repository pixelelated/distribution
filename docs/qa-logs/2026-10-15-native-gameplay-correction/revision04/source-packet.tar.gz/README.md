# Revision04 — bounded live profile readback, source only, UNRUN

This additive packet is `/tmp/m7-native-gameplay-lifecycle-20261015-03`. Revision03 at `/tmp/m7-native-gameplay-lifecycle-20261015-02` and the already prepared owner02 remain unchanged. Root must prepare a new owner from this packet; no preparation or runtime occurred here.

`revision04-profiles.diff` changes only `guest.py`: the existing `status` response now includes `profiles`. The unchanged `host-action.py status --owner ACTUAL_OWNER` operation obtains and prints it through the existing sole-operator `serial.lock`, original serial result marker, and retained host invocation stdout. There is no second serial path, new input command, acceptance criterion, or timer.

The fixed allowlist returns live GCPadNew.ini and WiimoteNew.ini; Flycast SDL_Keyboard.cfg, SDL_Xbox 360 Controller.cfg and its sdl_joystick_0 instance, plus the equivalent raw QA521 name variants; and actual control.ini. Each row records existence, resolved path, bytes, SHA-256 and observed text. A fresh positive raw/sysfs/owned-pad/controller identity accompanies control.ini. Missing profiles or mappings are explicit; a missing disk mapping does not prove Flycast's compiled defaults. The operator still reviews actual launcher/engine observations and existing mapping criteria before input.

Flycast emu.cfg is read only within a 64-KiB local parse. Its raw text is never returned: only the explicit AutoLoad/AutoSave and rendering keys in the static review appear, with absent values as null. Account sections/values are excluded by positive key selection. Mapping/profile files are capped at 8 KiB, control.ini at 4 KiB, returned file bytes at 64 KiB, and the resulting profile JSON at 96 KiB. A readback receipt is retained in guest evidence. These are live byte observations and may race an engine write; they do not claim atomic snapshots.

Root can call status after launch and before any controller action, and again after each observed setting/profile change. Existing host-action stdout exposes the values while the guest is running, allowing the original profile-review criterion to be fulfilled. Gameplay/save/frame criteria, controller constructor and actions, the 1800-second family, 120-second cleanup/first-frame bounds, and 360-second scoring window are unchanged.

Only AST/source-flow checks were performed. `revision04-static-review.json` binds unchanged helpers and limits; `revision03-SHA256SUMS` preserves the parent seal. Earlier source/static/failed-original records remain historical. No fixture or preparer was imported/executed, and no VM, service, controller, compiler, admission, or prepared owner was changed.

---

The complete earlier procedure and criteria follow as historical detail. Revision04 above governs the new source packet and observability addition; root must bind a fresh owner.

# Revision03 — source-only fixture correction, UNRUN

Use this packet at `/tmp/m7-native-gameplay-lifecycle-20261015-02`; the prior packet and actual failed owner remain unchanged. `revision03-fixture.diff` is the entire executable change: only `guest.py` and one existing finally-flush command in `vm-lifecycle.py`. The preparer, pad constructor/capabilities/mappings, supervisor, host action/export helpers, full lawful fixture, gameplay/save/state criteria, 1800-second family, 120-second cleanup, 120-second first frame, and 360-second scoring window remain unchanged.

The actual failed 20261015-01 owner stopped during provision, before ES restart or any game launch. Normal production `control-gen.cpp` uses `SDL_JoystickName` and returned `param_device="Xbox 360 Controller"`, with GUID `030080a15e0400008e02000014010000`. Requiring the raw kernel uinput name in that generated SDL output was the fixture defect. The corrected assertion requires this exact observed SDL name/GUID and, separately, a live child pad process belonging to the recorded supervisor, its `/dev/uinput` descriptor, exactly one virtual kernel event with raw name `QA521 Synthetic Xbox 360 Controller`, bus/vendor/product/version `0003:045e:028e:0114`, and matching sysfs/device-node major:minor. `controller-identity.json` will retain those positive observations before ES restart. An arbitrary name or controller cannot satisfy the assertion.

The existing supervisor already aborts and destroys its pad in `finally`. The new internal guest cleanup operation writes its existing abort marker, waits at most 12 seconds for the recorded supervisor identity to disappear, then requires the original supervisor/pad results, absent pad identity, and one actual `destroyed` event. It records failed original pad/supervisor exits without replacing them. The existing 30-second host finally-flush call invokes this before unmount, inside the unchanged whole 120-second cleanup budget. A failed cleanup refuses the unmount step and remains a cleanup error; the existing exact-QEMU stop follows. This is source review, not a claim that cleanup has run.

`failed-originals/` preserves the coordinator's actual failed export, including original archive, recovered guest files, review and consumption evidence. Its missing guest export manifest and busy-unmount result remain limitations: those recovered files are best-effort originals, not qualified lossless guest export. No failed result was rewritten. `prior-README.md`, `prior-SHA256SUMS`, source bindings and earlier diffs retain historical context. Their previous dates and UNRUN/source labels are not fresh runtime claims.

Root may later run the unchanged preparer using the actual completed readback `/workspace/tmp/pix-m7-image-readback-20261015-01/artifacts` and frozen checkout `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01`, source `d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a`, branch `build/m7-p5-20261015-01`, the original authored CDI owner and a newly allocated unique owner/free display. This packet does not create them or reserve a guest. The detailed original procedure/criteria below remain unchanged. All Python files were parsed only; no preparer, fixture, VM, controller, service, or compiler ran.

---

The following original README is retained verbatim as historical detailed procedure and acceptance criteria. Its old source/output example locators are superseded by Revision03 above; its gameplay criteria and budgets are unchanged.

# Installed native gameplay and ordinary-save continuation — UNRUN

Revision02 targets the frozen `fac608ff89940ce358ea9b8a95e9a08a6fe26568`
checkout `m7-p5-build-20261014-02`. Actual final-image readback remains pending.
The source-only verifier is `/tmp/pix-m7-gstnet-image-verifier-20261014`; supply
its eventual completed **output directory**, containing `result.json` and
`inputs.json`, as `--verification`, not that source directory. No image hash is
invented here. Preparation requires checkout HEAD, both verifier source fields
and identity build commit to agree; the current full ES recipe pin must match
both verifier ES identities. It refuses a dirty/non-build checkout or an image
from another checkout. All runtime code, input mapping, cases and bounds are
unchanged. The 15 source-bound launch/config/control files match the original
d6a packet exactly; `revision02-source-continuity.json` records those identities.
Original `source-bindings.json`, fixture provenance and older diffs remain
historical d6a records, not claims that a new guest ran. Only `prepare.py` changes
executable behavior; `revision02-prepare.diff` is the complete executable diff.

The already authored Tetris2 CDI remains 740,202,281 bytes, SHA256
`e4ff051cccb1f37d1260edaf9a6b57257e51b8c920f92bb4319db73ca04197d7`.
Preparation checks that exact identity against the successful original author
receipt and file bytes. There is no compiler, disc authoring or completed-case
replay in this adaptation. GStreamer retention is the only product delta;
the host selected-state checker and its controls also changed between source
heads and are recorded separately in the continuity receipt.

Source-only preparation, 2026-10-14. No program in this packet has been imported or
run. No emulator, VM, controller, compiler or allocation was started. This is the
existing #575/#581 continuation; it does not add a release criterion. Can this be
done on the VM? Yes: one fresh final-image no-NIC guest,8GiB/4CPU, one native engine
at a time, root as the sole serial/HMP/input/frame operator.

The complete family is1800s with120s cleanup, including boot and provisioning.
Each launch has120s to capture its first observed interactive game frame. The
supervisor enforces that capture deadline; root must actually view/review the
frame before claiming first interactive play. These are observed upper bounds,
not automatic first-render detection. Tetris scoring gets a single360s clock;
presses are refused after it until score-end records the result. No timer resets,
fixed blind game navigation or automatic retry. Guest evidence448MiB plus host
frames64MiB gives512MiB; the immutable authored disc and initial SD input are
separate. Snapshot only the needed states/configs and two quiescent SD witnesses.

## Inputs and existing ownership

`fixture/` is the unchanged fcc9783c packet (inner seal b76c627e), including licenses,
exact ordinary-save semantics and bounded helpers. It remains the authority on
what these lawful games can prove. SuDokuL Wii ordinary save is SD
`/apps/SuDokuL/save.bin`; it is not NAND or a GC memory-card test. Tetris2 ordinary
save is inner VMU file`tetris2.sys` on actual A1. No game source or score is edited.

The accepted tool owner is now complete/consumed. Actual CDI:
`/workspace/tmp/pix-m7-mkdcdisc-20261014-01/artifacts/Tetris2-M7.cdi`,740202281bytes,
SHA256`e4ff051cccb1f37d1260edaf9a6b57257e51b8c920f92bb4319db73ca04197d7`.
Preparation still reads and binds the actual author work/owner receipts and CDI
bytes. It also binds the completed final image verifier dynamically, including
SYSTEM/source/ES. No predicted image name is used. Initial128MiB SD creation runs
only inside the later allocated owner, through unchanged prepare-wii-sd.sh.

The outer lifecycle/media/serial/process census/stop/export is a minimal derivative
of `/tmp/m7-installed-native-lifecycle-20261014` (f10d5ba9), with the accepted #566
post-lock visual handoff. It does not rerun hash/codec controls or clean588.
`consumed-paths.txt` is the exact added native/input scope. Guest hashes existing
verifier rows against that receipt. Other listed installed bytes are recorded
with final image/SYSTEM/BUILD_ID, not relabeled source-to-final comparisons.
Frozen launcher/profile source bindings and relevant source lines are retained
in source-bindings.json. frozen-config-bindings.json compares seven newly consumed
launcher/config bytes with exact frozen source (Flycast renderer placeholder4 is
the recipe transformation; the per-game fixture still explicitly chooses OpenGL0). Existing final verifier is not reopened.

## Controller route, with source-bound labels

`virtualpad-original.py` is the accepted Oct08 DuckStation QA521 Xbox constructor
and its historical capture-only loop. Do not execute that historical script.
`pad.py` preserves the exact constructor/name/USB IDs/capabilities and only replaces
its command loop with bounded named press/release/destroy. Original acceptance:
coordinator `docs/qa-logs/2026-10-08-save-repair-cases/duckstation-captures/vm-ui/README.md`
and `receipts/native01/virtualpad.py` (native SDL-0 Guide+B capture, actual destroy).
No host device is created. Final shipped SDL DB has Linux GUID
`030000005e0400008e02000014010000`, Xbox360 version0114. Normal control-gen and
launcher-generated profiles remain in use; no keyboard-to-gamepad assumption.

| Named guest action | Linux event | Normal Wii nogui profile | Flycast Dreamcast default |
|---|---|---|---|
| a | BTN_SOUTH304 | GameCube A | Dreamcast A |
| b | BTN_EAST305 | GameCube X | Dreamcast B |
| x | BTN_NORTH307 / SDL X | GameCube B | Dreamcast X |
| y | BTN_WEST308 / SDL Y | GameCube Y | Dreamcast Y |
| start | BTN_START315 | Start/pause | Start |
| rb | BTN_TR311 | Z/save-and-quit in SuDokuL pause | native SDL shoulder |
| back | BTN_SELECT314 | default native hotkey modifier | Flycast menu |
| lt / rt | ABS_Z2 / ABS_RZ5=255 | native load/save selected slot | triggers |
| up/down/left/right | ABS_HAT0Y17 / X16 | D-pad | D-pad |

Every action releases all pressed controls after40–1000ms and logs claim/ack.
Two-button chords are allowed; the sole three-button chord is `lb,back,start`,
the shipped input_sense exit route (BTN_TL+SELECT+START). That route can SIGKILL a
native engine; keep it separate from Dolphin's Back+Start normal RequestShutdown
and Flycast's observed native-menu orderly exit. Never claim SIGKILL flushed
native automatic states. Flycast menu Save/Load/Exit navigation must be chosen from
actual reviewed frames. Do not substitute a guessed keyboard shortcut: shipped
SDL_Keyboard.cfg has only emulator shortcuts and its exact bytes are retained.

Before native gameplay, retain `control.ini`, actual engine argv/SDL logs, and
snapshot the launcher-generated GCPadNew.ini/WiimoteNew.ini or Flycast mappings.
Require the actual device resolves to the guest QA521 controller, with Wii
Buttons/A=`Button S`, B=`Button W`, Z=`Shoulder R`, hotkey=Back. If actual mapping
or displayed UI differs, stop and report it. The source map is not runtime proof.

Dolphin's Wayland nogui loop starts at slot0. `back,up` selects1; observe the native
slot notification. `back,rt` saves, alter a visible game scene, `back,lt` loads.
These are the analog-trigger nogui bindings; Qt uses a different Hotkeys.ini.
Flycast's Back menu uses actual native Save/Load slot controls. Save-state files
and ordinary game-save bytes remain distinct.

## Prepare and allocate later

Run only after the current owner is closed and root allocates this guest. Use an
observed-free VNC display and a fresh owner;126 below is an example, not a claim.
All host namespace/workspace calls require the same actual-host access as the
accepted lifecycle. `prepare.py` creates logs before watcher submission.

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261014-02
TASK_PACKET=/tmp/m7-native-gameplay-lifecycle-20261014-02
TASK_VERIFY=/workspace/tmp/ACTUAL_FINAL_READBACK_OWNER/verification
TASK_OWNER=/workspace/tmp/pix-m7-native-gameplay-20261014-02
python3 -I -S -B "$TASK_PACKET/prepare.py" \
  --checkout "$TASK_TREE" --verification "$TASK_VERIFY" \
  --author-owner /workspace/tmp/pix-m7-mkdcdisc-20261014-01 \
  --owner "$TASK_OWNER" --vnc 126
cd "$TASK_TREE"
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

Wait for actual`visual-ready.json`; the original family clock continues. The
normal installed essway service is stopped for disposable settings/ROM seeding,
then restarted with the pad already present. Full ES POST/launch on127.0.0.1:1234
queues ViewController::launch, then actual runemu/start_dolphin_wii/start_flycast.
The prepared settings choose Dolphin/dolphin-sa-wii and Flycast/flycast-sa,
OpenGL, global.autosave0, native Flycast AutoLoad/AutoSave off. Wii literal
write_protect_configs=false is only disposable fixture state; original files
are preserved, then the whole guest is retired. Product defaults stay unchanged.

## Observed operations under one shared lock

Every command below acquires the same owner/serial.lock as lifecycle. Never call
vm-serial, HMP or input directly beside it. Each ambiguous action is retained and
must not be replayed automatically. Output frame path is unique; view it with the
normal local image viewer, then add a review of what was actually visible.

```bash
python3 -I -S -B "$TASK_OWNER/host-action.py" status --owner "$TASK_OWNER"
python3 -I -S -B "$TASK_OWNER/host-action.py" launch --owner "$TASK_OWNER" --game wii
python3 -I -S -B "$TASK_OWNER/host-action.py" capture --owner "$TASK_OWNER" --label wii-first --first-frame
# View the emitted PNG, then bind the actual observation:
python3 -I -S -B "$TASK_OWNER/host-action.py" review --owner "$TASK_OWNER" --label wii-first --review 'ACTUAL OBSERVATION'
python3 -I -S -B "$TASK_OWNER/host-action.py" pad --owner "$TASK_OWNER" --buttons a --milliseconds 120
python3 -I -S -B "$TASK_OWNER/host-action.py" snapshot --owner "$TASK_OWNER" --label wii-running
```

The example A press is a primitive, not an approved blind sequence. Capture each
needed role with its own label. `key --key start|a|b|up|down|left|right` uses the
actual copied ES keyboard map and refuses while a native engine exists. That is
for ES manager/return UI only. Native actions use pad. `status` retains actual
native PID/start/argv and HTTP runningGame; process-observations samples native
presence every second. Snapshot before another launch because exec.log resets.

1. Wii: observe title and interactive puzzle within120s. Enter one legal visible
   editable-cell value, record puzzle/row/column/value. Start pauses; rb is Z Save
   and Quit. Then `back,start` requests orderly native shutdown. Observe native
   absence and ES return; capture/review returned UI, snapshot `wii-saved` with
   `--copy-sd`. Relaunch `--game wii`, capture a new `--first-frame`; do not load
   a native state. Play/Continue must restore the same changed cell and puzzle.
   Separately perform observed slot1 manual save/change/load. Preserve actual
   StateSaves link, file names/hashes and restored frame. No GC card inference.
2. Dreamcast: launch `--game tetris2`, capture/review first interactive frame.
   Use actual menu Save→observed A1→A to establish card. Begin1Player/Normal.
   Immediately before earning points, run `score-start`. Use short observed
   Down holds/releases, Left/Right distribution and A rotation. Source grants
   +1 successful down-cell and+10 landing. Earn at least110, gameover, inspect
   new Highscore/name entry, explicit Save→A1→A. Run `score-end` within360s and
   bind reviewed earned-score frame. Do not seed a score. If impractical, stop
   scoring at the bound and retain actual VMU creation/reopen separately from
   unproved earned-score persistence. Cold relaunch native AutoLoad off; ordinary
   VMULoad must restore the observed earned entry. Native manual state remains a
   separate observed menu Save/change/Load operation.
3. Existing global/native-auto cases: with engines stopped, `global-auto --value
   0|1` changes global.autosave and restarts installed ES; observe both with native
   Flycast AutoLoad/AutoSave off. `native-auto --value 0|1` changes only those two
   native options while engine stopped; with global0, observe orderly unload and
   automatic restoration when enabled. Capture native file inventory each time.
   Do not infer native automatic behavior from ES global setting. Use exact game
   settings/core readback and returned UI, including absent RetroArch-only manager.
4. Record normal ES return and next observed first frame timestamps for existing
   time-to-play scope. Frame timestamps plus1s native-presence sampling are the
   actual measurement resolution; this packet does not call a title transition
   the first gameplay frame or claim the RetroArch-specific time-to-play tool ran.

After each launch, review the actual generated profiles/logs before using their
controls. GUI gameplay/menu choices remain root-owned observed decisions.

## Finish, original results and export

After actual engines are absent and required reviewed evidence is collected:

```bash
python3 -I -S -B "$TASK_OWNER/host-action.py" finish --owner "$TASK_OWNER"
# Wait for the original watcher/runner/launcher and VM owner to finish.
TASK_RUN="$TASK_TREE/.build-runs/ACTUAL_RETURNED_RUN_ID"
TASK_EXPORT=/workspace/tmp/pix-m7-native-gameplay-evidence-20261014-02
python3 -I -S -B "$TASK_OWNER/close.py" --owner "$TASK_OWNER" \
  --run "$TASK_RUN" --packet "$TASK_EXPORT"
```

Finish takes final quiescent SD/config/state/log snapshot, requests pad destroy,
waits actual supervisor disappearance, manifests closed guest bytes, releases
serial, then atomically hands ownership back. Lifecycle unmounts/flushes and stops
exact QEMU pid; host exporter rehashes stopped ext4 originals and all host channels.
Coordinator independently reviews, consumes admission and retires owned vm/media.
The VM/result0 only means lifecycle success; it never automatically checks off
ordinary save/gameplay/frame criteria. Use abort with a concrete reason after a
failed/ambiguous observation; preserve original failure, no fresh owner retry.

Actual ES/launcher logs and return path are separate from native process
observations. Native engines are children of the unchanged installed launchers;
cleanup can mask engine exit. Therefore native original status is explicitly
unknown unless an existing original log provides it. No shim, ptrace, invented
exit0 or backend bypass is introduced. The packet retains real input/supervisor,
phase/helper/HTTP, lifecycle/transport and watcher/runner/launcher originals.

For Wii ordinary-save inspection use the unchanged fixture's mdir/mcopy commands
on the exported quiescent SD (under a subsequent admitted small read operation if
required by the current allocation). Keep original SD and extracted save bytes.
All ordinary-save/source/licenses details are in fixture/README.md.

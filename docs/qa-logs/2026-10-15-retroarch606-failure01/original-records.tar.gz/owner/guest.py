#!/usr/bin/python3
"""#606 selected guest observations/actions. CONFIG, OP and ARG are supplied inline."""
import base64,hashlib,json,os,re,resource,selectors,shlex,signal,stat,subprocess,time,urllib.request,xml.etree.ElementTree as ET
from pathlib import Path
R=Path('/tmp/pix606');ROM=Path('/storage/roms/gb/ExitProbe.gb');STATES=Path('/storage/roms/savestates/gb')
result={'status':'FAIL','operation':OP,'commands':[],'cleanup_errors':[]};raw_commands=[];output_bytes=0
# Qualified bounded command/wait/output mechanics copied from the parent guest.
def require(ok,code):
    if not ok:raise RuntimeError(code)

def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def command(argv,seconds=10,readiness=False):
    global output_bytes
    require(len(raw_commands)<32,'command-count-bound')
    row={'argv':argv,'timeout_seconds':seconds,'original_returncode':None,'timed_out':False,'output_limit':False,'readiness':readiness};child=None;parts={'stdout':bytearray(),'stderr':bytearray()}
    try:
        child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        end=time.monotonic()+seconds
        with selectors.DefaultSelector() as mux:
            for key,stream in [('stdout',child.stdout),('stderr',child.stderr)]:os.set_blocking(stream.fileno(),False);mux.register(stream,selectors.EVENT_READ,key)
            while mux.get_map():
                if time.monotonic()>=end:row['timed_out']=True;raise TimeoutError('child-timeout')
                for event,_ in mux.select(min(.1,max(0,end-time.monotonic()))):
                    b=os.read(event.fd,8192)
                    if not b:mux.unregister(event.fileobj);continue
                    if len(parts[event.data])+len(b)>65536 or output_bytes+len(b)>256*1024:
                        row['output_limit']=True;raise RuntimeError('child-output-bound')
                    parts[event.data].extend(b);output_bytes+=len(b)
            row['original_returncode']=child.wait(timeout=max(.01,end-time.monotonic()))
        if not readiness:require(row['original_returncode']==0,'child-exit-nonzero')
        return bytes(parts['stdout'])
    finally:
        if child:
            try:
                if child.poll() is None:
                    os.killpg(child.pid,signal.SIGKILL);row['forced_cleanup']=True
                row['original_returncode']=child.wait(timeout=5)
            except BaseException as exc:
                row['cleanup_error']=type(exc).__name__+': '+str(exc)
                result['cleanup_errors'].append('child-original-wait-incomplete')
            finally:child.stdout.close();child.stderr.close()
        original=dict(row,stdout_b64=base64.b64encode(parts['stdout']).decode(),stderr_b64=base64.b64encode(parts['stderr']).decode())
        raw_commands.append(original);result['commands'].append(row)

def put(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def bounded(p,limit=2*1024**2):
    p=Path(p);s=p.stat();require(stat.S_ISREG(s.st_mode) and s.st_size<=limit,'file-bound:'+str(p))
    with p.open('rb') as f:b=f.read(limit+1)
    a=p.stat();require(len(b)==s.st_size and (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns),'file-changed:'+str(p))
    return b,s
def file_row(p,body=False):
    p=Path(p)
    if not p.exists():require(not p.is_symlink(),'dangling-file');return {'path':str(p),'exists':False}
    b,s=bounded(p);row={'path':str(p),'exists':True,'resolved':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'dev':s.st_dev,'ino':s.st_ino,'mode':stat.S_IMODE(s.st_mode)}
    if body:row['bytes_b64']=base64.b64encode(b).decode()
    return row
def identity(pid):
    try:
        p=Path('/proc',str(pid));raw=(p/'stat').read_text();f=raw.rsplit(')',1)[1].split()
        if f[0]=='Z':return None
        return {'pid':pid,'ppid':int(f[1]),'start_ticks':int(f[19]),'cpu_ticks':int(f[11])+int(f[12]),'state':f[0],'argv':[x.decode() for x in (p/'cmdline').read_bytes().split(b'\0') if x],'exe':os.readlink(p/'exe'),'stat':raw}
    except (FileNotFoundError,ProcessLookupError):return None
def processes():
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        row=identity(int(p.name))
        if row and (Path(row['exe']).name in ['retroarch','retroarch32','emulationstation'] or '/usr/bin/runemu.sh' in row['argv']):rows.append(row)
    return rows
def engines(rows):return [r for r in rows if Path(r['exe']).name in ['retroarch','retroarch32']]
def selected_config():
    wanted=['input_enable_hotkey','input_save_state','input_state_slot_increase','input_exit_emulator','savestate_auto_index','savestate_auto_save','savestate_auto_load','state_slot','savestate_directory','savefiles_in_content_dir','savestates_in_content_dir','sort_savestates_enable','sort_savestates_by_content_enable','video_driver','video_fullscreen','log_verbosity','savestate_thumbnail_enable']
    effective={};files=[]
    for name in ['/storage/.config/retroarch/retroarch.cfg','/tmp/.retroarch.cfg']:
        p=Path(name)
        if not p.exists():continue
        b,s=bounded(p);values={}
        for line in b.decode().splitlines():
            m=re.fullmatch(r'\s*([A-Za-z0-9_]+)\s*=\s*"([^"]*)"\s*',line)
            if m and m[1] in wanted:values[m[1]]=m[2];effective[m[1]]=m[2]
        files.append({'path':name,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'values':values})
    return {'files':files,'effective_last_definition':effective,'scope':'base plus actual append config; runtime slot changes are separately proven by input/frame/state filename'}
def state_rows(body=False):
    paths=[ROM.with_suffix('.srm')]+[STATES/('ExitProbe.state'+suffix) for suffix in ['', '1','.auto','.png','1.png','.auto.png']]
    extra=[str(p) for p in STATES.glob('ExitProbe*') if p not in paths] if STATES.exists() else []
    require(not extra,'unexpected-state-members:'+repr(extra))
    require(all(not p.is_symlink() for p in paths),'state-link-refused')
    rows=[file_row(p,body) for p in paths];require(sum(r.get('bytes',0) for r in rows)<=2*1024**2,'selected-state-total');return rows
def api(path,data=None):
    req=urllib.request.Request('http://127.0.0.1:1234'+path,data=data.encode() if data else None,headers={'Content-Type':'text/plain'})
    before=time.monotonic()
    with urllib.request.urlopen(req,timeout=5) as response:
        body=response.read(65537);require(len(body)<=65536,'api-response-bound');row={'path':path,'http_status':response.status,'body':body.decode(),'before_monotonic':before,'after_monotonic':time.monotonic()}
    require(row['http_status'] in (200,201),'api-status');return row
def installed():
    names=['/usr/bin/retroarch','/usr/lib/libretro/gambatte_libretro.so','/usr/bin/runemu.sh','/usr/bin/setsettings.sh','/usr/bin/emulationstation','/usr/config/emulationstation/es_savestates.cfg','/usr/config/retroarch/retroarch.cfg']
    rows={};mounts=[x.split()[4] for x in Path('/proc/self/mountinfo').read_text().splitlines()]
    for n in names:
        p=Path(n);require(p.is_file() and 0<p.stat().st_size<=256*1024**2,'installed-shape:'+n)
        require(not any(n==m or str(p.resolve())==m or (m=='/usr' or m.startswith('/usr/')) and (n.startswith(m+'/') or str(p.resolve()).startswith(m+'/')) for m in mounts),'installed-overlay')
        row={'path':n,'resolved':str(p.resolve()),'bytes':p.stat().st_size,'sha256':digest(p),'mode':stat.filemode(p.stat().st_mode)}
        if n=='/usr/bin/emulationstation':
            want=CONFIG['frontend'];require(row['sha256']==want['sha256'] and row['bytes']==want['bytes'],'accepted-frontend-hash')
        row['scope']='actual installed image-bound bytes; no inferred standalone package binary hash'
        rows[n]=row
    return rows
def observation(body=False):
    rows=processes();cfg=selected_config();out={'epoch_ns':time.time_ns(),'monotonic':time.monotonic(),'processes':rows,'states':state_rows(body),'settings':cfg}
    if engines(rows):
        require(len(engines(rows))==1,'one-engine');engine=engines(rows)[0]
        require(str(ROM) in engine['argv'] and '-L' in engine['argv'],'actual-fixture-engine')
        core=Path(engine['argv'][engine['argv'].index('-L')+1]);require(core.resolve()==Path('/usr/lib/libretro/gambatte_libretro.so'),'actual-gambatte')
        mapping=[x for x in Path('/proc',str(engine['pid']),'maps').read_text().splitlines() if 'gambatte_libretro.so' in x];require(mapping,'core-loaded-map')
        out['core_mapping']=mapping;out['core_resolved']=str(core.resolve())
    return out
def provision():
    require(not R.exists() and not ROM.exists(),'fresh-fixture-owner');require(not engines(processes()),'pre-existing-engine');R.mkdir(mode=0o700)
    result['installed']=installed()
    managed=Path('/storage/.config/emulationstation/es_savestates.cfg');require(managed.is_symlink() and managed.resolve()==Path('/usr/config/emulationstation/es_savestates.cfg'),'managed-savestate-layout')
    result['managed_savestates']={'path':str(managed),'target':os.readlink(managed),'resolved':str(managed.resolve()),'sha256':digest(managed)}
    require(all(not r['exists'] for r in state_rows()),'pre-existing-fixture-state')
    result['initial_states']=state_rows();result['initial_processes']=processes()
    command(['systemctl','stop','essway.service'],30)
    settings=Path('/storage/.config/emulationstation/es_settings.cfg');system=Path('/storage/.config/system/configs/system.cfg')
    result['original_configuration_hashes']={str(p):digest(p) for p in [settings,system]}
    for p in [settings,system]:
        b,_=bounded(p);(R/(p.name+'.original')).write_bytes(b)
    ROM.parent.mkdir(parents=True,exist_ok=True)
    b=base64.b64decode(CONFIG['rom_b64']);require(len(b)==32768 and hashlib.sha256(b).hexdigest()==CONFIG['fixture']['sha256'],'authored-fixture-bytes')
    with ROM.open('xb') as f:f.write(b)
    values=[('gb["ExitProbe.gb"].emulator','retroarch'),('gb["ExitProbe.gb"].core','gambatte'),('gb["ExitProbe.gb"].autosave','1'),('global.incrementalsavestates','2'),('gb["ExitProbe.gb"].incrementalsavestates','2'),('system.loglevel','verbose')]
    command(['bash','-ec','. /etc/profile; '+ '; '.join('set_setting '+shlex.quote(k)+' '+shlex.quote(v) for k,v in values)],15)
    xml=ET.fromstring(settings.read_bytes())
    for key,value in [('StartupSystem','gb'),('LogLevel','information')]:
        old=[e for e in xml if e.get('name')==key];require(len(old)<=1,'duplicate-ES-setting')
        for e in old:xml.remove(e)
        ET.SubElement(xml,'string',{'name':key,'value':value})
    settings.write_bytes(ET.tostring(xml,encoding='utf-8',xml_declaration=True))
    keyboard=ET.fromstring(Path('/storage/.config/emulationstation/es_input.cfg').read_bytes()).find("inputConfig[@type='keyboard']");require(keyboard is not None,'keyboard-profile')
    key_names={13:'ret',27:'esc',32:'spc',8:'backspace',1073741906:'up',1073741905:'down',1073741904:'left',1073741903:'right',1073742049:'shift',1073742053:'shift_r'};mapping={}
    for e in keyboard.findall('input'):
        if e.get('type')=='key':
            n=int(e.get('id'));key=key_names.get(n) or (chr(n) if 97<=n<=122 else None)
            if key:mapping[e.get('name')]=key
    require(all(k in mapping for k in ['a','b','x','up','down','left','right','start']),'keyboard-actions')
    result['input_keys']=mapping;result['rom']=file_row(ROM);result['settings_written']=dict(values)
    command(['systemctl','start','essway.service'],30)
    deadline=time.monotonic()+25
    while True:
        try:result['systems']=api('/systems');break
        except (OSError,TimeoutError):require(time.monotonic()<deadline,'ES-readiness');time.sleep(.5)
    frontend=[r for r in processes() if Path(r['exe']).name=='emulationstation'];require(len(frontend)==1,'one-live-frontend');result['frontend_process']=frontend[0]
    put(R/'provision.json',{'input_keys':mapping,'installed':result['installed'],'fixture':result['rom']})
def launch():
    require(not (R/'launch.json').exists() and not engines(processes()),'exact-one-launch')
    before=observation();require(all(not r['exists'] for r in before['states']),'clean-state-before-launch');put(R/'launch.json',{'epoch_ns':time.time_ns(),'before':before})
    result['launch']=api('/launch',str(ROM));limit=time.monotonic()+60
    while True:
        now=observation()
        if engines(now['processes']):break
        require(time.monotonic()<limit,'engine-start-deadline');time.sleep(.25)
    require(len([r for r in now['processes'] if '/usr/bin/runemu.sh' in r['argv']])==1,'normal-runemu-process')
    expected={'input_enable_hotkey':'nul','input_save_state':'f2','input_state_slot_increase':'f7','input_exit_emulator':'escape','savestate_auto_index':'false','savestate_auto_save':'true','savestate_auto_load':'true','state_slot':'-1','savestate_directory':str(STATES),'savefiles_in_content_dir':'true','savestates_in_content_dir':'false','sort_savestates_enable':'false','sort_savestates_by_content_enable':'false','log_verbosity':'true','video_fullscreen':'true'}
    require(all(now['settings']['effective_last_definition'].get(k)==v for k,v in expected.items()),'effective-settings-mismatch')
    actual=engines(now['processes'])[0];want=json.loads((R/'provision.json').read_text())['installed']
    require(digest(Path('/proc',str(actual['pid']),'exe'))==want['/usr/bin/retroarch']['sha256'],'executing-engine-hash');require(digest(Path(now['core_resolved']))==want['/usr/lib/libretro/gambatte_libretro.so']['sha256'],'executing-core-hash')
    put(R/'engine.json',actual);result['observation']=now
    # Original cartridge proof: require observed CPU progress, not just process presence.
    initial=actual['cpu_ticks'];deadline=time.monotonic()+45
    while True:
        active=identity(actual['pid']);require(active and active['start_ticks']==actual['start_ticks'],'engine-left-before-ready')
        if active['cpu_ticks']-initial>=30:break
        require(time.monotonic()<deadline,'engine-cpu-progress');time.sleep(.25)
    result['ready_process']=active;result['cpu_delta']=active['cpu_ticks']-initial
    sockets=list(Path('/run/0-runtime-dir').glob('sway-ipc.*.sock'));require(len(sockets)==1,'single-compositor')
    tree=json.loads(command(['swaymsg','-s',str(sockets[0]),'-t','get_tree','-r'],5));windows=[]
    def descend(node):
        if node.get('pid')==actual['pid']:windows.append({k:node.get(k) for k in ['pid','app_id','name','rect','window_rect','fullscreen_mode']})
        for child in node.get('nodes',[])+node.get('floating_nodes',[]):descend(child)
    descend(tree);require(len(windows)==1 and windows[0]['rect']['width']==640 and windows[0]['rect']['height']==480 and windows[0]['fullscreen_mode']>0,'actual-full-panel-engine-surface')
    result['compositor_surface']=windows[0]

def snapshot():
    result['observation']=observation(True);result['logs']=[]
    for n in ['/var/log/exec.log','/var/log/es_log.txt']:
        p=Path(n)
        if p.exists():result['logs'].append(file_row(p,True))
    require(sum(r.get('bytes',0) for r in result['logs'])<=1024**2,'selected-log-total')

def finish():
    snapshot();rows=result['observation']['processes'];require(not engines(rows) and not any('/usr/bin/runemu.sh' in r['argv'] for r in rows),'launch-not-stopped')
    previous=json.loads((R/'engine.json').read_text());now=identity(previous['pid']);require(now is None or now['start_ticks']!=previous['start_ticks'],'recorded-engine-survived')
    files={x['path']:x for x in result['observation']['states']}
    for p in [str(ROM.with_suffix('.srm')),str(STATES/'ExitProbe.state1'),str(STATES/'ExitProbe.state.auto')]:require(files[p]['exists'] and files[p]['bytes']>0,'missing-save:'+p)
    require(base64.b64decode(files[str(ROM.with_suffix('.srm'))]['bytes_b64'])[0]==0x55,'SRAM-sentinel')
    log=Path('/var/log/exec.log').read_text();statuses=re.findall(r'Checking errors:\s*(-?\d+)',log);require(statuses==['0'],'original-runemu-shell-wait')
    require(' -state_slot -1' in log and 'gambatte' in log and str(ROM) in log,'actual-launch-log')
    require(not Path('/tmp/.process-kill-requested').exists(),'no-hotkey-marker')
    result['logged_engine_shell_wait_status']=0;result['engine_wait_source']='unchanged runemu.sh eval then ret_error=$?; Checking errors line before exit mapping'
    result['frontend_wait_status']='not independently waitpid-observed; ES owns child'
    result['observed_recorded_engine_gone']=True;result['no_fixture_background_process']=True

def expire(*_):raise TimeoutError('bounded guest action deadline')
signal.signal(signal.SIGALRM,expire);signal.signal(signal.SIGTERM,expire);signal.alarm(125 if OP=='launch' else 100)
try:
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(4*1024**2,4*1024**2))
    require(sorted(p.name for p in Path('/sys/class/net').iterdir())==['lo'],'no-NIC');require('BUILD_ID="'+CONFIG['commit']+'"' in Path('/etc/os-release').read_text(),'exact-installed-source')
    result['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if OP=='provision':provision()
    elif OP=='launch':launch()
    elif OP=='snapshot':snapshot()
    elif OP=='finish':finish()
    elif OP=='status':result['observation']=observation()
    else:raise RuntimeError('unknown-operation')
    result['status']='PASS'
except BaseException as exc:result['error']=type(exc).__name__+': '+str(exc)
finally:
    signal.alarm(0);result['ended_ns']=time.time_ns();result['original_commands']=raw_commands
    raw=json.dumps(result,separators=(',',':')).encode();require(len(raw)<=5*1024**2,'guest-report-bound');print('PIX_RA_REPORT='+base64.b64encode(raw).decode(),flush=True)
raise SystemExit(0 if result['status']=='PASS' and not result['cleanup_errors'] else 1)

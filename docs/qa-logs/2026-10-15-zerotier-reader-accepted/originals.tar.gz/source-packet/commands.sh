#!/bin/bash
# UNRUN; root separately allocates each stage and supervises launch to original completion.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-zerotier-readback-plan-20261015-03
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-zerotier-readback-20261015-03}
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-player-setup
TASK_STAGE="$TASK_OWNER/stages/zerotier-readback"
cd "$TASK_TREE"
case "${1:-}" in
 prepare) tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/plan.py" --checkout "$TASK_TREE" --owner "$TASK_OWNER" ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_STAGE/retention-plan.json" --output "$TASK_STAGE/retention-report.json" ;;
 admit) python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_STAGE/admission-plan.json" --output "$TASK_STAGE/admission.json" ;;
 launch) PROJECT=ROCKNIX DEVICE=GENERIC_X64 ARCH=x86_64 tools/watch-build-submit --owner "$TASK_STAGE/submit" -- --admission "$TASK_STAGE/admission.json" --activity-dir "$TASK_STAGE/logs" -- python3 -I -S -B "$TASK_PACKET/run-stage.py" --checkout "$TASK_TREE" --owner "$TASK_OWNER" --stage zerotier-readback ;;
 completion) python3 -I -S -B "$TASK_PACKET/completion-evidence.py" --owner "$TASK_OWNER" ;;
 consume) TASK_RUN=$(python3 -I -S -B -c 'import json,sys;print(json.load(open(sys.argv[1]))["run"])' "$TASK_STAGE/watch-run.json"); python3 -I tools/host-maintenance/build-admission consume --run "$TASK_RUN" --evidence "$TASK_STAGE/completion-evidence.json" ;;
 *) echo 'choose prepare | preflight | report | admit | launch | completion | consume' >&2;exit 2 ;;
esac

"""One bounded metadata/data inspection; no candidate helper, target or acquired code execution."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,posixpath,shlex,stat,time
P=Path('/tmp/pix-m7-zerotier-readback-plan-20261015-03');B=json.loads((P/'build-plan.json').read_text());C=json.loads((P/'dependency-context.json').read_text());ROOT=Path(B['completed_source']['host_path']);STAGE=Path(B['original_compile']['stage']);START=time.monotonic();READ=0
TOOL_V=B['container_root']+'/'+B['build_relative']+'/toolchain';TOOL_H=Path(B['physical_root'])/B['build_relative']/'toolchain';MAP=[('/work/source',ROOT),(TOOL_V,TOOL_H)]
def require(ok,msg):
 if not ok:raise RuntimeError(msg)
def checktime():require(time.monotonic()-START<60,'passive60s limit')
def digest(path):
 global READ
 checktime();s=path.stat();require(s.st_size<128*1024**2 and READ+s.st_size<1024**3,'passive named1GiB read limit');READ+=s.st_size;h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
 a=path.stat();require((s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_mode,a.st_size,a.st_mtime_ns,a.st_ctime_ns),'file changed during read')
 return h.hexdigest()
def physical(v):
 for prefix,host in MAP:
  if v==prefix or v.startswith(prefix+'/'):return host/str(PurePosixPath(v).relative_to(prefix))
 raise RuntimeError('outside container mounts: '+v)
def resolve(v):
 v=posixpath.normpath(v);links=[]
 for hop in range(41):
  checktime();found=False
  for prefix,host in MAP:
   if not(v==prefix or v.startswith(prefix+'/')):continue
   parts=PurePosixPath(v).relative_to(prefix).parts;cur=prefix
   for i,part in enumerate(parts):
    cur+='/'+part;p=physical(cur);s=p.lstat()
    if stat.S_ISLNK(s.st_mode):
     target=os.readlink(p);links.append({'path':cur,'target':target});tail='/'.join(parts[i+1:]);base=target if target.startswith('/') else posixpath.dirname(cur)+'/'+target;v=posixpath.normpath(base+('/'+tail if tail else ''));found=True;break
   break
  else:raise RuntimeError('resolved outside container mounts: '+v)
  if not found:return v,physical(v),links
 raise RuntimeError('symlink hop bound')
def deps(path,cwd):
 require(path.stat().st_size<=4*1024**2,'large .d');t=path.read_text().replace('\\\n','').splitlines()[0];require(':' in t,'missing dependency target');names=shlex.split(t.split(':',1)[1]);require(bool(names),'empty .d');return [x if x.startswith('/') else cwd+'/'+x for x in names]
before=json.loads((STAGE/'source-before.json').read_text());source_bytes=0
for r in before['files']:
 p=ROOT/r['path'];s=p.lstat();require(stat.S_ISREG(s.st_mode) and s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==r['mode'] and digest(p)==r['sha256'],'original selected source changed: '+r['path']);source_bytes+=s.st_size
for r in before['links']:require(os.readlink(ROOT/r['path'])==r['target'],'source symlink changed')
require(not (ROOT/'nonfree').exists() and not (ROOT/'nonfree').is_symlink(),'nonfree exists')
actual_d=[];actual_o=[];nodes=0
for directory,dirs,files in os.walk(ROOT,followlinks=False):
 checktime();nodes+=len(dirs)+len(files);require(nodes<6000,'source glob bound')
 for name in files:
  rel=str((Path(directory)/name).relative_to(ROOT))
  if name.endswith('.d'):actual_d.append(rel)
  if name.endswith('.o'):actual_o.append(rel)
require(sorted(actual_d)==sorted(r['dependency_file'] for r in C['bindings']),'actual dependency set mismatch')
objects={r['object']:r for r in C['bindings']+C['assembly_bindings']};require(len(objects)==113 and sorted(actual_o)==sorted(objects),'actual object set mismatch')
names=[];object_bytes=0
for r in C['bindings']:
 p=ROOT/r['dependency_file'];require(p.stat().st_size==r['dependency_bytes'] and digest(p)==r['dependency_sha256'],'.d identity mismatch');logical=p.read_text().replace('\\\n','').splitlines()[0];target,prereq=logical.split(':',1);require(shlex.split(target)==[r['object_argument']] and shlex.split(prereq)[0]==r['source_argument'],'target/source mismatch');require(posixpath.normpath(r['cwd']+'/'+r['object_argument'])=='/work/source/'+r['object'],'cwd mapping mismatch');names+=deps(p,r['cwd'])
for obj,r in objects.items():
 p=ROOT/obj;require(p.is_file() and not p.is_symlink(),'object type');digest(p);object_bytes+=p.stat().st_size;names.append('/work/source/'+r['source'])
for r in C['assembly_bindings']:
 p=ROOT/r['source'];data=p.read_bytes();require(len(data)==r['source_bytes'] and hashlib.sha256(data).hexdigest()==r['source_sha256'],'assembly source mismatch')
 import re
 require(not re.search(rb'(?i)\.(?:include|incbin)\b',data),'assembly input directive requires explicit mapping')
link_names=deps(STAGE/'link.d','/work/source');names+=link_names;unique={};symlinks=[];total=0
for v in names:
 if v in unique:continue
 require('nonfree' not in PurePosixPath(v).parts,'nonfree path');resolved,p,links=resolve(v);require('nonfree' not in PurePosixPath(resolved).parts and p.is_file(),'invalid resolved dependency');size=p.stat().st_size;total+=size;require(len(unique)<9999 and total<1024**3,'reader unique bounds');unique[v]={'path':v,'resolved':resolved,'host_path':str(p),'bytes':size,'sha256':digest(p)}
 if links:symlinks.append({'path':v,'resolved':resolved,'chain':links})
for r in unique.values():require(digest(Path(r['host_path']))==r['sha256'],'consumed dependency changed')
artifact=ROOT/'zerotier-one';head=artifact.read_bytes()[:20];require(head[:6]==b'\x7fELF\x02\x01' and int.from_bytes(head[18:20],'little')==62,'ELF mismatch')
for name in ['zerotier-cli','zerotier-idtool']:require(os.readlink(ROOT/name)=='zerotier-one','CLI link mismatch')
require(digest(artifact)=='dd84354af5a6ea19e694845d0edfa0f9743f6176c5ddca5389bee82b1bbb96a8','artifact changed')
report={'status':'PASS_PASSIVE_NAMED_DATA_INSPECTION','candidate_helper_executed':False,'target_or_acquired_code_executed':False,'network_used':False,'original_source_files':len(before['files']),'original_source_links':len(before['links']),'original_source_bytes':source_bytes,'source_glob_nodes':nodes,'dependency_files':len(actual_d),'object_files':len(actual_o),'object_bytes':object_bytes,'assembly_source_count':24,'assembly_include_incbin_directives':0,'link_dependency_count':len(link_names),'unique_dependency_spellings':len(unique),'unique_dependency_bytes':total,'symlink_dependencies':symlinks,'read_bytes':READ,'elapsed_seconds':time.monotonic()-START,'target_sha256':digest(artifact),'target_links':{'zerotier-cli':'zerotier-one','zerotier-idtool':'zerotier-one'},'all_consumed_paths_within_readonly_mounts':True,'binding_refs':{'dependency_context_sha256':hashlib.sha256((P/'dependency-context.json').read_bytes()).hexdigest(),'source_before_sha256':hashlib.sha256((STAGE/'source-before.json').read_bytes()).hexdigest(),'link_d_sha256':hashlib.sha256((STAGE/'link.d').read_bytes()).hexdigest()}}
(P/'passive-preflight.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='symlink_dependencies'},indent=2));print('symlink dependency count',len(symlinks))

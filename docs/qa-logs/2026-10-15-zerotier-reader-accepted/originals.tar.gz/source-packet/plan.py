#!/usr/bin/env python3
"""UNRUN preparation only. No reader/container creation/admission here."""
import argparse,os,re,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import DISK_LIMIT,HERE,read,require,sha,verify_packet,write

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--owner',type=Path,required=True);p.add_argument('--checkout',type=Path,required=True);a=p.parse_args()
 owner=a.owner;tree=a.checkout;stage=owner/'stages/zerotier-readback'
 require(re.fullmatch('/workspace/tmp/pix-m7-zerotier-readback-20261015-[0-9]{2}',str(owner)) and owner.resolve()==owner and not owner.exists(),'fresh exact owner required')
 require(os.getuid()!=0 and tree.is_absolute() and tree.resolve()==tree,'normal host user/real checkout required');verify_packet(HERE)
 b=read(HERE/'build-plan.json');seal=sha(HERE/'SHA256SUMS')
 for argv,expected in [(['git','-C',b['physical_root'],'rev-parse','HEAD'],b['distribution_commit']+'\n'),(['git','-C',b['physical_root'],'status','--porcelain','--untracked-files=no'],'')]:
  r=subprocess.run(argv,capture_output=True,text=True,timeout=10);require(r.returncode==0 and r.stdout==expected and not r.stderr,'frozen source mismatch')
 host_inputs=[]
 for row in b['inputs']:
  path=Path(row['host_path']);st=path.stat();require(st.st_size==row['bytes'] and sha(path)==row['sha256'],'input changed: '+str(path))
  host_inputs.append({**row,'stat':{k:getattr(st,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')}})
 require(sha(Path(b['candidate_packet'])/'SHA256SUMS')==b['candidate_seal'],'candidate seal changed')
 st=Path(b['completed_source']['host_path']).lstat();require(all(getattr(st,k)==v for k,v in b['completed_source']['identity'].items()),'completed source root identity changed')
 consumed=read(Path(b['original_compile']['run'])/'admission-consumed.json');require(consumed['state']=='consumed' and consumed['id']==b['original_compile']['consumed_id'],'original compile failure not consumed')
 owner.mkdir(mode=0o700)
 for name in ['work','work/tmp','stages','stages/zerotier-readback','stages/zerotier-readback/scan','stages/zerotier-readback/logs','stages/zerotier-readback/submit']:(owner/name).mkdir()
 write(owner/'host-input-identities.json',{'pid_namespace':os.stat('/proc/self/ns/pid').st_ino,'user_namespace':os.stat('/proc/self/ns/user').st_ino,'uid_map':Path('/proc/self/uid_map').read_text(),'gid_map':Path('/proc/self/gid_map').read_text(),'uid':os.getuid(),'gid':os.getgid(),'inputs':host_inputs})
 write(owner/'family.json',{'family':'zerotier','checkout':str(tree),'runner_manifest_sha256':seal})
 outputs=[{'path':str(owner/'work'),'issue':528,'kind':'qa-scratch','release_when':'After original reader-only result consumption and compact evidence retention. This owner contains only new reader temporary files, never the completed source.'},{'path':str(owner/'stages'),'issue':528,'kind':'qa-scratch','release_when':'After original watcher/container/cleanup and reader evidence is compactly retained; retain raw dependency lists and original result receipts.'}]
 write(stage/'retention-plan.json',{'volume':'/workspace','scan_roots':[str(stage/'scan')],'reference_stores':[],'protected':[str(HERE),b['physical_root'],b['candidate_packet'],b['completed_source']['host_path']],'candidates':[],'builds':[{'name':'m7-zerotier-no-nonfree-compile','terms_bytes':{'selected_family_scratch_ceiling':DISK_LIMIT},'basis':'One60s reader-only proof.2CPU1GiB256PIDs,64MiB sampled new scratch and16MiB per-child-output limit. Completed source and frozen toolchain read-only, pinned networkless builder. No compiler/make/extraction/rebuild/target execution. Original completed source remains separately held.','evidence':[{'path':str(HERE/'build-plan.json'),'sha256':sha(HERE/'build-plan.json')}]}]})
 write(stage/'admission-plan.json',{'checkout':str(tree),'retention_plan':str(stage/'retention-plan.json'),'retention_report':str(stage/'retention-report.json'),'stage':'m7-zerotier-no-nonfree-compile','profiles':[{'PROJECT':'ROCKNIX','DEVICE':'GENERIC_X64','ARCH':'x86_64'}],'outputs':outputs})
 write(stage/'selection.json',{'stage':'zerotier-readback','owner':str(owner),'runner_manifest_sha256':seal,'sealed_manifest_sha256':seal})
 print(stage/'admission-plan.json')
if __name__=='__main__':main()

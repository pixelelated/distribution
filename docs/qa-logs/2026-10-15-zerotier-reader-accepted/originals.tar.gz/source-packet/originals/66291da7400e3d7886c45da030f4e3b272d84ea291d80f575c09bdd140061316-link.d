zerotier-one: \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/crt1.o \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/crti.o \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/crtbegin.o \
  node/AES.o \
  node/AES_aesni.o \
  node/AES_armcrypto.o \
  node/ECC.o \
  node/Capability.o \
  node/CertificateOfMembership.o \
  node/CertificateOfOwnership.o \
  node/Identity.o \
  node/IncomingPacket.o \
  node/InetAddress.o \
  node/Membership.o \
  node/Metrics.o \
  node/Multicaster.o \
  node/Network.o \
  node/NetworkConfig.o \
  node/Node.o \
  node/OutboundMulticast.o \
  node/Packet.o \
  node/Path.o \
  node/Peer.o \
  node/Poly1305.o \
  node/Revocation.o \
  node/Salsa20.o \
  node/SelfAwareness.o \
  node/SHA512.o \
  node/Switch.o \
  node/Tag.o \
  node/Topology.o \
  node/Trace.o \
  node/Utils.o \
  node/Bond.o \
  node/PacketMultiplexer.o \
  osdep/OSUtils.o \
  ext/x64-salsa2012-asm/salsa2012.o \
  ext/ed25519-amd64-asm/choose_t.o \
  ext/ed25519-amd64-asm/consts.o \
  ext/ed25519-amd64-asm/fe25519_add.o \
  ext/ed25519-amd64-asm/fe25519_freeze.o \
  ext/ed25519-amd64-asm/fe25519_mul.o \
  ext/ed25519-amd64-asm/fe25519_square.o \
  ext/ed25519-amd64-asm/fe25519_sub.o \
  ext/ed25519-amd64-asm/ge25519_add_p1p1.o \
  ext/ed25519-amd64-asm/ge25519_dbl_p1p1.o \
  ext/ed25519-amd64-asm/ge25519_nielsadd2.o \
  ext/ed25519-amd64-asm/ge25519_nielsadd_p1p1.o \
  ext/ed25519-amd64-asm/ge25519_p1p1_to_p2.o \
  ext/ed25519-amd64-asm/ge25519_p1p1_to_p3.o \
  ext/ed25519-amd64-asm/ge25519_pnielsadd_p1p1.o \
  ext/ed25519-amd64-asm/heap_rootreplaced.o \
  ext/ed25519-amd64-asm/heap_rootreplaced_1limb.o \
  ext/ed25519-amd64-asm/heap_rootreplaced_2limbs.o \
  ext/ed25519-amd64-asm/heap_rootreplaced_3limbs.o \
  ext/ed25519-amd64-asm/sc25519_add.o \
  ext/ed25519-amd64-asm/sc25519_barrett.o \
  ext/ed25519-amd64-asm/sc25519_lt.o \
  ext/ed25519-amd64-asm/sc25519_sub_nored.o \
  ext/ed25519-amd64-asm/ull4_mul.o \
  ext/ed25519-amd64-asm/fe25519_getparity.o \
  ext/ed25519-amd64-asm/fe25519_invert.o \
  ext/ed25519-amd64-asm/fe25519_iseq.o \
  ext/ed25519-amd64-asm/fe25519_iszero.o \
  ext/ed25519-amd64-asm/fe25519_neg.o \
  ext/ed25519-amd64-asm/fe25519_pack.o \
  ext/ed25519-amd64-asm/fe25519_pow2523.o \
  ext/ed25519-amd64-asm/fe25519_setint.o \
  ext/ed25519-amd64-asm/fe25519_unpack.o \
  ext/ed25519-amd64-asm/ge25519_add.o \
  ext/ed25519-amd64-asm/ge25519_base.o \
  ext/ed25519-amd64-asm/ge25519_double.o \
  ext/ed25519-amd64-asm/ge25519_double_scalarmult.o \
  ext/ed25519-amd64-asm/ge25519_isneutral.o \
  ext/ed25519-amd64-asm/ge25519_multi_scalarmult.o \
  ext/ed25519-amd64-asm/ge25519_pack.o \
  ext/ed25519-amd64-asm/ge25519_scalarmult_base.o \
  ext/ed25519-amd64-asm/ge25519_unpackneg.o \
  ext/ed25519-amd64-asm/hram.o \
  ext/ed25519-amd64-asm/index_heap.o \
  ext/ed25519-amd64-asm/sc25519_from32bytes.o \
  ext/ed25519-amd64-asm/sc25519_from64bytes.o \
  ext/ed25519-amd64-asm/sc25519_from_shortsc.o \
  ext/ed25519-amd64-asm/sc25519_iszero.o \
  ext/ed25519-amd64-asm/sc25519_mul.o \
  ext/ed25519-amd64-asm/sc25519_mul_shortsc.o \
  ext/ed25519-amd64-asm/sc25519_slide.o \
  ext/ed25519-amd64-asm/sc25519_to32bytes.o \
  ext/ed25519-amd64-asm/sc25519_window4.o \
  ext/ed25519-amd64-asm/sign.o \
  osdep/EthernetTap.o \
  osdep/ManagedRoute.o \
  osdep/Http.o \
  service/OneService.o \
  osdep/LinuxEthernetTap.o \
  osdep/LinuxNetLink.o \
  osdep/PortMapper.o \
  ext/miniupnpc/connecthostport.o \
  ext/miniupnpc/igd_desc_parse.o \
  ext/miniupnpc/minisoap.o \
  ext/miniupnpc/minissdpc.o \
  ext/miniupnpc/miniupnpc.o \
  ext/miniupnpc/miniwget.o \
  ext/miniupnpc/minixml.o \
  ext/miniupnpc/portlistingparse.o \
  ext/miniupnpc/receivedata.o \
  ext/miniupnpc/upnpcommands.o \
  ext/miniupnpc/upnpdev.o \
  ext/miniupnpc/upnperrors.o \
  ext/miniupnpc/upnpreplyparse.o \
  ext/libnatpmp/natpmp.o \
  ext/libnatpmp/getgateway.o \
  ext/http-parser/http_parser.o \
  one.o \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/../../../../x86_64-rocknix-linux-gnu/lib/libstdc++.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so.6 \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libmvec.so.1 \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/../../../../x86_64-rocknix-linux-gnu/lib/libgcc_s.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/libgcc.a \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libpthread.a \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so.6 \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc_nonshared.a \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/ld-linux-x86-64.so.2 \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/../../../../x86_64-rocknix-linux-gnu/lib/libgcc_s.so \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/libgcc.a \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/crtend.o \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/crtn.o \
  /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/ld-linux-x86-64.so.2

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/crt1.o:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/crti.o:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/crtbegin.o:

node/AES.o:

node/AES_aesni.o:

node/AES_armcrypto.o:

node/ECC.o:

node/Capability.o:

node/CertificateOfMembership.o:

node/CertificateOfOwnership.o:

node/Identity.o:

node/IncomingPacket.o:

node/InetAddress.o:

node/Membership.o:

node/Metrics.o:

node/Multicaster.o:

node/Network.o:

node/NetworkConfig.o:

node/Node.o:

node/OutboundMulticast.o:

node/Packet.o:

node/Path.o:

node/Peer.o:

node/Poly1305.o:

node/Revocation.o:

node/Salsa20.o:

node/SelfAwareness.o:

node/SHA512.o:

node/Switch.o:

node/Tag.o:

node/Topology.o:

node/Trace.o:

node/Utils.o:

node/Bond.o:

node/PacketMultiplexer.o:

osdep/OSUtils.o:

ext/x64-salsa2012-asm/salsa2012.o:

ext/ed25519-amd64-asm/choose_t.o:

ext/ed25519-amd64-asm/consts.o:

ext/ed25519-amd64-asm/fe25519_add.o:

ext/ed25519-amd64-asm/fe25519_freeze.o:

ext/ed25519-amd64-asm/fe25519_mul.o:

ext/ed25519-amd64-asm/fe25519_square.o:

ext/ed25519-amd64-asm/fe25519_sub.o:

ext/ed25519-amd64-asm/ge25519_add_p1p1.o:

ext/ed25519-amd64-asm/ge25519_dbl_p1p1.o:

ext/ed25519-amd64-asm/ge25519_nielsadd2.o:

ext/ed25519-amd64-asm/ge25519_nielsadd_p1p1.o:

ext/ed25519-amd64-asm/ge25519_p1p1_to_p2.o:

ext/ed25519-amd64-asm/ge25519_p1p1_to_p3.o:

ext/ed25519-amd64-asm/ge25519_pnielsadd_p1p1.o:

ext/ed25519-amd64-asm/heap_rootreplaced.o:

ext/ed25519-amd64-asm/heap_rootreplaced_1limb.o:

ext/ed25519-amd64-asm/heap_rootreplaced_2limbs.o:

ext/ed25519-amd64-asm/heap_rootreplaced_3limbs.o:

ext/ed25519-amd64-asm/sc25519_add.o:

ext/ed25519-amd64-asm/sc25519_barrett.o:

ext/ed25519-amd64-asm/sc25519_lt.o:

ext/ed25519-amd64-asm/sc25519_sub_nored.o:

ext/ed25519-amd64-asm/ull4_mul.o:

ext/ed25519-amd64-asm/fe25519_getparity.o:

ext/ed25519-amd64-asm/fe25519_invert.o:

ext/ed25519-amd64-asm/fe25519_iseq.o:

ext/ed25519-amd64-asm/fe25519_iszero.o:

ext/ed25519-amd64-asm/fe25519_neg.o:

ext/ed25519-amd64-asm/fe25519_pack.o:

ext/ed25519-amd64-asm/fe25519_pow2523.o:

ext/ed25519-amd64-asm/fe25519_setint.o:

ext/ed25519-amd64-asm/fe25519_unpack.o:

ext/ed25519-amd64-asm/ge25519_add.o:

ext/ed25519-amd64-asm/ge25519_base.o:

ext/ed25519-amd64-asm/ge25519_double.o:

ext/ed25519-amd64-asm/ge25519_double_scalarmult.o:

ext/ed25519-amd64-asm/ge25519_isneutral.o:

ext/ed25519-amd64-asm/ge25519_multi_scalarmult.o:

ext/ed25519-amd64-asm/ge25519_pack.o:

ext/ed25519-amd64-asm/ge25519_scalarmult_base.o:

ext/ed25519-amd64-asm/ge25519_unpackneg.o:

ext/ed25519-amd64-asm/hram.o:

ext/ed25519-amd64-asm/index_heap.o:

ext/ed25519-amd64-asm/sc25519_from32bytes.o:

ext/ed25519-amd64-asm/sc25519_from64bytes.o:

ext/ed25519-amd64-asm/sc25519_from_shortsc.o:

ext/ed25519-amd64-asm/sc25519_iszero.o:

ext/ed25519-amd64-asm/sc25519_mul.o:

ext/ed25519-amd64-asm/sc25519_mul_shortsc.o:

ext/ed25519-amd64-asm/sc25519_slide.o:

ext/ed25519-amd64-asm/sc25519_to32bytes.o:

ext/ed25519-amd64-asm/sc25519_window4.o:

ext/ed25519-amd64-asm/sign.o:

osdep/EthernetTap.o:

osdep/ManagedRoute.o:

osdep/Http.o:

service/OneService.o:

osdep/LinuxEthernetTap.o:

osdep/LinuxNetLink.o:

osdep/PortMapper.o:

ext/miniupnpc/connecthostport.o:

ext/miniupnpc/igd_desc_parse.o:

ext/miniupnpc/minisoap.o:

ext/miniupnpc/minissdpc.o:

ext/miniupnpc/miniupnpc.o:

ext/miniupnpc/miniwget.o:

ext/miniupnpc/minixml.o:

ext/miniupnpc/portlistingparse.o:

ext/miniupnpc/receivedata.o:

ext/miniupnpc/upnpcommands.o:

ext/miniupnpc/upnpdev.o:

ext/miniupnpc/upnperrors.o:

ext/miniupnpc/upnpreplyparse.o:

ext/libnatpmp/natpmp.o:

ext/libnatpmp/getgateway.o:

ext/http-parser/http_parser.o:

one.o:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/../../../../x86_64-rocknix-linux-gnu/lib/libstdc++.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libm.so.6:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libmvec.so.1:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/../../../../x86_64-rocknix-linux-gnu/lib/libgcc_s.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/libgcc.a:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libpthread.a:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc.so.6:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/libc_nonshared.a:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/ld-linux-x86-64.so.2:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/../../../../x86_64-rocknix-linux-gnu/lib/libgcc_s.so:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/libgcc.a:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/lib/gcc/x86_64-rocknix-linux-gnu/15.2.0/crtend.o:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/crtn.o:

/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/lib/ld-linux-x86-64.so.2:

#!/bin/bash
# UNRUN. Ordinary frozen recipe commands; only diagnostic dependency flags added.
set -eo pipefail
cd /workspace/repos/rocknix.worktrees/m7-pixelelated
# Both package indexes already exist, are hash-bound, and are mounted read-only.
# config/options therefore does not regenerate package indexes in the frozen tree.
. config/options zerotier-one
setup_toolchain target manual
[[ "$PKG_NAME" == zerotier-one && "$PKG_VERSION" == 1.16.0 && "$PKG_TOOLCHAIN" == manual ]]
[[ "$BUILD_WITH_DEBUG" == no && -z "$PKG_BUILD_FLAGS" && "$TARGET_CPU" == x86-64-v3 ]]
[[ "$CC" == "$TARGET_PREFIX"gcc && "$CXX" == "$TARGET_PREFIX"g++ ]]
[[ ! -e "$ROOT/.rocknix/options" && ! -e "${HOME}/.rocknix/options" ]]
[[ ! -e "$BUILD/build/zerotier-one-1.16.0" ]]
PKG_BUILD=/work/source
[[ ! -e "$PKG_BUILD/nonfree" && ! -L "$PKG_BUILD/nonfree" ]]
# Capture only relevant public toolchain variables, never a full environment.
/usr/bin/python3 -I -S -B /runner/record-environment.py
# -MD/-MP record actual system and project headers. No optimization/feature flag changes.
export CFLAGS="$CFLAGS -MD -MP"
export CXXFLAGS="$CXXFLAGS -MD -MP"
# Exact two make commands from the frozen recipe, with a diagnostic link dependency file.
make -C "$PKG_BUILD/ext/libnatpmp" CC="$CC"
cd "$PKG_BUILD"
CPPFLAGS="${CPPFLAGS} -I${PKG_BUILD}/ext/libnatpmp" \
LDLIBS="${LDLIBS} -L${PKG_BUILD}/ext/libnatpmp" \
LDFLAGS="${LDFLAGS} -Wl,--dependency-file,/receipts/link.d" \
make -f make-linux.mk ZT_SSO_SUPPORTED=0 one

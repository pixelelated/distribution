#!/usr/bin/env python3
"""Prepare successful completion evidence only after original owner/watch closure.
Failures stay failures and require root's separate bounded investigation/disposition.
"""
import argparse,json,os,re,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import read,require,sha,write
p=argparse.ArgumentParser();p.add_argument('--owner',required=True,type=Path);a=p.parse_args();o=a.owner;s=o/'stages/zerotier-readback'
require(o.resolve()==o and re.fullmatch('/workspace/tmp/pix-m7-zerotier-readback-20261015-[0-9]{2}',str(o)),'wrong owner')
r=read(s/'result.json');require(r['status']=='PASS' and all(type(r[k]) is int and r[k]==0 for k in ('original_attach_exit','original_container_exit','watchdog_original_exit')),'original reader/container failure')
require(r['cleanup']['status']=='PASS' and r['cleanup']['forced_stop'] is False and not r['cleanup']['survivors'] and not r.get('forced_client_stop') and not r.get('watchdog_timeout'),'cleanup not qualified')
i=read(s/'container-result.json');require(i['status']=='PASS' and not i['monitor_errors'] and i['sampler_exited'],'inner failed')
require([x['label'] for x in i['children']]==['source-readback','target-readelf'] and all(type(x['original_exit']) is int and x['original_exit']==0 and x['reaped'] and not x.get('forced_group_stop') for x in i['children']),'actual child failure')
run=Path(read(s/'watch-run.json')['run']);admission=read(run/'admission.json');require(admission['pid_namespace']==os.stat('/proc/self/ns/pid').st_ino,'not admitted host namespace')
rc=read(run/'runner-result.json');require(all(type(rc[k]) is int and rc[k]==0 for k in ['runner_rc','command_rc','monitor_rc']),'outer failed')
launch=read(s/'submit/launcher-result.json');require(type(launch['runner_returncode']) is int and launch['runner_returncode']==0 and (s/'submit/tool-wrapper.rc').read_text()=='0\n','launcher not complete')
cid=(s/'container.cid').read_text().strip();require(re.fullmatch('[0-9a-f]{64}',cid),'CID absent')
# Successful daemon listing; an arbitrary failed inspect is never absence proof.
z=subprocess.run(['docker','--host','unix:///var/run/docker.sock','ps','-a','--no-trunc','--format','{{.ID}}'],capture_output=True,text=True,timeout=20)
require(z.returncode==0 and not z.stderr and cid not in z.stdout.splitlines() and all(re.fullmatch('[0-9a-f]{64}',x) for x in z.stdout.splitlines()),'CID not absent')
write(s/'completion-container-census.json',{'original_exit':z.returncode,'ids':z.stdout.splitlines(),'exact_cid':cid,'absent':True})
paths=[s/n for n in ['result.json','container-result.json','target-artifact.json','consumed-dependencies.json','dependency-context-used.json','source-readback.json','target-readelf.json','logs/target-readelf.stdout','logs/target-readelf.stderr','completion-container-census.json','submit/launcher-result.json','submit/tool-wrapper.rc']]+[run/'runner-result.json',run/'build.rc']
write(s/'completion-evidence.json',{'run':str(run),'expected_rc':0,'disposition':'qualified','outputs':admission['outputs'],'evidence':[{'path':str(x),'sha256':sha(x)} for x in paths],'scope':'Read-only completion of actual ZeroTier02 successful recipe dependency/target inspection without nonfree; original compile02 combined failure remains failed. No target execution, product integration, firmware acceptance or legal/publication clearance.'})
print(s/'completion-evidence.json')

ext/ed25519-amd64-asm/fe25519_invert.o: \
 ext/ed25519-amd64-asm/fe25519_invert.c \
 /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/stdc-predef.h \
 ext/ed25519-amd64-asm/fe25519.h
/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/stdc-predef.h:
ext/ed25519-amd64-asm/fe25519.h:

ext/ed25519-amd64-asm/ge25519_double_scalarmult.o: \
 ext/ed25519-amd64-asm/ge25519_double_scalarmult.c \
 /workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/stdc-predef.h \
 ext/ed25519-amd64-asm/fe25519.h ext/ed25519-amd64-asm/sc25519.h \
 ext/ed25519-amd64-asm/ge25519.h \
 ext/ed25519-amd64-asm/ge25519_base_slide_multiples.data
/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/stdc-predef.h:
ext/ed25519-amd64-asm/fe25519.h:
ext/ed25519-amd64-asm/sc25519.h:
ext/ed25519-amd64-asm/ge25519.h:
ext/ed25519-amd64-asm/ge25519_base_slide_multiples.data:

# Four simple-library notice dispositions for #528

Ready for root review and integration. Exact current notice/source attribution is verified for enet, libspeexdsp, libxmp-lite and opusfile across14 profile occurrences. The proposed treatment is conservative: include each complete pinned component source and its full applicable notices in the existing source/publication worklist. Missing historical compiler/link detail remains a recorded uncertainty about consumers; it does not block this inclusive treatment or justify excluding source/notices.

This is a source/evidence disposition, not a collector run or whole-release publication clearance. Original records are unchanged. Accepted notice04 run20261015T113024Z-b6cc9938 supplies43 collected occurrences (38 exact historical observations and5 new), original0/0/0 plus collector/launcher0, ordinarily consumed23d610ed. The14 records used here belong to those38 historical observations: enet's3 originated in failed owner01, the other11 in failed owner03. Accepted04's reuse does not turn those earlier producers into successful runs.

| Component | Exact current source | Profiles | Exact retained notices | Positive package→staged members |
|---|---|---|---|---:|
| enet | v1.3.18 | GENERIC x86_64, H700 AArch64, SM8550 AArch64 | LICENSE; docs/license.dox; AUTHORS is empty and does not count as notice coverage |9|
| libspeexdsp |738e17905e1ca2a1fa932ddd9c2a85d089f4e845| Same3 main profiles | Entire COPYING and AUTHORS, including all named copyright holders |9|
| libxmp-lite |4.5.0| Same3 main profiles | Entire README, including its full LICENSE section |9|
| opusfile |9d718345ce03b2fad5d7d28e0bcd1cc69ab2b166| All5 profiles, including H700/SM8550 ARM | Entire COPYING and AUTHORS |30|

The57 positive observations cover shared-library files and links. Opusfile also has12 exact ARM→lib32 package→AArch64 image handoffs. Sixteen package .la metadata files are absent from staged images; that is not absence of the library. Named moonlight, EasyRPG and SDL2_mixer consumer CMakeCache/TargetDirectories files are observed; selected link.txt/.la/Meson patterns do not supply complete consumer reconstruction. We do not assert static exclusion or make that historical reconstruction a new publication gate.

The28 logical notice bindings resolve to8 exact content-addressed blobs totaling8,080bytes, including empty enet AUTHORS. These are actual retained texts, not recipe-header licence labels. The observed enet and libxmp-lite texts carry MIT permission/disclaimer language; libspeexdsp and opusfile COPYING carry the source/binary notice conditions, disclaimer and endorsement condition. The proposal retains complete texts and attribution rather than attempting to narrow them by uncertain build selection.

coverage-map.json binds every source/profile/recipe/output/notice record and records consumer uncertainty. proposed-dispositions.json is the explicit four-row proposal. integration-text.md is ready factual wording for root's existing #528 worklist; it does not request issue closure. originals/ contains exact14 occurrence records, notices/ the8 small payloads, and acceptance-originals/ the actual accepted collection/consumption bindings. Original metadata and hashes are retained in the two index files. No cache, source archive, binary, service, network, collector, preparer or test was read/run by this disposition task.

The three archive identities for enet/libxmp-lite/opusfile are recorded from accepted inventory; libspeexdsp has an exact Git HEAD and no archive SHA in that record. This packet does not manufacture an archive identity, copy complete source artifacts or prove their independent retrieval. Materializing/reference-verifying those complete sources and notices in the final publication bundle remains the existing #528 work, not a new compiler-reproducibility requirement.

Shader per-file scope/installed-origin collisions, ZeroTier selected/nonfree scope, database per-content applicability, ABL implementation/access and Doom WAD terms are outside this four-row treatment and remain their actual recorded dispositions. The other12 non-prebuilt components and prebuilt/source issues are not silently cleared. Physical/device/runtime qualification and a public RC are not claimed.

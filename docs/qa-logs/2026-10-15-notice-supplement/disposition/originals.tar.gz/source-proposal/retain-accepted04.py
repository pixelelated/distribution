"""Retain completed notice04 originals; no collector, cache or target execution."""
from pathlib import Path
import hashlib,json,stat,tarfile,gzip,decimal,datetime
S=Path('/tmp/pix-m7-current-notice-supplement-20261015-04')
O=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-04')
R=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T113024Z-b6cc9938')
V=Path('/tmp/pix-m7-notice04-root-review-20261015')
D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-notice-supplement/accepted')
P=D.with_name('failure03');P1=D.with_name('failure')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def verify_seal(p,expected):
 assert sha(p/'SHA256SUMS')==expected
 for line in (p/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(p/n)==h
verify_seal(S,'b7a03ebae20a8d7050b8254e2249643da3be2d5cd3ffe76ef797509a73fdeb8f')
verify_seal(P,'bd4f13b2683808882a9d3c43378235fa8deff00a6e753dc100f44e44ae9f16be')
verify_seal(P1,'243ad17d66453598349fc0442c155e2e60a4bbc7f143cc3f449d1c55d8232850')
pm=load(P/'members.json');pr=load(P/'reused-members.json')['members'];pmsha=sha(P/'members.json')
old={}
for x in pm['members']+pr:
 if x['kind']=='file' and x['member'].startswith('failed-owner/collection/'):
  y=dict(x)
  y['retained_bytes_at']=x.get('retained_bytes_at',{'archive':str(P/'originals.tar.gz'),'archive_sha256':pm['archive_sha256'],'member':x['member'],'prior_manifest_sha256':pmsha})
  old[x['member'].removeprefix('failed-owner/')]=y
payloads=load(O/'collection-members.json');assert len(payloads)==7193
for x in payloads:
 p=O/x['path'];assert p.resolve(strict=True).is_relative_to(O/'collection') and not p.is_symlink()
 assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
assert sorted(x['path'] for x in payloads)==sorted(str(p.relative_to(O)) for p in (O/'collection').rglob('*') if p.is_file())
c=load(R/'admission-consumed.json');a=load(O/'collection-result.json');runtime=load(O/'result.json');child=load(O/'stage/notices.result.json');cleanup=load(O/'cleanup.json')
assert sha(R/'admission-consumed.json')=='7302e03844ddc4a6deae5363893bdd396725eff17b3d4737445a64036cd918ba'
assert c['id']=='23d610ed3610468c8902f9019a38a65e' and c['state']=='consumed'
assert [c['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[0,0,0]
assert load(O/'launcher-result.json')['runner_returncode']==0
assert child['original_child_returncode']==0 and child['wait_observed'] and not child['timeout'] and not child['interrupted'] and not child['cleanup_signals']
assert cleanup['all_recorded_identities_absent'] and not cleanup['signals_sent'] and not cleanup['errors']
assert runtime['result']=='PASS_NOTICE_COLLECTION_WITH_OPEN_DISPOSITIONS'
assert (a['occurrences'],a['new_occurrences'],a['reused_occurrences'],a['content_addressed_text_members'],a['retained_text_bytes'])==(43,5,38,7187,46303721)
controls=load(V/'guard-controls-result.json');assert controls['original_exit']==0
external=[]
for e in load(O/'resume.json')['completed']:
 q=Path(e['path']);rel='collection/'+q.name;x=old[rel]
 assert e['sha256']==x['sha256'] and e['bytes']==x['bytes'] and str(q)==x['original_path']
 z=dict(e);z['original_metadata']={k:x[k] for k in ['mode','uid','gid','mtime_ns']};z['retained_bytes_at']=x['retained_bytes_at'];external.append(z)
assert len(external)==38
rows=[];pairs=[];reused=[]
for root,prefix in [(S,'original-source'),(O,'accepted-owner'),(R,'original-watch-run'),(V,'root-review')]:
 for p in [root,*sorted(root.rglob('*'))]:
  assert not p.is_symlink() and (p.is_file() or p.is_dir());s=p.stat();name=prefix+('/'+str(p.relative_to(root)) if p!=root else '')
  assert not p.is_file() or s.st_size<128*1024**2
  row={'member':name,'original_path':str(p),'kind':'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None}
  prior=old.get(str(p.relative_to(O))) if root==O and p.is_file() else None
  if prior is not None and row['sha256']==prior['sha256'] and row['bytes']==prior['bytes']:
   row['retained_bytes_at']=prior['retained_bytes_at'];reused.append(row)
  else:rows.append(row);pairs.append((p,name,row))
assert len([r for r in reused if r['member'].startswith('accepted-owner/collection/notices/')])==7186
owner_total=sum(p.stat().st_size for p in O.rglob('*') if p.is_file());assert owner_total==48543758
assert not D.exists();D.mkdir(parents=True)
archive=D/'originals.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for p,name,row in pairs:
    m=t.gettarinfo(str(p),arcname=name);m.pax_headers={'mtime':str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(10**9))};row['uname']=m.uname;row['gname']=m.gname
    if p.is_file():
     with p.open('rb') as src:t.addfile(m,src)
    else:t.addfile(m)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  assert m.name.rstrip('/')==r['member'] and m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'] and m.uname==r['uname'] and m.gname==r['gname']
  assert int(decimal.Decimal(m.pax_headers['mtime'])*decimal.Decimal(10**9))==r['mtime_ns']
  if r['kind']=='file':assert m.isfile() and m.size==r['bytes'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']==sha(Path(r['original_path']))
  else:assert m.isdir()
dump(D/'members.json',{'archive_sha256':sha(archive),'members':rows,'files':sum(r['kind']=='file' for r in rows),'directories':sum(r['kind']=='directory' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)})
dump(D/'reused-members.json',{'members':reused,'scope':'Exact owner04 original metadata and byte hashes; identical content retained once in failure03 or failure archive, with exact archive/member/manifest links.'})
dump(D/'external-occurrence-references.json',{'members':external,'scope':'38 original occurrence records remain historical observations:11 owner01 and27 owner03. Exact hashes were rechecked by accepted04 consumer and bound to prior independently verified custody. They are not bytes retained inside owner04, new source observations, or successful earlier producers.'})
dump(D/'outcomes.json',{'original_source_seal':sha(S/'SHA256SUMS'),'owner':str(O),'run':str(R),'consumed_id':c['id'],'consumed_sha256':sha(R/'admission-consumed.json'),'original_command_monitor_runner':[0,0,0],'original_collector_exit':0,'original_launcher_exit':0,'collector_elapsed_seconds':1.246988,'timeout':False,'cleanup_signals':[],'occurrences':43,'historical_reused_occurrences':38,'new_occurrences':5,'content_addressed_text_members':7187,'text_bytes':46303721,'actual_owner_bytes':owner_total,'named_input_hash_bytes':a['named_input_hash_bytes'],'maximum_new_batch_selected_rows':a['maximum_new_batch_selected_rows'],'synthetic_controls_original_exit':0,'synthetic_controls_cases':14,'prior_failed_producers_relabelled':False,'original03_bound_breach_preserved':True,'publication_clearance':False,'publication_bundle_complete':False,'independent_SYSTEM_relation_established':False})
(D/'README.md').write_text('''# #528 notice supplement: accepted bounded revision04 collection

Original run20261015T113024Z-b6cc9938 completed with collector, command, monitor, runner and launcher exits0. Admission23d610ed3610468c8902f9019a38a65e was ordinarily consumed at11:30:48UTC. The original result is PASS_NOTICE_COLLECTION_WITH_OPEN_DISPOSITIONS: it is collection acceptance, not publication or licence clearance. No timeout, interruption, cleanup signal or cleanup error occurred. Root's14 isolated source controls exited0 in0.032seconds before allocation; exact stdout/stderr/result are retained. The source packet's UNRUN statements describe its earlier preparation, not this later execution.

The43 occurrence records comprise38 exact referenced historical observations (11 from failed owner01,27 from failed owner03) and5 new observations. Owner04 contains7187 text members/46,303,721bytes and total48,543,758bytes, within256MiB. It hashed315,577,456 named-input bytes; the largest new selected batch had43 rows. Historical records are not counted as freshly observed or owner04-retained bytes. Failure01/02/03 remain failed originals; owner03's305,482,534-byte output exceeded its promised256MiB bound and is not relabelled compliant.

originals.tar.gz contains the exact sealed source04, new owner04 bytes, watched-run/admission/consumption originals and root review. members.json preserves included byte hashes, modes, owners and nanosecond mtimes. reused-members.json preserves owner04 metadata and exact archive/member links for existing content already held by sibling failure03/ or failure/. external-occurrence-references.json binds all38 original JSONs through that prior custody. Every7193 actual owner04 collection member was rehashed and complete membership compared to its original manifest; prior custody seals/archive hashes were checked. Prior historical JSONs use their accepted consumer hashes and already independently verified custody, without copying their259MB again.

Root's first optional cat run.path observation raced file creation and returned1; no owner rerun occurred. The retained completion-readback.json distinguishes this observation from the later original collector/runner/launcher0.

No cache, firmware or bulk source archive was copied. Retention did not run a collector, preparer, target, service or test. Original source selection, per-content attribution/applicability, shader/ZeroTier scope, ABL implementation, Doom WAD terms, independent SYSTEM relation and publication/custody work remain as recorded. This packet does not close those dispositions.
''')
dump(D/'custody-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_CUSTODY_OF_ACCEPTED_COLLECTION_ORIGINALS','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'actual_collection_members_rehashed':len(payloads),'reused_payloads':len(reused),'historical_occurrences_referenced':38,'prior_custody_seals':[sha(P/'SHA256SUMS'),sha(P1/'SHA256SUMS')],'new_collector_or_product_runtime':False})
files=sorted(p for p in D.iterdir() if p.is_file());(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
for line in (D/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(D/n)==h
print(json.dumps({'directory':str(D),'seal':sha(D/'SHA256SUMS'),'archive':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'reused_payloads':len(reused),'external_occurrences':len(external)},indent=2))

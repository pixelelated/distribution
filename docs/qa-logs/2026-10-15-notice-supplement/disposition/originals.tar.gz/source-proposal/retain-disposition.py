"""Seal the evidence-only proposal and preserve exact private packet bytes/metadata."""
from pathlib import Path
import hashlib,json,stat,tarfile,gzip,decimal,datetime
S=Path('/tmp/pix-m7-notice-disposition-20261015')
D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-notice-supplement/disposition')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
for idx in ['originals-index.json','acceptance-originals-index.json']:
 a=json.loads((S/idx).read_text())
 if isinstance(a,list): rr=a
 elif 'originals' in a:rr=a['originals']
 else:
  rr=[]
  for v in a.values():
   if isinstance(v,list):rr+=v
 for r in rr:
  if not isinstance(r,dict) or 'retained' not in r:continue
  p=S/r['retained'];assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
assert not (S/'SHA256SUMS').exists()
files=sorted(p for p in S.rglob('*') if p.is_file());(S/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(S))+'\n' for p in files))
for line in (S/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(S/n)==h
assert not D.exists();D.mkdir(parents=True)
rows=[];pairs=[]
for p in [S,*sorted(S.rglob('*'))]:
 assert not p.is_symlink() and (p.is_file() or p.is_dir());s=p.stat();name='source-proposal'+('/'+str(p.relative_to(S)) if p!=S else '')
 row={'member':name,'original_path':str(p),'kind':'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None};rows.append(row);pairs.append((p,name,row))
archive=D/'originals.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for p,name,row in pairs:
    m=t.gettarinfo(str(p),arcname=name);m.pax_headers={'mtime':str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(10**9))};row['uname']=m.uname;row['gname']=m.gname
    if p.is_file():
     with p.open('rb') as src:t.addfile(m,src)
    else:t.addfile(m)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  assert m.name.rstrip('/')==r['member'] and m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'] and m.uname==r['uname'] and m.gname==r['gname']
  assert int(decimal.Decimal(m.pax_headers['mtime'])*decimal.Decimal(10**9))==r['mtime_ns']
  if r['kind']=='file':assert m.isfile() and m.size==r['bytes'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']==sha(Path(r['original_path']))
  else:assert m.isdir()
dump(D/'members.json',{'archive_sha256':sha(archive),'members':rows,'files':sum(r['kind']=='file' for r in rows),'directories':sum(r['kind']=='directory' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)})
(D/'README.md').write_text('''# #528 four-library notice disposition proposal

This is the exact source/evidence proposal from /tmp/pix-m7-notice-disposition-20261015. Root may review and integrate it; no tracker, rule or canonical record was changed. The archive preserves14 original occurrence JSONs,8 exact notice blobs (8,080bytes), source/profile/output mapping, accepted notice04 bindings, proposed four-row treatment and ready additive worklist wording. Original byte/mode/uid/gid/nanosecond-time metadata is in members.json; source original locators and metadata remain inside the packet's two index files.

The proposed narrow closure is current notice/source-member rebinding for enet, libspeexdsp, libxmp-lite and opusfile. Their14 profile records show57 positive selected shared-library file/link package→staged-image matches and12 opusfile ARM→lib32 handoffs. Sixteen missing .la metadata files do not establish exclusion. Conservative complete component source plus full notices/attribution is selected for the existing source/notice bundle work; consumer linkage uncertainty does not create a blanket historical compiler-flag gate.

No complete source archive is copied or independently retrieved by this packet. Whole-release publication, source-bundle materialization, actual notice delivery and off-host custody remain existing #528 work. Other component scope/terms, including shader/ZeroTier, ABL and Doom, remain unchanged. Original failed collectors and their limits are preserved in the adjacent failure packets. Accepted04 collection and its exact original0/consumption are retained separately in sibling accepted/.

No cache scan, collector, preparer, test, target, service, network transfer or product edit was performed for this evidence disposition. Archive creation and byte/metadata custody verification are the only executable work here. No public RC or legal clearance is claimed.
''')
dump(D/'custody-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_CUSTODY_SOURCE_EVIDENCE_PROPOSAL','source_seal':sha(S/'SHA256SUMS'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'proposal_sha256':sha(S/'proposed-dispositions.json'),'integration_text_sha256':sha(S/'integration-text.md'),'accepted_collection_seal':'7cc8dd05d32d5dbcb496de311a0bdb39034637cf19c5ddc747e836b1f682e607','new_tests_or_collection':False,'publication_clearance':False})
files=sorted(p for p in D.iterdir() if p.is_file());(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
for line in (D/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(D/n)==h
print(json.dumps({'directory':str(D),'seal':sha(D/'SHA256SUMS'),'source_seal':sha(S/'SHA256SUMS'),'archive':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)},indent=2))

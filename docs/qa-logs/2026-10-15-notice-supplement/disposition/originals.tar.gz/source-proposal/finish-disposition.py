"""Assemble a source-only notice disposition from retained originals, without cache reads."""
from pathlib import Path
import json,hashlib,shutil,datetime
P=Path('/tmp/pix-m7-notice-disposition-20261015');a=json.loads((P/'coverage-map.json').read_text())
O=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-04');R=Path((O/'run.path').read_text().strip())
D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-notice-supplement/accepted')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
assert sha(D/'SHA256SUMS')=='7cc8dd05d32d5dbcb496de311a0bdb39034637cf19c5ddc747e836b1f682e607'
assert sha(O/'collection-result.json')==a['accepted_collection_result_sha256']
assert sha(O/'result.json')==a['accepted_runtime_sha256']
originals=[]
for src in [O/'collection-result.json',O/'result.json',R/'admission-consumed.json',D/'outcomes.json',D/'custody-verification.json',D/'SHA256SUMS',Path('/tmp/pix-m7-current-notice-gaps-20261015/next-selection.md')]:
 dest=P/'acceptance-originals'/('accepted-'+src.name if src.parent==D else src.name)
 dest.parent.mkdir(exist_ok=True);shutil.copy2(src,dest);s=src.stat()
 originals.append({'original_path':str(src),'retained':str(dest.relative_to(P)),'sha256':sha(src),'bytes':s.st_size,'mode':s.st_mode&0o7777,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns})
rows=[]
for component,s in a['source_sets'].items():
 records=[r for r in a['source_records'] if r['component']==component]
 positive=sum(o['package_matches_staged'] for r in records for o in r['selected_outputs'])
 missing=sum(o['staged_kind']=='missing' for r in records for o in r['selected_outputs'])
 rows.append({'component':component,'proposed_status':'CURRENT_NOTICE_REBIND_VERIFIED_CONSERVATIVE_FULL_COMPONENT_SOURCE_SELECTED','profiles':s['profiles'],'current_source_identity':s['source'],'original_source_inputs':s['cache'],'recipe_inheritance':s['recipe_inheritance'],'exact_notice_members':s['notice_members'],'positive_package_to_staged_files_or_links':positive,'absent_staged_la_metadata':missing,'treatment':'Include complete exact component source, all listed notice/author members and applicable recorded recipe/patch inputs in the existing source/publication worklist. Do not prune source/notices based on missing historical consumer flags or link logs.','verified_now':['Exact notice bytes and original source/profile/member attribution.','Positive selected shared-library package-to-staged-image identity.','All applicable profiles remain included, including opusfile ARM compatibility rows where present.'],'not_claimed':['Every statically linked consumer reconstructed.','Independently extracted SYSTEM proof for these particular library paths.','Full source archive copied into this packet or public retrieval verified.','Whole release licence clearance, publication or off-host custody complete.'],'remaining_existing_work':['Materialize/reference the complete source artifact in the final source bundle and verify its actual retained identity using the existing final inventory/source procedure.','Carry exact notices and author attribution into the distributed notice bundle and manifest; retain full component scope when consumer linkage is unknown.','Complete existing independent retrieval/off-host custody requirements at release level.'],'informational_uncertainty':'Named consumer CMake cache and target-directory metadata exist; selected link/object detail is incomplete. This is not an exclusion claim or a requirement to reconstruct historical compiler flags before conservative source/notice inclusion.'})
assert sum(r['positive_package_to_staged_files_or_links'] for r in rows)==57
assert sum(r['absent_staged_la_metadata'] for r in rows)==16
dump('proposed-dispositions.json',{'schema':1,'proposal_only':True,'scope':'Four existing simple-library notice-rebind rows only; no change to the original collector records or whole #528 acceptance criteria.','basis_selected_current_sha256':sha(Path('/tmp/pix-m7-current-notice-gaps-20261015/selected-current.json')),'accepted_collection_seal':sha(D/'SHA256SUMS'),'rows':rows,'source_bundle_complete':False,'publication_clearance':False,'tracker_or_shared_record_mutated':False})
dump('acceptance-originals-index.json',{'originals':originals})
(P/'README.md').write_text('''# Four simple-library notice dispositions for #528

Ready for root review and integration. Exact current notice/source attribution is verified for enet, libspeexdsp, libxmp-lite and opusfile across14 profile occurrences. The proposed treatment is conservative: include each complete pinned component source and its full applicable notices in the existing source/publication worklist. Missing historical compiler/link detail remains a recorded uncertainty about consumers; it does not block this inclusive treatment or justify excluding source/notices.

This is a source/evidence disposition, not a collector run or whole-release publication clearance. Original records are unchanged. Accepted notice04 run20261015T113024Z-b6cc9938 supplies43 collected occurrences (38 exact historical observations and5 new), original0/0/0 plus collector/launcher0, ordinarily consumed23d610ed. The14 records used here belong to those38 historical observations: enet's3 originated in failed owner01, the other11 in failed owner03. Accepted04's reuse does not turn those earlier producers into successful runs.

| Component | Exact current source | Profiles | Exact retained notices | Positive package→staged members |
|---|---|---|---|---:|
| enet | v1.3.18 | GENERIC x86_64, H700 AArch64, SM8550 AArch64 | LICENSE; docs/license.dox; AUTHORS is empty and does not count as notice coverage |9|
| libspeexdsp |738e17905e1ca2a1fa932ddd9c2a85d089f4e845| Same3 main profiles | Entire COPYING and AUTHORS, including all named copyright holders |9|
| libxmp-lite |4.5.0| Same3 main profiles | Entire README, including its full LICENSE section |9|
| opusfile |9d718345ce03b2fad5d7d28e0bcd1cc69ab2b166| All5 profiles, including H700/SM8550 ARM | Entire COPYING and AUTHORS |30|

The57 positive observations cover shared-library files and links. Opusfile also has12 exact ARM→lib32 package→AArch64 image handoffs. Sixteen package .la metadata files are absent from staged images; that is not absence of the library. Named moonlight, EasyRPG and SDL2_mixer consumer CMakeCache/TargetDirectories files are observed; selected link.txt/.la/Meson patterns do not supply complete consumer reconstruction. We do not assert static exclusion or make that historical reconstruction a new publication gate.

The28 logical notice bindings resolve to8 exact content-addressed blobs totaling8,080bytes, including empty enet AUTHORS. These are actual retained texts, not recipe-header licence labels. The observed enet and libxmp-lite texts carry MIT permission/disclaimer language; libspeexdsp and opusfile COPYING carry the source/binary notice conditions, disclaimer and endorsement condition. The proposal retains complete texts and attribution rather than attempting to narrow them by uncertain build selection.

coverage-map.json binds every source/profile/recipe/output/notice record and records consumer uncertainty. proposed-dispositions.json is the explicit four-row proposal. integration-text.md is ready factual wording for root's existing #528 worklist; it does not request issue closure. originals/ contains exact14 occurrence records, notices/ the8 small payloads, and acceptance-originals/ the actual accepted collection/consumption bindings. Original metadata and hashes are retained in the two index files. No cache, source archive, binary, service, network, collector, preparer or test was read/run by this disposition task.

The three archive identities for enet/libxmp-lite/opusfile are recorded from accepted inventory; libspeexdsp has an exact Git HEAD and no archive SHA in that record. This packet does not manufacture an archive identity, copy complete source artifacts or prove their independent retrieval. Materializing/reference-verifying those complete sources and notices in the final publication bundle remains the existing #528 work, not a new compiler-reproducibility requirement.

Shader per-file scope/installed-origin collisions, ZeroTier selected/nonfree scope, database per-content applicability, ABL implementation/access and Doom WAD terms are outside this four-row treatment and remain their actual recorded dispositions. The other12 non-prebuilt components and prebuilt/source issues are not silently cleared. Physical/device/runtime qualification and a public RC are not claimed.
''')
(P/'integration-text.md').write_text('''## Proposed additive #528 worklist disposition — four current library notice rows

Current notice/source-member rebinding is verified for enet, libspeexdsp, libxmp-lite and opusfile in the accepted43-occurrence notice supplement. Across their14 profile records, all28 listed notice/member bindings match8 exact retained texts (8,080bytes); all57 selected shared-library files/links match package→staged image, and opusfile retains12 positive ARM→lib32 handoffs. The16 missing .la metadata files do not remove a library from scope.

Treat these four rows by conservative inclusion: carry each complete exact component source, its recorded recipe/patch inputs and all retained notice/author texts into the final source and notice bundles. Do not prune based on missing expanded flags or consumer link logs. Complete consumer linkage reconstruction remains unproved and informational for this treatment; neither static exclusion nor historical reproducibility is claimed. enet's empty AUTHORS contributes no notice coverage; libxmp-lite's full notice is in README; Speex/Opus COPYING and AUTHORS remain whole.

The selected-notice rebinding task for these four rows can close after this disposition is accepted. Full-source bundle materialization/identity, distributed notice delivery, independent retrieval and off-host custody remain the existing release-level #528 work. Source archive identities are retained for enet/libxmp-lite/opusfile; Speex has a Git HEAD, not a newly invented archive hash. No full source archive was copied by this disposition. Other component scope issues, including shader/ZeroTier, ABL and Doom, are unchanged. This is not whole-issue or publication clearance.

Evidence: docs/qa-logs/2026-10-15-notice-supplement/disposition/ and sibling accepted/. Original failures01–03 remain separate, including the explicit original03 retained-output bound breach. Accepted04 completed with original collector/command/monitor/runner/launcher0 and ordinary consumed admission23d610ed3610468c8902f9019a38a65e.
''')
dump('assessment.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_EVIDENCE_DISPOSITION_PROPOSAL_READY','component_count':4,'profile_occurrences':14,'notice_bindings':28,'unique_notice_blobs':8,'notice_bytes':8080,'positive_package_to_staged_members':57,'positive_arm_lib32_handoffs':12,'absent_la_metadata':16,'new_tests':False,'cache_reads':False,'source_archives_opened':False,'tracker_mutations':False,'full_source_bundle_materialized':False,'publication_clearance':False})
for r in a['source_records']:
 p=P/r['record']['retained'];assert sha(p)==r['record']['sha256']
for h,r in a['notice_index'].items():assert sha(P/r['retained'])==h and (P/r['retained']).stat().st_size==r['bytes']
print(json.dumps({'proposal_sha256':sha(P/'proposed-dispositions.json'),'integration_text_sha256':sha(P/'integration-text.md'),'readme_sha256':sha(P/'README.md'),'records':14,'notice_blobs':8},indent=2))

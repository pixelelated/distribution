"""Copy only completed failed-run evidence into the assigned durable directory."""
from pathlib import Path
import hashlib,json,stat,tarfile,gzip,decimal,datetime
S=Path('/tmp/pix-m7-current-notice-supplement-20261015-03')
O=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-03')
R=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T111040Z-0d23a097')
V=Path('/tmp/pix-m7-notice03-root-review-20261015')
D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-notice-supplement/failure03')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
assert sha(S/'SHA256SUMS')=='a3a137e449a53673414eefdd23839f6d9cf55aceaa670e55d568faf08df76b1f'
for line in (S/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(S/n)==h
assert sha(O/'partial-members.json')==load(O/'failure-completion-evidence.json')['evidence'][1]['sha256']
partial=load(O/'partial-members.json');assert len(partial)==7224
for r in partial:
 p=Path(r['path']);assert p.resolve(strict=True).is_relative_to(O/'collection') and not p.is_symlink()
 assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert sorted(r['path'] for r in partial)==sorted(str(p) for p in (O/'collection').rglob('*') if p.is_file())
assert sum(r['bytes'] for r in partial)==305482534
c=load(R/'admission-consumed.json');assert c['state']=='consumed' and c['id']=='9c391a0521ba4a98bd2f0547773bca8b'
assert [c['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[1,0,1]
assert load(O/'launcher-result.json')['runner_returncode']==1
child=load(O/'stage/notices.result.json');assert child['original_child_returncode']==1 and child['wait_observed'] and not child['timeout'] and not child['interrupted'] and not child['cleanup_signals']
assert not D.exists();D.mkdir(parents=True)
prior=D.with_name('failure')
assert sha(prior/'SHA256SUMS')=='243ad17d66453598349fc0442c155e2e60a4bbc7f143cc3f449d1c55d8232850'
for line in (prior/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(prior/n)==h
prior_members=load(prior/'members.json');prior_rows={r['member'].removeprefix('failed-owner/'):r for r in prior_members['members'] if r['kind']=='file' and r['member'].startswith('failed-owner/collection/')}
rows=[];pairs=[];reused=[]
for root,prefix in [(S,'original-source'),(O,'failed-owner'),(R,'original-watch-run'),(V,'root-source-review')]:
 for p in [root,*sorted(root.rglob('*'))]:
  assert not p.is_symlink() and (p.is_file() or p.is_dir());s=p.stat();name=prefix+('/'+str(p.relative_to(root)) if p!=root else '')
  assert not p.is_file() or s.st_size<128*1024**2,'unexpected bulk original'
  row={'member':name,'original_path':str(p),'kind':'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None}
  if root==O and p.is_file() and str(p.relative_to(O)) in prior_rows:
   old=prior_rows[str(p.relative_to(O))]
   assert row['sha256']==old['sha256'] and row['bytes']==old['bytes']
   row['retained_bytes_at']={'archive':str(prior/'originals.tar.gz'),'archive_sha256':prior_members['archive_sha256'],'member':old['member'],'prior_manifest_sha256':sha(prior/'members.json')}
   reused.append(row)
  else:rows.append(row);pairs.append((p,name,row))
assert len(reused)==2813

archive=D/'originals.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for p,name,row in pairs:
    m=t.gettarinfo(str(p),arcname=name);m.pax_headers={'mtime':str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(10**9))};row['uname']=m.uname;row['gname']=m.gname
    if p.is_file():
     with p.open('rb') as src:t.addfile(m,src)
    else:t.addfile(m)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  assert m.name.rstrip('/')==r['member'] and m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'] and m.uname==r['uname'] and m.gname==r['gname']
  assert int(decimal.Decimal(m.pax_headers['mtime'])*decimal.Decimal(10**9))==r['mtime_ns']
  if r['kind']=='file':assert m.isfile() and m.size==r['bytes'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']==sha(Path(r['original_path']))
  else:assert m.isdir()
dump(D/'members.json',{'archive_sha256':sha(archive),'members':rows,'files':sum(r['kind']=='file' for r in rows),'directories':sum(r['kind']=='directory' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)})
dump(D/'reused-members.json',{'members':reused,'scope':'Exact current original metadata; byte-identical payload content is retained once in the prior failure archive, explicitly linked by member and hash.'})
dump(D/'outcomes.json',{'original_source_seal':sha(S/'SHA256SUMS'),'run':str(R),'owner':str(O),'consumed_id':c['id'],'consumed_sha256':sha(R/'admission-consumed.json'),'original_command_monitor_runner':[1,0,1],'original_collector_exit':1,'original_launcher_exit':1,'timeout':False,'cleanup_signals':[],'partial_payload_files':len(partial),'partial_payload_bytes':305482534,'retained_text_bytes':46298646,'completed_occurrences':38,'attempted_incomplete_occurrence':'generic-x64-x86_64:zerotier-one','current_batch_selected_rows':16,'original_owner_exceeded_promised_256MiB_bound':True,'publication_clearance':False,'selection_complete':False})
(D/'README.md').write_text("""# #528 original notice-supplement revision03 failure

This retains immutable sourcea3a137e4, its root review, owner03 and watched run20261015T111040Z-0d23a097. Original collector, command, runner and launcher exits are1; monitor0. The collector stopped after approximately132.14seconds at GENERIC zerotier-one's ext/*/*.d intermediate-path assertion, without timeout, interruption or cleanup signals. Ordinary admission9c391a0521ba4a98bd2f0547773bca8b was consumed failed-investigated11:19:24UTC.

The complete original partial manifest covers7224files/305,482,534bytes, including38complete occurrence JSONs totaling259,183,888bytes and46,298,646bytes of content-addressed text. Those original retained bytes already exceeded the promised256MiB owner bound. The old aggregate check ran only after successful collection and did not enforce that bound on this failing path. This is an explicit original bounded-collector defect/limitation; no bound compliance or successful producer is claimed. The38files include11historical owner01 observations plus27 completed owner03 observations, including one disclosure-only ABL record. The first ZeroTier occurrence did not complete.

originals.tar.gz preserves exact source/root-review/watch/owner records and newly produced partial bytes. members.json retains included original hashes/modes/uid/gid/nsmtime. reused-members.json records current original metadata and exact prior archive/member links for2813byte-identical payloads already retained in sibling failure/. Every one of the7224actual partial payloads was rehashed and complete membership verified. Referenced prior bytes are not silently omitted or duplicated. The original partial member manifest and every failure/consumption channel remain retained.

No build caches, firmware or source-tree archive was copied. No old source/owner/archive was changed, and no collector/preparer, product runtime, tracker or shared-record edit occurred during retention. The source correction and any new runtime remain separate. Source selection, per-content attribution/applicability, archive-member/public retrieval, ABL/Doom and publication/custody limits remain explicit.
""")
dump(D/'custody-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_CUSTODY_OF_FAILED_ORIGINALS','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'partial_payload_members_verified':7224,'reused_payloads_linked_to_prior_custody':len(reused),'checks':['Original source outer seal and65 payloads exact.','All7224 partial payloads exact, complete membership compared to original completed output directory.','Original child1, command/monitor/runner1/0/1, launcher1 and consumed failure retained.','Every archive member byte/hash/mode/uid/gid/name/nsmtime matches original.'],'new_collector_or_product_runtime':False})
files=sorted(p for p in D.iterdir() if p.is_file());(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
for line in (D/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(D/n)==h
print(json.dumps({'directory':str(D),'seal':sha(D/'SHA256SUMS'),'archive':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'reused_payloads':len(reused),'reused_payload_bytes':sum(r['bytes'] for r in reused)},indent=2))

# #528 selected-notice supplement revision 04 — SOURCE ONLY, UNRUN

Revision03 run `20261015T111040Z-0d23a097` stopped after approximately132.14seconds with original collector/command/runner/launcher1, monitor0, no timeout. It produced38 complete occurrence JSONs, retaining46,298,646bytes of content-addressed text, before GENERIC zerotier-one's `ext/*/*.d` pattern failed with `metadata parent link/special path`. Those originals remain failed evidence; completion of individual records does not qualify the whole producer.

The original traceback and traversal receipt identify the exact pattern but omit its failed candidate path. A subsequent bounded read of only the22 immediate `ext/` entry types found `README.md` first in lexical order: a391-byte regular file, mode0644, mtime1757613129000000000ns; the other21entries are directories. The source sorts candidates, so this identifies the first assertion candidate by source/readback inference, not by inventing a missing original diagnostic. No recursive source/cache enumeration or file-content read was used for that diagnosis.

The minimal matcher correction skips a regular file when the pattern still requires a directory segment. It continues to reject every intermediate symlink, including dangling links, before traversal, and rejects any other special type. Both refusals include the exact candidate path. Leaf link behavior, finite-pattern depth/entry bounds and selected-root containment remain unchanged. Regular-file intermediates cannot match the requested path; treating them as nonmatches does not exclude any matching dependency file or infer that optional code was absent.

## Preserve completed evidence without copying or recollecting it

The38 completed JSONs total259,183,888bytes. Three database records are67,124,088–67,719,141bytes each. **Owner03 already exceeded its promised256MiB owner-output bound before failure:** its retained partial manifest totals305,482,534bytes. The old supervisor's aggregate-size assertion ran only after successful collection, so it never enforced that promised bound on this failing path. This is a second original bounded-collector defect/limitation, not merely a hypothetical duplication issue. Copying those bytes into fresh04 would repeat the breach. Instead, `resume.json` binds every completed original in owner03 by exact path/hash/bytes, its actual failed consumed receipt, partial manifest and original source plan. The collector verifies those complete bytes and their accepted input mapping, then retains only small summary/reference records; it never copies or re-observes those38 source/package selections. The consumer independently rehashes the same original JSONs before qualifying a later successful continuation. Their original metadata and failed-run custody remain separate. The copied historical11 in owner03 retain their original owner01 observation identity in the resume index.

The existing content-addressed text is hash-verified and copied once into fresh04 so all retained text references resolve without recollection. Its46.3MB counts against the same128MiB unique-text ceiling and read budget. Large completed JSON inputs are accepted only at the exact sealed sizes and below the already existing128MiB per-file resource bound; the former16MiB copy guard applied to the eleven small predecessor JSONs and is replaced by exact-size reference validation, not an increased output or collection allowance. Their immutable original paths are protected in retention planning. Only five remaining occurrences are processed: zerotier-one for GENERIC/H700/SM8550, then the two unchanged Doom disclosure-only holds. Database/shader selection is not repeated.

A narrow pre-write accounting guard now counts initial actual owner files and each collector JSON/text write before creation. It reserves4MiB inside the unchanged256MiB ceiling for supervisory receipts; normal collector retention stops at252MiB inclusive of the initial files. A failure receipt is capped at3MiB and always leaves1MiB reserved for supervisory receipts; it cannot consume the entire reserve. The unchanged supervisor final actual-size check remains mandatory, and the consumer independently repeats the actual-size check. External originals are held separately and not counted as physically retained copies in fresh04. No original03 bound compliance is claimed.

All16components,43accepted occurrence inputs, numeric time/byte/output/traversal bounds, database hash-only notice disposition, explicit shader-retention gaps, source/archive linkage limits, publication holds remain unchanged. The actual corresponding-source/public retrieval gaps, per-content attribution, static/vendor selection, ABL implementation/access and Doom terms stay unresolved. This is notice evidence collection, not legal or publication clearance.

`changes.diff` is the full revision03→04 executable/input delta. Lifecycle identity/signal/wait functions and process-identity.py remain unchanged; supervisor/consumer count predicates become38historical plus5new, and the consumer verifies exact external occurrence references. The preparer adds owner03 protection and binds the new immutable resume input. The original failure bodies/seals are retained historically. No candidate import, collector/preparer execution, tests, target process, archive/source-cache read or network operation ran during preparation. The one bounded22-entry metadata read and separately authorized completed-evidence custody are stated above rather than described as no filesystem observation.

## Root execution boundaries

```bash
bash /tmp/pix-m7-current-notice-supplement-20261015-04/commands.sh prepare
bash /tmp/pix-m7-current-notice-supplement-20261015-04/commands.sh preflight
bash /tmp/pix-m7-current-notice-supplement-20261015-04/commands.sh report
# Root reviews actual resource/retention output before allocating.
bash /tmp/pix-m7-current-notice-supplement-20261015-04/commands.sh admit
bash /tmp/pix-m7-current-notice-supplement-20261015-04/commands.sh launch
# Root supervises original channels at <=60-second cadence.
bash /tmp/pix-m7-current-notice-supplement-20261015-04/commands.sh consume
```

Fresh default owner is `/workspace/tmp/pix-m7-current-notice-supplement-20261015-04`. Frozen GENERICf863 ordinary admission/watch tools and separate preparation/report/admission boundaries remain authoritative. Do not run the success consumer after failure. Original38 external JSONs and all failed source/run receipts must remain held until their exact durable custody/reference chain is incorporated. No successful continuation is predicted.

The actual failed03 ordinary admission is `9c391a0521ba4a98bd2f0547773bca8b`, consumed11:19:24UTC. Its exact receipt and7,224-member partial manifest are sealed inputs.


`guard-controls.py` is a separately prepared, **UNRUN** in-memory control file. It reads the hash-bound source text and executes only the three AST-selected `account_output`/`write`/`patterned` definitions with fake paths. Ten proposed write-guard cases cover exact/one-byte-over normal and failure boundaries, existing-byte accounting, overwrite refusal, dangling output-link refusal, the existing per-file bound and bounded reserve use, including the new failure-receipt share cap. Four additional matcher cases cover a regular-file intermediate nonmatch, valid directory/leaf match, parent-link refusal and dangling-parent-link refusal. It never imports the collector or runs its main, touches a production path, or writes a filesystem file. Root may allocate an isolated <=1second check with <1MiB scratch (the fixture writes0bytes) before collection:

```bash
timeout 1s python3 -I -S -B /tmp/pix-m7-current-notice-supplement-20261015-04/guard-controls.py
```

Its original process exit/stdout must be retained separately. Prepared controls and static parsing do not claim that they passed.

#!/usr/bin/env python3
"""Prepare a fresh selected-notice owner; no collector/cache reads or runtime."""
from pathlib import Path
import argparse,hashlib,json,re,runpy,shutil
P=Path(__file__).resolve().parent

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()

def put(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')

def main():
    q=argparse.ArgumentParser(description=__doc__);q.add_argument('--owner',type=Path,required=True)
    q.add_argument('--extra-records',type=Path);q.add_argument('--extra-records-sha256')
    a=q.parse_args();names=[]
    for line in (P/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);p=P/n
        assert not Path(n).is_absolute() and '..' not in Path(n).parts and p.is_file() and not p.is_symlink()
        assert sha(p)==h;names.append(n)
    assert sorted(names)==sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
    B=runpy.run_path(str(P/'templates/bindings.py'));B['host_and_serialization']()
    assert Path.cwd()==B['VM_TREE'];O=a.owner
    assert O.parent==Path('/workspace/tmp') and re.fullmatch('pix-m7-current-notice-supplement-20261015-[0-9]{2}',O.name)
    assert not O.exists() and not O.is_symlink()
    plan=json.loads((P/'supplement-plan.json').read_text())
    for name,h in plan['binding_refs'].items():
        p=Path(name);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<8*1024**2
        assert sha(p)==h,name
    extra=P/'extra-records.template.json'
    if a.extra_records is not None:
        extra=a.extra_records
        assert a.extra_records_sha256 is not None and extra.resolve(strict=True)==extra and extra.stat().st_size<=2*1024**2 and sha(extra)==a.extra_records_sha256
    else:assert a.extra_records_sha256 is None
    data=json.loads(extra.read_text());assert data['schema']==1 and isinstance(data['records'],list) and len(data['records'])<=65536
    seen=set()
    for r in data['records']:
        assert set(r)=={'component','profile','role','root_role','relative_path','sha256','interpretation'}
        key=(r['component'],r['profile'],r['root_role'],r['relative_path']);assert key not in seen;seen.add(key)
        assert not Path(r['relative_path']).is_absolute() and '..' not in Path(r['relative_path']).parts and re.fullmatch('[0-9a-f]{64}',r['sha256'])
        assert any((x['component'],x['profile'])==(r['component'],r['profile']) for x in plan['occurrences'])
        if r['root_role'].startswith('retained:'):
            root=Path(r['root_role'].split(':',1)[1]);p=root/r['relative_path']
            assert root.is_absolute() and root.resolve(strict=True)==root and p.resolve(strict=True).is_relative_to(root) and not p.is_symlink()
            assert p.is_file() and p.stat().st_size<=2*1024**2 and sha(p)==r['sha256']
    O.mkdir(mode=0o700);(O/'stage').mkdir();(O/'empty-retention-scan').mkdir()
    for n in ['bindings.py','process-identity.py','collect.py','run.py','run.sh','consume.py']:shutil.copy2(P/'templates'/n,O/n)
    for n in ['resources.json','frozen-tools.json','supplement-plan.json','selected-current.json','basis.json','retained-notice-index.json']:shutil.copy2(P/n,O/n)
    shutil.copy2(extra,O/'extra-records.json')
    put(O/'preparation.json',dict(status='PREPARED_UNRUN',packet=str(P),packet_sha256=sha(P/'SHA256SUMS'),extra_records_sha256=sha(O/'extra-records.json'),prior_inventory_admission='e73b73b3325f41c392a8eb6e7ddeb105',collector_executed=False,cache_inputs_read=False,publication_clearance=False))
    protected=sorted({r['tree'] for r in plan['occurrences']}|{'/workspace/cache/rocknix-sources','/workspace/artifacts/pixelelated-release-sources','/workspace/tmp/pix-m7-final-inventory-20261015-01'})
    put(O/'retention-plan.json',dict(volume='/workspace',scan_roots=[str(O/'empty-retention-scan')],reference_stores=[],protected=protected,candidates=[],builds=[dict(name='m7-current-notice-supplement',terms_bytes={'bounded_text_metadata_and_margin':1024**3},basis='128MiB text + bounded manifests + operating margin. Exact selected input roots read only; no deletion credit.',evidence=[dict(path=str(O/'resources.json'),sha256=sha(O/'resources.json'))])]))
    put(O/'admission-plan.json',dict(checkout=str(B['VM_TREE']),container_checkout=str(B['VM_TREE']),retention_plan=str(O/'retention-plan.json'),retention_report=str(O/'retention-report.json'),stage='m7-current-notice-supplement',profiles=[dict(PROJECT='ROCKNIX',DEVICE=d,ARCH=arch) for d,arch in [('GENERIC_X64','x86_64'),('H700','arm'),('H700','aarch64'),('SM8550','arm'),('SM8550','aarch64')]],outputs=[dict(path=str(O),kind='qa-scratch',issue=528,release_when='Original bounded notice collection consumed and compact evidence retained; source selection, notice interpretation and custody/publication holds remain open.')]))
    put(O/'seal.json',{str(p):sha(p) for p in sorted(O.rglob('*')) if p.is_file()});B['verify'](O)
    print(json.dumps(dict(owner=str(O),status='PREPARED_UNRUN',seal_sha256=sha(O/'seal.json'),publication_clearance=False)))
if __name__=='__main__':main()

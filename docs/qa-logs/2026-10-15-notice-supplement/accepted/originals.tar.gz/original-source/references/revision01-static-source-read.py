"""Source parse/AST and immutable metadata comparison only; imports no candidate tools."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json
D=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parsed=[]
for p in sorted(D.rglob('*.py')):
 ast.parse(p.read_text(),filename=str(p));parsed.append(str(p.relative_to(D)))
def functions(p):
 return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=functions(D/'originals/run.py'),functions(D/'templates/run.py');assert a==b
assert (D/'originals/process-identity.py').read_bytes()==(D/'templates/process-identity.py').read_bytes()
assert functions(D/'originals/bindings.py')['host_and_serialization']==functions(D/'templates/bindings.py')['host_and_serialization']
plan=json.loads((D/'supplement-plan.json').read_text());selected=json.loads((D/'selected-current.json').read_text())
assert len(plan['component_specs'])==16 and len(plan['occurrences'])==43
assert set(plan['component_specs'])=={c['component'] for c in selected['components']} - {'rclone','tailscale'}
for row in plan['occurrences']:
 matches=[x for c in selected['components'] if c['component']==row['component'] for x in c['selected_inputs'] if x['profile']==row['profile']];assert len(matches)==1
 assert all(row[k]==v for k,v in matches[0].items())
assert len([r for r in plan['occurrences'] if 'compatibility_handoff' in r])==2
assert all(plan['component_specs'][c]['hold_only'] for c in ['rocknix-abl','idtech-lr/doom.wad'])
assert plan['limits']['path_rows']==65536 and plan['limits']['text_member_bytes']==2*1024**2 and plan['limits']['retained_text_bytes']==128*1024**2
collector=ast.parse((D/'templates/collect.py').read_text())
imports=[]
for n in ast.walk(collector):
 if isinstance(n,ast.Import):imports += [a.name for a in n.names]
 if isinstance(n,ast.ImportFrom):imports.append(n.module)
assert not {'subprocess','runpy','importlib','tarfile','zipfile','socket','urllib','requests'}.intersection(imports)
for n in ast.walk(collector):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):assert n.func.id not in {'eval','exec','__import__'}
assert sha(D/'basis.json')=='5830ce00d272e8e2b77bf0800e8337674a6d996c6012163a61e2c5c213c96011'
diff=''
for old,new in [('originals/collect-licence-basis.py','templates/collect.py'),('originals/run.py','templates/run.py'),('originals/run.sh','templates/run.sh'),('originals/bindings.py','templates/bindings.py'),('originals/consume.py','templates/consume.py'),('originals/prepare-owner.py','prepare-owner.py'),('originals/commands.sh','commands.sh'),('originals/resources.json','resources.json')]:
 diff+=''.join(difflib.unified_diff((D/old).read_text().splitlines(True),(D/new).read_text().splitlines(True),fromfile=old,tofile=new))
(D/'changes.diff').write_text(diff)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOURCE_PARSED_AND_REVIEWED_UNRUN','parsed_source_files':parsed,'unchanged_supervisor_functions':sorted(a),'process_identity_bytes_unchanged':True,'serialization_function_unchanged':True,'components':16,'profile_occurrences':43,'immutable_selected_rows_preserved':True,'arm_opusfile_handoffs_bound':2,'historical_notice_records':len(plan['historical_notices']),'collector_imports':imports,'limits':plan['limits'],'scope':'AST/source and bound JSON comparison only. No candidate imports, collector, preparer, admission, archive or cache reads, tests, services or runtime.','limitations':['Exact generated metadata existence and sizes are unobserved; bounded absence remains explicit and limit hits fail.','No JAR/archive reader added; original selected index/link receipts remain optional named inputs with missing-selection gaps.','No independent SYSTEM extraction or legal/publication clearance.']}
(D/'static-source-review.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'parsed':len(parsed),'unchanged_supervisor_functions':len(a),'components':16,'occurrences':43,'changes_sha256':sha(D/'changes.diff'),'collector_sha256':sha(D/'templates/collect.py')},indent=2))

# Minimal additive change to the existing notice collector

Base: retained `collect-licence-basis.py`, SHA-256
`495fb9cbcb571be0fff92d0c3625a54e901553bc2e9b765d26d9bd61eb0738c9`.
Do not edit or rerun that sealed historical script. Prepare a small derivative
in a fresh owner; preserve its content-addressed notice files and component
records. Reuse the already reviewed owner/monitor lifecycle for a separately
allocated stage. No new runner, full-cache census or source download is needed
for this notice-selection supplement.

## Required input binding before implementation freeze

1. The completed final inventory's original result, consumed receipt, outer
   source/result hashes, five profile input manifests, component maps and
   immutable accepted bundle hashes. VM/H700 stay f863; SM is 9aa7 with the
   exact ABL-checksum delta. The final inventory must select the actual source
   member identity rather than a package-name/version-only association.
2. `selection-plan.json` narrowed into exact paths for only those 18 rows.
   Explicit package/profile absence is retained as inventory evidence, without
   treating missing install stamps as absence of statically shipped work.
3. Exact retained text-member locators from `evidence-index.json`, plus a
   separately bound list of missing selected source/installed/build metadata.
   For source archives, use their immutable custody member/index hashes.
   For current build-selection records, root first names the stopped owner and
   exact package/source/build directories. No broad live cache enumeration.
4. A reviewed output directory that does not exist, admission/reserve and
   bounded owner command. No directory deletion or cleanup exception is part
   of this change.

## Small code delta

- Replace hardcoded checkout/build roots and the hand-maintained `labels`
  dictionary with required `--basis`, `--selection`, `--final-inventory` and
  `--output` arguments. Load the exact corrected basis hash 5830ce00….
  Reuse its scope statements as evidence, without classifying licences from
  keywords. Reject null final bindings, duplicate component/profile identities,
  unlisted components, changed source/member hashes and an existing output.
- Keep the existing notice hash/copy loop. Take its input from explicit
  manifest entries, never `next(B.glob(name+'-*'))`. Preserve full logical
  source-member paths even when identical bytes share one content hash.
  Empty AUTHORS files can be retained as originals but are not notice coverage.
  Read only regular files under bound roots; reject path escape, unresolved
  links and unexpected special files. Preserve raw symlink identity where it
  is part of an installed attribution map, without following outside the root.
- Add one `selected_files` relation per component/profile: final artifact
  path/hash/mode/link chain → package staged path/hash → exact source member
  or generated-input map → applicable scoped notice member hashes. Only the
  declared shader/database prefixes may be enumerated. Do not parse only the
  first few lines and call the file cleared: retain exact applicable comment
  blocks/notice files with source hashes, and leave all unmatched paths explicit.
  If two shader packages match the same final bytes, preserve both candidates;
  if neither matches, mark the attribution unresolved. Runtime-selected shader
  presets do not reduce the set of files actually shipped.
- Add a `build_selection` relation from the explicit small records in the
  selection plan. Copy original compile/link lines or generated target/dependency
  metadata and their hashes. Do not run `make -n`, include an upstream Makefile,
  invoke Ant/CMake or execute a target binary. These operations can evaluate
  commands and cannot reconstruct an original build environment. Missing
  original selection evidence remains unknown; missing stripped symbols and
  absent object files alone do not prove exclusion. If already-retained
  historical selection evidence is reused, require exact current binary/source
  identity and an explained equivalence, not the same version string.
- Add a `dependency_notices` relation for only selected FreeJ2ME and Go-module
  dependencies. Preserve module replacements, source commits/archive members,
  notices and generated output associations. Existing nonexecuting JAR or Go
  build-metadata readers may supply bounded data records in a separately
  allocated step; this notice collector itself consumes those records and
  does not execute the JAR or binary. Do not use go.mod alone as a list of code
  proven shipped, or a README's compatibility claim as the full vendor notice.
- Emit exact coverage totals, unmatched selected paths, unavailable notice or
  build-selection inputs, historical evidence references and per-row technical
  disposition. Keep `publication_clearance=false` for every row and
  `publication_bundle_complete=false`. A successful bounded collection can be
  `COLLECTED_WITH_OPEN_DISPOSITIONS`; it must not claim publication readiness.
  Transport/hash/limit/parse errors remain original failures with partial
  evidence held. Do not substitute empty lists or a successful status for an
  unavailable input.

## Bounded allocation proposal, not runtime measurements

Use one later serialized host metadata stage with a 600-second work ceiling
and 30-second owned cleanup allowance. Proposed data limits are 65,536 selected
path rows, 2 MiB per text member, 128 MiB retained text total and 65,536 archive
index entries. These are ceilings, not predictions. A limit hit retains the
failure and exact originals; it does not silently truncate. No network,
archive download, firmware copy, binary execution, cache-wide traversal,
cleanup deletion or privileged whole-host visibility is introduced.

The existing source inventory is not rerun. Final bundle/member indices supply
identity and membership; the supplement reads only listed missing text,
selected shader/database paths and relevant generated build metadata. The
53 already retained text members are reused by content identity; no new copy
of source archives or full notice bundle is required for the plan.

Before any future collector allocation, root can allocate small isolated
fixtures for the changed path/coverage logic: corrected nested GLSL scope,
same-prefix shader collisions, an empty notice, duplicate conflicting mappings,
path escape/link escape, missing original build flags, changed source hash and
a data-limit hit. They verify collection semantics only; none ran here and
they do not settle legal interpretation.

## Stop conditions

This packet intentionally has no runnable launch command: final inventory and
selected-input bindings do not yet exist. Once those are available, bind the
derivative and use the existing watched/ordinary admission path. If a required
original build-selection record is unavailable, report that exact gap before
considering any further action; do not launch a broad rebuild. ABL source
access, Doom data terms, independent retrieval and off-host custody retain
their existing separate dispositions. No new release gate is proposed.

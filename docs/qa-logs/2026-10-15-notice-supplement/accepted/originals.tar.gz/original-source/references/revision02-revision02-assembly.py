"""Source assembly only; never imports or runs candidate collector/preparer."""
from pathlib import Path
P=Path(__file__).resolve().parent
p=P/'templates/collect.py';s=p.read_text()
s=s.replace('SEEN = set()', '''SEEN = set()  # Selected logical rows in the current component/profile batch.
BATCHES = []
TRAVERSALS = []
NOTICE_RECORDS = {}
REUSED = []''')
a=s.index('def tick(path):');b=s.index('\ndef write(',a)
s=s[:a]+'''def tick(path=None):
    assert time.monotonic()-START < L['soft_seconds'], 'soft collection deadline exceeded'

def selected_row(key):
    tick()
    SEEN.add(key)
    assert len(SEEN) <= L['path_rows'], '65,536 selected rows in one declared component/profile batch exceeded'

def traversal(directory, scope):
    # Numeric cap is unchanged; traversal is distinct from selected evidence rows.
    row=dict(root=str(directory),scope=scope,entries=0,complete=False)
    TRAVERSALS.append(row)
    assert len(TRAVERSALS)<=L['path_rows'], 'traversal receipt count exceeded'
    return row

''' +s[b:]
s=s.replace('json.dump(value, f, indent=2, sort_keys=True)', "json.dump(value, f, sort_keys=True, separators=(',',':'))")
a=s.index('def entries(directory):');b=s.index('\ndef retain(',a)
s=s[:a]+'''def entries(directory, census):
    if not directory.exists():
        return []
    assert directory.is_dir() and not directory.is_symlink(), directory
    items = []
    with os.scandir(directory) as scan:
        for item in scan:
            tick(item.path)
            census['entries']+=1
            assert census['entries']<=L['path_rows'], '65,536 entries in one declared prefix/pattern traversal exceeded'
            assert len(items)<L['path_rows'], '65,536 entries in one directory exceeded'
            items.append(item.name)
    return [directory/n for n in sorted(items)]

''' +s[b:]
s=s.replace("    current=[Path(root)]\n", "    census=traversal(root,'finite-pattern:'+pattern)\n    current=[Path(root)]\n")
s=s.replace("candidates=entries(parent) if", "candidates=entries(parent,census) if")
s=s.replace("    return sorted({str(p.relative_to(root)) for p in current})", "    census['complete']=True\n    return sorted({str(p.relative_to(root)) for p in current})")
s=s.replace("    matches=[p for p in entries(Path(root)) if", "    census=traversal(root,'generated-target-root-candidates')\n    matches=[p for p in entries(Path(root),census) if")
s=s.replace("    return matches\n", "    census['complete']=True\n    return matches\n")
s=s.replace("        if not matches:\n            result.append", "        if not matches:\n            selected_row(('metadata-missing',role,str(root),pattern))\n            result.append")
s=s.replace("        for rel in matches:\n            result.append", "        for rel in matches:\n            selected_row(('metadata',role,str(root),rel))\n            result.append")
s=s.replace("    pending=[base];found=set()", "    census=traversal(base,'declared-installed-prefix')\n    pending=[base];found=set()")
s=s.replace("for p in entries(current):", "for p in entries(current,census):")
s=s.replace("    return found\n\ndef source_notices", "    census['complete']=True\n    return found\n\ndef source_notices")
a=s.index('def source_notices(');b=s.index('\ndef same_identity(',a)
s=s[:a]+'''def source_notices(root, relative, source):
    rel=PurePosixPath(relative);found=[]
    for parent in [rel.parent,*rel.parent.parents]:
        for name in NOTICE_NAMES:
            member=str(parent/name)
            p=path_in(root,member)
            if p.is_file() and not p.is_symlink():
                record=inspect(root,member,text=True)
                raw=json.dumps(record,sort_keys=True,separators=(',',':')).encode()
                key=hashlib.sha256(raw).hexdigest()
                NOTICE_RECORDS[key]=record
                found.append(key)
    # Keep the selected source text directly on its source record, once.
    p=path_in(root,relative)
    if p.is_file() and not p.is_symlink():
        with p.open('rb') as f:sample=f.read(4096)
        if b'\\0' not in sample:
            observed=inspect(root,relative,text=True)
            assert observed['sha256']==source['sha256']
            source['retained_text']=observed['retained_text']
    return sorted(set(found))

''' +s[b:]
s=s.replace("    for rel in sorted(paths):\n        final=", "    for rel in sorted(paths):\n        selected_row(('output',rel))\n        final=")
s=s.replace("notice_members=source_notices(c['unpacked_root'],source_rel) if source['kind']=='file' else []", "notice_member_refs=source_notices(c['unpacked_root'],source_rel,source) if source['kind']=='file' else []")
s=s.replace("    for rel in sorted(paths):\n        package=", "    for rel in sorted(paths):\n        selected_row(('output',rel))\n        package=")
a=s.index('def main():')
s=s[:a]+'''def restore_completed():
    """Copy exact retained evidence only; never reread its package/source inputs."""
    global INPUT_BYTES
    cfg=json.loads((O/'resume.json').read_text());old=Path(cfg['original_owner'])
    assert cfg['original_collector_exit']==1 and cfg['original_channels']==[1,0,1]
    consumed=Path(cfg['consumed_path']);raw=consumed.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==cfg['consumed_sha256']
    c=json.loads(raw);assert c['state']=='consumed' and c['id']==cfg['consumed_id']
    assert [c['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[1,0,1]
    assert hashlib.sha256((old/'supplement-plan.json').read_bytes()).hexdigest()==cfg['original_plan_sha256']
    raw=(old/'partial-members.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==cfg['partial_manifest_sha256']
    members=json.loads(raw);completed={x['path']:x for x in cfg['completed']}
    assert len(completed)==11 and len(members)==2813
    result={};seen=set()
    for m in members:
        tick();p=Path(m['path']);rel=p.relative_to(old/'collection')
        assert '..' not in rel.parts and p.resolve(strict=True)==p and not p.is_symlink() and p.is_file()
        assert str(p) not in seen;seen.add(str(p))
        is_text=len(rel.parts)==2 and rel.parts[0]=='notices'
        assert is_text or str(p) in completed, 'unexpected partial member'
        assert m['bytes'] <= (L['text_member_bytes'] if is_text else 16*1024**2)
        assert INPUT_BYTES+m['bytes']<=L['input_hash_bytes']
        raw=p.read_bytes();assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
        INPUT_BYTES+=len(raw)
        if is_text:
            assert rel.name==m['sha256'];retain(raw)
        else:
            expected=completed[str(p)];assert m['sha256']==expected['sha256'] and m['bytes']==expected['bytes']
            row=json.loads(raw);key=(row['component'],row['profile'])
            assert key==(expected['component'],expected['profile']) and key not in result
            assert row['status']=='COLLECTED_SELECTION_EVIDENCE_WITH_OPEN_DISPOSITIONS' and row['publication_clearance'] is False
            with (OUT/rel).open('xb') as f:f.write(raw)
            result[key]=row;REUSED.append(dict(expected,original_collector_exit=1,observation='HISTORICAL_COMPLETED_OCCURRENCE_FROM_FAILED_RUN'))
    assert len(result)==11 and set(completed)<=seen
    write(O/'resume-receipt.json',dict(binding=cfg,reused=REUSED,new_cache_observation=False,original_failure_preserved=True))
    return result

''' +s[a:]
s=s.replace("    assert len(PLAN['component_specs'])==16 and len(PLAN['occurrences'])==43\n", "    assert len(PLAN['component_specs'])==16 and len(PLAN['occurrences'])==43\n    restored=restore_completed()\n")
s=s.replace("    for r in PLAN['occurrences']:\n        spec=", "    for r in PLAN['occurrences']:\n        SEEN.clear();CACHE.clear();NOTICE_RECORDS.clear()\n        key=(r['component'],r['profile'])\n        if key in restored:\n            row=restored[key];assert row['accepted_input']==r\n            ROWS.append(row)\n            BATCHES.append(dict(component=key[0],profile=key[1],scope='historical completed output; original global counter unavailable per occurrence',selected_outputs=len(row['selected_files']),selected_rows=None))\n            continue\n        batch=dict(component=key[0],profile=key[1],scope='new disjoint occurrence',selected_rows=0)\n        BATCHES.append(batch)\n        spec=")
s=s.replace("        row['selected_identity']=exact_identity(r)", "        selected_row(('identity',r['component'],r['profile']))\n        row['selected_identity']=exact_identity(r)")
s=s.replace("        if 'prefix' not in spec:row['unresolved']", "        row['notice_member_index']=dict(NOTICE_RECORDS)\n        batch['selected_rows']=len(SEEN);batch['selected_outputs']=len(row['selected_files'])\n        if 'prefix' not in spec:row['unresolved']")
s=s.replace("    extra=json.loads((O/'extra-records.json').read_text());extra_rows=[]", "    SEEN.clear()\n    extra=json.loads((O/'extra-records.json').read_text());extra_rows=[]")
s=s.replace("    for x in extra['records']:\n        matches=", "    for x in extra['records']:\n        selected_row(('extra',x['component'],x['profile'],x['root_role'],x['relative_path']))\n        matches=")
s=s.replace("    # Hash inventory is data;", "    write(O/'batch-counters.json',dict(batches=BATCHES,traversals=TRAVERSALS,extra_rows=len(SEEN),reused=REUSED,semantics=PLAN['batch_bound_semantics']))\n    # Hash inventory is data;")
s=s.replace("                path_index_rows=len(SEEN),retained_text_bytes=TEXT_BYTES,named_input_hash_bytes=INPUT_BYTES,", "                maximum_new_batch_selected_rows=max(b['selected_rows'] or 0 for b in BATCHES),reused_occurrences=len(REUSED),new_occurrences=43-len(REUSED),\n                batch_counters='batch-counters.json',original_failed_collector_exit=1,retained_text_bytes=TEXT_BYTES,named_input_hash_bytes=INPUT_BYTES,")
s=s.replace("                  path_index_rows=len(SEEN),retained_text_bytes=TEXT_BYTES,publication_bundle_complete=False))", "                  current_batch_selected_rows=len(SEEN),batches=BATCHES,traversals=TRAVERSALS,reused=REUSED,retained_text_bytes=TEXT_BYTES,publication_bundle_complete=False))")
p.write_text(s)
p=P/'prepare-owner.py';s=p.read_text().replace("'retained-notice-index.json']", "'retained-notice-index.json','resume.json']")
s=s.replace("'prior_inventory_admission'", "'prior_inventory_admission'")
s=s.replace("protected=sorted({r['tree'] for r in plan['occurrences']}|{", "protected=sorted({r['tree'] for r in plan['occurrences']}|{'/workspace/tmp/pix-m7-current-notice-supplement-20261015-01',")
p.write_text(s)
p=P/'commands.sh';s=p.read_text().replace('TASK_PACKET=/tmp/pix-m7-current-notice-supplement-20261015\n','TASK_PACKET=/tmp/pix-m7-current-notice-supplement-20261015-02\n').replace('TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-current-notice-supplement-20261015-01}', 'TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-current-notice-supplement-20261015-02}');p.write_text(s)

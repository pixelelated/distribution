# #528 selected-notice supplement revision 03 — SOURCE ONLY, UNRUN

Revision02 stopped after approximately 8.97 seconds at the original 2 MiB text-member limit while trying to retain `cht/Nintendo - Nintendo 64/Turok - Dinosaur Hunter (USA).cht` in full as notice text. Its actual source packet is `24790e2e`, owner `/workspace/tmp/pix-m7-current-notice-supplement-20261015-02`, run `20261015T110245Z-3a3197d2`, consumed failed admission `ebe34e2c82ee4e0c8f0286e8fa7d46b9`. Collector/command/runner/launcher exits remain 1, monitor 0, without timeout or cleanup signals. The two actual database-prefix traversals completed at 28,374 entries each; failure occurred at selected row 6,446. No complete database output row or selection proof was produced.

This corrects the collection scope: database payload content is not automatically notice text. Every selected libretro-database member still receives full source/package/staged-image SHA-256, size and metadata observations, equality results and exact relative source mapping. No payload is skipped because of its name or size, and the existing binary/input bounds still apply. Root and scoped ancestor notice files remain retained in full under the original text limits. The database payload record explicitly says its complete content is not retained as notice text. Per-content supplied attribution, modification indications and applicability remain unresolved; this does not assert absence of in-file notices or give all contents blanket licence clearance.

The exact retained root LICENSE is `23ee78c8`, headed Attribution-ShareAlike 4.0 International. The accepted current inventory binds source pin `4de37d2c8042d9d0f608c43006c9b35438c536ce`, archive `libretro-database-4de37d2c8042d9d0f608c43006c9b35438c536ce.tar.gz`, SHA-256 `cd8d09c2408e193d2ea4925de60afcf01523fa8cf269c38b5ae5c2580cd56c1f`, 177,256,189 bytes, plus actual unpack/build stamps and recipe identity. Each new database occurrence links its exact accepted inventory input and source-inventory hashes, source-cache root, archive record, recipe and unpack stamp. This is an exact archive-identity and unpacked-source linkage: no archive is opened here, its member-by-member equality is not independently verified, and independent retrieval/public delivery remain false. The tracked recipe's post-unpack change removes `rdb` from the installed copy command; the actual patched Makefile and installed prefix membership remain the source of the selected-content claim. Recipe copyright headers are not implementation/data terms.

Shader source keeps its existing whole-text notice evidence within 2 MiB per member and 128 MiB unique retained text. A source member exceeding either bound receives its full payload hash/size and an explicit `OPEN_SHADER_*` gap, listed in the occurrence's `payload_text_gaps` and unresolved summary. No prefix or partial text is substituted, and no notice-completeness claim is made for that member. NUL-bearing assets retain the existing hash-only disposition explicitly. Named root/ancestor notices and build metadata continue to fail on an exceeded text bound; their retention is not silently waived.

The same 11 complete occurrence JSONs and content-addressed text are copied byte-for-byte from **owner01**, with the exact failed-run provenance and unchanged input assertions from revision02. No source/package re-observation is added for those rows. Owner02's partial cheat text is not imported into the continuation. Only the remaining 32 occurrences, including three unchanged ABL/Doom disclosure-only holds, are processed. All 16 components, 43 occurrence input mappings, prior unresolved selection/consumer holds, disjoint batch/traversal limits and numerical resource limits remain unchanged.

The supervisor, consumer, bindings, preparer and identity helper are byte-identical to revision02. The only executable change is `source_notices`' payload disposition and its caller/occurrence summaries, plus the fresh packet/owner paths in commands.sh. The plan adds the database policy, exact accepted archive-link records, an explicit unresolved disposition and failed02 provenance hashes. No generic framework, archive reader, source evaluator, network operation or target execution is introduced. `changes.diff` is the exact revision02→03 executable/input delta; earlier source/diagnosis/static results are historical under references/.

## Root execution boundaries

Source was parsed and compared without importing or executing a candidate collector/preparer or running tests. Root's finite source review found no further source defect. The only executed helper was separately authorized completed-failure custody. Runtime qualification remains absent until actual originals exist.

```bash
bash /tmp/pix-m7-current-notice-supplement-20261015-03/commands.sh prepare
bash /tmp/pix-m7-current-notice-supplement-20261015-03/commands.sh preflight
bash /tmp/pix-m7-current-notice-supplement-20261015-03/commands.sh report
# Root inspects actual resource/retention output before fresh ordinary admission.
bash /tmp/pix-m7-current-notice-supplement-20261015-03/commands.sh admit
bash /tmp/pix-m7-current-notice-supplement-20261015-03/commands.sh launch
# Supervise original launcher/watch/child channels at <=60-second cadence.
bash /tmp/pix-m7-current-notice-supplement-20261015-03/commands.sh consume
```

Default owner is `/workspace/tmp/pix-m7-current-notice-supplement-20261015-03`. Frozen GENERIC f863 tools, all execution bounds and separate report/admission boundaries remain unchanged. Never run the success consumer after failure. Both failed predecessors, their original exits and partial evidence remain preserved separately; no successful retry, publication clearance, archive-member equality or retrieval is predicted.

# #528 selected notice supplement — SOURCE ONLY, UNRUN

This packet prepares one bounded addition to the existing notice evidence. It covers exactly the 16 non-prebuilt rows and their 43 profile occurrences from `selected-current.json`. Rclone and Tailscale are excluded and remain with the separate prebuilt work. The accepted final inventory and its consumed receipt are required inputs; no full inventory is repeated.

`basis.json` is the exact corrected 5830ce00 basis, not a new licence classification. The original collector 495fb9cb and the prior source/selection plans are retained. Thirty-one applicable historical notice/text records are copied by content hash during the proposed run, with every original logical member path preserved. A historical notice is rebound to a current member only on exact byte equality. Empty AUTHORS is evidence of an empty file, not notice coverage. Changed or missing selected members remain explicit. No recipe header is used as implementation or game-data licensing.

The derivative records:

- All files under the declared shader/database staged prefixes, compared with corresponding package files and exact relative source members. H700 common-shaders is compared with both common and RetroPie origins. Both byte-identical origins are retained; neither matching is an unresolved attribution. Scoped ancestor notice candidates and the full selected text preserve in-file notices and include declarations for review. They do not automatically establish applicability or recursively resolve every include. GLSL's nnedi3 and crt-royale notices stay separate. Database Makefile records retain the deliberate rdb removal.
- Exact named source and generated records for FreeJ2ME Ant/native inputs, WildMIDI CMake, OpenBOR architecture/PREFIX/link inputs, HarfBuzz-ICU Meson and ZeroTier conditional/object/header inputs. Actual CMake cache serializations are reported for WANT_PLAYER/WANT_ALSA/BUILD_SHARED_LIBS; Makefile variables are not presented as effective environment. All matching generated target directories are retained, never an arbitrary first glob result.
- HarfBuzz-ICU metadata from its actual ICU build root, plus separately bound shared harfbuzz-14.3.0 source identity/notices. Font/test terms remain distinct. Static-library rows include named dependency-consumer metadata candidates; these are not proof of actual linkage. Both ARM opusfile occurrences retain the source-recipe-defined ARM-image → lib32 package → AArch64 staged-image relation.
- Optional individually bound original Ant/JAR member-index/link/dependency receipts from `extra-records.json`. No archive or JAR is opened here, and no Makefile, Ant, CMake, Meson, compiler, target binary or network operation is executed. Missing original flags, JAR selection, static-consumer linkage and selected vendor/header maps remain unknown. The default empty extra-record list does not claim those inputs were found.
- The existing ABL implementation/access and Doom WAD terms holds, with original accepted component identities. These three profile occurrences are disclosure-only: no archive or source read is added for them. No LLVM reconstruction or nineteenth notice row is introduced.

`templates/collect.py` reads only explicit roots and bounded patterns. Recursive enumeration is limited to the declared shader/database prefixes. Generated records use at most four explicit path segments; only matching named build records and selected library filenames are read. Source/consumer roots and recipe/unpack/build-stamp hashes come from accepted inventory metadata. Missing install/output roots are recorded without claiming static code was absent. Leaf links retain raw target text without resolving an unbound referent. Parent-link escapes and unexpected special files fail. These are staged-source observations: no new independent SYSTEM extraction is claimed.

The retained text remains content-addressed under `collection/notices/<sha256>`, with full logical source paths in per-occurrence records. `collection-members.json` binds every generated payload. A successful collection is **COLLECTED_WITH_OPEN_DISPOSITIONS**, with `publication_bundle_complete=false` and `publication_clearance=false`. It does not complete source selection, notice interpretation, independent retrieval, off-host custody or publication. Missing input/attribution is visible; parse/hash/type/limit failures preserve original failure and partial evidence instead of becoming an empty successful list.

## Bounds and lifecycle

Ceilings are 65,536 unique path/index rows, 2 MiB per retained text member and 128 MiB total unique retained text. Named binary hashing is at most 256 MiB per file and 10 GiB total. One collector has a 580-second soft deadline, 600-second supervisor wait, inherited 13-second bounded cleanup, and outer 630-second timeout plus 15-second hard-kill allowance. The owner has a 256 MiB output ceiling, two CPUs, 2 GiB address space and 1 GiB retention allowance. These are bounds, not measured totals: an oversized metadata member or row count fails with evidence; no truncation or automatic increase is introduced.

The one-stage supervisor derives from `/tmp/pix-m7-prebuilt-association-20261015`, itself a narrow derivative of the qualified final-inventory supervisor. Its PID/start-identity census, pidfd-only owned-child signals, subreaper, original Popen wait capture and error-aware finalization are unchanged. `process-identity.py` is byte-identical. Only stage names, collector result predicates and output scope change. The prebuilt collection's own outcomes are not inherited. No new generic runner or cleanup framework is added.

The commands keep preparation, preflight, retention report, admission, launch and consumption separate for coordinator review. They use the frozen GENERIC f863 ordinary admission/watch tools with five explicit profile tuples, not the #597 recovery route. Root remains sole allocator and supervisor. Never pre-create a launcher-owned receipt or run the success-only consumer after a failed/interrupted stage.

```bash
bash /tmp/pix-m7-current-notice-supplement-20261015/commands.sh prepare
bash /tmp/pix-m7-current-notice-supplement-20261015/commands.sh preflight
bash /tmp/pix-m7-current-notice-supplement-20261015/commands.sh report
# Root inspects the actual resource/retention report before admission.
bash /tmp/pix-m7-current-notice-supplement-20261015/commands.sh admit
bash /tmp/pix-m7-current-notice-supplement-20261015/commands.sh launch
# Supervise original launcher/watch/child/cleanup channels at <=60-second cadence.
bash /tmp/pix-m7-current-notice-supplement-20261015/commands.sh consume
```

Default fresh owner is `/workspace/tmp/pix-m7-current-notice-supplement-20261015-01`. Optional `TASK_EXTRA_RECORDS` and `TASK_EXTRA_RECORDS_SHA256` bind existing individual original metadata/reader receipts; each record names its exact source/consumer or retained-receipt root and hash. The absence of those records remains a stated gap, not an invitation to scan logs, rebuild or fetch. Root reviews and allocates before any command above. Any isolated fixture controls remain separately unallocated; none ran here.

Preparation read only the existing plans, completed inventory JSON and exact tracked recipe/build-script blobs. It did not inspect current package directories, archives, binaries, generated metadata or changing caches. Source was parsed/read without importing or executing candidate tools. The source-only data-assembly script records initial joins; the final sealed plan additionally retains the explicit lib32 handoff binding. No collector, preparer, tests, VM, service, admission, shared-record edit or product change occurred.

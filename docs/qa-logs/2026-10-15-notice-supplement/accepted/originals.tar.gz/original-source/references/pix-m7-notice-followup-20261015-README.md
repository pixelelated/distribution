# #528 notice follow-up — source-only bounded plan

The next useful action is a selected-file and build-selection supplement to
the existing notice collector, after final five-profile inventory is accepted.
Do not repeat the full source inventory. `selection-plan.json` fixes the scope
at the existing 17 notice rows plus Doom and names each row's exact missing
inputs. Its current profile bindings are deliberately null; this is not a
launch-ready collector or a publication disposition.

The current fork issue body and three comments were read successfully
(issue updated 2026-10-15 06:44:53 UTC; tool observation `8fb663`, exit 0).
The attempted second read for a standalone original failed to reach the API
(exit 1); its empty stdout and the observation remain in this packet. No
successful raw GitHub response file is invented. The issue's later comments
preserve the architecture-specific Tailscale association correction and the
already accepted declaration/Doom-input work.

Existing evidence was reused, not regenerated: the corrected notice basis
5830ce00…, the final-inventory proposal's publication-holds f7ecd58f…,
18 exact recipe Git objects, 53 retained notice/text members (633,946 bytes),
the source-backed October11 dispositions, and the Tailscale/rclone provenance
receipts. All 53 exact small text members were rehashed against their retained
identities; their paths and source scopes are in `evidence-index.json`. They
are referenced rather than copied again. No live build/cache roots, source
archives or target binaries were read. Only the three small ZeroTier selection
makefiles are additionally copied for an implementer.

Concrete findings that shape the bounded supplement:

- Common-shaders and RetroPie shaders both install to
  `/usr/share/common-shaders`. Compare final packaged bytes against both
  package/source maps. Directory presence or an install stamp cannot identify
  the final source of a colliding file. Preserve multiple matching origins or
  an unresolved mismatch instead of inventing a winner.
- GLSL's retained LGPL text is only `nnedi3/LICENSE`; crt-royale's separate
  `LICENSE.TXT` is also retained. The old collector hardcodes the superseded
  root-licence description. Its small derivative must load the corrected basis
  as data and retain per-file/subdirectory scopes.
- ZeroTier's actual selected compile/link inputs are needed. The retained
  `make-linux.mk:20–27` selects controller objects only for `ZT_NONFREE=1`
  (also set by `ZT_CONTROLLER=1`). Lines 40–62 select bundled/system
  miniupnpc and natpmp using header detection, while bundled http-parser is
  unconditional. Header-only ext dependencies also need their selected source
  scope. The recipe explicitly supplies `ZT_SSO_SUPPORTED=0`; absence of other
  flags from that recipe is not proof of the effective old build environment.
- FreeJ2ME requires the actual installed JAR member/build selection and native
  core inputs for JLayer, libsdl4j, ASM and libretro attribution. WildMIDI needs
  actual per-profile CMake selection, not the recipe's apparent `WANT_PLAYER`
  value; an earlier retained cache had the player enabled. OpenBOR's root,
  engine and tools notices remain distinct. Missing install stamps do not
  eliminate static library or vendored work.
- rclone's historical 1.75.1 source/module basis cannot qualify 1.75.2.
  Tailscale's archive name cannot choose amd64 versus arm64. Exact current
  binary hashes and nonexecuting build-metadata readback bind the selected
  dependency notice lists; old module counts are not current totals.

Final inventory is necessary but not the only remaining dependency. It will
bind actual profile/source membership and immutable artifacts, but does not
itself supply every shader header, selected vendor notice or conditional build
input. ABL v1.2 implementation-source/access and Doom game-data notice/terms
remain the existing unresolved dispositions; no new lookup, upstream contact
or legal conclusion was attempted. The #600 checksum repair and five-file ABL
proof do not settle those source/notice questions. Independent retrieval and
off-host custody remain later existing #528 work.

See `collector-change-plan.md` for the minimal additive implementation and
proposed limits. Root owns final bindings, any implementation allocation and
all execution. No collector or preparer was imported/run, no tests ran, and no
product, issue, shared documentation or original evidence was changed.

# #528 selected-notice supplement revision 02 — SOURCE ONLY, UNRUN

This is an additive continuation of the consumed failed collection at `/workspace/tmp/pix-m7-current-notice-supplement-20261015-01`, run `20261015T104827Z-81133446`, admission `3f886f1bc9dc47acb891bb587449df77`. Original collector/command/runner/launcher exits remain 1; monitor exit is 0. It stopped after about 4.96 seconds with no timeout or cleanup signals. Neither that producer nor its incomplete database occurrence is relabelled successful.

The original `tick()` counted every encountered absolute path globally: directory entries before pattern filtering, directories themselves, and separate image/package/source paths. The traceback proves the final entry was encountered while traversing GENERIC libretro-database's package prefix. This is actual selected-prefix enumeration, not proof that irrelevant names alone caused the failure. The old in-memory set was not retained, so its exact 65,537-entry breakdown and database cardinality remain unknown. Eleven completed occurrence JSONs retain 3,011 selected output rows and 12,185 distinct absolute path records. `diagnosis.json` records the data-only calculation and its limits.

## Exact continuation

`resume.json` binds the original partial manifest, failed consumed receipt, original plan and exactly 11 completed occurrence files. The new collector verifies all 2,813 retained partial members (34,621,035 bytes), copies the 11 occurrence files byte-for-byte and restores the existing content-addressed text. Those are explicitly historical completed observations from a failed run, not new cache observations or a previously successful collector. Each carried row's accepted input must equal the unchanged current occurrence binding. Their old schema remains intact. Only the remaining 32 occurrences are processed; three of these are the unchanged disclosure-only ABL/Doom holds. The prior 16-component / 43-occurrence scope and all selection, provenance and publication limitations remain unchanged.

The integer cap stays 65,536, with an explicitly changed scope: one disjoint component/profile batch of selected output/metadata/ancestor-notice rows. A final/package/source relation occupies one selected output row with all origins retained. Every declared installed-prefix traversal independently permits at most 65,536 entries including directories; every finite pattern traversal and directory enumeration retains that same cap, including nonmatching names. There are at most 65,536 traversal receipts. These are disclosed per-scope bounds, not the former global cap with a new label. Actual per-batch and traversal counts are retained on success and failure. No new cap is chosen from guessed source cardinalities.

New prefix rows store ancestor notice metadata once in `notice_member_index`, keyed by SHA-256 of its compact canonical JSON. Each origin has `notice_member_refs`; its selected source full text is linked directly from `source.retained_text`. All exact source paths, metadata, collision origins, content hashes and in-file text remain represented. New JSON uses compact serialization. This prevents repeating the same ancestor dictionaries thousands of times. Carried originals are never reformatted. The original format/selected-source scope is documented in `references/revision01-README.md`.

Family limits are unchanged: 2 MiB per retained text member, 128 MiB unique text total including reused text, 256 MiB per named binary, 10 GiB named reads including carried payload reads, 580-second collector deadline, 600-second supervisor wait, 13-second cleanup allowance, outer 630 seconds plus 15-second hard-kill allowance, two CPUs, 2 GiB address space, 128 MiB maximum output file, 256 MiB total owner output, and 1 GiB retention reservation. An output/bound failure remains a failure. The new size and duration are unknown until a separately allocated run; no cap was raised to make it pass.

The PID/start-identity, pidfd, subreaper, signal and original-wait supervisor functions and `process-identity.py` are unchanged. Only additional resume-result predicates are added to the supervisor. The consumer verifies new batch/traversal counts, exact 11/32 provenance, all original successful retry channels and complete collection member hashes. The old failed admission remains distinct. No new generic lifecycle, independent SYSTEM reader, build evaluation, compiler, target execution, archive reader or network path is introduced. ABL implementation/access and Doom WAD terms, static consumer/vendor selection, and publication/custody gaps remain unresolved.

## Root execution boundaries

No command below ran during this preparation. Root reviews the source and actual resource report before ordinary fresh admission. The frozen GENERIC f863 admission/watch tools remain authoritative. The default fresh owner is `/workspace/tmp/pix-m7-current-notice-supplement-20261015-02`; owner01 and its outputs are protected for the resumed evidence reads.

```bash
bash /tmp/pix-m7-current-notice-supplement-20261015-02/commands.sh prepare
bash /tmp/pix-m7-current-notice-supplement-20261015-02/commands.sh preflight
bash /tmp/pix-m7-current-notice-supplement-20261015-02/commands.sh report
# Root reviews actual preflight and retention output before allocating.
bash /tmp/pix-m7-current-notice-supplement-20261015-02/commands.sh admit
bash /tmp/pix-m7-current-notice-supplement-20261015-02/commands.sh launch
# Root supervises original launcher/watch/child channels at <=60-second cadence.
bash /tmp/pix-m7-current-notice-supplement-20261015-02/commands.sh consume
```

Optional exact extra-record bindings remain available as documented in the historical README; default empty selection stays an explicit gap. Do not run the success-only consumer on a failed retry. `changes.diff` is the full executable/input delta from immutable revision01; the old delta and old static results are retained under `references/revision01-*` as historical evidence only. `revision02-assembly.py` is the source-edit transcript; the sealed files/diff, including subsequent final source adjustments, are authoritative.

Preparation only parsed source and read completed failure records/partial outputs. It did not enumerate source/build caches, execute a collector or preparer, import candidate tools, run controls, allocate runtime, mutate products or shared records, or change any old packet/owner.

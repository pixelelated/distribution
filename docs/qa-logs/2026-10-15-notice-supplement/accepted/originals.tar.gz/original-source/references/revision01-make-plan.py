from pathlib import Path
import json,hashlib,shutil,subprocess
D=Path('/tmp/pix-m7-current-notice-supplement-20261015');F=Path('/tmp/pix-m7-notice-followup-20261015');C=Path('/tmp/pix-m7-current-notice-gaps-20261015');Q=Path('/tmp/pix-m7-prebuilt-association-20261015');R=Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
selected=load(C/'selected-current.json');basis=load(F/'references/licence-basis-corrected.json');evidence=load(F/'evidence-index.json')
assert sha(F/'references/licence-basis-corrected.json')=='5830ce00d272e8e2b77bf0800e8337674a6d996c6012163a61e2c5c213c96011'
refs={str(C/'selected-current.json'):sha(C/'selected-current.json'),str(C/'SHA256SUMS'):sha(C/'SHA256SUMS'),str(F/'SHA256SUMS'):sha(F/'SHA256SUMS')}
for name,p in [('selected-current.json',C/'selected-current.json'),('basis.json',F/'references/licence-basis-corrected.json'),('retained-notice-index.json',F/'evidence-index.json')]:shutil.copy2(p,D/name)
for n in ['collect-licence-basis.py']:
 p=F/'references/original-collect-licence-basis.py';shutil.copy2(p,D/'originals'/n)
for n in ['run.py','run.sh','bindings.py','consume.py','process-identity.py']:
 p=Q/'templates'/n;shutil.copy2(p,D/'originals'/n)
for n in ['prepare-owner.py','commands.sh','resources.json','frozen-tools.json']:
 shutil.copy2(Q/n,D/'originals'/n)
shutil.copy2(Q/'frozen-tools.json',D/'frozen-tools.json')
shutil.copy2(Q/'templates/process-identity.py',D/'templates/process-identity.py')
for p in [F/'collector-change-plan.md',C/'next-selection.md',F/'README.md']:
 shutil.copy2(p,D/'references'/(p.parent.name+'-'+p.name));refs[str(p)]=sha(p)
# Only metadata JSON and tracked Git blobs are read during preparation.
consumers={'enet':['moonlight'],'libspeexdsp':['easyrpg-lr'],'libxmp-lite':['easyrpg-lr'],'opusfile':['SDL2_mixer'],'harfbuzz-icu':['webkitgtk'],'wildmidi':['easyrpg-lr']}
profiles={}
for name in ['generic-x64-x86_64','h700-arm','h700-aarch64','sm8550-arm','sm8550-aarch64']:
 p=Path(selected['inventory']['owner'])/'profiles'/name/'components.json';assert sha(p)==selected['source_references'][str(p)];v=load(p);profiles[name]=v.get('components',v) if isinstance(v,dict) else v
specs={
'common-shaders':{'prefix':'usr/share/common-shaders','source_files':['Makefile','configure']},
'retropie-shaders':{'prefix':'usr/share/common-shaders','source_files':['Makefile','configure']},
'glsl-shaders':{'prefix':'usr/share/glsl-shaders','source_files':['Makefile','nnedi3/LICENSE','crt/shaders/crt-royale/LICENSE.TXT']},
'slang-shaders':{'prefix':'usr/share/slang-shaders','source_files':['Makefile']},
'libretro-database':{'prefix':'usr/share/libretro-database','source_files':['Makefile','LICENSE']},
'freej2me-lr':{'outputs':['usr/lib/libretro/freej2me_libretro.so','usr/config/game/freej2me/freej2me-lr.jar','usr/bin/freej2me.sh'],'source_files':['build.xml','src/libretro/Makefile','LICENSE','README.md'],'metadata':['build.xml','nbproject/build-impl.xml','nbproject/project.properties','manifest.mf','src/libretro/*.d','src/libretro/*.rsp','src/libretro/compile_commands.json'],'unresolved':['Original Ant target/classpath/import/include selection is required; source XML is not execution evidence.','Installed JAR member/class/resource index and individual JLayer/libsdl4j/ASM/libretro association remain unknown without an explicitly bound existing reader record. No JAR is opened by this collector.']},
'wildmidi':{'library_patterns':['libWildMidi*'],'source_files':['CMakeLists.txt','COPYING','src/wildmidi_lib.c','docs/license/GPLv3.txt','docs/license/LGPLv3.txt'],'outputs':['usr/bin/wildmidi'],'effective_variables':['WANT_PLAYER','WANT_ALSA','BUILD_SHARED_LIBS'],'unresolved':['Library/player selection must be read from actual generated records; source recipe WANT_PLAYER text is not effective configuration.']},
'openbor':{'outputs':['usr/bin/OpenBOR','usr/bin/start_OpenBOR.sh'],'source_files':['LICENSE','engine/LICENSE','tools/LICENSE','engine/Makefile'],'metadata':['engine/*.d','engine/*.rsp','engine/compile_commands.json','engine/.depend','engine/.deps/*.d'],'effective_variables':['BUILD_LINUX_x86_64','BUILD_LINUX_aarch64','SDKPATH','PREFIX'],'unresolved':['Original expanded BUILD_LINUX architecture, SDKPATH/PREFIX and actual final link inputs remain unknown without original commands; Makefile assignments alone are not effective values.','No tools/LICENSE coverage is inferred for the engine; exact tools output selection must be shown.','OpenBOR config members require explicit selected-file binding; this run does not broaden directory traversal beyond shader/database prefixes.']},
'harfbuzz-icu':{'library_patterns':['libharfbuzz-icu*'],'source_files':['COPYING','AUTHORS','src/COPYING','test/COPYING','meson.build','src/meson.build'],'unresolved':['The ICU generated build root and shared harfbuzz source package are distinct and both retained. Test-font terms do not apply to the library by default.']},
'zerotier-one':{'outputs':['usr/sbin/zerotier-one','usr/sbin/zerotier-cli','usr/sbin/zerotier-idtool'],'source_files':['LICENSE.txt','make-linux.mk','objects.mk','objects-nonfree.mk','ext/http-parser/LICENSE-MIT','ext/miniupnpc/LICENSE','ext/libnatpmp/LICENSE'],'metadata':['.depend','*.d','*.rsp','compile_commands.json','node/*.d','osdep/*.d','service/*.d','nonfree/controller/*.d','ext/*/*.d','ext/libnatpmp/Makefile'],'effective_variables':['ZT_NONFREE','ZT_CONTROLLER','ZT_SSO_SUPPORTED','ZT_OTEL','ZT_OFFICIAL','ZT_EXTOSDEP','CPPFLAGS','DEFS','LDLIBS','CORE_OBJS','ONE_OBJS','CONTROLLER_OBJS'],'unresolved':['Original effective conditional flags and CORE/ONE/CONTROLLER link lists are required. Source makefiles and missing stripped symbols never establish exclusion.','http-parser is unconditional in retained source; miniupnpc/natpmp depend on actual header-detection branches. Header-only ext/prometheus/OpenTelemetry selection needs actual dependency/header records.','Full selected ext/nonfree notice/member map is unresolved until the actual object/header inputs are bound.']},
'enet':{'library_patterns':['libenet*'],'source_files':['LICENSE','AUTHORS','docs/license.dox']},
'libspeexdsp':{'library_patterns':['libspeexdsp*'],'source_files':['COPYING','AUTHORS']},
'libxmp-lite':{'library_patterns':['libxmp-lite*'],'source_files':['README']},
'opusfile':{'library_patterns':['libopusfile*','libopusurl*'],'source_files':['COPYING','AUTHORS']},
'rocknix-abl':{'hold_only':True,'unresolved':['Existing five-file #600/#602 artifact mapping remains valid. LinuxLoader e9d37131 implementation access and applicable source/notices remain unresolved under #601. No archive download/read or inference from the packaging GPL header.']},
'idtech-lr/doom.wad':{'hold_only':True,'unresolved':['Pinned Doom archive ff35cde0 and staged equality are existing evidence; WAD game-data redistribution/notice terms remain unresolved. No archive read/refetch or inference from engine/recipe licensing.']}}
generated=['CMakeCache.txt','install_manifest.txt','build.ninja','compile_commands.json','CMakeFiles/TargetDirectories.txt','CMakeFiles/rules.ninja','CMakeFiles/*.dir/link.txt','CMakeFiles/*.dir/flags.make','CMakeFiles/*.dir/DependInfo.cmake','CMakeFiles/*.dir/build.make','meson-info/intro-targets.json','meson-info/intro-installed.json','meson-info/intro-buildoptions.json','meson-info/intro-dependencies.json','meson-info/intro-buildsystem_files.json','meson-logs/install-log.txt','meson-logs/meson-log.txt','config.log','config.status','Makefile','*.la','*.pc']
rows=[];consumer_meta={};recipe_refs={}
for c in selected['components']:
 if c['component'] in ['rclone','tailscale']:continue
 name=c['component'];spec=specs[name];spec['component']=name;spec['basis']=next((x for x in basis['components'] if x['component']==name),None)
 spec['required_exact_inputs']=c['required_exact_inputs'];spec['flags_and_scope_controls']=c['flags_and_scope_controls'];spec['generated_patterns']=generated
 for inp in c['selected_inputs']:
  r=dict(inp);r['component']=name;r['source_parents']=[]
  for parent,unpacked in inp['component_row']['unpacked_source'].get('source_packages',{}).items():r['source_parents'].append({'package':parent,'root':str(Path(inp['build_root'])/'build'/unpacked)})
  rows.append(r)
  key=inp['profile']+':'+name;cs=[]
  for consumer in consumers.get(name,[]):
   matches=[x for x in profiles[inp['profile']] if x['component']==consumer]
   assert len(matches)<=1
   if not matches:cs.append({'component':consumer,'status':'ABSENT_COMPONENT_ROW_NOT_EXCLUSION'});continue
   cr=matches[0];un=cr.get('unpacked_source',{}).get('unpacked')
   cs.append({'component':consumer,'status':'DECLARED_DEPENDENCY_CANDIDATE_NOT_PROVEN_LINKED','component_row':cr,'source_root':str(Path(inp['build_root'])/'build'/un) if un else None,'install_pkg_root':str(Path(inp['build_root'])/'install_pkg'/un) if un else None})
  consumer_meta[key]=cs
  for rec in inp['component_row']['recipe_inheritance']:
   loc=str(Path(inp['tree'])/rec['path']);recipe_refs[loc]=rec['sha256']
# Parent harfbuzz source is bound by its actual component row, not guessed from a matching version.
for r in rows:
 if r['component']=='harfbuzz-icu':
  for parent in r['source_parents']:
   cr=[x for x in profiles[r['profile']] if x['component']==parent['package']];assert len(cr)==1;parent['component_row']=cr[0]
assert len(specs)==16 and len(rows)==43
notices=[]
for x in evidence['retained_notice_members_rehashed']:
 if x['component'] not in specs or specs[x['component']].get('hold_only'):continue
 source=x['source_scope'];part=source.split('/build/',1)
 rel=part[1].split('/',1)[1] if len(part)==2 and '/' in part[1] else None
 notices.append(dict(x,current_relative_member=rel,association='Historical original; current source-member byte equality required before reuse.'))
plan={'schema':1,'scope':'Existing 16 non-prebuilt notice rows only; rclone/Tailscale owned separately.','selection_sha256':sha(D/'selected-current.json'),'basis_sha256':sha(D/'basis.json'),'notice_index_sha256':sha(D/'retained-notice-index.json'),'inventory':selected['inventory'],'binding_refs':dict(selected['source_references'],**refs),'component_specs':specs,'occurrences':rows,'consumer_candidates':consumer_meta,'historical_notices':notices,'recipe_refs':recipe_refs,'limits':{'path_rows':65536,'text_member_bytes':2*1024**2,'retained_text_bytes':128*1024**2,'binary_member_bytes':256*1024**2,'input_hash_bytes':10*1024**3,'soft_seconds':580,'max_pattern_depth':4},'external_record_policy':'Only an explicitly prepared, hash-bound extra-records.json may add exact original Ant/JAR/link/dependency records under already selected source/consumer roots. Empty records remain explicit unresolved selection; no discovery outside bound roots.','publication_bundle_complete':False}
dump(D/'supplement-plan.json',plan)
dump(D/'extra-records.template.json',{'schema':1,'records':[],'scope':'Optional exact original metadata/data-reader receipts; absence stays explicit. Every record requires component, profile, role, root_role (source or consumer:<name>), relative_path, sha256 and interpretation. No source-selection claims may be inferred by this collector.'})
dump(D/'resources.json',{'address_space_bytes':2147483648,'cleanup_seconds':15,'collector_seconds':600,'cpu_affinity':[0,1],'outer_seconds':630,'owner_output_ceiling_bytes':256*1024**2,'per_file_bytes':128*1024**2,'retention_budget_bytes':1024**3,'scope':'One bounded selected-file/text metadata collector, no archive open, target, network, cache-wide scan or deletion. Text cap 128MiB plus manifests/operating margin.'})
for path in ['scripts/build','config/path','packages/graphics/harfbuzz/package.mk','packages/addons/addon-depends/chrome-depends/harfbuzz-icu/package.mk']:
 b=subprocess.check_output(['git','-C',str(R),'show','9aa7affee9d4ad5e69725cab20b6d7ad84d93dea:'+path]);p=D/'references'/path.replace('/','__');p.write_bytes(b);recipe_refs['git:9aa7affee9d4ad5e69725cab20b6d7ad84d93dea:'+path]=hashlib.sha256(b).hexdigest()
dump(D/'source-reference-identities.json',{'original_supervisor_packet':str(Q),'original_supervisor_seal':sha(Q/'SHA256SUMS'),'original_collector_sha256':sha(D/'originals/collect-licence-basis.py'),'references':refs,'additional_git_source':{k:v for k,v in recipe_refs.items() if k.startswith('git:')}})
print(json.dumps({'components':len(specs),'occurrences':len(rows),'historical_notice_rows':len(notices),'selected_hash':sha(D/'selected-current.json'),'plan_hash':sha(D/'supplement-plan.json')},indent=2))

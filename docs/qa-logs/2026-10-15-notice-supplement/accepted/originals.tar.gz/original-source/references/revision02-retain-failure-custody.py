"""Copy only completed failed-run evidence into the assigned durable directory."""
from pathlib import Path
import hashlib,json,stat,tarfile,gzip,decimal,datetime
S=Path('/tmp/pix-m7-current-notice-supplement-20261015')
O=Path('/workspace/tmp/pix-m7-current-notice-supplement-20261015-01')
R=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02/.build-runs/20261015T104827Z-81133446')
V=Path('/tmp/pix-m7-notice-root-review-20261015')
D=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/qa-logs/2026-10-15-notice-supplement/failure')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(p.read_text())
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
assert sha(S/'SHA256SUMS')=='8f6a6fd930b24809aab7c2438fe59c2d360ef09cb743f808618ab81ccff1ec69'
for line in (S/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(S/n)==h
assert sha(O/'partial-members.json')=='8ef2d4c94be4cd75f539a95bf686086f026bfd3991b5a3c8df296df509e931b4'
partial=load(O/'partial-members.json');assert len(partial)==2813
for r in partial:
 p=Path(r['path']);assert p.resolve(strict=True).is_relative_to(O/'collection') and not p.is_symlink()
 assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert sorted(r['path'] for r in partial)==sorted(str(p) for p in (O/'collection').rglob('*') if p.is_file())
assert sum(r['bytes'] for r in partial)==34621035
c=load(R/'admission-consumed.json');assert c['state']=='consumed' and c['id']=='3f886f1bc9dc47acb891bb587449df77'
assert [c['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[1,0,1]
assert load(O/'launcher-result.json')['runner_returncode']==1
child=load(O/'stage/notices.result.json');assert child['original_child_returncode']==1 and child['wait_observed'] and not child['timeout'] and not child['interrupted'] and not child['cleanup_signals']
assert not D.exists();D.mkdir(parents=True)
rows=[];pairs=[]
for root,prefix in [(S,'original-source'),(O,'failed-owner'),(R,'original-watch-run'),(V,'root-source-review')]:
 for p in [root,*sorted(root.rglob('*'))]:
  assert not p.is_symlink() and (p.is_file() or p.is_dir());s=p.stat();name=prefix+('/'+str(p.relative_to(root)) if p!=root else '')
  assert not p.is_file() or s.st_size<16*1024**2,'unexpected bulk original'
  row={'member':name,'original_path':str(p),'kind':'directory' if p.is_dir() else 'file','mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if p.is_file() else 0,'sha256':sha(p) if p.is_file() else None};rows.append(row);pairs.append((p,name,row))
archive=D/'originals.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for p,name,row in pairs:
    m=t.gettarinfo(str(p),arcname=name);m.pax_headers={'mtime':str(decimal.Decimal(row['mtime_ns'])/decimal.Decimal(10**9))};row['uname']=m.uname;row['gname']=m.gname
    if p.is_file():
     with p.open('rb') as src:t.addfile(m,src)
    else:t.addfile(m)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,r in zip(members,rows):
  assert m.name.rstrip('/')==r['member'] and m.mode==r['mode'] and m.uid==r['uid'] and m.gid==r['gid'] and m.uname==r['uname'] and m.gname==r['gname']
  assert int(decimal.Decimal(m.pax_headers['mtime'])*decimal.Decimal(10**9))==r['mtime_ns']
  if r['kind']=='file':assert m.isfile() and m.size==r['bytes'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']==sha(Path(r['original_path']))
  else:assert m.isdir()
dump(D/'members.json',{'archive_sha256':sha(archive),'members':rows,'files':sum(r['kind']=='file' for r in rows),'directories':sum(r['kind']=='directory' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)})
dump(D/'outcomes.json',{'original_source_seal':sha(S/'SHA256SUMS'),'run':str(R),'owner':str(O),'consumed_id':c['id'],'consumed_sha256':sha(R/'admission-consumed.json'),'original_command_monitor_runner':[1,0,1],'original_collector_exit':1,'original_launcher_exit':1,'timeout':False,'cleanup_signals':[],'partial_payload_files':len(partial),'partial_payload_bytes':34621035,'retained_text_bytes':21640664,'completed_occurrences':11,'attempted_incomplete_occurrence':'generic-x64-x86_64:libretro-database','failed_global_counter':65537,'publication_clearance':False,'selection_complete':False})
(D/'README.md').write_text('''# #528 original notice-supplement failure

This is exact custody of source packet `8f6a6fd9`, its root source review/allocation record, completed owner01, and original watched run `20261015T104827Z-81133446`. The collector stopped after approximately 4.96 seconds at its original global path/index limit, with counter 65,537. Original collector, command, runner and launcher exits are 1; monitor exit is 0. No timeout, interruption or cleanup signal occurred. The coordinator consumed it as failed-investigated under admission `3f886f1bc9dc47acb891bb587449df77`.

The traceback reaches package-prefix enumeration for the twelfth attempted occurrence, GENERIC libretro-database. The old global counter included all encountered directory names before filtering and separate image/package/source paths; its in-memory path set was not retained. No exact database cardinality or irrelevant-name-only cause is claimed. Eleven occurrence files completed; the database occurrence did not. All 2,813 partial collection payloads (34,621,035 bytes), including 21,640,664 bytes of content-addressed text, are retained once in the archive. Their complete original manifest is preserved. These partial observations do not qualify the failed producer or establish complete selection.

`originals.tar.gz` contains exact source, root review, owner, and watch-run originals. `members.json` records original paths, hashes, bytes, modes, uid/gid, names and nanosecond mtimes; every archive member was checked against its original. Content-addressed text is stored only in the original owner's collection subtree; no separate payload copy is added here. No build caches, firmware, source-tree archive, product mutation, runtime rerun or shared-record edit occurred during retention. A fresh correction and any later execution are separate evidence. ABL implementation/access, Doom WAD terms, source selection, notice interpretation and publication gaps remain open.
''')
dump(D/'custody-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_EXACT_CUSTODY_OF_FAILED_ORIGINALS','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows),'partial_payload_members_verified':2813,'checks':['Original source outer seal and42 payloads exact.','All2813 partial payloads exact, complete membership compared to original completed output directory.','Original child1, command/monitor/runner1/0/1, launcher1 and consumed failure retained.','Every archive member byte/hash/mode/uid/gid/name/nsmtime matches original.'],'new_collector_or_product_runtime':False})
files=sorted(p for p in D.iterdir() if p.is_file());(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files))
for line in (D/'SHA256SUMS').read_text().splitlines():h,n=line.split('  ',1);assert sha(D/n)==h
print(json.dumps({'directory':str(D),'seal':sha(D/'SHA256SUMS'),'archive':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'files':sum(r['kind']=='file' for r in rows),'original_file_bytes':sum(r['bytes'] for r in rows)},indent=2))

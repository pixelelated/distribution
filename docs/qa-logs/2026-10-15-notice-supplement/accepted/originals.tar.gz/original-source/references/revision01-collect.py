#!/usr/bin/env python3
"""Bounded additive notice evidence; no build evaluation, archives, network or target execution."""
from pathlib import Path, PurePosixPath
import datetime, fnmatch, hashlib, json, os, stat, time, traceback

O = Path(__file__).resolve().parent
START = time.monotonic()
PLAN = json.loads((O/'supplement-plan.json').read_text())
L = PLAN['limits']
OUT = O/'collection'
NOTICES = OUT/'notices'
SEEN = set()
CACHE = {}
TEXT_HASHES = set()
TEXT_BYTES = 0
INPUT_BYTES = 0
ROWS = []
NOTICE_NAMES = ('LICENSE','LICENSE.txt','LICENSE.TXT','LICENSE.md','COPYING','COPYING.txt','NOTICE','NOTICE.txt','AUTHORS','README','README.md')

def tick(path):
    assert time.monotonic()-START < L['soft_seconds'], 'soft collection deadline exceeded'
    key = str(path)
    SEEN.add(key)
    assert len(SEEN) <= L['path_rows'], '65,536 path/index row limit exceeded'

def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')

def path_in(root, rel):
    root = Path(root)
    assert root.is_absolute() and '..' not in root.parts
    assert root.resolve(strict=True) == root and root.is_dir(), 'noncanonical root: '+str(root)
    r = PurePosixPath(rel)
    assert not r.is_absolute() and '..' not in r.parts and r.parts, 'unsafe selected relative path'
    p = root.joinpath(*r.parts)
    # Never follow an unbound parent link. Leaf links are recorded, never traversed.
    for parent in p.parents:
        if parent == root:
            break
        assert not parent.is_symlink(), 'symlinked selected parent: '+str(parent)
    else:
        raise AssertionError('selected path escaped root')
    return p

def entries(directory):
    if not directory.exists():
        return []
    assert directory.is_dir() and not directory.is_symlink(), directory
    items = []
    with os.scandir(directory) as scan:
        for item in scan:
            tick(item.path)
            items.append(item.name)
    return [directory/n for n in sorted(items)]

def retain(raw):
    global TEXT_BYTES
    assert len(raw) <= L['text_member_bytes'], '2 MiB text member limit exceeded'
    h = hashlib.sha256(raw).hexdigest()
    if h not in TEXT_HASHES:
        assert TEXT_BYTES+len(raw) <= L['retained_text_bytes'], '128 MiB retained text limit exceeded'
        with (NOTICES/h).open('xb') as f:
            f.write(raw)
        TEXT_HASHES.add(h)
        TEXT_BYTES += len(raw)
    return dict(sha256=h, bytes=len(raw), retained='collection/notices/'+h,
                empty=len(raw)==0, notice_coverage_established=False)

def inspect(root, rel, text=False, expected=None):
    global INPUT_BYTES
    root=Path(root)
    if not root.exists():
        assert root.is_absolute() and '..' not in root.parts and not root.is_symlink()
        r=PurePosixPath(rel);assert not r.is_absolute() and '..' not in r.parts and r.parts
        return dict(path=str(root/r),relative=rel,kind='missing',status='UNAVAILABLE_SELECTED_ROOT_NOT_PROOF_OF_EXCLUSION')
    p = path_in(root, rel)
    tick(p)
    key = str(p)
    if key in CACHE:
        row = dict(CACHE[key])
        if expected is not None:
            assert row.get('sha256') == expected, 'changed selected member: '+key
        if text and row['kind']=='file' and 'retained_text' not in row:
            assert row['bytes'] <= L['text_member_bytes'], '2 MiB text member limit exceeded: '+key
            raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
            row['retained_text']=retain(raw);CACHE[key]=row
        return row
    try:
        s = p.lstat()
    except FileNotFoundError:
        return dict(path=key, relative=rel, kind='missing', status='UNAVAILABLE_AT_EXACT_SELECTED_PATH')
    row = dict(path=key, relative=rel, mode=stat.S_IMODE(s.st_mode), uid=s.st_uid,
               gid=s.st_gid, mtime_ns=s.st_mtime_ns, bytes=s.st_size)
    if stat.S_ISLNK(s.st_mode):
        target=os.readlink(p)
        row.update(kind='symlink', link_target=target,
                   status='RAW_LINK_RETAINED_TARGET_RELATION_UNRESOLVED')
        # Preserve raw identity, but do not read outside a declared root or infer referent equality.
        row['sha256']=hashlib.sha256(os.fsencode(target)).hexdigest()
    else:
        assert stat.S_ISREG(s.st_mode), 'unexpected selected special file: '+key
        limit=L['text_member_bytes'] if text else L['binary_member_bytes']
        assert s.st_size<=limit, 'selected member size limit exceeded: '+key
        assert INPUT_BYTES+s.st_size<=L['input_hash_bytes'], 'summed named-read limit exceeded'
        h=hashlib.sha256();parts=[]
        with p.open('rb') as f:
            assert stat.S_ISREG(os.fstat(f.fileno()).st_mode)
            for block in iter(lambda:f.read(1024**2),b''):
                tick(p);h.update(block)
                if text:parts.append(block)
        after=p.lstat()
        assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns), 'input changed during read'
        INPUT_BYTES+=s.st_size
        row.update(kind='file',sha256=h.hexdigest(),status='OBSERVED_REGULAR_FILE')
        if text:row['retained_text']=retain(b''.join(parts))
    if expected is not None:assert row['sha256']==expected, 'selected identity mismatch: '+key
    CACHE[key]=row
    return dict(row)

def patterned(root, pattern):
    """Finite path segments only; no recursive ** or package/cache-root census."""
    parts=PurePosixPath(pattern).parts
    assert parts and len(parts)<=L['max_pattern_depth'] and '**' not in pattern and '..' not in parts
    current=[Path(root)]
    for i,part in enumerate(parts):
        following=[]
        for parent in current:
            candidates=entries(parent) if any(c in part for c in '*?[') else [parent/part]
            for p in candidates:
                if not fnmatch.fnmatchcase(p.name,part):continue
                if i==len(parts)-1:
                    if p.is_file() or p.is_symlink():following.append(p)
                elif p.exists():
                    assert p.is_dir() and not p.is_symlink(), 'metadata parent link/special path'
                    following.append(p)
        current=following
    return sorted({str(p.relative_to(root)) for p in current})

def generated_roots(root):
    # scripts/build places generated target records in .${TARGET_NAME}; retain all candidates.
    matches=[p for p in entries(Path(root)) if p.name.startswith('.') and '-rocknix-linux-' in p.name]
    assert all(p.is_dir() and not p.is_symlink() for p in matches), 'unexpected generated-root link/type'
    return matches

def metadata(root, patterns, role):
    result=[]
    for pattern in patterns:
        matches=patterned(root,pattern)
        if not matches:
            result.append(dict(role=role,pattern=pattern,status='NO_MATCH_IN_SELECTED_ROOT'))
        for rel in matches:
            result.append(dict(role=role,pattern=pattern,original=inspect(root,rel,text=True),
                               interpretation='Original bytes only; not an executed build or effective-variable inference.'))
    return result

def exact_identity(r):
    src=r['unpacked_root'];un=r['component_row']['unpacked_source']
    observed=[inspect(src,'.rocknix-unpack',text=True,expected=un['unpack_stamp_sha256'])]
    assert observed[0]['kind']=='file', 'required unpack stamp absent'
    for name,h in un['build_stamps'].items():
        row=inspect(r['build_root'],'.stamps/'+un['package']+'/'+name,text=True,expected=h)
        assert row['kind']=='file';observed.append(row)
    for rec in r['component_row']['recipe_inheritance']:
        row=inspect(r['tree'],rec['path'],text=True,expected=rec['sha256'])
        assert row['kind']=='file';observed.append(row)
    return observed

def prefix_members(root, prefix):
    base=path_in(root,prefix)
    if not base.exists():return set()
    assert base.is_dir() and not base.is_symlink()
    pending=[base];found=set()
    while pending:
        current=pending.pop()
        assert len(current.relative_to(base).parts)<=32, 'selected prefix nesting bound'
        for p in entries(current):
            if p.is_symlink() or p.is_file():found.add(str(p.relative_to(root)))
            else:
                assert p.is_dir(), 'special selected prefix entry'
                pending.append(p)
    return found

def source_notices(root, relative):
    rel=PurePosixPath(relative);found=[]
    for parent in [rel.parent,*rel.parent.parents]:
        for name in NOTICE_NAMES:
            member=str(parent/name)
            p=path_in(root,member)
            if p.is_file() and not p.is_symlink():
                found.append(inspect(root,member,text=True))
    # Exact full text retains in-file notices/includes; binary assets retain hashes only.
    p=path_in(root,relative)
    if p.is_file() and not p.is_symlink():
        with p.open('rb') as f:sample=f.read(4096)
        if b'\0' not in sample:
            found.append(inspect(root,relative,text=True))
    return found

def same_identity(a,b):
    if a['kind']!=b['kind']:return False
    if a['kind']=='file':return a['sha256']==b['sha256'] and a['bytes']==b['bytes']
    if a['kind']=='symlink':return a['link_target']==b['link_target']
    return False

def shaders_and_database(r,spec):
    prefix=spec['prefix'];profile=r['profile']
    # Both H700 common-shaders candidates are preserved, including identical origins.
    candidates=[x for x in PLAN['occurrences'] if x['profile']==profile and PLAN['component_specs'][x['component']].get('prefix')==prefix]
    final_paths=prefix_members(r['image_root'],prefix)
    staged={x['component']:prefix_members(x['install_pkg_root'],prefix) for x in candidates}
    paths=set(final_paths)
    for v in staged.values():paths.update(v)
    result=[]
    for rel in sorted(paths):
        final=inspect(r['image_root'],rel)
        origins=[]
        for c in candidates:
            stage=inspect(c['install_pkg_root'],rel)
            source_rel=str(PurePosixPath(rel).relative_to(prefix))
            source=inspect(c['unpacked_root'],source_rel)
            match=final['kind']=='file' and same_identity(final,stage) and same_identity(stage,source)
            origins.append(dict(component=c['component'],package=stage,source=source,
                                package_matches_final=same_identity(final,stage),source_matches_package=same_identity(stage,source),
                                source_byte_origin_match=match,mode_equal=(final.get('mode')==stage.get('mode')==source.get('mode')),
                                notice_members=source_notices(c['unpacked_root'],source_rel) if source['kind']=='file' else [],
                                notice_scope='Scoped ancestor candidates and full selected source bytes; applicability not automatically settled.'))
        matches=[x['component'] for x in origins if x['source_byte_origin_match']]
        result.append(dict(final=final,origins=origins,matching_origins=matches,
                           attribution='MULTIPLE_MATCHING_ORIGINS_PRESERVED' if len(matches)>1 else 'SINGLE_BYTE_MATCH_NOT_LICENCE_CLEARANCE' if matches else 'UNRESOLVED_NO_SOURCE_PACKAGE_FINAL_MATCH'))
    return result

def library_and_outputs(r,spec):
    paths=set(spec.get('outputs',[]))
    for pattern in spec.get('library_patterns',[]):
        for root in [r['install_pkg_root'],r['image_root']]:
            for rel in patterned(root,'usr/lib/'+pattern):paths.add(rel)
    result=[]
    for rel in sorted(paths):
        package=inspect(r['install_pkg_root'],rel);staged=inspect(r['image_root'],rel)
        item=dict(path=rel,package=package,staged_image=staged,package_matches_staged=same_identity(package,staged),
                  relation='Observation only; stripped/generated output needs explicit source/link derivation, and no independent SYSTEM extraction is added.')
        if 'compatibility_handoff' in r and rel.startswith('usr/lib/'):
            handoff=r['compatibility_handoff'];dest='usr/lib32/'+rel.removeprefix('usr/lib/')
            hp=inspect(handoff['package_root'],dest);hi=inspect(handoff['image_root'],dest)
            item['compatibility_handoff']=dict(binding=handoff,destination=dest,package=hp,staged_image=hi,
                arm_image_matches_lib32_package=same_identity(staged,hp),lib32_package_matches_aarch64_image=same_identity(hp,hi))
        result.append(item)
    return result

def cache_variables(records,names):
    observed=[]
    for rec in records:
        f=rec.get('original',{})
        if f.get('kind')!='file' or not f['path'].endswith('/CMakeCache.txt'):continue
        raw=(O/f['retained_text']['retained']).read_text(errors='strict')
        values={name:[] for name in names}
        for line in raw.splitlines():
            for name in names:
                if line.startswith(name+':') and '=' in line:values[name].append(line)
        observed.append(dict(path=f['path'],sha256=f['sha256'],raw_cache_entries=values,
                             meaning='Observed generated cache serialization only; no recipe override or default guessed.'))
    return observed

def main():
    OUT.mkdir();NOTICES.mkdir()
    selected=json.loads((O/'selected-current.json').read_text())
    assert hashlib.sha256((O/'selected-current.json').read_bytes()).hexdigest()==PLAN['selection_sha256']
    assert hashlib.sha256((O/'basis.json').read_bytes()).hexdigest()==PLAN['basis_sha256']
    assert len(PLAN['component_specs'])==16 and len(PLAN['occurrences'])==43
    historical_observed={}
    for note in PLAN['historical_notices']:
        p=Path(note['path'])
        historical_observed[str(p)]=inspect(p.parent,p.name,text=True,expected=note['sha256'])
    for r in PLAN['occurrences']:
        spec=PLAN['component_specs'][r['component']]
        row=dict(component=r['component'],profile=r['profile'],accepted_input=r,
                 observed_licence_basis=spec['basis'],publication_clearance=False,
                 scope_controls=spec['flags_and_scope_controls'],unresolved=list(spec.get('unresolved',[])))
        ROWS.append(row)
        if spec.get('hold_only'):
            row.update(status='EXISTING_UNRESOLVED_HOLD_NO_NEW_SOURCE_READ',selected_files=[],build_selection=[])
            write(OUT/(r['profile']+'--'+r['component'].replace('/','_')+'.json'),row)
            continue
        row['selected_identity']=exact_identity(r)
        row['notice_rebindings']=[]
        for note in PLAN['historical_notices']:
            if note['component']!=r['component']:continue
            item=dict(historical=note,retained_historical=historical_observed[note['path']],current=None,status='UNRESOLVED_NO_RELATIVE_MEMBER')
            rel=note['current_relative_member']
            if rel is not None:
                current=inspect(r['unpacked_root'],rel,text=True);item['current']=current
                if current.get('sha256')==note['sha256']:
                    item['status']='EXACT_CURRENT_MEMBER_MATCH_EMPTY_NOT_COVERAGE' if current.get('bytes')==0 else 'EXACT_CURRENT_MEMBER_MATCH_SCOPE_STILL_OPEN'
                else:item['status']='UNRESOLVED_CURRENT_MEMBER_MISSING_OR_CHANGED'
            row['notice_rebindings'].append(item)
        row['source_semantics']=metadata(r['unpacked_root'],spec.get('source_files',[]),'SOURCE_SEMANTICS_NOT_EFFECTIVE_BUILD_FLAGS')
        row['build_selection']=metadata(r['unpacked_root'],spec.get('metadata',[]),'SELECTED_ORIGINAL_RECORD')
        gr=generated_roots(r['unpacked_root']);row['generated_roots']=[str(p) for p in gr]
        for g in gr:row['build_selection']+=metadata(g,spec['generated_patterns'],'GENERATED_BUILD_RECORD')
        row['effective_cache_observations']=cache_variables(row['build_selection'],spec.get('effective_variables',[]))
        row['unknown_effective_variables']=[n for n in spec.get('effective_variables',[]) if not any(v['raw_cache_entries'].get(n) for v in row['effective_cache_observations'])]
        row['shared_source_parents']=[]
        for parent in r['source_parents']:
            pr=dict(parent,identity=exact_identity(dict(r,unpacked_root=parent['root'],component_row=parent['component_row'])),notices=[inspect(parent['root'],n,text=True) for n in ['COPYING','src/COPYING','test/COPYING']])
            row['shared_source_parents'].append(pr)
        row['consumer_candidates']=[]
        for consumer in PLAN['consumer_candidates'][r['profile']+':'+r['component']]:
            cr=dict(consumer,records=[])
            if consumer.get('source_root'):
                cr['identity']=exact_identity(dict(r,unpacked_root=consumer['source_root'],component_row=consumer['component_row']))
                for g in generated_roots(consumer['source_root']):
                    # Avoid scanning/retaining whole WebKit/consumer compile graphs. Keep small named originals.
                    cr['records']+=metadata(g,['CMakeCache.txt','CMakeFiles/TargetDirectories.txt','CMakeFiles/*.dir/link.txt','*.la','meson-info/intro-dependencies.json'],'CONSUMER_SELECTION_CANDIDATE_NOT_LINK_PROOF')
            row['consumer_candidates'].append(cr)
        row['selected_output_roots']={k:dict(path=r[k],exists=Path(r[k]).is_dir(),absence_is_exclusion=False) for k in ['install_pkg_root','image_root']}
        row['selected_files']=shaders_and_database(r,spec) if 'prefix' in spec else library_and_outputs(r,spec)
        if 'prefix' not in spec:row['unresolved'].append('Selected native/static consumer inclusion remains unproved until exact original link/source selection is reviewed; no install stamp or absent symbols establish exclusion.')
        row['status']='COLLECTED_SELECTION_EVIDENCE_WITH_OPEN_DISPOSITIONS'
        write(OUT/(r['profile']+'--'+r['component'].replace('/','_')+'.json'),row)
    # An additional record can only come from a pre-bound selected source/consumer root.
    extra=json.loads((O/'extra-records.json').read_text());extra_rows=[]
    for x in extra['records']:
        matches=[r for r in PLAN['occurrences'] if (r['component'],r['profile'])==(x['component'],x['profile'])];assert len(matches)==1
        r=matches[0];role=x['root_role']
        if role=='source':root=r['unpacked_root']
        elif role.startswith('retained:'):
            root=Path(role.split(':',1)[1]);assert root.is_absolute() and root.resolve(strict=True)==root
        else:
            assert role.startswith('consumer:');name=role.split(':',1)[1]
            matches=[c for c in PLAN['consumer_candidates'][r['profile']+':'+r['component']] if c['component']==name and c.get('source_root')];assert len(matches)==1;root=matches[0]['source_root']
        original=inspect(root,x['relative_path'],text=True,expected=x['sha256']);assert original['kind']=='file'
        extra_rows.append(dict(binding=x,original=original,automatic_source_selection_clearance=False))
    write(OUT/'extra-records.json',extra_rows)
    # Hash inventory is data; no licence applicability is inferred from filenames or declarations.
    members=[dict(path=str(p.relative_to(O)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()]
    write(O/'collection-members.json',members)
    report=dict(result='COLLECTED_WITH_OPEN_DISPOSITIONS',original_collector_exit=0,components=16,occurrences=43,
                rows=[dict(component=r['component'],profile=r['profile'],status=r['status'],unresolved=r['unresolved']) for r in ROWS],
                path_index_rows=len(SEEN),retained_text_bytes=TEXT_BYTES,named_input_hash_bytes=INPUT_BYTES,
                content_addressed_text_members=len(TEXT_HASHES),publication_clearance=False,publication_bundle_complete=False,
                target_execution=False,network_used=False,archives_opened=False,independent_SYSTEM_relation_established=False,
                limits=L,scope='Bounded staged/package/selected-source and original metadata observations; applicability and missing selection remain open. ABL/Doom holds unchanged.')
    write(O/'collection-result.json',report)
    print(json.dumps(report,sort_keys=True))

if __name__=='__main__':
    try:main()
    except BaseException as error:
        if OUT.exists() and not (O/'collection-failure.json').exists():
            write(O/'collection-failure.json',dict(result='COLLECTION_FAILED',error=type(error).__name__+': '+str(error),
                  partial_occurrences=[dict(component=r['component'],profile=r['profile']) for r in ROWS],
                  path_index_rows=len(SEEN),retained_text_bytes=TEXT_BYTES,publication_bundle_complete=False))
        traceback.print_exc()
        raise

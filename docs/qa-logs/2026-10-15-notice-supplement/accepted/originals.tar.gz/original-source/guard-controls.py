#!/usr/bin/env python3
"""UNRUN pure in-memory controls for the exact write-guard and matcher functions only."""
from pathlib import Path, PurePosixPath
import ast,hashlib,io,json,fnmatch
P=Path(__file__).resolve().parent
source=(P/'templates/collect.py').read_bytes()
expected=json.loads((P/'guard-controls-binding.json').read_text())
assert hashlib.sha256(source).hexdigest()==expected['collector_sha256']
tree=ast.parse(source);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['account_output','write','patterned']]
assert [n.name for n in nodes]==['account_output','write','patterned']
# Only these reviewed guard/write/matcher definitions execute, using memory-only fake paths.
assert hashlib.sha256(ast.dump(ast.Module(body=nodes,type_ignores=[]),include_attributes=False).encode()).hexdigest()==expected['guard_ast_sha256']
ns={'json':json};exec(compile(ast.Module(body=nodes,type_ignores=[]),'selected-guard-definitions','exec'),ns)
class MemoryPath:
    def __init__(self,name='member.json',data=None,link=False):self.name=name;self.data=data;self.link=link
    def __str__(self):return 'memory-only:'+self.name
    def exists(self):return self.data is not None
    def is_symlink(self):return self.link
    def open(self,mode):
        assert mode=='xb'
        if self.exists() or self.link:raise FileExistsError(self.name)
        p=self
        class Sink(io.BytesIO):
            def __exit__(self,*args):p.data=self.getvalue();self.close()
        return Sink()
rows=[]
def setup(initial,ceiling,per_file=64,reserve=16):
    ns.update(OUTPUT_BYTES=initial,RESOURCES={'per_file_bytes':per_file,'owner_output_ceiling_bytes':ceiling},PLAN={'owner_output_enforcement':{'supervisor_receipt_reserve_bytes':reserve,'failure_receipt_budget_bytes':12,'supervisor_receipt_margin_bytes':4}})
def check(name,path,value,initial,ceiling,expected_error=False,per_file=64):
    setup(initial,ceiling,per_file);before=path.data
    try:ns['write'](path,value)
    except AssertionError:
        assert expected_error;assert path.data==before and ns['OUTPUT_BYTES']==initial
        rows.append({'case':name,'result':'PASS_EXPECTED_REFUSAL','output_bytes':ns['OUTPUT_BYTES']})
    else:
        assert not expected_error
        raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
        assert path.data==raw and ns['OUTPUT_BYTES']==initial+len(raw)
        rows.append({'case':name,'result':'PASS','output_bytes':ns['OUTPUT_BYTES']})
value={'x':1};size=len((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode())
check('normal-exact-reserved-boundary',MemoryPath(),value,7,7+size+16)
check('normal-one-byte-over',MemoryPath(),value,8,7+size+16,True)
check('initial-existing-file-byte-counts',MemoryPath(),value,5+7,5+7+size+16)
check('existing-output-refused-no-overwrite',MemoryPath(data=b'existing'),value,8,64,True)
check('dangling-output-link-refused',MemoryPath(link=True),value,0,64,True)
check('failure-receipt-exact-full-boundary',MemoryPath('collection-failure.json'),value,7,7+size+4)
check('failure-receipt-one-byte-over',MemoryPath('collection-failure.json'),value,8,7+size+4,True)
check('existing-per-file-bound-refusal',MemoryPath(),value,0,64,True,per_file=size-1)
# Normal write cannot consume the reserve; a subsequent bounded failure receipt can.
setup(0,size+16);normal=MemoryPath();ns['write'](normal,value)
failure=MemoryPath('collection-failure.json');ns['write'](failure,{})
assert ns['OUTPUT_BYTES']==size+3 and ns['OUTPUT_BYTES']<=size+16-4
rows.append({'case':'failure-uses-only-bounded-remaining-reserve','result':'PASS','output_bytes':ns['OUTPUT_BYTES']})
check('failure-receipt-share-refusal',MemoryPath('collection-failure.json'),{'x':'0123456789'},0,64,True)
# Four matcher cases use synthetic nodes; no Path filesystem methods are called.
class Node:
    def __init__(self,path,kind='directory',children=None,dangling=False):
        self.path=PurePosixPath(path);self.kind=kind;self.children=children or {};self.dangling=dangling
    @property
    def name(self):return self.path.name
    def __str__(self):return str(self.path)
    def __truediv__(self,name):return self.children.get(name,Node(str(self.path/name),'missing'))
    def exists(self):return self.kind!='missing' and not self.dangling
    def is_file(self):return self.kind=='file'
    def is_dir(self):return self.kind=='directory'
    def is_symlink(self):return self.kind=='symlink'
    def relative_to(self,root):return self.path.relative_to(root.path)
def entries(node,census):
    assert node.is_dir() and not node.is_symlink(), 'fake traversal reached forbidden parent'
    census['entries']+=len(node.children)
    return [node.children[k] for k in sorted(node.children)]
ns.update(Path=lambda node:node,PurePosixPath=PurePosixPath,fnmatch=fnmatch,L={'max_pattern_depth':4},entries=entries,traversal=lambda root,scope:dict(root=str(root),scope=scope,entries=0,complete=False))
def match_case(name,children,expected_result=None,refusal=False):
    ext=Node('/memory/ext',children=children);root=Node('/memory',children={'ext':ext})
    try:result=ns['patterned'](root,'ext/*/*.d')
    except AssertionError as error:
        assert refusal and str(error).startswith('metadata parent link: /memory/ext/')
        rows.append({'case':name,'result':'PASS_EXPECTED_REFUSAL'})
    else:
        assert not refusal and result==expected_result
        rows.append({'case':name,'result':'PASS','matches':result})
match_case('matcher-regular-intermediate-nonmatch',{'README.md':Node('/memory/ext/README.md','file')},[])
match_case('matcher-directory-leaf-match',{'vendor':Node('/memory/ext/vendor',children={'ok.d':Node('/memory/ext/vendor/ok.d','file')})},['ext/vendor/ok.d'])
match_case('matcher-parent-link-refusal',{'link':Node('/memory/ext/link','symlink')},refusal=True)
match_case('matcher-dangling-parent-link-refusal',{'link':Node('/memory/ext/link','symlink',dangling=True)},refusal=True)
print(json.dumps({'result':'PASS_SYNTHETIC_GUARD_CONTROLS','collector_sha256':expected['collector_sha256'],'cases':rows,'candidate_module_imported_or_main_run':False,'filesystem_writes':False,'production_paths_accessed':False,'scope':'Only three extracted definitions with in-memory fake paths; not collector, actual owner-census or runtime qualification.'},sort_keys=True))

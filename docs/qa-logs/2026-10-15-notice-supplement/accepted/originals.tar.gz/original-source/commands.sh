#!/bin/bash
# SOURCE ONLY / UNRUN. Root reviews each boundary and allocates one serialized owner.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-current-notice-supplement-20261015-04
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-current-notice-supplement-20261015-04}
cd "$TASK_TREE"
case "${1:?prepare, preflight, report, admit, launch, or consume}" in
 prepare)
  task_extra=()
  if [[ -n ${TASK_EXTRA_RECORDS:-} ]]; then task_extra=(--extra-records "$TASK_EXTRA_RECORDS" --extra-records-sha256 "${TASK_EXTRA_RECORDS_SHA256:?exact original record-list hash}"); fi
  tools/watch-build --record-only -- python3 -I -S -B "$TASK_PACKET/prepare-owner.py" --owner "$TASK_OWNER" "${task_extra[@]}"
  ;;
 preflight) tools/build-preflight ;;
 report) tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json" ;;
 admit) python3 -I tools/host-maintenance/build-admission prepare --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json" ;;
 launch) env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh" ;;
 consume) python3 -I "$TASK_OWNER/consume.py" ;;
 *) exit 2 ;;
esac
# Root supervises original channels <=60s. Submission is not completion; never
# pre-create launcher-owned receipts. Failed outputs are held and investigated.

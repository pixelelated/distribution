Selected source and notice evidence collection is next.

Can this be done on the VM? No. This check reads original build-selection records retained on the build host; a guest cannot reconstruct that metadata. No guest or handheld behavior is being tested.

The bounded read-only check covers 16 non-prebuilt components across the accepted device profiles. It compares shader source attribution and collects selected build metadata without rebuilding, opening game archives, accessing user data, or modifying firmware. The original results will be recorded before any success claim. Missing evidence and unresolved publication requirements remain open.

The private-copy strip proof passed for all nine rclone/Tailscale binaries: transformed bytes match packaged and staged bytes, all originals remained unchanged, and successful temporary copies were removed. Remaining corresponding-source and embedded-notice questions stay open.

Next is the reviewed notice continuation. It retains eleven complete records from the failed collection as explicitly historical evidence and collects the remaining thirty-two occurrences in separate bounded batches. The overall time, memory and byte limits remain unchanged; shared notice metadata is stored once instead of repeated per file. The original failure remains intact.

Can this be done on the VM? No: these are original host build-selection and staged-source records, not guest behavior. This is a bounded host evidence read, with active watcher supervision and original-result verification. No firmware, device, cloud or source-build action is included.

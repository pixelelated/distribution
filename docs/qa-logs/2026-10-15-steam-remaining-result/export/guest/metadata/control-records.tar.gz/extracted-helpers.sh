log_info() { echo -e "[\033[1;34mINFO\033[0m] $1"; }
die() { echo -e "[\033[1;31mERROR\033[0m] $1" >&2; sleep 10; exit 1; }

set -e
set -o pipefail
log_info() { echo -e "[\033[1;34mINFO\033[0m] $1"; }
die() { echo -e "[\033[1;31mERROR\033[0m] $1" >&2; sleep 10; exit 1; }
fetch_proton_latest_release() {
  local api_url="$1"
  local asset_pattern="$2"
  local tag_prefix_to_strip="$3"
  local var_prefix="$4"
  local display_name="$5"

  log_info "Fetching latest ${display_name} release from GitHub..."

  local release_json
  release_json=$(curl -q -fsSL --connect-timeout 10 --max-time 30 --max-filesize 1048576 "${api_url}") || die "Failed to fetch ${display_name} latest release info."

  # Extract tag name
  local version_tag
  version_tag=$(echo "${release_json}" | grep -oP '"tag_name":\s*"\K[^"]+' | head -n 1) || die "Failed to parse ${display_name} version tag."
  [ -n "${version_tag}" ] || die "${display_name} version tag is empty."

  # Extract download URL for specified asset pattern, excluding checksums
  local download_url
  download_url=$(echo "${release_json}" | grep -oP '"browser_download_url":\s*"\K[^"]*'"${asset_pattern}"'[^"]*' | grep -v '\.sha512sum' | head -n 1) || die "Failed to parse ${display_name} download URL."
  [ -n "${download_url}" ] || die "Could not find ${asset_pattern} asset in ${display_name} release."

  # Extract filename from URL
  local tar_name
  tar_name=$(basename "${download_url}") || die "Failed to extract ${display_name} filename."
  [ -n "${tar_name}" ] || die "${display_name} filename is empty."

  local version_clean="${version_tag}"
  if [ -n "${tag_prefix_to_strip}" ]; then
    version_clean="${version_tag#${tag_prefix_to_strip}}"
  fi

  # Infer directory name based on tar filename
  local dir_name
  dir_name=$(echo "${tar_name}" | sed 's/\.[^.]*$//' | sed 's/\.[^.]*$//')  # Remove .tar.xz or .tar.gz

  # Set global variables dynamically
  eval "${var_prefix}_VERSION_FULL='${version_clean}'"
  eval "${var_prefix}_TAR='${tar_name}'"
  eval "${var_prefix}_DIR='${dir_name}'"
  eval "${var_prefix}_URL='${download_url}'"

  log_info "${display_name} latest version: ${version_clean}"
  log_info "${display_name} download URL: ${download_url}"
}

fetch_proton_latest_release http://127.0.0.1:42793/oversize arm64 cachyos- PROTON_CACHYOS Proton-CachyOS
printf '%s\n' "${PROTON_CACHYOS_VERSION_FULL}" "${PROTON_CACHYOS_TAR}" "${PROTON_CACHYOS_DIR}" "${PROTON_CACHYOS_URL}" > /tmp/pix-output/metadata/control/oversize/parsed.txt

"""Exact source/host bindings; no collection at import."""
from pathlib import Path
import hashlib,json,os,stat
COMMIT='f8636de1d105275dbf9420bbabbbc26f79abb10f'
VM_TREE=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def load(path):
 p=Path(path);assert p.is_file() and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size<16*1024**2,p
 return json.loads(p.read_text())
def host_and_serialization(own_run=None):
 assert (os.getuid(),os.getgid())==(1000,1000)
 assert os.readlink('/proc/self/ns/pid')=='pid:[4026531836]' and os.readlink('/proc/self/ns/user')=='user:[4026531837]'
 jobs=load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')['jobs'].values();active=[j for j in jobs if j['state']!='consumed']
 assert all(own_run is not None and j['run']==str(own_run) for j in active),'another unconsumed owner remains'
 if own_run is not None:assert len(active)==1 and active[0]['source']['head']==COMMIT

def prerequisites(plan):
 owner,run=Path(plan['failed_owner']),Path(plan['failed_run'])
 consumed=load(run/'admission-consumed.json');acceptance=load(plan['failed_acceptance'])
 assert consumed['id']==plan['failed_admission_id']=='3b38d221fb5f4d3cb7e83845e290780f' and consumed['state']=='consumed'
 assert consumed['run']==str(run) and consumed['submission_owner']==str(owner) and consumed['source']['head']==COMMIT
 assert consumed['evidence_sha256']==sha(plan['failed_acceptance']) and acceptance['disposition']=='failed-investigated' and acceptance['expected_rc']==1
 assert consumed['original_result']==load(run/'runner-result.json')
 assert [consumed['original_result'][k] for k in ['command_rc','monitor_rc','runner_rc']]==[1,0,1]
 assert load(owner/'launcher-result.json')['runner_returncode']==1
 failure=load(owner/'collection-failure.json');assert failure['original_collector_exit']==1 and failure['completed_normalized_patches']==0
 assert failure['error']=='AssertionError: canonical normalized patch SHA256 mismatch; no fallback'
 assert len(failure['requests'])==3 and len(failure['child_outcomes'])==7
 assert all(r['original_returncode']==0 and r['wait_observed'] is True and not r['timeout'] for r in failure['child_outcomes'])
 cleanup=load(owner/'cleanup.json');assert cleanup['all_recorded_identities_absent'] is True and not any(cleanup[k] for k in ['errors','receipt_errors','signals_sent','recorded_identities_still_present','survivors_after_cleanup'])
 return consumed

def verify(O):
 for name,h in load(O/'seal.json').items():
  p=Path(name);assert p.is_relative_to(O) and p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<1024**2 and sha(p)==h,name
 for name,h in load(O/'frozen-tools.json').items():assert sha(VM_TREE/name)==h,name
 plan=load(O/'collection-plan.json')
 for name,h in plan['binding_refs'].items():
  p=Path(name);assert p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_size<1024**2 and sha(p)==h,name
 assert load(O/'destination.json')['path']=='/workspace/artifacts/pixelelated-release-sources/m7-fex-normalized-patches-'+O.name.removeprefix('pix-m7-fex-patch-byte-custody-')
 assert [r['output_bytes'] for r in plan['inputs']]==[219,620] and [r['offset'] for r in plan['inputs']]==[71,0]
 assert [r['output_sha256'] for r in plan['inputs']]==['63a602cddfe36755593fd6c59479078f34b04a15de03b88959dc9fc69813da5d','233cf3f489f9dd6ec20befa4d5b2ebefc892ae6c69166d5c1fca9c4a9a6da144']
 assert bytes.fromhex(plan['exact_prefix_hex'])==b'diff --git a/configure.ac b/configure.ac\nindex 98c4175..e3f4fec 100644\n'
 assert [(r['member'],r['bytes'],r['sha256']) for r in plan['provenance_inputs']]==[('raw-large-file.patch',1193,'61b196be57e03fa7cef42d2d654e6b1351efe0c930757e4e8ec3b16eade6bb6f'),('normalizer-large-file.patch',290,'73f296735999f7fcb84cd9fa9c6ca9dd26b659382d6402416ddf488a677c2ac1')]
 assert plan['publication_clearance'] is False and plan['general_normalizer_equivalence_claim'] is False
 prerequisites(plan);return plan

#!/usr/bin/env python3
"""Consume exact original success channels only; retention does not clear publication."""
from pathlib import Path
import json,runpy,subprocess
O=Path(__file__).resolve().parent;B=runpy.run_path(str(O/'bindings.py'));plan=B['verify'](O)
assert Path.cwd()==B['VM_TREE'];load,sha=B['load'],B['sha'];run=Path((O/'run.path').read_text().strip());assert run.parent==B['VM_TREE']/'.build-runs';B['host_and_serialization'](run)
runner,launch=load(run/'runner-result.json'),load(O/'launcher-result.json')
assert all(type(runner[k])is int and runner[k]==0 for k in ['command_rc','monitor_rc','runner_rc'])
assert type(launch['runner_returncode'])is int and launch['runner_returncode']==0
for p in [O/'inner.rc',O/'outer.rc',O/'tool-wrapper.rc',run/'build.rc',O/'stage/association.exit']:assert p.read_text().strip()=='0',p
result,cleanup=load(O/'result.json'),load(O/'cleanup.json');assert result['result']=='PASS_SOURCE_COLLECTION_WITH_GAPS' and result['publication_bundle_complete']is False
assert result['runtime_control_source']==B['COMMIT'] and result['independent_SYSTEM_relation_established']is False
assert result['execution_error']is None and not result['cleanup_errors'] and not result['receipt_errors'] and not result['interrupted_signals']
assert len(result['stages'])==1 and result['stages'][0]['association_rc']==0 and not result['stages'][0]['timeout']
child=load(O/'stage/association.result.json');assert child['wait_observed']is True and type(child['original_child_returncode'])is int and child['original_child_returncode']==0
assert child['qualification']is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
report=load(O/'collection-result.json');assert report['result']=='COLLECTED_WITH_EXPLICIT_GAPS' and type(report['original_collector_exit'])is int and report['original_collector_exit']==0
assert report['objects']==2 and report['object_bytes']==839 and report['acquired_tools_executed'] is False
assert all(report[k] is False for k in ['source_execution','archive_decode','network_used','target_execution','publication_clearance','publication_bundle_complete'])
assert not (O/'collection-failure.json').exists();D=Path(load(O/'destination.json')['path']);assert report['custody_path']==str(D)
assert len(report['files'])==5 and {str(Path(r['path']).relative_to(D)) for r in report['files']}=={'manifest.json','large-file.patch','meson.patch','raw-large-file.patch','normalizer-large-file.patch'}
for r in report['files']:
 p=Path(r['path']);assert p.parent==D and not p.is_symlink() and p.resolve(strict=True)==p and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert {r['path'] for r in report['files']}=={str(p) for p in D.iterdir()}
assert sum(r['bytes'] for r in report['files'])<=1024**2 and sha(D/'manifest.json')==report['manifest_sha256']
manifest=load(D/'manifest.json');assert manifest['inputs']==plan['inputs'] and manifest['binding_refs']==plan['binding_refs']
assert manifest['provenance_inputs']==plan['provenance_inputs'] and report['provenance_bytes']==1483
for spec in plan['provenance_inputs']:
 p=D/spec['member'];assert p.stat().st_size==spec['bytes'] and sha(p)==spec['sha256']
 assert p.read_bytes()==Path(spec['path']).read_bytes()
assert manifest['exact_removed_prefix_hex']==plan['exact_prefix_hex'] and manifest['exact_removed_prefix_bytes']==71
assert manifest['prior_failed_run']==plan['failed_run'] and manifest['prior_failed_admission']==plan['failed_admission_id']
assert manifest['prior_original_channels']==[1,0,1] and manifest['prior_launcher']==1 and manifest['output_bytes']==839
assert manifest['general_normalizer_equivalence_claim'] is False and manifest['package_binaries_copied'] is False and manifest['publication_bundle_complete'] is False
for spec in plan['inputs']:
 source=Path(spec['path']);assert source.stat().st_size==spec['bytes'] and sha(source)==spec['sha256']
 raw=source.read_bytes()
 if spec['offset']:assert raw[:71]==bytes.fromhex(plan['exact_prefix_hex'])
 output=D/spec['member'];assert output.read_bytes()==raw[spec['offset']:] and output.stat().st_size==spec['output_bytes'] and sha(output)==spec['output_sha256']
 assert (output.stat().st_dev,output.stat().st_ino)!=(source.stat().st_dev,source.stat().st_ino)
import stat
assert all(stat.S_IMODE(p.lstat().st_mode)==(0o555 if p.is_dir() else 0o444) and not p.is_symlink() for p in [D,*D.iterdir()])
assert cleanup['all_recorded_identities_absent']is True and cleanup['recorded_identities_still_present']==[] and cleanup['survivors_after_cleanup']==[]
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent'] and cleanup['direct_child_unreaped']is False
I=runpy.run_path(str(O/'process-identity.py'));snapshot=I['census']();keys={(r['pid'],r['start_ticks']) for r in cleanup['recorded_identities']};supervisor=cleanup['supervisor_identity'];assert supervisor is not None;keys.add((supervisor['pid'],supervisor['start_ticks']))
matching=[r for r in snapshot if (r['pid'],r['start_ticks']) in keys];parents={r['pid'] for r in matching};descendants=[]
while parents:
 children=[r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants];descendants.extend(children);parents={r['pid'] for r in children}
assert not matching and not descendants
admission=load(run/'admission.json');assert admission['source']['head']==B['COMMIT'] and admission['submission_owner']==str(O)
files=[p for p in O.rglob('*') if p.is_file()]+[run/'runner-result.json',run/'build.rc']+[Path(r['path']) for r in report['files']]
assert len(files)<=1024 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())<=32*1024**2
out=O/'admission-completion-evidence.json';evidence=dict(run=str(run),disposition='qualified',expected_rc=0,outputs=admission['outputs'],evidence=[dict(path=str(p),sha256=sha(p)) for p in files],scope='Exact219-byte and620-byte canonical patch custody only, using bound290-byte input plus exact71-byte prefix and unchanged620-byte raw input. Prior normalizer run remains failed1; no general normalizer equivalence. No network, acquired tools, package binary custody, installation or publication clearance.')
raw=(json.dumps(evidence,indent=2)+'\n').encode();assert len(raw)<=1024**2 and sum(p.stat().st_size for p in O.rglob('*') if p.is_file())+len(raw)<=32*1024**2
with out.open('xb') as f:f.write(raw)
subprocess.run(['python3','-I',str(B['VM_TREE']/'tools/host-maintenance/build-admission'),'consume','--run',str(run),'--evidence',str(out)],check=True)
print('PASS consumed exact two-patch byte custody; prior normalization failure unchanged')

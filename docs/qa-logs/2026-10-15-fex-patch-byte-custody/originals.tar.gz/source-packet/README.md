# Exact retained patch bytes — #528, SOURCE ONLY / UNRUN

A small offline successor to the failed normalizer run. No further download, package extraction, acquired-tool execution, installation, build, Nix invocation or patch application is needed. Root reviews and allocates the existing guarded custody lifecycle; no new controls are proposed.

The two fixed selections are:

| Retained input | Required exact input | Exact selection | Required output |
| --- | --- | --- | --- |
| normalized01 `streams/final-large-file.patch.stdout` |290B, SHA256 `73f296735999f7fcb84cd9fa9c6ca9dd26b659382d6402416ddf488a677c2ac1` |Remove exactly the71-byte prefix below; retain bytes71–289 |219B, SHA256 `63a602cddfe36755593fd6c59479078f34b04a15de03b88959dc9fc69813da5d` |
| normalized01 `raw/meson.patch` |620B, SHA256 `233cf3f489f9dd6ec20befa4d5b2ebefc892ae6c69166d5c1fca9c4a9a6da144` |Copy unchanged |Same620B/hash |

The exact removable prefix consists of these two LF-terminated Git extended headers:

```text
diff --git a/configure.ac b/configure.ac
index 98c4175..e3f4fec 100644
```

This is a fixed byte slice, not a generalized header stripper. The source input must have the exact size, SHA256, inode/file identity and prefix, and the suffix must start `--- a/configure.ac\n`. Both selected outputs must match the original fetch derivations' canonical hashes **before any destination is created**. No expected hash changes and no patchutils version-equivalence claim.

`originals/` preserves the exact290-byte intermediate,620-byte meson input, original1193-byte large-file response, root investigation, all seven original child wait/result receipts, package inspection metadata, failed collector/runner/launcher/cleanup and ordinary consumed record. `originals.json` records exact source locators, bytes, hashes, modes, uid/gid and nanosecond mtimes. Package binaries and tar streams are not copied. The71-byte prefix and both source/output identities are explicit in the plan and future manifest.

Original run `20261015T151501Z-6dcae797` remains **command/monitor/runner1/0/1, launcher1**, zero completed normalized patches, with all three GETs and seven tool waits0. Ordinary failed-investigated consumption `3b38d221fb5f4d3cb7e83845e290780f` is bound to the actual acceptance and original result. This successor does not qualify or rewrite that failed attempt.

Fresh default owner: `/workspace/tmp/pix-m7-fex-patch-byte-custody-20261015-01`. Fixed supplement: `/workspace/artifacts/pixelelated-release-sources/m7-fex-normalized-patches-20261015-01`. Success writes `large-file.patch`219B, `meson.patch`620B, `raw-large-file.patch`1193B, `normalizer-large-file.patch`290B and `manifest.json`; files0444, directory0555. The manifest retains the exact selection map and prior failed outcome. Refuse overwrite and preserve partials on failure. The supplement retains the original1193-byte author/context response and290-byte intermediate alongside both canonical outputs; total patch/context text2322B. Raw HTTP status/error streams, package and tools remain excluded. Public/source-custody scope contains no package binaries.

The accepted Koko/Tailscale-derived custody lifecycle and its process identity, original-wait, cleanup and write-accounting helpers are reused. Only exact bindings, the small two-file operation, scope checks and resources change. Bounds:1MiB destination,32MiB owner with16MiB supervisor reserve and1MiB failure receipt,64MiB retention,1MiB per file,8 output files/2 directories,16MiB named reads,20s soft/30s supervised/45s+15s outer, two CPUs and1GiB address space. The collector starts no child and makes no network request. Its success consumer independently rechecks both source slices, exact output hashes, membership, modes, all original success channels and process absence before ordinary consumption.

Root's separate commands after source review:

```bash
TASK_PACKET=/tmp/pix-m7-fex-patch-byte-custody-20261015
bash "$TASK_PACKET/commands.sh" prepare
bash "$TASK_PACKET/commands.sh" preflight
bash "$TASK_PACKET/commands.sh" report
# Inspect actual preparation/preflight/retention before admission.
bash "$TASK_PACKET/commands.sh" admit
bash "$TASK_PACKET/commands.sh" launch
# Review original completion and independently checked custody before success consumption.
bash "$TASK_PACKET/commands.sh" consume
```

Static source/AST and byte readback only are recorded in `static-review.json`; no preparer, collector, tests or runtime ran during preparation. Source integration, applicable notices, independent retrieval/offhost proof and publication remain separate. Existing failure owner and all other source custody stay unchanged.

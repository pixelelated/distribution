# Minimal ZeroTier refresh — source-only proposal

No runtime, preparer, allocation, cache move/copy, admission, build, measurement, test, network operation, or shared-record edit was performed. This packet contains a plan and finite existing-source/receipt locators; it is not an executable admission packet. `inputs.json` names the exact current roots and observed target filenames.

Use five same-filesystem cache renames into three fresh frozen `build/*` worktrees, then build only `zerotier-one` explicitly before the existing canonical image targets. Reuse the shared source cache and the existing SM8550 Nix store in place. Do not clone the build caches, copy the Nix store, or repeat the previous 8/12-package clean lists.

## Source dependency

Wait for root's current unpack/custody proof and the reviewed ZeroTier change to be committed, integrated and published on `next`. Bind the actual resulting 40-character commit and the SHA256 of BOTH `projects/ROCKNIX/packages/network/zerotier-one/package.mk` and `patches/001-client-without-nonfree-headers.patch`. The observed coordinator HEAD was 2426f88aba0eaa51e448c42917ca80fde2972a16; the ZeroTier edits were still uncommitted. No future commit is guessed.

Compare product roots (`packages projects config scripts distributions Makefile`) from each cache's exact old commit to the final commit. Expected change versus f8636de1d105275dbf9420bbabbbc26f79abb10f: the two ZeroTier paths and the already accepted `projects/ROCKNIX/packages/tools/rocknix-abl/package.mk` checksum correction. Versus SM8550's 9aa7affee9d4ad5e69725cab20b6d7ad84d93dea: only the two ZeroTier paths. ABL is not selected for GENERIC_X64/H700. Retain ES pin16dbac5211eea7e70db7394372033be2be7df829 and all other reviewed product sources. Review/reseal any additional product delta.

## Exact cache succession

All paths below start `/workspace/repos/rocknix.worktrees/`. Destinations were absent during this source inspection, not reserved.

| Device | Existing frozen source | Proposed new frozen source | Cache roots to transfer | Stable container checkout |
|---|---|---|---|---|
| GENERIC_X64 | m7-p5-build-20261015-02 @ f8636de1d105 | m7-p5-build-20261015-03 | build.pixelelated-GENERIC_X64.x86_64 | m7-pixelelated |
| H700 | m7-pixelelated-h700-04 @ f8636de1d105 | m7-pixelelated-h700-05 | build.pixelelated-H700.arm and .aarch64 | m7-pixelelated-h700-01 |
| SM8550 | m7-pixelelated-sm8550-05 @ 9aa7affee9d4 | m7-pixelelated-sm8550-06 | build.pixelelated-SM8550.arm and .aarch64 | m7-pixelelated-sm8550-01 |

Use the corresponding branch names in `inputs.json`. Preserve the old checkout's tracked source, original watcher/owner receipts and target outputs. Do not mutate its commit. A transfer deliberately changes custody of its stopped cache; old cache paths cease to be runnable.

The existing adapter is `/tmp/pix-m7-next-image-delta-20261015-02/transfer-cache.py` (SHA2560b454196e1b435063dd1f6ea4a292da61c911763536719d49e613ba78c15f2f9). Its actual successful predecessor transfer is `/workspace/tmp/pix-m7-next-cache-transfer-20261015-02/transfer-result.json`, watched run20261015T035306Z-b0f999e1, with all-zero originals and unchanged device/inode. This already establishes the no-copy method.

Prepare a narrow derivative of that adapter and its existing plan/dependency helpers, not a new transfer framework. Rebind old/new trees, branches, source commits, exact product allowlist/hashes, per-root identity and stable container prefix. Preserve `renameat2(RENAME_NOREPLACE)`, same-filesystem check, no fallback copy/overwrite/symlink/rollback, before/after inode+device, fsync and originals. Each of the five roots is a separate atomic operation; the two-root device pair is not one filesystem transaction. Record and consume each completed transfer. After a partial failure, resume only the untransferred root under a new owner; never rerun a completed move. Do not start a profile build until all its required root transfers are consumed.

The adapter's old `original.status == PASS` / `consumed.disposition == qualified` guard CANNOT be reused unchanged: the current GENERIC producer had the #597 reporting collision and H700/SM8550 combined producers failed after their canonical make stage. Bind those immutable failure dispositions, verified completed package/image stages, consumed cleanup, and the separately accepted artifact results listed below. Do not relabel the old producers or synthesize a success receipt.

Immediately before each transfer, root resolves current and prepared consumers, including the ZeroTier source proof's compiler/toolchain references into the GENERIC cache. Reuse the existing actual-host dependency readback and assessment: exact root identity, host namespace, original observation age≤900s, no unexplained processes, active admissions or overlapping Docker mounts, prepared consumers explicitly resolved/rebound. This planning read did not inspect process state or assert that any cache is idle.

SM8550's existing Nix store is `/workspace/tmp/pix-m7-sm8550-refresh-20261015-02/nix`. Retain it explicitly for the immediately queued SM8550 image job and use that exact path for the existing `/nix` mount under exclusive ownership. This avoids a second store. If the existing owner implementation insists on a new private path, make that a separately bound same-filesystem rename after consumer closure, never a copy. No FEX/Nix compile or dependency rewrite is proposed.

## Minimal canonical stages

ZeroTier exists in the GENERIC x86_64 and both device AArch64 package caches. Neither existing ARM compatibility cache has a ZeroTier package tree/stamp/install. Both ARM roots remain immediate dependencies because `compat/lib32` installs from the ARM image tree and the canonical H700/SM8550 targets run ARM then AArch64.

Within the existing fresh watched/admitted owner, run the following stages for each profile, with its exact final source commit, stable `DOCKER_WORK_DIR`, current preflight and original resource/container lifecycle:

```bash
# Choose GENERIC_X64/x86_64, H700/aarch64, or SM8550/aarch64.
PROJECT=ROCKNIX DEVICE="$TASK_DEVICE" ARCH="$TASK_ARCH" PACKAGE=zerotier-one make docker-package-clean
PROJECT=ROCKNIX DEVICE="$TASK_DEVICE" ARCH="$TASK_ARCH" PACKAGE=zerotier-one make docker-package
# The existing owner unlinks only the NEW tree's matching .stamps/image/build_target.
# Then choose its canonical target, with the existing container-ready/checkdeps wrapper:
make docker-GENERIC_X64
make docker-H700
make docker-SM8550
```

The last three lines are alternatives, one per profile, not three commands in one tree. H700/SM8550 keep the existing `COMMAND=bash <new-owner>/inside-build.sh` wrapper whose actual inner command is `make H700` / `make SM8550`. Rebind that wrapper and its finite source checks. No DIRTY, image-stamp forgery, install-only bypass, copied ELF, or explicit unrelated clean. Standard non-DIRTY build_distro housekeeping and cache invalidation remain in force.

Reuse the original pinned builder988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39, actual nonroot UID/GID, shared sources, real main `.git` mount and stable container checkout paths. Keep `TMPDIR=/tmp`, a new per-profile BUILD_TIMESTAMP and development qualifier. Retain existing CID/nonce, limits, actual original exit channels, watchdog cleanup and result-consumption machinery; the old build owners and consumed admissions are not executable again. A new source-only derivative needs to replace the old clean arrays with only ZeroTier, not add ZeroTier to them.

## Concrete owner sequence

1. Bind the actual final published commit and reviewed two file hashes. Verify its exact device product deltas. Allocate the three named fresh `build/*` worktrees only at execution time.
2. Derive/review/reseal the existing transfer/dependency/plan sources with the identities above. Make fresh transfer owners per root and fresh build/readback owners per profile; suggested build owner paths are in `inputs.json`.
3. Use the established sequence: `tools/build-preflight`; existing watched retention report; actual-host dependency readback/assessment; `python3 -I tools/host-maintenance/build-admission prepare --plan <fresh-plan> --output <fresh-admission>`; `tools/watch-build-submit --owner <fresh-owner> -- --admission <fresh-admission> --activity-dir <fresh-owner> -- python3 -I <derived-transfer.py> ...`; review exact original channels and consume the run. Derivative paths/options must be supplied by the sealed packet; the old hardcoded adapter is not directly runnable for these roots.
4. Use the existing `prepare-owner.py` / `prepare-plan.py` lifecycle rebound to the new source/owners, consumed cache-ready records, actual timestamp and scoped stages. Fresh preflight/admission precedes the new watched build. Preserve failures as failures.
5. First refresh/read back GENERIC and do the existing affected VM clean/retained upgrade checks. Then refresh/read back the two device artifacts under their existing qualification policy. Do not run simultaneous heavy families merely because three profiles are listed.

This is ready for preparation of those narrow derivatives once the commit exists; it does not claim that the new owner packets or fresh admissions already exist.

## Accepted predecessors and next readback

GENERIC: `/workspace/tmp/pix-m7-image-readback-20261015-02/artifacts/result.json` is the independently accepted f863 result after the producer's reporting failure. SYSTEM SHA2562c69f6533629244edef4ec2405bfaaf438f507451733ae955be7eefe7ffeb1cf; KERNEL SHA2560d7e3f11b4012645c5e39d81b61bf4acc800750cc57ffaee3e23206166f56089. Prior runtime results retain their exact historical source/image scope.

H700: `docs/qa-logs/2026-10-15-device-refresh/h70004/` binds independent acceptance20261015T064734Z-8868082e, consumed4ebc249f9b7d4e9a8c61cff36cc23fea, acceptancee8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db and bundle32f7a6523dfae61b5142cf803876bf4e09f9a21a3a6784a69ca74b9d9b587833. Both DDR3/DDR4 and update payloads were accepted. Earlier combined/selected-state failures remain unchanged.

SM8550: `docs/qa-logs/2026-10-15-sm8550-abl-format/accepted/outcomes.json` binds source9aa7, independent reader20261015T092225Z-e7702372 and acceptance20261015T092333Z-2bc44656, consumed40d2d16b1a4a42e0864bf5bf881a242f, acceptanceb576f190e56c01ed534bbec593dc669c5fc034317a69ccb68af14cb568787dd0 and bundle09addac6d353e2a30e06610d87fa46b72a4bdfa82c711fd77a658b9e7f1d3ca0. Its combined producer remains1/0/1, launcher1. The accepted five ABL payloads are not a reason to rebuild ABL again.

Rebind the accepted readers to actual new source, outputs and independent extraction. Add the changed ZeroTier package/install/SYSTEM mapping and provenance: filtered unpack excludes nonfree, exact reviewed patch, actual architecture/source dependencies and generated installed binary. Keep raw/update SYSTEM+KERNEL equality, identities, bootloader and ARM handoff checks already in the device readers. Do not require new ELF bytes to equal the isolated x86 compile; its accepted dd84354a artifact is a separate proof, not a prebuilt package input. Do not make prior unchanged runtime matrices run again solely because the image identifier changed. Root selects the already required affected VM clean/retained-storage checks; no provider account/network join, physical action or new acceptance matrix is added here. Hardware boot, RC/publication and source-delivery/off-host retrieval gates remain separate.

## Retention and capacity

The last actual GENERIC final_after_producer measurement recorded125,726,416,896B cache,68,286,742,528B shared sources and4,245,315,584B target. Historical device predecessor measurements recorded H700 ARM26,834,862,080B + AArch64111,496,507,392B; SM8550 ARM19,319,939,072B + AArch64147,234,422,784B + Nix2,680,090,624B. These are original observations, not current measurements or new space claims. No du scan was run. Reuse existing measurement/report paths subject to their age/material-change rules; the old500/600GiB copy reservations are not a forecast for a rename.

Reserve normal warm-build growth/readback scratch through current admission, not duplicate-cache bytes or speculative deletion credit. Retain only each cache's next named package/image consumer, the current source-proof dependency until consumed, and the baseline/new firmware actually needed for immediate clean/upgrade/artifact checks. Preserve compact sources/manifests/licence/receipts. After those dependencies close, use the existing retention workflow to retire superseded large payloads; historical provenance alone is not a retention reason (D-INFRA-022). This packet does not delete or authorize deletion of any existing payload.

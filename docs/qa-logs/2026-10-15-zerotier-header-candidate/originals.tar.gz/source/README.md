# ZeroTier1.16.0: candidate isolation of nonfree header inputs

A small source change can make the ordinary `one` translation unit independent
of the three named nonfree headers. Guarding only the includes is insufficient:
`OneService.cpp` also declares, initializes and deletes their pointer types
unconditionally. `candidate.patch` guards that complete lifetime with existing
feature macros. It is an **uncompiled proposal**, confined to this private packet;
no product recipe, pin, original source or accepted artifact changed.

The patch is against selected OneService.cpp SHA256
`f7bf80806777e802f23164b086021aa6fae638ce198eeeda3eef07159e4de552`.
Candidate SHA256 is
`b546cf4e77dc15175cca16c4143b5f615808e5d30a0ceafdf802881425b812e8`;
patch SHA256 is
`5fe6dcc77910a0faf40fa2e9bcb09e918632d0ed2880fd7b30efdeb335c34ad5`.
The frozen package selects ZeroTier1.16.0 archive
`aa9de313d365bf0efb3871aaa56f2d323a08f46df47b627c4eff4f4203fa7fc5`.
Original source/notice provenance is retained in `source-references.json` and
`prior-references.json`.

## Existing route and candidate

The exact recipe calls `make -f make-linux.mk ZT_SSO_SUPPORTED=0 one`.
`make-linux.mk:20–27` sets `ZT_NONFREE=1` from `ZT_CONTROLLER=1`, and only then
includes the seven `objects-nonfree.mk` controller objects and defines
`ZT_NONFREE_CONTROLLER`. The controller mode also defines
`ZT_CONTROLLER_USE_LIBPQ` at349–353. The ordinary recipe enables neither mode;
`official` and `central-controller` are separate targets. `Makefile` dispatches
Linux to the same makefile, and the install target copies the built agent.

Original OneService.cpp includes the nonfree headers at126–128. The pointer
fields are at827/929, constructor initializers at946/979 and deletions at1036/1037.
Controller construction/registration and remote trace handling are already under
`ZT_NONFREE_CONTROLLER`; Redis configuration population is already under
`ZT_CONTROLLER_USE_LIBPQ`. The candidate extends those existing boundaries:

| Material | Candidate condition |
| --- | --- |
| EmbeddedNetworkController.hpp, `_controller` field/initialization/deletion | `#ifdef ZT_NONFREE_CONTROLLER` |
| PostgreSQL.hpp | `#ifdef ZT_CONTROLLER_USE_LIBPQ` |
| Redis.hpp, `_rc` field/initialization/deletion | either existing macro is defined |
| Existing construction, configuration and controller calls | existing guards and statements unchanged |

The OR condition keeps `_rc` available for the ordinary nonfree controller's
constructor even when the PostgreSQL mode is off, and preserves the independently
defined PostgreSQL branch without inventing a macro dependency. This follows the
existing code's `#ifdef` semantics, not a new numeric0/1 interpretation.
Three standard includes (`memory`, `set`, `sstream`) explicitly supply standard
types used directly by this translation unit, avoiding reliance on transitive
includes after removing the nonfree header route. Controller path/SSO preference
strings and ordinary client behavior are otherwise untouched. No forward
nonfree declaration or delete-through-incomplete-type workaround is introduced.

| Macro definitions | Named header inputs after the candidate |
| --- | --- |
| Neither | none of the three |
| NONFREE_CONTROLLER only | EmbeddedNetworkController + Redis |
| CONTROLLER_USE_LIBPQ only | PostgreSQL + Redis |
| Both | all three |

Textual directive-stack readback places all21 named include/type/pointer
occurrences under an appropriate feature condition. Eight unique replacement
sites account for the entire patch; inverse replacement restores all original
bytes. This is source inspection, not preprocessing, C++ compilation, a runtime
result or proof of the whole build's dependency graph.

## Upstream check, 2026-10-15

Seven bounded primary GitHub text/metadata reads total374,146 bytes, all HTTP200;
no archives, auth, redirects or retries. The first six reads found the exact
relevant commit; one final adaptive read inspected its patch. Original response
bodies and request identities are retained under `public-text/`.

- Latest published stable was [1.16.2](https://github.com/zerotier/ZeroTierOne/releases/tag/1.16.2),
  dated2026-05-28. Its retained OneService.cpp still has the three unconditional
  includes, fields, initializers and deletions. A version bump alone therefore
  does not solve this specific header-input question.
- Recent upstream [8ae153b44c1cd773f219355357a26b13a6eba010](https://github.com/zerotier/ZeroTierOne/commit/8ae153b44c1cd773f219355357a26b13a6eba010),
  2026-06-15, says it fixes a ZT_NONFREE issue. The exact service-file diff adds
  only `#ifdef ZT_NONFREE_CONTROLLER` around `delete _controller`. That partial
  fix is absent in selected1.16.0 and present in this candidate.
- Current service file at [4bcff9d3e348f9715326fa6a840110cbe5a08d6c](https://github.com/zerotier/ZeroTierOne/blob/4bcff9d3e348f9715326fa6a840110cbe5a08d6c/service/OneService.cpp)
  includes that destructor guard but retains unconditional nonfree headers,
  fields/initializers and `_rc` deletion. It has additional later central-controller
  code; this candidate targets selected1.16.0, not an unreviewed apply to current.
- Bounded issue search `repo:zerotier/ZeroTierOne nonfree header` returned two
  results: #2615 concerns Java licence headers, and #2613 README edits. Neither
  supplies the C++ header isolation fix. A separate PR search for
  `ZT_NONFREE_CONTROLLER` returned zero results. These limited queries do not
  establish that no other report exists.
- Local ROCKNIX `upstream/next` package history shows1.16.0 selection and packaging
  changes, and the selected package tree has no patch directory. No matching
  distribution-side fix was found in those named records. ZeroTier is the
  component upstream for a reusable complete header-isolation patch; downstream
  ROCKNIX propagation would be separate. No report or PR was sent.

## Source-delivery choice

Keep the exact originalaa9d archive and all historical evidence immutable in
held custody. If root adopts and qualifies the candidate, create a **separately
identified source deliverable** from the selected version, omitting only the
`ZeroTierOne-1.16.0/nonfree/` subtree and applying this MPL service-file patch.
Retain MPL source, ext source/notices, ordinary build files and the patch. Record
original archive hash, every included member hash, exact omitted-member list,
patch hash and new deliverable hash, explicitly marked as a modified selection.
Never rewrite the old archive's hash or describe the filtered archive as the
original upstream tarball. No filtered archive or predicted receipt is created
here. A map slot may remain pending until actual generation and readback.

The filtered delivery is not a declaration that all remaining dependencies are
MPL; ext/ retains its own already-assessed terms. Build instructions should name
the qualified ordinary `one` target and the local filtered root, not require
fetching omitted nonfree material. `objects-nonfree.mk` can remain as an optional
unselected build-list file; its inclusion is conditional. Do not silently strip
selected ext material or otherwise broaden this filter.

The source-bundle selection must also avoid accidentally adding whole upstream
archives or copied nonfree headers from diagnostic custody. This private review
packet contains original nonfree header copies solely to bind the diagnosis;
they are **not proposed public filtered-source members**. Earlier selected
header copies are also retained in
`docs/qa-logs/2026-10-15-remaining-notice-disposition/originals.tar.gz`.
Root must distinguish review custody from the chosen public source delivery;
no historical evidence is removed or relabelled by this task.

## Minimum proof after root chooses this option

1. In a fresh isolated source/build owner, apply this patch to exact selected
   source. Prepare a filtered working input with nonfree/ absent from the start;
   do not delete or alter the original held archive or any live source tree.
2. Run the existing ordinary package build with its actual flags, unchanged
   `ZT_SSO_SUPPORTED=0 one` route and both controller modes unset. Retain original
   compiler/link statuses and dependency manifests. A successful build from an
   input that lacks nonfree/ proves the three unavailable headers were not
   consumed; no stripped-symbol absence argument is needed. Check the installed
   agent's normal dependency/artifact identity via the existing reader.
3. Preserve enabled-feature behavior when evaluating the patch for upstream;
   the source matrix above describes the intended branches but is not their
   compiled proof. Root can allocate a focused branch check separately if needed.
4. If integrated, existing changed-artifact qualification/rebuild policy applies.
   Current accepted images are unchanged and cannot be relabelled as built from
   this proposal. No full runtime matrix, network/controller service, physical
   device action or provider test is allocated by this packet.

This is an actionable source-isolation option. It does not reinterpret the
nonfree licence, grant licence clearance or decide whether current public source
publication is already covered. It avoids needing the named nonfree inputs in
the intended future client build only after the focused build proof succeeds.

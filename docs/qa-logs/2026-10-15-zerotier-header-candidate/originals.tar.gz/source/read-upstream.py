#!/usr/bin/env python3
"""Bounded public source metadata reads only; never executes downloaded content."""
from pathlib import Path
import datetime,hashlib,json,signal,time,urllib.error,urllib.parse,urllib.request
ROOT=Path(__file__).parent/'public-text'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
OPENER=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
RECORDS=[];TOTAL=0

def read(label,url):
 global TOTAL
 assert len(RECORDS)<6 and TOTAL<2097152
 limit=min(524288,2097152-TOTAL);number=len(RECORDS)+1
 rec=dict(number=number,label=label,url=url,request_limit=6,response_limit=limit,aggregate_limit=2097152,timeout_seconds=15,redirects=False,retries=False,authentication=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 b=b'';status=None;error=None;t=time.monotonic()
 def expired(*args):raise TimeoutError('15-second request bound')
 signal.signal(signal.SIGALRM,expired);signal.setitimer(signal.ITIMER_REAL,15)
 try:
  try:resp=OPENER.open(urllib.request.Request(url,headers={'User-Agent':'pixelelated-source-review/1.0','Accept':'application/vnd.github+json,text/plain'}),timeout=15)
  except urllib.error.HTTPError as e:resp=e
  with resp:
   status=resp.status;b=resp.read(limit+1);assert len(b)<=limit,'response cap'
 except Exception as e:error=type(e).__name__+': '+str(e)
 finally:signal.setitimer(signal.ITIMER_REAL,0)
 TOTAL+=len(b);rec.update(status=status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),error=error,elapsed_seconds=time.monotonic()-t)
 file=ROOT/f'{number:02d}-{label}.body';file.write_bytes(b);rec['retained']=file.name
 (ROOT/f'{number:02d}-{label}.request.json').write_text(json.dumps(rec,indent=2)+'\n');RECORDS.append(rec)
 print(json.dumps(rec),flush=True)
 if status==200 and error is None:
  try:return json.loads(b)
  except json.JSONDecodeError:return b
 return None

release=read('latest-release','https://api.github.com/repos/zerotier/ZeroTierOne/releases/latest')
commits=read('service-commits','https://api.github.com/repos/zerotier/ZeroTierOne/commits?path=service%2FOneService.cpp&per_page=3')
issues=read('header-issues','https://api.github.com/search/issues?q='+urllib.parse.quote('repo:zerotier/ZeroTierOne nonfree header')+'&per_page=5')
if isinstance(commits,list) and commits:
 commit=commits[0]['sha'];assert len(commit)==40 and all(c in '0123456789abcdef' for c in commit)
 read('current-service','https://raw.githubusercontent.com/zerotier/ZeroTierOne/'+commit+'/service/OneService.cpp')
prs=read('macro-prs','https://api.github.com/search/issues?q='+urllib.parse.quote('repo:zerotier/ZeroTierOne is:pr ZT_NONFREE_CONTROLLER')+'&per_page=5')
if isinstance(release,dict) and isinstance(release.get('tag_name'),str):
 tag=release['tag_name'];assert len(tag)<=50 and all(c in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-' for c in tag)
 read('stable-service','https://raw.githubusercontent.com/zerotier/ZeroTierOne/'+tag+'/service/OneService.cpp')
(ROOT/'requests.json').write_text(json.dumps(dict(requests=RECORDS,total_bytes=TOTAL,downloaded_content_executed=False),indent=2)+'\n')

# #528 source-custody refresh plan — f8636de1

SOURCE ONLY. No inventory collector, cache traversal, build, container, VM,
download, archive-custody job, transfer or publication ran. This packet prepares
the existing #528 work while root owns #555. Final H700/SM8550 products and
their original acceptance/input manifests are not predicted here.

The two historical inventory source commits are
`7f58b7b1c592908dcd0ba5987955e59aaa79fe66` and
`8b5113fa164ada7d002ab138b1e3a9bf795e9de5`. Both differ from frozen
`f8636de1d105275dbf9420bbabbbc26f79abb10f` in the same 73 product paths under
the recorded scope. `product-delta.json` records each old/current Git blob,
mode, SHA256 and raw symlink target. `source-f863/` retains current selected
source bytes; a symlink there is represented by its raw Git blob bytes and
the original mode in the manifest, not a followed copy. The complete current
distribution snapshot still belongs in the later custody collection.

Exactly four changed PKG_VERSION declarations occur in that delta: ES
1d76b3da→16dbac52, rclone 1.75.1→1.75.2, ABL 1.1.9→1.2, and RAOfflineProxy
879b1589→c7ebd1b6. Dolphin's 6094cfc pin is unchanged; its local patch 018,
Sys installation, profiles and launcher/helper changes require current
distribution custody. FEX's e869aa64 pin is unchanged but its nixpkgs input
is now b6018f87. Linux remains 7.2 for H700/SM8550 and 7.1.2 for GENERIC_X64,
with the new shared 7.2 patch retained. Doom now names the immutable 4cb65b68
URL and the same retained ff35cde0 archive. Steam's launcher archive pin is
unchanged; its optional player downloads still use the dynamic endpoints
shown in the source. No new runtime/Proton version pin was found.

`component-source-delta.json` maps ten affected input families to existing
members or exact additive members. It also inventories all 135 tracked files
in Dolphin, RAOfflineProxy and the two coupled source-package directories.
`historical-member-projection.json` is a selected projection of the original
2,327-row map, whose original path/hash is retained. Historical source members
can be reused only by exact content/commit identity; historical profile
membership and the old 2,327 count cannot be promoted to current results.

`notice-provenance-worklist.json` carries the 17 existing corrected notice
rows and the separately recorded Doom-data disposition. It retains exact
notice locators/hashes, source pins and missing output/member maps. The
five aggregate gaps remain common/GLSL/RetroPie/slang shaders and ABL.
GLSL's nnedi3 and crt-royale notices are scoped separately. rclone 1.75.1
source, modified-binary evidence and module counts remain historical;
1.75.2 needs its own source and actual binary/module metadata. ABL's current
implementation reference is LinuxLoader e9d37131; the prior 45887331 lookup
failure is not a new lookup result. Doom fetch/checksum/installation proof
remains accepted, while the WAD redistribution hold remains open.

The existing collectors have specific rebinding needs. `collector-changes.diff`
contains only (1) current rclone version-derived binary path, (2) Doom's
current normal cached source name/checksum and unchanged staged/installed-byte
assertion, and (3) the already accepted warning that absence of an image
install stamp does not exclude static or vendored shipped work. The source
inventory is the exact attempt04 helper (byte-identical to attempt03), and
the component mapper is the accepted attempt05 helper. All other classification
and missing-input failures remain. Both derivatives are UNRUN; AST validation
does not qualify them against current caches.

`invocation-plan.md` names the exact interfaces, five-profile bindings,
remaining collector rebinding points, original result channels and retention
limits. It deliberately does not provide a fabricated completed owner or
manifest. In particular, today's VM producer has `build-inputs.json` rather
than the old `inputs.json` schema, and its artifact verifier binds outputs
directly rather than the old bundle-equals-inputs shape. Its #597 launcher
reporting failure remains nonqualified with null original launcher returncode.
Artifact integrity is independently accepted; an inventory must preserve both
facts instead of inventing a launcher zero or an old-schema manifest.

This fulfills source preparation for checklist items 1–2 only. It does not
close #528, reopen the completed audit, authorize another build, change any
component or remove a publication hold. D-WORKFLOW-121 requires inventory
and fork-owned corresponding-source custody; D-INFRA-022 limits large
retention to named consumers. D-WORKFLOW-107/125 govern the later storage/
restore decisions. Local copies and public repository visibility are not
independent retrieval or off-host backup. No legal-clearance conclusion,
RC designation or publication authority is asserted.

Source-worker static review passed; exact original tool exits and the retained
static stdout/stderr are recorded in `execution-observation.json`. Independent
peer review has not completed. Root requested this sealed source-preparation
handoff without delaying the active H700 review; root review remains pending.

# Publication holds: work ready during device builds

Read-only review at coordinator9ad2f966fe. Live #528 was last updated2026-10-12;
#344 readback is2026-10-15T05:52:19Z and includes the newly published audit-to-device
handoff. All five #528 criteria and six #344 publication/security/asset criteria
remain open. This review creates no new gate and reopens no audit.

1. **Prepare the current component/source delta and rebind #528's inventory plan.**
   Existing inputs: `docs/qa-logs/2026-10-08-final-inventory/profiles/*/{binding,components,source-inventory,publication-worklist}.json`,
   `docs/qa-logs/2026-10-08-source-custody/git-complete/component-member-index.json`
   (2,327 historical profile rows/701 distinct names), and retained
   `attempt-03/{source-inventory,component-map}.py` plus
   `git-complete/build-member-index.py`. Ready now: a source-only f863 delta table
   mapping each changed pin/patch/recipe to existing custody or an exact missing
   source member, and an additive invocation/binding plan for these existing
   collectors. Concrete rebinding points include ES16dbac, Dolphin6094cfc plus
   local patches, rclone1.75.2, ABL1.2 and FEX's nixpkgsb6018f87. ABL's current
   LinuxLoader reference is e9d37131, not the older45887331 in #528. Missing final
   artifacts: the five current-profile reports and component-to-source map bound
   to each new immutable bundle/input-manifest hash. Those final byte bindings
   wait for #555 outputs; do not read changing caches or relabel the old reports.

2. **Complete bounded notice/provenance disposition worksheets from retained evidence.**
   Start from `2026-10-11-component-inputs/dispositions.json` and
   `2026-10-09-notice-scope/licence-basis-corrected.json`, not the superseded
   October8 aggregate label. Existing holds name common/GLSL/RetroPie/slang
   shaders and ABL; GLSL's `nnedi3/LICENSE` cannot cover the collection. Concrete
   missing rows are exact included-file/subdirectory notice and output-use maps;
   FreeJ2ME's named bundled libraries, OpenBOR's distinct notices, WildMIDI's
   library/player outputs and ZeroTier's actual nonfree build selection already
   have explicit starting points. Preserve the pinned Doom WAD redistribution
   disposition, prebuilt provenance and embedded dependencies. The dedicated
   `rclone-1.75.2-binding.json` explicitly still lacks current corresponding
   source/dependency notices; older1.75.1 custody does not fill it. ABL1.2 needs
   exact implementation-source/access and notice evidence; public packaging and
   release notes are insufficient. Ready work is exact evidence mapping and
   documenting unresolved rows, not declaring legal clearance or silently
   removing/changing components while the source is frozen.

3. **Reconcile release notes/support/adoption documentation now.**
   Existing bases: `docs/rasteratops/{release-readiness,support-matrix}.md`,
   `docs/releases/{device-facts,versioning}.md`, `docs/es-menu-map.md`, and
   `docs/pixelelated/cloud-folders.md`. The first two still present October7/11
   state as current, including obsolete #508/#510 blockers and pre-October12
   board adoption status. Ready deliverable: a draft current summary/support
   table with f863 VM evidence, accepted bc9 physical history, new device assets
   explicitly pending, and linked manual adoption/recovery, unchanged SSH
   password, trust assumption, lineage/non-endorsement, source links, selected
   cloud-path and same-model restore instructions. Keep historical evidence;
   don't label old board observations as f863 smoke. Actual current asset
   names/hashes and source URLs remain placeholders until their receipts exist.
   #511's broad website/QR work is separate. The existing placeholder/Pages
   receipts in `docs/qa-logs/2026-10-07-site-access/` record403/404 and HTTPS
   uncertainty; they are not a current successful deployment/retrieval receipt.

4. **Prepare exact retrieval/off-host custody instructions and evidence fields.**
   Existing local archives/Git/prebuilt custody and component-member maps are
   under `docs/qa-logs/2026-10-08-source-custody/`; these prove local historical
   custody only. Ready deliverable: a current required-member manifest delta,
   original-source-to-member mapping, and a bounded independent retrieval/hash
   readback plan using the same explicit hashes. Missing acceptance artifacts
   are actual independent retrieval results and off-host backup custody for
   the final bundle. D-WORKFLOW-107 already names intended B2 subject to the
   owner's Vultr comparison (#347); do not invent a storage decision or count
   another local directory as backup. No transfer, account or storage mutation
   is part of this parallel preparation.

5. **Prepare the sanitized security/custody readback checklist.**
   #344 explicitly requires repository permission/expiry inventory, an
   expiry-notice mechanism, and remote-runner trusted-trigger/isolation evidence
   or a disabled-runner fallback. Ready deliverable: enumerate the exact
   repository/workflow principals, required non-secret fields and original
   readback locations; distinguish local workflow source from remote settings.
   Missing artifacts are those actual control-plane/expiry-notice receipts.
   Local absence, a403 or a token rename does not prove them. No credential
   values, token changes, notifications or runner operations are needed to
   prepare this checklist.

## Boundaries for the handoff

- `tools/fork-publish-release` is prepare-only, but it also reads actual firmware
  through the selected-state checker and accepts only RC/release identities.
  The current dev artifacts cannot be renamed into an accepted public plan.
  No reason to invoke it during this document/source-only work; #265 owns the
  remaining publication transaction and explicit authority.
- Final profile inventory, artifact sizes/hashes/sweeps and boot-chain acceptance
  need the completed #555 products. Physical smoke, attachment, RC allocation,
  release reassembly/requalification, off-host transfer and named publication
  authority remain their existing later gates.
- The best immediate assignments are items1–3. Items4–5 can produce concrete
  plans now; their missing external acceptance receipts cannot be inferred from
  this local review. No broad audit, full-suite replay, rebuild or cleanup is
  proposed.

`readback-index.json` binds the two issue responses and14 existing source/doc
identities. No shared file, completed audit, product, cache or tracker was changed.

#!/usr/bin/env python3
"""Build this source-only record packet from tracked Git and named saved receipts.

No build/cache roots, source archives, firmware, network or collectors are read.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil
import subprocess

P = Path(__file__).resolve().parent
R = Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
C = 'f8636de1d105275dbf9420bbabbbc26f79abb10f'
OLD = ['7f58b7b1c592908dcd0ba5987955e59aaa79fe66', '8b5113fa164ada7d002ab138b1e3a9bf795e9de5']
SCOPE = ['packages', 'projects', 'distributions', 'scripts', 'config', 'Makefile']
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', '-C', str(R), *args])
def put(name, value):
    out = P/name
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def blob(commit, path):
    row = git('ls-tree', commit, '--', path).decode().strip()
    if not row: return None
    meta, name = row.split('\t')
    mode, kind, oid = meta.split()
    assert kind == 'blob' and name == path
    raw = git('cat-file', 'blob', oid)
    return {'git_mode': mode, 'git_blob': oid, 'sha256': sha(raw), 'bytes': len(raw), 'raw_symlink': raw.decode() if mode == '120000' else None}

refs = []
def retain(src, name):
    src = Path(src)
    dst = P/'references'/name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    refs.append({'original': str(src), 'member': str(dst.relative_to(P)), 'sha256': sha(src.read_bytes()), 'bytes': src.stat().st_size, 'mode': oct(src.stat().st_mode & 0o777)})

docs = {
    'issue-528.json': '/tmp/pix-m7-publication-holds-review-20261015/528.json',
    'publication-checklist.md': '/tmp/pix-m7-publication-holds-review-20261015/checklist.md',
    'dispositions.json': R/'docs/qa-logs/2026-10-11-component-inputs/dispositions.json',
    'licence-basis-corrected.json': R/'docs/qa-logs/2026-10-09-notice-scope/licence-basis-corrected.json',
    'shader-archive-review.json': R/'docs/qa-logs/2026-10-09-notice-scope/archive-review.json',
    'rclone-1.75.2-binding.json': R/'docs/qa-logs/2026-10-11-component-inputs/rclone-1.75.2-binding.json',
    'abl-release-notes.json': R/'docs/qa-logs/2026-10-12-upstream-review/abl-release-notes.json',
    'engineering-dispositions.md': R/'docs/qa-logs/2026-10-11-component-inputs/README.md',
    'historical-inventory.md': R/'docs/qa-logs/2026-10-08-final-inventory/README.md',
    'historical-custody.md': R/'docs/qa-logs/2026-10-08-source-custody/git-complete/README.md',
    'vm-build-inputs.json': '/workspace/tmp/pix-m7-engineering-build-20261015-02/build-inputs.json',
    'vm-artifact-inputs.json': '/workspace/tmp/pix-m7-image-readback-20261015-02/artifacts/inputs.json',
    'vm-artifact-result.json': '/workspace/tmp/pix-m7-image-readback-20261015-02/artifacts/result.json',
}
for n, src in docs.items(): retain(src, n)
collectors = {
    'source-inventory.py': 'docs/qa-logs/2026-10-08-final-inventory/attempt-04/source-inventory.py',
    'component-map.py': 'docs/qa-logs/2026-10-08-final-inventory/attempt-05/component-map.py',
    'inventory-run.py': 'docs/qa-logs/2026-10-08-final-inventory/attempt-02/run.py',
    'build-member-index.py': 'docs/qa-logs/2026-10-08-source-custody/git-complete/build-member-index.py',
    'archive-run.py': 'docs/qa-logs/2026-10-08-source-custody/source-archives-02/run.py',
    'git-run.py': 'docs/qa-logs/2026-10-08-source-custody/git-complete/run.py',
    'prebuilt-run.py': 'docs/qa-logs/2026-10-08-source-custody/git-complete/prebuilt-review/owner/run.py',
    'collect-licence-basis.py': 'docs/qa-logs/2026-10-08-source-custody/git-complete/collect-licence-basis.py',
}
for n, src in collectors.items(): retain(R/src, 'collectors/'+n)

memberpath = R/'docs/qa-logs/2026-10-08-source-custody/git-complete/component-member-index.json'
historical = json.loads(memberpath.read_text())
recipes = {r['component']: r['recipe'] for r in historical['components']}
profiles = []
base = R/'docs/qa-logs/2026-10-08-final-inventory/profiles'
for p in sorted(base.iterdir()):
    b = json.loads((p/'binding.json').read_text())
    w = json.loads((p/'publication-worklist.json').read_text())
    assert b['name'] == p.name
    profiles.append({**b, 'distribution_commit': w['distribution_commit'], 'publication_worklist_sha256': sha((p/'publication-worklist.json').read_bytes())})
put('historical-profiles.json', profiles)

paths = sorted(set().union(*(set(git('diff', '--name-only', o, C, '--', *SCOPE).decode().splitlines()) for o in OLD)))
assert len(paths) == 73
delta = []
pinchanges = []
for path in paths:
    cur = blob(C, path)
    olds = {o: blob(o, path) for o in OLD}
    component = next((n for n, recipe in sorted(recipes.items(), key=lambda x: -len(x[1])) if path.startswith(str(Path(recipe).parent)+'/')), None)
    delta.append({'path': path, 'component_from_historical_recipe': component, 'current': cur, 'historical': olds})
    if cur:
        dst = P/'source-f863'/path
        dst.parent.mkdir(parents=True, exist_ok=True)
        # Symlink targets are retained as Git blob bytes; never followed.
        dst.write_bytes(git('show', C+':'+path))
    if path.endswith('/package.mk'):
        def declarations(commit):
            if not blob(commit, path): return []
            return re.findall(r'^\s*PKG_VERSION=[^\n]+', git('show', commit+':'+path).decode(), re.M)
        before = {o: declarations(o) for o in OLD}
        after = declarations(C)
        if any(v != after for v in before.values()): pinchanges.append({'path': path, 'before': before, 'after': after})
assert len(pinchanges) == 4
put('product-delta.json', {'source': C, 'historical_sources': OLD, 'scope': SCOPE, 'path_count': len(paths), 'changed_version_declarations': pinchanges, 'paths': delta})
(P/'product-delta.diff').write_bytes(git('diff', '--binary', OLD[0], C, '--', *SCOPE))

selected = {'emulationstation','dolphin-sa','rclone','rocknix-abl','fex-emu','raofflineproxy','linux','idtech-lr','steam','gstreamer'}
selected.update(r['component'] for r in json.loads((P/'references/dispositions.json').read_text())['components'])
selected.update(r['component_from_historical_recipe'] for r in delta if r['component_from_historical_recipe'])
put('historical-member-projection.json', {'original': str(memberpath), 'sha256': sha(memberpath.read_bytes()), 'original_rows': len(historical['components']), 'custodies': historical['custodies'], 'scope': 'Selected existing rows only; historical records do not establish current profile membership.', 'components': [r for r in historical['components'] if r['component'] in selected]})

details = {}
for name in sorted(selected):
    path = recipes.get(name)
    if not path: continue
    data = git('show', C+':'+path)
    details[name] = {'recipe': path, **blob(C, path), 'declarations': [line for line in data.decode().splitlines() if line.startswith(('PKG_NAME=', 'PKG_VERSION=', 'PKG_SHA256=', 'PKG_SOURCE_NAME=', 'PKG_URL=', 'PKG_SITE='))]}
    dst = P/'source-f863'/path
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(data)
put('current-component-recipes.json', details)

# A narrow derivative of the accepted inventory, not a new collector.
original = (P/'references/collectors/source-inventory.py').read_text()
s = original.replace("custom = {'gamescope-glm',", "custom = {'idtech-lr', 'gamescope-glm',")
s = s.replace("    if record['cache']:\n", """    if name == 'idtech-lr':
        path, text = recipe(name)
        wanted = re.search(r'^PKG_SHA256=\"([0-9a-f]{64})\"$', text, re.M)[1]
        url = re.search(r'^PKG_URL=\"([^\"\\n]+)\"$', text, re.M)[1]
        assert wanted == 'ff35cde05801cfb27005229a6c55f20130ffa8f026ca27d7717c03152634e168'
        assert url == 'https://raw.githubusercontent.com/ROCKNIX/packages/4cb65b687c90f56856e9d6a55e51f56a09955699/doom.tar.gz'
        assert len(record['cache']) == 1 and record['cache'][0]['sha256'] == wanted
        installed = build / 'image/system/usr/share/idtech/doom.tar.gz'
        staged = build / 'install_pkg' / record['unpacked'] / 'usr/share/idtech/doom.tar.gz'
        assert sha(installed) == sha(staged) == wanted
        record['downloaded_asset'] = {'url': url, 'installed_path': str(installed), 'sha256': wanted, 'bytes': installed.stat().st_size, 'staged_bytes_match': True, 'disposition': 'Pinned fetched archive, same retained Doom bytes; game-data redistribution terms remain a publication hold'}
    if record['cache']:
""")
start = s.index("    elif name == 'idtech-lr':\n")
end = s.index("    elif name == 'rclone':\n", start)
s = s[:start] + s[end:]
s = s.replace("        rclone_arch =", "        path, text = recipe(name)\n        version = re.search(r'^PKG_VERSION=\"([^\"\\n]+)\"$', text, re.M)[1]\n        assert record['unpacked'] == 'rclone-' + version\n        rclone_arch =")
s = s.replace("('rclone-v1.75.1-linux-' + rclone_arch)", "('rclone-v' + version + '-linux-' + rclone_arch)")
(P/'collectors').mkdir(exist_ok=True)
(P/'collectors/source-inventory.py').write_text(s)

original_map = (P/'references/collectors/component-map.py').read_text()
correction = next(r['publication_disposition'] for r in json.loads((base/'vm18-x86_64/publication-worklist.json').read_text())['components'] if not r['image_install_stamp'])
old_disposition = 'build-only dependency: retain with reproducibility inputs; not counted as an installed runtime package'
assert original_map.count(old_disposition) == 1
t = original_map.replace(old_disposition, correction)
(P/'collectors/component-map.py').write_text(t)
(P/'collector-changes.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), s.splitlines(True), fromfile='accepted/source-inventory.py', tofile='candidate/source-inventory.py')) + ''.join(difflib.unified_diff(original_map.splitlines(True), t.splitlines(True), fromfile='accepted/component-map.py', tofile='candidate/component-map.py')))

put('reference-index.json', refs)
print(json.dumps({'source': C, 'product_paths': len(paths), 'changed_PKG_VERSION_declarations': len(pinchanges), 'historical_profiles': len(profiles), 'references': len(refs), 'collectors_executed': False}))

#!/usr/bin/env python3
"""Verify this source/record packet only. Never imports or runs a collector."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
P=Path(__file__).resolve().parent
R=Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(name): return json.loads((P/name).read_text())
refs=read('reference-index.json')
for row in refs:
 p=P/row['member']
 assert sha(p.read_bytes())==row['sha256']
 assert sha(Path(row['original']).read_bytes())==row['sha256']
 assert p.stat().st_size==row['bytes']
 assert oct(p.stat().st_mode&0o777)==row['mode']
d=read('product-delta.json');assert d['path_count']==73 and len(d['changed_version_declarations'])==4
assert len({x['path'] for x in d['paths']})==73
for old in d['historical_sources']:
 names=subprocess.check_output(['git','-C',str(R),'diff','--name-only',old,d['source'],'--',*d['scope']],text=True).splitlines()
 assert set(names)=={r['path'] for r in d['paths']}
for row in d['paths']:
 for obj in [row['current'],*row['historical'].values()]:
  if obj:
   raw=subprocess.check_output(['git','-C',str(R),'cat-file','blob',obj['git_blob']])
   assert sha(raw)==obj['sha256'] and len(raw)==obj['bytes']
 if row['current']: assert sha((P/'source-f863'/row['path']).read_bytes())==row['current']['sha256']
for row in read('current-component-recipes.json').values():
 assert sha((P/'source-f863'/row['recipe']).read_bytes())==row['sha256']
for row in read('component-source-delta.json')['complete_selected_package_directory_manifest']:
 assert sha(subprocess.check_output(['git','-C',str(R),'cat-file','blob',row['git_blob']]))==row['sha256']
for n in ['prepare-records.py','prepare-worklists.py','verify-static.py','collectors/source-inventory.py','collectors/component-map.py']:
 ast.parse((P/n).read_text(),filename=n)
# Existing functions remain byte-for-byte equivalent as ASTs; changes occur in
# the selected top-level record classification and one disposition string.
for n in ['source-inventory.py','component-map.py']:
 a=ast.parse((P/'references/collectors'/n).read_text())
 b=ast.parse((P/'collectors'/n).read_text())
 af={x.name:ast.dump(x,include_attributes=False) for x in a.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
 bf={x.name:ast.dump(x,include_attributes=False) for x in b.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
 assert af==bf,n
assert sha((R/'docs/qa-logs/2026-10-08-final-inventory/attempt-03/source-inventory.py').read_bytes())==sha((P/'references/collectors/source-inventory.py').read_bytes())
notice=read('notice-provenance-worklist.json');assert len(notice['components'])==18
assert all(row['publication_clearance'] is False for row in notice['components'])
vm=read('references/vm-artifact-result.json')['build_closeout']
assert vm['qualification'] is False and vm['original_launcher_returncode'] is None
assert vm['completion_disposition']=='failed-investigated/reporting-failure'
print(json.dumps({'status':'PASS_SOURCE_RECORD_STATIC_ONLY','source':d['source'],'historical_bases':len(d['historical_sources']),'product_paths':len(d['paths']),'changed_PKG_VERSION_declarations':len(d['changed_version_declarations']),'original_references':len(refs),'notice_rows':len(notice['components']),'collectors_executed':False,'cache_or_firmware_read':False,'network':False},sort_keys=True))

#!/usr/bin/env python3
"""Generate review worksheets from the packet's retained source/record bytes only."""
from pathlib import Path
import hashlib
import json
import subprocess
P=Path(__file__).resolve().parent
R=Path('/workspace/repos/rocknix.worktrees/m7-player-setup')
C='f8636de1d105275dbf9420bbabbbc26f79abb10f'
def put(name,obj): (P/name).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n')
recipes=json.loads((P/'current-component-recipes.json').read_text())
historical=json.loads((P/'historical-member-projection.json').read_text())
def row(name,current,missing,reuse,notes):
 return {'component':name,'current_input':current,'recipe':recipes[name],'prior_member_rows':[{'profile':r['profile'],'members':r['input_members']} for r in historical['components'] if r['component']==name],'required_additive_members_or_binding':missing,'reusable_by_exact_identity_only':reuse,'limits':notes,'publication_clearance':False}
rows=[
 row('emulationstation',{'git_commit':'16dbac5211eea7e70db7394372033be2be7df829'},['Exact root tree 16dbac plus its actual recursive gitlinks, commit/tree/mode/symlink metadata and any separately observed copied extra-cache content','Current f863 distribution recipe/build hooks and current profile membership'],['Historical unchanged submodule snapshots only after exact current gitlink identity match'],['Old 1d76 root snapshot is not current source. Local ES checkout/published repository visibility is not fork-owned retained corresponding-source custody.']),
 row('dolphin-sa',{'git_commit':'6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4'},['f863 complete selected patch directory, including 018-nogui-achievements-lifecycle.patch; launchers/helper/save-paths/config raw symlinks and Sys alias recipe','Current profile membership and source-to-installed-resource mapping'],['Existing exact 6094 root and 38 recursive tracked snapshots are listed in historical-member-projection.json'],['No engine pin change. Historical mapping only listed SM8550 aarch64; new profile membership must come from current inventory. Patches do not replace upstream or dependency notices.']),
 row('rclone',{'version':'1.75.2','amd64_zip_sha256':'349ac8fba6ff65d6247043f1750cdcb518ec5d500ef91463a10d37c0ccdf3702','arm64_zip_sha256':'7e1e8d69654941b7b7df84ee74c5f7fb09cce7d5496947fb7bf16b55ff427d10'},['Fork-owned exact two 1.75.2 ZIP members with original names and upstream checksum receipt','Exact 1.75.2 source commit/tree/tag resolution and notices including COPYING, go.mod/go.sum and notices for the actual embedded modules','Current binary metadata and release-modification disposition; bind stripped installed binaries separately'],['Only exact content-identical individual notice/dependency members after current source/module mapping'],['Historical 1.75.1 commit 687d264b and 244 module rows do not establish 1.75.2 source or dependency closure. Do not assert current vcs.modified from historical bytes. Version/ZIP binding receipt is retained.']),
 row('rocknix-abl',{'version':'1.2','archive_sha256':'4fcf983aff6af152fb5d7d0ef1a31727d64ecb93b2d75e202efeea5c5d4b565d','LinuxLoader_commit':'e9d37131c0c2273076468156fb0f87aa6834202b'},['Exact v1.2 release archive, its five selected installed payload mappings and current release metadata','Exact LinuxLoader e9d37131 implementation tree, applicable notices, dependencies and build inputs; access/source locator still unresolved in reviewed evidence','Exact v1.2 packaging tag commit/tree, kept separate from implementation'],[],['The older 458873 implementation lookup returned 404; no current lookup was performed here and that result is not transferred to e9d37131. Recipe SPDX header and public packaging do not establish implementation terms.']),
 row('fex-emu',{'git_commit':'e869aa644a16e4332cdc15c1ea0b4d13d482385d','nixpkgs_commit':'b6018f87da91d19d0ab4cf979885689b469cdd41','nixpkgs_url':'https://github.com/NixOS/nixpkgs/archive/b6018f87da91d19d0ab4cf979885689b469cdd41.tar.gz'},['Exact b6018 nixpkgs source archive/tree and actual post-build generated Nix/toolchain/rootfs input manifest','Actual current reachable store/source/derivation references needed by selected FEX outputs, separated from hashes reported by Nix metadata','Installer-response/source disposition for recipe curl https://nixos.org/nix/install | sh; no retained response claimed by current build plan'],['Existing e869 root and 19 recursive tracked snapshots if current identities match'],['Old 81-store-path inventory and old Nix version do not describe a new build. Device helper checks actual Nix/toolchain inputs and 14 ELF outputs; this is not a whole source-closure or installer-response retention proof. Do not rerun installer to fabricate original response.']),
 row('raofflineproxy',{'git_commit':'c7ebd1b6e777f3751ff0ecdf8aba54045844e00d','archive_sha256':'88eef31acfa4104b20258bd5cea514ade30e6cdf35767ffc958009851d61898b'},['Exact c7eb parent archive, current local patch set including 020 and 021, service/scripts and rcheevos glue','Current mapping of separately inventoried raofflineproxy-rcheevos and raofflineproxy-libchdr dependencies'],['Unchanged child-package source members after exact recipe/current inventory identity comparison'],['This is the fourth changed PKG_VERSION declaration. Archive parent and independently fetched child packages must remain separate mapped works.']),
 row('linux',{'H700_SM8550':'7.2','H700_SM8550_archive_sha256':'f9fef3d14c0df53819026f4be74459835c2a0b0dcbf5b5bbd9ea19f0829402b3','GENERIC_X64':'7.1.2','GENERIC_X64_archive_sha256':'37198c93727be247c9fb5309bb86cd5e496c61e5322cd8c4eca9476bb0b5883f'},['f863 patch/config/build-script selection, including shared 7.2 patch 0016; actual selected profile output/source mapping'],['Both exact historical kernel archives'],['No kernel version bump in this delta. SM8250-only source changes are retained in full distribution source but are not inferred to be selected by these five profiles.']),
 row('idtech-lr',{'version':'1.0','source_commit':'4cb65b687c90f56856e9d6a55e51f56a09955699','doom_archive_sha256':'ff35cde05801cfb27005229a6c55f20130ffa8f026ca27d7717c03152634e168'},['Current immutable URL/checksum/cache member name and staged/installed archive equality mapping','Game-data redistribution basis/notice; archive contains only doom.wad'],['Exact ff35 Doom bytes already retained in historical supplement'],['Version unchanged. Existing proof69 settled fetch/checksum/installation provenance only. Launcher GPL declaration does not license game data.']),
 row('steam',{'launcher_archive_sha256':'b44634a6a604ca7c8b23809d0f2a921a0348bb2081c8cb8944116d0799872b70','downloaded_runtime_inputs':'Player-triggered latest stable Steam runtime, public-beta client metadata, latest Proton and rolling FEX rootfs endpoints remain dynamic'},['f863 installed Install Steam.sh and current selected launcher/profile mapping','Explicit boundary between shipped proprietary launcher input and optional post-install downloads'],['Exact unchanged Steam launcher archive if selected'],['No new runtime/proton version pin was found in the tracked delta. Player downloads are not silently counted as firmware source inputs, nor declared licensed by fork scripts.']),
 row('gstreamer',{'change':'Build tools/plugin scanner enabled; libgstcontroller and libgstnet retained'},['Current source/recipe-inheritance mapping and installed selected libraries/scanner'],['Same upstream source/archive pins'],['Selected ELF/direct dependency-presence evidence is not recursive loader/runtime or notice clearance.'])
]
patches=[]
for component in ['dolphin-sa','raofflineproxy','raofflineproxy-rcheevos','raofflineproxy-libchdr']:
 path=recipes.get(component,{}).get('recipe')
 if not path:
  # These two unchanged child recipes are in the historical index.
  full=json.loads((R/'docs/qa-logs/2026-10-08-source-custody/git-complete/component-member-index.json').read_text())
  path=next(r['recipe'] for r in full['components'] if r['component']==component)
 for line in subprocess.check_output(['git','-C',str(R),'ls-tree','-r',C,'--',str(Path(path).parent)],text=True).splitlines():
  meta,n=line.split('\t');mode,kind,oid=meta.split();assert kind=='blob'
  raw=subprocess.check_output(['git','-C',str(R),'cat-file','blob',oid])
  patches.append({'component':component,'path':n,'git_mode':mode,'git_blob':oid,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
put('component-source-delta.json',{'source':C,'scope':'Review worksheet; current archive/source custody has not been collected or retrieved here.','components':rows,'complete_selected_package_directory_manifest':patches,'publication_bundle_complete':False})

basis=json.loads((P/'references/licence-basis-corrected.json').read_text())
extra={
 'common-shaders':['Exact included shader-file headers and subdirectory notices at 9c0d839a; installed-file → notice/member mapping, with unresolved files explicit'],
 'glsl-shaders':['Exact included-file notices at 4f4eb801; nnedi3/LICENSE da7eabb7 and crt/shaders/crt-royale/LICENSE.TXT d8c320ff are scoped separately; complete installed-file → notice map remains missing'],
 'retropie-shaders':['Exact included shader headers/subdirectory notices at 43eaf9b9; installed-file → notice/member map'],
 'slang-shaders':['Exact included shader headers/subdirectory notices at 4812a82f; installed-file → notice/member map'],
 'freej2me-lr':['JLayer individual notices and included output mapping','libsdl4j individual notices and included output mapping','ASM individual notices and included output mapping','libretro individual notices and included output mapping'],
 'openbor':['Keep root LICENSE, engine/LICENSE and tools/LICENSE as distinct notice members; map shipped engine/tool outputs to relevant files'],
 'wildmidi':['Current WANT_PLAYER/build/output mapping for LGPL library and GPL player; retain COPYING, src/wildmidi_lib.c and docs/license/{GPLv3,LGPLv3}.txt separately'],
 'zerotier-one':['Actual ZT_NONFREE/ZT_CONTROLLER effective build flags and corresponding object/output list','Separate notice/member map for selected ext/ and nonfree/ code; do not infer selection from directory existence'],
 'harfbuzz-icu':['Map shared HarfBuzz source and applicable per-directory COPYING; test/COPYING font terms are not a blanket library basis'],
 'libretro-database':['Included database attribution and exact root LICENSE in release materials'],
 'enet':['Exact root LICENSE plus source/output attribution in final current manifest'],
 'libspeexdsp':['Exact COPYING with notices/conditions in final materials'],
 'libxmp-lite':['Exact README permission text in final materials'],
 'opusfile':['Exact Xiph COPYING for every selected current profile, including ARM'],
 'rclone':['Supersede historical 1.75.1-only scope with current 1.75.2 source and embedded-module notice map; see component-source-delta.json'],
 'tailscale':['Current binary metadata compared with unchanged 1.98.8 input; 58 CLI/72 daemon historical module rows need exact selected dependency notices; no embedded VCS revision in prior binary'],
 'rocknix-abl':['Supersede older 1.1.9/458873 scope with exact v1.2/e9d371 implementation-source/access and applicable notices; see component-source-delta.json'],
}
out=[]
for old in basis['components']:
 n=old['component']
 out.append({'component':n,'historical_basis_record':old,'current_recipe':recipes[n],'exact_missing_members_or_output_maps':extra[n],'old_basis_only_for_unchanged_exact_source':n not in ['rclone','rocknix-abl'],'current_profiles':'Require final five-profile inventory; historical profile lists are not promoted.','publication_clearance':False})
out.append({'component':'idtech-lr/doom.wad','current_recipe':recipes['idtech-lr'],'retained_archive_sha256':'ff35cde05801cfb27005229a6c55f20130ffa8f026ca27d7717c03152634e168','exact_missing_members_or_output_maps':['Game-data redistribution terms/notice for the exact WAD; no licence member exists inside retained archive. Existing immutable-fetch proof is retained, not reopened.'],'publication_clearance':False})
put('notice-provenance-worklist.json',{'source':C,'basis_sha256':hashlib.sha256((P/'references/licence-basis-corrected.json').read_bytes()).hexdigest(),'components':out,'scope':'17 existing notice rows plus the separately tracked Doom data disposition. No new legal standard, aggregate licence inference or publication clearance.','publication_bundle_complete':False})
print(json.dumps({'component_delta_rows':len(rows),'notice_rows':len(out),'package_directory_members':len(patches),'collector_executed':False}))

# Existing collector handoff, after completed device outputs

This is a bounded source-only invocation/binding plan, not an allocated job.
Root retains the existing build/readback lifecycle. Do not execute any command
below until the current device owners are complete, their actual result and
cleanup receipts have been reviewed, and a new inventory owner has a fresh
retention/admission record. This task holds no active cache consumer; the
future inventory/source collection is a named pending consumer to resolve
before discarding its needed inputs.

## Bind exactly five profiles

| Profile | Current source tree | Original record needed |
|---|---|---|
| generic-x64-x86_64 | m7-p5-build-20261015-02 | `/workspace/tmp/pix-m7-engineering-build-20261015-02/build-inputs.json` plus accepted `/workspace/tmp/pix-m7-image-readback-20261015-02/artifacts/{inputs,result}.json` |
| h700-arm | m7-pixelelated-h700-04 | Final actual continuation-owner inputs, ARM output manifest, acceptance and immutable bundle manifest |
| h700-aarch64 | same | Same original input plus final AArch64 output/acceptance and immutable bundle manifest |
| sm8550-arm | m7-pixelelated-sm8550-04, subject to actual owner readback | Final actual owner inputs, ARM output manifest, acceptance and immutable bundle manifest |
| sm8550-aarch64 | same | Same original input plus final AArch64 output/acceptance, current FEX/Nix observations and immutable bundle manifest |

Every row records original input path/SHA, producer run/source, output manifest
path/SHA, actual artifact paths/hashes, profile arch, source-cache path from
original custody, and exact derived inventory-input SHA. Roots above are
planned/current source identities, not an assertion that either device build
has completed. Read original owner paths from the final receipts, including
any continuation; do not assume owner01 was the successful owner.

For the VM, retained `references/vm-build-inputs.json` SHA
`11c9cb3dd179405cc6ce1eca543846063b63e625e0ba7d2c7bc2d6cba47057d6`
and `references/vm-artifact-inputs.json` SHA
`7c3f497b08f494d15a233ae99be05e61af1656aec173120b00b41dd0266e2728`
bind f863, ES16dbac and the actual raw/update hashes. Preserve the complete
`build_closeout` record: failed-investigated/reporting-failure,
qualification=false, original_launcher_returncode=null. Never replace it
with a guessed success because artifact verification passed.

Derive per-profile `inventory-inputs.json` without changing originals. Required
existing collector keys are `distribution_commit`, `host_worktree`,
`container_worktree`, `build_root`, `source_cache`, `device`, `arch`,
`source_files`, and `source_symlinks`. Bind all to final original records and
f863 Git source; normalize absolute source-file keys only by a checked
`relative_to(host_worktree)` projection, preserving every digest and raw
symlink target. Assert no duplicate/colliding keys. VM's original manifest
has `checkout`, `commit`, `container_checkout` and only six product digests;
the full product-source map must be separately derived and hash-checked
against f863 tracked files, with its provenance named, not represented as an
original build-time manifest. Get `source_cache` from the actual retained
cache/build custody record; it is not present in that VM build-input file.

Use `build.pixelelated-DEVICE.ARCH` from the actual output, and the original
container logical prefix, not the host checkout, for `.cache_package_*`
resolution. ARM is a distinct inventory, not a copy of AArch64. The existing
lib32 relationship maps each AArch64 row to its accepted companion ARM row.

## Run the two accepted interfaces, with the narrow candidate corrections

The exact inner invocations for each separately bound profile are:

```bash
python3 -I "$TASK_OWNER/source-inventory.py" "$TASK_TREE" \
  "$TASK_PROFILE/inventory-inputs.json" "$TASK_PROFILE/source-inventory.json"
python3 -I "$TASK_OWNER/component-map.py" --tree "$TASK_TREE" \
  --inputs "$TASK_PROFILE/inventory-inputs.json" \
  --inventory "$TASK_PROFILE/source-inventory.json" \
  --output "$TASK_PROFILE/components.json"
```

The second runs only if the first's original returncode is zero. Preserve
each stdout/stderr and original returncode, even if another profile fails.
Use one fresh owner and one serialized finite five-profile job; no build,
download or VM command belongs in it. A 30-minute per-profile/150-minute
family ceiling is a proposed operating limit, not a measured requirement;
timeout/kill remains a failed original outcome. Root binds the actual helper
hashes, numeric limits, paths and no-concurrent-writer proof before admission.
No scan of unrelated cache entries or build-cache archive is proposed.

`references/collectors/inventory-run.py` is the successful attempt02 loop
template. Keep its exact per-profile original statuses and terminal
PASS_INVENTORY_WITH_PUBLICATION_GAPS semantics. Do not use attempt05's
historical source04 carry-forward shortcut for new images. Before using the
template, replace only its old `bundle['inputs'] == original` assumption with
explicit checks of the actual producer/readback schema described above;
for device bundles retain the existing equality when their actual schema
has it. There is no generic missing-receipt fallback. Final acceptance binds
all five source/component JSON hashes and their original channel receipts.

Use the existing tool contracts from the actual frozen runner checkout:

```bash
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build --admission "$TASK_OWNER/admission.json" -- \
  python3 -I "$TASK_OWNER/run.py"
python3 -I tools/host-maintenance/build-admission consume \
  --run "$TASK_RUN" --evidence "$TASK_OWNER/acceptance.json"
```

These are existing interface signatures, not ready values for TASK_*.
Root establishes the owner, plan and acceptance from originals. Run through
the frozen tree's ordinary admission tool, whose SHA must match its runner;
the coordinator's #597 recovery tool is not a replacement admission tool.
If root uses the existing submission helper instead of a foreground run,
preserve its launcher final wait/result independently of submission receipt,
watcher/command/runner/owner exits, resources and PID/CID teardown. A reporting
failure is investigated explicitly, never normalized. No consume is executed
by this packet.

## Reuse custody collectors additively

Retained originals and exact hashes are in `reference-index.json`. Do not run
them unmodified against historical paths or overwrite their outputs.

1. `archive-run.py` (successful source-archives02) validates already copied
   archive members; it does **not** perform the first copy. Bind its D profile
   directory, new unique DEST and exact new input manifests. Copy only the
   inventory-selected source archives that lack an exact already retained
   member, preserving source→member receipts. Include a new f863 distribution
   archive of full product source, patches and build scripts, with raw
   symlinks. Reuse old content-addressed members by their manifest/hash; do
   not copy a whole build cache. Independent streamed hash/member verification
   and actual copy exits remain required before immutable rename.
2. `git-run.py` (successful git-complete) binds the new pending root identities
   and an additive DEST. Its tracked blobs/modes/raw symlinks, recursive
   gitlinks, export-attribute override and separate extra-cache-content
   accounting remain. Use old snapshot members only when commit and metadata
   match; new ES16dbac needs a new root and its actual closure. Keep historical
   Teakra LFS pointer/non-use disposition; do not download the unused test
   payload merely to enlarge custody. Newly observed inputs require their
   own use/disposition, not the historical conclusion.
3. `prebuilt-run.py` is a prior bounded network collector, **not authorized to
   run by this packet**. For future explicit allocation, rebind rclone to the
   actual resolved 1.75.2 source commit and ABL packaging to actual v1.2 tag,
   while keeping LinuxLoader implementation separately pending. Retain its
   original API/tree/archive comparisons and HTTP limits; preserve failures.
   Do not copy hardcoded historical vcs.modified=true or 404 into new rows.
   Existing Tailscale source can be reused by exact identity; actual embedded
   module notice coverage is still separate.
4. `build-member-index.py` needs BASE/A/G/S rebinding to current profiles and
   old-plus-additive member manifests; assert each source manifest hash. Use
   per-profile arch and actual rclone version instead of vm18/1.75.1 literals.
   Map Doom's current cached archive once; keep the old supplemental member
   as same-byte provenance, not a second independent input. Replace 2327 with
   the sum of the five actual profile row counts and require exact profile
   and row membership. Preserve recursion, local recipe hashes, inherited
   recipe hashes and ARM references. No new current counts are predicted.

The final member index must identify which custody manifest owns every
archive/snapshot/notice; a content address alone is not a backup receipt.
Do not silently flatten two manifests with conflicting member metadata.
Keep static/vendor dependencies even without an install stamp. Current FEX
input and store/source closure is collected only after SM completes; the
installer-response limit stays explicit. `collect-licence-basis.py` is
retained for provenance only: its old GLSL aggregate label and old version
tables are superseded by the corrected worksheet, not eligible for replay.

## Completion and retention boundary

Needed next are the final two device output/acceptance records, checked VM
source-cache custody locator, derived profile inputs, minimally rebound
runner/member-index sources and actual original inventory/custody results.
The final binding review is finite and does not reopen broad audit or repeat
gameplay. All output consumers/retention classes are declared before any
copy; D-INFRA-022 preserves compact receipts and required source/notice
members and does not authorize deletion of originals.

The inventory/member-map result remains engineering source evidence with
publication_bundle_complete=false while exact notices/provenance,
independent retrieval and off-host custody are unresolved. #528's existing
publication gate remains; no RC, upload, component removal or physical-device
action is authorized by this preparation.

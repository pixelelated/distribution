#!/usr/bin/env python3
"""Parse source and compare named small originals; never invoke candidate helpers."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

P = Path(__file__).resolve().parent
OLD = Path('/tmp/pix-m7-source-custody-refresh-20261015')
TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def sha(p):
    assert p.is_file() and not p.is_symlink() and p.stat().st_size < 20 * 1024**2
    return hashlib.sha256(p.read_bytes()).hexdigest()

parsed = []
for p in sorted(P.rglob('*.py')):
    ast.parse(p.read_bytes(), filename=str(p), feature_version=(3, 10))
    parsed.append(str(p.relative_to(P)))
for name in ['commands.sh', 'templates/run.sh']:
    subprocess.run(['bash', '-n', str(P/name)], check=True)

for name in ['source-inventory.py', 'component-map.py']:
    assert (P/'templates'/name).read_bytes() == (OLD/'collectors'/name).read_bytes()
for name in ['source-inventory.py', 'component-map.py', 'inventory-run.py']:
    assert (P/'originals'/name).read_bytes() == (OLD/'references/collectors'/name).read_bytes()
assert (P/'collector-changes.diff').read_bytes() == (OLD/'collector-changes.diff').read_bytes()
assert (P/'publication-holds.json').read_bytes() == (OLD/'notice-provenance-worklist.json').read_bytes()

known = json.loads((P/'known-bindings.json').read_text())
for name, ref in known.items():
    assert sha(Path(ref['path'])) == ref['sha256'], name
    copy = P/'originals'/(name+'.json')
    if copy.exists():
        assert sha(copy) == ref['sha256'], name
for name, digest in json.loads((P/'frozen-tools.json').read_text()).items():
    assert sha(TREE/name) == digest, name

sm = json.loads((P/'sm-final.template.json').read_text())
assert set(sm) == {'inputs', 'acceptance', 'completion', 'consumed', 'output', 'arm', 'bundle'}
assert all(ref == {'path': None, 'sha256': None} for ref in sm.values())
resources = json.loads((P/'resources.json').read_text())
wrapper = (P/'templates/run.sh').read_text()
for literal in ['-c 0,1', '--as='+str(resources['address_space_bytes']),
                '--fsize='+str(resources['per_file_bytes']),
                '--kill-after='+str(resources['cleanup_seconds'])+'s',
                str(resources['family_seconds'])+'s']:
    assert literal in wrapper, literal
assert resources['profile_seconds'] * 5 == resources['family_seconds']
assert 'outer.rc' not in (P/'templates/run.py').read_text()
assert 'task_rc=$?' in wrapper and 'exit "$task_rc"' in wrapper

# Read only the accepted metadata and Git object path table, never a build root.
h = json.loads(Path(known['h700_inputs']['path']).read_text())
scope = ['packages', 'projects', 'config', 'scripts', 'distributions',
         'Makefile', 'LICENSE.md', 'TRADEMARK.md']
raw = subprocess.check_output(['git', '-C', h['host_worktree'], 'ls-tree', '-r', '-z',
    'f8636de1d105275dbf9420bbabbbc26f79abb10f', '--', *scope])
paths = {row.split(b'\t', 1)[1].decode() for row in raw.split(b'\0') if row}
declared = {str(Path(n).relative_to(h['host_worktree'])) if Path(n).is_absolute() else n
            for key in ['source_files', 'source_symlinks'] for n in h[key]}
assert paths == declared
print(json.dumps({'result': 'PASS_STATIC_ONLY', 'python_310_parsed': parsed,
    'shell_syntax_files': ['commands.sh', 'templates/run.sh'],
    'named_accepted_metadata_hashed': len(known), 'tracked_product_paths': len(paths),
    'collector_bytes_equal_reviewed_proposal': True, 'candidate_helpers_executed': False,
    'cache_or_archive_scan': False, 'runtime_qualified': False}, sort_keys=True))

"""AST and exact source equivalence only; never import candidate or inspect caches."""
from pathlib import Path
import ast,hashlib,json,subprocess
P=Path(__file__).resolve().parent;OLD=Path('/tmp/pix-m7-final-inventory-review-20261015');checks=[]
def check(name,condition):
 assert condition,name;checks.append(name)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
check('original seal unchanged',digest(OLD/'SHA256SUMS')=='485b9937f874ba2030ee6e1600670922c1c144872e8cee637165ae767bda47b9')
for line in (OLD/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);check('original sealed payload '+n,digest(OLD/n)==h)
for p in sorted(P.rglob('*.py')):
 ast.parse(p.read_bytes(),filename=str(p),feature_version=(3,10));checks.append('Python3.10 AST '+str(p.relative_to(P)))
for n in ['commands.sh','templates/run.sh']:
 r=subprocess.run(['bash','-n',str(P/n)],capture_output=True,text=True);check('bash-n '+n,r.returncode==0 and not r.stdout and not r.stderr)
for n in ['templates/bindings.py','templates/source-inventory.py','templates/component-map.py','templates/run.sh','resources.json','frozen-tools.json','known-bindings.json','sm-final.template.json','publication-holds.json','collector-changes.diff']:
 check('unchanged '+n,(P/n).read_bytes()==(OLD/n).read_bytes())
qualified=P/'lifecycle-references/qualified-worker-observer.py';helper=P/'templates/process-identity.py'
check('exact qualified source',digest(qualified)=='239a3977dd5800ee30b6ad56fb9655e200a24cb7a561e1e6d78e38cfca45bff0')
a=ast.parse(qualified.read_text());b=ast.parse(helper.read_text())
for name in ['identity','census','children','tree','same','signal_child']:
 aa=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name==name);bb=next(n for n in b.body if isinstance(n,ast.FunctionDef) and n.name==name)
 check('qualified helper AST-identical '+name,ast.dump(aa,include_attributes=False)==ast.dump(bb,include_attributes=False))
run=(P/'templates/run.py').read_text();consume=(P/'templates/consume.py').read_text();wrapper=(P/'templates/run.sh').read_text();prep=(P/'prepare-owner.py').read_text()
check('no numeric group signaling or census','killpg' not in run and 'group_members' not in run and 'child_groups' not in run and "cleanup['groups']" not in consume)
check('subreaper setup present','libc.prctl(36, 1, 0, 0, 0)' in run)
check('signal only qualified helper',"I['signal_child']" in run and 'os.kill(' not in run)
check('bounded13sec inner cleanup','deadline = time.monotonic()+13' in run and "setdefault('cleanup_deadline', deadline)" in run)
check('outer15sec/9000sec unchanged','--kill-after=15s 9000s' in wrapper)
check('outer status preserved only by shell','outer.rc' not in run and 'task_rc=$?' in wrapper)
check('spawn window blocks termination','signal.pthread_sigmask(signal.SIG_BLOCK' in run and 'signal.pthread_sigmask(signal.SIG_SETMASK' in run)
check('direct Popen wait excluded from adopted reap',"row['pid'] == active['proc'].pid:\n            continue" in run)
check('wait retention is actual int/once',"if active['wait_observed']:\n            assert active['original_rc'] == value" in run)
check('unknown outcome not written as exit',"if active['wait_observed']:\n        path = d/(key+'.exit')" in run)
check('interrupted receipt nonqualified',"key+'.interrupted.json'" in run and 'wait_observed=active[\'wait_observed\'], qualification=False' in run)
check('cleanup failure stays explicit','survivors = None' in run and "survivors != []" in run and 'receipt_errors' in run)
check('consumer exact identity and ancestry','owned_keys' in consume and "(r['pid'], r['start_ticks'])" in consume and 'assert not matching and not descendants' in consume)
check('consumer errors force refusal',"not cleanup['errors']" in consume and "not cleanup['receipt_errors']" in consume and "not cleanup['signals_sent']" in consume)
check('consumer child wait/status required',"child['wait_observed'] is True" in consume and "child['original_child_returncode'] == 0" in consume)
oldprep=(OLD/'prepare-owner.py').read_text();expected=oldprep.replace("'bindings.py', 'run.py', 'run.sh', 'consume.py', 'source-inventory.py', 'component-map.py'","'bindings.py', 'process-identity.py', 'run.py', 'run.sh', 'consume.py', 'source-inventory.py', 'component-map.py'")
check('preparer only copies new helper',prep==expected)
check('command path only rebased',(P/'commands.sh').read_text()==(OLD/'commands.sh').read_text().replace('TASK_PACKET=/tmp/pix-m7-final-inventory-review-20261015\n','TASK_PACKET=/tmp/pix-m7-final-inventory-review-20261015-02\n'))
check('mixed-source binding stays pending',"sources['GENERIC_X64'] == sources['H700'] == sources['SM8550']" in prep)
print(json.dumps(dict(status='PASS_STATIC_ONLY',checks=checks,count=len(checks),candidate_imported_or_executed=False,runtime_tests=False,cache_scan=False,source_binding_ready=False),indent=2))

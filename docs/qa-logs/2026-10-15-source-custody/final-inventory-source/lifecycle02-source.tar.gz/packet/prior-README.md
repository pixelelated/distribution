# #528 five-profile final inventory — source review packet

**SOURCE ONLY / UNRUN.** No preparer, inventory collector, admission, runtime,
cache scan or archive scan ran. Root review precedes preparation. The final
SM8550 acceptance does not yet exist in this packet and is a required input.
This produces source/component inventories, not corresponding-source archives,
off-host custody, licence clearance, an RC or publication clearance.

The frozen source is `f8636de1d105275dbf9420bbabbbc26f79abb10f`; ES is
`16dbac5211eea7e70db7394372033be2be7df829`. The owner will inventory exactly
GENERIC_X64 x86_64, H700 ARM and AArch64, and SM8550 ARM and AArch64, in that
order. Counts come from actual reports; neither the historical 2,327 rows nor
any anticipated per-profile count is accepted as a new result.

## Source changes

`templates/source-inventory.py` and `templates/component-map.py` are byte-exact
copies of the released proposal's three narrow corrections: derive rclone's
binary path from the current recipe version; recognize the pinned normal Doom
cache input and retain staged/installed equality; preserve the accepted caveat
that no image install stamp does not exclude static or vendored shipped work.
Their original helpers and exact diff are retained. Missing classifications,
source checksum mismatches, recursive Git identity mismatches and the existing
scoped LLVM reconstruction requirements still fail.

`templates/run.py` adapts the accepted inventory02 sequential loop: exact new
bindings, per-profile stdout/stderr and original child statuses, finite time
and process cleanup, output bounds and a current publication worklist copy.
`inventory-run.diff` shows that entire delta. New glue is limited to
`prepare-owner.py`, `templates/bindings.py`, `templates/consume.py` and the two
command wrappers. None launches target software or fetches anything.

## Actual accepted bindings

`known-bindings.json` pins metadata originals by path and SHA256. The H700
acceptance is `e8107b4bffac81fa72dd127a45ec1b6b7455518829f04c143690ec60687813db`,
with immutable bundle `32f7a6523dfae61b5142cf803876bf4e09f9a21a3a6784a69ca74b9d9b587833`.
That bundle embeds the corrected reader's `inputs.json`, SHA
`12fadf79ad5ee43876786ecad7763dc4f4da5bee0b653bb4660e9d6f8dc08c26`, rather
than the earlier build owner's input manifest. The original combined producer
1 and failed acceptance 1 remain in its retained acceptance record.

The VM uses its actual `build-inputs.json`, accepted artifact input/result
records and consumed reader receipt. Its original container observation
binds `/workspace/cache/rocknix-sources` to the actual logical `sources` mount.
The producer's #597 reporting failure remains nonqualified, with original
launcher status null; independently accepted artifact integrity remains a
separate fact. No old bundle schema or launcher zero is invented.

For device inputs, preparation projects absolute source paths to relative
paths without changing hashes or raw symlink targets. It requires the exact
same set as f863 Git-tracked product files and verifies every blob against
checkout bytes, including raw symlinks and executable mode. The VM full source
map is newly derived from f863 and labelled as inventory-time provenance;
the original VM build manifest only contains six product hashes. Original
metadata is copied verbatim to the new owner, and all three source maps must
match. This preparation reads tracked source and named metadata only; actual
build/source-cache input inspection occurs only in the later admitted job.

## Required final SM binding

Create a new JSON using `sm-final.template.json` only after the final SM8550
artifact acceptance is PASS and consumed. All seven entries require the
actual absolute original path and SHA256; nulls refuse preparation:

| Entry | Required original |
|---|---|
| inputs | Input manifest embedded verbatim in the accepted candidate bundle |
| acceptance | Final independent `artifacts/acceptance.json` |
| completion | Original qualified acceptance `admission-completion-evidence.json` |
| consumed | That exact acceptance run's `admission-consumed.json` |
| output | Accepted producer/reader `artifacts/output-manifest.json` |
| arm | Actual current ARM manifest named by inputs and hashed by output manifest |
| bundle | Accepted immutable candidate's `manifest.json` |

The validator requires f863/ES16dbac, SM8550 tree04 and its original container
logical prefix, accepted PASS/cleanup/source/inode checks, bundle-input object
equality, exact output-file manifest equality, exact ARM manifest digest and
the actual consumed original zero result plus matching completion evidence.
It reads and hashes metadata, never opens firmware archives. A different final
schema must receive a narrow source review; missing fields are not waived.

## Root commands after review and final SM acceptance

Choose a fresh owner. The provided default is
`/workspace/tmp/pix-m7-final-inventory-20261015-01`; it is not created now.

```bash
export TASK_OWNER=/workspace/tmp/pix-m7-final-inventory-20261015-01
export TASK_SM_FINAL=/absolute/path/to/reviewed-sm-final.json
export TASK_SM_FINAL_SHA256=actual_64_hex_digest
bash /tmp/pix-m7-final-inventory-review-20261015/commands.sh prepare
bash /tmp/pix-m7-final-inventory-review-20261015/commands.sh run
# After original terminal channels and root report review:
bash /tmp/pix-m7-final-inventory-review-20261015/commands.sh consume
```

Preparation refuses an existing owner, any unconsumed registry owner, changed
packet bytes or wrong actual-host namespace/UID. It creates ordinary retention
and admission plans but does not allocate or run them. `run` uses the frozen
tree's exact ordinary admission tool and existing `watch-build-submit`; it
clears inherited PROJECT/DEVICE/ARCH at the gateway. Root actively supervises
at <=60-second intervals. Never pre-create launcher final receipts.

The current registry gate enforces this serialized host job; it is not a
claim of independent whole-host FD or external-writer census. Root must keep
the three retained build roots and shared source cache free of writers for
the run. The fresh ordinary preflight/retention/admission controls remain.
The actual runtime rechecks accepted input bindings before and after the five
profiles and all tracked source hashes/symlinks after collection.

Proposed limits, sealed in `resources.json`: CPUs 0–1, 4 GiB address space,
128 MiB per output file, 512 MiB owner output ceiling, 1,800 seconds total per
profile, 9,000 seconds family deadline and 15 seconds outer cleanup allowance.
Retention reserves 2 GiB including margin, without deletion credit. These are
operating ceilings, not measured requirements. A timeout retains the original
killed child status, fails that profile and does not become a zero. Recorded
collector groups are terminated/reaped as needed and required absent before
successful consumption. No container or target execution is involved.
The shell records the actual bounded invocation result in `outer.rc`; Python
records only `inner.rc`. A GNU timeout status such as 124 is not replaced by
the Python cleanup status, and missing final receipts are not manufactured.

## Results and remaining scope

Each profile retains its exact `inventory-inputs.json`, `source-inventory.json`,
`components.json`, identical `publication-worklist.json`, stdout/stderr,
child PID/group records, original exit values and per-profile result.
`result.json` succeeds only with all five current pairs zero and no timeout;
`cleanup.json`, inner/outer, launcher and watch-job original results remain
separate. Root inspects counts/unclassified inputs/current pins and the
original channels before `consume.py` invokes ordinary consumption. Failure
requires explicit investigation; the consumer never auto-qualifies it.

All #528 notice/source/vendor/Nix/retrieval/off-host/publication holds remain
open in `publication-holds.json`. This packet does not run the custody archive,
Git snapshot, prebuilt network or member-index collectors. Their later input
is the five actual reports and preserved exact source-cache identities, not
an assumed historical count or copied old result. No full matrix, rebuild or
ordinary-gameplay replay is proposed.

## Source review and static originals

`static-execution.json` records the actual source-check invocation and original
exit 0 on 2026-10-15 at 07:22:10 UTC, with stdout/stderr retained. It parsed all
Python as Python 3.10 and both shell files, checked the two candidate collectors
against the released proposal, all 13 named accepted metadata references and
six frozen tools, and compared the H700 original path set with f863 Git paths.
It did not import or execute any candidate helper, preparer or collector.

Peer `frame_diff_review` independently cleared the released proposal and three
collector corrections. That clearance explicitly excludes this new lifecycle
and binding glue; those received source-worker review and still require root's
review before allocation. `source-review.md` records scope and the original
status-capture correction. No inventory result or publication gate is claimed.

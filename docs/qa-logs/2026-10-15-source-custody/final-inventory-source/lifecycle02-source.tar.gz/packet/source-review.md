# Finite lifecycle source disposition

The original two P2 findings are corrected in source, pending root review and future scoped execution. No runtime pass is claimed.

| Finding | Source correction | Evidence/limit |
| --- | --- | --- |
| Numeric PGID reuse could signal or classify an unrelated process | Qualified strict numeric proc parsing, PID/start-ticks identities, verified direct/adopted child pidfd signaling, subreaper adoption, direct-Popen-safe waits and exact final consumer identities/ancestry | Six helper definitions are AST-identical to the named qualified source. No raw killpg or historical group census remains in the active runner/consumer. Proc errors remain unknown/failing. The source is read; no helper executes in this review. |
| Family interruption discarded an observed child return value | Active child/profile/command/output/identity record; wait value retained once; known original `.exit`, child result and nonqualified interruption/timeout receipts; best-effort incomplete profile/family/cleanup receipts | Direct Popen owns the wait. Cleanup does not synthesize zero. The shell's outer timeout124 remains separate from the inner failure status. Completed originals are immutable; partial/conflicting receipt writes become explicit errors. Fatal SIGKILL cannot guarantee a final receipt. |

The spawn registration window masks SIGTERM/SIGINT until Popen custody is recorded, then restores the prior mask. Finalization records further signals without restarting cleanup. Each active collector has one retained cleanup deadline; cleanup uses at most the previous 5+5+3-second allowance. Adopted descendants are signaled only after verified direct ancestry; reaping uses their recorded identities and never steals the active Popen wait. A successful original child with forced descendant cleanup cannot qualify the family.

Normal collector results, manifest checks, worklist copy and original per-profile output paths remain. New child result files expose original wait/identity/disposition separately. Current final consumption requires five successful profile pairs, no timeout/interruption, no custody/receipt errors, no forced cleanup and the actual original zero outer/inner/launcher/runner channels. Existing publication holds remain unchanged.

The only preparer delta copies `process-identity.py`; existing owner sealing binds it. The command wrapper merely relocates the packet path. `templates/run.sh`, resources, collectors, bindings and frozen admission-tool hashes are byte-identical to485b9937. `verify-static.py` and prior observations are retained historical source, not newly rerun checks; the new `verify-lifecycle-static.py` only parses and compares source.

Subsequent dependency: #600 changes the SM ABL recipe/source identity. This packet intentionally leaves original f863 commit/source-map assertions intact. The exact per-device commit and one-path old/new hash binding require root's separately assigned derivative. No mixed-source family or common RC identity is qualified here.

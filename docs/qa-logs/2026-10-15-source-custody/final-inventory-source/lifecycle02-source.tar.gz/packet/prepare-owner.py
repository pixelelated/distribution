#!/usr/bin/env python3
"""Prepare one bound inventory owner after final device acceptance; never inventory."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import runpy
import shutil

P = Path(__file__).resolve().parent
def sha(p):
    with Path(p).open('rb') as f:
        h = hashlib.sha256()
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
        return h.hexdigest()
def put(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write('\n')

def main():
    q = argparse.ArgumentParser(description=__doc__)
    q.add_argument('--owner', type=Path, required=True)
    q.add_argument('--sm-final', type=Path, required=True)
    q.add_argument('--sm-final-sha256', required=True)
    args = q.parse_args()
    for line in (P/'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        assert sha(P/n) == h, n
    B = runpy.run_path(str(P/'templates/bindings.py'))
    B['host_and_serialization']()
    for name, h in B['load'](P/'frozen-tools.json').items():
        assert sha(B['VM_TREE']/name) == h
    O = args.owner
    assert O.parent == Path('/workspace/tmp') and re.fullmatch(r'pix-m7-final-inventory-20261015-[0-9]{2}', O.name)
    assert not O.exists()
    sm = B['checked']({'path': str(args.sm_final), 'sha256': args.sm_final_sha256})
    known = B['load'](P/'known-bindings.json')
    bound = B['all_bindings'](known, sm)
    sources = {}
    for device in ['H700', 'SM8550']:
        j = bound[device][0]
        sources[device] = B['source_manifest'](Path(j['host_worktree']), j)
    sources['GENERIC_X64'] = B['source_manifest'](B['VM_TREE'])
    assert sources['GENERIC_X64'] == sources['H700'] == sources['SM8550'], 'same f863 product source differs'
    vi = bound['GENERIC_X64'][0]
    for rel, h in vi['product_sha256'].items():
        assert sources['GENERIC_X64'][0][rel] == h
    O.mkdir()
    (O/'profiles').mkdir()
    (O/'originals').mkdir()
    (O/'empty-retention-scan').mkdir()
    for name in ['bindings.py', 'process-identity.py', 'run.py', 'run.sh', 'consume.py', 'source-inventory.py', 'component-map.py']:
        shutil.copy2(P/'templates'/name, O/name)
    for name in ['known-bindings.json', 'resources.json', 'publication-holds.json', 'frozen-tools.json']:
        shutil.copy2(P/name, O/name)
    shutil.copy2(args.sm_final, O/'sm-final.json')
    references = dict(known)
    references.update({'sm8550_'+k: v for k, v in sm.items()})
    for name, ref in references.items():
        B['checked'](ref)
        shutil.copy2(ref['path'], O/'originals'/(name+'.json'))
    profiles = []
    for name in B['PROFILE_NAMES']:
        if name == 'generic-x64-x86_64':
            device, arch = 'GENERIC_X64', 'x86_64'
            j, a = bound[device]
            tree, canonical = j['checkout'], j['container_checkout']
            original = known['vm_inputs']
            acceptance = known['vm_result']
            source_note = 'Full tracked product map derived at inventory preparation from exact f863 Git blobs and verified current checkout bytes; not an original VM build-time full manifest.'
        else:
            prefix, arch = name.split('-', 1)
            device = prefix.upper()
            j, a = bound[device]
            tree, canonical = j['host_worktree'], j['container_worktree']
            drefs = sm if device == 'SM8550' else {k.removeprefix('h700_'): v for k, v in known.items() if k.startswith('h700_')}
            original, acceptance = drefs['inputs'], drefs['acceptance']
            source_note = 'Original accepted device input map projected to relative paths without changing hashes/targets, then independently matched to exact f863 Git blobs and checkout bytes.'
        d = O/'profiles'/name
        d.mkdir()
        inputs = {'distribution_commit': B['COMMIT'], 'host_worktree': tree,
                  'container_worktree': canonical, 'source_cache': B['SOURCE_CACHE'],
                  'device': device, 'arch': arch, 'build_root': 'build.pixelelated-'+device+'.'+arch,
                  'source_files': sources[device][0], 'source_symlinks': sources[device][1],
                  'original_inputs': original, 'artifact_acceptance': acceptance,
                  'derivation_scope': source_note}
        put(d/'inventory-inputs.json', inputs)
        profiles.append({'name': name, 'tree': tree, 'device': device, 'arch': arch,
                         'inputs': str(d/'inventory-inputs.json'), 'inputs_sha256': sha(d/'inventory-inputs.json'),
                         'original_inputs': original, 'artifact_acceptance': acceptance,
                         'output': str(d), 'source_provenance': source_note})
    put(O/'profiles.json', profiles)
    put(O/'binding-receipt.json', {'source': B['COMMIT'], 'packet_sha256': sha(P/'SHA256SUMS'),
        'sm_final_path': str(args.sm_final), 'sm_final_sha256': args.sm_final_sha256,
        'references': references, 'profile_names': B['PROFILE_NAMES'],
        'known_producer_limits': {'VM': bound['GENERIC_X64'][1]['build_closeout'],
                                 'H700': bound['H700'][1]},
        'status': 'PREPARED_UNRUN', 'source_inventory_executed': False})
    resources = B['load'](O/'resources.json')
    protected = sorted({B['SOURCE_CACHE'], *(p['tree'] for p in profiles),
                        *(str(Path(p['tree'])/('build.pixelelated-'+p['device']+'.'+p['arch'])) for p in profiles)})
    retention = {'volume': '/workspace', 'scan_roots': [str(O/'empty-retention-scan')],
        'reference_stores': [], 'protected': protected, 'candidates': [], 'builds': [{
            'name': 'm7-final-source-inventory', 'terms_bytes': {'bounded_inventory_and_margin': resources['retention_budget_bytes']},
            'basis': 'Metadata-only outputs bounded to 512 MiB, plus 1536 MiB operating margin. Existing source/cache allocation remains occupied; no source copies, no deletion credit. Empty explicit scan is not whole-volume classification.',
            'evidence': [{'path': str(O/'resources.json'), 'sha256': sha(O/'resources.json')}]}]}
    put(O/'retention-plan.json', retention)
    put(O/'admission-plan.json', {'checkout': str(B['VM_TREE']), 'container_checkout': str(B['VM_TREE']),
        'retention_plan': str(O/'retention-plan.json'), 'retention_report': str(O/'retention-report.json'),
        'stage': 'm7-final-source-inventory',
        'profiles': [{'PROJECT': 'ROCKNIX', 'DEVICE': p['device'], 'ARCH': p['arch']} for p in profiles],
        'outputs': [{'path': str(O), 'kind': 'qa-scratch', 'issue': 528,
                     'release_when': 'Original inventory results consumed and compact source/component records retained; corresponding-source publication and independent custody remain separately open.'}]})
    put(O/'seal.json', {str(p): sha(p) for p in sorted(O.rglob('*')) if p.is_file()})
    print(json.dumps({'owner': str(O), 'status': 'PREPARED_UNRUN', 'source': B['COMMIT'],
                      'profiles': B['PROFILE_NAMES'], 'seal_sha256': sha(O/'seal.json')}))

if __name__ == '__main__':
    main()

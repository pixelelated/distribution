#!/bin/bash
# Invoke one named step after root source review and final SM artifact acceptance.
set -euo pipefail
TASK_PACKET=/tmp/pix-m7-final-inventory-review-20261015-02
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_OWNER=${TASK_OWNER:-/workspace/tmp/pix-m7-final-inventory-20261015-01}
cd "$TASK_TREE"
case "${1:?prepare, run, or consume}" in
 prepare)
  tools/watch-build --record-only -- python3 -I "$TASK_PACKET/prepare-owner.py" \
    --owner "$TASK_OWNER" --sm-final "${TASK_SM_FINAL:?exact final binding JSON}" \
    --sm-final-sha256 "${TASK_SM_FINAL_SHA256:?actual binding JSON digest}"
  ;;
 run)
  tools/build-preflight
  tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
    --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
  python3 -I tools/host-maintenance/build-admission prepare \
    --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
  env -u PROJECT -u DEVICE -u ARCH tools/watch-build-submit --owner "$TASK_OWNER" -- \
    --admission "$TASK_OWNER/admission.json" -- bash "$TASK_OWNER/run.sh"
  # Submission is not completion. Supervise originals at <=60-second cadence.
  # Never pre-create tool-wrapper.rc or launcher-result.json as submission proof.
  ;;
 consume)
  python3 -I "$TASK_OWNER/consume.py"
  ;;
 *) exit 2;;
esac

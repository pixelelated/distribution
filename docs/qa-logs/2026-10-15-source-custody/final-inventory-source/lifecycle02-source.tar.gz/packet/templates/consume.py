#!/usr/bin/env python3
"""Consume only this inventory's successful original channels; never a prior build."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import subprocess

O = Path(__file__).resolve().parent
def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda: f.read(4*1024*1024), b''):
            h.update(block)
    return h.hexdigest()
def load(p): return json.loads(Path(p).read_text())
for name, h in load(O/'seal.json').items():
    assert sha(name) == h, name
B = runpy.run_path(str(O/'bindings.py'))
assert Path.cwd() == B['VM_TREE']
for name, h in B['load'](O/'frozen-tools.json').items():
    assert sha(B['VM_TREE']/name) == h
run = Path((O/'run.path').read_text().strip())
assert run.parent == B['VM_TREE']/'.build-runs'
B['host_and_serialization'](run)
runner, launch = load(run/'runner-result.json'), load(O/'launcher-result.json')
assert all(type(runner[k]) is int and runner[k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
assert type(launch['runner_returncode']) is int and launch['runner_returncode'] == 0
for f in [O/'inner.rc', O/'outer.rc', O/'tool-wrapper.rc', run/'build.rc']:
    assert f.read_text().strip() == '0', f
result, cleanup = load(O/'result.json'), load(O/'cleanup.json')
assert result['result'] == 'PASS_INVENTORY_WITH_PUBLICATION_GAPS'
assert result['publication_bundle_complete'] is False
assert [r['profile'] for r in result['profiles']] == B['PROFILE_NAMES']
I = runpy.run_path(str(O/'process-identity.py'))
assert cleanup['all_recorded_identities_absent'] is True
assert cleanup['recorded_identities_still_present'] == [] and cleanup['survivors_after_cleanup'] == []
assert not cleanup['errors'] and not cleanup['receipt_errors'] and not cleanup['signals_sent']
assert cleanup['direct_child_unreaped'] is False and not result['interrupted_signals']
assert not result['cleanup_errors'] and not result['receipt_errors'] and result['execution_error'] is None
# One strict census: PID reuse is not an owned identity, and no historical PGID
# authorizes a survivor claim. Unknown proc reads still fail this consumer.
snapshot = I['census']()
owned_keys = {(r['pid'], r['start_ticks']) for r in cleanup['recorded_identities']}
supervisor = cleanup['supervisor_identity'];assert supervisor is not None
owned_keys.add((supervisor['pid'], supervisor['start_ticks']))
matching = [r for r in snapshot if (r['pid'], r['start_ticks']) in owned_keys]
parents = {r['pid'] for r in matching};descendants = []
while parents:
    children = [r for r in snapshot if r['ppid'] in parents and r not in matching and r not in descendants]
    descendants.extend(children);parents = {r['pid'] for r in children}
assert not matching and not descendants, 'recorded identity or owned descendant still present'
files = [O/'result.json', O/'cleanup.json', O/'binding-receipt.json', O/'publication-holds.json',
         O/'profiles.json', O/'seal.json', O/'inner.rc', O/'outer.rc', O/'launcher-result.json',
         O/'tool-wrapper.rc', run/'runner-result.json', run/'build.rc']
for row in result['profiles']:
    assert row['source_inventory_rc'] == row['component_map_rc'] == 0 and not row['timeout'] and not row['interrupted']
    d = O/'profiles'/row['profile']
    assert sha(d/'source-inventory.json') == row['source_inventory_sha256']
    assert sha(d/'components.json') == row['components_sha256']
    assert (d/'publication-worklist.json').read_bytes() == (d/'components.json').read_bytes()
    for key in ['source_inventory', 'component_map']:
        assert (d/(key+'.exit')).read_text().strip() == '0'
        child = load(d/(key+'.result.json'))
        assert child['wait_observed'] is True and type(child['original_child_returncode']) is int and child['original_child_returncode'] == 0
        assert child['qualification'] is True and not child['interrupted'] and not child['timeout'] and not child['cleanup_signals']
        identity = load(d/(key+'.process.json'))['identity']
        assert (identity['pid'], identity['start_ticks']) in owned_keys
    files += sorted(p for p in d.iterdir() if p.is_file())
admission = load(run/'admission.json')
assert admission['source']['head'] == B['COMMIT'] and admission['submission_owner'] == str(O)
evidence = {'run': str(run), 'disposition': 'qualified', 'expected_rc': 0,
    'outputs': admission['outputs'], 'evidence': [{'path': str(p), 'sha256': sha(p)} for p in files],
    'scope': 'Only five-profile post-build inventory execution qualified. Existing #528 notice, source custody, retrieval/off-host and publication holds remain open; prior producer failures unchanged.'}
out = O/'admission-completion-evidence.json'
with out.open('x') as f:
    json.dump(evidence, f, indent=2)
    f.write('\n')
subprocess.run(['python3', '-I', str(B['VM_TREE']/'tools/host-maintenance/build-admission'),
                'consume', '--run', str(run), '--evidence', str(out)], check=True)
print('PASS consumed original inventory results; publication holds remain open')

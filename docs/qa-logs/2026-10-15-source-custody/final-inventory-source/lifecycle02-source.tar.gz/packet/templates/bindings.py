"""Exact final-artifact/producer metadata binding for this five-profile inventory."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

COMMIT = 'f8636de1d105275dbf9420bbabbbc26f79abb10f'
ES = '16dbac5211eea7e70db7394372033be2be7df829'
VM_TREE = Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
SOURCE_CACHE = '/workspace/cache/rocknix-sources'
PRODUCT = ['packages', 'projects', 'config', 'scripts', 'distributions',
           'Makefile', 'LICENSE.md', 'TRADEMARK.md']
PROFILE_NAMES = ['generic-x64-x86_64', 'h700-arm', 'h700-aarch64',
                 'sm8550-arm', 'sm8550-aarch64']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    p = Path(path)
    assert p.is_file() and not p.is_symlink() and p.stat().st_size < 20 * 1024**2, p
    return json.loads(p.read_text())

def checked(ref):
    assert set(ref) == {'path', 'sha256'}
    p = Path(ref['path'])
    assert p.is_absolute() and p.resolve(strict=True) == p
    assert re.fullmatch('[0-9a-f]{64}', ref['sha256'])
    assert p.stat().st_size < 20 * 1024**2 and sha(p) == ref['sha256'], p
    return load(p)

def git(tree, *args):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', '-C', str(tree), *args], env=env)

def host_and_serialization(own_run=None):
    assert (os.getuid(), os.getgid()) == (1000, 1000)
    assert os.readlink('/proc/self/ns/pid') == 'pid:[4026531836]'
    registry = load('/workspace/repos/rocknix/.git/pixelelated-build-admission/jobs.json')
    active = [j for j in registry['jobs'].values() if j['state'] != 'consumed']
    assert all(own_run is not None and j['run'] == str(own_run) for j in active), 'another unconsumed owner remains'
    if own_run is not None:
        assert len(active) == 1 and active[0]['source']['head'] == COMMIT

def consumed(refs, proof_key):
    c, evidence = checked(refs['consumed']), checked(refs['completion'])
    assert c['state'] == 'consumed' and c['source']['head'] == COMMIT
    assert c['evidence_sha256'] == refs['completion']['sha256']
    assert c['run'] == evidence['run']
    assert evidence['disposition'] == 'qualified' and evidence['expected_rc'] == 0
    assert all(type(c['original_result'][k]) is int and c['original_result'][k] == 0
               for k in ['command_rc', 'monitor_rc', 'runner_rc'])
    assert refs[proof_key] in evidence['evidence']
    for item in evidence['evidence']:
        # Original channel/acceptance receipts only. Never read firmware here.
        p = Path(item['path'])
        assert p.stat().st_size < 20 * 1024**2 and sha(p) == item['sha256'], p
    return c

def source_manifest(tree, declared=None):
    assert tree.resolve(strict=True) == tree
    assert git(tree, 'rev-parse', 'HEAD').decode().strip() == COMMIT
    assert not git(tree, 'diff', '--name-only', COMMIT, '--', *PRODUCT).strip()
    files, links = {}, {}
    raw = git(tree, 'ls-tree', '-r', '-z', COMMIT, '--', *PRODUCT)
    for row in raw.split(b'\0'):
        if not row:
            continue
        meta, name = row.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        rel = os.fsdecode(name)
        assert kind == 'blob' and mode in ['100644', '100755', '120000']
        p = tree / rel
        if mode == '120000':
            assert p.is_symlink()
            target = os.readlink(p)
            data = os.fsencode(target)
            links[rel] = target
        else:
            assert p.is_file() and not p.is_symlink()
            assert bool(p.stat().st_mode & 0o111) == (mode == '100755')
            data = p.read_bytes()
            files[rel] = hashlib.sha256(data).hexdigest()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == oid, rel
    if declared is not None:
        normalized = []
        for key in ['source_files', 'source_symlinks']:
            result = {}
            for name, value in declared[key].items():
                p = Path(name)
                rel = str(p.relative_to(tree)) if p.is_absolute() else str(p)
                assert not Path(rel).is_absolute() and '..' not in Path(rel).parts and rel not in result
                result[rel] = value
            normalized.append(result)
        assert normalized == [files, links], 'original source map differs from exact f863 tracked scope'
    return files, links

def device_binding(device, refs):
    assert set(refs) == {'inputs', 'acceptance', 'completion', 'consumed', 'output', 'arm', 'bundle'}
    j, a, out, arm, bundle = (checked(refs[k]) for k in ['inputs', 'acceptance', 'output', 'arm', 'bundle'])
    consumed(refs, 'acceptance')
    tree = Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-' + device.lower() + '-04')
    assert j['host_worktree'] == str(tree) and j['device'] == device and j['arch'] == 'aarch64'
    assert j['distribution_commit'] == a['distribution_commit'] == out['distribution_commit'] == COMMIT
    assert j['emulationstation_commit'] == ES and j['source_cache'] == SOURCE_CACHE
    assert j['build_root'] == 'build.pixelelated-' + device + '.aarch64'
    assert j['container_worktree'] == str(tree.with_name('m7-pixelelated-' + device.lower() + '-01'))
    assert a['result'] == 'PASS' and a['scratch_removed'] and a['source_unchanged'] and a['independent_bundle_inodes']
    assert len(a['variants']) == (2 if device == 'H700' else 1)
    assert bundle['inputs'] == j
    assert str(Path(a['bundle']) / 'manifest.json') == refs['bundle']['path']
    assert a['bundle_manifest_sha256'] == refs['bundle']['sha256'] == Path(a['bundle']).name
    assert {n: {k: v[k] for k in ['bytes', 'sha256']} for n, v in out['files'].items()} == bundle['files']
    assert j['arm_manifest'] == refs['arm']['path'] and arm['result'] == 'PASS'
    if device == 'SM8550':
        assert out['arm_manifest_sha256'] == refs['arm']['sha256']
    else:
        assert refs['arm']['sha256'] == '18ec6c1df54763a3a78f685a236f72dda677cd4136af161509c743e6a8b13944'
        assert a['producer_combined_run_returncode'] == a['failed_acceptance_returncode'] == 1
    assert a['arm_handoff_files'] > 0 and arm['files'] and arm['stamps']
    return j, a

def all_bindings(known, sm):
    h = {k.removeprefix('h700_'): v for k, v in known.items() if k.startswith('h700_')}
    hj, ha = device_binding('H700', h)
    sj, sa = device_binding('SM8550', sm)
    v = {k.removeprefix('vm_'): value for k, value in known.items() if k.startswith('vm_')}
    vi, va, vr, mounts = (checked(v[k]) for k in ['inputs', 'artifact_inputs', 'result', 'mounts'])
    consumed(v, 'result')
    assert vi['commit'] == va['source'] == vr['source'] == COMMIT and vi['es_commit'] == va['es_commit'] == ES
    assert vi['checkout'] == str(VM_TREE) and vi['build_root'] == 'build.pixelelated-GENERIC_X64.x86_64'
    assert va['build_inputs_sha256'] == v['inputs']['sha256'] and vr['status'] == 'PASS'
    assert mounts['workdir'] == vi['container_checkout']
    assert sum(m['Source'] == SOURCE_CACHE and m['Destination'] == vi['container_checkout'] + '/sources' for m in mounts['mounts']) == 1
    assert vr['build_closeout'] == va['build_closeout']
    close = vr['build_closeout']
    assert close['completion_disposition'] == 'failed-investigated/reporting-failure'
    assert close['qualification'] is False and close['original_launcher_returncode'] is None
    return {'H700': (hj, ha), 'SM8550': (sj, sa), 'GENERIC_X64': (vi, va)}

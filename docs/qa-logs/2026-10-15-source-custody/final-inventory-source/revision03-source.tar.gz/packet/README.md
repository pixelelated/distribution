# Final inventory signal mask and mixed-source binding — SOURCE ONLY / UNRUN

This additive revision preserves the original485b9937 packet and lifecycle revision02 seal `6a57502a9a97d0d9fa6049cc730aa841565a0cbd903f0af58dd2c27d2bd3970c` unchanged. `revision02-originals/` retains the latter seal, manifest and review text. `revision03.diff` is the complete five-file executable delta from revision02. Earlier `lifecycle.diff`, source checks and review records remain historical evidence, not current runtime results.

Root's finite review of revision02 found that a child inherits the parent's blocked signal mask across exec. This revision corrects that specific follow-up and implements the assigned #600 per-device source binding. No candidate helper, preparer, collector, test, cache scan, firmware read, admission action, network action or runtime has executed.

## Child signal custody

The runner retains its SIGTERM/SIGINT mask around spawn and active-child registration. Immediately before spawn it requires exactly the current main thread in `/proc/self/task`; this single-threaded runner creates no threads. It refuses an inherited mask that already blocks TERM/INT. The child-only `preexec_fn` performs only `signal.pthread_sigmask(SIG_SETMASK, previous_mask)`, restoring the original unblocked termination mask before exec. It performs no file access, imports, locks, process inspection or receipt writes. This is deliberately limited to the enforced single-threaded runner; it is not a reusable recommendation for threaded applications. Parent restoration remains in `finally`, after registration.

All runner wait, cleanup and publication functions are AST-identical to revision02. The qualified PID/start-ticks/pidfd helper, original child-wait retention, adopted-child cleanup and nonqualified interruption/error handling are unchanged. `run.sh` is byte-identical: its original outer timeout status, including124, remains separate from Python's inner status. Fatal SIGKILL can prevent final receipts; neither missing receipts nor unknown custody may qualify.

## Exact engineering sources

| Profiles | Exact source | Frozen checkout |
| --- | --- | --- |
| GENERIC_X64 x86_64 | `f8636de1d105275dbf9420bbabbbc26f79abb10f` | `m7-p5-build-20261015-02` |
| H700 ARM and AArch64 | `f8636de1d105275dbf9420bbabbbc26f79abb10f` | `m7-pixelelated-h700-04` |
| SM8550 ARM and AArch64 | `9aa7affee9d4ad5e69725cab20b6d7ad84d93dea` | `m7-pixelelated-sm8550-05` |

The registry, ordinary admission/consume tool and inventory command checkout remain GENERIC_X64 f863. The family is explicitly `mixed-engineering`, with `common_rc_identity: null`. This does not allocate or qualify a common RC identity.

The full tracked product scope remains `packages`, `projects`, `config`, `scripts`, `distributions`, `Makefile`, `LICENSE.md` and `TRADEMARK.md`. Its complete commit-to-commit diff must contain exactly `projects/ROCKNIX/packages/tools/rocknix-abl/package.mk`. Both mode100644 and fixed Git blob IDs are checked. The new blob must equal the entire old blob with only the single exact `PKG_SHA256` line changed from `4fcf983aff6af152fb5d7d0ef1a31727d64ecb93b2d75e202efeea5c5d4b565d` to `64034fb076ea0bb858beaa2f29dbef635e97d29f3e3d32c13bce61bd4af4cff7`. There is no excluded-path or wildcard allowance.

Preparation derives each complete source map from that device's exact Git tree, checks current source bytes/modes/links and compares the full accepted original map. VM/H700 maps must remain identical. SM must have the same file membership and symlinks, with exactly the ABL file hash differing and both hashes matched to those exact Git blobs. Acceptance consumption, input/output receipts, each profile's inputs, runner rows and both collector reports carry and check their device's exact commit. Original collectors are unchanged.

`revision03-references/` retains the two recipe blobs and complete product diff/name list read from Git objects. This is source evidence, not SM build or artifact acceptance. Earlier producer failures and VM reporting-failure limitations remain intact.

## Execution dependency and commands

**Do not allocate until actual successful SM acceptance and ordinary consumption exist.** `sm-final.template.json` intentionally retains all seven path/hash pairs as null: `inputs`, `acceptance`, `completion`, `consumed`, `output`, `arm`, `bundle`. Root must construct a separate final-binding JSON from actual immutable accepted receipts and supply its exact hash. No future receipt paths or hashes are invented here.

Root retains the existing reviewed sequence in `commands.sh`: `prepare`, inspect fresh capacity/retention, `run`, supervise original channels at no more than60-second intervals, then `consume`. `TASK_SM_FINAL` and `TASK_SM_FINAL_SHA256` are required for preparation. `TASK_OWNER` defaults to the unchanged fresh `/workspace/tmp/pix-m7-final-inventory-20261015-01`; preparation refuses an existing owner. The ordinary frozen f863 tool must prepare and consume its own admission. No #597 reporting-failure recovery or launcher-success fallback is introduced.

All resource bounds, publication holds, known accepted VM/H700 references and the unresolved SM receipt template are unchanged. A successful future inventory would qualify five post-build metadata inventories only. It would not establish source custody, notice completeness, retrieval, off-host recovery, physical device proof, publication permission or release readiness.

## Source-only review

`revision03-static.stdout` records133 passing source checks: Python3.10 AST parsing, `bash -n`, unchanged original seals/payloads, unchanged lifecycle functions and collectors, exact mask callback and single-thread guard, retained exact Git blobs and source-delta assertions, per-device receipt checks, frozen control identity and unresolved SM receipt template. Stderr is empty. `revision03-static-execution.json` records the observed tool exit0, explicitly as a post-completion transcription rather than a launcher receipt. No candidate was imported or executed.

Root's finite source read of executable diff `5a80d844facbba9bda2853efed64922810ee7298a61284099f8b518713319999` found no new finding before this seal. Allocation remains root-owned and conditional on actual SM evidence. The earlier readiness proposals and sealed audit remain untouched.

#!/usr/bin/env python3
"""Source parsing/equality only. Never import or execute a candidate helper."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

P=Path(__file__).resolve().parent
OLD=Path('/tmp/pix-m7-final-inventory-review-20261015-02')
BASE='f8636de1d105275dbf9420bbabbbc26f79abb10f'
SM='9aa7affee9d4ad5e69725cab20b6d7ad84d93dea'
checks=[]
def check(value,label):
    assert value,label
    checks.append(label)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(n): return ast.parse((P/n).read_text(),filename=n,feature_version=(3,10))
def segment(n,name):
    s=(P/n).read_text();t=ast.parse(s)
    return ast.get_source_segment(s,next(v for v in t.body if isinstance(v,(ast.FunctionDef,ast.AsyncFunctionDef)) and v.name==name))
def dump(s):return ast.dump(ast.parse(s),include_attributes=False)
def assignment(n,key):
    return next(v.value for v in parse(n).body if isinstance(v,ast.Assign) and any(isinstance(t,ast.Name) and t.id==key for t in v.targets))
check(sha(OLD/'SHA256SUMS')=='6a57502a9a97d0d9fa6049cc730aa841565a0cbd903f0af58dd2c27d2bd3970c','original revision02 seal unchanged')
for line in (OLD/'SHA256SUMS').read_text().splitlines():
    h,n=line.split('  ',1);check(sha(OLD/n)==h,'revision02 original '+n)
check((P/'revision02-originals/SHA256SUMS').read_bytes()==(OLD/'SHA256SUMS').read_bytes(),'retained original seal exact')
for n in ['templates/process-identity.py','templates/run.sh','templates/source-inventory.py','templates/component-map.py','resources.json','publication-holds.json','known-bindings.json','sm-final.template.json','frozen-tools.json']:
    check((P/n).read_bytes()==(OLD/n).read_bytes(),'unchanged '+n)
for f in sorted(P.rglob('*.py')):
    ast.parse(f.read_text(),filename=str(f),feature_version=(3,10));checks.append('Python3.10 AST '+str(f.relative_to(P)))
for n in ['commands.sh','templates/run.sh']:
    r=subprocess.run(['bash','-n',str(P/n)],capture_output=True)
    check(r.returncode==0 and not r.stdout and not r.stderr,'bash-n '+n)
# Every original runner function is unchanged: wait/cleanup/publication mechanisms.
oldsource=(OLD/'templates/run.py').read_text()
for v in ast.parse(oldsource).body:
    if isinstance(v,ast.FunctionDef):
        check(dump(segment('templates/run.py',v.name))==dump(ast.get_source_segment(oldsource,v)),'runner function unchanged '+v.name)
for name in ['sha','load','checked','git','host_and_serialization']:
    s=(OLD/'templates/bindings.py').read_text();v=next(v for v in ast.parse(s).body if isinstance(v,ast.FunctionDef) and v.name==name)
    check(dump(segment('templates/bindings.py',name))==dump(ast.get_source_segment(s,v)),'binding helper unchanged '+name)
run=(P/'templates/run.py').read_text();rt=parse('templates/run.py')
spawns=[v for v in ast.walk(rt) if isinstance(v,ast.Call) and isinstance(v.func,ast.Attribute) and isinstance(v.func.value,ast.Name) and v.func.value.id=='subprocess' and v.func.attr=='Popen']
check(len(spawns)==1,'one existing direct Popen site')
callback=next(k.value for k in spawns[0].keywords if k.arg=='preexec_fn')
check(ast.dump(callback,include_attributes=False)==ast.dump(ast.parse('lambda: signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)',mode='eval').body,include_attributes=False),'child callback only restores original mask')
check("assert sorted(t.name for t in Path('/proc/self/task').iterdir()) == [str(os.getpid())]" in run,'single-threaded kernel task assertion')
check("assert not previous_mask.intersection({signal.SIGTERM, signal.SIGINT})" in run,'already blocked original termination mask refuses')
check("finally:\n                    signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)" in run,'parent restores original mask in finally')
check(run.index('previous_mask = signal.pthread_sigmask')<run.index('proc = subprocess.Popen')<run.index('active = dict(proc=proc')<run.index('identities[(proc.pid,')<run.index('signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)\n                write'),'parent registration remains inside protected window')
check(ast.literal_eval(assignment('templates/bindings.py','COMMIT'))==BASE,'runtime control commit remains f863')
dev=assignment('templates/bindings.py','DEVICE_COMMITS')
check(ast.dump(dev,include_attributes=False)==ast.dump(ast.parse("{'GENERIC_X64': COMMIT, 'H700': COMMIT, 'SM8550': '"+SM+"'}",mode='eval').body,include_attributes=False),'exact per-device source map')
check("'SM8550': Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-sm8550-05')" in (P/'templates/bindings.py').read_text(),'exact SM05 tree')
check("'H700': Path('/workspace/repos/rocknix.worktrees/m7-pixelelated-h700-04')" in (P/'templates/bindings.py').read_text(),'unchanged H70004 tree')
abl=ast.literal_eval(assignment('templates/bindings.py','ABL_PATH'))
before=(P/'revision03-references/f863-rocknix-abl-package.mk').read_bytes()
after=(P/'revision03-references/9aa7-rocknix-abl-package.mk').read_bytes()
old=ast.literal_eval(assignment('templates/bindings.py','ABL_OLD'));new=ast.literal_eval(assignment('templates/bindings.py','ABL_NEW'))
check(before.count(old)==1 and before.count(new)==0 and before.replace(old,new,1)==after,'retained exact sole checksum replacement')
check((P/'revision03-references/full-product-names.bin').read_bytes()==abl.encode()+b'\0','retained full product diff has exactly one path')
for data,wanted in [(before,'d8bc42f348013aa1698590be6caa13e7aedfcc5d'),(after,'24d9b38a2dcb62d78ce632ea26c7bd80eafe54c9')]:
    check(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==wanted,'exact retained Git blob '+wanted)
delta=segment('templates/bindings.py','product_delta')
for text,label in [("'--name-only', '-z', COMMIT, sm_commit, '--', *PRODUCT",'runtime full product Git diff'),("names == os.fsencode(ABL_PATH)+b'\\0'",'exact sole path assertion'),("'100644 blob '+oid",'exact mode and Git blob assertion'),("after == before.replace(ABL_OLD, ABL_NEW, 1)",'exact checksum-only source assertion')]:
    check(text in delta,label)
relation=segment('templates/bindings.py','source_relationship')
for text,label in [("sources['GENERIC_X64'] == sources['H700']",'VM/H700 exact map equality'),('base_links == sm_links and base_files.keys() == sm_files.keys()','same exact map membership and all symlinks'),("sorted(n for n in base_files if base_files[n] != sm_files[n]) == [ABL_PATH]",'all source map hash differences exactly ABL'),("base_files[ABL_PATH] == delta['old_source_sha256']",'baseline source hash bound'),("sm_files[ABL_PATH] == delta['new_source_sha256']",'SM source hash bound')]:check(text in relation,label)
check("tree, commit = DEVICE_TREES[device], DEVICE_COMMITS[device]" in segment('templates/bindings.py','source_manifest'),'per-device exact current Git/source manifest')
check("c['source']['head'] == expected_commit" in segment('templates/bindings.py','consumed'),'prior acceptance consumption commit bound')
check("consumed(refs, 'acceptance', commit)" in segment('templates/bindings.py','device_binding'),'device-specific consumption expected commit')
check("consumed(v, 'result', DEVICE_COMMITS['GENERIC_X64'])" in segment('templates/bindings.py','all_bindings'),'VM consumption stays f863')
prep=(P/'prepare-owner.py').read_text();consumer=(P/'templates/consume.py').read_text()
check("delta = B['source_relationship'](sources)" in prep,'preparer verifies complete source relationship')
check("'distribution_commit': B['DEVICE_COMMITS'][device]" in prep,'profile inputs and profiles carry exact expected commit')
check("assert p['distribution_commit'] == inputs['distribution_commit'] == expected_commit" in run,'runner exact profile/input source')
check("report['distribution_commit'] == expected_commit" in run and "B['load'](d/'source-inventory.json')['distribution_commit'] == expected_commit" in run,'both original collector outputs source checked')
check("row['distribution_commit'] == B['DEVICE_COMMITS'][device]" in consumer,'consumer source expected per profile')
check("load(d/name)['distribution_commit'] == B['DEVICE_COMMITS'][device]" in consumer,'consumer original inputs/inventory/components source checks')
check("admission['source']['head'] == B['COMMIT']" in consumer,'ordinary inventory admission stays frozen f863')
check("source_family='mixed-engineering', common_rc_identity=None" in run,'result explicitly mixed engineering with no RC identity')
check("'source_family': 'mixed-engineering'" in prep and "'common_rc_identity': None" in prep,'binding explicitly mixed engineering with no RC identity')
check("result['source_family'] == 'mixed-engineering' and result['common_rc_identity'] is None" in consumer,'consumer enforces engineering label')
check(all(set(v)=={'path','sha256'} and v['path'] is None and v['sha256'] is None for v in json.loads((P/'sm-final.template.json').read_text()).values()),'SM receipt paths and hashes remain unresolved')
print(json.dumps({'status':'PASS_STATIC_ONLY','count':len(checks),'checks':checks,'candidate_imported_or_executed':False,'runtime_tests':False,'cache_scan':False,'source_binding':'Exact per-device source; final SM acceptance receipts still required'},indent=2))

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2021-present Xargon (https://github.com/XargonWan)
# Copyright (C) 2023 JELOS (https://github.com/JustEnoughLinuxOS)
# Copyright (C) 2025 ROCKNIX Team (https://github.com/ROCKNIX)

PKG_NAME="rclone"
PKG_VERSION="1.75.2"
# Primary project; embedded dependencies retain their own terms (#528).
PKG_LICENSE="MIT"
# Python3 is the interpreter for cloud_remote. A shipped script's tools are
# real dependencies even though nothing links against them: upstream deleted
# packages/compress/zip in a3d0ad0430, nothing referenced it, and backuptool
# lost its archiver silently for months.
# webkitgtk is here because cloud_oauth needs a browser on the device: a
# provider's OAuth redirect goes to localhost, so it only lands somewhere
# useful if the browser is on the same machine as rclone's authorize listener.
# glib-networking is what gives that browser TLS at all.
# jq is cloud_capture's only JSON reader and writer (the save manifest, #21);
# the same policy as Python3 above -- until now it reached the image only
# through virtual/image's own dependency list.
PKG_DEPENDS_TARGET="toolchain fuse rsync qrencode Python3 \
                    webkitgtk cloud-signin-window glib-networking jq"
PKG_LONGDESC="rsync for cloud storage"
PKG_TOOLCHAIN="manual"

# Pinned per arch, and pinned to OUR version.
#
# Upstream added PKG_SHA256 for 1.71.0 in e0a68c95bd while this fork is on
# 1.75.2, so a rebase would bring in a hash that cannot match what we download.
# Setting the right ones here makes that merge a no-op instead of a build
# failure whose message names a checksum and not the version behind it.
#
# Verified against downloads.rclone.org/v1.75.2/SHA256SUMS and independent
# archive hashing (#541). Image assembly strips the binary; installed version
# and protocol proof are recorded separately.
case ${ARCH} in
    aarch64)
      RCLONE_ARCH="arm64"
      PKG_SHA256="7e1e8d69654941b7b7df84ee74c5f7fb09cce7d5496947fb7bf16b55ff427d10"
    ;;
    *)
      RCLONE_ARCH="amd64"
      PKG_SHA256="349ac8fba6ff65d6247043f1750cdcb518ec5d500ef91463a10d37c0ccdf3702"
    ;;
esac

PKG_URL="https://downloads.rclone.org/v${PKG_VERSION}/rclone-v${PKG_VERSION}-linux-${RCLONE_ARCH}.zip"
PKG_RCLONE="rclone-v${PKG_VERSION}-linux-${RCLONE_ARCH}/rclone"

unpack() {
  # Create build directory
  mkdir -p ${PKG_BUILD}
  # Rename the downloaded zip to include architecture for better tracking
  mv ${SOURCES}/rclone/rclone-${PKG_VERSION}.zip ${SOURCES}/rclone/rclone-${PKG_VERSION}-${RCLONE_ARCH}.zip
  # Extract the binary package to the build directory
  unzip ${SOURCES}/rclone/rclone-${PKG_VERSION}-${RCLONE_ARCH}.zip -d ${PKG_BUILD}/
  # Remove downloaded zip files to conserve space
  rm -f ${SOURCES}/rclone/rclone-${PKG_VERSION}*
}

makeinstall_target() {
  mkdir -p ${INSTALL}/usr/bin/
  mkdir -p ${INSTALL}/usr/config/
  cp cloud_backup ${INSTALL}/usr/bin/
  cp cloud_restore ${INSTALL}/usr/bin/
  cp cloud_sync_helper ${INSTALL}/usr/bin/
  cp cloud_setup ${INSTALL}/usr/bin/
  cp cloud_folder_validate ${INSTALL}/usr/bin/
  cp cloud_remote ${INSTALL}/usr/bin/
  cp cloud_connections.py ${INSTALL}/usr/bin/
  cp cloud_device_id ${INSTALL}/usr/bin/
  cp cloud_oauth ${INSTALL}/usr/bin/
  cp cloud_content_restore ${INSTALL}/usr/bin/
  cp cloud_content_backup ${INSTALL}/usr/bin/
  cp cloud_content_transfer ${INSTALL}/usr/bin/
  cp cloud_sync_cleanup_duplicates.sh ${INSTALL}/usr/bin/
  cp cloud_saves_root ${INSTALL}/usr/bin/
  cp cloud_capture ${INSTALL}/usr/bin/
  # cloud_log_scrub: once per device, masks the credentials earlier builds
  # wrote into cloud_sync.log and the interface's es_log*.txt (the audit of
  # the fix round, PL-014); run at boot by autostart/102-cloud-saves.
  cp cloud_log_scrub ${INSTALL}/usr/bin/
  # cloud_net_ready: what EmulationStation's startup sync asks before it runs
  # the restore/backup pair -- is the network up, and has it stayed up (#103).
  cp cloud_net_ready ${INSTALL}/usr/bin/
  # cloud_scan: the restore flow's scan page runs it first and offers only
  # what it found (D-CLOUD-156, fork #350); reads under a parent-held lock.
  cp cloud_scan ${INSTALL}/usr/bin/
  cp rasteratops-settings-archive ${INSTALL}/usr/bin/
  # No game-end event hook. EmulationStation runs the save sync itself now
  # (FileData::launchGame), so it can show the result on the progress card
  # instead of backgrounding the work into /dev/null where nobody could tell
  # whether it had happened. The hook had no caller but ES, and leaving it
  # installed would start a second concurrent cloud_backup on the same remote.
  cp ${PKG_BUILD}/${PKG_RCLONE} ${INSTALL}/usr/bin/
  chmod 0755 ${INSTALL}/usr/bin/*
  cp cloud_sync-rules.txt ${INSTALL}/usr/config/
  cp cloud_sync.conf ${INSTALL}/usr/config/
  cp cloud_sync.conf.defaults ${INSTALL}/usr/config/
  cp cloud_sync-rules.txt.defaults ${INSTALL}/usr/config/
  chmod 755 ${INSTALL}/usr/bin/rclone
  # No TOOLS entries for cloud backup and restore.
  #
  # These symlinked the scripts into the tools list, so running one dropped
  # the player into a fullscreen console. That was the parity stopgap while
  # cloud sync had no native surface; EmulationStation now has the whole flow
  # -- direction, the three data classes, progress and the last result -- so
  # the console route is a second, worse way to do the same thing, and two
  # paths to one operation is how somebody ends up with a backup missing what
  # they assumed was in it.
}

# ZeroTier02 reader-only completion proposal — revision02 SOURCE ONLY, UNRUN

The original normal recipe completed with exit0 in 33.652 seconds. The following
reader exited1 because it assumed every ext/libnatpmp dependency file used that
subdirectory as its working directory. Original run `20261015T151203Z-e2399d5a`
remains failed (command/monitor/runner1/0/1), ordinarily consumed under
`b4f1025d4ecb491088316269b99386f0`. Its failure investigation, acceptance,
consumption, stage and watched receipts are retained by exact bytes and hashes.
The candidate source and patch are unchanged. No revision02 proof has executed.

The completed source is exactly:
`/workspace/tmp/pix-m7-zerotier-compile-20261015-02/work/source`.
Its already linked zerotier-one is 2,180,776 bytes, SHA256
`dd84354af5a6ea19e694845d0edfa0f9743f6176c5ddca5389bee82b1bbb96a8`.
This preparation passively hashed that named file as data; it did not execute it.

## Exact correction and source delta

The original recipe stdout has91 explicit C/C++ compile commands and89 final
objects. Lines2–5 compile libnatpmp objects inside `/work/source/ext/libnatpmp`.
After that make returns, lines120–121 compile natpmp/getgateway again from
`/work/source`, replacing those objects and dependency files. Therefore:

| Dependency file | Last target argument | Exact compiler cwd |
| --- | --- | --- |
| ext/libnatpmp/getgateway.d | ext/libnatpmp/getgateway.o | /work/source |
| ext/libnatpmp/natpmp.d | ext/libnatpmp/natpmp.o | /work/source |
| ext/libnatpmp/natpmpc.d | natpmpc.o | /work/source/ext/libnatpmp |
| ext/libnatpmp/testgetgateway.d | testgetgateway.o | /work/source/ext/libnatpmp |

`dependency-context.json` retains all91 commands and their exact stdout line
numbers, plus the last command for each of89 objects. Its named89 dependency
files total6,585,633 bytes; each was passively read as text and matched to its
last command's exact target and first source prerequisite. Each file is bound
by size and SHA256. This is source preparation, not executed reader acceptance.

The new reader requires that exact dependency-file and object set, validates
each target/source pair, then resolves prerequisites relative to the sealed
command cwd. There is no path-existence fallback. It retains the original89
raw dependency files and the mapping used. Duplicate dependency spellings are
hashed once before the existing final rehash, avoiding repeated header I/O.
The original source-before manifest, source/link identities, ELF/CLI-link checks
and nonfree/outside-root refusals remain. The extraction function is removed.
`reader-only.diff` gives the complete eight-file operational delta from02.
In this revision, `docker_owner.py` corrects only its expected memory value
from4 GiB to1 GiB. `watchdog.py`, OneService.cpp and candidate.patch remain
byte-identical. No new lifecycle or synthetic fixture framework was introduced.

## One read-only container stage

Use the same already qualified cached image, without pulling:
`ghcr.io/pixelelated/build@sha256:988c0ba586263caeba4be4c03bd16eee055c9d066657951e320087bb8226ee39`.
Only the completed source and frozen toolchain are added as read-only input
mounts, with the original generated toolchain prefix preserved. Plan/runner are
read-only; only fresh owner work/tmp and stage receipts are writable. The source
archive, package configuration and recipe are not execution inputs.

The only container child commands are:

```text
/usr/bin/python3 -I -S -B /runner/source-inputs.py verify
/workspace/repos/rocknix.worktrees/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/bin/x86_64-rocknix-linux-gnu-readelf -h -d /work/source/zerotier-one
```

No compiler, make, extraction, rebuild, source script or target executable is
called. `readelf` inspects the existing artifact as data. Both commands, their
original exits and outputs must complete successfully for a new reader PASS.
The old combined failure is neither rewritten nor promoted to success.

The admitted work clock is60 seconds including input checks and reader/readelf.
The reused independent watchdog and exact-CID/PID lifecycle enforce it. Existing
bounded cleanup calls and watchdog wait remain unchanged; reserve600 seconds
for cleanup separately. This is not a claim of a60-second total cleanup bound.
Container limits:2 CPUs,1 GiB RAM with no swap,256 PIDs, network none, read-only
root, all capabilities dropped and no-new-privileges. Record actual cgroup,
host resource, child RSS, wall time and original process/container outcomes.

New owner scratch has a64 MiB sampled ceiling and512 MiB host-free floor;
/tmp is a64 MiB tmpfs. Child output files are limited to16 MiB, with receipt JSON
size checked before write. Named digest reads cap at3 GiB and128 MiB per input;
unique consumed dependencies cap below1 GiB/10,000 entries before hashing.
The known raw dependency copies consume6.6 MB; the remaining scratch allowance
covers context/dependency JSON and original lifecycle telemetry. Sampled owner
storage remains a forecast, not a filesystem quota. The original completed
source is mounted read-only and is excluded from new scratch accounting.

## Root commands, after independent review and exclusive allocation

Fresh default owner: `/workspace/tmp/pix-m7-zerotier-readback-20261015-02`.
Existing owners are refused. Preparation checks the consumed original failure,
completed source-root identity and all named input hashes. Root inspects each
original result before proceeding; no submission is a completion receipt.

```bash
TASK_PACKET=/tmp/pix-m7-zerotier-readback-plan-20261015-02
bash "$TASK_PACKET/commands.sh" prepare
bash "$TASK_PACKET/commands.sh" preflight
bash "$TASK_PACKET/commands.sh" report
bash "$TASK_PACKET/commands.sh" admit
bash "$TASK_PACKET/commands.sh" launch
# Supervise through original runner/container/watchdog/launcher completion.
bash "$TASK_PACKET/commands.sh" completion
bash "$TASK_PACKET/commands.sh" consume
```

`static-review.json` records only syntax, exact source reuse, two-child scope,
read-only mount selection and original binding checks; no candidate module was
imported, control run executed, owner prepared or container started here.
This packet does not change the product candidate, original compile output,
shared records or publication state. A future PASS adds dependency/artifact
readback to the already successful selected GENERIC_X64 recipe; it does not
claim target runtime behavior, ARM compatibility, firmware identity or legal
and publication clearance.

## Revision02: correct the inspector memory expectation

Reader01 run `20261015T153108Z-9f9cdb27` failed before either reader child
started. The container requested1 GiB and the inner check expected1 GiB, but
DockerOwner.inspect still required4 GiB. The same mismatch refused normal
cleanup and watchdog cleanup. Original command/monitor/runner1/0/1, attach0
after forced client stop, watchdog1 and cleanupFAIL are preserved. Root
separately removed only the exact stopped container, verified absence and
original process identities, and consumed failure
`8a82b1f0f75d48ef8d5609d54210a7db`. The successful compile output remains intact.

`revision02.diff` changes three operational files only: DockerOwner's one memory
constant, fresh02 command/owner handoff and exact prior-failure input bindings.
`source-inputs.py`, `inner.py`, `run-stage.py`, `common.py`, `watchdog.py`,
`plan.py`, completion checks, dependency map and candidate bytes are unchanged.
`predecessor/` preserves01 source seal/manifest/static observation;
`reader-only.diff` remains the original compile02-to-reader01 delta.
The new static review confirms all three memory expectations agree at1 GiB.
No new lifecycle, fixture, control run, compiler or extraction step is added.

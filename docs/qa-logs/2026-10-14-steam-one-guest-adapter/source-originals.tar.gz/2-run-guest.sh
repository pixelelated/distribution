#!/bin/sh
set -eu
mkdir /tmp/pix-output/steam
mkdir /run/pix582-scratch
mount -t tmpfs -o size=3G,mode=700,nosuid,nodev tmpfs /run/pix582-scratch
set +e
cat /proc/self/mountinfo > /tmp/pix-output/steam/guest-mountinfo.txt
cat /proc/self/cgroup > /tmp/pix-output/steam/guest-self-cgroup.txt
cat /proc/cmdline > /tmp/pix-output/steam/guest-cmdline.txt
ls -la /sys/fs/cgroup > /tmp/pix-output/steam/guest-cgroup-layout.txt
systemctl --version > /tmp/pix-output/steam/guest-systemd-version.txt
timeout --signal=TERM --kill-after=2s 5s python3 -I -S -B /tmp/pix-input/fsize-control.py > /tmp/pix-output/steam/fsize-control.stdout 2> /tmp/pix-output/steam/fsize-control.stderr
control_rc=$?
printf '%s\n' "$control_rc" > /tmp/pix-output/steam/fsize-control.rc
TMPDIR=/run/pix582-scratch timeout --signal=TERM --kill-after=10s 120s python3 -I -S -B /tmp/pix-input/docs/qa-logs/2026-10-14-steam-crc-event-source/fixture.py --disposable-vm --case crc-failure-retry --installer '/tmp/pix-input/projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh' --output /run/pix582-scratch/crc-failure-retry-events-11 > /tmp/pix-output/steam/stdout 2> /tmp/pix-output/steam/stderr
pxrc=$?
printf '%s\n' "$pxrc" > /tmp/pix-output/steam/original.rc
set -e
if test -d /run/pix582-scratch/crc-failure-retry-events-11; then
  tar -czf /tmp/pix-output/steam/fixture-records.tar.gz --exclude='crc-failure-retry-events-11/rootfs' --exclude='crc-failure-retry-events-11/storage' --exclude='crc-failure-retry-events-11/tmp' --exclude='crc-failure-retry-events-11/qa/payloads' -C /run/pix582-scratch crc-failure-retry-events-11
fi
sync
umount /run/pix582-scratch
printf 'PIX582_CALLER_RC:%s\n' "$pxrc"
test "$pxrc" -eq 0
test "$control_rc" -eq 0

set -eu
python3 -I -S -B /tmp/pix-input/provision.py

#!/usr/bin/python3
"""Recording-only synthetic engine/controller/achievement/OS-hook seam."""
import json
import os
from pathlib import Path
import sys

root = Path('/tmp/pix581-flow/active')
name = Path(sys.argv[0]).name
with (root / 'stubs.jsonl').open('a') as stream:
    stream.write(json.dumps({'name': name, 'argv': sys.argv[1:], 'pid': os.getpid()}) + '\n')
if name in ('dolphin-emu', 'dolphin-emu-nogui'):
    # A text marker only; never feed its bytes to an emulator.
    expected = '/storage/roms/qa581/synthetic.iso'
    if '-e' not in sys.argv or sys.argv[sys.argv.index('-e') + 1:] != [expected]:
        sys.exit(91)
    if Path(expected).read_bytes() != b'NOT A ROM: synthetic #581 launch witness\n':
        sys.exit(92)
elif name not in ('control-gen_init.sh', 'game-guides-tool', 'cheevos_dolphin.sh',
                  'serial_number_check', 'cloud_capture'):
    sys.exit(93)
sys.exit(0)

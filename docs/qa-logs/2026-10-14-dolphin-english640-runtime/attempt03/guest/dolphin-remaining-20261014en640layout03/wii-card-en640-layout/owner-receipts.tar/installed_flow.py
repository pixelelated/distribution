#!/usr/bin/python3
"""UNRUN: #581 source-staged full callers/native ES boundary, disposable VM only.

prepare validates recipe-staged source and genuine defaults before a new /tmp
owner. run owns one bounded private namespace. invoke is the synthetic catalog's return-code witness.
No product module is imported, rewritten, sliced, or evaluated by this harness.
"""
import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import stat
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
LIVE = Path('/tmp/pix581-flow')
SYSTEMS = ('gamecube', 'wii')
CASES = ('fresh', 'known-link', 'retained-state', 'card-conflict', 'busy')
PRODUCT = ('runemu.sh', 'start_dolphin_gc.sh', 'start_dolphin_wii.sh', 'dolphin-save-paths')
# /bin must be the image's /usr/bin alias. No inherited OS scripts survive this
# allowlist; the normal caller tools remain real guest executables.
UTILITIES = ('bash', 'sh', 'python3', 'cat', 'cp', 'mv', 'rm', 'mkdir', 'sed', 'awk',
             'grep', 'cut', 'tr', 'basename', 'dirname', 'date', 'mktemp', 'tee', 'true')
STUBS = ('dolphin-emu', 'dolphin-emu-nogui', 'control-gen_init.sh', 'game-guides-tool',
         'cheevos_dolphin.sh', 'serial_number_check', 'cloud_capture')
REQUIRED_DEFAULTS = ('Dolphin.ini', 'GFX.ini', 'Hotkeys.ini', 'GameSettings',
                     'GamecubeControllerProfiles/GCPadNew.ini.south.stacked',
                     'WiiControllerProfiles/vremote.ini', 'triforce_gecko_codes',
                     'GC/dsp_coef.bin', 'GC/dsp_rom.bin', 'GC/font-licenses.txt',
                     'GC/font_japanese.bin', 'GC/font_western.bin')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    path = Path(path)
    pending = path.with_name(path.name + '.pending')
    pending.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    pending.replace(path)


def ns_identity():
    return {key: os.readlink('/proc/self/ns/' + key) for key in ('mnt', 'net', 'pid')}


def source_bytes(repo, renderer):
    binding = json.loads((HERE / 'source.json').read_text())
    result = {}
    for relative, expected in binding['distribution_files'].items():
        path = repo / relative
        require(sha(path) == expected, 'source binding mismatch: ' + relative)
        if path.name not in PRODUCT:
            continue
        data = path.read_bytes()
        if path.name.startswith('start_dolphin_'):
            for a, b in ((b'@DOLPHIN_BACKEND@', b'wayland'),
                         (b'@GRENDERER@', renderer.encode()),
                         (b'@EXPORTS@', b'export QT_QPA_PLATFORM=wayland')):
                data = data.replace(a, b)
        result[path.name] = data
    require(set(result) == set(PRODUCT), 'incomplete product binding')
    return result


def product_check(root, expected):
    receipt = {}
    for name, data in expected.items():
        path = root / name
        require(stat.S_ISREG(path.lstat().st_mode) and os.access(path, os.X_OK),
                'missing regular executable: ' + str(path))
        require(path.read_bytes() == data, 'recipe bytes differ: ' + str(path))
        receipt[name] = sha(path)
    return receipt


def stage_products(args):
    # Preparation only: complete source files plus the recipe's three literal
    # substitutions. No shell evaluation, imports, build or guest installation.
    expected = source_bytes(args.repo, args.renderer)
    require(not os.path.lexists(args.output), 'product stage already exists')
    args.output.mkdir(mode=0o700)
    for name, data in expected.items():
        path = args.output / name
        path.write_bytes(data)
        path.chmod(0o755)
    write_json(args.output / 'recipe-staged.json', {
        'qualification':'source-staged caller proof; not shipped-image qualification',
        'renderer':args.renderer, 'files':product_check(args.output, expected)})
    print('STAGED ' + str(args.output))


def defaults_check(root, receipt_path, binding_path=None):
    binding = json.loads((binding_path or HERE / 'source.json').read_text())['packaged_defaults']
    require(sha(receipt_path) == binding['receipt_sha256'], 'unrecognized defaults receipt')
    receipt = json.loads(receipt_path.read_text())
    require(receipt['content_equal'] is True and receipt['entries'] == binding['entries']
            and receipt['bytes'] == binding['bytes']
            and receipt['archive_sha256'] == binding['archive_sha256'], 'defaults provenance mismatch')
    expected = receipt['files']
    require(len(expected) == binding['entries'] and len(expected) <= 10000,
            'defaults manifest count mismatch')
    require(stat.S_ISDIR(root.lstat().st_mode), 'defaults root must be a real directory')
    found = set()
    total = 0
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            path = Path(parent) / name
            relative = str(path.relative_to(root))
            require(relative in expected, 'unexpected defaults entry: ' + relative)
            item = expected[relative]
            info = path.lstat()
            require(stat.S_IMODE(info.st_mode) == item['mode'], 'defaults image mode mismatch: ' + relative)
            if item.get('directory') is True:
                require(stat.S_ISDIR(info.st_mode), 'defaults directory type mismatch: ' + relative)
            else:
                require(stat.S_ISREG(info.st_mode), 'defaults file type mismatch: ' + relative)
                total += info.st_size
                require(total <= 128 * 1024 * 1024 and info.st_size == item['bytes'],
                        'defaults file size mismatch: ' + relative)
                require(sha(path) == item['sha256'], 'defaults content mismatch: ' + relative)
            found.add(relative)
    require(found == set(expected) and total == binding['bytes'], 'incomplete defaults tree')
    # Root mode is not part of the supplied receipt; all 2734 descendants are.
    return {'receipt_sha256':binding['receipt_sha256'], 'entries':len(found), 'bytes':total,
            'modes':'actual staged-image modes; 22 package/image differences retained',
            'status':'PASS'}


def prepare(args):
    require(args.disposable_vm, 'explicit --disposable-vm acknowledgement required')
    require(os.geteuid() == 0, 'guest root required')
    require(re.fullmatch(r'/tmp/pix581-installed-[A-Za-z0-9_-]+', str(args.owner)), 'new /tmp owner required')
    require(not args.owner.exists(), 'owner already exists; never reuse a run')
    require(Path('/bin').resolve() == Path('/usr/bin'), 'requires image /bin -> /usr/bin layout')
    require(Path('/var/run').resolve() == Path('/run'), 'requires image /var/run -> /run layout')
    require(re.fullmatch('[0-9a-f]{40}', args.es_source), 'full coordinator ES source commit required')
    require(re.fullmatch('[0-9a-f]{64}', args.es_sha256), 'coordinator ES binary SHA256 required')
    expected = source_bytes(args.repo, args.renderer)
    for path in (args.product_root, args.defaults_root, args.defaults_receipt):
        require(path.is_absolute() and path.resolve() == path and str(path).startswith('/tmp/'),
                'explicit private /tmp staging path required: ' + str(path))
    products = product_check(args.product_root, expected)
    defaults = args.defaults_root
    defaults_receipt = defaults_check(defaults, args.defaults_receipt)
    require(sha('/usr/bin/emulationstation') == args.es_sha256, 'ES binary does not match coordinator receipt')
    require(stat.S_ISSOCK(args.wayland_socket.stat().st_mode), 'live coordinator Wayland socket required')
    for name in (*UTILITIES, 'unshare', 'emulationstation'):
        require(os.access('/usr/bin/' + name, os.X_OK), 'missing guest utility: ' + name)
    for relative in REQUIRED_DEFAULTS:
        require((defaults / relative).exists(), 'missing packaged defaults: ' + relative)
    require(Path('/usr/config/emulationstation/resources').is_dir(), 'missing ES resources')
    require(Path('/usr/share/themes/es-theme-art-book-next/theme.xml').is_file(), 'missing packaged system theme')
    require(Path('/usr/config/locale/en_US.UTF-8/LC_CTYPE').is_file(), 'missing shipped en_US.UTF-8 locale')
    require(Path('/usr/config/locale/fr/LC_MESSAGES/emulationstation2.mo').is_file(),
            'missing packaged fr catalog (player language remains fr_FR)')
    # Shipped defaults, not retained player data. Reject unexpected managed trees.
    for relative in ('StateSaves', 'GC/EUR', 'GC/JAP', 'GC/USA'):
        require(not os.path.lexists(defaults / relative), 'unexpected managed tree in defaults: ' + relative)
    require(not list((defaults / 'GC').glob('MemoryCard*')), 'unexpected cards in packaged defaults')
    args.owner.mkdir(mode=0o700)
    for name in ('installed_flow.py', 'profile.sh', 'record-stub.py', 'source.json'):
        shutil.copyfile(HERE / name, args.owner / name)
    (args.owner / 'product').mkdir()
    for name, data in expected.items():
        (args.owner / 'product' / name).write_bytes(data)
        (args.owner / 'product' / name).chmod(0o755)
    shutil.copyfile(args.defaults_receipt, args.owner / 'defaults-receipt.json')
    config = {'product_commit': json.loads((HERE / 'source.json').read_text())['product_commit'],
              'qualification':'source-staged caller proof; not shipped-image qualification',
              'staged_products':products, 'product_root':str(args.product_root),
              'defaults_root':str(defaults), 'es_source_coordinator_asserted': args.es_source,
              'es_sha256': args.es_sha256, 'renderer': args.renderer,
              'wayland_socket': str(args.wayland_socket.resolve()), 'parent_ns': ns_identity(),
              'defaults': defaults_receipt, 'created': time.time(), 'runtime': 'UNRUN'}
    config['tools'] = {name:{'invocation_path':'/usr/bin/' + name,
                            'resolved_identity_path':str(Path('/usr/bin', name).resolve()),
                            'sha256':sha('/usr/bin/' + name)}
                       for name in (*UTILITIES, 'unshare', 'emulationstation')}
    config['frame_resources'] = {str(path):sha(path) for path in
        [Path('/usr/share/themes/es-theme-art-book-next/theme.xml'),
         Path('/usr/config/locale/fr/LC_MESSAGES/emulationstation2.mo')]}
    write_json(args.owner / 'owner.json', config)
    print('PREPARED ' + str(args.owner))


def snapshot(root):
    result = {}
    if not root.exists():
        return result
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(dirs + files):
            path = Path(parent) / name
            info = path.lstat()
            entry = {'mode': stat.S_IMODE(info.st_mode), 'inode': info.st_ino}
            if path.is_symlink():
                entry.update(kind='link', target=os.readlink(path))
            elif path.is_file():
                entry.update(kind='file', sha256=sha(path), size=info.st_size, mtime_ns=info.st_mtime_ns)
            else:
                require(path.is_dir(), 'unexpected synthetic storage object')
                entry['kind'] = 'directory'
            result[str(path.relative_to(root))] = entry
    return result


def put(path, data='Synthetic #581 protected data\n'):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)


def seed(active, system, case, language, defaults):
    storage = active / 'storage'
    for name in ('.config', '.local/share', 'roms', '.cache', '.config/emulationstation'):
        (storage / name).mkdir(parents=True, exist_ok=True)
    put(storage / '.config/gptokeyb/control.ini', "param_device='Synthetic QA controller'\n")
    put(storage / 'roms/qa581/synthetic.iso', 'NOT A ROM: synthetic #581 launch witness\n')
    put(storage / 'unrelated/protected.txt')
    conf = storage / '.config/dolphin-emu'
    gc = storage / 'roms/bios/GC'
    if case != 'fresh':
        shutil.copytree(defaults, conf, symlinks=True)
        for platform in SYSTEMS:
            put(storage / 'roms/savestates' / platform / 'protected.state', 'Synthetic ' + platform + ' state\n')
        for region in ('EUR', 'JAP', 'USA'):
            put(gc / region / 'protected.gci', 'Synthetic ' + region + ' directory card\n')
        put(gc / 'MemoryCardA.USA.raw', 'Synthetic canonical raw card\n')
        put(conf / 'Wii/title/protected-save', 'Synthetic retained Wii save\n')
        (conf / 'GC').mkdir(exist_ok=True)
        if case == 'retained-state':
            put(conf / 'StateSaves/protected.state', 'Synthetic retained private state\n')
        elif case == 'card-conflict':
            put(conf / 'GC/MemoryCardA.USA.raw', 'Different retained private card\n')
        else:
            other = 'wii' if system == 'gamecube' else 'gamecube'
            (conf / 'StateSaves').symlink_to('/storage/roms/savestates/' + other)
            for region in ('EUR', 'JAP', 'USA'):
                (conf / 'GC' / region).symlink_to('/storage/roms/bios/GC/' + region)
                for slot in ('A', 'B'):
                    name = 'MemoryCard' + slot + '.' + region + '.raw'
                    (conf / 'GC' / name).symlink_to('/storage/roms/bios/GC/' + name)
            (storage / '.local/share/dolphin-emu').symlink_to('/storage/.config/dolphin-emu')
    config = storage / '.config/emulationstation'
    # Minimal synthetic catalog. ES still resolves emulator/core metadata and
    # calls its real ProcessStartInfo / error reader. Only its command is a witness.
    xml = ET.Element('systemList')
    item = ET.SubElement(xml, 'system')
    for key, value in {'name': system, 'fullname': 'QA 581 ' + system,
                       'path': '/storage/roms/qa581', 'extension': '.iso',
                       'command': '/usr/bin/python3 -I -S -B /tmp/pix581-flow/installed_flow.py invoke %ROM% --emulator=%EMULATOR% --core=%CORE%',
                       'platform': system, 'theme': system}.items():
        ET.SubElement(item, key).text = value
    emu = ET.SubElement(ET.SubElement(item, 'emulators'), 'emulator', name='dolphin')
    ET.SubElement(ET.SubElement(emu, 'cores'), 'core', default='true').text = 'dolphin-sa'
    ET.ElementTree(xml).write(config / 'es_systems.cfg', encoding='utf-8', xml_declaration=True)
    keys = {'a':120, 'b':122, 'up':1073741906, 'down':1073741905, 'left':1073741904,
            'right':1073741903, 'start':13, 'select':1073742053, 'x':115, 'y':97}
    inputs = ET.Element('inputList')
    keyboard = ET.SubElement(inputs, 'inputConfig', type='keyboard', deviceName='Keyboard', deviceGUID='-1')
    for name, value in keys.items():
        ET.SubElement(keyboard, 'input', name=name, type='key', id=str(value), value='1')
    ET.ElementTree(inputs).write(config / 'es_input.cfg', encoding='utf-8', xml_declaration=True)
    settings = ET.Element('config')
    for name, value in {'Language':language, 'StartupSystem':system, 'CollectionSystemsAuto':'',
                        'CollectionSystemsCustom':'', 'ThemeSet':'system-theme', 'GamelistViewStyle':'basic'}.items():
        ET.SubElement(settings, 'string', name=name, value=value)
    for name in ('HideWindow', 'HideWindowFullReinit', 'audio.bgmusic'):
        ET.SubElement(settings, 'bool', name=name, value='false')
    ET.SubElement(settings, 'bool', name='StartupOnGameList', value='true')
    ET.SubElement(settings, 'int', name='ScreenSaverTime', value='0')
    ET.ElementTree(settings).write(config / 'es_settings.cfg', encoding='utf-8', xml_declaration=True)
    put(storage / '.config/system/configs/system.cfg', 'system.language=' + language + '\ncloudsaves.gameexit=0\ncloudsaves.enabled=0\n')
    (storage / '.emulationstation').symlink_to('.config/emulationstation')


def mount(source, target, flags=4096, fstype=None, data=None):
    libc = ctypes.CDLL(None, use_errno=True)
    libc.mount.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p,
                           ctypes.c_ulong, ctypes.c_char_p]
    def encoded(value):
        return None if value is None else os.fsencode(value)
    if libc.mount(encoded(source), encoded(target), encoded(fstype), flags, encoded(data)):
        raise OSError(ctypes.get_errno(), 'fixture mount failed: ' + str(target))


def bind(source, target, readonly=False):
    mount(source, target)
    if readonly:
        mount(None, target, 4096 | 32 | 1)  # bind remount readonly


def child(owner):
    # BusyBox unshare has -f, but no util-linux --kill-child. Namespace PID 1
    # belongs to the runner's process group, and also dies if its unshare parent
    # disappears. Killing namespace PID 1 retires all remaining descendants.
    libc = ctypes.CDLL(None, use_errno=True)
    libc.prctl.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong]
    require(libc.prctl(1, signal.SIGKILL, 0, 0, 0) == 0, 'cannot bind namespace lifetime to parent')
    def terminate(signum, _frame):
        raise SystemExit(128 + signum)
    signal.signal(signal.SIGTERM, terminate)
    config = json.loads((owner / 'owner.json').read_text())
    spec = json.loads((owner / 'active/case.json').read_text())
    require(all(ns_identity()[k] != config['parent_ns'][k] for k in ('mnt', 'net', 'pid')), 'namespace isolation failed')
    require([name for _, name in socket.if_nameindex()] == ['lo'], 'network namespace has external interface')
    mount(None, '/', (1 << 18) | 16384)  # recursively private, before any bind
    require(not any('shared:' in line.split(' - ')[0] for line in Path('/proc/self/mountinfo').read_text().splitlines()), 'shared mount propagation')
    # Preserve only explicit handles across replacing /tmp, /run and /usr/bin.
    handles = {}
    for key, path in {'owner':owner, 'socket':config['wayland_socket'],
                      'defaults':config['defaults_root'],
                      'es_resources':'/usr/config/emulationstation/resources',
                      'locale':'/usr/config/locale'}.items():
        handles[key] = os.open(path, os.O_PATH)
    # Open the actual invocation paths BEFORE hiding any directories. This keeps
    # per-file candidate bind mounts and symlinks into staging storage intact.
    # A plain bind of /usr/bin would omit its nested per-file bind mounts.
    native_fds = {name:os.open('/usr/bin/' + name, os.O_PATH)
                  for name in (*UTILITIES, 'emulationstation')}
    mount('tmpfs', '/tmp', 0, 'tmpfs', 'size=128m,mode=1777')
    LIVE.mkdir()
    bind('/proc/self/fd/' + str(handles['owner']), LIVE)
    active = LIVE / 'active'
    bind(active / 'storage', '/storage')
    bind(active / 'storage/roms', '/storage/roms')  # actual helper mountinfo prerequisite
    mount('tmpfs', '/run', 0, 'tmpfs', 'size=16m,mode=755')
    display = Path('/run/pix581-display')
    display.mkdir(mode=0o700)
    (display / 'wayland-qa').touch()
    bind('/proc/self/fd/' + str(handles['socket']), display / 'wayland-qa')
    mount('tmpfs', '/var', 0, 'tmpfs', 'size=16m,mode=755')
    Path('/var/log').mkdir()
    Path('/var/run').symlink_to('/run')
    bind(active / 'logs', '/var/log')
    mount('tmpfs', '/usr/bin', 0, 'tmpfs', 'size=8m,mode=755')
    for name, fd in native_fds.items():
        target = Path('/usr/bin') / name
        target.touch()
        bind('/proc/self/fd/' + str(fd), target, True)
    for name in PRODUCT:
        target = Path('/usr/bin') / name
        target.touch()
        bind(LIVE / 'product' / name, target, True)
    for name in STUBS:
        target = Path('/usr/bin') / name
        target.touch()
        bind(LIVE / 'record-stub.py', target, True)
    # Missing outer destinations are created ONLY inside this private tmpfs.
    # Preserve resources by handles opened before hiding /tmp and /usr/config.
    mount('tmpfs', '/usr/config', 0, 'tmpfs', 'size=8m,mode=755')
    for key, target in (('defaults', '/usr/config/dolphin-emu'),
                        ('es_resources', '/usr/config/emulationstation/resources'),
                        ('locale', '/usr/config/locale')):
        Path(target).mkdir(parents=True)
        bind('/proc/self/fd/' + str(handles[key]), target, True)
    for fd in (*handles.values(), *native_fds.values()):
        os.close(fd)
    bind(LIVE / 'profile.sh', '/etc/profile', True)
    # Actual runemu sources this after profile: fixed fixture capability values
    # prevent a hardware flag from turning a harmless function seam into a service.
    bind(LIVE / 'os-release', Path('/etc/os-release').resolve(), True)
    for source, target in (('/usr/config/emulationstation/resources', '/storage/.config/emulationstation/resources'),
                           ('/usr/config/locale', '/storage/.config/locale')):
        Path(target).mkdir()
        bind(source, target, True)
    # Theme is a packaged resource, never copied from a player's /storage.
    Path('/storage/.config/emulationstation/themes').mkdir()
    Path('/storage/.config/emulationstation/themes/system-theme').symlink_to('/usr/share/themes/es-theme-art-book-next')
    identity = product_check(Path('/usr/bin'), {name:(LIVE / 'product' / name).read_bytes() for name in PRODUCT})
    require(identity == config['staged_products'], 'mounted product differs from prepared source')
    mounted_defaults = defaults_check(Path('/usr/config/dolphin-emu'), LIVE / 'defaults-receipt.json', LIVE / 'source.json')
    require(mounted_defaults == config['defaults'], 'mounted defaults differ from prepared receipt')
    require(sha('/usr/bin/emulationstation') == config['es_sha256'], 'mounted ES binary mismatch')
    mounted_tools = {name:sha('/usr/bin/' + name) for name in (*UTILITIES, 'emulationstation')}
    for name, actual in mounted_tools.items():
        require(actual == config['tools'][name]['sha256'], 'mounted utility bytes changed: ' + name)
    for name, expected in config['frame_resources'].items():
        require(sha(name) == expected, 'frame resource changed after preparation: ' + name)
    write_json(active / 'mounted.json', {'files':identity, 'es_sha256':sha('/usr/bin/emulationstation'),
               'namespaces':ns_identity(), 'interfaces':[name for _, name in socket.if_nameindex()],
               'mountinfo':Path('/proc/self/mountinfo').read_text(), 'substituted_executables':list(STUBS),
               'tools':mounted_tools, 'defaults':mounted_defaults,
               'qualification':config['qualification']})
    env = {'PATH':'/usr/bin:/bin', 'HOME':'/storage', 'LANG':'en_US.UTF-8',
           'LANGUAGE':spec['language'], 'LC_ALL':'en_US.UTF-8', 'SDL_VIDEODRIVER':'wayland',
           'SDL_AUDIODRIVER':'dummy', 'XDG_RUNTIME_DIR':str(display), 'WAYLAND_DISPLAY':'wayland-qa',
           'LOCPATH':'/usr/share/locale', 'PYTHONDONTWRITEBYTECODE':'1'}
    with (active / 'es.stdout').open('wb') as stdout, (active / 'es.stderr').open('wb') as stderr:
        process = subprocess.Popen(['/usr/bin/emulationstation', '--no-splash'], env=env,
                                   cwd='/storage', stdout=stdout, stderr=stderr)
        write_json(active / 'es-pid.json', {'namespace_pid':process.pid})
        started = time.monotonic()
        ready = False
        consumed = False
        try:
            while process.poll() is None and time.monotonic() - started < 300:
                if Path('/tmp/emulationstation.ready').is_file() and not ready:
                    ready = True
                    write_json(active / 'ready.json', {'ready':True, 'case':spec})
                if (active / 'caller.json').is_file() and not consumed:
                    caller = json.loads((active / 'caller.json').read_text())
                    if caller.get('runemu_exit') == 250 and not Path('/tmp/launch_error.log').exists():
                        consumed = True
                        write_json(active / 'native-consumed.json', {'consumed':True, 'es_alive':True,
                                  'source_boundary':'real ES removes /tmp/launch_error.log for exit 250'})
                if (active / 'stop').exists():
                    break
                if not ready and time.monotonic() - started > 90:
                    raise RuntimeError('ES readiness timeout')
                time.sleep(0.1)
            require(process.poll() is None, 'ES exited before coordinator stop')
            require((active / 'stop').exists(), '300 second UI allocation expired')
            caller = json.loads((active / 'caller.json').read_text())
            require(caller['status'] == 'PASS', 'caller fixture failed')
            require(caller['runemu_exit'] != 250 or consumed, 'ES did not consume native message')
            write_json(active / 'boundary.json', {'status':'PASS', 'ready':ready, 'native_consumed':consumed,
                       'frames':'REVIEW REQUIRED; file consumption alone is not a visible-dialog proof'})
        finally:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
            try:
                code = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill(); code = process.wait(timeout=3)
            write_json(active / 'es-exit.json', {'original_exit':code})
        require(code == 0, 'ES did not exit cleanly after the coordinator stop marker')


def managed_snapshot():
    return {name:snapshot(Path('/storage') / name) for name in
            ('.config/dolphin-emu', '.local/share', 'roms/bios', 'roms/savestates', 'unrelated')}


def invoke(args):
    active = LIVE / 'active'
    spec = json.loads((active / 'case.json').read_text())
    require(not (active / 'caller.json').exists(), 'one launch per case; repeated launch refused')
    require(args.rom == '/storage/roms/qa581/synthetic.iso', 'unexpected ROM argument')
    require(args.emulator == 'dolphin' and args.core == 'dolphin-sa', 'unexpected ES dispatch metadata')
    before = managed_snapshot()
    write_json(active / 'before.json', before)
    lock = None
    if spec['case'] == 'busy':
        lock = open('/run/dolphin-save-paths.lock', 'a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    argv = ['/usr/bin/bash', '/usr/bin/runemu.sh', args.rom, '-P' + spec['system'],
            '--emulator=' + args.emulator, '--core=' + args.core, '--controllers=1']
    env = dict(os.environ, SHELLOPTS='xtrace', PS4='+${BASH_SOURCE}:${LINENO}: ')
    try:
        with (active / 'caller.stdout').open('wb') as stdout, (active / 'caller.stderr').open('wb') as stderr, \
                (active / 'caller.trace').open('wb') as trace:
            env['BASH_XTRACEFD'] = str(trace.fileno())
            process = subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr,
                                       pass_fds=(trace.fileno(),), start_new_session=True)
            try:
                code = process.wait(timeout=45)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(timeout=3)
    finally:
        if lock is not None:
            lock.close()
    write_json(active / 'runemu-exit.json', {'original_exit':code})
    after = managed_snapshot()
    write_json(active / 'after.json', after)
    error = Path('/tmp/launch_error.log')
    if error.exists():
        require(error.is_file() and not error.is_symlink(), 'unsafe error message')
        shutil.copyfile(error, active / 'visible-error.txt')  # real ES consumes original
    events = [json.loads(line) for line in (active / 'stubs.jsonl').read_text().splitlines()]
    engines = [e for e in events if e['name'].startswith('dolphin-emu')]
    trace = (active / 'caller.trace').read_text()
    checks = len(re.findall(r'^\++(?:/usr/bin/start_dolphin_(?:gc|wii)\.sh:[0-9]+:)? /usr/bin/python3 -I -S -B /usr/bin/dolphin-save-paths check ' + spec['system'] + r'$', trace, re.M))
    preparations = len(re.findall(r'^\++(?:/usr/bin/start_dolphin_(?:gc|wii)\.sh:[0-9]+:)? /usr/bin/python3 -I -S -B /usr/bin/dolphin-save-paths prepare ' + spec['system'] + r'$', trace, re.M))
    launcher_exits = [int(value) for value in re.findall(r'^\++(?:/usr/bin/runemu\.sh:[0-9]+:)? ret_error=([0-9]+)$', trace, re.M)]
    clean = spec['case'] in ('fresh', 'known-link')
    assertions = {'original_exit':code == (0 if clean else 250), 'engine_count':len(engines) == int(clean),
                  'original_launcher_exit':launcher_exits == [0 if clean else 250],
                  'default_nogui_dispatch':not engines or engines[0]['name'] == 'dolphin-emu-nogui',
                  'controller_seam_once':sum(e['name'] == 'control-gen_init.sh' for e in events) == 1,
                  'achievement_seam_only_after_success':sum(e['name'] == 'cheevos_dolphin.sh' for e in events) == int(clean),
                  'real_preflight_count':checks == 1, 'real_prepare_count':preparations == int(clean)}
    if not clean:
        assertions['retained_tree_identical'] = before == after
        message = (active / 'visible-error.txt').read_text() if error.exists() else ''
        title = 'DOLPHIN N’A PAS DÉMARRÉ' if spec['language'] == 'fr_FR' else 'DOLPHIN DID NOT START'
        assertions['localized_title_once'] = message.startswith(title + '\n\n') and message.count(title) == 1
        assertions['no_protocol_in_french'] = spec['language'] != 'fr_FR' or 'DOLPHIN DID NOT START' not in message
        assertions['busy_copy'] = spec['case'] != 'busy' or ('déjà en cours' if spec['language'] == 'fr_FR' else 'already running') in message
    else:
        # Immutable witnesses: all pre-existing regular save/card files, their
        # inode/mode/hash, including unrelated and retained Wii saves.
        assertions['saved_files_preserved'] = all(after[group].get(name) == entry
            for group, contents in before.items() for name, entry in contents.items()
            if entry['kind'] == 'file' and ('protected' in name or name.endswith('.raw')))
        assertions['selected_state_link'] = os.readlink('/storage/.config/dolphin-emu/StateSaves') == '/storage/roms/savestates/' + spec['system']
        assertions['no_error_file'] = not error.exists()
        assertions['card_links'] = all(os.readlink('/storage/.config/dolphin-emu/GC/' + name) == '/storage/roms/bios/GC/' + name
            for region in ('EUR','JAP','USA') for name in ('MemoryCardA.'+region+'.raw', 'MemoryCardB.'+region+'.raw'))
    write_json(active / 'caller.json', {'status':'PASS' if all(assertions.values()) else 'FAIL',
               'argv':argv, 'runemu_exit':code, 'engine_calls':len(engines), 'helper_check_calls':checks,
               'launcher_exits_from_actual_runemu_trace':launcher_exits,
               'helper_prepare_calls':preparations, 'assertions':assertions})
    # Preserve the real exit even when a harness assertion fails; coordinator
    # checks caller.json separately. Do not manufacture a native error dialog.
    return code if code >= 0 else 128 - code


def run(args):
    def terminate(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, terminate)
    require(os.geteuid() == 0, 'guest root required')
    config = json.loads((args.owner / 'owner.json').read_text())
    require(config['parent_ns'] == ns_identity(), 'owner was prepared in a different namespace')
    require(not (args.owner / 'active').exists(), 'one immutable case per owner; prepare a new owner')
    expected = {name:(args.owner / 'product' / name).read_bytes() for name in PRODUCT}
    require(product_check(args.owner / 'product', expected) == config['staged_products'],
            'owner product changed after prepare')
    defaults = Path(config['defaults_root'])
    require(defaults_check(defaults, args.owner / 'defaults-receipt.json') == config['defaults'],
            'defaults changed after prepare')
    require(sha('/usr/bin/emulationstation') == config['es_sha256'], 'ES changed after prepare')
    require(sha('/usr/bin/unshare') == config['tools']['unshare']['sha256'], 'unshare changed after prepare')
    for path in Path('/proc').glob('[0-9]*/comm'):
        try:
            require(path.read_text().strip() != 'emulationstatio', 'stop coordinator essway frontend before fixture; keep sway running')
        except FileNotFoundError:
            pass
    active = args.owner / 'active'
    active.mkdir()
    (active / 'logs').mkdir()
    for name in PRODUCT:
        (args.owner / 'product' / name).chmod(0o755)
    (args.owner / 'record-stub.py').chmod(0o755)
    (args.owner / 'os-release').write_text('NAME="pix581 disposable fixture"\nDEVICE_HAS_FAN=false\nDEVICE_HAS_DUAL_SCREEN=false\nDEVICE_MANGOHUD_SUPPORT=false\n')
    seed(active, args.system, args.case, args.language, defaults)
    write_json(active / 'case.json', {'system':args.system, 'case':args.case, 'language':args.language})
    command = ['/usr/bin/unshare', '-m', '-n', '-p', '-f', '--mount-proc', '--propagation', 'private',
               '--', '/usr/bin/python3', '-I', '-S', '-B',
               str(args.owner / 'installed_flow.py'), 'child', str(args.owner)]
    with (active / 'namespace.stdout').open('wb') as stdout, (active / 'namespace.stderr').open('wb') as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
        write_json(active / 'runner-pid.json', {'pid':process.pid, 'start_ticks':Path('/proc/' + str(process.pid) + '/stat').read_text().rsplit(')',1)[1].split()[19]})
        try:
            code = process.wait(timeout=330)
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            # An abnormal abort is not a graceful UI completion. Retire the
            # entire owned group, including namespace PID 1, before restoring
            # the outer frontend. No util-linux --kill-child dependency.
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=3)
    write_json(active / 'runner-exit.json', {'original_unshare_exit':code})
    require(code == 0, 'namespace runner failed; preserve original logs and exits')
    require(json.loads((active / 'boundary.json').read_text())['status'] == 'PASS', 'missing boundary result')
    print('PASS source-staged caller/native consumption; frame review still required: ' + str(active))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='operation', required=True)
    p = commands.add_parser('stage-products')
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--renderer', choices=('Vulkan','OGL'), required=True)
    p.add_argument('--output', type=Path, required=True)
    p = commands.add_parser('prepare')
    p.add_argument('--disposable-vm', action='store_true')
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--owner', type=Path, required=True)
    p.add_argument('--renderer', choices=('Vulkan','OGL'), required=True)
    p.add_argument('--es-sha256', required=True)
    p.add_argument('--es-source', required=True)
    p.add_argument('--wayland-socket', type=Path, required=True)
    p.add_argument('--product-root', type=Path, required=True)
    p.add_argument('--defaults-root', type=Path, required=True)
    p.add_argument('--defaults-receipt', type=Path, required=True)
    p = commands.add_parser('run')
    p.add_argument('--owner', type=Path, required=True)
    p.add_argument('--system', choices=SYSTEMS, required=True)
    p.add_argument('--case', choices=CASES, required=True)
    p.add_argument('--language', choices=('en_US','fr_FR'), required=True)
    p = commands.add_parser('child'); p.add_argument('owner', type=Path)
    p = commands.add_parser('invoke'); p.add_argument('rom')
    p.add_argument('--emulator', required=True); p.add_argument('--core', required=True)
    args = parser.parse_args()
    if args.operation == 'stage-products':
        stage_products(args); return 0
    if args.operation == 'prepare':
        prepare(args); return 0
    if args.operation == 'child':
        child(args.owner); return 0
    if args.operation == 'invoke':
        return invoke(args)
    return run(args)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print('REFUSED: ' + str(error), file=sys.stderr)
        sys.exit(1)

# Synthetic settings/controller/hardware seam. Sourced by the unmodified callers.
export PATH=/usr/bin:/bin
export HOME=/storage
export DEVICE_HAS_FAN=false DEVICE_HAS_DUAL_SCREEN=false DEVICE_MANGOHUD_SUPPORT=false
export VERBOSE=false
get_setting() {
    case "$1" in
        controllers.bluetooth.enabled) printf '0\n' ;;
        system.loglevel) printf 'verbose\n' ;;
        *) : ;;
    esac
}
fixture_record() { printf '%s\n' "$*" >> /tmp/pix581-flow/active/seams.log; }
performance() { fixture_record performance "$@"; }
set_kill() { fixture_record set_kill "$@"; }
get_controls() { DEVICE=''; param_device='Synthetic QA controller'; }
gpu_performance_level() { fixture_record gpu_performance_level "$@"; }
onlinethreads() { fixture_record onlinethreads "$@"; }
gpu_profiling() { fixture_record gpu_profiling "$@"; }
clear() { :; }
redact_credentials() {
    # All caller arguments and settings are generated here. Preserve both forms
    # of the real function's API without blocking its argument-taking calls.
    if [ "$#" -gt 0 ]; then printf '%s\n' "$*"; else cat; fi
}

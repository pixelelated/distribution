# Minimal separable boundaries — source/record preparation only

Frozen distribution: `f8636de1d105275dbf9420bbabbbc26f79abb10f`.
Accepted ES: `16dbac5211eea7e70db7394372033be2be7df829`.
Exact tracked-file hashes and the existing evidence locators are in
`source-and-evidence-bindings.json`. No current-upstream rebase, patch application,
compiler, runtime or upstream submission occurred here.

| Existing queue owner | Destination and smallest boundary |
| --- | --- |
| #574 MD5 | `libretro/libretro-common`, only `utils/md5.c`; use the already prepared public patch/reproducer under `docs/qa-logs/2026-10-14-md5-upstream-source/contribution/`. Keep its original license. No rcheevos or frontend file belongs in that patch. Upstream-only execution remains UNRUN. |
| #574 Nintendo disc reader | `RetroAchievements/rcheevos`, only `src/rhash/hash_disc.c`: complete-read checks, unsigned/wide header arithmetic, caller-owned close on allocation failure. `accepted-rcheevos-disc-reader.diff` records the exact vendored accepted delta, not a current-upstream-applicable patch. The shared Wii helper success/truncation controls already exist; no new full-disc or platform claim. Dated upstream source is retained from October13; refresh applicability/duplicates later. |
| #574 RVZ frontend adapter | ES component; deliver via focused `ROCKNIX/distribution:next` ES patches/package integration. `external/libcheevos/rvz_hash.cpp/.h`, cheevos wrapper dispatch/capability, root/libcheevos CMake, notices/license and direct package zstd dependency/license installation. Keep bounded supported modes/failure semantics; exclude the MD5 and rcheevos corrections into their own patches. |
| #574 failed-hash retry | ES `GameCubeRvzHashRetry.h` and the matching `ThreadedHasher.cpp` hunk only; depends on the adapter capability. Preserve valid unmatched hashes/positive IDs and existing indexing policy. Do not confuse this frontend item with the separate #583 distribution scanner retry already in the queue. |
| #575 capability guidance | ES `GuiMenu.cpp` global help/per-game resolved-emulator support row plus the matching EN/FR catalog/POT entries. Source commit23df404f6 introduces the UI boundary; retain later accepted French text. Exclude other GuiMenu flows and all save-state integration or preference rewrites. Destination remains conditional on upstream's same UI/capability mismatch. |
| #584 offline route | ROCKNIX Dolphin `scripts/cheevos_dolphin.sh`: raw enabled/casual/offline setting decision and IPv4-capable listener guard/customhost fallback. Offer only with equivalent upstream service/toggle contract. Keep it separate from the #594 publication correction and from Dolphin core. |
| #584/#590 NoGUI lifecycle | `dolphin-emu/dolphin`, only `Source/Core/DolphinNoGUI/MainNoGUI.cpp`, preserving USE_RETRO_ACHIEVEMENTS guards and scope cleanup on normal/failed boot. Exact distribution patch018 is the backport; upstream support intent/duplicate review remains required. No Qt ownership, API, routing, Sys or settings schema changes. |
| #593 normal-exit Wi-Fi worker | ES commit16dbac changes `GuiWifi.cpp`, `GuiWifi.h`, `WifiScanProcess.h`, and `main.cpp`. Offer the joinable owner/cancel/shutdown delta only with the compatible asynchronous picker worker; otherwise retain the conditional disposition. Do not bundle search/copy/backend features or alter fatal-signal/whole-service policy. |
| #594 inactive session/refusal | ROCKNIX `cheevos_dolphin.sh` plus both `start_dolphin_gc.sh` and `start_dolphin_wii.sh` caller blocks: disabled/missing-token explicit inactive file, atomic mktemp/mv publication, refusal on error, EN/FR message. Preserve helper exit1 for a safely inactive session and250 on publication refusal. Existing enabled routing and all unrelated save-path/controller work stay separate. Source d9054efc46 is a combined commit, so select these hunks rather than submit the whole commit. |
| #595 isolated Python | ROCKNIX `projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh`, only the invocation at `install_steam_runtime_arm64`: `python3 -` becomes `/usr/bin/python3 -I -S -B -`. Embedded body is unchanged. This is independent of the already queued runtime/FEX/Proton transactions and metadata bounds; no ARM runtime claim follows from x64 fixture proof. |

All six issues already had queue coverage. The concrete omission was explicit
rcheevos ownership/split within the existing #574 disc-reader row. This packet
does not add another priority, research matrix, upstream-only build prerequisite,
or submission. Root owns actual issue/doc application and any later public action.

## Owner direction — October 14

> Let's keep a running list of what we plan on upstreaming, and we can do it once we know we have our initial build complete. Do we have any other open items that we've been working on since the last release candidate version of 0.0.1 that we're still waiting to do that came up through testing?

This is the cross-project contribution queue. **Hold upstream submissions until the initial build from the current M7 fix set is complete and the relevant fixes are qualified.** Track and preserve useful patches now; contribution-only preparation or standalone upstream reproduction is not a prerequisite for generating that build. Local defect repair and release qualification remain required. Build completion is not automatic permission to post to an upstream project.

The M7 milestone body remains the ordered release plan. This issue has no M7 milestone because submission is follow-up work, not an RC blocker. #168 retains the detailed RAOfflineProxy patch map; #559 is incoming ROCKNIX integration policy, a different direction of work. Historical broad PR-series issues #256/#333/#335 and toolkit proposals #229–#231/#261 remain separate; this queue does not reopen closed upstream PRs or authorize a large combined submission.

## Planned focused contributions

| Change | Intended upstream | Source / present evidence | Remaining before submission |
| --- | --- | --- | --- |
| RVZ unaligned packed-padding reads | misantronic/RAOfflineProxy | #583; revised22cf candidate: original126 unaligned mismatches, candidate0; aligned/malformed controls and synthetic packed-RVZ proof pass. Current reader matches our pin. | Independent Dolphin/native ISO-RVZ hash parity, final integration; recheck current upstream/duplicates after build. |
| Alignment-safe MD5 loads | libretro/libretro-common | #574; target candidate314da58d passes528 digest comparisons; local current-upstream one-file patch/public reproducer/PR drafta58b2313. | Upstream-only standalone before/after run remains UNRUN and is deferred until after the build; retain local sanitizer qualification. |
| Frontend GameCube RVZ recognition, disc-reader and retry correction | ROCKNIX/emulationstation-next | #574; source and staged target controls exist; separate from MD5 and proxy padding. No Dolphin decoder defect established. | Finish independent format/native/frontend proof; extract the smallest patch from the composed frontend. |
| Flush a startup reconnect observed by the first monitor probe | misantronic/RAOfflineProxy | #588; causal original-service failure, repaired actual-service pass and ten component controls pass. Product patch021 reproduces the tested source. | Installed/default-boot qualification now PASS on d6a87f05; #588 closed with published exact-source evidence. Minimal upstream patch/current-upstream recheck remains; no submission yet. |
| Initialize missing Wii controller profiles in the configured directory | ROCKNIX/distribution | #581; inherited destination typo remains in live upstream50097e80. One-line local correction preserves existing custom profiles and leaves old nested data untouched. | New-image missing/custom-profile controls and native launcher qualification; preserve the small independent patch. |
| Preserve existing Dolphin saves/states before relinking | ROCKNIX/distribution | #581; preservation controls and reviewed refusal flows pass within their recorded scope. | English640 layout is complete; native/installed/upgrade qualification remains, with current-upstream comparison before submission. |
| Correct default Recent collection spelling | ROCKNIX/emulationstation-next | #578; `favorites, recent` produces an unmatched name. Corrected compiled default/explicit-choice/history controls pass on staged source; current-upstream mismatch recorded October13. | Final source/image proof, isolate the one-literal change; recheck upstream. |
| Preserve Steam runtime, FEX and Proton during failed replacement; recover partial client bootstrap honestly | ROCKNIX/distribution | #564/#579/#580/#582; staged replacement and full synthetic caller evidence exist. Actual client archive CRC/layout and corrected full synthetic caller/recovery controls pass. Metadata network bounds and isolated runtime Python invocation (#595) are independently verified. | Finish relevant native/image proof; split independently useful transaction, metadata-bound and invocation fixes, then recheck current upstream. |

| Clear retained Dolphin achievements when disabled or signed out | ROCKNIX/distribution | #594, source d9054efc; current upstream retains the early exit. Fifteen exact helper/launcher-block controls pass; failed publication refuses launch and preserves saved data. | Full EN/FR launcher refusal and next-image qualification; extract a small helper/caller correction and recheck upstream after the build. |
| Supply Dolphin resources at the compiled immutable Sys path | ROCKNIX/distribution | #592; package alias6616cc36, d4af installed resource identities and startup-error absence pass. | Confirm current upstream packaging has the same compiled path mismatch; preserve the focused alias patch. |

## Conditional candidates — establish upstream fit first

| Change | Possible destination | Current disposition |
| --- | --- | --- |
| Dolphin offline-proxy routing (#584) | ROCKNIX/distribution |126 full configuration cases pass. Offer only if upstream has an equivalent service/toggle contract; no Dolphin-core patch. Installed/native proof remains. |
| GStreamer controller/scanner dependency closure (#572) | ROCKNIX/distribution | Package/install and fresh-registry controls pass. Sign-in-specific requirements differ from the generic recipe; offer a focused dependency repair if applicable, otherwise record fork-only integration. Not a GStreamer engine bug. |
| Release retained ES memory before external sign-in (#570) | ROCKNIX/emulationstation-next | Actual compiled VM comparison reclaims78.01MiB; bounded repeated handoff/recovery tests pass. Requires a comparable upstream caller and qualification, not a claim of a WebKit cure. |
| Wi-Fi picker persistence, in-list search and failed-enumeration distinction (#577) | ROCKNIX/emulationstation-next and ROCKNIX/distribution | Staged UI and backend controls exist. Keep UI and script propagation patches independently reviewable; combined final-source proof remains. |
| Reap the asynchronous Wi-Fi scan on normal frontend exit (#593) | ROCKNIX/emulationstation-next, together with the compatible picker worker | Exact candidate16dbac target compilation passes; driver and actual frontend proof remain due. This addresses our asynchronous-worker lifetime; do not claim the same worker already exists upstream. |
| DolphinNoGUI achievements lifecycle (#584/#590) | Dolphin, if upstream intends achievements support in NoGUI | Missing initialization/shutdown reproduced; compiled and installed enabled/disabled/failed-boot controls pass. Establish upstream frontend/support intent before proposing the guarded lifecycle patch. |
| Standalone save-state capability guidance (#575) | ROCKNIX/emulationstation-next | Useful if upstream exposes the same unsupported automatic-state/manager promise. Separate engine capability from launcher integration; native/retained proof remains. |
| Phone status/navigation and game-list offline notice (#571/#567) | Fork UI unless an equivalent upstream integration exists | Component/installed-flow evidence exists; do not bundle fork-specific browser/cloud presentation into unrelated upstream fixes. |
| Explicit retry for RVZ zero-hash failures (#583) | Fork distribution integration at present |44 before/after listing controls pass. Preserve D-RA-013 automatic/index policy; not an RAOfflineProxy decoder change. |

## Previously prepared RAOfflineProxy contributions — retain #168 as owner

Ten focused drafts already exist under `docs/upstream/raofflineproxy/`: HTTP client errors, warning achievement sets, refresh resilience, configured cached login, log-upload consent, concurrent image publication, image completeness, bounded DNS, pixelelated platform/account discovery, and early consent observation. Their independent before/after evidence was recorded against earlier October2/6 upstream bases; **none is claimed current-base-ready or submitted by this inventory**.

The existing contribution map also tracks award-flush events, whole-library preparation, store-only/provenance/image-outcome API proposals and earlier audit suggestions requiring upstream API agreement. Preserve its explicit already-upstream/retired dispositions (including connection reuse and subset award mapping); do not resubmit them. Add the new RVZ row to that map and reconcile all remaining drafts against current upstream only when preparing the post-build contribution batch.

## Maintenance and acceptance

Can this be done on the VM? This issue is a tracker/source inventory; no runtime test is needed to maintain it. Each linked defect retains its own VM-first acceptance and evidence. Future standalone reproductions need their own finite scope.

- [x] Queue records each known contribution or candidate, target, owning issue, evidence, missing proof and submitted/accepted/declined/superseded/fork-only disposition. Links to existing detailed maps avoid losing older work.
- [x] Decision, canonical engineering rule, M7 body and resume checkpoint agree that upstream submissions wait until the initial current-build completion; no upstream-only proof is treated as a release build blocker.
- [ ] Before the first submission, record the completed build/artifact and relevant qualification, refresh current upstream and duplicate checks, and retain minimal patches/public regressions with original licences and no private data.
- [ ] Record each eventual upstream URL/outcome or explicit non-submission disposition; keep local fixes until upstream adoption and integration proof. No submission is claimed by preparing this queue.

This issue is the live contribution status list; `docs/upstream/README.md` is its repository entrypoint. The dated next-candidate working list records outstanding testing work, while the milestone owns order.



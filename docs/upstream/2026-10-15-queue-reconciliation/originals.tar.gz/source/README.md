# Upstream queue reconciliation — prepared, not applied

Scope: only completed #574/#575/#584 and audit fixes #593/#594/#595, against the
current fork issue#585 and canonical `docs/upstream/README.md`. All six issues
already have queue coverage. The one concrete omission is component ownership
for the rcheevos disc-reader correction already bundled in #574's frontend row.
No duplicate candidate, priority change, upstream submission, current-upstream
research matrix, shared edit, cache operation or runtime was performed.

Ready edits:

- `issue-585.addition.md`: exact additive section. `issue-585.body.after.md`
  is the complete replacement body, preserving all earlier bytes and ordering.
  `issue-585.diff` shows the insertion before the older detailed proxy map.
- `upstream-README.addition.md`: exact appended canonical-doc section.
  `upstream-README.after.md` and `upstream-README.diff` are ready for root review.
- `patch-boundaries.md`: intended destination and minimal separable product hunks.
  `accepted-rcheevos-disc-reader.diff` is the accepted vendored change only,
  not an untested claim of a current-upstream-applicable patch.

Before applying, root must compare the current remote issue body and canonical
file against the exact before hashes and issue updatedAt in `reconciliation.json`.
If another writer changed either, reconcile only this additive section rather
than overwrite their work. Root owns any `gh issue edit --body-file` or repository
edit; none was invoked here. No existing checklist or settled priority changes.

The snapshot binds accepted distributionf863 and ES16dbac; live issue bodies and
comments are retained. `source-and-evidence-bindings.json` records exact Git
source hashes and the finite existing accepted records consulted. It does not
claim that historical component results used today's upstream base, or that
new tests ran. D-WORKFLOW-165 submission timing/explicit authority, applicable
current-upstream/duplicate checks, and original evidence limits remain intact.

The prepared text preserves unknown original #597 launcher wait, synthetic
login/award limits, conditional NoGUI/routing/Wi-Fi adoption, native states versus
frontend-manager scope, and absent x64 ARM Steam payload. It removes no historic
failures. H700's active independent cache copy was not accessed or altered.

# #597 exact reporting-failure artifact readback

SOURCE ONLY; verifier, preparer, admission and artifact reader UNRUN. This additive
packet preserves the original verifier3c0806f5 and does not turn the launcher
collision into a successful build submission. The four producer stages and
runner have original zero outcomes. The original launcher final wait is unknown;
its reporting failure is observed. The root-written `tool-wrapper.rc` zero is
submission provenance, not a launcher result. Source-inferred exit2 remains an
inference only.

The only changes to the original verifier's main flow are replacing the two
launcher-success assertions with one exact reporting-failure guard and adding
`build_closeout` metadata to both output records. The new guard has no generic
missing-receipt fallback. It requires the exact frozen producer f8636de1, run
20261015T035405Z-403ed573, admission e8ed7da80b97410086485381fb175702 and failure
packet20ec6989. It rehashes all49 bound originals, checks the unchanged collision
inode/metadata, requires `launcher-result.json` still absent, and requires the
settled consumed reporting-failure record with qualification false and original
launcher returncode null. It also checks exact recorded PID/group/CID census
metadata and the reviewed recovery tool provenance. Ordinary source, recipe,
branch, clean-tree, stage, runner, resource, process/CID absence, identity,
GPT/CRC/bootloader, raw/update SYSTEM+KERNEL, installed bytes/modes/link chains,
ELF/catalog/profile and six Dolphin Sys resource checks remain unchanged.

The frozen producer is `/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02`
on `build/m7-p5-20261015-02`. Its source and original admission tool stay frozen.
The new explicit recovery operation is performed by the separately reviewed
coordinator tool. Its actual tool path/hash must appear in the consumed record
and are retained in the verifier's `build_closeout`; neither is represented as
the producer's original tool identity.

The exact immutable failure JSON is copied under `evidence/`; it locates/hashes
all49 originals. Independent review is copied there too. Full originals are
retained in their existing build/run owners and independently archived under
`docs/audits/2026_10_14-milestone-m7-next-candidate/supplements/build-launcher-collision/originals.tar.gz`
(SHA2567ea8daf764694e24105e51d0ba924694f9c6996e267df8571c00911c72762351).
No original or existing packet is rewritten. The four original reader files
are retained under `originals/`. `verifier.diff` is the complete executable delta.

## Later root execution

1. Finish independent tool/guard review and isolated controls; consume this exact
   completed build through `consume-reporting-failure`. Preserve the original
   runner object, unknown launcher wait, outputs-held disposition and zero
   deleted bytes. Before that actual consumed receipt exists, this reader refuses.
2. Use the existing qualified readback retention/admission/owner workflow from
   `/tmp/pix-m7-next-image-delta-20261015-02`, with the new coordinator admission
   tool and frozen producer checkout unchanged. Fresh owner remains
   `/workspace/tmp/pix-m7-image-readback-20261015-02`; it must not already be used.
   Copy `verify-image.py`, `run.sh` and `dolphin-sys-source-manifest.json` together;
   preserve `inputs.template.json`, then materialize actual `inputs.json` with the
   real consumed receipt SHA. The known completed build run/source/timestamp and
   build-inputs hash are bound; no image filename or hash is predicted. Create
   fresh empty `artifacts/` and `empty-scan/` through that reviewed owner workflow.
3. Retain the existing preflight, retention report and admission bindings,24GiB
   reader allowance plus8GiB margin, no deletion credit, and root's sole runtime
   allocation. Run the unchanged `run.sh` via the qualified durable launcher.
   Its CPU0,8GiB address-space,16GiB file,1500s work and15s cleanup bounds remain.
   Preserve all original reader/launcher/runner outcomes; do not write into a
   producer-owned completion receipt while it is live.
4. Review the actual image/product rows and original outcomes, then separately
   consume that reader admission. An actual reader PASS means artifact integrity
   only. Retain its `build_closeout` limitations in downstream installed evidence.
   Clean/retained affected checks668755cb and state-only checks e7326fe6 remain
   separate, pending actual image readback and root allocation. No runtime,
   release-candidate, audit-completion or original-launcher-success claim follows.

`static-review.json` records syntax and exact original-main/helper equivalence,
not execution of the recovery guard or artifact reader. Root and auditor review
this packet before allocation. No current build cache or firmware is read while
preparing this source packet.

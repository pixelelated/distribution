#!/usr/bin/env python3
"""UNRUN: prepare a fresh source-bound interactive native guest, no allocation."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
p=argparse.ArgumentParser()
for n in ['checkout','verification','author-owner','owner']:p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--vnc',type=int,required=True);p.add_argument('--expected-commit',required=True);a=p.parse_args();tree=a.checkout.resolve(strict=True);v=a.verification.resolve(strict=True);author=a.author_owner.resolve(strict=True);out=a.owner.absolute()
assert out.parent==Path('/workspace/tmp') and re.fullmatch('pix[a-z0-9-]+',out.name) and not out.exists() and 100<=a.vnc<=199
commit=subprocess.check_output(['git','-C',str(tree),'rev-parse','HEAD'],text=True).strip();assert re.fullmatch('[0-9a-f]{40}',commit)
assert commit==a.expected_commit,'root must explicitly bind the reviewed final commit; no predicted or silently followed source'
assert not subprocess.check_output(['git','-C',str(tree),'status','--porcelain'],text=True)
branch=subprocess.check_output(['git','-C',str(tree),'branch','--show-current'],text=True).strip();assert branch.startswith('build/')
for line in (HERE/'SHA256SUMS').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(HERE/n)==h
result=json.loads((v/'result.json').read_text());inputs=json.loads((v/'inputs.json').read_text());assert result['status']=='PASS' and result['source']==inputs['source']==inputs['identity']['build_commit']==commit
for required in ['usr/bin/dolphin-emu-nogui','usr/bin/start_dolphin_wii.sh','usr/bin/cheevos_dolphin.sh']:assert required in result['products'],'require actual integrated image product mapping: '+required
assert inputs['branch']==branch and inputs['identity']['dirty']=='no' and inputs['identity']['device']=='GENERIC_X64' and inputs['identity']['arch']=='x86_64'
recipe=tree/'projects/ROCKNIX/packages/ui/emulationstation/package.mk';pins=re.findall(r'^PKG_VERSION="([0-9a-f]{40})"$',recipe.read_text(),re.M);assert len(pins)==1 and result['es_commit']==inputs['es_commit']==pins[0]
assert pins[0]=='16dbac5211eea7e70db7394372033be2be7df829','selected global-state interpretation requires the reviewed ES source'
continuity=json.loads((HERE/'source-continuity.json').read_text())
for path,row in continuity['reviewed_sources'].items():assert sha(tree/path)==row['sha256'],path
images=[(Path(k),r) for k,r in inputs['artifacts'].items() if k.endswith('.img.gz')];assert len(images)==1;image,row=images[0]
assert not image.is_symlink() and image.resolve(strict=True).parent==tree/'target'
w=json.loads((author/'work-result.json').read_text());o=json.loads((author/'owner-result.json').read_text());assert w['status']==o['status']=='PASS' and o['original_scope_returncode']==0
assert [x['name'] for x in w['stages']]==['build','author'] and all(x['original_returncode']==0 and not x['timed_out'] for x in w['stages'])
cdi=author/'artifacts/Tetris2-M7.cdi';cr=w['artifacts']['Tetris2-M7.cdi'];assert cdi.stat().st_size==cr['bytes'] and sha(cdi)==cr['sha256'] and cr['bytes']<=1024**3
assert all(cr[key]==continuity['unchanged_tetris_cdi'][key] for key in ['bytes','sha256'])
helper=Path('/workspace/repos/rocknix.worktrees/m7-offline-vm-567/projects/ROCKNIX/devices/GENERIC_X64/vm/generic-x64-vm');assert sha(helper)=='5b058ed8a8b11135cd5997e3d925939baff30726033125acf1244863a756318d'
dol=Path('/tmp/m7-native-save-staged-01/SuDokuL-Wii.dol');assert dol.stat().st_size==6204908 and sha(dol)=='e4fc81977b527538d7fa8d6427099c21c0f2502d18b81a58134f8f07416a8455'
out.mkdir(mode=0o700)
for n in ['records','scan','logs','vm','source','frames','lifecycle-owner']:(out/n).mkdir()
for n in ['vm-lifecycle.py','host-action.py','close.py','census.py']:shutil.copy2(HERE/n,out/n)
for n in ['guest.py','supervisor.py','pad.py','consumed-paths.txt','frozen-config-bindings.json']:shutil.copy2(HERE/n,out/'source'/n)
shutil.copytree(HERE/'fixture',out/'source/fixture')
for name,src in [('final-image-result.json',v/'result.json'),('final-image-inputs.json',v/'inputs.json'),('author-work-result.json',author/'work-result.json'),('author-owner-result.json',author/'owner-result.json')]:shutil.copy2(src,out/'records'/name)
shutil.copy2(HERE/'source-continuity.json',out/'records/source-continuity.json')
save(out/'records/preparation-binding.json',{'commit':commit,'branch':branch,'es_commit':pins[0],'es_recipe_sha256':sha(recipe),'verification_sha256':sha(v/'result.json'),'verification_inputs_sha256':sha(v/'inputs.json'),'source_continuity_sha256':sha(out/'records/source-continuity.json')})
tools=[helper,helper.parent/'profile.json']+[tree/n for n in ['tools/vm-serial','tools/vm-stop','tools/vm-visual-qa','tools/watch-build','tools/watch-job','tools/watch-build-submit']]
config={'checkout':str(tree),'commit':commit,'es_commit':result['es_commit'],'vnc':a.vnc,'helper':str(helper),'image':{'path':str(image),**row},'system':result['payload']['SYSTEM'],'verification_sha256':sha(v/'result.json'),'verification_inputs_sha256':sha(v/'inputs.json'),'tools':{str(f):sha(f) for f in tools},'code':{n:sha(out/n) for n in ['vm-lifecycle.py','host-action.py','close.py','census.py']},'source':{str(f.relative_to(out/'source')):sha(f) for f in sorted((out/'source').rglob('*')) if f.is_file()},'fixture_inputs':{'SuDokuL-Wii.dol':{'path':str(dol),'bytes':dol.stat().st_size,'sha256':sha(dol)},'Tetris2-M7.cdi':{'path':str(cdi),**cr}},'work_seconds':1800,'cleanup_seconds':120,'first_frame_seconds':120,'score_seconds':360,'evidence_bytes':512*1024**2}
save(out/'config.json',config)
save(out/'retention-plan.json',{'volume':'/workspace','scan_roots':[str(out/'scan')],'reference_stores':[],'protected':[str(HERE),str(out/'source'),str(out/'records'),str(v),str(image),str(author),str(dol),str(tree/'tools/host-maintenance')],'candidates':[],'builds':[{'name':'m7-native-states','terms_bytes':{'raw_image_ceiling':16*1024**3,'guest_disk':16*1024**3,'input_media_staging':3*1024**3,'output_media':576*1024**2,'frames_and_logs':64*1024**2},'basis':'One no-NIC8GiB4CPU native gameplay guest.30min whole family +120s cleanup;120s first observed interactive frame per launch;360s earned-score window.448MiB guest evidence +64MiB host frames/logs =512MiB. Authored CDI <=1GiB immutable input, not evidence replay. No compiler or native component replay.','evidence':[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','vm-lifecycle.py','source/guest.py','source/pad.py']]}]})
save(out/'admission-plan.json',{'checkout':str(tree),'retention_plan':str(out/'retention-plan.json'),'retention_report':str(out/'retention-report.json'),'stage':'m7-native-states','profiles':[{'PROJECT':'ROCKNIX','DEVICE':'GENERIC_X64','ARCH':'x86_64'}],'outputs':[{'path':str(out/'vm'),'issue':575,'kind':'qa-scratch','release_when':'Actual four-launch native-state/frame and original host/guest/input outcomes exported; coordinator consumes exact admission before retiring owned VM/media.'}]})
print(json.dumps({'status':'PREPARED_UNRUN','owner':str(out),'family_seconds':1800,'cleanup_seconds':120}))

#!/usr/bin/env python3
"""Tiny isolated selected-settings controls; never import or run guest/runtime code."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import resource
import time

resource.setrlimit(resource.RLIMIT_CPU,(8,8))
resource.setrlimit(resource.RLIMIT_FSIZE,(1024*1024,1024*1024))
start=time.monotonic();root=Path(__file__).resolve().parent
candidate=ast.parse((root/'guest.py').read_text())
function=next(n for n in candidate.body if isinstance(n,ast.FunctionDef) and n.name=='selected_state_settings')
namespace={};exec(compile(ast.Module(body=[function],type_ignores=[]),'selected-state-parser-only','exec'),namespace)
parse=namespace['selected_state_settings']
original=ast.parse((root/'revision01/guest.py').read_text())
old=copy.deepcopy(next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name=='state_observation'))
assert len(old.body)>=7 and isinstance(old.body[0],ast.Assign) and isinstance(old.body[3],ast.Assert) and isinstance(old.body[4],ast.Assign) and isinstance(old.body[5],ast.For) and isinstance(old.body[6],ast.Assert)
# Only the original byte-bound, key collection and uniqueness assertion; no Path/open/runtime statements.
old.name='original_selected_assertion';old.args=ast.parse('def f(data): pass').body[0].args
old.body=[old.body[i] for i in (0,3,4,5,6)]
namespace={};exec(compile(ast.fix_missing_locations(ast.Module(body=[old],type_ignores=[])),'original-selected-assertion-only','exec'),namespace)
old_parse=namespace['original_selected_assertion']
keys={
 'wii["SuDokuL-Wii.dol"].emulator':'dolphin',
 'wii["SuDokuL-Wii.dol"].core':'dolphin-sa-wii',
 'dreamcast["Tetris2-M7.cdi"].emulator':'flycast',
 'dreamcast["Tetris2-M7.cdi"].core':'flycast-sa',
 'dreamcast["Tetris2-M7.cdi"].graphics_backend':'opengl'}
base=''.join(k+'='+v+'\n' for k,v in keys.items()).encode();results=[]
def accept(name,data,present,raw,enabled):
 row=parse(data);g=row['global_autosave'];assert g['present'] is present and g['raw_value']==raw and g['effective_enabled'] is enabled
 assert g['es_read_value']==('' if raw is None or raw=='' else raw)
 assert g['effective_label']==('On' if enabled else 'Off')
 assert {k:row['explicit_system_settings'][k] for k in keys}==keys
 assert ('global.autosave' in row['explicit_system_settings']) is present
 assert len(g['raw_occurrences'])==int(present)
 if present:
  occurrence=g['raw_occurrences'][0];assert bytes.fromhex(occurrence['value_hex'])==raw.encode()
  assert bytes.fromhex(occurrence['line_hex']).split(b'=',1)[0]==b'global.autosave'
 else:assert g['raw_occurrences']==[]
 assert 'SYNTHETIC_UNRELATED_SENTINEL' not in json.dumps(row)
 results.append({'case':name,'result':'PASS','expected':'accepted source-bound representation'})
def reject(name,data,parser=parse):
 try:parser(data)
 except AssertionError:results.append({'case':name,'result':'PASS','expected':'rejected'});return
 raise AssertionError('unexpected acceptance: '+name)
accept('omitted_off',base,False,None,False)
accept('ui_on_serialization_1',base+b'global.autosave=1\n',True,'1',True)
accept('explicit_provisioned_0',base+b'global.autosave=0\n',True,'0',False)
accept('explicit_empty_reads_default_off',base+b'global.autosave=\n',True,'',False)
accept('on_without_final_lf_preserves_raw_bytes',base+b'global.autosave=1',True,'1',True)
accept('comments_are_not_explicit_global',base+b'#global.autosave=1\n;global.autosave=1\n',False,None,False)
accept('unrelated_setting_not_disclosed',base+b'unrelated=SYNTHETIC_UNRELATED_SENTINEL\n',False,None,False)
for label,data in [('conflicting',b'0\nglobal.autosave=1'),('identical',b'1\nglobal.autosave=1'),('empty_then_on',b'\nglobal.autosave=1')]:
 reject('duplicate_global_'+label,base+b'global.autosave='+data+b'\n')
for value in (b'2',b'true',b'false',b'auto',b'default',b' 1',b'1 ',b'1#comment',b'1\r'):
 reject('invalid_global_'+repr(value),base+b'global.autosave='+value+b'\n')
for line in (b'global.autosave\n',b'global.autosave =1\n',b' global.autosave=1\n'):
 reject('malformed_global_'+repr(line),base+line)
for key,value in keys.items():
 reject('missing_per_game_'+key,base.replace((key+'='+value+'\n').encode(),b''))
reject('duplicate_per_game',base+next(iter(keys)).encode()+b'=other\n')
reject('original_regression_omitted_off',base,old_parse)
old_parse(base+b'global.autosave=1\n');results.append({'case':'original_explicit_on_control','result':'PASS','expected':'accepted'})
diag=(root/'source-evidence/failed01-diagnostic.stdout').read_text();row=json.JSONDecoder().raw_decode(diag.lstrip())[0]
assert row['sha256']=='44b3f96e8b1fcf0f6fb92cb8a1c8efa9868283d77705deb7a94d8b6ca994c6b7'
reconstructed=('\n'.join(row['selected_raw_lines'])+'\n').encode()
accept('failed01_selected_lines_reconstruction',reconstructed,False,None,False)
reject('original_regression_failed01_reconstruction',reconstructed,old_parse)
assert time.monotonic()-start<8
receipt={'schema':1,'status':'PASS_ISOLATED_PARSER_CONTROLS','count':len(results),'cases':results,'elapsed_seconds':time.monotonic()-start,'guest_sha256':hashlib.sha256((root/'guest.py').read_bytes()).hexdigest(),'original_guest_sha256':hashlib.sha256((root/'revision01/guest.py').read_bytes()).hexdigest(),'diagnostic_reconstruction_is_full_config':False,'scope':'only AST-extracted pure parser functions and synthetic/selected diagnostic bytes; no guest module import or runtime path executed','vm_service_provider_preparer_executed':False}
encoded=(json.dumps(receipt,indent=2)+'\n').encode();assert len(encoded)<65536
with (root/'parser-controls-result.json').open('xb') as out:out.write(encoded)
print(json.dumps({'status':receipt['status'],'count':len(results),'elapsed_seconds':receipt['elapsed_seconds'],'receipt_bytes':len(encoded)}))

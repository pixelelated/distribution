# Accurate global automatic-state observation

This new packet preserves immutable e7326fe6 and the failed state01 owner. The
failure occurred before a game launch: closing the installed global Game Settings
page while Off removed global.autosave, while all five explicit per-game settings
remained. Original root diagnostic stdout is retained under source-evidence/;
it binds config SHA44b3f96e8b1fcf0f6fb92cb8a1c8efa9868283d77705deb7a94d8b6ca994c6b7.
The diagnostic is selected lines plus a full-file hash, not a full config copy.
The original abort and complete owner/export outcomes remain root's originals;
this packet does not rewrite or infer those channels.

Exact pinned source is ES16dbac5211eea7e70db7394372033be2be7df829:
- GuiMenu.cpp5800 reads `get("global.autosave") == "1"`;5806 sets On to `"1"`
  and Off to `""`. These are strings, not general Python truthiness.
- SystemConf.cpp defaults38–54 contain no global.autosave. get423–436 returns
  stored/default values or `""`. The Off setter makes confMap empty; applyChanges
  removes an existing line with empty value and does not append a missing empty
  value. saveSystemConf persists those changes through the existing locked path.
- AtomicFileUtil.cpp453–470 parses exact, untrimmed keys/values, skips comment
  lines and empty values, and overwrites duplicates. The fixture intentionally
  rejects ambiguous duplicates rather than using that last-write behavior.

`selected_state_settings(data)` now requires the same five unique explicit
per-game selections. It records `global_autosave.present`, exact active raw line
and value hex, raw value or null, the source-derived ES read value and effective
Boolean/On-Off label. Missing is recorded as missing, never invented stored0.
Explicit0 and empty are also Off; only exact1 is On. Unsupported values,
noncanonical key spelling/malformed lines and duplicate active keys fail closed.
This is a narrow fixture representation policy, not a claim that ES rejects all
those inputs. An ES global Boolean is not proof of engine behavior or unsaved
live UI memory; actual global frames/native settings/log/state criteria remain.

The only existing executable changes are the observation parser/readback and
one preparer assertion binding this interpretation to exact16dbac. All other
functions, input, provisioning, controller identity, four-launch order, timing,
state/log custody, cleanup and admission behavior remain unchanged. The old
explicit0 provisioning and normal global-auto command are preserved; closing
the real Off menu may subsequently remove their line, which is now observed
accurately. No engine/player settings are repaired by this parser.

`parser-controls.py` extracts only the pure candidate function and the original
key-count assertion through AST; it does not import guest.py or execute any
runtime operation. Thirty-two controls pass in under0.01s with a4492-byte receipt:
missing/empty/explicit0 Off, exact UI On1, raw final-LF preservation, comments,
unrelated-value exclusion, conflicting/identical/empty duplicate globals,
unsupported/malformed globals, every missing per-game key, duplicate per-game,
and selected-line reconstruction of the actual diagnostic. The original parser
fails both omitted-Off regressions and accepts the explicit-On control. The
reconstruction is explicitly not the full original config.

Use the updated exact preparation block in README.md after root reviews the seal
and original failed-run teardown/consumption. It binds the actual f863 verifier
artifacts and a fresh state02 owner. Root chooses an unused display; no owner or
runtime is prepared here. Ordinary admission/launcher tools come from the same
frozen checkout. The first run launched no game, so the same four unresolved
state-only launches remain; no ordinary-game-save or broad qualification replay.

# Required observations — UNRUN

Dolphin Saved/Loaded completion is a 2000 ms OSD, not a promised log event; the immediate ten-second capture burst retains transient and later settled frames. Each listed role requires actual capture SHA, a personal review, matching host action/guest launch ID, and original log/settings/state evidence. Labels are suggestions and must be unique. Failed/pending frames remain alongside settled frames. These are four launches, not a new exhaustive matrix. UI navigation is selected from the actual frame, not hardcoded here.

| Phase | Required frame/observation | Exact accompanying evidence / acceptance |
|---|---|---|
| Before launches | `es-wii-native-selection` | Actual per-game Dolphin/dolphin-sa-wii selected; complete relevant options page has no RetroArch-only manager. Explicit stored key readback. |
| Before launches | `es-dc-native-selection` | Actual per-game Flycast/flycast-sa selected; complete relevant options page has no RetroArch-only manager. Do not mistake system default for per-game selection. |
| Before launches | `es-global-off-initial` | Actual global automatic-state setting Off; status global_autosave.effective_enabled=false with actual raw presence/value retained, native AutoLoad/Save=no; exact normalized and raw owned controller identity, profiles. |
| Wii launch1 | `wii-first-interactive` | Viewed title/puzzle within original120s, actual installed API/runemu/launcher/engine observations and generated profile. A blank first capture fails this role. |
| Wii | `wii-slot1`, `wii-scene-a`, `wii-saved-complete` | Released hotkey slot selection1, saved native state feedback, exact .s01 hash/size/mtime, timer/cursor A. No ordinary Save/Quit input. |
| Wii | `wii-changed-b` | Timer clearly advanced; visible paused scene B differs from A. The difference is recorded, not assumed. |
| Wii | `wii-load-pending-*` then `wii-loaded-complete` | One load input; retain pending Decompressing frame if seen; later completed A with earlier timer/cursor, no pending overlay; actual loaded notification/log where available. |
| Wii | `wii-loaded-responsive` | Input response or advancing timer after completed restoration. Snapshot .s01 identity and original full logs. |
| Wii exit | `wii-es-return` | One or two separately released normal shutdown requests, engine gone; no kill chord; stopped snapshot before any next launch. Native original wait status remains unknown if not recorded by installed launcher. |
| Before DC1 | `es-global-on`, `es-dc-native-selection-on` | Actual global On plus actual native per-game selection/no manager. status effective global On (stored1)/native0, no per-game native override. |
| DC1 launch2 | `dc-manual-first-interactive`, `dc-manual-scene-a` | Actual installed launch, live generated mapping/positive controller, first interactive frame≤120s. Stable non-saving menu scene A. |
| DC1 | `dc-native-slot-before`, `dc-manual-saved-complete` | Native slot shown (initial Slot1/Empty expected), one Save State action from observed menu, completed feedback, original `Saved state to PATH` and nonzero stable .state byte identity. |
| DC1 | `dc-manual-changed-b` | Distinct game menu/table B, no score/VMU save. |
| DC1 | `dc-manual-loaded-complete`, `dc-manual-responsive` | One same-slot Load input, original `Loaded state ver ... from PATH`, settled A before response input, then actual response. Pending/blank is not completion. |
| DC1 exit | `dc-native-off-before-exit-b`, `dc-global-on-es-return` | Deliberately changed B before normal native Exit; manual state hash+mtime unchanged after stopped snapshot, native auto remains no despite effective global On (stored1). No automatic save log on exit. |
| Before DC2 | `es-global-off-native-auto`, `dc-native-auto-options` | Actual global Off and actual Flycast Auto Save/Load options On (native UI may be captured after launch); positive status effective global Off/nativeyes, same selected slot. |
| DC2 launch3 | `dc-auto-save-first-interactive` | Actual launch/first interactive frame≤120s; possible prior manual-state auto-load retained as such. No manual Save in this launch. |
| DC2 | `dc-auto-scene-c`, `dc-auto-native-exit` | Stable distinctive C differs from A and normal boot; capture C before invoking menu Exit. Pre-exit snapshot still carries prior state. |
| DC2 exit | `dc-auto-saved-es-return` | Engine absent, original exit-path `Saved state to PATH`, state hash and mtime changed from manual/prior state, same slot and effective global Off. A changed file alone is insufficient. |
| DC3 launch4 | `dc-auto-cold-first-interactive`, `dc-auto-cold-restored-c` | Original cold launch and `Loaded state ver ... from PATH`, unchanged effective global Off/nativeyes/slot; scene C restored before ANY pad/manual Load input. State identity binds DC2 stopped snapshot. First interactive capture≤120s. |
| DC3 | `dc-auto-cold-responsive` | Only after C is reviewed, observed input response. Native options UI may be captured now if not yet; no manual Load. |
| Final exit | `dc-auto-cold-es-return`, `es-final-return` | Normal native Exit, absent engine, reset native/effective global Off while stopped, final selected readback; original pad destroy/supervisor/VM/watch/export outcomes retained. Fourth exit can auto-save again; do not compare that later hash as the initial cold-load identity. |

Read full original `/var/log/exec.log` snapshots **before the following launch** resets them. Status's bounded selected tails aid live review but do not replace those originals. No engine shims, log injection, telemetry inference, or acceptance from helper0. If a required message is absent, retain that explicit evidence limitation; the packet does not fabricate an automatic PASS.

Existing ordinary cold evidence is retained in `prior-evidence.json` and the durable native-result packet. Neither an SD copy nor VMU game-save replay is part of these observations. State-file names are native emulator data; they are never called ordinary game saves.

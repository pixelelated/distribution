# Native state continuation revision02 — SOURCE ONLY, VM UNRUN

This packet is `/tmp/pix-m7-native-states-20261015-02`, a narrow correction of immutable state packet e7326fe6 at `/tmp/pix-m7-native-states-20261015`. See `REVISION02.md` and `revision02-code.diff` for the exact correction and source/isolated controls. Its original lifecycle derives from accepted native03's immutable revision04 source `/tmp/m7-native-gameplay-lifecycle-20261015-03`, seal `c9d6faa5bb47950f5c73f947bf03fa925ba2fbdebc8a4d0c5ffb3824ae02379d`. It prepares four launches: one Wii manual-state proof and three Flycast manual/native-auto/global comparisons. Only source checks and the isolated pure parser controls have run for revision02. No ordinary-save replay, scoring session, compiler, VM, service, preparer or admission has run for it.

Can the VM prove this? Yes: these are installed software, settings, state and shutdown behaviors. Root records the scoped criteria in the issue and is the sole allocator and live input/frame operator. This packet does not designate an RC or close any criterion. Prior accepted ordinary game-save/cold frames remain bound to d4af5a and are identified in `prior-evidence.json`; they do not become proof for a future image.

## Dependencies and source authority

Run only after #593 frontend proof/pin integration, #594 refusal proof/integration, and the next completed integrated engineering image plus actual artifact verifier. No overlay. `source-continuity.json` captures current reviewed product bytes at 47dda767c7afc47020a3f21ab19a4493bfd5ff8a; it is a source baseline, not a predicted final commit. Preparation requires a root-supplied exact `--expected-commit`, clean `build/*` checkout HEAD, actual verifier result/input/identity commit equality, matching actual ES pin, and the exact reviewed launch/config/controller/engine recipe/patch bytes. A changed bound file requires explicit review and a new immutable packet, not a silently updated seal. Revision02 additionally requires exact ES16dbac5211eea7e70db7394372033be2be7df829 for its source-proven global-setting interpretation; it does not itself requalify #593.

The actual verifier must contain Dolphin executable, Wii launcher and achievement-helper product rows. Guest rehashes those actual installed rows; other consumed files retain the original explicit distinction between installed image identity and source-to-installed comparison. The seven qualified Flycast/control input transformations remain byte-identical. Source-only `source-references.json` binds the actual pinned engine files used to interpret native hotkeys, state filenames, saved/load messages, and automatic behavior.

Reused authored CDI, DOL, licenses and initial blank SD constructor are unchanged. All paths/checks live in the original preparer. The fixture's historical README includes the already completed ordinary-save procedure; **do not execute that historical procedure** in this continuation.

## Narrow changes

`changes.diff` preserves the historical native03-to-state01 executable delta; `revision02-code.diff` contains this correction and `revision02.diff` also includes its README/frame-plan changes. `parent/` preserves the historical parent sources and seals; `revision01/` preserves the immediately preceding state packet files and seal. `pad.py`, controller identity, provisioning/normal installed launch path, `supervisor.py`, `vm-lifecycle.py`, `census.py`, `close.py`, and all lawful game fixture files remain unchanged. There is no serial/HMP bypass or new engine input route.

- `capture --settle-seconds N` waits 0–10 seconds under the existing shared serial lock. Optional `--observe-seconds 10` captures 11 original PNGs at nominal one-second intervals, with actual timestamps and unique suffixes `-00` through `-10`; it sends no input. Individual first-interactive captures cannot use the burst. Every frame retains its original shot exit and unique label. A wait is never treated as restore completion. First-frame captures still need the original 120-second deadline. All game actions remain observed, acknowledged and released; ambiguous input is never automatically replayed.
- `status` additionally returns the five unique explicit per-game settings plus actual global.autosave presence/raw selected bytes and its source-derived ES Boolean, live native state path/hash/mtime/stability, and bounded selected original launch/state log tails. Existing live profiles now include native slot/path and positive selected per-game overrides. Full original logs remain in snapshots. No account values or raw system/emu config are returned. Unknown state path overrides or native automatic per-game overrides stop the narrow fixture for source review.
- Snapshots preserve selected live profiles, selected settings/config readback, original exec/ES logs and native state bytes, excluding packaged Sys/GameSettings and ordinary VMU/SD payloads. Each distinct native state is retained once in `state-bytes/<sha256>.bin`; every snapshot binds its original path/size/mtime/hash and copied location. A state changing during copy is rejected. This is data custody, not a state interpreter or proof of restore. No final SD copy.
- Exactly four successful launch submissions in Wii/Flycast/Flycast/Flycast order are allowed; finish requires four. The whole family remains 1800 seconds, cleanup 120, first observed interactive frame 120 per launch, unused scoring clock 360, guest evidence 448 MiB plus host 64 MiB, no NIC, 8 GiB/4 CPU. Guest manifest is capped at 4095 payloads so the unchanged exporter ceiling includes the manifest as file 4096. Historical failed export1 remains intact.

## Root-owned later preparation/allocation

The actual completed f863 source/readback are named below; root still verifies their bound originals and selects an observed unused display. The new owner must be absent. These commands are executable once those dependencies exist; they were not run here. No display or owner has been reserved. Run under actual-host access/namespace as required by the existing qualified lifecycle, after the current runtime owner has closed.

```bash
TASK_PACKET=/tmp/pix-m7-native-states-20261015-02
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02
TASK_COMMIT=f8636de1d105275dbf9420bbabbbc26f79abb10f
TASK_VERIFY=/workspace/tmp/pix-m7-image-readback-20261015-02/artifacts
TASK_OWNER=/workspace/tmp/pix-m7-native-states-20261015-02
TASK_VNC=ACTUAL_OBSERVED_FREE_DISPLAY
python3 -I -S -B "$TASK_PACKET/verify-static.py"
python3 -I -S -B "$TASK_PACKET/prepare.py" \
  --checkout "$TASK_TREE" --expected-commit "$TASK_COMMIT" \
  --verification "$TASK_VERIFY" \
  --author-owner /workspace/tmp/pix-m7-mkdcdisc-20261014-01 \
  --owner "$TASK_OWNER" --vnc "$TASK_VNC"
cd "$TASK_TREE"
tools/build-preflight
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

Wait for actual `visual-ready.json`; the 1800-second family already runs. Use only the existing action helper:

```bash
state_action() { python3 -I -S -B "$TASK_OWNER/host-action.py" "$@" --owner "$TASK_OWNER"; }
state_action status
state_action capture --label es-initial
# View the emitted local PNG, then record what is actually visible:
state_action review --label es-initial --review 'ACTUAL OBSERVATION'
```

Every call retains original stdout/stderr/return status and exact input/serial receipt. `key --key ...` uses the actual ES keyboard map and refuses while native processes exist. `pad --buttons ... --milliseconds 120` uses the unchanged exact raw/sysfs/SDL controller route. Buttons are selected from **currently viewed** frames/profile, never a fixed blind menu macro. A/B/X names and actual profile interpretation are in the preserved base source. Normal engine Exit, never the `lb,back,start` input_sense kill chord.

## Completed-restore observation rule

After one save or load action, immediately start one ten-second observation burst. View its original frames, including pending and settled frames. Dolphin's completion messages last only 2000 ms: State.cpp calls Core::DisplayMessage, and Core.cpp forwards this to OSD without logging it. A delayed single screenshot can miss the message. Flycast separately writes NOTICE Saved/Loaded state lines. Retain full original logs in both cases; do not invent Dolphin log events.

```bash
state_action capture --label wii-load --observe-seconds 10
# Emits wii-load-00 through wii-load-10 paths. View relevant original frames.
state_action review --label wii-load-XX --review 'ACTUAL PENDING OR COMPLETED OBSERVATION'
state_action status
```

Review the exact frame that shows completed restoration and a later settled frame; neither a burst nor its final frame automatically passes. If still pending, use further observation-only captures with unique labels and at most five-second waits, within a 30-second observation window measured from the original action receipt and the unchanged family deadline. Never resend Save/Load to make a frame look successful. If no completed restore is established within that window, preserve all originals and stop the acceptance claim; root decides bounded abort. The burst retains nominal spacing and actual times rather than claiming exact frame-rate sampling. The existing command/family limits remain authoritative.

A completed restore needs the saved scene/timer or cursor position reinstated, no pending overlay, a stable state identity, actual native state log/notification where emitted, and a subsequent observed input response or advancing timer. A pending Decompressing State frame does not pass. A black frame does not count as the first interactive frame. The original engine wait status remains unknown unless an existing original log exposes it; wrapper0 never becomes native exit0.

## Four launches and acceptance frames

Use labels from `frame-plan.md` and retain each capture/review. Snapshots must precede the next launch because `/var/log/exec.log` is overwritten.

**Before launch 1:** `status` must show explicit Wii Dolphin/dolphin-sa-wii and Dreamcast Flycast/flycast-sa selection, effective global Off, native AutoLoad/Save=no, positive owned controller. Navigate the installed ES per-game options for both titles and capture the actual selected native core and absence of the RetroArch-only save-state manager. Also capture the global automatic-state setting off. Do not infer UI from raw settings. First-frame deadline begins only at each actual launch.

**1 — Wii manual save/change/load.**

```bash
state_action launch --game wii
state_action status
state_action capture --label wii-first-interactive --first-frame
```

Review actual generated GCPadNew/Wiimote/control mappings before pad actions. Open a fresh puzzle; no entered-cell/ordinary Save and Quit replay. Observe a stable timer/cursor. Select native slot1 with released `back,up`; capture slot notification. Save once using `back,rt`, observe completed saved notification and .s01 creation, `snapshot --label wii-saved-a`. Retain scene A timer/cursor. Let the observed timer advance enough to distinguish rollback, then use Start to pause into scene B; capture timer/paused difference. Load once `back,lt`, perform the completed-restore observation rule, then capture unpaused scene A with restored earlier timer/cursor and one observed non-saving cursor move or timer advance. Require actual saved/loaded notification or log plus settled visual behavior; if a completion message is too transient, keep all original logs and do not invent it.

```bash
state_action pad --buttons back,up --milliseconds 120
state_action capture --label wii-slot1
state_action pad --buttons back,rt --milliseconds 120
state_action capture --label wii-save --observe-seconds 10
state_action status
state_action snapshot --label wii-saved-a
# Observe/review timer advancement, then Start to distinct paused B.
state_action pad --buttons start --milliseconds 120
state_action capture --label wii-changed-b
state_action pad --buttons back,lt --milliseconds 120
# Capture immediately; inspect completed OSD and later settled frame, then verify response.
state_action capture --label wii-load --observe-seconds 10
```

Exit via released `back,start`. Observe actual process/ES return. The first request may only tap Wii STM power; if the DOL stays active, a **second separately released** `back,start` follows the shipped orderly RequestShutdown path. Record both rather than use the force-kill chord. Require absent engine in `status` and ES return frame, then `snapshot --label wii-manual-stopped`.

**2 — Flycast effective global On (stored1)/native0, manual restore.** While stopped:

```bash
state_action global-auto --value 1
state_action status
state_action capture --label dc-global-on-native-selected
# Navigate/view global On and per-game Flycast/flycast-sa/no-manager screens.
state_action launch --game tetris2
state_action status
state_action capture --label dc-manual-first-interactive --first-frame
```

Review generated profiles before input. Use distinct game menu scenes, not score earning: the already observed Tetris menu's `High Score` selected entry can be A; entering its default high-score table can be B. Choose C later to differ from A and fresh boot. Do not choose the game's Save/VMU operation. Open Flycast's native menu with Back, capture actual Slot1/Empty, navigate from the viewed menu to **Save State**, and activate once. Observe “State saved”/original `Saved state to ...` log and nonzero `.state`, then `snapshot --label dc-manual-saved-a`. Preserve the displayed slot and resolved actual file path. Return to the game, change to B, capture; open native menu and activate **Load State** once in the same slot. Observe completed A and responsive input. `snapshot --label dc-manual-loaded-a` while settled. Change to a distinct menu B again before native-menu Exit so lack of auto rewrite is meaningful. After orderly Exit and absent process: `snapshot --label dc-global-on-native-off-stopped`. Require same manual state hash and mtime as saved A, no subsequent automatic save log, and actual native AutoSave/Load=no despite effective global On (stored1). The retained prior effective global Off/native0 case is additional historical context, not a new-image claim.

**3 — Flycast effective global Off/native1, auto-save.** While stopped:

```bash
state_action global-auto --value 0
state_action native-auto --value 1
state_action status
state_action capture --label dc-global-off-before-native-auto
# Capture actual global Off and Flycast native auto options through observed UI.
state_action launch --game tetris2
state_action status
state_action capture --label dc-auto-save-first-interactive --first-frame
```

This launch may auto-load manual state A. Retain that original load event and do not confuse it with the final proof. Native AutoSave/Load must read yes, effective global Off, same slot. Change to a distinctive stable menu scene C (for example the default high-score table, which differs from selected-menu A and initial boot); capture C and its visible distinguishing detail. Take `snapshot --label dc-auto-before-exit-c`; this records the still-prior manual state. Perform **no manual Save**. Open the actual native menu and choose Exit. Require absent process/ES return, `snapshot --label dc-auto-saved-stopped`, a changed state hash and mtime, and original `Saved state to ...` on this exit path. The file change alone is insufficient. The same selected slot is used by Flycast manual and automatic source; displayed slot1 corresponds to index0 and no `_0` filename suffix.

**4 — Flycast cold auto-restore.** Leave native yes/effective global Off unchanged.

```bash
state_action launch --game tetris2
state_action status
state_action capture --label dc-auto-cold-first-interactive --first-frame
```

Before any native-menu Load or other pad input, observe completed restored C, distinct from fresh boot/A, with original `Loaded state ver ... from ...` log, exact launch/process/slot/file binding and selected settings. Capture/review settled C; only then verify input responsiveness. This first input order is essential. Capture native auto options in actual UI if not already shown, without altering them. Normal native-menu Exit, absent process/ES return, `snapshot --label dc-auto-restored-stopped`. While stopped reset `native-auto --value 0`, `global-auto --value 0`; status must show both. The fourth normal exit may legitimately auto-save again; compare cold-load identity against the launch3 stopped snapshot before that exit, not the later final file.

## Finish and export original results

```bash
state_action native-auto --value 0
state_action global-auto --value 0
state_action status
state_action capture --label es-final-return
# View/review actual return and settings, then:
state_action finish
# Wait for actual original watcher/runner/launcher/VM completion; preserve each rc.
TASK_RUN="$TASK_TREE/.build-runs/ACTUAL_RETURNED_RUN_ID"
TASK_EXPORT=/workspace/tmp/pix-m7-native-states-evidence-20261015-01
tools/watch-build --record-only -- python3 -I -S -B "$TASK_OWNER/close.py" \
  --owner "$TASK_OWNER" --run "$TASK_RUN" --packet "$TASK_EXPORT"
```

On an ambiguous action or failure, preserve original action/frame/log receipt and use `state_action abort --label CONCRETE-REASON`; do not disguise failed originals or retry a consumed admission. Root reviews all exact frame hashes, original actual launches/state messages/settings/state bytes, teardown and exporter results, then separately consumes admission/retention. This packet does not perform acceptance, consume anything, or retire any owner.

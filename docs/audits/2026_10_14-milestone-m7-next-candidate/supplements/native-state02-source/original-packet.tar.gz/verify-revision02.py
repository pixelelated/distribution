#!/usr/bin/env python3
"""Source equivalence only; never import or execute guest/parser/runtime code."""
import ast
import copy
import hashlib
import json
from pathlib import Path

p=Path(__file__).resolve().parent;original=Path('/tmp/pix-m7-native-states-20261015')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
dump=lambda n:ast.dump(n,include_attributes=False)
assert sha(original/'SHA256SUMS')=='e7326fe60287d921566aeb679b2dc85751b5b1333d384c6e0065030745855484'
original_rows=[line.split('  ',1) for line in (original/'SHA256SUMS').read_text().splitlines()]
changed={'guest.py','prepare.py','README.md','frame-plan.md','static-review.json'}
unchanged=[]
for digest,name in original_rows:
 assert sha(original/name)==digest,name
 if name not in changed:assert sha(p/name)==digest,name;unchanged.append(name)
old=ast.parse((p/'revision01/guest.py').read_text());new=ast.parse((p/'guest.py').read_text())
functions=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
a,b=functions(old),functions(new)
assert set(b)==set(a)|{'selected_state_settings'}
for name in a:
 if name!='state_observation':assert dump(a[name])==dump(b[name]),name
assert [dump(n) for n in old.body if not isinstance(n,ast.FunctionDef)]==[dump(n) for n in new.body if not isinstance(n,ast.FunctionDef)]
expected=copy.deepcopy(a['state_observation'])
prefix="p=Path('/storage/.config/system/configs/system.cfg')\nwith p.open('rb') as f:data=f.read(1024*1024+1)\nselected=selected_state_settings(data)\n"
expected.body=ast.parse(prefix).body+expected.body[7:]
row=next(n.value for n in expected.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='row')
indexes=[i for i,k in enumerate(row.keys) if isinstance(k,ast.Constant) and k.value=='explicit_system_settings'];assert len(indexes)==1
i=indexes[0];row.keys[i]=None;row.values[i]=ast.Name(id='selected',ctx=ast.Load())
assert dump(expected)==dump(b['state_observation']),'unexpected state/hash/log/process observation change'
a=ast.parse((p/'revision01/prepare.py').read_text());b=ast.parse((p/'prepare.py').read_text())
added=ast.parse("assert pins[0]=='16dbac5211eea7e70db7394372033be2be7df829','selected global-state interpretation requires the reviewed ES source'").body[0]
assert sum(dump(n)==dump(added) for n in b.body)==1
b.body=[n for n in b.body if dump(n)!=dump(added)];assert dump(a)==dump(b),'unexpected preparer change'
controls=json.loads((p/'parser-controls-result.json').read_text());assert controls['status']=='PASS_ISOLATED_PARSER_CONTROLS' and controls['count']==32
assert controls['guest_sha256']==sha(p/'guest.py')
print(json.dumps({'status':'PASS_STATIC_REVISION02','unchanged_original_members':unchanged,'original_packet_unchanged':True,'existing_guest_functions_unchanged_except':['state_observation'],'state_observation_state_logs_hashes_process_reads':'AST-identical after parser/readback replacement','prepare_only_addition':'exact ES16dbac source binding','parser_controls_reexecuted':False,'runtime_executed':False},indent=2))

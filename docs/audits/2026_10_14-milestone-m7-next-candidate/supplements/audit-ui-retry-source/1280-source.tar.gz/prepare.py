#!/usr/bin/env python3
"""UNRUN fresh1280 refusal derivative; no directory bind bypasses the save-path guard."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=Path('/tmp/pix-m7-audit-ui-1280-plan-20261015');BASE_SEAL='2a7c4fa2ab3dadf4a131cb83d63b8381b88f926d2c3ef0f44dc82c350cecf2d8'
def sha(p):
 with p.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sealed(p,seal):
 assert sha(p/'SHA256SUMS')==seal
 for line in (p/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert not Path(n).is_absolute() and '..' not in Path(n).parts and sha(p/n)==h,n
p=argparse.ArgumentParser()
for n in ['checkout','verification','author-owner','owner']:p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--vnc',type=int,required=True);a=p.parse_args();sealed(HERE,sha(HERE/'SHA256SUMS'));sealed(BASE,BASE_SEAL)
argv=[sys.executable,'-I','-S','-B',str(BASE/'prepare.py')]
for n in ['checkout','verification','author-owner','owner']:argv+=['--'+n,str(getattr(a,n.replace('-','_')))]
argv+=['--vnc',str(a.vnc)];subprocess.run(argv,check=True,timeout=150)
out=a.owner;target=out/'source/audit-ui';shutil.copy2(HERE/'guest-audit.py',target/'guest-audit.py')
b=json.loads((target/'binding.json').read_text());b['installed_inputs']['/usr/bin/dolphin-save-paths']='507ccc96245bfc7aaca5e154ef0567cacccd0cbc9d0f999761d2fdee1fc245e8';b['packet_files']={str(f.relative_to(target)):sha(f) for f in sorted(target.rglob('*')) if f.is_file() and f!=target/'binding.json'};save(target/'binding.json',b)
c=json.loads((out/'config.json').read_text());c['source']={str(f.relative_to(out/'source')):sha(f) for f in sorted((out/'source').rglob('*')) if f.is_file()};c['audit_ui'].update(packet_seal=sha(HERE/'SHA256SUMS'),base_packet_seal=BASE_SEAL,binding_sha256=sha(target/'binding.json'),config_custody_revision='ordinary private copy, no-replace rename, exact original restoration; helper-specific positive refusal evidence');save(out/'config.json',c)
ret=json.loads((out/'retention-plan.json').read_text());ret['protected']+=[str(HERE)];ret['builds'][0]['name']='m7-dolphin-refusal-ui1280-custody-retry';ret['builds'][0]['basis']='Fresh1280 refusal-only continuation. Ordinary same-filesystem private config copy at normal path; unchanged save-path guard; exact preserved original links/modes/hashes/inodes restored. Actual helper error log/mv diagnostic plus250 and four EN/FR frames required.900s whole family+120s cleanup unchanged; prior failed owner retained.';ret['builds'][0]['evidence']=[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','vm-lifecycle.py','close.py','source/guest.py','source/audit-ui/guest-audit.py','host-audit.py']];save(out/'retention-plan.json',ret)
adm=json.loads((out/'admission-plan.json').read_text());adm['stage']='m7-dolphin-refusal-ui1280-custody-retry';save(out/'admission-plan.json',adm)
save(out/'records/refusal-custody-preparation.json',{'status':'PREPARED_UNRUN','packet_seal':sha(HERE/'SHA256SUMS'),'base_packet_seal':BASE_SEAL,'base_prepare_argv':argv,'prior_original_failure':'/workspace/tmp/pix-m7-audit-ui-1280-20261015-01','scope':'Four1280 refusal frames only; correct ordinary config custody; no Wi-Fi control execution.'})
print(json.dumps({'owner':str(out),'status':'PREPARED_UNRUN','work_seconds':900,'cleanup_seconds':120,'panel':[1280,800],'operator':str(out/'host-audit.py')}))

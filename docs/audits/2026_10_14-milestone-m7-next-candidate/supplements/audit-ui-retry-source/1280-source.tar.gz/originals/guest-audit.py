#!/usr/bin/env python3
"""UNRUN additive actions inside a fresh accepted native no-NIC guest owner."""
import argparse,hashlib,json,os,re,shlex,shutil,signal,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE.parent))
from guest import R as NATIVE,api,identity,natives,run,save,sha
R=NATIVE.parent/'audit-ui';B=json.loads((HERE/'binding.json').read_text())
PRIVATE=Path('/run/pix-audit-ui');SYSTEM=Path('/storage/.config/system/configs/system.cfg');SETTINGS=Path('/storage/.config/emulationstation/es_settings.cfg')
def require_guest():
 assert B['panel']==[1280,800] and B['refusal_only']
 assert os.getuid()==0 and sorted(x.name for x in Path('/sys/class/net').iterdir())==['lo']
 v=json.loads((HERE.parent.parent/'final-image-result.json').read_text());assert v['source']==B['guest_build_commit'] and v['status']=='PASS'
 assert 'BUILD_ID="'+B['guest_build_commit']+'"' in Path('/etc/os-release').read_text()
 assert NATIVE.is_dir() and not natives()
 for name,h in B['packet_files'].items():assert sha(HERE/name)==h,name
 assert re.fullmatch('[0-9a-f]{64}',B['candidate_es_sha256'])
def es_pids():
 rows=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   if (p/'comm').read_text().strip() in ['emulationstation','emulationstatio']:
    row=identity(int(p.name));row['exe_sha256']=sha(p/'exe');assert row['exe_sha256'] in [B['installed_inputs']['/usr/bin/emulationstation'],B['candidate_es_sha256']];rows.append(row)
  except (FileNotFoundError,ProcessLookupError):pass
 return rows
def mounts():
 return [line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()]
def bind(source,target):
 target=Path(target);assert str(target) not in mounts(),'pre-existing target bind refuses fixture'
 before={'path':str(target),'sha256':sha(target) if target.is_file() else None}
 run('audit-bind',['mount','--bind',source,target],5);run('audit-private',['mount','--make-private',target],5)
 assert target.stat().st_ino==Path(source).stat().st_ino and target.stat().st_dev==Path(source).stat().st_dev
 rows=json.loads((R/'mounts.json').read_text());rows.append(dict(before,source=str(source)));save(R/'mounts.json',rows)
def unbind_all():
 rows=json.loads((R/'mounts.json').read_text())
 for row in reversed(rows):
  target=Path(row['path']);source=Path(row['source']);assert mounts().count(str(target))==1
  assert target.stat().st_ino==source.stat().st_ino and target.stat().st_dev==source.stat().st_dev
  run('audit-unbind',['umount',target],5)
  if row['sha256']:assert sha(target)==row['sha256']
 save(R/'mounts.json',[])
def settings(language):
 values=[('system.language',language),('global.retroachievements','0'),('global.retroachievements.offlineproxy','0')]
 run('audit-settings',['bash','-ec','. /etc/profile; '+ '; '.join('set_setting '+shlex.quote(k)+' '+shlex.quote(v) for k,v in values)],10)
 tree=ET.parse(SETTINGS);root=tree.getroot();assert root.tag=='config'
 for key,value in [('LogLevel','information'),('StartupSystem','wii')]:
  matches=root.findall("string[@name='"+key+"']");assert len(matches)<=1
  node=matches[0] if matches else ET.SubElement(root,'string',{'name':key});node.set('value',value)
 tree.write(SETTINGS,encoding='utf-8',xml_declaration=True)
def stop_es():
 assert not natives();run('audit-stop-es',['systemctl','stop','essway.service'],30);assert not es_pids()
def start_es():
 run('audit-start-es',['systemctl','start','essway.service'],40)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':return
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
def refusal(language):
 assert language in ['en_US','fr_FR']
 stop_es();unbind_all();settings(language)
 bind(HERE/'emulationstation','/usr/bin/emulationstation')
 bind(PRIVATE/'cheevos_dolphin.sh','/usr/bin/cheevos_dolphin.sh');bind(PRIVATE/'start_dolphin_wii.sh','/usr/bin/start_dolphin_wii.sh')
 config=PRIVATE/('dolphin-'+language);assert not config.exists();src=Path('/storage/.config/dolphin-emu')
 files=[f for f in src.rglob('*') if f.is_file() and not f.is_symlink()];assert len(files)<=4096 and sum(f.stat().st_size for f in files)<=32*1024**2
 shutil.copytree(src,config,symlinks=True);target=config/'RetroAchievements.ini'
 if target.exists() or target.is_symlink():
  assert target.is_file() or target.is_symlink();target.rename(config/'RetroAchievements.ini.fixture-original')
 target.mkdir();(target/'sentinel').write_text('private refusal target, preserve this member\n');bind(config,src)
 start_es();before={'es':es_pids(),'exec_log_sha256':sha(Path('/var/log/exec.log')) if Path('/var/log/exec.log').exists() else None,'config_clone':str(config)}
 save(R/('refusal-'+language+'-before.json'),before)
 prior_errors=Path('/var/log/es_log.txt').read_text().count('capture rotation: not recorded, the launch exited 250')
 launch=api('/launch','/storage/roms/wii/SuDokuL-Wii.dol');save(R/('refusal-'+language+'-launch.json'),launch)
 deadline=time.monotonic()+30
 while True:
  assert not natives(),'engine unexpectedly reached'
  text=Path('/var/log/es_log.txt').read_text()
  if text.count('capture rotation: not recorded, the launch exited 250')==prior_errors+1:break
  assert time.monotonic()<deadline;time.sleep(.1)
 assert (target/'sentinel').read_text()=='private refusal target, preserve this member\n'
 for name,path in [('exec-log','/var/log/exec.log'),('es-log','/var/log/es_log.txt'),('cheevos-log','/var/log/cheevos.log')]:
  text=Path(path).read_bytes();assert len(text)<=2*1024**2;(R/('refusal-'+language+'-'+name)).write_bytes(text)
 result={'rc':0,'language':language,'original_launch_exit':250,'exit_evidence':'actual ES log; helper/launcher status propagation through installed runemu','es':es_pids(),'native_processes':natives(),'private_target_directory_preserved':True,'frame_review':'pending'}
 save(R/('refusal-'+language+'-result.json'),result);return result
def cleanup():
 stop_es();unbind_all()
 for src,dst in [('system.cfg',SYSTEM),('es_settings.cfg',SETTINGS)]:shutil.copy2(R/'originals'/src,dst);assert sha(dst)==sha(R/'originals'/src)
 for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
 start_es();save(R/'restored.json',{'rc':0,'original_input_hashes_restored':True,'mounts':json.loads((R/'mounts.json').read_text())});return {'rc':0}
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['init','refusal','cleanup']);p.add_argument('--language',choices=['en_US','fr_FR']);a=p.parse_args();require_guest()
 if a.action=='init':
  assert not R.exists() and not PRIVATE.exists();R.mkdir();PRIVATE.mkdir();(R/'originals').mkdir();save(R/'mounts.json',[])
  for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
  for src,name in [(SYSTEM,'system.cfg'),(SETTINGS,'es_settings.cfg')]:shutil.copy2(src,R/'originals'/name)
  shutil.copy2(HERE/'source/cheevos_dolphin.after.sh',PRIVATE/'cheevos_dolphin.sh');os.chmod(PRIVATE/'cheevos_dolphin.sh',0o755)
  before=(HERE/'source/launcher-wii.before.snippet').read_bytes();after=(HERE/'source/launcher-wii.after.snippet').read_bytes();raw=Path('/usr/bin/start_dolphin_wii.sh').read_bytes();assert raw.count(before)==1
  candidate=raw.replace(before,after,1);(PRIVATE/'start_dolphin_wii.sh').write_bytes(candidate);os.chmod(PRIVATE/'start_dolphin_wii.sh',0o755)
  save(R/'bindings.json',dict(B,derived_installed_launcher_sha256=hashlib.sha256(candidate).hexdigest()));result={'rc':0}
 else:
  assert R.is_dir()
  result=cleanup() if a.action=='cleanup' else refusal(a.language)
 print('PIX_AUDIT_JSON='+json.dumps(result))
if __name__=='__main__':main()

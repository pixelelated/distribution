# #594 refusal1280 ordinary-copy continuation — SOURCE ONLY, UNRUN

This fresh-owner derivative corrects the fixture in
`/tmp/pix-m7-audit-ui-1280-plan-20261015`, seal
`2a7c4fa2ab3dadf4a131cb83d63b8381b88f926d2c3ef0f44dc82c350cecf2d8`.
That original source and its failed1280 owner remain immutable. The actual
original frame/exec showed the save-path guard rejecting the separately mounted
config before the achievements helper ran. Absent cheevos.log was correct;
numeric250 was insufficient. Compact original diagnostics/frame are retained.

Only guest-audit.py and its fresh preparation wrapper change. The same ordinary
config custody functions are used by the fresh640 navigation continuation.
With ES stopped and no native engine, a bounded lstat inventory records every
original file hash, symlink target, mode, uid/gid and dev/inode. A same-filesystem
copy is checked by content, then RENAME_NOREPLACE preserves the original and
moves the copy into the ordinary normal config path. No directory bind remains.
The installed dolphin-save-paths hash507ccc96245bfc7aaca5e154ef0567cacccd0cbc9d0f999761d2fdee1fc245e8
is bound and its normal check must pass before the actual launcher/API invocation.
No product guard is changed, bypassed or shimmed.

Only the private copy's RetroAchievements.ini is made a directory. The real helper
must produce a fresh exact two-line disabled/publication-error log and the exact
target BusyBox mv directory-refusal line, plus fresh ES250 and unchanged sentinel.
Expected bytes were compared with accepted controls02 case13's original log and
stderr, preserved with their hashes here. Both locales require personally reviewed
frames with the exact intended title/body, named in their result receipts.
A missing helper log or unrelated earlier250 remains a failed observation.

Before the next locale and at normal cleanup, the active copy's owned root is
verified and renamed aside; the held original is renamed back without replacement.
The entire original lstat manifest, including identities/modes/symlinks/hashes,
must match. Completed copies stay in the disposable guest; only manifests leave
it. No data is deleted. Partial phases refuse ambiguous recovery and preserve
the trees; an aborted guest cannot claim normal restoration.

All inherited no-NIC lifecycle/profile/process/serial/stop/export controls and
1280x800 generated-device/PNG assertions remain unchanged. Exactly four EN/FR
refusal/return frames are required. No Wi-Fi action, worker control or gameplay
runs. Final d4af/ES3178 image has explicit ES16dbac and #594 product47dda767
overlays, with exact source/binary binding inherited from the base. Rebuilt-image
acceptance remains pending. Can this be done on the VM? Yes: both rendering
profiles and normal error presentation need no physical fact. Root records the
focused continuation before allocation; this is no handheld/radio claim.

Unchanged bound: one fresh no-NIC8GiB/4CPU/16GiB guest,900s whole family plus120s
cleanup;128MiB output/4096files including manifest and64MiB host frames. Ordinary
config inventories cap4096entries/32MiB; only this synthetic guest is modified.
No runtime, preparer, VM, compiler, product helper or fixture has executed from
this source packet.

Root-only preparation, after current owners are consumed; verify VNC141 is free:

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01
TASK_PACKET=/tmp/pix-m7-audit-ui-1280-retry-plan-20261015
TASK_OWNER=/workspace/tmp/pix-m7-audit-ui-1280-20261015-02
python3 -I -S -B "$TASK_PACKET/prepare.py" --checkout "$TASK_TREE" \
  --verification /workspace/tmp/pix-m7-image-readback-20261015-01/artifacts \
  --author-owner /workspace/tmp/pix-m7-mkdcdisc-20261014-01 \
  --owner "$TASK_OWNER" --vnc 141
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
# Review original report/watch and exclusive allocation before admission.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

After actual visual-ready, perform sequentially:

```bash
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" init
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" cleanup
```

View all four PNGs and use unchanged `host-action.py --owner "$TASK_OWNER" review
--label LABEL --review TEXT`, explicitly comparing refusal title/body to the
result's expected localized strings. Then `host-audit.py --owner "$TASK_OWNER"
finish`; await original lifecycle/launcher completion and export with unchanged
`close.py --owner "$TASK_OWNER" --run ACTUAL_RUN --packet FRESH_EXPORT`.
Root reviews all originals/restoration/absence, consumes admission, and owns any
later guarded retirement. This packet performs no admission, staging, commit,
pin promotion or runtime acceptance.

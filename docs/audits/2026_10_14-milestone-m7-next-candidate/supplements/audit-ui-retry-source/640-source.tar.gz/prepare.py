#!/usr/bin/env python3
"""UNRUN fresh640 navigation derivative; preserves original failed owner and seals."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=Path('/tmp/pix-m7-audit-ui-plan-20261015');BASE_SEAL='61bab02371cd65a6b8bd0b22fa0d8a82fdba93dea54476e29355406b901c6958'
def sha(p):
 with p.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sealed(p,seal):
 assert sha(p/'SHA256SUMS')==seal
 for line in (p/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1);assert not Path(n).is_absolute() and '..' not in Path(n).parts and sha(p/n)==h,n
p=argparse.ArgumentParser()
for n in ['checkout','verification','author-owner','owner']:p.add_argument('--'+n,type=Path,required=True)
p.add_argument('--vnc',type=int,required=True);a=p.parse_args();sealed(HERE,sha(HERE/'SHA256SUMS'));sealed(BASE,BASE_SEAL)
argv=[sys.executable,'-I','-S','-B',str(BASE/'prepare.py')]
for n in ['checkout','verification','author-owner','owner']:argv+=['--'+n,str(getattr(a,n.replace('-','_')))]
argv+=['--vnc',str(a.vnc)];subprocess.run(argv,check=True,timeout=120)
out=a.owner;target=out/'source/audit-ui';shutil.copy2(HERE/'host-audit.py',out/'host-audit.py');shutil.copy2(HERE/'guest-audit.py',target/'guest-audit.py')
b=json.loads((target/'binding.json').read_text());b['installed_inputs']['/usr/bin/dolphin-save-paths']='507ccc96245bfc7aaca5e154ef0567cacccd0cbc9d0f999761d2fdee1fc245e8';b['packet_files']={str(f.relative_to(target)):sha(f) for f in sorted(target.rglob('*')) if f.is_file() and f!=target/'binding.json'};save(target/'binding.json',b)
c=json.loads((out/'config.json').read_text());c['code']['host-audit.py']=sha(out/'host-audit.py');c['source']={str(f.relative_to(out/'source')):sha(f) for f in sorted((out/'source').rglob('*')) if f.is_file()};c['audit_ui'].update(packet_seal=sha(HERE/'SHA256SUMS'),base_packet_seal=BASE_SEAL,binding_sha256=sha(target/'binding.json'),navigation_revision='GENERIC_X64 conditional NETWORK NAME; six downs and reviewed pre-activation frame');save(out/'config.json',c)
ret=json.loads((out/'retention-plan.json').read_text());ret['protected']+=[str(HERE)];ret['builds'][0]['name']='m7-audit-ui-navigation-retry';ret['builds'][0]['basis']='Fresh640 narrow suite retry. Same four fast worker controls and GUI/refusal flows; exact GENERIC_X64 hostname condition adds NETWORK NAME row. Six downs plus personally reviewed selected-WI-FI-NETWORK frame before activation.1200s whole family+120s cleanup unchanged; original failed owner retained; ten frames including two pre-activation gates.';ret['builds'][0]['evidence']=[{'path':str(out/n),'sha256':sha(out/n)} for n in ['config.json','vm-lifecycle.py','source/guest.py','source/audit-ui/guest-audit.py','host-audit.py']];save(out/'retention-plan.json',ret)
adm=json.loads((out/'admission-plan.json').read_text());adm['stage']='m7-audit-ui-navigation-retry';save(out/'admission-plan.json',adm)
save(out/'records/navigation-preparation.json',{'status':'PREPARED_UNRUN','packet_seal':sha(HERE/'SHA256SUMS'),'base_packet_seal':BASE_SEAL,'base_prepare_argv':argv,'prior_original_failure':'/workspace/tmp/pix-m7-audit-ui-evidence-20261015-01','scope':'Fresh exact narrow suite; no replay in original owner; unchanged four driver controls; source-bound menu route and reviewed activation gate.'})
print(json.dumps({'owner':str(out),'status':'PREPARED_UNRUN','work_seconds':1200,'cleanup_seconds':120,'panel':[640,480],'operator':str(out/'host-audit.py')}))

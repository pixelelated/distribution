#!/usr/bin/env python3
"""UNRUN additive actions inside a fresh accepted native no-NIC guest owner."""
import argparse,hashlib,json,os,re,shlex,shutil,signal,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE.parent))
from guest import R as NATIVE,api,identity,natives,run,save,sha
R=NATIVE.parent/'audit-ui';B=json.loads((HERE/'binding.json').read_text())
PRIVATE=Path('/run/pix-audit-ui');SYSTEM=Path('/storage/.config/system/configs/system.cfg');SETTINGS=Path('/storage/.config/emulationstation/es_settings.cfg')
def require_guest():
 assert os.getuid()==0 and sorted(x.name for x in Path('/sys/class/net').iterdir())==['lo']
 v=json.loads((HERE.parent.parent/'final-image-result.json').read_text());assert v['source']==B['guest_build_commit'] and v['status']=='PASS'
 assert 'BUILD_ID="'+B['guest_build_commit']+'"' in Path('/etc/os-release').read_text()
 assert NATIVE.is_dir() and not natives()
 for name,h in B['packet_files'].items():assert sha(HERE/name)==h,name
 assert re.fullmatch('[0-9a-f]{64}',B['candidate_es_sha256'])
def es_pids():
 rows=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   if (p/'comm').read_text().strip() in ['emulationstation','emulationstatio']:
    row=identity(int(p.name));row['exe_sha256']=sha(p/'exe');assert row['exe_sha256'] in [B['installed_inputs']['/usr/bin/emulationstation'],B['candidate_es_sha256']];rows.append(row)
  except (FileNotFoundError,ProcessLookupError):pass
 return rows
def mounts():
 return [line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines()]
def bind(source,target):
 target=Path(target);assert str(target) not in mounts(),'pre-existing target bind refuses fixture'
 before={'path':str(target),'sha256':sha(target) if target.is_file() else None}
 run('audit-bind',['mount','--bind',source,target],5);run('audit-private',['mount','--make-private',target],5)
 assert target.stat().st_ino==Path(source).stat().st_ino and target.stat().st_dev==Path(source).stat().st_dev
 rows=json.loads((R/'mounts.json').read_text());rows.append(dict(before,source=str(source)));save(R/'mounts.json',rows)
def unbind_all():
 rows=json.loads((R/'mounts.json').read_text())
 for row in reversed(rows):
  target=Path(row['path']);source=Path(row['source']);assert mounts().count(str(target))==1
  assert target.stat().st_ino==source.stat().st_ino and target.stat().st_dev==source.stat().st_dev
  run('audit-unbind',['umount',target],5)
  if row['sha256']:assert sha(target)==row['sha256']
 save(R/'mounts.json',[])
def settings(language,wifi=False):
 values=[('system.language',language),('global.retroachievements','0'),('global.retroachievements.offlineproxy','0')]
 if wifi:values += [('wifi.enabled','1'),('wifi.adhoc.enabled','0')]
 run('audit-settings',['bash','-ec','. /etc/profile; '+ '; '.join('set_setting '+shlex.quote(k)+' '+shlex.quote(v) for k,v in values)],10)
 tree=ET.parse(SETTINGS);root=tree.getroot();assert root.tag=='config'
 for key,value in [('LogLevel','information'),('StartupSystem','wii')]:
  matches=root.findall("string[@name='"+key+"']");assert len(matches)<=1
  node=matches[0] if matches else ET.SubElement(root,'string',{'name':key});node.set('value',value)
 tree.write(SETTINGS,encoding='utf-8',xml_declaration=True)
def stop_es():
 assert not natives();run('audit-stop-es',['systemctl','stop','essway.service'],30);assert not es_pids()
def start_es():
 run('audit-start-es',['systemctl','start','essway.service'],40)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':return
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
def controls():
 out=R/'controls';out.mkdir();rows=[]
 for name,binary,mode,expected in [('baseline-explicit','baseline','explicit',1),('candidate-explicit','candidate','explicit',0),('candidate-atexit','candidate','atexit',0),('candidate-complete','candidate','complete',0)]:
  argv=['python3','-I','-S','-B',str(HERE/'worker-observer.py'),'--binary',str(HERE/'drivers'/binary),'--binary-sha256',B['drivers'][binary]['sha256'],'--backend-dir',str(HERE/'worker-proof/fixtures/bin'),'--output',str(out/name),'--mode',mode]
  row={'name':name,'argv':argv,'original_returncode':None,'expected_original_returncode':expected,'timed_out':False}
  with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
   p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True)
   fd=os.pidfd_open(p.pid,0)  # Unreaped direct child cannot be replaced by another PID.
   try:
    try:row['original_returncode']=p.wait(timeout=20)
    except subprocess.TimeoutExpired:
     row['timed_out']=True;signal.pidfd_send_signal(fd,signal.SIGTERM,None,0)
     try:row['original_returncode']=p.wait(timeout=6)
     except subprocess.TimeoutExpired:
      signal.pidfd_send_signal(fd,signal.SIGKILL,None,0);row['original_returncode']=p.wait(timeout=2)
   finally:os.close(fd)
  save(out/(name+'.command.json'),row);rows.append(row);save(out/'original-commands.json',rows)
  assert row['original_returncode']==expected and not row['timed_out']
  result=json.loads((out/name/'result.json').read_text());assert not result['survivors_after_cleanup'] and result['driver_original_returncode']==0
  if expected:assert result['status']=='FAIL' and result['owned_identities_still_present'] and result['original_observation_returncode']==1
  else:assert result['status']=='PASS' and not result['forced_cleanup']
 save(out/'review.json',{'rc':0,'originals':rows,'baseline_remains_failed':True});return {'rc':0,'controls':4}
def wifi_route():
 # Exact installed fresh-image hostname adds GuiMenu.cpp9910's NETWORK NAME row.
 # Read only these public fixture settings; never retain the whole live config.
 values={}
 for key in ['system.hostname','wifi.enabled','wifi.adhoc.enabled']:
  rows=[line.split('=',1)[1] for line in SYSTEM.read_text().splitlines() if line.startswith(key+'=')]
  assert len(rows)==1,(key,'missing or duplicate fixture setting');values[key]=rows[0]
 assert values=={'system.hostname':'GENERIC_X64','wifi.enabled':'1','wifi.adhoc.enabled':'0'},values
 return {'settings':values,'clean_network_name':'GENERIC-X64','conditional_network_name_row':True,'down_steps_to_wifi_network':6}
def wifi_start(mode):
 assert mode in ['baseline','candidate'];assert json.loads((R/'controls/review.json').read_text())['rc']==0
 if (R/'wifi-current.json').exists():assert json.loads((R/'wifi-current.json').read_text())['closed']
 stop_es();unbind_all();settings('en_US',True);route=wifi_route()
 if mode=='candidate':bind(HERE/'emulationstation','/usr/bin/emulationstation')
 bind(PRIVATE/'wifictl','/usr/bin/wifictl')
 expected=B['candidate_es_sha256'] if mode=='candidate' else B['installed_inputs']['/usr/bin/emulationstation']
 label='wifi-'+mode;argv=['python3','-I','-S','-B',str(HERE/'wifi-owner.py'),'--output',str(R/label),'--binary-sha256',expected]
 if mode=='baseline':argv+=['--known-bad']
 with (R/(label+'.owner.stdout')).open('xb') as out,(R/(label+'.owner.stderr')).open('xb') as err:
  child=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True)
 row={'closed':False,'mode':mode,'output':str(R/label),'owner':identity(child.pid),'binary_sha256':expected,'menu_route':route};save(R/'wifi-current.json',row)
 deadline=time.monotonic()+45
 while not (R/label/'frontend-ready.json').exists():
  assert child.poll() is None and time.monotonic()<deadline;time.sleep(.1)
 deadline=time.monotonic()+30
 while True:
  try:
   if api('/isIdle')['body'].replace(' ','').strip()=='[true]':break
  except (OSError,TimeoutError):pass
  assert time.monotonic()<deadline;time.sleep(.2)
 return row
def wifi_state():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output'])
 assert not row['closed'] and not (case/'owner-result.json').exists()
 assert identity(row['owner']['pid'])['start_ticks']==row['owner']['start_ticks']
 frontend=json.loads((case/'frontend-ready.json').read_text())['identity'];assert identity(frontend['pid'])['start_ticks']==frontend['start_ticks']
 assert wifi_route()==row['menu_route']
 result={'case':row,'blocked':json.loads((case/'blocked-ready.json').read_text()) if (case/'blocked-ready.json').exists() else None,'calls':(case/'invocations').read_text().splitlines() if (case/'invocations').exists() else []}
 if result['blocked']:
  for item in result['blocked']['group']:
   actual=identity(item['pid']);assert actual['start_ticks']==item['start_ticks'] and actual['state']!='Z'
 return result
def wifi_exit():
 row=json.loads((R/'wifi-current.json').read_text());case=Path(row['output']);assert (case/'blocked-ready.json').exists()
 with (case/'continue-exit').open('x') as f:f.write('normal SIGINT after reviewed Back/reopen flow\n')
 deadline=time.monotonic()+20
 while not (case/'owner-result.json').exists():assert time.monotonic()<deadline;time.sleep(.05)
 owner=json.loads((case/'owner-result.json').read_text());result=json.loads((case/'result.json').read_text());expected=1 if row['mode']=='baseline' else 0
 assert owner['original_returncode']==expected and not owner['timed_out'] and result['final_returncode']==expected
 assert not result['survivors_after_cleanup']
 if expected:assert result['driver_original_returncode']==0 and result['owned_identities_still_present']
 else:assert result['driver_original_returncode']==0 and not result['forced_cleanup']
 while Path('/proc',str(row['owner']['pid'])).exists():assert time.monotonic()<deadline;time.sleep(.05)
 assert not es_pids();row['closed']=True;save(R/'wifi-current.json',row);return {'rc':0,'observation_original_returncode':expected,'result':result}
def refusal(language):
 assert language in ['en_US','fr_FR'];assert json.loads((R/'wifi-current.json').read_text())['closed']
 stop_es();unbind_all();settings(language)
 bind(HERE/'emulationstation','/usr/bin/emulationstation')
 bind(PRIVATE/'cheevos_dolphin.sh','/usr/bin/cheevos_dolphin.sh');bind(PRIVATE/'start_dolphin_wii.sh','/usr/bin/start_dolphin_wii.sh')
 config=PRIVATE/('dolphin-'+language);assert not config.exists();src=Path('/storage/.config/dolphin-emu')
 files=[f for f in src.rglob('*') if f.is_file() and not f.is_symlink()];assert len(files)<=4096 and sum(f.stat().st_size for f in files)<=32*1024**2
 shutil.copytree(src,config,symlinks=True);target=config/'RetroAchievements.ini'
 if target.exists() or target.is_symlink():
  assert target.is_file() or target.is_symlink();target.rename(config/'RetroAchievements.ini.fixture-original')
 target.mkdir();(target/'sentinel').write_text('private refusal target, preserve this member\n');bind(config,src)
 start_es();before={'es':es_pids(),'exec_log_sha256':sha(Path('/var/log/exec.log')) if Path('/var/log/exec.log').exists() else None,'config_clone':str(config)}
 save(R/('refusal-'+language+'-before.json'),before)
 prior_errors=Path('/var/log/es_log.txt').read_text().count('capture rotation: not recorded, the launch exited 250')
 launch=api('/launch','/storage/roms/wii/SuDokuL-Wii.dol');save(R/('refusal-'+language+'-launch.json'),launch)
 deadline=time.monotonic()+30
 while True:
  assert not natives(),'engine unexpectedly reached'
  text=Path('/var/log/es_log.txt').read_text()
  if text.count('capture rotation: not recorded, the launch exited 250')==prior_errors+1:break
  assert time.monotonic()<deadline;time.sleep(.1)
 assert (target/'sentinel').read_text()=='private refusal target, preserve this member\n'
 for name,path in [('exec-log','/var/log/exec.log'),('es-log','/var/log/es_log.txt'),('cheevos-log','/var/log/cheevos.log')]:
  text=Path(path).read_bytes();assert len(text)<=2*1024**2;(R/('refusal-'+language+'-'+name)).write_bytes(text)
 result={'rc':0,'language':language,'original_launch_exit':250,'exit_evidence':'actual ES log; helper/launcher status propagation through installed runemu','es':es_pids(),'native_processes':natives(),'private_target_directory_preserved':True,'frame_review':'pending'}
 save(R/('refusal-'+language+'-result.json'),result);return result
def cleanup():
 if (R/'wifi-current.json').exists():
  row=json.loads((R/'wifi-current.json').read_text());assert row['closed'],'observer still owned; wait finite observer or abort guest, do not unbind live code'
 stop_es();unbind_all()
 for src,dst in [('system.cfg',SYSTEM),('es_settings.cfg',SETTINGS)]:shutil.copy2(R/'originals'/src,dst);assert sha(dst)==sha(R/'originals'/src)
 for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
 start_es();save(R/'restored.json',{'rc':0,'original_input_hashes_restored':True,'mounts':json.loads((R/'mounts.json').read_text())});return {'rc':0}
def main():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['init','controls','wifi-start','wifi-state','wifi-exit','refusal','cleanup']);p.add_argument('--mode',choices=['baseline','candidate']);p.add_argument('--language',choices=['en_US','fr_FR']);a=p.parse_args();require_guest()
 if a.action=='init':
  assert not R.exists() and not PRIVATE.exists();R.mkdir();PRIVATE.mkdir();(R/'originals').mkdir();save(R/'mounts.json',[])
  for path,h in B['installed_inputs'].items():assert sha(Path(path))==h,path
  for src,name in [(SYSTEM,'system.cfg'),(SETTINGS,'es_settings.cfg')]:shutil.copy2(src,R/'originals'/name)
  shutil.copy2(HERE/'source/wifictl',PRIVATE/'wifictl');os.chmod(PRIVATE/'wifictl',0o755)
  shutil.copy2(HERE/'source/cheevos_dolphin.after.sh',PRIVATE/'cheevos_dolphin.sh');os.chmod(PRIVATE/'cheevos_dolphin.sh',0o755)
  before=(HERE/'source/launcher-wii.before.snippet').read_bytes();after=(HERE/'source/launcher-wii.after.snippet').read_bytes();raw=Path('/usr/bin/start_dolphin_wii.sh').read_bytes();assert raw.count(before)==1
  candidate=raw.replace(before,after,1);(PRIVATE/'start_dolphin_wii.sh').write_bytes(candidate);os.chmod(PRIVATE/'start_dolphin_wii.sh',0o755)
  save(R/'bindings.json',dict(B,derived_installed_launcher_sha256=hashlib.sha256(candidate).hexdigest()));result={'rc':0}
 else:
  assert R.is_dir()
  result={'controls':controls,'wifi-state':wifi_state,'wifi-exit':wifi_exit,'cleanup':cleanup}.get(a.action,lambda: wifi_start(a.mode) if a.action=='wifi-start' else refusal(a.language))()
 print('PIX_AUDIT_JSON='+json.dumps(result))
if __name__=='__main__':main()

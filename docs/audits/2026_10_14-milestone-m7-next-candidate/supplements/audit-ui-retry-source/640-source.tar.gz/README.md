# #593/#594 fresh640 navigation continuation — SOURCE ONLY, UNRUN

This is a fresh-owner derivative of sealed packet
`/tmp/pix-m7-audit-ui-plan-20261015`, seal
`61bab02371cd65a6b8bd0b22fa0d8a82fdba93dea54476e29355406b901c6958`.
The first runtime remains failed. Its completed four worker controls remain
original accepted evidence; its actual GUI attempt never opened the picker.
Root exported that original at
`/workspace/tmp/pix-m7-audit-ui-evidence-20261015-01` before this continuation.
No old owner, sealed source, product file or live tool is edited.

The exact cause was fixture navigation. GuiMenu.cpp9871–9872 reads the correct
`wifi.enabled`/`wifi.adhoc.enabled` keys. Lines9910–9913 insert NETWORK NAME when
cleaning `system.hostname` changes it. The fresh default GENERIC_X64 becomes
GENERIC-X64, so this image has that extra row; Enable Wi-Fi is row5 and WI-FI
NETWORK is row6. The inherited five-down route pressed Enable Wi-Fi and turned
it off. The actual captured frame shows the extra row and OFF switch; the
original serial receipt says blocked:null and calls current, has_ap_mode,
disable. These compact originals and source excerpt are retained in `evidence/`.
This failure says nothing about the normal-exit orphan criterion.

The two additive action scripts and their preparer binding change. Before starting either observed ES,
the guest requires exactly hostname GENERIC_X64, wifi.enabled1 and adhoc0 from
unique settings rows. It records the source-backed conditional row and six-down
route. `wifi-select` moves to the row and captures it without activation.
Root must view that exact frame, then record this exact review through the
unchanged review helper:

`WI-FI NETWORK selected; ENABLE WI-FI ON; activate this bound picker.`

The separate `wifi-activate` requires that reviewed image hash/path/source binding,
the same case/owner/frontend and unchanged setting readback, and no enumeration
or unexpected backend command before pressing A. Thus a misplaced selector cannot
silently flip the switch again. Both pre-activation frames are required at finish,
so the existing eight proof frames become ten. They add no product UI change.

All compiler binaries, worker observers, backends, four control modes/oracles,
GUI observer deadlines, normal SIGINT signal, bounded process custody cleanup,
candidate no-forced-cleanup requirement, lifecycle, serial lock, no-NIC helper
and exporter remain byte-identical to the sealed base. Root permits
the four fast controls to repeat within this one narrow failed-suite retry;
keeping their established prerequisite avoids a new evidence-import bypass.
No broad accepted matrix is rerun. Baseline negative observations remain failures.

The separate1280 run01 exposed a second fixture defect before the intended
helper: binding the cloned config triggered the existing dolphin-save-paths
nested-mount guard. That original failed250/frame is retained in `evidence/`.
Both fresh continuations now use identical ordinary-copy custody. With ES stopped
and no native engine, a bounded lstat inventory records every original file hash,
symlink target, mode, uid/gid and dev/inode. A same-filesystem private copy is
verified by content, then the original is preserved through RENAME_NOREPLACE and
the copy takes the normal path through a second no-replace rename. No directory
bind is introduced. The unchanged installed save-path checker is hash-bound and
must pass before the actual launcher/API invocation.

Only the copied RetroAchievements.ini becomes a directory. The actual helper
must emit the freshly written, exact two-line disabled/publication-error log and
its target BusyBox `mv` directory-refusal line, in addition to fresh ES250 and
sentinel preservation. Both expected strings were compared byte-for-byte with
accepted controls02 case13 originals retained here; numeric250 alone cannot pass.
The EN/FR title and body named in the result must match the personally viewed
frames. No helper log or UI error is fabricated.

Before the next locale and at normal cleanup, the owned active copy is checked
and renamed to a retained completed path, and the held original is restored with
no-replace rename. Its entire original lstat manifest must match, including
inodes, links and modes. Only manifests are exported, no config payload. Partial
setup/restoration phases refuse ambiguous recovery and preserve both directories;
abort is failed evidence, not an automatic restoration claim. No data is deleted,
and product save-path guards are unchanged.

The bound inputs remain final d4af image/ES3178 with explicit ES16dbac binary
067defd8c760ae9085b1faba1ada643812be494be39e5690a472ab241258ab5d and #594 product
47dda767c7afc47020a3f21ab19a4493bfd5ff8a overlay. Final rebuilt-image acceptance
is pending. Can this be done on the VM? Yes; this is exact menu navigation,
frontend lifecycle and refusal rendering, with no physical fact or hardware claim.
Root records that focused continuation in the issues before allocation.

Same bound: one fresh no-NIC8GiB/4CPU/16GiB guest,1200s family plus120s cleanup,
128MiB/4096files including manifest,64MiB host frames. The observer waits at most
75s for the first backend after frontend readiness, so review the selected row
promptly. After activation, run the remaining scan actions without pauses inside
the unchanged30s product scan deadline. An expired original action stays failed;
no replay, extension or claim of restoration after abort is authorized here.

Root-only preparation, after current owners are consumed; commands are UNRUN:

```bash
TASK_TREE=/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-01
TASK_PACKET=/tmp/pix-m7-audit-ui-retry-plan-20261015
TASK_OWNER=/workspace/tmp/pix-m7-audit-ui-20261015-02
python3 -I -S -B "$TASK_PACKET/prepare.py" --checkout "$TASK_TREE" \
  --verification /workspace/tmp/pix-m7-image-readback-20261015-01/artifacts \
  --author-owner /workspace/tmp/pix-m7-mkdcdisc-20261014-01 \
  --owner "$TASK_OWNER" --vnc 140
cd "$TASK_TREE"
tools/watch-build --record-only -- python3 -I tools/host-maintenance/retention-report \
  --plan "$TASK_OWNER/retention-plan.json" --output "$TASK_OWNER/retention-report.json"
# Review original report/watch, observed-free VNC and exclusive allocation first.
python3 -I tools/host-maintenance/build-admission prepare \
  --plan "$TASK_OWNER/admission-plan.json" --output "$TASK_OWNER/admission.json"
tools/watch-build-submit --owner "$TASK_OWNER/lifecycle-owner" -- \
  --activity-dir "$TASK_OWNER/logs" --admission "$TASK_OWNER/admission.json" -- \
  python3 -I -S -B "$TASK_OWNER/vm-lifecycle.py"
```

After actual visual-ready, operate sequentially:

```bash
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" init
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" controls
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-start --mode baseline
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-select
# View wifi-baseline-selected-network, then review only if it shows the stated row.
python3 -I -S -B "$TASK_OWNER/host-action.py" --owner "$TASK_OWNER" review \
  --label wifi-baseline-selected-network \
  --review 'WI-FI NETWORK selected; ENABLE WI-FI ON; activate this bound picker.'
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-activate
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-exit
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-start --mode candidate
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-select
# View wifi-candidate-selected-network, then review only if it shows the stated row.
python3 -I -S -B "$TASK_OWNER/host-action.py" --owner "$TASK_OWNER" review \
  --label wifi-candidate-selected-network \
  --review 'WI-FI NETWORK selected; ENABLE WI-FI ON; activate this bound picker.'
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-activate
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-back-reopen
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" wifi-exit
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language en_US
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" refusal --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" dismiss --language fr_FR
python3 -I -S -B "$TASK_OWNER/host-audit.py" --owner "$TASK_OWNER" cleanup
```

View and record the other eight exact frame reviews. Then run additive
`host-audit.py --owner "$TASK_OWNER" finish`, await original lifecycle/launcher
completion and use unchanged `close.py --owner "$TASK_OWNER" --run ACTUAL_RUN
--packet FRESH_EXPORT`. Root alone reviews custody/original exits and consumes
admission. This source packet does not admit, allocate, delete, stage, commit,
promote or claim runtime success. SIGTERM/fatal boundaries remain separate under
D-CLOUD-133, as in the original #593 correction.

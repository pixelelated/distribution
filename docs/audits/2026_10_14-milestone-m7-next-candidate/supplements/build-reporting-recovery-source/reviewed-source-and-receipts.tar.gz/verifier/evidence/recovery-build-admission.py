#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026-present pixelelated
"""Require a current, single-use retention/capacity admission before compilation.

This tool registers reservations and consumes completion evidence. It NEVER deletes
build outputs, changes permissions, stops processes, or runs privileged commands.
"""
import argparse
import contextlib
import datetime
import fcntl
import hashlib
import json
import os
import re
from pathlib import Path
import stat
import subprocess
import sys
import time
import uuid

MAX_AGE = 900


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, data, exclusive=False):
    path = Path(path)
    text = json.dumps(data, indent=2, sort_keys=True) + '\n'
    if exclusive:
        with path.open('x') as f:
            f.write(text)
    else:
        temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
        with temp.open('x') as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        temp.replace(path)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def path_identity(path):
    p = Path(path)
    require(p.is_absolute() and p.resolve() == p, 'path must be absolute without symlink ancestors')
    s = p.lstat()
    require(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode), 'unsupported path type')
    return dict(device=s.st_dev, inode=s.st_ino, size=s.st_size,
                mtime_ns=s.st_mtime_ns, allocated_bytes=s.st_blocks * 512,
                uid=s.st_uid, links=s.st_nlink, mode=s.st_mode)


def source_state(root):
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=root, stderr=subprocess.PIPE)
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'tracked_diff_sha256': hashlib.sha256(git('diff', '--binary', 'HEAD', '--')).hexdigest()}


def registry_for(root):
    common = subprocess.check_output(['git', 'rev-parse', '--path-format=absolute', '--git-common-dir'],
                                     cwd=root, text=True, stderr=subprocess.PIPE).strip()
    return Path(common) / 'pixelelated-build-admission'


@contextlib.contextmanager
def registry(path):
    path = Path(path)
    path.mkdir(mode=0o700, exist_ok=True)
    require(not path.is_symlink() and path.stat().st_uid == os.getuid(), 'invalid registry owner/path')
    with (path / 'lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        file = path / 'jobs.json'
        data = read(file) if file.exists() else {'schema': 1, 'generation': 0, 'jobs': {}}
        require(data.get('schema') == 1 and isinstance(data.get('jobs'), dict), 'invalid registry')
        yield data
        write(file, data)


def evidence(items):
    require(isinstance(items, list) and items, 'retained evidence is required')
    for item in items:
        path_identity(item['path'])
        require(digest(item['path']) == item['sha256'], 'retained evidence changed: ' + item['path'])


def current(plan):
    root = Path(plan['checkout'])
    path_identity(root)
    require(root.is_dir(), 'checkout must exist')
    retention_plan = Path(plan['retention_plan'])
    report_path = Path(plan['retention_report'])
    path_identity(retention_plan); path_identity(report_path)
    rp, report = read(retention_plan), read(report_path)
    require(report['schema'] == 1 and report['result'] == 'REPORT_COMPLETE', 'retention report incomplete')
    require(not report['deletion_performed'] and not report['inventory']['errors'], 'retention report refused/unresolved')
    require(report['plan_sha256'] == digest(retention_plan), 'retention plan changed')
    tool = Path(__file__).with_name('retention-report')
    require(report['tool_sha256'] == digest(tool), 'retention report tool changed')
    age = time.time() - datetime.datetime.fromisoformat(report['utc']).timestamp()
    require(0 <= age <= MAX_AGE, 'retention report expired or from the future')
    volume = Path(rp['volume']); volume_id = path_identity(volume)
    require(root.stat().st_dev == volume_id['device'], 'checkout and budget volume differ')
    require(report['protected'] and len(report['protected']) == len(rp['protected']), 'protected identities missing')
    require({x['path'] for x in report['protected']} == set(rp['protected']), 'protected scope changed')
    for row in report['protected']:
        require(path_identity(row['path']) == row['identity'], 'protected identity changed: ' + row['path'])
    for item in rp['candidates']:
        require(path_identity(item['path']) == item['identity'], 'retirement candidate changed')
    matches = [b for b in rp['builds'] if b['name'] == plan['stage']]
    rows = [b for b in report['builds'] if b['name'] == plan['stage']]
    require(len(matches) == len(rows) == 1, 'exactly one matching build stage required')
    budget, observed = matches[0], rows[0]
    terms = budget['terms_bytes']
    require(terms and all(type(v) is int and v >= 0 for v in terms.values()), 'invalid budget')
    need = sum(terms.values())
    require(need > 0 and budget['basis'].strip(), 'positive measured budget and basis required')
    evidence(budget['evidence'])
    require(observed['fits_now'] is True and observed['terms_bytes'] == terms
            and observed['required_bytes'] == need, 'retention budget refused or changed')
    holds = plan['outputs']
    require(isinstance(holds, list) and holds, 'owned outputs and release conditions required')
    seen = set()
    for h in holds:
        p = Path(h['path'])
        require(p.is_absolute() and p.resolve() == p and str(p) not in seen, 'invalid/duplicate output path')
        seen.add(str(p))
        require(type(h['issue']) is int and h['issue'] > 0 and h['release_when'].strip(), 'output needs issue and release condition')
        parent = p if p.exists() else p.parent
        require(parent.is_dir() and parent.stat().st_dev == volume_id['device'], 'output is outside measured volume')
        require(h['kind'] in ['build-cache', 'firmware', 'qa-scratch'], 'invalid output classification')
    profiles = plan['profiles']
    require(isinstance(profiles, list) and profiles, 'explicit build profiles required')
    for profile in profiles:
        require(set(profile) == {'PROJECT', 'DEVICE', 'ARCH'} and all(isinstance(v, str) and v for v in profile.values()), 'invalid build profile')
    s = os.statvfs(volume)
    return {'checkout': str(root), 'source': source_state(root), 'profiles': profiles,
            'volume': str(volume), 'volume_device': volume_id['device'],
            'required_bytes': need, 'available_bytes': s.f_bavail * s.f_frsize,
            'retention_plan_sha256': digest(retention_plan), 'retention_report_sha256': digest(report_path),
            'outputs': holds, 'registry': str(registry_for(root)),
            'container_checkout': plan.get('container_checkout', str(root))}


def prepare(plan_path, output):
    plan_path = Path(plan_path).resolve(strict=True)
    plan = read(plan_path); state = current(plan)
    with registry(state['registry']) as jobs:
        reserved = sum(j['required_bytes'] for j in jobs['jobs'].values()
                       if j['state'] != 'consumed' and j['volume_device'] == state['volume_device'])
        require(state['available_bytes'] >= state['required_bytes'] + reserved, 'insufficient space after existing reservations')
        row = {'schema': 1, 'id': uuid.uuid4().hex, 'utc': utc(), 'plan': str(plan_path),
               'plan_sha256': digest(plan_path), 'state': state,
               'registry_generation': jobs['generation'], 'reserved_bytes': reserved,
               'tool_sha256': digest(__file__)}
        write(output, row, exclusive=True)
    return row


def admit(receipt_path, root, run, environment, docker=False):
    receipt_path = Path(receipt_path).resolve(strict=True)
    receipt = read(receipt_path)
    require(receipt['schema'] == 1 and receipt['tool_sha256'] == digest(__file__), 'admission schema/tool changed')
    age = time.time() - datetime.datetime.fromisoformat(receipt['utc']).timestamp()
    require(0 <= age <= MAX_AGE, 'admission expired or from the future')
    require(digest(receipt['plan']) == receipt['plan_sha256'], 'admission plan changed')
    state = current(read(receipt['plan'])); expected = receipt['state']
    require(state['checkout'] == str(root.resolve()), 'admission belongs to a different checkout')
    require({k:v for k,v in state.items() if k != 'available_bytes'} ==
            {k:v for k,v in expected.items() if k != 'available_bytes'}, 'admission state changed')
    redirected = Path(environment.get('BUILD_DIR', str(root)))
    if docker:
        require(str(redirected) == state['container_checkout'], 'Docker checkout differs from measured mount contract')
    else:
        require(redirected.resolve() == root.resolve() or any(
            redirected.resolve() == Path(h['path']) for h in state['outputs']),
            'redirected BUILD_DIR is not a declared output')
    require(any(all(not environment.get(k) or environment[k] == v for k,v in p.items())
                for p in state['profiles']), 'build profile is outside admission')
    if len(state['profiles']) == 1:
        environment.update(state['profiles'][0])
    with registry(state['registry']) as jobs:
        require(receipt['id'] not in jobs['jobs'], 'admission has already been used')
        require(jobs['generation'] == receipt['registry_generation'], 'registry changed; prepare a new admission')
        reserved = sum(j['required_bytes'] for j in jobs['jobs'].values()
                       if j['state'] != 'consumed' and j['volume_device'] == state['volume_device'])
        require(state['available_bytes'] >= state['required_bytes'] + reserved, 'current capacity no longer fits')
        row = dict(state, id=receipt['id'], state='running', run=str(run), admitted=utc(),
                   receipt_sha256=digest(receipt_path), runner_pid=os.getpid(),
                   submission_owner=environment.get('PIXELELATED_SUBMISSION_OWNER'),
                   pid_namespace=os.stat('/proc/self/ns/pid').st_ino,
                   runner_start=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19])
        write(run / 'admission.json', row, exclusive=True)
        write(run / 'admission-input.json', receipt, exclusive=True)
        plan = read(receipt['plan'])
        write(run / 'admission-plan.json', plan, exclusive=True)
        write(run / 'retention-plan.json', read(plan['retention_plan']), exclusive=True)
        write(run / 'retention-report.json', read(plan['retention_report']), exclusive=True)
        jobs['jobs'][row['id']] = row; jobs['generation'] += 1
    return row


def nested(root, run, environment):
    row = read(run / 'admission.json')
    require(not (run / 'runner-result.json').exists(), 'admitted run has already ended')
    require(source_state(root) == row['source'], 'nested source differs from admission')
    require(any(all(environment.get(k) == v for k,v in p.items())
                for p in row['profiles']), 'nested profile is outside admission')
    return row


def finish(run, command_code, monitor_code, runner_code):
    write(run / 'runner-result.json', {'utc': utc(), 'command_rc': command_code,
                                      'monitor_rc': monitor_code, 'runner_rc': runner_code}, exclusive=True)


def exited(pid):
    p = Path('/proc') / str(pid) / 'cmdline'
    try:
        require(not p.read_bytes(), 'recorded process is still live: ' + str(pid))
    except FileNotFoundError:
        pass


def consume(run, evidence_path):
    # Run in the host namespace; inaccessible /proc state raises, never succeeds.
    run = Path(run).resolve(strict=True)
    row = read(run / 'admission.json'); proof = read(evidence_path)
    require(os.stat('/proc/self/ns/pid').st_ino == row['pid_namespace'], 'consume from the original host PID namespace')
    require(proof['run'] == str(run) and proof['disposition'] in ['qualified', 'failed-investigated'], 'wrong completion evidence')
    evidence(proof['evidence'])
    require(proof['outputs'] == row['outputs'], 'retained output dispositions changed')
    rc = read(run / 'runner-result.json')
    require(type(proof['expected_rc']) is int and rc['runner_rc'] == proof['expected_rc'], 'unexpected original result')
    require(int((run/'build.rc').read_text()) == rc['command_rc'], 'original command rc changed')
    require((run/'build.status').read_text().startswith('state:       finished\n'), 'watcher has no terminal status')
    require(rc['monitor_rc'] == 0, 'watcher failed; keep reservation for investigation')
    require((proof['disposition'] == 'qualified') == (rc['runner_rc'] == 0), 'failure cannot be called qualified')
    pids = [row['runner_pid']]
    for name in ['build.pid','command.pid','watcher.pid','build.status.pid']:
        if (run/name).exists():pids.append(int((run/name).read_text()))
    if row['submission_owner']:
        owner=Path(row['submission_owner']);launch=read(owner/'launcher-result.json')
        require(launch['runner_returncode'] == rc['runner_rc'] == int((owner/'tool-wrapper.rc').read_text()), 'launcher result mismatch')
        pids.append(launch['pid'])
    for pid in set(pids):exited(pid)
    if (run/'command.pid').exists():
        group = int((run/'command.pid').read_text())
        for p in Path('/proc').glob('[0-9]*/stat'):
            try:
                fields = p.read_text().rsplit(')',1)[1].split()
                require(int(fields[2]) != group or fields[0] == 'Z', 'command process group still has live children')
            except FileNotFoundError:
                pass
    with registry(row['registry']) as jobs:
        job=jobs['jobs'][row['id']]
        require(job['run'] == str(run), 'registry run mismatch')
        if job['state'] == 'consumed':
            require(job['evidence_sha256'] == digest(evidence_path), 'different evidence for consumed run')
            return job
        job.update(state='consumed', consumed=utc(), evidence_sha256=digest(evidence_path),
                   original_result=rc, deleted_bytes=0, outputs_held=True)
        jobs['generation'] += 1
        write(run/'admission-consumed.json',job,exclusive=True)
    return job


# Only this reviewed launcher's exclusive wrapper write ordering is recoverable.
COLLISION_LAUNCHER_SHA256 = '3777c68fb2677775550183f8bacdb860d7e1e477ebac4e923beda63beba8e88e'
COLLISION_STAGES = ['clean-dolphin-sa', 'build-dolphin-sa', 'build-emulationstation', 'image']


def recovery_processes():
    """Error-aware PID/parent/group/session census; no privileged FD claim."""
    rows = []
    for directory in Path('/proc').iterdir():
        if not directory.name.isascii() or not directory.name.isdigit():
            continue
        try:
            raw = (directory / 'stat').read_text()
        except (FileNotFoundError, ProcessLookupError):
            try:
                directory.stat()
            except (FileNotFoundError, ProcessLookupError):
                continue
            raise ValueError('stat unavailable for present PID ' + directory.name)
        prefix, separator, tail = raw.rpartition(')')
        fields = tail.split()
        require(separator and prefix.split(' (', 1)[0] == directory.name and len(fields) >= 20,
                'malformed process identity')
        rows.append(dict(pid=int(directory.name), ppid=int(fields[1]), pgid=int(fields[2]),
                         sid=int(fields[3]), start_ticks=int(fields[19]), state=fields[0]))
    return rows


def recovery_containers():
    """A successful daemon census, never an arbitrary failed inspect as absence."""
    result = subprocess.run(['docker', 'container', 'ls', '--all', '--no-trunc', '--format', '{{.ID}}'],
                            capture_output=True, text=True, timeout=15, check=True)
    require(not result.stderr.strip(), 'container census diagnostic is ambiguous')
    ids = result.stdout.splitlines()
    require(all(re.fullmatch('[0-9a-f]{64}', item) for item in ids) and len(set(ids)) == len(ids),
            'invalid container census')
    return set(ids)


def consume_reporting_failure(run, evidence_path, failure_path):
    """Settle custody for the exact #597 producer/report collision; never qualify it."""
    run, evidence_path, failure_path = map(lambda p: Path(p).resolve(strict=True),
                                         [run, evidence_path, failure_path])
    path_identity(run); path_identity(evidence_path); path_identity(failure_path)
    row, proof, failure = read(run / 'admission.json'), read(evidence_path), read(failure_path)
    root = Path(row['checkout']); owner = Path(row['submission_owner'])
    path_identity(root); path_identity(owner)
    require(run.parent == root / '.build-runs' and row['run'] == str(run), 'wrong original run path')
    require(row['registry'] == str(registry_for(root)), 'wrong original registry')
    require(os.stat('/proc/self/ns/pid').st_ino == row['pid_namespace'], 'recover from original host PID namespace')
    require(source_state(root) == row['source'], 'original source changed')
    require(proof['run'] == str(run) and proof['disposition'] == 'failed-investigated'
            and type(proof['expected_rc']) is int and proof['expected_rc'] == 0,
            'reporting failure requires investigated disposition with original runner0')
    require(proof['outputs'] == row['outputs'], 'retained output dispositions changed')
    evidence(proof['evidence'])
    require(any(x['path'] == str(failure_path) and x['sha256'] == digest(failure_path)
                for x in proof['evidence']), 'acceptance must bind launcher failure evidence')
    require(failure['schema'] == 1 and failure['reason'] == 'exclusive-wrapper-receipt-collision'
            and failure['run'] == str(run) and failure['admission_id'] == row['id']
            and failure['owner'] == str(owner) and failure['source'] == row['source']
            and failure['pid_namespace'] == row['pid_namespace'], 'wrong launcher failure binding')
    require(failure['original_launcher_returncode'] is None and failure['qualification'] is False,
            'unknown launcher wait status must not be invented or qualified')
    provenance = failure['coordinator_provenance']
    require(provenance['action'] == 'premature-wrapper-receipt-write'
            and provenance['receipt_path'] == str(owner / 'tool-wrapper.rc')
            and provenance['receipt_is_launcher_result'] is False
            and isinstance(provenance['acknowledgment'], str) and provenance['acknowledgment'].strip(),
            'explicit coordinator collision provenance required')
    evidence(failure['originals'])
    indexed = {item['path']: item['sha256'] for item in failure['originals']}
    require(len(indexed) == len(failure['originals']), 'duplicate original evidence path')
    def original(path):
        require(str(path) in indexed and digest(path) == indexed[str(path)], 'missing/changed original: ' + str(path))
        return path
    def obj(path):
        return read(original(path))
    def number(path):
        text = original(path).read_text()
        require(re.fullmatch('[0-9]+\n?', text) is not None, 'invalid original number: ' + str(path))
        return int(text)
    original(run / 'admission.json')
    rc = obj(run / 'runner-result.json')
    require(all(type(rc[k]) is int and rc[k] == 0 for k in ['command_rc', 'monitor_rc', 'runner_rc'])
            and number(run / 'build.rc') == number(owner / 'inner.rc') == 0, 'producer did not complete successfully')
    status = original(run / 'build.status').read_text()
    require(status.startswith('state:       finished\n') and '\noutcome:     rc=0\n' in status,
            'watcher has no successful terminal status')
    runner = number(run / 'build.pid'); command = number(run / 'command.pid')
    watcher = number(run / 'watcher.pid')
    require(runner == row['runner_pid'] and int(row['runner_start']) > 0
            and watcher == number(run / 'build.status.pid'), 'recorded process bindings differ')
    require(re.search(r'^watcher_pid: '+str(watcher)+r'$', status, re.M)
            and re.search(r'^job_pid:     '+str(runner)+r'\s', status, re.M), 'terminal watcher identity differs')
    require(not os.path.lexists(owner / 'launcher-result.json'), 'launcher result exists; use ordinary consume')
    launcher_source = original(owner / 'watch-build-submit.py')
    require(digest(launcher_source) == COLLISION_LAUNCHER_SHA256, 'unsupported launcher source for collision recovery')
    collision = original(owner / 'tool-wrapper.rc')
    require(path_identity(collision) == failure['collision_identity'], 'conflicting receipt identity changed')
    # The collision bytes are retained but NEVER parsed as a launcher return code.
    console = original(owner / 'console.log').read_text()
    diagnostic = "watch-build-submit: [Errno 17] File exists: '" + str(collision) + "'"
    require(console.splitlines()[-1:] == [diagnostic] and console.splitlines().count(diagnostic) == 1,
            'missing exact terminal exclusive-wrapper collision diagnostic')
    launch, launch_pid = obj(owner / 'launcher-start.json'), obj(owner / 'launcher-pid.json')
    submission = obj(owner / 'launcher-submission.json')
    require(launch['pid'] == launch_pid['pid'] and int(launch['start_ticks']) > 0
            and launch['cwd'] == submission['cwd'] == str(root)
            and submission['runner'] == str(root / 'tools/watch-build')
            and submission['runner_sha256'] == digest(root / 'tools/watch-build')
            and submission['submission_is_not_completion'] is True, 'launcher producer identity differs')
    started, result = obj(owner / 'owner-start.json'), obj(owner / 'owner-result.json')
    inputs, resources = obj(owner / 'build-inputs.json'), obj(owner / 'resource-result.json')
    require(started['pid'] == command and int(started['start_ticks']) > 0
            and started['pid_namespace'] == inputs['host_pid_namespace'] == 'pid:['+str(row['pid_namespace'])+']'
            and started['source_commit'] == inputs['commit'] == row['source']['head']
            and inputs['checkout'] == str(root) and inputs['container_checkout'] == row['container_checkout']
            and started['input_sha256'] == digest(owner / 'build-inputs.json'), 'completed producer source/identity differs')
    require(set(inputs['helper_sha256']) == {'build-owner.py', 'host-resources.py', 'inner-build.py'}, 'producer helper scope differs')
    for name, expected in inputs['helper_sha256'].items():
        path_identity(owner / name)
        require(digest(owner / name) == expected, 'producer helper changed')
    require(result['status'] == resources['status'] == 'PASS' and not result['cleanup'] and not result['signals']
            and resources['all_threads_exited'] is True and not resources['errors'], 'producer cleanup/resources unresolved')
    require([x['stage'] for x in result['stages']] == COLLISION_STAGES, 'unsupported/incomplete producer stage sequence')
    pids = {runner, command, watcher, launch['pid']}; groups = {command, watcher, launch['pid']}; cids = set(); stage_groups = set()
    for expected in result['stages']:
        stage = expected['stage']; folder = owner / 'stages' / stage
        host, inner = obj(folder / 'host-result.json'), obj(folder / 'inner-result.json')
        ready, observed = obj(folder / 'inner-ready.json'), obj(folder / 'host-observed.json')
        container, host_command = obj(folder / 'container-observed.json'), obj(folder / 'host-command.json')
        codes = [host['original_host_make_rc'], inner['original_command_rc'], inner['wrapper_rc']]
        require(host == expected and all(type(code) is int and code == 0 for code in codes)
                and host['container_observed'] is True and host['observation_handshake'] is True and not inner['signals'],
                'stage did not complete successfully: ' + stage)
        require(inner['stage'] == ready['stage'] == observed['stage'] == host_command['stage'] == stage
                and inner['host_observation_handshake'] == observed and ready['nonce'] == observed['nonce']
                and re.fullmatch('[0-9a-f]{32}', ready['nonce']) is not None, 'stage handshake differs: ' + stage)
        cid = container['id']
        require(re.fullmatch('[0-9a-f]{64}', cid) is not None and cid == observed['container_id']
                and original(folder / 'container.cid').read_text().strip() == cid and cid not in cids,
                'container identity differs: ' + stage)
        require(container['image_id'] == started['builder_image_id']
                and container['image_reference'] == inputs['builder_image'] and container['workdir'] == row['container_checkout']
                and any(x['Source'] == str(root) and x['Destination'] == row['container_checkout'] and x['RW'] is True for x in container['mounts'])
                and any(x['Source'] == str(owner) and x['Destination'] == '/build-owner' and x['RW'] is True for x in container['mounts']),
                'container source/mount provenance differs: ' + stage)
        pid = host_command['pid']; require(type(pid) is int and pid > 0 and pid == host_command['process_group'], 'stage group identity differs')
        pids.add(pid); groups.add(pid); stage_groups.add(str(pid)); cids.add(cid)
    require(set(result['surviving_host_command_groups']) == stage_groups
            and all(value == [] for value in result['surviving_host_command_groups'].values()), 'producer groups unresolved')
    require(all(type(pid) is int and pid > 0 for pid in pids), 'invalid recorded PID')
    with registry(row['registry']) as jobs:
        job = jobs['jobs'][row['id']]
        require(all(job.get(k) == v for k, v in row.items() if k != 'state'), 'registry admission identity differs')
        # Recheck originals and current custody under the reservation lock. Unknown
        # or reused PIDs conservatively refuse; no broad root-FD visibility assumed.
        evidence(failure['originals']); evidence(proof['evidence'])
        require(path_identity(collision) == failure['collision_identity'] and not os.path.lexists(owner / 'launcher-result.json'),
                'launcher reporting state changed')
        processes = recovery_processes()
        require(not any(x['pid'] in pids or x['ppid'] in pids or x['pgid'] in groups or x['sid'] in groups for x in processes),
                'recorded process, child, group or session remains')
        require(not (cids & recovery_containers()), 'recorded container remains')
        if job['state'] == 'consumed':
            require(job['evidence_sha256'] == digest(evidence_path)
                    and job.get('completion_disposition') == 'failed-investigated/reporting-failure'
                    and job.get('qualification') is False and job.get('original_launcher_returncode') is None
                    and job.get('original_result') == rc
                    and job.get('recovery_tool_path') == str(Path(__file__).resolve())
                    and job.get('recovery_tool_sha256') == digest(__file__)
                    and job['launcher_reporting_failure']['evidence_sha256'] == digest(failure_path)
                    and read(run / 'admission-consumed.json') == job, 'different recovery for consumed run')
            return job
        require(job['state'] == 'running', 'admission is not a running reservation')
        job.update(state='consumed', consumed=utc(), evidence_sha256=digest(evidence_path), original_result=rc,
                   recovery_tool_path=str(Path(__file__).resolve()), recovery_tool_sha256=digest(__file__),
                   completion_disposition='failed-investigated/reporting-failure', qualification=False,
                   original_launcher_returncode=None, deleted_bytes=0, outputs_held=True,
                   launcher_reporting_failure={'reason':failure['reason'], 'evidence_path':str(failure_path),
                       'evidence_sha256':digest(failure_path), 'launcher_source_sha256':COLLISION_LAUNCHER_SHA256,
                       'conflicting_receipt_used_as_launcher_result':False},
                   recovery_absence={'utc':utc(), 'pid_namespace':row['pid_namespace'], 'pids':sorted(pids),
                       'groups_and_sessions':sorted(groups), 'container_ids':sorted(cids),
                       'scope':'recorded PID/parent/group/session and successful container-ID census; no root-FD claim'})
        jobs['generation'] += 1
        write(run / 'admission-consumed.json', job, exclusive=True)
    return job


def main():
    os.umask(0o077)
    parser=argparse.ArgumentParser(description=__doc__);subs=parser.add_subparsers(dest='action',required=True)
    p=subs.add_parser('prepare');p.add_argument('--plan',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p=subs.add_parser('consume');p.add_argument('--run',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True)
    p=subs.add_parser('consume-reporting-failure');p.add_argument('--run',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True);p.add_argument('--launcher-failure-evidence',type=Path,required=True)
    args=parser.parse_args()
    if args.action=='prepare':r=prepare(args.plan,args.output);print('prepared admission '+r['id'])
    elif args.action=='consume-reporting-failure':
        r=consume_reporting_failure(args.run,args.evidence,args.launcher_failure_evidence)
        print('consumed reporting failure; launcher wait unknown; outputs held; qualification false: '+r['id'])
    else:r=consume(args.run,args.evidence);print('consumed original results; retained outputs remain held: '+r['id'])


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError) as error:
        print('build-admission: '+str(error),file=sys.stderr);sys.exit(2)

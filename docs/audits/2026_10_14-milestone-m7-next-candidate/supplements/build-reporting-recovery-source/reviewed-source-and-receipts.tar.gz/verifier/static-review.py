#!/usr/bin/env python3
"""Check this fixed source delta without importing or executing the artifact reader."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
before = (root / 'originals/verify-image.py').read_bytes()
after = (root / 'verify-image.py').read_bytes()
assert hashlib.sha256(before).hexdigest() == '3c0806f560643bb4ad4f21ebada9e975a83d068117b6e17e9580e8509471cf4b'
a, b = ast.parse(before), ast.parse(after)
dump = lambda node: ast.dump(node, include_attributes=False)
def main(tree):
    return copy.deepcopy(next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main'))
old, new = main(a), main(b)
removed = ["assert json.loads((owner / 'launcher-result.json').read_text())['runner_returncode'] == 0",
           "assert (owner / 'tool-wrapper.rc').read_text().strip() == '0'"]
old_assertions = [dump(ast.parse(s).body[0]) for s in removed]
assert all(sum(dump(node) == expected for node in old.body) == 1 for expected in old_assertions)
old.body = [node for node in old.body if dump(node) not in old_assertions]
replacement = dump(ast.parse('build_closeout = reporting_failure_closeout(owner, cfg)').body[0])
assert sum(dump(node) == replacement for node in new.body) == 1
new.body = [node for node in new.body if dump(node) != replacement]
records = 0
for node in ast.walk(new):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'record':
        data = node.args[1]
        if not isinstance(data, ast.Dict):
            continue
        selected = [i for i, key in enumerate(data.keys) if isinstance(key, ast.Constant) and key.value == 'build_closeout']
        if selected:
            assert len(selected) == 1
            i = selected[0]
            assert dump(data.values[i]) == dump(ast.Name(id='build_closeout', ctx=ast.Load()))
            del data.keys[i]; del data.values[i]; records += 1
assert records == 2
assert dump(old) == dump(new), 'unexpected original main-flow change'
def is_main(node):
    return isinstance(node, ast.FunctionDef) and node.name == 'main'
def is_addition(node):
    return (isinstance(node, ast.FunctionDef) and node.name == 'reporting_failure_closeout') or (
        isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id.startswith('REPORTING_FAILURE_'))
assert [dump(n) for n in a.body if not is_main(n)] == [dump(n) for n in b.body if not is_main(n) and not is_addition(n)]
assert (root/'run.sh').read_bytes() == (root/'originals/run.sh').read_bytes()
assert (root/'dolphin-sys-source-manifest.json').read_bytes() == (root/'originals/dolphin-sys-source-manifest.json').read_bytes()
assert hashlib.sha256((root/'evidence/launcher-failure-evidence.json').read_bytes()).hexdigest() == '20ec69891a76207467412e15d7536e4d7bb20c1d189faeea1f4cf2bf69cd80cc'
template = json.loads((root/'inputs.template.json').read_text())
assert template['verifier_sha256'] == hashlib.sha256(after).hexdigest()
assert template['run_script_sha256'] == hashlib.sha256((root/'run.sh').read_bytes()).hexdigest()
assert template['recovery_tool_sha256'] == hashlib.sha256((root/'evidence/recovery-build-admission.py').read_bytes()).hexdigest() == '8923610caf6a8a1b32775bc1a7e3f67d5e5d5b7468955b35fd40d07da2e2047d'
for path in root.rglob('*.py'):
    ast.parse(path.read_bytes(), filename=str(path))
subprocess.run(['bash', '-n', str(root/'run.sh')], check=True, timeout=10)
receipt = {'schema':1, 'status':'PASS', 'scope':'source-only syntax and exact original AST/byte identities',
           'utc':datetime.now(timezone.utc).isoformat(), 'original_verifier_sha256':hashlib.sha256(before).hexdigest(),
           'recovery_verifier_sha256':hashlib.sha256(after).hexdigest(),
           'main_delta':'only two original launcher-success gates replaced; two build_closeout output fields added',
           'all_other_original_main_statements_and_helpers':'AST-identical',
           'run_and_six_resource_manifest':'byte-identical',
           'reader_or_guard_executed':False, 'preparer_admission_compiler_vm_executed':False,
           'cache_or_artifact_read':False, 'source_packet_status':'UNRUN'}
with (root/'static-review.json').open('x') as f:
    json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,sort_keys=True))

from pathlib import Path
import json,hashlib,stat,tarfile,shutil,datetime,re,subprocess
p=Path('/workspace/tmp/pix-m7-native-states-evidence-20261015-02');o=Path('/workspace/tmp/pix-m7-native-states-20261015-02');a=Path('/workspace/repos/rocknix.worktrees/m7-player-setup/docs/audits/2026_10_14-milestone-m7-next-candidate');packet=Path('/tmp/pix-m7-native-states-20261015-02')
x=json.loads(Path('/tmp/m7-native02-index.json').read_text());g=p/'guest/gameplay'
def h(b):return hashlib.sha256(b).hexdigest()
consumption=json.loads((p/'consumption.json').read_text());run=Path(consumption['run']);consumed=json.loads((run/'admission-consumed.json').read_text())
assert consumed['state']=='consumed' and consumed['id']=='d739030019bc445bae908b3ca6dd6b48' and consumed['evidence_sha256']==h((p/'consumption.json').read_bytes())
assert consumed['original_result']==json.loads(x['channels']['run/runner-result.json'])
assert all(consumed['original_result'][v]==0 for v in ['command_rc','monitor_rc','runner_rc'])
assert json.loads(x['channels']['owner/lifecycle-owner/launcher-result.json'])['runner_returncode']==0 and x['channels']['owner/lifecycle-owner/tool-wrapper.rc']=='0\n'
for r in consumption['evidence']:assert h(Path(r['path']).read_bytes())==r['sha256']
vm=json.loads((p/'vm-result.json').read_text());assert vm['rc']==0 and vm['cleanup_errors']==vm['remaining_host_children']==[] and all(r['wait_status']==0 for r in vm['reaped_host_children'])
sup=json.loads((g/'supervisor-result.json').read_text());assert sup['rc']==sup['pad_original_returncode']==0 and sup['forced_cleanup'] is False and sup['native_processes_at_end']==[]
assert json.loads((g/'pad-result.json').read_text())['rc']==0
pids=json.loads((p/'host-exits.json').read_text())['pids_absent'];assert len(pids)==5 and all(not Path('/proc',str(pid)).exists() for pid in pids)
source_matches=[]
for n in ['guest.py','host-action.py','vm-lifecycle.py','supervisor.py','pad.py','census.py','close.py']:
 f=(o/'source'/n) if n in ['guest.py','supervisor.py','pad.py'] else o/n;assert f.read_bytes()==(packet/n).read_bytes();source_matches.append({'path':'owner/'+str(f.relative_to(o)),'sha256':h(f.read_bytes())})
installed=json.loads((g/'installed-inputs.json').read_text());assert installed['source']=='f8636de1d105275dbf9420bbabbbc26f79abb10f' and installed['system']['sha256']=='2c69f6533629244edef4ec2405bfaaf438f507451733ae955be7eefe7ffeb1cf'
final=json.loads((o/'records/final-image-result.json').read_text())
for name,row in installed['products'].items():
 if name in final['products']:assert row['sha256']==final['products'][name]['sha256'] and row['bytes']==final['products'][name]['bytes']
 if 'frozen_source_comparison' in row:
  q=row['frozen_source_comparison'];raw=subprocess.check_output(['git','show',installed['source']+':'+q['source']],cwd=a.parents[2]);assert h(raw)==q['source_sha256']
  if q['transform'].startswith('@GRENDERER@'):raw=raw.replace(b'@GRENDERER@',b'4')
  assert h(raw)==q['expected_installed_sha256']==row['sha256']
s=x['snapshots'];dc='/storage/roms/bios/dc/Tetris2-M7.state'
def state(n,path=dc):return next(r for r in s[n]['state']['states'] if r['path']==path)
def eq(u,v):return all(u[k]==v[k] for k in ['path','resolved','bytes','sha256','mtime_ns'])
manual=state('dc-manual-saved-a');assert all(eq(manual,state(n)) for n in ['dc-manual-loaded-a','dc-global-on-native-off-stopped','dc-auto-before-exit-c'])
auto=state('dc-auto-saved-stopped');assert eq(auto,state('dc-auto-cold-restored-c')) and auto['sha256']!=manual['sha256'] and auto['mtime_ns']>manual['mtime_ns']
last=state('dc-auto-restored-stopped');assert last['sha256']!=auto['sha256']
for n in ['dc-manual-saved-a','dc-manual-loaded-a','dc-global-on-native-off-stopped']:
 assert s[n]['state']['global_autosave']['effective_enabled'] and all(s[n]['profiles']['global'][k]=='no' for k in ['Dreamcast.AutoLoadState','Dreamcast.AutoSaveState'])
for n in ['dc-auto-before-exit-c','dc-auto-saved-stopped','dc-auto-cold-restored-c','dc-auto-restored-stopped']:
 assert not s[n]['state']['global_autosave']['effective_enabled'] and all(s[n]['profiles']['global'][k]=='yes' for k in ['Dreamcast.AutoLoadState','Dreamcast.AutoSaveState'])
for n in ['dc-global-on-native-off-stopped','dc-auto-saved-stopped','dc-auto-restored-stopped','wii-manual-stopped','final']:assert s[n]['state']['native_processes']==[]
assert all(s['final']['profiles']['global'][k]=='no' for k in ['Dreamcast.AutoLoadState','Dreamcast.AutoSaveState']) and s['final']['state']['global_autosave']['raw_value']=='0'
manual_log=(g/'snapshots/dc-global-on-native-off-stopped/var/log/exec.log').read_text();assert manual_log.count('N[SAVESTATE]: Saved state to')==1 and manual_log.count('N[SAVESTATE]: Loaded state ver')==1
prelog=(g/'snapshots/dc-auto-before-exit-c/var/log/exec.log').read_text();assert prelog.count('N[SAVESTATE]: Loaded state ver')==1 and 'N[SAVESTATE]: Saved state to' not in prelog
postlog=(g/'snapshots/dc-auto-saved-stopped/var/log/exec.log').read_text();assert postlog.count('N[SAVESTATE]: Loaded state ver')==postlog.count('N[SAVESTATE]: Saved state to')==1
coldlog=(g/'snapshots/dc-auto-cold-restored-c/var/log/exec.log').read_text();assert coldlog.count('N[SAVESTATE]: Loaded state ver')==1 and 'N[SAVESTATE]: Saved state to' not in coldlog
wii='/storage/roms/savestates/wii/ID-SuDokuL-Wii.s01';assert all(eq(state('wii-saved-a',wii),state(n,wii)) for n in ['wii-loaded-a','wii-manual-stopped'])
events=[json.loads(l) for l in (g/'pad.events.jsonl').read_text().splitlines()];assert len([r for r in events if r.get('state')=='created'])==len([r for r in events if r.get('state')=='destroyed'])==1
presses=[r for r in events if r.get('operation')=='press']
for r in presses:
 ack=json.loads((g/('pad-ack-'+r['id']+'.json')).read_text());assert ack['rc']==0 and ack['released'] is True and ack['buttons']==r['buttons']
timing=[]
for label in ['wii-first-interactive','dc-manual-interactive-actual','dc-auto-save-first-interactive','dc-auto-cold-first-interactive']:
 cap=json.loads((o/'frames'/(label+'-capture.json')).read_text());assert h(Path(cap['path']).read_bytes())==cap['sha256'];assert cap['first_observed_frame_upper_bound_seconds']<=120
 after=[r for r in presses if r['time']>cap['launch']['time']];first=min(after,key=lambda r:r['time']);assert first['time']>cap['time']
 timing.append({'label':label,'launch_ordinal':cap['launch']['guest']['ordinal'],'launch_time':cap['launch']['time'],'capture_time':cap['time'],'host_complete_frame_upper_bound_seconds':cap['first_observed_frame_upper_bound_seconds'],'guest_capture_ack_elapsed_seconds':cap['guest_capture_ack']['elapsed_seconds'],'first_subsequent_pad_time':first['time'],'first_subsequent_pad_buttons':first['buttons'],'first_subsequent_pad_id':first['id'],'scope':'Original host serial-lock action ordering, capture receipts and guest pad-event time corroborate no input between launch and this frame; not a hardware latency benchmark.'})
labels={
'es-global-off-initial':'Global auto save/load visibly Off.',
'es-wii-native-selection':'Wii explicitly Dolphin:dolphin-sa-wii; support row, no frontend manager.',
'es-wii-state-support':'Complete informational limitation distinguishes native options and ordinary game saves.',
'es-dc-native-selection':'Dreamcast explicitly Flycast:flycast-sa.',
'es-dc-state-support':'Complete native-support limitation; no frontend state manager.',
'wii-first-interactive':'SuDokuL title/Press+ visible; VM OpenGL capability warning preserved.',
'wii-save-01':'Completed Saved State to ID-SuDokuL-Wii.s01 OSD; visible timer00:31.',
'wii-changed-b':'Distinct paused sceneB, timer01:00.',
'wii-load-00':'Decompressing State pending; excluded as completed restoration.',
'wii-load-02':'Completed Loaded State from ID-SuDokuL-Wii.s01 OSD, unpaused timer00:31.',
'wii-load-10':'Settled restored scene with timer advanced00:42.',
'wii-es-return':'Actual ES Dreamcast carousel after Wii normal exit.',
'es-global-on':'Global auto save/load visibly On.',
'es-dc-native-selection-on':'Mislabeled original shows SPLORE/PICO-8; excluded from Dreamcast evidence.',
'es-dc-native-selection-on-actual':'Correct actual Tetris2/Dreamcast Flycast selection.',
'dc-manual-first-interactive':'Original loading/Please Wait image; excluded from interactive-frame acceptance.',
'dc-manual-interactive-actual':'Actual interactive Tetris50/60Hz/Test selection.',
'dc-manual-scene-a':'Manual saved sceneA: High Score selection.',
'dc-native-slot-before':'Native Slot1 Empty; Load disabled.',
'dc-native-save-selected':'Native Save State selected while High Score scene behind.',
'dc-manual-save-00':'State saved notification; resumed into High Score table. Activation-input cause not established.',
'dc-manual-changed-b':'Distinct changedB:1Player selection.',
'dc-native-load-selected':'Load State selected; Slot1 thumbnail shows saved High Score selection.',
'dc-manual-load-00':'Completed post-load High Score table; corroborated by native load log, response and later coldA.',
'dc-manual-responsive':'Subsequent Y returns to High Score selection.',
'dc-native-off-before-exit-b':'1Player sceneB before normal exit with native auto options disabled.',
'dc-global-on-es-return':'Actual ES Dreamcast carousel after native-off normal exit.',
'es-global-off-native-auto':'Global auto save/load visibly Off before native auto case.',
'dc-auto-save-first-interactive':'Launch3 cold-loaded manualA High Score selection before any pad input.',
'dc-native-settings-scroll1':'Native Automatic State Load and Save both visibly checked.',
'dc-auto-scene-c':'Distinct automatic sceneC:2Players selection.',
'dc-auto-native-exit':'Native Exit selected; thumbnail still manual High ScoreA before exit auto-save.',
'dc-auto-cold-first-interactive':'Launch4 cold restored2PlayersC before any pad input.',
'dc-auto-cold-responsive':'Subsequent Down changes to High Score selection.',
'es-final-return':'Final actual ES PICO-8 carousel; not a title-specific return claim.'}
out=a/'supplements/native-state02-result';out.mkdir();frames=out/'frames';frames.mkdir()
frame_index=[]
for label,note in labels.items():
 cap=json.loads((o/'frames'/(label+'-capture.json')).read_text());f=Path(cap['path']);b=f.read_bytes();assert h(b)==cap['sha256'];dest=frames/(label+'.png');shutil.copy2(f,dest)
 frame_index.append({'label':label,'file':'frames/'+dest.name,'original':str(f),'original_archive_member':'owner/'+str(f.relative_to(o)),'sha256':h(b),'bytes':len(b),'viewed_by':'primary independent auditor /root/m7_audit_resume','detail':'original','observation':note,'capture_time':cap['time']})
(out/'frame-index.json').write_text(json.dumps({'source_commit':installed['source'],'es_commit':'16dbac5211eea7e70db7394372033be2be7df829','observed_frames':len(frame_index),'frames':frame_index},indent=2)+'\n')
retained=[]
for n in ['original-records.tar.gz','original-records.json','guest-manifest.json','export-result.json','readback-result.json','host-exits.json','vm-result.json','config.json','consumption.json','root-review.json']:
 shutil.copy2(p/n,out/n);retained.append({'path':n,'original':str(p/n),'sha256':h((p/n).read_bytes()),'bytes':(p/n).stat().st_size})
shutil.copy2(run/'admission-consumed.json',out/'admission-consumed.json');retained.append({'path':'admission-consumed.json','original':str(run/'admission-consumed.json'),'sha256':h((run/'admission-consumed.json').read_bytes()),'bytes':(run/'admission-consumed.json').stat().st_size})
selected=[]
for f in sorted(g.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(p/'guest');n=str(rel)
 if '/snapshots/' in n:keep=f.name in ['state-observation.json','profiles.json','inventory.json','exec.log']
 elif '/state-bytes/' in n:keep=True
 elif f.parent==g:keep=(f.name in ['installed-inputs.json','provision.json','controller-identity.json','supervisor-result.json','pad-result.json','finish.json','pad.events.jsonl','process-observations.jsonl'] or f.name.startswith(('launch-','first-frame-','pad-ack-','pad-claim-')))
 else:keep=False
 if keep:selected.append((n,f))
archive=out/'selected-guest-originals.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,f in selected:t.add(f,arcname=n,recursive=False)
selected_rows=[{'path':n,'sha256':h(f.read_bytes()),'bytes':f.stat().st_size,'mode':stat.S_IMODE(f.stat().st_mode)} for n,f in selected]
with tarfile.open(archive) as t:
 ms=t.getmembers();assert len(ms)==len(selected_rows)
 for m,r in zip(ms,selected_rows):assert m.name==r['path'] and m.mode==r['mode'] and h(t.extractfile(m).read())==r['sha256']
(out/'selected-guest-members.json').write_text(json.dumps(selected_rows,indent=2)+'\n');(out/'retained-originals.json').write_text(json.dumps(retained,indent=2)+'\n')
review={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_SCOPED_NATIVE_STATE_PROOF','source':installed['source'],'es_commit':'16dbac5211eea7e70db7394372033be2be7df829','all_host_original_bytes_modes_membership_verified':1363,'all_guest_export_rows_rehashed':611,'original_guest_payload_rows':610,'export_additional_row':'guest-export-manifest.json','host_archive_sha256':x['host_archive_sha256'],'selected_guest_archive_sha256':h(archive.read_bytes()),'selected_guest_archive_bytes':archive.stat().st_size,'selected_guest_members':len(selected_rows),'viewed_frames':len(frame_index),'source_files_reverified':source_matches,'first_frames':timing,'manual':manual,'manual_stopped':state('dc-global-on-native-off-stopped'),'automatic_saved':auto,'automatic_cold_before_input':state('dc-auto-cold-restored-c'),'fourth_exit_saved':last,'wii_state':state('wii-saved-a',wii),'actual_consumed_sha256':h((run/'admission-consumed.json').read_bytes()),'actual_consumed_id':consumed['id'],'recorded_host_pids_independently_absent':pids,'all_pad_presses_released':len(presses),'native_exit_status':'unknown; original runemu logs report Checking errors:0, but no direct native wait observer. Supervisor/pad/runner0 are not substituted.','proof_boundaries':['VM software proof with actual installed engines and generated controller profile; no physical GPU/radio/power claim.','Ordinary cold game saves remain separately accepted native03 evidence on earlier d4af, not replayed on f863.','Flycast manual Save/Load activation immediately resumes into High Score table; saved thumbnail and later cold launch show actual saved selectionA. Cause of immediate table navigation unestablished; no defect inferred.','Exact pre-input state identity is compared before fourth normal exit, which legitimately auto-saves again.','Original native01 prelaunch fixture failure remains failed, including guest forced cleanup and partial export.','Two incorrectly named original frames remain explicit exclusions.','Full guest original configuration/account files are excluded from compact retention.','Three local readback script schema assumptions (run prefix, absent run.path, self-row manifest) refused before acceptance, then corrected from actual originals; no runtime or evidence bytes changed.'],'audit_completion':'This settles the remaining native-state proof dependency; final audit artifact/tracker reconciliation is separate.'}
(out/'auditor-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({k:review[k] for k in ['status','selected_guest_members','selected_guest_archive_bytes','selected_guest_archive_sha256','viewed_frames','actual_consumed_sha256']}))

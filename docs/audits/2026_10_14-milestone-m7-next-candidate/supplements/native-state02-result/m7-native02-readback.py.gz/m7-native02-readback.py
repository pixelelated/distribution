from pathlib import Path
import json,hashlib,tarfile,stat,datetime
p=Path('/workspace/tmp/pix-m7-native-states-evidence-20261015-02');o=Path('/workspace/tmp/pix-m7-native-states-20261015-02');tree=Path('/workspace/repos/rocknix.worktrees/m7-p5-build-20261015-02')
def h(b):return hashlib.sha256(b).hexdigest()
host=json.loads((p/'original-records.json').read_text());guest=json.loads((p/'guest-manifest.json').read_text())
assert len(host)==1363 and len(guest)==611
hostmap={r['path']:r for r in host};assert len(hostmap)==len(host)
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host_members':len(host),'guest_members':len(guest),'host_archive_sha256':h((p/'original-records.tar.gz').read_bytes()),'host_archive_bytes':(p/'original-records.tar.gz').stat().st_size,'channels':{},'pngs':[],'snapshots':{},'launches':[],'state_blobs':[]}
with tarfile.open(p/'original-records.tar.gz') as t:
 members=t.getmembers();assert set(m.name for m in members)==set(hostmap) and len(members)==len(hostmap)
 for m in members:
  assert m.isfile(),m.name;b=t.extractfile(m).read();r=hostmap[m.name];assert len(b)==r['bytes'] and h(b)==r['sha256'],m.name
  q=Path(m.name);original=(o.joinpath(*q.parts[1:]) if q.parts[0]=='owner' else Path(json.loads((p/'consumption.json').read_text())['run'])/Path(*q.parts[1:]))
  assert original.is_file() and not original.is_symlink(),str(original)
  assert original.read_bytes()==b and stat.S_IMODE(original.stat().st_mode)==m.mode,m.name
  if m.name.endswith(('runner-result.json','launcher-result.json','tool-wrapper.rc','build.pid.rc','run.path')):summary['channels'][m.name]=b.decode()
  if m.name.endswith('.png'):summary['pngs'].append(r)
actual={str(f.relative_to(p/'guest')) for f in (p/'guest').rglob('*') if f.is_file()}
assert actual=={r['path'] for r in guest}|{'guest-export-manifest.json'}
for r in guest:
 f=p/'guest'/r['path'];assert f.is_file() and not f.is_symlink();b=f.read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'],r['path']
 if '/state-bytes/' in r['path']:summary['state_blobs'].append(r)
original_guest=json.loads((p/'guest/guest-export-manifest.json').read_text());assert original_guest==[r for r in guest if r['path']!='guest-export-manifest.json']
for d in sorted((p/'guest/gameplay/snapshots').iterdir()):
 state=json.loads((d/'state-observation.json').read_text());profiles=json.loads((d/'profiles.json').read_text());inv=json.loads((d/'inventory.json').read_text())
 log=d/'var/log/exec.log';lines=log.read_text(errors='replace').splitlines() if log.exists() else []
 summary['snapshots'][d.name]={'state':state,'native_exit_status':inv['native_exit_status'],'profiles':{'global':profiles['flycast_emu']['selected_config'],'overrides':profiles['flycast_emu']['selected_per_game_overrides']},'exec_log_lines':[l for l in lines if any(x in l for x in ['Saved state','Loaded state','Save state','Load state','flycast','dolphin','runemu'])]}
for f in sorted((p/'guest/gameplay').glob('launch*.json')):summary['launches'].append({'path':str(f.relative_to(p)),**json.loads(f.read_text())})
for n in ['supervisor-result.json','pad-result.json','finish.json','provision.json']:
 f=p/'guest/gameplay'/n
 if f.exists():summary['channels'][str(f.relative_to(p))]=json.loads(f.read_text())
Path('/tmp/m7-native02-index.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['pngs','snapshots','channels']},indent=2))
print('channels',json.dumps(summary['channels'],indent=2)[:12000]);print('snapshots',list(summary['snapshots']));print('frames',len(summary['pngs']))

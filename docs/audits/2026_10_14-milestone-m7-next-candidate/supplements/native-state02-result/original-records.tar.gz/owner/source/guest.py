#!/usr/bin/env python3
"""UNRUN normal installed ES/native handoff, operated only through owned serial."""
import argparse,configparser,hashlib,json,os,re,shlex,shutil,signal,stat,subprocess,time,urllib.request,uuid,xml.etree.ElementTree as ET
from pathlib import Path
HERE=Path(__file__).resolve().parent;R=Path('/tmp/pix-output/gameplay');INPUT=Path('/tmp/pix-input/gameplay')
ROMS={'wii':'/storage/roms/wii/SuDokuL-Wii.dol','tetris2':'/storage/roms/dreamcast/Tetris2-M7.cdi'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):
 t=p.with_suffix('.pending');t.write_text(json.dumps(x,indent=2)+'\n');os.replace(t,p)
def identity(pid):
 p=Path('/proc',str(pid));f=(p/'stat').read_text().rsplit(')',1)[1].split()
 return {'pid':pid,'start_ticks':int(f[19]),'state':f[0],'argv':[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x]}
def natives():
 result=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   row=identity(int(p.name))
   if row['argv'] and Path(row['argv'][0]).name in ('flycast','dolphin-emu-nogui','dolphin-emu'):result.append(row)
  except (FileNotFoundError,ProcessLookupError):pass
 return result
def run(label,args,seconds=30):
 stem=R/(label+'-'+uuid.uuid4().hex[:8]);row={'argv':list(map(str,args)),'original_returncode':None,'timed_out':False}
 with Path(str(stem)+'.stdout').open('xb') as out,Path(str(stem)+'.stderr').open('xb') as err:
  child=subprocess.Popen(row['argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:row['original_returncode']=child.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   row['timed_out']=True;os.killpg(child.pid,signal.SIGKILL);row['original_returncode']=child.wait(timeout=5)
 save(Path(str(stem)+'.json'),row);assert row['original_returncode']==0 and not row['timed_out'],label
 return Path(str(stem)+'.stdout').read_text()
def api(path,data=None):
 before=time.monotonic();req=urllib.request.Request('http://127.0.0.1:1234'+path,data=data.encode() if data else None,headers={'Content-Type':'text/plain'})
 with urllib.request.urlopen(req,timeout=5) as response:row={'path':path,'http_status':response.status,'body':response.read(1024*1024).decode(),'before_monotonic':before,'after_monotonic':time.monotonic()}
 save(R/('http-'+uuid.uuid4().hex+'.json'),row);assert row['http_status'] in (200,201);return row
def pad(buttons=None,milliseconds=120,quit=False):
 q={'id':uuid.uuid4().hex,'operation':'quit' if quit else 'press','buttons':buttons,'milliseconds':milliseconds};save(R/('pad-claim-'+q['id']+'.json'),q)
 fd=os.open(R/'pad.commands',os.O_WRONLY|os.O_NONBLOCK)
 try:assert os.write(fd,(json.dumps(q)+'\n').encode())>0
 finally:os.close(fd)
 if quit:return q
 end=time.monotonic()+3
 while not (R/('pad-ack-'+q['id']+'.json')).exists():
  assert time.monotonic()<end,'ambiguous pad action: retain claim, never replay';time.sleep(.05)
 return json.loads((R/('pad-ack-'+q['id']+'.json')).read_text())
def native_state_files():
 # Exact fixture games only. Packaged Sys/GameSettings and ordinary saves are excluded.
 files=list(Path('/storage/roms/savestates/wii').glob('ID-SuDokuL-Wii.s[0-9][0-9]'))
 files+=list(Path('/storage/roms/bios/dc').glob('Tetris2-M7*.state'))
 assert len(files)<=32,'unexpected native state inventory'
 for f in files:assert not f.is_symlink() and f.is_file() and f.stat().st_size<=128*1024**2
 return sorted(files)

def selected_state_settings(data):
 # ES16dbac: exact keys/values, no trimming; Off saves empty then removes the line.
 keys=['wii["SuDokuL-Wii.dol"].emulator','wii["SuDokuL-Wii.dol"].core','dreamcast["Tetris2-M7.cdi"].emulator','dreamcast["Tetris2-M7.cdi"].core','dreamcast["Tetris2-M7.cdi"].graphics_backend']
 assert len(data)<=1024*1024
 data.decode('utf-8')
 values={k:[] for k in keys}
 global_rows=[];lines=data.split(b'\n')
 for number,line in enumerate(lines,1):
  key,sep,value=line.partition(b'=')
  k=key.decode('utf-8');v=value.decode('utf-8')
  if k.strip()=='global.autosave':assert k=='global.autosave' and sep,'noncanonical global.autosave line'
  if sep and k in values:values[k].append(v)
  if sep and k=='global.autosave':
   raw=line+(b'\n' if number<len(lines) else b'')
   global_rows.append({'line_number':number,'line_hex':raw.hex(),'value_hex':value.hex(),'value':v})
 assert all(len(v)==1 for v in values.values()),'require unique explicit per-game fixture selection'
 assert len(global_rows)<=1,'duplicate global.autosave is ambiguous fixture evidence'
 raw_value=global_rows[0]['value'] if global_rows else None
 assert raw_value in (None,'','0','1'),'unsupported global.autosave serialization; retain original and review'
 # SystemConf::get returns empty for absent/empty; the UI tests equality to "1".
 parsed_value=raw_value if raw_value else ''
 explicit={k:v[0] for k,v in values.items()}
 if global_rows:explicit['global.autosave']=raw_value
 return {'explicit_system_settings':explicit,'global_autosave':{
  'present':bool(global_rows),'raw_occurrences':global_rows,'raw_value':raw_value,
  'es_read_value':parsed_value,'effective_enabled':parsed_value=='1',
  'effective_label':'On' if parsed_value=='1' else 'Off',
  'semantics_es_commit':'16dbac5211eea7e70db7394372033be2be7df829',
  'scope':'selected stored bytes and source-derived ES global toggle; not engine state or live unsaved UI memory'}}

def state_observation():
 p=Path('/storage/.config/system/configs/system.cfg')
 with p.open('rb') as f:data=f.read(1024*1024+1)
 selected=selected_state_settings(data)
 states=[]
 for f in native_state_files():
  before=f.stat();h=sha(f);after=f.stat()
  states.append({'path':str(f),'resolved':str(f.resolve()),'bytes':before.st_size,'sha256':h,'mtime_ns':before.st_mtime_ns,'stable_during_read':(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)})
 logs=[]
 for name in ['/var/log/exec.log','/var/log/es_log.txt','/var/log/es_log.txt.bak']:
  f=Path(name)
  if not f.is_file():continue
  with f.open('rb') as stream:
   stream.seek(max(0,f.stat().st_size-32768));tail=stream.read(32768)
  lines=[line for line in tail.decode(errors='replace').splitlines() if re.search(r'Saved [Ss]tate|Loaded [Ss]tate|[Dd]ecompress|Auto.?Load|Auto.?Save|dolphin-emu|flycast|runemu|start_dolphin',line)]
  logs.append({'path':name,'bytes':f.stat().st_size,'tail_bytes_read':len(tail),'selected_lines':lines[-40:]})
 row={'time':time.time(),'native_processes':natives(),**selected,'system_config_sha256':hashlib.sha256(data).hexdigest(),'states':states,'selected_original_log_tail':logs,'scope':'live selected bytes, not completed restore or effective engine-setting proof; full original logs retained by snapshot'}
 save(R/('state-readback-'+uuid.uuid4().hex+'.json'),row);return row

def snapshot(label,copy_sd=False):
 assert not copy_sd,'state-only continuation does not copy ordinary-save SD images'
 assert re.fullmatch('[a-z0-9-]{1,60}',label);dest=R/'snapshots'/label;dest.mkdir(parents=True)
 profiles=live_profiles();save(dest/'profiles.json',profiles);save(dest/'state-observation.json',state_observation())
 paths=[Path(name) for name in profiles['files']]
 paths += [Path('/var/log/exec.log'),Path('/var/log/es_log.txt'),Path('/var/log/es_log.txt.bak')]
 states=native_state_files();paths+=states;rows=[];blobs=R/'state-bytes';blobs.mkdir(exist_ok=True)
 for f in paths:
  if not f.exists():continue
  if f.is_symlink():rows.append({'path':str(f),'link':os.readlink(f),'resolved':str(f.resolve())});continue
  assert f.is_file();before=f.stat();assert before.st_size<=128*1024**2
  # Retain each distinct state once; every snapshot still binds its actual path/hash.
  target=blobs/(sha(f)+'.bin') if f in states else dest/str(f).lstrip('/')
  target.parent.mkdir(parents=True,exist_ok=True)
  if not target.exists():shutil.copy2(f,target)
  h=sha(target);after=f.stat()
  if f in states:assert h+'.bin'==target.name and (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'native state changed during copy; preserve original, do not count snapshot'
  rows.append({'path':str(f),'bytes':target.stat().st_size,'sha256':h,'source_mtime_ns':before.st_mtime_ns,'copied':str(target.relative_to(R)),'live_source_may_advance':bool(natives())})
 save(dest/'inventory.json',{'rows':rows,'native_processes':natives(),'native_exit_status':'unknown: no engine shim or wait-status observer','time':time.time()});return str(dest)
def controller_identity(text):
 # control-gen emits SDL_JoystickName, not the kernel's raw uinput name.
 raw_name='QA521 Synthetic Xbox 360 Controller';expected_ids={'bustype':'0003','vendor':'045e','product':'028e','version':'0114'}
 assert text.count('get_controls()')==1
 assert re.findall(r'^DEVICE="([^"]+)"$',text,re.M)==['030080a15e0400008e02000014010000']
 assert re.findall(r'^param_device="([^"]+)"$',text,re.M)==['Xbox 360 Controller']
 ready=json.loads((R/'pad-ready.json').read_text());assert ready['name']==raw_name
 supervisor=json.loads((R/'supervisor.json').read_text());live_supervisor=identity(supervisor['pid'])
 assert live_supervisor['start_ticks']==supervisor['start_ticks'] and live_supervisor['argv']==supervisor['argv']
 pad_identity=identity(ready['pid']);assert pad_identity['argv']==['python3','-I','-S','-B',str(HERE/'pad.py')]
 fields=(Path('/proc',str(ready['pid']))/'stat').read_text().rsplit(')',1)[1].split();assert int(fields[1])==supervisor['pid']
 uinput_fds=[str(f) for f in Path('/proc',str(ready['pid']),'fd').iterdir() if os.readlink(f)=='/dev/uinput'];assert len(uinput_fds)==1
 matches=[]
 for event in sorted(Path('/sys/class/input').glob('event*')):
  device=event/'device'
  if (device/'name').read_text().strip()!=raw_name:continue
  ids={k:(device/'id'/k).read_text().strip() for k in expected_ids};assert ids==expected_ids
  resolved=str(device.resolve());assert resolved.startswith('/sys/devices/virtual/input/')
  node=Path('/dev/input')/event.name;st=node.stat();assert stat.S_ISCHR(st.st_mode)
  major_minor=f'{os.major(st.st_rdev)}:{os.minor(st.st_rdev)}';assert (event/'dev').read_text().strip()==major_minor
  matches.append({'raw_name':raw_name,'ids':ids,'sysfs_event':str(event),'resolved_input':resolved,'resolved_event':str(event.resolve()),'event_node':str(node),'major_minor':major_minor})
 assert len(matches)==1,'require one exact owned QA521 kernel event identity'
 row={'normalized_sdl_name':'Xbox 360 Controller','normalized_sdl_guid':'030080a15e0400008e02000014010000','kernel':matches[0],'pad':pad_identity,'supervisor':live_supervisor,'uinput_fds':uinput_fds,'control_sha256':sha(R/'control.ini')}
 save(R/'controller-identity.json',row);return row

def live_profiles():
 # Fixed profile/config allowlist, returned through existing locked status only.
 def read(path,limit,include_text=True):
  p=Path(path);row={'path':str(p),'exists':False}
  try:
   with p.open('rb') as stream:data=stream.read(limit+1)
  except FileNotFoundError:return row,None
  assert len(data)<=limit,'profile readback file bound: '+str(p)
  row.update(exists=True,resolved=str(p.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  if include_text:row['text']=data.decode('utf-8')
  return row,data
 files={}
 for name in ['GCPadNew.ini','WiimoteNew.ini']:
  path='/storage/.config/dolphin-emu/'+name;files[path]=read(path,8192)[0]
 for name in ['SDL_Keyboard.cfg','SDL_Xbox 360 Controller.cfg','SDL_Xbox 360 Controller-sdl_joystick_0.cfg','SDL_QA521 Synthetic Xbox 360 Controller.cfg','SDL_QA521 Synthetic Xbox 360 Controller-sdl_joystick_0.cfg']:
  path='/storage/.config/flycast/mappings/'+name;files[path]=read(path,8192)[0]
 control,data=read('/storage/.config/gptokeyb/control.ini',4096);assert data is not None
 files[control['path']]=control;positive=controller_identity(control['text'])
 positive['initial_provision_control_sha256']=positive.pop('control_sha256');positive['live_control_sha256']=control['sha256']
 # Read emu.cfg with a separate bound; never include its raw text/account values.
 emu,data=read('/storage/.config/flycast/emu.cfg',65536,include_text=False)
 keys=['Dreamcast.AutoLoadState','Dreamcast.AutoSaveState','Dreamcast.SavestateSlot','Dreamcast.SavestatePath','pvr.rend','rend.Resolution','rend.vsync','rend.WideScreen','rend.SuperWideScreen','rend.ShowFPS','pvr.AutoSkipFrame']
 if data is not None:
  config=configparser.ConfigParser(interpolation=None,strict=False);config.optionxform=str;config.read_string(data.decode('utf-8'))
  emu['selected_config']={key:config.get('config',key,raw=True,fallback=None) for key in keys}
  emu['selected_per_game_overrides']={section:{'config.'+key:config.get(section,'config.'+key,raw=True) for key in keys if config.has_option(section,'config.'+key)} for section in config.sections() if section!='config' and any(config.has_option(section,'config.'+key) for key in keys)}
  assert emu['selected_config']['Dreamcast.SavestatePath'] in (None,''),'unexpected custom native-state path; stop and review actual path'
 else:emu['selected_config']={key:None for key in keys}
 row={'observed_monotonic':time.monotonic(),'files':files,'flycast_emu':emu,'positive_controller_identity':positive,'scope':'live allowlisted profile bytes; missing mapping file does not establish compiled default mapping','live_reads_may_race_engine_writes':True}
 assert sum(entry.get('bytes',0) for entry in files.values())<=64*1024
 encoded=json.dumps(row).encode();assert len(encoded)<=96*1024,'profile readback total JSON bound'
 save(R/('profile-readback-'+uuid.uuid4().hex+'.json'),row);return row

def cleanup():
 # Failure-only finalizer: retain the original failed supervisor/pad exits.
 row={'rc':1,'started':time.time(),'scope':'abort owned input supervisor and verify pad destruction before output unmount'}
 try:
  receipt=R/'supervisor.json'
  if not receipt.exists():
   assert not (R/'pad-ready.json').exists(),'pad exists without supervisor identity'
   row['supervisor_was_not_started']=True
  else:
   expected=json.loads(receipt.read_text());deadline=time.monotonic()+12
   def alive(owner):
    try:current=identity(owner['pid'])
    except (FileNotFoundError,ProcessLookupError):return False
    if current['start_ticks']!=owner['start_ticks']:return False
    assert current['argv']==owner['argv'] or current['state']=='Z','owned PID changed argv'
    return True
   if alive(expected) and not (R/'abort.json').exists():save(R/'abort.json',{'reason':'lifecycle finalizer after unsuccessful completion','time':time.time()})
   while alive(expected):
    assert time.monotonic()<deadline,'owned supervisor did not finish bounded abort/destroy';time.sleep(.05)
   supervisor=json.loads((R/'supervisor-result.json').read_text());pad_result=json.loads((R/'pad-result.json').read_text())
   assert supervisor['pad_original_returncode'] is not None and not alive(supervisor['pad'])
   events=[json.loads(line) for line in (R/'pad.events.jsonl').read_text().splitlines()]
   assert sum(event.get('state')=='destroyed' for event in events)==1
   row.update(supervisor_original_rc=supervisor['rc'],pad_original_rc=supervisor['pad_original_returncode'],pad_result_original_rc=pad_result['rc'],pad_destroyed=True,supervisor_absent=True,pad_absent=True,native_processes=natives())
  row['rc']=0
 except BaseException as exc:row['error']=type(exc).__name__+': '+str(exc)
 finally:row['ended']=time.time();save(R/'failure-cleanup.json',row)
 assert row['rc']==0,row.get('error');return row

def provision(remaining):
 assert not R.exists();R.mkdir();(R/'snapshots').mkdir();end=time.monotonic()+90
 manifest=json.loads((INPUT/'input-files.json').read_text())
 for name,row in manifest.items():assert sha(INPUT/name)==row['sha256'] and (INPUT/name).stat().st_size==row['bytes']
 verification=json.loads((INPUT/'final-image-result.json').read_text());assert verification['status']=='PASS'
 installed={}
 for name in (HERE/'consumed-paths.txt').read_text().splitlines():
  if not name or name.startswith('#'):continue
  f=Path('/'+name);assert f.is_file(),name
  row={'bytes':f.stat().st_size,'sha256':sha(f),'resolved':str(f.resolve()),'mode':f.stat().st_mode&0o777}
  if name in verification['products']:
   expected=verification['products'][name];assert row['bytes']==expected['bytes'] and row['sha256']==expected['sha256'];row['comparison']='existing final verifier row matched'
  else:row['comparison']='actual installed bytes; final image/SYSTEM/BUILD_ID bound, no unlisted source-to-final equality claim'
  installed[name]=row
 for name,expected in json.loads((HERE/'frozen-config-bindings.json').read_text()).items():
  assert installed[name]['sha256']==expected['expected_installed_sha256'];installed[name]['frozen_source_comparison']=expected
 save(R/'installed-inputs.json',{'system':verification['payload']['SYSTEM'],'source':verification['source'],'products':installed})
 while True:
  displays=[p for p in Path('/run/0-runtime-dir').glob('wayland-*') if p.is_socket()];sway=[p for p in Path('/run/0-runtime-dir').glob('sway-ipc.*.sock') if p.is_socket()]
  if len(displays)==len(sway)==1 and Path('/storage/.config/emulationstation/es_input.cfg').is_file():
   out=run('display-outputs',['swaymsg','-s',sway[0],'-t','get_outputs','-r'],3);active=[r for r in json.loads(out) if r.get('active')]
   if len(active)==1:break
  assert time.monotonic()<end,'display/input readiness';time.sleep(1)
 assert not natives();run('stop-es',['systemctl','stop','essway.service'])
 originals=R/'originals';originals.mkdir()
 for path in ['/storage/.config/system/configs/system.cfg','/storage/.config/emulationstation/es_input.cfg']:
  f=Path(path)
  if f.is_file():shutil.copy2(f,originals/f.name)
 for game,rom in ROMS.items():
  src=INPUT/('SuDokuL-Wii.dol' if game=='wii' else 'Tetris2-M7.cdi');target=Path(rom);assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target);assert sha(src)==sha(target)
 q=Path('/storage/qa-m7-homebrew');q.mkdir();shutil.copy2(INPUT/'sd.raw',q/'sd.raw');shutil.copy2(INPUT/'Tetris2-M7.cdi.sha256',q/'Tetris2-M7.cdi.sha256')
 run('wii-fixture',['bash',HERE/'fixture/prepare-wii-guest.sh',R/'wii-preparation'])
 if not Path('/storage/.config/flycast').exists():shutil.copytree('/usr/config/flycast','/storage/.config/flycast')
 run('flycast-fixture',['python3','-I','-S','-B',HERE/'fixture/configure-flycast.py','--expected-ini-sha256',sha(Path('/storage/.config/flycast/emu.cfg'))])
 script='. /etc/profile; cp -p "$J_CONF" '+shlex.quote(str(originals/'system-before-settings.cfg'))+'; '+ '; '.join('set_setting '+shlex.quote(key)+' '+shlex.quote(value) for key,value in [('wii["SuDokuL-Wii.dol"].emulator','dolphin'),('wii["SuDokuL-Wii.dol"].core','dolphin-sa-wii'),('dreamcast["Tetris2-M7.cdi"].emulator','flycast'),('dreamcast["Tetris2-M7.cdi"].core','flycast-sa'),('dreamcast["Tetris2-M7.cdi"].graphics_backend','opengl'),('global.autosave','0'),('system.loglevel','verbose')])
 run('fixture-settings',['bash','-ec',script])
 with (R/'supervisor.stdout').open('xb') as out,(R/'supervisor.stderr').open('xb') as err:
  child=subprocess.Popen(['python3','-I','-S','-B',str(HERE/'supervisor.py'),str(remaining)],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);save(R/'supervisor.json',identity(child.pid))
 limit=time.monotonic()+10
 while not (R/'pad-ready.json').exists():assert time.monotonic()<limit;time.sleep(.1)
 # Use the normal installed producer; retain its actual GUID/name and generated file.
 run('control-gen',['/usr/bin/control-gen_init.sh']);shutil.copy2('/storage/.config/gptokeyb/control.ini',R/'control.ini')
 text=(R/'control.ini').read_text();controller_identity(text)
 config=Path('/storage/.config/emulationstation/es_input.cfg');keyboard=ET.fromstring(config.read_bytes()).find("inputConfig[@type='keyboard']");assert keyboard is not None
 key_names={13:'ret',27:'esc',32:'spc',8:'backspace',1073741906:'up',1073741905:'down',1073741904:'left',1073741903:'right',1073742049:'shift',1073742053:'shift_r'}
 mapping={}
 for x in keyboard.findall('input'):
  if x.get('type')=='key':
   number=int(x.get('id'));key=key_names.get(number) or (chr(number) if 97<=number<=122 else None)
   if key:mapping[x.get('name')]=key
 run('start-es',['systemctl','start','essway.service'])
 limit=time.monotonic()+25
 while True:
  try:systems=api('/systems');break
  except (OSError,TimeoutError):assert time.monotonic()<limit;time.sleep(1)
 value={'rc':0,'input_keys':mapping,'panel':active,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'control_sha256':sha(R/'control.ini'),'api_port':1234,'native_exit_status':'unknown unless existing original logs expose it'};save(R/'provision.json',value);return value
def main():
 p=argparse.ArgumentParser();p.add_argument('operation',choices=['provision','status','launch','pad','snapshot','global-auto','native-auto','score-start','score-end','first-frame','finish','abort','cleanup']);p.add_argument('--remaining',type=int);p.add_argument('--game',choices=ROMS);p.add_argument('--buttons');p.add_argument('--milliseconds',type=int,default=120);p.add_argument('--label');p.add_argument('--copy-sd',action='store_true');p.add_argument('--value',choices=['0','1']);a=p.parse_args()
 if a.operation=='provision':assert 60<a.remaining<=1800;result=provision(a.remaining)
 else:
  assert R.is_dir()
  if a.operation=='cleanup':result=cleanup()
  elif a.operation=='status':result={'native_processes':natives(),'pad':json.loads((R/'pad-ready.json').read_text()),'supervisor_result':json.loads((R/'supervisor-result.json').read_text()) if (R/'supervisor-result.json').exists() else None,'running_game':api('/runningGame'),'profiles':live_profiles(),'state_observation':state_observation()}
  elif a.operation=='pad':
   if (R/'score-clock.json').exists() and not (R/'score-result.json').exists():assert time.monotonic()<=json.loads((R/'score-clock.json').read_text())['deadline_monotonic'],'earned-score input window ended; record score-end, do not continue scoring'
   result=pad(a.buttons.split(','),a.milliseconds)
  elif a.operation=='launch':
   prior=sorted(R.glob('launch-*.json'));order=['wii','tetris2','tetris2','tetris2']
   assert len(prior)<len(order) and a.game==order[len(prior)] and not natives(),'exact four-launch continuation order'
   result=api('/launch',ROMS[a.game]);result['game']=a.game;result['ordinal']=len(prior)+1;result['id']=uuid.uuid4().hex;save(R/('launch-'+result['id']+'.json'),result);save(R/'active-launch.json',result)
  elif a.operation=='snapshot':result={'snapshot':snapshot(a.label,a.copy_sd)}
  elif a.operation in ('global-auto','native-auto'):
   assert not natives() and a.value is not None
   snapshot(a.operation+'-before-'+uuid.uuid4().hex[:8])
   if a.operation=='global-auto':
    run('stop-es-setting',['systemctl','stop','essway.service']);run('global-auto',['bash','-ec','. /etc/profile; set_setting global.autosave '+a.value+'; get_setting global.autosave']);run('start-es-setting',['systemctl','start','essway.service'])
   else:
    f=Path('/storage/.config/flycast/emu.cfg');c=configparser.ConfigParser(interpolation=None);c.optionxform=str;c.read(f)
    assert not any(c.has_option(section,'config.'+key) for section in c.sections() if section!='config' for key in ['Dreamcast.AutoSaveState','Dreamcast.AutoLoadState']),'unexpected per-game native auto override; do not silently change global defaults'
    for k in ['Dreamcast.AutoSaveState','Dreamcast.AutoLoadState']:c['config'][k]='yes' if a.value=='1' else 'no'
    with f.open('w') as stream:c.write(stream)
   result={'setting':a.operation,'value':a.value,'state_observation':state_observation(),'profiles':live_profiles()}
  elif a.operation=='first-frame':
   launch=json.loads((R/'active-launch.json').read_text());result={'launch_id':launch['id'],'label':a.label,'elapsed_seconds':time.monotonic()-launch['before_monotonic'],'capture_only':True};assert result['elapsed_seconds']<=120;save(R/('first-frame-'+launch['id']+'.json'),result)
  elif a.operation=='score-start':
   assert not (R/'score-clock.json').exists();result={'start_monotonic':time.monotonic(),'deadline_monotonic':time.monotonic()+360};save(R/'score-clock.json',result)
  elif a.operation=='score-end':
   result=json.loads((R/'score-clock.json').read_text());result['end_monotonic']=time.monotonic();result['within_360s']=result['end_monotonic']<=result['deadline_monotonic'];save(R/'score-result.json',result)
  elif a.operation=='abort':save(R/'abort.json',{'reason':a.label or 'operator abort','time':time.time()});result={'abort_requested':True}
  elif a.operation=='finish':
   assert not natives() and len(list(R.glob('launch-*.json')))==4;snapshot('final');save(R/'finish.json',{'time':time.time()});limit=time.monotonic()+15
   while not (R/'supervisor-result.json').exists():assert time.monotonic()<limit;time.sleep(.1)
   supervisor=json.loads((R/'supervisor.json').read_text())
   while Path('/proc',str(supervisor['pid'])).exists():assert time.monotonic()<limit;time.sleep(.05)
   result=json.loads((R/'supervisor-result.json').read_text());assert result['rc']==0 and result['pad_original_returncode']==0
   run('sync',['sync']);rows=[{'path':str(f.relative_to(R.parent)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(R.parent.rglob('*')) if f.is_file() and f.name!='guest-export-manifest.json'];assert sum(r['bytes'] for r in rows)<=448*1024**2;assert len(rows)<=4095,'4096-file exporter includes manifest itself';save(R.parent/'guest-export-manifest.json',rows)
  else:raise AssertionError(a.operation)
 print('PIX_GAMEPLAY_JSON='+json.dumps(result))
if __name__=='__main__':main()

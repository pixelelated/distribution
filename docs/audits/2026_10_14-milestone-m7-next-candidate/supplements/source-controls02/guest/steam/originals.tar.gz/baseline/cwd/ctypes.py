from pathlib import Path
Path('poison-ran').write_text('fixture-only import')
raise SystemExit(91)

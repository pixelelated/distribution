#!/bin/bash
# Retroachievements
  /usr/bin/cheevos_dolphin.sh
  CHEEVOS_STATUS=$?
  # Disabled/logged-out is a valid launch only after the inactive INI is written.
  case "${CHEEVOS_STATUS}" in
    0|1) ;;
    *) exit "${CHEEVOS_STATUS}" ;;
  esac

printf 'helper_status=%s\n' "${CHEEVOS_STATUS:-$?}" > /tmp/engine.started

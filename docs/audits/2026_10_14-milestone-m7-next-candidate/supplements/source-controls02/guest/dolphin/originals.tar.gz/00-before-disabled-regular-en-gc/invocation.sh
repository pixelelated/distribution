#!/bin/bash
# Retroachievements
  /usr/bin/cheevos_dolphin.sh

printf 'helper_status=%s\n' "${CHEEVOS_STATUS:-$?}" > /tmp/engine.started

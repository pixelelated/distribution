# Steam runtime Python isolation — #595

Prepared, UNRUN. Can this be done on the VM? Yes: execute the exact extracted
runtime function using the installed interpreter in a no-NIC guest. Two cases
reproduce cwd/PYTHONPATH import interception in the baseline and complete the
candidate runtime transaction with the same harmless poisoned modules ignored.
The exact embedded Python body is unchanged. Curl/wget are explicit fixture
transports serving a tiny generated archive; its ARM64 ELF-shaped library stubs
are checked as bytes and never executed. This is no native ARM/client proof.

Run only in the allocated guest using python3 -I -S -B probe.py --out
/run/pix595-isolation-01. Each exact function has a 30-second wall bound,
20 CPU seconds, 256 MiB address-space ceiling, and an 8 MiB soft output limit.
The hard file limit is 2 GiB to permit the unchanged product downloader to set
its own bounded archive limit. An earlier static review rejected an incompatible
8 MiB hard limit before runtime. The transport can copy only the tiny fixture
archive; no network/client operation is performed.

Keep original stdout/stderr/status and before/after file bindings. Expected
function exits are 1 (baseline, poisoned import reached) and 0 (candidate,
complete library/links installed with no unfinished journal or bytecode output).
Root owns allocation, final proof review, integration, and qualification.

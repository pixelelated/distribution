install_steam_runtime_arm64() {
  log_info "Downloading and installing Steam runtime (ARM64)..."
  # Keep the existing runtime until the complete staged archive and both library
  # links validate. The journal also recovers a process killed between renames.
  # This transaction does not cover the separate FEX/client/Proton operations.
  if /usr/bin/python3 -I -S -B - "${STEAM}" "${RUNTIME_TAR_VERSION_URL}" "${RUNTIME_TAR_BASE}" <<'PY_STEAM_RUNTIME'
import ctypes
import fcntl
import hashlib
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import resource
import shutil
import signal
import stat
import subprocess
import sys
import tarfile

RUNTIME = "steam-runtime-steamrt-arm64"
LINKS = ("libibus-1.0.so.5", "libva.so.2")
RESERVE = 256 * 1024 * 1024
MAX_ARCHIVE = 2 * 1024 * 1024 * 1024
MAX_EXPANDED = 16 * 1024 * 1024 * 1024
MAX_MEMBERS = 250000
MAX_LINK_BACKUP = 64 * 1024 * 1024


def identity(path):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    if not stat.S_ISDIR(info.st_mode):
        raise RuntimeError("Runtime transaction directory is not a real directory: " + str(path))
    return [info.st_dev, info.st_ino]


def describe(path):
    if path.is_symlink():
        return {"kind": "link", "target": os.readlink(path)}
    if not path.exists():
        return {"kind": "absent"}
    if not path.is_file():
        raise RuntimeError("Refusing to replace a non-file library entry: " + str(path))
    info = path.stat()
    if info.st_size > MAX_LINK_BACKUP:
        raise RuntimeError("Existing library entry exceeds the bounded backup size.")
    return {"kind": "file", "sha256": digest(path), "mode": stat.S_IMODE(info.st_mode),
            "mtime_ns": info.st_mtime_ns}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def capacity(root, needed):
    if shutil.disk_usage(root).free < needed + RESERVE:
        raise RuntimeError("Not enough free space to keep the previous Steam runtime while replacing it.")


def directory(path, device):
    if path.is_symlink() or not path.is_dir() or path.stat().st_dev != device:
        raise RuntimeError("Runtime update needs real directories on the Steam filesystem: " + str(path))


def no_mounts(path):
    # st_dev alone misses a bind mount on the same filesystem. Never walk a
    # mounted subtree while retiring or rolling back an owned runtime tree.
    boundary = path.resolve()
    for line in Path("/proc/self/mountinfo").read_text().splitlines():
        field = line.split()[4]
        mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field))
        if mount == boundary or boundary in mount.parents:
            raise RuntimeError("Mounted runtime paths must be released before replacement: " + str(path))


def validate(runtime):
    directory(runtime, runtime.parent.stat().st_dev)
    platforms = list(runtime.glob("steamrt3c_platform_*"))
    if len(platforms) != 1 or platforms[0].is_symlink() or not platforms[0].is_dir():
        raise RuntimeError("Expected one complete Steam ARM64 platform directory.")
    targets = {}
    for name in LINKS:
        matches = list((platforms[0] / "files/lib/aarch64-linux-gnu").glob(name + ".*"))
        if len(matches) != 1:
            raise RuntimeError("Missing or ambiguous runtime library: " + name)
        target = matches[0]
        if not target.resolve(strict=True).is_relative_to(runtime.resolve(strict=True)):
            raise RuntimeError("Runtime library escapes the staged runtime.")
        with target.open("rb") as stream:
            header = stream.read(20)
        if (len(header) != 20 or header[:6] != b"\x7fELF\x02\x01"
                or header[16:20] != b"\x03\x00\xb7\x00"):
            raise RuntimeError("Runtime library is not an ARM64 shared object: " + name)
        targets[name] = {"path": str(target.relative_to(runtime)), "sha256": digest(target)}
    return targets


class RuntimeUpdate:
    def __init__(self, root):
        self.link_root = Path(os.path.abspath(root))
        self.root = root.resolve(strict=True)
        if self.root == Path("/"):
            raise RuntimeError("Refusing the filesystem root as the Steam directory.")
        self.device = self.root.stat().st_dev
        self.work = self.root / ".steam-runtime-update"
        self.live = self.root / RUNTIME
        self.lib = self.root / "lib/aarch64-linux-gnu"
        self.state = None

    def write_state(self):
        pending = self.work / "state.tmp"
        with pending.open("w") as stream:
            json.dump(self.state, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(pending, self.work / "state.json")
        fd = os.open(self.work, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

    def clean(self):
        # Keep the journal until all other owned remnants are gone. A killed
        # cleanup is retried without accumulating another staging tree.
        for child in self.work.iterdir():
            if child.name == "state.json":
                continue
            if child.is_dir() and not child.is_symlink():
                no_mounts(child)
                shutil.rmtree(child)
            else:
                child.unlink()
        (self.work / "state.json").unlink(missing_ok=True)
        self.work.rmdir()
        self.state = None

    def check_parents(self):
        for path in (self.root / "lib", self.lib):
            if path.exists() or path.is_symlink():
                directory(path, self.device)
                no_mounts(path)

    def recover(self):
        if not self.work.exists() and not self.work.is_symlink():
            return
        directory(self.work, self.device)
        journal = self.work / "state.json"
        if not journal.exists():
            # mkdir can be interrupted before the first journal is written.
            # An empty directory is safe to remove; unknown contents are not.
            self.work.rmdir()
            return
        if journal.is_symlink() or not journal.is_file() or journal.stat().st_size > 65536:
            raise RuntimeError("Refusing an invalid runtime recovery journal.")
        self.state = json.loads(journal.read_text())
        if (self.state.get("format") != 1 or self.state.get("root") != str(self.root)
                or self.state.get("link_root") != str(self.link_root)):
            raise RuntimeError("Unrecognized runtime recovery journal; retaining it.")
        no_mounts(self.work)
        phase = self.state["phase"]
        if phase in ("prepared", "committed"):
            no_mounts(self.live)
            if (set(self.state["targets"]) != set(LINKS)
                    or set(self.state["links"]) != set(LINKS)
                    or any(p not in ("lib/aarch64-linux-gnu", "lib")
                           for p in self.state["created_dirs"])):
                raise RuntimeError("Invalid runtime recovery paths; retaining them.")
            for target in self.state["targets"].values():
                relative = PurePosixPath(target["path"])
                if relative.is_absolute() or ".." in relative.parts or not relative.parts:
                    raise RuntimeError("Invalid runtime recovery target.")
        self.check_parents()
        if phase == "committed":
            if identity(self.live) != self.state["candidate_id"] or validate(self.live) != self.state["targets"]:
                raise RuntimeError("Committed runtime changed; keeping its recovery copy.")
            for name in LINKS:
                if describe(self.lib / name) != self.new_link(name):
                    raise RuntimeError("Committed library link changed; keeping its recovery copy.")
        elif phase == "prepared":
            old_id = self.state["old_id"]
            live_id = identity(self.live)
            backup = self.work / "previous"
            if old_id is not None and live_id == old_id:
                pass  # Not activated yet, or rollback was itself interrupted.
            else:
                if old_id is not None and identity(backup) != old_id:
                    raise RuntimeError("Previous runtime identity changed; no automatic cleanup.")
                if live_id == self.state["candidate_id"]:
                    os.replace(self.live, self.work / "discard")
                elif live_id is not None:
                    raise RuntimeError("Active runtime identity changed; no automatic cleanup.")
                if old_id is not None:
                    os.replace(backup, self.live)
            for name in LINKS:
                saved = self.state["links"][name]
                live = self.lib / name
                current = describe(live)
                if current == saved:
                    continue
                if current != self.new_link(name):
                    raise RuntimeError("Library link changed outside the update; retaining recovery data.")
                if saved["kind"] == "absent":
                    live.unlink()
                else:
                    restore = self.work / ("restore-" + name)
                    restore.unlink(missing_ok=True)
                    shutil.copy2(self.work / ("saved-" + name), restore, follow_symlinks=False)
                    os.replace(restore, live)
            for relative in self.state["created_dirs"]:
                path = self.root / relative
                if path.exists():
                    path.rmdir()  # Never remove another writer's contents.
        elif phase != "staging":
            raise RuntimeError("Unknown runtime recovery phase; retaining it.")
        self.clean()

    def new_link(self, name):
        return {"kind": "link", "target": str(self.link_root / RUNTIME / self.state["targets"][name]["path"])}

    def begin(self):
        self.work.mkdir(mode=0o700)
        self.state = {"format": 1, "root": str(self.root), "link_root": str(self.link_root), "phase": "staging"}
        self.write_state()
        (self.work / "unpack").mkdir()

    def prepare(self):
        candidate = self.work / "unpack" / RUNTIME
        targets = validate(candidate)
        self.check_parents()
        links = {name: describe(self.lib / name) for name in LINKS}
        capacity(self.root, sum((self.lib / name).stat().st_size for name in LINKS
                               if links[name]["kind"] == "file"))
        for name in LINKS:
            if links[name]["kind"] != "absent":
                shutil.copy2(self.lib / name, self.work / ("saved-" + name), follow_symlinks=False)
        old_id = identity(self.live)
        no_mounts(self.live)
        if old_id is not None and old_id[0] != self.device:
            raise RuntimeError("Previous runtime is on a different filesystem.")
        self.state.update(phase="prepared", targets=targets, links=links, old_id=old_id,
                          candidate_id=identity(candidate),
                          created_dirs=[p for p in ("lib/aarch64-linux-gnu", "lib")
                                        if not (self.root / p).exists()])
        self.write_state()  # The complete rollback description precedes every rename.

    def activate(self):
        self.lib.mkdir(parents=True, exist_ok=True)
        if self.state["old_id"] is not None:
            os.replace(self.live, self.work / "previous")
        os.replace(self.work / "unpack" / RUNTIME, self.live)
        for name in LINKS:
            pending = self.work / ("new-" + name)
            pending.symlink_to(self.new_link(name)["target"])
            os.replace(pending, self.lib / name)
        if validate(self.live) != self.state["targets"]:
            raise RuntimeError("Activated runtime failed validation.")
        for name in LINKS:
            if describe(self.lib / name) != self.new_link(name) or not (self.lib / name).is_file():
                raise RuntimeError("Activated runtime library link failed validation.")
        self.state["phase"] = "committed"
        self.write_state()  # Only this point permits retiring the superseded tree.
        self.clean()


def fetch_archive(update, version_url, base_url):
    owner_pid = os.getpid()

    def child_setup(limit=None):
        # SIGKILL cannot run a Python cleanup handler. Linux must kill the
        # transport child with its owner, before another updater can retry.
        libc = ctypes.CDLL(None, use_errno=True)
        if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:  # PR_SET_PDEATHSIG
            raise OSError(ctypes.get_errno(), "Cannot bind downloader lifetime to installer")
        if os.getppid() != owner_pid:  # Parent may have died before prctl.
            os.kill(os.getpid(), signal.SIGKILL)
        if limit is not None:
            resource.setrlimit(resource.RLIMIT_FSIZE, (limit, limit))

    version = subprocess.run(["curl", "-fsSL", "--connect-timeout", "10", "--max-time", "30",
                              "--max-filesize", "128", version_url],
                             check=True, capture_output=True, timeout=35, preexec_fn=child_setup).stdout.decode().strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,79}", version):
        raise RuntimeError("Invalid Steam runtime version.")
    capacity(update.root, 1)
    budget = min(MAX_ARCHIVE, shutil.disk_usage(update.root).free - RESERVE)
    archive = update.work / "runtime.tar.xz"

    subprocess.run(["wget", "-t", "3", "-T", "30", "-O", str(archive),
                    base_url + "/" + version + "/" + RUNTIME + ".tar.xz"],
                   check=True, timeout=900, preexec_fn=lambda: child_setup(budget))
    return archive


def unpack_archive(update, archive):
    # Inspect the complete compressed stream (including its integrity footer)
    # before extraction; never use the live Steam directory as tar's destination.
    needed = 0
    seen = set()
    with lzma.open(archive, "rb") as stream:
        with tarfile.open(fileobj=stream, mode="r|") as archive_stream:
            for member in archive_stream:
                path = PurePosixPath(member.name)
                if (path.is_absolute() or ".." in path.parts or not path.parts
                        or path.parts[0] != RUNTIME or path.as_posix() in seen or member.size < 0):
                    raise RuntimeError("Unsafe or duplicate runtime archive path.")
                if not (member.isfile() or member.isdir() or member.issym() or member.islnk()):
                    raise RuntimeError("Unsupported runtime archive entry.")
                seen.add(path.as_posix())
                needed += ((member.size + 4095) // 4096) * 4096 + 8192
                if len(seen) > MAX_MEMBERS or needed > MAX_EXPANDED:
                    raise RuntimeError("Runtime archive exceeds the bounded extraction budget.")
        while True:
            chunk = stream.read(1024 * 1024)
            if stream.tell() > MAX_EXPANDED:
                raise RuntimeError("Runtime archive exceeds the decoded-stream budget.")
            if not chunk:
                break
    capacity(update.root, needed)
    with tarfile.open(archive, "r:xz") as payload:
        payload.extractall(update.work / "unpack", filter="data")
    capacity(update.root, 0)
    archive.unlink()


def interrupted(signum, frame):
    raise InterruptedError("Steam runtime update interrupted by signal " + str(signum))


def main():
    update = RuntimeUpdate(Path(sys.argv[1]))
    # A persistent lock inode serializes this component; never unlink the lock
    # file while another invocation may have opened it. No service is started.
    lock_path = update.root / ".steam-runtime-update.lock"
    fd = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise RuntimeError("Runtime update lock is not a regular file.")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
            signal.signal(sig, interrupted)
        signal.alarm(1800)
        try:
            update.recover()
            update.check_parents()
            capacity(update.root, 1)
            update.begin()
            archive = fetch_archive(update, sys.argv[2], sys.argv[3])
            unpack_archive(update, archive)
            update.prepare()
            update.activate()
            return 0
        except Exception as error:
            print("Steam runtime replacement failed: " + str(error), file=sys.stderr)
            signal.alarm(0)
            try:
                update.recover()
            except Exception as recovery_error:
                print("Runtime recovery needs attention; previous data is retained at "
                      + str(update.work) + ": " + str(recovery_error), file=sys.stderr)
            return 1
        finally:
            signal.alarm(0)
    finally:
        os.close(fd)


if __name__ == "__main__":
    sys.exit(main())
PY_STEAM_RUNTIME
  then
    return 0
  fi
  die "Steam runtime replacement failed. The installer has stopped."
}

# #594 stale Dolphin achievement session: focused source packet

Status: **source-only; runtime UNRUN**. No VM, chroot, preparer, service, product
script, or emulator was executed while preparing this packet. `bash -n` and
Python AST/compile checks only. Root owns source integration, final commit binding,
VM admission, allocation, execution, player-facing frames, and acceptance.

Baseline is frozen `d4af5a255f4778a6ecf63ca5b37e05a0f1c83e3a`.
Candidate is the exact captured uncommitted coordinator helper/GC/Wii launcher
delta; `context.json`, `bindings.json`, original files and product.diff bind it.
Before allocation, compare all three candidate source SHA256 values against the
final reviewed/committed versions. A changed script requires a new binding and
static review; this packet does not silently follow coordinator working files.

## Focused cases

The 15-case probe runs complete helper bytes inside a disposable guest chroot.
The launcher portion is the exact unique block from `# Retroachievements` to
the next backend heading, followed by a fixture-only engine-reached marker.
Both GC and Wii blocks are separately bound; the candidate blocks are identical.
This verifies the real status gate, not the full launcher or an actual engine.

| Cases | Expected evidence |
| --- | --- |
| Old disabled and missing token (GC/Wii) | Helper exit 1, old enabled INI with prior credentials remains byte-identical, launcher reaches marker: reproduce stale session. |
| Candidate disabled and missing token (GC/Wii) | Helper exit 1, inactive INI with every session flag false and Username/ApiToken/HostUrl empty, launcher reaches marker. |
| Old/new enabled casual proxy | Exact generated INI unchanged, HostUrl 127.0.0.1:8080, helper exit 0. |
| Old/new enabled hardcore/custom host | Exact generated INI unchanged, custom host retained, helper exit 0. |
| Old/new enabled missing listener | Exact generated INI unchanged, custom host retained, helper exit 0. |
| Candidate denied tempfile creation (EN/GC) | Actual guest mktemp fails, old bytes retained, exit 250, no engine marker, exact English error file. |
| Candidate denied publication (EN/GC and FR/Wii) | Root-owned old INI in a sticky writable directory allows child temporary creation but denies actual mv replacement. Old bytes retained, temporary removed, exit 250, no marker, exact localized error protocol. |
| Candidate directory destination (EN/Wii) | Actual mv -T refuses directory, prior member retained, no token file placed inside, temporary removed, exit 250, no marker. |
| Candidate symlink destination (GC) | Atomic publish replaces the link with inactive regular mode-0600 INI; protected target bytes remain unchanged. |

Every case compares the synthetic saved-account settings, pending-award SQLite
queue, ordinary save, native state sentinel, symlink target, profile and runtime
files before/after. All values are synthetic; no real account or award exists.

## Reused containment and execution contract

Source derivative of the qualified
`docs/qa-logs/2026-10-14-dolphin-proxy-routing-source/fixtures/probe.py`.
Its original is retained. The ELF parser and complete child `isolate()` AST are
unchanged. The runtime stager's only change is extending bash/cat to include the
actual guest mktemp/mv/rm binaries and their statically discovered ELF dependencies.
No ldd, host binary execution, listener, emulation or network request is used.

Child contract: private network namespace; disposable chroot; UID/GID 65534;
empty supplementary groups; no-new-privileges; parent-death SIGKILL readback;
owned process group; 2 CPU seconds / at most 3 wall seconds / 64 KiB file limit.
Parent contract: 60-second work alarm, 50 CPU seconds, 256 MiB address space,
24 MiB runtime stage and 32 MiB total scratch. Existing bounded owned-descendant
cleanup is retained after the work alarm. The output and all child original exits,
containment readbacks, runtime identities, stdout/stderr and generated INIs remain.
Any timeout, leftover descendant, unexpected mutation or leaked temporary fails.

## Root's bounded next execution

Can this be done on the VM? **Yes**: real installed shell/utilities, file modes,
atomic publication and exact launcher status gate are guest-verifiable. No
physical fact is required. Root must record that answer in #594 before execution.

Use the existing qualified single-guest lifecycle and its sole serial operator.
Bind the allocated guest's actual image/SYSTEM identity, final product commit and
this packet seal. Stage this sealed packet read-only in that owner's input media.
The probe itself refuses a non-root caller, missing installed ES/Dolphin, reused
output, or an output outside `/run/pix594-*`. It must never run on the build host.
After allocation only, from the guest's existing operator route:

```sh
python3 -I -S -B /run/pix-input/session-clear/fixtures/probe.py \
  --output /run/pix594-session-01
```

The input mount path is chosen by root's existing owner; adjust only that path,
not fixture bytes. Capture the original command exit and resulting `result.json`
through the owner's existing receipt/export route. Preserve failure outputs.
Require 15 PASS rows, exact before/after bindings, all child cleanup and protected
file assertions, and wrapper exit 0 before accepting this fixture evidence.
Existing EN/FR player-facing frame work is separate and remains root-owned.

No admission, outer runner, resource allocation, install, source promotion or
runtime acceptance is implied by this source packet.

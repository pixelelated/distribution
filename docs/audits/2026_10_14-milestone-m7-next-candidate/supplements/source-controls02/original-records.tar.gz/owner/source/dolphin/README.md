# #594 revision02: additive descendant-census correction

**Source-only; runtime UNRUN.** This revision changes only fixture supervision
and final failure-receipt handling. All 15 cases, expected product bytes, complete
helper scripts, exact GC/Wii launcher snippets, staging of actual guest tools,
synthetic inputs and child isolation remain unchanged from revision01.

Revision01 and its failed owner are immutable. The prior packet seal remains
`79a9d0903443c0cc0d13fb5e28c85cccfc19a0718e7308660b7a30204b785a1d`.
Its README and static report are retained under explicit revision01 names.
That historical report proves syntax and its original comparisons only; it did
not establish guest availability of `/proc/self/task/PID/children`.

## Original failure and first case

Original export:
`/workspace/tmp/pix-m7-audit-controls-evidence-20261015-01`.
Original guest command exited **1**, without timeout. Per-case observation of
`/proc/self/task/1952/children` failed, and the same unavailable interface failed
again during cleanup, preventing final JSON publication. I inherited that old
interface despite the existing correction; this revision applies it explicitly.

`first-failure-review.json` binds the original archive and selected original
command/stderr/first-case bytes. All 26 archived members were checked against
their original member manifest. Only `00-before-disabled-regular-en-gc` ran.
Its helper is byte-identical to the baseline helper, stdout/stderr are empty,
the old enabled session remains, the disabled log is present, and the engine
marker contains `helper_status=1`. The candidate helper was not reached.
No candidate product failure is hidden by this correction. The first case's
formal assertions were interrupted, so this is a bounded raw observation,
not a case PASS or a revised original exit.

## Existing correction reused exactly

Source:
`docs/qa-logs/2026-10-14-dolphin-proxy-routing-census-source/fixtures/probe.py`,
SHA256 `35e8daa514262c3f40ccae8009f71c5e3069ff966ea9c1d4dedaa7c1e08482c4`.

The `proc_identity`, `direct_children`, and `signal_child` function ASTs and the
complete final cleanup/receipt block AST are identical to that source. The
replacement reads numeric `/proc/PID/stat`, selects only this subreaper's PPID,
and binds PID/PPID/start ticks. Missing or malformed observations fail closed;
only a confirmed vanished proc directory is a benign read race. Cleanup rechecks
identity before and after opening a pidfd, then signals that pidfd. No numeric
kill, killpg, process-name matching, or optional children-file fallback remains.
Python/Linux pidfd support is required before any helper execution.

The final child observation begins as null/unknown. Observation and cleanup
failures remain FAIL and are recorded independently of result publication.
Receipt-write failure emits the complete FAIL record to captured stdout before
raising. Original errors and any recorded child exit survive cleanup errors.

`revision02-fixture.diff` is the exact delta from revision01. `static-result.json`
also verifies every original non-main function, the entire expectation tail and
all product-input hashes unchanged. The complete child isolation function is
AST-identical across revision01, revision02 and the existing census source.
This packet makes no new runtime qualification claim about itself or its inputs.

## Root handoff

Self-contained packet; no adjacent revision01 runtime dependency is required.
The revised probe validates `revision-bindings.json`, its retained original
fixture/seal, the census-source hash, and the unchanged product binding manifest.
Root still binds the exact final committed product source, installed guest image,
fresh admitted owner and packet seal before execution. Existing source plan and
15-case criteria are in `README.revision01.md`; its obsolete process-group
description is superseded by this revision's identity-checked pidfd cleanup.

Under the same qualified outer lifecycle, **after root allocation only**, use
the revised packet at the owner's input location and a fresh output:

```sh
python3 -I -S -B /tmp/pix-input/controls/dolphin/fixtures/probe.py \
  --output /run/pix594-session-02
```

Keep the 75-second outer bound and all existing inner resource limits. Preserve
original failures and first stopping case; do not automatically retry or weaken
descendant assertions. No product edit, VM, preparer, runtime, commit, or shared
record mutation occurred during this revision.

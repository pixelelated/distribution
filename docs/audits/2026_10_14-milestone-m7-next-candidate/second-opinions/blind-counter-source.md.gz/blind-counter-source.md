# Source used to test external leads


## DISTRO fac608ff8994:projects/ROCKNIX/packages/network/networkmanager/package.mk

```text
    1 # SPDX-License-Identifier: GPL-2.0
    2 # Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
    3 
    4 PKG_NAME="networkmanager"
    5 PKG_VERSION="1.51.4"
    6 PKG_SHA256="865a7cc5686a51d7efe81d7dcb3c5246bfa3b996a58629135354972804ff4d3c"
    7 PKG_LICENSE="GPL"
    8 PKG_SITE="https://gitlab.freedesktop.org/NetworkManager/NetworkManager"
    9 PKG_URL="https://download.gnome.org/sources/NetworkManager/1.51/NetworkManager-${PKG_VERSION}.tar.xz"
   10 PKG_DEPENDS_TARGET="toolchain glib dbus libndp nss nspr systemd util-linux readline ncurses"
   11 PKG_LONGDESC="Network connection manager (Ethernet and Wi-Fi; Wi-Fi via iwd backend)"
   12 PKG_TOOLCHAIN="meson"
   13 
   14 PKG_MESON_OPTS_TARGET="
   15   -Dsystemdsystemunitdir=no
   16   -Dudev_dir=no
   17   -Ddbus_conf_dir=/etc/dbus-1/system.d
   18 
   19   -Dsession_tracking=no
   20   -Dsession_tracking_consolekit=false
   21   -Dsuspend_resume=auto
   22   -Dpolkit=false
   23   -Dselinux=false
   24   -Dsystemd_journal=false
   25   -Dlibaudit=no
   26   -Dlibpsl=false
   27   -Dwifi=true
   28   -Dwext=false
   29   -Diwd=true
   30   -Dconfig_wifi_backend_default=iwd
   31   -Dppp=false
   32   -Dmodem_manager=false
   33   -Dofono=false
   34   -Dconcheck=false
   35   -Dteamdctl=false
   36   -Dovs=false
   37   -Dnmcli=true
   38   -Dnmtui=false
   39   -Dnm_cloud_setup=false
   40   -Dbluez5_dun=false
   41   -Debpf=false
   42   -Difcfg_rh=false
   43   -Difupdown=false
   44   -Ddhclient=no
   45   -Ddhcpcd=no
   46   -Dconfig_dhcp_default=internal
   47   -Dintrospection=false
   48   -Dvapi=false
   49   -Ddocs=false
   50   -Dtests=no
   51   -Dfirewalld_zone=false
   52   -Dmore_logging=false
   53   -Dvalgrind=no
   54   -Dqt=false
   55   -Dreadline=auto
   56   -Dconfig_plugins_default=keyfile
   57   -Dcrypto=nss
   58 "
   59 
   60 post_makeinstall_target() {
   61   rm -rf ${INSTALL}/home
   62   rm -rf ${INSTALL}/mnt
   63   rm -rf ${INSTALL}/usr/include
   64   rm -rf ${INSTALL}/usr/lib/pkgconfig
   65   find ${INSTALL}/usr/lib -name "*.a" -delete
   66   find ${INSTALL}/usr/lib -name "*.la" -delete
   67   rm -rf ${INSTALL}/usr/share/locale
   68 
   69   mkdir -p ${INSTALL}/etc/NetworkManager/conf.d
   70   cp -P ${PKG_DIR}/config/NetworkManager.conf ${INSTALL}/etc/NetworkManager/NetworkManager.conf
   71 
   72   mkdir -p ${INSTALL}/etc/dbus-1/system.d
   73   cp -P ${PKG_DIR}/dbus.d/org.freedesktop.NetworkManager.conf ${INSTALL}/etc/dbus-1/system.d/
   74 
   75   mkdir -p ${INSTALL}/usr/lib/tmpfiles.d
   76   cp -P ${PKG_DIR}/tmpfiles.d/z_02_networkmanager.conf ${INSTALL}/usr/lib/tmpfiles.d/
   77 }
   78 
   79 post_install() {
   80   enable_service NetworkManager.service
   81   enable_service network-online.service
   82 }
```

## Pinned NetworkManager1.51.4 nm-device-iwd.c

```text
 1195 dbus_request_scan_cb(NMDevice              *device,
 1196                      GDBusMethodInvocation *context,
 1197                      NMAuthSubject         *subject,
 1198                      GError                *error,
 1199                      gpointer               user_data)
 1200 {
 1201     NMDeviceIwd               *self = NM_DEVICE_IWD(device);
 1202     NMDeviceIwdPrivate        *priv;
 1203     gs_unref_variant GVariant *scan_options = user_data;
 1204 
 1205     if (error) {
 1206         g_dbus_method_invocation_return_gerror(context, error);
 1207         return;
 1208     }
 1209 
 1210     if (check_scanning_prohibited(self, FALSE)) {
 1211         g_dbus_method_invocation_return_error_literal(context,
 1212                                                       NM_DEVICE_ERROR,
 1213                                                       NM_DEVICE_ERROR_NOT_ALLOWED,
 1214                                                       "Scanning not allowed at this time");
 1215         return;
 1216     }
 1217 
 1218     priv = NM_DEVICE_IWD_GET_PRIVATE(self);
 1219 
 1220     if (!priv->can_scan) {
 1221         g_dbus_method_invocation_return_error_literal(context,
 1222                                                       NM_DEVICE_ERROR,
 1223                                                       NM_DEVICE_ERROR_NOT_ALLOWED,
 1224                                                       "Scanning not allowed while unavailable");
 1225         return;
 1226     }
 1227 
 1228     if (scan_options) {
 1229         gs_unref_variant GVariant *val = g_variant_lookup_value(scan_options, "ssids", NULL);
 1230 
 1231         if (val) {
 1232             g_dbus_method_invocation_return_error_literal(context,
 1233                                                           NM_DEVICE_ERROR,
 1234                                                           NM_DEVICE_ERROR_NOT_ALLOWED,
 1235                                                           "'ssid' scan option not supported");
 1236             return;
 1237         }
 1238     }
 1239 
 1240     if (!priv->scanning && !priv->scan_requested) {
 1241         g_dbus_proxy_call(priv->dbus_station_proxy,
 1242                           "Scan",
 1243                           NULL,
 1244                           G_DBUS_CALL_FLAGS_NONE,
 1245                           -1,
 1246                           priv->cancellable,
 1247                           scan_cb,
 1248                           self);
 1249         priv->scan_requested = TRUE;
 1250     }
 1251 
 1252     g_dbus_method_invocation_return_value(context, NULL);
 1253 }
 1280 check_scanning_prohibited(NMDeviceIwd *self, gboolean periodic)
 1281 {
 1282     NMDeviceIwdPrivate *priv = NM_DEVICE_IWD_GET_PRIVATE(self);
 1283 
 1284     g_return_val_if_fail(priv->dbus_obj != NULL, TRUE);
 1285 
 1286     switch (nm_device_get_state(NM_DEVICE(self))) {
 1287     case NM_DEVICE_STATE_UNKNOWN:
 1288     case NM_DEVICE_STATE_UNMANAGED:
 1289     case NM_DEVICE_STATE_UNAVAILABLE:
 1290     case NM_DEVICE_STATE_PREPARE:
 1291     case NM_DEVICE_STATE_CONFIG:
 1292     case NM_DEVICE_STATE_IP_CONFIG:
 1293     case NM_DEVICE_STATE_IP_CHECK:
 1294     case NM_DEVICE_STATE_SECONDARIES:
 1295     case NM_DEVICE_STATE_DEACTIVATING:
 1296         /* Prohibit scans when unusable or activating */
 1297         return TRUE;
 1298     case NM_DEVICE_STATE_DISCONNECTED:
 1299     case NM_DEVICE_STATE_FAILED:
 1300     case NM_DEVICE_STATE_ACTIVATED:
 1301     case NM_DEVICE_STATE_NEED_AUTH:
 1302         break;
 1303     }
 1304 
 1305     /* Prohibit scans if IWD is busy */
 1306     return !priv->can_scan;
 2775         ap               = find_ap_by_supplicant_path(self, network_path);
 2776 
 2777         if (!ap) {
 2778             _LOGW(LOGD_DEVICE | LOGD_WIFI,
 2779                   "ConnectedNetwork points to an unknown Network %s",
 2780                   network_path_str);
 2781             return;
 2782         }
 2783     }
 2784 
 2785     /* Don't allow scanning while connecting, disconnecting or roaming */
 2786     set_can_scan(self, NM_IN_STRSET(new_state, "connected", "disconnected"));
 2787 
 2788     priv->nm_autoconnect = FALSE;
 2789 
 2790     if (nm_connection && iwd_connection && priv->current_ap && ap != priv->current_ap) {
 2791         gboolean switch_ap = priv->iwd_autoconnect && priv->assumed_ac;
 2792 
 2793         _LOGW(LOGD_DEVICE | LOGD_WIFI,
 2794               "IWD is connecting to the wrong AP, %s activation",
 2795               switch_ap ? "replacing" : "aborting");
```

## ES c8dc72cf9ec0:es-core/src/Settings.cpp

```text
  310 
  311 	mBoolMap["VideoAudio"] = true;
  312 	mBoolMap["ScreenSaverVideoMute"] = false;
  313 	mBoolMap["VideoLowersMusic"] = true;
  314 	mBoolMap["VolumePopup"] = Settings::_VolumePopup;
  315 	mBoolMap["RightStickVolume"] = true;
  316 
  317 	mIntMap["MusicVolume"] = 128;
  318 
  319 	// Audio out device for Video playback using OMX player.
  320 	mStringMap["OMXAudioDev"] = "both";
  321 	mStringMap["CollectionSystemsAuto"] = "favorites, recent"; // 2players,4players,favorites,recent
  322 	mStringMap["CollectionSystemsCustom"] = "";
  323 	mBoolMap["SortAllSystems"] = true; 
  324 	mStringMap["SortSystems"] = "manufacturer";
  325 	
  435 	mStringMap["LogLevel"] = "warning";
  436 
  437 	mFloatMap["GunMoveTolerence"] = 2.5;
  438 
  439 	mBoolMap["DisableTouchscreen"] = false;
  440 
  441 	mDefaultBoolMap = mBoolMap;
  442 	mDefaultIntMap = mIntMap;
  443 	mDefaultFloatMap = mFloatMap;
  444 	mDefaultStringMap = mStringMap;
  445 }
  446 
  447 template <typename K, typename V>
  448 void saveMap(pugi::xml_node &node, std::map<K, V>& map, const char* type, std::map<K, V>& defaultMap, V defaultValue)
  449 {
  469 bool Settings::saveFile()
  470 {
  471 	if (!mWasChanged)
  472 		return false;
  473 
  474 	mWasChanged = false;
  475 
  476 	LOG(LogDebug) << "Settings::saveFile() : Saving Settings to file.";
  477 
  478 	const std::string path = Paths::getUserEmulationStationPath() + "/es_settings.cfg";
  479 
  480 	pugi::xml_document doc;
  481 
  482 	pugi::xml_node config = doc.append_child("config"); // root element
  483 
  484 	saveMap<std::string, bool>(config, mBoolMap, "bool", mDefaultBoolMap, false);
  485 	saveMap<std::string, int>(config, mIntMap, "int", mDefaultIntMap, 0);
  486 	saveMap<std::string, float>(config, mFloatMap, "float", mDefaultFloatMap, 0);
  487 
  488 	//saveMap<std::string, std::string>(config, mStringMap, "string");
  489 	for(auto iter = mStringMap.cbegin(); iter != mStringMap.cend(); iter++)
  490 	{
  491 		// key is on the "don't save" list, so don't save it
  492 		if (std::find(settings_dont_save.cbegin(), settings_dont_save.cend(), iter->first) != settings_dont_save.cend())
  493 			continue;
  494 
  495 		// Value is not known, and empty, don't save it
  496 		auto def = mDefaultStringMap.find(iter->first);
  497 		if (def == mDefaultStringMap.cend() && iter->second.empty())
  498 			continue;
  499 
  500 		// Value is know and has default value, don't save it
  501 		if (def != mDefaultStringMap.cend() && def->second == iter->second)
  502 			continue;
  503 
  504 		pugi::xml_node node = config.append_child("string");
  505 		node.append_attribute("name").set_value(iter->first.c_str());
  506 		node.append_attribute("value").set_value(iter->second.c_str());
  507 	}
  508 
  509 	// Serialised once, then written through a temporary and a rename
  510 	// (D-CLOUD-079): save_file opened the live path for writing, which
```

## ES 3178b832b8d1:es-core/src/Settings.cpp

```text
  310 
  311 	mBoolMap["VideoAudio"] = true;
  312 	mBoolMap["ScreenSaverVideoMute"] = false;
  313 	mBoolMap["VideoLowersMusic"] = true;
  314 	mBoolMap["VolumePopup"] = Settings::_VolumePopup;
  315 	mBoolMap["RightStickVolume"] = true;
  316 
  317 	mIntMap["MusicVolume"] = 128;
  318 
  319 	// Audio out device for Video playback using OMX player.
  320 	mStringMap["OMXAudioDev"] = "both";
  321 	mStringMap["CollectionSystemsAuto"] = "favorites,recent"; // 2players,4players,favorites,recent
  322 	mStringMap["CollectionSystemsCustom"] = "";
  323 	mBoolMap["SortAllSystems"] = true; 
  324 	mStringMap["SortSystems"] = "manufacturer";
  325 	
  435 	mStringMap["LogLevel"] = "warning";
  436 
  437 	mFloatMap["GunMoveTolerence"] = 2.5;
  438 
  439 	mBoolMap["DisableTouchscreen"] = false;
  440 
  441 	mDefaultBoolMap = mBoolMap;
  442 	mDefaultIntMap = mIntMap;
  443 	mDefaultFloatMap = mFloatMap;
  444 	mDefaultStringMap = mStringMap;
  445 }
  446 
  447 template <typename K, typename V>
  448 void saveMap(pugi::xml_node &node, std::map<K, V>& map, const char* type, std::map<K, V>& defaultMap, V defaultValue)
  449 {
  469 bool Settings::saveFile()
  470 {
  471 	if (!mWasChanged)
  472 		return false;
  473 
  474 	mWasChanged = false;
  475 
  476 	LOG(LogDebug) << "Settings::saveFile() : Saving Settings to file.";
  477 
  478 	const std::string path = Paths::getUserEmulationStationPath() + "/es_settings.cfg";
  479 
  480 	pugi::xml_document doc;
  481 
  482 	pugi::xml_node config = doc.append_child("config"); // root element
  483 
  484 	saveMap<std::string, bool>(config, mBoolMap, "bool", mDefaultBoolMap, false);
  485 	saveMap<std::string, int>(config, mIntMap, "int", mDefaultIntMap, 0);
  486 	saveMap<std::string, float>(config, mFloatMap, "float", mDefaultFloatMap, 0);
  487 
  488 	//saveMap<std::string, std::string>(config, mStringMap, "string");
  489 	for(auto iter = mStringMap.cbegin(); iter != mStringMap.cend(); iter++)
  490 	{
  491 		// key is on the "don't save" list, so don't save it
  492 		if (std::find(settings_dont_save.cbegin(), settings_dont_save.cend(), iter->first) != settings_dont_save.cend())
  493 			continue;
  494 
  495 		// Value is not known, and empty, don't save it
  496 		auto def = mDefaultStringMap.find(iter->first);
  497 		if (def == mDefaultStringMap.cend() && iter->second.empty())
  498 			continue;
  499 
  500 		// Value is know and has default value, don't save it
  501 		if (def != mDefaultStringMap.cend() && def->second == iter->second)
  502 			continue;
  503 
  504 		pugi::xml_node node = config.append_child("string");
  505 		node.append_attribute("name").set_value(iter->first.c_str());
  506 		node.append_attribute("value").set_value(iter->second.c_str());
  507 	}
  508 
  509 	// Serialised once, then written through a temporary and a rename
  510 	// (D-CLOUD-079): save_file opened the live path for writing, which
```

## ES 3178b832b8d1:es-app/src/guis/GuiSettings.cpp

```text
   68 GuiSettings::~GuiSettings()
   69 {
   70 	
   71 }
   72 
   73 void GuiSettings::close()
   74 {
   75 	save();
   76 
   77 	if (mOnFinalizeFunc != nullptr)
   78 		mOnFinalizeFunc();
   79 
   80 	delete this;
   81 }
   82 
```

## ES 3178b832b8d1:es-app/src/guis/GuiMenu.cpp

```text
 6460 // The sign-in pages that own a waiting `cloud_oauth serve` (#308 8a gpt
 6461 // F-ES-17). A page handed on to the next one by cloudSetupPresent leaves
 6462 // the session to it; a page that closes any other way -- EXIT, back -- is
 6463 // the player leaving the sign-in, and the session is cancelled then rather
 6464 // than left listening until its own 900-second timeout. The interface
 6465 // thread only, like the pages.
 6466 static std::set<GuiSettings*> sOAuthSessionPages;
 6467 
 6468 static void cloudOAuthOwnSession(GuiSettings* s)
 6469 {
 6470 	sOAuthSessionPages.insert(s);
 6471 	s->onFinalize([s]
 6472 	{
 6473 		if (sOAuthSessionPages.erase(s) == 0)
 6474 			return;   // handed on: the next page owns the session
 6475 		LOG(LogInfo) << "cloud_oauth: the sign-in was left; cancelling its session";
 6476 		Utils::Platform::runSystemCommand("/usr/bin/cloud_oauth cancel", "", nullptr);
 6477 	});
 6478 }
 6479 
 6480 // Show a freshly built wizard page: give it the standard large-menu
 6481 // height (the cap MenuComponent::updateSize applies) so the window does
 6482 // not jump between steps, push it, then close the page it replaces -
 6483 // closing first would flash the menu underneath.
 6484 static void cloudSetupPresent(Window* window, GuiSettings* s, GuiSettings* prev, bool completeInstructions = false)
 6485 {
 6486 	if (prev != nullptr)
 6487 		sOAuthSessionPages.erase(prev);   // handed on, not left
 6488 	if (!Renderer::ScreenSettings::fullScreenMenus())
 6489 	{
 6490 		float width = Renderer::getScreenWidth() * 0.90f;
 6491 		if (!completeInstructions && width > Renderer::getScreenHeight())
 6492 			width = (float)Renderer::getScreenHeight();
 6493 		// Instruction-only rows cannot scroll into view by cursor movement.
 6494 		// Resize AND position this page; GuiSettings otherwise keeps its
 6495 		// 15% top offset, pushing a taller page's buttons below the panel.
 6496 		s->getMenu().setSize(width, Renderer::getScreenHeight() * (completeInstructions ? 0.90f : 0.75f));
 6497 		if (completeInstructions)
 6498 			s->getMenu().setPosition((Renderer::getScreenWidth() - width) / 2,
 6499 				Renderer::getScreenHeight() * 0.025f);
 6500 	}
 6501 	window->pushGui(s);
 6502 	if (prev != nullptr)
 6503 		prev->close();
 6504 }
 6505 
 6506 // Bottom button row for a wizard page: EXIT SETUP on the left and,
 6507 // once the step's check has passed, CONTINUE on the right - replacing
 6508 // the default BACK button so each page offers exactly those two ways
 6509 // out.
 7664 		// One line (D-UI-023): the sentence this replaced measured 929 of
 7665 		// 780 px at 1280x800 and 701 of 620 at 640x480 (#308 F-ES-14).
 7666 		_("YOUR PHONE BECOMES THE KEYBOARD. SCAN THE CODE, THEN CONTINUE."),
 7667 		nullptr, [window, backend, remoteName, s, ready]
 7668 		{
 7669 			cloudOAuthShowSignIn(window, backend, remoteName, s, true, ready);
 7670 		}, "", false, true);
 7671 
 7672 	cloudSetupSetButtons(s, nullptr);
 7673 	cloudOAuthOwnSession(s);
 7674 	cloudSetupPresent(window, s, prev);
 7675 }
 7676 
 7677 // Both keyboard routes use the same window and can fail before it opens
 7678 // (fork #570). The page beneath this dialog still owns the authorization.
 7680 static void cloudOAuthOpenSignIn(Window* window, CloudBackend backend,
 7681 	std::string remoteName, GuiSettings* page, bool usePhone,
 7682 	std::function<void()> onReturn)
 7683 {
 7684 	if (ApiSystem::getInstance()->launchCloudSignIn(window, usePhone))
 7685 	{
 7686 		if (onReturn)
 7687 			onReturn();
 7688 		return;
 7689 	}
 7690 
 7691 	// A completed authorization wins even if the window failed to return.
 7692 	const auto lines = Utils::Platform::GetShOutputLines("/usr/bin/cloud_oauth status");
 7693 	const std::string status = lines.empty() ? "" : Utils::String::trim(lines.front());
 7694 	if (status == "signed-in")
 7695 	{
 7696 		cloudOAuthShowConnected(window, backend, remoteName, page);
 7697 		return;
 7698 	}
 7699 
 7700 	// The bool also covers a failed wait, so do not claim every failure was
 7701 	// at startup. No OK action returns to a page still claiming to open.
 7702 	window->pushGui(new GuiMsgBox(window,
 7703 		_("THE SIGN-IN WINDOW DID NOT OPEN OR STOPPED WORKING.\n\nTRY AGAIN, OR CANCEL SIGN-IN."),
 7704 		_("TRY AGAIN"), [window, backend, remoteName, page, usePhone, onReturn]
 7705 		{
 7706 			// Recheck on the press: authorization can finish or expire while
 7707 			// the question is open. A waiting attempt keeps its phone pairing.
 7708 			const auto lines = Utils::Platform::GetShOutputLines("/usr/bin/cloud_oauth status");
 7709 			const std::string status = lines.empty() ? "" : Utils::String::trim(lines.front());
 7710 			if (status == "signed-in")
 7711 				cloudOAuthShowConnected(window, backend, remoteName, page);
 7712 			else if (status == "waiting")
 7713 				cloudOAuthOpenSignIn(window, backend, remoteName, page, usePhone, onReturn);
 7714 			else
 7715 				cloudOAuthStart(window, backend, remoteName, page);
 7716 		},
 7717 		_("CANCEL SIGN-IN"), [page] { page->close(); }, GuiMsgBoxIcon::ICON_ERROR));
 7718 }
 7719 
 7720 static void cloudOAuthShowSignIn(Window* window, CloudBackend backend,
 7721 	std::string remoteName, GuiSettings* prev, bool usePhone,
 7722 	const CloudOAuthReady& ready)
 7723 {
 7724 	auto s = new GuiSettings(window, _("CONNECT CLOUD STORAGE"));
 7725 	s->setSubTitle(CloudText::providerSubtitle(backend.name, backend.label));
 7726 
 7727 	// The address carries its own PIN in its path. ADDRESS and PIN are still
 7728 	// reported by `info` for anything driving this from a shell, but the page
 7729 	// has nothing to do with them separately -- two numbers on one screen is
 7730 	// what made "code" ambiguous the first time.
 7731 	const std::string url = ready.url;
 7732 	const bool onDevice = ready.onDevice;
 7733 	const std::string exitHint = ready.exitHint;
 7734 
 7735 	if (!ready.started)
 7736 	{
 7737 		cloudSetupAddProse(s, window, _("SIGN-IN DID NOT START"),
 7738 			_("THE DEVICE COULD NOT REACH THE PROVIDER. CHECK THE NETWORK AND TRY AGAIN."));
 7739 		// One button, and it goes back. This page used to carry CONTINUE as
 7740 		// well, which offered to continue with a sign-in that had not begun.
 7741 		s->getMenu().clearButtons();
 7742 		s->getMenu().addButton(_("GO BACK"), _("go back"), [s] { s->close(); });
 7743 		cloudOAuthOwnSession(s);
 7744 		cloudSetupPresent(window, s, prev);
 7745 		return;
 7746 	}
 7747 
 7748 	// Typing on the handheld: nothing to read off the screen, nothing to
 7854 			}
 7855 		}
 7856 		// Completion can delete s and its buttons; own the invocation first.
 7857 		auto finish = finishSignIn;
 7858 		finish();
 7859 	});
 7860 
 7861 	cloudOAuthOwnSession(s);
 7862 	cloudSetupPresent(window, s, prev);
 7863 
 7864 	// After the page is on the stack, never while it is being built: this
 7865 	// blocks for as long as somebody is signing in, and ES is suspended for
 7866 	// the duration. The page has to already be there for ES to come back to.
 7867 	// backend and remoteName are owned values: presenting s deleted prev,
 7868 	// which may have held the callback that supplied them.
 7869 	if (openImmediately)
 7870 		cloudOAuthOpenSignIn(window, backend, remoteName, s, false, nullptr);
 7871 }
 7872 
 7873 // What it means to have connected something, said once, at the only moment
 7874 // anybody is going to read it.
 7875 //
```

## ES 3178b832b8d1:es-app/src/guis/GuiWifi.cpp

```text
  374 		onJoined();
  375 }
  376 
  377 bool GuiWifi::input(InputConfig* config, Input input)
  378 {
  379 	if (input.value != 0 && config->isMappedTo(BUTTON_BACK, input))
  380 	{
  381 		if (!mWaitingLoad)
  382 			delete this;
  383 		return true;
  384 	}
  385 
  386 	// A press during a scan cannot join an old row, open a key editor or
  387 	// queue another scan. BACK remains available without joining the worker.
  388 	if (mScan || mWaitingLoad)
  389 		return true;
  390 	return GuiComponent::input(config, input);
  391 }
  392 
  393 bool GuiWifi::hitTest(int x, int y, Transform4x4f& parentTransform, std::vector<GuiComponent*>* result)
  394 {
  395 	if (!mScan)
  396 		return GuiComponent::hitTest(x, y, parentTransform, result);
  397 
  398 	// Mouse/touch bypass input(). During scanning only the native BACK
  399 	// button may capture a press, so a release after completion cannot act
  400 	// on a refreshed row or start the action of a previously pressed button.
  401 	std::vector<GuiComponent*> hits;
  402 	const bool hit = GuiComponent::hitTest(x, y, parentTransform, &hits);
  403 	if (result)
  404 		for (auto component : hits)
  405 			if (auto button = dynamic_cast<ButtonComponent*>(component))
  406 				if (button->getText() == _("BACK"))
  407 					result->push_back(button);
  408 	return hit;
  409 }
  410 
  411 std::vector<HelpPrompt> GuiWifi::getHelpPrompts()
  412 {
  413 	std::vector<HelpPrompt> prompts;
  414 	if (!mScan && !mWaitingLoad)
  415 		prompts = mMenu.getHelpPrompts();
  416 	prompts.push_back(HelpPrompt(BUTTON_BACK, _("BACK")));
  417 	return prompts;
  418 }
  419 
  470 void GuiWifi::onRefresh(bool rescan)
  471 {
  472 	if (mScan || mWaitingLoad)
  473 		return;
  474 
  475 	// UI-thread-only weak registry. Closing a picker leaves at most the one
  476 	// bounded read job; reopening attaches to it instead of starting a rival.
  477 	// A completed answer is never reused for a later explicit refresh.
  478 	static std::weak_ptr<Scan> activeScan;
  479 	mScan = activeScan.lock();
  480 	if (mScan && mScan->ready.load(std::memory_order_acquire))
  481 		mScan.reset();
  482 	const bool reused = mScan != nullptr;
  483 	if (!mScan)
  484 	{
  485 		mScan = std::make_shared<Scan>();
  486 		activeScan = mScan;
  487 		auto scan = mScan;
  488 		try
  489 		{
  490 			std::thread([scan, rescan]
  491 			{
  492 				try
  493 				{
  494 					Answer answer;
  495 					const auto range = WifiScanProcess::read({"wifictl", rescan ? "scanlist" : "list"}, std::chrono::seconds(rescan ? 45 : 30));
  496 					answer.inRangeKnown = range.code == 0;
  497 					answer.inRange = range.lines;
  498 
  499 					// Match ApiSystem's saved/current protocol, but reject signal
  500 					// and read failures too. No singleton or GUI is worker-owned.
  501 					const auto saved = WifiScanProcess::read({"wifictl", "saved", "--ssid"}, std::chrono::seconds(15));
  502 					answer.savedKnown = saved.code == 0;
  503 					if (answer.savedKnown)
  504 						for (const auto& line : saved.lines)
  505 						{
  506 							WifiText::SavedNetwork network;
  507 							if (!WifiText::parseSavedDetailsLine(line, network))
  508 							{
  509 								answer.savedKnown = false;
  510 								break;
  511 							}
  512 							answer.saved.push_back(network);
  513 						}
  514 					if (!answer.savedKnown)
  515 						answer.saved.clear();
  516 
  517 					const auto current = WifiScanProcess::read({"wifictl", "current"}, std::chrono::seconds(10));
  518 					answer.current = WifiText::parseCurrent(current.lines);
  519 					answer.currentKnown = (current.code == 0 && !answer.current.empty()) || current.code == 1;
  520 					if (current.code != 0)
  521 						answer.current.clear();
  522 					scan->answer = std::move(answer);
  523 				}
  524 				catch (...)
  525 				{
  526 					// The default answer is unknown, not a successful empty scan.
  527 					LOG(LogWarning) << "wifi picker: scan worker failed";
  528 				}
  529 				LOG(LogInfo) << "wifi picker: scan worker finished";
  530 				scan->ready.store(true, std::memory_order_release);
  531 			}).detach();
  532 		}
  533 		catch (const std::exception&)
  534 		{
  535 			LOG(LogWarning) << "wifi picker: could not start scan worker";
```

## ES 3178b832b8d1:es-app/src/guis/WifiScanProcess.h

```text
   21 namespace WifiScanProcess
   22 {
   23 struct Answer
   24 {
   25 	int code = -1; // spawn/read/signal/timeout/cleanup failure is never empty success
   26 	std::vector<std::string> lines;
   27 };
   28 
   29 #if !WIN32
   30 class Child
   31 {
   32 public:
   33 	Child(pid_t child, int output) : pid(child), fd(output) {}
   34 	Child(const Child&) = delete;
   35 	Child& operator=(const Child&) = delete;
   36 	~Child() { finish(); }
   37 
   38 	bool finish()
   39 	{
   40 		if (finished)
   41 			return cleaned;
   42 		finished = true;
   43 		close(fd);
   44 		// Even a reaped leader may have descendants holding the pipe. The
   45 		// spawn creates this group; never signal ES's own process group.
   46 		cleaned = kill(-pid, SIGKILL) == 0 || errno == ESRCH;
   47 		if (!cleaned)
   48 			kill(pid, SIGKILL);
   49 		const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
   50 		while (!reaped)
   51 		{
   52 			const pid_t waited = waitpid(pid, &status, WNOHANG);
   53 			if (waited == pid)
   54 				reaped = true;
   55 			else if ((waited < 0 && errno != EINTR) || std::chrono::steady_clock::now() >= deadline)
   56 				return cleaned = false;
   57 			else
   58 				poll(nullptr, 0, 10);
   59 		}
   60 		return cleaned;
   61 	}
   62 
   63 	pid_t pid;
   64 	int fd;
   65 	int status = 0;
   66 	bool reaped = false;
   67 private:
   68 	bool finished = false;
   69 	bool cleaned = false;
   70 };
   71 #endif
   72 
   73 inline Answer read(const std::vector<std::string>& command, std::chrono::milliseconds timeout)
   74 {
   75 	Answer answer;
   76 #if !WIN32
   77 	if (command.empty() || timeout.count() <= 0)
   78 		return answer;
   79 	std::vector<char*> argv;
   80 	for (const auto& part : command)
   81 		argv.push_back(const_cast<char*>(part.c_str()));
   82 	argv.push_back(nullptr);
   83 
   84 	int output[2];
   85 	if (pipe2(output, O_CLOEXEC) != 0)
   86 		return answer;
   87 	// File actions must not close stdout after dup2 when an inherited
   88 	// standard descriptor was absent and pipe2 reused its number.
   89 	for (int& descriptor : output)
   90 		if (descriptor <= STDERR_FILENO)
   91 		{
   92 			const int moved = fcntl(descriptor, F_DUPFD_CLOEXEC, STDERR_FILENO + 1);
   93 			if (moved == -1)
   94 			{
   95 				close(output[0]); close(output[1]);
   96 				return answer;
   97 			}
   98 			close(descriptor);
   99 			descriptor = moved;
  100 		}
  101 	posix_spawn_file_actions_t actions;
  102 	posix_spawnattr_t attributes;
  103 	if (posix_spawn_file_actions_init(&actions) != 0)
  104 	{
  105 		close(output[0]); close(output[1]);
  106 		return answer;
  107 	}
  108 	if (posix_spawnattr_init(&attributes) != 0)
  109 	{
  110 		posix_spawn_file_actions_destroy(&actions);
  111 		close(output[0]); close(output[1]);
  112 		return answer;
  113 	}
  114 	pid_t pid = -1;
  115 	const bool configured =
  116 		posix_spawn_file_actions_adddup2(&actions, output[1], STDOUT_FILENO) == 0 &&
  117 		posix_spawn_file_actions_addclose(&actions, output[0]) == 0 &&
  118 		posix_spawn_file_actions_addclose(&actions, output[1]) == 0 &&
  119 		posix_spawnattr_setflags(&attributes, POSIX_SPAWN_SETPGROUP) == 0 &&
  120 		posix_spawnattr_setpgroup(&attributes, 0) == 0;
  121 	const int spawned = configured ? posix_spawnp(&pid, argv[0], &actions, &attributes, argv.data(), environ) : -1;
  122 	posix_spawnattr_destroy(&attributes);
  123 	posix_spawn_file_actions_destroy(&actions);
  124 	close(output[1]);
  125 	if (spawned != 0)
  126 	{
  127 		close(output[0]);
  128 		return answer;
  129 	}
  130 
  131 	Child child(pid, output[0]);
  132 	const int flags = fcntl(child.fd, F_GETFL);
  133 	if (flags == -1 || fcntl(child.fd, F_SETFL, flags | O_NONBLOCK) == -1)
  134 		return answer;
  135 	const auto deadline = std::chrono::steady_clock::now() + timeout;
  136 	std::string outputText;
  137 	bool eof = false;
  138 	while (true)
  139 	{
  140 		char buffer[4096];
  141 		while (!eof)
  142 		{
  143 			const ssize_t count = ::read(child.fd, buffer, sizeof(buffer));
  144 			if (count > 0)
  145 			{
  146 				// A corrupt/unbounded command must not grow the UI's heap.
  147 				if (outputText.size() + count > 256 * 1024 || std::chrono::steady_clock::now() >= deadline)
  148 					return answer;
  149 				outputText.append(buffer, count);
  150 			}
  151 			else if (count == 0)
  152 				eof = true;
  153 			else if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
  154 				break;
  155 			else
  156 				return answer;
  157 		}
  158 		if (!child.reaped)
  159 		{
  160 			const pid_t waited = waitpid(child.pid, &child.status, WNOHANG);
  161 			if (waited == child.pid)
  162 				child.reaped = true;
  163 			else if (waited < 0 && errno != EINTR)
  164 				return answer;
  165 		}
  166 		if (eof && child.reaped)
  167 			break;
  168 		if (std::chrono::steady_clock::now() >= deadline)
  169 			return answer;
  170 		pollfd descriptor{eof ? -1 : child.fd, POLLIN, 0};
  171 		if (poll(&descriptor, 1, 25) < 0 && errno != EINTR)
  172 			return answer;
  173 	}
  174 	if (!child.finish() || !WIFEXITED(child.status))
  175 		return answer;
  176 	answer.code = WEXITSTATUS(child.status);
  177 	if (answer.code == 0)
  178 	{
  179 		size_t start = 0;
  180 		while (start < outputText.size())
  181 		{
  182 			const size_t end = outputText.find('\n', start);
  183 			const std::string line = outputText.substr(start, end == std::string::npos ? end : end - start);
  184 			if (!line.empty())
  185 				answer.lines.push_back(line);
  186 			if (end == std::string::npos)
  187 				break;
  188 			start = end + 1;
  189 		}
  190 	}
  191 #endif
  192 	return answer;
  193 }
```

## ES 3178b832b8d1:es-app/src/main.cpp

```text
  346 void onExit()
  347 {
  348 	// A deletion still on the worker is finished, then the log closes
  349 	// (D-UI-073, third rule). Idempotent: main's tail has usually done it.
  350 	SaveStateBookkeeper::shutdown();
  351 	Log::close();
  352 }
 1317 	// The loop has ended: a worker that finishes from here on posts to
 1318 	// nothing (AppWindow; #308 8-es claude F-ES-26). Before any teardown, so
 1319 	// no post lands in a window on its way out.
 1320 	AppWindow::closing();
 1321 
 1322 	if (Utils::Platform::isFastShutdown())
 1323 		Settings::getInstance()->setBool("IgnoreGamelist", true);
 1324 
 1325 	WatchersManager::stop();
 1326 	ThreadedHasher::stop();
 1327 	ThreadedScraper::stop();
 1328 	SaveStateBookkeeper::shutdown();
 1329 
 1330 	ApiSystem::getInstance()->deinit();
 1331 
 1332 	while (window.peekGui() != ViewController::get())
 1333 		delete window.peekGui();
 1334 
 1335 	if (SystemData::hasDirtySystems())
 1336 		window.renderSplashScreen(_("SAVING METADATA. PLEASE WAIT..."));
 1337 
 1338 	MameNames::deinit();
 1339 	ViewController::saveState();
 1340 	CollectionSystemManager::deinit();
 1341 	SystemData::deleteSystems();
 1342 	Scripting::exitScriptingEngine();
 1343 
 1344 	// call this ONLY when linking with FreeImage as a static library
 1345 #ifdef FREEIMAGE_LIB
 1346 	FreeImage_DeInitialise();
 1347 #endif
 1348 	
 1349 	// Delete ViewController
 1350 	while (window.peekGui() != nullptr)
 1351 		delete window.peekGui();
 1352 
 1353 	window.deinit();
 1354 
 1355 	Utils::Platform::processQuitMode();
 1356 
 1357 	LOG(LogInfo) << "EmulationStation cleanly shutting down.";
 1358 
 1359 	Log::flush();
 1360 
 1361 	return 0;
 1362 }
 1363 
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/ui/emulationstation/system.d/emustation.service

```text
    1 [Unit]
    2 Description=EmulationStation emulator frontend
    3 ConditionPathExists=/var/lock/start.games
    4 After=rocknix-automount.service
    5 
    6 [Service]
    7 Environment=XDG_RUNTIME_DIR=/var/run/0-runtime-dir
    8 Environment=HOME=/storage
    9 Environment=SDL_AUDIODRIVER=pulseaudio
   10 EnvironmentFile=/etc/profile
   11 ExecStartPre=/usr/bin/es_settings
   12 ExecStart=/usr/bin/emulationstation --log-path /var/log --no-splash
   13 KillMode=process
   14 TimeoutStopSec=3
   15 Restart=always
   16 RestartSec=2
   17 StartLimitInterval=0
   18 
   19 [Install]
   20 WantedBy=rocknix.target
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/ui/emulationstation/system.d/essway.service

```text
    1 [Unit]
    2 Description=EmulationStation-with-Sway
    3 # This path never exist on rk3566
    4 #ConditionPathExists=/var/lock/start.games
    5 Requires=sway.service
    6 After=sway.service
    7 
    8 [Service]
    9 Type=simple
   10 Environment=HOME=/storage
   11 EnvironmentFile=/etc/profile
   12 # Wait for usable Wayland; keep failure/retry owned by this frontend unit.
   13 ExecStartPre=/usr/bin/sway-ready
   14 TimeoutStartSec=20
   15 ExecStart=/usr/bin/start_es.sh
   16 WorkingDirectory=/storage
   17 Restart=always
   18 RestartSec=2
   19 
   20 [Install]
   21 WantedBy=rocknix.target
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/ui/emulationstation/sources/start_es.sh

```text
    1 #!/bin/bash
    2 # SPDX-License-Identifier: GPL-2.0-or-later
    3 # Copyright (C) 2024 ROCKNIX (https://github.com/ROCKNIX)
    4 
    5 ### setup is the same
    6 . $(dirname $0)/es_settings
    7 
    8 emulationstation --log-path /var/log --no-splash
```

## ES 3178b832b8d1:locale/CMakeLists.txt

```text
    1 add_custom_target (i18n ALL COMMENT "Building i18n messages.")
    2 file (GLOB es_PO_FILES ${dir}/locale/lang/*)
    3 set(es_POT ${dir}/locale/emulationstation2.pot)
    4 # update the pot
    5 MESSAGE("Building the pot file")
    6 add_custom_command (
    7     TARGET i18n
    8     POST_BUILD
    9     COMMAND find "${dir}/es-app" "${dir}/es-core" -name "*.cpp" -o -name "*.h" | ${XGETTEXT_EXECUTABLE} --add-comments=TRANSLATION -f - -o ${es_POT} --no-location --keyword=_
   10 )
   11 add_custom_command (
   12     TARGET i18n
   13     POST_BUILD
   14     COMMAND sed -i '/^\"POT-Creation-Date:/d' ${es_POT}
   15 )
   16 
   17 foreach (es_PO_INPUT ${es_PO_FILES})
   18         get_filename_component (es_PO_LANG ${es_PO_INPUT} NAME_WE)
   19         MESSAGE("LANG = ${es_PO_LANG}")
   20         set (es_MO_OUTPUT ${es_PO_INPUT}/LC_MESSAGES/emulationstation2.mo)
   21         # update the po from the pot
   22         add_custom_command (
   23             TARGET i18n
   24             POST_BUILD
   25             COMMAND ${MSGMERGE_EXECUTABLE} -U --no-fuzzy-matching ${es_PO_INPUT}/LC_MESSAGES/emulationstation2.po ${es_POT}
   26         )
   27         # compile the po to mo
   28         add_custom_command (
   29             TARGET i18n
   30             POST_BUILD
   31             COMMAND basename ${es_PO_INPUT} && ${MSGFMT_EXECUTABLE} -o ${es_MO_OUTPUT} ${es_PO_INPUT}/LC_MESSAGES/emulationstation2.po
   32         )
   33         install (FILES ${es_MO_OUTPUT} DESTINATION share/locale/${es_PO_LANG}/LC_MESSAGES RENAME emulationstation2.mo)
   34 endforeach (es_PO_INPUT ${es_PO_FILES})
   35 
   36 add_custom_command (
   37     TARGET i18n
   38     POST_BUILD
   39     COMMAND echo
   40 )
   41 foreach (es_PO_INPUT ${es_PO_FILES})
   42   add_custom_command (
   43       TARGET i18n
   44       POST_BUILD
   45       COMMAND printf "%-5s " `basename ${es_PO_INPUT}` && LANG=C ${MSGFMT_EXECUTABLE} -o /dev/null ${es_PO_INPUT}/LC_MESSAGES/emulationstation2.po --statistics
   46   )
   47 endforeach (es_PO_INPUT ${es_PO_FILES})
   48 add_custom_command (
   49     TARGET i18n
   50     POST_BUILD
   51     COMMAND echo
   52 )
```

## ES 3178b832b8d1:CMakeLists.txt

```text
  562     endif()
  563 endif()
  564 
  565 if(NOT WIN32)
  566 	# batocera / i18n
  567 	# i18n
  568 	find_program (MSGFMT_EXECUTABLE msgfmt)
  569 	find_program (MSGMERGE_EXECUTABLE msgmerge)
  570 	find_program (XGETTEXT_EXECUTABLE xgettext)
  571 	find_package(Intl)
  572 
  573 	if(MSGFMT_EXECUTABLE AND MSGMERGE_EXECUTABLE AND XGETTEXT_EXECUTABLE AND Intl_FOUND)
  574 	  message (STATUS "Native language support enabled.")
  575 	  add_definitions(-DHAVE_INTL)
  576 	else()
  577 	  message (STATUS "Native language support disabled.")
  578 	endif()
```

## Pinned Dolphin6094cfcf docs/WiaAndRvz.md

```text
  115 |`u64 raw_data_off`|The offset on the disc at which this data starts.|
  116 |`u64 raw_data_size`|The number of bytes on the disc covered by this struct.|
  117 |`u32 group_index`|The index of the first `wia_group_t` struct that points to the data covered by this struct. The other `wia_group_t` indices follow sequentially.|
  118 |`u32 n_groups`|The number of `wia_group_t` structs used for this data.|
  119 
  120 ## `wia_group_t`
  121 
  122 This struct points directly to the actual disc data, stored compressed. The data is interpreted differently depending on whether the `wia_group_t` is referenced by a `wia_part_data_t` or a `wia_raw_data_t` (see the `wia_part_t` section for details).
  123 
  124 A `wia_group_t` normally contains `chunk_size` bytes of decompressed data (or `chunk_size / 0x8000 * 0x7C00` for Wii partition data when not counting hashes), not counting any `wia_except_list_t` structs. However, the last `wia_group_t` of a `wia_part_data_t` or `wia_raw_data_t` contains less data than that if `n_sectors * 0x8000` (for `wia_part_data_t`) or  `raw_data_size` (for `wia_raw_data_t`)  is not evenly divisible by `chunk_size`.
  125 
  126 |Type and name|Description|
  127 |--|--|
  128 |`u32 data_off4`|The offset in the file where the compressed data is stored, divided by 4.|
  129 |`u32 data_size`|The size of the compressed data, including any `wia_except_list_t` structs, and including any padding that is required after the `wia_except_list_t` structs when using the compression method NONE or PURGE. 0 is a special case meaning that every byte of the decompressed data is `0x00` and the `wia_except_list_t` structs (if there are supposed to be any) contain 0 exceptions.|
  130 
  131 ## `wia_exception_t`
  132 
  133 This struct represents a 20-byte difference between the recalculated hash data and the original hash data. (See also `wia_except_list_t` below.)
  134 
  135 When recalculating hashes for a `wia_group_t` with a size which is not evenly divisible by 2 MiB (with the size of the hashes included), the missing bytes should be treated as zeroes for the purpose of hashing. (wit's writing code seems to act as if the reading code does not assume that these missing bytes are zero, but both wit's and Dolphin's reading code treat them as zero. Dolphin's writing code assumes that the reading code treats them as zero.)
  136 
  137 wit's writing code only outputs `wia_exception_t` structs for mismatches in the actual hash data, not in the padding data (which normally only contains zeroes). Dolphin's writing code outputs `wia_exception_t` structs for both hash data and padding data. When Dolphin needs to write `wia_exception_t` structs for a padding area which is 32 bytes long, it writes one which covers the first 20 bytes of the padding area and one which covers the last 20 bytes of the padding area, generating 12 bytes of overlap between the `wia_exception_t` structs.
  138 
  139 |Type and name|Description|
  140 |--|--|
  141 |`u16 offset`|The offset among the hashes. The offsets `0x0000`-`0x0400` here map to the offsets `0x0000`-`0x0400` in the full 2 MiB of data, the offsets `0x0400`-`0x0800` here map to the offsets `0x8000`-`0x8400` in the full 2 MiB of data, and so on. The offsets start over at 0 for each new `wia_except_list_t`.|
  142 |`sha1_hash_t hash`|The hash that the automatically generated hash at the given offset needs to be replaced with. The replacement should happen after calculating all hashes for the current 2 MiB of data but before encrypting the hashes.|
  143 
  144 ## `wia_except_list_t`
  145 
  180     * For Wii partition data, each chunk contains one `wia_except_list_t` which contains exceptions for that chunk (and no other chunks). Offset 0 refers to the first hash of the current chunk, not the first hash of the full 2 MiB of data.
  181 * The `wia_group_t` struct has been expanded. See the `rvz_group_t` section below.
  182 * Pseudorandom padding data is stored losslessly using an encoding scheme described in the *RVZ packing* section below.
  183 
  184 ## `rvz_group_t`
  185 
  186 Compared to `wia_group_t`, `rvz_group_t` changes the meaning of the most significant bit of `data_size` and adds one additional attribute.
  187 
  188 "Compressed data" below means the data as it is stored in the file. When the compression method is NONE, this "compressed data" is actually not compressed.
  189 
  190 |Type and name|Description|
  191 |--|--|
  192 |`u32 data_off4`|The offset in the file where the compressed data is stored, divided by 4.|
  193 |`u32 data_size`|The most significant bit is 1 if the data is stored using the compression method indicated in `wia_disc_t`, and 0 if it is stored using the compression method NONE. The lower 31 bits are the size of the compressed data, including any `wia_except_list_t` structs, and including any padding that is required after the `wia_except_list_t` structs when using the compression method NONE. The lower 31 bits being 0 is a special case meaning that every byte of the decompressed and unpacked data is `0x00` and the `wia_except_list_t` structs (if there are supposed to be any) contain 0 exceptions.|
  194 |`u32 rvz_packed_size`|The size after decompressing but before decoding the RVZ packing. If this is 0, RVZ packing is not used for this group.|
  195 
  196 ## RVZ packing
  197 
  198 The RVZ packing encoding scheme can be applied to `wia_group_t` data, with any bzip2/LZMA/Zstandard compression being applied on top of it. (In other words, when reading an RVZ file, bzip2/LZMA/Zstandard decompression is done before decoding the RVZ packing.) RVZ packed data can be decoded as follows:
  199 
  200 1. Read 4 bytes of data and interpret it as a 32-bit unsigned big endian integer. Call this `size`.
  201 2. If the most significant bit of `size` is not set, read `size` bytes and output them unchanged. If the most significant bit of `size` is set, unset the most significant bit of `size`, then read 68 bytes of PRNG seed data and output `size` bytes using the PRNG algorithm described below.
  202 3. Repeat until all input has been read.
  203 
  204 ### PRNG algorithm
  205 
```

## Pinned Dolphin6094cfcf Source/Core/DiscIO/WIABlob.cpp

```text
 1170   size_t position = 0;
 1171   while (position < total_size)
 1172   {
 1173     // Skip the 0 to 32 zero bytes that typically come after a file
 1174     size_t zeroes = 0;
 1175     while (position + zeroes < total_size && in[position + zeroes] == 0)
 1176       ++zeroes;
 1177 
 1178     // If there are very many zero bytes (perhaps the PRNG junk data has been scrubbed?)
 1179     // and we aren't using compression, it makes sense to encode the zero bytes as junk.
 1180     // If we are using compression, the compressor will likely encode zeroes better than we can
 1181     if (!compression && zeroes > SEED_SIZE)
 1182       junk_info.emplace(position + zeroes, JunkInfo{position, {}});
 1183 
 1184     position += zeroes;
 1185     data_offset += zeroes;
 1186 
 1187     const size_t bytes_to_read =
 1188         std::min(Common::AlignUp(data_offset + 1, VolumeWii::BLOCK_TOTAL_SIZE) - data_offset,
 1189                  total_size - position);
 1530         OutputParametersEntry& entry = output_entries[chunks_per_wii_group == 1 ? 0 : i];
 1531         if (entry.reused_group)
 1532           continue;
 1533 
 1534         const std::vector<HashExceptionEntry>& in = exception_lists[i];
 1535         std::vector<u8>& out = entry.exception_lists;
 1536 
 1537         const u16 exceptions = Common::swap16(static_cast<u16>(in.size()));
 1538         PushBack(&out, exceptions);
 1539         for (const HashExceptionEntry& exception : in)
 1540           PushBack(&out, exception);
 1541       }
 1542 
 1543       for (u64 i = 0; i < output_entries.size(); ++i)
 1544       {
 1545         OutputParametersEntry& entry = output_entries[i];
 1546 
 1547         // If this chunk was set as reusable because the decrypted data is AllSame,
 1548         // but it has exceptions, unmark it as reusable
 1549         if (entry.reuse_id && !entry.reuse_id->encrypted && !AllZero(entry.exception_lists))
 1550           entry.reuse_id.reset();
 1551       }
 1552     }
 1553   }
 1554 
 1555   for (OutputParametersEntry& entry : output_entries)
 1556   {
 1557     TryReuse(reusable_groups, reusable_groups_mutex, &entry);
 1558     if (entry.reused_group)
 1559       continue;
 1560 
 1561     // Special case - a compressed size of zero is treated by WIA as meaning the data is all zeroes
 1562     if (entry.reuse_id && !entry.reuse_id->encrypted && entry.reuse_id->value == 0)
 1563     {
 1564       entry.exception_lists.clear();
 1565       entry.main_data.clear();
 1566       if constexpr (RVZ)
 1567       {
 1568         entry.rvz_packed_size = 0;
 1569         entry.compressed = false;
 1570       }
 1571       continue;
 1572     }
 1573 
 1574     const auto pad_exception_lists = [&entry] {
 1575       while (entry.exception_lists.size() % 4 != 0)
 1576         entry.exception_lists.push_back(0);
 1577     };
 1578 
 1579     if (state->compressor)
 1580     {
 1581       if (!state->compressor->Start(entry.exception_lists.size() + entry.main_data.size()))
 1582         return std::unexpected{ConversionResultCode::InternalError};
 1583     }
 1584 
 1585     if (!entry.exception_lists.empty())
 1586     {
 1587       if (compressed_exception_lists && state->compressor)
 1588       {
 1589         if (!state->compressor->Compress(entry.exception_lists.data(),
 1590                                          entry.exception_lists.size()))
 1591         {
 1592           return std::unexpected{ConversionResultCode::InternalError};
 1593         }
 1594       }
 1595       else
 1596       {
 1597         if (!compressed_exception_lists)
 1598           pad_exception_lists();
 1599 
 1600         if (state->compressor)
 1601         {
 1602           if (!state->compressor->AddPrecedingDataOnlyForPurgeHashing(entry.exception_lists.data(),
 1603                                                                       entry.exception_lists.size()))
 1604           {
 1605             return std::unexpected{ConversionResultCode::InternalError};
 1606           }
 1607         }
 1608       }
 1609     }
 1610 
 1611     if (state->compressor)
 1612     {
 1613       if (!state->compressor->Compress(entry.main_data.data(), entry.main_data.size()))
 1614         return std::unexpected{ConversionResultCode::InternalError};
 1615       if (!state->compressor->End())
 1616         return std::unexpected{ConversionResultCode::InternalError};
 1617     }
 1618 
 1619     bool compressed = !!state->compressor;
 1620     if constexpr (RVZ)
 1621     {
 1622       size_t uncompressed_size = entry.main_data.size();
 1623       if (compressed_exception_lists)
 1624         uncompressed_size += Common::AlignUp(entry.exception_lists.size(), 4);
 1625 
 1626       compressed = state->compressor && state->compressor->GetSize() < uncompressed_size;
 1627       entry.compressed = compressed;
 1628 
```

## ES 3178b832b8d1:external/libcheevos/rvz_hash.cpp

```text
  245     {
  246         if (failed || requested > discSize - position || requested > 128 * 1024 * 1024 - totalRead)
  247         {
  248             failed = true;
  249             return 0;
  250         }
  251         totalRead += requested;
  252         auto* out = static_cast<uint8_t*>(destination);
  253         size_t done = 0;
  254         while (done < requested)
  255         {
  256             if (position < head.size())
  257             {
  258                 const size_t take = std::min(requested - done, head.size() - size_t(position));
  259                 std::memcpy(out + done, head.data() + position, take);
  260                 position += take;
  261                 done += take;
  262                 continue;
  263             }
  264             const auto found = std::upper_bound(raw.begin(), raw.end(), position,
  265                 [](uint64_t value, const Raw& entry) { return value < entry.offset; });
  266             require(found != raw.begin());
  267             const Raw& entry = *(found - 1);
  268             require(position < entry.end);
  269             const uint64_t groupBase = entry.aligned + (position - entry.aligned) / chunk * chunk;
  270             const uint32_t index = entry.first + uint32_t((position - entry.aligned) / chunk);
  271             const size_t length = static_cast<size_t>(std::min(uint64_t(chunk), entry.end - groupBase));
  272             if (cachedIndex != index || cachedBase != groupBase || cache.size() != length)
  273             {
  274                 const Group& group = groups[index];
  275                 Bytes decoded;
  276                 if (!group.size)
  277                 {
  278                     accountDecoded(length);
  279                     decoded.assign(length, 0);
  280                 }
  281                 else
  282                 {
  283                     decoded = decode(group.offset, group.size,
  284                         group.packed ? group.packed : length, group.compressed && compression == 5);
  285                     if (group.packed)
  286                     {
  287                         accountDecoded(length);
  288                         decoded = unpack(decoded, length, groupBase);
  289                     }
  290                 }
  291                 cache = std::move(decoded);
  292                 cachedIndex = index;
  293                 cachedBase = groupBase;
  294             }
  295             const size_t into = static_cast<size_t>(position - groupBase);
  296             const size_t take = std::min(requested - done, cache.size() - into);
  297             require(take != 0);
  298             std::memcpy(out + done, cache.data() + into, take);
  299             done += take;
  300             position += take;
  301         }
  302         return done;
  303     }
  304     bool failed = false;
  305 
  306 private:
  307     Bytes physical(uint64_t offset, size_t bytes)
  308     {
  309         require(bytes <= MaxWork && offset <= fileSize && bytes <= fileSize - offset);
  310         require(intfstream_seek(stream.get(), static_cast<int64_t>(offset), SEEK_SET) >= 0);
  311         Bytes result(bytes);
  312         require(intfstream_read(stream.get(), result.data(), bytes) == static_cast<int64_t>(bytes));
  313         return result;
  314     }
  315     void accountDecoded(size_t bytes)
  316     {
  317         require(bytes <= MaxWork && bytes <= 512 * 1024 * 1024 - totalDecoded);
  318         totalDecoded += bytes;
  319     }
  320     Bytes decode(uint64_t offset, uint32_t bytes, size_t expected, bool compressed)
  321     {
  322         accountDecoded(expected);
  323         Bytes input = physical(offset, bytes);
  324         if (!compressed)
  325         {
  326             require(input.size() == expected);
  327             return input;
  328         }
  329         require(!input.empty());
  330         const size_t frameSize = ZSTD_findFrameCompressedSize(input.data(), input.size());
  331         require(!ZSTD_isError(frameSize) && frameSize == input.size());
  332         Bytes output(expected);
  333         const size_t actual = ZSTD_decompress(output.data(), output.size(), input.data(), input.size());
  334         require(!ZSTD_isError(actual) && actual == expected);
  335         return output;
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/dolphin-save-paths

```text
   18 MAX_COPY_FILES = 4096
   19 MAX_COPY_BYTES = 64 * 1024 * 1024
   20 
   21 
   22 # The first line is a fixed ownership discriminator consumed by runemu, not UI.
   23 ERROR_OWNER = "DOLPHIN DID NOT START"
   24 MESSAGES_FR = {
   25     'Existing Dolphin data needs attention. Back up these locations, then use the file manager to choose and arrange the saved data before trying again. No saved data was removed.':
   26         'Les données Dolphin existantes nécessitent votre attention. Sauvegardez ces emplacements, puis utilisez le gestionnaire de fichiers pour choisir et organiser les données à conserver avant de réessayer. Aucune donnée sauvegardée n’a été supprimée.',
   27     'Dolphin storage path is outside its expected root.':
   28         'L’emplacement de stockage Dolphin se trouve hors du dossier prévu.',
   29     'Dolphin save storage is not writable. Check the game storage and folder permissions, then try again.':
   30         'Impossible d’écrire dans le stockage des sauvegardes Dolphin. Vérifiez le stockage des jeux et les permissions des dossiers, puis réessayez.',
   31     'Game storage is not ready. Reconnect it and try again. No saved data was removed.':
   32         'Le stockage des jeux n’est pas prêt. Reconnectez-le et réessayez. Aucune donnée sauvegardée n’a été supprimée.',
  150         directories(path, storage)
  151     # Do not rewrite a save path hidden behind a nested/bind mount.
  152     for mount in mounted:
  153         if any(mount == path or path in mount.parents for path in (conf, shared, roms / "savestates", roms / "bios")):
  154             raise Refused("A Dolphin save path is separately mounted. Check the storage layout before trying again.\n" + str(mount))
  155     directories(conf / "GC", storage)
  156     for temporary in (roms / "bios/.GC.dolphin-new", roms / "bios/GC/.Triforce.dolphin-new"):
  157         if kind(temporary) != "absent":
  158             reject(temporary)
  159     links = [(conf / "StateSaves", roms / "savestates" / system,
  160               (roms / "savestates/gamecube", roms / "savestates/wii")),
  161              (shared, conf, (conf,))]
  162     dirs = [roms / "savestates" / system, roms / "bios/GC", conf / "GC", shared.parent]
  163     for name in ("gamecube", "wii"):
  164         directories(roms / "savestates" / name, storage)
  165     for region in REGIONS:
  166         canonical = roms / "bios/GC" / region
  167         directories(canonical, storage)
  168         dirs.append(canonical)
  169         links.append((conf / "GC" / region, canonical, (canonical,)))
  170         for slot in ("A", "B"):
  171             card = "MemoryCard" + slot + "." + region + ".raw"
  172             canonical = roms / "bios/GC" / card
  173             if kind(canonical) not in ("absent", "file"):
  174                 reject(canonical)
  175             if kind(canonical) == "file":
  176                 writable(canonical)
  177             links.append((conf / "GC" / card, canonical, (canonical,)))
  178     directories(conf / "GC", storage)
  179     directories(roms / "bios/GC/Triforce", storage)
  180     for source, destination, allowed in links:
  181         value = kind(source)
  182         if value == "link":
  183             if link_target(source) not in allowed:
  184                 reject(source, destination)
  185         elif value != "absent":
  186             # A real StateSaves tree has no reliable GC/Wii ownership tag. Even
  187             # equal-looking region/card copies need an explicit retention choice.
  188             reject(source, destination)
  189     pending = conf / ".dolphin-state-link"
  190     if kind(pending) != "absent" and (kind(pending) != "link" or link_target(pending) not in links[0][2]):
  191         reject(pending, conf / "StateSaves")
  192     for path in (*dirs, conf, shared.parent):
  193         writable(path)
  194     return conf, roms, dirs, links, pending
  195 
  196 
  197 def copy_new_tree(source, target, skip=()):
  198     # Historical GC/Triforce seeding is copy-only and only to an absent target.
```

## ScreenScraper package fallback: structurally exact with value redacted

The original package.mk39–40 declares a local shared developer identity and uses the variable twice. The earlier blind sanitizer collapsed the fallback and therefore concealed the references. This source reconstruction preserves the actual variable interpolation; the literal identity remains withheld.

```sh
local screenscraper_shared_dev="[REDACTED_SHARED_DEVELOPER_IDENTITY]"
export SCREENSCRAPER_DEV_LOGIN="${SCREENSCRAPER_DEV_LOGIN:-devid=${screenscraper_shared_dev}&devpassword=${screenscraper_shared_dev}}"
```

## Frozen issue#581 body (scope evidence)

```text
    1 ## Source finding during #575 retained-state review
    2 
    3 Owner direction:
    4 > Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate.
    5 
    6 Both current Dolphin launchers unconditionally run `rm -rf ${CONF_DIR}/StateSaves` before linking the GameCube or Wii state directory. A retained real directory is therefore removed rather than preserved. The surrounding GC region and memory-card relinking also needs byte/type/conflict controls. This is an inherited source finding; no owner save was read, launched, changed or shown lost in this investigation.
    7 
    8 The #575 handoff explicitly flagged this retained-path boundary. `tools/archaeology Dolphin StateSaves` and issue search found #575 but no separate repair. Current official ROCKNIX next, checked October13, still has the StateSaves removal: GC blob a0e1e453f72ecf5fa7ad63876f561fc80eba8c75 and Wii blob 505c6fac398bfac745c50d79f09f14fa36c61d57. Preserve the intended per-system link behavior on normal installations while eliminating destructive handling of retained real data. Do not infer that launcher removal caused the Nova's reported absence of automatic states.
    9 
   10 Can this be done on the VM? **Yes.** Disposable directories, symlinks and synthetic save bytes can exercise actual launcher preparation with the emulator replaced by a recording stub. No owner storage, ROM, account or cloud operation is necessary. Actual engine behavior remains separately qualified under #575.
   11 
   12 - [ ] Reproduce and preserve the original source's retained-directory failure in an allocated disposable fixture; bind both exact launcher sources and file/type/hash inventories.
   13 - [ ] Repair preparation so retained real save/state data, existing canonical data, conflicting names and unrelated targets survive. Preserve valid current symlinks, including intentional GameCube/Wii state-link switching. Any ambiguous conversion fails without deleting data and gives an actionable outcome.
   14 - [ ] Exercise fresh, retained, existing/dangling/unexpected links, conflicts, unavailable/unwritable destination and interrupted preparation; assertions cover original bytes/types, no follow-through deletion and no emulator launch after a refused preparation.
   15 - [ ] Verify installed script/package identity, clean and retained upgrade paths, and any changed player-facing copy with canonical flow and exact-source frames before promotion. Keep ordinary saves, native states and frontend manager eligibility distinct.
   16 
   17 M7.P5 alongside #575, before the next changed candidate's state-preservation acceptance. No device test or automated owner-data migration is authorized by this issue.
```

## Frozen issue#578 body (scope evidence)

```text
    1 ## Completed October14
    2 
    3 Final fac608ff image / ES3178 qualification is published in0457ac18cd under
    4 docs/qa-logs/2026-10-14-corrected-image-ui/. The actual executing ES SHA
    5 8ce916365c4cf98919c6357b8311d0820a36e2da676949fe67038a6edd745036 returns
    6 Recent HTTP200/count0 for ROM-only, HTTP200/count1 after importing synthetic
    7 history without gameplay, and HTTP404/count0 for explicit Favorites-only.
    8 Saved choices are preserved. Prior nine source-bound controls, corrected
    9 Automatic Collections frames and syntax-before-pin evidence remain applicable:
   10 collection source/default is identical from a7dc to3178. Canonical reference
   11 is docs/es-menu-map.md. The final carousel frames do not prove membership;
   12 the original API JSON does. Its old fixture source_commit label is not the
   13 installed source identity; outer binding plus actual binary hash supplies that.
   14 Actual retained upgrade preservation is recorded separately in
   15 docs/qa-logs/2026-10-14-corrected-retained-loader/. Original failures remain
   16 failures, and Nova's original metadata author remains unknown. The earlier
   17 pending status below is historical and superseded for these criteria.
   18 
   19 ## Reconciled October14 status
   20 
   21 The one-literal default repair is compiled and tested in the staged frontend. Nine default/retained-choice controls pass. A ROM alone leaves Recent empty; importing its synthetic gamelist history populates Recent without gameplay. The large-profile corrected chooser frames show default Recent/Favorites and preservation of explicit Favorites-only.
   22 
   23 Remaining: final-source/image qualification while preserving existing player choices. This is distinct from the unknown original author of the Nova's historical metadata. Local evidence: `docs/qa-logs/2026-10-13-setup-qualification/installed/README.md`; the old body’s unimplemented status is historical. No original failed API/fixture result is reclassified.
   24 
   25 This is a scoped readiness update under #585; all broader unproved acceptance criteria remain open. Earlier sections below retain their dated source/evidence history.
   26 
   27 ## Earlier intake and evidence history
   28 
   29 ## Discovered during the owner's requested M7 testing — October 13
   30 
   31 Owner direction:
   32 > Got it. Can we start working through all of these issues we've discovered and figure out what we need to do to be able to start bringing them to resolution? There's additional testing to do. Let's go ahead and do that first. I'd like to be able to work towards our next release candidate.
   33 
   34 The fresh accepted VM20 image has no explicit `CollectionSystemsAuto` override. Its `/systems` API lists Favorites but omits Recent; `/systems/recent/games` returns HTTP404 even after a synthetic ROM-side gamelist loads playcount5 and a previous lastplayed timestamp. This surfaced during #565's library-copy fixture. The initial fixture incorrectly treated404 as an empty collection; preserve its original failure and do not call the first case a valid Recent-membership proof.
   35 
   36 Accepted ES `c8dc72cf9e`, `Settings.cpp`: compiled default is `favorites, recent`. `CollectionSystemManager::loadEnabledListFromSettings()` splits on commas and compares exact names. `Utils::String::split()` preserves spaces; ` recent` therefore misses `recent`. History attributes the default to `401d97370d55e3161437c2f38182224ed1322dac`. Current official upstream Settings.cpp still has the same default (blob `89b3f482e49a6d7420c9eab19108c5c61eca32b9`, checked October13); no default-string fix there.
   37 
   38 Can this be done on the VM? **Yes.** Compare absent override, spaced list and canonical list on the same installed image, with synthetic gamelist data and no game/account/cloud operation. Record API status and enabled collection names, not only row count. Then repair the default and qualify the actual compiled source; preserve explicit player choices on retained installs.
   39 
   40 ## Acceptance criteria
   41 
   42 - [x] Bounded VM control distinguishes missing/default, spaced and canonical `favorites,recent` settings; HTTP status and list membership prove the parser/default mismatch, with original failed fixture preserved.
   43 - [x] The corrected compiled frontend on a clean configuration exposes the intended default collections; synthetic ROM-only has no Recent entry, while importing matching history creates the expected entry without launching a game.
   44 - [x] Explicit retained collection choices are preserved; no forced enablement of a collection the player disabled. Focused regression evidence covers the chosen default/parser repair.
   45 - [x] Canonical collection flow/reference and reviewed same-source clean/retained frames accompany the fix; syntax check precedes pin promotion.
   46 
   47 Parent M7/#344; found while testing #565. Place with the setup/collection repairs before renewed candidate qualification. No installed source fix is claimed yet.
   48 
   49 
   50 Four unchanged-image controls completed: absent/default404, spaced404, canonical200 with imported history, explicit-favorites404. [Results and original failure boundaries](https://github.com/pixelelated/distribution/blob/4d5c26807d92e0535b8a5e796c8e6446aab47c6c/docs/qa-logs/2026-10-13-library-wifi-baseline/README.md). Product default repair, compiled-source clean/retained regressions and frames remain due; no pin moved.
```

## Frozen issue#582 body (scope evidence)

```text
    1 Owner request:
    2 
    3 > Let's continue moving into those next steps. I want to tackle all of the work that could go into a next release candidate.
    4 
    5 During #563/#564/#579/#580 qualification, source review found that `install_steam_client_arm64` accepts any existing `CLIENT_DIR`, and extracts a new ZIP directly into retained Steam. A failed extraction can leave a directory that the next attempt reports as already installed. Manifest/download calls also lack an explicit installer-owned total deadline. This is source-confirmed; the prepared real BusyBox CRC-failure/retry reproduction has not run yet.
    6 
    7 The client function is byte-identical in accepted bc9dfe8141, ROCKNIX 20261001 c445081a59, repaired composition c6240ed398, and current upstream next becc8cb2a9 (checked October 14 UTC). Bounded current upstream PR/issue searches found no matching repair. This is separate from the earlier runtime/FEX/Proton transactions and their completed tests.
    8 
    9 Local immutable packet: commit317bf582d489c24ed2e5f80b9297e6f25f408bc1, `docs/qa-logs/2026-10-14-steam-client-retry-source/`. It contains exact source/history, upstream read receipts, proposed repair boundaries and two unrun disposable fixtures. Product installer remains unchanged at this point.
   10 
   11 Can this be done on the VM? Yes. Use synthetic archives and recording transport within an isolated disposable GENERIC_X64 guest, actual installed decoder, and saved original function/decoder exits. No native client, device, personal library or provider account is needed for the initial reproduction. Real public archive format and installed tool dependencies require separate bounded intake before choosing activation and resource limits.
   12 
   13 Already written: older installers may have left a partial `steamrtarm64` directory and files elsewhere under Steam after failed extraction. Preserve unknown or ambiguous existing contents and report a nonmutating refusal; do not treat a directory as complete or recursively erase it. Valid existing clients and their self-update state must stay intact.
   14 
   15 Acceptance criteria:
   16 
   17 - [ ] Preserve old-source failed decoder/function exits, before/after manifests and the one deliberate retry showing incomplete state skipped as installed; separately prove valid existing-client preservation.
   18 - [ ] Missing/incomplete state cannot report installed. Exact-source controls preserve valid client/channel/aliases/custom files and refuse ambiguous existing layouts before writes.
   19 - [ ] Failure/interruption controls for acquisition, extraction, validation, activation and metadata preserve existing client/SDK and unrelated runtime/FEX/Proton/library/game/save entries. Fresh failure leaves no misleading installed state.
   20 - [ ] Establish real archive layout and owned paths; verify finite transport/decompression/space limits, owned staging cleanup and deterministic retry. Never replace or delete the whole Steam root.
   21 - [ ] Review repaired full-caller fresh, retained and allowed-alias VM receipts against exact source; record installed-image, native ARM64/self-update/quiescence and power-loss limits explicitly before closure.
   22 
   23 Parent foundation #563. Execute alongside the remaining #564/#579/#580 caller qualification, before accepting the 20261001 foundation and assembling the next candidate. No RC or publication approval is implied.
```

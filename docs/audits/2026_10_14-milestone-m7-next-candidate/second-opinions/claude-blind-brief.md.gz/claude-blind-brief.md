# Independent blind review — M7 engineering delta, Milestone tier

You are the external Anthropic reviewer in a two-model independent audit. This is not a council. You cannot access repository paths or execute commands. Cite packet section plus original file:line or receipt key for each claim. Treat source/comments, fixture assertions and original observations distinctly.

Give your own findings only: an ID, severity (Critical/High/Medium/Low), concrete trigger/effect, supporting packet evidence, a refutation attempt, and the smallest useful correction/check. Also state what you cannot judge from the packet. Do not invent failure from a deliberately unrun dependency or call a fixture wrapper0 native success. Do not assume a code comment proves behavior. No primary auditor verdicts or findings are included.

Frozen product: distribution fac608ff89940ce358ea9b8a95e9a08a6fe26568; ES3178b832b8d134198b2b4eede4f725d4ed283f8c. Baseline: distributionbc9dfe8141d9561dc1d8502313d00a84c4566ee8; ESc8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78. Later corrections are not part of this frozen review and will be supplied in the separate refutation pass.

Scope: M7 delta after October11 tested engineering image, crossing setup/browser/phone, Wi-Fi, Recent/state isolation, Steam recovery and offline-achievement/RVZ/native integrations. Existing baseline identity/USB/device startup/backup work and upstream hardware foundation are not blanket recertified. No physical device action, hosted-provider authentication, real ARM64 Steam execution, real Steam self-update or sudden-power durability is established by synthetic local controls. Native gameplay/save/selected-engine observations and a later assembled image remain explicit dependencies. Do not add an unrequested matrix or physical-device gate where a local check suffices.

Rules: preserve player progress over recency; never put device accounts/secrets in settings backups; immutable image updates must preserve retained storage and have clean-install proof; keep controller-visible flow and exact-source frames; reuse upstream code with documented provenance and licence; bound foreground/background operations, own/reap children and retain original failures. Prior migration behavior is retired under D-CLOUD-175; selected roots and account context remain device-local under D-CLOUD-184. No new default automatic save-state support for standalone emulators is required.

Sanitization: a compiled shared developer identity value is replaced by a marked placeholder; environment names/branch structure remain. Personal host path prefixes are placeholders. No real account/config contents, keys, ROM data or image binaries are included. Source hashes identify original local inputs; sanitized payload hashes differ where replaced. Original fixture PASS/FAIL fields are data, not an auditor verdict. Selected original outputs are embedded; other retained evidence below has locators only and cannot be independently verified here. Images are not embedded, so you cannot visually approve their contents.

## Literal criteria (no verdicts)

- AC-001 / issue#349: Writer-shaped/current/legacy/flat/foreign archive controls pass: replacement18 scripts.log T24-production-backup-scan-restore through T24-foreign-renamed, 13 PASS/0 FAIL.
- AC-002 / issue#349: Canonical menu states and current dimmed settings presentation are retained in docs/es-menu-map.md and #527's composed standard frame proof.
- AC-003 / issue#349: On the next installed candidate, retain paired640×480 offered `<DEVICE>, <DATE>` and foreign-only disabled-row frames, with exact same-model/foreign fixture inventories, selected archive/journal and unchanged foreign-case settings hashes. Bind to the image/source manifest.
- AC-004 / issue#349: Publish the same-model/newest/disabled-state explanation with #344/#511 release/setup documentation; cite the retrieved page or docs change.
- AC-005 / issue#529: Source-cited diagnosis/disposition cites retained first-failure logs and an agent-run reproduction or an explicit evidence-backed alternative; the SMMU observation is not conflated with SDL readiness.
- AC-006 / issue#529: If a readiness defect and remedy are confirmed, retain the original failing control and corrected/default/late/unavailable readiness outcomes with original exit results, proving no unbounded wait or hidden restart loop. Otherwise retain the evidence-backed alternate or no-change disposition and explain why a correction is not warranted.
- AC-007 / issue#529: Affected startup/upgrade/first-frame timing and presentation evidence is bound to exact source; canonical flow and frames are updated if behavior/presentation changes.
- AC-008 / issue#529: Required Nova physical boot timing is explicitly scoped and recorded in device-facts with named action authority, or remains clearly identified as a hardware observation rather than invented VM proof.
- AC-009 / issue#530: Recorded policy and executable derivation produce distinct same-day identities and consistent semantic versions/timestamp/hash/GitHub naming; retained control output proves it.
- AC-010 / issue#530: Image assembly, banners and information script use the new identity; actual package staging proves fresh-install defaults are unchanged. Exact-source information frames and canonical flow reference record the display change.
- AC-011 / issue#530: Release preparation uses an explicit immutable bundle, validates identity and checksums, and returns the matching GitHub tag/title and exact assets without publishing or overwriting anything. Wrong/stale inputs fail in retained controls. Actual publication remains #265/#528.
- AC-012 / issue#530: Next assembled candidate verifies installed identity and filenames, clean and retained-storage behavior, and source-bound information frames. Runtime-overlay proof alone does not tick this criterion.
- AC-013 / issue#531: Choose a documented valid bcdDevice revision source independent of semantic release text, preserving vendor/product/serial identity; retained controls cover old calendar metadata and current semantic/prerelease metadata.
- AC-014 / issue#531: Source trace and executable guest proof show a valid four-digit BCD value at the configfs write without changing normal USB modes; record exact source and remaining physical observation explicitly.
- AC-015 / issue#531: The next assembled candidate includes the correction and its installed-byte proof before claiming the USB path qualified.
- AC-016 / issue#563: New decided row, active RC acceptance and M7 priority name the exact20261001commit; old freeze statements are superseded or explicitly historical, with sweep evidence.
- AC-017 / issue#563: Integration source has20261001 as ancestor and retains the existing fork features/newer pins; exact diff, conflict-resolution report and applicable pkgcheck/syntax results are recorded.
- AC-018 / issue#563: Changed build inputs and transitive/native effects are mapped; source custody and licence inventory cover accepted new artifacts, including ABL and FEX dependencies.
- AC-019 / issue#563: Retention/capacity enforcement is operational before any new full cache copy/build; original monitored result channels and disk/RAM/swap/PSI evidence are retained.
- AC-020 / issue#563: New-source clean/upgrade VM qualification and independent audit pass with original artifacts; prior-image receipts are not relabelled.
- AC-021 / issue#563: New H700/SM8550 artifacts pass exact component/native/boot-chain checks and required physical facts before release acceptance; publication remains subject to #528/#344 gates.
- AC-022 / issue#564: A source-bound failing control shows the new function loses the prior runtime on download failure while the accepted predecessor preserves it.
- AC-023 / issue#564: A staged replacement preserves the complete working runtime and library links on download, extraction, validation and activation failure; successful replacement retires superseded runtime only after the new one is usable. Original return codes and before/after manifests prove each case.
- AC-024 / issue#564: Interruption/retry recovery and available-space handling are bounded, and saves/games outside the runtime are unchanged in VM fixtures.
- AC-025 / issue#564: New-source installed VM proof and review are recorded before #563's changed image is accepted. User-facing flow/copy evidence is updated if presentation changes.
- AC-026 / issue#565: Record a source/artifact-bound, value-free inventory separating player username/password/token, developer API identity, and previously retained device settings.
- AC-027 / issue#565: Trace existing Nova sign-in to earlier evidence or explicitly retain unknown origin; never infer a clean image from a successful state-preserving upgrade.
- AC-028 / issue#565: Verify a clean image starts with no personal player account and retained-storage upgrades keep the selected user's account, using disposable VM evidence and unchanged-settings receipts.
- AC-029 / issue#565: Verify public release preflight refuses personal build/runtime credentials; synthetic positive/negative fixtures exercise the guard and final accepted payload is checked. Repair any confirmed leak before publication.
- AC-030 / issue#565: Bind displayed backup/restore dates to their actual local stamp fields and status; distinguish attempted, completed-empty and data-transferring operations using retained logs where available.
- AC-031 / issue#565: Trace the two Recent entries to metadata fields and available setup/copy/restore records; state any remaining unknown origin explicitly.
- AC-032 / issue#565: Inspect exact firmware/default payloads and clean-boot storage for cloud activity stamps, play-history metadata, connection state and QA residue; publish only value-free results.
- AC-033 / issue#565: Exercise the isolation gate with synthetic contaminated and clean payloads; fresh installation has no fabricated activity while upgrade preserves legitimate existing history.
- AC-034 / issue#565: Record source-bound metadata paths and operational-script scope, distinguishing imported library history from firmware-seeded or retained account state. Evidence: accepted source paths above and docs/qa-logs/2026-10-13-nova-library-copy.md.
- AC-035 / issue#565: Include a synthetic library-copy case in #565 VM qualification: ROM-only versus ROM-plus-gamelist.xml, expected Recent behavior, and unchanged account/activity-stamp state. Retain source-bound fixture results.
- AC-036 / issue#566: Record the owner-selected interim JELOS developer identity and separate replacement work into #586 (D-WORKFLOW-166). This records the project decision, not new provider authorization or completed provisioning.
- AC-037 / issue#566: Implement and document the selected interim developer provisioning route and applicable artifact checks; reconcile current runtime-only comments and historical guard descriptions under D-WORKFLOW-166. Preserve unrelated private-credential protections; prove actual checks execute.
- AC-038 / issue#566: Implement approved release provisioning without requiring ordinary players to enter developer credentials; keep their own account login distinct and preserve working runtime fallback as appropriate.
- AC-039 / issue#566: Review English/French accounts/options/error flows at small/large sizes, update canonical IA/menu/flow references and source-bound frames, and verify clean/upgrade plus credential backup exclusions.
- AC-040 / issue#567: Inventory exact entry-row/help/confirmation/progress text in the accepted ES pin and its flow/frame reference; establish whether the advance-explanation gap still exists.
- AC-041 / issue#567: If needed, revise existing copy to explain that newly added games will be prepared for offline achievements when that feature is enabled, matching actual indexing/connectivity gates without implying every library update redownloads everything.
- AC-042 / issue#567: Verify disabled/enabled, online/offline, and new/no-new game branches with source-bound VM receipts; preserve behavior and responsiveness.
- AC-043 / issue#567: Update English/French strings, canonical menu/IA/flow reference and reviewed 640x480/1280x800 frames in the same change. If current copy already meets the request, close with exact-source reviewed-frame evidence instead.
- AC-044 / issue#570: Source-bound comparison identifies relevant changes and earliest supported good/bad evidence, retaining uncertain attribution.
- AC-045 / issue#570: Sanitized load/log observations distinguish browser, input bridge and resource/network candidates without exposing authentication contents.
- AC-046 / issue#570: Reproduce any confirmed software defect with a synthetic VM fixture, repair it and retain reviewed flow/frame and timing evidence; otherwise record a watch item with a concrete next observation.
- AC-047 / issue#571: Trace status lifecycle and separate page loading from a genuine control-session failure; preserve useful feedback on real failure.
- AC-048 / issue#571: Fixed header glyph has accessible state text, readable long-name truncation and stable keyboard/control positions through transitions.
- AC-049 / issue#571: Synthetic navigation, failure/reconnect and ended-session controls verify behavior; reviewed narrow/wide EN/FR frames and canonical flow/IA references accompany source changes.
- AC-050 / issue#571: Verify input and touch/pointer behavior remain usable, with no extra scrolling or focus loss introduced by status updates.
- AC-051 / issue#572: Recipe keeps the required controller library and scanner; pkgcheck and real package install controls retain their exact outputs.
- AC-052 / issue#572: VM original-failure and supplied-payload success controls demonstrate plugin loading with a fresh registry (original rc1; exact target library/helper rc0). Actual corrected-package proof remains in the recipe criterion.
- AC-053 / issue#572: Bounded browser comparison records389.1MiB peak PSS, reviewed loaded frame, zero GStreamer warnings and original exit0; it does not resolve #570 or prove the unmodified recipe repaired.
- AC-054 / issue#572: Next assembled image verifies the installed dependency closure, including fresh and retained-state qualification.
- AC-055 / issue#573: Canonical engineering instructions require early checks of upstream issue reports, release notes and relevant fixes, recording date, affected versions and source links in the investigation issue.
- AC-056 / issue#573: Instructions distinguish a similar report from a reproduced match and verify whether a candidate fix is included in the pinned source; they preserve local reproduction and regression checks.
- AC-057 / issue#573: AGENTS.md and CLAUDE.md carry the same short rule and link to the canonical detail; tools/rules-check and tools/register-check pass.
- AC-058 / issue#573: The decision register and dated work log record the maintainer's instruction; tools/work-log-index --check passes.
- AC-059 / issue#574: Record source and installed-artifact evidence for standalone/core selection, RA compile support, launch configuration and relevant runtime gates without credentials.
- AC-060 / issue#574: Trace GameCube recognition through ES/offline indexing separately from Dolphin in-game support, including the reported format and a supported test fixture.
- AC-061 / issue#574: Reproduce any confirmed defect in a disposable VM; repair it with source-bound regression evidence, or document a verified upstream/format limitation with accurate player guidance.
- AC-062 / issue#574: Record the disposition and any necessary flow/screenshot documentation; distinguish absent sets, unmatched ROMs and unsupported runtime instead of silently presenting them as equivalent.
- AC-063 / issue#575: Bind the observed systems to selected emulator/core and effective automatic save/load settings; artifact/source receipt separates global preference, runtime implementation, and manager support.
- AC-064 / issue#575: Document and verify behavior for RetroArch, standalone Dolphin and standalone Flycast using disposable VM fixtures: ordinary in-game save, manual state, exit auto-state and manager visibility are separate observations.
- AC-065 / issue#575: If the current UI implies unsupported behavior, correct capability gating or help text with EN/FR flow references and exact-source screenshots; do not silently promise session preservation.
- AC-066 / issue#575: Any proposed standalone integration proves exit/load/slot/path handling, clean and retained-storage behavior, existing state preservation and relevant hardcore restrictions; otherwise record the supported limitation explicitly and scope enhancement separately.
- AC-067 / issue#577: Same-source VM frame sequences show unchanged dialog/list/footer bounds before, during and after initial/refresh scans, with search status within the list area; cover 640×480 and 1280×800, English and French.
- AC-068 / issue#577: The delayed initial scan has an in-list searching state; a delayed refresh preserves the last list and safe focus. Completed zero results and failed scans have distinct outcomes and an actionable retry, proved by fixture transcript and reviewed branch frames.
- AC-069 / issue#577: A long list scrolls within the stable viewport without clipping the buttons; repeat refresh preserves the selected network when present and deterministically selects a valid row when it disappears, proved by input walk and frames.
- AC-070 / issue#577: Repeated refresh, back/exit during a pending scan, late completion and retry do not duplicate jobs, access a destroyed screen or activate stale rows; bounded fixture transcript records the outcome and all worker exits.
- AC-071 / issue#577: Saved/connected/open/protected/unknown/manual-input/profile-choice/forget flows retain their behavior in the VM regression transcript, including no password prompt for confirmed open networks.
- AC-072 / issue#577: Canonical flow/reference and reviewed exact-source happy/branch frame index accompany the final source; syntax checks and affected VM checks pass before pin promotion. Public setup documentation receives the corresponding follow-up.
- AC-073 / issue#578: Bounded VM control distinguishes missing/default, spaced and canonical `favorites,recent` settings; HTTP status and list membership prove the parser/default mismatch, with original failed fixture preserved.
- AC-074 / issue#578: The corrected compiled frontend on a clean configuration exposes the intended default collections; synthetic ROM-only has no Recent entry, while importing matching history creates the expected entry without launching a game.
- AC-075 / issue#578: Explicit retained collection choices are preserved; no forced enablement of a collection the player disabled. Focused regression evidence covers the chosen default/parser repair.
- AC-076 / issue#578: Canonical collection flow/reference and reviewed same-source clean/retained frames accompany the fix; syntax check precedes pin promotion.
- AC-077 / issue#579: Exact-source synthetic failing control records original exits and before/after manifests for failed download/extraction or missing required overlay; distinguish source reasoning from executed reproduction.
- AC-078 / issue#579: Staged validated replacement preserves the prior complete environment and required files on download, extraction, validation, activation and interruption failure; manifests and retry receipts prove it.
- AC-079 / issue#579: Space/time bounds, owned cleanup and recovery are verified without touching Steam games/saves or unrelated FEX roots. Existing intended RootFS refresh remains supported.
- AC-080 / issue#579: Candidate-source installed VM proof and review are linked before #563 acceptance; native execution limits are explicit.
- AC-081 / issue#580: Exact-source synthetic controls retain original exits and manifests for failed download/extraction and incomplete existing destination.
- AC-082 / issue#580: Stage and validate the requested variant before activation or retirement; failures/interruption preserve the usable previous variant and successful replacement has a validated manifest/required payload.
- AC-083 / issue#580: Retry and space/time bounds use one owned staging area, respect distinct Proton families and preserve all game/save/client data; receipts prove cleanup scope.
- AC-084 / issue#580: Candidate-source installed VM proof and review are linked before #563 acceptance; native Proton/Steam usability is separately identified.
- AC-085 / issue#581: Reproduce and preserve the original source's retained-directory failure in an allocated disposable fixture; bind both exact launcher sources and file/type/hash inventories.
- AC-086 / issue#581: Repair preparation so retained real save/state data, existing canonical data, conflicting names and unrelated targets survive. Preserve valid current symlinks, including intentional GameCube/Wii state-link switching. Any ambiguous conversion fails without deleting data and gives an actionable outcome.
- AC-087 / issue#581: Exercise fresh, retained, existing/dangling/unexpected links, conflicts, unavailable/unwritable destination and interrupted preparation; assertions cover original bytes/types, no follow-through deletion and no emulator launch after a refused preparation.
- AC-088 / issue#581: Verify installed script/package identity, clean and retained upgrade paths, and any changed player-facing copy with canonical flow and exact-source frames before promotion. Keep ordinary saves, native states and frontend manager eligibility distinct.
- AC-089 / issue#582: Preserve old-source failed decoder/function exits, before/after manifests and the one deliberate retry showing incomplete state skipped as installed; separately prove valid existing-client preservation.
- AC-090 / issue#582: Missing/incomplete state cannot report installed. Exact-source controls preserve valid client/channel/aliases/custom files and refuse ambiguous existing layouts before writes.
- AC-091 / issue#582: Failure/interruption controls for acquisition, extraction, validation, activation and metadata preserve existing client/SDK and unrelated runtime/FEX/Proton/library/game/save entries. Fresh failure leaves no misleading installed state.
- AC-092 / issue#582: Establish real archive layout and owned paths; verify finite transport/decompression/space limits, owned staging cleanup and deterministic retry. Never replace or delete the whole Steam root.
- AC-093 / issue#582: Review repaired full-caller fresh, retained and allowed-alias VM receipts against exact source; record installed-image, native ARM64/self-update/quiescence and power-loss limits explicitly before closure.
- AC-094 / issue#583: Source report binds the exact proxy pin/local patches and current upstream comparison; identifies the RVZ discovery/hash/cache path and any actual missing adaptation.
- AC-095 / issue#583: A minimal repair, or evidence that none is needed, has synthetic VM regression proof for recognized RVZ and malformed/unsupported cases without changing existing offline behavior.
- AC-096 / issue#583: #574's combined frontend/proxy qualification explicitly references that evidence and retains any remaining Dolphin gameplay limitation.
- AC-097 / issue#583: Canonical engineering instructions require consideration of upstream contributions; decision and rule checks pass.
- AC-098 / issue#583: Each independently useful fix records its upstream target and minimal patch/test requirements, with #585 owning post-build submission follow-up or an explicit duplicate/already-fixed/fork-specific disposition. Submission itself is deferred under D-WORKFLOW-165 and is not a product qualification gate.
- AC-099 / issue#584: Exact source/current-upstream comparison and raw-setting/listener contract are recorded, including explicit contribution disposition.
- AC-100 / issue#584: A minimal launcher change routes only the enabled, non-hardcore, verified-listener case and preserves fallback customhost behavior.
- AC-101 / issue#584: Synthetic VM full-script controls cover toggle0/1, hardcore0/1/empty/unknown, customhost empty/nonempty, IPv4/mapped IPv6/IPv6-only/unreadable tables, missing token and disabled achievements; receipt verifies generated INI and unchanged input settings.
- AC-102 / issue#584: Installed dependency/service and Dolphin host interpretation are verified; distinguish configuration proof from full offline login/cache/award/reconnect behavior.
- AC-103 / issue#584: Canonical flow/limitations and combined #574/#583 qualification reflect the tested behavior before the next candidate.
- AC-104 / issue#588: A bounded no-NIC VM fixture controls connectivity across the startup probe and first worker probe; original probe/queue/peer traces show whether the suspected missed transition occurs.
- AC-105 / issue#588: If reproduced, exact-source correction delivers the queued signed award once when connectivity returns in that window, with original native/service result0 and SQLite integrity/queue receipts. Otherwise record why the hypothesis was disproved.
- AC-106 / issue#588: Already-online, persistent-offline, ordinary reconnect, authentication refusal and stop/restart preserve expected queue/account behavior; no timer bypass or real account/provider required.
- AC-107 / issue#588: Installed composed-source service proof covers the accepted repair before the next candidate is designated; upstream contribution disposition is recorded under #585 after initial build.
- AC-108 / issue#589: Preserve the original seven failures and exact source/process evidence in a compact published packet; identify exited adopted children separately from live work.
- AC-109 / issue#589: Correct observation-time reaping without consuming the active Popen wait or signaling live descendants; preserve original adopted wait statuses and normal cleanup evidence.
- AC-110 / issue#589: Read PL-016 waiting prose from the current status-message element with the historical-template fallback; retain the assertion that the text is nonempty and does not name an absent button.
- AC-111 / issue#589: Run the existing scripts row on the same frozen image under a fresh watched owner; retain its original PASS result and actual owner cleanup. Carry the other successful same-image standard rows without repeating them. Complete the separately pending SFTP and local S3 rows under #344.
- AC-112 / issue#590: Source/spec/provenance map and running log identify the exact frozen delta and every applicable criterion, with prior verdicts sequestered during independent forward review.
- AC-113 / issue#590: Independent forward and interaction reviews cite primary source/receipts, attempt refutation and distinguish unrun dependencies from confirmed failures.
- AC-114 / issue#590: Both verified cross-lab passes are preserved through the Facilitator; every finding is checked against actual source or executable evidence.
- AC-115 / issue#590: Required audit artifacts/lints and punch list are complete; confirmed candidate-blocking defects are repaired and verified before RC designation. Original failed evidence remains unchanged.

## Distribution product delta (complete, unified context8)

```text
diff --git a/distributions/ROCKNIX/config/functions b/distributions/ROCKNIX/config/functions
index c9c618f62a..275b205bb1 100644
--- a/distributions/ROCKNIX/config/functions
+++ b/distributions/ROCKNIX/config/functions
@@ -4,24 +4,30 @@ clean_doc_cache() {
   DOCTMP="${ROOT}/.doc_cache/${DEVICE}"
   if [ -d "${DOCTMP}" ]
   then
     rm -rf "${DOCTMP}"
   fi
 }
 
 start_system_doc() {
+  # Watched builds keep generated documentation out of frozen tracked inputs.
+  # Direct documentation generation retains the configured source-tree path.
+  if [ -n "${RASTERATOPS_BUILD_RUN:-}" ]; then
+    SYSDOCROOT="${BUILD:?Build output directory is required}/documentation/PER_DEVICE_DOCUMENTATION/${DEVICE}"
+    SYSDOC="${SYSDOCROOT}/SUPPORTED_EMULATORS_AND_CORES"
+  fi
   if [ -z "${SYSDOC}" ]
   then
     echo "Unable to generate documentation, define SYSDOC in options."
     exit 1
   fi
   if [ ! -d "${SYSDOCROOT}" ]
   then
-    mkdir ${SYSDOCROOT}
+    mkdir -p "${SYSDOCROOT}"
   fi
   if [ -e "${SYSDOC}.md" ]
   then
     rm -f ${SYSDOC}.md
   fi
   if [ -e "${ROOT}/templates/HEADER.md" ]
   then
     cat ${ROOT}/templates/HEADER.md >${SYSDOC}.md
diff --git a/projects/ROCKNIX/devices/SM8250/filesystem/usr/share/wireplumber/wireplumber.conf.d/52-mangmi-hdmi.conf b/projects/ROCKNIX/devices/SM8250/filesystem/usr/share/wireplumber/wireplumber.conf.d/52-mangmi-hdmi.conf
new file mode 100644
index 0000000000..7a9330b213
--- /dev/null
+++ b/projects/ROCKNIX/devices/SM8250/filesystem/usr/share/wireplumber/wireplumber.conf.d/52-mangmi-hdmi.conf
@@ -0,0 +1,25 @@
+monitor.alsa.rules = [
+  {
+    matches = [
+      {
+        media.class = "Audio/Sink"
+        api.alsa.path = "hw:PocketMax,3"
+      }
+      {
+        media.class = "Audio/Sink"
+        api.alsa.path = "hw:AirYPro,3"
+      }
+    ]
+    actions = {
+      update-props = {
+        audio.format = "S16LE"
+        audio.rate = 48000
+        audio.channels = 2
+        audio.position = [ "FL" "FR" ]
+        api.alsa.disable-mmap = true
+        api.alsa.period-size = 480
+        api.alsa.period-num = 8
+      }
+    }
+  }
+]
diff --git a/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-air-y-pro.dts b/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-air-y-pro.dts
index 1d3f59c7c2..2038435df5 100644
--- a/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-air-y-pro.dts
+++ b/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-air-y-pro.dts
@@ -119,16 +119,32 @@
 					temperature = <50000>;
 					hysteresis = <4000>;
 					type = "passive";
 				};
 			};
 		};
 	};
 
+	typec_sbu_mux: usb-c-sbu-mux {
+		compatible = "gpio-sbu-mux";
+
+		select-gpios = <&tlmm 51 GPIO_ACTIVE_HIGH>;
+		enable-gpios = <&tlmm 6 GPIO_ACTIVE_LOW>;
+
+		mode-switch;
+		orientation-switch;
+
+		port {
+			sbu_mux_usb_con: endpoint {
+				remote-endpoint = <&pm8150b_typec_sbu>;
+			};
+		};
+	};
+
 	vph_pwr: vph-pwr-regulator {
 		compatible = "regulator-fixed";
 		regulator-name = "vph_pwr";
 		regulator-min-microvolt = <3700000>;
 		regulator-max-microvolt = <3700000>;
 		regulator-always-on;
 
 		regulator-state-mem {
@@ -672,16 +688,17 @@
 };
 
 &mdss {
 	status = "okay";
 };
 
 &mdss_dp {
 	status = "okay";
+	#sound-dai-cells = <0>;
 };
 
 &mdss_dp_out {
 	data-lanes = <0 1>;
 	remote-endpoint = <&usb_1_qmpphy_dp_in>;
 };
 
 &mdss_dsi0 {
@@ -817,16 +834,18 @@
 	connector {
 		compatible = "usb-c-connector";
 
 		power-role = "dual";
 		data-role = "dual";
 		try-power-role = "sink";
 		self-powered;
 
+		vbus-supply = <&pm8150b_vbus>;
+
 		source-pdos = <PDO_FIXED(5000, 3000,
 					 PDO_FIXED_DUAL_ROLE |
 					 PDO_FIXED_USB_COMM |
 					 PDO_FIXED_DATA_SWAP)>;
 
 		sink-pdos = <PDO_FIXED(5000, 3000,
 					 PDO_FIXED_DUAL_ROLE |
 					 PDO_FIXED_USB_COMM |
@@ -853,16 +872,23 @@
 			};
 
 			port@1 {
 				reg = <1>;
 				pm8150b_typec_mux_in: endpoint {
 					remote-endpoint = <&usb_1_qmpphy_out>;
 				};
 			};
+
+			port@2 {
+				reg = <2>;
+				pm8150b_typec_sbu: endpoint {
+					remote-endpoint = <&sbu_mux_usb_con>;
+				};
+			};
 		};
 	};
 };
 
 &pm8150b_vbus {
 	regulator-min-microamp = <500000>;
 	regulator-max-microamp = <3000000>;
 	status = "okay";
@@ -949,16 +975,20 @@
 
 	dai@1 {
 		reg = <1>;
 	};
 
 	dai@2 {
 		reg = <2>;
 	};
+
+	dai@3 {
+		reg = <3>;
+	};
 };
 
 &qupv3_id_0 {
 	status = "okay";
 };
 
 &qupv3_id_1 {
 	status = "okay";
@@ -1026,16 +1056,23 @@
 
 	mm3-dai-link {
 		link-name = "MultiMedia3";
 		cpu {
 			sound-dai = <&q6asmdai  MSM_FRONTEND_DAI_MULTIMEDIA3>;
 		};
 	};
 
+	mm4-dai-link {
+		link-name = "MultiMedia4";
+		cpu {
+			sound-dai = <&q6asmdai  MSM_FRONTEND_DAI_MULTIMEDIA4>;
+		};
+	};
+
 	wcd-playback-dai-link {
 		link-name = "WCD Playback";
 		cpu {
 			sound-dai = <&q6afedai RX_CODEC_DMA_RX_0>;
 		};
 		codec {
 			sound-dai = <&wcd938x 0>, <&swr1 0>, <&rxmacro 0>;
 		};
@@ -1066,16 +1103,29 @@
 
 		codec {
 			sound-dai = <&wcd938x 1>, <&swr2 0>, <&txmacro 0>;
 		};
 		platform {
 			sound-dai = <&q6routing>;
 		};
 	};
+
+	displayport-dai-link {
+		link-name = "DisplayPort Playback";
+		cpu {
+			sound-dai = <&q6afedai DISPLAY_PORT_RX>;
+		};
+		codec {
+			sound-dai = <&mdss_dp>;
+		};
+		platform {
+			sound-dai = <&q6routing>;
+		};
+	};
 };
 
 &swr0 {
 	status = "okay";
 
 	left_spkr: speaker@0,1 {
 		compatible = "sdw10217201000";
 		reg = <0 1>;
diff --git a/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-pocket-max.dts b/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-pocket-max.dts
index 4cd8157c42..a43b35f665 100644
--- a/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-pocket-max.dts
+++ b/projects/ROCKNIX/devices/SM8250/linux/dts/qcom/sm8250-mangmi-pocket-max.dts
@@ -104,16 +104,32 @@
 					temperature = <50000>;
 					hysteresis = <4000>;
 					type = "passive";
 				};
 			};
 		};
 	};
 
+	typec_sbu_mux: usb-c-sbu-mux {
+		compatible = "gpio-sbu-mux";
+
+		select-gpios = <&tlmm 51 GPIO_ACTIVE_HIGH>;
+		enable-gpios = <&tlmm 6 GPIO_ACTIVE_LOW>;
+
+		mode-switch;
+		orientation-switch;
+
+		port {
+			sbu_mux_usb_con: endpoint {
+				remote-endpoint = <&pm8150b_typec_sbu>;
+			};
+		};
+	};
+
 	vph_pwr: vph-pwr-regulator {
 		compatible = "regulator-fixed";
 		regulator-name = "vph_pwr";
 		regulator-min-microvolt = <3700000>;
 		regulator-max-microvolt = <3700000>;
 		regulator-always-on;
 
 		regulator-state-mem {
@@ -671,16 +687,17 @@
 };
 
 &mdss {
 	status = "okay";
 };
 
 &mdss_dp {
 	status = "okay";
+	#sound-dai-cells = <0>;
 };
 
 &mdss_dp_out {
 	data-lanes = <0 1>;
 	remote-endpoint = <&usb_1_qmpphy_dp_in>;
 };
 
 &mdss_dsi0 {
@@ -816,16 +833,18 @@
 	connector {
 		compatible = "usb-c-connector";
 
 		power-role = "dual";
 		data-role = "dual";
 		try-power-role = "sink";
 		self-powered;
 
+		vbus-supply = <&pm8150b_vbus>;
+
 		source-pdos = <PDO_FIXED(5000, 3000,
 					 PDO_FIXED_DUAL_ROLE |
 					 PDO_FIXED_USB_COMM |
 					 PDO_FIXED_DATA_SWAP)>;
 
 		sink-pdos = <PDO_FIXED(5000, 3000,
 					 PDO_FIXED_DUAL_ROLE |
 					 PDO_FIXED_USB_COMM |
@@ -852,16 +871,23 @@
 			};
 
 			port@1 {
 				reg = <1>;
 				pm8150b_typec_mux_in: endpoint {
 					remote-endpoint = <&usb_1_qmpphy_out>;
 				};
 			};
+
+			port@2 {
+				reg = <2>;
+				pm8150b_typec_sbu: endpoint {
+					remote-endpoint = <&sbu_mux_usb_con>;
+				};
+			};
 		};
 	};
 };
 
 &pm8150b_vbus {
 	regulator-min-microamp = <500000>;
 	regulator-max-microamp = <3000000>;
 	status = "okay";
@@ -930,16 +956,20 @@
 
 	dai@1 {
 		reg = <1>;
 	};
 
 	dai@2 {
 		reg = <2>;
 	};
+
+	dai@3 {
+		reg = <3>;
+	};
 };
 
 &qupv3_id_0 {
 	status = "okay";
 };
 
 &qupv3_id_1 {
 	status = "okay";
@@ -1007,16 +1037,23 @@
 
 	mm3-dai-link {
 		link-name = "MultiMedia3";
 		cpu {
 			sound-dai = <&q6asmdai  MSM_FRONTEND_DAI_MULTIMEDIA3>;
 		};
 	};
 
+	mm4-dai-link {
+		link-name = "MultiMedia4";
+		cpu {
+			sound-dai = <&q6asmdai  MSM_FRONTEND_DAI_MULTIMEDIA4>;
+		};
+	};
+
 	wcd-playback-dai-link {
 		link-name = "WCD Playback";
 		cpu {
 			sound-dai = <&q6afedai RX_CODEC_DMA_RX_0>;
 		};
 		codec {
 			sound-dai = <&wcd938x 0>, <&swr1 0>, <&rxmacro 0>;
 		};
@@ -1047,16 +1084,29 @@
 
 		codec {
 			sound-dai = <&wcd938x 1>, <&swr2 0>, <&txmacro 0>;
 		};
 		platform {
 			sound-dai = <&q6routing>;
 		};
 	};
+
+	displayport-dai-link {
+		link-name = "DisplayPort Playback";
+		cpu {
+			sound-dai = <&q6afedai DISPLAY_PORT_RX>;
+		};
+		codec {
+			sound-dai = <&mdss_dp>;
+		};
+		platform {
+			sound-dai = <&q6routing>;
+		};
+	};
 };
 
 &swr0 {
 	status = "okay";
 
 	left_spkr: speaker@0,1 {
 		compatible = "sdw10217201000";
 		reg = <0 1>;
diff --git a/projects/ROCKNIX/devices/SM8250/patches/linux/0011-qcom-pm8150b-charger.patch b/projects/ROCKNIX/devices/SM8250/patches/linux/0011-qcom-pm8150b-charger.patch
index d84d62840c..dd676bdfe7 100644
--- a/projects/ROCKNIX/devices/SM8250/patches/linux/0011-qcom-pm8150b-charger.patch
+++ b/projects/ROCKNIX/devices/SM8250/patches/linux/0011-qcom-pm8150b-charger.patch
@@ -1668,23 +1668,23 @@ diff -rupbN linux.orig/drivers/power/supply/qcom_pm8150b_charger.c linux/drivers
 +#define DCP_CURRENT_UA			3300000
 +#define CURRENT_MAX_UA			DCP_CURRENT_UA
 +
 +/* pmi8150b registers represent current in increments of 1/40th of an amp */
 +#define CURRENT_SCALE_FACTOR		50000
 +/* clang-format on */
 +
 +enum charger_status {
-+	TRICKLE_CHARGE = 0,
++	INHIBIT_CHARGE = 0,
++	TRICKLE_CHARGE,
 +	PRE_CHARGE,
-+	FAST_CHARGE,
 +	FULLON_CHARGE,
 +	TAPER_CHARGE,
 +	TERMINATE_CHARGE,
-+	INHIBIT_CHARGE,
++	PAUSE_CHARGE,
 +	DISABLE_CHARGE,
 +};
 +
 +struct smb5_register {
 +	u16 addr;
 +	u8 mask;
 +	u8 val;
 +};
@@ -1815,31 +1815,31 @@ diff -rupbN linux.orig/drivers/power/supply/qcom_pm8150b_charger.c linux/drivers
 +	rc = regmap_bulk_read(chip->regmap,
 +			      chip->base + BATTERY_CHARGER_STATUS_1, &stat, 2);
 +	if (rc < 0) {
 +		dev_err(chip->dev, "Failed to read charging status ret=%d\n",
 +			rc);
 +		return rc;
 +	}
 +
-+	if (stat[1] & VBATT_GTET_INHIBIT_BIT) {
++	if (stat[1] & CHARGER_ERROR_STATUS_BAT_OV_BIT) {
 +		*val = POWER_SUPPLY_STATUS_NOT_CHARGING;
 +		return 0;
 +	}
 +
 +	stat[0] = stat[0] & BATTERY_CHARGER_STATUS_MASK;
 +
 +	switch (stat[0]) {
 +	case TRICKLE_CHARGE:
 +	case PRE_CHARGE:
-+	case FAST_CHARGE:
 +	case FULLON_CHARGE:
 +	case TAPER_CHARGE:
 +		*val = POWER_SUPPLY_STATUS_CHARGING;
 +		return rc;
++	case PAUSE_CHARGE:
 +	case DISABLE_CHARGE:
 +		*val = POWER_SUPPLY_STATUS_NOT_CHARGING;
 +		return rc;
 +	case TERMINATE_CHARGE:
 +	case INHIBIT_CHARGE:
 +		*val = POWER_SUPPLY_STATUS_FULL;
 +		return rc;
 +	default:
diff --git a/projects/ROCKNIX/devices/SM8250/patches/linux/0019-drm-msm-dp-on-sm8250-refuse-to-start-dp-audio-while-the-link-is-down.patch b/projects/ROCKNIX/devices/SM8250/patches/linux/0019-drm-msm-dp-on-sm8250-refuse-to-start-dp-audio-while-the-link-is-down.patch
new file mode 100644
index 0000000000..d08282286e
--- /dev/null
+++ b/projects/ROCKNIX/devices/SM8250/patches/linux/0019-drm-msm-dp-on-sm8250-refuse-to-start-dp-audio-while-the-link-is-down.patch
@@ -0,0 +1,105 @@
+From 0000000000000000000000000000000000000000 Mon Sep 17 00:00:00 2001
+From: Philippe Simons <simons.philippe@gmail.com>
+Date: Wed, 30 Sep 2026 22:55:55 +0200
+Subject: [PATCH] drm/msm/dp: on SM8250, refuse to start DP audio while the
+ link is down
+
+msm_dp implements dp_audio_prepare and dp_audio_shutdown but not
+dp_audio_startup, so opening the DP PCM always succeeds, and since
+d858770e86e7 prepare succeeds with the cable unplugged too. The stream
+then goes on to start the DSP's DP port. On SM8250 (q6afe) the DSP does
+not answer that first AFE_PORT_CMD_DEVICE_START on port 0x6020 at all:
+the open blocks for q6afe's 3 s timeout (-110), and only the retry gets
+an immediate "not ready" (-22).
+
+PipeWire's profile probe opens the DP PCM five times, so on a board with
+nothing plugged into USB-C every boot lost ~16 s before any sound came
+up (measured on a MANGMI Pocket Max: sinks at ~33 s instead of ~16.5 s).
+
+On SM8250, fail the open in startup instead, with the same link-state
+test prepare already uses to avoid unclocked access. It never reaches
+the DSP, which is what the downstream DP audio codec does: its startup
+asks the display driver for cable status and returns -ENODEV when
+nothing is connected (msm_ext_disp_audio_codec_rx_dai_startup, msm-4.19
+techpack/audio).
+
+Scoped to the "qcom,sm8250-dp" compatible. The AudioReach SoCs do not
+stall on an unplugged open, and failing it there would bring back the
+dummy-sink behaviour d858770e86e7 removed from prepare, for no gain.
+
+hdmi_codec_startup() returns before marking the codec busy, so a
+refused open leaves no state behind.
+
+Written here, never posted.
+---
+ drivers/gpu/drm/msm/dp/dp_audio.c | 23 +++++++++++++++++++++++
+ drivers/gpu/drm/msm/dp/dp_audio.h |  2 ++
+ drivers/gpu/drm/msm/dp/dp_drm.c   |  1 +
+ 3 files changed, 26 insertions(+)
+
+diff --git a/drivers/gpu/drm/msm/dp/dp_audio.c b/drivers/gpu/drm/msm/dp/dp_audio.c
+--- a/drivers/gpu/drm/msm/dp/dp_audio.c
++++ b/drivers/gpu/drm/msm/dp/dp_audio.c
+@@ -6,6 +6,7 @@
+ 
+ #define pr_fmt(fmt)	"[drm-dp] %s: " fmt, __func__
+ 
++#include <linux/of.h>
+ #include <linux/platform_device.h>
+ 
+ #include <drm/display/drm_dp_helper.h>
+@@ -265,6 +266,28 @@ static struct msm_dp_audio_private *msm_dp_audio_get_data(struct msm_dp *msm_dp_
+ 	return container_of(msm_dp_audio, struct msm_dp_audio_private, msm_dp_audio);
+ }
+ 
++/*
++ * On SM8250, refuse to open a DP audio stream while the link is down. Without
++ * this the open succeeds and the stream is started on the DSP's DP port anyway,
++ * and SM8250's DSP (q6afe) does not answer that first port start at all: every
++ * open made with nothing plugged in blocks for q6afe's 3 s timeout before it
++ * fails. The downstream DP audio codec makes the same check in its startup.
++ *
++ * SM8250 only: on the AudioReach SoCs the unplugged open is harmless, and
++ * failing it there is what d858770e86e7 removed from prepare.
++ */
++int msm_dp_audio_startup(struct drm_bridge *bridge,
++			 struct drm_connector *connector)
++{
++	struct msm_dp *msm_dp_display = to_dp_bridge(bridge)->msm_dp_display;
++
++	if (!of_device_is_compatible(msm_dp_display->pdev->dev.of_node,
++				     "qcom,sm8250-dp"))
++		return 0;
++
++	return msm_dp_display->power_on ? 0 : -ENODEV;
++}
++
+ int msm_dp_audio_prepare(struct drm_bridge *bridge,
+ 			 struct drm_connector *connector,
+ 			 struct hdmi_codec_daifmt *daifmt,
+diff --git a/drivers/gpu/drm/msm/dp/dp_audio.h b/drivers/gpu/drm/msm/dp/dp_audio.h
+--- a/drivers/gpu/drm/msm/dp/dp_audio.h
++++ b/drivers/gpu/drm/msm/dp/dp_audio.h
+@@ -45,6 +45,8 @@ struct msm_dp_audio *msm_dp_audio_get(struct platform_device *pdev,
+  */
+ void msm_dp_audio_put(struct msm_dp_audio *msm_dp_audio);
+ 
++int msm_dp_audio_startup(struct drm_bridge *bridge,
++			 struct drm_connector *connector);
+ int msm_dp_audio_prepare(struct drm_bridge *bridge,
+ 			 struct drm_connector *connector,
+ 			 struct hdmi_codec_daifmt *daifmt,
+diff --git a/drivers/gpu/drm/msm/dp/dp_drm.c b/drivers/gpu/drm/msm/dp/dp_drm.c
+--- a/drivers/gpu/drm/msm/dp/dp_drm.c
++++ b/drivers/gpu/drm/msm/dp/dp_drm.c
+@@ -65,6 +65,7 @@ static const struct drm_bridge_funcs msm_dp_bridge_ops = {
+ 	.hpd_notify   = msm_dp_bridge_hpd_notify,
+ 	.debugfs_init = msm_dp_bridge_debugfs_init,
+ 
++	.dp_audio_startup = msm_dp_audio_startup,
+ 	.dp_audio_prepare = msm_dp_audio_prepare,
+ 	.dp_audio_shutdown = msm_dp_audio_shutdown,
+ };
+-- 
+2.55.0
+
diff --git a/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/AirYPro.conf b/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/AirYPro.conf
index 338e0ed1ca..edc18e19cd 100644
--- a/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/AirYPro.conf
+++ b/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/AirYPro.conf
@@ -4,16 +4,21 @@ Syntax 4
 
 Comment "Mangmi Air Y Pro"
 
 SectionUseCase."HiFi" {
 	File "/Qualcomm/sm8250/AirYPro-HiFi.conf"
 	Comment "Speakers, headphones and headset mic"
 }
 
+SectionUseCase."HDMI" {
+	File "/Qualcomm/sm8250/HDMI-RP.conf"
+	Comment "HDMI / DisplayPort Output."
+}
+
 BootSequence [
 	cset "name='WSA_RX0 Digital Volume' 120"
 	cset "name='WSA_RX1 Digital Volume' 120"
 	cset "name='SpkrLeft PA Volume' 12"
 	cset "name='SpkrRight PA Volume' 12"
 	cset "name='HPHL Volume' 20"
 	cset "name='HPHR Volume' 20"
 	cset "name='ADC2 Volume' 10"
diff --git a/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/PocketMax.conf b/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/PocketMax.conf
index 7d62bc0f8d..147ddfb6bb 100644
--- a/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/PocketMax.conf
+++ b/projects/ROCKNIX/packages/audio/alsa-ucm-conf/sources/ucm2/Qualcomm/sm8250/PocketMax.conf
@@ -4,16 +4,21 @@ Syntax 4
 
 Comment "Mangmi Pocket Max"
 
 SectionUseCase."HiFi" {
 	File "/Qualcomm/sm8250/PocketMax-HiFi.conf"
 	Comment "Speakers, headphones and headset mic"
 }
 
+SectionUseCase."HDMI" {
+	File "/Qualcomm/sm8250/HDMI-RP.conf"
+	Comment "HDMI / DisplayPort Output."
+}
+
 BootSequence [
 	cset "name='WSA_RX0 Digital Volume' 120"
 	cset "name='WSA_RX1 Digital Volume' 120"
 	cset "name='SpkrLeft PA Volume' 12"
 	cset "name='SpkrRight PA Volume' 12"
 	cset "name='HPHL Volume' 20"
 	cset "name='HPHR Volume' 20"
 	cset "name='ADC2 Volume' 10"
diff --git a/projects/ROCKNIX/packages/compat/fex-emu/package.mk b/projects/ROCKNIX/packages/compat/fex-emu/package.mk
index 287d7b22d7..ba6541009b 100644
--- a/projects/ROCKNIX/packages/compat/fex-emu/package.mk
+++ b/projects/ROCKNIX/packages/compat/fex-emu/package.mk
@@ -69,16 +69,19 @@ make_target() {
   for _v in CFLAGS CXXFLAGS LDFLAGS; do
     export ${_v}="$(echo ${!_v} | sed 's/-mabi=lp64//g; s/-mtune=[^ ]*//g')"
   done
   export USER="${USER:-$(whoami)}"
   export HOME=${PKG_BUILD}/nix
   curl -L https://nixos.org/nix/install | sh -s -- --no-daemon
   . "${HOME}/.nix-profile/etc/profile.d/nix.sh"
 
+  #Pin for monthly revert after bumping gcc
+  export NIX_PATH="nixpkgs=https://github.com/NixOS/nixpkgs/archive/b6018f87da91d19d0ab4cf979885689b469cdd41.tar.gz"
+
   mkdir -p "${PKG_BUILD}/.${TARGET_NAME}"
   cd "${PKG_BUILD}/.${TARGET_NAME}"
 
   case ${TARGET_CPU} in
     cortex-x3|cortex-x4)
       TUNE_CPU="cortex-a78"
       ;;
     *)
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Dolphin.ini b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Dolphin.ini
index 823db4700a..ea11e42374 100644
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Dolphin.ini
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Dolphin.ini
@@ -121,17 +121,17 @@ WiiKeyboard = False
 WiimoteContinuousScanning = False
 WiimoteEnableSpeaker = False
 RunCompareServer = False
 RunCompareClient = False
 EmulationSpeed = 1.00000000
 FrameSkip = 0x00000003
 Overclock = 1.0
 OverclockEnable = False
-GFXBackend = Vulkan
+GFXBackend = OGL
 GPUDeterminismMode = auto
 PerfMapDir = 
 AutoDiscChange = True
 [Movie]
 PauseMovie = False
 Author = 
 DumpFrames = False
 DumpFramesSilent = False
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/GamecubeControllerProfiles b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/GamecubeControllerProfiles
index adef25610d..afefcdedd8 120000
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/GamecubeControllerProfiles
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/GamecubeControllerProfiles
@@ -1 +1 @@
-../InputPlumber/GamecubeControllerProfiles
\ No newline at end of file
+../controllers/GamecubeControllerProfiles
\ No newline at end of file
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Hotkeys.ini b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Hotkeys.ini
index d65ca4e2bd..de694e6ad3 120000
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Hotkeys.ini
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/Hotkeys.ini
@@ -1 +1 @@
-../InputPlumber/Hotkeys.ini
\ No newline at end of file
+../controllers/Hotkeys.ini
\ No newline at end of file
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/WiiControllerProfiles b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/WiiControllerProfiles
index d0c169d967..d789730540 120000
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/WiiControllerProfiles
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/config/GENERIC_X64/WiiControllerProfiles
@@ -1 +1 @@
-../InputPlumber/WiiControllerProfiles
\ No newline at end of file
+../controllers/WiiControllerProfiles
\ No newline at end of file
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk
index f09cfc3308..beef5706a2 100644
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk
@@ -1,17 +1,17 @@
 # SPDX-License-Identifier: GPL-2.0
 # Copyright (C) 2024-present ROCKNIX (https://github.com/ROCKNIX)
 
 PKG_NAME="dolphin-sa"
 PKG_VERSION="6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4" #2606
 PKG_LICENSE="GPL-2.0-or-later"
 PKG_SITE="https://github.com/dolphin-emu/dolphin"
 PKG_URL="${PKG_SITE}.git"
-PKG_DEPENDS_TARGET="toolchain libevdev libdrm ffmpeg zlib libpng lzo libusb zstd ecm openal-soft pulseaudio alsa-lib libfmt hidapi curl SDL3 qt6"
+PKG_DEPENDS_TARGET="toolchain libevdev libdrm ffmpeg zlib libpng lzo libusb zstd ecm openal-soft pulseaudio alsa-lib libfmt hidapi curl SDL3 qt6 Python3"
 PKG_LONGDESC="Dolphin is a GameCube / Wii / Triforce emulator, allowing you to play games for these two platforms on PC with improvements. "
 
 PKG_DOLPHIN_VERSION_MAJOR="2606"
 PKG_DOLPHIN_VERSION_MINOR="1"
 
 if [ "${OPENGL_SUPPORT}" = "yes" ]; then
   PKG_DEPENDS_TARGET+=" ${OPENGL} glu libglvnd"
   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_EGL=ON"
@@ -36,16 +36,22 @@ if [ "${VULKAN_SUPPORT}" = "yes" ]; then
   PKG_DEPENDS_TARGET+=" ${VULKAN}"
   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_VULKAN=ON"
   GRENDERER="Vulkan"
 else
   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_VULKAN=OFF"
   GRENDERER="OGL"
 fi
 
+# The developer VM has Vulkan headers/loader but no guest Vulkan ICD.
+# Keep both compiled backends; automatic launches use its working GL path.
+if [ "${DEVICE}" = "GENERIC_X64" ]; then
+  GRENDERER="OGL"
+fi
+
 # Every device builds both frontends: nogui plays games, Qt provides the settings
 # UI from the Tools menu. RetroAchievements lives in Core (AchievementManager) and
 # is driven entirely by RetroAchievements.ini, so it is not tied to either one.
 PKG_CMAKE_OPTS_TARGET+=" -DENABLE_QT=ON \
                          -DUSE_RETRO_ACHIEVEMENTS=ON \
                          -DENABLE_HEADLESS=OFF \
                          -DCMAKE_EXE_LINKER_FLAGS=-flto=$(nproc) \
                          -DCMAKE_BUILD_TYPE=Release \
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh
index 33dc5b68e6..0726d34c0e 100755
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh
@@ -29,16 +29,17 @@ fi
 
 # Check if api token is present in system.cfg
 if [ -z "${token}" ]; then
     echo "RetroAchievements token is empty, please log in with your RetroAchievements credentials in Emulation Station." > ${LOG_FILE}
     exit 1
 fi
 
 # Set hardcore mode
+hardcore_raw="${hardcore}"
 if [ "${hardcore}" = 1 ]; then
   hardcore="True"
 else
   hardcore="False"
 fi
 
 # Set encore mode
 if [ "${encore}" = 1 ]; then
@@ -49,16 +50,49 @@ fi
 
 # Set unofficial mode
 if [ "${unofficial}" = 1 ]; then
   unofficial="True"
 else
   unofficial="False"
 fi
 
+# The offline toggle routes only a known casual session to a listening proxy
+# (#584, D-RA-002). Keep the configured custom host for every fallback; never
+# change saved settings or credentials here. An empty/unknown hardcore read
+# is not permission to use a service that cannot queue hardcore awards.
+# Dolphin2606 passes HostUrl to rc_client_set_host; its bundled rcheevos adds
+# http:// to a host without a scheme. The bare host below therefore uses HTTP.
+# Match PPSSPP's read-only IPv4-capable listener check (0 listening, 1 absent,
+# 2 unreadable). A listening socket is not proof of proxy identity or readiness.
+proxy_listening() {
+  local proc="${RAOFFLINEPROXY_PROC_NET:-/proc/net}" f readable=0 sl addr rem st rest
+  for f in "${proc}/tcp" "${proc}/tcp6"; do
+    [ -r "${f}" ] || continue
+    readable=1
+    while read -r sl addr rem st rest; do
+      [ "${st}" = "0A" ] || continue
+      case "${addr}" in
+        0100007F:1F90|00000000:1F90|0000000000000000FFFF00000100007F:1F90) return 0 ;;
+      esac
+    done < "${f}"
+  done
+  [ "${readable}" -eq 1 ] && return 1
+  return 2
+}
+
+if [ "$(get_setting "global.retroachievements.offlineproxy")" = 1 ] && [ "${hardcore_raw}" = "0" ]; then
+  proxy_listening
+  case $? in
+    0) hosturl="127.0.0.1:8080" ;;
+    1) echo "Offline RetroAchievements is on but nothing is listening on 127.0.0.1:8080; keeping the configured achievements host." >> "${LOG_FILE}" ;;
+    *) echo "Offline RetroAchievements is on but the listener tables could not be read; keeping the configured achievements host." >> "${LOG_FILE}" ;;
+  esac
+fi
+
 cat <<EOF >/storage/.config/dolphin-emu/RetroAchievements.ini
 [Achievements]
 DiscordPresenceEnabled = False
 Enabled = ${enabled}
 EncoreEnabled = ${encore}
 HardcoreEnabled = ${hardcore}
 ProgressEnabled = False
 SpectatorEnabled = False
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/dolphin-save-paths b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/dolphin-save-paths
new file mode 100755
index 0000000000..c5ac981c15
--- /dev/null
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/dolphin-save-paths
@@ -0,0 +1,346 @@
+#!/usr/bin/python3
+# SPDX-License-Identifier: GPL-2.0-or-later
+# Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
+"""Prepare Dolphin's known save links without converting retained real data."""
+import argparse
+import ctypes
+import fcntl
+import os
+from pathlib import Path
+import re
+import shutil
+import signal
+import stat
+import sys
+import tempfile
+
+REGIONS = ("EUR", "JAP", "USA")
+MAX_COPY_FILES = 4096
+MAX_COPY_BYTES = 64 * 1024 * 1024
+
+
+# The first line is a fixed ownership discriminator consumed by runemu, not UI.
+ERROR_OWNER = "DOLPHIN DID NOT START"
+MESSAGES_FR = {
+    'Existing Dolphin data needs attention. Back up these locations, then use the file manager to choose and arrange the saved data before trying again. No saved data was removed.':
+        'Les données Dolphin existantes nécessitent votre attention. Sauvegardez ces emplacements, puis utilisez le gestionnaire de fichiers pour choisir et organiser les données à conserver avant de réessayer. Aucune donnée sauvegardée n’a été supprimée.',
+    'Dolphin storage path is outside its expected root.':
+        'L’emplacement de stockage Dolphin se trouve hors du dossier prévu.',
+    'Dolphin save storage is not writable. Check the game storage and folder permissions, then try again.':
+        'Impossible d’écrire dans le stockage des sauvegardes Dolphin. Vérifiez le stockage des jeux et les permissions des dossiers, puis réessayez.',
+    'Game storage is not ready. Reconnect it and try again. No saved data was removed.':
+        'Le stockage des jeux n’est pas prêt. Reconnectez-le et réessayez. Aucune donnée sauvegardée n’a été supprimée.',
+    'A Dolphin save path is separately mounted. Check the storage layout before trying again.':
+        'Un emplacement de sauvegarde Dolphin possède un montage distinct. Vérifiez l’organisation du stockage avant de réessayer.',
+    "Dolphin's retained GC resources exceed the preparation limit. Arrange them in the file manager before trying again.":
+        'Les ressources GameCube conservées dépassent la limite de préparation. Organisez-les dans le gestionnaire de fichiers avant de réessayer.',
+    'Dolphin configuration is missing. Check the installed defaults before trying again.':
+        'La configuration Dolphin est absente. Vérifiez la configuration fournie avec le système avant de réessayer.',
+    'Dolphin save preparation was interrupted. Saved data was kept. Try again.':
+        'La préparation des sauvegardes Dolphin a été interrompue. Les données sauvegardées ont été conservées. Réessayez.',
+    'Dolphin save preparation lock is unavailable. Try again after the other launch finishes.':
+        'La préparation des sauvegardes Dolphin est indisponible. Réessayez après la fin de l’autre lancement.',
+    'Dolphin save preparation is already running. Wait for it to finish, then try again.':
+        'La préparation des sauvegardes Dolphin est déjà en cours. Attendez sa fin, puis réessayez.',
+    'Dolphin could not prepare save storage. Check the storage connection and permissions, then try again. Saved data was kept.':
+        'Dolphin n’a pas pu préparer le stockage des sauvegardes. Vérifiez la connexion du stockage et les permissions, puis réessayez. Les données sauvegardées ont été conservées.',
+}
+
+
+def message_language():
+    # ES exports LANGUAGE; use the same precedence as the cloud companion page.
+    value = next((os.environ[key] for key in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG")
+                  if os.environ.get(key)), "en")
+    primary = value.split(":", 1)[0].replace("-", "_").split("_", 1)[0].split(".", 1)[0].split("@", 1)[0].lower()
+    return "fr" if primary == "fr" else "en"
+
+
+def visible_path(path):
+    # The native message wraps only at whitespace. Keep this known long card
+    # path intact except for a display line break at its final slash.
+    prefix = "/storage/.config/dolphin-emu/GC/"
+    leaf = path.removeprefix(prefix)
+    if path.startswith(prefix) and re.fullmatch(r"MemoryCard[AB]\.(EUR|JAP|USA)\.raw", leaf):
+        return prefix + "\n" + leaf
+    return path
+
+
+def visible_error(message):
+    language = message_language()
+    title = "DOLPHIN N’A PAS DÉMARRÉ" if language == "fr" else "DOLPHIN DID NOT START"
+    # Translate only the known sentence, never player data paths below it.
+    sentence, separator, paths = message.partition("\n")
+    if language == "fr":
+        sentence = MESSAGES_FR.get(sentence, sentence)
+    paths = "\n".join(visible_path(path) for path in paths.split("\n"))
+    return title + "\n\n" + sentence + separator + paths + "\n"
+
+
+class Refused(Exception):
+    pass
+
+
+def kind(path):
+    try:
+        mode = path.lstat().st_mode
+    except FileNotFoundError:
+        return "absent"
+    if stat.S_ISLNK(mode):
+        return "link"
+    if stat.S_ISDIR(mode):
+        return "dir"
+    if stat.S_ISREG(mode):
+        return "file"
+    return "other"
+
+
+def link_target(path):
+    return Path(os.path.abspath(path.parent / os.readlink(path)))
+
+
+def reject(path, destination=None):
+    detail = "\n" + str(path)
+    if destination is not None:
+        detail += "\n" + str(destination)
+    raise Refused("Existing Dolphin data needs attention. Back up these locations, then use the file manager "
+                  "to choose and arrange the saved data before trying again. No saved data was removed." + detail)
+
+
+def directories(path, boundary):
+    # Missing descendants are fine; existing parents must not redirect traversal.
+    if not path.is_relative_to(boundary):
+        raise Refused("Dolphin storage path is outside its expected root.")
+    for item in (boundary, *reversed(path.relative_to(boundary).parents)):
+        if item == boundary:
+            current = boundary
+        else:
+            current = boundary / item
+        if kind(current) not in ("dir", "absent"):
+            reject(current)
+    if kind(path) not in ("dir", "absent"):
+        reject(path)
+
+
+def mounts():
+    result = set()
+    for line in Path("/proc/self/mountinfo").read_text().splitlines():
+        field = line.split()[4]
+        result.add(Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field)))
+    return result
+
+
+def writable(path):
+    current = path
+    while kind(current) == "absent":
+        current = current.parent
+    # Mode check also catches a read-only player directory when the launcher is root.
+    mode = current.stat().st_mode
+    if not mode & 0o222 or not os.access(current, os.W_OK):
+        raise Refused("Dolphin save storage is not writable. Check the game storage and folder permissions, then try again.\n" + str(path))
+
+
+def plan(storage, system):
+    conf = storage / ".config/dolphin-emu"
+    roms = storage / "roms"
+    shared = storage / ".local/share/dolphin-emu"
+    mounted = mounts()
+    if kind(storage) != "dir" or kind(roms) != "dir" or roms not in mounted:
+        raise Refused("Game storage is not ready. Reconnect it and try again. No saved data was removed.")
+    for path in (conf, roms / "savestates", roms / "bios/GC", shared.parent):
+        directories(path, storage)
+    # Do not rewrite a save path hidden behind a nested/bind mount.
+    for mount in mounted:
+        if any(mount == path or path in mount.parents for path in (conf, shared, roms / "savestates", roms / "bios")):
+            raise Refused("A Dolphin save path is separately mounted. Check the storage layout before trying again.\n" + str(mount))
+    directories(conf / "GC", storage)
+    for temporary in (roms / "bios/.GC.dolphin-new", roms / "bios/GC/.Triforce.dolphin-new"):
+        if kind(temporary) != "absent":
+            reject(temporary)
+    links = [(conf / "StateSaves", roms / "savestates" / system,
+              (roms / "savestates/gamecube", roms / "savestates/wii")),
+             (shared, conf, (conf,))]
+    dirs = [roms / "savestates" / system, roms / "bios/GC", conf / "GC", shared.parent]
+    for name in ("gamecube", "wii"):
+        directories(roms / "savestates" / name, storage)
+    for region in REGIONS:
+        canonical = roms / "bios/GC" / region
+        directories(canonical, storage)
+        dirs.append(canonical)
+        links.append((conf / "GC" / region, canonical, (canonical,)))
+        for slot in ("A", "B"):
+            card = "MemoryCard" + slot + "." + region + ".raw"
+            canonical = roms / "bios/GC" / card
+            if kind(canonical) not in ("absent", "file"):
+                reject(canonical)
+            if kind(canonical) == "file":
+                writable(canonical)
+            links.append((conf / "GC" / card, canonical, (canonical,)))
+    directories(conf / "GC", storage)
+    directories(roms / "bios/GC/Triforce", storage)
+    for source, destination, allowed in links:
+        value = kind(source)
+        if value == "link":
+            if link_target(source) not in allowed:
+                reject(source, destination)
+        elif value != "absent":
+            # A real StateSaves tree has no reliable GC/Wii ownership tag. Even
+            # equal-looking region/card copies need an explicit retention choice.
+            reject(source, destination)
+    pending = conf / ".dolphin-state-link"
+    if kind(pending) != "absent" and (kind(pending) != "link" or link_target(pending) not in links[0][2]):
+        reject(pending, conf / "StateSaves")
+    for path in (*dirs, conf, shared.parent):
+        writable(path)
+    return conf, roms, dirs, links, pending
+
+
+def copy_new_tree(source, target, skip=()):
+    # Historical GC/Triforce seeding is copy-only and only to an absent target.
+    # A killed copy leaves one reserved stage and refuses retry until reviewed.
+    # Canonical data is never replaced, and the original config tree stays intact.
+    # Shipped resources are real files; refuse retained redirects before copying.
+    if kind(source) == "absent":
+        target.mkdir()
+        return
+    if kind(source) != "dir":
+        reject(source, target)
+    count = total = 0
+    def unreadable(error):
+        raise error
+
+    for base, dirs, files in os.walk(source, followlinks=False, onerror=unreadable):
+        if Path(base) == source:
+            dirs[:] = [name for name in dirs if name not in skip]
+            files = [name for name in files if name not in skip]
+        for name in dirs + files:
+            path = Path(base) / name
+            if kind(path) not in ("dir", "file"):
+                reject(path, target)
+            count += 1
+            if kind(path) == "file":
+                total += path.lstat().st_size
+            if count > MAX_COPY_FILES or total > MAX_COPY_BYTES:
+                raise Refused("Dolphin's retained GC resources exceed the preparation limit. Arrange them in the file manager before trying again.")
+    temporary = target.parent / ("." + target.name + ".dolphin-new")
+    temporary.mkdir(mode=0o700)
+    owned = temporary.lstat()
+    try:
+        shutil.copytree(source, temporary, symlinks=True, dirs_exist_ok=True,
+                        ignore=lambda base, names: set(skip) if Path(base) == source else set())
+        rename(temporary, target, 1)  # RENAME_NOREPLACE: canonical data wins a race.
+    finally:
+        if kind(temporary) != "absent":
+            current = temporary.lstat()
+            if (current.st_dev, current.st_ino) != (owned.st_dev, owned.st_ino) or kind(temporary) != "dir":
+                reject(temporary)
+            if any(m == temporary or temporary in m.parents for m in mounts()):
+                reject(temporary)
+            shutil.rmtree(temporary)  # Only this invocation's private, unactivated copy.
+
+
+def rename(first, second, flags):
+    libc = ctypes.CDLL(None, use_errno=True)
+    operation = libc.renameat2
+    operation.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
+    operation.restype = ctypes.c_int
+    if operation(-100, os.fsencode(first), -100, os.fsencode(second), flags):
+        raise OSError(ctypes.get_errno(), "Could not switch Dolphin's save-state link")
+
+
+def apply(storage, system):
+    conf, roms, dirs, links, pending = plan(storage, system)
+    if kind(conf) != "dir":
+        raise Refused("Dolphin configuration is missing. Check the installed defaults before trying again.")
+    # Seed only an absent GC root, retaining the existing launchers' resource copy.
+    (roms / "bios").mkdir(exist_ok=True)
+    if kind(roms / "bios/GC") == "absent":
+        managed = (*REGIONS, *("MemoryCard" + slot + "." + region + ".raw"
+                              for region in REGIONS for slot in ("A", "B")))
+        copy_new_tree(conf / "GC", roms / "bios/GC", skip=managed)
+    if system == "gamecube" and kind(roms / "bios/GC/Triforce") == "absent":
+        copy_new_tree(conf / "GC/Triforce", roms / "bios/GC/Triforce")
+    for directory in dirs:
+        directory.mkdir(parents=True, exist_ok=True)
+    if kind(pending) == "link":
+        if link_target(pending) not in links[0][2]:
+            reject(pending, conf / "StateSaves")
+        pending.unlink()  # Only a recognized leftover symlink; never its target.
+    for source, destination, allowed in links:
+        value = kind(source)
+        if value == "absent":
+            source.symlink_to(destination)  # Exclusive creation; never overwrites a racing entry.
+        elif value == "link" and link_target(source) == destination:
+            continue
+        elif source == conf / "StateSaves" and value == "link" and link_target(source) in allowed:
+            previous = source.lstat()
+            pending.symlink_to(destination)
+            rename(pending, source, 2)  # RENAME_EXCHANGE keeps the displaced object.
+            moved = pending.lstat()
+            if (moved.st_dev, moved.st_ino) != (previous.st_dev, previous.st_ino) or kind(pending) != "link":
+                # Keep the unexpected object; do not delete data moved by a race.
+                # Refusal identifies the reserved path for explicit recovery.
+                reject(pending, source)
+            pending.unlink()
+        else:
+            reject(source, destination)
+
+
+def write_error(path, message):
+    # ES already consumes this native launch-error file on exit 250.
+    fd, temporary = tempfile.mkstemp(prefix=".dolphin-launch-error-", dir=path.parent)
+    try:
+        with os.fdopen(fd, "w", encoding="utf-8", errors="backslashreplace") as stream:
+            stream.write(ERROR_OWNER + "\n" + visible_error(message))
+        os.replace(temporary, path)
+    finally:
+        if os.path.lexists(temporary):
+            os.unlink(temporary)
+
+
+def interrupted(signum, frame):
+    raise Refused("Dolphin save preparation was interrupted. Saved data was kept. Try again.")
+
+
+def main():
+    parser = argparse.ArgumentParser(description=__doc__)
+    parser.add_argument("phase", choices=("check", "prepare"))
+    parser.add_argument("system", choices=("gamecube", "wii"))
+    parser.add_argument("--storage", type=Path, default=Path("/storage"))
+    parser.add_argument("--lock", type=Path, default=Path("/run/dolphin-save-paths.lock"))
+    parser.add_argument("--error-file", type=Path, default=Path("/tmp/launch_error.log"))
+    args = parser.parse_args()
+    try:
+        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
+            signal.signal(sig, interrupted)
+        signal.alarm(30)
+        storage = Path(os.path.abspath(args.storage))
+        fd = os.open(args.lock, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
+        try:
+            if not stat.S_ISREG(os.fstat(fd).st_mode):
+                raise Refused("Dolphin save preparation lock is unavailable. Try again after the other launch finishes.")
+            try:
+                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
+            except BlockingIOError:
+                raise Refused("Dolphin save preparation is already running. Wait for it to finish, then try again.") from None
+            if args.phase == "check":
+                plan(storage, args.system)
+            else:
+                apply(storage, args.system)
+        finally:
+            os.close(fd)
+        return 0
+    except Exception as error:
+        message = str(error) if isinstance(error, Refused) else "Dolphin could not prepare save storage. Check the storage connection and permissions, then try again. Saved data was kept."
+        print(message, file=sys.stderr)
+        print("Dolphin preparation detail: " + str(error), file=sys.stderr)
+        try:
+            write_error(args.error_file, message)
+        except OSError:
+            print("Could not write the native launch error message.", file=sys.stderr)
+        return 250
+    finally:
+        signal.alarm(0)
+
+
+if __name__ == "__main__":
+    sys.exit(main())
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_gc.sh b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_gc.sh
index abdb449a77..fdcb087008 100755
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_gc.sh
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_gc.sh
@@ -21,16 +21,21 @@ source /storage/.config/gptokeyb/control.ini
 get_controls
 
 # Conf files vars
 CONF_DIR="/storage/.config/dolphin-emu"
 DOLPHIN_INI="Dolphin.ini"
 GFX_INI="GFX.ini"
 CONTROLLER_INI="GCPadNew.ini"
 
+# Refuse ambiguous retained save paths before any configuration preparation.
+if ! /usr/bin/python3 -I -S -B /usr/bin/dolphin-save-paths check gamecube; then
+  exit 250
+fi
+
 # Dolphin writes its shader and pipeline caches here but will not create the
 # directory itself, so an orderly shutdown had nothing to flush into.
 mkdir -p "/storage/.cache/dolphin-emu"
 
 # Check if dolphin-emu exists in .config
 if [ ! -d "${CONF_DIR}" ]; then
         cp -r "/usr/config/dolphin-emu" "/storage/.config/"
 fi
@@ -54,68 +59,27 @@ for PROFILE in east.stacked east.inline south.stacked south.inline; do
         fi
 done
 
 # Check if GC custom controller profile exists in .config/dolphin-emu/GamecubeControllerProfiles
 if [ ! -f "${CONF_DIR}/GamecubeControllerProfiles/GCPadNew.ini.custom" ]; then
         cp -r "/usr/config/dolphin-emu/GamecubeControllerProfiles/GCPadNew.ini.south.stacked" "${CONF_DIR}/GamecubeControllerProfiles/GCPadNew.ini.custom"
 fi
 
-# Link Save States to /roms/savestates/gamecube
-if [ ! -d "/storage/roms/savestates/gamecube/" ]; then
-    mkdir -p "/storage/roms/savestates/gamecube/"
-fi
-
-rm -rf ${CONF_DIR}/StateSaves
-ln -sf /storage/roms/savestates/gamecube ${CONF_DIR}/StateSaves
-
-# Copy bios, memory cards and other system stuff to roms
-if [ ! -d "/storage/roms/bios/GC/" ]; then
-    mkdir -p /storage/roms/bios/GC/{USA,JAP,EUR}
-    cp -r ${CONF_DIR}/GC /storage/roms/bios/
-fi
-
-# Create Triforce Bios folder if does not exist
-if [ ! -d "/storage/roms/bios/GC/Triforce" ]; then
-    mkdir -p /storage/roms/bios/GC/Triforce
-    cp -r ${CONF_DIR}/GC/Triforce /storage/roms/bios/GC/
+# Prepare only known save links; retained real data requires an explicit choice.
+if ! /usr/bin/python3 -I -S -B /usr/bin/dolphin-save-paths prepare gamecube; then
+  exit 250
 fi
 
 # Make sure all Triforce Gecko codes are copied to GameSettings
 for f in /usr/config/dolphin-emu/triforce_gecko_codes/*; do
   [ -e "/storage/.config/dolphin-emu/GameSettings/$(basename "$f")" ] || cp -fH "$f" "/storage/.config/dolphin-emu/GameSettings/"
 done
 rm -rf "/storage/.config/dolphin-emu/triforce_gecko_codes"
 
-# Link bios and memory cards to roms
-for REGION in EUR JAP USA
-do
-  # Link bios
-  rm -rf "${CONF_DIR}/GC/${REGION}"
-  ln -sf "/storage/roms/bios/GC/${REGION}" "${CONF_DIR}/GC/${REGION}"
-
-  # Link memory cards, copying to roms/bios first as needed
-  for SLOT in A B
-  do
-    MEM_CARD_FILE="MemoryCard${SLOT}.${REGION}.raw"
-    CONFIG_MEM_CARD="${CONF_DIR}/GC/${MEM_CARD_FILE}"
-    ROMS_BIOS_MEM_CARD="/storage/roms/bios/GC/${MEM_CARD_FILE}"
-
-    if [ -f "${ROMS_BIOS_MEM_CARD}" ]; then
-      # Exists in roms/bios, remove from .config and link
-      rm -f "${CONFIG_MEM_CARD}"
-      ln -sf "${ROMS_BIOS_MEM_CARD}" "${CONFIG_MEM_CARD}"
-    elif [ -f "${CONFIG_MEM_CARD}" ]; then
-      # Only exists in .config, move to roms/bios and link
-      mv -f "${CONFIG_MEM_CARD}" "${ROMS_BIOS_MEM_CARD}"
-      ln -sf "${ROMS_BIOS_MEM_CARD}" "${CONFIG_MEM_CARD}"
-    fi
-  done
-done
-
 # Emulation Station Features
 GAME=$(echo "${1}"| sed "s#^/.*/##")
 PLATFORM=$(echo "${2}"| sed "s#^/.*/##")
 AA=$(get_setting anti_aliasing "${PLATFORM}" "${GAME}")
 ASPECT=$(get_setting aspect_ratio "${PLATFORM}" "${GAME}")
 AUDIOBE=$(get_setting audio_backend "${PLATFORM}" "${GAME}")
 ASWAPDISCS=$(get_setting auto_swap_discs "${PLATFORM}" "${GAME}")
 CLOCK=$(get_setting clock_speed "${PLATFORM}" "${GAME}")
@@ -450,19 +414,17 @@ for CFG in "${CONF_DIR}/Hotkeys.ini" "${CONF_DIR}/GCPadNew.ini" "${CONF_DIR}/Wii
            -e 's/`Button E`/`Button S`/g' \
            -e 's/`Button %`/`Button E`/g' \
            -e 's/`Button W`/`Button %`/g' \
            -e 's/`Button N`/`Button W`/g' \
            -e 's/`Button %`/`Button N`/g' "${CFG}"
   fi
 done
 
-# Link  .config/dolphin-emu to .local
-rm -rf /storage/.local/share/dolphin-emu
-ln -sf /storage/.config/dolphin-emu /storage/.local/share/dolphin-emu
+# The shared Dolphin data link was checked and prepared before settings writes.
 
 @EXPORTS@
 
 # Retroachievements
   /usr/bin/cheevos_dolphin.sh
 
 # Set video and audio backend
   CMD="${CMD} -v $GRENDERER"
diff --git a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_wii.sh b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_wii.sh
index f7b7112aae..ff68acd3cf 100755
--- a/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_wii.sh
+++ b/projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/start_dolphin_wii.sh
@@ -21,16 +21,21 @@ source /storage/.config/gptokeyb/control.ini
 get_controls
 
 # Conf files vars
 CONF_DIR="/storage/.config/dolphin-emu"
 DOLPHIN_INI="Dolphin.ini"
 GFX_INI="GFX.ini"
 GC_CONTROLLER_INI="GCPadNew.ini"
 
+# Refuse ambiguous retained save paths before any configuration preparation.
+if ! /usr/bin/python3 -I -S -B /usr/bin/dolphin-save-paths check wii; then
+  exit 250
+fi
+
 # Dolphin writes its shader and pipeline caches here but will not create the
 # directory itself, so an orderly shutdown had nothing to flush into.
 mkdir -p "/storage/.cache/dolphin-emu"
 
 # Check if dolphin-emu exists in .config
 if [ ! -d "${CONF_DIR}" ]; then
         cp -r "/usr/config/dolphin-emu" "/storage/.config/"
 fi
@@ -44,71 +49,36 @@ fi
 
 # Check if GC controller dir exists in .config/dolphin-emu/GamecubeControllerProfiles
 if [ ! -d "${CONF_DIR}/GamecubeControllerProfiles" ]; then
         cp -r "/usr/config/dolphin-emu/GamecubeControllerProfiles" "${CONF_DIR}/"
 fi
 
 # Check if Wii controller dir exists in .config/dolphin-emu/WiiControllerProfiles
 if [ ! -d "${CONF_DIR}/WiiControllerProfiles" ]; then
-        cp -r "/usr/config/dolphin-emu/WiiControllerProfiles" "${CONF_DIR}/dolphin-emu/"
+        cp -r "/usr/config/dolphin-emu/WiiControllerProfiles" "${CONF_DIR}/"
 fi
 
 # Check if Wii custom controller profile exists in .config/dolphin-emu
 if [ ! -f "${CONF_DIR}/WiiControllerProfiles/custom.ini" ]; then
         cp -r "${CONF_DIR}/WiiControllerProfiles/vremote.ini" "${CONF_DIR}/WiiControllerProfiles/custom.ini"
 fi
 
 # Gamecube controller profile needed for hotkeys to work on SA
 if [ "${DOLPHIN_CORE}" = 'dolphin-emu-nogui' ]; then
   cp -r "/storage/.config/dolphin-emu/GamecubeControllerProfiles/GCPadNew.ini.south.stacked" "/storage/.config/dolphin-emu/GCPadNew.ini"
 else
   rm -r "/storage/.config/dolphin-emu/GCPadNew.ini"
 fi
 
-# Link Save States to /roms/savestates/wii
-if [ ! -d "/storage/roms/savestates/wii/" ]; then
-    mkdir -p "/storage/roms/savestates/wii/"
-fi
-
-rm -rf ${CONF_DIR}/StateSaves
-ln -sf /storage/roms/savestates/wii ${CONF_DIR}/StateSaves
-
-# Copy bios, memory cards and other system stuff to roms
-if [ ! -d "/storage/roms/bios/GC/" ]; then
-    mkdir -p /storage/roms/bios/GC/{USA,JAP,EUR}
-    cp -r ${CONF_DIR}/GC /storage/roms/bios/
+# Prepare only known save links; retained real data requires an explicit choice.
+if ! /usr/bin/python3 -I -S -B /usr/bin/dolphin-save-paths prepare wii; then
+  exit 250
 fi
 
-# Link bios and memory cards to roms
-for REGION in EUR JAP USA
-do
-  # Link bios
-  rm -rf "${CONF_DIR}/GC/${REGION}"
-  ln -sf "/storage/roms/bios/GC/${REGION}" "${CONF_DIR}/GC/${REGION}"
-
-  # Link memory cards, copying to roms/bios first as needed
-  for SLOT in A B
-  do
-    MEM_CARD_FILE="MemoryCard${SLOT}.${REGION}.raw"
-    CONFIG_MEM_CARD="${CONF_DIR}/GC/${MEM_CARD_FILE}"
-    ROMS_BIOS_MEM_CARD="/storage/roms/bios/GC/${MEM_CARD_FILE}"
-
-    if [ -f "${ROMS_BIOS_MEM_CARD}" ]; then
-      # Exists in roms/bios, remove from .config and link
-      rm -f "${CONFIG_MEM_CARD}"
-      ln -sf "${ROMS_BIOS_MEM_CARD}" "${CONFIG_MEM_CARD}"
-    elif [ -f "${CONFIG_MEM_CARD}" ]; then
-      # Only exists in .config, move to roms/bios and link
-      mv -f "${CONFIG_MEM_CARD}" "${ROMS_BIOS_MEM_CARD}"
-      ln -sf "${ROMS_BIOS_MEM_CARD}" "${CONFIG_MEM_CARD}"
-    fi
-  done
-done
-
 # Emulation Station Features
 GAME=$(echo "${1}"| sed "s#^/.*/##")
 PLATFORM=$(echo "${2}"| sed "s#^/.*/##")
 AA=$(get_setting anti_aliasing "${PLATFORM}" "${GAME}")
 ASPECT=$(get_setting aspect_ratio "${PLATFORM}" "${GAME}")
 AUDIOBE=$(get_setting audio_backend "${PLATFORM}" "${GAME}")
 CLOCK=$(get_setting clock_speed "${PLATFORM}" "${GAME}")
 ENBCHEATS=$(get_setting enable_cheats "${PLATFORM}" "${GAME}")
@@ -413,19 +383,17 @@ for CFG in "${CONF_DIR}/Hotkeys.ini" "${CONF_DIR}/GCPadNew.ini" "${CONF_DIR}/Wii
            -e 's/`Button E`/`Button S`/g' \
            -e 's/`Button %`/`Button E`/g' \
            -e 's/`Button W`/`Button %`/g' \
            -e 's/`Button N`/`Button W`/g' \
            -e 's/`Button %`/`Button N`/g' "${CFG}"
   fi
 done
 
-# Link  .config/dolphin-emu to .local
-rm -rf /storage/.local/share/dolphin-emu
-ln -sf /storage/.config/dolphin-emu /storage/.local/share/dolphin-emu
+# The shared Dolphin data link was checked and prepared before settings writes.
 
 @EXPORTS@
 
 # Retroachievements
   /usr/bin/cheevos_dolphin.sh
 
 # Set video and audio backend
   CMD="${CMD} -v $GRENDERER"
diff --git a/projects/ROCKNIX/packages/emulators/standalone/steam/package.mk b/projects/ROCKNIX/packages/emulators/standalone/steam/package.mk
index 5d2c8b2ec4..e9aa34a4d5 100644
--- a/projects/ROCKNIX/packages/emulators/standalone/steam/package.mk
+++ b/projects/ROCKNIX/packages/emulators/standalone/steam/package.mk
@@ -2,17 +2,17 @@
 # Copyright (C) 2024-present ROCKNIX (https://github.com/ROCKNIX)
 
 PKG_NAME="steam"
 PKG_VERSION="1.0.0.85"
 PKG_SHA256="b44634a6a604ca7c8b23809d0f2a921a0348bb2081c8cb8944116d0799872b70"
 PKG_LICENSE="proprietary"
 PKG_SITE="https://steampowered.com"
 PKG_URL="https://repo.steampowered.com/steam/archive/stable/steam-launcher_${PKG_VERSION}_amd64.deb"
-PKG_DEPENDS_TARGET="fex-emu gamescope lsfg-vk nss networkmanager"
+PKG_DEPENDS_TARGET="fex-emu gamescope lsfg-vk nss networkmanager Python3"
 PKG_LONGDESC="Steam is the ultimate destination for playing, discussing, and creating games"
 PKG_TOOLCHAIN="manual"
 
 unpack() {
   mkdir -p ${PKG_BUILD}
   cd ${PKG_BUILD}
   ar x ${SOURCES}/${PKG_NAME}/steam-${PKG_VERSION}.deb
   tar -xf data.tar.xz
diff --git a/projects/ROCKNIX/packages/linux/patches/7.2/0016-drm-msm-dp-return-0-from-audio_prepare-when-cable-is-disconnected.patch b/projects/ROCKNIX/packages/linux/patches/7.2/0016-drm-msm-dp-return-0-from-audio_prepare-when-cable-is-disconnected.patch
new file mode 100644
index 0000000000..0c6ea6b5e2
--- /dev/null
+++ b/projects/ROCKNIX/packages/linux/patches/7.2/0016-drm-msm-dp-return-0-from-audio_prepare-when-cable-is-disconnected.patch
@@ -0,0 +1,31 @@
+From d858770e86e75bf78429b9f5210b7556ef431033 Mon Sep 17 00:00:00 2001
+From: Kumar Anurag <kumar.singh@oss.qualcomm.com>
+Date: Tue, 16 Jun 2026 08:12:52 -0700
+Subject: [PATCH] drm/msm/dp: return 0 from audio_prepare when cable is
+ disconnected
+
+PipeWire treats a non-zero return from prepare as fatal, marking the
+DP audio device as a dummy sink when the cable is unplugged. The
+active_stream_cnt guard already prevents any unclocked hardware access,
+so return success instead of -EINVAL when the link is not active.
+
+Upstream-Status: Backport [https://lore.kernel.org/r/20260616151252.3599089-2-kumar.singh@oss.qualcomm.com]
+---
+ drivers/gpu/drm/msm/dp/dp_audio.c | 4 +---
+ 1 file changed, 1 insertion(+), 3 deletions(-)
+
+diff --git a/drivers/gpu/drm/msm/dp/dp_audio.c b/drivers/gpu/drm/msm/dp/dp_audio.c
+--- a/drivers/gpu/drm/msm/dp/dp_audio.c
++++ b/drivers/gpu/drm/msm/dp/dp_audio.c
+@@ -284,10 +284,8 @@ int msm_dp_audio_prepare(struct drm_bridge *bridge,
+ 	 * such cases check for connection status and bail out if not
+ 	 * connected.
+ 	 */
+-	if (!msm_dp_display->power_on) {
+-		rc = -EINVAL;
++	if (!msm_dp_display->power_on)
+ 		goto end;
+-	}
+ 
+ 	audio = msm_dp_audio_get_data(msm_dp_display);
+ 	if (IS_ERR(audio)) {
diff --git a/projects/ROCKNIX/packages/multimedia/gstreamer/gstreamer/package.mk b/projects/ROCKNIX/packages/multimedia/gstreamer/gstreamer/package.mk
index 01cea8c37e..a58b8ddb45 100644
--- a/projects/ROCKNIX/packages/multimedia/gstreamer/gstreamer/package.mk
+++ b/projects/ROCKNIX/packages/multimedia/gstreamer/gstreamer/package.mk
@@ -9,38 +9,45 @@
 # only be found if something linked them in directly. So WebKit asks for
 # "appsink", the registry that would have found it does not exist, it gets
 # NULL back and segfaults dereferencing it -- killing the web process a
 # second after every page load. Shipping the plugin made no difference, and
 # neither did GST_PLUGIN_PATH, because nothing was scanning.
 #
 # Restated in full rather than patched: the generic recipe builds this string
 # inside pre_configure_target, so a substitution at global scope is
-# overwritten before configure sees it. Only -Dregistry differs from
-# upstream; keep the rest in step when rebasing.
+# overwritten before configure sees it. Registry and tools differ from
+# upstream: tools also builds the external plugin scanner (#572). Keep the
+# remaining options in step when rebasing.
 pre_configure_target() {
   PKG_MESON_OPTS_TARGET="-Dgst_debug=false \
                          -Dgst_parse=true \
                          -Dregistry=true \
                          -Dtracer_hooks=false \
                          -Doption-parsing=true \
                          -Dpoisoning=false \
                          -Dcheck=disabled \
                          -Dlibunwind=disabled \
                          -Dlibdw=disabled \
                          -Ddbghelp=disabled \
                          -Dbash-completion=disabled \
                          -Dcoretracers=disabled \
                          -Dexamples=disabled \
                          -Dtests=disabled \
                          -Dbenchmarks=disabled \
-                         -Dtools=disabled \
+                         -Dtools=enabled \
                          -Ddoc=disabled \
                          -Dintrospection=disabled \
                          -Dnls=disabled \
                          -Dglib_debug=disabled \
                          -Dglib_assert=false \
                          -Dglib_checks=false \
                          -Dextra-checks=disabled \
                          -Dpackage-name="gstreamer"
                          -Dpackage-origin="LibreELEC.tv"
                          -Ddoc=disabled"
 }
+
+post_makeinstall_target() {
+  # Keep libgstcontroller for GL and libgstnet for the installed UDP, RTP,
+  # RTSP and adaptive-demux plugins from gst-plugins-good (#572).
+  safe_remove ${INSTALL}/usr/share
+}
diff --git a/projects/ROCKNIX/packages/network/raofflineproxy/patches/020-rvz-padding-preserve-partial-word.patch b/projects/ROCKNIX/packages/network/raofflineproxy/patches/020-rvz-padding-preserve-partial-word.patch
new file mode 100644
index 0000000000..e404c33999
--- /dev/null
+++ b/projects/ROCKNIX/packages/network/raofflineproxy/patches/020-rvz-padding-preserve-partial-word.patch
@@ -0,0 +1,22 @@
+--- a/linux/raofflineproxy/rvz_datasource.py
++++ b/linux/raofflineproxy/rvz_datasource.py
+@@ -663,12 +663,16 @@
+ 
+     word_index = 0
+     bytes_to_skip = absolute_offset % _SECTOR_SIZE
++    # Keep the partial word: skipping it through the word writer would
++    # round the requested byte offset up and discard its remaining bytes.
++    leading_bytes = bytes_to_skip % 4
++    bytes_to_skip -= leading_bytes
+     if bytes_to_skip > 0:
+         word_index = _write_lagged_fibonacci_bytes(buffer, bytearray(bytes_to_skip), bytes_to_skip, word_index)
+ 
+-    output = bytearray(size)
+-    _write_lagged_fibonacci_bytes(buffer, output, size, word_index)
+-    return bytes(output)
++    output = bytearray(size + leading_bytes)
++    _write_lagged_fibonacci_bytes(buffer, output, len(output), word_index)
++    return bytes(memoryview(output)[leading_bytes:])
+ 
+ 
+ def _write_lagged_fibonacci_bytes(buffer: list, output: bytearray, byte_count: int, initial_word_index: int) -> int:
diff --git a/projects/ROCKNIX/packages/network/raofflineproxy/patches/021-flush-reconnect-during-startup.patch b/projects/ROCKNIX/packages/network/raofflineproxy/patches/021-flush-reconnect-during-startup.patch
new file mode 100644
index 0000000000..41a5bd58fe
--- /dev/null
+++ b/projects/ROCKNIX/packages/network/raofflineproxy/patches/021-flush-reconnect-during-startup.patch
@@ -0,0 +1,30 @@
+--- a/linux/raofflineproxy/proxy_service.py
++++ b/linux/raofflineproxy/proxy_service.py
+@@ -1089,6 +1089,7 @@
+         self.interval_seconds = interval_seconds
+         self.stop_event = threading.Event()
+         self.watched_inodes = _capture_file_inodes([DATABASE_FILE])
++        self.initial_online = False
+ 
+     def stop(self) -> None:
+         self.stop_event.set()
+@@ -1096,6 +1097,11 @@
+     def run(self) -> None:
+         was_online = self.server.refresh_reachability(force_probe=True)
+         save_online_state(was_online)
++        # Carry the startup observation across the first worker probe. A link
++        # returning between them must not become an unhandled online baseline.
++        if was_online and not self.initial_online and not self.stop_event.is_set():
++            LOGGER.info("Connectivity restored; attempting flush")
++            self.server.flush_pending_awards()
+         while not self.stop_event.wait(self.interval_seconds):
+             if self.watched_inodes and _files_replaced_underneath(self.watched_inodes):
+                 # A reinstall deleted our log/database out from under this
+@@ -1469,6 +1475,7 @@
+         if initial_online:
+             server.flush_pending_awards()
+             retry_storage_corruption_report(config_data)
++        connectivity_monitor.initial_online = initial_online
+         connectivity_monitor.start()
+         periodic_refresh.start()
+         cache_queue_worker.start()
diff --git a/projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-ctl b/projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-ctl
index 6c497a2c1e..58e33c9c89 100755
--- a/projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-ctl
+++ b/projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-ctl
@@ -1526,29 +1526,36 @@ def by_history(paths):
     """The played ones first, most recent first; then the rest, newest first."""
     order = {p: i for i, p in enumerate(history)}
     played = sorted((p for p in paths if str(p) in order), key=lambda p: order[str(p)])
     rest = sorted((p for p in paths if str(p) not in order), key=mtime, reverse=True)
     return played + rest
 
 
 indexed_dirs = set()
+failed_rvz_paths = set()
 indexed_seen = 0
 indexed_jobs = {}
 for name, folder in es_systems():
     if not folder.is_dir():
         continue
     index = read_index(name, folder)
     if not any(h for h, _ in index.values()):
         continue
     try:
         indexed_dirs.add(folder.resolve())
     except OSError:
         indexed_dirs.add(folder)
     for path, (hash_value, id_text) in index.items():
+        # ES uses this sentinel for a failed read, not an unmatched hash.
+        # A deliberate scan may try the proxy's independent RVZ reader.
+        # Keep valid unmatched hashes and automatic top-ups index-only.
+        if path.suffix.lower() == ".rvz" and hash_value == "0" * 32:
+            failed_rvz_paths.add(path)
+            continue
         try:
             game_id = int(id_text)
         except ValueError:
             game_id = 0
         if game_id <= 0 or not hash_value or not path.is_file():
             continue
         indexed_seen += 1
         if path in indexed_jobs or is_cached(game_id, hash_value):
@@ -1608,27 +1615,32 @@ if mode == "all":
     passed = not cursor
     before, after = [], []   # the candidates up to the cursor, and past it
     full = False
     for name in walk_systems:
         root = roms_root / name
         if not root.is_dir():
             continue
         try:
-            if root.resolve() in indexed_dirs:
-                continue
+            indexed_root = root.resolve() in indexed_dirs
         except OSError:
-            pass
+            indexed_root = root in indexed_dirs
+        # Only revisit a root that can actually contain one of the failed
+        # paths; use the same path form as the membership check in the walk.
+        if indexed_root and not any(path.is_relative_to(root) for path in failed_rvz_paths):
+            continue
         for dirpath, dirnames, filenames in os.walk(root):
             dirnames[:] = sorted(d for d in dirnames if not d.startswith(".") and d.lower() not in SKIP_DIRS)
             has_sheet = any(f.lower().endswith(DISC_SHEETS) for f in filenames)
             for fn in sorted(filenames):
                 if fn.startswith("."):
                     continue
                 path = Path(dirpath) / fn
+                if indexed_root and path not in failed_rvz_paths:
+                    continue
                 at_cursor = not passed and str(path) == cursor
                 # Before the cursor only the first cap's worth is ever
                 # taken (the circle's tail), so past that the walk only
                 # looks for the cursor.
                 if not passed and len(before) > MAX_SCAN_ENTRIES:
                     passed = passed or at_cursor
                     continue
                 take = False
diff --git a/projects/ROCKNIX/packages/network/rclone/sources/cloud_oauth b/projects/ROCKNIX/packages/network/rclone/sources/cloud_oauth
index a611ebf2aa..78c343771a 100755
--- a/projects/ROCKNIX/packages/network/rclone/sources/cloud_oauth
+++ b/projects/ROCKNIX/packages/network/rclone/sources/cloud_oauth
@@ -43,16 +43,17 @@
 # The listener binds the LAN only while a sign-in is running, times out on its
 # own, and requires a PIN shown on the handheld -- so reaching it takes the
 # device in your hands, not merely a seat on the wifi.
 
 import contextlib
 import errno
 import fcntl
 import hashlib
+import html
 import http.server
 import itertools
 import json
 import os
 import re
 import secrets
 import select
 import shutil
@@ -99,27 +100,63 @@ def signin_language():
     """
     value = next((os.environ[key] for key in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG")
                   if os.environ.get(key)), "en")
     primary = value.split(":", 1)[0].replace("-", "_").split("_", 1)[0].split(".", 1)[0].lower()
     return "fr" if primary == "fr" else "en"
 
 
 def phone_page(name, pin):
-    page = REMOTE_PAGE % {"style": STYLE, "name": name, "pin": pin}
+    # Translate the template before inserting the service name: names are
+    # data even if they happen to contain one of the English UI strings.
+    page = REMOTE_PAGE
     if signin_language() == "fr":
         for before, after in (
+            ('<html lang=en>', '<html lang=fr>'),
+            ('var phoneLanguage = "en";', 'var phoneLanguage = "fr";'),
+            ('<title>Keyboard for ', '<title>Clavier pour '),
+            ('<h1 title="Keyboard for ', '<h1 title="Clavier pour '),
+            ('">Keyboard for ', '">Clavier pour '),
+            ('Checking connection', 'Vérification de la connexion'),
+            ('id=status-hide>Hide status', 'id=status-hide>Masquer l’état'),
+            ('placeholder="Type here"', 'placeholder="Saisissez ici"'),
+            ('aria-label="Text to type on your handheld"',
+             'aria-label="Texte à saisir sur votre console"'),
+            ('aria-label="Backspace">Back', 'aria-label="Effacer un caractère">⌫'),
+            ('data-key=tab>Tab', 'data-key=tab aria-label="Tabulation">Tab'),
+            ('aria-label="Enter">Enter', 'aria-label="Entrée">↵'),
+            ('id=clear>Clear', 'id=clear>Vider'),
+            ('id=show>Show', 'id=show>Voir'),
+            ('aria-label="Left arrow"', 'aria-label="Flèche gauche"'),
+            ('aria-label="Up arrow"', 'aria-label="Flèche haut"'),
+            ('aria-label="Down arrow"', 'aria-label="Flèche bas"'),
+            ('aria-label="Right arrow"', 'aria-label="Flèche droite"'),
+            ('data-key=f2>Page up',
+             'data-key=f2 aria-label="Faire défiler vers le haut">Monter'),
+            ('data-key=f3>Page down',
+             'data-key=f3 aria-label="Faire défiler vers le bas">Descendre'),
+            ('<h2>Pointer</h2>', '<h2>Pointeur</h2>'),
+            ('drag to move &middot; tap to click',
+             'glissez pour déplacer · touchez pour cliquer'),
+            ('The sign-in page is on your handheld&rsquo;s screen, not here.\n'
+             'This types for it, so you can more easily retrieve and type your login\n'
+             'info. What you type crosses your network unencrypted, so use this on a\n'
+             'network you trust.',
+             'La page de connexion est sur l’écran de votre console, pas ici.\n'
+             'Ce clavier vous permet d’y saisir vos identifiants plus facilement.\n'
+             'Le texte saisi traverse votre réseau sans chiffrement. Utilisez\n'
+             'un réseau de confiance.'),
             ("id=leave-ask>Close page", "id=leave-ask>Fermer la page"),
             ("<span>Close the sign-in page on your handheld?</span>",
              "<span>Fermer la page de connexion sur votre console ?</span>"),
             ("id=leave-keep>Keep", "id=leave-keep>Garder ouverte"),
             ("id=leave-close>Close", "id=leave-close>Fermer"),
         ):
             page = page.replace(before, after)
-    return page
+    return page % {"style": STYLE, "name": html.escape(name, quote=True), "pin": pin}
 
 
 # session.json is written by three threads of the serve (the collector, the
 # request handlers, the main thread) and read by other processes (`status`,
 # `info`, the interface). It was truncated and rewritten in place, and
 # read_state turns a half-written file into {} -- a status that read idle
 # for a moment while a sign-in was completing, and a merge that could write
 # that emptiness back (#308 claude F-RS-23, gpt F-RS-17). So: one writer at
@@ -622,19 +659,33 @@ input{width:100%;padding:12px;font-size:16px;border-radius:8px;border:1px solid
 input.pin{font-size:24px;letter-spacing:.5em;text-align:center;
           width:7ch;max-width:100%;padding-left:.6em}
 form.narrow{text-align:center}
 form.narrow button{width:auto;min-width:9rem}
 button{margin-top:10px;padding:12px 20px;font-size:16px;border-radius:8px;
        border:0;background:#4af;color:#000;font-weight:600;width:100%}
 button.minor{background:#333;color:#ddd;font-weight:500}
 .note{color:#aaa;font-size:.9rem}
-/* The connection line sits between the heading and the field; without
-   margins of its own it read as part of both (fork #351). */
-#state{margin:.75rem 0}
+/* Status has a fixed slot. Its details float over the page, so neither a
+   navigation nor a failure moves the typing field or pointer (fork #571). */
+.phone-header{position:relative;display:flex;align-items:center;gap:12px;
+              height:44px;margin-bottom:12px}
+.phone-header h1{flex:1;min-width:0;margin:0;overflow:hidden;
+                 white-space:nowrap;text-overflow:ellipsis}
+#state{flex:0 0 44px;width:44px;height:44px;margin:0;padding:0;
+       font-size:24px;line-height:1;background:#333;color:#ffd479}
+#state[data-kind=connected]{color:#9f9}
+#state[data-kind=disconnected]{color:#fff}
+#state:focus-visible{outline:2px solid #4af;outline-offset:2px}
+#status-panel{position:absolute;z-index:2;top:52px;left:0;right:0;
+              background:#242424;border:1px solid #888;border-radius:8px;
+              padding:12px;box-shadow:0 4px 12px #000;max-height:60vh;overflow:auto}
+#status-message{margin:0;overflow-wrap:anywhere}
+.status-live{position:absolute;width:1px;height:1px;padding:0;margin:-1px;
+             overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
 /* The way off the handheld's page lives at the very bottom, under the note,
    with room above it, so a drag on the pad that runs off its edge lands
    on text and not on Close (fork #351, D-CLOUD-163). Its two-step
    confirmation replaces the row in place. */
 [hidden]{display:none!important}
 .leave{margin-top:2rem}
 .leave .ask{display:flex;gap:8px;align-items:center}
 .leave .ask span{flex:1 1 auto;color:#aaa;font-size:.9rem}
@@ -645,16 +696,18 @@ button.minor{background:#333;color:#ddd;font-weight:500}
 .big{font-size:1.6rem;text-align:center;margin:1rem 0}
 /* Five buttons on a phone's 350 px share the row from a basis of nothing
    (flex:1 1 0) and may shrink below their words (min-width:0, which flex
    items refuse by default); width:auto undoes the block rule's 100%, which
    as a basis put every button on a row of its own. Show sat off the right
    edge of an iPhone's screen (fork #330). */
 .keys{display:flex;gap:8px;margin-top:10px}
 .keys button{flex:1 1 0;min-width:0;width:auto;padding:12px 6px;margin-top:0}
+/* Let the short French key symbols leave room for Vider and Voir/Cacher. */
+html[lang=fr] .keys button{flex-basis:auto}
 /* The trackpad. Tall enough to drag across a four-inch screen's worth of
    page without lifting a finger, and touch-action:none so the browser does
    not steal the gesture to scroll its own page. */
 .pad{height:11rem;margin-top:12px;border:1px dashed #555;border-radius:10px;
      background:#181818;touch-action:none;display:flex;align-items:center;
      justify-content:center;color:#666;font-size:.85rem;user-select:none}
 .pad.live{border-color:#4af;color:#4af}
 """
@@ -950,41 +1003,49 @@ def registrable_domain(host):
 # Shown when the sign-in page is open on the handheld itself. That is the good
 # path: the redirect completes on its own and nothing has to be copied.
 #
 # The keyboard below is an option, not a requirement. On a 6" handheld with a
 # touchscreen, typing on the device is perfectly reasonable and this page is
 # unnecessary; on a 3.5" screen driven by a d-pad it is the difference between
 # a minute of misery and a few seconds. Both work, because the page is on the
 # device's screen either way -- so the choice is the player's, not ours.
-REMOTE_PAGE = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1">
+REMOTE_PAGE = """<!doctype html><html lang=en><meta name=viewport content="width=device-width,initial-scale=1">
 <title>Keyboard for %(name)s</title>
 <style>%(style)s</style>
 <div class=card>
-<h1>Keyboard for %(name)s</h1>
-
-<div id=state class=note>Checking&hellip;</div>
+<div class=phone-header>
+<h1 title="Keyboard for %(name)s">Keyboard for %(name)s</h1>
+<button type=button id=state data-kind=warning aria-label="Checking connection"
+        title="Checking connection" aria-expanded=false aria-controls=status-panel>
+<span id=status-glyph aria-hidden=true>!</span></button>
+<div id=status-panel hidden>
+<p id=status-message>Checking connection</p>
+<button type=button class=minor id=status-hide>Hide status</button>
+</div>
+</div>
+<div id=status-live class=status-live role=status aria-live=polite aria-atomic=true></div>
 
-<input id=kb type=password placeholder="Type here" autocapitalize=off
+<input id=kb type=password placeholder="Type here" aria-label="Text to type on your handheld" autocapitalize=off
        autocorrect=off spellcheck=false autofocus>
 <div id=warn class=err hidden></div>
 <div class=keys>
-<button type=button class=minor data-key=backspace>Back</button>
+<button type=button class=minor data-key=backspace aria-label="Backspace">Back</button>
 <button type=button class=minor data-key=tab>Tab</button>
-<button type=button class=minor data-key=enter>Enter</button>
+<button type=button class=minor data-key=enter aria-label="Enter">Enter</button>
 <button type=button class=minor id=clear>Clear</button>
 <button type=button class=minor id=show>Show</button>
 </div>
 
 
 <div class=keys>
-<button type=button class=minor data-key=left>&larr;</button>
-<button type=button class=minor data-key=up>&uarr;</button>
-<button type=button class=minor data-key=down>&darr;</button>
-<button type=button class=minor data-key=right>&rarr;</button>
+<button type=button class=minor data-key=left aria-label="Left arrow">&larr;</button>
+<button type=button class=minor data-key=up aria-label="Up arrow">&uarr;</button>
+<button type=button class=minor data-key=down aria-label="Down arrow">&darr;</button>
+<button type=button class=minor data-key=right aria-label="Right arrow">&rarr;</button>
 </div>
 <div class=keys>
 <button type=button class=minor data-key=f2>Page up</button>
 <button type=button class=minor data-key=f3>Page down</button>
 </div>
 <h2>Pointer</h2>
 <div class=pad id=pad>drag to move &middot; tap to click</div>
 
@@ -1001,31 +1062,102 @@ network you trust.</p>
 <div class=leave id=leave>
 <button type=button class=minor id=leave-ask>Close page</button>
 <div class=ask id=leave-confirm hidden><span>Close the sign-in page on your handheld?</span>
 <button type=button class=minor id=leave-keep>Keep</button><button type=button id=leave-close>Close</button></div>
 </div>
 </div>
 
 <script>
+var phoneLanguage = "en";
+var phoneMessages = {
+  en: {
+    connected: "Connected", disconnected: "Disconnected", warning: "Warning",
+    open: "The keyboard is ready.",
+    loading: "Opening on your handheld. You can keep typing here; it goes across once a box on that page is ready.",
+    waiting: "Not open yet. Choose CONTINUE on your handheld. You can type or paste here meanwhile; it goes across when the page opens.",
+    ended: "The sign-in page is closed. Start sign-in again on your handheld if you still need it.",
+    retrying: "Checking the connection to your handheld again.",
+    unreachable: "Your phone can't reach your handheld. Both need to be on the same Wi-Fi, and a VPN on your phone can get in the way. If sign-in has ended, you can close this phone page.",
+    broken: "This page stopped working. Reload it; if it happens again, report it to the pixelelated project: ",
+    show: "Show", hide: "Hide",
+    droppedMaskedOne: "The handheld can't type one of the characters you entered, so it was left out.",
+    droppedMaskedMany: "The handheld can't type {count} of the characters you entered, so they were left out.",
+    droppedVisibleOne: "The handheld can't type {characters}, so it was left out.",
+    droppedVisibleMany: "The handheld can't type {characters}, so they were left out."
+  },
+  fr: {
+    connected: "Connecté", disconnected: "Déconnecté", warning: "Attention",
+    open: "Le clavier est prêt.",
+    loading: "La page s’ouvre sur votre console. Vous pouvez continuer à saisir ici ; le texte sera envoyé dès qu’un champ de la page sera prêt.",
+    waiting: "La page n’est pas encore ouverte. Choisissez CONTINUER sur votre console. Vous pouvez saisir ou coller du texte ici ; il sera envoyé à l’ouverture de la page.",
+    ended: "La page de connexion est fermée. Relancez la connexion sur votre console si nécessaire.",
+    retrying: "Nouvelle vérification de la connexion à votre console.",
+    unreachable: "Votre téléphone ne peut pas joindre votre console. Les deux doivent être sur le même réseau Wi-Fi. Un VPN sur votre téléphone peut bloquer la connexion. Si la connexion au service est terminée, vous pouvez fermer cette page sur votre téléphone.",
+    broken: "Cette page ne fonctionne plus. Rechargez-la ; si le problème persiste, signalez-le au projet pixelelated : ",
+    show: "Voir", hide: "Cacher",
+    droppedMaskedOne: "La console ne peut pas saisir un des caractères entrés. Il a été ignoré.",
+    droppedMaskedMany: "La console ne peut pas saisir {count} des caractères entrés. Ils ont été ignorés.",
+    droppedVisibleOne: "La console ne peut pas saisir {characters}. Ce caractère a été ignoré.",
+    droppedVisibleMany: "La console ne peut pas saisir {characters}. Ces caractères ont été ignorés."
+  }
+}[phoneLanguage];
+var phoneScriptFailed = false;
+var phoneStatusKey = "";
+function phoneStatus(kind, key, detail, reveal) {
+  var state = document.getElementById("state");
+  var label = phoneMessages[kind];
+  state.setAttribute("data-kind", kind);
+  state.setAttribute("aria-label", label + ". " + detail);
+  state.title = label + ". " + detail;
+  document.getElementById("status-glyph").textContent =
+    kind === "connected" ? "\u2713" : kind === "disconnected" ? "\u00d7" : "!";
+  document.getElementById("status-message").textContent = detail;
+  // Announce transitions, not every poll. Opening details never steals the
+  // caret; repeated failures respect an explicit Hide status action.
+  if (key !== phoneStatusKey) {
+    document.getElementById("status-live").textContent = label + ". " + detail;
+    if (reveal) {
+      document.getElementById("status-panel").hidden = false;
+      state.setAttribute("aria-expanded", "true");
+    }
+  }
+  phoneStatusKey = key;
+}
 // A script that dies before it starts leaves the page saying Checking... for
 // as long as it is open, its taps dead (fork #330). Said on the page, with
 // the browser's words for the ROCKNIX team, instead of nothing.
 window.onerror = function (message) {
-  var state = document.getElementById("state");
-  if (!state) return;
-  state.className = "err";
-  state.textContent = "This page stopped working. Reload it; if it happens again, report it to the pixelelated project: " + message;
+  phoneScriptFailed = true;
+  phoneStatus("warning", "broken", phoneMessages.broken + message, true);
 };
 (function () {
   var pin = "%(pin)s";
   var box = document.getElementById("kb");
   var warn = document.getElementById("warn");
   var state = document.getElementById("state");
   var pad = document.getElementById("pad");
+  var statusPanel = document.getElementById("status-panel");
+  state.addEventListener("click", function () {
+    statusPanel.hidden = !statusPanel.hidden;
+    state.setAttribute("aria-expanded", String(!statusPanel.hidden));
+  });
+  document.getElementById("status-hide").addEventListener("click", function () {
+    statusPanel.hidden = true;
+    state.setAttribute("aria-expanded", "false");
+    state.focus();
+  });
+  statusPanel.addEventListener("keydown", function (e) {
+    if (e.key === "Escape") {
+      statusPanel.hidden = true;
+      state.setAttribute("aria-expanded", "false");
+      state.focus();
+      e.preventDefault();
+    }
+  });
 
   // One request at a time, in order. Backspaces and characters that overtake
   // each other arrive as scrambled text in the field on the handheld.
   //
   // Two states from the probe: winUp, the window is on the handheld's
   // screen (the named keys drive it -- Tab is how a field the page did not
   // focus is reached); ready, a field on its page has had the caret, so
   // text has somewhere to go. It was `up` until fork #330 -- the same name
@@ -1110,20 +1242,20 @@ window.onerror = function (message) {
   // masked it counts them: a password's characters written out under a
   // box that hides them is the box's masking undone (G-C-05, the audit of
   // stream C).
   var dropped = [];
   function warnSay() {
     if (!dropped.length) { warn.hidden = true; return; }
     var many = dropped.length > 1;
     warn.textContent = box.type === "password"
-      ? "The handheld can't type " + (many ? dropped.length + " of the characters you entered"
-          : "one of the characters you entered") + ", so " + (many ? "they were" : "it was") + " left out."
-      : "The handheld can't type " + dropped.join(" ") + ", so "
-          + (many ? "they were" : "it was") + " left out.";
+      ? (many ? phoneMessages.droppedMaskedMany.replace("{count}", dropped.length)
+          : phoneMessages.droppedMaskedOne)
+      : (many ? phoneMessages.droppedVisibleMany : phoneMessages.droppedVisibleOne)
+          .replace("{characters}", dropped.join(" "));
     warn.hidden = false;
   }
   function typable() {
     var v = box.value, kept = v.replace(/[^ -~]/g, "");
     if (kept === v) return;
     dropped = v.replace(/[ -~]/g, "").split("");
     box.value = kept;
     warnSay();
@@ -1146,17 +1278,17 @@ window.onerror = function (message) {
   // Masked, because what goes through this box is mostly a password, and
   // it stayed readable on the phone's screen after it was sent (#308 gpt
   // F-RS-14). Show reveals it for checking; it hides again on a second
   // press.
   var show = document.getElementById("show");
   show.addEventListener("click", function () {
     var hidden = box.type === "password";
     box.type = hidden ? "text" : "password";
-    show.textContent = hidden ? "Hide" : "Show";
+    show.textContent = hidden ? phoneMessages.hide : phoneMessages.show;
     warnSay();
   });
 
   // Local only: the handheld has moved to another field and this box still
   // holds what went into the last one.
   document.getElementById("clear").addEventListener("click", function () {
     box.value = ""; sent = ""; dropped = []; warnSay(); box.focus();
   });
@@ -1237,57 +1369,56 @@ window.onerror = function (message) {
   pad.addEventListener("touchend", up, {passive: false});
   pad.addEventListener("mousedown", down);
   window.addEventListener("mousemove", move);
   window.addEventListener("mouseup", up);
 
   // This page is scanned before the window exists -- the QR is on the screen
   // the sign-in page then replaces -- so it has to come alive by itself.
   //
-  // A probe that fails is counted; five in a row (ten seconds) and the line
+  // A probe that fails is counted; five in a row and the status
   // says the handheld cannot be reached and what to look at, instead of
   // Checking... for as long as the page is open (fork #330: an iPhone with a
   // VPN badge in its status bar showed Checking... for two minutes while
   // its taps went nowhere). The polling goes on: the moment an answer comes
-  // the line changes to what it says.
+  // the status changes to what it says. A loading page remains connected;
+  // its field readiness is a separate gate for the existing input queue.
   var failed = 0;
-  function unreachable() {
-    state.className = "err";
-    state.textContent = "Your phone can't reach your handheld. Both need to be "
-      + "on the same Wi-Fi, and a VPN on your phone can get in the way.";
-  }
+  var hadWindow = false;
   function poll() {
     fetch("/" + pin + "?probe=1", {cache: "no-store"}).then(function (r) {
         if (!r.ok) throw new Error("status " + r.status);
-        failed = 0;
         return r.text();
       })
       .then(function (t) {
         // "open <page>" -- the page token changes when the handheld
         // navigates, which is when what is in this box stopped being
         // relevant to what is on that screen.
         var parts = t.trim().split(" ");
+        // A PIN page or unrelated HTTP 200 is not a control-session probe.
+        if (!/^(open|loading)( [^\\s]+)?$|^waiting$/.test(t.trim())) {
+          throw new Error("invalid probe");
+        }
+        failed = 0;
         var open = parts[0] === "open";
         var isUp = open || parts[0] === "loading";
         // A new page: what is in the box was for the one before. Noticed
         // while the new one loads too, so what is typed meanwhile is kept
         // for it.
         if (isUp && parts[1] && parts[1] !== page) {
           if (page !== null) { box.value = ""; sent = ""; }
           page = parts[1];
         }
         winUp = isUp;
-        state.className = open ? "ok" : "note";
-        state.textContent = open
-          ? "Connected."
-          : isUp
-          ? "Opening on your handheld. You can keep typing here; it goes "
-            + "across once a box on that page is ready."
-          : "Not open yet -- choose CONTINUE on your handheld. You can type "
-            + "or paste here meanwhile; it goes across when the page opens.";
+        var statusKey = open ? "open" : isUp ? "loading" : hadWindow ? "ended" : "waiting";
+        if (isUp) hadWindow = true;
+        if (!phoneScriptFailed) {
+          phoneStatus(isUp ? "connected" : "disconnected", statusKey,
+                      phoneMessages[statusKey], statusKey === "ended");
+        }
         // The box is never disabled. It was, until this said the handheld was
         // ready -- so somebody who scanned the QR first, which is the order
         // this flow asks for, could not type at all and saw nothing appear.
         // Re-asserting disabled every two seconds also dismisses a phone
         // keyboard in the middle of typing.
         //
         // And what was typed meanwhile goes across the moment it opens. The
         // box only ever sent on an input event, so text typed while the page
@@ -1296,17 +1427,25 @@ window.onerror = function (message) {
         // #307 PL-016). The window opens on an empty field, so nothing has
         // been sent to it yet: `sent` starts again from nothing. And not
         // before a field has the caret -- open is that, not the window's
         // process starting (claude G2-C-01) -- and again on each new page.
         var opened = open && !ready;
         ready = open;
         if (opened) { sent = ""; deliver(box.value); }
       })
-      .catch(function () { if (++failed >= 5) unreachable(); })
+      .catch(function () {
+        ++failed;
+        if (!phoneScriptFailed) {
+          phoneStatus(failed >= 5 ? "disconnected" : "warning",
+                      failed >= 5 ? "unreachable" : "retrying",
+                      failed >= 5 ? phoneMessages.unreachable : phoneMessages.retrying,
+                      failed >= 5);
+        }
+      })
       .then(function () { setTimeout(poll, 2000); });
   }
   poll();
 })();
 </script>
 """
 
 
diff --git a/projects/ROCKNIX/packages/rocknix/sources/scripts/runemu.sh b/projects/ROCKNIX/packages/rocknix/sources/scripts/runemu.sh
index 63b39af1fc..23da79300f 100755
--- a/projects/ROCKNIX/packages/rocknix/sources/scripts/runemu.sh
+++ b/projects/ROCKNIX/packages/rocknix/sources/scripts/runemu.sh
@@ -40,16 +40,17 @@ LOG_DIRECTORY="/var/log"
 LOG_FILE="exec.log"
 RUN_SHELL="/usr/bin/bash"
 RETROARCH_TEMP_CONFIG="/storage/.config/retroarch/retroarch.cfg"
 RETROARCH_APPEND_CONFIG="/tmp/.retroarch.cfg"
 NETWORK_PLAY="No"
 SET_SETTINGS_TMP="/tmp/shader"
 OUTPUT_LOG="${LOG_DIRECTORY}/${LOG_FILE}"
 SCRIPT_NAME=$(basename "$0")
+DOLPHIN_LAUNCH=false
 
 ### The marker the global exit hotkey leaves behind (input_sense,
 ### execute_kill): cleared before the emulator starts, consumed by the exit
 ### mapping at the bottom of this script -- fork #92, D-LAUNCH-002. It sits
 ### in /tmp beside the kill data the same hotkey reads
 ### (/tmp/.process-kill-data) because /tmp is a tmpfs: a power cut wipes it,
 ### which is exactly what is wanted of a flag that must never outlive the
 ### boot. input.service and this script both run as root, so each can write
@@ -355,19 +356,21 @@ case ${EMULATOR} in
     fi
   ;;
   *)
     case ${PLATFORM} in
       "setup")
         RUNTHIS='${RUN_SHELL} "${ROMNAME}"'
       ;;
       "gamecube"|"triforce")
+        DOLPHIN_LAUNCH=true
         RUNTHIS='${RUN_SHELL} /usr/bin/start_dolphin_gc.sh "${ROMNAME}" "${PLATFORM}" "${CORE}"'
       ;;
       "wii"|"wiiware")
+        DOLPHIN_LAUNCH=true
         RUNTHIS='${RUN_SHELL} /usr/bin/start_dolphin_wii.sh "${ROMNAME}" "${PLATFORM}" "${CORE}"'
       ;;
       "ports")
       if [[ "${ROMNAME,,}" == *".appimage" ]]; then
         RUNTHIS='${EMUPERF} "${ROMNAME}"'
       else
         RUNTHIS='${EMUPERF} ${RUN_SHELL} "${ROMNAME}"'
       fi
@@ -479,20 +482,26 @@ fi
 ### hotkey kills EmulationStation -- can never be read as this launch ending
 ### (fork #92). Both dispatch paths below run through here, and nothing above
 ### it starts an emulator; keep it that way.
 rm -f "${EXIT_HOTKEY_MARKER}"
 
 # If the rom is a shell script just execute it, useful for DOSBOX and ScummVM scan scripts
 if [[ "${ROMNAME}" == *".sh" ]] && [ ! "${PLATFORM}" = "ports" ] && [ ! "${PLATFORM}" = "windows" ]; then
         ${VERBOSE} && log $0 "Executing shell script ${ROMNAME}"
+        DOLPHIN_LAUNCH=false
         "${ROMNAME}" &>>${OUTPUT_LOG}
         ret_error=$?
 else
         ${VERBOSE} && log $0 "Executing $(eval echo ${RUNTHIS})"
+        # A Dolphin preparation refusal owns only this launch's native message.
+        # Other emulator exit codes must not acquire a stale custom error.
+        if [ "${DOLPHIN_LAUNCH}" = true ]; then
+                rm -f /tmp/launch_error.log || quit 1
+        fi
         eval ${RUNTHIS} &>>${OUTPUT_LOG}
         ret_error=$?
 fi
 
 ### Switch back to performance mode to clean up
 performance
 
 clear_screen
@@ -575,16 +584,33 @@ ${VERBOSE} && log $0 "Checking errors: ${ret_error} "
 ### (fork #92, D-LAUNCH-002). A launch with no marker behaves exactly as before.
 ### Consume the marker here whatever happened, so it cannot reach another launch.
 EXIT_HOTKEY_PRESSED=false
 if [ -e "${EXIT_HOTKEY_MARKER}" ]
 then
         EXIT_HOTKEY_PRESSED=true
         rm -f "${EXIT_HOTKEY_MARKER}"
 fi
+# Dolphin preparation uses the existing ES custom-error channel. Require its
+# fresh message as well as its status; a native emulator's numeric exit alone
+# is not a preparation refusal. This precedes the hotkey's clean-exit mapping.
+if [ "${DOLPHIN_LAUNCH}" = true ] && [ "${ret_error}" = 250 ] &&
+   [ -f /tmp/launch_error.log ] && [ ! -L /tmp/launch_error.log ]; then
+        IFS= read -r DOLPHIN_ERROR_TITLE < /tmp/launch_error.log
+        if [ "${DOLPHIN_ERROR_TITLE}" = "DOLPHIN DID NOT START" ]; then
+                # Remove the fixed ownership line before ES displays localized text.
+                DOLPHIN_VISIBLE_ERROR=$(mktemp /tmp/.dolphin-visible-error.XXXXXX) || quit 1
+                if ! sed '1d' /tmp/launch_error.log > "${DOLPHIN_VISIBLE_ERROR}" ||
+                   ! mv -f "${DOLPHIN_VISIBLE_ERROR}" /tmp/launch_error.log; then
+                        rm -f "${DOLPHIN_VISIBLE_ERROR}"
+                        quit 1
+                fi
+                quit 250
+        fi
+fi
 case "${ret_error}" in
   0)
         quit 0
   ;;
   137|143)
         log $0 "emulator ended by signal (${ret_error}, the exit hotkey); a clean exit"
         quit 0
   ;;
diff --git a/projects/ROCKNIX/packages/rocknix/sources/scripts/wifictl b/projects/ROCKNIX/packages/rocknix/sources/scripts/wifictl
index 33d754de08..9b724b7961 100755
--- a/projects/ROCKNIX/packages/rocknix/sources/scripts/wifictl
+++ b/projects/ROCKNIX/packages/rocknix/sources/scripts/wifictl
@@ -1,23 +1,27 @@
 #!/bin/bash
 # SPDX-License-Identifier: Apache-2.0
 # Copyright (C) 2023 JELOS (https://github.com/JustEnoughLinuxOS)
 # Copyright (C) 2022 kkoshelev (https://github.com/kkoshelev)
+# Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
 # Wi-Fi via NetworkManager (iwd backend). AP/netplay still uses iwctl on the interface.
 
 . /etc/profile
 
 NMCLI="$(command -v nmcli 2>/dev/null)"
 
 ###
 ### Basic WIFI properties used across the tool.
 ###
 ### Usage:
 ###     wifictl command [ssid] [psk]
+###     wifictl list / scanlist  SSIDs on success, including nothing and exit 0;
+###                               exit 2 when the adapter or nmcli is unavailable;
+###                               nonzero when readiness, rescan, or enumeration fails
 ###
 ### For the interface's network rows (fork #191), reading NetworkManager
 ### rather than the wifi.ssid setting:
 ###     wifictl current           the network joined now; nothing and exit 1 when none,
 ###                               exit 2 when NetworkManager could not be asked
 ###     wifictl saved             the remembered networks, one per line: <name><TAB>active|saved
 ###     wifictl saved --ssid      the same with each profile's SSID between: <name><TAB><ssid><TAB>active|saved,
 ###                               a tab or backslash inside the name or the SSID written \t or \\;
@@ -36,18 +40,19 @@ NMCLI="$(command -v nmcli 2>/dev/null)"
 
 WIFI_TYPE=$(get_setting wifi.adhoc.enabled)
 NETWORK_ADDRESS="192.168.80"
 ADHOC_CLIENT_ID=$(get_setting wifi.adhoc.id)
 [ -z "${ADHOC_CLIENT_ID}" ] && ADHOC_CLIENT_ID="1"
 NETPLAY_SSID="NETPLAY_AP"
 WIFI_DEV="$(ls /sys/class/net | grep -m1 ^wlan)"
 
-# Typed security/join callers must not read an unavailable radio as success.
-if [ "${1}" = security ] || [ "${1}" = connect-open ]; then
+# Typed scan/security/join callers must not read an unavailable radio as success.
+if [ "${1}" = list ] || [ "${1}" = scanlist ] || \
+   [ "${1}" = security ] || [ "${1}" = connect-open ]; then
   [ -n "${WIFI_DEV}" ] && [ -d "/sys/class/net/${WIFI_DEV}" ] && [ -n "${NMCLI}" ] || exit 2
 fi
 
 # Exit the script if the WiFi device isn't available
 [ -z "${WIFI_DEV}" ] && exit 0
 [ ! -d "/sys/class/net/${WIFI_DEV}" ] && exit 0
 [ -z "${NMCLI}" ] && exit 0
 
@@ -59,36 +64,54 @@ if [ "${WIFI_TYPE}" = "1" ]; then
   SSID="${NETPLAY_SSID}"
   PSK="deadbeef"
 fi
 
 ###
 ### Functions...
 ###
 
-# Wait for iwd to start and have a device available
+# Wait for iwd to start and have a device available. A successful query that
+# never sees the adapter is exit 1; a failed final query keeps its status.
+# Connection/AP callers still make their own operation the final result.
 wait_for_wifi() {
+  local i devices status=1
   for i in $(seq 1 5); do
-    iwctl device list | grep -q "${WIFI_DEV}" && break
+    if devices=$(iwctl device list); then
+      if grep -q "${WIFI_DEV}" <<< "${devices}"; then
+        status=0
+        break
+      fi
+      status=1
+    else
+      status=$?
+    fi
     sleep 1
   done
-  [ -n "${COUNTRY}" ] && iw reg set "${COUNTRY}"
+  if [ -n "${COUNTRY}" ]; then
+    iw reg set "${COUNTRY}" || return $?
+  fi
+  return "${status}"
 }
 
 # lists all wifi networks, each name as the network has it: terse output
 # escapes ':' and '\', so "Cafe: Guest" arrived as "Cafe\: Guest" from here
 # and as "Cafe: Guest" from current and saved, and the picker -- which
 # compares names exactly -- showed the network twice and tried to connect
 # to the escaped name (#308 claude F-WF-05). nm_unescape is defined below;
 # this runs after the whole file is read.
 list_wifi() {
-  wait_for_wifi
-  "${NMCLI}" -w 15 dev wifi rescan ifname "${WIFI_DEV}" 2>/dev/null
+  local rows
+  wait_for_wifi >/dev/null || return $?
+  "${NMCLI}" -w 15 dev wifi rescan ifname "${WIFI_DEV}" >/dev/null 2>&1 || return $?
   sleep 1
-  "${NMCLI}" -t -f SSID dev wifi list ifname "${WIFI_DEV}" 2>/dev/null | nm_unescape | sed '/^$/d' | sort -u
+  # Capture the producer's status before filtering, and discard partial rows
+  # on failure. Empty successful output is a different answer from no answer.
+  rows=$("${NMCLI}" -t -f SSID dev wifi list ifname "${WIFI_DEV}" 2>/dev/null) || return $?
+  (set -o pipefail; printf '%s\n' "${rows}" | nm_unescape | sed '/^$/d' | sort -u)
 }
 
 # Only an explicit, unanimous open result may skip the key prompt. SECURITY
 # has no colons; SSIDs do, escaped by nmcli. Unknown/mixed scans fail closed.
 wifi_security() {
   local wanted="${1}" rows line name security found=0 open=0 protected=0
   rows=$(LC_ALL=C "${NMCLI}" -t -f SSID,SECURITY device wifi list ifname "${WIFI_DEV}" --rescan no 2>/dev/null) || { echo unknown; return 1; }
   while IFS= read -r line; do
@@ -506,17 +529,17 @@ case "${1}" in
     ;;
   has_ap_mode)
     has_ap_mode
     ;;
   scan)
     "${NMCLI}" dev wifi rescan ifname "${WIFI_DEV}" 2>/dev/null
     ;;
   scanlist)
-    "${NMCLI}" dev wifi rescan ifname "${WIFI_DEV}" 2>/dev/null
+    "${NMCLI}" -w 15 dev wifi rescan ifname "${WIFI_DEV}" >/dev/null 2>&1 || exit $?
     sleep 2
     list_wifi
     ;;
   current)
     current_wifi
     ;;
   saved)
     if [ "${2:-}" = "--ssid" ]; then
diff --git a/projects/ROCKNIX/packages/tools/rocknix-abl/package.mk b/projects/ROCKNIX/packages/tools/rocknix-abl/package.mk
index c75a45881c..d8bc42f348 100644
--- a/projects/ROCKNIX/packages/tools/rocknix-abl/package.mk
+++ b/projects/ROCKNIX/packages/tools/rocknix-abl/package.mk
@@ -1,14 +1,14 @@
 # SPDX-License-Identifier: GPL-2.0
 # Copyright (C) 2025 ROCKNIX (https://github.com/ROCKNIX)
 
 PKG_NAME="rocknix-abl"
-PKG_VERSION="1.1.9"
-PKG_SHA256="2fc42c9cc60fe9eb33196785a8e92608f0ffbaa0b739b7051d948ba27a3bd747"
+PKG_VERSION="1.2"
+PKG_SHA256="4fcf983aff6af152fb5d7d0ef1a31727d64ecb93b2d75e202efeea5c5d4b565d"
 PKG_SITE="https://github.com/ROCKNIX/abl"
 PKG_URL="https://github.com/ROCKNIX/abl/releases/download/v${PKG_VERSION}/rocknix-abl-v${PKG_VERSION}.tar.gz"
 PKG_LONGDESC="ROCKNIX ABL."
 PKG_TOOLCHAIN="manual"
 
 makeinstall_target() {
   mkdir -p ${INSTALL}/usr/share/bootloader/rocknix_abl
     cp -a ${PKG_BUILD}/abl_signed-${DEVICE}.elf ${INSTALL}/usr/share/bootloader/rocknix_abl/abl_signed-${DEVICE}.elf
diff --git a/projects/ROCKNIX/packages/ui/emulationstation/package.mk b/projects/ROCKNIX/packages/ui/emulationstation/package.mk
index 34ee02ec86..cb8ba27c4a 100644
--- a/projects/ROCKNIX/packages/ui/emulationstation/package.mk
+++ b/projects/ROCKNIX/packages/ui/emulationstation/package.mk
@@ -1,59 +1,74 @@
 # SPDX-License-Identifier: GPL-2.0
 # Copyright (C) 2024-present ROCKNIX (https://github.com/ROCKNIX)
 
 PKG_NAME="emulationstation"
-PKG_VERSION="c8dc72cf9ec00ab00d6c4a9fcdcea1746c6f1f78"
+PKG_VERSION="3178b832b8d134198b2b4eede4f725d4ed283f8c"
 PKG_GIT_CLONE_BRANCH="test/qa-integration"
-PKG_LICENSE="MIT"
+PKG_LICENSE="MIT AND BSD-3-Clause"
 PKG_SITE="https://github.com/pixelelated/emulationstation"
 PKG_URL="${PKG_SITE}.git"
 # noto-sans-cjk came from upstream 2026-09, and poppler with the PDF support
 # upstream's EmulationStation gained (e0e8b7ac33); the fork builds its own ES
 # from its own branch, so the clone form stays.
-PKG_DEPENDS_TARGET="boost toolchain SDL2 freetype curl freeimage bash rapidjson SDL2_mixer fping p7zip alsa vlc drm_tool poppler pugixml noto-sans-cjk ${OPENGLES}"
+PKG_DEPENDS_TARGET="boost toolchain SDL2 freetype curl freeimage bash rapidjson SDL2_mixer fping p7zip alsa vlc drm_tool poppler pugixml noto-sans-cjk zstd ${OPENGLES}"
 PKG_NEED_UNPACK="busybox"
 PKG_LONGDESC="Emulationstation emulator frontend"
 PKG_BUILD_FLAGS="-gold"
 GET_HANDLER_SUPPORT="git"
 
 PKG_CMAKE_OPTS_TARGET+=" -DROCKNIX=1 \
                          -DDISABLE_KODI=1 \
                          -DENABLE_FILEMANAGER=0 \
                          -DCEC=0 \
                          -DENABLE_PULSE=1 \
                          -DUSE_SYSTEM_PUGIXML=1 \
                          -DGLES3=1"
 
-# The ScreenScraper developer pair is entered on the device, not compiled in,
-# so no fork image carries a key (#64). A SCREENSCRAPER_DEV_LOGIN in the build
-# environment still wins and hides the rows.
+# #566 / D-WORKFLOW-166: provision the shared JELOS developer identity below.
+# Keep runtime support for alternate builds; a compiled pair hides developer
+# entry rows while the player's own ScreenScraper account stays separate.
 PKG_CMAKE_OPTS_TARGET+=" -DSCREENSCRAPER_RUNTIME_DEV_LOGIN=1"
 
 # Upstream replaced the S922X test with a build option (2026-09).
 [ "${BATTERYPLUS_SUPPORT}" = "yes" ] && PKG_CMAKE_OPTS_TARGET+=" -DBATTERYPLUS=1"
 
 pre_configure_target() {
+  # This public shared developer account is the explicit interim choice. An
+  # intentional build override remains supported, but does not gain the shared
+  # identity exception in the image's selected-state gate (#565/#566).
+  local screenscraper_shared_dev="jelos"
+  export SCREENSCRAPER_DEV_LOGIN="${SCREENSCRAPER_DEV_LOGIN:-[REDACTED_SHARED_DEVELOPER_IDENTITY]}"
+
   for key in SCREENSCRAPER_DEV_LOGIN \
              GAMESDB_APIKEY \
              CHEEVOS_DEV_LOGIN; do
     if [ -z "${!key}" ]; then
       echo "WARNING: ${key} not declared, will not build support."
     else
       # The name, never the value: a developer password or an API key does
       # not belong in a build log that gets pasted into an issue.
       echo "USING: ${key} (set)"
     fi
   done
 
   export DEVICE=$(echo ${DEVICE^^} | sed "s#-#_##g")
 }
 
 makeinstall_target() {
+  # The bounded RVZ reader carries a BSD padding adaptation. Older ES pins
+  # have no such reader; preserve their existing installation path.
+  if [ -f "${PKG_BUILD}/external/libcheevos/LICENSE.rvz-padding" ]; then
+    mkdir -p ${INSTALL}/usr/share/licenses/emulationstation
+    cp -a ${PKG_BUILD}/external/libcheevos/LICENSE.rvz-padding \
+          ${PKG_BUILD}/external/libcheevos/RVZ-NOTICES.md \
+          ${INSTALL}/usr/share/licenses/emulationstation/
+  fi
+
   mkdir -p ${INSTALL}/usr/config/locale
     cp -a ${PKG_BUILD}/locale/lang/* ${INSTALL}/usr/config/locale
 
     # Pre-generate default (en_US.UTF-8) locale for lower-end devices to speed up first boot
     # This saves a minute or two on RK3326 in a cost of about 1 MB of SYSTEM size
     # Copy-paste of a locale generating part of es_settings script
     I18NPATH=$(get_install_dir glibc)/usr/share/i18n/locales/ \
       localedef --force --verbose --inputfile=en_US --charmap=UTF-8 \
diff --git a/projects/ROCKNIX/packages/virtual/emulators/package.mk b/projects/ROCKNIX/packages/virtual/emulators/package.mk
index 0cd90523e0..a9908b89cf 100644
--- a/projects/ROCKNIX/packages/virtual/emulators/package.mk
+++ b/projects/ROCKNIX/packages/virtual/emulators/package.mk
@@ -1,10 +1,11 @@
 # SPDX-License-Identifier: GPL-2.0
 # Copyright (C) 2023 JELOS (https://github.com/JustEnoughLinuxOS)
+# Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
 
 PKG_NAME="emulators"
 PKG_LICENSE="GPLv2"
 PKG_SITE="https://rocknix.org"
 PKG_SECTION="emulation" # Do not change to virtual or makeinstall_target will not execute.
 PKG_LONGDESC="Emulation metapackage."
 PKG_TOOLCHAIN="manual"
 
@@ -88,16 +89,20 @@ case "${DEVICE}" in
                 xemu-sa skyemu-sa steam vita3k-sa armsx2-sa"
     LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr kronos-lr uae4arm-lr"
     ;;
   S922X)
     [ "${ENABLE_32BIT}" == "true" ] && EMUS_32BIT="box86 pcsx_rearmed-lr"
     PKG_EMUS+=" aethersx2-sa azahar-sa bigpemu-sa dolphin-sa drastic-sa duckstation-sa melonds-sa vita3k-sa armsx2-sa"
     LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr uae4arm-lr"
     ;;
+  GENERIC_X64)
+    # Native standalone Dolphin supports the developer VM qualification path.
+    PKG_EMUS+=" dolphin-sa"
+    ;;
   AMD64)
     PKG_EMUS+=" ares-sa azahar-sa cemu-sa dolphin-sa gopher64-sa mednafen melonds-sa nanoboyadvance-sa \
                 xemu-sa skyemu-sa vita3k-sa armsx2-sa"
     LIBRETRO_CORES+=" beetle-psx-lr beetle-saturn-lr bsnes-lr bsnes-hd-lr dolphin-lr"
 esac
 
 # GENERIC_X64 (x86_64): drop libretro cores that don't yet build for x86_64.
 # These are tracked in issue #16 to fix/re-enable per-core later (e.g. parallel-n64-lr's
@@ -649,16 +654,22 @@ makeinstall_target() {
     SM8550|SM8650|SM8750|AMD64)
       add_emu_core gbch ares ares-sa false
       ;;
   esac
   add_es_system gbch
 
   ### Nintendo GameCube
   case ${DEVICE} in
+    GENERIC_X64)
+      add_emu_core gamecube dolphin dolphin-sa-gc true
+      add_emu_core gamecube dolphin dolphin-qt-gc false
+      install_script "Start Dolphin.sh"
+      add_es_system gamecube
+      ;;
     RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
       add_emu_core gamecube dolphin dolphin-sa-gc true
       add_emu_core gamecube dolphin dolphin-qt-gc false
       add_emu_core gamecube retroarch dolphin false
       install_script "Start Dolphin.sh"
       add_es_system gamecube
       ;;
   esac
@@ -670,16 +681,21 @@ makeinstall_target() {
       add_emu_core triforce dolphin dolphin-qt-gc false
       install_script "Start Dolphin.sh"
       add_es_system triforce
       ;;
   esac
 
   ### Nintendo Wii/ware
   case ${DEVICE} in
+    GENERIC_X64)
+      add_emu_core wii dolphin dolphin-sa-wii true
+      add_emu_core wii dolphin dolphin-qt-wii false
+      add_es_system wii
+      ;;
     RK3399|RK3576|RK3566|RK3588|SM4450|SM6115|SM8250|SM8550|SM8650|SM8750|S922X|AMD64)
       add_emu_core wii dolphin dolphin-sa-wii true
       add_emu_core wiiware dolphin dolphin-sa-wii true
       add_emu_core wii dolphin dolphin-qt-wii false
       add_emu_core wiiware dolphin dolphin-qt-wii false
       add_emu_core wii retroarch dolphin false
       add_emu_core wiiware retroarch dolphin false
       add_es_system wii
diff --git a/projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh b/projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh
index fdc39ca9b4..b29f68dcc4 100755
--- a/projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh	
+++ b/projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh	
@@ -1,42 +1,210 @@
 #!/bin/bash
 
 # SPDX-License-Identifier: GPL-2.0-or-later
 # Copyright (C) 2026-present ROCKNIX (https://github.com/ROCKNIX)
 
 set -e
 set -o pipefail
 
-source /etc/profile
-set_kill set "-9 steam FEX"
-
 STEAM="${STEAM:-/storage/.local/share/Steam}"
 STEAM_GAMES_ROOT="${STEAM_GAMES_ROOT:-/storage/games-internal/roms/steam}"
-STEAM_DOT="${STEAM_DOT:-/storage/.steam}"
-APPLICATIONS="${APPLICATIONS:-/storage/.local/share/applications}"
-FEX_DATA="/storage/.local/share/fex-emu"
-FEX_ARCH_ROOT="${FEX_DATA}/RootFS/ArchLinux"
-FEX_ARCH_USR_LIB="${FEX_ARCH_ROOT}/usr/lib"
-RUNTIME_DIR="${STEAM}/steam-runtime-steamrt-arm64"
-CLIENT_DIR="${STEAM}/steamrtarm64"
-RUNTIME_TAR_BASE="https://repo.steampowered.com/steamrt3c/images"
-RUNTIME_TAR_VERSION_URL="${RUNTIME_TAR_BASE}/latest-public-stable.txt"
-STEAM_MANIFEST_URL="https://client-update.fastly.steamstatic.com/steam_client_publicbeta_linuxarm64"
-STEAM_CDN="https://client-update.steamstatic.com"
-PROTON_CACHYOS_RELEASE_API="https://api.github.com/repos/CachyOS/proton-cachyos/releases/latest"
-PROTON_GE_RELEASE_API="https://api.github.com/repos/GloriousEggroll/proton-ge-custom/releases/latest"
-unset MESA_LOADER_DRIVER_OVERRIDE
-
 # --- Logging & Error Handling Helpers ---
 log_info() { echo -e "[\033[1;34mINFO\033[0m] $1"; }
 log_success() { echo -e "[\033[1;32mSUCCESS\033[0m] $1"; sleep 10; exit 0; }
 die() { echo -e "[\033[1;31mERROR\033[0m] $1" >&2; sleep 10; exit 1; }
 # ----------------------------------------
 
+# Inspect before profiles or installer functions can write. The saved plan is
+# process-local; no marker, directory, lock, or test file is created by preflight.
+steam_root_layout() {
+  /usr/bin/python3 -I -S -B - "$1" "${STEAM}" "${STEAM_GAMES_ROOT}" "${STEAM_ROOT_PLAN:-}" <<'PY_STEAM_ROOT'
+import json
+import os
+from pathlib import Path
+import re
+import stat
+import sys
+
+STORAGE = Path("/storage")
+MOUNTINFO = Path("/proc/self/mountinfo")
+MEDIA = Path("/var/media")
+
+
+def beneath(path, parent):
+    return path == parent or parent in path.parents
+
+
+def input_path(value):
+    if (not value.startswith("/") or value != os.path.normpath(value)
+            or value.startswith("//") or any(ord(c) < 32 for c in value)):
+        raise ValueError("The Steam folder path is not an absolute, unambiguous path.")
+    return Path(value)
+
+
+def read_mounts():
+    with MOUNTINFO.open() as stream:
+        raw = stream.read(1024 * 1024 + 1)
+    if not raw or len(raw) > 1024 * 1024:
+        raise ValueError("Storage availability could not be checked.")
+    rows = []
+    for line in raw.splitlines():
+        fields = line.split()
+        split = fields.index("-")
+        if split < 6 or len(fields) != split + 4:
+            raise ValueError("Storage availability could not be checked.")
+        point = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), fields[4])
+        rows.append((Path(point), fields))
+    return rows
+
+
+def inspect(steam_value, library_value):
+    steam = input_path(steam_value)
+    rows = read_mounts()
+    used = {}
+    required = (STORAGE, STORAGE / "games-external", STORAGE / "roms")
+    reserved = (*required, STORAGE / "games-internal", MEDIA, Path("/"))
+
+    def available(path):
+        wanted = [p for p in required if beneath(path, p)]
+        if beneath(path, MEDIA) and path != MEDIA:
+            wanted.append(MEDIA / path.relative_to(MEDIA).parts[0])
+        for point in wanted:
+            matches = [row for row in rows if row[0] == point]
+            if len(matches) != 1:
+                raise ValueError("The Steam storage is unavailable or has overlapping mounts.")
+            used[str(point)] = matches[0][1]
+        covers = [row for row in rows if beneath(path, row[0])]
+        if not covers:
+            raise ValueError("The Steam storage is unavailable.")
+        depth = max(len(row[0].parts) for row in covers)
+        covers = [row for row in covers if len(row[0].parts) == depth]
+        if len(covers) != 1 or covers[0][0] == Path("/"):
+            raise ValueError("The Steam storage is unavailable or ambiguous.")
+        point, fields = covers[0]
+        if "rw" not in fields[5].split(",") or "rw" not in fields[-1].split(","):
+            raise ValueError("The Steam storage is read-only.")
+        used[str(point)] = fields
+
+    # FEX/config also use /storage, even when the Steam alias points elsewhere.
+    available(STORAGE)
+
+    def probe(path):
+        available(path)
+        current, pending, entries, links = Path("/"), list(path.parts[1:]), [], 0
+        while pending:
+            part = pending.pop(0)
+            if part in ("", "."):
+                continue
+            if part == "..":
+                current = current.parent
+                continue
+            candidate = current / part
+            if candidate in required or candidate.parent == MEDIA:
+                available(candidate)
+            try:
+                info = candidate.lstat()
+            except FileNotFoundError:
+                if ".." in pending:
+                    raise ValueError("The Steam folder path is ambiguous.")
+                resolved = candidate.joinpath(*pending)
+                available(resolved)
+                if resolved in reserved:
+                    raise ValueError("The Steam folder path is ambiguous.")
+                if not os.access(current, os.W_OK | os.X_OK):
+                    raise ValueError("The Steam folder is not writable.")
+                return {"path": str(resolved), "exists": False, "entries": entries}
+            entry = [str(candidate), info.st_dev, info.st_ino, info.st_mode]
+            if stat.S_ISLNK(info.st_mode):
+                links += 1
+                if links > 40 or not stat.S_ISDIR(candidate.stat().st_mode):
+                    raise ValueError("The Steam folder link is unavailable or invalid.")
+                target = os.readlink(candidate)
+                if any(ord(c) < 32 for c in target):
+                    raise ValueError("The Steam folder link is ambiguous.")
+                entry.append(target)
+                entries.append(entry)
+                target_path = Path(target)
+                if target_path.is_absolute():
+                    current = Path("/")
+                    pending = list(target_path.parts[1:]) + pending
+                else:
+                    pending = list(target_path.parts) + pending
+                continue
+            if not stat.S_ISDIR(info.st_mode):
+                raise ValueError("A file is blocking the Steam folder.")
+            entries.append(entry)
+            current = candidate
+        available(current)
+        if current in reserved or not os.access(current, os.W_OK | os.X_OK):
+            raise ValueError("The Steam folder is ambiguous or not writable.")
+        return {"path": str(current), "exists": True, "entries": entries}
+
+    root = probe(steam)
+    plan = {"steam": steam_value, "library": library_value, "root": root}
+    if not root["exists"]:
+        library = probe(input_path(library_value))
+        a, b = Path(root["path"]), Path(library["path"])
+        if beneath(a, b) or beneath(b, a):
+            raise ValueError("The Steam folder and library paths overlap.")
+        plan["target"] = library
+    plan["mounts"] = used
+    return plan
+
+
+def open_directory(path):
+    # Use the resolved path and no-follow directory descriptors. mkdir only
+    # adds missing directories; neither it nor symlink replaces an existing entry.
+    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
+    try:
+        for part in Path(path).parts[1:]:
+            flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
+            try:
+                child = os.open(part, flags, dir_fd=fd)
+            except FileNotFoundError:
+                os.mkdir(part, dir_fd=fd)
+                child = os.open(part, flags, dir_fd=fd)
+            os.close(fd)
+            fd = child
+        return fd
+    except BaseException:
+        os.close(fd)
+        raise
+
+
+def main():
+    mode, steam, library, saved = sys.argv[1:]
+    plan = inspect(steam, library)
+    if mode == "inspect":
+        print(json.dumps(plan, sort_keys=True))
+        return
+    if mode not in ("verify", "link") or plan != json.loads(saved):
+        raise ValueError("The Steam folder or storage changed. Try again when it is available.")
+    if mode == "verify" or plan["root"]["exists"]:
+        return
+    target_fd = open_directory(plan["target"]["path"])
+    os.close(target_fd)
+    root = Path(plan["root"]["path"])
+    parent_fd = open_directory(root.parent)
+    try:
+        os.symlink(library, root.name, dir_fd=parent_fd)
+    finally:
+        os.close(parent_fd)
+
+
+if __name__ == "__main__":
+    try:
+        main()
+    except (OSError, ValueError, RuntimeError) as error:
+        print("Steam folder check: " + str(error), file=sys.stderr)
+        sys.exit(1)
+PY_STEAM_ROOT
+}
+
 fetch_proton_latest_release() {
   local api_url="$1"
   local asset_pattern="$2"
   local tag_prefix_to_strip="$3"
   local var_prefix="$4"
   local display_name="$5"
 
   log_info "Fetching latest ${display_name} release from GitHub..."
@@ -73,149 +241,2439 @@ fetch_proton_latest_release() {
   eval "${var_prefix}_TAR='${tar_name}'"
   eval "${var_prefix}_DIR='${dir_name}'"
   eval "${var_prefix}_URL='${download_url}'"
 
   log_info "${display_name} latest version: ${version_clean}"
   log_info "${display_name} download URL: ${download_url}"
 }
 
-install_fex_config() {
-  log_info "Installing FEX config..."
-  cp -r "/usr/config/fex-emu" "/storage/.config/" || die "Failed to copy FEX config."
-}
-
 ensure_fex_rootfs() {
-  rm -rf ${FEX_DATA}/RootFS/ArchLinux* || die "Failed to remove existing FEX RootFS."
+  log_info "Preparing the Steam support environment. This may take a while..."
+  # FEXRootFSFetcher also writes Config.json. Isolate that write, then commit
+  # the fully overlaid RootFS and packaged config together. Never clean by glob.
+  if /usr/bin/python3 -I -S -B - "${FEX_DATA}" <<'PY_STEAM_FEX'
+import fcntl
+import hashlib
+import json
+import os
+from pathlib import Path
+import re
+import resource
+import selectors
+import shutil
+import signal
+import stat
+import subprocess
+import sys
+import time
 
-  if [ ! -d "${FEX_DATA}/RootFS/ArchLinux" ]; then
-    log_info "FEX needs to download rootfs before starting Steam. This may take a while..."
-    FEXRootFSFetcher --distro-name=arch --distro-version=rolling -y -x || die "Failed to fetch FEX RootFS."
-    rm -rf ${FEX_DATA}/RootFS/ArchLinux.sqsh || die "Failed to remove FEX RootFS sqsh."
-  fi
+CONFIG = Path("/storage/.config/fex-emu")
+DEFAULTS = Path("/usr/config/fex-emu")
+OVERLAYS = (
+    (Path("/usr/lib/liblsfg-vk-layer.so"), "usr/lib/liblsfg-vk-layer.so"),
+    (Path("/usr/share/fex-emu/liblsfg-vk-layer-x86.so"), "usr/lib/liblsfg-vk-layer-x86.so"),
+    (Path("/usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation.json"),
+     "usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation.json"),
+    (Path("/usr/share/fex-emu/VkLayer_LSFGVK_frame_generation-x86.json"),
+     "usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation-x86.json"),
+)
+FETCHER = "/usr/bin/FEXRootFSFetcher"
+RESERVE = 256 * 1024 * 1024
+MAX_FILE = 2 * 1024 * 1024 * 1024
+MAX_TREE = 16 * 1024 * 1024 * 1024
+MAX_CONFIG = 64 * 1024 * 1024
+MAX_ENTRIES = 250000
+FETCH_SECONDS = 900
+TOTAL_SECONDS = 1800
+ICD = "usr/share/vulkan/icd.d/freedreno_icd.x86_64.json"
+
+
+def ident(path):
+    try:
+        info = path.lstat()
+    except FileNotFoundError:
+        return None
+    if not stat.S_ISDIR(info.st_mode):
+        raise RuntimeError("FEX replacement requires real directories: " + str(path))
+    return [info.st_dev, info.st_ino]
+
+
+def no_mounts(path):
+    boundary = path.absolute()
+    for row in Path("/proc/self/mountinfo").read_text().splitlines():
+        field = row.split()[4]
+        mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field))
+        if mount == boundary or boundary in mount.parents:
+            raise RuntimeError("Release mounted FEX paths before refreshing: " + str(path))
+
+
+def parents(path):
+    # No symlinked destination ancestors: do not normalize another storage view.
+    for item in reversed((path, *path.parents)):
+        if ident(item) is None:
+            item.mkdir()
+        ident(item)
+
+
+def capacity(path, required=0):
+    info = os.statvfs(path)
+    if info.f_bavail * info.f_frsize < RESERVE + required:
+        raise RuntimeError("Not enough free space to keep the existing FEX environment.")
+
+
+def tree_budget(path, limit):
+    no_mounts(path)
+    total = count = 0
+    for base, dirs, files in os.walk(path, followlinks=False):
+        for name in dirs + files:
+            info = (Path(base) / name).lstat()
+            if not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode)):
+                raise RuntimeError("Unsupported entry in the FEX staging tree.")
+            count += 1
+            total += info.st_size + 4096
+            if info.st_size > MAX_FILE or total > limit or count > MAX_ENTRIES:
+                raise RuntimeError("FEX staging exceeds the bounded file/space budget.")
+    return total
+
+
+def inside(root, relative):
+    path = root / relative
+    target = path.resolve(strict=True)
+    if not target.is_relative_to(root.resolve(strict=True)) or not target.is_file():
+        raise RuntimeError("Missing or escaping FEX file: " + relative)
+    return target
+
+
+def document(path):
+    if path.stat().st_size > 1024 * 1024:
+        raise RuntimeError("FEX metadata exceeds its size bound.")
+    data = json.loads(path.read_text())
+    if not isinstance(data, dict):
+        raise RuntimeError("FEX metadata is not a JSON object.")
+    return data
+
+
+def elf(path, machine):
+    with path.open("rb") as stream:
+        header = stream.read(20)
+    if (len(header) != 20 or header[:6] != b"\x7fELF\x02\x01"
+            or int.from_bytes(header[18:20], "little") != machine):
+        raise RuntimeError("Missing or wrong-architecture FEX binary: " + str(path))
+
+
+def digest(path):
+    result = hashlib.sha256()
+    with path.open("rb") as stream:
+        for block in iter(lambda: stream.read(1024 * 1024), b""):
+            result.update(block)
+    return result.hexdigest()
+
+
+def validate(root, config):
+    ident(root)
+    ident(config)
+    required = ["usr/bin/env", "usr/lib/ld-linux-x86-64.so.2", "usr/lib/libc.so.6",
+                "graphics_provider.json", ICD] + [rel for _, rel in OVERLAYS]
+    for rel in required[:3]:
+        elf(inside(root, rel), 62)
+    if not document(inside(root, "graphics_provider.json")):
+        raise RuntimeError("Empty graphics provider description.")
+    if document(inside(root, ICD)).get("ICD", {}).get("library_path") != "libvulkan_freedreno.so":
+        raise RuntimeError("Freedreno ICD does not select the host driver.")
+    elf(inside(root, OVERLAYS[0][1]), 183)
+    elf(inside(root, OVERLAYS[1][1]), 62)
+    for index, suffix in ((2, ""), (3, "_x86")):
+        layer = document(inside(root, OVERLAYS[index][1])).get("layer", {})
+        if (layer.get("name") != "VK_LAYER_LSFGVK_frame_generation" + suffix
+                or layer.get("library_path") != "/usr/lib/liblsfg-vk-layer" + ("-x86" if suffix else "") + ".so"):
+            raise RuntimeError("Invalid LSFG layer description.")
+    if document(inside(config, "Config.json")).get("Config", {}).get("RootFS") != "ArchLinux":
+        raise RuntimeError("FEX config does not select the prepared ArchLinux tree.")
+    packaged = {}
+    for base, dirs, files in os.walk(DEFAULTS, followlinks=False):
+        for name in dirs + files:
+            source = Path(base) / name
+            if source.is_symlink():
+                raise RuntimeError("Unexpected link in packaged FEX config.")
+            if source.is_file():
+                rel = str(source.relative_to(DEFAULTS))
+                packaged[rel] = digest(inside(config, rel))
+                if packaged[rel] != digest(source):
+                    raise RuntimeError("Packaged FEX config copy failed validation: " + rel)
+    return {"root": {rel: digest(inside(root, rel)) for rel in required}, "config": packaged}
+
+
+def overlay(root):
+    for source, rel in OVERLAYS:
+        # A RootFS symlink must never redirect a host-side overlay copy.
+        dest = root / rel
+        parent = dest.parent.resolve(strict=True)
+        if not parent.is_relative_to(root.resolve(strict=True)) or dest.is_symlink():
+            raise RuntimeError("Unsafe FEX overlay destination: " + rel)
+        if not source.is_file() or source.stat().st_size > MAX_CONFIG:
+            raise RuntimeError("Required FEX overlay is missing or oversized: " + source.name)
+        shutil.copy2(source, dest)
+    for rel, section, key, old, new in (
+        (OVERLAYS[3][1], "layer", "name", "VK_LAYER_LSFGVK_frame_generation", "VK_LAYER_LSFGVK_frame_generation_x86"),
+        (ICD, "ICD", "library_path", "/usr/lib/libvulkan_freedreno.so", "libvulkan_freedreno.so"),
+    ):
+        path = inside(root, rel)
+        data = document(path)
+        if data.get(section, {}).get(key) not in (old, new):
+            raise RuntimeError("Unexpected FEX overlay metadata: " + rel)
+        data[section][key] = new
+        path.write_text(json.dumps(data, indent=2) + "\n")
+
+
+def config_copy(source, destination):
+    # Preserve extra config files, but apply the packaged defaults just as the
+    # previous cp -r did. Do not follow any existing config link when overlaying.
+    ident(source)
+    for base, dirs, files in os.walk(source, followlinks=False):
+        relative = Path(base).relative_to(source)
+        target = destination / relative
+        if target.is_symlink():
+            raise RuntimeError("Refusing a linked config overlay directory.")
+        target.mkdir(exist_ok=True)
+        for name in dirs + files:
+            item, out = Path(base) / name, target / name
+            if out.is_symlink():
+                raise RuntimeError("Refusing a linked config overlay entry.")
+            if item.is_symlink():
+                if out.exists():
+                    raise RuntimeError("Conflicting config link.")
+                out.symlink_to(os.readlink(item))
+            elif item.is_file():
+                if out.exists() and not out.is_file():
+                    raise RuntimeError("Conflicting config entry.")
+                shutil.copy2(item, out)
+        shutil.copystat(base, target)
 
-  cp -f "/usr/lib/liblsfg-vk-layer.so" "${FEX_ARCH_USR_LIB}"  || die "Failed to copy liblsfg-vk-layer.so."
-  cp -f "/usr/share/fex-emu/liblsfg-vk-layer-x86.so" "${FEX_ARCH_USR_LIB}"  || die "Failed to copy liblsfg-vk-layer-x86.so."
-  cp -f "/usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation.json" \
-     "${FEX_ARCH_ROOT}/usr/share/vulkan/implicit_layer.d/" || die "Failed to copy VkLayer_LSFGVK_frame_generation.json to ArchLinux rootfs."
-  cp -f "/usr/share/fex-emu/VkLayer_LSFGVK_frame_generation-x86.json" \
-     "${FEX_ARCH_ROOT}/usr/share/vulkan/implicit_layer.d/" || die "Failed to copy VkLayer_LSFGVK_frame_generation-x86.json to ArchLinux rootfs."
-  sed -i 's/"name": "VK_LAYER_LSFGVK_frame_generation"/"name": "VK_LAYER_LSFGVK_frame_generation_x86"/' "${FEX_ARCH_ROOT}/usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation-x86.json"
-  sed -i 's|"library_path": "/usr/lib/libvulkan_freedreno.so"|"library_path": "libvulkan_freedreno.so"|' \
-    ${FEX_ARCH_ROOT}/usr/share/vulkan/icd.d/freedreno_icd.x86_64.json
+
+def fetch_environment(work):
+    # No inherited FEX_*, STEAM_COMPAT_*, or loader/config overrides.
+    # HOME must exist or FEX falls back to passwd/PWD. Both FEX paths need '/'.
+    environment = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C",
+            "HOME": str(work / "home"), "PWD": str(work / "home"),
+            "TMPDIR": str(work / "tmp"), "XDG_DATA_HOME": str(work / "data"),
+            "XDG_CONFIG_HOME": str(work / "fetch-config"), "XDG_CACHE_HOME": str(work / "cache"),
+            "FEX_APP_DATA_LOCATION": str(work / "data") + "/",
+            "FEX_APP_CONFIG_LOCATION": str(work / "fetch-config") + "/",
+            "FEX_APP_CACHE_LOCATION": str(work / "cache") + "/"}
+    # Keep the existing transport's explicit proxy settings; never log values.
+    for key in ("http_proxy", "https_proxy", "all_proxy", "no_proxy",
+                "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY"):
+        if key in os.environ:
+            environment[key] = os.environ[key]
+    return environment
+
+
+def fetch_rootfs(work):
+    # The guardian survives SIGKILL of the updater, holds its inherited flock,
+    # and kills the entire fetcher/curl/extractor group on pipe EOF or timeout.
+    read_fd, write_fd = os.pipe()
+    guardian = os.fork()
+    if guardian == 0:
+        os.close(write_fd)
+        os.setsid()
+        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
+            signal.signal(sig, interrupted)
+        signal.alarm(0)
+        proc = None
+        result = 1
+        try:
+            resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_FILE, MAX_FILE))
+            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
+            proc = subprocess.Popen(
+                [FETCHER, "--distro-name=arch", "--distro-version=rolling", "-y", "-x", "--force-ui=tty"],
+                cwd=work / "home", env=fetch_environment(work), stdin=subprocess.DEVNULL,
+                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
+            deadline = time.monotonic() + FETCH_SECONDS
+            next_scan = 0.0
+            selector = selectors.DefaultSelector()
+            selector.register(read_fd, selectors.EVENT_READ)
+            selector.register(proc.stdout, selectors.EVENT_READ)
+            logged = 0
+            with (work / "fetch.log").open("wb") as log:
+                while True:
+                    capacity(work)
+                    if time.monotonic() >= next_scan:
+                        tree_budget(work / "data", MAX_TREE)
+                        next_scan = time.monotonic() + 1
+                    if time.monotonic() >= deadline:
+                        raise RuntimeError("FEX fetch/extraction reached its time limit.")
+                    for key, _ in selector.select(0.2):
+                        if key.fd == read_fd:
+                            raise RuntimeError("FEX updater exited; cancelling its fetcher group.")
+                        chunk = os.read(key.fd, 65536)
+                        if not chunk:
+                            selector.unregister(key.fileobj)
+                        else:
+                            saved = chunk[:max(0, 65536 - logged)]
+                            log.write(saved)
+                            logged += len(saved)
+                    code = proc.poll()
+                    if code is not None:
+                        if code != 0:
+                            raise RuntimeError("FEX fetcher exited " + str(code))
+                        result = 0
+                        break
+        except BaseException as error:
+            print("FEX fetch stopped: " + str(error), file=sys.stderr, flush=True)
+        finally:
+            for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
+                signal.signal(sig, signal.SIG_IGN)
+            if proc is not None:
+                try:
+                    os.killpg(proc.pid, signal.SIGKILL)
+                except ProcessLookupError:
+                    pass
+                try:
+                    proc.wait(timeout=5)
+                except subprocess.TimeoutExpired:
+                    result = 1
+            os.close(read_fd)
+            os._exit(result)
+    os.close(read_fd)
+    try:
+        _, status = os.waitpid(guardian, 0)
+        if os.waitstatus_to_exitcode(status) != 0:
+            raise RuntimeError("FEX download or extraction did not finish.")
+    finally:
+        # On a catchable interruption the guardian sees EOF and kills children
+        # before rollback can remove their staging directory. Mask repeated
+        # catchable signals while waiting; SIGKILL still leaves the guardian's
+        # inherited lock held until its process group has been killed.
+        mask = signal.pthread_sigmask(signal.SIG_BLOCK,
+                                     {signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM})
+        try:
+            os.close(write_fd)
+            try:
+                os.waitpid(guardian, 0)
+            except ChildProcessError:
+                pass
+        finally:
+            signal.pthread_sigmask(signal.SIG_SETMASK, mask)
+
+
+class FexUpdate:
+    def __init__(self, data):
+        self.data = data
+        self.root = data / "RootFS" / "ArchLinux"
+        self.config = CONFIG
+        parents(self.root.parent)
+        parents(self.config.parent)
+        self.device = self.data.stat().st_dev
+        if self.config.parent.stat().st_dev != self.device:
+            raise RuntimeError("FEX root and config must share a filesystem for recovery.")
+        self.work = data / ".steam-fex-update"
+        self.state = None
+        self.check_live()
+
+    def check_live(self):
+        for path in (self.root, self.config):
+            value = ident(path)
+            if value is not None and value[0] != self.device:
+                raise RuntimeError("FEX destination is on another filesystem.")
+            no_mounts(path)
+
+    def write_state(self):
+        pending = self.work / "state.tmp"
+        with pending.open("w") as stream:
+            json.dump(self.state, stream)
+            stream.flush()
+            os.fsync(stream.fileno())
+        os.replace(pending, self.work / "state.json")
+        fd = os.open(self.work, os.O_RDONLY | os.O_DIRECTORY)
+        try:
+            os.fsync(fd)
+        finally:
+            os.close(fd)
+
+    def clean(self):
+        no_mounts(self.work)
+        for item in self.work.iterdir():
+            if item.name == "state.json":
+                continue
+            if item.is_dir() and not item.is_symlink():
+                shutil.rmtree(item)
+            else:
+                item.unlink()
+        (self.work / "state.json").unlink(missing_ok=True)
+        self.work.rmdir()
+        self.state = None
+
+    def recover(self):
+        if ident(self.work) is None:
+            return
+        no_mounts(self.work)
+        journal = self.work / "state.json"
+        if not journal.exists():
+            # Before first journal publication only this temporary file may
+            # exist. After final cleanup the directory may be empty.
+            entries = list(self.work.iterdir())
+            if entries:
+                if len(entries) != 1 or entries[0].name != "state.tmp" or not stat.S_ISREG(entries[0].lstat().st_mode):
+                    raise RuntimeError("Unrecognized FEX staging directory; retaining it.")
+                entries[0].unlink()
+            self.work.rmdir()
+            return
+        if journal.is_symlink() or not journal.is_file() or journal.stat().st_size > 65536:
+            raise RuntimeError("Invalid FEX recovery journal; retaining it.")
+        self.state = json.loads(journal.read_text())
+        if (self.state.get("format") != 1 or self.state.get("data") != str(self.data)
+                or self.state.get("config") != str(self.config)
+                or self.state.get("phase") not in ("staging", "prepared", "committed")):
+            raise RuntimeError("Unrecognized FEX recovery journal; retaining it.")
+        self.check_live()
+        phase = self.state["phase"]
+        if phase == "committed":
+            if (any(ident(getattr(self, name)) != self.state["new"][name] for name in ("root", "config"))
+                    or validate(self.root, self.config) != self.state["validation"]):
+                raise RuntimeError("Committed FEX environment changed; retaining recovery data.")
+        elif phase == "prepared":
+            for name in ("config", "root"):
+                live = getattr(self, name)
+                old, new = self.state["old"][name], self.state["new"][name]
+                previous = self.work / ("previous-" + name)
+                current = ident(live)
+                if current == old:
+                    if ident(previous) is not None:
+                        raise RuntimeError("Ambiguous FEX recovery copy; retaining it.")
+                    continue
+                if old is not None and ident(previous) != old:
+                    raise RuntimeError("Previous FEX identity changed; retaining recovery data.")
+                if current == new:
+                    discard = self.work / ("discard-" + name)
+                    if ident(discard) is not None:
+                        raise RuntimeError("Ambiguous FEX discard path; retaining it.")
+                    os.rename(live, discard)
+                elif current is not None:
+                    raise RuntimeError("FEX destination changed outside this update.")
+                if old is not None:
+                    os.rename(previous, live)
+        self.clean()
+
+    def begin(self):
+        self.work.mkdir(mode=0o700)
+        self.state = {"format": 1, "data": str(self.data), "config": str(self.config), "phase": "staging",
+                      "old": {name: ident(getattr(self, name)) for name in ("root", "config")}}
+        self.write_state()
+        for name in ("home", "tmp", "data", "cache", "fetch-config", "new-config"):
+            (self.work / name).mkdir()
+
+    def stage(self):
+        # Inspect required local inputs before allowing a download.
+        if ident(DEFAULTS) is None:
+            raise RuntimeError("Packaged FEX config is missing.")
+        needed = tree_budget(DEFAULTS, MAX_CONFIG)
+        if ident(self.config) is not None:
+            needed += tree_budget(self.config, MAX_CONFIG)
+        capacity(self.work, needed)
+        for source, _ in OVERLAYS:
+            if not source.is_file() or source.stat().st_size > MAX_CONFIG:
+                raise RuntimeError("Required FEX overlay is missing or oversized: " + source.name)
+        config = self.work / "new-config"
+        if ident(self.config) is not None:
+            config_copy(self.config, config)
+        config_copy(DEFAULTS, config)
+        tree_budget(config, MAX_CONFIG)
+        fetch_rootfs(self.work)
+        root = self.work / "data" / "RootFS" / "ArchLinux"
+        if ident(root) is None:
+            raise RuntimeError("Fetcher did not produce an extracted ArchLinux directory.")
+        if document(inside(self.work / "fetch-config", "Config.json")).get("Config", {}).get("RootFS") != "ArchLinux":
+            raise RuntimeError("Fetcher selected an unexpected RootFS or left an unextracted image.")
+        tree_budget(self.work / "data", MAX_TREE)
+        overlay(root)
+        capacity(self.work)
+        self.check_live()
+        validation = validate(root, config)
+        if any(ident(getattr(self, name)) != self.state["old"][name] for name in ("root", "config")):
+            raise RuntimeError("FEX destination changed while preparing its replacement.")
+        self.state.update(phase="prepared", new={"root": ident(root), "config": ident(config)}, validation=validation)
+        self.write_state()
+
+    def activate(self):
+        for name, staged in (("root", self.work / "data" / "RootFS" / "ArchLinux"),
+                             ("config", self.work / "new-config")):
+            live = getattr(self, name)
+            if ident(live) != self.state["old"][name]:
+                raise RuntimeError("FEX destination changed before activation.")
+            if self.state["old"][name] is not None:
+                os.rename(live, self.work / ("previous-" + name))
+            os.rename(staged, live)
+        if validate(self.root, self.config) != self.state["validation"]:
+            raise RuntimeError("Activated FEX environment failed validation.")
+        self.state["phase"] = "committed"
+        self.write_state()
+        self.clean()
+
+
+def interrupted(signum, frame):
+    raise InterruptedError("FEX refresh interrupted by signal " + str(signum))
+
+
+def main():
+    update = FexUpdate(Path(sys.argv[1]))
+    fd = os.open(update.data / ".steam-fex-update.lock", os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
+    try:
+        if not stat.S_ISREG(os.fstat(fd).st_mode) or os.fstat(fd).st_nlink != 1:
+            raise RuntimeError("Invalid FEX update lock.")
+        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
+        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
+            signal.signal(sig, interrupted)
+        signal.alarm(TOTAL_SECONDS)
+        try:
+            update.recover()
+            capacity(update.data)
+            update.begin()
+            update.stage()
+            update.activate()
+            return 0
+        except Exception as error:
+            print("FEX refresh failed: " + str(error), file=sys.stderr)
+            signal.alarm(0)
+            # Do not interrupt rollback with a second catchable termination.
+            for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
+                signal.signal(sig, signal.SIG_IGN)
+            try:
+                update.recover()
+            except Exception as recovery_error:
+                print("FEX recovery data retained at " + str(update.work) + ": " + str(recovery_error), file=sys.stderr)
+            return 1
+        finally:
+            signal.alarm(0)
+    finally:
+        os.close(fd)
+
+
+if __name__ == "__main__":
+    try:
+        sys.exit(main())
+    except Exception as error:
+        print("FEX refresh refused: " + str(error), file=sys.stderr)
+        sys.exit(1)
+PY_STEAM_FEX
+  then
+    log_info "Steam support environment is ready."
+  else
+    die "The Steam support environment could not be updated. Try Install Steam again."
+  fi
 }
 
 link_steam_library() {
-  log_info "Linking Steam library..."
-  if [ -d "${STEAM}" ] && [ ! -L "${STEAM}" ]; then
-    rm -rf "${STEAM}" || die "Failed to remove existing Steam directory."
-  fi
-  mkdir -p "${STEAM_GAMES_ROOT}"
-  ln -sfn "${STEAM_GAMES_ROOT}" "${STEAM}" || die "Failed to create Steam symlink."
+  log_info "Checking Steam library..."
+  steam_root_layout link || die "The Steam library could not be prepared. Installation stopped."
 }
 
 ensure_steam_desktop_stub() {
   log_info "Ensuring Steam desktop stub exists..."
   mkdir -p "${APPLICATIONS}"
   touch "${APPLICATIONS}/Steam.desktop" || die "Failed to create Steam.desktop stub."
 }
 
 install_steam_runtime_arm64() {
   log_info "Downloading and installing Steam runtime (ARM64)..."
-  local tar_path="${STEAM}/steam-runtime-steamrt-arm64.tar.xz"
-
-  local runtime_version
-  runtime_version=$(curl -fsSL "${RUNTIME_TAR_VERSION_URL}" | tr -d '[:space:]') || die "Failed to fetch Steam runtime version."
-  [ -n "${runtime_version}" ] || die "Steam runtime version string is empty."
-  local RUNTIME_TAR_URL="${RUNTIME_TAR_BASE}/${runtime_version}/steam-runtime-steamrt-arm64.tar.xz"
-  log_info "Steam runtime URL: ${RUNTIME_TAR_URL}"
-
-  wget -c -t 5 -O "${tar_path}" "${RUNTIME_TAR_URL}" || die "Failed to download Steam runtime."
-  tar xvf "${tar_path}" -C "${STEAM}" || die "Failed to extract Steam runtime."
-  rm -f "${tar_path}"
-
-  local target
-  target=$(echo "${STEAM}"/steam-runtime-steamrt-arm64/steamrt3c_platform_*/files/lib/aarch64-linux-gnu/libibus-1.0.so.5.* | head -n 1)
-  if [ ! -f "$target" ]; then
-      die "Could not locate libibus target inside runtime."
-  fi
+  # Keep the existing runtime until the complete staged archive and both library
+  # links validate. The journal also recovers a process killed between renames.
+  # This transaction does not cover the separate FEX/client/Proton operations.
+  if python3 - "${STEAM}" "${RUNTIME_TAR_VERSION_URL}" "${RUNTIME_TAR_BASE}" <<'PY_STEAM_RUNTIME'
+import ctypes
+import fcntl
+import hashlib
+import json
+import lzma
+import os
+from pathlib import Path, PurePosixPath
+import re
+import resource
+import shutil
+import signal
+import stat
+import subprocess
+import sys
+import tarfile
+
+RUNTIME = "steam-runtime-steamrt-arm64"
+LINKS = ("libibus-1.0.so.5", "libva.so.2")
+RESERVE = 256 * 1024 * 1024
+MAX_ARCHIVE = 2 * 1024 * 1024 * 1024
+MAX_EXPANDED = 16 * 1024 * 1024 * 1024
+MAX_MEMBERS = 250000
+MAX_LINK_BACKUP = 64 * 1024 * 1024
+
+
+def identity(path):
+    try:
+        info = path.lstat()
+    except FileNotFoundError:
+        return None
+    if not stat.S_ISDIR(info.st_mode):
+        raise RuntimeError("Runtime transaction directory is not a real directory: " + str(path))
+    return [info.st_dev, info.st_ino]
+
+
+def describe(path):
+    if path.is_symlink():
+        return {"kind": "link", "target": os.readlink(path)}
+    if not path.exists():
+        return {"kind": "absent"}
+    if not path.is_file():
+        raise RuntimeError("Refusing to replace a non-file library entry: " + str(path))
+    info = path.stat()
+    if info.st_size > MAX_LINK_BACKUP:
+        raise RuntimeError("Existing library entry exceeds the bounded backup size.")
+    return {"kind": "file", "sha256": digest(path), "mode": stat.S_IMODE(info.st_mode),
+            "mtime_ns": info.st_mtime_ns}
+
+
+def digest(path):
+    with path.open("rb") as stream:
+        return hashlib.file_digest(stream, "sha256").hexdigest()
+
+
+def capacity(root, needed):
+    if shutil.disk_usage(root).free < needed + RESERVE:
+        raise RuntimeError("Not enough free space to keep the previous Steam runtime while replacing it.")
+
+
+def directory(path, device):
+    if path.is_symlink() or not path.is_dir() or path.stat().st_dev != device:
+        raise RuntimeError("Runtime update needs real directories on the Steam filesystem: " + str(path))
+
 
-  mkdir -p "${STEAM}/lib/aarch64-linux-gnu"
-  ln -sf "${target}" "${STEAM}/lib/aarch64-linux-gnu/libibus-1.0.so.5" || die "Failed to symlink libibus."
+def no_mounts(path):
+    # st_dev alone misses a bind mount on the same filesystem. Never walk a
+    # mounted subtree while retiring or rolling back an owned runtime tree.
+    boundary = path.resolve()
+    for line in Path("/proc/self/mountinfo").read_text().splitlines():
+        field = line.split()[4]
+        mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field))
+        if mount == boundary or boundary in mount.parents:
+            raise RuntimeError("Mounted runtime paths must be released before replacement: " + str(path))
 
-  target=$(echo "${STEAM}"/steam-runtime-steamrt-arm64/steamrt3c_platform_*/files/lib/aarch64-linux-gnu/libva.so.2.* | head -n 1)
-  if [ ! -f "$target" ]; then
-      die "Could not locate libva target inside runtime."
-    fi
-  ln -sf "${target}" "${STEAM}/lib/aarch64-linux-gnu/libva.so.2" || die "Failed to symlink libva."
+
+def validate(runtime):
+    directory(runtime, runtime.parent.stat().st_dev)
+    platforms = list(runtime.glob("steamrt3c_platform_*"))
+    if len(platforms) != 1 or platforms[0].is_symlink() or not platforms[0].is_dir():
+        raise RuntimeError("Expected one complete Steam ARM64 platform directory.")
+    targets = {}
+    for name in LINKS:
+        matches = list((platforms[0] / "files/lib/aarch64-linux-gnu").glob(name + ".*"))
+        if len(matches) != 1:
+            raise RuntimeError("Missing or ambiguous runtime library: " + name)
+        target = matches[0]
+        if not target.resolve(strict=True).is_relative_to(runtime.resolve(strict=True)):
+            raise RuntimeError("Runtime library escapes the staged runtime.")
+        with target.open("rb") as stream:
+            header = stream.read(20)
+        if (len(header) != 20 or header[:6] != b"\x7fELF\x02\x01"
+                or header[16:20] != b"\x03\x00\xb7\x00"):
+            raise RuntimeError("Runtime library is not an ARM64 shared object: " + name)
+        targets[name] = {"path": str(target.relative_to(runtime)), "sha256": digest(target)}
+    return targets
+
+
+class RuntimeUpdate:
+    def __init__(self, root):
+        self.link_root = Path(os.path.abspath(root))
+        self.root = root.resolve(strict=True)
+        if self.root == Path("/"):
+            raise RuntimeError("Refusing the filesystem root as the Steam directory.")
+        self.device = self.root.stat().st_dev
+        self.work = self.root / ".steam-runtime-update"
+        self.live = self.root / RUNTIME
+        self.lib = self.root / "lib/aarch64-linux-gnu"
+        self.state = None
+
+    def write_state(self):
+        pending = self.work / "state.tmp"
+        with pending.open("w") as stream:
+            json.dump(self.state, stream)
+            stream.flush()
+            os.fsync(stream.fileno())
+        os.replace(pending, self.work / "state.json")
+        fd = os.open(self.work, os.O_RDONLY | os.O_DIRECTORY)
+        try:
+            os.fsync(fd)
+        finally:
+            os.close(fd)
+
+    def clean(self):
+        # Keep the journal until all other owned remnants are gone. A killed
+        # cleanup is retried without accumulating another staging tree.
+        for child in self.work.iterdir():
+            if child.name == "state.json":
+                continue
+            if child.is_dir() and not child.is_symlink():
+                no_mounts(child)
+                shutil.rmtree(child)
+            else:
+                child.unlink()
+        (self.work / "state.json").unlink(missing_ok=True)
+        self.work.rmdir()
+        self.state = None
+
+    def check_parents(self):
+        for path in (self.root / "lib", self.lib):
+            if path.exists() or path.is_symlink():
+                directory(path, self.device)
+                no_mounts(path)
+
+    def recover(self):
+        if not self.work.exists() and not self.work.is_symlink():
+            return
+        directory(self.work, self.device)
+        journal = self.work / "state.json"
+        if not journal.exists():
+            # mkdir can be interrupted before the first journal is written.
+            # An empty directory is safe to remove; unknown contents are not.
+            self.work.rmdir()
+            return
+        if journal.is_symlink() or not journal.is_file() or journal.stat().st_size > 65536:
+            raise RuntimeError("Refusing an invalid runtime recovery journal.")
+        self.state = json.loads(journal.read_text())
+        if (self.state.get("format") != 1 or self.state.get("root") != str(self.root)
+                or self.state.get("link_root") != str(self.link_root)):
+            raise RuntimeError("Unrecognized runtime recovery journal; retaining it.")
+        no_mounts(self.work)
+        phase = self.state["phase"]
+        if phase in ("prepared", "committed"):
+            no_mounts(self.live)
+            if (set(self.state["targets"]) != set(LINKS)
+                    or set(self.state["links"]) != set(LINKS)
+                    or any(p not in ("lib/aarch64-linux-gnu", "lib")
+                           for p in self.state["created_dirs"])):
+                raise RuntimeError("Invalid runtime recovery paths; retaining them.")
+            for target in self.state["targets"].values():
+                relative = PurePosixPath(target["path"])
+                if relative.is_absolute() or ".." in relative.parts or not relative.parts:
+                    raise RuntimeError("Invalid runtime recovery target.")
+        self.check_parents()
+        if phase == "committed":
+            if identity(self.live) != self.state["candidate_id"] or validate(self.live) != self.state["targets"]:
+                raise RuntimeError("Committed runtime changed; keeping its recovery copy.")
+            for name in LINKS:
+                if describe(self.lib / name) != self.new_link(name):
+                    raise RuntimeError("Committed library link changed; keeping its recovery copy.")
+        elif phase == "prepared":
+            old_id = self.state["old_id"]
+            live_id = identity(self.live)
+            backup = self.work / "previous"
+            if old_id is not None and live_id == old_id:
+                pass  # Not activated yet, or rollback was itself interrupted.
+            else:
+                if old_id is not None and identity(backup) != old_id:
+                    raise RuntimeError("Previous runtime identity changed; no automatic cleanup.")
+                if live_id == self.state["candidate_id"]:
+                    os.replace(self.live, self.work / "discard")
+                elif live_id is not None:
+                    raise RuntimeError("Active runtime identity changed; no automatic cleanup.")
+                if old_id is not None:
+                    os.replace(backup, self.live)
+            for name in LINKS:
+                saved = self.state["links"][name]
+                live = self.lib / name
+                current = describe(live)
+                if current == saved:
+                    continue
+                if current != self.new_link(name):
+                    raise RuntimeError("Library link changed outside the update; retaining recovery data.")
+                if saved["kind"] == "absent":
+                    live.unlink()
+                else:
+                    restore = self.work / ("restore-" + name)
+                    restore.unlink(missing_ok=True)
+                    shutil.copy2(self.work / ("saved-" + name), restore, follow_symlinks=False)
+                    os.replace(restore, live)
+            for relative in self.state["created_dirs"]:
+                path = self.root / relative
+                if path.exists():
+                    path.rmdir()  # Never remove another writer's contents.
+        elif phase != "staging":
+            raise RuntimeError("Unknown runtime recovery phase; retaining it.")
+        self.clean()
+
+    def new_link(self, name):
+        return {"kind": "link", "target": str(self.link_root / RUNTIME / self.state["targets"][name]["path"])}
+
+    def begin(self):
+        self.work.mkdir(mode=0o700)
+        self.state = {"format": 1, "root": str(self.root), "link_root": str(self.link_root), "phase": "staging"}
+        self.write_state()
+        (self.work / "unpack").mkdir()
+
+    def prepare(self):
+        candidate = self.work / "unpack" / RUNTIME
+        targets = validate(candidate)
+        self.check_parents()
+        links = {name: describe(self.lib / name) for name in LINKS}
+        capacity(self.root, sum((self.lib / name).stat().st_size for name in LINKS
+                               if links[name]["kind"] == "file"))
+        for name in LINKS:
+            if links[name]["kind"] != "absent":
+                shutil.copy2(self.lib / name, self.work / ("saved-" + name), follow_symlinks=False)
+        old_id = identity(self.live)
+        no_mounts(self.live)
+        if old_id is not None and old_id[0] != self.device:
+            raise RuntimeError("Previous runtime is on a different filesystem.")
+        self.state.update(phase="prepared", targets=targets, links=links, old_id=old_id,
+                          candidate_id=identity(candidate),
+                          created_dirs=[p for p in ("lib/aarch64-linux-gnu", "lib")
+                                        if not (self.root / p).exists()])
+        self.write_state()  # The complete rollback description precedes every rename.
+
+    def activate(self):
+        self.lib.mkdir(parents=True, exist_ok=True)
+        if self.state["old_id"] is not None:
+            os.replace(self.live, self.work / "previous")
+        os.replace(self.work / "unpack" / RUNTIME, self.live)
+        for name in LINKS:
+            pending = self.work / ("new-" + name)
+            pending.symlink_to(self.new_link(name)["target"])
+            os.replace(pending, self.lib / name)
+        if validate(self.live) != self.state["targets"]:
+            raise RuntimeError("Activated runtime failed validation.")
+        for name in LINKS:
+            if describe(self.lib / name) != self.new_link(name) or not (self.lib / name).is_file():
+                raise RuntimeError("Activated runtime library link failed validation.")
+        self.state["phase"] = "committed"
+        self.write_state()  # Only this point permits retiring the superseded tree.
+        self.clean()
+
+
+def fetch_archive(update, version_url, base_url):
+    owner_pid = os.getpid()
+
+    def child_setup(limit=None):
+        # SIGKILL cannot run a Python cleanup handler. Linux must kill the
+        # transport child with its owner, before another updater can retry.
+        libc = ctypes.CDLL(None, use_errno=True)
+        if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:  # PR_SET_PDEATHSIG
+            raise OSError(ctypes.get_errno(), "Cannot bind downloader lifetime to installer")
+        if os.getppid() != owner_pid:  # Parent may have died before prctl.
+            os.kill(os.getpid(), signal.SIGKILL)
+        if limit is not None:
+            resource.setrlimit(resource.RLIMIT_FSIZE, (limit, limit))
+
+    version = subprocess.run(["curl", "-fsSL", "--connect-timeout", "10", "--max-time", "30",
+                              "--max-filesize", "128", version_url],
+                             check=True, capture_output=True, timeout=35, preexec_fn=child_setup).stdout.decode().strip()
+    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,79}", version):
+        raise RuntimeError("Invalid Steam runtime version.")
+    capacity(update.root, 1)
+    budget = min(MAX_ARCHIVE, shutil.disk_usage(update.root).free - RESERVE)
+    archive = update.work / "runtime.tar.xz"
+
+    subprocess.run(["wget", "-t", "3", "-T", "30", "-O", str(archive),
+                    base_url + "/" + version + "/" + RUNTIME + ".tar.xz"],
+                   check=True, timeout=900, preexec_fn=lambda: child_setup(budget))
+    return archive
+
+
+def unpack_archive(update, archive):
+    # Inspect the complete compressed stream (including its integrity footer)
+    # before extraction; never use the live Steam directory as tar's destination.
+    needed = 0
+    seen = set()
+    with lzma.open(archive, "rb") as stream:
+        with tarfile.open(fileobj=stream, mode="r|") as archive_stream:
+            for member in archive_stream:
+                path = PurePosixPath(member.name)
+                if (path.is_absolute() or ".." in path.parts or not path.parts
+                        or path.parts[0] != RUNTIME or path.as_posix() in seen or member.size < 0):
+                    raise RuntimeError("Unsafe or duplicate runtime archive path.")
+                if not (member.isfile() or member.isdir() or member.issym() or member.islnk()):
+                    raise RuntimeError("Unsupported runtime archive entry.")
+                seen.add(path.as_posix())
+                needed += ((member.size + 4095) // 4096) * 4096 + 8192
+                if len(seen) > MAX_MEMBERS or needed > MAX_EXPANDED:
+                    raise RuntimeError("Runtime archive exceeds the bounded extraction budget.")
+        while True:
+            chunk = stream.read(1024 * 1024)
+            if stream.tell() > MAX_EXPANDED:
+                raise RuntimeError("Runtime archive exceeds the decoded-stream budget.")
+            if not chunk:
+                break
+    capacity(update.root, needed)
+    with tarfile.open(archive, "r:xz") as payload:
+        payload.extractall(update.work / "unpack", filter="data")
+    capacity(update.root, 0)
+    archive.unlink()
+
+
+def interrupted(signum, frame):
+    raise InterruptedError("Steam runtime update interrupted by signal " + str(signum))
+
+
+def main():
+    update = RuntimeUpdate(Path(sys.argv[1]))
+    # A persistent lock inode serializes this component; never unlink the lock
+    # file while another invocation may have opened it. No service is started.
+    lock_path = update.root / ".steam-runtime-update.lock"
+    fd = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
+    try:
+        if not stat.S_ISREG(os.fstat(fd).st_mode):
+            raise RuntimeError("Runtime update lock is not a regular file.")
+        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
+        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
+            signal.signal(sig, interrupted)
+        signal.alarm(1800)
+        try:
+            update.recover()
+            update.check_parents()
+            capacity(update.root, 1)
+            update.begin()
+            archive = fetch_archive(update, sys.argv[2], sys.argv[3])
+            unpack_archive(update, archive)
+            update.prepare()
+            update.activate()
+            return 0
+        except Exception as error:
+            print("Steam runtime replacement failed: " + str(error), file=sys.stderr)
+            signal.alarm(0)
+            try:
+                update.recover()
+            except Exception as recovery_error:
+                print("Runtime recovery needs attention; previous data is retained at "
+                      + str(update.work) + ": " + str(recovery_error), file=sys.stderr)
+            return 1
+        finally:
+            signal.alarm(0)
+    finally:
+        os.close(fd)
+
+
+if __name__ == "__main__":
+    sys.exit(main())
+PY_STEAM_RUNTIME
+  then
+    return 0
+  fi
+  die "Steam runtime replacement failed. The installer has stopped."
 }
 
 install_steam_client_arm64() {
-  if [ -d "${CLIENT_DIR}" ]; then
-    log_info "Steam client already exists. Skipping."
+  if steam_client_state install; then
     return 0
   fi
-  log_info "Downloading and installing Steam client (ARM64)..."
-  local manifest target_file zip_path
+  die "Steam client setup could not finish. Existing client files were kept."
+}
+
+# The first call inspects only the client tree, before profile side effects.
+# Support metadata uses STEAM_DOT after profiles, preserving that override.
+# A legacy bootstrap check is not native readiness; no old receipt hash is used.
+steam_client_state() {
+  /usr/bin/python3 -I -S -B - "$1" "${STEAM_ROOT_PLAN}" "${STEAM_DOT:-}" "${STEAM_CLIENT_PLAN:-}" "${STEAM_CLIENT_METADATA_PLAN:-}" <<'PY_STEAM_CLIENT'
+# SPDX-License-Identifier: GPL-2.0-or-later
+# Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
+# #582: structure is a bootstrap check, never native readiness or account proof.
+import ctypes
+import errno
+import fcntl
+import hashlib
+import json
+import os
+from pathlib import Path
+import re
+import resource
+import selectors
+import signal
+import stat
+import struct
+import subprocess
+import sys
+import time
+import zlib
+
+CLIENT = "steamrtarm64"
+WORK = ".steam-client-update"
+LOCK = ".steam-client-update.lock"
+MAX_ZIP = 128 * 1024**2
+MAX_OUTPUT = 384 * 1024**2
+MAX_MEMBER = 128 * 1024**2
+MAX_JOURNAL = 2 * 1024**2
+RESERVE = 64 * 1024**2
+CORE = ("steam", "steamclient.so", "libtier0_s.so", "libvstdlib_s.so")
+NAME_MAP = {
+    "steamrtarm64\\libs/": "steamrtarm64/libs/",
+    "steamrtarm64\\swiftshader/": "steamrtarm64/swiftshader/",
+    "steamrtarm64\\libs\\libcurl.so": "steamrtarm64/libs/libcurl.so",
+    "steamrtarm64\\libs\\libnghttp2.so": "steamrtarm64/libs/libnghttp2.so",
+    "steamrtarm64\\libs\\libnghttp2.so.14": "steamrtarm64/libs/libnghttp2.so.14",
+}
+# Filled from the accepted 55-member format, not from a moving remote filename.
+EXPECTED = {'steamrtarm64/libs/': 'directory',
+ 'steamrtarm64/swiftshader/': 'directory',
+ 'steamrtarm64/builddate.txt': 'file',
+ 'steamrtarm64/chromehtml.so': 'file',
+ 'steamrtarm64/crashhandler.so': 'file',
+ 'steamrtarm64/filesystem_stdio.so': 'file',
+ 'steamrtarm64/fossilize_replay': 'file',
+ 'steamrtarm64/friendsui.so': 'file',
+ 'steamrtarm64/gameoverlayrenderer.so': 'file',
+ 'steamrtarm64/gameoverlayui': 'file',
+ 'steamrtarm64/gameoverlayui.so': 'file',
+ 'steamrtarm64/gldriverquery': 'file',
+ 'steamrtarm64/icudtl.dat': 'file',
+ 'steamrtarm64/libVkLayer_khronos_validation.so': 'file',
+ 'steamrtarm64/libVkLayer_steam_fossilize.so': 'file',
+ 'steamrtarm64/libaom.so.3': 'file',
+ 'steamrtarm64/libaudio.so': 'file',
+ 'steamrtarm64/libdav1d.so.6': 'file',
+ 'steamrtarm64/libmiles.so': 'file',
+ 'steamrtarm64/libminigbm.so': 'file',
+ 'steamrtarm64/libopenvr_api.so': 'file',
+ 'steamrtarm64/libpulsecommon-10.0.so': 'file',
+ 'steamrtarm64/libs/libcurl.so': 'link',
+ 'steamrtarm64/libs/libcurl.so.4.8.0': 'file',
+ 'steamrtarm64/libs/libnghttp2.so': 'link',
+ 'steamrtarm64/libs/libnghttp2.so.14': 'link',
+ 'steamrtarm64/libs/libnghttp2.so.14.20.1': 'file',
+ 'steamrtarm64/libsdkencryptedappticket.so': 'file',
+ 'steamrtarm64/libtier0_s.so': 'file',
+ 'steamrtarm64/libvideo.so': 'file',
+ 'steamrtarm64/libvk_swiftshader.so': 'file',
+ 'steamrtarm64/libvstdlib_s.so': 'file',
+ 'steamrtarm64/libvulkan.so': 'file',
+ 'steamrtarm64/libvulkan.so.1': 'file',
+ 'steamrtarm64/reaper': 'file',
+ 'steamrtarm64/steam': 'file',
+ 'steamrtarm64/steam_monitor': 'file',
+ 'steamrtarm64/steamclient.so': 'file',
+ 'steamrtarm64/steamerrorreporter': 'file',
+ 'steamrtarm64/steamoverlayvulkanlayer.so': 'file',
+ 'steamrtarm64/steamservice.so': 'file',
+ 'steamrtarm64/steamsysinfo': 'file',
+ 'steamrtarm64/steamui.so': 'file',
+ 'steamrtarm64/steamwebhelper': 'file',
+ 'steamrtarm64/steamwebhelper.sh': 'file',
+ 'steamrtarm64/streaming_client': 'file',
+ 'steamrtarm64/swiftshader/libEGL.so': 'file',
+ 'steamrtarm64/swiftshader/libEGL.so.TOC': 'file',
+ 'steamrtarm64/swiftshader/libGLESv2.so': 'file',
+ 'steamrtarm64/swiftshader/libGLESv2.so.TOC': 'file',
+ 'steamrtarm64/v8_context_snapshot.bin': 'file',
+ 'steamrtarm64/vgui2_s.so': 'file',
+ 'steamrtarm64/vgui_panel_zoo': 'file',
+ 'steamrtarm64/vk_swiftshader_icd.json': 'file',
+ 'steamrtarm64/vulkandriverquery': 'file'}
+EXECUTABLES = {
+    "steam", "steam_monitor", "steamerrorreporter", "steamwebhelper",
+    "steamwebhelper.sh", "gldriverquery", "vulkandriverquery",
+    "steamsysinfo", "fossilize_replay", "gameoverlayui",
+}
+LIBC = ctypes.CDLL(None, use_errno=True)
 
-  manifest=$(curl -fsSL "${STEAM_MANIFEST_URL}" | strings) || die "Failed to fetch Steam manifest."
-  target_file=$(echo "${manifest}" | grep -oP 'bins_linuxarm64_linuxarm64\.zip\.(?!vz\.)[^"]+') || die "Failed to parse target file from manifest."
-  zip_path="${STEAM}/linuxarm64.zip"
 
-  wget -c -t 5 -O "${zip_path}" "${STEAM_CDN}/${target_file}" || die "Failed to download Steam client zip."
-  unzip -o "${zip_path}" -d "${STEAM}" || die "Failed to extract Steam client."
-  rm -f "${zip_path}"
+def need(ok, text):
+    if not ok:
+        raise RuntimeError(text)
 
-  chmod +x "${CLIENT_DIR}/steam" || die "Failed to make Steam client executable."
 
-  mkdir -p "${STEAM}/package"
-  echo publicbeta > "${STEAM}/package/beta"
-  mkdir -p "${STEAM_DOT}"
-  ln -sfn "${STEAM}" "${STEAM_DOT}/steam" || die "Failed to symlink STEAM_DOT/steam."
-  ln -sfn "${STEAM}/linuxarm64" "${STEAM_DOT}/sdkarm64" || die "Failed to symlink STEAM_DOT/sdkarm64."
-  mkdir -p "${STEAM}/compatibilitytools.d/"
+def identity(path):
+    try:
+        s = path.lstat()
+    except FileNotFoundError:
+        return None
+    return [s.st_dev, s.st_ino, stat.S_IFMT(s.st_mode)]
+
+
+def directory(path):
+    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
+    try:
+        for part in path.parts[1:]:
+            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
+            os.close(fd)
+            fd = child
+        return fd
+    except BaseException:
+        os.close(fd)
+        raise
+
+
+def open_file(path, flags=os.O_RDONLY, mode=0o600):
+    parent = directory(path.parent)
+    try:
+        return os.open(path.name, flags | os.O_NOFOLLOW | os.O_NONBLOCK, mode, dir_fd=parent)
+    finally:
+        os.close(parent)
+
+
+def read_file(path, maximum):
+    fd = open_file(path)
+    try:
+        before = os.fstat(fd)
+        need(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, "Unexpected or oversized file: " + str(path))
+        with os.fdopen(fd, "rb", closefd=False) as stream:
+            data = stream.read(maximum + 1)
+        after = os.fstat(fd)
+        need(len(data) <= maximum and stamp(before) == stamp(after), "File changed during inspection.")
+        return data
+    finally:
+        os.close(fd)
+
+
+def stamp(s):
+    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns]
+
+
+def fingerprint(path):
+    fd = open_file(path)
+    try:
+        s = os.fstat(fd)
+        need(stat.S_ISREG(s.st_mode), "Expected a regular file: " + str(path))
+        return stamp(s)
+    finally:
+        os.close(fd)
+
+
+def elf(path, executable=False):
+    # Bounded header/program-table reads. No loader, execution, ldd, or full-file
+    # receipt comparison: legitimate self-updates may change every file digest.
+    fd = open_file(path)
+    try:
+        before = os.fstat(fd)
+        need(stat.S_ISREG(before.st_mode) and before.st_size >= 64, "A core Steam file is missing or incomplete.")
+        header = os.pread(fd, 64, 0)
+        need(len(header) == 64 and header[:7] == b"\x7fELF\x02\x01\x01", "A core Steam file is not an ARM64 ELF.")
+        _, kind, machine, version, entry, phoff, _, _, ehsize, phsize, count, _, _, _ = struct.unpack("<16sHHIQQQIHHHHHH", header)
+        need(machine == 183 and version == 1 and kind in (2, 3) and (executable or kind == 3), "A core Steam file has an unsupported architecture or type.")
+        need(ehsize == 64 and phsize == 56 and 0 < count <= 128 and phoff >= 64
+             and phoff + count * 56 <= before.st_size, "A core Steam program table is incomplete.")
+        raw = os.pread(fd, count * 56, phoff)
+        need(len(raw) == count * 56, "A core Steam program table could not be read.")
+        loads = []
+        for i in range(count):
+            typ, flags, offset, address, _, filesz, memsz, align = struct.unpack_from("<IIQQQQQQ", raw, i * 56)
+            need(offset <= before.st_size and filesz <= before.st_size - offset, "A core Steam segment exceeds its file.")
+            if typ == 1:
+                need(filesz <= memsz and (align in (0, 1) or align & (align - 1) == 0)
+                     and (align in (0, 1) or offset % align == address % align), "A core Steam load segment is invalid.")
+                loads.append((flags, address, memsz))
+        need(loads, "A core Steam file has no load segment.")
+        if executable:
+            need(before.st_mode & 0o111 and entry > 0
+                 and any(flags & 1 and address <= entry < address + size for flags, address, size in loads),
+                 "The Steam bootstrap entrypoint is not executable.")
+        need(stamp(before) == stamp(os.fstat(fd)), "A core Steam file changed during inspection.")
+        return stamp(before)
+    finally:
+        os.close(fd)
+
+
+def bootstrap(root):
+    path = root / CLIENT
+    ident = identity(path)
+    need(ident is not None and ident[2] == stat.S_IFDIR, "The existing Steam client folder is ambiguous.")
+    fd = directory(path)
+    os.close(fd)
+    result = {"directory": ident, "core": {}}
+    for name in CORE:
+        result["core"][name] = elf(path / name, name == "steam")
+    return result
+
+
+def mounts_below(path):
+    raw = read_file(Path("/proc") / str(os.getpid()) / "mountinfo", 1024**2)
+    # proc regular files have size 0; read_file bounds bytes rather than trusting it.
+    for line in raw.decode().splitlines():
+        point = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), line.split()[4]))
+        need(point != path and path not in point.parents, "A client transaction path has a mounted subtree.")
+
+
+def mount_rows():
+    raw = read_file(Path("/proc") / str(os.getpid()) / "mountinfo", 1024**2)
+    result = {}
+    for line in raw.decode().splitlines():
+        fields = line.split()
+        separator = fields.index("-")
+        need(separator >= 6 and len(fields) == separator + 4, "Storage mounts could not be inspected.")
+        point = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), fields[4])
+        result.setdefault(point, []).append(fields)
+    return result
+
+
+def available(path):
+    rows = mount_rows()
+    required = [Path("/storage")]
+    for p in (Path("/storage/games-external"), Path("/storage/roms")):
+        if path == p or p in path.parents:
+            required.append(p)
+    media = Path("/var/media")
+    if media in path.parents:
+        required.append(media / path.relative_to(media).parts[0])
+    covers = [Path(p) for p in rows if path == Path(p) or Path(p) in path.parents]
+    need(covers, "The Steam support storage is unavailable.")
+    required.append(max(covers, key=lambda p: len(p.parts)))
+    result = {}
+    for p in set(required):
+        found = rows.get(str(p), [])
+        need(p != Path("/") and len(found) == 1 and "rw" in found[0][5].split(",")
+             and "rw" in found[0][-1].split(","), "The Steam support storage is unavailable or read-only.")
+        result[str(p)] = found[0]
+    return result
+
+
+def bindings(plan, root, require_root=False):
+    current_mounts = mount_rows()
+    need(all(current_mounts.get(point) == [fields] for point, fields in plan["mounts"].items()),
+         "The Steam storage mount changed.")
+    for key in ("root", "target"):
+        for row in plan.get(key, {}).get("entries", []):
+            path = Path(row[0])
+            s = path.lstat()
+            now = [str(path), s.st_dev, s.st_ino, s.st_mode]
+            if stat.S_ISLNK(s.st_mode):
+                now.append(os.readlink(path))
+            need(now == row, "The Steam storage path changed.")
+    if require_root:
+        need(Path(plan["steam"]).resolve(strict=True) == root, "The Steam storage destination changed.")
+        fd = directory(root)
+        os.close(fd)
+
+
+def consumers(root):
+    # A visible installer lock is not a lock on Steam's independent updater.
+    # Refuse an observed client; do not kill it or claim this scan eliminates races.
+    for p in Path("/proc").iterdir():
+        if not p.name.isdecimal() or int(p.name) == os.getpid():
+            continue
+        try:
+            exe = os.readlink(p / "exe").removesuffix(" (deleted)")
+            fd = os.open(p / "cmdline", os.O_RDONLY | os.O_NOFOLLOW)
+            try:
+                cmd = os.read(fd, 4096).split(b"\0", 1)[0].decode(errors="replace")
+            finally:
+                os.close(fd)
+        except (FileNotFoundError, ProcessLookupError):
+            continue
+        except PermissionError as error:
+            raise RuntimeError("Steam processes could not be checked safely.") from error
+        paths = (root / CLIENT, Path(plan_global["steam"]) / CLIENT)
+        need(not any(exe == str(x) or exe.startswith(str(x) + "/") or cmd.startswith(str(x) + "/") for x in paths),
+             "Close Steam before installing it again.")
+
+
+def journal_schema(rows, root):
+    header = rows[0]
+    need(header.get("op") == "header" and header.get("policy") == "arm64-bootstrap-55-v2",
+         "Unsupported client ownership policy was kept.")
+    work = root / WORK
+    need(stat.S_IMODE(work.lstat().st_mode) == 0o700
+         and work.lstat().st_uid == os.geteuid()
+         and (work / "owner.jsonl").lstat().st_nlink == 1, "Client staging ownership is ambiguous.")
+    meta = header["metadata"]
+    committed = any(row["op"] == "committed" for row in rows)
+    physical = Path(meta["dot"]["path"])
+    if not committed:
+        dot = probe_directory(header["dot"])
+        need(dot["path"] == str(physical), "The previous support destination changed.")
+        check_probe(meta["dot"])
+        need(available(physical) == meta["mounts"], "The previous support storage changed.")
+    need(physical != root and physical not in root.parents and root not in physical.parents
+         and physical not in (Path("/storage"), Path("/var/media"), Path("/"))
+         and (physical.is_relative_to("/storage") or physical.is_relative_to("/var/media")),
+         "Unsupported client metadata ownership.")
+    specifications = [
+        (str(root / "package"), "directory", None),
+        (str(root / "package/beta"), "file", "7075626c6963626574610a"),
+        (str(physical), "directory", None),
+        (str(physical / "steam"), "link", plan_global["steam"]),
+        (str(physical / "sdkarm64"), "link", str(Path(plan_global["steam"]) / "linuxarm64")),
+    ]
+    need([(n["path"], n["kind"], n["value"]) for n in meta["nodes"]] == specifications,
+         "Unexpected client metadata plan was kept.")
+    stage_allowed = {"archive": "file", "manifest": "file", "payload": "directory"}
+    for name, kind in EXPECTED.items():
+        stage_allowed["payload/" + name.rstrip("/")] = kind
+        for p in Path(name.rstrip("/")).parents:
+            if str(p) != ".":
+                stage_allowed["payload/" + str(p)] = "directory"
+    external_allowed = {name: (kind, value) for name, kind, value in specifications}
+    for node in meta["nodes"]:
+        path = Path(node["path"]).parent
+        # Extra parents may be created only along the saved absent-dot path,
+        # below a pre-existing, identity-bound ancestor.
+        known_dirs = {row[0] for row in meta["dot"]["entries"]}
+        while path != Path("/") and str(path) not in known_dirs and path != root:
+            if physical == path or path in physical.parents:
+                external_allowed[str(path)] = ("directory", None)
+            path = path.parent
+    seen_stage, seen_external = set(), set()
+    active_transfer = None
+    transfer_count = 0
+    for row in rows[1:]:
+        op = row["op"]
+        if op == "transfer-start":
+            transfer_count += 1
+            need(active_transfer is None and transfer_count <= 2
+                 and row.get("serial") == transfer_count, "Ambiguous transfer ownership record.")
+            active_transfer = transfer_count
+        elif op == "transfer-stopped":
+            need(active_transfer is not None and row.get("serial") == active_transfer,
+                 "Unmatched transfer quiescence record.")
+            active_transfer = None
+        elif op == "stage":
+            name = row["path"]
+            need(name in stage_allowed and name not in seen_stage and row["kind"] == stage_allowed[name],
+                 "Unrecognized stage ownership record.")
+            seen_stage.add(name)
+        elif op == "external":
+            name = row["path"]
+            need(name in external_allowed and name not in seen_external
+                 and (row["kind"], row["value"]) == external_allowed[name], "Unrecognized metadata ownership record.")
+            seen_external.add(name)
+        elif op == "intent":
+            need(all(n["path"] in external_allowed and (n["kind"], n["value"]) == external_allowed[n["path"]]
+                     for n in row["nodes"]), "Unrecognized metadata creation intent.")
+        elif op == "prepared":
+            need(isinstance(row["tree"], dict) and len(row["tree"]) <= 256
+                 and all(not Path(p).is_absolute() and ".." not in Path(p).parts for p in row["tree"]),
+                 "Unrecognized prepared client inventory.")
+        else:
+            need(op in ("publishing", "committed", "failure"), "Unexpected client phase.")
+        if op in ("stage", "external"):
+            ident = row["id"]
+            kind = {"file": stat.S_IFREG, "directory": stat.S_IFDIR, "link": stat.S_IFLNK}[row["kind"]]
+            need(isinstance(ident, list) and len(ident) == 3
+                 and all(type(v) is int for v in ident) and ident[2] == kind,
+                 "Malformed client node identity.")
+
+
+def load_journal(work, root):
+    need(identity(work) is not None and identity(work)[2] == stat.S_IFDIR, "Unknown client staging state was kept.")
+    mounts_below(work)
+    raw = read_file(work / "owner.jsonl", MAX_JOURNAL)
+    need(raw.endswith(b"\n"), "An interrupted client journal was kept for review.")
+    lines = raw.splitlines(keepends=True)
+    need(lines and lines[0].endswith(b"\n"), "Incomplete client ownership record was kept.")
+    rows = [json.loads(line) for line in lines if line.endswith(b"\n")]
+    h = rows[0]
+    need(h.get("format") == 1 and h.get("root") == str(root)
+         and h.get("root_id") == identity(root) and h.get("work_id") == identity(work)
+         and h.get("journal_id") == identity(work / "owner.jsonl"), "Client ownership changed; existing state was kept.")
+    need(len(rows) <= 512 and all(isinstance(row, dict) for row in rows), "Unsupported client ownership record.")
+    allowed = {"header", "stage", "external", "intent", "prepared", "publishing", "committed", "failure", "transfer-start", "transfer-stopped"}
+    need(all(row.get("op") in allowed for row in rows), "Unknown client transaction phase was kept.")
+    journal_schema(rows, root)
+    tx = Transaction(root, h["dot"], h["metadata"], rows)
+    tx.check_owned_state()
+    if any(row["op"] == "committed" for row in rows):
+        bootstrap(root)  # A committed client's updater may legitimately change bytes.
+    elif tx.published():
+        need(tx.tree(root / CLIENT) == tx.prepared()["tree"], "An uncommitted published client changed; it was kept.")
+    return rows
+
+
+def inspect_tree(plan, root, check_lock=True):
+    bindings(plan, root)
+    consumers(root)
+    if check_lock and identity(root / LOCK) is not None:
+        fd = open_file(root / LOCK)
+        try:
+            need(stat.S_ISREG(os.fstat(fd).st_mode), "The client lock is ambiguous.")
+            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
+            fcntl.flock(fd, fcntl.LOCK_UN)
+        finally:
+            os.close(fd)
+    work = root / WORK
+    if identity(work) is not None:
+        rows = load_journal(work, root)
+        # Recovery runs later under the lock. This read-only branch does not
+        # bless an existing directory as installed, or normalize old contents.
+        return {"kind": "recovery", "root": str(root), "work_id": identity(work),
+                "journal_id": identity(work / "owner.jsonl"), "dot": rows[0]["dot"],
+                "committed": any(row["op"] == "committed" for row in rows)}
+    if identity(root / CLIENT) is not None:
+        return {"kind": "existing", "root": str(root), "bootstrap": bootstrap(root)}
+    for name in ("linuxarm64.zip", "steamrtarm64\\libs", "steamrtarm64\\swiftshader",
+                 "steamrtarm64\\libs\\libcurl.so", "steamrtarm64\\libs\\libnghttp2.so", "steamrtarm64\\libs\\libnghttp2.so.14"):
+        need(identity(root / name) is None, "An earlier Steam download is incomplete. Its files were kept.")
+    return {"kind": "fresh", "root": str(root)}
+
+
+def probe_directory(value):
+    path = Path(value)
+    need(path.is_absolute() and str(path) == os.path.normpath(value) and not value.startswith("//")
+         and not any(ord(c) < 32 for c in value), "The Steam support folder path is ambiguous.")
+    entries = []
+    current = Path("/")
+    pending = list(path.parts[1:])
+    links = 0
+    while pending:
+        part = pending.pop(0)
+        if part in ("", "."):
+            continue
+        if part == "..":
+            current = current.parent
+            continue
+        candidate = current / part
+        ident = identity(candidate)
+        if ident is None:
+            need(".." not in pending, "A missing support folder precedes a parent traversal.")
+            return {"input": value, "path": str(candidate.joinpath(*pending)), "entries": entries, "exists": False}
+        s = candidate.lstat()
+        row = [str(candidate), *ident]
+        if stat.S_ISLNK(s.st_mode):
+            links += 1
+            need(links <= 40, "The Steam support folder has too many links.")
+            target = os.readlink(candidate)
+            need(target and not any(ord(c) < 32 for c in target), "The Steam support folder link is ambiguous.")
+            row.append(target)
+            entries.append(row)
+            # Resolve each target component before applying any following '..'.
+            # Lexical normpath would erase a preceding directory symlink.
+            pending = target.split("/") + pending
+            if target.startswith("/"):
+                current = Path("/")
+        else:
+            need(stat.S_ISDIR(s.st_mode), "A file is blocking the Steam support folder.")
+            entries.append(row)
+            current = candidate
+    return {"input": value, "path": str(current), "entries": entries, "exists": True}
+
+
+def check_probe(probe):
+    for row in probe["entries"]:
+        path = Path(row[0])
+        now = [str(path), *(identity(path) or [])]
+        if path.is_symlink():
+            now.append(os.readlink(path))
+        need(now == row, "The Steam support folder changed.")
+    need(probe_directory(probe["input"])["path"] == probe["path"],
+         "The logical Steam support destination changed.")
+
+
+def describe(path):
+    ident = identity(path)
+    if ident is None:
+        return None
+    if ident[2] == stat.S_IFLNK:
+        return {"id": ident, "target": os.readlink(path)}
+    if ident[2] == stat.S_IFREG:
+        return {"id": ident, "bytes": read_file(path, 4096).hex(), "stamp": fingerprint(path)}
+    need(ident[2] == stat.S_IFDIR, "Unsupported Steam metadata entry.")
+    return {"id": ident}
+
+
+def metadata(root, dot_value, tree):
+    dot = probe_directory(dot_value)
+    physical = Path(dot["path"])
+    need(physical not in (Path("/"), Path("/storage"), Path("/var/media")) and physical != root and root not in physical.parents
+         and physical not in root.parents, "The Steam support folder overlaps client storage.")
+    # Preserve profile-selected paths, but require them on available /storage or
+    # /var/media storage. Root-path/mount admission remains the shared root helper.
+    need(physical.is_relative_to("/storage") or physical.is_relative_to("/var/media"), "The Steam support folder is outside supported storage.")
+    if tree["kind"] == "existing":
+        need(dot["exists"], "The existing client support folder is missing. Existing files were kept.")
+    nodes = [
+        (root / "package", "directory", None),
+        (root / "package/beta", "file", "7075626c6963626574610a"),
+        (physical, "directory", None),
+        (physical / "steam", "link", plan_global["steam"]),
+        (physical / "sdkarm64", "link", str(Path(plan_global["steam"]) / "linuxarm64")),
+    ]
+    result = {"dot": dot, "mounts": available(physical), "nodes": []}
+    for path, kind, value in nodes:
+        before = describe(path)
+        if before is not None:
+            if kind == "directory":
+                need(before["id"][2] == stat.S_IFDIR, "A Steam metadata directory is blocked.")
+            elif tree["kind"] == "fresh":
+                equal = before.get("bytes") == value if kind == "file" else (
+                    "target" in before and os.path.realpath(path) == os.path.realpath(value))
+                need(equal, "Existing Steam support settings were kept. Fresh setup cannot replace them.")
+            elif kind == "file":
+                need(before["id"][2] == stat.S_IFREG, "The existing Steam channel entry is ambiguous.")
+            else:
+                need(before["id"][2] == stat.S_IFLNK, "An existing Steam support alias is ambiguous.")
+            # Existing client channels and aliases belong to Steam/the player:
+            # inspect their types but neither replace them nor assert readiness.
+        result["nodes"].append({"path": str(path), "kind": kind, "value": value, "before": before})
+    return result
+
+
+def same_metadata(saved, root, dot, tree):
+    current = metadata(root, dot, tree)
+    need(current == saved, "Steam support settings changed during installation.")
+    check_probe(saved["dot"])
+
+
+def digest_file(path, maximum):
+    fd = open_file(path)
+    try:
+        s = os.fstat(fd)
+        need(stat.S_ISREG(s.st_mode) and s.st_size <= maximum, "Unexpected client file size or type.")
+        h = hashlib.sha256()
+        with os.fdopen(fd, "rb", closefd=False) as stream:
+            while chunk := stream.read(65536):
+                h.update(chunk)
+        need(stamp(s) == stamp(os.fstat(fd)), "A client file changed during validation.")
+        return h.hexdigest()
+    finally:
+        os.close(fd)
+
+
+def manifest(raw):
+    need(len(raw) <= 2 * 1024**2, "Steam manifest exceeded its limit.")
+    text = raw.decode("ascii")
+    tokens, end = [], 0
+    for match in re.finditer(r'"(?:[^"\\]|\\.)*"|[{}]', text):
+        need(not text[end:match.start()].strip(), "Unrecognized Steam manifest syntax.")
+        tokens.append(match.group())
+        end = match.end()
+    need(not text[end:].strip() and len(tokens) < 5000, "Steam manifest exceeded its syntax limits.")
+    pos = 0
+    def obj(depth=0):
+        nonlocal pos
+        need(depth < 8, "Steam manifest nesting exceeded its limit.")
+        result = {}
+        while pos < len(tokens) and tokens[pos] != "}":
+            key = json.loads(tokens[pos])
+            pos += 1
+            need(isinstance(key, str) and key not in result and pos < len(tokens), "Ambiguous Steam manifest key.")
+            token = tokens[pos]
+            pos += 1
+            if token == "{":
+                result[key] = obj(depth + 1)
+                need(pos < len(tokens) and tokens[pos] == "}", "Incomplete Steam manifest.")
+                pos += 1
+            else:
+                result[key] = json.loads(token)
+        return result
+    tree = obj()
+    need(pos == len(tokens), "Trailing Steam manifest data.")
+    selected = tree["linuxarm64"]["bins_linuxarm64_linuxarm64"]
+    name, checksum, size = selected["file"], selected["sha2"], selected["size"]
+    need(isinstance(name, str) and re.fullmatch(r"bins_linuxarm64_linuxarm64\.zip\.[0-9a-f]{40}", name)
+         and isinstance(checksum, str) and re.fullmatch(r"[0-9a-f]{64}", checksum)
+         and isinstance(size, str) and re.fullmatch(r"[0-9]{1,9}", size), "Unsupported Steam package selection.")
+    size = int(size)
+    need(22 <= size <= MAX_ZIP, "Steam client archive exceeds the supported size.")
+    return name, checksum, size
+
+
+def process_identity(pid):
+    path = Path("/proc") / str(pid)
+    try:
+        raw = read_file(path / "stat", 16384).decode()
+    except (FileNotFoundError, ProcessLookupError):
+        # A disappeared PID is a normal race. A present PID with unreadable stat
+        # is a visibility failure, never evidence of an empty process census.
+        need(identity(path) is None, "A live process identity could not be read.")
+        return None
+    prefix, separator, suffix = raw.rpartition(")")
+    fields = suffix.split()
+    need(separator and prefix.startswith(str(pid) + " (") and len(fields) >= 20,
+         "Malformed process identity; client state was kept.")
+    ppid, start = int(fields[1]), int(fields[19])
+    need(ppid >= 0 and start >= 0, "Invalid process owner or start time.")
+    return {"pid": pid, "ppid": ppid, "start_ticks": start}
+
+
+def direct_children(deadline):
+    # /proc/PID/task/PID/children is optional on the target kernel. The numeric
+    # stat census is the already-used PPID/start-time contract instead.
+    owner = os.getpid()
+    result, seen_owner, count = [], False, 0
+    for path in Path("/proc").iterdir():
+        if not path.name.isdecimal():
+            continue
+        count += 1
+        need(count <= 65536 and time.monotonic() < deadline, "Process census exceeded its bound.")
+        row = process_identity(int(path.name))
+        if row is not None:
+            seen_owner |= row["pid"] == owner
+            if row["ppid"] == owner:
+                result.append(row)
+    need(seen_owner, "Process census does not show this supervisor.")
+    return result
+
+
+def terminate_group(proc):
+    # Always retire the group, including successful drivers' leftover children.
+    # The helper is a subreaper: orphaned setsid descendants become its children.
+    try:
+        os.killpg(proc.pid, signal.SIGKILL)
+    except ProcessLookupError:
+        pass
+    proc.wait(timeout=5)
+    deadline = time.monotonic() + 5
+    while True:
+        try:
+            pid, _ = os.waitpid(-1, os.WNOHANG)
+        except ChildProcessError:
+            return  # Kernel ECHILD after the leader was reaped is quiescence.
+        need(time.monotonic() < deadline, "A client transfer child did not retire.")
+        if pid:
+            continue
+        for row in direct_children(deadline):
+            need(time.monotonic() < deadline, "Transfer child cleanup exceeded its bound.")
+            try:
+                pfd = os.pidfd_open(row["pid"], 0)
+            except ProcessLookupError:
+                continue
+            try:
+                current = process_identity(row["pid"])
+                if current is None:
+                    continue
+                need(current == row and current["ppid"] == os.getpid(),
+                     "A transfer child identity changed; client state was kept.")
+                try:
+                    signal.pidfd_send_signal(pfd, signal.SIGKILL)
+                except ProcessLookupError:
+                    pass
+            finally:
+                os.close(pfd)
+        time.sleep(0.01)
+
+
+def transfer(url, fd, limit, seconds, quiescent):
+    argv = ["curl", "--disable", "--fail", "--silent", "--show-error", "--location",
+            "--proto", "=https", "--proto-redir", "=https", "--max-redirs", "5",
+            "--connect-timeout", "10", "--max-time", str(seconds),
+            "--max-filesize", str(limit), "--output", "-", url]
+    parent = os.getpid()
+    def child_limits():
+        resource.setrlimit(resource.RLIMIT_FSIZE, (limit, limit))
+        if LIBC.prctl(1, signal.SIGKILL, 0, 0, 0) or os.getppid() != parent:
+            os._exit(125)
+    proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=fd, stderr=subprocess.PIPE,
+                            start_new_session=True, preexec_fn=child_limits)
+    errors = bytearray()
+    deadline = time.monotonic() + seconds + 2
+    selector = None
+    try:
+        selector = selectors.DefaultSelector()
+        selector.register(proc.stderr, selectors.EVENT_READ)
+        while selector.get_map():
+            need(time.monotonic() < deadline, "Steam client transfer timed out.")
+            for key, _ in selector.select(0.1):
+                block = os.read(key.fd, 8192)
+                if not block:
+                    selector.unregister(key.fileobj)
+                else:
+                    errors.extend(block)
+                    need(len(errors) <= 65536, "Steam client transfer log exceeded its limit.")
+        code = proc.wait(timeout=max(0.01, deadline - time.monotonic()))
+        need(code == 0, "Steam client transfer failed (exit " + str(code) + ").")
+        os.fsync(fd)
+    finally:
+        try:
+            if selector is not None:
+                selector.close()
+            proc.stderr.close()
+        finally:
+            terminate_group(proc)
+            # An exception, visibility gap or deadline before ECHILD must leave
+            # a durable unmatched transfer-start. Never authorize stage cleanup.
+            quiescent()
+
+
+def rename_new(source, target):
+    a, b = directory(source.parent), directory(target.parent)
+    try:
+        need(LIBC.renameat2(a, os.fsencode(source.name), b, os.fsencode(target.name), 1) == 0,
+             "The new Steam client could not be published without replacing an existing path.")
+        os.fsync(a)
+        os.fsync(b)
+    finally:
+        os.close(a)
+        os.close(b)
+
+
+class Transaction:
+    def __init__(self, root, dot, meta, rows=None):
+        self.root, self.work, self.dot, self.meta = root, root / WORK, dot, meta
+        self.rows = rows or []
+        self.journal = None
+
+    def append(self, row):
+        self.rows.append(row)  # Active cleanup knows identity even if journaling fails.
+        raw = (json.dumps(row, sort_keys=True) + "\n").encode()
+        need(os.fstat(self.journal).st_size + len(raw) <= MAX_JOURNAL, "Client journal exceeded its limit.")
+        need(os.write(self.journal, raw) == len(raw), "Short client journal write.")
+        os.fsync(self.journal)
+
+    def begin(self):
+        self.work.mkdir(mode=0o700)
+        self.journal = open_file(self.work / "owner.jsonl", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_APPEND)
+        self.append({"op": "header", "format": 1, "policy": "arm64-bootstrap-55-v2", "root": str(self.root), "root_id": identity(self.root),
+                     "work_id": identity(self.work), "journal_id": identity(self.work / "owner.jsonl"),
+                     "dot": self.dot, "metadata": self.meta})
+        fd = directory(self.root)
+        os.fsync(fd)
+        os.close(fd)
+
+    def add(self, relative, kind, data=None):
+        path = self.work / relative
+        need(not Path(relative).is_absolute() and ".." not in Path(relative).parts, "Invalid owned stage name.")
+        if kind == "directory":
+            parent = directory(path.parent)
+            try:
+                os.mkdir(path.name, 0o700, dir_fd=parent)
+            finally:
+                os.close(parent)
+            self.append({"op": "stage", "path": relative, "id": identity(path), "kind": kind})
+            return None
+        if kind == "link":
+            parent = directory(path.parent)
+            try:
+                os.symlink(data, path.name, dir_fd=parent)
+            finally:
+                os.close(parent)
+            self.append({"op": "stage", "path": relative, "id": identity(path), "kind": kind, "target": data})
+            return None
+        fd = open_file(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
+        try:
+            self.append({"op": "stage", "path": relative, "id": identity(path), "kind": "file"})
+        except BaseException:
+            os.close(fd)
+            raise
+        return fd
+
+    def put(self, relative, data):
+        fd = self.add(relative, "file")
+        try:
+            need(os.write(fd, data) == len(data), "Short staging write.")
+            os.fsync(fd)
+        finally:
+            os.close(fd)
+
+    def download(self, url, fd, limit, seconds):
+        serial = 1 + sum(row["op"] == "transfer-start" for row in self.rows)
+        self.append({"op": "transfer-start", "serial": serial})
+        transfer(url, fd, limit, seconds,
+                 lambda: self.append({"op": "transfer-stopped", "serial": serial}))
+
+    def fetch(self):
+        fd = self.add("manifest", "file")
+        try:
+            self.download("https://client-update.fastly.steamstatic.com/steam_client_publicbeta_linuxarm64", fd, 2 * 1024**2, 30)
+        finally:
+            os.close(fd)
+        name, checksum, size = manifest(read_file(self.work / "manifest", 2 * 1024**2))
+        need(os.statvfs(self.root).f_bavail * os.statvfs(self.root).f_frsize >= size + MAX_OUTPUT + RESERVE,
+             "There is not enough free space to prepare the Steam client.")
+        fd = self.add("archive", "file")
+        try:
+            self.download("https://client-update.steamstatic.com/" + name, fd, size, 180)
+        finally:
+            os.close(fd)
+        need((self.work / "archive").stat().st_size == size and digest_file(self.work / "archive", MAX_ZIP) == checksum,
+             "The Steam client download did not match its manifest.")
+        return size, checksum
+
+    def extract(self, size):
+        archive = self.work / "archive"
+        fd = open_file(archive)
+        rows = []
+        try:
+            def read(offset, length):
+                need(0 <= offset <= size and 0 <= length <= size - offset, "ZIP record exceeds the archive.")
+                raw = os.pread(fd, length, offset)
+                need(len(raw) == length, "Incomplete ZIP record.")
+                return raw
+            sig, disk, cd_disk, count_disk, count, cd_size, cd_start, comment = struct.unpack("<4s4H2IH", read(size - 22, 22))
+            need(sig == b"PK\x05\x06" and disk == cd_disk == comment == 0 and count_disk == count
+                 and count == len(EXPECTED) <= 128 and cd_start + cd_size == size - 22 and cd_size <= 65536,
+                 "Unsupported Steam ZIP directory.")
+            central = read(cd_start, cd_size)
+            pos, next_local, expanded, seen = 0, None, 0, set()
+            for _ in range(count):
+                need(pos + 46 <= len(central), "Incomplete ZIP directory.")
+                fields = struct.unpack_from("<4s6H3I5H2I", central, pos)
+                sig, made, required, flags, method, mtime, mdate, crc, packed, unpacked, nlen, extra, note, disk, _, attr, local = fields
+                need(sig == b"PK\x01\x02" and flags == extra == note == disk == 0 and required == 20
+                     and method in (0, 8) and pos + 46 + nlen <= len(central), "Unsupported Steam ZIP member.")
+                name_bytes = central[pos + 46:pos + 46 + nlen]
+                name = name_bytes.decode("ascii")
+                canonical = NAME_MAP.get(name, name)
+                kind = EXPECTED.get(canonical)
+                need(kind is not None and canonical not in seen and "\\" not in canonical
+                     and all(part not in ("", ".", "..") for part in canonical.rstrip("/").split("/")),
+                     "Unexpected or duplicate Steam ZIP path.")
+                seen.add(canonical)
+                if kind == "directory":
+                    need(method == 0 and unpacked == packed == crc == 0 and made == 20 and attr == 0x40000000,
+                         "Unexpected Steam directory attributes.")
+                elif kind == "link":
+                    need(made == 788 and stat.S_IFMT(attr >> 16) == stat.S_IFLNK and method == 0
+                         and 0 < unpacked == packed <= 4096, "Unexpected stored Steam link.")
+                else:
+                    need(made == 20 and attr == 2176188416 and method == 8, "Unsupported Steam file attributes.")
+                need(unpacked <= MAX_MEMBER, "Steam ZIP member exceeds its output limit.")
+                expanded += unpacked
+                need(expanded <= MAX_OUTPUT, "Steam ZIP exceeds its total output limit.")
+                if next_local is None:
+                    need(local in (0, 20), "Unsupported ZIP prefix.")
+                else:
+                    need(local == next_local, "Overlapping or unlisted ZIP local data.")
+                header = struct.unpack("<4s5H3I2H", read(local, 30))
+                need(header == (b"PK\x03\x04", required, flags, method, mtime, mdate, crc, packed, unpacked, nlen, 0)
+                     and read(local + 30, nlen) == name_bytes, "ZIP local and central records disagree.")
+                offset = local + 30 + nlen
+                next_local = offset + packed
+                need(next_local <= cd_start, "ZIP payload overlaps its directory.")
+                rows.append({"name": canonical, "kind": kind, "offset": offset, "packed": packed,
+                             "bytes": unpacked, "crc": crc, "method": method})
+                pos += 46 + nlen
+            need(pos == len(central) and next_local == cd_start and seen == set(EXPECTED), "Incomplete Steam ZIP inventory.")
+            self.add("payload", "directory")
+            dirs = {str(Path(row["name"]).parent) for row in rows}
+            dirs |= {row["name"].rstrip("/") for row in rows if row["kind"] == "directory"}
+            dirs.discard(".")
+            for name in sorted(dirs, key=lambda x: (len(Path(x).parts), x)):
+                self.add("payload/" + name, "directory")
+            deadline, total, links, receipt = time.monotonic() + 90, 0, [], []
+            for row in rows:
+                if row["kind"] == "directory":
+                    continue
+                target = "payload/" + row["name"]
+                out = self.add(target, "file") if row["kind"] == "file" else None
+                unpacker = zlib.decompressobj(-15) if row["method"] == 8 else None
+                length, crc, sha, link = 0, 0, hashlib.sha256(), bytearray()
+                try:
+                    remaining, offset = row["packed"], row["offset"]
+                    while remaining:
+                        chunk = read(offset, min(65536, remaining))
+                        remaining -= len(chunk)
+                        offset += len(chunk)
+                        while chunk:
+                            need(time.monotonic() < deadline, "Steam ZIP decoding timed out.")
+                            data = unpacker.decompress(chunk, 65536) if unpacker else chunk
+                            chunk = unpacker.unconsumed_tail if unpacker else b""
+                            length += len(data)
+                            total += len(data)
+                            need(length <= row["bytes"] and total <= MAX_OUTPUT, "Steam ZIP produced too much output.")
+                            crc = zlib.crc32(data, crc)
+                            sha.update(data)
+                            if out is None:
+                                link.extend(data)
+                            else:
+                                need(os.write(out, data) == len(data), "Short Steam client write.")
+                            if unpacker:
+                                need(not unpacker.unused_data, "Trailing compressed Steam data.")
+                    need(length == row["bytes"] and crc == row["crc"] and (not unpacker or unpacker.eof),
+                         "Steam client CRC, length, or compressed stream verification failed.")
+                    if out is not None:
+                        os.fchmod(out, 0o755 if Path(row["name"]).name in EXECUTABLES else 0o644)
+                        os.fsync(out)
+                    else:
+                        value = link.decode("ascii")
+                        need(value not in ("", ".", "..") and "/" not in value and "\\" not in value
+                             and not any(ord(c) < 32 for c in value)
+                             and EXPECTED.get(str(Path(row["name"]).parent / value)) == "file",
+                             "Steam link target is outside the validated client.")
+                        links.append((target, value))
+                    receipt.append({"path": row["name"], "kind": row["kind"], "bytes": length, "sha256": sha.hexdigest()})
+                finally:
+                    if out is not None:
+                        os.close(out)
+            for target, value in links:
+                self.add(target, "link", value)
+            for name in dirs:
+                os.chmod(self.work / "payload" / name, 0o755, follow_symlinks=False)
+            bootstrap(self.work / "payload")
+            tree = self.tree(self.work / "payload" / CLIENT)
+            self.append({"op": "prepared", "client_id": identity(self.work / "payload" / CLIENT),
+                         "tree": tree, "members": receipt})
+        finally:
+            os.close(fd)
+
+    def tree(self, path):
+        mounts_below(path)
+        result = {}
+        for base, dirs, files in os.walk(path, followlinks=False):
+            need(len(result) <= 256, "The staged client has too many paths.")
+            for name in dirs + files:
+                p = Path(base) / name
+                s = p.lstat()
+                key = str(p.relative_to(path))
+                entry = {"id": identity(p), "mode": stat.S_IMODE(s.st_mode)}
+                if stat.S_ISLNK(s.st_mode):
+                    entry["target"] = os.readlink(p)
+                elif stat.S_ISREG(s.st_mode):
+                    need(s.st_nlink == 1, "The staged client has a hard link.")
+                    entry.update(bytes=s.st_size, sha256=digest_file(p, MAX_MEMBER))
+                else:
+                    need(stat.S_ISDIR(s.st_mode), "Unexpected staged client node.")
+                result[key] = entry
+        return result
+
+    def prepare_metadata(self):
+        check_probe(self.meta["dot"])
+        need(available(Path(self.meta["dot"]["path"])) == self.meta["mounts"],
+             "The support storage changed before metadata writes.")
+        self.append({"op": "intent", "nodes": self.meta["nodes"]})
+        for node in self.meta["nodes"]:
+            path = Path(node["path"])
+            if node["before"] is not None:
+                need(describe(path) == node["before"], "Steam support settings changed.")
+                continue
+            # Only absent parents/nodes are created, never substituted for
+            # existing aliases, channels, SDK trees or custom files.
+            missing = []
+            parent = path.parent
+            while identity(parent) is None:
+                missing.append(parent)
+                parent = parent.parent
+            for p in reversed(missing):
+                self.external(p, "directory", None)
+            self.external(path, node["kind"], node["value"])
+
+    def external(self, path, kind, value):
+        check_probe(self.meta["dot"])
+        self.append({"op": "intent", "nodes": [{"path": str(path), "kind": kind, "value": value, "before": None}]})
+        need(identity(path) is None, "A Steam metadata destination appeared.")
+        parent = directory(path.parent)
+        parent_id = identity(path.parent)
+        try:
+            if kind == "directory":
+                os.mkdir(path.name, 0o755, dir_fd=parent)
+            elif kind == "link":
+                os.symlink(value, path.name, dir_fd=parent)
+            else:
+                fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=parent)
+                try:
+                    data = bytes.fromhex(value)
+                    need(os.write(fd, data) == len(data), "Short Steam metadata write.")
+                    os.fsync(fd)
+                finally:
+                    os.close(fd)
+            self.append({"op": "external", "path": str(path), "id": identity(path),
+                         "parent_id": parent_id, "kind": kind, "value": value})
+            os.fsync(parent)
+        finally:
+            os.close(parent)
+
+    def prepared(self):
+        rows = [row for row in self.rows if row["op"] == "prepared"]
+        need(len(rows) <= 1, "Ambiguous prepared client record.")
+        return rows[0] if rows else None
+
+    def published(self):
+        prepared = self.prepared()
+        return prepared is not None and identity(self.root / CLIENT) == prepared["client_id"]
+
+    def check_external(self, row):
+        path = Path(row["path"])
+        need(identity(path.parent) == row["parent_id"], "A client metadata parent changed; state was kept.")
+        current = describe(path)
+        need(current is not None and current["id"] == row["id"], "Client metadata ownership changed; state was kept.")
+        if row["kind"] == "file":
+            need(current.get("bytes") == row["value"], "Client metadata contents changed; state was kept.")
+        elif row["kind"] == "link":
+            need(current.get("target") == row["value"], "Client metadata link changed; state was kept.")
+
+    def commit(self):
+        need(self.published(), "Published client identity changed.")
+        prepared = self.prepared()
+        need(self.tree(self.root / CLIENT) == prepared["tree"], "The published client changed before commit.")
+        for row in self.rows:
+            if row["op"] == "external":
+                self.check_external(row)
+        for node in self.meta["nodes"]:
+            if node["before"] is not None:
+                need(describe(Path(node["path"])) == node["before"], "Existing Steam metadata changed before commit.")
+        self.append({"op": "committed"})
+        self.cleanup(keep_client=True)
+
+    def check_owned_state(self):
+        starts = [row["serial"] for row in self.rows if row["op"] == "transfer-start"]
+        stops = [row["serial"] for row in self.rows if row["op"] == "transfer-stopped"]
+        need(starts == stops, "Transfer quiescence is unestablished; client staging was kept for review.")
+        bindings(plan_global, self.root, True)
+        need(identity(self.work) == self.rows[0]["work_id"] and identity(self.work / "owner.jsonl") == self.rows[0]["journal_id"],
+             "Client stage ownership changed; state was kept.")
+        mounts_below(self.work)
+        stage = [row for row in self.rows if row["op"] == "stage"]
+        known = {row["path"]: row for row in stage}
+        actual = set()
+        for base, dirs, files in os.walk(self.work, followlinks=False):
+            for name in dirs + files:
+                p = Path(base) / name
+                relative = str(p.relative_to(self.work))
+                if relative == "owner.jsonl":
+                    continue
+                need(relative in known and identity(p) == known[relative]["id"], "Unknown or changed stage contents were kept.")
+                need(p.lstat().st_dev == self.work.stat().st_dev and
+                     (not p.is_file() or p.lstat().st_nlink == 1), "A client stage crosses an ownership boundary.")
+                actual.add(relative)
+        # Unrecorded creation after interruption is deliberately held. No
+        # ownership is inferred from a familiar filename or partial journal.
+        external = [row for row in self.rows if row["op"] == "external"]
+        owned = {row["path"] for row in external}
+        for row in self.rows:
+            if row["op"] == "intent":
+                for node in row["nodes"]:
+                    if node["before"] is None and identity(Path(node["path"])) is not None:
+                        need(node["path"] in owned, "Unrecorded client metadata was kept for review.")
+        committed = any(row["op"] == "committed" for row in self.rows)
+        if not committed:
+            for row in external:
+                if identity(Path(row["path"])) is not None or self.published():
+                    self.check_external(row)
+        return known, actual, external
+
+    def cleanup(self, keep_client=False):
+        known, actual, external = self.check_owned_state()
+        if not keep_client:
+            need(not self.published(), "A published client must be verified before recovery.")
+            for row in external:
+                if identity(Path(row["path"])) is not None:
+                    self.check_external(row)
+            for row in reversed(external):
+                self.remove(Path(row["path"]), row["id"], row["kind"])
+        for relative in sorted(actual, key=lambda x: (len(Path(x).parts), x), reverse=True):
+            row = known[relative]
+            self.remove(self.work / relative, row["id"], row["kind"])
+        if self.journal is not None:
+            os.close(self.journal)
+            self.journal = None
+        self.remove(self.work / "owner.jsonl", self.rows[0]["journal_id"], "file")
+        self.remove(self.work, self.rows[0]["work_id"], "directory")
+
+    def remove(self, path, expected, kind):
+        if identity(path) is None:
+            return  # An earlier interrupted cleanup already retired this owned node.
+        parent = directory(path.parent)
+        try:
+            s = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
+            need([s.st_dev, s.st_ino, stat.S_IFMT(s.st_mode)] == expected, "Client cleanup identity changed.")
+            if kind == "directory":
+                os.rmdir(path.name, dir_fd=parent)
+            else:
+                os.unlink(path.name, dir_fd=parent)
+            os.fsync(parent)
+        finally:
+            os.close(parent)
+
+
+def install(root, tree, meta, dot):
+    bindings(plan_global, root, True)
+    consumers(root)
+    lock = open_file(root / LOCK, os.O_RDWR | os.O_CREAT, 0o600)
+    try:
+        s = os.fstat(lock)
+        need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1, "The client lock is ambiguous.")
+        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
+        work = root / WORK
+        if identity(work) is not None:
+            rows = load_journal(work, root)
+            committed = any(row["op"] == "committed" for row in rows)
+            need(committed or rows[0]["dot"] == dot, "Recovery needs the same profile-selected Steam support folder.")
+            tx = Transaction(root, dot, rows[0]["metadata"], rows)
+            if not committed:
+                check_probe(tx.meta["dot"])
+            tx.journal = open_file(work / "owner.jsonl", os.O_WRONLY | os.O_APPEND)
+            try:
+                if committed:
+                    tx.cleanup(keep_client=True)
+                    print("An existing Steam client was kept; completed setup scratch was retired.")
+                    return
+                if tx.published():
+                    tx.commit()
+                    print("Steam client file setup recovered.")
+                    return
+                tx.cleanup()
+            finally:
+                if tx.journal is not None:
+                    os.close(tx.journal)
+            # Do not turn a recovered failure into a successful installed state.
+            # This same explicit invocation can start a fresh bounded download.
+            tree = inspect_tree(plan_global, root, False)
+            meta = metadata(root, dot, tree)
+        else:
+            need(inspect_tree(plan_global, root, False) == tree, "The Steam client changed during installation.")
+            same_metadata(meta, root, dot, tree)
+        if tree["kind"] == "existing":
+            print("Existing Steam client files were kept.")
+            return
+        need(tree["kind"] == "fresh" and identity(root / CLIENT) is None, "Steam client state is ambiguous.")
+        need(os.statvfs(root).f_bavail * os.statvfs(root).f_frsize >= MAX_ZIP + MAX_OUTPUT + RESERVE,
+             "There is not enough free space to prepare the Steam client.")
+        tx = Transaction(root, dot, meta)
+        try:
+            tx.begin()
+            size, _ = tx.fetch()
+            tx.extract(size)
+            bindings(plan_global, root, True)
+            consumers(root)
+            same_metadata(meta, root, dot, tree)
+            tx.prepare_metadata()
+            tx.append({"op": "publishing"})
+            rename_new(work / "payload" / CLIENT, root / CLIENT)
+            tx.commit()
+        except BaseException:
+            if tx.rows and tx.journal is not None:
+                try:
+                    tx.append({"op": "failure"})
+                    if not tx.published():
+                        tx.cleanup()
+                except BaseException as cleanup_error:
+                    print("Steam client recovery state was kept: " + str(cleanup_error), file=sys.stderr)
+            raise
+        finally:
+            if tx.journal is not None:
+                os.close(tx.journal)
+        print("Steam client files are in place.")
+    finally:
+        os.close(lock)
+
+
+def interrupted(signum, frame):
+    raise RuntimeError("Steam client setup was interrupted (signal " + str(signum) + ").")
+
+
+def main():
+    global plan_global
+    mode, plan_text, dot, tree_text, meta_text = sys.argv[1:]
+    plan_global = json.loads(plan_text)
+    root = Path(plan_global.get("target", plan_global["root"])["path"])
+    for sig in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT):
+        signal.signal(sig, interrupted)
+    signal.alarm(360 if mode == "install" else 30)
+    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
+    if mode == "tree":
+        print(json.dumps(inspect_tree(plan_global, root), sort_keys=True))
+        return
+    tree = json.loads(tree_text)
+    if mode == "metadata":
+        need(inspect_tree(plan_global, root) == tree, "The Steam client changed while profiles loaded.")
+        if tree["kind"] == "recovery" and not tree["committed"]:
+            need(tree["dot"] == dot, "Recovery needs the same profile-selected Steam support folder.")
+            rows = load_journal(root / WORK, root)
+            print(json.dumps(rows[0]["metadata"], sort_keys=True))
+        else:
+            print(json.dumps(metadata(root, dot, {"kind": "existing"} if tree["kind"] == "recovery" else tree), sort_keys=True))
+        return
+    need(mode == "install", "Unsupported Steam client operation.")
+    need(LIBC.prctl(36, 1, 0, 0, 0) == 0, "Client transfer child supervision is unavailable.")
+    install(root, tree, json.loads(meta_text), dot)
+
+
+if __name__ == "__main__":
+    try:
+        main()
+    except (OSError, RuntimeError, ValueError, KeyError, TypeError, IndexError, struct.error, zlib.error, subprocess.SubprocessError) as error:
+        print("Steam client setup stopped: " + str(error), file=sys.stderr)
+        sys.exit(1)
+PY_STEAM_CLIENT
 }
 
 install_bundled_proton_files() {
   log_info "Installing bundled Proton files..."
   cp -f "/usr/share/steam/registry.vdf" "${STEAM_DOT}" || die "Failed to copy registry.vdf."
 }
 
 install_proton_variant() {
   local display_name="$1"
-  local url="$2"
-  local tar_name="$3"
-  local dir_name="$4"
-  local cleanup_glob="$5"
-
-  local dest_dir="${STEAM}/compatibilitytools.d"
-  local tar_path="${dest_dir}/${tar_name}"
-  local extracted_dir="${dest_dir}/${dir_name}"
-  local manifest_file="${extracted_dir}/toolmanifest.vdf"
-
-  if [ -d "${dest_dir}" ]; then
-    for old_dir in "${dest_dir}"/${cleanup_glob}; do
-      [ -d "${old_dir}" ] || continue
-      if [ "${old_dir}" != "${extracted_dir}" ]; then
-        log_info "Removing old ${display_name}: $(basename "${old_dir}")"
-        rm -rf "${old_dir}"
-      fi
-    done
-  fi
+  # The fifth argument is retained for caller compatibility, never for deletion:
+  # games can select an older named version even after a new version installs.
+  log_info "Checking and installing ${display_name}; keeping existing versions..."
+  if /usr/bin/python3 -I -S -B - "${STEAM}" "$2" "$3" "$4" "$5" <<'PY_PROTON_VARIANT'
+import ctypes
+import fcntl
+import gzip
+import json
+import lzma
+import os
+from pathlib import Path, PurePosixPath
+import posixpath
+import re
+import resource
+import shutil
+import signal
+import stat
+import subprocess
+import sys
+import tarfile
+from urllib.parse import urlsplit
+
+RESERVE = 256 * 1024**2
+MAX_ARCHIVE = 2 * 1024**3
+MAX_EXPANDED = 16 * 1024**3
+MAX_MEMBERS = 250000
+WORK = ".proton-variant-stage"
+LOCK = ".proton-variant.lock"
+FAMILIES = {"proton-cachyos-*-arm64": (r"proton-cachyos-[A-Za-z0-9._+-]+-arm64", ".tar.xz"),
+            "GE-Proton*-aarch64": (r"GE-Proton[A-Za-z0-9._+-]+-aarch64", ".tar.gz")}
+
+
+def directory(path, device):
+    info = path.lstat()
+    if not stat.S_ISDIR(info.st_mode) or info.st_dev != device:
+        raise RuntimeError("Proton installation requires a real directory on the Steam filesystem.")
+
+
+def no_mounts(path):
+    for line in Path("/proc/self/mountinfo").read_text().splitlines():
+        field = line.split()[4]
+        mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field))
+        if mount == path or path in mount.parents:
+            raise RuntimeError("A mounted Proton staging or target path must be released first.")
+
+
+def capacity(root, needed):
+    if shutil.disk_usage(root).free < needed + RESERVE:
+        raise RuntimeError("Not enough space to install Proton while keeping existing versions.")
+
+
+def manifest(path):
+    if path.is_symlink() or not path.is_file() or not 0 < path.stat().st_size <= 65536:
+        raise RuntimeError("Missing or unsupported Proton manifest.")
+    raw = path.read_text(encoding="utf-8")
+    tokens, offset = [], 0
+    pattern = re.compile(r'\s+|//[^\n]*|"(?:\\.|[^"\\])*"|[{}]')
+    for match in pattern.finditer(raw):
+        if match.start() != offset:
+            raise RuntimeError("Malformed Proton manifest.")
+        offset = match.end()
+        token = match[0]
+        if not token.isspace() and not token.startswith("//"):
+            tokens.append(token)
+    if offset != len(raw):
+        raise RuntimeError("Malformed Proton manifest.")
+    index = 0
+
+    def object_value(depth=0):
+        nonlocal index
+        if depth > 16:
+            raise RuntimeError("Proton manifest nesting exceeds the supported format.")
+        result = {}
+        while index < len(tokens) and tokens[index] != "}":
+            key = json.loads(tokens[index])
+            index += 1
+            if not isinstance(key, str) or key in result or index == len(tokens):
+                raise RuntimeError("Malformed or duplicate Proton manifest field.")
+            if tokens[index] == "{":
+                index += 1
+                value = object_value(depth + 1)
+                if index == len(tokens) or tokens[index] != "}":
+                    raise RuntimeError("Unclosed Proton manifest object.")
+                index += 1
+            else:
+                value = json.loads(tokens[index])
+                index += 1
+            result[key] = value
+        return result
+
+    result = object_value()
+    if index != len(tokens):
+        raise RuntimeError("Unexpected Proton manifest closing brace.")
+    return result
+
+
+def validate(target, device):
+    directory(target, device)
+    no_mounts(target)
+    tool = manifest(target / "toolmanifest.vdf")["manifest"]
+    if tool.get("version") != "2" or tool.get("commandline") != "/proton %verb%":
+        raise RuntimeError("Unsupported Proton command manifest.")
+    entries = manifest(target / "compatibilitytool.vdf")["compatibilitytools"]["compat_tools"]
+    if not isinstance(entries, dict) or len(entries) != 1:
+        raise RuntimeError("Expected one Proton compatibility tool.")
+    name, entry = next(iter(entries.items()))
+    if (not name or "##" in name or not isinstance(entry, dict) or entry.get("install_path") != "."
+            or entry.get("from_oslist") != "windows" or entry.get("to_oslist") != "linux"):
+        raise RuntimeError("Unsupported Proton compatibility manifest.")
+    for relative in ("proton", "filelock.py", "version", "files/bin-arm64/wine", "files/bin-arm64/wineserver"):
+        path = target / relative
+        resolved = path.resolve(strict=True)
+        if not resolved.is_relative_to(target) or not resolved.is_file() or resolved.stat().st_size == 0:
+            raise RuntimeError("Missing or escaping required Proton payload: " + relative)
+        if relative == "proton" or relative.startswith("files/"):
+            if not resolved.stat().st_mode & 0o111:
+                raise RuntimeError("Required Proton launcher is not executable: " + relative)
+        if relative.startswith("files/"):
+            with resolved.open("rb") as stream:
+                header = stream.read(20)
+            if (len(header) != 20 or header[:6] != b"\x7fELF\x02\x01" or header[18:20] != b"\xb7\x00"
+                    or header[16:18] not in (b"\x02\x00", b"\x03\x00")):
+                raise RuntimeError("Required Proton payload is not ARM64 ELF: " + relative)
+
+
+def unpack(archive, stage, name, root, suffix):
+    # Validate every member and the compressed footer before extraction. Python's
+    # data filter then checks resolved link paths again during extraction.
+    members, seen, expanded = [], {}, 0
+    opener = lzma.open if suffix == ".tar.xz" else gzip.open
+    with opener(archive, "rb") as compressed:
+        class BoundedReader:
+            count = 0
+
+            def read(self, size):
+                data = compressed.read(size)
+                self.count += len(data)
+                if self.count > MAX_EXPANDED + MAX_MEMBERS * 8192:
+                    raise RuntimeError("Proton tar stream exceeds the size bound.")
+                return data
+
+        reader = BoundedReader()
+        with tarfile.open(fileobj=reader, mode="r|") as bundle:
+            for member in bundle:
+                path = PurePosixPath(member.name)
+                if (path.is_absolute() or ".." in path.parts or not path.parts or path.parts[0] != name
+                        or str(path) in seen or member.size < 0 or member.issparse()
+                        or not (member.isdir() or member.isfile() or member.issym() or member.islnk())):
+                    raise RuntimeError("Unsafe or unsupported Proton archive member.")
+                if len(path.parts) == 1 and not member.isdir():
+                    raise RuntimeError("Proton archive root must be a directory.")
+                if member.issym() or member.islnk():
+                    link = PurePosixPath(member.linkname)
+                    base = str(path.parent) if member.issym() else ""
+                    resolved = PurePosixPath(posixpath.normpath(posixpath.join(base, str(link))))
+                    if link.is_absolute() or not resolved.parts or resolved.parts[0] != name:
+                        raise RuntimeError("Proton archive link escapes its version directory.")
+                    if member.islnk() and seen.get(str(resolved)) != "file":
+                        raise RuntimeError("Proton hard link must name an earlier regular file.")
+                seen[str(path)] = "file" if member.isfile() else "other"
+                expanded += ((member.size + 4095) // 4096) * 4096 + 8192
+                members.append(member)
+                if expanded > MAX_EXPANDED or len(members) > MAX_MEMBERS:
+                    raise RuntimeError("Proton archive exceeds the extraction bound.")
+        while reader.read(1024 * 1024):
+            pass
+    capacity(root, expanded)
+    stage.mkdir()
+    with tarfile.open(archive, "r:*") as bundle:
+        bundle.extractall(stage, members=members, filter="data")
 
-  if [ -d "${extracted_dir}" ]; then
-    log_info "${display_name} already installed. Skipping download."
+
+def cleanup(work, lock_info, device):
+    if not os.path.lexists(work):
+        return
+    directory(work, device)
+    no_mounts(work)
+    children = {path.name for path in work.iterdir()}
+    if not children:  # Interrupted before the ownership link or after unlinking it.
+        work.rmdir()
+        return
+    owner = work / "owner"
+    info = owner.lstat()
+    if (not stat.S_ISREG(info.st_mode) or (info.st_dev, info.st_ino) != lock_info
+            or not children <= {"owner", "archive", "unpack"}):
+        raise RuntimeError("Unrecognized Proton staging contents; leaving them untouched.")
+    for name in ("archive", "unpack"):
+        path = work / name
+        if path.is_symlink() or path.is_file():
+            path.unlink()
+        elif path.exists():
+            directory(path, device)
+            shutil.rmtree(path)
+    owner.unlink()  # Ownership anchor is always removed last, for retry after a kill.
+    work.rmdir()
+
+
+def activate(candidate, target):
+    # Linux renameat2 refuses any existing target, including a concurrently created
+    # empty directory. Never replace a player-owned same-name installation.
+    libc = ctypes.CDLL(None, use_errno=True)
+    rename = libc.renameat2
+    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
+    rename.restype = ctypes.c_int
+    if rename(-100, os.fsencode(candidate), -100, os.fsencode(target), 1) != 0:
+        raise OSError(ctypes.get_errno(), "Could not activate staged Proton without replacing existing data")
+
+
+def install(root, url, tar_name, name, family):
+    pattern, suffix = FAMILIES[family]
+    if not re.fullmatch(pattern, name) or tar_name != name + suffix:
+        raise RuntimeError("Unsupported Proton family or archive name.")
+    parsed = urlsplit(url)
+    if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
+        raise RuntimeError("Proton download requires an HTTPS release URL.")
+    root = Path(root).resolve(strict=True)
+    if root == Path("/"):
+        raise RuntimeError("Refusing the filesystem root as a Steam directory.")
+    device = root.stat().st_dev
+    directory(root, device)
+    fd = os.open(root / LOCK, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
+    try:
+        info = os.fstat(fd)
+        if not stat.S_ISREG(info.st_mode) or info.st_size:
+            raise RuntimeError("Unsupported Proton installer lock.")
+        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
+        work = root / WORK
+        lock_info = (info.st_dev, info.st_ino)
+        cleanup(work, lock_info, device)
+        dest = root / "compatibilitytools.d"
+        if not os.path.lexists(dest):
+            dest.mkdir()
+        directory(dest, device)
+        no_mounts(dest)
+        target = dest / name
+        if os.path.lexists(target):
+            try:
+                validate(target, device)
+            except Exception as error:
+                raise RuntimeError("Existing Proton target is incomplete or unsupported; kept untouched: "
+                                   + name + ". Resolve that version separately before retrying.") from error
+            print("Requested Proton version passes payload checks; keeping it unchanged.")
+            return
+        capacity(root, MAX_ARCHIVE)
+        work.mkdir(mode=0o700)
+        try:
+            os.link(root / LOCK, work / "owner", follow_symlinks=False)
+            archive = work / "archive"
+            parent = os.getpid()
+
+            def child_setup():
+                libc = ctypes.CDLL(None, use_errno=True)
+                if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0 or os.getppid() != parent:
+                    os._exit(125)
+                resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_ARCHIVE, MAX_ARCHIVE))
+
+            subprocess.run(["wget", "-t", "3", "-T", "30", "-O", str(archive), url],
+                           check=True, timeout=900, preexec_fn=child_setup)
+            if not 0 < archive.stat().st_size <= MAX_ARCHIVE:
+                raise RuntimeError("Proton download is empty or exceeds the size bound.")
+            unpack(archive, work / "unpack", name, root, suffix)
+            candidate = work / "unpack" / name
+            validate(candidate, device)
+            capacity(root, 0)
+            activate(candidate, target)
+            print("Proton installed; every existing version has been kept.")
+        finally:
+            cleanup(work, lock_info, device)
+    finally:
+        os.close(fd)  # Keep the lock inode: never unlink a lock another caller may hold.
+
+
+def interrupted(signum, frame):
+    raise InterruptedError("Proton installation interrupted; existing versions are kept.")
+
+
+def main():
+    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
+        signal.signal(signum, interrupted)
+    signal.alarm(1800)
+    try:
+        install(*sys.argv[1:])
+    except Exception as error:
+        print("Proton installation stopped: " + str(error), file=sys.stderr)
+        return 1
+    finally:
+        signal.alarm(0)
     return 0
-  fi
 
-  log_info "Downloading and installing ${display_name}..."
-  mkdir -p "${dest_dir}"
-  wget -c -t 5 -O "${tar_path}" "$url" || die "Failed to download ${display_name}."
-  tar -xvf "${tar_path}" -C "${dest_dir}" || die "Failed to extract ${display_name}."
-  rm -f "${tar_path}"
+
+if __name__ == "__main__":
+    sys.exit(main())
+PY_PROTON_VARIANT
+  then
+    return 0
+  else
+    die "Could not install ${display_name}. Existing Proton versions have been kept."
+  fi
 }
 
 install_proton_cachyos() {
   install_proton_variant \
     "Proton-CachyOS" \
     "${PROTON_CACHYOS_URL}" \
     "${PROTON_CACHYOS_TAR}" \
     "${PROTON_CACHYOS_DIR}" \
@@ -247,25 +2705,51 @@ run_steam_first_launch() {
   if [ "${DEVICE_HAS_DUAL_SCREEN}" = "true" ]; then
     swaymsg 'seat seat1 fallback false' || log_info "Swaymsg dual screen teardown failed, ignoring."
   fi
 
   systemctl restart systemd-binfmt || die "Failed to restart systemd-binfmt."
 }
 
 # --- Execution ---
+# Freeze the checked inputs before profile scripts can run or change the roots.
+STEAM_ROOT_PLAN="$(steam_root_layout inspect)" || die "Steam storage is not ready. Nothing was installed."
+readonly STEAM STEAM_GAMES_ROOT STEAM_ROOT_PLAN
+STEAM_CLIENT_PLAN="$(steam_client_state tree)" || die "Steam client files could not be checked. Nothing was changed."
+readonly STEAM_CLIENT_PLAN
+source /etc/profile
+STEAM_DOT="${STEAM_DOT:-/storage/.steam}"
+APPLICATIONS="${APPLICATIONS:-/storage/.local/share/applications}"
+FEX_DATA="/storage/.local/share/fex-emu"
+FEX_ARCH_ROOT="${FEX_DATA}/RootFS/ArchLinux"
+FEX_ARCH_USR_LIB="${FEX_ARCH_ROOT}/usr/lib"
+RUNTIME_DIR="${STEAM}/steam-runtime-steamrt-arm64"
+CLIENT_DIR="${STEAM}/steamrtarm64"
+RUNTIME_TAR_BASE="https://repo.steampowered.com/steamrt3c/images"
+RUNTIME_TAR_VERSION_URL="${RUNTIME_TAR_BASE}/latest-public-stable.txt"
+STEAM_MANIFEST_URL="https://client-update.fastly.steamstatic.com/steam_client_publicbeta_linuxarm64"
+STEAM_CDN="https://client-update.steamstatic.com"
+PROTON_CACHYOS_RELEASE_API="https://api.github.com/repos/CachyOS/proton-cachyos/releases/latest"
+PROTON_GE_RELEASE_API="https://api.github.com/repos/GloriousEggroll/proton-ge-custom/releases/latest"
+unset MESA_LOADER_DRIVER_OVERRIDE
+
+steam_root_layout verify || die "Steam storage changed. Installation stopped."
+# Profiles may already have written. Metadata refusal preserves their selected
+# path and does not claim rollback of profile effects or other transactions.
+STEAM_CLIENT_METADATA_PLAN="$(steam_client_state metadata)" || die "Steam support folders could not be checked. Client files were kept."
+readonly STEAM_DOT STEAM_CLIENT_METADATA_PLAN
+set_kill set "-9 steam FEX"
 log_info "Starting Steam Installation Process..."
 
-install_fex_config
 ensure_fex_rootfs
 link_steam_library
 ensure_steam_desktop_stub
 install_steam_runtime_arm64
 install_steam_client_arm64
 install_bundled_proton_files
 fetch_proton_latest_release "${PROTON_CACHYOS_RELEASE_API}" "arm64" "cachyos-" "PROTON_CACHYOS" "Proton-CachyOS"
 install_proton_cachyos
 fetch_proton_latest_release "${PROTON_GE_RELEASE_API}" "aarch64" "" "PROTON_GE" "Proton-GE"
 install_proton_ge
 run_steam_first_launch
 
 echo ""
-log_success "Steam installed successfully. You can now start it from EmulationStation from the Steam section."
+log_success "Steam setup finished. Start Steam to continue."

```

## ES delta (complete, unified context8)

```text
diff --git a/CMakeLists.txt b/CMakeLists.txt
index 315f26dff..cdbd1dfdd 100644
--- a/CMakeLists.txt
+++ b/CMakeLists.txt
@@ -303,21 +303,21 @@ endif()
 if(DEFINED ENV{SCREENSCRAPER_SOFTNAME})
     add_definitions(-DSCREENSCRAPER_SOFTNAME="$ENV{SCREENSCRAPER_SOFTNAME}")
 endif()
 
 if(DEFINED ENV{SCREENSCRAPER_DEV_LOGIN})
     add_definitions(-DSCREENSCRAPER_DEV_LOGIN="$ENV{SCREENSCRAPER_DEV_LOGIN}")
 endif()
 
-# The ScreenScraper developer pair entered on the device rather than compiled
-# in: the scraper is built, and its settings page grows DEVELOPER ID and
-# DEVELOPER PASSWORD rows, so no image carries a key. Set from the package
-# recipe (-DSCREENSCRAPER_RUNTIME_DEV_LOGIN=1) or the environment. A compiled-in
-# SCREENSCRAPER_DEV_LOGIN still takes precedence and hides the rows.
+# Enable runtime developer credentials for builds without a compiled pair.
+# Those builds show DEVELOPER ID and DEVELOPER PASSWORD under SCRAPER > ACCOUNTS.
+# Set from the package recipe (-DSCREENSCRAPER_RUNTIME_DEV_LOGIN=1) or environment.
+# A compiled-in SCREENSCRAPER_DEV_LOGIN takes precedence and hides the rows;
+# normal distribution builds supply that pair at build time (#566).
 if(SCREENSCRAPER_RUNTIME_DEV_LOGIN OR DEFINED ENV{SCREENSCRAPER_RUNTIME_DEV_LOGIN})
     add_definitions(-DSCREENSCRAPER_RUNTIME_DEV_LOGIN=1)
 endif()
 
 if(DEFINED ENV{GAMESDB_APIKEY})
     add_definitions(-DGAMESDB_APIKEY="$ENV{GAMESDB_APIKEY}")
 endif()
 
diff --git a/es-app/src/ApiSystem.cpp b/es-app/src/ApiSystem.cpp
index 9abd29fca..5975b449c 100644
--- a/es-app/src/ApiSystem.cpp
+++ b/es-app/src/ApiSystem.cpp
@@ -14,16 +14,19 @@
 #include "utils/ThreadPool.h"
 #include "RetroAchievements.h"
 #include "utils/ZipFile.h"
 #include "Paths.h"
 #include "utils/VectorEx.h"
 #include "LocaleES.h"
 
 #include <stdlib.h>
+#if defined(__GLIBC__)
+#include <malloc.h>
+#endif
 #include <sstream>
 #include <iostream>
 #include <fstream>
 #include <chrono>
 #include <thread>
 #include <stdio.h>
 #include <string.h>
 #include <regex>
@@ -569,16 +572,20 @@ bool ApiSystem::launchCloudSignIn(Window *window, bool phoneKeyboard)
 		? "/usr/bin/cloud_oauth open --phone" : "/usr/bin/cloud_oauth open";
 	if (system(open) != 0)
 	{
 		LOG(LogWarning) << "cloud sign-in window did not open; staying put";
 		return false;
 	}
 
 	ApiSystem::launchExternalWindow_before(window);
+#if defined(__GLIBC__)
+	// Return freed renderer heaps before waiting for sign-in (distro #570).
+	malloc_trim(0);
+#endif
 	int exitCode = system("/usr/bin/cloud_oauth wait");
 	if (WIFEXITED(exitCode))
 		exitCode = WEXITSTATUS(exitCode);
 	ApiSystem::launchExternalWindow_after(window);
 
 	// `wait` returns as soon as the sign-in lands, with the page still up
 	// saying "Finishing up" -- so this rebuild happens behind something
 	// rather than in front of a black screen. Now that we are drawing again,
diff --git a/es-app/src/GameCubeRvzHashRetry.h b/es-app/src/GameCubeRvzHashRetry.h
new file mode 100644
index 000000000..794d06a8c
--- /dev/null
+++ b/es-app/src/GameCubeRvzHashRetry.h
@@ -0,0 +1,45 @@
+#pragma once
+// SPDX-License-Identifier: MIT
+// #574: narrow recovery of failed frontend RVZ hashes, not metadata cleanup.
+#include <string>
+
+namespace GameCubeRvzHashRetry
+{
+    inline std::string trim(const std::string& value)
+    {
+        const auto first = value.find_first_not_of(" \t\r\n");
+        if (first == std::string::npos)
+            return {};
+        return value.substr(first, value.find_last_not_of(" \t\r\n") - first + 1);
+    }
+
+    inline bool needed(bool readerEnabled, bool gameCubeOnly,
+        const std::string& extension, const std::string& storedHash, const std::string& storedId)
+    {
+        if (!readerEnabled || !gameCubeOnly || extension.size() != 4 || extension[0] != '.' ||
+            (extension[1] != 'r' && extension[1] != 'R') ||
+            (extension[2] != 'v' && extension[2] != 'V') ||
+            (extension[3] != 'z' && extension[3] != 'Z'))
+            return false;
+
+        // Only an absent ID or the existing no-ID marker is eligible. Preserve
+        // positive IDs and unfamiliar nonempty metadata, even beside a bad hash.
+        const std::string id = trim(storedId);
+        if (!id.empty() && id != "0")
+            return false;
+
+        const std::string hash = trim(storedHash);
+        if (hash.size() != 32)
+            return true;
+        bool nonzero = false;
+        for (char c : hash)
+        {
+            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
+                return true;
+            nonzero = nonzero || c != '0';
+        }
+        // A valid unknown hash still takes the old lookup-only path. The all-
+        // zero value is getCheevosHashFromFile's historical failure sentinel.
+        return !nonzero;
+    }
+}
diff --git a/es-app/src/ThreadedHasher.cpp b/es-app/src/ThreadedHasher.cpp
index b2547d475..c601da863 100644
--- a/es-app/src/ThreadedHasher.cpp
+++ b/es-app/src/ThreadedHasher.cpp
@@ -7,16 +7,19 @@
 #include "RetroAchievements.h"
 #include "SystemConf.h"
 #include "SystemData.h"
 #include "FileData.h"
 #include "ApiSystem.h"
 #include "OfflineAchievements.h"
 #include "ProxyCards.h"
 #include "CheevosIndex.h"
+#include "GameCubeRvzHashRetry.h"
+#include "PlatformId.h"
+#include <libcheevos/cheevos.h>
 #include "utils/StringUtil.h"
 #include "Log.h"
 #include "Settings.h"
 #include <ctime>
 #include <unordered_set>
 #include <queue>
 
 #include "LocaleES.h"
@@ -24,16 +27,30 @@
 #define ICONINDEX _U("\uF002 ")
 
 ThreadedHasher* ThreadedHasher::mInstance = nullptr;
 bool ThreadedHasher::mPaused = false;
 bool ThreadedHasher::sCheevosLibraryCame = false;
 
 static std::mutex mLoaderLock;
 
+static bool retryGameCubeRvzHash(FileData* game)
+{
+    if (!gameCubeRvzHashEnabled() || game->getSystem() == nullptr)
+        return false;
+    const auto& platforms = game->getSystem()->getPlatformIds();
+    // A mixed-platform system can select another console in getCheevosHash.
+    // Keep the repair confined to the unambiguous GameCube mapping.
+    const bool gameCubeOnly = platforms.size() == 1 &&
+        platforms.count(PlatformIds::NINTENDO_GAMECUBE) != 0;
+    return GameCubeRvzHashRetry::needed(true, gameCubeOnly,
+        Utils::FileSystem::getExtension(game->getPath()),
+        game->getMetadata(MetaDataId::CheevosHash), game->getMetadata(MetaDataId::CheevosId));
+}
+
 ThreadedHasher::ThreadedHasher(Window* window, HasherType type, std::queue<FileData*> searchQueue, const std::vector<FileData*>& lookupOnly, bool forceAllGames)
 	: mWindow(window), mWndNotification(nullptr)
 {
 	mForce = forceAllGames;
 	mExit = false;
 	mType = type;
 	mCheevosIndexed = false;
 	mThreadCount = 0;
@@ -200,17 +217,19 @@ void ThreadedHasher::run()
 			LOG(LogDebug) << "CheckCrc32 : " << label;
 			game->checkCrc32(mForce);
 		}
 
 		if (cheevos)
 		{
 			LOG(LogDebug) << "CheckCheevosHash : " << label;
 			if (!lookupOnly)
-				game->checkCheevosHash(mForce);
+				// Queue eligibility alone is insufficient: FileData skips every
+				// stored hash unless forced. Force only this failed RVZ entry.
+				game->checkCheevosHash(mForce || retryGameCubeRvzHash(game));
 
 			auto hash = Utils::String::toUpper(game->getMetadata(MetaDataId::CheevosHash));
 			if (!hash.empty())
 			{
 				// The id reaches the disk with the hash. checkCheevosHash
 				// saved the game to the recovery folder with the hash and no
 				// id, because the id is decided here, afterwards, and until
 				// now it lived in memory until the gamelist was written at
@@ -297,17 +316,21 @@ void ThreadedHasher::start(Window* window, HasherType type, bool forceAllGames,
 		if (sys->isGroupChildSystem() ? sys->isHidden() : !sys->isVisible())
 			continue;
 
 		for (auto file : sys->getRootFolder()->getFilesRecursive(GAME))
 		{
 			bool netPlay = takeNetplay && (forceAllGames || file->getMetadata(MetaDataId::Crc32).empty());
 			CheevosIndex::Take take = CheevosIndex::Take::None;
 			if (takeCheevos)
+			{
 				take = CheevosIndex::take(forceAllGames, file->getMetadata(MetaDataId::CheevosHash), file->getMetadata(MetaDataId::CheevosId));
+				if (retryGameCubeRvzHash(file))
+					take = CheevosIndex::Take::Hash;
+			}
 			bool cheevos = take == CheevosIndex::Take::Hash;
 
 			if (cheevos)
 			{
 				std::string ext = Utils::String::toLower(Utils::FileSystem::getExtension(file->getPath()));
 				
 				if (ext == ".pbp" || ext == ".cso") // Currently unsupported formats
 					cheevos = false;
diff --git a/es-app/src/guis/GuiMenu.cpp b/es-app/src/guis/GuiMenu.cpp
index 4b329c4b9..ae348511b 100644
--- a/es-app/src/guis/GuiMenu.cpp
+++ b/es-app/src/guis/GuiMenu.cpp
@@ -5793,17 +5793,21 @@ void GuiMenu::openGamesSettings()
 	}
 
 	// Custom config for systems
 	s->addGroup(_("SAVE STATES"));
 
 	// AUTO SAVE/LOAD
 	auto autosave_enabled = std::make_shared<SwitchComponent>(mWindow);
 	autosave_enabled->setState(SystemConf::getInstance()->get("global.autosave") == "1");
+#if defined(ROCKNIX)
+	s->addWithDescription(_("AUTO SAVE/LOAD"), _("Supported emulators only. Save on exit and load on launch."), autosave_enabled);
+#else
 	s->addWithDescription(_("AUTO SAVE/LOAD"), _("Load latest save state on game launch and save state when exiting game."), autosave_enabled);
+#endif
 	s->addSaveFunc([autosave_enabled] { SystemConf::getInstance()->set("global.autosave", autosave_enabled->getState() ? "1" : ""); });
 
 	// INCREMENTAL SAVESTATES
 	auto incrementalSaveStates = std::make_shared<OptionListComponent<std::string>>(mWindow, _("INCREMENTAL SAVE STATES"));
 	// A device upgraded from before the row had two spellings can hold "0",
 	// which matches no entry, so the row showed INCREMENT PER SAVE while the
 	// launcher ran with auto-index off. "0" reads as DO NOT INCREMENT, which
 	// is what it does (fork #209, D-UI-083); the row's next save writes "2".
@@ -5820,17 +5824,21 @@ void GuiMenu::openGamesSettings()
 		incrementalValue);
 
 	s->addWithLabel(_("INCREMENTAL SAVE STATES"), incrementalSaveStates);
 	s->addSaveFunc([incrementalSaveStates] { SystemConf::getInstance()->set("global.incrementalsavestates", incrementalSaveStates->getSelected()); });
 
 	// SHOW SAVE STATES
 	auto showSaveStates = std::make_shared<OptionListComponent<std::string>>(mWindow, _("SHOW SAVE STATE MANAGER"));
 	showSaveStates->addRange({ { _("NO"), "auto" },{ _("ALWAYS") , "1" },{ _("IF NOT EMPTY") , "2" } }, SystemConf::getInstance()->get("global.savestates"));
+#if defined(ROCKNIX)
+	s->addWithDescription(_("SHOW SAVE STATE MANAGER"), _("RetroArch only. Show the manager before launching a game."), showSaveStates);
+#else
 	s->addWithDescription(_("SHOW SAVE STATE MANAGER"), _("Display save state manager before launching a game."), showSaveStates);
+#endif
 	s->addSaveFunc([showSaveStates] { SystemConf::getInstance()->set("global.savestates", showSaveStates->getSelected()); });
 
 	s->addGroup(_("DEFAULT GLOBAL SETTINGS"));
 
 	// Screen ratio choice
 	if (!hasGlobalFeature("ratio"))
 	{
 		auto ratio_choice = createRatioOptionList(mWindow, "global");
@@ -7480,18 +7488,18 @@ static void cloudRemoteChooseBackend(Window* window, const CloudBackend& backend
 struct CloudOAuthReady
 {
 	bool started = false;
 	bool onDevice = false;
 	std::string url;
 	std::string exitHint = "SELECT + START";
 };
 
-static void cloudOAuthShowSignIn(Window* window, const CloudBackend& backend,
-	const std::string& remoteName, GuiSettings* prev, bool usePhone,
+static void cloudOAuthShowSignIn(Window* window, CloudBackend backend,
+	std::string remoteName, GuiSettings* prev, bool usePhone,
 	const CloudOAuthReady& ready);
 static void cloudOAuthPresentChoice(Window* window, const CloudBackend& backend,
 	const std::string& remoteName, GuiSettings* prev,
 	const CloudOAuthReady& ready);
 static void cloudOAuthShowConnected(Window* window, const CloudBackend& backend,
 	const std::string& remoteName, GuiSettings* prev);
 static void cloudOAuthChooseInput(Window* window, const CloudBackend& backend,
 	const std::string& remoteName, GuiSettings* prev);
@@ -7661,18 +7669,61 @@ static void cloudOAuthPresentChoice(Window* window, const CloudBackend& backend,
 			cloudOAuthShowSignIn(window, backend, remoteName, s, true, ready);
 		}, "", false, true);
 
 	cloudSetupSetButtons(s, nullptr);
 	cloudOAuthOwnSession(s);
 	cloudSetupPresent(window, s, prev);
 }
 
-static void cloudOAuthShowSignIn(Window* window, const CloudBackend& backend,
-	const std::string& remoteName, GuiSettings* prev, bool usePhone,
+// Both keyboard routes use the same window and can fail before it opens
+// (fork #570). The page beneath this dialog still owns the authorization.
+// Copy onReturn: checking completion can replace and delete that page.
+static void cloudOAuthOpenSignIn(Window* window, CloudBackend backend,
+	std::string remoteName, GuiSettings* page, bool usePhone,
+	std::function<void()> onReturn)
+{
+	if (ApiSystem::getInstance()->launchCloudSignIn(window, usePhone))
+	{
+		if (onReturn)
+			onReturn();
+		return;
+	}
+
+	// A completed authorization wins even if the window failed to return.
+	const auto lines = Utils::Platform::GetShOutputLines("/usr/bin/cloud_oauth status");
+	const std::string status = lines.empty() ? "" : Utils::String::trim(lines.front());
+	if (status == "signed-in")
+	{
+		cloudOAuthShowConnected(window, backend, remoteName, page);
+		return;
+	}
+
+	// The bool also covers a failed wait, so do not claim every failure was
+	// at startup. No OK action returns to a page still claiming to open.
+	window->pushGui(new GuiMsgBox(window,
+		_("THE SIGN-IN WINDOW DID NOT OPEN OR STOPPED WORKING.\n\nTRY AGAIN, OR CANCEL SIGN-IN."),
+		_("TRY AGAIN"), [window, backend, remoteName, page, usePhone, onReturn]
+		{
+			// Recheck on the press: authorization can finish or expire while
+			// the question is open. A waiting attempt keeps its phone pairing.
+			const auto lines = Utils::Platform::GetShOutputLines("/usr/bin/cloud_oauth status");
+			const std::string status = lines.empty() ? "" : Utils::String::trim(lines.front());
+			if (status == "signed-in")
+				cloudOAuthShowConnected(window, backend, remoteName, page);
+			else if (status == "waiting")
+				cloudOAuthOpenSignIn(window, backend, remoteName, page, usePhone, onReturn);
+			else
+				cloudOAuthStart(window, backend, remoteName, page);
+		},
+		_("CANCEL SIGN-IN"), [page] { page->close(); }, GuiMsgBoxIcon::ICON_ERROR));
+}
+
+static void cloudOAuthShowSignIn(Window* window, CloudBackend backend,
+	std::string remoteName, GuiSettings* prev, bool usePhone,
 	const CloudOAuthReady& ready)
 {
 	auto s = new GuiSettings(window, _("CONNECT CLOUD STORAGE"));
 	s->setSubTitle(CloudText::providerSubtitle(backend.name, backend.label));
 
 	// The address carries its own PIN in its path. ADDRESS and PIN are still
 	// reported by `info` for anything driving this from a shell, but the page
 	// has nothing to do with them separately -- two numbers on one screen is
@@ -7750,34 +7801,20 @@ static void cloudOAuthShowSignIn(Window* window, const CloudBackend& backend,
 		else
 			cloudSetupAddProse(s, window, _("THEN"),
 				_("THAT PAGE WALKS YOU THROUGH SIGNING IN. COME BACK HERE AND SELECT 'CONTINUE' WHEN IT SAYS YOU ARE CONNECTED."));
 	}
 
 	// Ask cloud_oauth, which asks rclone. Nothing here decides on its own
 	// that a sign-in worked.
 	//
-	// openOnContinue is false when the page is already open: pressing
-	// CONTINUE then means "I am done", not "open it".
-	const bool openOnContinue = onDevice && usePhone;
-	cloudSetupSetButtons(s, [window, backend, remoteName, s, openOnContinue]
+	// Keep this callback separate so a successful phone-window retry runs
+	// the same completion check as its original CONTINUE press.
+	auto finishSignIn = [window, backend, remoteName, s]
 	{
-		if (openOnContinue)
-		{
-			auto info = Utils::Platform::GetShOutputLines("/usr/bin/cloud_oauth status");
-			std::string now = info.empty() ? "" : Utils::String::trim(info.front());
-			if (now == "waiting")
-			{
-				// Blocks until the player comes back out of the page, so
-				// there is no dialog to dismiss afterwards and no second
-				// CONTINUE to press -- fall through and say what happened.
-				ApiSystem::getInstance()->launchCloudSignIn(window, true);
-			}
-		}
-
 		auto lines = Utils::Platform::GetShOutputLines("/usr/bin/cloud_oauth status");
 		std::string status = lines.empty() ? "" : Utils::String::trim(lines.front());
 		LOG(LogInfo) << "cloud_oauth status=" << status;
 
 		if (status == "signed-in")
 		{
 			cloudOAuthShowConnected(window, backend, remoteName, s);
 			return;
@@ -7793,26 +7830,49 @@ static void cloudOAuthShowSignIn(Window* window, const CloudBackend& backend,
 		window->pushGui(new GuiMsgBox(window,
 			_("STILL WAITING FOR THE SIGN-IN.\n\nFINISH IT, THEN CHOOSE 'CONTINUE' AGAIN."),
 			_("OK"), nullptr,
 			_("CANCEL SIGN-IN"), [window, s]
 			{
 				Utils::Platform::runSystemCommand("/usr/bin/cloud_oauth cancel", "", nullptr);
 				s->close();
 			}));
+	};
+
+	// Native CONTINUE checks completion; phone CONTINUE first opens the
+	// window while the session is waiting. A failed launch owns its dialog
+	// and must not fall through to the generic still-waiting message.
+	const bool openOnContinue = onDevice && usePhone;
+	cloudSetupSetButtons(s, [window, backend, remoteName, s, openOnContinue, finishSignIn]
+	{
+		if (openOnContinue)
+		{
+			auto info = Utils::Platform::GetShOutputLines("/usr/bin/cloud_oauth status");
+			std::string now = info.empty() ? "" : Utils::String::trim(info.front());
+			if (now == "waiting")
+			{
+				cloudOAuthOpenSignIn(window, backend, remoteName, s, true, finishSignIn);
+				return;
+			}
+		}
+		// Completion can delete s and its buttons; own the invocation first.
+		auto finish = finishSignIn;
+		finish();
 	});
 
 	cloudOAuthOwnSession(s);
 	cloudSetupPresent(window, s, prev);
 
 	// After the page is on the stack, never while it is being built: this
 	// blocks for as long as somebody is signing in, and ES is suspended for
 	// the duration. The page has to already be there for ES to come back to.
+	// backend and remoteName are owned values: presenting s deleted prev,
+	// which may have held the callback that supplied them.
 	if (openImmediately)
-		ApiSystem::getInstance()->launchCloudSignIn(window, false);
+		cloudOAuthOpenSignIn(window, backend, remoteName, s, false, nullptr);
 }
 
 // What it means to have connected something, said once, at the only moment
 // anybody is going to read it.
 //
 // The old ending was a one-line dialog -- "CONNECTED. CLOUD TOOLS ARE NOW
 // AVAILABLE" -- which named neither the provider just connected nor anything
 // the player could go and do. Somebody who has just finished a sign-in on a
@@ -8459,17 +8519,27 @@ void GuiMenu::updateGameLists(Window* window, bool confirm)
 	if (!confirm)
 	{
 		// The same update without the question (the API, the collections page): the
 		// same rescan, and the same index of new games after it (fork #299).
 		ViewController::reloadAllGames(window, true, true, true);
 		return;
 	}
 
-	window->pushGui(new GuiMsgBox(window, _("REALLY UPDATE GAMELISTS?"), _("YES"), [window]
+	std::string confirmation = _("REALLY UPDATE GAMELISTS?");
+#if defined(ROCKNIX)
+	// UPDATE GAMELISTS uses the startup index; its offline top-up follows
+	// only when that index has work (fork #567). Explain the download before
+	// this existing question, without probing the connection or promising
+	// a download on every update. The index can be switched off separately.
+	if (OfflineAchievements::available() && OfflineAchievements::toggleOn() && Settings::CheevosCheckIndexesAtStart())
+		confirmation = _("THIS ALSO CHECKS NEW GAMES FOR OFFLINE ACHIEVEMENTS. AN INTERNET CONNECTION IS NEEDED TO DOWNLOAD THEIR ACHIEVEMENT DATA.")
+			+ std::string("\n\n") + confirmation;
+#endif
+	window->pushGui(new GuiMsgBox(window, confirmation, _("YES"), [window]
 		{
 			Scripting::fireEvent("update-gamelists");
 			ViewController::reloadAllGames(window, true, true, true);
 		}, 
 		_("NO"), nullptr));
 }
 
 void GuiMenu::openSystemEmulatorSettings(SystemData* system)
@@ -10785,16 +10855,30 @@ void GuiMenu::popSpecificConfigurationGui(Window* mWindow, std::string title, st
 			popSpecificConfigurationGui(mWindow, title, configName, systemData, fileData);
 			delete systemConfiguration;
 
 		});
 
 		systemConfiguration->addWithLabel(_("Emulator"), emulChoice);
 	}
 
+#if defined(ROCKNIX)
+	// Resolve AUTO through the same per-game/system selection used at launch.
+	// These launchers do not consume autosave; engine-native options are separate.
+	const std::string saveStateEmulator = fileData != nullptr ? fileData->getEmulator() : systemData->getEmulator();
+	if (saveStateEmulator == "dolphin" || saveStateEmulator == "flycast")
+	{
+		systemConfiguration->addEntry(_("SAVE STATE SUPPORT"), true, [mWindow]
+		{
+			mWindow->pushGui(new GuiMsgBox(mWindow,
+				_("THE AUTO SAVE/LOAD SETTING AND SAVE STATE MANAGER DO NOT APPLY TO THIS EMULATOR.\n\nUSE THE EMULATOR'S OWN SAVE OPTIONS. IN-GAME SAVES ARE SEPARATE."), _("OK")));
+		});
+	}
+#endif
+
 	// System settings
 	systemConfiguration->addEntry(_("SYSTEM OPTIONS"), true, [mWindow, configName] { openSystemOptionsConfiguration(mWindow, configName); });
 
 	auto customFeatures = systemData->getCustomFeatures(currentEmulator, currentCore);
 
 	// Screen ratio choice
 	if (systemData->isFeatureSupported(currentEmulator, currentCore, EmulatorFeatures::ratio))
 	{
diff --git a/es-app/src/guis/GuiWifi.cpp b/es-app/src/guis/GuiWifi.cpp
index 819eec475..75953749a 100644
--- a/es-app/src/guis/GuiWifi.cpp
+++ b/es-app/src/guis/GuiWifi.cpp
@@ -1,70 +1,125 @@
 #include "guis/GuiWifi.h"
+#include "guis/WifiScanProcess.h"
 #include "guis/GuiMenu.h"
 #include "guis/GuiMsgBox.h"
 #include "guis/GuiSettings.h"
 #include "guis/GuiTextEditPopup.h"
 #include "guis/GuiTextEditPopupKeyboard.h"
 #include "components/TextComponent.h"
+#include "components/BusyComponent.h"
+#include "components/ButtonComponent.h"
 #include "ApiSystem.h"
 #include "GuiLoading.h"
 #include "LocaleES.h"
 #include "Log.h"
 #include "Settings.h"
 #include "SystemConf.h"
 #include "ThemeData.h"
 #include "Window.h"
 #include "utils/StringUtil.h"
 
+#include <algorithm>
+#include <exception>
+#include <utility>
+#include <thread>
+
+namespace
+{
+void releasePickerButtons(GuiComponent* component)
+{
+	// Called only after hitTest(-1, -1) has cleared every hover flag. A
+	// held mouse press is then released without invoking a button action.
+	if (auto button = dynamic_cast<ButtonComponent*>(component))
+		button->onMouseClick(1, false, -1, -1);
+	for (int i = 0; i < component->getChildCount(); ++i)
+		releasePickerButtons(component->getChild(i));
+}
+}
+
 GuiWifi::GuiWifi(Window* window, const std::string& title, const std::function<void()>& onJoined)
-	: GuiComponent(window), mMenu(window, title.c_str()), mTitle(title), mOnJoined(onJoined), mSavedKnown(true), mWaitingLoad(false)
+	: GuiComponent(window), mMenu(window, title.c_str()), mTitle(title), mOnJoined(onJoined), mSavedKnown(false), mWaitingLoad(false)
 {
+	setSize(Renderer::getScreenWidth(), Renderer::getScreenHeight());
 	addChild(&mMenu);
+	mMenu.setUpdateType(ComponentListFlags::UPDATE_WHEN_SELECTED);
+	mMenu.addButton(_("REFRESH"), _("REFRESH"), [this] { onRefresh(); });
+	mMenu.addButton(_("INPUT MANUALLY"), _("INPUT MANUALLY"), [this] { onManualInput(); });
+	mMenu.addButton(_("BACK"), _("BACK"), [this] { if (!mWaitingLoad) delete this; });
+
+	// Reserve the viewport once, including an in-list status band. Never
+	// call updateSize/setSubTitle or rebuild buttons as scan answers arrive.
+	const bool fullScreen = Renderer::ScreenSettings::fullScreenMenus();
+	mMenu.setSize(fullScreen ? mSize.x() : std::min(mSize.y(), mSize.x() * 0.90f),
+		fullScreen ? mSize.y() : mSize.y() * 0.75f);
+	mMenu.setPosition((mSize.x() - mMenu.getSize().x()) / 2,
+		fullScreen ? 0 : mSize.y() * 0.15f);
 
-	// Fetched off the interface thread. wifictl list is itself a rescan --
-	// it waits for the adapter, asks NetworkManager to scan, sleeps, then
-	// lists -- so this constructor used to run up to twenty seconds of
-	// nmcli with nothing drawn, and with NetworkManager unresponsive (fork
-	// #102) nothing bounded it at all. Posted rather than pushed here,
-	// because the page has to be on the stack before anything can go over
-	// it; an empty first answer still turns into the full scan it always did.
-	mWindow->postToUiThread([this]() { onRefresh(false); });
-
-	mMenu.addButton(_("REFRESH"), "refresh", [&] { onRefresh(); });
-	mMenu.addButton(_("INPUT MANUALLY"), "manual input", [&] { onManualInput(); });
-	mMenu.addButton(_("BACK"), "back", [&] { delete this; });
-
-	if (Renderer::ScreenSettings::fullScreenMenus())
-		mMenu.setPosition((Renderer::getScreenWidth() - mMenu.getSize().x()) / 2, (Renderer::getScreenHeight() - mMenu.getSize().y()) / 2);
-	else
-		mMenu.setPosition((Renderer::getScreenWidth() - mMenu.getSize().x()) / 2, Renderer::getScreenHeight() * 0.15f);
+	auto theme = ThemeData::getMenuTheme();
+	auto list = mMenu.getList();
+	const auto position = list->getPosition();
+	const auto size = list->getSize();
+	// Prime this shared font before measuring its maximum glyph height.
+	theme->Text.font->sizeText(_("SEARCHING WI-FI NETWORKS") + std::string(_("COULDN'T SEARCH WI-FI NETWORKS. TRY AGAIN.")) +
+		_("SHOWING PREVIOUS RESULTS.") + _("COULDN'T CHECK WHICH NETWORKS ARE SAVED.") + _("NO WI-FI NETWORKS FOUND"));
+	const float statusHeight = theme->Text.font->sizeText("A\nA", 1.0f).y() + mSize.y() * 0.01f;
+	const float inset = ComponentList::rowInset();
+	const float spinnerWidth = theme->Text.font->getLetterHeight() * 2.0f;
+	mStatus = std::make_shared<TextComponent>(mWindow, "", theme->Text.font, theme->Text.color);
+	mStatus->setMultiLine(TextComponent::MultiLineType::MULTILINE);
+	mStatus->setLineSpacing(1.0f);
+	mStatus->setVerticalAlignment(ALIGN_CENTER);
+	if (EsLocale::isRTL())
+		mStatus->setHorizontalAlignment(ALIGN_RIGHT);
+	mStatus->setSize(size.x() - 2 * inset - spinnerWidth, statusHeight);
+	mStatus->setPosition(position.x() + inset + spinnerWidth, position.y());
+	mStatus->setZIndex(20);
+	mMenu.addChild(mStatus.get());
+	list->setPosition(position.x(), position.y() + statusHeight);
+	list->setSize(size.x(), std::max(0.0f, size.y() - statusHeight));
+
+	// No posted callback capturing this. The worker starts after the native
+	// components are ready and publishes values for update() to consume.
+	onRefresh(false);
 }
 
 void GuiWifi::load(const std::vector<WifiText::PickerRow>& rows)
 {
-	mMenu.clear();
-
-	// A list whose SAVED marks could not be read says so, once, under the
-	// title (#308 F-WF-03): the rows are then neither saved nor unsaved, and
-	// a press on one asks before it acts.
-	mMenu.setSubTitle(mSavedKnown ? "" : _("COULDN'T CHECK WHICH NETWORKS ARE SAVED."));
+	auto list = mMenu.getList();
+	const bool buttonsFocused = mMenu.isCursorToButtons();
+	const int previousIndex = list->getCursorIndex();
+	const std::string selected = list->getSelectedUserData();
+	const bool unchanged = rows.size() == mRows.size() && std::equal(rows.begin(), rows.end(), mRows.begin(),
+		[](const WifiText::PickerRow& a, const WifiText::PickerRow& b)
+		{
+			return a.name == b.name && a.saved == b.saved && a.connected == b.connected &&
+				a.savedKnown == b.savedKnown && a.profile == b.profile;
+		});
 
-	if (rows.empty())
-		mMenu.addEntry(_("NO WI-FI NETWORKS FOUND"), false, [this] { onRefresh(); });
-	else
-		for (const auto& row : rows)
+	// Keep the actual list and scroll offset on identical refreshes. When
+	// rows change, restore the SSID, or the nearest surviving index. The
+	// native list keeps that row visible instead of jumping to the top.
+	if (!unchanged)
+	{
+		mMenu.clear();
+		mRows = rows;
+		for (const auto& row : mRows)
 			addRow(row);
-
-	mMenu.updateSize();
-
-	if (Renderer::ScreenSettings::fullScreenMenus())
-		mMenu.setPosition((Renderer::getScreenWidth() - mMenu.getSize().x()) / 2, (Renderer::getScreenHeight() - mMenu.getSize().y()) / 2);
-
-	mWaitingLoad = false;
+		if (!mRows.empty())
+		{
+			auto match = std::find_if(mRows.begin(), mRows.end(), [&selected](const WifiText::PickerRow& row) { return row.name == selected; });
+			const int index = match == mRows.end() ? std::min(previousIndex, (int)mRows.size() - 1) : (int)(match - mRows.begin());
+			list->setCursorIndex(std::max(0, index), true);
+		}
+	}
+	if (mRows.empty())
+		mMenu.setCursorToButton(0);
+	else if (!buttonsFocused)
+		mMenu.setCursorToList();
 }
 
 // The name as NetworkManager has it -- case and spaces kept, since a
 // network's name is what the player recognises it by (addEntry would
 // upper-case it) -- and, on the right at the row's own weight, CONNECTED for
 // the network the device is on or SAVED for one it holds a profile for: the
 // shape and the word of MANAGE SAVED NETWORKS' mark, a fact beside the
 // action.
@@ -83,29 +138,29 @@ void GuiWifi::addRow(const WifiText::PickerRow& network)
 		const std::string mark = network.connected ? _("CONNECTED") : _("SAVED");
 		auto label = std::make_shared<TextComponent>(mWindow, mark, theme->Text.font, theme->Text.color, Alignment::ALIGN_RIGHT);
 		label->setSize(theme->Text.font->sizeText(mark + "  ").x(), 0);
 		row.addElement(label, false);
 	}
 
 	const WifiText::PickerRow chosen = network;
 	row.makeAcceptInputHandler([this, chosen] { onSelect(chosen); });
-	mMenu.addRow(row);
+	mMenu.addRow(row, false, false, network.name);
 }
 
 // A press: the network the device is on joins again with the key
 // NetworkManager holds -- it answers at once, or comes back if it had
 // dropped (#308 F-WF-05: this used to close on the list's snapshot); a
 // saved one is offered CONNECT / FORGET / CANCEL (#318, D-UI-118); any
 // unsaved open network connects without a key; protected or unknown ones ask
 // for their key. One whose profile could not be asked about
 // is asked about again first (F-WF-03/06). WifiText::pressAction decides.
 void GuiWifi::onSelect(const WifiText::PickerRow& row)
 {
-	if (mWaitingLoad)
+	if (mWaitingLoad || mScan)
 		return;
 
 	if (row.savedKnown && WifiText::profilesForSsid(row.name, mSaved).size() > 1 && row.profile.empty())
 	{
 		chooseProfile(row.name);
 		return;
 	}
 	act(WifiText::pressAction(row), row.name, WifiText::joinName(row));
@@ -176,16 +231,19 @@ void GuiWifi::act(WifiText::PressAction action, const std::string& name, const s
 }
 
 // INPUT MANUALLY: a hidden network's name, taken as a row would be -- a
 // name NetworkManager holds a profile for joins, the one the device is on
 // needs nothing, any other is asked for its key. Not trimmed: a name may
 // begin or end with a space, and it is matched as NetworkManager has it.
 void GuiWifi::onManualInput()
 {
+	if (mWaitingLoad || mScan)
+		return;
+
 	auto onName = [this](const std::string& name)
 	{
 		if (name.empty())
 			return;
 		const auto profile = WifiText::preferredProfile(name, mSaved);
 		if (mSavedKnown && WifiText::profilesForSsid(name, mSaved).size() > 1 && profile.empty())
 		{
 			chooseProfile(name);
@@ -313,75 +371,186 @@ void GuiWifi::joined(const std::string& name)
 	window->displayNotificationMessage(_U("\uF058 ") + WifiText::joinedNotice(name, _("CONNECTED")));
 	delete this;
 	if (onJoined != nullptr)
 		onJoined();
 }
 
 bool GuiWifi::input(InputConfig* config, Input input)
 {
-	if (GuiComponent::input(config, input))
-		return true;
-
 	if (input.value != 0 && config->isMappedTo(BUTTON_BACK, input))
 	{
 		if (!mWaitingLoad)
 			delete this;
-
 		return true;
 	}
 
-	return false;
+	// A press during a scan cannot join an old row, open a key editor or
+	// queue another scan. BACK remains available without joining the worker.
+	if (mScan || mWaitingLoad)
+		return true;
+	return GuiComponent::input(config, input);
+}
+
+bool GuiWifi::hitTest(int x, int y, Transform4x4f& parentTransform, std::vector<GuiComponent*>* result)
+{
+	if (!mScan)
+		return GuiComponent::hitTest(x, y, parentTransform, result);
+
+	// Mouse/touch bypass input(). During scanning only the native BACK
+	// button may capture a press, so a release after completion cannot act
+	// on a refreshed row or start the action of a previously pressed button.
+	std::vector<GuiComponent*> hits;
+	const bool hit = GuiComponent::hitTest(x, y, parentTransform, &hits);
+	if (result)
+		for (auto component : hits)
+			if (auto button = dynamic_cast<ButtonComponent*>(component))
+				if (button->getText() == _("BACK"))
+					result->push_back(button);
+	return hit;
 }
 
 std::vector<HelpPrompt> GuiWifi::getHelpPrompts()
 {
-	std::vector<HelpPrompt> prompts = mMenu.getHelpPrompts();
+	std::vector<HelpPrompt> prompts;
+	if (!mScan && !mWaitingLoad)
+		prompts = mMenu.getHelpPrompts();
 	prompts.push_back(HelpPrompt(BUTTON_BACK, _("BACK")));
 	return prompts;
 }
 
-// rescan: ask NetworkManager for a fresh scan first (REFRESH, and an empty
-// first list); false lists what it already knows, which is what the page
-// opens with. The saved profiles and the network joined now come with the
-// same wait, behind the spinner, each time-boxed in ApiSystem.
-void GuiWifi::onRefresh(bool rescan)
+void GuiWifi::update(int deltaTime)
 {
-	Window* window = mWindow;
-	mWaitingLoad = true;
+	GuiComponent::update(deltaTime);
+	if (!mScan || !mScan->ready.load(std::memory_order_acquire))
+		return;
 
-	window->pushGui(new GuiLoading<Answer>(window, _("SEARCHING WI-FI NETWORKS"),
-		[rescan](IGuiLoadingHandler*)
+	const Answer answer = mScan->answer;
+	mScan.reset();
+	mBusy.reset();
+	mWindow->releaseMouseCapture();
+
+	// A failed range query keeps prior network names. Saved/current metadata
+	// is freshly read even then; unknown metadata keeps the existing guarded
+	// CheckAgain route rather than interpreting an unknown profile as absent.
+	std::vector<std::string> inRange = answer.inRange;
+	const bool retainedResults = !answer.inRangeKnown && !mRows.empty();
+	if (!answer.inRangeKnown)
+		for (const auto& row : mRows)
+			inRange.push_back(row.name);
+	const auto rows = WifiText::pickerRows(inRange, answer.saved, answer.current,
+		answer.savedKnown, answer.currentKnown);
+	mSaved = answer.saved;
+	mSavedKnown = answer.savedKnown;
+	mCurrent.clear();
+	mCurrentProfile.clear();
+	for (const auto& row : rows)
+		if (row.connected)
 		{
-			// Each getter says whether it could ask at all (true for an
-			// answer, "none" included), and that is kept: "could not ask"
-			// used to be read as "none" (#308 F-WF-03/06).
-			Answer answer;
-			answer.inRange = ApiSystem::getInstance()->getWifiNetworks(rescan);
-			answer.savedKnown = ApiSystem::getInstance()->getSavedWifiNetworks(answer.saved);
-			answer.currentKnown = ApiSystem::getInstance()->getCurrentWifiSsid(answer.current);
-			return answer;
-		},
-		[this, rescan](Answer answer)
+			mCurrent = row.name;
+			mCurrentProfile = row.profile;
+		}
+	load(rows);
+
+	std::string status;
+	if (!answer.inRangeKnown)
+	{
+		status = _("COULDN'T SEARCH WI-FI NETWORKS. TRY AGAIN.");
+		if (retainedResults)
+			status += "\n" + std::string(_("SHOWING PREVIOUS RESULTS."));
+	}
+	else if (rows.empty())
+		status = _("NO WI-FI NETWORKS FOUND");
+	else if (!mSavedKnown)
+		status = _("COULDN'T CHECK WHICH NETWORKS ARE SAVED.");
+	mStatus->setText(status);
+	LOG(LogInfo) << "wifi picker: scan " << (answer.inRangeKnown ? "completed" : "failed")
+		<< "; rows=" << rows.size() << "; retained=" << retainedResults;
+	updateHelpPrompts();
+}
+
+void GuiWifi::onRefresh(bool rescan)
+{
+	if (mScan || mWaitingLoad)
+		return;
+
+	// UI-thread-only weak registry. Closing a picker leaves at most the one
+	// bounded read job; reopening attaches to it instead of starting a rival.
+	// A completed answer is never reused for a later explicit refresh.
+	static std::weak_ptr<Scan> activeScan;
+	mScan = activeScan.lock();
+	if (mScan && mScan->ready.load(std::memory_order_acquire))
+		mScan.reset();
+	const bool reused = mScan != nullptr;
+	if (!mScan)
+	{
+		mScan = std::make_shared<Scan>();
+		activeScan = mScan;
+		auto scan = mScan;
+		try
 		{
-			mWaitingLoad = false;
-			if (answer.inRange.empty() && !rescan)
+			std::thread([scan, rescan]
 			{
-				onRefresh(true);
-				return;
-			}
-			const std::vector<WifiText::PickerRow> rows = WifiText::pickerRows(answer.inRange, answer.saved, answer.current,
-				answer.savedKnown, answer.currentKnown);
-			mSaved = answer.saved;
-			mSavedKnown = answer.savedKnown;
-			// The network the device is on, as the rows have it: from the
-			// saved list's active profile when current could not say.
-			mCurrent.clear();
-			mCurrentProfile.clear();
-			for (const auto& row : rows)
-				if (row.connected)
+				try
 				{
-					mCurrent = row.name;
-					mCurrentProfile = row.profile;
+					Answer answer;
+					const auto range = WifiScanProcess::read({"wifictl", rescan ? "scanlist" : "list"}, std::chrono::seconds(rescan ? 45 : 30));
+					answer.inRangeKnown = range.code == 0;
+					answer.inRange = range.lines;
+
+					// Match ApiSystem's saved/current protocol, but reject signal
+					// and read failures too. No singleton or GUI is worker-owned.
+					const auto saved = WifiScanProcess::read({"wifictl", "saved", "--ssid"}, std::chrono::seconds(15));
+					answer.savedKnown = saved.code == 0;
+					if (answer.savedKnown)
+						for (const auto& line : saved.lines)
+						{
+							WifiText::SavedNetwork network;
+							if (!WifiText::parseSavedDetailsLine(line, network))
+							{
+								answer.savedKnown = false;
+								break;
+							}
+							answer.saved.push_back(network);
+						}
+					if (!answer.savedKnown)
+						answer.saved.clear();
+
+					const auto current = WifiScanProcess::read({"wifictl", "current"}, std::chrono::seconds(10));
+					answer.current = WifiText::parseCurrent(current.lines);
+					answer.currentKnown = (current.code == 0 && !answer.current.empty()) || current.code == 1;
+					if (current.code != 0)
+						answer.current.clear();
+					scan->answer = std::move(answer);
 				}
-			load(rows);
-		}));
+				catch (...)
+				{
+					// The default answer is unknown, not a successful empty scan.
+					LOG(LogWarning) << "wifi picker: scan worker failed";
+				}
+				LOG(LogInfo) << "wifi picker: scan worker finished";
+				scan->ready.store(true, std::memory_order_release);
+			}).detach();
+		}
+		catch (const std::exception&)
+		{
+			LOG(LogWarning) << "wifi picker: could not start scan worker";
+			mScan->ready.store(true, std::memory_order_release);
+		}
+	}
+
+	if (mMenu.getList()->getScrollingVelocity() != 0)
+		mMenu.getList()->stopScrolling();
+	auto transform = Transform4x4f::Identity();
+	mMenu.hitTest(-1, -1, transform);
+	releasePickerButtons(&mMenu);
+	mWindow->releaseMouseCapture();
+	mStatus->setText(_("SEARCHING WI-FI NETWORKS"));
+	const float spinnerWidth = ThemeData::getMenuTheme()->Text.font->getLetterHeight() * 2.0f;
+	mBusy = std::make_shared<BusyComponent>(mWindow, "");
+	mBusy->setBackgroundVisible(false);
+	mBusy->setSize(spinnerWidth, mStatus->getSize().y());
+	mBusy->setPosition(mStatus->getPosition().x() - spinnerWidth, mStatus->getPosition().y());
+	mBusy->setZIndex(20);
+	mMenu.addChild(mBusy.get());
+	LOG(LogInfo) << "wifi picker: " << (reused ? "attached to pending scan" : "scan started");
+	updateHelpPrompts();
 }
diff --git a/es-app/src/guis/GuiWifi.h b/es-app/src/guis/GuiWifi.h
index 867c22438..e372d5ef1 100644
--- a/es-app/src/guis/GuiWifi.h
+++ b/es-app/src/guis/GuiWifi.h
@@ -1,18 +1,22 @@
 #pragma once
 
 #include "GuiComponent.h"
 #include "components/MenuComponent.h"
 #include "WifiText.h"
 
+#include <atomic>
 #include <functional>
+#include <memory>
 #include <string>
 #include <vector>
 
+class BusyComponent;
+
 // The Wi-Fi picker behind NETWORK SETTINGS' WI-FI NETWORK row (fork #191,
 // renamed from WI-FI SSID by D-UI-071; the
 // maintainer's paradigm of 2026-09-15: the row is the network the device is
 // on, this list is what is in range). One row per network in range -- the
 // one joined now first and marked CONNECTED, the ones NetworkManager holds a
 // profile for marked SAVED. A press on a saved row offers CONNECT (with
 // the key NetworkManager has), FORGET (the manage page's confirmation and
 // reader) or CANCEL (#318, D-UI-118); a press on the connected row joins it
@@ -20,48 +24,63 @@
 // which saves it for next time; INPUT MANUALLY takes a hidden network's
 // name the same way. Once the device is on a network the page that opened
 // the picker is told, so it rebuilds and reads the connection back.
 class GuiWifi : public GuiComponent
 {
 public:
 	GuiWifi(Window* window, const std::string& title, const std::function<void()>& onJoined);
 	bool input(InputConfig* config, Input input) override;
+	void update(int deltaTime) override;
+	bool hitTest(int x, int y, Transform4x4f& parentTransform, std::vector<GuiComponent*>* result = nullptr) override;
 	std::vector<HelpPrompt> getHelpPrompts() override;
 
 private:
 	// The three answers the list is built from, fetched together off the
 	// interface thread.
 	struct Answer
 	{
 		std::vector<std::string> inRange;
+		bool inRangeKnown = false;
 		std::vector<WifiText::SavedNetwork> saved;
 		std::string current;
 		// Whether `wifictl saved` and `wifictl current` answered at all: an
 		// empty list and no list are different answers (#308 F-WF-03/06).
 		bool savedKnown = false;
 		bool currentKnown = false;
 	};
 
+	// The worker owns only this value. No GUI or Window pointer crosses into
+	// it, and the UI consumes the answer only after the release/acquire pair.
+	struct Scan
+	{
+		Answer answer;
+		std::atomic<bool> ready{false};
+	};
+
 	void load(const std::vector<WifiText::PickerRow>& rows);
 	void addRow(const WifiText::PickerRow& row);
 	void onSelect(const WifiText::PickerRow& row);
 	void chooseProfile(const std::string& name);
 	// name is the network as the player sees it; joinAs the name `wifictl
 	// join` takes (WifiText::joinName, manualJoinName).
 	void act(WifiText::PressAction action, const std::string& name, const std::string& joinAs);
 	void onManualInput();
 	void onRefresh(bool rescan = true);
 	void join(const std::string& name, const std::string& profile);
 	void checkSecurityAndConnect(const std::string& name);
 	void askKeyAndConnect(const std::string& name);
 	void connect(const std::string& name, const std::string& key, bool openNetwork = false);
 	void joined(const std::string& name);
 
 	MenuComponent mMenu;
+	std::shared_ptr<TextComponent> mStatus;
+	std::shared_ptr<BusyComponent> mBusy;
+	std::shared_ptr<Scan> mScan;
+	std::vector<WifiText::PickerRow> mRows;
 	std::string mTitle;
 	std::function<void()> mOnJoined;
 	std::vector<WifiText::SavedNetwork> mSaved;
 	std::string mCurrent;
 	std::string mCurrentProfile;   // the connected row's profile, for a typed name
 	bool mSavedKnown;
 	bool mWaitingLoad;
 };
diff --git a/es-app/src/guis/WifiScanProcess.h b/es-app/src/guis/WifiScanProcess.h
new file mode 100644
index 000000000..f9b633e09
--- /dev/null
+++ b/es-app/src/guis/WifiScanProcess.h
@@ -0,0 +1,194 @@
+#pragma once
+
+// A bounded, read-only subprocess for the Wi-Fi picker (#577). No shell,
+// GUI, singleton or callback is owned here. Kept separate so a disposable
+// process fixture can exercise the actual runner without linking ES.
+#include <chrono>
+#include <string>
+#include <vector>
+
+#if !WIN32
+#include <cerrno>
+#include <csignal>
+#include <fcntl.h>
+#include <poll.h>
+#include <spawn.h>
+#include <sys/wait.h>
+#include <unistd.h>
+extern char** environ;
+#endif
+
+namespace WifiScanProcess
+{
+struct Answer
+{
+	int code = -1; // spawn/read/signal/timeout/cleanup failure is never empty success
+	std::vector<std::string> lines;
+};
+
+#if !WIN32
+class Child
+{
+public:
+	Child(pid_t child, int output) : pid(child), fd(output) {}
+	Child(const Child&) = delete;
+	Child& operator=(const Child&) = delete;
+	~Child() { finish(); }
+
+	bool finish()
+	{
+		if (finished)
+			return cleaned;
+		finished = true;
+		close(fd);
+		// Even a reaped leader may have descendants holding the pipe. The
+		// spawn creates this group; never signal ES's own process group.
+		cleaned = kill(-pid, SIGKILL) == 0 || errno == ESRCH;
+		if (!cleaned)
+			kill(pid, SIGKILL);
+		const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
+		while (!reaped)
+		{
+			const pid_t waited = waitpid(pid, &status, WNOHANG);
+			if (waited == pid)
+				reaped = true;
+			else if ((waited < 0 && errno != EINTR) || std::chrono::steady_clock::now() >= deadline)
+				return cleaned = false;
+			else
+				poll(nullptr, 0, 10);
+		}
+		return cleaned;
+	}
+
+	pid_t pid;
+	int fd;
+	int status = 0;
+	bool reaped = false;
+private:
+	bool finished = false;
+	bool cleaned = false;
+};
+#endif
+
+inline Answer read(const std::vector<std::string>& command, std::chrono::milliseconds timeout)
+{
+	Answer answer;
+#if !WIN32
+	if (command.empty() || timeout.count() <= 0)
+		return answer;
+	std::vector<char*> argv;
+	for (const auto& part : command)
+		argv.push_back(const_cast<char*>(part.c_str()));
+	argv.push_back(nullptr);
+
+	int output[2];
+	if (pipe2(output, O_CLOEXEC) != 0)
+		return answer;
+	// File actions must not close stdout after dup2 when an inherited
+	// standard descriptor was absent and pipe2 reused its number.
+	for (int& descriptor : output)
+		if (descriptor <= STDERR_FILENO)
+		{
+			const int moved = fcntl(descriptor, F_DUPFD_CLOEXEC, STDERR_FILENO + 1);
+			if (moved == -1)
+			{
+				close(output[0]); close(output[1]);
+				return answer;
+			}
+			close(descriptor);
+			descriptor = moved;
+		}
+	posix_spawn_file_actions_t actions;
+	posix_spawnattr_t attributes;
+	if (posix_spawn_file_actions_init(&actions) != 0)
+	{
+		close(output[0]); close(output[1]);
+		return answer;
+	}
+	if (posix_spawnattr_init(&attributes) != 0)
+	{
+		posix_spawn_file_actions_destroy(&actions);
+		close(output[0]); close(output[1]);
+		return answer;
+	}
+	pid_t pid = -1;
+	const bool configured =
+		posix_spawn_file_actions_adddup2(&actions, output[1], STDOUT_FILENO) == 0 &&
+		posix_spawn_file_actions_addclose(&actions, output[0]) == 0 &&
+		posix_spawn_file_actions_addclose(&actions, output[1]) == 0 &&
+		posix_spawnattr_setflags(&attributes, POSIX_SPAWN_SETPGROUP) == 0 &&
+		posix_spawnattr_setpgroup(&attributes, 0) == 0;
+	const int spawned = configured ? posix_spawnp(&pid, argv[0], &actions, &attributes, argv.data(), environ) : -1;
+	posix_spawnattr_destroy(&attributes);
+	posix_spawn_file_actions_destroy(&actions);
+	close(output[1]);
+	if (spawned != 0)
+	{
+		close(output[0]);
+		return answer;
+	}
+
+	Child child(pid, output[0]);
+	const int flags = fcntl(child.fd, F_GETFL);
+	if (flags == -1 || fcntl(child.fd, F_SETFL, flags | O_NONBLOCK) == -1)
+		return answer;
+	const auto deadline = std::chrono::steady_clock::now() + timeout;
+	std::string outputText;
+	bool eof = false;
+	while (true)
+	{
+		char buffer[4096];
+		while (!eof)
+		{
+			const ssize_t count = ::read(child.fd, buffer, sizeof(buffer));
+			if (count > 0)
+			{
+				// A corrupt/unbounded command must not grow the UI's heap.
+				if (outputText.size() + count > 256 * 1024 || std::chrono::steady_clock::now() >= deadline)
+					return answer;
+				outputText.append(buffer, count);
+			}
+			else if (count == 0)
+				eof = true;
+			else if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
+				break;
+			else
+				return answer;
+		}
+		if (!child.reaped)
+		{
+			const pid_t waited = waitpid(child.pid, &child.status, WNOHANG);
+			if (waited == child.pid)
+				child.reaped = true;
+			else if (waited < 0 && errno != EINTR)
+				return answer;
+		}
+		if (eof && child.reaped)
+			break;
+		if (std::chrono::steady_clock::now() >= deadline)
+			return answer;
+		pollfd descriptor{eof ? -1 : child.fd, POLLIN, 0};
+		if (poll(&descriptor, 1, 25) < 0 && errno != EINTR)
+			return answer;
+	}
+	if (!child.finish() || !WIFEXITED(child.status))
+		return answer;
+	answer.code = WEXITSTATUS(child.status);
+	if (answer.code == 0)
+	{
+		size_t start = 0;
+		while (start < outputText.size())
+		{
+			const size_t end = outputText.find('\n', start);
+			const std::string line = outputText.substr(start, end == std::string::npos ? end : end - start);
+			if (!line.empty())
+				answer.lines.push_back(line);
+			if (end == std::string::npos)
+				break;
+			start = end + 1;
+		}
+	}
+#endif
+	return answer;
+}
+}
diff --git a/es-app/src/scrapers/ScreenScraper.cpp b/es-app/src/scrapers/ScreenScraper.cpp
index 852098a11..61c9865ab 100644
--- a/es-app/src/scrapers/ScreenScraper.cpp
+++ b/es-app/src/scrapers/ScreenScraper.cpp
@@ -21,21 +21,21 @@
 
 // bezel-16-9 
 // bezel-4-3
 
 using namespace PlatformIds;
 
 #if defined(SCREENSCRAPER_DEV_LOGIN) || defined(SCREENSCRAPER_RUNTIME_DEV_LOGIN)
 
-// Upstream compiles the developer pair in. A fork build without one reads it
-// from settings, entered by the player under the scraper's options beside the
-// account it belongs to, so no image carries a key and images can be shared
-// (#64). Callers check for empty and say what is missing rather than letting
-// the API answer with a login error.
+// A compiled developer pair takes precedence. Runtime-only builds read it
+// from settings under SCRAPER > ACCOUNTS (#64); normal distribution builds
+// supply it at build time and hide those developer rows (#566). Callers check
+// for empty and say what is missing rather than letting the API answer with
+// a login error.
 std::string screenScraperDevLogin()
 {
 #if defined(SCREENSCRAPER_DEV_LOGIN)
 	return SCREENSCRAPER_DEV_LOGIN;
 #else
 	const std::string id = Settings::getInstance()->getString("ScreenScraperDevId");
 	const std::string pass = Settings::getInstance()->getString("ScreenScraperDevPass");
 	if (id.empty() || pass.empty())
@@ -966,18 +966,18 @@ ScreenScraperUser ScreenScraperRequest::processUserInfo(const pugi::xml_document
 // What the screen says when ScreenScraper refuses the first request of a
 // scrape (#66). The API answers every failure with a French sentence, and
 // asked with a bad developer pair together with an account it blames the
 // account ("Verifier les identifiants utilisateurs"), while asked with the
 // pair alone it blames the pair ("Verifier vos identifiants developpeur").
 // EmulationStation used to put that body on screen as it came. So: the body
 // goes to the log; a login failure is told apart by one call with the pair
 // alone -- made only after a failure, so a scrape that starts makes no
-// extra request -- and the screen names the credential and the tab it lives
-// under, in English. No code on screen: it is in the log (D-UI-028).
+// extra request -- and the screen gives recovery guidance for this build's
+// credential source. No code on screen: it is in the log (D-UI-028).
 static std::string screenScraperFailureMessage(HttpReq& req, const ScreenScraperRequest::ScreenScraperConfig& config)
 {
 	const int status = req.status();
 	const std::string body = Utils::String::trim(Utils::String::removeHtmlTags(req.getErrorMsg()));
 	LOG(LogError) << "ScreenScraper refused the user-info request: HTTP " << status << ": " << body;
 	const std::string lower = Utils::String::toLower(body);
 
 	// No answer at all -- no route, no DNS, a timeout, a cut link: curl got
@@ -1038,17 +1038,23 @@ static std::string screenScraperFailureMessage(HttpReq& req, const ScreenScraper
 	enum { PairAccepted, PairRejected, PairUnknown } pair = PairUnknown;
 	if (probe.status() == HttpReq::REQ_SUCCESS)
 		pair = Utils::String::trim(probe.getContent()).find("<?xml") == 0 ? PairAccepted : PairRejected;
 	LOG(LogInfo) << "ScreenScraper developer pair alone: HTTP " << probe.status()
 		<< (pair == PairAccepted ? ", accepted" : pair == PairRejected ? ", rejected" : ", no usable answer");
 	if (pair == PairUnknown)
 		return _("COULDN'T REACH SCREENSCRAPER. TRY AGAIN.");
 	if (pair == PairRejected)
+	{
+#if defined(SCREENSCRAPER_DEV_LOGIN)
+		return _("SCREENSCRAPER REJECTED THIS SYSTEM'S ACCESS.\nCHECK FOR A SYSTEM UPDATE OR REPORT THE PROBLEM.");
+#else
 		return _("SCREENSCRAPER REJECTED THE DEVELOPER ID OR PASSWORD.\nCHECK THEM UNDER SCRAPER > ACCOUNTS.");
+#endif
+	}
 
 	// The pair is fine and the API still refused: it needs an account on
 	// this request and on every game request, so with none configured the
 	// account is what is missing. Say that, rather than that a password
 	// they never typed was rejected.
 	if (Settings::getInstance()->getString("ScreenScraperUser").empty() || Settings::getInstance()->getString("ScreenScraperPass").empty())
 		return _("SCREENSCRAPER NEEDS YOUR ACCOUNT TO SCRAPE.\nADD IT UNDER SCRAPER > ACCOUNTS.");
 	return _("SCREENSCRAPER REJECTED YOUR USERNAME OR PASSWORD.\nCHECK THEM UNDER SCRAPER > ACCOUNTS.");
diff --git a/es-core/src/Settings.cpp b/es-core/src/Settings.cpp
index b890f548a..425358c05 100644
--- a/es-core/src/Settings.cpp
+++ b/es-core/src/Settings.cpp
@@ -313,17 +313,17 @@ void Settings::setDefaults()
 	mBoolMap["VideoLowersMusic"] = true;
 	mBoolMap["VolumePopup"] = Settings::_VolumePopup;
 	mBoolMap["RightStickVolume"] = true;
 
 	mIntMap["MusicVolume"] = 128;
 
 	// Audio out device for Video playback using OMX player.
 	mStringMap["OMXAudioDev"] = "both";
-	mStringMap["CollectionSystemsAuto"] = "favorites, recent"; // 2players,4players,favorites,recent
+	mStringMap["CollectionSystemsAuto"] = "favorites,recent"; // 2players,4players,favorites,recent
 	mStringMap["CollectionSystemsCustom"] = "";
 	mBoolMap["SortAllSystems"] = true; 
 	mStringMap["SortSystems"] = "manufacturer";
 	
 	mStringMap["UseCustomCollectionsSystemEx"] = "";
 	
 	mBoolMap["HiddenSystemsShowGames"] = false;
 	mBoolMap["CollectionShowSystemInfo"] = true;
diff --git a/external/libcheevos/CMakeLists.txt b/external/libcheevos/CMakeLists.txt
index 39574ad05..952b33efc 100644
--- a/external/libcheevos/CMakeLists.txt
+++ b/external/libcheevos/CMakeLists.txt
@@ -221,8 +221,25 @@ if(NOT DEFINED MSVC)
 	add_definitions("-DHAVE_LROUND")
 endif()
 
 include_directories(${COMMON_INCLUDE_DIRS} ${CMAKE_CURRENT_SOURCE_DIR}/rcheevos/include)
 include_directories(${COMMON_INCLUDE_DIRS} ${CMAKE_CURRENT_SOURCE_DIR}/libretro-common/include)
 include_directories(${COMMON_INCLUDE_DIRS} ${CMAKE_CURRENT_SOURCE_DIR}/libretro-common/src/7zip)
 
 add_library(libcheevos STATIC ${CHEEVOS_SOURCES} ${CHEEVOS_HEADERS} ${LIBRETRO_COMMON_HEADERS} ${LIBRETRO_COMMON_SOURCES})
+
+# The distro enables this bounded GameCube reader; other builds may opt in.
+# No global file-reader override, extracted ISO, or emulator invocation.
+option(ENABLE_RVZ_HASH "Hash supported GameCube RVZ files" ${ROCKNIX})
+if(ENABLE_RVZ_HASH)
+    find_path(LIBCHEEVOS_ZSTD_INCLUDE_DIR zstd.h)
+    find_library(LIBCHEEVOS_ZSTD_LIBRARY NAMES zstd libzstd)
+    find_path(LIBCHEEVOS_SHA1_INCLUDE_DIR boost/uuid/detail/sha1.hpp
+        HINTS ${Boost_INCLUDE_DIRS} ${COMMON_INCLUDE_DIRS})
+    if(NOT LIBCHEEVOS_ZSTD_INCLUDE_DIR OR NOT LIBCHEEVOS_ZSTD_LIBRARY OR NOT LIBCHEEVOS_SHA1_INCLUDE_DIR)
+        message(FATAL_ERROR "ENABLE_RVZ_HASH requires target Zstandard and Boost SHA-1 headers")
+    endif()
+    target_sources(libcheevos PRIVATE rvz_hash.cpp rvz_hash.h)
+    target_compile_definitions(libcheevos PRIVATE HAVE_RVZ_HASH)
+    target_include_directories(libcheevos PRIVATE ${LIBCHEEVOS_ZSTD_INCLUDE_DIR} ${LIBCHEEVOS_SHA1_INCLUDE_DIR})
+    target_link_libraries(libcheevos PUBLIC ${LIBCHEEVOS_ZSTD_LIBRARY})
+endif()
diff --git a/external/libcheevos/LICENSE.rvz-padding b/external/libcheevos/LICENSE.rvz-padding
new file mode 100644
index 000000000..5a19a8fc6
--- /dev/null
+++ b/external/libcheevos/LICENSE.rvz-padding
@@ -0,0 +1,29 @@
+BSD 3-Clause License
+
+Copyright (c) 2020, Matt Dainty
+All rights reserved.
+
+Redistribution and use in source and binary forms, with or without
+modification, are permitted provided that the following conditions are met:
+
+* Redistributions of source code must retain the above copyright notice, this
+  list of conditions and the following disclaimer.
+
+* Redistributions in binary form must reproduce the above copyright notice,
+  this list of conditions and the following disclaimer in the documentation
+  and/or other materials provided with the distribution.
+
+* Neither the name of the copyright holder nor the names of its
+  contributors may be used to endorse or promote products derived from
+  this software without specific prior written permission.
+
+THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
+AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
+IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
+DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
+FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
+DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
+SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
+CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
+OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
+OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
diff --git a/external/libcheevos/RVZ-NOTICES.md b/external/libcheevos/RVZ-NOTICES.md
new file mode 100644
index 000000000..5c7c58960
--- /dev/null
+++ b/external/libcheevos/RVZ-NOTICES.md
@@ -0,0 +1,29 @@
+# GameCube RVZ hash reader
+
+`rvz_hash.cpp` and `rvz_hash.h` are original pixelelated integration code under
+MIT, except the padding recurrence/serialization adapted under BSD-3-Clause
+from bodgit/rvz `internal/padding/reader.go` at
+`bc439051cbedab7fe22a0c73bd2e7f19a310645e`
+(<https://github.com/bodgit/rvz/blob/bc439051cbedab7fe22a0c73bd2e7f19a310645e/internal/padding/reader.go>). Preserve `LICENSE.rvz-padding`.
+The ES root `LICENSE.md` carries the MIT permission notice.
+
+The exact sources, limits, dependencies, and unrun qualification controls are
+recorded in distribution issue #574 and
+`docs/qa-logs/2026-10-13-rvz-source/`. No RetroArch GPL reader is imported.
+Dolphin's published `docs/WiaAndRvz.md` describes the container format.
+Boost SHA-1 uses the existing BSL-1.0 headers; Zstandard uses BSD-3-Clause
+(the permissive option of its dual license). They are not copied here.
+
+Scope: GameCube RVZ v0.3 through v1.0, NONE or Zstandard, 32 KiB through 2 MiB
+power-of-two chunks, raw data and RVZ packing, including lossless padding.
+Wii/WIA, BZIP2/LZMA/LZMA2, larger chunks, incomplete/gapped raw mappings,
+and inputs outside the explicit reader limits fail. Limits also include 4096
+raw entries, 65536 groups, 4096 packed records per chunk, 2 GiB virtual disc,
+4 GiB container, 128 MiB bytes read per hash, and 512 MiB decoded work per
+reader. These are rejection bounds, not a measured memory or timing claim. This is a bounded
+frontend reader candidate, not a disc verifier or in-game achievement engine.
+
+Build with `ENABLE_RVZ_HASH=ON` and target Boost/Zstandard headers and libzstd.
+It defaults on for ROCKNIX. The distribution must declare the direct zstd
+build/runtime dependency when integrating. Other builds can opt in; missing
+requested dependencies fail configuration rather than silently disable it.
diff --git a/external/libcheevos/cheevos.cpp b/external/libcheevos/cheevos.cpp
index 554504b88..e21bea792 100644
--- a/external/libcheevos/cheevos.cpp
+++ b/external/libcheevos/cheevos.cpp
@@ -1,9 +1,12 @@
 #include "cheevos.h"
+#ifdef HAVE_RVZ_HASH
+#include "rvz_hash.h"
+#endif
 #include "rcheevos/include/rc_hash.h"
 #include "rcheevos/include/rc_consoles.h"
 #include "libretro-common/include/formats/cdfs.h"
 #include "libretro-common/include/string/stdstring.h"
 #include "libretro-common/include/file/file_path.h"
 #include "libretro.h"
 
 #include <cstdlib>
@@ -148,18 +151,31 @@ static void* rc_hash_handle_cd_open_track(
     {
         /* not a CHD file, use the default handlers */
         struct rc_hash_cdreader cdreader;
         rc_hash_get_default_cdreader(&cdreader);
         return cdreader.open_track_iterator(path, track, iterator);
     }
 }
 
+bool gameCubeRvzHashEnabled()
+{
+#ifdef HAVE_RVZ_HASH
+    return true;
+#else
+    return false;
+#endif
+}
+
 bool generateHashFromFile(char hash[33], int console_id, const char* path)
 {
+#ifdef HAVE_RVZ_HASH
+    if (console_id == RC_CONSOLE_GAMECUBE && string_is_equal_noncase(path_get_extension(path), "rvz"))
+        return generateGameCubeRvzHash(hash, path);
+#endif
 	try
 	{
 		if (!readersinit)
 		{
             struct rc_hash_cdreader cdreader;
             rc_hash_get_default_cdreader(&cdreader);
             cdreader.open_track_iterator = rc_hash_handle_cd_open_track;
             rc_hash_init_custom_cdreader(&cdreader);
diff --git a/external/libcheevos/cheevos.h b/external/libcheevos/cheevos.h
index a18ccb71a..ca6f3785c 100644
--- a/external/libcheevos/cheevos.h
+++ b/external/libcheevos/cheevos.h
@@ -1,5 +1,8 @@
 #pragma once
 
 #include "rcheevos/include/rc_consoles.h"
 
 bool generateHashFromFile(char hash[33], int console_id, const char* path);
+
+// Build capability only: individual RVZ modes/inputs may still be rejected.
+bool gameCubeRvzHashEnabled();
diff --git a/external/libcheevos/libretro-common/src/utils/md5.c b/external/libcheevos/libretro-common/src/utils/md5.c
index 5deb03ce5..132486f06 100644
--- a/external/libcheevos/libretro-common/src/utils/md5.c
+++ b/external/libcheevos/libretro-common/src/utils/md5.c
@@ -63,18 +63,27 @@
  * MD5_SET reads 4 input bytes in little-endian byte order and stores them
  * in a properly aligned word in host byte order.
  *
  * The check for little-endian architectures that tolerate unaligned
  * memory accesses is just an optimization.  Nothing will break if it
  * doesn't work.
  */
 #if defined(__i386__) || defined(__x86_64__) || defined(__vax__)
+/* These hosts are little-endian, but input need not satisfy C alignment or
+ * effective-type requirements. memcpy preserves the unaligned fast path
+ * without dereferencing an incompatible or misaligned word pointer. */
+static MD5_u32plus MD5_load_word(const unsigned char *input)
+{
+	MD5_u32plus word;
+	memcpy(&word, input, sizeof(word));
+	return word;
+}
 #define MD5_SET(n) \
-	(*(MD5_u32plus *)&ptr[(n) * 4])
+	MD5_load_word(&ptr[(n) * 4])
 #define MD5_GET(n) \
 	MD5_SET(n)
 #else
 #define MD5_SET(n) \
 	(ctx->block[(n)] = \
 	(MD5_u32plus)ptr[(n) * 4] | \
 	((MD5_u32plus)ptr[(n) * 4 + 1] << 8) | \
 	((MD5_u32plus)ptr[(n) * 4 + 2] << 16) | \
diff --git a/external/libcheevos/rcheevos/src/rhash/hash_disc.c b/external/libcheevos/rcheevos/src/rhash/hash_disc.c
index 83c93545e..e74ac4208 100644
--- a/external/libcheevos/rcheevos/src/rhash/hash_disc.c
+++ b/external/libcheevos/rcheevos/src/rhash/hash_disc.c
@@ -420,93 +420,104 @@ static int rc_hash_nintendo_disc_partition(md5_state_t* md5, const rc_hash_itera
 
   uint32_t apploader_header_size, apploader_body_size, apploader_trailer_size, header_size;
 
   uint8_t quad_buffer[4];
   uint8_t addr_buffer[0xD8];
   uint8_t* buffer;
 
   uint64_t dol_offset;
+  uint64_t full_header_size;
   uint64_t dol_offsets[18];
   uint64_t dol_sizes[18];
 
   uint8_t ix;
   uint64_t remaining_size;
   const uint32_t MAX_CHUNK_SIZE = 1024 * 1024;
 
   /* GetApploaderSize */
   rc_file_seek(iterator, file_handle, part_offset + BASE_HEADER_SIZE + 0x14, SEEK_SET);
   apploader_header_size = 0x20;
-  rc_file_read(iterator, file_handle, quad_buffer, 4);
+  if (rc_file_read(iterator, file_handle, quad_buffer, 4) != 4)
+    return rc_hash_iterator_error(iterator, "Truncated Nintendo disc header");
   apploader_body_size =
-    (quad_buffer[0] << 24) | (quad_buffer[1] << 16) | (quad_buffer[2] << 8) | quad_buffer[3];
-  rc_file_read(iterator, file_handle, quad_buffer, 4);
+    ((uint32_t)quad_buffer[0] << 24) | (quad_buffer[1] << 16) | (quad_buffer[2] << 8) | quad_buffer[3];
+  if (rc_file_read(iterator, file_handle, quad_buffer, 4) != 4)
+    return rc_hash_iterator_error(iterator, "Truncated Nintendo disc header");
   apploader_trailer_size =
-    (quad_buffer[0] << 24) | (quad_buffer[1] << 16) | (quad_buffer[2] << 8) | quad_buffer[3];
-  header_size = BASE_HEADER_SIZE + apploader_header_size + apploader_body_size + apploader_trailer_size;
-  if (header_size > MAX_HEADER_SIZE) header_size = MAX_HEADER_SIZE;
+    ((uint32_t)quad_buffer[0] << 24) | (quad_buffer[1] << 16) | (quad_buffer[2] << 8) | quad_buffer[3];
+  full_header_size = (uint64_t)BASE_HEADER_SIZE + apploader_header_size + apploader_body_size + apploader_trailer_size;
+  header_size = (full_header_size > MAX_HEADER_SIZE) ? MAX_HEADER_SIZE : (uint32_t)full_header_size;
 
   /* Hash headers */
   buffer = (uint8_t*)malloc(header_size);
   if (!buffer) {
-    rc_file_close(iterator, file_handle);
     return rc_hash_iterator_error(iterator, "Could not allocate temporary buffer");
   }
   rc_file_seek(iterator, file_handle, part_offset, SEEK_SET);
-  rc_file_read(iterator, file_handle, buffer, header_size);
+  if (rc_file_read(iterator, file_handle, buffer, header_size) != header_size) {
+    free(buffer);
+    return rc_hash_iterator_error(iterator, "Truncated Nintendo disc header");
+  }
   rc_hash_iterator_verbose_formatted(iterator, "Hashing %u byte partition header", header_size);
   md5_append(md5, buffer, header_size);
 
   /* GetBootDOLOffset
    * Base header size is guaranteed larger than 0x423 therefore buffer contains dol_offset right now
    */
   dol_offset = (((uint64_t)buffer[0x420] << 24) |
     ((uint64_t)buffer[0x421] << 16) |
     ((uint64_t)buffer[0x422] << 8) |
     (uint64_t)buffer[0x423]) << wii_shift;
   free(buffer);
 
   /* Find offsets and sizes for the 7 main.dol code segments and 11 main.dol data segments */
   rc_file_seek(iterator, file_handle, part_offset + dol_offset, SEEK_SET);
-  rc_file_read(iterator, file_handle, addr_buffer, 0xD8);
+  if (rc_file_read(iterator, file_handle, addr_buffer, sizeof(addr_buffer)) != sizeof(addr_buffer))
+    return rc_hash_iterator_error(iterator, "Truncated Nintendo disc executable table");
   for (ix = 0; ix < 18; ix++) {
     dol_offsets[ix] = (((uint64_t)addr_buffer[0x0 + ix * 4] << 24) |
       ((uint64_t)addr_buffer[0x1 + ix * 4] << 16) |
       ((uint64_t)addr_buffer[0x2 + ix * 4] << 8) |
       (uint64_t)addr_buffer[0x3 + ix * 4]) << wii_shift;
     dol_sizes[ix] = (((uint64_t)addr_buffer[0x90 + ix * 4] << 24) |
       ((uint64_t)addr_buffer[0x91 + ix * 4] << 16) |
       ((uint64_t)addr_buffer[0x92 + ix * 4] << 8) |
       (uint64_t)addr_buffer[0x93 + ix * 4]) << wii_shift;
   }
 
   /* Iterate through the 18 main.dol segments and hash each */
   buffer = (uint8_t*)malloc(MAX_CHUNK_SIZE);
   if (!buffer) {
-    rc_file_close(iterator, file_handle);
     return rc_hash_iterator_error(iterator, "Could not allocate temporary buffer");
   }
 
   for (ix = 0; ix < 18; ix++) {
     if (dol_sizes[ix] == 0)
       continue;
 
     rc_file_seek(iterator, file_handle, part_offset + dol_offsets[ix], SEEK_SET);
     if (ix < 7)
       rc_hash_iterator_verbose_formatted(iterator, "Hashing %u byte main.dol code segment %u", dol_sizes[ix], ix);
     else
       rc_hash_iterator_verbose_formatted(iterator, "Hashing %u byte main.dol data segment %u", dol_sizes[ix], ix - 7);
 
     remaining_size = dol_sizes[ix];
     while (remaining_size > MAX_CHUNK_SIZE) {
-      rc_file_read(iterator, file_handle, buffer, MAX_CHUNK_SIZE);
+      if (rc_file_read(iterator, file_handle, buffer, MAX_CHUNK_SIZE) != MAX_CHUNK_SIZE) {
+        free(buffer);
+        return rc_hash_iterator_error(iterator, "Truncated Nintendo disc executable");
+      }
       md5_append(md5, buffer, MAX_CHUNK_SIZE);
       remaining_size -= MAX_CHUNK_SIZE;
     }
-    rc_file_read(iterator, file_handle, buffer, (int32_t)remaining_size);
+    if (rc_file_read(iterator, file_handle, buffer, (size_t)remaining_size) != remaining_size) {
+      free(buffer);
+      return rc_hash_iterator_error(iterator, "Truncated Nintendo disc executable");
+    }
     md5_append(md5, buffer, (int32_t)remaining_size);
   }
 
   free(buffer);
   return 1;
 }
 
 int rc_hash_gamecube(char hash[33], const rc_hash_iterator_t* iterator)
@@ -519,18 +530,19 @@ int rc_hash_gamecube(char hash[33], const rc_hash_iterator_t* iterator)
 
   file_handle = rc_file_open(iterator, iterator->path);
   if (!file_handle)
     return rc_hash_iterator_error(iterator, "Could not open file");
 
   md5_init(&md5);
   /* Check Magic Word */
   rc_file_seek(iterator, file_handle, 0x1c, SEEK_SET);
-  rc_file_read(iterator, file_handle, quad_buffer, 4);
-  if (quad_buffer[0] == 0xC2 && quad_buffer[1] == 0x33 && quad_buffer[2] == 0x9F && quad_buffer[3] == 0x3D)
+  if (rc_file_read(iterator, file_handle, quad_buffer, 4) != 4)
+    success = rc_hash_iterator_error(iterator, "Truncated GameCube disc magic");
+  else if (quad_buffer[0] == 0xC2 && quad_buffer[1] == 0x33 && quad_buffer[2] == 0x9F && quad_buffer[3] == 0x3D)
     success = rc_hash_nintendo_disc_partition(&md5, iterator, file_handle, 0, 0);
   else
     success = rc_hash_iterator_error(iterator, "Not a Gamecube disc");
 
   /* Finalize */
   rc_file_close(iterator, file_handle);
 
   if (success)
diff --git a/external/libcheevos/rvz_hash.cpp b/external/libcheevos/rvz_hash.cpp
new file mode 100644
index 000000000..b1cc767e5
--- /dev/null
+++ b/external/libcheevos/rvz_hash.cpp
@@ -0,0 +1,389 @@
+// SPDX-License-Identifier: MIT AND BSD-3-Clause
+// Copyright (c) 2026 pixelelated contributors
+// Padding recurrence/serialization adapted from bodgit/rvz (BSD-3-Clause).
+// See RVZ-NOTICES.md and LICENSE.rvz-padding. Container code follows Dolphin's
+// published WiaAndRvz format; no RetroArch or Dolphin implementation is copied.
+#include "rvz_hash.h"
+#include "rcheevos/include/rc_hash.h"
+#include "libretro-common/include/streams/interface_stream.h"
+#include "libretro-common/include/libretro.h"
+#include <boost/uuid/detail/sha1.hpp>
+#include <zstd.h>
+#include <algorithm>
+#include <array>
+#include <cstdint>
+#include <cstdlib>
+#include <cstring>
+#include <memory>
+#include <stdexcept>
+#include <vector>
+#include <utility>
+
+namespace
+{
+constexpr uint64_t Sector = 0x8000;
+constexpr uint32_t MaxChunk = 2 * 1024 * 1024;
+constexpr uint32_t MaxWork = MaxChunk + 1024 * 1024;
+constexpr uint64_t MaxDisc = uint64_t(2) * 1024 * 1024 * 1024;
+constexpr uint64_t MaxFile = uint64_t(4) * 1024 * 1024 * 1024;
+constexpr uint32_t MaxGroups = 65536;
+constexpr uint32_t MaxRaw = 4096;
+using Bytes = std::vector<uint8_t>;
+
+void require(bool condition)
+{
+    if (!condition)
+        throw std::runtime_error("Invalid or unsupported GameCube RVZ");
+}
+uint32_t be32(const uint8_t* p)
+{
+    return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) |
+        (uint32_t(p[2]) << 8) | p[3];
+}
+uint64_t be64(const uint8_t* p)
+{
+    return (uint64_t(be32(p)) << 32) | be32(p + 4);
+}
+bool sha1Matches(const uint8_t* data, size_t size, const uint8_t* expected)
+{
+    boost::uuids::detail::sha1 state;
+    boost::uuids::detail::sha1::digest_type digest;
+    state.process_bytes(data, size);
+    state.get_digest(digest);
+    // Boost changed digest_type from host words to bytes. Accept both APIs.
+    for (size_t i = 0; i < 20; ++i)
+    {
+        const auto byte = sizeof(digest[0]) == 1 ? digest[i] :
+            ((digest[i / 4] >> (24 - 8 * (i % 4))) & 0xff);
+        if (byte != expected[i])
+            return false;
+    }
+    return true;
+}
+
+// BSD-3-Clause adaptation of bodgit/rvz/internal/padding/reader.go.
+// State is local, and output uses explicit bytes on both endian families.
+void padding(const uint8_t* seed, uint64_t offset, uint8_t* out, size_t size)
+{
+    std::array<uint32_t, 521> words{};
+    for (size_t i = 0; i < 17; ++i)
+        words[i] = be32(seed + 4 * i);
+    for (size_t i = 17; i < words.size(); ++i)
+        words[i] = (words[i - 17] << 23) ^ (words[i - 16] >> 9) ^ words[i - 1];
+    const auto advance = [&]() {
+        for (size_t i = 0; i < 32; ++i)
+            words[i] ^= words[i + words.size() - 32];
+        for (size_t i = 32; i < words.size(); ++i)
+            words[i] ^= words[i - 32];
+    };
+    for (unsigned i = 0; i < 4; ++i)
+        advance();
+    size_t byteIndex = static_cast<size_t>(offset % Sector);
+    while (byteIndex >= words.size() * 4)
+    {
+        advance();
+        byteIndex -= words.size() * 4;
+    }
+    const unsigned shifts[] = {24, 18, 8, 0};
+    for (size_t i = 0; i < size; ++i)
+    {
+        if (byteIndex == words.size() * 4)
+        {
+            advance();
+            byteIndex = 0;
+        }
+        out[i] = static_cast<uint8_t>(words[byteIndex / 4] >> shifts[byteIndex % 4]);
+        ++byteIndex;
+    }
+}
+
+Bytes unpack(const Bytes& packed, size_t expected, uint64_t discOffset)
+{
+    Bytes result(expected);
+    size_t input = 0, output = 0, records = 0;
+    while (input < packed.size())
+    {
+        require(++records <= 4096 && packed.size() - input >= 4);
+        const uint32_t tag = be32(packed.data() + input);
+        input += 4;
+        const uint32_t length = tag & 0x7fffffff;
+        require(length <= result.size() - output);
+        if (tag & 0x80000000)
+        {
+            require(packed.size() - input >= 68);
+            if (length)
+                padding(packed.data() + input, discOffset + output, result.data() + output, length);
+            input += 68;
+        }
+        else
+        {
+            require(length <= packed.size() - input);
+            if (length)
+                std::memcpy(result.data() + output, packed.data() + input, length);
+            input += length;
+        }
+        output += length;
+    }
+    require(output == expected);
+    return result;
+}
+
+struct StreamCloser
+{
+    void operator()(intfstream_t* stream) const
+    {
+        if (stream)
+        {
+            intfstream_close(stream);
+            std::free(stream);
+        }
+    }
+};
+struct Raw
+{
+    uint64_t offset, end, aligned;
+    uint32_t first, count;
+};
+struct Group
+{
+    uint64_t offset;
+    uint32_t size, packed;
+    bool compressed;
+};
+class Reader
+{
+public:
+    explicit Reader(const char* path) : stream(intfstream_open_file(path,
+        RETRO_VFS_FILE_ACCESS_READ, RETRO_VFS_FILE_ACCESS_HINT_NONE))
+    {
+        require(stream != nullptr);
+        const int64_t size = intfstream_get_size(stream.get());
+        require(size >= 0x48 + 0xd5 && uint64_t(size) <= MaxFile);
+        fileSize = static_cast<uint64_t>(size);
+        const Bytes header = physical(0, 0x48);
+        require(be32(header.data()) == 0x52565a01);
+        const uint32_t version = be32(header.data() + 4);
+        const uint32_t compatible = be32(header.data() + 8);
+        require(version >= 0x00030000 && version <= 0x01000000 &&
+            compatible >= 0x00030000 && compatible <= version);
+        require(sha1Matches(header.data(), 0x34, header.data() + 0x34));
+        discSize = be64(header.data() + 0x24);
+        require(discSize >= 0x2460 && discSize <= MaxDisc &&
+            be64(header.data() + 0x2c) == fileSize);
+        const uint32_t secondSize = be32(header.data() + 0xc);
+        require(secondSize >= 0xd5 && secondSize <= 4096);
+        const Bytes second = physical(0x48, secondSize);
+        require(sha1Matches(second.data(), second.size(), header.data() + 0x10));
+        require(be32(second.data()) == 1 && be32(second.data() + 0x90) == 0);
+        compression = be32(second.data() + 4);
+        require((compression == 0 || compression == 5) && second[0xd4] == 0);
+        chunk = be32(second.data() + 0xc);
+        require(chunk >= Sector && chunk <= MaxChunk && (chunk & (chunk - 1)) == 0);
+        std::copy_n(second.data() + 0x10, head.size(), head.begin());
+        require(be32(head.data() + 0x1c) == 0xc2339f3d);
+        const uint32_t rawCount = be32(second.data() + 0xb4);
+        const uint32_t groupCount = be32(second.data() + 0xc4);
+        require(rawCount && rawCount <= MaxRaw && groupCount && groupCount <= MaxGroups);
+        Bytes table = decode(be64(second.data() + 0xc8), be32(second.data() + 0xd0),
+            groupCount * 12, compression == 5);
+        groups.reserve(groupCount);
+        for (uint32_t i = 0; i < groupCount; ++i)
+        {
+            const uint8_t* p = table.data() + size_t(i) * 12;
+            const uint32_t flags = be32(p + 4);
+            Group group{uint64_t(be32(p)) * 4, flags & 0x7fffffff, be32(p + 8),
+                (flags & 0x80000000) != 0};
+            require(group.size <= MaxWork && group.packed <= MaxWork);
+            require(group.offset <= fileSize && group.size <= fileSize - group.offset);
+            groups.push_back(group);
+        }
+        table = decode(be64(second.data() + 0xb8), be32(second.data() + 0xc0),
+            rawCount * 24, compression == 5);
+        raw.reserve(rawCount);
+        for (uint32_t i = 0; i < rawCount; ++i)
+        {
+            const uint8_t* p = table.data() + size_t(i) * 24;
+            const uint64_t offset = be64(p), length = be64(p + 8);
+            require(offset < discSize && length && length <= discSize - offset);
+            Raw entry{offset, offset + length, offset - offset % Sector,
+                be32(p + 16), be32(p + 20)};
+            require(entry.first < groups.size() && entry.count <= groups.size() - entry.first);
+            require(entry.count == (entry.end - entry.aligned + chunk - 1) / chunk);
+            raw.push_back(entry);
+        }
+        std::sort(raw.begin(), raw.end(), [](const Raw& a, const Raw& b) { return a.offset < b.offset; });
+        uint64_t end = raw.front().offset;
+        require(end == 0 || end == head.size());
+        for (const Raw& entry : raw)
+        {
+            require(entry.offset == end);
+            end = entry.end;
+        }
+        require(end == discSize);
+    }
+
+    void seek(int64_t offset, int origin)
+    {
+        uint64_t base;
+        if (origin == SEEK_SET) base = 0;
+        else if (origin == SEEK_CUR) base = position;
+        else if (origin == SEEK_END) base = discSize;
+        else { failed = true; return; }
+        if (offset < 0)
+        {
+            if (offset < -static_cast<int64_t>(base)) { failed = true; return; }
+            position = base - static_cast<uint64_t>(-offset);
+        }
+        else
+        {
+            if (static_cast<uint64_t>(offset) > discSize - base) { failed = true; return; }
+            position = base + static_cast<uint64_t>(offset);
+        }
+    }
+    int64_t tell() const { return static_cast<int64_t>(position); }
+    size_t read(void* destination, size_t requested)
+    {
+        if (failed || requested > discSize - position || requested > 128 * 1024 * 1024 - totalRead)
+        {
+            failed = true;
+            return 0;
+        }
+        totalRead += requested;
+        auto* out = static_cast<uint8_t*>(destination);
+        size_t done = 0;
+        while (done < requested)
+        {
+            if (position < head.size())
+            {
+                const size_t take = std::min(requested - done, head.size() - size_t(position));
+                std::memcpy(out + done, head.data() + position, take);
+                position += take;
+                done += take;
+                continue;
+            }
+            const auto found = std::upper_bound(raw.begin(), raw.end(), position,
+                [](uint64_t value, const Raw& entry) { return value < entry.offset; });
+            require(found != raw.begin());
+            const Raw& entry = *(found - 1);
+            require(position < entry.end);
+            const uint64_t groupBase = entry.aligned + (position - entry.aligned) / chunk * chunk;
+            const uint32_t index = entry.first + uint32_t((position - entry.aligned) / chunk);
+            const size_t length = static_cast<size_t>(std::min(uint64_t(chunk), entry.end - groupBase));
+            if (cachedIndex != index || cachedBase != groupBase || cache.size() != length)
+            {
+                const Group& group = groups[index];
+                Bytes decoded;
+                if (!group.size)
+                {
+                    accountDecoded(length);
+                    decoded.assign(length, 0);
+                }
+                else
+                {
+                    decoded = decode(group.offset, group.size,
+                        group.packed ? group.packed : length, group.compressed && compression == 5);
+                    if (group.packed)
+                    {
+                        accountDecoded(length);
+                        decoded = unpack(decoded, length, groupBase);
+                    }
+                }
+                cache = std::move(decoded);
+                cachedIndex = index;
+                cachedBase = groupBase;
+            }
+            const size_t into = static_cast<size_t>(position - groupBase);
+            const size_t take = std::min(requested - done, cache.size() - into);
+            require(take != 0);
+            std::memcpy(out + done, cache.data() + into, take);
+            done += take;
+            position += take;
+        }
+        return done;
+    }
+    bool failed = false;
+
+private:
+    Bytes physical(uint64_t offset, size_t bytes)
+    {
+        require(bytes <= MaxWork && offset <= fileSize && bytes <= fileSize - offset);
+        require(intfstream_seek(stream.get(), static_cast<int64_t>(offset), SEEK_SET) >= 0);
+        Bytes result(bytes);
+        require(intfstream_read(stream.get(), result.data(), bytes) == static_cast<int64_t>(bytes));
+        return result;
+    }
+    void accountDecoded(size_t bytes)
+    {
+        require(bytes <= MaxWork && bytes <= 512 * 1024 * 1024 - totalDecoded);
+        totalDecoded += bytes;
+    }
+    Bytes decode(uint64_t offset, uint32_t bytes, size_t expected, bool compressed)
+    {
+        accountDecoded(expected);
+        Bytes input = physical(offset, bytes);
+        if (!compressed)
+        {
+            require(input.size() == expected);
+            return input;
+        }
+        require(!input.empty());
+        const size_t frameSize = ZSTD_findFrameCompressedSize(input.data(), input.size());
+        require(!ZSTD_isError(frameSize) && frameSize == input.size());
+        Bytes output(expected);
+        const size_t actual = ZSTD_decompress(output.data(), output.size(), input.data(), input.size());
+        require(!ZSTD_isError(actual) && actual == expected);
+        return output;
+    }
+    std::unique_ptr<intfstream_t, StreamCloser> stream;
+    uint64_t fileSize = 0, discSize = 0, position = 0;
+    uint32_t chunk = 0, compression = 0;
+    std::array<uint8_t, 128> head{};
+    std::vector<Raw> raw;
+    std::vector<Group> groups;
+    Bytes cache;
+    uint32_t cachedIndex = UINT32_MAX;
+    uint64_t cachedBase = 0;
+    size_t totalRead = 0, totalDecoded = 0;
+};
+
+void* openRvz(const char* path)
+{
+    try { return new Reader(path); }
+    catch (...) { return nullptr; }
+}
+void closeRvz(void* opaque) { delete static_cast<Reader*>(opaque); }
+void seekRvz(void* opaque, int64_t offset, int origin)
+{
+    static_cast<Reader*>(opaque)->seek(offset, origin);
+}
+int64_t tellRvz(void* opaque) { return static_cast<Reader*>(opaque)->tell(); }
+size_t readRvz(void* opaque, void* data, size_t bytes)
+{
+    Reader& reader = *static_cast<Reader*>(opaque);
+    try { return reader.read(data, bytes); }
+    catch (...) { reader.failed = true; return 0; }
+}
+struct Iterator
+{
+    explicit Iterator(const char* path) { rc_hash_initialize_iterator(&value, path, nullptr, 0); }
+    ~Iterator() { rc_hash_destroy_iterator(&value); }
+    rc_hash_iterator_t value;
+};
+} // namespace
+
+bool generateGameCubeRvzHash(char hash[33], const char* path)
+{
+    hash[0] = '\0';
+    try
+    {
+        Iterator iterator(path);
+        if (!iterator.value.path)
+            return false;
+        iterator.value.callbacks.filereader = {openRvz, seekRvz, tellRvz, readRvz, closeRvz};
+        if (rc_hash_generate(hash, RC_CONSOLE_GAMECUBE, &iterator.value))
+            return true;
+    }
+    catch (...) {}
+    hash[0] = '\0';
+    return false;
+}
diff --git a/external/libcheevos/rvz_hash.h b/external/libcheevos/rvz_hash.h
new file mode 100644
index 000000000..7e83249c6
--- /dev/null
+++ b/external/libcheevos/rvz_hash.h
@@ -0,0 +1,7 @@
+// SPDX-License-Identifier: MIT
+// Copyright (c) 2026 pixelelated contributors
+#pragma once
+
+// GameCube RVZ only; unsupported or malformed data returns false.
+// No global rcheevos callback changes and no temporary extracted image.
+bool generateGameCubeRvzHash(char hash[33], const char* path);
diff --git a/locale/emulationstation2.pot b/locale/emulationstation2.pot
index 59a51f460..c7fce51c3 100644
--- a/locale/emulationstation2.pot
+++ b/locale/emulationstation2.pot
@@ -4025,8 +4025,12 @@ msgstr ""
 
 #. cloud folder path refusal (#524 PL-003)
 msgid "YOUR CLOUD SETTINGS COULDN'T BE SAVED. TRY AGAIN."
 msgstr ""
 
 #. cloud folder path refusal (#524 PL-003)
 msgid "CHECK THE PATH AND YOUR CONNECTION, THEN TRY AGAIN."
 msgstr ""
+
+#: es-app/src/scrapers/ScreenScraper.cpp
+msgid "SCREENSCRAPER REJECTED THIS SYSTEM'S ACCESS.\nCHECK FOR A SYSTEM UPDATE OR REPORT THE PROBLEM."
+msgstr ""
diff --git a/locale/lang/en_GB/LC_MESSAGES/emulationstation2.po b/locale/lang/en_GB/LC_MESSAGES/emulationstation2.po
index 5eaf34636..38bcd554e 100644
--- a/locale/lang/en_GB/LC_MESSAGES/emulationstation2.po
+++ b/locale/lang/en_GB/LC_MESSAGES/emulationstation2.po
@@ -4054,8 +4054,44 @@ msgstr[1] "%d seconds ago"
 #~ msgid "CREATE NEW CUSTOM COLLECTION FROM THEME"
 #~ msgstr "CREATE NEW CUSTOM COLLECTION FROM THEME"
 
 #~ msgid "SELECT THEME FOLDER"
 #~ msgstr "SELECT THEME FOLDER"
 
 #~ msgid "GROUP UNTHEMED CUSTOM COLLECTIONS"
 #~ msgstr "GROUP UNTHEMED CUSTOM COLLECTIONS"
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "THIS ALSO CHECKS NEW GAMES FOR OFFLINE ACHIEVEMENTS. AN INTERNET CONNECTION IS NEEDED TO DOWNLOAD THEIR ACHIEVEMENT DATA."
+msgstr "THIS ALSO CHECKS NEW GAMES FOR OFFLINE ACHIEVEMENTS. AN INTERNET CONNECTION IS NEEDED TO DOWNLOAD THEIR ACHIEVEMENT DATA."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "THE SIGN-IN WINDOW DID NOT OPEN OR STOPPED WORKING.\n\nTRY AGAIN, OR CANCEL SIGN-IN."
+msgstr "THE SIGN-IN WINDOW DID NOT OPEN OR STOPPED WORKING.\n\nTRY AGAIN, OR CANCEL SIGN-IN."
+
+#: es-app/src/guis/GuiWifi.cpp
+msgid "COULDN'T SEARCH WI-FI NETWORKS. TRY AGAIN."
+msgstr "COULDN'T SEARCH WI-FI NETWORKS. TRY AGAIN."
+
+#: es-app/src/guis/GuiWifi.cpp
+msgid "SHOWING PREVIOUS RESULTS."
+msgstr "SHOWING PREVIOUS RESULTS."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "Supported emulators only. Save on exit and load on launch."
+msgstr "Supported emulators only. Save on exit and load on launch."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "RetroArch only. Show the manager before launching a game."
+msgstr "RetroArch only. Show the manager before launching a game."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "SAVE STATE SUPPORT"
+msgstr "SAVE STATE SUPPORT"
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "THE AUTO SAVE/LOAD SETTING AND SAVE STATE MANAGER DO NOT APPLY TO THIS EMULATOR.\n\nUSE THE EMULATOR'S OWN SAVE OPTIONS. IN-GAME SAVES ARE SEPARATE."
+msgstr "THE AUTO SAVE/LOAD SETTING AND SAVE STATE MANAGER DO NOT APPLY TO THIS EMULATOR.\n\nUSE THE EMULATOR'S OWN SAVE OPTIONS. IN-GAME SAVES ARE SEPARATE."
+
+#: es-app/src/scrapers/ScreenScraper.cpp
+msgid "SCREENSCRAPER REJECTED THIS SYSTEM'S ACCESS.\nCHECK FOR A SYSTEM UPDATE OR REPORT THE PROBLEM."
+msgstr "SCREENSCRAPER REJECTED THIS SYSTEM'S ACCESS.\nCHECK FOR A SYSTEM UPDATE OR REPORT THE PROBLEM."
diff --git a/locale/lang/fr/LC_MESSAGES/emulationstation2.po b/locale/lang/fr/LC_MESSAGES/emulationstation2.po
index 7ed595967..41d0878cb 100644
--- a/locale/lang/fr/LC_MESSAGES/emulationstation2.po
+++ b/locale/lang/fr/LC_MESSAGES/emulationstation2.po
@@ -3015,18 +3015,17 @@ msgstr "QUITTER EMULATIONSTATION"
 
 msgid "REALLY QUIT?"
 msgstr "VOULEZ-VOUS VRAIMENT QUITTER ?"
 
 msgid "AUTO SAVE/LOAD ON GAME LAUNCH"
 msgstr "SAUV./CHARG. AUTO AU LANCEMENT"
 
 msgid "Load latest save state on game launch and save state when exiting game."
-msgstr ""
-"Charge la dernière sauvegarde automatiquement et sauve en quittant le jeu."
+msgstr "Charge le dernier état au lancement et le sauve à la sortie."
 
 msgid "SHOW CONTROLLER OVERLAYS"
 msgstr "AFFICHER LA MANETTE EN SURIMPRESSION"
 
 msgid "CUSTOM .PNG IMAGE"
 msgstr "IMAGE .PNG PERSONNALISÉE"
 
 msgid "OVERLAY CORNER"
@@ -6922,8 +6921,44 @@ msgstr "METTRE À JOUR CETTE CONNEXION EN GARDANT LES DOSSIERS CHOISIS ?\n\nLES
 
 #: es-core/src/guis/GuiTextEditPopup.cpp es-core/src/guis/GuiTextEditPopupKeyboard.cpp
 msgid "CLEAR"
 msgstr "EFFACER"
 
 #: es-app/src/guis/GuiMenu.cpp
 msgid "THE SELECTED CONNECTION IS MISSING. CHOOSE ANOTHER UNDER CLOUD CONNECTIONS."
 msgstr "LA CONNEXION SÉLECTIONNÉE N’EXISTE PLUS. CHOISISSEZ-EN UNE AUTRE DANS CONNEXIONS AU CLOUD."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "THIS ALSO CHECKS NEW GAMES FOR OFFLINE ACHIEVEMENTS. AN INTERNET CONNECTION IS NEEDED TO DOWNLOAD THEIR ACHIEVEMENT DATA."
+msgstr "LES NOUVEAUX JEUX SONT AUSSI ANALYSÉS POUR LES SUCCÈS HORS LIGNE. UNE CONNEXION INTERNET EST NÉCESSAIRE POUR TÉLÉCHARGER LEURS DONNÉES DE SUCCÈS."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "THE SIGN-IN WINDOW DID NOT OPEN OR STOPPED WORKING.\n\nTRY AGAIN, OR CANCEL SIGN-IN."
+msgstr "LA FENÊTRE DE CONNEXION NE S’EST PAS OUVERTE OU A CESSÉ DE FONCTIONNER.\n\nRÉESSAYEZ OU ANNULEZ LA CONNEXION."
+
+#: es-app/src/guis/GuiWifi.cpp
+msgid "COULDN'T SEARCH WI-FI NETWORKS. TRY AGAIN."
+msgstr "RECHERCHE WI-FI IMPOSSIBLE. RÉESSAYEZ."
+
+#: es-app/src/guis/GuiWifi.cpp
+msgid "SHOWING PREVIOUS RESULTS."
+msgstr "RÉSULTATS PRÉCÉDENTS AFFICHÉS."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "Supported emulators only. Save on exit and load on launch."
+msgstr "Émulateurs compatibles. Sauvegarde à la sortie, chargement au lancement."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "RetroArch only. Show the manager before launching a game."
+msgstr "RetroArch uniquement. Affiche le gestionnaire avant le jeu."
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "SAVE STATE SUPPORT"
+msgstr "AIDE AUX SAUVEGARDES D’ÉTAT"
+
+#: es-app/src/guis/GuiMenu.cpp
+msgid "THE AUTO SAVE/LOAD SETTING AND SAVE STATE MANAGER DO NOT APPLY TO THIS EMULATOR.\n\nUSE THE EMULATOR'S OWN SAVE OPTIONS. IN-GAME SAVES ARE SEPARATE."
+msgstr "LE RÉGLAGE SAUV./CHARG. AUTO ET LE GESTIONNAIRE DES SAUVEGARDES D’ÉTAT NE S’APPLIQUENT PAS À CET ÉMULATEUR.\n\nUTILISEZ SES PROPRES OPTIONS DE SAUVEGARDE. LES SAUVEGARDES DANS LE JEU SONT DISTINCTES."
+
+#: es-app/src/scrapers/ScreenScraper.cpp
+msgid "SCREENSCRAPER REJECTED THIS SYSTEM'S ACCESS.\nCHECK FOR A SYSTEM UPDATE OR REPORT THE PROBLEM."
+msgstr "SCREENSCRAPER A REFUSÉ L’ACCÈS DE CE SYSTÈME.\nCHERCHEZ UNE MISE À JOUR DU SYSTÈME OU SIGNALEZ LE PROBLÈME."
diff --git a/tests/cloud-oauth-lifetime.py b/tests/cloud-oauth-lifetime.py
index 196abce8f..634ddbfdd 100644
--- a/tests/cloud-oauth-lifetime.py
+++ b/tests/cloud-oauth-lifetime.py
@@ -58,17 +58,17 @@ int getScreenWidth() { return 640; }
 int getScreenHeight() { return 480; }
 struct ScreenSettings { static bool fullScreenMenus() { return false; } };
 }
 struct GuiSettings;
 struct Window {
     std::vector<GuiSettings*> stack;
     void pushGui(GuiSettings* gui) { stack.push_back(gui); }
 };
-struct Menu { void setSize(float, float) {} };
+struct Menu { void setSize(float, float) {} void setPosition(float, float) {} };
 struct GuiSettings {
     Window* window;
     Menu menu;
     bool saveAllowed = true;
     std::vector<std::pair<std::string, std::function<void()>>> choices;
     GuiSettings(Window* w, const std::string&) : window(w) {}
     ~GuiSettings() {
         auto& stack = window->stack;
diff --git a/tests/md5-alignment.c b/tests/md5-alignment.c
new file mode 100644
index 000000000..4f378a50a
--- /dev/null
+++ b/tests/md5-alignment.c
@@ -0,0 +1,34 @@
+/* SPDX-License-Identifier: MIT
+ * Cross-compile with the actual libretro-common md5.c and compare each emitted
+ * digest with an independent implementation. No game, account or file input.
+ */
+#include <lrc_hash.h>
+#include <stddef.h>
+#include <stdio.h>
+
+int main(void)
+{
+    static const size_t lengths[] = {0, 1, 55, 56, 63, 64, 65, 127, 128, 129, 1024};
+    union { MD5_u32plus aligned; unsigned char bytes[1032]; } input;
+    unsigned char digest[16];
+    unsigned offset, split, i;
+    size_t l, n;
+    for (offset = 0; offset < 8; ++offset) {
+        for (i = 0; i < 1024; ++i) input.bytes[offset + i] = (unsigned char)(i * 13 + 7);
+        for (l = 0; l < sizeof(lengths) / sizeof(lengths[0]); ++l) {
+            n = lengths[l];
+            for (split = 0; split < 3; ++split) {
+                const size_t first = split == 0 ? n : split == 1 ? n / 2 : (n > 1 ? 1 : 0);
+                MD5_CTX ctx;
+                MD5_Init(&ctx);
+                MD5_Update(&ctx, input.bytes + offset, (unsigned long)first);
+                MD5_Update(&ctx, input.bytes + offset + first, (unsigned long)(n - first));
+                MD5_Final(digest, &ctx);
+                printf("%u %zu %u ", offset, n, split);
+                for (i = 0; i < sizeof(digest); ++i) printf("%02x", digest[i]);
+                putchar('\n');
+            }
+        }
+    }
+    return 0;
+}

```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/virtual/emulators/sources/Install Steam.sh

```text
    1 #!/bin/bash
    2 
    3 # SPDX-License-Identifier: GPL-2.0-or-later
    4 # Copyright (C) 2026-present ROCKNIX (https://github.com/ROCKNIX)
    5 
    6 set -e
    7 set -o pipefail
    8 
    9 STEAM="${STEAM:-/storage/.local/share/Steam}"
   10 STEAM_GAMES_ROOT="${STEAM_GAMES_ROOT:-/storage/games-internal/roms/steam}"
   11 # --- Logging & Error Handling Helpers ---
   12 log_info() { echo -e "[\033[1;34mINFO\033[0m] $1"; }
   13 log_success() { echo -e "[\033[1;32mSUCCESS\033[0m] $1"; sleep 10; exit 0; }
   14 die() { echo -e "[\033[1;31mERROR\033[0m] $1" >&2; sleep 10; exit 1; }
   15 # ----------------------------------------
   16 
   17 # Inspect before profiles or installer functions can write. The saved plan is
   18 # process-local; no marker, directory, lock, or test file is created by preflight.
   19 steam_root_layout() {
   20   /usr/bin/python3 -I -S -B - "$1" "${STEAM}" "${STEAM_GAMES_ROOT}" "${STEAM_ROOT_PLAN:-}" <<'PY_STEAM_ROOT'
   21 import json
   22 import os
   23 from pathlib import Path
   24 import re
   25 import stat
   26 import sys
   27 
   28 STORAGE = Path("/storage")
   29 MOUNTINFO = Path("/proc/self/mountinfo")
   30 MEDIA = Path("/var/media")
   31 
   32 
   33 def beneath(path, parent):
   34     return path == parent or parent in path.parents
   35 
   36 
   37 def input_path(value):
   38     if (not value.startswith("/") or value != os.path.normpath(value)
   39             or value.startswith("//") or any(ord(c) < 32 for c in value)):
   40         raise ValueError("The Steam folder path is not an absolute, unambiguous path.")
   41     return Path(value)
   42 
   43 
   44 def read_mounts():
   45     with MOUNTINFO.open() as stream:
   46         raw = stream.read(1024 * 1024 + 1)
   47     if not raw or len(raw) > 1024 * 1024:
   48         raise ValueError("Storage availability could not be checked.")
   49     rows = []
   50     for line in raw.splitlines():
   51         fields = line.split()
   52         split = fields.index("-")
   53         if split < 6 or len(fields) != split + 4:
   54             raise ValueError("Storage availability could not be checked.")
   55         point = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), fields[4])
   56         rows.append((Path(point), fields))
   57     return rows
   58 
   59 
   60 def inspect(steam_value, library_value):
   61     steam = input_path(steam_value)
   62     rows = read_mounts()
   63     used = {}
   64     required = (STORAGE, STORAGE / "games-external", STORAGE / "roms")
   65     reserved = (*required, STORAGE / "games-internal", MEDIA, Path("/"))
   66 
   67     def available(path):
   68         wanted = [p for p in required if beneath(path, p)]
   69         if beneath(path, MEDIA) and path != MEDIA:
   70             wanted.append(MEDIA / path.relative_to(MEDIA).parts[0])
   71         for point in wanted:
   72             matches = [row for row in rows if row[0] == point]
   73             if len(matches) != 1:
   74                 raise ValueError("The Steam storage is unavailable or has overlapping mounts.")
   75             used[str(point)] = matches[0][1]
   76         covers = [row for row in rows if beneath(path, row[0])]
   77         if not covers:
   78             raise ValueError("The Steam storage is unavailable.")
   79         depth = max(len(row[0].parts) for row in covers)
   80         covers = [row for row in covers if len(row[0].parts) == depth]
   81         if len(covers) != 1 or covers[0][0] == Path("/"):
   82             raise ValueError("The Steam storage is unavailable or ambiguous.")
   83         point, fields = covers[0]
   84         if "rw" not in fields[5].split(",") or "rw" not in fields[-1].split(","):
   85             raise ValueError("The Steam storage is read-only.")
   86         used[str(point)] = fields
   87 
   88     # FEX/config also use /storage, even when the Steam alias points elsewhere.
   89     available(STORAGE)
   90 
   91     def probe(path):
   92         available(path)
   93         current, pending, entries, links = Path("/"), list(path.parts[1:]), [], 0
   94         while pending:
   95             part = pending.pop(0)
   96             if part in ("", "."):
   97                 continue
   98             if part == "..":
   99                 current = current.parent
  100                 continue
  101             candidate = current / part
  102             if candidate in required or candidate.parent == MEDIA:
  103                 available(candidate)
  104             try:
  105                 info = candidate.lstat()
  106             except FileNotFoundError:
  107                 if ".." in pending:
  108                     raise ValueError("The Steam folder path is ambiguous.")
  109                 resolved = candidate.joinpath(*pending)
  110                 available(resolved)
  111                 if resolved in reserved:
  112                     raise ValueError("The Steam folder path is ambiguous.")
  113                 if not os.access(current, os.W_OK | os.X_OK):
  114                     raise ValueError("The Steam folder is not writable.")
  115                 return {"path": str(resolved), "exists": False, "entries": entries}
  116             entry = [str(candidate), info.st_dev, info.st_ino, info.st_mode]
  117             if stat.S_ISLNK(info.st_mode):
  118                 links += 1
  119                 if links > 40 or not stat.S_ISDIR(candidate.stat().st_mode):
  120                     raise ValueError("The Steam folder link is unavailable or invalid.")
  121                 target = os.readlink(candidate)
  122                 if any(ord(c) < 32 for c in target):
  123                     raise ValueError("The Steam folder link is ambiguous.")
  124                 entry.append(target)
  125                 entries.append(entry)
  126                 target_path = Path(target)
  127                 if target_path.is_absolute():
  128                     current = Path("/")
  129                     pending = list(target_path.parts[1:]) + pending
  130                 else:
  131                     pending = list(target_path.parts) + pending
  132                 continue
  133             if not stat.S_ISDIR(info.st_mode):
  134                 raise ValueError("A file is blocking the Steam folder.")
  135             entries.append(entry)
  136             current = candidate
  137         available(current)
  138         if current in reserved or not os.access(current, os.W_OK | os.X_OK):
  139             raise ValueError("The Steam folder is ambiguous or not writable.")
  140         return {"path": str(current), "exists": True, "entries": entries}
  141 
  142     root = probe(steam)
  143     plan = {"steam": steam_value, "library": library_value, "root": root}
  144     if not root["exists"]:
  145         library = probe(input_path(library_value))
  146         a, b = Path(root["path"]), Path(library["path"])
  147         if beneath(a, b) or beneath(b, a):
  148             raise ValueError("The Steam folder and library paths overlap.")
  149         plan["target"] = library
  150     plan["mounts"] = used
  151     return plan
  152 
  153 
  154 def open_directory(path):
  155     # Use the resolved path and no-follow directory descriptors. mkdir only
  156     # adds missing directories; neither it nor symlink replaces an existing entry.
  157     fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
  158     try:
  159         for part in Path(path).parts[1:]:
  160             flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
  161             try:
  162                 child = os.open(part, flags, dir_fd=fd)
  163             except FileNotFoundError:
  164                 os.mkdir(part, dir_fd=fd)
  165                 child = os.open(part, flags, dir_fd=fd)
  166             os.close(fd)
  167             fd = child
  168         return fd
  169     except BaseException:
  170         os.close(fd)
  171         raise
  172 
  173 
  174 def main():
  175     mode, steam, library, saved = sys.argv[1:]
  176     plan = inspect(steam, library)
  177     if mode == "inspect":
  178         print(json.dumps(plan, sort_keys=True))
  179         return
  180     if mode not in ("verify", "link") or plan != json.loads(saved):
  181         raise ValueError("The Steam folder or storage changed. Try again when it is available.")
  182     if mode == "verify" or plan["root"]["exists"]:
  183         return
  184     target_fd = open_directory(plan["target"]["path"])
  185     os.close(target_fd)
  186     root = Path(plan["root"]["path"])
  187     parent_fd = open_directory(root.parent)
  188     try:
  189         os.symlink(library, root.name, dir_fd=parent_fd)
  190     finally:
  191         os.close(parent_fd)
  192 
  193 
  194 if __name__ == "__main__":
  195     try:
  196         main()
  197     except (OSError, ValueError, RuntimeError) as error:
  198         print("Steam folder check: " + str(error), file=sys.stderr)
  199         sys.exit(1)
  200 PY_STEAM_ROOT
  201 }
  202 
  203 fetch_proton_latest_release() {
  204   local api_url="$1"
  205   local asset_pattern="$2"
  206   local tag_prefix_to_strip="$3"
  207   local var_prefix="$4"
  208   local display_name="$5"
  209 
  210   log_info "Fetching latest ${display_name} release from GitHub..."
  211 
  212   local release_json
  213   release_json=$(curl -fsSL "${api_url}") || die "Failed to fetch ${display_name} latest release info."
  214 
  215   # Extract tag name
  216   local version_tag
  217   version_tag=$(echo "${release_json}" | grep -oP '"tag_name":\s*"\K[^"]+' | head -n 1) || die "Failed to parse ${display_name} version tag."
  218   [ -n "${version_tag}" ] || die "${display_name} version tag is empty."
  219 
  220   # Extract download URL for specified asset pattern, excluding checksums
  221   local download_url
  222   download_url=$(echo "${release_json}" | grep -oP '"browser_download_url":\s*"\K[^"]*'"${asset_pattern}"'[^"]*' | grep -v '\.sha512sum' | head -n 1) || die "Failed to parse ${display_name} download URL."
  223   [ -n "${download_url}" ] || die "Could not find ${asset_pattern} asset in ${display_name} release."
  224 
  225   # Extract filename from URL
  226   local tar_name
  227   tar_name=$(basename "${download_url}") || die "Failed to extract ${display_name} filename."
  228   [ -n "${tar_name}" ] || die "${display_name} filename is empty."
  229 
  230   local version_clean="${version_tag}"
  231   if [ -n "${tag_prefix_to_strip}" ]; then
  232     version_clean="${version_tag#${tag_prefix_to_strip}}"
  233   fi
  234 
  235   # Infer directory name based on tar filename
  236   local dir_name
  237   dir_name=$(echo "${tar_name}" | sed 's/\.[^.]*$//' | sed 's/\.[^.]*$//')  # Remove .tar.xz or .tar.gz
  238 
  239   # Set global variables dynamically
  240   eval "${var_prefix}_VERSION_FULL='${version_clean}'"
  241   eval "${var_prefix}_TAR='${tar_name}'"
  242   eval "${var_prefix}_DIR='${dir_name}'"
  243   eval "${var_prefix}_URL='${download_url}'"
  244 
  245   log_info "${display_name} latest version: ${version_clean}"
  246   log_info "${display_name} download URL: ${download_url}"
  247 }
  248 
  249 ensure_fex_rootfs() {
  250   log_info "Preparing the Steam support environment. This may take a while..."
  251   # FEXRootFSFetcher also writes Config.json. Isolate that write, then commit
  252   # the fully overlaid RootFS and packaged config together. Never clean by glob.
  253   if /usr/bin/python3 -I -S -B - "${FEX_DATA}" <<'PY_STEAM_FEX'
  254 import fcntl
  255 import hashlib
  256 import json
  257 import os
  258 from pathlib import Path
  259 import re
  260 import resource
  261 import selectors
  262 import shutil
  263 import signal
  264 import stat
  265 import subprocess
  266 import sys
  267 import time
  268 
  269 CONFIG = Path("/storage/.config/fex-emu")
  270 DEFAULTS = Path("/usr/config/fex-emu")
  271 OVERLAYS = (
  272     (Path("/usr/lib/liblsfg-vk-layer.so"), "usr/lib/liblsfg-vk-layer.so"),
  273     (Path("/usr/share/fex-emu/liblsfg-vk-layer-x86.so"), "usr/lib/liblsfg-vk-layer-x86.so"),
  274     (Path("/usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation.json"),
  275      "usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation.json"),
  276     (Path("/usr/share/fex-emu/VkLayer_LSFGVK_frame_generation-x86.json"),
  277      "usr/share/vulkan/implicit_layer.d/VkLayer_LSFGVK_frame_generation-x86.json"),
  278 )
  279 FETCHER = "/usr/bin/FEXRootFSFetcher"
  280 RESERVE = 256 * 1024 * 1024
  281 MAX_FILE = 2 * 1024 * 1024 * 1024
  282 MAX_TREE = 16 * 1024 * 1024 * 1024
  283 MAX_CONFIG = 64 * 1024 * 1024
  284 MAX_ENTRIES = 250000
  285 FETCH_SECONDS = 900
  286 TOTAL_SECONDS = 1800
  287 ICD = "usr/share/vulkan/icd.d/freedreno_icd.x86_64.json"
  288 
  289 
  290 def ident(path):
  291     try:
  292         info = path.lstat()
  293     except FileNotFoundError:
  294         return None
  295     if not stat.S_ISDIR(info.st_mode):
  296         raise RuntimeError("FEX replacement requires real directories: " + str(path))
  297     return [info.st_dev, info.st_ino]
  298 
  299 
  300 def no_mounts(path):
  301     boundary = path.absolute()
  302     for row in Path("/proc/self/mountinfo").read_text().splitlines():
  303         field = row.split()[4]
  304         mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field))
  305         if mount == boundary or boundary in mount.parents:
  306             raise RuntimeError("Release mounted FEX paths before refreshing: " + str(path))
  307 
  308 
  309 def parents(path):
  310     # No symlinked destination ancestors: do not normalize another storage view.
  311     for item in reversed((path, *path.parents)):
  312         if ident(item) is None:
  313             item.mkdir()
  314         ident(item)
  315 
  316 
  317 def capacity(path, required=0):
  318     info = os.statvfs(path)
  319     if info.f_bavail * info.f_frsize < RESERVE + required:
  320         raise RuntimeError("Not enough free space to keep the existing FEX environment.")
  321 
  322 
  323 def tree_budget(path, limit):
  324     no_mounts(path)
  325     total = count = 0
  326     for base, dirs, files in os.walk(path, followlinks=False):
  327         for name in dirs + files:
  328             info = (Path(base) / name).lstat()
  329             if not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode)):
  330                 raise RuntimeError("Unsupported entry in the FEX staging tree.")
  331             count += 1
  332             total += info.st_size + 4096
  333             if info.st_size > MAX_FILE or total > limit or count > MAX_ENTRIES:
  334                 raise RuntimeError("FEX staging exceeds the bounded file/space budget.")
  335     return total
  336 
  337 
  338 def inside(root, relative):
  339     path = root / relative
  340     target = path.resolve(strict=True)
  341     if not target.is_relative_to(root.resolve(strict=True)) or not target.is_file():
  342         raise RuntimeError("Missing or escaping FEX file: " + relative)
  343     return target
  344 
  345 
  346 def document(path):
  347     if path.stat().st_size > 1024 * 1024:
  348         raise RuntimeError("FEX metadata exceeds its size bound.")
  349     data = json.loads(path.read_text())
  350     if not isinstance(data, dict):
  351         raise RuntimeError("FEX metadata is not a JSON object.")
  352     return data
  353 
  354 
  355 def elf(path, machine):
  356     with path.open("rb") as stream:
  357         header = stream.read(20)
  358     if (len(header) != 20 or header[:6] != b"\x7fELF\x02\x01"
  359             or int.from_bytes(header[18:20], "little") != machine):
  360         raise RuntimeError("Missing or wrong-architecture FEX binary: " + str(path))
  361 
  362 
  363 def digest(path):
  364     result = hashlib.sha256()
  365     with path.open("rb") as stream:
  366         for block in iter(lambda: stream.read(1024 * 1024), b""):
  367             result.update(block)
  368     return result.hexdigest()
  369 
  370 
  371 def validate(root, config):
  372     ident(root)
  373     ident(config)
  374     required = ["usr/bin/env", "usr/lib/ld-linux-x86-64.so.2", "usr/lib/libc.so.6",
  375                 "graphics_provider.json", ICD] + [rel for _, rel in OVERLAYS]
  376     for rel in required[:3]:
  377         elf(inside(root, rel), 62)
  378     if not document(inside(root, "graphics_provider.json")):
  379         raise RuntimeError("Empty graphics provider description.")
  380     if document(inside(root, ICD)).get("ICD", {}).get("library_path") != "libvulkan_freedreno.so":
  381         raise RuntimeError("Freedreno ICD does not select the host driver.")
  382     elf(inside(root, OVERLAYS[0][1]), 183)
  383     elf(inside(root, OVERLAYS[1][1]), 62)
  384     for index, suffix in ((2, ""), (3, "_x86")):
  385         layer = document(inside(root, OVERLAYS[index][1])).get("layer", {})
  386         if (layer.get("name") != "VK_LAYER_LSFGVK_frame_generation" + suffix
  387                 or layer.get("library_path") != "/usr/lib/liblsfg-vk-layer" + ("-x86" if suffix else "") + ".so"):
  388             raise RuntimeError("Invalid LSFG layer description.")
  389     if document(inside(config, "Config.json")).get("Config", {}).get("RootFS") != "ArchLinux":
  390         raise RuntimeError("FEX config does not select the prepared ArchLinux tree.")
  391     packaged = {}
  392     for base, dirs, files in os.walk(DEFAULTS, followlinks=False):
  393         for name in dirs + files:
  394             source = Path(base) / name
  395             if source.is_symlink():
  396                 raise RuntimeError("Unexpected link in packaged FEX config.")
  397             if source.is_file():
  398                 rel = str(source.relative_to(DEFAULTS))
  399                 packaged[rel] = digest(inside(config, rel))
  400                 if packaged[rel] != digest(source):
  401                     raise RuntimeError("Packaged FEX config copy failed validation: " + rel)
  402     return {"root": {rel: digest(inside(root, rel)) for rel in required}, "config": packaged}
  403 
  404 
  405 def overlay(root):
  406     for source, rel in OVERLAYS:
  407         # A RootFS symlink must never redirect a host-side overlay copy.
  408         dest = root / rel
  409         parent = dest.parent.resolve(strict=True)
  410         if not parent.is_relative_to(root.resolve(strict=True)) or dest.is_symlink():
  411             raise RuntimeError("Unsafe FEX overlay destination: " + rel)
  412         if not source.is_file() or source.stat().st_size > MAX_CONFIG:
  413             raise RuntimeError("Required FEX overlay is missing or oversized: " + source.name)
  414         shutil.copy2(source, dest)
  415     for rel, section, key, old, new in (
  416         (OVERLAYS[3][1], "layer", "name", "VK_LAYER_LSFGVK_frame_generation", "VK_LAYER_LSFGVK_frame_generation_x86"),
  417         (ICD, "ICD", "library_path", "/usr/lib/libvulkan_freedreno.so", "libvulkan_freedreno.so"),
  418     ):
  419         path = inside(root, rel)
  420         data = document(path)
  421         if data.get(section, {}).get(key) not in (old, new):
  422             raise RuntimeError("Unexpected FEX overlay metadata: " + rel)
  423         data[section][key] = new
  424         path.write_text(json.dumps(data, indent=2) + "\n")
  425 
  426 
  427 def config_copy(source, destination):
  428     # Preserve extra config files, but apply the packaged defaults just as the
  429     # previous cp -r did. Do not follow any existing config link when overlaying.
  430     ident(source)
  431     for base, dirs, files in os.walk(source, followlinks=False):
  432         relative = Path(base).relative_to(source)
  433         target = destination / relative
  434         if target.is_symlink():
  435             raise RuntimeError("Refusing a linked config overlay directory.")
  436         target.mkdir(exist_ok=True)
  437         for name in dirs + files:
  438             item, out = Path(base) / name, target / name
  439             if out.is_symlink():
  440                 raise RuntimeError("Refusing a linked config overlay entry.")
  441             if item.is_symlink():
  442                 if out.exists():
  443                     raise RuntimeError("Conflicting config link.")
  444                 out.symlink_to(os.readlink(item))
  445             elif item.is_file():
  446                 if out.exists() and not out.is_file():
  447                     raise RuntimeError("Conflicting config entry.")
  448                 shutil.copy2(item, out)
  449         shutil.copystat(base, target)
  450 
  451 
  452 def fetch_environment(work):
  453     # No inherited FEX_*, STEAM_COMPAT_*, or loader/config overrides.
  454     # HOME must exist or FEX falls back to passwd/PWD. Both FEX paths need '/'.
  455     environment = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C",
  456             "HOME": str(work / "home"), "PWD": str(work / "home"),
  457             "TMPDIR": str(work / "tmp"), "XDG_DATA_HOME": str(work / "data"),
  458             "XDG_CONFIG_HOME": str(work / "fetch-config"), "XDG_CACHE_HOME": str(work / "cache"),
  459             "FEX_APP_DATA_LOCATION": str(work / "data") + "/",
  460             "FEX_APP_CONFIG_LOCATION": str(work / "fetch-config") + "/",
  461             "FEX_APP_CACHE_LOCATION": str(work / "cache") + "/"}
  462     # Keep the existing transport's explicit proxy settings; never log values.
  463     for key in ("http_proxy", "https_proxy", "all_proxy", "no_proxy",
  464                 "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY"):
  465         if key in os.environ:
  466             environment[key] = os.environ[key]
  467     return environment
  468 
  469 
  470 def fetch_rootfs(work):
  471     # The guardian survives SIGKILL of the updater, holds its inherited flock,
  472     # and kills the entire fetcher/curl/extractor group on pipe EOF or timeout.
  473     read_fd, write_fd = os.pipe()
  474     guardian = os.fork()
  475     if guardian == 0:
  476         os.close(write_fd)
  477         os.setsid()
  478         for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
  479             signal.signal(sig, interrupted)
  480         signal.alarm(0)
  481         proc = None
  482         result = 1
  483         try:
  484             resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_FILE, MAX_FILE))
  485             resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
  486             proc = subprocess.Popen(
  487                 [FETCHER, "--distro-name=arch", "--distro-version=rolling", "-y", "-x", "--force-ui=tty"],
  488                 cwd=work / "home", env=fetch_environment(work), stdin=subprocess.DEVNULL,
  489                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
  490             deadline = time.monotonic() + FETCH_SECONDS
  491             next_scan = 0.0
  492             selector = selectors.DefaultSelector()
  493             selector.register(read_fd, selectors.EVENT_READ)
  494             selector.register(proc.stdout, selectors.EVENT_READ)
  495             logged = 0
  496             with (work / "fetch.log").open("wb") as log:
  497                 while True:
  498                     capacity(work)
  499                     if time.monotonic() >= next_scan:
  500                         tree_budget(work / "data", MAX_TREE)
  501                         next_scan = time.monotonic() + 1
  502                     if time.monotonic() >= deadline:
  503                         raise RuntimeError("FEX fetch/extraction reached its time limit.")
  504                     for key, _ in selector.select(0.2):
  505                         if key.fd == read_fd:
  506                             raise RuntimeError("FEX updater exited; cancelling its fetcher group.")
  507                         chunk = os.read(key.fd, 65536)
  508                         if not chunk:
  509                             selector.unregister(key.fileobj)
  510                         else:
  511                             saved = chunk[:max(0, 65536 - logged)]
  512                             log.write(saved)
  513                             logged += len(saved)
  514                     code = proc.poll()
  515                     if code is not None:
  516                         if code != 0:
  517                             raise RuntimeError("FEX fetcher exited " + str(code))
  518                         result = 0
  519                         break
  520         except BaseException as error:
  521             print("FEX fetch stopped: " + str(error), file=sys.stderr, flush=True)
  522         finally:
  523             for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
  524                 signal.signal(sig, signal.SIG_IGN)
  525             if proc is not None:
  526                 try:
  527                     os.killpg(proc.pid, signal.SIGKILL)
  528                 except ProcessLookupError:
  529                     pass
  530                 try:
  531                     proc.wait(timeout=5)
  532                 except subprocess.TimeoutExpired:
  533                     result = 1
  534             os.close(read_fd)
  535             os._exit(result)
  536     os.close(read_fd)
  537     try:
  538         _, status = os.waitpid(guardian, 0)
  539         if os.waitstatus_to_exitcode(status) != 0:
  540             raise RuntimeError("FEX download or extraction did not finish.")
  541     finally:
  542         # On a catchable interruption the guardian sees EOF and kills children
  543         # before rollback can remove their staging directory. Mask repeated
  544         # catchable signals while waiting; SIGKILL still leaves the guardian's
  545         # inherited lock held until its process group has been killed.
  546         mask = signal.pthread_sigmask(signal.SIG_BLOCK,
  547                                      {signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM})
  548         try:
  549             os.close(write_fd)
  550             try:
  551                 os.waitpid(guardian, 0)
  552             except ChildProcessError:
  553                 pass
  554         finally:
  555             signal.pthread_sigmask(signal.SIG_SETMASK, mask)
  556 
  557 
  558 class FexUpdate:
  559     def __init__(self, data):
  560         self.data = data
  561         self.root = data / "RootFS" / "ArchLinux"
  562         self.config = CONFIG
  563         parents(self.root.parent)
  564         parents(self.config.parent)
  565         self.device = self.data.stat().st_dev
  566         if self.config.parent.stat().st_dev != self.device:
  567             raise RuntimeError("FEX root and config must share a filesystem for recovery.")
  568         self.work = data / ".steam-fex-update"
  569         self.state = None
  570         self.check_live()
  571 
  572     def check_live(self):
  573         for path in (self.root, self.config):
  574             value = ident(path)
  575             if value is not None and value[0] != self.device:
  576                 raise RuntimeError("FEX destination is on another filesystem.")
  577             no_mounts(path)
  578 
  579     def write_state(self):
  580         pending = self.work / "state.tmp"
  581         with pending.open("w") as stream:
  582             json.dump(self.state, stream)
  583             stream.flush()
  584             os.fsync(stream.fileno())
  585         os.replace(pending, self.work / "state.json")
  586         fd = os.open(self.work, os.O_RDONLY | os.O_DIRECTORY)
  587         try:
  588             os.fsync(fd)
  589         finally:
  590             os.close(fd)
  591 
  592     def clean(self):
  593         no_mounts(self.work)
  594         for item in self.work.iterdir():
  595             if item.name == "state.json":
  596                 continue
  597             if item.is_dir() and not item.is_symlink():
  598                 shutil.rmtree(item)
  599             else:
  600                 item.unlink()
  601         (self.work / "state.json").unlink(missing_ok=True)
  602         self.work.rmdir()
  603         self.state = None
  604 
  605     def recover(self):
  606         if ident(self.work) is None:
  607             return
  608         no_mounts(self.work)
  609         journal = self.work / "state.json"
  610         if not journal.exists():
  611             # Before first journal publication only this temporary file may
  612             # exist. After final cleanup the directory may be empty.
  613             entries = list(self.work.iterdir())
  614             if entries:
  615                 if len(entries) != 1 or entries[0].name != "state.tmp" or not stat.S_ISREG(entries[0].lstat().st_mode):
  616                     raise RuntimeError("Unrecognized FEX staging directory; retaining it.")
  617                 entries[0].unlink()
  618             self.work.rmdir()
  619             return
  620         if journal.is_symlink() or not journal.is_file() or journal.stat().st_size > 65536:
  621             raise RuntimeError("Invalid FEX recovery journal; retaining it.")
  622         self.state = json.loads(journal.read_text())
  623         if (self.state.get("format") != 1 or self.state.get("data") != str(self.data)
  624                 or self.state.get("config") != str(self.config)
  625                 or self.state.get("phase") not in ("staging", "prepared", "committed")):
  626             raise RuntimeError("Unrecognized FEX recovery journal; retaining it.")
  627         self.check_live()
  628         phase = self.state["phase"]
  629         if phase == "committed":
  630             if (any(ident(getattr(self, name)) != self.state["new"][name] for name in ("root", "config"))
  631                     or validate(self.root, self.config) != self.state["validation"]):
  632                 raise RuntimeError("Committed FEX environment changed; retaining recovery data.")
  633         elif phase == "prepared":
  634             for name in ("config", "root"):
  635                 live = getattr(self, name)
  636                 old, new = self.state["old"][name], self.state["new"][name]
  637                 previous = self.work / ("previous-" + name)
  638                 current = ident(live)
  639                 if current == old:
  640                     if ident(previous) is not None:
  641                         raise RuntimeError("Ambiguous FEX recovery copy; retaining it.")
  642                     continue
  643                 if old is not None and ident(previous) != old:
  644                     raise RuntimeError("Previous FEX identity changed; retaining recovery data.")
  645                 if current == new:
  646                     discard = self.work / ("discard-" + name)
  647                     if ident(discard) is not None:
  648                         raise RuntimeError("Ambiguous FEX discard path; retaining it.")
  649                     os.rename(live, discard)
  650                 elif current is not None:
  651                     raise RuntimeError("FEX destination changed outside this update.")
  652                 if old is not None:
  653                     os.rename(previous, live)
  654         self.clean()
  655 
  656     def begin(self):
  657         self.work.mkdir(mode=0o700)
  658         self.state = {"format": 1, "data": str(self.data), "config": str(self.config), "phase": "staging",
  659                       "old": {name: ident(getattr(self, name)) for name in ("root", "config")}}
  660         self.write_state()
  661         for name in ("home", "tmp", "data", "cache", "fetch-config", "new-config"):
  662             (self.work / name).mkdir()
  663 
  664     def stage(self):
  665         # Inspect required local inputs before allowing a download.
  666         if ident(DEFAULTS) is None:
  667             raise RuntimeError("Packaged FEX config is missing.")
  668         needed = tree_budget(DEFAULTS, MAX_CONFIG)
  669         if ident(self.config) is not None:
  670             needed += tree_budget(self.config, MAX_CONFIG)
  671         capacity(self.work, needed)
  672         for source, _ in OVERLAYS:
  673             if not source.is_file() or source.stat().st_size > MAX_CONFIG:
  674                 raise RuntimeError("Required FEX overlay is missing or oversized: " + source.name)
  675         config = self.work / "new-config"
  676         if ident(self.config) is not None:
  677             config_copy(self.config, config)
  678         config_copy(DEFAULTS, config)
  679         tree_budget(config, MAX_CONFIG)
  680         fetch_rootfs(self.work)
  681         root = self.work / "data" / "RootFS" / "ArchLinux"
  682         if ident(root) is None:
  683             raise RuntimeError("Fetcher did not produce an extracted ArchLinux directory.")
  684         if document(inside(self.work / "fetch-config", "Config.json")).get("Config", {}).get("RootFS") != "ArchLinux":
  685             raise RuntimeError("Fetcher selected an unexpected RootFS or left an unextracted image.")
  686         tree_budget(self.work / "data", MAX_TREE)
  687         overlay(root)
  688         capacity(self.work)
  689         self.check_live()
  690         validation = validate(root, config)
  691         if any(ident(getattr(self, name)) != self.state["old"][name] for name in ("root", "config")):
  692             raise RuntimeError("FEX destination changed while preparing its replacement.")
  693         self.state.update(phase="prepared", new={"root": ident(root), "config": ident(config)}, validation=validation)
  694         self.write_state()
  695 
  696     def activate(self):
  697         for name, staged in (("root", self.work / "data" / "RootFS" / "ArchLinux"),
  698                              ("config", self.work / "new-config")):
  699             live = getattr(self, name)
  700             if ident(live) != self.state["old"][name]:
  701                 raise RuntimeError("FEX destination changed before activation.")
  702             if self.state["old"][name] is not None:
  703                 os.rename(live, self.work / ("previous-" + name))
  704             os.rename(staged, live)
  705         if validate(self.root, self.config) != self.state["validation"]:
  706             raise RuntimeError("Activated FEX environment failed validation.")
  707         self.state["phase"] = "committed"
  708         self.write_state()
  709         self.clean()
  710 
  711 
  712 def interrupted(signum, frame):
  713     raise InterruptedError("FEX refresh interrupted by signal " + str(signum))
  714 
  715 
  716 def main():
  717     update = FexUpdate(Path(sys.argv[1]))
  718     fd = os.open(update.data / ".steam-fex-update.lock", os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
  719     try:
  720         if not stat.S_ISREG(os.fstat(fd).st_mode) or os.fstat(fd).st_nlink != 1:
  721             raise RuntimeError("Invalid FEX update lock.")
  722         fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
  723         for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
  724             signal.signal(sig, interrupted)
  725         signal.alarm(TOTAL_SECONDS)
  726         try:
  727             update.recover()
  728             capacity(update.data)
  729             update.begin()
  730             update.stage()
  731             update.activate()
  732             return 0
  733         except Exception as error:
  734             print("FEX refresh failed: " + str(error), file=sys.stderr)
  735             signal.alarm(0)
  736             # Do not interrupt rollback with a second catchable termination.
  737             for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
  738                 signal.signal(sig, signal.SIG_IGN)
  739             try:
  740                 update.recover()
  741             except Exception as recovery_error:
  742                 print("FEX recovery data retained at " + str(update.work) + ": " + str(recovery_error), file=sys.stderr)
  743             return 1
  744         finally:
  745             signal.alarm(0)
  746     finally:
  747         os.close(fd)
  748 
  749 
  750 if __name__ == "__main__":
  751     try:
  752         sys.exit(main())
  753     except Exception as error:
  754         print("FEX refresh refused: " + str(error), file=sys.stderr)
  755         sys.exit(1)
  756 PY_STEAM_FEX
  757   then
  758     log_info "Steam support environment is ready."
  759   else
  760     die "The Steam support environment could not be updated. Try Install Steam again."
  761   fi
  762 }
  763 
  764 link_steam_library() {
  765   log_info "Checking Steam library..."
  766   steam_root_layout link || die "The Steam library could not be prepared. Installation stopped."
  767 }
  768 
  769 ensure_steam_desktop_stub() {
  770   log_info "Ensuring Steam desktop stub exists..."
  771   mkdir -p "${APPLICATIONS}"
  772   touch "${APPLICATIONS}/Steam.desktop" || die "Failed to create Steam.desktop stub."
  773 }
  774 
  775 install_steam_runtime_arm64() {
  776   log_info "Downloading and installing Steam runtime (ARM64)..."
  777   # Keep the existing runtime until the complete staged archive and both library
  778   # links validate. The journal also recovers a process killed between renames.
  779   # This transaction does not cover the separate FEX/client/Proton operations.
  780   if python3 - "${STEAM}" "${RUNTIME_TAR_VERSION_URL}" "${RUNTIME_TAR_BASE}" <<'PY_STEAM_RUNTIME'
  781 import ctypes
  782 import fcntl
  783 import hashlib
  784 import json
  785 import lzma
  786 import os
  787 from pathlib import Path, PurePosixPath
  788 import re
  789 import resource
  790 import shutil
  791 import signal
  792 import stat
  793 import subprocess
  794 import sys
  795 import tarfile
  796 
  797 RUNTIME = "steam-runtime-steamrt-arm64"
  798 LINKS = ("libibus-1.0.so.5", "libva.so.2")
  799 RESERVE = 256 * 1024 * 1024
  800 MAX_ARCHIVE = 2 * 1024 * 1024 * 1024
  801 MAX_EXPANDED = 16 * 1024 * 1024 * 1024
  802 MAX_MEMBERS = 250000
  803 MAX_LINK_BACKUP = 64 * 1024 * 1024
  804 
  805 
  806 def identity(path):
  807     try:
  808         info = path.lstat()
  809     except FileNotFoundError:
  810         return None
  811     if not stat.S_ISDIR(info.st_mode):
  812         raise RuntimeError("Runtime transaction directory is not a real directory: " + str(path))
  813     return [info.st_dev, info.st_ino]
  814 
  815 
  816 def describe(path):
  817     if path.is_symlink():
  818         return {"kind": "link", "target": os.readlink(path)}
  819     if not path.exists():
  820         return {"kind": "absent"}
  821     if not path.is_file():
  822         raise RuntimeError("Refusing to replace a non-file library entry: " + str(path))
  823     info = path.stat()
  824     if info.st_size > MAX_LINK_BACKUP:
  825         raise RuntimeError("Existing library entry exceeds the bounded backup size.")
  826     return {"kind": "file", "sha256": digest(path), "mode": stat.S_IMODE(info.st_mode),
  827             "mtime_ns": info.st_mtime_ns}
  828 
  829 
  830 def digest(path):
  831     with path.open("rb") as stream:
  832         return hashlib.file_digest(stream, "sha256").hexdigest()
  833 
  834 
  835 def capacity(root, needed):
  836     if shutil.disk_usage(root).free < needed + RESERVE:
  837         raise RuntimeError("Not enough free space to keep the previous Steam runtime while replacing it.")
  838 
  839 
  840 def directory(path, device):
  841     if path.is_symlink() or not path.is_dir() or path.stat().st_dev != device:
  842         raise RuntimeError("Runtime update needs real directories on the Steam filesystem: " + str(path))
  843 
  844 
  845 def no_mounts(path):
  846     # st_dev alone misses a bind mount on the same filesystem. Never walk a
  847     # mounted subtree while retiring or rolling back an owned runtime tree.
  848     boundary = path.resolve()
  849     for line in Path("/proc/self/mountinfo").read_text().splitlines():
  850         field = line.split()[4]
  851         mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field))
  852         if mount == boundary or boundary in mount.parents:
  853             raise RuntimeError("Mounted runtime paths must be released before replacement: " + str(path))
  854 
  855 
  856 def validate(runtime):
  857     directory(runtime, runtime.parent.stat().st_dev)
  858     platforms = list(runtime.glob("steamrt3c_platform_*"))
  859     if len(platforms) != 1 or platforms[0].is_symlink() or not platforms[0].is_dir():
  860         raise RuntimeError("Expected one complete Steam ARM64 platform directory.")
  861     targets = {}
  862     for name in LINKS:
  863         matches = list((platforms[0] / "files/lib/aarch64-linux-gnu").glob(name + ".*"))
  864         if len(matches) != 1:
  865             raise RuntimeError("Missing or ambiguous runtime library: " + name)
  866         target = matches[0]
  867         if not target.resolve(strict=True).is_relative_to(runtime.resolve(strict=True)):
  868             raise RuntimeError("Runtime library escapes the staged runtime.")
  869         with target.open("rb") as stream:
  870             header = stream.read(20)
  871         if (len(header) != 20 or header[:6] != b"\x7fELF\x02\x01"
  872                 or header[16:20] != b"\x03\x00\xb7\x00"):
  873             raise RuntimeError("Runtime library is not an ARM64 shared object: " + name)
  874         targets[name] = {"path": str(target.relative_to(runtime)), "sha256": digest(target)}
  875     return targets
  876 
  877 
  878 class RuntimeUpdate:
  879     def __init__(self, root):
  880         self.link_root = Path(os.path.abspath(root))
  881         self.root = root.resolve(strict=True)
  882         if self.root == Path("/"):
  883             raise RuntimeError("Refusing the filesystem root as the Steam directory.")
  884         self.device = self.root.stat().st_dev
  885         self.work = self.root / ".steam-runtime-update"
  886         self.live = self.root / RUNTIME
  887         self.lib = self.root / "lib/aarch64-linux-gnu"
  888         self.state = None
  889 
  890     def write_state(self):
  891         pending = self.work / "state.tmp"
  892         with pending.open("w") as stream:
  893             json.dump(self.state, stream)
  894             stream.flush()
  895             os.fsync(stream.fileno())
  896         os.replace(pending, self.work / "state.json")
  897         fd = os.open(self.work, os.O_RDONLY | os.O_DIRECTORY)
  898         try:
  899             os.fsync(fd)
  900         finally:
  901             os.close(fd)
  902 
  903     def clean(self):
  904         # Keep the journal until all other owned remnants are gone. A killed
  905         # cleanup is retried without accumulating another staging tree.
  906         for child in self.work.iterdir():
  907             if child.name == "state.json":
  908                 continue
  909             if child.is_dir() and not child.is_symlink():
  910                 no_mounts(child)
  911                 shutil.rmtree(child)
  912             else:
  913                 child.unlink()
  914         (self.work / "state.json").unlink(missing_ok=True)
  915         self.work.rmdir()
  916         self.state = None
  917 
  918     def check_parents(self):
  919         for path in (self.root / "lib", self.lib):
  920             if path.exists() or path.is_symlink():
  921                 directory(path, self.device)
  922                 no_mounts(path)
  923 
  924     def recover(self):
  925         if not self.work.exists() and not self.work.is_symlink():
  926             return
  927         directory(self.work, self.device)
  928         journal = self.work / "state.json"
  929         if not journal.exists():
  930             # mkdir can be interrupted before the first journal is written.
  931             # An empty directory is safe to remove; unknown contents are not.
  932             self.work.rmdir()
  933             return
  934         if journal.is_symlink() or not journal.is_file() or journal.stat().st_size > 65536:
  935             raise RuntimeError("Refusing an invalid runtime recovery journal.")
  936         self.state = json.loads(journal.read_text())
  937         if (self.state.get("format") != 1 or self.state.get("root") != str(self.root)
  938                 or self.state.get("link_root") != str(self.link_root)):
  939             raise RuntimeError("Unrecognized runtime recovery journal; retaining it.")
  940         no_mounts(self.work)
  941         phase = self.state["phase"]
  942         if phase in ("prepared", "committed"):
  943             no_mounts(self.live)
  944             if (set(self.state["targets"]) != set(LINKS)
  945                     or set(self.state["links"]) != set(LINKS)
  946                     or any(p not in ("lib/aarch64-linux-gnu", "lib")
  947                            for p in self.state["created_dirs"])):
  948                 raise RuntimeError("Invalid runtime recovery paths; retaining them.")
  949             for target in self.state["targets"].values():
  950                 relative = PurePosixPath(target["path"])
  951                 if relative.is_absolute() or ".." in relative.parts or not relative.parts:
  952                     raise RuntimeError("Invalid runtime recovery target.")
  953         self.check_parents()
  954         if phase == "committed":
  955             if identity(self.live) != self.state["candidate_id"] or validate(self.live) != self.state["targets"]:
  956                 raise RuntimeError("Committed runtime changed; keeping its recovery copy.")
  957             for name in LINKS:
  958                 if describe(self.lib / name) != self.new_link(name):
  959                     raise RuntimeError("Committed library link changed; keeping its recovery copy.")
  960         elif phase == "prepared":
  961             old_id = self.state["old_id"]
  962             live_id = identity(self.live)
  963             backup = self.work / "previous"
  964             if old_id is not None and live_id == old_id:
  965                 pass  # Not activated yet, or rollback was itself interrupted.
  966             else:
  967                 if old_id is not None and identity(backup) != old_id:
  968                     raise RuntimeError("Previous runtime identity changed; no automatic cleanup.")
  969                 if live_id == self.state["candidate_id"]:
  970                     os.replace(self.live, self.work / "discard")
  971                 elif live_id is not None:
  972                     raise RuntimeError("Active runtime identity changed; no automatic cleanup.")
  973                 if old_id is not None:
  974                     os.replace(backup, self.live)
  975             for name in LINKS:
  976                 saved = self.state["links"][name]
  977                 live = self.lib / name
  978                 current = describe(live)
  979                 if current == saved:
  980                     continue
  981                 if current != self.new_link(name):
  982                     raise RuntimeError("Library link changed outside the update; retaining recovery data.")
  983                 if saved["kind"] == "absent":
  984                     live.unlink()
  985                 else:
  986                     restore = self.work / ("restore-" + name)
  987                     restore.unlink(missing_ok=True)
  988                     shutil.copy2(self.work / ("saved-" + name), restore, follow_symlinks=False)
  989                     os.replace(restore, live)
  990             for relative in self.state["created_dirs"]:
  991                 path = self.root / relative
  992                 if path.exists():
  993                     path.rmdir()  # Never remove another writer's contents.
  994         elif phase != "staging":
  995             raise RuntimeError("Unknown runtime recovery phase; retaining it.")
  996         self.clean()
  997 
  998     def new_link(self, name):
  999         return {"kind": "link", "target": str(self.link_root / RUNTIME / self.state["targets"][name]["path"])}
 1000 
 1001     def begin(self):
 1002         self.work.mkdir(mode=0o700)
 1003         self.state = {"format": 1, "root": str(self.root), "link_root": str(self.link_root), "phase": "staging"}
 1004         self.write_state()
 1005         (self.work / "unpack").mkdir()
 1006 
 1007     def prepare(self):
 1008         candidate = self.work / "unpack" / RUNTIME
 1009         targets = validate(candidate)
 1010         self.check_parents()
 1011         links = {name: describe(self.lib / name) for name in LINKS}
 1012         capacity(self.root, sum((self.lib / name).stat().st_size for name in LINKS
 1013                                if links[name]["kind"] == "file"))
 1014         for name in LINKS:
 1015             if links[name]["kind"] != "absent":
 1016                 shutil.copy2(self.lib / name, self.work / ("saved-" + name), follow_symlinks=False)
 1017         old_id = identity(self.live)
 1018         no_mounts(self.live)
 1019         if old_id is not None and old_id[0] != self.device:
 1020             raise RuntimeError("Previous runtime is on a different filesystem.")
 1021         self.state.update(phase="prepared", targets=targets, links=links, old_id=old_id,
 1022                           candidate_id=identity(candidate),
 1023                           created_dirs=[p for p in ("lib/aarch64-linux-gnu", "lib")
 1024                                         if not (self.root / p).exists()])
 1025         self.write_state()  # The complete rollback description precedes every rename.
 1026 
 1027     def activate(self):
 1028         self.lib.mkdir(parents=True, exist_ok=True)
 1029         if self.state["old_id"] is not None:
 1030             os.replace(self.live, self.work / "previous")
 1031         os.replace(self.work / "unpack" / RUNTIME, self.live)
 1032         for name in LINKS:
 1033             pending = self.work / ("new-" + name)
 1034             pending.symlink_to(self.new_link(name)["target"])
 1035             os.replace(pending, self.lib / name)
 1036         if validate(self.live) != self.state["targets"]:
 1037             raise RuntimeError("Activated runtime failed validation.")
 1038         for name in LINKS:
 1039             if describe(self.lib / name) != self.new_link(name) or not (self.lib / name).is_file():
 1040                 raise RuntimeError("Activated runtime library link failed validation.")
 1041         self.state["phase"] = "committed"
 1042         self.write_state()  # Only this point permits retiring the superseded tree.
 1043         self.clean()
 1044 
 1045 
 1046 def fetch_archive(update, version_url, base_url):
 1047     owner_pid = os.getpid()
 1048 
 1049     def child_setup(limit=None):
 1050         # SIGKILL cannot run a Python cleanup handler. Linux must kill the
 1051         # transport child with its owner, before another updater can retry.
 1052         libc = ctypes.CDLL(None, use_errno=True)
 1053         if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:  # PR_SET_PDEATHSIG
 1054             raise OSError(ctypes.get_errno(), "Cannot bind downloader lifetime to installer")
 1055         if os.getppid() != owner_pid:  # Parent may have died before prctl.
 1056             os.kill(os.getpid(), signal.SIGKILL)
 1057         if limit is not None:
 1058             resource.setrlimit(resource.RLIMIT_FSIZE, (limit, limit))
 1059 
 1060     version = subprocess.run(["curl", "-fsSL", "--connect-timeout", "10", "--max-time", "30",
 1061                               "--max-filesize", "128", version_url],
 1062                              check=True, capture_output=True, timeout=35, preexec_fn=child_setup).stdout.decode().strip()
 1063     if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,79}", version):
 1064         raise RuntimeError("Invalid Steam runtime version.")
 1065     capacity(update.root, 1)
 1066     budget = min(MAX_ARCHIVE, shutil.disk_usage(update.root).free - RESERVE)
 1067     archive = update.work / "runtime.tar.xz"
 1068 
 1069     subprocess.run(["wget", "-t", "3", "-T", "30", "-O", str(archive),
 1070                     base_url + "/" + version + "/" + RUNTIME + ".tar.xz"],
 1071                    check=True, timeout=900, preexec_fn=lambda: child_setup(budget))
 1072     return archive
 1073 
 1074 
 1075 def unpack_archive(update, archive):
 1076     # Inspect the complete compressed stream (including its integrity footer)
 1077     # before extraction; never use the live Steam directory as tar's destination.
 1078     needed = 0
 1079     seen = set()
 1080     with lzma.open(archive, "rb") as stream:
 1081         with tarfile.open(fileobj=stream, mode="r|") as archive_stream:
 1082             for member in archive_stream:
 1083                 path = PurePosixPath(member.name)
 1084                 if (path.is_absolute() or ".." in path.parts or not path.parts
 1085                         or path.parts[0] != RUNTIME or path.as_posix() in seen or member.size < 0):
 1086                     raise RuntimeError("Unsafe or duplicate runtime archive path.")
 1087                 if not (member.isfile() or member.isdir() or member.issym() or member.islnk()):
 1088                     raise RuntimeError("Unsupported runtime archive entry.")
 1089                 seen.add(path.as_posix())
 1090                 needed += ((member.size + 4095) // 4096) * 4096 + 8192
 1091                 if len(seen) > MAX_MEMBERS or needed > MAX_EXPANDED:
 1092                     raise RuntimeError("Runtime archive exceeds the bounded extraction budget.")
 1093         while True:
 1094             chunk = stream.read(1024 * 1024)
 1095             if stream.tell() > MAX_EXPANDED:
 1096                 raise RuntimeError("Runtime archive exceeds the decoded-stream budget.")
 1097             if not chunk:
 1098                 break
 1099     capacity(update.root, needed)
 1100     with tarfile.open(archive, "r:xz") as payload:
 1101         payload.extractall(update.work / "unpack", filter="data")
 1102     capacity(update.root, 0)
 1103     archive.unlink()
 1104 
 1105 
 1106 def interrupted(signum, frame):
 1107     raise InterruptedError("Steam runtime update interrupted by signal " + str(signum))
 1108 
 1109 
 1110 def main():
 1111     update = RuntimeUpdate(Path(sys.argv[1]))
 1112     # A persistent lock inode serializes this component; never unlink the lock
 1113     # file while another invocation may have opened it. No service is started.
 1114     lock_path = update.root / ".steam-runtime-update.lock"
 1115     fd = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
 1116     try:
 1117         if not stat.S_ISREG(os.fstat(fd).st_mode):
 1118             raise RuntimeError("Runtime update lock is not a regular file.")
 1119         fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
 1120         for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
 1121             signal.signal(sig, interrupted)
 1122         signal.alarm(1800)
 1123         try:
 1124             update.recover()
 1125             update.check_parents()
 1126             capacity(update.root, 1)
 1127             update.begin()
 1128             archive = fetch_archive(update, sys.argv[2], sys.argv[3])
 1129             unpack_archive(update, archive)
 1130             update.prepare()
 1131             update.activate()
 1132             return 0
 1133         except Exception as error:
 1134             print("Steam runtime replacement failed: " + str(error), file=sys.stderr)
 1135             signal.alarm(0)
 1136             try:
 1137                 update.recover()
 1138             except Exception as recovery_error:
 1139                 print("Runtime recovery needs attention; previous data is retained at "
 1140                       + str(update.work) + ": " + str(recovery_error), file=sys.stderr)
 1141             return 1
 1142         finally:
 1143             signal.alarm(0)
 1144     finally:
 1145         os.close(fd)
 1146 
 1147 
 1148 if __name__ == "__main__":
 1149     sys.exit(main())
 1150 PY_STEAM_RUNTIME
 1151   then
 1152     return 0
 1153   fi
 1154   die "Steam runtime replacement failed. The installer has stopped."
 1155 }
 1156 
 1157 install_steam_client_arm64() {
 1158   if steam_client_state install; then
 1159     return 0
 1160   fi
 1161   die "Steam client setup could not finish. Existing client files were kept."
 1162 }
 1163 
 1164 # The first call inspects only the client tree, before profile side effects.
 1165 # Support metadata uses STEAM_DOT after profiles, preserving that override.
 1166 # A legacy bootstrap check is not native readiness; no old receipt hash is used.
 1167 steam_client_state() {
 1168   /usr/bin/python3 -I -S -B - "$1" "${STEAM_ROOT_PLAN}" "${STEAM_DOT:-}" "${STEAM_CLIENT_PLAN:-}" "${STEAM_CLIENT_METADATA_PLAN:-}" <<'PY_STEAM_CLIENT'
 1169 # SPDX-License-Identifier: GPL-2.0-or-later
 1170 # Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
 1171 # #582: structure is a bootstrap check, never native readiness or account proof.
 1172 import ctypes
 1173 import errno
 1174 import fcntl
 1175 import hashlib
 1176 import json
 1177 import os
 1178 from pathlib import Path
 1179 import re
 1180 import resource
 1181 import selectors
 1182 import signal
 1183 import stat
 1184 import struct
 1185 import subprocess
 1186 import sys
 1187 import time
 1188 import zlib
 1189 
 1190 CLIENT = "steamrtarm64"
 1191 WORK = ".steam-client-update"
 1192 LOCK = ".steam-client-update.lock"
 1193 MAX_ZIP = 128 * 1024**2
 1194 MAX_OUTPUT = 384 * 1024**2
 1195 MAX_MEMBER = 128 * 1024**2
 1196 MAX_JOURNAL = 2 * 1024**2
 1197 RESERVE = 64 * 1024**2
 1198 CORE = ("steam", "steamclient.so", "libtier0_s.so", "libvstdlib_s.so")
 1199 NAME_MAP = {
 1200     "steamrtarm64\\libs/": "steamrtarm64/libs/",
 1201     "steamrtarm64\\swiftshader/": "steamrtarm64/swiftshader/",
 1202     "steamrtarm64\\libs\\libcurl.so": "steamrtarm64/libs/libcurl.so",
 1203     "steamrtarm64\\libs\\libnghttp2.so": "steamrtarm64/libs/libnghttp2.so",
 1204     "steamrtarm64\\libs\\libnghttp2.so.14": "steamrtarm64/libs/libnghttp2.so.14",
 1205 }
 1206 # Filled from the accepted 55-member format, not from a moving remote filename.
 1207 EXPECTED = {'steamrtarm64/libs/': 'directory',
 1208  'steamrtarm64/swiftshader/': 'directory',
 1209  'steamrtarm64/builddate.txt': 'file',
 1210  'steamrtarm64/chromehtml.so': 'file',
 1211  'steamrtarm64/crashhandler.so': 'file',
 1212  'steamrtarm64/filesystem_stdio.so': 'file',
 1213  'steamrtarm64/fossilize_replay': 'file',
 1214  'steamrtarm64/friendsui.so': 'file',
 1215  'steamrtarm64/gameoverlayrenderer.so': 'file',
 1216  'steamrtarm64/gameoverlayui': 'file',
 1217  'steamrtarm64/gameoverlayui.so': 'file',
 1218  'steamrtarm64/gldriverquery': 'file',
 1219  'steamrtarm64/icudtl.dat': 'file',
 1220  'steamrtarm64/libVkLayer_khronos_validation.so': 'file',
 1221  'steamrtarm64/libVkLayer_steam_fossilize.so': 'file',
 1222  'steamrtarm64/libaom.so.3': 'file',
 1223  'steamrtarm64/libaudio.so': 'file',
 1224  'steamrtarm64/libdav1d.so.6': 'file',
 1225  'steamrtarm64/libmiles.so': 'file',
 1226  'steamrtarm64/libminigbm.so': 'file',
 1227  'steamrtarm64/libopenvr_api.so': 'file',
 1228  'steamrtarm64/libpulsecommon-10.0.so': 'file',
 1229  'steamrtarm64/libs/libcurl.so': 'link',
 1230  'steamrtarm64/libs/libcurl.so.4.8.0': 'file',
 1231  'steamrtarm64/libs/libnghttp2.so': 'link',
 1232  'steamrtarm64/libs/libnghttp2.so.14': 'link',
 1233  'steamrtarm64/libs/libnghttp2.so.14.20.1': 'file',
 1234  'steamrtarm64/libsdkencryptedappticket.so': 'file',
 1235  'steamrtarm64/libtier0_s.so': 'file',
 1236  'steamrtarm64/libvideo.so': 'file',
 1237  'steamrtarm64/libvk_swiftshader.so': 'file',
 1238  'steamrtarm64/libvstdlib_s.so': 'file',
 1239  'steamrtarm64/libvulkan.so': 'file',
 1240  'steamrtarm64/libvulkan.so.1': 'file',
 1241  'steamrtarm64/reaper': 'file',
 1242  'steamrtarm64/steam': 'file',
 1243  'steamrtarm64/steam_monitor': 'file',
 1244  'steamrtarm64/steamclient.so': 'file',
 1245  'steamrtarm64/steamerrorreporter': 'file',
 1246  'steamrtarm64/steamoverlayvulkanlayer.so': 'file',
 1247  'steamrtarm64/steamservice.so': 'file',
 1248  'steamrtarm64/steamsysinfo': 'file',
 1249  'steamrtarm64/steamui.so': 'file',
 1250  'steamrtarm64/steamwebhelper': 'file',
 1251  'steamrtarm64/steamwebhelper.sh': 'file',
 1252  'steamrtarm64/streaming_client': 'file',
 1253  'steamrtarm64/swiftshader/libEGL.so': 'file',
 1254  'steamrtarm64/swiftshader/libEGL.so.TOC': 'file',
 1255  'steamrtarm64/swiftshader/libGLESv2.so': 'file',
 1256  'steamrtarm64/swiftshader/libGLESv2.so.TOC': 'file',
 1257  'steamrtarm64/v8_context_snapshot.bin': 'file',
 1258  'steamrtarm64/vgui2_s.so': 'file',
 1259  'steamrtarm64/vgui_panel_zoo': 'file',
 1260  'steamrtarm64/vk_swiftshader_icd.json': 'file',
 1261  'steamrtarm64/vulkandriverquery': 'file'}
 1262 EXECUTABLES = {
 1263     "steam", "steam_monitor", "steamerrorreporter", "steamwebhelper",
 1264     "steamwebhelper.sh", "gldriverquery", "vulkandriverquery",
 1265     "steamsysinfo", "fossilize_replay", "gameoverlayui",
 1266 }
 1267 LIBC = ctypes.CDLL(None, use_errno=True)
 1268 
 1269 
 1270 def need(ok, text):
 1271     if not ok:
 1272         raise RuntimeError(text)
 1273 
 1274 
 1275 def identity(path):
 1276     try:
 1277         s = path.lstat()
 1278     except FileNotFoundError:
 1279         return None
 1280     return [s.st_dev, s.st_ino, stat.S_IFMT(s.st_mode)]
 1281 
 1282 
 1283 def directory(path):
 1284     fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
 1285     try:
 1286         for part in path.parts[1:]:
 1287             child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
 1288             os.close(fd)
 1289             fd = child
 1290         return fd
 1291     except BaseException:
 1292         os.close(fd)
 1293         raise
 1294 
 1295 
 1296 def open_file(path, flags=os.O_RDONLY, mode=0o600):
 1297     parent = directory(path.parent)
 1298     try:
 1299         return os.open(path.name, flags | os.O_NOFOLLOW | os.O_NONBLOCK, mode, dir_fd=parent)
 1300     finally:
 1301         os.close(parent)
 1302 
 1303 
 1304 def read_file(path, maximum):
 1305     fd = open_file(path)
 1306     try:
 1307         before = os.fstat(fd)
 1308         need(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, "Unexpected or oversized file: " + str(path))
 1309         with os.fdopen(fd, "rb", closefd=False) as stream:
 1310             data = stream.read(maximum + 1)
 1311         after = os.fstat(fd)
 1312         need(len(data) <= maximum and stamp(before) == stamp(after), "File changed during inspection.")
 1313         return data
 1314     finally:
 1315         os.close(fd)
 1316 
 1317 
 1318 def stamp(s):
 1319     return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns]
 1320 
 1321 
 1322 def fingerprint(path):
 1323     fd = open_file(path)
 1324     try:
 1325         s = os.fstat(fd)
 1326         need(stat.S_ISREG(s.st_mode), "Expected a regular file: " + str(path))
 1327         return stamp(s)
 1328     finally:
 1329         os.close(fd)
 1330 
 1331 
 1332 def elf(path, executable=False):
 1333     # Bounded header/program-table reads. No loader, execution, ldd, or full-file
 1334     # receipt comparison: legitimate self-updates may change every file digest.
 1335     fd = open_file(path)
 1336     try:
 1337         before = os.fstat(fd)
 1338         need(stat.S_ISREG(before.st_mode) and before.st_size >= 64, "A core Steam file is missing or incomplete.")
 1339         header = os.pread(fd, 64, 0)
 1340         need(len(header) == 64 and header[:7] == b"\x7fELF\x02\x01\x01", "A core Steam file is not an ARM64 ELF.")
 1341         _, kind, machine, version, entry, phoff, _, _, ehsize, phsize, count, _, _, _ = struct.unpack("<16sHHIQQQIHHHHHH", header)
 1342         need(machine == 183 and version == 1 and kind in (2, 3) and (executable or kind == 3), "A core Steam file has an unsupported architecture or type.")
 1343         need(ehsize == 64 and phsize == 56 and 0 < count <= 128 and phoff >= 64
 1344              and phoff + count * 56 <= before.st_size, "A core Steam program table is incomplete.")
 1345         raw = os.pread(fd, count * 56, phoff)
 1346         need(len(raw) == count * 56, "A core Steam program table could not be read.")
 1347         loads = []
 1348         for i in range(count):
 1349             typ, flags, offset, address, _, filesz, memsz, align = struct.unpack_from("<IIQQQQQQ", raw, i * 56)
 1350             need(offset <= before.st_size and filesz <= before.st_size - offset, "A core Steam segment exceeds its file.")
 1351             if typ == 1:
 1352                 need(filesz <= memsz and (align in (0, 1) or align & (align - 1) == 0)
 1353                      and (align in (0, 1) or offset % align == address % align), "A core Steam load segment is invalid.")
 1354                 loads.append((flags, address, memsz))
 1355         need(loads, "A core Steam file has no load segment.")
 1356         if executable:
 1357             need(before.st_mode & 0o111 and entry > 0
 1358                  and any(flags & 1 and address <= entry < address + size for flags, address, size in loads),
 1359                  "The Steam bootstrap entrypoint is not executable.")
 1360         need(stamp(before) == stamp(os.fstat(fd)), "A core Steam file changed during inspection.")
 1361         return stamp(before)
 1362     finally:
 1363         os.close(fd)
 1364 
 1365 
 1366 def bootstrap(root):
 1367     path = root / CLIENT
 1368     ident = identity(path)
 1369     need(ident is not None and ident[2] == stat.S_IFDIR, "The existing Steam client folder is ambiguous.")
 1370     fd = directory(path)
 1371     os.close(fd)
 1372     result = {"directory": ident, "core": {}}
 1373     for name in CORE:
 1374         result["core"][name] = elf(path / name, name == "steam")
 1375     return result
 1376 
 1377 
 1378 def mounts_below(path):
 1379     raw = read_file(Path("/proc") / str(os.getpid()) / "mountinfo", 1024**2)
 1380     # proc regular files have size 0; read_file bounds bytes rather than trusting it.
 1381     for line in raw.decode().splitlines():
 1382         point = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), line.split()[4]))
 1383         need(point != path and path not in point.parents, "A client transaction path has a mounted subtree.")
 1384 
 1385 
 1386 def mount_rows():
 1387     raw = read_file(Path("/proc") / str(os.getpid()) / "mountinfo", 1024**2)
 1388     result = {}
 1389     for line in raw.decode().splitlines():
 1390         fields = line.split()
 1391         separator = fields.index("-")
 1392         need(separator >= 6 and len(fields) == separator + 4, "Storage mounts could not be inspected.")
 1393         point = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), fields[4])
 1394         result.setdefault(point, []).append(fields)
 1395     return result
 1396 
 1397 
 1398 def available(path):
 1399     rows = mount_rows()
 1400     required = [Path("/storage")]
 1401     for p in (Path("/storage/games-external"), Path("/storage/roms")):
 1402         if path == p or p in path.parents:
 1403             required.append(p)
 1404     media = Path("/var/media")
 1405     if media in path.parents:
 1406         required.append(media / path.relative_to(media).parts[0])
 1407     covers = [Path(p) for p in rows if path == Path(p) or Path(p) in path.parents]
 1408     need(covers, "The Steam support storage is unavailable.")
 1409     required.append(max(covers, key=lambda p: len(p.parts)))
 1410     result = {}
 1411     for p in set(required):
 1412         found = rows.get(str(p), [])
 1413         need(p != Path("/") and len(found) == 1 and "rw" in found[0][5].split(",")
 1414              and "rw" in found[0][-1].split(","), "The Steam support storage is unavailable or read-only.")
 1415         result[str(p)] = found[0]
 1416     return result
 1417 
 1418 
 1419 def bindings(plan, root, require_root=False):
 1420     current_mounts = mount_rows()
 1421     need(all(current_mounts.get(point) == [fields] for point, fields in plan["mounts"].items()),
 1422          "The Steam storage mount changed.")
 1423     for key in ("root", "target"):
 1424         for row in plan.get(key, {}).get("entries", []):
 1425             path = Path(row[0])
 1426             s = path.lstat()
 1427             now = [str(path), s.st_dev, s.st_ino, s.st_mode]
 1428             if stat.S_ISLNK(s.st_mode):
 1429                 now.append(os.readlink(path))
 1430             need(now == row, "The Steam storage path changed.")
 1431     if require_root:
 1432         need(Path(plan["steam"]).resolve(strict=True) == root, "The Steam storage destination changed.")
 1433         fd = directory(root)
 1434         os.close(fd)
 1435 
 1436 
 1437 def consumers(root):
 1438     # A visible installer lock is not a lock on Steam's independent updater.
 1439     # Refuse an observed client; do not kill it or claim this scan eliminates races.
 1440     for p in Path("/proc").iterdir():
 1441         if not p.name.isdecimal() or int(p.name) == os.getpid():
 1442             continue
 1443         try:
 1444             exe = os.readlink(p / "exe").removesuffix(" (deleted)")
 1445             fd = os.open(p / "cmdline", os.O_RDONLY | os.O_NOFOLLOW)
 1446             try:
 1447                 cmd = os.read(fd, 4096).split(b"\0", 1)[0].decode(errors="replace")
 1448             finally:
 1449                 os.close(fd)
 1450         except (FileNotFoundError, ProcessLookupError):
 1451             continue
 1452         except PermissionError as error:
 1453             raise RuntimeError("Steam processes could not be checked safely.") from error
 1454         paths = (root / CLIENT, Path(plan_global["steam"]) / CLIENT)
 1455         need(not any(exe == str(x) or exe.startswith(str(x) + "/") or cmd.startswith(str(x) + "/") for x in paths),
 1456              "Close Steam before installing it again.")
 1457 
 1458 
 1459 def journal_schema(rows, root):
 1460     header = rows[0]
 1461     need(header.get("op") == "header" and header.get("policy") == "arm64-bootstrap-55-v2",
 1462          "Unsupported client ownership policy was kept.")
 1463     work = root / WORK
 1464     need(stat.S_IMODE(work.lstat().st_mode) == 0o700
 1465          and work.lstat().st_uid == os.geteuid()
 1466          and (work / "owner.jsonl").lstat().st_nlink == 1, "Client staging ownership is ambiguous.")
 1467     meta = header["metadata"]
 1468     committed = any(row["op"] == "committed" for row in rows)
 1469     physical = Path(meta["dot"]["path"])
 1470     if not committed:
 1471         dot = probe_directory(header["dot"])
 1472         need(dot["path"] == str(physical), "The previous support destination changed.")
 1473         check_probe(meta["dot"])
 1474         need(available(physical) == meta["mounts"], "The previous support storage changed.")
 1475     need(physical != root and physical not in root.parents and root not in physical.parents
 1476          and physical not in (Path("/storage"), Path("/var/media"), Path("/"))
 1477          and (physical.is_relative_to("/storage") or physical.is_relative_to("/var/media")),
 1478          "Unsupported client metadata ownership.")
 1479     specifications = [
 1480         (str(root / "package"), "directory", None),
 1481         (str(root / "package/beta"), "file", "7075626c6963626574610a"),
 1482         (str(physical), "directory", None),
 1483         (str(physical / "steam"), "link", plan_global["steam"]),
 1484         (str(physical / "sdkarm64"), "link", str(Path(plan_global["steam"]) / "linuxarm64")),
 1485     ]
 1486     need([(n["path"], n["kind"], n["value"]) for n in meta["nodes"]] == specifications,
 1487          "Unexpected client metadata plan was kept.")
 1488     stage_allowed = {"archive": "file", "manifest": "file", "payload": "directory"}
 1489     for name, kind in EXPECTED.items():
 1490         stage_allowed["payload/" + name.rstrip("/")] = kind
 1491         for p in Path(name.rstrip("/")).parents:
 1492             if str(p) != ".":
 1493                 stage_allowed["payload/" + str(p)] = "directory"
 1494     external_allowed = {name: (kind, value) for name, kind, value in specifications}
 1495     for node in meta["nodes"]:
 1496         path = Path(node["path"]).parent
 1497         # Extra parents may be created only along the saved absent-dot path,
 1498         # below a pre-existing, identity-bound ancestor.
 1499         known_dirs = {row[0] for row in meta["dot"]["entries"]}
 1500         while path != Path("/") and str(path) not in known_dirs and path != root:
 1501             if physical == path or path in physical.parents:
 1502                 external_allowed[str(path)] = ("directory", None)
 1503             path = path.parent
 1504     seen_stage, seen_external = set(), set()
 1505     active_transfer = None
 1506     transfer_count = 0
 1507     for row in rows[1:]:
 1508         op = row["op"]
 1509         if op == "transfer-start":
 1510             transfer_count += 1
 1511             need(active_transfer is None and transfer_count <= 2
 1512                  and row.get("serial") == transfer_count, "Ambiguous transfer ownership record.")
 1513             active_transfer = transfer_count
 1514         elif op == "transfer-stopped":
 1515             need(active_transfer is not None and row.get("serial") == active_transfer,
 1516                  "Unmatched transfer quiescence record.")
 1517             active_transfer = None
 1518         elif op == "stage":
 1519             name = row["path"]
 1520             need(name in stage_allowed and name not in seen_stage and row["kind"] == stage_allowed[name],
 1521                  "Unrecognized stage ownership record.")
 1522             seen_stage.add(name)
 1523         elif op == "external":
 1524             name = row["path"]
 1525             need(name in external_allowed and name not in seen_external
 1526                  and (row["kind"], row["value"]) == external_allowed[name], "Unrecognized metadata ownership record.")
 1527             seen_external.add(name)
 1528         elif op == "intent":
 1529             need(all(n["path"] in external_allowed and (n["kind"], n["value"]) == external_allowed[n["path"]]
 1530                      for n in row["nodes"]), "Unrecognized metadata creation intent.")
 1531         elif op == "prepared":
 1532             need(isinstance(row["tree"], dict) and len(row["tree"]) <= 256
 1533                  and all(not Path(p).is_absolute() and ".." not in Path(p).parts for p in row["tree"]),
 1534                  "Unrecognized prepared client inventory.")
 1535         else:
 1536             need(op in ("publishing", "committed", "failure"), "Unexpected client phase.")
 1537         if op in ("stage", "external"):
 1538             ident = row["id"]
 1539             kind = {"file": stat.S_IFREG, "directory": stat.S_IFDIR, "link": stat.S_IFLNK}[row["kind"]]
 1540             need(isinstance(ident, list) and len(ident) == 3
 1541                  and all(type(v) is int for v in ident) and ident[2] == kind,
 1542                  "Malformed client node identity.")
 1543 
 1544 
 1545 def load_journal(work, root):
 1546     need(identity(work) is not None and identity(work)[2] == stat.S_IFDIR, "Unknown client staging state was kept.")
 1547     mounts_below(work)
 1548     raw = read_file(work / "owner.jsonl", MAX_JOURNAL)
 1549     need(raw.endswith(b"\n"), "An interrupted client journal was kept for review.")
 1550     lines = raw.splitlines(keepends=True)
 1551     need(lines and lines[0].endswith(b"\n"), "Incomplete client ownership record was kept.")
 1552     rows = [json.loads(line) for line in lines if line.endswith(b"\n")]
 1553     h = rows[0]
 1554     need(h.get("format") == 1 and h.get("root") == str(root)
 1555          and h.get("root_id") == identity(root) and h.get("work_id") == identity(work)
 1556          and h.get("journal_id") == identity(work / "owner.jsonl"), "Client ownership changed; existing state was kept.")
 1557     need(len(rows) <= 512 and all(isinstance(row, dict) for row in rows), "Unsupported client ownership record.")
 1558     allowed = {"header", "stage", "external", "intent", "prepared", "publishing", "committed", "failure", "transfer-start", "transfer-stopped"}
 1559     need(all(row.get("op") in allowed for row in rows), "Unknown client transaction phase was kept.")
 1560     journal_schema(rows, root)
 1561     tx = Transaction(root, h["dot"], h["metadata"], rows)
 1562     tx.check_owned_state()
 1563     if any(row["op"] == "committed" for row in rows):
 1564         bootstrap(root)  # A committed client's updater may legitimately change bytes.
 1565     elif tx.published():
 1566         need(tx.tree(root / CLIENT) == tx.prepared()["tree"], "An uncommitted published client changed; it was kept.")
 1567     return rows
 1568 
 1569 
 1570 def inspect_tree(plan, root, check_lock=True):
 1571     bindings(plan, root)
 1572     consumers(root)
 1573     if check_lock and identity(root / LOCK) is not None:
 1574         fd = open_file(root / LOCK)
 1575         try:
 1576             need(stat.S_ISREG(os.fstat(fd).st_mode), "The client lock is ambiguous.")
 1577             fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
 1578             fcntl.flock(fd, fcntl.LOCK_UN)
 1579         finally:
 1580             os.close(fd)
 1581     work = root / WORK
 1582     if identity(work) is not None:
 1583         rows = load_journal(work, root)
 1584         # Recovery runs later under the lock. This read-only branch does not
 1585         # bless an existing directory as installed, or normalize old contents.
 1586         return {"kind": "recovery", "root": str(root), "work_id": identity(work),
 1587                 "journal_id": identity(work / "owner.jsonl"), "dot": rows[0]["dot"],
 1588                 "committed": any(row["op"] == "committed" for row in rows)}
 1589     if identity(root / CLIENT) is not None:
 1590         return {"kind": "existing", "root": str(root), "bootstrap": bootstrap(root)}
 1591     for name in ("linuxarm64.zip", "steamrtarm64\\libs", "steamrtarm64\\swiftshader",
 1592                  "steamrtarm64\\libs\\libcurl.so", "steamrtarm64\\libs\\libnghttp2.so", "steamrtarm64\\libs\\libnghttp2.so.14"):
 1593         need(identity(root / name) is None, "An earlier Steam download is incomplete. Its files were kept.")
 1594     return {"kind": "fresh", "root": str(root)}
 1595 
 1596 
 1597 def probe_directory(value):
 1598     path = Path(value)
 1599     need(path.is_absolute() and str(path) == os.path.normpath(value) and not value.startswith("//")
 1600          and not any(ord(c) < 32 for c in value), "The Steam support folder path is ambiguous.")
 1601     entries = []
 1602     current = Path("/")
 1603     pending = list(path.parts[1:])
 1604     links = 0
 1605     while pending:
 1606         part = pending.pop(0)
 1607         if part in ("", "."):
 1608             continue
 1609         if part == "..":
 1610             current = current.parent
 1611             continue
 1612         candidate = current / part
 1613         ident = identity(candidate)
 1614         if ident is None:
 1615             need(".." not in pending, "A missing support folder precedes a parent traversal.")
 1616             return {"input": value, "path": str(candidate.joinpath(*pending)), "entries": entries, "exists": False}
 1617         s = candidate.lstat()
 1618         row = [str(candidate), *ident]
 1619         if stat.S_ISLNK(s.st_mode):
 1620             links += 1
 1621             need(links <= 40, "The Steam support folder has too many links.")
 1622             target = os.readlink(candidate)
 1623             need(target and not any(ord(c) < 32 for c in target), "The Steam support folder link is ambiguous.")
 1624             row.append(target)
 1625             entries.append(row)
 1626             # Resolve each target component before applying any following '..'.
 1627             # Lexical normpath would erase a preceding directory symlink.
 1628             pending = target.split("/") + pending
 1629             if target.startswith("/"):
 1630                 current = Path("/")
 1631         else:
 1632             need(stat.S_ISDIR(s.st_mode), "A file is blocking the Steam support folder.")
 1633             entries.append(row)
 1634             current = candidate
 1635     return {"input": value, "path": str(current), "entries": entries, "exists": True}
 1636 
 1637 
 1638 def check_probe(probe):
 1639     for row in probe["entries"]:
 1640         path = Path(row[0])
 1641         now = [str(path), *(identity(path) or [])]
 1642         if path.is_symlink():
 1643             now.append(os.readlink(path))
 1644         need(now == row, "The Steam support folder changed.")
 1645     need(probe_directory(probe["input"])["path"] == probe["path"],
 1646          "The logical Steam support destination changed.")
 1647 
 1648 
 1649 def describe(path):
 1650     ident = identity(path)
 1651     if ident is None:
 1652         return None
 1653     if ident[2] == stat.S_IFLNK:
 1654         return {"id": ident, "target": os.readlink(path)}
 1655     if ident[2] == stat.S_IFREG:
 1656         return {"id": ident, "bytes": read_file(path, 4096).hex(), "stamp": fingerprint(path)}
 1657     need(ident[2] == stat.S_IFDIR, "Unsupported Steam metadata entry.")
 1658     return {"id": ident}
 1659 
 1660 
 1661 def metadata(root, dot_value, tree):
 1662     dot = probe_directory(dot_value)
 1663     physical = Path(dot["path"])
 1664     need(physical not in (Path("/"), Path("/storage"), Path("/var/media")) and physical != root and root not in physical.parents
 1665          and physical not in root.parents, "The Steam support folder overlaps client storage.")
 1666     # Preserve profile-selected paths, but require them on available /storage or
 1667     # /var/media storage. Root-path/mount admission remains the shared root helper.
 1668     need(physical.is_relative_to("/storage") or physical.is_relative_to("/var/media"), "The Steam support folder is outside supported storage.")
 1669     if tree["kind"] == "existing":
 1670         need(dot["exists"], "The existing client support folder is missing. Existing files were kept.")
 1671     nodes = [
 1672         (root / "package", "directory", None),
 1673         (root / "package/beta", "file", "7075626c6963626574610a"),
 1674         (physical, "directory", None),
 1675         (physical / "steam", "link", plan_global["steam"]),
 1676         (physical / "sdkarm64", "link", str(Path(plan_global["steam"]) / "linuxarm64")),
 1677     ]
 1678     result = {"dot": dot, "mounts": available(physical), "nodes": []}
 1679     for path, kind, value in nodes:
 1680         before = describe(path)
 1681         if before is not None:
 1682             if kind == "directory":
 1683                 need(before["id"][2] == stat.S_IFDIR, "A Steam metadata directory is blocked.")
 1684             elif tree["kind"] == "fresh":
 1685                 equal = before.get("bytes") == value if kind == "file" else (
 1686                     "target" in before and os.path.realpath(path) == os.path.realpath(value))
 1687                 need(equal, "Existing Steam support settings were kept. Fresh setup cannot replace them.")
 1688             elif kind == "file":
 1689                 need(before["id"][2] == stat.S_IFREG, "The existing Steam channel entry is ambiguous.")
 1690             else:
 1691                 need(before["id"][2] == stat.S_IFLNK, "An existing Steam support alias is ambiguous.")
 1692             # Existing client channels and aliases belong to Steam/the player:
 1693             # inspect their types but neither replace them nor assert readiness.
 1694         result["nodes"].append({"path": str(path), "kind": kind, "value": value, "before": before})
 1695     return result
 1696 
 1697 
 1698 def same_metadata(saved, root, dot, tree):
 1699     current = metadata(root, dot, tree)
 1700     need(current == saved, "Steam support settings changed during installation.")
 1701     check_probe(saved["dot"])
 1702 
 1703 
 1704 def digest_file(path, maximum):
 1705     fd = open_file(path)
 1706     try:
 1707         s = os.fstat(fd)
 1708         need(stat.S_ISREG(s.st_mode) and s.st_size <= maximum, "Unexpected client file size or type.")
 1709         h = hashlib.sha256()
 1710         with os.fdopen(fd, "rb", closefd=False) as stream:
 1711             while chunk := stream.read(65536):
 1712                 h.update(chunk)
 1713         need(stamp(s) == stamp(os.fstat(fd)), "A client file changed during validation.")
 1714         return h.hexdigest()
 1715     finally:
 1716         os.close(fd)
 1717 
 1718 
 1719 def manifest(raw):
 1720     need(len(raw) <= 2 * 1024**2, "Steam manifest exceeded its limit.")
 1721     text = raw.decode("ascii")
 1722     tokens, end = [], 0
 1723     for match in re.finditer(r'"(?:[^"\\]|\\.)*"|[{}]', text):
 1724         need(not text[end:match.start()].strip(), "Unrecognized Steam manifest syntax.")
 1725         tokens.append(match.group())
 1726         end = match.end()
 1727     need(not text[end:].strip() and len(tokens) < 5000, "Steam manifest exceeded its syntax limits.")
 1728     pos = 0
 1729     def obj(depth=0):
 1730         nonlocal pos
 1731         need(depth < 8, "Steam manifest nesting exceeded its limit.")
 1732         result = {}
 1733         while pos < len(tokens) and tokens[pos] != "}":
 1734             key = json.loads(tokens[pos])
 1735             pos += 1
 1736             need(isinstance(key, str) and key not in result and pos < len(tokens), "Ambiguous Steam manifest key.")
 1737             token = tokens[pos]
 1738             pos += 1
 1739             if token == "{":
 1740                 result[key] = obj(depth + 1)
 1741                 need(pos < len(tokens) and tokens[pos] == "}", "Incomplete Steam manifest.")
 1742                 pos += 1
 1743             else:
 1744                 result[key] = json.loads(token)
 1745         return result
 1746     tree = obj()
 1747     need(pos == len(tokens), "Trailing Steam manifest data.")
 1748     selected = tree["linuxarm64"]["bins_linuxarm64_linuxarm64"]
 1749     name, checksum, size = selected["file"], selected["sha2"], selected["size"]
 1750     need(isinstance(name, str) and re.fullmatch(r"bins_linuxarm64_linuxarm64\.zip\.[0-9a-f]{40}", name)
 1751          and isinstance(checksum, str) and re.fullmatch(r"[0-9a-f]{64}", checksum)
 1752          and isinstance(size, str) and re.fullmatch(r"[0-9]{1,9}", size), "Unsupported Steam package selection.")
 1753     size = int(size)
 1754     need(22 <= size <= MAX_ZIP, "Steam client archive exceeds the supported size.")
 1755     return name, checksum, size
 1756 
 1757 
 1758 def process_identity(pid):
 1759     path = Path("/proc") / str(pid)
 1760     try:
 1761         raw = read_file(path / "stat", 16384).decode()
 1762     except (FileNotFoundError, ProcessLookupError):
 1763         # A disappeared PID is a normal race. A present PID with unreadable stat
 1764         # is a visibility failure, never evidence of an empty process census.
 1765         need(identity(path) is None, "A live process identity could not be read.")
 1766         return None
 1767     prefix, separator, suffix = raw.rpartition(")")
 1768     fields = suffix.split()
 1769     need(separator and prefix.startswith(str(pid) + " (") and len(fields) >= 20,
 1770          "Malformed process identity; client state was kept.")
 1771     ppid, start = int(fields[1]), int(fields[19])
 1772     need(ppid >= 0 and start >= 0, "Invalid process owner or start time.")
 1773     return {"pid": pid, "ppid": ppid, "start_ticks": start}
 1774 
 1775 
 1776 def direct_children(deadline):
 1777     # /proc/PID/task/PID/children is optional on the target kernel. The numeric
 1778     # stat census is the already-used PPID/start-time contract instead.
 1779     owner = os.getpid()
 1780     result, seen_owner, count = [], False, 0
 1781     for path in Path("/proc").iterdir():
 1782         if not path.name.isdecimal():
 1783             continue
 1784         count += 1
 1785         need(count <= 65536 and time.monotonic() < deadline, "Process census exceeded its bound.")
 1786         row = process_identity(int(path.name))
 1787         if row is not None:
 1788             seen_owner |= row["pid"] == owner
 1789             if row["ppid"] == owner:
 1790                 result.append(row)
 1791     need(seen_owner, "Process census does not show this supervisor.")
 1792     return result
 1793 
 1794 
 1795 def terminate_group(proc):
 1796     # Always retire the group, including successful drivers' leftover children.
 1797     # The helper is a subreaper: orphaned setsid descendants become its children.
 1798     try:
 1799         os.killpg(proc.pid, signal.SIGKILL)
 1800     except ProcessLookupError:
 1801         pass
 1802     proc.wait(timeout=5)
 1803     deadline = time.monotonic() + 5
 1804     while True:
 1805         try:
 1806             pid, _ = os.waitpid(-1, os.WNOHANG)
 1807         except ChildProcessError:
 1808             return  # Kernel ECHILD after the leader was reaped is quiescence.
 1809         need(time.monotonic() < deadline, "A client transfer child did not retire.")
 1810         if pid:
 1811             continue
 1812         for row in direct_children(deadline):
 1813             need(time.monotonic() < deadline, "Transfer child cleanup exceeded its bound.")
 1814             try:
 1815                 pfd = os.pidfd_open(row["pid"], 0)
 1816             except ProcessLookupError:
 1817                 continue
 1818             try:
 1819                 current = process_identity(row["pid"])
 1820                 if current is None:
 1821                     continue
 1822                 need(current == row and current["ppid"] == os.getpid(),
 1823                      "A transfer child identity changed; client state was kept.")
 1824                 try:
 1825                     signal.pidfd_send_signal(pfd, signal.SIGKILL)
 1826                 except ProcessLookupError:
 1827                     pass
 1828             finally:
 1829                 os.close(pfd)
 1830         time.sleep(0.01)
 1831 
 1832 
 1833 def transfer(url, fd, limit, seconds, quiescent):
 1834     argv = ["curl", "--disable", "--fail", "--silent", "--show-error", "--location",
 1835             "--proto", "=https", "--proto-redir", "=https", "--max-redirs", "5",
 1836             "--connect-timeout", "10", "--max-time", str(seconds),
 1837             "--max-filesize", str(limit), "--output", "-", url]
 1838     parent = os.getpid()
 1839     def child_limits():
 1840         resource.setrlimit(resource.RLIMIT_FSIZE, (limit, limit))
 1841         if LIBC.prctl(1, signal.SIGKILL, 0, 0, 0) or os.getppid() != parent:
 1842             os._exit(125)
 1843     proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=fd, stderr=subprocess.PIPE,
 1844                             start_new_session=True, preexec_fn=child_limits)
 1845     errors = bytearray()
 1846     deadline = time.monotonic() + seconds + 2
 1847     selector = None
 1848     try:
 1849         selector = selectors.DefaultSelector()
 1850         selector.register(proc.stderr, selectors.EVENT_READ)
 1851         while selector.get_map():
 1852             need(time.monotonic() < deadline, "Steam client transfer timed out.")
 1853             for key, _ in selector.select(0.1):
 1854                 block = os.read(key.fd, 8192)
 1855                 if not block:
 1856                     selector.unregister(key.fileobj)
 1857                 else:
 1858                     errors.extend(block)
 1859                     need(len(errors) <= 65536, "Steam client transfer log exceeded its limit.")
 1860         code = proc.wait(timeout=max(0.01, deadline - time.monotonic()))
 1861         need(code == 0, "Steam client transfer failed (exit " + str(code) + ").")
 1862         os.fsync(fd)
 1863     finally:
 1864         try:
 1865             if selector is not None:
 1866                 selector.close()
 1867             proc.stderr.close()
 1868         finally:
 1869             terminate_group(proc)
 1870             # An exception, visibility gap or deadline before ECHILD must leave
 1871             # a durable unmatched transfer-start. Never authorize stage cleanup.
 1872             quiescent()
 1873 
 1874 
 1875 def rename_new(source, target):
 1876     a, b = directory(source.parent), directory(target.parent)
 1877     try:
 1878         need(LIBC.renameat2(a, os.fsencode(source.name), b, os.fsencode(target.name), 1) == 0,
 1879              "The new Steam client could not be published without replacing an existing path.")
 1880         os.fsync(a)
 1881         os.fsync(b)
 1882     finally:
 1883         os.close(a)
 1884         os.close(b)
 1885 
 1886 
 1887 class Transaction:
 1888     def __init__(self, root, dot, meta, rows=None):
 1889         self.root, self.work, self.dot, self.meta = root, root / WORK, dot, meta
 1890         self.rows = rows or []
 1891         self.journal = None
 1892 
 1893     def append(self, row):
 1894         self.rows.append(row)  # Active cleanup knows identity even if journaling fails.
 1895         raw = (json.dumps(row, sort_keys=True) + "\n").encode()
 1896         need(os.fstat(self.journal).st_size + len(raw) <= MAX_JOURNAL, "Client journal exceeded its limit.")
 1897         need(os.write(self.journal, raw) == len(raw), "Short client journal write.")
 1898         os.fsync(self.journal)
 1899 
 1900     def begin(self):
 1901         self.work.mkdir(mode=0o700)
 1902         self.journal = open_file(self.work / "owner.jsonl", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_APPEND)
 1903         self.append({"op": "header", "format": 1, "policy": "arm64-bootstrap-55-v2", "root": str(self.root), "root_id": identity(self.root),
 1904                      "work_id": identity(self.work), "journal_id": identity(self.work / "owner.jsonl"),
 1905                      "dot": self.dot, "metadata": self.meta})
 1906         fd = directory(self.root)
 1907         os.fsync(fd)
 1908         os.close(fd)
 1909 
 1910     def add(self, relative, kind, data=None):
 1911         path = self.work / relative
 1912         need(not Path(relative).is_absolute() and ".." not in Path(relative).parts, "Invalid owned stage name.")
 1913         if kind == "directory":
 1914             parent = directory(path.parent)
 1915             try:
 1916                 os.mkdir(path.name, 0o700, dir_fd=parent)
 1917             finally:
 1918                 os.close(parent)
 1919             self.append({"op": "stage", "path": relative, "id": identity(path), "kind": kind})
 1920             return None
 1921         if kind == "link":
 1922             parent = directory(path.parent)
 1923             try:
 1924                 os.symlink(data, path.name, dir_fd=parent)
 1925             finally:
 1926                 os.close(parent)
 1927             self.append({"op": "stage", "path": relative, "id": identity(path), "kind": kind, "target": data})
 1928             return None
 1929         fd = open_file(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
 1930         try:
 1931             self.append({"op": "stage", "path": relative, "id": identity(path), "kind": "file"})
 1932         except BaseException:
 1933             os.close(fd)
 1934             raise
 1935         return fd
 1936 
 1937     def put(self, relative, data):
 1938         fd = self.add(relative, "file")
 1939         try:
 1940             need(os.write(fd, data) == len(data), "Short staging write.")
 1941             os.fsync(fd)
 1942         finally:
 1943             os.close(fd)
 1944 
 1945     def download(self, url, fd, limit, seconds):
 1946         serial = 1 + sum(row["op"] == "transfer-start" for row in self.rows)
 1947         self.append({"op": "transfer-start", "serial": serial})
 1948         transfer(url, fd, limit, seconds,
 1949                  lambda: self.append({"op": "transfer-stopped", "serial": serial}))
 1950 
 1951     def fetch(self):
 1952         fd = self.add("manifest", "file")
 1953         try:
 1954             self.download("https://client-update.fastly.steamstatic.com/steam_client_publicbeta_linuxarm64", fd, 2 * 1024**2, 30)
 1955         finally:
 1956             os.close(fd)
 1957         name, checksum, size = manifest(read_file(self.work / "manifest", 2 * 1024**2))
 1958         need(os.statvfs(self.root).f_bavail * os.statvfs(self.root).f_frsize >= size + MAX_OUTPUT + RESERVE,
 1959              "There is not enough free space to prepare the Steam client.")
 1960         fd = self.add("archive", "file")
 1961         try:
 1962             self.download("https://client-update.steamstatic.com/" + name, fd, size, 180)
 1963         finally:
 1964             os.close(fd)
 1965         need((self.work / "archive").stat().st_size == size and digest_file(self.work / "archive", MAX_ZIP) == checksum,
 1966              "The Steam client download did not match its manifest.")
 1967         return size, checksum
 1968 
 1969     def extract(self, size):
 1970         archive = self.work / "archive"
 1971         fd = open_file(archive)
 1972         rows = []
 1973         try:
 1974             def read(offset, length):
 1975                 need(0 <= offset <= size and 0 <= length <= size - offset, "ZIP record exceeds the archive.")
 1976                 raw = os.pread(fd, length, offset)
 1977                 need(len(raw) == length, "Incomplete ZIP record.")
 1978                 return raw
 1979             sig, disk, cd_disk, count_disk, count, cd_size, cd_start, comment = struct.unpack("<4s4H2IH", read(size - 22, 22))
 1980             need(sig == b"PK\x05\x06" and disk == cd_disk == comment == 0 and count_disk == count
 1981                  and count == len(EXPECTED) <= 128 and cd_start + cd_size == size - 22 and cd_size <= 65536,
 1982                  "Unsupported Steam ZIP directory.")
 1983             central = read(cd_start, cd_size)
 1984             pos, next_local, expanded, seen = 0, None, 0, set()
 1985             for _ in range(count):
 1986                 need(pos + 46 <= len(central), "Incomplete ZIP directory.")
 1987                 fields = struct.unpack_from("<4s6H3I5H2I", central, pos)
 1988                 sig, made, required, flags, method, mtime, mdate, crc, packed, unpacked, nlen, extra, note, disk, _, attr, local = fields
 1989                 need(sig == b"PK\x01\x02" and flags == extra == note == disk == 0 and required == 20
 1990                      and method in (0, 8) and pos + 46 + nlen <= len(central), "Unsupported Steam ZIP member.")
 1991                 name_bytes = central[pos + 46:pos + 46 + nlen]
 1992                 name = name_bytes.decode("ascii")
 1993                 canonical = NAME_MAP.get(name, name)
 1994                 kind = EXPECTED.get(canonical)
 1995                 need(kind is not None and canonical not in seen and "\\" not in canonical
 1996                      and all(part not in ("", ".", "..") for part in canonical.rstrip("/").split("/")),
 1997                      "Unexpected or duplicate Steam ZIP path.")
 1998                 seen.add(canonical)
 1999                 if kind == "directory":
 2000                     need(method == 0 and unpacked == packed == crc == 0 and made == 20 and attr == 0x40000000,
 2001                          "Unexpected Steam directory attributes.")
 2002                 elif kind == "link":
 2003                     need(made == 788 and stat.S_IFMT(attr >> 16) == stat.S_IFLNK and method == 0
 2004                          and 0 < unpacked == packed <= 4096, "Unexpected stored Steam link.")
 2005                 else:
 2006                     need(made == 20 and attr == 2176188416 and method == 8, "Unsupported Steam file attributes.")
 2007                 need(unpacked <= MAX_MEMBER, "Steam ZIP member exceeds its output limit.")
 2008                 expanded += unpacked
 2009                 need(expanded <= MAX_OUTPUT, "Steam ZIP exceeds its total output limit.")
 2010                 if next_local is None:
 2011                     need(local in (0, 20), "Unsupported ZIP prefix.")
 2012                 else:
 2013                     need(local == next_local, "Overlapping or unlisted ZIP local data.")
 2014                 header = struct.unpack("<4s5H3I2H", read(local, 30))
 2015                 need(header == (b"PK\x03\x04", required, flags, method, mtime, mdate, crc, packed, unpacked, nlen, 0)
 2016                      and read(local + 30, nlen) == name_bytes, "ZIP local and central records disagree.")
 2017                 offset = local + 30 + nlen
 2018                 next_local = offset + packed
 2019                 need(next_local <= cd_start, "ZIP payload overlaps its directory.")
 2020                 rows.append({"name": canonical, "kind": kind, "offset": offset, "packed": packed,
 2021                              "bytes": unpacked, "crc": crc, "method": method})
 2022                 pos += 46 + nlen
 2023             need(pos == len(central) and next_local == cd_start and seen == set(EXPECTED), "Incomplete Steam ZIP inventory.")
 2024             self.add("payload", "directory")
 2025             dirs = {str(Path(row["name"]).parent) for row in rows}
 2026             dirs |= {row["name"].rstrip("/") for row in rows if row["kind"] == "directory"}
 2027             dirs.discard(".")
 2028             for name in sorted(dirs, key=lambda x: (len(Path(x).parts), x)):
 2029                 self.add("payload/" + name, "directory")
 2030             deadline, total, links, receipt = time.monotonic() + 90, 0, [], []
 2031             for row in rows:
 2032                 if row["kind"] == "directory":
 2033                     continue
 2034                 target = "payload/" + row["name"]
 2035                 out = self.add(target, "file") if row["kind"] == "file" else None
 2036                 unpacker = zlib.decompressobj(-15) if row["method"] == 8 else None
 2037                 length, crc, sha, link = 0, 0, hashlib.sha256(), bytearray()
 2038                 try:
 2039                     remaining, offset = row["packed"], row["offset"]
 2040                     while remaining:
 2041                         chunk = read(offset, min(65536, remaining))
 2042                         remaining -= len(chunk)
 2043                         offset += len(chunk)
 2044                         while chunk:
 2045                             need(time.monotonic() < deadline, "Steam ZIP decoding timed out.")
 2046                             data = unpacker.decompress(chunk, 65536) if unpacker else chunk
 2047                             chunk = unpacker.unconsumed_tail if unpacker else b""
 2048                             length += len(data)
 2049                             total += len(data)
 2050                             need(length <= row["bytes"] and total <= MAX_OUTPUT, "Steam ZIP produced too much output.")
 2051                             crc = zlib.crc32(data, crc)
 2052                             sha.update(data)
 2053                             if out is None:
 2054                                 link.extend(data)
 2055                             else:
 2056                                 need(os.write(out, data) == len(data), "Short Steam client write.")
 2057                             if unpacker:
 2058                                 need(not unpacker.unused_data, "Trailing compressed Steam data.")
 2059                     need(length == row["bytes"] and crc == row["crc"] and (not unpacker or unpacker.eof),
 2060                          "Steam client CRC, length, or compressed stream verification failed.")
 2061                     if out is not None:
 2062                         os.fchmod(out, 0o755 if Path(row["name"]).name in EXECUTABLES else 0o644)
 2063                         os.fsync(out)
 2064                     else:
 2065                         value = link.decode("ascii")
 2066                         need(value not in ("", ".", "..") and "/" not in value and "\\" not in value
 2067                              and not any(ord(c) < 32 for c in value)
 2068                              and EXPECTED.get(str(Path(row["name"]).parent / value)) == "file",
 2069                              "Steam link target is outside the validated client.")
 2070                         links.append((target, value))
 2071                     receipt.append({"path": row["name"], "kind": row["kind"], "bytes": length, "sha256": sha.hexdigest()})
 2072                 finally:
 2073                     if out is not None:
 2074                         os.close(out)
 2075             for target, value in links:
 2076                 self.add(target, "link", value)
 2077             for name in dirs:
 2078                 os.chmod(self.work / "payload" / name, 0o755, follow_symlinks=False)
 2079             bootstrap(self.work / "payload")
 2080             tree = self.tree(self.work / "payload" / CLIENT)
 2081             self.append({"op": "prepared", "client_id": identity(self.work / "payload" / CLIENT),
 2082                          "tree": tree, "members": receipt})
 2083         finally:
 2084             os.close(fd)
 2085 
 2086     def tree(self, path):
 2087         mounts_below(path)
 2088         result = {}
 2089         for base, dirs, files in os.walk(path, followlinks=False):
 2090             need(len(result) <= 256, "The staged client has too many paths.")
 2091             for name in dirs + files:
 2092                 p = Path(base) / name
 2093                 s = p.lstat()
 2094                 key = str(p.relative_to(path))
 2095                 entry = {"id": identity(p), "mode": stat.S_IMODE(s.st_mode)}
 2096                 if stat.S_ISLNK(s.st_mode):
 2097                     entry["target"] = os.readlink(p)
 2098                 elif stat.S_ISREG(s.st_mode):
 2099                     need(s.st_nlink == 1, "The staged client has a hard link.")
 2100                     entry.update(bytes=s.st_size, sha256=digest_file(p, MAX_MEMBER))
 2101                 else:
 2102                     need(stat.S_ISDIR(s.st_mode), "Unexpected staged client node.")
 2103                 result[key] = entry
 2104         return result
 2105 
 2106     def prepare_metadata(self):
 2107         check_probe(self.meta["dot"])
 2108         need(available(Path(self.meta["dot"]["path"])) == self.meta["mounts"],
 2109              "The support storage changed before metadata writes.")
 2110         self.append({"op": "intent", "nodes": self.meta["nodes"]})
 2111         for node in self.meta["nodes"]:
 2112             path = Path(node["path"])
 2113             if node["before"] is not None:
 2114                 need(describe(path) == node["before"], "Steam support settings changed.")
 2115                 continue
 2116             # Only absent parents/nodes are created, never substituted for
 2117             # existing aliases, channels, SDK trees or custom files.
 2118             missing = []
 2119             parent = path.parent
 2120             while identity(parent) is None:
 2121                 missing.append(parent)
 2122                 parent = parent.parent
 2123             for p in reversed(missing):
 2124                 self.external(p, "directory", None)
 2125             self.external(path, node["kind"], node["value"])
 2126 
 2127     def external(self, path, kind, value):
 2128         check_probe(self.meta["dot"])
 2129         self.append({"op": "intent", "nodes": [{"path": str(path), "kind": kind, "value": value, "before": None}]})
 2130         need(identity(path) is None, "A Steam metadata destination appeared.")
 2131         parent = directory(path.parent)
 2132         parent_id = identity(path.parent)
 2133         try:
 2134             if kind == "directory":
 2135                 os.mkdir(path.name, 0o755, dir_fd=parent)
 2136             elif kind == "link":
 2137                 os.symlink(value, path.name, dir_fd=parent)
 2138             else:
 2139                 fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=parent)
 2140                 try:
 2141                     data = bytes.fromhex(value)
 2142                     need(os.write(fd, data) == len(data), "Short Steam metadata write.")
 2143                     os.fsync(fd)
 2144                 finally:
 2145                     os.close(fd)
 2146             self.append({"op": "external", "path": str(path), "id": identity(path),
 2147                          "parent_id": parent_id, "kind": kind, "value": value})
 2148             os.fsync(parent)
 2149         finally:
 2150             os.close(parent)
 2151 
 2152     def prepared(self):
 2153         rows = [row for row in self.rows if row["op"] == "prepared"]
 2154         need(len(rows) <= 1, "Ambiguous prepared client record.")
 2155         return rows[0] if rows else None
 2156 
 2157     def published(self):
 2158         prepared = self.prepared()
 2159         return prepared is not None and identity(self.root / CLIENT) == prepared["client_id"]
 2160 
 2161     def check_external(self, row):
 2162         path = Path(row["path"])
 2163         need(identity(path.parent) == row["parent_id"], "A client metadata parent changed; state was kept.")
 2164         current = describe(path)
 2165         need(current is not None and current["id"] == row["id"], "Client metadata ownership changed; state was kept.")
 2166         if row["kind"] == "file":
 2167             need(current.get("bytes") == row["value"], "Client metadata contents changed; state was kept.")
 2168         elif row["kind"] == "link":
 2169             need(current.get("target") == row["value"], "Client metadata link changed; state was kept.")
 2170 
 2171     def commit(self):
 2172         need(self.published(), "Published client identity changed.")
 2173         prepared = self.prepared()
 2174         need(self.tree(self.root / CLIENT) == prepared["tree"], "The published client changed before commit.")
 2175         for row in self.rows:
 2176             if row["op"] == "external":
 2177                 self.check_external(row)
 2178         for node in self.meta["nodes"]:
 2179             if node["before"] is not None:
 2180                 need(describe(Path(node["path"])) == node["before"], "Existing Steam metadata changed before commit.")
 2181         self.append({"op": "committed"})
 2182         self.cleanup(keep_client=True)
 2183 
 2184     def check_owned_state(self):
 2185         starts = [row["serial"] for row in self.rows if row["op"] == "transfer-start"]
 2186         stops = [row["serial"] for row in self.rows if row["op"] == "transfer-stopped"]
 2187         need(starts == stops, "Transfer quiescence is unestablished; client staging was kept for review.")
 2188         bindings(plan_global, self.root, True)
 2189         need(identity(self.work) == self.rows[0]["work_id"] and identity(self.work / "owner.jsonl") == self.rows[0]["journal_id"],
 2190              "Client stage ownership changed; state was kept.")
 2191         mounts_below(self.work)
 2192         stage = [row for row in self.rows if row["op"] == "stage"]
 2193         known = {row["path"]: row for row in stage}
 2194         actual = set()
 2195         for base, dirs, files in os.walk(self.work, followlinks=False):
 2196             for name in dirs + files:
 2197                 p = Path(base) / name
 2198                 relative = str(p.relative_to(self.work))
 2199                 if relative == "owner.jsonl":
 2200                     continue
 2201                 need(relative in known and identity(p) == known[relative]["id"], "Unknown or changed stage contents were kept.")
 2202                 need(p.lstat().st_dev == self.work.stat().st_dev and
 2203                      (not p.is_file() or p.lstat().st_nlink == 1), "A client stage crosses an ownership boundary.")
 2204                 actual.add(relative)
 2205         # Unrecorded creation after interruption is deliberately held. No
 2206         # ownership is inferred from a familiar filename or partial journal.
 2207         external = [row for row in self.rows if row["op"] == "external"]
 2208         owned = {row["path"] for row in external}
 2209         for row in self.rows:
 2210             if row["op"] == "intent":
 2211                 for node in row["nodes"]:
 2212                     if node["before"] is None and identity(Path(node["path"])) is not None:
 2213                         need(node["path"] in owned, "Unrecorded client metadata was kept for review.")
 2214         committed = any(row["op"] == "committed" for row in self.rows)
 2215         if not committed:
 2216             for row in external:
 2217                 if identity(Path(row["path"])) is not None or self.published():
 2218                     self.check_external(row)
 2219         return known, actual, external
 2220 
 2221     def cleanup(self, keep_client=False):
 2222         known, actual, external = self.check_owned_state()
 2223         if not keep_client:
 2224             need(not self.published(), "A published client must be verified before recovery.")
 2225             for row in external:
 2226                 if identity(Path(row["path"])) is not None:
 2227                     self.check_external(row)
 2228             for row in reversed(external):
 2229                 self.remove(Path(row["path"]), row["id"], row["kind"])
 2230         for relative in sorted(actual, key=lambda x: (len(Path(x).parts), x), reverse=True):
 2231             row = known[relative]
 2232             self.remove(self.work / relative, row["id"], row["kind"])
 2233         if self.journal is not None:
 2234             os.close(self.journal)
 2235             self.journal = None
 2236         self.remove(self.work / "owner.jsonl", self.rows[0]["journal_id"], "file")
 2237         self.remove(self.work, self.rows[0]["work_id"], "directory")
 2238 
 2239     def remove(self, path, expected, kind):
 2240         if identity(path) is None:
 2241             return  # An earlier interrupted cleanup already retired this owned node.
 2242         parent = directory(path.parent)
 2243         try:
 2244             s = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
 2245             need([s.st_dev, s.st_ino, stat.S_IFMT(s.st_mode)] == expected, "Client cleanup identity changed.")
 2246             if kind == "directory":
 2247                 os.rmdir(path.name, dir_fd=parent)
 2248             else:
 2249                 os.unlink(path.name, dir_fd=parent)
 2250             os.fsync(parent)
 2251         finally:
 2252             os.close(parent)
 2253 
 2254 
 2255 def install(root, tree, meta, dot):
 2256     bindings(plan_global, root, True)
 2257     consumers(root)
 2258     lock = open_file(root / LOCK, os.O_RDWR | os.O_CREAT, 0o600)
 2259     try:
 2260         s = os.fstat(lock)
 2261         need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1, "The client lock is ambiguous.")
 2262         fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
 2263         work = root / WORK
 2264         if identity(work) is not None:
 2265             rows = load_journal(work, root)
 2266             committed = any(row["op"] == "committed" for row in rows)
 2267             need(committed or rows[0]["dot"] == dot, "Recovery needs the same profile-selected Steam support folder.")
 2268             tx = Transaction(root, dot, rows[0]["metadata"], rows)
 2269             if not committed:
 2270                 check_probe(tx.meta["dot"])
 2271             tx.journal = open_file(work / "owner.jsonl", os.O_WRONLY | os.O_APPEND)
 2272             try:
 2273                 if committed:
 2274                     tx.cleanup(keep_client=True)
 2275                     print("An existing Steam client was kept; completed setup scratch was retired.")
 2276                     return
 2277                 if tx.published():
 2278                     tx.commit()
 2279                     print("Steam client file setup recovered.")
 2280                     return
 2281                 tx.cleanup()
 2282             finally:
 2283                 if tx.journal is not None:
 2284                     os.close(tx.journal)
 2285             # Do not turn a recovered failure into a successful installed state.
 2286             # This same explicit invocation can start a fresh bounded download.
 2287             tree = inspect_tree(plan_global, root, False)
 2288             meta = metadata(root, dot, tree)
 2289         else:
 2290             need(inspect_tree(plan_global, root, False) == tree, "The Steam client changed during installation.")
 2291             same_metadata(meta, root, dot, tree)
 2292         if tree["kind"] == "existing":
 2293             print("Existing Steam client files were kept.")
 2294             return
 2295         need(tree["kind"] == "fresh" and identity(root / CLIENT) is None, "Steam client state is ambiguous.")
 2296         need(os.statvfs(root).f_bavail * os.statvfs(root).f_frsize >= MAX_ZIP + MAX_OUTPUT + RESERVE,
 2297              "There is not enough free space to prepare the Steam client.")
 2298         tx = Transaction(root, dot, meta)
 2299         try:
 2300             tx.begin()
 2301             size, _ = tx.fetch()
 2302             tx.extract(size)
 2303             bindings(plan_global, root, True)
 2304             consumers(root)
 2305             same_metadata(meta, root, dot, tree)
 2306             tx.prepare_metadata()
 2307             tx.append({"op": "publishing"})
 2308             rename_new(work / "payload" / CLIENT, root / CLIENT)
 2309             tx.commit()
 2310         except BaseException:
 2311             if tx.rows and tx.journal is not None:
 2312                 try:
 2313                     tx.append({"op": "failure"})
 2314                     if not tx.published():
 2315                         tx.cleanup()
 2316                 except BaseException as cleanup_error:
 2317                     print("Steam client recovery state was kept: " + str(cleanup_error), file=sys.stderr)
 2318             raise
 2319         finally:
 2320             if tx.journal is not None:
 2321                 os.close(tx.journal)
 2322         print("Steam client files are in place.")
 2323     finally:
 2324         os.close(lock)
 2325 
 2326 
 2327 def interrupted(signum, frame):
 2328     raise RuntimeError("Steam client setup was interrupted (signal " + str(signum) + ").")
 2329 
 2330 
 2331 def main():
 2332     global plan_global
 2333     mode, plan_text, dot, tree_text, meta_text = sys.argv[1:]
 2334     plan_global = json.loads(plan_text)
 2335     root = Path(plan_global.get("target", plan_global["root"])["path"])
 2336     for sig in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT):
 2337         signal.signal(sig, interrupted)
 2338     signal.alarm(360 if mode == "install" else 30)
 2339     resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
 2340     if mode == "tree":
 2341         print(json.dumps(inspect_tree(plan_global, root), sort_keys=True))
 2342         return
 2343     tree = json.loads(tree_text)
 2344     if mode == "metadata":
 2345         need(inspect_tree(plan_global, root) == tree, "The Steam client changed while profiles loaded.")
 2346         if tree["kind"] == "recovery" and not tree["committed"]:
 2347             need(tree["dot"] == dot, "Recovery needs the same profile-selected Steam support folder.")
 2348             rows = load_journal(root / WORK, root)
 2349             print(json.dumps(rows[0]["metadata"], sort_keys=True))
 2350         else:
 2351             print(json.dumps(metadata(root, dot, {"kind": "existing"} if tree["kind"] == "recovery" else tree), sort_keys=True))
 2352         return
 2353     need(mode == "install", "Unsupported Steam client operation.")
 2354     need(LIBC.prctl(36, 1, 0, 0, 0) == 0, "Client transfer child supervision is unavailable.")
 2355     install(root, tree, json.loads(meta_text), dot)
 2356 
 2357 
 2358 if __name__ == "__main__":
 2359     try:
 2360         main()
 2361     except (OSError, RuntimeError, ValueError, KeyError, TypeError, IndexError, struct.error, zlib.error, subprocess.SubprocessError) as error:
 2362         print("Steam client setup stopped: " + str(error), file=sys.stderr)
 2363         sys.exit(1)
 2364 PY_STEAM_CLIENT
 2365 }
 2366 
 2367 install_bundled_proton_files() {
 2368   log_info "Installing bundled Proton files..."
 2369   cp -f "/usr/share/steam/registry.vdf" "${STEAM_DOT}" || die "Failed to copy registry.vdf."
 2370 }
 2371 
 2372 install_proton_variant() {
 2373   local display_name="$1"
 2374   # The fifth argument is retained for caller compatibility, never for deletion:
 2375   # games can select an older named version even after a new version installs.
 2376   log_info "Checking and installing ${display_name}; keeping existing versions..."
 2377   if /usr/bin/python3 -I -S -B - "${STEAM}" "$2" "$3" "$4" "$5" <<'PY_PROTON_VARIANT'
 2378 import ctypes
 2379 import fcntl
 2380 import gzip
 2381 import json
 2382 import lzma
 2383 import os
 2384 from pathlib import Path, PurePosixPath
 2385 import posixpath
 2386 import re
 2387 import resource
 2388 import shutil
 2389 import signal
 2390 import stat
 2391 import subprocess
 2392 import sys
 2393 import tarfile
 2394 from urllib.parse import urlsplit
 2395 
 2396 RESERVE = 256 * 1024**2
 2397 MAX_ARCHIVE = 2 * 1024**3
 2398 MAX_EXPANDED = 16 * 1024**3
 2399 MAX_MEMBERS = 250000
 2400 WORK = ".proton-variant-stage"
 2401 LOCK = ".proton-variant.lock"
 2402 FAMILIES = {"proton-cachyos-*-arm64": (r"proton-cachyos-[A-Za-z0-9._+-]+-arm64", ".tar.xz"),
 2403             "GE-Proton*-aarch64": (r"GE-Proton[A-Za-z0-9._+-]+-aarch64", ".tar.gz")}
 2404 
 2405 
 2406 def directory(path, device):
 2407     info = path.lstat()
 2408     if not stat.S_ISDIR(info.st_mode) or info.st_dev != device:
 2409         raise RuntimeError("Proton installation requires a real directory on the Steam filesystem.")
 2410 
 2411 
 2412 def no_mounts(path):
 2413     for line in Path("/proc/self/mountinfo").read_text().splitlines():
 2414         field = line.split()[4]
 2415         mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field))
 2416         if mount == path or path in mount.parents:
 2417             raise RuntimeError("A mounted Proton staging or target path must be released first.")
 2418 
 2419 
 2420 def capacity(root, needed):
 2421     if shutil.disk_usage(root).free < needed + RESERVE:
 2422         raise RuntimeError("Not enough space to install Proton while keeping existing versions.")
 2423 
 2424 
 2425 def manifest(path):
 2426     if path.is_symlink() or not path.is_file() or not 0 < path.stat().st_size <= 65536:
 2427         raise RuntimeError("Missing or unsupported Proton manifest.")
 2428     raw = path.read_text(encoding="utf-8")
 2429     tokens, offset = [], 0
 2430     pattern = re.compile(r'\s+|//[^\n]*|"(?:\\.|[^"\\])*"|[{}]')
 2431     for match in pattern.finditer(raw):
 2432         if match.start() != offset:
 2433             raise RuntimeError("Malformed Proton manifest.")
 2434         offset = match.end()
 2435         token = match[0]
 2436         if not token.isspace() and not token.startswith("//"):
 2437             tokens.append(token)
 2438     if offset != len(raw):
 2439         raise RuntimeError("Malformed Proton manifest.")
 2440     index = 0
 2441 
 2442     def object_value(depth=0):
 2443         nonlocal index
 2444         if depth > 16:
 2445             raise RuntimeError("Proton manifest nesting exceeds the supported format.")
 2446         result = {}
 2447         while index < len(tokens) and tokens[index] != "}":
 2448             key = json.loads(tokens[index])
 2449             index += 1
 2450             if not isinstance(key, str) or key in result or index == len(tokens):
 2451                 raise RuntimeError("Malformed or duplicate Proton manifest field.")
 2452             if tokens[index] == "{":
 2453                 index += 1
 2454                 value = object_value(depth + 1)
 2455                 if index == len(tokens) or tokens[index] != "}":
 2456                     raise RuntimeError("Unclosed Proton manifest object.")
 2457                 index += 1
 2458             else:
 2459                 value = json.loads(tokens[index])
 2460                 index += 1
 2461             result[key] = value
 2462         return result
 2463 
 2464     result = object_value()
 2465     if index != len(tokens):
 2466         raise RuntimeError("Unexpected Proton manifest closing brace.")
 2467     return result
 2468 
 2469 
 2470 def validate(target, device):
 2471     directory(target, device)
 2472     no_mounts(target)
 2473     tool = manifest(target / "toolmanifest.vdf")["manifest"]
 2474     if tool.get("version") != "2" or tool.get("commandline") != "/proton %verb%":
 2475         raise RuntimeError("Unsupported Proton command manifest.")
 2476     entries = manifest(target / "compatibilitytool.vdf")["compatibilitytools"]["compat_tools"]
 2477     if not isinstance(entries, dict) or len(entries) != 1:
 2478         raise RuntimeError("Expected one Proton compatibility tool.")
 2479     name, entry = next(iter(entries.items()))
 2480     if (not name or "##" in name or not isinstance(entry, dict) or entry.get("install_path") != "."
 2481             or entry.get("from_oslist") != "windows" or entry.get("to_oslist") != "linux"):
 2482         raise RuntimeError("Unsupported Proton compatibility manifest.")
 2483     for relative in ("proton", "filelock.py", "version", "files/bin-arm64/wine", "files/bin-arm64/wineserver"):
 2484         path = target / relative
 2485         resolved = path.resolve(strict=True)
 2486         if not resolved.is_relative_to(target) or not resolved.is_file() or resolved.stat().st_size == 0:
 2487             raise RuntimeError("Missing or escaping required Proton payload: " + relative)
 2488         if relative == "proton" or relative.startswith("files/"):
 2489             if not resolved.stat().st_mode & 0o111:
 2490                 raise RuntimeError("Required Proton launcher is not executable: " + relative)
 2491         if relative.startswith("files/"):
 2492             with resolved.open("rb") as stream:
 2493                 header = stream.read(20)
 2494             if (len(header) != 20 or header[:6] != b"\x7fELF\x02\x01" or header[18:20] != b"\xb7\x00"
 2495                     or header[16:18] not in (b"\x02\x00", b"\x03\x00")):
 2496                 raise RuntimeError("Required Proton payload is not ARM64 ELF: " + relative)
 2497 
 2498 
 2499 def unpack(archive, stage, name, root, suffix):
 2500     # Validate every member and the compressed footer before extraction. Python's
 2501     # data filter then checks resolved link paths again during extraction.
 2502     members, seen, expanded = [], {}, 0
 2503     opener = lzma.open if suffix == ".tar.xz" else gzip.open
 2504     with opener(archive, "rb") as compressed:
 2505         class BoundedReader:
 2506             count = 0
 2507 
 2508             def read(self, size):
 2509                 data = compressed.read(size)
 2510                 self.count += len(data)
 2511                 if self.count > MAX_EXPANDED + MAX_MEMBERS * 8192:
 2512                     raise RuntimeError("Proton tar stream exceeds the size bound.")
 2513                 return data
 2514 
 2515         reader = BoundedReader()
 2516         with tarfile.open(fileobj=reader, mode="r|") as bundle:
 2517             for member in bundle:
 2518                 path = PurePosixPath(member.name)
 2519                 if (path.is_absolute() or ".." in path.parts or not path.parts or path.parts[0] != name
 2520                         or str(path) in seen or member.size < 0 or member.issparse()
 2521                         or not (member.isdir() or member.isfile() or member.issym() or member.islnk())):
 2522                     raise RuntimeError("Unsafe or unsupported Proton archive member.")
 2523                 if len(path.parts) == 1 and not member.isdir():
 2524                     raise RuntimeError("Proton archive root must be a directory.")
 2525                 if member.issym() or member.islnk():
 2526                     link = PurePosixPath(member.linkname)
 2527                     base = str(path.parent) if member.issym() else ""
 2528                     resolved = PurePosixPath(posixpath.normpath(posixpath.join(base, str(link))))
 2529                     if link.is_absolute() or not resolved.parts or resolved.parts[0] != name:
 2530                         raise RuntimeError("Proton archive link escapes its version directory.")
 2531                     if member.islnk() and seen.get(str(resolved)) != "file":
 2532                         raise RuntimeError("Proton hard link must name an earlier regular file.")
 2533                 seen[str(path)] = "file" if member.isfile() else "other"
 2534                 expanded += ((member.size + 4095) // 4096) * 4096 + 8192
 2535                 members.append(member)
 2536                 if expanded > MAX_EXPANDED or len(members) > MAX_MEMBERS:
 2537                     raise RuntimeError("Proton archive exceeds the extraction bound.")
 2538         while reader.read(1024 * 1024):
 2539             pass
 2540     capacity(root, expanded)
 2541     stage.mkdir()
 2542     with tarfile.open(archive, "r:*") as bundle:
 2543         bundle.extractall(stage, members=members, filter="data")
 2544 
 2545 
 2546 def cleanup(work, lock_info, device):
 2547     if not os.path.lexists(work):
 2548         return
 2549     directory(work, device)
 2550     no_mounts(work)
 2551     children = {path.name for path in work.iterdir()}
 2552     if not children:  # Interrupted before the ownership link or after unlinking it.
 2553         work.rmdir()
 2554         return
 2555     owner = work / "owner"
 2556     info = owner.lstat()
 2557     if (not stat.S_ISREG(info.st_mode) or (info.st_dev, info.st_ino) != lock_info
 2558             or not children <= {"owner", "archive", "unpack"}):
 2559         raise RuntimeError("Unrecognized Proton staging contents; leaving them untouched.")
 2560     for name in ("archive", "unpack"):
 2561         path = work / name
 2562         if path.is_symlink() or path.is_file():
 2563             path.unlink()
 2564         elif path.exists():
 2565             directory(path, device)
 2566             shutil.rmtree(path)
 2567     owner.unlink()  # Ownership anchor is always removed last, for retry after a kill.
 2568     work.rmdir()
 2569 
 2570 
 2571 def activate(candidate, target):
 2572     # Linux renameat2 refuses any existing target, including a concurrently created
 2573     # empty directory. Never replace a player-owned same-name installation.
 2574     libc = ctypes.CDLL(None, use_errno=True)
 2575     rename = libc.renameat2
 2576     rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
 2577     rename.restype = ctypes.c_int
 2578     if rename(-100, os.fsencode(candidate), -100, os.fsencode(target), 1) != 0:
 2579         raise OSError(ctypes.get_errno(), "Could not activate staged Proton without replacing existing data")
 2580 
 2581 
 2582 def install(root, url, tar_name, name, family):
 2583     pattern, suffix = FAMILIES[family]
 2584     if not re.fullmatch(pattern, name) or tar_name != name + suffix:
 2585         raise RuntimeError("Unsupported Proton family or archive name.")
 2586     parsed = urlsplit(url)
 2587     if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
 2588         raise RuntimeError("Proton download requires an HTTPS release URL.")
 2589     root = Path(root).resolve(strict=True)
 2590     if root == Path("/"):
 2591         raise RuntimeError("Refusing the filesystem root as a Steam directory.")
 2592     device = root.stat().st_dev
 2593     directory(root, device)
 2594     fd = os.open(root / LOCK, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
 2595     try:
 2596         info = os.fstat(fd)
 2597         if not stat.S_ISREG(info.st_mode) or info.st_size:
 2598             raise RuntimeError("Unsupported Proton installer lock.")
 2599         fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
 2600         work = root / WORK
 2601         lock_info = (info.st_dev, info.st_ino)
 2602         cleanup(work, lock_info, device)
 2603         dest = root / "compatibilitytools.d"
 2604         if not os.path.lexists(dest):
 2605             dest.mkdir()
 2606         directory(dest, device)
 2607         no_mounts(dest)
 2608         target = dest / name
 2609         if os.path.lexists(target):
 2610             try:
 2611                 validate(target, device)
 2612             except Exception as error:
 2613                 raise RuntimeError("Existing Proton target is incomplete or unsupported; kept untouched: "
 2614                                    + name + ". Resolve that version separately before retrying.") from error
 2615             print("Requested Proton version passes payload checks; keeping it unchanged.")
 2616             return
 2617         capacity(root, MAX_ARCHIVE)
 2618         work.mkdir(mode=0o700)
 2619         try:
 2620             os.link(root / LOCK, work / "owner", follow_symlinks=False)
 2621             archive = work / "archive"
 2622             parent = os.getpid()
 2623 
 2624             def child_setup():
 2625                 libc = ctypes.CDLL(None, use_errno=True)
 2626                 if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0 or os.getppid() != parent:
 2627                     os._exit(125)
 2628                 resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_ARCHIVE, MAX_ARCHIVE))
 2629 
 2630             subprocess.run(["wget", "-t", "3", "-T", "30", "-O", str(archive), url],
 2631                            check=True, timeout=900, preexec_fn=child_setup)
 2632             if not 0 < archive.stat().st_size <= MAX_ARCHIVE:
 2633                 raise RuntimeError("Proton download is empty or exceeds the size bound.")
 2634             unpack(archive, work / "unpack", name, root, suffix)
 2635             candidate = work / "unpack" / name
 2636             validate(candidate, device)
 2637             capacity(root, 0)
 2638             activate(candidate, target)
 2639             print("Proton installed; every existing version has been kept.")
 2640         finally:
 2641             cleanup(work, lock_info, device)
 2642     finally:
 2643         os.close(fd)  # Keep the lock inode: never unlink a lock another caller may hold.
 2644 
 2645 
 2646 def interrupted(signum, frame):
 2647     raise InterruptedError("Proton installation interrupted; existing versions are kept.")
 2648 
 2649 
 2650 def main():
 2651     for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
 2652         signal.signal(signum, interrupted)
 2653     signal.alarm(1800)
 2654     try:
 2655         install(*sys.argv[1:])
 2656     except Exception as error:
 2657         print("Proton installation stopped: " + str(error), file=sys.stderr)
 2658         return 1
 2659     finally:
 2660         signal.alarm(0)
 2661     return 0
 2662 
 2663 
 2664 if __name__ == "__main__":
 2665     sys.exit(main())
 2666 PY_PROTON_VARIANT
 2667   then
 2668     return 0
 2669   else
 2670     die "Could not install ${display_name}. Existing Proton versions have been kept."
 2671   fi
 2672 }
 2673 
 2674 install_proton_cachyos() {
 2675   install_proton_variant \
 2676     "Proton-CachyOS" \
 2677     "${PROTON_CACHYOS_URL}" \
 2678     "${PROTON_CACHYOS_TAR}" \
 2679     "${PROTON_CACHYOS_DIR}" \
 2680     "proton-cachyos-*-arm64"
 2681 }
 2682 
 2683 install_proton_ge() {
 2684   install_proton_variant \
 2685     "Proton-GE" \
 2686     "${PROTON_GE_URL}" \
 2687     "${PROTON_GE_TAR}" \
 2688     "${PROTON_GE_DIR}" \
 2689     "GE-Proton*-aarch64"
 2690 }
 2691 
 2692 run_steam_first_launch() {
 2693   log_info "Running Steam first launch routine..."
 2694   echo 0 > /proc/sys/fs/binfmt_misc/x86 || true
 2695   echo 0 > /proc/sys/fs/binfmt_misc/box32 || true
 2696   echo 0 > /proc/sys/fs/binfmt_misc/box64 || true
 2697 
 2698   if [ "${DEVICE_HAS_DUAL_SCREEN}" = "true" ]; then
 2699     swaymsg 'seat seat1 fallback true' || log_info "Swaymsg dual screen setup failed, ignoring."
 2700   fi
 2701 
 2702   # Allow Steam launch commands to fail cleanly if needed, though they shouldn't
 2703   LD_LIBRARY_PATH="${STEAM}/lib/aarch64-linux-gnu/" "${CLIENT_DIR}/steam" -deckard -exitsteam || log_info "Native Steam execution exited with an error."
 2704 
 2705   if [ "${DEVICE_HAS_DUAL_SCREEN}" = "true" ]; then
 2706     swaymsg 'seat seat1 fallback false' || log_info "Swaymsg dual screen teardown failed, ignoring."
 2707   fi
 2708 
 2709   systemctl restart systemd-binfmt || die "Failed to restart systemd-binfmt."
 2710 }
 2711 
 2712 # --- Execution ---
 2713 # Freeze the checked inputs before profile scripts can run or change the roots.
 2714 STEAM_ROOT_PLAN="$(steam_root_layout inspect)" || die "Steam storage is not ready. Nothing was installed."
 2715 readonly STEAM STEAM_GAMES_ROOT STEAM_ROOT_PLAN
 2716 STEAM_CLIENT_PLAN="$(steam_client_state tree)" || die "Steam client files could not be checked. Nothing was changed."
 2717 readonly STEAM_CLIENT_PLAN
 2718 source /etc/profile
 2719 STEAM_DOT="${STEAM_DOT:-/storage/.steam}"
 2720 APPLICATIONS="${APPLICATIONS:-/storage/.local/share/applications}"
 2721 FEX_DATA="/storage/.local/share/fex-emu"
 2722 FEX_ARCH_ROOT="${FEX_DATA}/RootFS/ArchLinux"
 2723 FEX_ARCH_USR_LIB="${FEX_ARCH_ROOT}/usr/lib"
 2724 RUNTIME_DIR="${STEAM}/steam-runtime-steamrt-arm64"
 2725 CLIENT_DIR="${STEAM}/steamrtarm64"
 2726 RUNTIME_TAR_BASE="https://repo.steampowered.com/steamrt3c/images"
 2727 RUNTIME_TAR_VERSION_URL="${RUNTIME_TAR_BASE}/latest-public-stable.txt"
 2728 STEAM_MANIFEST_URL="https://client-update.fastly.steamstatic.com/steam_client_publicbeta_linuxarm64"
 2729 STEAM_CDN="https://client-update.steamstatic.com"
 2730 PROTON_CACHYOS_RELEASE_API="https://api.github.com/repos/CachyOS/proton-cachyos/releases/latest"
 2731 PROTON_GE_RELEASE_API="https://api.github.com/repos/GloriousEggroll/proton-ge-custom/releases/latest"
 2732 unset MESA_LOADER_DRIVER_OVERRIDE
 2733 
 2734 steam_root_layout verify || die "Steam storage changed. Installation stopped."
 2735 # Profiles may already have written. Metadata refusal preserves their selected
 2736 # path and does not claim rollback of profile effects or other transactions.
 2737 STEAM_CLIENT_METADATA_PLAN="$(steam_client_state metadata)" || die "Steam support folders could not be checked. Client files were kept."
 2738 readonly STEAM_DOT STEAM_CLIENT_METADATA_PLAN
 2739 set_kill set "-9 steam FEX"
 2740 log_info "Starting Steam Installation Process..."
 2741 
 2742 ensure_fex_rootfs
 2743 link_steam_library
 2744 ensure_steam_desktop_stub
 2745 install_steam_runtime_arm64
 2746 install_steam_client_arm64
 2747 install_bundled_proton_files
 2748 fetch_proton_latest_release "${PROTON_CACHYOS_RELEASE_API}" "arm64" "cachyos-" "PROTON_CACHYOS" "Proton-CachyOS"
 2749 install_proton_cachyos
 2750 fetch_proton_latest_release "${PROTON_GE_RELEASE_API}" "aarch64" "" "PROTON_GE" "Proton-GE"
 2751 install_proton_ge
 2752 run_steam_first_launch
 2753 
 2754 echo ""
 2755 log_success "Steam setup finished. Start Steam to continue."
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/dolphin-save-paths

```text
    1 #!/usr/bin/python3
    2 # SPDX-License-Identifier: GPL-2.0-or-later
    3 # Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
    4 """Prepare Dolphin's known save links without converting retained real data."""
    5 import argparse
    6 import ctypes
    7 import fcntl
    8 import os
    9 from pathlib import Path
   10 import re
   11 import shutil
   12 import signal
   13 import stat
   14 import sys
   15 import tempfile
   16 
   17 REGIONS = ("EUR", "JAP", "USA")
   18 MAX_COPY_FILES = 4096
   19 MAX_COPY_BYTES = 64 * 1024 * 1024
   20 
   21 
   22 # The first line is a fixed ownership discriminator consumed by runemu, not UI.
   23 ERROR_OWNER = "DOLPHIN DID NOT START"
   24 MESSAGES_FR = {
   25     'Existing Dolphin data needs attention. Back up these locations, then use the file manager to choose and arrange the saved data before trying again. No saved data was removed.':
   26         'Les données Dolphin existantes nécessitent votre attention. Sauvegardez ces emplacements, puis utilisez le gestionnaire de fichiers pour choisir et organiser les données à conserver avant de réessayer. Aucune donnée sauvegardée n’a été supprimée.',
   27     'Dolphin storage path is outside its expected root.':
   28         'L’emplacement de stockage Dolphin se trouve hors du dossier prévu.',
   29     'Dolphin save storage is not writable. Check the game storage and folder permissions, then try again.':
   30         'Impossible d’écrire dans le stockage des sauvegardes Dolphin. Vérifiez le stockage des jeux et les permissions des dossiers, puis réessayez.',
   31     'Game storage is not ready. Reconnect it and try again. No saved data was removed.':
   32         'Le stockage des jeux n’est pas prêt. Reconnectez-le et réessayez. Aucune donnée sauvegardée n’a été supprimée.',
   33     'A Dolphin save path is separately mounted. Check the storage layout before trying again.':
   34         'Un emplacement de sauvegarde Dolphin possède un montage distinct. Vérifiez l’organisation du stockage avant de réessayer.',
   35     "Dolphin's retained GC resources exceed the preparation limit. Arrange them in the file manager before trying again.":
   36         'Les ressources GameCube conservées dépassent la limite de préparation. Organisez-les dans le gestionnaire de fichiers avant de réessayer.',
   37     'Dolphin configuration is missing. Check the installed defaults before trying again.':
   38         'La configuration Dolphin est absente. Vérifiez la configuration fournie avec le système avant de réessayer.',
   39     'Dolphin save preparation was interrupted. Saved data was kept. Try again.':
   40         'La préparation des sauvegardes Dolphin a été interrompue. Les données sauvegardées ont été conservées. Réessayez.',
   41     'Dolphin save preparation lock is unavailable. Try again after the other launch finishes.':
   42         'La préparation des sauvegardes Dolphin est indisponible. Réessayez après la fin de l’autre lancement.',
   43     'Dolphin save preparation is already running. Wait for it to finish, then try again.':
   44         'La préparation des sauvegardes Dolphin est déjà en cours. Attendez sa fin, puis réessayez.',
   45     'Dolphin could not prepare save storage. Check the storage connection and permissions, then try again. Saved data was kept.':
   46         'Dolphin n’a pas pu préparer le stockage des sauvegardes. Vérifiez la connexion du stockage et les permissions, puis réessayez. Les données sauvegardées ont été conservées.',
   47 }
   48 
   49 
   50 def message_language():
   51     # ES exports LANGUAGE; use the same precedence as the cloud companion page.
   52     value = next((os.environ[key] for key in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG")
   53                   if os.environ.get(key)), "en")
   54     primary = value.split(":", 1)[0].replace("-", "_").split("_", 1)[0].split(".", 1)[0].split("@", 1)[0].lower()
   55     return "fr" if primary == "fr" else "en"
   56 
   57 
   58 def visible_path(path):
   59     # The native message wraps only at whitespace. Keep this known long card
   60     # path intact except for a display line break at its final slash.
   61     prefix = "/storage/.config/dolphin-emu/GC/"
   62     leaf = path.removeprefix(prefix)
   63     if path.startswith(prefix) and re.fullmatch(r"MemoryCard[AB]\.(EUR|JAP|USA)\.raw", leaf):
   64         return prefix + "\n" + leaf
   65     return path
   66 
   67 
   68 def visible_error(message):
   69     language = message_language()
   70     title = "DOLPHIN N’A PAS DÉMARRÉ" if language == "fr" else "DOLPHIN DID NOT START"
   71     # Translate only the known sentence, never player data paths below it.
   72     sentence, separator, paths = message.partition("\n")
   73     if language == "fr":
   74         sentence = MESSAGES_FR.get(sentence, sentence)
   75     paths = "\n".join(visible_path(path) for path in paths.split("\n"))
   76     return title + "\n\n" + sentence + separator + paths + "\n"
   77 
   78 
   79 class Refused(Exception):
   80     pass
   81 
   82 
   83 def kind(path):
   84     try:
   85         mode = path.lstat().st_mode
   86     except FileNotFoundError:
   87         return "absent"
   88     if stat.S_ISLNK(mode):
   89         return "link"
   90     if stat.S_ISDIR(mode):
   91         return "dir"
   92     if stat.S_ISREG(mode):
   93         return "file"
   94     return "other"
   95 
   96 
   97 def link_target(path):
   98     return Path(os.path.abspath(path.parent / os.readlink(path)))
   99 
  100 
  101 def reject(path, destination=None):
  102     detail = "\n" + str(path)
  103     if destination is not None:
  104         detail += "\n" + str(destination)
  105     raise Refused("Existing Dolphin data needs attention. Back up these locations, then use the file manager "
  106                   "to choose and arrange the saved data before trying again. No saved data was removed." + detail)
  107 
  108 
  109 def directories(path, boundary):
  110     # Missing descendants are fine; existing parents must not redirect traversal.
  111     if not path.is_relative_to(boundary):
  112         raise Refused("Dolphin storage path is outside its expected root.")
  113     for item in (boundary, *reversed(path.relative_to(boundary).parents)):
  114         if item == boundary:
  115             current = boundary
  116         else:
  117             current = boundary / item
  118         if kind(current) not in ("dir", "absent"):
  119             reject(current)
  120     if kind(path) not in ("dir", "absent"):
  121         reject(path)
  122 
  123 
  124 def mounts():
  125     result = set()
  126     for line in Path("/proc/self/mountinfo").read_text().splitlines():
  127         field = line.split()[4]
  128         result.add(Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), field)))
  129     return result
  130 
  131 
  132 def writable(path):
  133     current = path
  134     while kind(current) == "absent":
  135         current = current.parent
  136     # Mode check also catches a read-only player directory when the launcher is root.
  137     mode = current.stat().st_mode
  138     if not mode & 0o222 or not os.access(current, os.W_OK):
  139         raise Refused("Dolphin save storage is not writable. Check the game storage and folder permissions, then try again.\n" + str(path))
  140 
  141 
  142 def plan(storage, system):
  143     conf = storage / ".config/dolphin-emu"
  144     roms = storage / "roms"
  145     shared = storage / ".local/share/dolphin-emu"
  146     mounted = mounts()
  147     if kind(storage) != "dir" or kind(roms) != "dir" or roms not in mounted:
  148         raise Refused("Game storage is not ready. Reconnect it and try again. No saved data was removed.")
  149     for path in (conf, roms / "savestates", roms / "bios/GC", shared.parent):
  150         directories(path, storage)
  151     # Do not rewrite a save path hidden behind a nested/bind mount.
  152     for mount in mounted:
  153         if any(mount == path or path in mount.parents for path in (conf, shared, roms / "savestates", roms / "bios")):
  154             raise Refused("A Dolphin save path is separately mounted. Check the storage layout before trying again.\n" + str(mount))
  155     directories(conf / "GC", storage)
  156     for temporary in (roms / "bios/.GC.dolphin-new", roms / "bios/GC/.Triforce.dolphin-new"):
  157         if kind(temporary) != "absent":
  158             reject(temporary)
  159     links = [(conf / "StateSaves", roms / "savestates" / system,
  160               (roms / "savestates/gamecube", roms / "savestates/wii")),
  161              (shared, conf, (conf,))]
  162     dirs = [roms / "savestates" / system, roms / "bios/GC", conf / "GC", shared.parent]
  163     for name in ("gamecube", "wii"):
  164         directories(roms / "savestates" / name, storage)
  165     for region in REGIONS:
  166         canonical = roms / "bios/GC" / region
  167         directories(canonical, storage)
  168         dirs.append(canonical)
  169         links.append((conf / "GC" / region, canonical, (canonical,)))
  170         for slot in ("A", "B"):
  171             card = "MemoryCard" + slot + "." + region + ".raw"
  172             canonical = roms / "bios/GC" / card
  173             if kind(canonical) not in ("absent", "file"):
  174                 reject(canonical)
  175             if kind(canonical) == "file":
  176                 writable(canonical)
  177             links.append((conf / "GC" / card, canonical, (canonical,)))
  178     directories(conf / "GC", storage)
  179     directories(roms / "bios/GC/Triforce", storage)
  180     for source, destination, allowed in links:
  181         value = kind(source)
  182         if value == "link":
  183             if link_target(source) not in allowed:
  184                 reject(source, destination)
  185         elif value != "absent":
  186             # A real StateSaves tree has no reliable GC/Wii ownership tag. Even
  187             # equal-looking region/card copies need an explicit retention choice.
  188             reject(source, destination)
  189     pending = conf / ".dolphin-state-link"
  190     if kind(pending) != "absent" and (kind(pending) != "link" or link_target(pending) not in links[0][2]):
  191         reject(pending, conf / "StateSaves")
  192     for path in (*dirs, conf, shared.parent):
  193         writable(path)
  194     return conf, roms, dirs, links, pending
  195 
  196 
  197 def copy_new_tree(source, target, skip=()):
  198     # Historical GC/Triforce seeding is copy-only and only to an absent target.
  199     # A killed copy leaves one reserved stage and refuses retry until reviewed.
  200     # Canonical data is never replaced, and the original config tree stays intact.
  201     # Shipped resources are real files; refuse retained redirects before copying.
  202     if kind(source) == "absent":
  203         target.mkdir()
  204         return
  205     if kind(source) != "dir":
  206         reject(source, target)
  207     count = total = 0
  208     def unreadable(error):
  209         raise error
  210 
  211     for base, dirs, files in os.walk(source, followlinks=False, onerror=unreadable):
  212         if Path(base) == source:
  213             dirs[:] = [name for name in dirs if name not in skip]
  214             files = [name for name in files if name not in skip]
  215         for name in dirs + files:
  216             path = Path(base) / name
  217             if kind(path) not in ("dir", "file"):
  218                 reject(path, target)
  219             count += 1
  220             if kind(path) == "file":
  221                 total += path.lstat().st_size
  222             if count > MAX_COPY_FILES or total > MAX_COPY_BYTES:
  223                 raise Refused("Dolphin's retained GC resources exceed the preparation limit. Arrange them in the file manager before trying again.")
  224     temporary = target.parent / ("." + target.name + ".dolphin-new")
  225     temporary.mkdir(mode=0o700)
  226     owned = temporary.lstat()
  227     try:
  228         shutil.copytree(source, temporary, symlinks=True, dirs_exist_ok=True,
  229                         ignore=lambda base, names: set(skip) if Path(base) == source else set())
  230         rename(temporary, target, 1)  # RENAME_NOREPLACE: canonical data wins a race.
  231     finally:
  232         if kind(temporary) != "absent":
  233             current = temporary.lstat()
  234             if (current.st_dev, current.st_ino) != (owned.st_dev, owned.st_ino) or kind(temporary) != "dir":
  235                 reject(temporary)
  236             if any(m == temporary or temporary in m.parents for m in mounts()):
  237                 reject(temporary)
  238             shutil.rmtree(temporary)  # Only this invocation's private, unactivated copy.
  239 
  240 
  241 def rename(first, second, flags):
  242     libc = ctypes.CDLL(None, use_errno=True)
  243     operation = libc.renameat2
  244     operation.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
  245     operation.restype = ctypes.c_int
  246     if operation(-100, os.fsencode(first), -100, os.fsencode(second), flags):
  247         raise OSError(ctypes.get_errno(), "Could not switch Dolphin's save-state link")
  248 
  249 
  250 def apply(storage, system):
  251     conf, roms, dirs, links, pending = plan(storage, system)
  252     if kind(conf) != "dir":
  253         raise Refused("Dolphin configuration is missing. Check the installed defaults before trying again.")
  254     # Seed only an absent GC root, retaining the existing launchers' resource copy.
  255     (roms / "bios").mkdir(exist_ok=True)
  256     if kind(roms / "bios/GC") == "absent":
  257         managed = (*REGIONS, *("MemoryCard" + slot + "." + region + ".raw"
  258                               for region in REGIONS for slot in ("A", "B")))
  259         copy_new_tree(conf / "GC", roms / "bios/GC", skip=managed)
  260     if system == "gamecube" and kind(roms / "bios/GC/Triforce") == "absent":
  261         copy_new_tree(conf / "GC/Triforce", roms / "bios/GC/Triforce")
  262     for directory in dirs:
  263         directory.mkdir(parents=True, exist_ok=True)
  264     if kind(pending) == "link":
  265         if link_target(pending) not in links[0][2]:
  266             reject(pending, conf / "StateSaves")
  267         pending.unlink()  # Only a recognized leftover symlink; never its target.
  268     for source, destination, allowed in links:
  269         value = kind(source)
  270         if value == "absent":
  271             source.symlink_to(destination)  # Exclusive creation; never overwrites a racing entry.
  272         elif value == "link" and link_target(source) == destination:
  273             continue
  274         elif source == conf / "StateSaves" and value == "link" and link_target(source) in allowed:
  275             previous = source.lstat()
  276             pending.symlink_to(destination)
  277             rename(pending, source, 2)  # RENAME_EXCHANGE keeps the displaced object.
  278             moved = pending.lstat()
  279             if (moved.st_dev, moved.st_ino) != (previous.st_dev, previous.st_ino) or kind(pending) != "link":
  280                 # Keep the unexpected object; do not delete data moved by a race.
  281                 # Refusal identifies the reserved path for explicit recovery.
  282                 reject(pending, source)
  283             pending.unlink()
  284         else:
  285             reject(source, destination)
  286 
  287 
  288 def write_error(path, message):
  289     # ES already consumes this native launch-error file on exit 250.
  290     fd, temporary = tempfile.mkstemp(prefix=".dolphin-launch-error-", dir=path.parent)
  291     try:
  292         with os.fdopen(fd, "w", encoding="utf-8", errors="backslashreplace") as stream:
  293             stream.write(ERROR_OWNER + "\n" + visible_error(message))
  294         os.replace(temporary, path)
  295     finally:
  296         if os.path.lexists(temporary):
  297             os.unlink(temporary)
  298 
  299 
  300 def interrupted(signum, frame):
  301     raise Refused("Dolphin save preparation was interrupted. Saved data was kept. Try again.")
  302 
  303 
  304 def main():
  305     parser = argparse.ArgumentParser(description=__doc__)
  306     parser.add_argument("phase", choices=("check", "prepare"))
  307     parser.add_argument("system", choices=("gamecube", "wii"))
  308     parser.add_argument("--storage", type=Path, default=Path("/storage"))
  309     parser.add_argument("--lock", type=Path, default=Path("/run/dolphin-save-paths.lock"))
  310     parser.add_argument("--error-file", type=Path, default=Path("/tmp/launch_error.log"))
  311     args = parser.parse_args()
  312     try:
  313         for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
  314             signal.signal(sig, interrupted)
  315         signal.alarm(30)
  316         storage = Path(os.path.abspath(args.storage))
  317         fd = os.open(args.lock, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
  318         try:
  319             if not stat.S_ISREG(os.fstat(fd).st_mode):
  320                 raise Refused("Dolphin save preparation lock is unavailable. Try again after the other launch finishes.")
  321             try:
  322                 fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
  323             except BlockingIOError:
  324                 raise Refused("Dolphin save preparation is already running. Wait for it to finish, then try again.") from None
  325             if args.phase == "check":
  326                 plan(storage, args.system)
  327             else:
  328                 apply(storage, args.system)
  329         finally:
  330             os.close(fd)
  331         return 0
  332     except Exception as error:
  333         message = str(error) if isinstance(error, Refused) else "Dolphin could not prepare save storage. Check the storage connection and permissions, then try again. Saved data was kept."
  334         print(message, file=sys.stderr)
  335         print("Dolphin preparation detail: " + str(error), file=sys.stderr)
  336         try:
  337             write_error(args.error_file, message)
  338         except OSError:
  339             print("Could not write the native launch error message.", file=sys.stderr)
  340         return 250
  341     finally:
  342         signal.alarm(0)
  343 
  344 
  345 if __name__ == "__main__":
  346     sys.exit(main())
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/scripts/cheevos_dolphin.sh

```text
    1 #! /bin/bash
    2 
    3 # SPDX-License-Identifier: GPL-2.0-or-later
    4 # Copyright (C) 2024-present ROCKNIX (https://github.com/ROCKNIX)
    5 
    6 . /etc/profile
    7 
    8 LOG_FILE="/var/log/cheevos.log"
    9 
   10 # Extract username, password, token, if enabled, and hardcore mode from system.cfg
   11 username=$(get_setting "global.retroachievements.username")
   12 password=$(get_setting "global.retroachievements.password")
   13 token=$(get_setting "global.retroachievements.token")
   14 enabled=$(get_setting "global.retroachievements")
   15 hardcore=$(get_setting "global.retroachievements.hardcore")
   16 encore=$(get_setting "global.retroachievements.encore")
   17 unofficial=$(get_setting "global.retroachievements.unofficial")
   18 [ -z "${unofficial}" ] && unofficial=$(get_setting "global.retroachievements.testunofficial")  # the spelling before 2026-09; EmulationStation writes .unofficial
   19 hosturl=$(get_setting "global.retroachievements.customhost")
   20 
   21 # Check if RetroAchievements are enabled in Emulation Station
   22 if [ "${enabled}" = 1 ]; then
   23   enabled="True"
   24 else
   25   echo "RetroAchievements are not enabled, please turn them on in Emulation Station." > ${LOG_FILE}
   26   enabled="False"
   27   exit 1
   28 fi
   29 
   30 # Check if api token is present in system.cfg
   31 if [ -z "${token}" ]; then
   32     echo "RetroAchievements token is empty, please log in with your RetroAchievements credentials in Emulation Station." > ${LOG_FILE}
   33     exit 1
   34 fi
   35 
   36 # Set hardcore mode
   37 hardcore_raw="${hardcore}"
   38 if [ "${hardcore}" = 1 ]; then
   39   hardcore="True"
   40 else
   41   hardcore="False"
   42 fi
   43 
   44 # Set encore mode
   45 if [ "${encore}" = 1 ]; then
   46   encore="True"
   47 else
   48   encore="False"
   49 fi
   50 
   51 # Set unofficial mode
   52 if [ "${unofficial}" = 1 ]; then
   53   unofficial="True"
   54 else
   55   unofficial="False"
   56 fi
   57 
   58 # The offline toggle routes only a known casual session to a listening proxy
   59 # (#584, D-RA-002). Keep the configured custom host for every fallback; never
   60 # change saved settings or credentials here. An empty/unknown hardcore read
   61 # is not permission to use a service that cannot queue hardcore awards.
   62 # Dolphin2606 passes HostUrl to rc_client_set_host; its bundled rcheevos adds
   63 # http:// to a host without a scheme. The bare host below therefore uses HTTP.
   64 # Match PPSSPP's read-only IPv4-capable listener check (0 listening, 1 absent,
   65 # 2 unreadable). A listening socket is not proof of proxy identity or readiness.
   66 proxy_listening() {
   67   local proc="${RAOFFLINEPROXY_PROC_NET:-/proc/net}" f readable=0 sl addr rem st rest
   68   for f in "${proc}/tcp" "${proc}/tcp6"; do
   69     [ -r "${f}" ] || continue
   70     readable=1
   71     while read -r sl addr rem st rest; do
   72       [ "${st}" = "0A" ] || continue
   73       case "${addr}" in
   74         0100007F:1F90|00000000:1F90|0000000000000000FFFF00000100007F:1F90) return 0 ;;
   75       esac
   76     done < "${f}"
   77   done
   78   [ "${readable}" -eq 1 ] && return 1
   79   return 2
   80 }
   81 
   82 if [ "$(get_setting "global.retroachievements.offlineproxy")" = 1 ] && [ "${hardcore_raw}" = "0" ]; then
   83   proxy_listening
   84   case $? in
   85     0) hosturl="127.0.0.1:8080" ;;
   86     1) echo "Offline RetroAchievements is on but nothing is listening on 127.0.0.1:8080; keeping the configured achievements host." >> "${LOG_FILE}" ;;
   87     *) echo "Offline RetroAchievements is on but the listener tables could not be read; keeping the configured achievements host." >> "${LOG_FILE}" ;;
   88   esac
   89 fi
   90 
   91 cat <<EOF >/storage/.config/dolphin-emu/RetroAchievements.ini
   92 [Achievements]
   93 DiscordPresenceEnabled = False
   94 Enabled = ${enabled}
   95 EncoreEnabled = ${encore}
   96 HardcoreEnabled = ${hardcore}
   97 ProgressEnabled = False
   98 SpectatorEnabled = False
   99 UnofficialEnabled = ${unofficial}
  100 Username = ${username}
  101 ApiToken = ${token}
  102 HostUrl = ${hosturl}
  103 EOF
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/emulators/standalone/dolphin-sa/package.mk

```text
    1 # SPDX-License-Identifier: GPL-2.0
    2 # Copyright (C) 2024-present ROCKNIX (https://github.com/ROCKNIX)
    3 
    4 PKG_NAME="dolphin-sa"
    5 PKG_VERSION="6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4" #2606
    6 PKG_LICENSE="GPL-2.0-or-later"
    7 PKG_SITE="https://github.com/dolphin-emu/dolphin"
    8 PKG_URL="${PKG_SITE}.git"
    9 PKG_DEPENDS_TARGET="toolchain libevdev libdrm ffmpeg zlib libpng lzo libusb zstd ecm openal-soft pulseaudio alsa-lib libfmt hidapi curl SDL3 qt6 Python3"
   10 PKG_LONGDESC="Dolphin is a GameCube / Wii / Triforce emulator, allowing you to play games for these two platforms on PC with improvements. "
   11 
   12 PKG_DOLPHIN_VERSION_MAJOR="2606"
   13 PKG_DOLPHIN_VERSION_MINOR="1"
   14 
   15 if [ "${OPENGL_SUPPORT}" = "yes" ]; then
   16   PKG_DEPENDS_TARGET+=" ${OPENGL} glu libglvnd"
   17   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_EGL=ON"
   18 elif [ "${OPENGLES_SUPPORT}" = yes ]; then
   19   PKG_DEPENDS_TARGET+=" ${OPENGLES}"
   20   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_EGL=ON"
   21 fi
   22 
   23 # Both frontends can render straight to the compositor. X11 stays compiled in as an
   24 # XWayland fallback; the frontend selects a path at runtime from the window system
   25 # type, so building both only widens what a given image can do.
   26 if [ "${DISPLAYSERVER}" = "wl" ]; then
   27   PKG_DEPENDS_TARGET+=" wayland wayland-protocols ${WINDOWMANAGER} xwayland xrandr libXi"
   28   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_X11=ON \
   29                            -DENABLE_WAYLAND=ON"
   30 else
   31   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_X11=OFF \
   32                            -DENABLE_WAYLAND=OFF"
   33 fi
   34 
   35 if [ "${VULKAN_SUPPORT}" = "yes" ]; then
   36   PKG_DEPENDS_TARGET+=" ${VULKAN}"
   37   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_VULKAN=ON"
   38   GRENDERER="Vulkan"
   39 else
   40   PKG_CMAKE_OPTS_TARGET+=" -DENABLE_VULKAN=OFF"
   41   GRENDERER="OGL"
   42 fi
   43 
   44 # The developer VM has Vulkan headers/loader but no guest Vulkan ICD.
   45 # Keep both compiled backends; automatic launches use its working GL path.
   46 if [ "${DEVICE}" = "GENERIC_X64" ]; then
   47   GRENDERER="OGL"
   48 fi
   49 
   50 # Every device builds both frontends: nogui plays games, Qt provides the settings
   51 # UI from the Tools menu. RetroAchievements lives in Core (AchievementManager) and
   52 # is driven entirely by RetroAchievements.ini, so it is not tied to either one.
   53 PKG_CMAKE_OPTS_TARGET+=" -DENABLE_QT=ON \
   54                          -DUSE_RETRO_ACHIEVEMENTS=ON \
   55                          -DENABLE_HEADLESS=OFF \
   56                          -DCMAKE_EXE_LINKER_FLAGS=-flto=$(nproc) \
   57                          -DCMAKE_BUILD_TYPE=Release \
   58                          -DDISTRIBUTOR="ROCKNIX" \
   59                          -DENABLE_NOGUI=ON \
   60                          -DENABLE_EVDEV=ON \
   61                          -DENABLE_SDL=ON \
   62                          -DUSE_DISCORD_PRESENCE=OFF \
   63                          -DBUILD_SHARED_LIBS=OFF \
   64                          -DLINUX_LOCAL_DEV=OFF \
   65                          -DENABLE_PULSEAUDIO=ON \
   66                          -DENABLE_ALSA=ON \
   67                          -DENABLE_TESTS=OFF \
   68                          -DENABLE_LLVM=OFF \
   69                          -DENABLE_ANALYTICS=OFF \
   70                          -DENABLE_LTO=ON \
   71                          -DENCODE_FRAMEDUMPS=OFF \
   72                          -DENABLE_AUTOUPDATE=OFF \
   73                          -DUSE_MGBA=OFF \
   74                          -DENABLE_CLI_TOOL=OFF \
   75                          -DCMAKE_POLICY_VERSION_MINIMUM=3.5"
   76 
   77 
   78 post_unpack() {
   79   sed -i "s|gcc-ar|${TARGET_PREFIX}ar|g" "${PKG_BUILD}/CMakeLists.txt"
   80   sed -i "s|gcc-ranlib|${TARGET_PREFIX}ranlib|g" "${PKG_BUILD}/CMakeLists.txt"
   81   sed -i 's~#include <cstdlib>~#include <cstdlib>\n#include <cstdint>~g' ${PKG_BUILD}/Externals/VulkanMemoryAllocator/include/vk_mem_alloc.h
   82   sed -i 's~#include <cstdint>~#include <cstdint>\n#include <string>~g' ${PKG_BUILD}/Externals/VulkanMemoryAllocator/include/vk_mem_alloc.h
   83   if [ -n "${PKG_DOLPHIN_VERSION_MAJOR=}" ]; then
   84     sed -e "s/@PKG_DOLPHIN_VERSION_MAJOR@/${PKG_DOLPHIN_VERSION_MAJOR}/g" -i ${PKG_BUILD}/CMake/ScmRevGen.cmake
   85     sed -e "s/@PKG_DOLPHIN_VERSION_MINOR@/${PKG_DOLPHIN_VERSION_MINOR}/g" -i ${PKG_BUILD}/CMake/ScmRevGen.cmake
   86   fi
   87 }
   88 
   89 makeinstall_target() {
   90   mkdir -p ${INSTALL}/usr/bin
   91     cp -a ${PKG_BUILD}/.${TARGET_NAME}/Binaries/dolphin* ${INSTALL}/usr/bin
   92     cp -a ${PKG_DIR}/scripts/* ${INSTALL}/usr/bin
   93 
   94   mkdir -p ${INSTALL}/usr/config/dolphin-emu
   95     cp -a ${PKG_BUILD}/Data/Sys/* ${INSTALL}/usr/config/dolphin-emu
   96     cp -aL ${PKG_DIR}/config/${DEVICE}/* ${INSTALL}/usr/config/dolphin-emu
   97     cp -a ${PKG_DIR}/triforce ${INSTALL}/usr/config/dolphin-emu/triforce_gecko_codes
   98 }
   99 
  100 post_install() {
  101   # The Qt frontend renders straight to the compositor on every device. Patch 016 is
  102   # what makes this take effect; upstream otherwise rewrites the value back to xcb.
  103   EXPORTS="export QT_QPA_PLATFORM=wayland"
  104 
  105   # nogui is the default player, so its -p platform is Wayland everywhere.
  106   DOLPHIN_BACKEND="wayland"
  107 
  108   for script in start_dolphin_{gc,wii}.sh; do
  109     sed -i \
  110         -e "s/@DOLPHIN_BACKEND@/${DOLPHIN_BACKEND}/g" \
  111         -e "s/@GRENDERER@/${GRENDERER}/g" \
  112         -e "s/@EXPORTS@/${EXPORTS}/g" \
  113         "${INSTALL}/usr/bin/$script"
  114   done
  115 }
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/rocknix/sources/scripts/wifictl

```text
    1 #!/bin/bash
    2 # SPDX-License-Identifier: Apache-2.0
    3 # Copyright (C) 2023 JELOS (https://github.com/JustEnoughLinuxOS)
    4 # Copyright (C) 2022 kkoshelev (https://github.com/kkoshelev)
    5 # Copyright (C) 2026 ROCKNIX (https://github.com/ROCKNIX)
    6 # Wi-Fi via NetworkManager (iwd backend). AP/netplay still uses iwctl on the interface.
    7 
    8 . /etc/profile
    9 
   10 NMCLI="$(command -v nmcli 2>/dev/null)"
   11 
   12 ###
   13 ### Basic WIFI properties used across the tool.
   14 ###
   15 ### Usage:
   16 ###     wifictl command [ssid] [psk]
   17 ###     wifictl list / scanlist  SSIDs on success, including nothing and exit 0;
   18 ###                               exit 2 when the adapter or nmcli is unavailable;
   19 ###                               nonzero when readiness, rescan, or enumeration fails
   20 ###
   21 ### For the interface's network rows (fork #191), reading NetworkManager
   22 ### rather than the wifi.ssid setting:
   23 ###     wifictl current           the network joined now; nothing and exit 1 when none,
   24 ###                               exit 2 when NetworkManager could not be asked
   25 ###     wifictl saved             the remembered networks, one per line: <name><TAB>active|saved
   26 ###     wifictl saved --ssid      the same with each profile's SSID between: <name><TAB><ssid><TAB>active|saved,
   27 ###                               a tab or backslash inside the name or the SSID written \t or \\;
   28 ###                               nothing and exit 1 when any of it could not be read
   29 ###     wifictl forget <name>     forget one: prints "forgotten", then "disconnected" on a
   30 ###                               second line when it was the one in use, and clears wifi.ssid /
   31 ###                               wifi.key when they name it; exit 1, nothing printed, when it is
   32 ###                               not a remembered network or the delete failed; exit 2 when
   33 ###                               NetworkManager could not be asked
   34 ###     wifictl join <name>       join a saved network with the key NetworkManager holds for it
   35 ###                               (the picker's press on a SAVED row): prints "joined" once its
   36 ###                               profile is active and moves wifi.ssid / wifi.key onto it; exit 1,
   37 ###                               nothing printed, when it is not a saved network or the
   38 ###                               activation failed; exit 2 when NetworkManager could not be asked
   39 ###
   40 
   41 WIFI_TYPE=$(get_setting wifi.adhoc.enabled)
   42 NETWORK_ADDRESS="192.168.80"
   43 ADHOC_CLIENT_ID=$(get_setting wifi.adhoc.id)
   44 [ -z "${ADHOC_CLIENT_ID}" ] && ADHOC_CLIENT_ID="1"
   45 NETPLAY_SSID="NETPLAY_AP"
   46 WIFI_DEV="$(ls /sys/class/net | grep -m1 ^wlan)"
   47 
   48 # Typed scan/security/join callers must not read an unavailable radio as success.
   49 if [ "${1}" = list ] || [ "${1}" = scanlist ] || \
   50    [ "${1}" = security ] || [ "${1}" = connect-open ]; then
   51   [ -n "${WIFI_DEV}" ] && [ -d "/sys/class/net/${WIFI_DEV}" ] && [ -n "${NMCLI}" ] || exit 2
   52 fi
   53 
   54 # Exit the script if the WiFi device isn't available
   55 [ -z "${WIFI_DEV}" ] && exit 0
   56 [ ! -d "/sys/class/net/${WIFI_DEV}" ] && exit 0
   57 [ -z "${NMCLI}" ] && exit 0
   58 
   59 SSID="${2:-$(get_setting wifi.ssid 2>/dev/null)}"
   60 PSK="${3-$(get_setting wifi.key 2>/dev/null)}"
   61 COUNTRY="${4:-$(get_setting wifi.country | tr -d '[:space:]' 2>/dev/null)}"
   62 
   63 if [ "${WIFI_TYPE}" = "1" ]; then
   64   SSID="${NETPLAY_SSID}"
   65   PSK="deadbeef"
   66 fi
   67 
   68 ###
   69 ### Functions...
   70 ###
   71 
   72 # Wait for iwd to start and have a device available. A successful query that
   73 # never sees the adapter is exit 1; a failed final query keeps its status.
   74 # Connection/AP callers still make their own operation the final result.
   75 wait_for_wifi() {
   76   local i devices status=1
   77   for i in $(seq 1 5); do
   78     if devices=$(iwctl device list); then
   79       if grep -q "${WIFI_DEV}" <<< "${devices}"; then
   80         status=0
   81         break
   82       fi
   83       status=1
   84     else
   85       status=$?
   86     fi
   87     sleep 1
   88   done
   89   if [ -n "${COUNTRY}" ]; then
   90     iw reg set "${COUNTRY}" || return $?
   91   fi
   92   return "${status}"
   93 }
   94 
   95 # lists all wifi networks, each name as the network has it: terse output
   96 # escapes ':' and '\', so "Cafe: Guest" arrived as "Cafe\: Guest" from here
   97 # and as "Cafe: Guest" from current and saved, and the picker -- which
   98 # compares names exactly -- showed the network twice and tried to connect
   99 # to the escaped name (#308 claude F-WF-05). nm_unescape is defined below;
  100 # this runs after the whole file is read.
  101 list_wifi() {
  102   local rows
  103   wait_for_wifi >/dev/null || return $?
  104   "${NMCLI}" -w 15 dev wifi rescan ifname "${WIFI_DEV}" >/dev/null 2>&1 || return $?
  105   sleep 1
  106   # Capture the producer's status before filtering, and discard partial rows
  107   # on failure. Empty successful output is a different answer from no answer.
  108   rows=$("${NMCLI}" -t -f SSID dev wifi list ifname "${WIFI_DEV}" 2>/dev/null) || return $?
  109   (set -o pipefail; printf '%s\n' "${rows}" | nm_unescape | sed '/^$/d' | sort -u)
  110 }
  111 
  112 # Only an explicit, unanimous open result may skip the key prompt. SECURITY
  113 # has no colons; SSIDs do, escaped by nmcli. Unknown/mixed scans fail closed.
  114 wifi_security() {
  115   local wanted="${1}" rows line name security found=0 open=0 protected=0
  116   rows=$(LC_ALL=C "${NMCLI}" -t -f SSID,SECURITY device wifi list ifname "${WIFI_DEV}" --rescan no 2>/dev/null) || { echo unknown; return 1; }
  117   while IFS= read -r line; do
  118     [[ "${line}" == *:* ]] || continue
  119     name=$(printf '%s\n' "${line%:*}" | nm_unescape)
  120     [ "${name}" = "${wanted}" ] || continue
  121     found=1
  122     security="${line##*:}"
  123     case "${security}" in
  124       ''|--) open=1 ;;
  125       *WPA*|*WEP*|*802.1X*|*OWE*) protected=1 ;;
  126       *) echo unknown; return 1 ;;
  127     esac
  128   done <<< "${rows}"
  129   if [ "${found}" = 0 ] || { [ "${open}" = 1 ] && [ "${protected}" = 1 ]; }; then
  130     echo unknown; return 1
  131   fi
  132   if [ "${open}" = 1 ]; then echo open; else echo protected; fi
  133 }
  134 
  135 # An unsaved open network never borrows wifi.key or deletes a saved profile.
  136 # Check again at the mutation boundary, including profiles renamed by NM.
  137 connect_open_wifi() {
  138   local name="${1}" rows line profile saved_ssid
  139   [ "${WIFI_TYPE}" != 1 ] && [ -n "${name}" ] || return 1
  140   [ "$(wifi_security "${name}")" = open ] || return 1
  141   rows=$(saved_wifi) || return 1
  142   while IFS= read -r line; do
  143     [ -n "${line}" ] || continue
  144     profile="${line%$'\t'*}"
  145     saved_ssid=$("${NMCLI}" --escape no -g 802-11-wireless.ssid connection show id "${profile}" 2>/dev/null) || return 1
  146     [ "${profile}" != "${name}" ] && [ "${saved_ssid}" != "${name}" ] || return 1
  147   done <<< "${rows}"
  148   wait_for_wifi
  149   "${NMCLI}" -w 90 device wifi connect "${name}" ifname "${WIFI_DEV}" >/dev/null 2>&1
  150 }
  151 
  152 connect_wifi() {
  153   wait_for_wifi
  154   # Ensure NM has the device ready and has scanned
  155   for i in $(seq 1 10); do
  156     "${NMCLI}" -t -f DEVICE,STATE dev status 2>/dev/null | grep -q "^${WIFI_DEV}:disconnected" && break
  157     "${NMCLI}" -t -f DEVICE,STATE dev status 2>/dev/null | grep -q "^${WIFI_DEV}:connected" && break
  158     sleep 1
  159   done
  160   "${NMCLI}" dev wifi rescan ifname "${WIFI_DEV}" 2>/dev/null
  161   sleep 2
  162   # If a keyfile profile for this SSID already exists but is incomplete (e.g. missing
  163   # 802-11-wireless-security.key-mgmt), NM fails connection-update with "key-mgmt: property is missing".
  164   # Drop the stale profile so "device wifi connect" creates a clean one.
  165   # Two lines taken from ROCKNIX's own saved-network work (spycat88,
  166   # b1f8464241; the merged design D-UI-118, #318): with no key given, a
  167   # profile NetworkManager already holds for the name is brought up before
  168   # anything is deleted and rebuilt -- the settings-driven paths (ENABLE
  169   # WI-FI, the restore wizard) reach a saved network that way -- and a keyed
  170   # connect stores the key in the profile explicitly (psk-flags 0), so a
  171   # later join can read it.
  172   if [ -z "${PSK}" ] && "${NMCLI}" -w 30 connection up id "${SSID}" ifname "${WIFI_DEV}" >/dev/null 2>&1; then
  173     return 0
  174   fi
  175   "${NMCLI}" connection delete id "${SSID}" >/dev/null 2>&1 || true
  176   if [ -n "${PSK}" ]; then
  177     "${NMCLI}" -w 90 device wifi connect "${SSID}" password "${PSK}" ifname "${WIFI_DEV}" >/dev/null 2>&1 || return 1
  178     "${NMCLI}" connection modify "${SSID}" wifi-sec.psk-flags 0 >/dev/null 2>&1 || true
  179   else
  180     "${NMCLI}" -w 90 device wifi connect "${SSID}" ifname "${WIFI_DEV}" >/dev/null 2>&1
  181   fi
  182 }
  183 
  184 create_adhoc() {
  185   wait_for_wifi
  186   # NetworkManager drives iwd into AP mode itself (Device.Mode + AP.Start).
  187   # Switching the mode behind its back only makes NM force the device back to
  188   # station mode, so the netplay AP has to be a NetworkManager connection.
  189   # No DHCP: the clients derive their address from the local play ID.
  190   "${NMCLI}" connection delete id "${SSID}" >/dev/null 2>&1
  191   "${NMCLI}" connection add type wifi ifname "${WIFI_DEV}" con-name "${SSID}" ssid "${SSID}" \
  192     802-11-wireless.mode ap \
  193     802-11-wireless.band bg \
  194     802-11-wireless-security.key-mgmt wpa-psk \
  195     802-11-wireless-security.psk "${PSK}" \
  196     ipv4.method manual ipv4.addresses "${NETWORK_ADDRESS}.${ADHOC_CLIENT_ID}/24" \
  197     ipv6.method disabled || return 1
  198   "${NMCLI}" -w 30 connection up id "${SSID}" || return 1
  199 }
  200 
  201 connect_adhoc_client() {
  202   destroy_adhoc
  203   # Static lease: the netplay host runs no DHCP server, so the client
  204   # address is derived from the local play ID. Autoconnect stays off so a
  205   # vanished host doesn't keep the device from returning to ordinary
  206   # networks; rejoining is an explicit wifictl connect (ES toggle).
  207   "${NMCLI}" connection add type wifi ifname "${WIFI_DEV}" con-name "${SSID}" ssid "${SSID}" \
  208     802-11-wireless-security.key-mgmt wpa-psk \
  209     802-11-wireless-security.psk "${PSK}" \
  210     ipv4.method manual ipv4.addresses "${NETWORK_ADDRESS}.${ADHOC_CLIENT_ID}/24" \
  211     ipv6.method disabled connection.autoconnect no || return 1
  212   # The iwd backend fails "connection up" instantly when the SSID is not in
  213   # the scan cache yet, so make sure the host AP shows up first
  214   for i in $(seq 1 15); do
  215     "${NMCLI}" device wifi rescan ifname "${WIFI_DEV}" >/dev/null 2>&1
  216     sleep 2
  217     "${NMCLI}" -t -f SSID device wifi list ifname "${WIFI_DEV}" 2>/dev/null | grep -q "^${SSID}$" && break
  218   done
  219   "${NMCLI}" -t -f SSID device wifi list ifname "${WIFI_DEV}" 2>/dev/null | grep -q "^${SSID}$" || return 1
  220   # The host may still be coming up
  221   for i in $(seq 1 3); do
  222     "${NMCLI}" -w 20 connection up id "${SSID}" && return 0
  223     sleep 3
  224   done
  225   return 1
  226 }
  227 
  228 destroy_adhoc() {
  229   # Remove the netplay connection (host or client) so NM autoconnect
  230   # can't resurrect it and the device returns to the ordinary networks
  231   "${NMCLI}" connection delete id "${NETPLAY_SSID}" >/dev/null 2>&1
  232 }
  233 
  234 # Prefer the network currently in use for the next automatic connection. On
  235 # resume the radio is only rfkill-unblocked, so NetworkManager autoconnect
  236 # chooses among every saved profile and can join a different access point than
  237 # the one in use -- often on another subnet, silently moving the device and
  238 # dropping whatever was connected. The same applies at boot. Raising the
  239 # priority of the active profile makes NM try that one first.
  240 #
  241 # Priority only, deliberately: every profile keeps autoconnect enabled, so a
  242 # preferred network that is out of range just loses to whatever is in range.
  243 # Turning autoconnect off on the others would pin harder but strand the device
  244 # on a network it can no longer see. With no active connection there is nothing
  245 # to prefer, and the priorities from the previous call still stand.
  246 pin_wifi() {
  247   local active name
  248 
  249   active=$("${NMCLI}" -t -f GENERAL.CONNECTION device show "${WIFI_DEV}" 2>/dev/null | cut -d: -f2-)
  250   [ -z "${active}" ] && return 0
  251 
  252   "${NMCLI}" -t -f NAME,TYPE connection show 2>/dev/null |
  253     awk -F: '$2 ~ /wireless/ {print $1}' |
  254     while IFS= read -r name; do
  255       if [ "${name}" = "${active}" ]; then
  256         "${NMCLI}" connection modify "${name}" connection.autoconnect-priority 100 >/dev/null 2>&1
  257       else
  258         "${NMCLI}" connection modify "${name}" connection.autoconnect-priority 0 >/dev/null 2>&1
  259       fi
  260     done
  261 }
  262 
  263 # What NetworkManager remembers and what it is joined to, for the interface
  264 # (fork #191). The setting wifi.ssid is the network the player configured
  265 # last; NetworkManager keeps a profile for every network the device has
  266 # joined and autoconnects to whichever remembered one is in range, so the
  267 # two are not the same network -- and NETWORK SETTINGS showed the setting as
  268 # though it were the connection. These read NetworkManager itself.
  269 #
  270 # nmcli -t separates fields with ':' and escapes a ':' or '\' inside a value
  271 # with a backslash. A network's name can carry either, so the fields that
  272 # cannot (TYPE, ACTIVE) are taken from the right, and the name is unescaped
  273 # once it stands alone.
  274 nm_unescape() {
  275   sed 's/\\\(.\)/\1/g'
  276 }
  277 
  278 # The state saved_wifi gives a remembered network, by its whole name: the
  279 # name is everything before the LAST tab (the state is after it), as the
  280 # interface's parser reads it. awk -F'\t' compared the part before the
  281 # FIRST tab, so a profile whose name holds a tab -- listed as SAVED and
  282 # accepted by the interface -- could be neither joined nor forgotten (#308
  283 # claude F-WF-06, gpt F-WF-04). The name crosses through the environment,
  284 # not awk -v, which would read backslashes in it as escapes.
  285 saved_state() { # <saved_wifi rows> <name>
  286   printf '%s\n' "${1}" | NAME="${2}" awk '{ n = $0; sub(/\t[^\t]*$/, "", n); if (n == ENVIRON["NAME"]) { s = $0; sub(/^.*\t/, "", s); print s } }'
  287 }
  288 
  289 # The SSID the device is joined to now: the one access point NetworkManager
  290 # marks active, from the list it already holds (no rescan). Nothing and exit
  291 # 1 when the device is joined to none; exit 2 when NetworkManager could not
  292 # be asked, so a caller cannot read a silence as "not connected".
  293 current_wifi() {
  294   local aps ssid
  295   aps=$("${NMCLI}" -t -f ACTIVE,SSID device wifi list ifname "${WIFI_DEV}" --rescan no 2>/dev/null) || return 2
  296   ssid=$(printf '%s\n' "${aps}" | sed -n 's/^yes://p' | head -n 1 | nm_unescape)
  297   [ -n "${ssid}" ] || return 1
  298   printf '%s\n' "${ssid}"
  299 }
  300 
  301 # Every network NetworkManager remembers: one line per wireless profile,
  302 # <name><TAB>active or <name><TAB>saved, in nmcli's order (the one in use
  303 # first). Wired and other profiles are not networks a player joined and are
  304 # left out. Exit 1 with nothing printed when NetworkManager could not be
  305 # asked -- an empty list and no list are different answers.
  306 saved_wifi() {
  307   local profiles
  308   profiles=$("${NMCLI}" -t -f NAME,TYPE,ACTIVE connection show 2>/dev/null) || return 1
  309   printf '%s\n' "${profiles}" |
  310     awk -F: 'NF >= 3 && $(NF-1) ~ /wireless/ {
  311       name = $1; for (i = 2; i <= NF - 2; i++) name = name ":" $i
  312       print name "\t" ($NF == "yes" ? "active" : "saved")
  313     }' | nm_unescape
  314 }
  315 
  316 # saved with each profile's SSID (--ssid): a profile's name need not be its
  317 # SSID (renamed, or NetworkManager's own "Home 1"), and the picker marks a
  318 # scanned network SAVED by its SSID (stream E2's 6caac243c, #308 F-WF-12).
  319 # A third column, not a change to saved's own shape, which the interface's
  320 # parser and join and forget read: <name><TAB><ssid><TAB>active|saved, with
  321 # a tab or backslash inside the name or the SSID written \t or \\ so the
  322 # three fields split cleanly. Buffered: an SSID that cannot be read prints
  323 # nothing and exits 1, never a list short of one.
  324 field_escape() {
  325   local v="${1//\\/\\\\}"
  326   printf '%s' "${v//$'\t'/\\t}"
  327 }
  328 saved_with_ssids() {
  329   local rows line name state ssid out=""
  330   rows=$(saved_wifi) || return 1
  331   while IFS= read -r line; do
  332     [ -n "${line}" ] || continue
  333     name="${line%$'\t'*}"; state="${line##*$'\t'}"
  334     ssid=$("${NMCLI}" --escape no -g 802-11-wireless.ssid connection show id "${name}" 2>/dev/null) || return 1
  335     out="${out}$(field_escape "${name}")"$'\t'"$(field_escape "${ssid}")"$'\t'"${state}"$'\n'
  336   done <<< "${rows}"
  337   printf '%s' "${out}"
  338 }
  339 
  340 # Forget a remembered network: delete its profile, and say when that dropped
  341 # the connection. Prints "forgotten" once the profile is gone, then
  342 # "disconnected" on a second line when it was the one in use --
  343 # NetworkManager deactivates a profile as it deletes it, so the device is
  344 # off that network from this moment (autoconnect may then join another
  345 # remembered one in range). A name that is not a remembered wireless
  346 # network, a NetworkManager that cannot be asked, or a delete that fails:
  347 # nothing printed and exit 1, so a caller cannot read a refusal as done.
  348 # The name is matched whole (saved_state).
  349 #
  350 # NetworkManager not answering is exit 2, as for current and join: "could
  351 # not ask" is a different answer from "no such network" (#308 claude
  352 # F-WF-07). And a network forgotten here is forgotten in the settings too:
  353 # when wifi.ssid names it (by SSID, or by the profile name an older join
  354 # wrote), wifi.ssid and wifi.key are removed -- otherwise the paths that
  355 # connect from the settings (ENABLE WI-FI, the restore wizard; the WI-FI
  356 # KEY row until #318) rebuilt the profile the player had just forgotten, with its key,
  357 # which also stayed in system.cfg and travelled in the settings backup
  358 # (#308 claude F-WF-01, gpt F-WF-07).
  359 forget_wifi() {
  360   local name="${1}" rows state ssid named
  361   [ -n "${name}" ] || return 1
  362   rows=$(saved_wifi) || return 2
  363   state=$(saved_state "${rows}" "${name}")
  364   [ -n "${state}" ] || return 1
  365   #
  366   # And the settings go first, checked, and come back if the delete then
  367   # fails: a forget that deleted the profile and could not clear the
  368   # settings said "forgotten" while the settings-driven paths could still
  369   # rebuild it; an SSID that could not be read is not guessed at (exit 2)
  370   # (#307, the audit of the fixes, gpt G-B-11).
  371   #
  372   # The pair is cleared, and put back, in one write each (set_settings): two
  373   # set_setting calls could fail between them, and the put-back after a
  374   # failed delete was not checked at all (#307, the audit of the fix round,
  375   # gpt G2-B-11). A put-back that fails is said in the log, with the state
  376   # it leaves.
  377   local key clear=0
  378   ssid=$("${NMCLI}" --escape no -g 802-11-wireless.ssid connection show id "${name}" 2>/dev/null) || return 2
  379   named=$(get_setting wifi.ssid 2>/dev/null)
  380   if [ -n "${named}" ] && { [ "${named}" = "${name}" ] || [ "${named}" = "${ssid}" ]; }; then
  381     clear=1
  382     key=$(get_setting wifi.key 2>/dev/null)
  383     if ! set_settings wifi.ssid default wifi.key default; then
  384       return 1
  385     fi
  386   fi
  387   if ! "${NMCLI}" connection delete id "${name}" >/dev/null 2>&1; then
  388     if [ "${clear}" -eq 1 ] && ! set_settings wifi.ssid "${named}" wifi.key "${key}"; then
  389       logger -t wifictl "forget ${name}: its profile could not be deleted, and the Wi-Fi settings cleared for it could not be put back; wifi.ssid and wifi.key are unset while the profile remains" 2>/dev/null
  390     fi
  391     return 1
  392   fi
  393   echo "forgotten"
  394   case "${state}" in *active*) echo "disconnected" ;; esac
  395   return 0
  396 }
  397 
  398 # Join a saved network by its profile, with the key NetworkManager holds --
  399 # the picker's press on a network the device has joined before (fork #191;
  400 # the maintainer's paradigm of 2026-09-15: the WI-FI NETWORK row -- WI-FI SSID
  401 # until D-UI-071 renamed it -- is the network
  402 # you are on, the list behind it is what is in range, a saved one joins with
  403 # a press). `connect` would have deleted the profile and rebuilt it from the
  404 # wifi.key setting, which held the last key typed, for some other network
  405 # (the WI-FI KEY row that wrote it is gone since #318, D-UI-118).
  406 # Prints "joined" once the profile is active (at once when it already is),
  407 # then the settings wifi.ssid and wifi.key follow the profile, so the paths
  408 # that connect from the settings -- the ENABLE WI-FI switch, the restore
  409 # wizard -- name the network the player is on; the key is
  410 # read from NetworkManager and never printed. pin_wifi then prefers this
  411 # network at the next boot and resume. A name that is not a saved wireless
  412 # network, or an activation that fails: nothing printed, exit 1. NetworkManager
  413 # not answering: exit 2, so a caller cannot read a silence as a refusal.
  414 # The profile active on this device's adapter, by name, unescaped. A
  415 # profile's ACTIVE in saved_wifi says it is up somewhere -- on any adapter.
  416 wifi_dev_connection() {
  417   "${NMCLI}" -t -f GENERAL.CONNECTION device show "${WIFI_DEV}" 2>/dev/null | sed -n 's/^GENERAL\.CONNECTION://p' | nm_unescape
  418 }
  419 
  420 join_wifi() {
  421   local name="${1}" rows state psk
  422   [ -n "${name}" ] || return 1
  423   rows=$(saved_wifi) || return 2
  424   state=$(saved_state "${rows}" "${name}")
  425   [ -n "${state}" ] || return 1
  426   # Judged on the adapter the picker speaks for (WIFI_DEV, as current_wifi
  427   # is): a profile already up on another adapter read as "active" and
  428   # skipped the activation, and "joined" was said while this adapter stayed
  429   # on another network (#307 PL-031). So the profile is brought up on
  430   # WIFI_DEV by name, and joined is said only once WIFI_DEV reads it.
  431   if [ "$(wifi_dev_connection)" != "${name}" ]; then
  432     "${NMCLI}" -w 90 connection up id "${name}" ifname "${WIFI_DEV}" >/dev/null 2>&1 || return 1
  433     [ "$(wifi_dev_connection)" = "${name}" ] || return 1
  434   fi
  435   # The key as NetworkManager holds it, byte for byte. -g is terse output,
  436   # which escapes ':' and '\' in a value -- ab:cd\ef12345 came back as
  437   # ab\:cd\\ef12345 on the target's nmcli (guest d, 2026-09-27) and that was
  438   # stored as wifi.key -- so --escape no (#307 PL-003). Its status is read
  439   # before anything is written: a read that failed is not an open network,
  440   # and writing its empty answer over wifi.key cleared the key of a network
  441   # the device is on (#308 claude F-WF-02). An empty key is written only
  442   # when the profile has no key management -- an open network; a keyed one
  443   # whose key did not come back leaves the settings as they were. Either
  444   # way the device is joined, and says so.
  445   #
  446   # And wifi.ssid is the network's SSID, not the profile's name: the two
  447   # differ for a renamed profile or one NetworkManager deduplicated ("Home
  448   # 1"), and connect -- which the settings-driven paths run -- looks the
  449   # SSID up in the scan, where a profile's name is not found (#308 claude
  450   # F-WF-12, gpt F-WF-03).
  451   local keyed ssid
  452   if psk=$("${NMCLI}" --escape no -s -g 802-11-wireless-security.psk connection show id "${name}" 2>/dev/null) \
  453      && ssid=$("${NMCLI}" --escape no -g 802-11-wireless.ssid connection show id "${name}" 2>/dev/null) \
  454      && [ -n "${ssid}" ]; then
  455     if [ -z "${psk}" ]; then
  456       keyed=$("${NMCLI}" --escape no -g 802-11-wireless-security.key-mgmt connection show id "${name}" 2>/dev/null) || keyed="unread"
  457     fi
  458     if [ -z "${psk}" ] && [ -n "${keyed}" ]; then
  459       logger -t wifictl "joined ${name}; its key did not come back from NetworkManager, so the Wi-Fi settings were left as they were" 2>/dev/null
  460     elif ! set_settings wifi.ssid "${ssid}" wifi.key "${psk}"; then
  461       # One write for the pair (set_settings): a second write failing after
  462       # the first left this network's SSID with the last network's key, and
  463       # nothing said so (#307, the audit of the fix round, gpt G2-B-11).
  464       # The device is joined either way, and says so.
  465       logger -t wifictl "joined ${name}; its Wi-Fi settings could not be saved, so they were left as they were" 2>/dev/null
  466     fi
  467   else
  468     logger -t wifictl "joined ${name}; its key or SSID could not be read from NetworkManager, so the Wi-Fi settings were left as they were" 2>/dev/null
  469   fi
  470   pin_wifi
  471   echo "joined"
  472   return 0
  473 }
  474 
  475 has_ap_mode() {
  476   wait_for_wifi
  477 
  478   PHY=$(basename "$(readlink /sys/class/net/${WIFI_DEV}/phy80211)")
  479   if iwctl adapter "$PHY" show | grep -q 'SupportedModes.*ap'; then
  480     exit 0
  481   else
  482     exit 1
  483   fi
  484 }
  485 
  486 case "${1}" in
  487   enable)
  488     rfkill unblock wifi
  489     ;;
  490   disable)
  491     rfkill block wifi
  492     ;;
  493   pin)
  494     pin_wifi
  495     ;;
  496   security)
  497     wifi_security "${2}"
  498     ;;
  499   connect-open)
  500     connect_open_wifi "${2}"
  501     ;;
  502   connect)
  503     if [ "${WIFI_TYPE}" = "1" ] && \
  504        [ "${ADHOC_CLIENT_ID}" = "1" ]; then
  505       create_adhoc
  506     elif [ "${WIFI_TYPE}" = "1" ]; then
  507       connect_adhoc_client
  508     else
  509       destroy_adhoc
  510       connect_wifi
  511     fi
  512   ;;
  513   disconnect)
  514     if [ "${WIFI_TYPE}" = "1" ]; then
  515       destroy_adhoc
  516     else
  517       "${NMCLI}" device disconnect "${WIFI_DEV}" >/dev/null 2>&1
  518     fi
  519     ;;
  520   reconnect)
  521     /usr/bin/wifictl disconnect
  522     /usr/bin/wifictl connect
  523     ;;
  524   list)
  525     list_wifi
  526     ;;
  527   channels)
  528     iw list | awk '/[0-9] MHz \[/ && ! /disabled|radar|no IR/ { gsub(/^.*\[/,""); gsub(/\].*$/,""); print}'
  529     ;;
  530   has_ap_mode)
  531     has_ap_mode
  532     ;;
  533   scan)
  534     "${NMCLI}" dev wifi rescan ifname "${WIFI_DEV}" 2>/dev/null
  535     ;;
  536   scanlist)
  537     "${NMCLI}" -w 15 dev wifi rescan ifname "${WIFI_DEV}" >/dev/null 2>&1 || exit $?
  538     sleep 2
  539     list_wifi
  540     ;;
  541   current)
  542     current_wifi
  543     ;;
  544   saved)
  545     if [ "${2:-}" = "--ssid" ]; then
  546       saved_with_ssids
  547     else
  548       saved_wifi
  549     fi
  550     ;;
  551   forget)
  552     forget_wifi "${2}"
  553     ;;
  554   join)
  555     join_wifi "${2}"
  556     ;;
  557 esac
```

## DISTRO fac608ff8994:projects/ROCKNIX/packages/network/raofflineproxy/sources/raofflineproxy-ctl

```text
 1400     if gamelist.is_file():
 1401         try:
 1402             size = gamelist.stat().st_size
 1403         except OSError:
 1404             size = 0
 1405         take(gamelist)
 1406     recovery = es_dir / "recovery" / name
 1407     if recovery.is_dir():
 1408         for dirpath, dirnames, filenames in os.walk(recovery):
 1409             dirnames.sort()
 1410             for fn in sorted(filenames):
 1411                 if fn.lower().endswith(".xml"):
 1412                     take(Path(dirpath) / fn, parent=size)
 1413     return entries
 1414 
 1415 
 1416 config = load_config()
 1417 storage = Storage()
 1418 
 1419 
 1420 def is_cached(game_id, hash_value):
 1421     """Everything a launch reads, for this account and this dump."""
 1422     return (
 1423         storage.get_cache(cache_keys.patch(game_id, user)) is not None
 1424         and storage.get_cache(cache_keys.unlocks(game_id, user)) is not None
 1425         and storage.get_cache(cache_keys.achievementsets(hash_value, user)) is not None
 1426     )
 1427 
 1428 
 1429 # The ROMs this account's patch rows name (rom_browser.load_cached_rom_paths,
 1430 # narrowed to the account), in the client's own two-component form -- where
 1431 # the game is ready for this account (whole_games: its unlocks row and an
 1432 # achievementsets row of the game), as is_cached asks of an indexed game. A patch row alone (a fetch that failed after the first write, or
 1433 # rows an older client's eviction thinned) used to pass the ROM over for
 1434 # ever; now it is a job again (#308 F-RA-14). The dump's own sets row cannot
 1435 # be asked here -- an unindexed ROM's hash is what the job finds out.
 1436 HEAD_VALUE = re.compile(r"\s*:\s*(\d+)\s*[,}]")
 1437 HEAD_COLON = re.compile(r"\s*:")
 1438 def head_game_id(head):
 1439     depth, i, n = 0, 0, len(head)
 1440     while i < n:
 1441         c = head[i]
 1442         if c == "\"":
 1443             j = i + 1
 1444             while j < n and head[j] != "\"":
 1445                 j += 2 if head[j] == "\\" else 1
 1446             if j >= n:
 1447                 return None
 1448             if depth == 1 and head[i + 1:j] == "GameId":
 1449                 whole = HEAD_VALUE.match(head, j + 1)
 1450                 if whole:
 1451                     return int(whole.group(1))
 1452                 if HEAD_COLON.match(head, j + 1):
 1453                     return None
 1454             i = j + 1
 1455             continue
 1456         if c in "{[":
 1457             depth += 1
 1458         elif c in "}]":
 1459             depth -= 1
 1460         i += 1
 1461     return None
 1462 
 1463 
 1464 def whole_games():
 1465     """The games ready for this account -- the unlocks row and an
 1466     achievementsets row of the game, the rows a launch reads -- by the same
 1467     rule as the shell's ready_games_into (audit of the fixes, claude G-D-08,
 1468     gpt G-D-04). A sets row's GameId is read from its first 512 characters,
 1469     where the service writes it, and from the whole body only when they do
 1470     not hold it: every body parsed whole at every listing was tens of
 1471     megabytes on a large store. The head answers only with the body's own
 1472     key and a number that ends inside it (head_game_id above, the same text
 1473     as in the shell's ready_games_into; audit of the fix round, gpt
 1474     G2-D-01, claude G2-D-08)."""
 1475     unlocks, sets = set(), set()
 1476     try:
 1477         db = sqlite3.connect("file:%s?mode=ro" % DATABASE_FILE, uri=True, timeout=1.0)
 1478         rows = db.execute("SELECT cacheKey, substr(responseBody, 1, 512) FROM api_cache WHERE cacheKey LIKE ? OR cacheKey LIKE ?", ("unlocks:%", "achievementsets:%")).fetchall()
 1479     except Exception:
 1480         db = None
 1481         rows = ((e.get("cacheKey") or "", e.get("responseBody") or "") for prefix in (cache_keys.PREFIX_UNLOCKS, cache_keys.PREFIX_ACHIEVEMENTSETS) for e in storage.iter_cache_by_prefix(prefix))
 1482     for key, head in rows:
 1483         parts = str(key).split(":")
 1484         if parts[0] == "unlocks":
 1485             if len(parts) == 4 and parts[2] == user and parts[3] == "0" and parts[1].isdigit():
 1486                 unlocks.add(int(parts[1]))
 1487             continue
 1488         if len(parts) != 3 or parts[2] != user:
 1489             continue
 1490         gid = head_game_id((head or "")[:512])
 1491         if gid is None:
 1492             try:
 1493                 body = db.execute("SELECT responseBody FROM api_cache WHERE cacheKey = ?", (key,)).fetchone()[0] if db is not None else head
 1494                 gid = int((json.loads(body) or {}).get("GameId") or 0)
 1495             except Exception:
 1496                 gid = 0
 1497         if gid > 0:
 1498             sets.add(gid)
 1499     if db is not None:
 1500         db.close()
 1501     return unlocks & sets
 1502 
 1503 
 1504 whole = whole_games()
 1505 cached_paths = {
 1506     normalize_cached_rom_path(entry["sourceRomPath"])
 1507     for entry in storage.cache_summaries_by_prefix(cache_keys.PREFIX_PATCH)
 1508     if isinstance(entry.get("sourceRomPath"), str) and entry["sourceRomPath"].strip()
 1509     and entry["cacheKey"].endswith(":" + user)
 1510     and cache_keys.parse_game_id_from_patch_key(entry["cacheKey"]) in whole
 1511 }
 1512 try:
 1513     history = [str(p) for p in load_content_history_paths(config)]
 1514 except Exception:
 1515     history = []
 1516 
 1517 
 1518 def mtime(p):
 1519     try:
 1520         return p.stat().st_mtime
 1521     except OSError:
 1522         return 0.0
 1523 
 1524 
 1525 def by_history(paths):
 1526     """The played ones first, most recent first; then the rest, newest first."""
 1527     order = {p: i for i, p in enumerate(history)}
 1528     played = sorted((p for p in paths if str(p) in order), key=lambda p: order[str(p)])
 1529     rest = sorted((p for p in paths if str(p) not in order), key=mtime, reverse=True)
 1530     return played + rest
 1531 
 1532 
 1533 indexed_dirs = set()
 1534 failed_rvz_paths = set()
 1535 indexed_seen = 0
 1536 indexed_jobs = {}
 1537 for name, folder in es_systems():
 1538     if not folder.is_dir():
 1539         continue
 1540     index = read_index(name, folder)
 1541     if not any(h for h, _ in index.values()):
 1542         continue
 1543     try:
 1544         indexed_dirs.add(folder.resolve())
 1545     except OSError:
 1546         indexed_dirs.add(folder)
 1547     for path, (hash_value, id_text) in index.items():
 1548         # ES uses this sentinel for a failed read, not an unmatched hash.
 1549         # A deliberate scan may try the proxy's independent RVZ reader.
 1550         # Keep valid unmatched hashes and automatic top-ups index-only.
 1551         if path.suffix.lower() == ".rvz" and hash_value == "0" * 32:
 1552             failed_rvz_paths.add(path)
 1553             continue
 1554         try:
 1555             game_id = int(id_text)
 1556         except ValueError:
 1557             game_id = 0
 1558         if game_id <= 0 or not hash_value or not path.is_file():
 1559             continue
 1560         indexed_seen += 1
 1561         if path in indexed_jobs or is_cached(game_id, hash_value):
 1562             continue
 1563         indexed_jobs[path] = (game_id, hash_value)
 1564 storage.close()
 1565 
 1566 def read_cursor():
 1567     try:
 1568         return cursor_file.read_text(encoding="utf-8", errors="surrogateescape").rstrip("\n") if cursor_file else ""
 1569     except OSError:
 1570         return ""
 1571 
 1572 
 1573 def propose_cursor(value):
 1574     """The cursor this walk proposes -- the path of the last file it took,
 1575     or nothing when the walk came round -- written whole to
 1576     scan-cursor.next for the ctl to keep once the run has worked through its
 1577     jobs (commit_cursor): a run cancelled or stopped after its listing
 1578     leaves the cursor where it was, so the next scan takes the same slice
 1579     (audit of the fixes, claude G-D-06). False when it could not be written
 1580     -- and the ctl says so rather than promising a continuation it cannot
 1581     keep (gpt G-D-06)."""
 1582     if cursor_file is None:
 1583         return True
 1584     proposal = cursor_file.with_name(cursor_file.name + ".next")
 1585     tmp = proposal.with_name(proposal.name + ".tmp")
 1586     try:
 1587         tmp.write_text(value + "\n" if value else "", encoding="utf-8", errors="surrogateescape")
 1588         os.replace(tmp, proposal)
 1589         return True
 1590     except OSError:
 1591         try:
 1592             tmp.unlink()
 1593         except OSError:
 1594             pass
 1595         return False
 1596 
 1597 
 1598 # The walk is a circle from a cursor (#307 PL-059). Cached files are passed
 1599 # over before the cap counts (#186 PL-17), but a file that never caches -- a
 1600 # ROM RetroAchievements does not know is skipped, and stays uncached --
 1601 # counted every run, so the first MAX_SCAN_ENTRIES such files held the front
 1602 # of the walk for ever and the files past them were never reached. So a walk
 1603 # the cap cuts proposes the path of the last file it took (scan-cursor.next),
 1604 # the ctl keeps it as scan-cursor once the run has worked through its jobs,
 1605 # and the next walk takes the files after it first, then comes round to the
 1606 # start. A walk that fits under the cap removes the cursor; a cursor that
 1607 # names a file the walk no longer meets (deleted, or its folder now indexed)
 1608 # starts the circle from the top.
 1609 walked = []
 1610 walked_cached = 0
 1611 truncated = 0
 1612 cursor_saved = 1
 1613 if mode == "all":
 1614     cursor = read_cursor()
 1615     passed = not cursor
 1616     before, after = [], []   # the candidates up to the cursor, and past it
 1617     full = False
 1618     for name in walk_systems:
 1619         root = roms_root / name
 1620         if not root.is_dir():
 1621             continue
 1622         try:
 1623             indexed_root = root.resolve() in indexed_dirs
 1624         except OSError:
 1625             indexed_root = root in indexed_dirs
 1626         # Only revisit a root that can actually contain one of the failed
 1627         # paths; use the same path form as the membership check in the walk.
 1628         if indexed_root and not any(path.is_relative_to(root) for path in failed_rvz_paths):
 1629             continue
 1630         for dirpath, dirnames, filenames in os.walk(root):
 1631             dirnames[:] = sorted(d for d in dirnames if not d.startswith(".") and d.lower() not in SKIP_DIRS)
 1632             has_sheet = any(f.lower().endswith(DISC_SHEETS) for f in filenames)
 1633             for fn in sorted(filenames):
 1634                 if fn.startswith("."):
 1635                     continue
 1636                 path = Path(dirpath) / fn
 1637                 if indexed_root and path not in failed_rvz_paths:
 1638                     continue
 1639                 at_cursor = not passed and str(path) == cursor
 1640                 # Before the cursor only the first cap's worth is ever
 1641                 # taken (the circle's tail), so past that the walk only
 1642                 # looks for the cursor.
 1643                 if not passed and len(before) > MAX_SCAN_ENTRIES:
 1644                     passed = passed or at_cursor
 1645                     continue
 1646                 take = False
 1647                 if is_supported_browser_file(path) and not (has_sheet and fn.lower().endswith(".bin")):
 1648                     try:
 1649                         take = path.is_file() and path.stat().st_size > 0
 1650                     except OSError:
 1651                         take = False
 1652                 if take and normalize_cached_rom_path(path) in cached_paths:
 1653                     walked_cached += 1
 1654                     take = False
 1655                 if take:
 1656                     (after if passed else before).append(path)
 1657                 passed = passed or at_cursor
 1658                 if len(after) > MAX_SCAN_ENTRIES:
 1659                     full = True
 1660                     break
 1661             if full:
 1662                 break
 1663         if full:
 1664             break
 1665     candidates = after + before
 1666     walked = candidates[:MAX_SCAN_ENTRIES]
 1667     truncated = 1 if len(candidates) > MAX_SCAN_ENTRIES else 0
 1668     cursor_saved = 1 if propose_cursor(str(walked[-1]) if truncated and walked else "") else 0
 1669 
 1670 hash_jobs = walked
 1671 
 1672 lines = [f"I\t{indexed_jobs[p][0]}\t{indexed_jobs[p][1]}\t{p}\n" for p in by_history(list(indexed_jobs))]
 1673 lines += [f"H\t\t\t{p}\n" for p in by_history(hash_jobs)]
 1674 out.write_text("".join(lines), encoding="utf-8")
 1675 found = indexed_seen + len(walked) + walked_cached
 1676 new = len(lines)
 1677 print(f"found={found} new={new} cached={found - new} indexed={len(indexed_jobs)} hashing={len(hash_jobs)} truncated={truncated} cursor_saved={cursor_saved}")
 1678 PY
 1679 }
 1680 
 1681 # One field of list_jobs' summary line, or 0.
 1682 count_of() {
 1683     local V="${1#*${2}=}"
 1684     V="${V%% *}"
 1685     case "${V}" in ''|*[!0-9]*) echo 0 ;; *) echo "${V}" ;; esac
 1686 }
 1687 
 1688 # The helper that works the job list: beside this script, so a copy of the
 1689 # two files runs from anywhere they are put together.
 1690 case "$0" in
 1691     */*) HELPER="${0%/*}/raofflineproxy-cache-indexed"; IMAGE_HELPER="${0%/*}/raofflineproxy-cache-images"; REFRESH_HELPER="${0%/*}/raofflineproxy-refresh" ;;
 1692     *)   HELPER="/usr/bin/raofflineproxy-cache-indexed"; IMAGE_HELPER="/usr/bin/raofflineproxy-cache-images"; REFRESH_HELPER="/usr/bin/raofflineproxy-refresh" ;;
 1693 esac
 1694 
 1695 # Run the job list $2 of $3 games through the helper and read its lines as
 1696 # they come -- "OK i/n <file>", "FAIL i/n <file>: <reason>", "DONE cached=
 1697 # failed= indexed=" -- stopping it after three lookups in a row that
 1698 # RetroAchievements did not answer, or on a refused sign-in, or when the
 1699 # client reports its cap. $1 is page (the >>> lines for GuiOfflineScan) or
 1700 # quiet (nothing on stdout, for the top-up); $4 a bound in seconds, 0 for
 1701 # none. Leaves R_CACHED R_SKIPPED R_ERRORS R_LIMIT R_WHY R_STOPPED R_INDEXED
 1702 # R_CLIENT_RC for the caller, and the helper's stderr in the scan log. The
 1703 # helper's stdout goes through a fifo so it can be stopped between two lines.
 1704 run_jobs() {
 1705     local MODE="$1" LIST="$2" TOTAL="$3" BUDGET="${4:-0}"
 1706     local -a PATHS
 1707     mapfile -t PATHS < "${LIST}"
 1708     JOBS_FIFO="$(mktemp -u /tmp/raofflineproxy-scan-out.XXXXXX)"
 1709     mkfifo "${JOBS_FIFO}" || fail "cannot create ${JOBS_FIFO}"
 1710     if [ "${BUDGET}" -gt 0 ]; then
```

## ES 3178b832b8d1:es-app/src/guis/GuiWifi.cpp

```text
    1 #include "guis/GuiWifi.h"
    2 #include "guis/WifiScanProcess.h"
    3 #include "guis/GuiMenu.h"
    4 #include "guis/GuiMsgBox.h"
    5 #include "guis/GuiSettings.h"
    6 #include "guis/GuiTextEditPopup.h"
    7 #include "guis/GuiTextEditPopupKeyboard.h"
    8 #include "components/TextComponent.h"
    9 #include "components/BusyComponent.h"
   10 #include "components/ButtonComponent.h"
   11 #include "ApiSystem.h"
   12 #include "GuiLoading.h"
   13 #include "LocaleES.h"
   14 #include "Log.h"
   15 #include "Settings.h"
   16 #include "SystemConf.h"
   17 #include "ThemeData.h"
   18 #include "Window.h"
   19 #include "utils/StringUtil.h"
   20 
   21 #include <algorithm>
   22 #include <exception>
   23 #include <utility>
   24 #include <thread>
   25 
   26 namespace
   27 {
   28 void releasePickerButtons(GuiComponent* component)
   29 {
   30 	// Called only after hitTest(-1, -1) has cleared every hover flag. A
   31 	// held mouse press is then released without invoking a button action.
   32 	if (auto button = dynamic_cast<ButtonComponent*>(component))
   33 		button->onMouseClick(1, false, -1, -1);
   34 	for (int i = 0; i < component->getChildCount(); ++i)
   35 		releasePickerButtons(component->getChild(i));
   36 }
   37 }
   38 
   39 GuiWifi::GuiWifi(Window* window, const std::string& title, const std::function<void()>& onJoined)
   40 	: GuiComponent(window), mMenu(window, title.c_str()), mTitle(title), mOnJoined(onJoined), mSavedKnown(false), mWaitingLoad(false)
   41 {
   42 	setSize(Renderer::getScreenWidth(), Renderer::getScreenHeight());
   43 	addChild(&mMenu);
   44 	mMenu.setUpdateType(ComponentListFlags::UPDATE_WHEN_SELECTED);
   45 	mMenu.addButton(_("REFRESH"), _("REFRESH"), [this] { onRefresh(); });
   46 	mMenu.addButton(_("INPUT MANUALLY"), _("INPUT MANUALLY"), [this] { onManualInput(); });
   47 	mMenu.addButton(_("BACK"), _("BACK"), [this] { if (!mWaitingLoad) delete this; });
   48 
   49 	// Reserve the viewport once, including an in-list status band. Never
   50 	// call updateSize/setSubTitle or rebuild buttons as scan answers arrive.
   51 	const bool fullScreen = Renderer::ScreenSettings::fullScreenMenus();
   52 	mMenu.setSize(fullScreen ? mSize.x() : std::min(mSize.y(), mSize.x() * 0.90f),
   53 		fullScreen ? mSize.y() : mSize.y() * 0.75f);
   54 	mMenu.setPosition((mSize.x() - mMenu.getSize().x()) / 2,
   55 		fullScreen ? 0 : mSize.y() * 0.15f);
   56 
   57 	auto theme = ThemeData::getMenuTheme();
   58 	auto list = mMenu.getList();
   59 	const auto position = list->getPosition();
   60 	const auto size = list->getSize();
   61 	// Prime this shared font before measuring its maximum glyph height.
   62 	theme->Text.font->sizeText(_("SEARCHING WI-FI NETWORKS") + std::string(_("COULDN'T SEARCH WI-FI NETWORKS. TRY AGAIN.")) +
   63 		_("SHOWING PREVIOUS RESULTS.") + _("COULDN'T CHECK WHICH NETWORKS ARE SAVED.") + _("NO WI-FI NETWORKS FOUND"));
   64 	const float statusHeight = theme->Text.font->sizeText("A\nA", 1.0f).y() + mSize.y() * 0.01f;
   65 	const float inset = ComponentList::rowInset();
   66 	const float spinnerWidth = theme->Text.font->getLetterHeight() * 2.0f;
   67 	mStatus = std::make_shared<TextComponent>(mWindow, "", theme->Text.font, theme->Text.color);
   68 	mStatus->setMultiLine(TextComponent::MultiLineType::MULTILINE);
   69 	mStatus->setLineSpacing(1.0f);
   70 	mStatus->setVerticalAlignment(ALIGN_CENTER);
   71 	if (EsLocale::isRTL())
   72 		mStatus->setHorizontalAlignment(ALIGN_RIGHT);
   73 	mStatus->setSize(size.x() - 2 * inset - spinnerWidth, statusHeight);
   74 	mStatus->setPosition(position.x() + inset + spinnerWidth, position.y());
   75 	mStatus->setZIndex(20);
   76 	mMenu.addChild(mStatus.get());
   77 	list->setPosition(position.x(), position.y() + statusHeight);
   78 	list->setSize(size.x(), std::max(0.0f, size.y() - statusHeight));
   79 
   80 	// No posted callback capturing this. The worker starts after the native
   81 	// components are ready and publishes values for update() to consume.
   82 	onRefresh(false);
   83 }
   84 
   85 void GuiWifi::load(const std::vector<WifiText::PickerRow>& rows)
   86 {
   87 	auto list = mMenu.getList();
   88 	const bool buttonsFocused = mMenu.isCursorToButtons();
   89 	const int previousIndex = list->getCursorIndex();
   90 	const std::string selected = list->getSelectedUserData();
   91 	const bool unchanged = rows.size() == mRows.size() && std::equal(rows.begin(), rows.end(), mRows.begin(),
   92 		[](const WifiText::PickerRow& a, const WifiText::PickerRow& b)
   93 		{
   94 			return a.name == b.name && a.saved == b.saved && a.connected == b.connected &&
   95 				a.savedKnown == b.savedKnown && a.profile == b.profile;
   96 		});
   97 
   98 	// Keep the actual list and scroll offset on identical refreshes. When
   99 	// rows change, restore the SSID, or the nearest surviving index. The
  100 	// native list keeps that row visible instead of jumping to the top.
  101 	if (!unchanged)
  102 	{
  103 		mMenu.clear();
  104 		mRows = rows;
  105 		for (const auto& row : mRows)
  106 			addRow(row);
  107 		if (!mRows.empty())
  108 		{
  109 			auto match = std::find_if(mRows.begin(), mRows.end(), [&selected](const WifiText::PickerRow& row) { return row.name == selected; });
  110 			const int index = match == mRows.end() ? std::min(previousIndex, (int)mRows.size() - 1) : (int)(match - mRows.begin());
  111 			list->setCursorIndex(std::max(0, index), true);
  112 		}
  113 	}
  114 	if (mRows.empty())
  115 		mMenu.setCursorToButton(0);
  116 	else if (!buttonsFocused)
  117 		mMenu.setCursorToList();
  118 }
  119 
  120 // The name as NetworkManager has it -- case and spaces kept, since a
  121 // network's name is what the player recognises it by (addEntry would
  122 // upper-case it) -- and, on the right at the row's own weight, CONNECTED for
  123 // the network the device is on or SAVED for one it holds a profile for: the
  124 // shape and the word of MANAGE SAVED NETWORKS' mark, a fact beside the
  125 // action.
  126 void GuiWifi::addRow(const WifiText::PickerRow& network)
  127 {
  128 	auto theme = ThemeData::getMenuTheme();
  129 	ComponentListRow row;
  130 
  131 	auto name = std::make_shared<TextComponent>(mWindow, network.name, theme->Text.font, theme->Text.color);
  132 	if (EsLocale::isRTL())
  133 		name->setHorizontalAlignment(Alignment::ALIGN_RIGHT);
  134 	row.addElement(name, true);
  135 
  136 	if (network.connected || network.saved)
  137 	{
  138 		const std::string mark = network.connected ? _("CONNECTED") : _("SAVED");
  139 		auto label = std::make_shared<TextComponent>(mWindow, mark, theme->Text.font, theme->Text.color, Alignment::ALIGN_RIGHT);
  140 		label->setSize(theme->Text.font->sizeText(mark + "  ").x(), 0);
  141 		row.addElement(label, false);
  142 	}
  143 
  144 	const WifiText::PickerRow chosen = network;
  145 	row.makeAcceptInputHandler([this, chosen] { onSelect(chosen); });
  146 	mMenu.addRow(row, false, false, network.name);
  147 }
  148 
  149 // A press: the network the device is on joins again with the key
  150 // NetworkManager holds -- it answers at once, or comes back if it had
  151 // dropped (#308 F-WF-05: this used to close on the list's snapshot); a
  152 // saved one is offered CONNECT / FORGET / CANCEL (#318, D-UI-118); any
  153 // unsaved open network connects without a key; protected or unknown ones ask
  154 // for their key. One whose profile could not be asked about
  155 // is asked about again first (F-WF-03/06). WifiText::pressAction decides.
  156 void GuiWifi::onSelect(const WifiText::PickerRow& row)
  157 {
  158 	if (mWaitingLoad || mScan)
  159 		return;
  160 
  161 	if (row.savedKnown && WifiText::profilesForSsid(row.name, mSaved).size() > 1 && row.profile.empty())
  162 	{
  163 		chooseProfile(row.name);
  164 		return;
  165 	}
  166 	act(WifiText::pressAction(row), row.name, WifiText::joinName(row));
  167 }
  168 
  169 // Several profiles can name one SSID. The player chooses a profile before
  170 // CONNECT or FORGET; neither operation guesses which stored key they meant.
  171 void GuiWifi::chooseProfile(const std::string& name)
  172 {
  173 	auto page = new GuiSettings(mWindow, _("SAVED NETWORKS"));
  174 	for (const auto& profile : WifiText::profilesForSsid(name, mSaved))
  175 		page->addEntry(profile.name, true, [this, name, profile, page]
  176 		{
  177 			// Closing page destroys this row's callback and its captures.
  178 			// Keep the values on the stack before opening the next dialog.
  179 			GuiWifi* picker = this;
  180 			const std::string networkName = name;
  181 			const std::string profileName = profile.name;
  182 			page->close();
  183 			picker->act(WifiText::PressAction::ChooseSaved, networkName, profileName);
  184 		});
  185 	mWindow->pushGui(page);
  186 }
  187 
  188 // A join goes by the profile's name, which need not be the SSID the row
  189 // shows (#308 claude F-WF-12, gpt F-WF-03): the connected row joined by its
  190 // SSID, which is no profile's name for a renamed one, and the player read
  191 // COULDN'T CONNECT, with forget-and-rejoin advice, about the network they
  192 // were on.
  193 void GuiWifi::act(WifiText::PressAction action, const std::string& name, const std::string& joinAs)
  194 {
  195 	switch (action)
  196 	{
  197 	case WifiText::PressAction::Join:
  198 		join(name, joinAs);
  199 		break;
  200 	case WifiText::PressAction::ChooseSaved:
  201 	{
  202 		// A saved network the device is not on: CONNECT with the key
  203 		// NetworkManager holds, or FORGET it -- the second choice is the one
  204 		// ROCKNIX's own saved-Wi-Fi work offers, behind the manage page's
  205 		// confirmation and reader (GuiMenu::forgetWifiNetworkWithConfirmation),
  206 		// which rebuilds this list once the profile is gone. CONNECT first;
  207 		// CANCEL last, so B lands on it (es-ui-style-guide: back never lands
  208 		// on the destructive choice). The profile is forgotten by the name
  209 		// NetworkManager has for it (joinAs), which is the name the manage
  210 		// page shows.
  211 		const std::string text = Utils::String::format(_("%s IS SAVED.").c_str(), name.c_str())
  212 			+ "\n\n" + _("CONNECT WITH ITS SAVED KEY, OR FORGET IT?");
  213 		mWindow->pushGui(new GuiMsgBox(mWindow, text,
  214 			_("CONNECT"), [this, name, joinAs] { join(name, joinAs); },
  215 			_("FORGET"), [this, joinAs] { GuiMenu::forgetWifiNetworkWithConfirmation(mWindow, joinAs, false, [this] { onRefresh(false); }); },
  216 			_("CANCEL"), nullptr));
  217 		break;
  218 	}
  219 	case WifiText::PressAction::AskKey:
  220 		checkSecurityAndConnect(name);
  221 		break;
  222 	case WifiText::PressAction::CheckAgain:
  223 		// Never taken for a network with no profile: the key path rebuilds a
  224 		// profile of that name from what is typed.
  225 		mWindow->pushGui(new GuiMsgBox(mWindow,
  226 			_("COULDN'T CHECK WHICH NETWORKS ARE SAVED.") + std::string("\n\n") + _("CHECK AGAIN NOW?"),
  227 			_("YES"), [this] { onRefresh(false); },
  228 			_("NO"), nullptr));
  229 		break;
  230 	}
  231 }
  232 
  233 // INPUT MANUALLY: a hidden network's name, taken as a row would be -- a
  234 // name NetworkManager holds a profile for joins, the one the device is on
  235 // needs nothing, any other is asked for its key. Not trimmed: a name may
  236 // begin or end with a space, and it is matched as NetworkManager has it.
  237 void GuiWifi::onManualInput()
  238 {
  239 	if (mWaitingLoad || mScan)
  240 		return;
  241 
  242 	auto onName = [this](const std::string& name)
  243 	{
  244 		if (name.empty())
  245 			return;
  246 		const auto profile = WifiText::preferredProfile(name, mSaved);
  247 		if (mSavedKnown && WifiText::profilesForSsid(name, mSaved).size() > 1 && profile.empty())
  248 		{
  249 			chooseProfile(name);
  250 			return;
  251 		}
  252 		act(WifiText::manualAction(name, mCurrent, mSaved, mSavedKnown), name,
  253 			profile.empty() ? WifiText::manualJoinName(name, mCurrent, mCurrentProfile) : profile);
  254 	};
  255 
  256 	if (Settings::getInstance()->getBool("UseOSK"))
  257 		mWindow->pushGui(new GuiTextEditPopupKeyboard(mWindow, mTitle, "", onName, false));
  258 	else
  259 		mWindow->pushGui(new GuiTextEditPopup(mWindow, mTitle, "", onName, false));
  260 }
  261 
  262 // A saved network: its profile, with the key NetworkManager holds, behind
  263 // the spinner -- wifictl join waits up to 90 s for the association, as
  264 // connect does, and the screen would otherwise freeze for it. The script
  265 // also moves the settings wifi.ssid and wifi.key onto the joined network,
  266 // so the paths that connect from the settings (the restore wizard, the
  267 // ENABLE WI-FI switch) still name the network the player is on; SystemConf
  268 // is re-read so the interface sees the same file.
  269 void GuiWifi::join(const std::string& name, const std::string& profile)
  270 {
  271 	Window* window = mWindow;
  272 	mWaitingLoad = true;
  273 	LOG(LogInfo) << "wifi picker: joining the saved network " << name << " (profile " << profile << ")";
  274 	window->pushGui(new GuiLoading<WifiText::JoinAnswer>(window, _("CONNECTING TO WI-FI"),
  275 		[profile](IGuiLoadingHandler*) { return ApiSystem::getInstance()->joinWifiNetwork(profile); },
  276 		[this, window, name, profile](WifiText::JoinAnswer answer)
  277 		{
  278 			mWaitingLoad = false;
  279 			const int code = answer.code;
  280 			if (!answer.joined())
  281 			{
  282 				LOG(LogWarning) << "wifi picker: could not join the saved network " << name << " (profile " << profile << ", wifictl join exited " << code << ")";
  283 				// The advice by what happened (WifiText::joinFailure, #308
  284 				// F-WF-03/06): NetworkManager not answering is not a key that
  285 				// changed, and forgetting the network on that advice would
  286 				// lose a profile that was fine.
  287 				const std::string advice = WifiText::joinFailure(code) == WifiText::JoinFailure::ServiceNotAnswering
  288 					? _("THE WI-FI SERVICE DIDN'T ANSWER. TRY AGAIN IN A MOMENT.")
  289 					: _("IF ITS KEY HAS CHANGED, FORGET IT UNDER MANAGE SAVED NETWORKS AND JOIN IT AGAIN WITH THE NEW KEY.");
  290 				window->pushGui(new GuiMsgBox(window,
  291 					Utils::String::format(_("COULDN'T CONNECT TO %s.").c_str(), name.c_str()) + "\n\n" + advice, _("OK")));
  292 				return;
  293 			}
  294 			// Re-read for what the join wrote (wifi.ssid, wifi.key), keeping
  295 			// any change this interface has not saved yet -- one the settings
  296 			// lock refused -- unless the join wrote that key (G-E1-03).
  297 			SystemConf::getInstance()->loadSystemConf(true);
  298 			joined(name);
  299 		}));
  300 }
  301 
  302 // Any other network: its key first -- empty for an open network -- then
  303 // the connection wifictl connect makes, which leaves a profile behind for
  304 // next time. On success the settings take the network and its key, as they
  305 // did when the row edited them: the network configured last, for the paths
  306 // that connect from the settings.
  307 void GuiWifi::checkSecurityAndConnect(const std::string& name)
  308 {
  309 	mWaitingLoad = true;
  310 	mWindow->pushGui(new GuiLoading<std::string>(mWindow, _("CHECKING WI-FI NETWORK"),
  311 		[name](IGuiLoadingHandler*) { return ApiSystem::getInstance()->getWifiSecurity(name); },
  312 		[this, name](const std::string& security)
  313 		{
  314 			mWaitingLoad = false;
  315 			if (security == "open")
  316 				connect(name, "", true);
  317 			else
  318 				askKeyAndConnect(name);
  319 		}));
  320 }
  321 
  322 void GuiWifi::askKeyAndConnect(const std::string& name)
  323 {
  324 	auto onKey = [this, name](const std::string& key) { connect(name, key); };
  325 
  326 	if (Settings::getInstance()->getBool("UseOSK"))
  327 		mWindow->pushGui(new GuiTextEditPopupKeyboard(mWindow, _("WI-FI KEY"), "", onKey, false));
  328 	else
  329 		mWindow->pushGui(new GuiTextEditPopup(mWindow, _("WI-FI KEY"), "", onKey, false));
  330 }
  331 
  332 void GuiWifi::connect(const std::string& name, const std::string& key, bool openNetwork)
  333 {
  334 	Window* window = mWindow;
  335 	mWaitingLoad = true;
  336 	LOG(LogInfo) << "wifi picker: connecting to " << name;
  337 #if !WIN32
  338 	const std::string country = SystemConf::getInstance()->get("wifi.country");
  339 	auto apply = [name, key, country, openNetwork](IGuiLoadingHandler*) { return openNetwork ? ApiSystem::getInstance()->connectOpenWifi(name) : ApiSystem::getInstance()->enableWifi(name, key, country); };
  340 #else
  341 	auto apply = [name, key, openNetwork](IGuiLoadingHandler*) { return openNetwork ? ApiSystem::getInstance()->connectOpenWifi(name) : ApiSystem::getInstance()->enableWifi(name, key); };
  342 #endif
  343 	window->pushGui(new GuiLoading<bool>(window, _("CONNECTING TO WI-FI"), apply,
  344 		[this, window, name, key, openNetwork](bool ok)
  345 		{
  346 			mWaitingLoad = false;
  347 			if (!ok)
  348 			{
  349 				LOG(LogWarning) << "wifi picker: could not connect to " << name;
  350 				window->pushGui(new GuiMsgBox(window,
  351 					Utils::String::format(_("COULDN'T CONNECT TO %s.").c_str(), name.c_str()) + "\n\n" + (openNetwork ? _("REFRESH THE NETWORK LIST AND TRY AGAIN.") : _("CHECK THE KEY AND TRY AGAIN.")), _("OK")));
  352 				return;
  353 			}
  354 			SystemConf::getInstance()->set("wifi.ssid", name);
  355 			SystemConf::getInstance()->set("wifi.key", key);
  356 			SystemConf::getInstance()->saveSystemConf();
  357 			joined(name);
  358 		}));
  359 }
  360 
  361 // The picker's job is done: the toast says so over whatever the page
  362 // returns to, and the page that opened the picker rebuilds to read the
  363 // connection back. The callback is copied out first -- it belongs to that
  364 // page, and this component is gone before it runs.
  365 void GuiWifi::joined(const std::string& name)
  366 {
  367 	Window* window = mWindow;
  368 	auto onJoined = mOnJoined;
  369 	// <glyph> <subject> : <outcome>, one space after the glyph, as every
  370 	// toast (#308 F-WF-08); CONNECTED is the row's word for the same fact.
  371 	window->displayNotificationMessage(_U("\uF058 ") + WifiText::joinedNotice(name, _("CONNECTED")));
  372 	delete this;
  373 	if (onJoined != nullptr)
  374 		onJoined();
  375 }
  376 
  377 bool GuiWifi::input(InputConfig* config, Input input)
  378 {
  379 	if (input.value != 0 && config->isMappedTo(BUTTON_BACK, input))
  380 	{
  381 		if (!mWaitingLoad)
  382 			delete this;
  383 		return true;
  384 	}
  385 
  386 	// A press during a scan cannot join an old row, open a key editor or
  387 	// queue another scan. BACK remains available without joining the worker.
  388 	if (mScan || mWaitingLoad)
  389 		return true;
  390 	return GuiComponent::input(config, input);
  391 }
  392 
  393 bool GuiWifi::hitTest(int x, int y, Transform4x4f& parentTransform, std::vector<GuiComponent*>* result)
  394 {
  395 	if (!mScan)
  396 		return GuiComponent::hitTest(x, y, parentTransform, result);
  397 
  398 	// Mouse/touch bypass input(). During scanning only the native BACK
  399 	// button may capture a press, so a release after completion cannot act
  400 	// on a refreshed row or start the action of a previously pressed button.
  401 	std::vector<GuiComponent*> hits;
  402 	const bool hit = GuiComponent::hitTest(x, y, parentTransform, &hits);
  403 	if (result)
  404 		for (auto component : hits)
  405 			if (auto button = dynamic_cast<ButtonComponent*>(component))
  406 				if (button->getText() == _("BACK"))
  407 					result->push_back(button);
  408 	return hit;
  409 }
  410 
  411 std::vector<HelpPrompt> GuiWifi::getHelpPrompts()
  412 {
  413 	std::vector<HelpPrompt> prompts;
  414 	if (!mScan && !mWaitingLoad)
  415 		prompts = mMenu.getHelpPrompts();
  416 	prompts.push_back(HelpPrompt(BUTTON_BACK, _("BACK")));
  417 	return prompts;
  418 }
  419 
  420 void GuiWifi::update(int deltaTime)
  421 {
  422 	GuiComponent::update(deltaTime);
  423 	if (!mScan || !mScan->ready.load(std::memory_order_acquire))
  424 		return;
  425 
  426 	const Answer answer = mScan->answer;
  427 	mScan.reset();
  428 	mBusy.reset();
  429 	mWindow->releaseMouseCapture();
  430 
  431 	// A failed range query keeps prior network names. Saved/current metadata
  432 	// is freshly read even then; unknown metadata keeps the existing guarded
  433 	// CheckAgain route rather than interpreting an unknown profile as absent.
  434 	std::vector<std::string> inRange = answer.inRange;
  435 	const bool retainedResults = !answer.inRangeKnown && !mRows.empty();
  436 	if (!answer.inRangeKnown)
  437 		for (const auto& row : mRows)
  438 			inRange.push_back(row.name);
  439 	const auto rows = WifiText::pickerRows(inRange, answer.saved, answer.current,
  440 		answer.savedKnown, answer.currentKnown);
  441 	mSaved = answer.saved;
  442 	mSavedKnown = answer.savedKnown;
  443 	mCurrent.clear();
  444 	mCurrentProfile.clear();
  445 	for (const auto& row : rows)
  446 		if (row.connected)
  447 		{
  448 			mCurrent = row.name;
  449 			mCurrentProfile = row.profile;
  450 		}
  451 	load(rows);
  452 
  453 	std::string status;
  454 	if (!answer.inRangeKnown)
  455 	{
  456 		status = _("COULDN'T SEARCH WI-FI NETWORKS. TRY AGAIN.");
  457 		if (retainedResults)
  458 			status += "\n" + std::string(_("SHOWING PREVIOUS RESULTS."));
  459 	}
  460 	else if (rows.empty())
  461 		status = _("NO WI-FI NETWORKS FOUND");
  462 	else if (!mSavedKnown)
  463 		status = _("COULDN'T CHECK WHICH NETWORKS ARE SAVED.");
  464 	mStatus->setText(status);
  465 	LOG(LogInfo) << "wifi picker: scan " << (answer.inRangeKnown ? "completed" : "failed")
  466 		<< "; rows=" << rows.size() << "; retained=" << retainedResults;
  467 	updateHelpPrompts();
  468 }
  469 
  470 void GuiWifi::onRefresh(bool rescan)
  471 {
  472 	if (mScan || mWaitingLoad)
  473 		return;
  474 
  475 	// UI-thread-only weak registry. Closing a picker leaves at most the one
  476 	// bounded read job; reopening attaches to it instead of starting a rival.
  477 	// A completed answer is never reused for a later explicit refresh.
  478 	static std::weak_ptr<Scan> activeScan;
  479 	mScan = activeScan.lock();
  480 	if (mScan && mScan->ready.load(std::memory_order_acquire))
  481 		mScan.reset();
  482 	const bool reused = mScan != nullptr;
  483 	if (!mScan)
  484 	{
  485 		mScan = std::make_shared<Scan>();
  486 		activeScan = mScan;
  487 		auto scan = mScan;
  488 		try
  489 		{
  490 			std::thread([scan, rescan]
  491 			{
  492 				try
  493 				{
  494 					Answer answer;
  495 					const auto range = WifiScanProcess::read({"wifictl", rescan ? "scanlist" : "list"}, std::chrono::seconds(rescan ? 45 : 30));
  496 					answer.inRangeKnown = range.code == 0;
  497 					answer.inRange = range.lines;
  498 
  499 					// Match ApiSystem's saved/current protocol, but reject signal
  500 					// and read failures too. No singleton or GUI is worker-owned.
  501 					const auto saved = WifiScanProcess::read({"wifictl", "saved", "--ssid"}, std::chrono::seconds(15));
  502 					answer.savedKnown = saved.code == 0;
  503 					if (answer.savedKnown)
  504 						for (const auto& line : saved.lines)
  505 						{
  506 							WifiText::SavedNetwork network;
  507 							if (!WifiText::parseSavedDetailsLine(line, network))
  508 							{
  509 								answer.savedKnown = false;
  510 								break;
  511 							}
  512 							answer.saved.push_back(network);
  513 						}
  514 					if (!answer.savedKnown)
  515 						answer.saved.clear();
  516 
  517 					const auto current = WifiScanProcess::read({"wifictl", "current"}, std::chrono::seconds(10));
  518 					answer.current = WifiText::parseCurrent(current.lines);
  519 					answer.currentKnown = (current.code == 0 && !answer.current.empty()) || current.code == 1;
  520 					if (current.code != 0)
  521 						answer.current.clear();
  522 					scan->answer = std::move(answer);
  523 				}
  524 				catch (...)
  525 				{
  526 					// The default answer is unknown, not a successful empty scan.
  527 					LOG(LogWarning) << "wifi picker: scan worker failed";
  528 				}
  529 				LOG(LogInfo) << "wifi picker: scan worker finished";
  530 				scan->ready.store(true, std::memory_order_release);
  531 			}).detach();
  532 		}
  533 		catch (const std::exception&)
  534 		{
  535 			LOG(LogWarning) << "wifi picker: could not start scan worker";
  536 			mScan->ready.store(true, std::memory_order_release);
  537 		}
  538 	}
  539 
  540 	if (mMenu.getList()->getScrollingVelocity() != 0)
  541 		mMenu.getList()->stopScrolling();
  542 	auto transform = Transform4x4f::Identity();
  543 	mMenu.hitTest(-1, -1, transform);
  544 	releasePickerButtons(&mMenu);
  545 	mWindow->releaseMouseCapture();
  546 	mStatus->setText(_("SEARCHING WI-FI NETWORKS"));
  547 	const float spinnerWidth = ThemeData::getMenuTheme()->Text.font->getLetterHeight() * 2.0f;
  548 	mBusy = std::make_shared<BusyComponent>(mWindow, "");
  549 	mBusy->setBackgroundVisible(false);
  550 	mBusy->setSize(spinnerWidth, mStatus->getSize().y());
  551 	mBusy->setPosition(mStatus->getPosition().x() - spinnerWidth, mStatus->getPosition().y());
  552 	mBusy->setZIndex(20);
  553 	mMenu.addChild(mBusy.get());
  554 	LOG(LogInfo) << "wifi picker: " << (reused ? "attached to pending scan" : "scan started");
  555 	updateHelpPrompts();
  556 }
```

## ES 3178b832b8d1:es-app/src/guis/GuiWifi.h

```text
    1 #pragma once
    2 
    3 #include "GuiComponent.h"
    4 #include "components/MenuComponent.h"
    5 #include "WifiText.h"
    6 
    7 #include <atomic>
    8 #include <functional>
    9 #include <memory>
   10 #include <string>
   11 #include <vector>
   12 
   13 class BusyComponent;
   14 
   15 // The Wi-Fi picker behind NETWORK SETTINGS' WI-FI NETWORK row (fork #191,
   16 // renamed from WI-FI SSID by D-UI-071; the
   17 // maintainer's paradigm of 2026-09-15: the row is the network the device is
   18 // on, this list is what is in range). One row per network in range -- the
   19 // one joined now first and marked CONNECTED, the ones NetworkManager holds a
   20 // profile for marked SAVED. A press on a saved row offers CONNECT (with
   21 // the key NetworkManager has), FORGET (the manage page's confirmation and
   22 // reader) or CANCEL (#318, D-UI-118); a press on the connected row joins it
   23 // again at once; a press on any other asks for the key and connects,
   24 // which saves it for next time; INPUT MANUALLY takes a hidden network's
   25 // name the same way. Once the device is on a network the page that opened
   26 // the picker is told, so it rebuilds and reads the connection back.
   27 class GuiWifi : public GuiComponent
   28 {
   29 public:
   30 	GuiWifi(Window* window, const std::string& title, const std::function<void()>& onJoined);
   31 	bool input(InputConfig* config, Input input) override;
   32 	void update(int deltaTime) override;
   33 	bool hitTest(int x, int y, Transform4x4f& parentTransform, std::vector<GuiComponent*>* result = nullptr) override;
   34 	std::vector<HelpPrompt> getHelpPrompts() override;
   35 
   36 private:
   37 	// The three answers the list is built from, fetched together off the
   38 	// interface thread.
   39 	struct Answer
   40 	{
   41 		std::vector<std::string> inRange;
   42 		bool inRangeKnown = false;
   43 		std::vector<WifiText::SavedNetwork> saved;
   44 		std::string current;
   45 		// Whether `wifictl saved` and `wifictl current` answered at all: an
   46 		// empty list and no list are different answers (#308 F-WF-03/06).
   47 		bool savedKnown = false;
   48 		bool currentKnown = false;
   49 	};
   50 
   51 	// The worker owns only this value. No GUI or Window pointer crosses into
   52 	// it, and the UI consumes the answer only after the release/acquire pair.
   53 	struct Scan
   54 	{
   55 		Answer answer;
   56 		std::atomic<bool> ready{false};
   57 	};
   58 
   59 	void load(const std::vector<WifiText::PickerRow>& rows);
   60 	void addRow(const WifiText::PickerRow& row);
   61 	void onSelect(const WifiText::PickerRow& row);
   62 	void chooseProfile(const std::string& name);
   63 	// name is the network as the player sees it; joinAs the name `wifictl
   64 	// join` takes (WifiText::joinName, manualJoinName).
   65 	void act(WifiText::PressAction action, const std::string& name, const std::string& joinAs);
   66 	void onManualInput();
   67 	void onRefresh(bool rescan = true);
   68 	void join(const std::string& name, const std::string& profile);
   69 	void checkSecurityAndConnect(const std::string& name);
   70 	void askKeyAndConnect(const std::string& name);
   71 	void connect(const std::string& name, const std::string& key, bool openNetwork = false);
   72 	void joined(const std::string& name);
   73 
   74 	MenuComponent mMenu;
   75 	std::shared_ptr<TextComponent> mStatus;
   76 	std::shared_ptr<BusyComponent> mBusy;
   77 	std::shared_ptr<Scan> mScan;
   78 	std::vector<WifiText::PickerRow> mRows;
   79 	std::string mTitle;
   80 	std::function<void()> mOnJoined;
   81 	std::vector<WifiText::SavedNetwork> mSaved;
   82 	std::string mCurrent;
   83 	std::string mCurrentProfile;   // the connected row's profile, for a typed name
   84 	bool mSavedKnown;
   85 	bool mWaitingLoad;
   86 };
```

## ES 3178b832b8d1:es-app/src/guis/WifiScanProcess.h

```text
    1 #pragma once
    2 
    3 // A bounded, read-only subprocess for the Wi-Fi picker (#577). No shell,
    4 // GUI, singleton or callback is owned here. Kept separate so a disposable
    5 // process fixture can exercise the actual runner without linking ES.
    6 #include <chrono>
    7 #include <string>
    8 #include <vector>
    9 
   10 #if !WIN32
   11 #include <cerrno>
   12 #include <csignal>
   13 #include <fcntl.h>
   14 #include <poll.h>
   15 #include <spawn.h>
   16 #include <sys/wait.h>
   17 #include <unistd.h>
   18 extern char** environ;
   19 #endif
   20 
   21 namespace WifiScanProcess
   22 {
   23 struct Answer
   24 {
   25 	int code = -1; // spawn/read/signal/timeout/cleanup failure is never empty success
   26 	std::vector<std::string> lines;
   27 };
   28 
   29 #if !WIN32
   30 class Child
   31 {
   32 public:
   33 	Child(pid_t child, int output) : pid(child), fd(output) {}
   34 	Child(const Child&) = delete;
   35 	Child& operator=(const Child&) = delete;
   36 	~Child() { finish(); }
   37 
   38 	bool finish()
   39 	{
   40 		if (finished)
   41 			return cleaned;
   42 		finished = true;
   43 		close(fd);
   44 		// Even a reaped leader may have descendants holding the pipe. The
   45 		// spawn creates this group; never signal ES's own process group.
   46 		cleaned = kill(-pid, SIGKILL) == 0 || errno == ESRCH;
   47 		if (!cleaned)
   48 			kill(pid, SIGKILL);
   49 		const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
   50 		while (!reaped)
   51 		{
   52 			const pid_t waited = waitpid(pid, &status, WNOHANG);
   53 			if (waited == pid)
   54 				reaped = true;
   55 			else if ((waited < 0 && errno != EINTR) || std::chrono::steady_clock::now() >= deadline)
   56 				return cleaned = false;
   57 			else
   58 				poll(nullptr, 0, 10);
   59 		}
   60 		return cleaned;
   61 	}
   62 
   63 	pid_t pid;
   64 	int fd;
   65 	int status = 0;
   66 	bool reaped = false;
   67 private:
   68 	bool finished = false;
   69 	bool cleaned = false;
   70 };
   71 #endif
   72 
   73 inline Answer read(const std::vector<std::string>& command, std::chrono::milliseconds timeout)
   74 {
   75 	Answer answer;
   76 #if !WIN32
   77 	if (command.empty() || timeout.count() <= 0)
   78 		return answer;
   79 	std::vector<char*> argv;
   80 	for (const auto& part : command)
   81 		argv.push_back(const_cast<char*>(part.c_str()));
   82 	argv.push_back(nullptr);
   83 
   84 	int output[2];
   85 	if (pipe2(output, O_CLOEXEC) != 0)
   86 		return answer;
   87 	// File actions must not close stdout after dup2 when an inherited
   88 	// standard descriptor was absent and pipe2 reused its number.
   89 	for (int& descriptor : output)
   90 		if (descriptor <= STDERR_FILENO)
   91 		{
   92 			const int moved = fcntl(descriptor, F_DUPFD_CLOEXEC, STDERR_FILENO + 1);
   93 			if (moved == -1)
   94 			{
   95 				close(output[0]); close(output[1]);
   96 				return answer;
   97 			}
   98 			close(descriptor);
   99 			descriptor = moved;
  100 		}
  101 	posix_spawn_file_actions_t actions;
  102 	posix_spawnattr_t attributes;
  103 	if (posix_spawn_file_actions_init(&actions) != 0)
  104 	{
  105 		close(output[0]); close(output[1]);
  106 		return answer;
  107 	}
  108 	if (posix_spawnattr_init(&attributes) != 0)
  109 	{
  110 		posix_spawn_file_actions_destroy(&actions);
  111 		close(output[0]); close(output[1]);
  112 		return answer;
  113 	}
  114 	pid_t pid = -1;
  115 	const bool configured =
  116 		posix_spawn_file_actions_adddup2(&actions, output[1], STDOUT_FILENO) == 0 &&
  117 		posix_spawn_file_actions_addclose(&actions, output[0]) == 0 &&
  118 		posix_spawn_file_actions_addclose(&actions, output[1]) == 0 &&
  119 		posix_spawnattr_setflags(&attributes, POSIX_SPAWN_SETPGROUP) == 0 &&
  120 		posix_spawnattr_setpgroup(&attributes, 0) == 0;
  121 	const int spawned = configured ? posix_spawnp(&pid, argv[0], &actions, &attributes, argv.data(), environ) : -1;
  122 	posix_spawnattr_destroy(&attributes);
  123 	posix_spawn_file_actions_destroy(&actions);
  124 	close(output[1]);
  125 	if (spawned != 0)
  126 	{
  127 		close(output[0]);
  128 		return answer;
  129 	}
  130 
  131 	Child child(pid, output[0]);
  132 	const int flags = fcntl(child.fd, F_GETFL);
  133 	if (flags == -1 || fcntl(child.fd, F_SETFL, flags | O_NONBLOCK) == -1)
  134 		return answer;
  135 	const auto deadline = std::chrono::steady_clock::now() + timeout;
  136 	std::string outputText;
  137 	bool eof = false;
  138 	while (true)
  139 	{
  140 		char buffer[4096];
  141 		while (!eof)
  142 		{
  143 			const ssize_t count = ::read(child.fd, buffer, sizeof(buffer));
  144 			if (count > 0)
  145 			{
  146 				// A corrupt/unbounded command must not grow the UI's heap.
  147 				if (outputText.size() + count > 256 * 1024 || std::chrono::steady_clock::now() >= deadline)
  148 					return answer;
  149 				outputText.append(buffer, count);
  150 			}
  151 			else if (count == 0)
  152 				eof = true;
  153 			else if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
  154 				break;
  155 			else
  156 				return answer;
  157 		}
  158 		if (!child.reaped)
  159 		{
  160 			const pid_t waited = waitpid(child.pid, &child.status, WNOHANG);
  161 			if (waited == child.pid)
  162 				child.reaped = true;
  163 			else if (waited < 0 && errno != EINTR)
  164 				return answer;
  165 		}
  166 		if (eof && child.reaped)
  167 			break;
  168 		if (std::chrono::steady_clock::now() >= deadline)
  169 			return answer;
  170 		pollfd descriptor{eof ? -1 : child.fd, POLLIN, 0};
  171 		if (poll(&descriptor, 1, 25) < 0 && errno != EINTR)
  172 			return answer;
  173 	}
  174 	if (!child.finish() || !WIFEXITED(child.status))
  175 		return answer;
  176 	answer.code = WEXITSTATUS(child.status);
  177 	if (answer.code == 0)
  178 	{
  179 		size_t start = 0;
  180 		while (start < outputText.size())
  181 		{
  182 			const size_t end = outputText.find('\n', start);
  183 			const std::string line = outputText.substr(start, end == std::string::npos ? end : end - start);
  184 			if (!line.empty())
  185 				answer.lines.push_back(line);
  186 			if (end == std::string::npos)
  187 				break;
  188 			start = end + 1;
  189 		}
  190 	}
  191 #endif
  192 	return answer;
  193 }
  194 }
```

## ES 3178b832b8d1:es-app/src/GameCubeRvzHashRetry.h

```text
    1 #pragma once
    2 // SPDX-License-Identifier: MIT
    3 // #574: narrow recovery of failed frontend RVZ hashes, not metadata cleanup.
    4 #include <string>
    5 
    6 namespace GameCubeRvzHashRetry
    7 {
    8     inline std::string trim(const std::string& value)
    9     {
   10         const auto first = value.find_first_not_of(" \t\r\n");
   11         if (first == std::string::npos)
   12             return {};
   13         return value.substr(first, value.find_last_not_of(" \t\r\n") - first + 1);
   14     }
   15 
   16     inline bool needed(bool readerEnabled, bool gameCubeOnly,
   17         const std::string& extension, const std::string& storedHash, const std::string& storedId)
   18     {
   19         if (!readerEnabled || !gameCubeOnly || extension.size() != 4 || extension[0] != '.' ||
   20             (extension[1] != 'r' && extension[1] != 'R') ||
   21             (extension[2] != 'v' && extension[2] != 'V') ||
   22             (extension[3] != 'z' && extension[3] != 'Z'))
   23             return false;
   24 
   25         // Only an absent ID or the existing no-ID marker is eligible. Preserve
   26         // positive IDs and unfamiliar nonempty metadata, even beside a bad hash.
   27         const std::string id = trim(storedId);
   28         if (!id.empty() && id != "0")
   29             return false;
   30 
   31         const std::string hash = trim(storedHash);
   32         if (hash.size() != 32)
   33             return true;
   34         bool nonzero = false;
   35         for (char c : hash)
   36         {
   37             if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
   38                 return true;
   39             nonzero = nonzero || c != '0';
   40         }
   41         // A valid unknown hash still takes the old lookup-only path. The all-
   42         // zero value is getCheevosHashFromFile's historical failure sentinel.
   43         return !nonzero;
   44     }
   45 }
```

## ES 3178b832b8d1:external/libcheevos/rvz_hash.cpp

```text
    1 // SPDX-License-Identifier: MIT AND BSD-3-Clause
    2 // Copyright (c) 2026 pixelelated contributors
    3 // Padding recurrence/serialization adapted from bodgit/rvz (BSD-3-Clause).
    4 // See RVZ-NOTICES.md and LICENSE.rvz-padding. Container code follows Dolphin's
    5 // published WiaAndRvz format; no RetroArch or Dolphin implementation is copied.
    6 #include "rvz_hash.h"
    7 #include "rcheevos/include/rc_hash.h"
    8 #include "libretro-common/include/streams/interface_stream.h"
    9 #include "libretro-common/include/libretro.h"
   10 #include <boost/uuid/detail/sha1.hpp>
   11 #include <zstd.h>
   12 #include <algorithm>
   13 #include <array>
   14 #include <cstdint>
   15 #include <cstdlib>
   16 #include <cstring>
   17 #include <memory>
   18 #include <stdexcept>
   19 #include <vector>
   20 #include <utility>
   21 
   22 namespace
   23 {
   24 constexpr uint64_t Sector = 0x8000;
   25 constexpr uint32_t MaxChunk = 2 * 1024 * 1024;
   26 constexpr uint32_t MaxWork = MaxChunk + 1024 * 1024;
   27 constexpr uint64_t MaxDisc = uint64_t(2) * 1024 * 1024 * 1024;
   28 constexpr uint64_t MaxFile = uint64_t(4) * 1024 * 1024 * 1024;
   29 constexpr uint32_t MaxGroups = 65536;
   30 constexpr uint32_t MaxRaw = 4096;
   31 using Bytes = std::vector<uint8_t>;
   32 
   33 void require(bool condition)
   34 {
   35     if (!condition)
   36         throw std::runtime_error("Invalid or unsupported GameCube RVZ");
   37 }
   38 uint32_t be32(const uint8_t* p)
   39 {
   40     return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) |
   41         (uint32_t(p[2]) << 8) | p[3];
   42 }
   43 uint64_t be64(const uint8_t* p)
   44 {
   45     return (uint64_t(be32(p)) << 32) | be32(p + 4);
   46 }
   47 bool sha1Matches(const uint8_t* data, size_t size, const uint8_t* expected)
   48 {
   49     boost::uuids::detail::sha1 state;
   50     boost::uuids::detail::sha1::digest_type digest;
   51     state.process_bytes(data, size);
   52     state.get_digest(digest);
   53     // Boost changed digest_type from host words to bytes. Accept both APIs.
   54     for (size_t i = 0; i < 20; ++i)
   55     {
   56         const auto byte = sizeof(digest[0]) == 1 ? digest[i] :
   57             ((digest[i / 4] >> (24 - 8 * (i % 4))) & 0xff);
   58         if (byte != expected[i])
   59             return false;
   60     }
   61     return true;
   62 }
   63 
   64 // BSD-3-Clause adaptation of bodgit/rvz/internal/padding/reader.go.
   65 // State is local, and output uses explicit bytes on both endian families.
   66 void padding(const uint8_t* seed, uint64_t offset, uint8_t* out, size_t size)
   67 {
   68     std::array<uint32_t, 521> words{};
   69     for (size_t i = 0; i < 17; ++i)
   70         words[i] = be32(seed + 4 * i);
   71     for (size_t i = 17; i < words.size(); ++i)
   72         words[i] = (words[i - 17] << 23) ^ (words[i - 16] >> 9) ^ words[i - 1];
   73     const auto advance = [&]() {
   74         for (size_t i = 0; i < 32; ++i)
   75             words[i] ^= words[i + words.size() - 32];
   76         for (size_t i = 32; i < words.size(); ++i)
   77             words[i] ^= words[i - 32];
   78     };
   79     for (unsigned i = 0; i < 4; ++i)
   80         advance();
   81     size_t byteIndex = static_cast<size_t>(offset % Sector);
   82     while (byteIndex >= words.size() * 4)
   83     {
   84         advance();
   85         byteIndex -= words.size() * 4;
   86     }
   87     const unsigned shifts[] = {24, 18, 8, 0};
   88     for (size_t i = 0; i < size; ++i)
   89     {
   90         if (byteIndex == words.size() * 4)
   91         {
   92             advance();
   93             byteIndex = 0;
   94         }
   95         out[i] = static_cast<uint8_t>(words[byteIndex / 4] >> shifts[byteIndex % 4]);
   96         ++byteIndex;
   97     }
   98 }
   99 
  100 Bytes unpack(const Bytes& packed, size_t expected, uint64_t discOffset)
  101 {
  102     Bytes result(expected);
  103     size_t input = 0, output = 0, records = 0;
  104     while (input < packed.size())
  105     {
  106         require(++records <= 4096 && packed.size() - input >= 4);
  107         const uint32_t tag = be32(packed.data() + input);
  108         input += 4;
  109         const uint32_t length = tag & 0x7fffffff;
  110         require(length <= result.size() - output);
  111         if (tag & 0x80000000)
  112         {
  113             require(packed.size() - input >= 68);
  114             if (length)
  115                 padding(packed.data() + input, discOffset + output, result.data() + output, length);
  116             input += 68;
  117         }
  118         else
  119         {
  120             require(length <= packed.size() - input);
  121             if (length)
  122                 std::memcpy(result.data() + output, packed.data() + input, length);
  123             input += length;
  124         }
  125         output += length;
  126     }
  127     require(output == expected);
  128     return result;
  129 }
  130 
  131 struct StreamCloser
  132 {
  133     void operator()(intfstream_t* stream) const
  134     {
  135         if (stream)
  136         {
  137             intfstream_close(stream);
  138             std::free(stream);
  139         }
  140     }
  141 };
  142 struct Raw
  143 {
  144     uint64_t offset, end, aligned;
  145     uint32_t first, count;
  146 };
  147 struct Group
  148 {
  149     uint64_t offset;
  150     uint32_t size, packed;
  151     bool compressed;
  152 };
  153 class Reader
  154 {
  155 public:
  156     explicit Reader(const char* path) : stream(intfstream_open_file(path,
  157         RETRO_VFS_FILE_ACCESS_READ, RETRO_VFS_FILE_ACCESS_HINT_NONE))
  158     {
  159         require(stream != nullptr);
  160         const int64_t size = intfstream_get_size(stream.get());
  161         require(size >= 0x48 + 0xd5 && uint64_t(size) <= MaxFile);
  162         fileSize = static_cast<uint64_t>(size);
  163         const Bytes header = physical(0, 0x48);
  164         require(be32(header.data()) == 0x52565a01);
  165         const uint32_t version = be32(header.data() + 4);
  166         const uint32_t compatible = be32(header.data() + 8);
  167         require(version >= 0x00030000 && version <= 0x01000000 &&
  168             compatible >= 0x00030000 && compatible <= version);
  169         require(sha1Matches(header.data(), 0x34, header.data() + 0x34));
  170         discSize = be64(header.data() + 0x24);
  171         require(discSize >= 0x2460 && discSize <= MaxDisc &&
  172             be64(header.data() + 0x2c) == fileSize);
  173         const uint32_t secondSize = be32(header.data() + 0xc);
  174         require(secondSize >= 0xd5 && secondSize <= 4096);
  175         const Bytes second = physical(0x48, secondSize);
  176         require(sha1Matches(second.data(), second.size(), header.data() + 0x10));
  177         require(be32(second.data()) == 1 && be32(second.data() + 0x90) == 0);
  178         compression = be32(second.data() + 4);
  179         require((compression == 0 || compression == 5) && second[0xd4] == 0);
  180         chunk = be32(second.data() + 0xc);
  181         require(chunk >= Sector && chunk <= MaxChunk && (chunk & (chunk - 1)) == 0);
  182         std::copy_n(second.data() + 0x10, head.size(), head.begin());
  183         require(be32(head.data() + 0x1c) == 0xc2339f3d);
  184         const uint32_t rawCount = be32(second.data() + 0xb4);
  185         const uint32_t groupCount = be32(second.data() + 0xc4);
  186         require(rawCount && rawCount <= MaxRaw && groupCount && groupCount <= MaxGroups);
  187         Bytes table = decode(be64(second.data() + 0xc8), be32(second.data() + 0xd0),
  188             groupCount * 12, compression == 5);
  189         groups.reserve(groupCount);
  190         for (uint32_t i = 0; i < groupCount; ++i)
  191         {
  192             const uint8_t* p = table.data() + size_t(i) * 12;
  193             const uint32_t flags = be32(p + 4);
  194             Group group{uint64_t(be32(p)) * 4, flags & 0x7fffffff, be32(p + 8),
  195                 (flags & 0x80000000) != 0};
  196             require(group.size <= MaxWork && group.packed <= MaxWork);
  197             require(group.offset <= fileSize && group.size <= fileSize - group.offset);
  198             groups.push_back(group);
  199         }
  200         table = decode(be64(second.data() + 0xb8), be32(second.data() + 0xc0),
  201             rawCount * 24, compression == 5);
  202         raw.reserve(rawCount);
  203         for (uint32_t i = 0; i < rawCount; ++i)
  204         {
  205             const uint8_t* p = table.data() + size_t(i) * 24;
  206             const uint64_t offset = be64(p), length = be64(p + 8);
  207             require(offset < discSize && length && length <= discSize - offset);
  208             Raw entry{offset, offset + length, offset - offset % Sector,
  209                 be32(p + 16), be32(p + 20)};
  210             require(entry.first < groups.size() && entry.count <= groups.size() - entry.first);
  211             require(entry.count == (entry.end - entry.aligned + chunk - 1) / chunk);
  212             raw.push_back(entry);
  213         }
  214         std::sort(raw.begin(), raw.end(), [](const Raw& a, const Raw& b) { return a.offset < b.offset; });
  215         uint64_t end = raw.front().offset;
  216         require(end == 0 || end == head.size());
  217         for (const Raw& entry : raw)
  218         {
  219             require(entry.offset == end);
  220             end = entry.end;
  221         }
  222         require(end == discSize);
  223     }
  224 
  225     void seek(int64_t offset, int origin)
  226     {
  227         uint64_t base;
  228         if (origin == SEEK_SET) base = 0;
  229         else if (origin == SEEK_CUR) base = position;
  230         else if (origin == SEEK_END) base = discSize;
  231         else { failed = true; return; }
  232         if (offset < 0)
  233         {
  234             if (offset < -static_cast<int64_t>(base)) { failed = true; return; }
  235             position = base - static_cast<uint64_t>(-offset);
  236         }
  237         else
  238         {
  239             if (static_cast<uint64_t>(offset) > discSize - base) { failed = true; return; }
  240             position = base + static_cast<uint64_t>(offset);
  241         }
  242     }
  243     int64_t tell() const { return static_cast<int64_t>(position); }
  244     size_t read(void* destination, size_t requested)
  245     {
  246         if (failed || requested > discSize - position || requested > 128 * 1024 * 1024 - totalRead)
  247         {
  248             failed = true;
  249             return 0;
  250         }
  251         totalRead += requested;
  252         auto* out = static_cast<uint8_t*>(destination);
  253         size_t done = 0;
  254         while (done < requested)
  255         {
  256             if (position < head.size())
  257             {
  258                 const size_t take = std::min(requested - done, head.size() - size_t(position));
  259                 std::memcpy(out + done, head.data() + position, take);
  260                 position += take;
  261                 done += take;
  262                 continue;
  263             }
  264             const auto found = std::upper_bound(raw.begin(), raw.end(), position,
  265                 [](uint64_t value, const Raw& entry) { return value < entry.offset; });
  266             require(found != raw.begin());
  267             const Raw& entry = *(found - 1);
  268             require(position < entry.end);
  269             const uint64_t groupBase = entry.aligned + (position - entry.aligned) / chunk * chunk;
  270             const uint32_t index = entry.first + uint32_t((position - entry.aligned) / chunk);
  271             const size_t length = static_cast<size_t>(std::min(uint64_t(chunk), entry.end - groupBase));
  272             if (cachedIndex != index || cachedBase != groupBase || cache.size() != length)
  273             {
  274                 const Group& group = groups[index];
  275                 Bytes decoded;
  276                 if (!group.size)
  277                 {
  278                     accountDecoded(length);
  279                     decoded.assign(length, 0);
  280                 }
  281                 else
  282                 {
  283                     decoded = decode(group.offset, group.size,
  284                         group.packed ? group.packed : length, group.compressed && compression == 5);
  285                     if (group.packed)
  286                     {
  287                         accountDecoded(length);
  288                         decoded = unpack(decoded, length, groupBase);
  289                     }
  290                 }
  291                 cache = std::move(decoded);
  292                 cachedIndex = index;
  293                 cachedBase = groupBase;
  294             }
  295             const size_t into = static_cast<size_t>(position - groupBase);
  296             const size_t take = std::min(requested - done, cache.size() - into);
  297             require(take != 0);
  298             std::memcpy(out + done, cache.data() + into, take);
  299             done += take;
  300             position += take;
  301         }
  302         return done;
  303     }
  304     bool failed = false;
  305 
  306 private:
  307     Bytes physical(uint64_t offset, size_t bytes)
  308     {
  309         require(bytes <= MaxWork && offset <= fileSize && bytes <= fileSize - offset);
  310         require(intfstream_seek(stream.get(), static_cast<int64_t>(offset), SEEK_SET) >= 0);
  311         Bytes result(bytes);
  312         require(intfstream_read(stream.get(), result.data(), bytes) == static_cast<int64_t>(bytes));
  313         return result;
  314     }
  315     void accountDecoded(size_t bytes)
  316     {
  317         require(bytes <= MaxWork && bytes <= 512 * 1024 * 1024 - totalDecoded);
  318         totalDecoded += bytes;
  319     }
  320     Bytes decode(uint64_t offset, uint32_t bytes, size_t expected, bool compressed)
  321     {
  322         accountDecoded(expected);
  323         Bytes input = physical(offset, bytes);
  324         if (!compressed)
  325         {
  326             require(input.size() == expected);
  327             return input;
  328         }
  329         require(!input.empty());
  330         const size_t frameSize = ZSTD_findFrameCompressedSize(input.data(), input.size());
  331         require(!ZSTD_isError(frameSize) && frameSize == input.size());
  332         Bytes output(expected);
  333         const size_t actual = ZSTD_decompress(output.data(), output.size(), input.data(), input.size());
  334         require(!ZSTD_isError(actual) && actual == expected);
  335         return output;
  336     }
  337     std::unique_ptr<intfstream_t, StreamCloser> stream;
  338     uint64_t fileSize = 0, discSize = 0, position = 0;
  339     uint32_t chunk = 0, compression = 0;
  340     std::array<uint8_t, 128> head{};
  341     std::vector<Raw> raw;
  342     std::vector<Group> groups;
  343     Bytes cache;
  344     uint32_t cachedIndex = UINT32_MAX;
  345     uint64_t cachedBase = 0;
  346     size_t totalRead = 0, totalDecoded = 0;
  347 };
  348 
  349 void* openRvz(const char* path)
  350 {
  351     try { return new Reader(path); }
  352     catch (...) { return nullptr; }
  353 }
  354 void closeRvz(void* opaque) { delete static_cast<Reader*>(opaque); }
  355 void seekRvz(void* opaque, int64_t offset, int origin)
  356 {
  357     static_cast<Reader*>(opaque)->seek(offset, origin);
  358 }
  359 int64_t tellRvz(void* opaque) { return static_cast<Reader*>(opaque)->tell(); }
  360 size_t readRvz(void* opaque, void* data, size_t bytes)
  361 {
  362     Reader& reader = *static_cast<Reader*>(opaque);
  363     try { return reader.read(data, bytes); }
  364     catch (...) { reader.failed = true; return 0; }
  365 }
  366 struct Iterator
  367 {
  368     explicit Iterator(const char* path) { rc_hash_initialize_iterator(&value, path, nullptr, 0); }
  369     ~Iterator() { rc_hash_destroy_iterator(&value); }
  370     rc_hash_iterator_t value;
  371 };
  372 } // namespace
  373 
  374 bool generateGameCubeRvzHash(char hash[33], const char* path)
  375 {
  376     hash[0] = '\0';
  377     try
  378     {
  379         Iterator iterator(path);
  380         if (!iterator.value.path)
  381             return false;
  382         iterator.value.callbacks.filereader = {openRvz, seekRvz, tellRvz, readRvz, closeRvz};
  383         if (rc_hash_generate(hash, RC_CONSOLE_GAMECUBE, &iterator.value))
  384             return true;
  385     }
  386     catch (...) {}
  387     hash[0] = '\0';
  388     return false;
  389 }
```

## ES 3178b832b8d1:external/libcheevos/rvz_hash.h

```text
    1 // SPDX-License-Identifier: MIT
    2 // Copyright (c) 2026 pixelelated contributors
    3 #pragma once
    4 
    5 // GameCube RVZ only; unsupported or malformed data returns false.
    6 // No global rcheevos callback changes and no temporary extracted image.
    7 bool generateGameCubeRvzHash(char hash[33], const char* path);
```

## ES 3178b832b8d1:es-app/src/ApiSystem.cpp

```text
  475 	}
  476 
  477 	LOG(LogInfo) << "Cannot update ";
  478 	return false;
  479 }
  480 
  481 void ApiSystem::launchExternalWindow_before(Window *window) 
  482 {
  483 	LOG(LogDebug) << "ApiSystem::launchExternalWindow_before";
  484 
  485 	AudioManager::getInstance()->deinit();
  486 	VolumeControl::getInstance()->deinit();
  487 	window->deinit();
  488 
  489 	LOG(LogDebug) << "ApiSystem::launchExternalWindow_before OK";
  490 }
  491 
  492 void ApiSystem::launchExternalWindow_after(Window *window) 
  493 {
  494 	LOG(LogDebug) << "ApiSystem::launchExternalWindow_after";
  495 
  496 	Utils::FileSystem::FileSystemCache::reset();
  497 
  498 	window->init();
  499 	VolumeControl::getInstance()->init();
  500 	AudioManager::getInstance()->init();
  501 	window->normalizeNextUpdate();
  502 	window->reactivateGui();
  503 
  504 	AudioManager::getInstance()->playRandomMusic();
  505 
  506 	LOG(LogDebug) << "ApiSystem::launchExternalWindow_after OK";
  507 }
  508 
  509 #ifdef BATOCERA
  510 void ApiSystem::launchControlcenter() {
  511   system("batocera-controlcenter");
  512 }
  513 #endif
  514 
  515 bool ApiSystem::launchKodi(Window *window) 
  516 {
  517 	LOG(LogDebug) << "ApiSystem::launchKodi";
  518 
  519 	std::string commandline = InputManager::getInstance()->configureEmulators();
  520 	std::string command = "batocera-kodi " + commandline;
  521 
  522 	ApiSystem::launchExternalWindow_before(window);
  523 
  524 	int exitCode = system(command.c_str());
  525 
  526 	// WIFEXITED returns a nonzero value if the child process terminated normally with exit or _exit.
  527 	// https://www.gnu.org/software/libc/manual/html_node/Process-Completion-Status.html
  528 	if (WIFEXITED(exitCode))
  529 		exitCode = WEXITSTATUS(exitCode);
  530 
  531 	ApiSystem::launchExternalWindow_after(window);
  532 
  533 	// handle end of kodi
  534 	switch (exitCode) 
  535 	{
  536 	case 10: // reboot code
  537 		Utils::Platform::quitES(Utils::Platform::QuitMode::REBOOT);
  538 		return true;
  539 		
  540 	case 11: // shutdown code
  541 		Utils::Platform::quitES(Utils::Platform::QuitMode::SHUTDOWN);
  542 		return true;
  543 	}
  544 
  545 	return exitCode == 0;
  546 }
  547 
  548 // The cloud sign-in page, which is a separate Wayland client that covers the
  549 // screen for as long as somebody is signing in.
  550 //
  551 // It is a takeover like Kodi or the file manager, and was not treated as one:
  552 // ES stayed up behind it, still rendering and still reading the gamepad. SDL
  553 // joystick events are not gated on window focus, so every d-pad press and
  554 // every A meant for the provider's page also drove the menu underneath.
  555 // Suspending ES stops that at the source and hands back the memory its
  556 // renderer and textures were holding, which is the difference between
  557 // comfortable and marginal when WebKit needs most of a gigabyte.
  558 //
  559 // `open` returns once the window is actually up, so the screen is never blank
  560 // between ES going down and the page appearing. `wait` blocks until the page
  561 // is gone *and* the gamepad has been released, which is what ES needs before
  562 // it re-initialises -- SDL re-opens the joystick on init and would otherwise
  563 // come back with no gamepad at all.
  564 bool ApiSystem::launchCloudSignIn(Window *window, bool phoneKeyboard)
  565 {
  566 	LOG(LogDebug) << "ApiSystem::launchCloudSignIn";
  567 
  568 	// --phone tells the window not to raise its own keyboard: somebody who
  569 	// chose to type on their phone does not want the screen they are reading
  570 	// the form on covered by a keyboard they did not ask for.
  571 	const char* open = phoneKeyboard
  572 		? "/usr/bin/cloud_oauth open --phone" : "/usr/bin/cloud_oauth open";
  573 	if (system(open) != 0)
  574 	{
  575 		LOG(LogWarning) << "cloud sign-in window did not open; staying put";
  576 		return false;
  577 	}
  578 
  579 	ApiSystem::launchExternalWindow_before(window);
  580 #if defined(__GLIBC__)
  581 	// Return freed renderer heaps before waiting for sign-in (distro #570).
  582 	malloc_trim(0);
  583 #endif
  584 	int exitCode = system("/usr/bin/cloud_oauth wait");
  585 	if (WIFEXITED(exitCode))
  586 		exitCode = WEXITSTATUS(exitCode);
  587 	ApiSystem::launchExternalWindow_after(window);
  588 
  589 	// `wait` returns as soon as the sign-in lands, with the page still up
  590 	// saying "Finishing up" -- so this rebuild happens behind something
  591 	// rather than in front of a black screen. Now that we are drawing again,
  592 	// the page can go.
  593 	system("/usr/bin/cloud_oauth close");
  594 
  595 	return exitCode == 0;
  596 }
  597 
  598 bool ApiSystem::launchFileManager(Window *window) 
  599 {
  600 	LOG(LogDebug) << "ApiSystem::launchFileManager";
  601 
  602 	std::string command = "filemanagerlauncher";
  603 
  604 	ApiSystem::launchExternalWindow_before(window);
  605 
  606 	int exitCode = system(command.c_str());
  607 	if (WIFEXITED(exitCode))
  608 		exitCode = WEXITSTATUS(exitCode);
  609 
  610 	ApiSystem::launchExternalWindow_after(window);
```

## ES 3178b832b8d1:es-app/src/scrapers/ScreenScraper.cpp

```text
   20 #include <thread>
   21 
   22 // bezel-16-9 
   23 // bezel-4-3
   24 
   25 using namespace PlatformIds;
   26 
   27 #if defined(SCREENSCRAPER_DEV_LOGIN) || defined(SCREENSCRAPER_RUNTIME_DEV_LOGIN)
   28 
   29 // A compiled developer pair takes precedence. Runtime-only builds read it
   30 // from settings under SCRAPER > ACCOUNTS (#64); normal distribution builds
   31 // supply it at build time and hide those developer rows (#566). Callers check
   32 // for empty and say what is missing rather than letting the API answer with
   33 // a login error.
   34 std::string screenScraperDevLogin()
   35 {
   36 #if defined(SCREENSCRAPER_DEV_LOGIN)
   37 	return SCREENSCRAPER_DEV_LOGIN;
   38 #else
   39 	const std::string id = Settings::getInstance()->getString("ScreenScraperDevId");
   40 	const std::string pass = Settings::getInstance()->getString("ScreenScraperDevPass");
   41 	if (id.empty() || pass.empty())
   42 		return "";
   43 	return "devid=" + HttpReq::urlEncode(id) + "&devpassword=" + HttpReq::urlEncode(pass);
   44 #endif
   45 }
   46 
   47 /**
   48 	List of systems and thein IDs from
  850 
  851 		out_results.push_back(result);
  852 	} // game
  853 
  854 	LOG(LogDebug) << "ScreenScraperRequest::processGame <<";
  855 }
  856 
  857 std::string ScreenScraperRequest::ScreenScraperConfig::getGameSearchUrl(const std::string gameName, bool jeuRecherche) const
  858 {	
  859 	std::string ret = API_URL_BASE
  860 		+ "/jeuInfos.php?" + screenScraperDevLogin() +
  861 		+ "&softname=" + HttpReq::urlEncode(VERSIONED_SOFT_NAME)
  862 		+ "&output=xml"
  863 		+ "&romnom=" + HttpReq::urlEncode(gameName);
  864 
  865 	if (jeuRecherche)
  866 	{
  867 		ret = std::string(API_URL_BASE)
  868 			+ "/jeuRecherche.php?" + screenScraperDevLogin() +
  869 			+ "&softname=" + HttpReq::urlEncode(VERSIONED_SOFT_NAME)
  870 			+ "&output=xml"
  871 			+ "&recherche=" + HttpReq::urlEncode(gameName);
  872 	}
  873 
  874 	std::string user = Settings::getInstance()->getString("ScreenScraperUser");
  875 	std::string pass = Settings::getInstance()->getString("ScreenScraperPass");
  876 
  877 	if (!user.empty() && !pass.empty())
  878 		ret = ret + "&ssid=" + HttpReq::urlEncode(user) + "&sspassword=" + HttpReq::urlEncode(pass);
  879 
  880 	return ret;
  881 }
  882 
  883 std::string ScreenScraperRequest::ScreenScraperConfig::getUserInfoUrl() const
  884 {
  885 	std::string ret = API_URL_BASE
  886 		+ "/ssuserInfos.php?" + screenScraperDevLogin() +
  887 		+ "&softname=" + HttpReq::urlEncode(VERSIONED_SOFT_NAME)
  888 		+ "&output=xml";
  889 
  890 	std::string user = Settings::getInstance()->getString("ScreenScraperUser");
  891 	std::string pass = Settings::getInstance()->getString("ScreenScraperPass");
  892 
  893 	if (!user.empty() && !pass.empty())
  894 		ret = ret + "&ssid=" + HttpReq::urlEncode(user) + "&sspassword=" + HttpReq::urlEncode(pass);
  895 
  896 	return ret;
  897 }
  898 
  899 
  900 std::string ScreenScraperRequest::ensureUrl(const std::string& url)
  966 // What the screen says when ScreenScraper refuses the first request of a
  967 // scrape (#66). The API answers every failure with a French sentence, and
  968 // asked with a bad developer pair together with an account it blames the
  969 // account ("Verifier les identifiants utilisateurs"), while asked with the
  970 // pair alone it blames the pair ("Verifier vos identifiants developpeur").
  971 // EmulationStation used to put that body on screen as it came. So: the body
  972 // goes to the log; a login failure is told apart by one call with the pair
  973 // alone -- made only after a failure, so a scrape that starts makes no
  974 // extra request -- and the screen gives recovery guidance for this build's
  975 // credential source. No code on screen: it is in the log (D-UI-028).
  976 static std::string screenScraperFailureMessage(HttpReq& req, const ScreenScraperRequest::ScreenScraperConfig& config)
  977 {
  978 	const int status = req.status();
  979 	const std::string body = Utils::String::trim(Utils::String::removeHtmlTags(req.getErrorMsg()));
  980 	LOG(LogError) << "ScreenScraper refused the user-info request: HTTP " << status << ": " << body;
  981 	const std::string lower = Utils::String::toLower(body);
  982 
  983 	// No answer at all -- no route, no DNS, a timeout, a cut link: curl got
  984 	// no HTTP status, and the body is curl's own sentence, which the tests
  985 	// below would read as the server's ("Couldn't resolve host" used to come
  986 	// out as SCREENSCRAPER ANSWERED WITH AN ERROR). Say the player is
  987 	// offline and stop; no credential is named, none was looked at
  988 	// (#151 PL-07).
  989 	if (status == HttpReq::REQ_IO_ERROR || status == HttpReq::REQ_IN_PROGRESS)
  990 		return _("YOU'RE NOT ONLINE. TRY AGAIN WHEN YOU ARE.");
  991 
  992 	// The status is the one thing the API says in a form a program can
  993 	// read; HttpReq names every code it documents. Only 403 covers both
  994 	// credentials, and on this endpoint its body always says "utilisateurs"
  995 	// -- with a bad pair, with no pair at all -- so the body cannot say
  996 	// which; the probe below can.
  997 	switch (status)
  998 	{
  999 	case HttpReq::REQ_401_FORBIDDEN:
 1000 		return _("SCREENSCRAPER IS OPEN TO ITS MEMBERS ONLY RIGHT NOW. TRY AGAIN LATER.");
 1001 	case HttpReq::REQ_426_SERVERMAINTENANCE:
 1002 		return _("SCREENSCRAPER IS DOWN FOR MAINTENANCE. TRY AGAIN LATER.");
 1003 	case HttpReq::REQ_426_BLACKLISTED:
 1004 		return _("SCREENSCRAPER HAS BLOCKED THIS VERSION OF THE SCRAPER.");
 1005 	case HttpReq::REQ_429_TOOMANYREQUESTS:
 1006 		return _("SCREENSCRAPER IS BUSY. TRY AGAIN IN A MINUTE.");
 1007 	case HttpReq::REQ_430_TOOMANYSCRAPS:
 1008 		return _("YOU HAVE REACHED TODAY'S SCREENSCRAPER QUOTA. TRY AGAIN TOMORROW.");
 1009 	case HttpReq::REQ_430_TOOMANYFAILURES:
 1010 		return _("TOO MANY FAILED SCREENSCRAPER REQUESTS TODAY. TRY AGAIN TOMORROW.");
 1011 	case HttpReq::REQ_403_BADLOGIN:
 1012 		break;
 1013 	default:
 1014 		if (lower.find("maintenance") != std::string::npos || lower.find("ferm") != std::string::npos)
 1015 			return _("SCREENSCRAPER IS DOWN FOR MAINTENANCE. TRY AGAIN LATER.");
 1016 		if (lower.find("identifiant") == std::string::npos && lower.find("login") == std::string::npos)
 1017 			return _("SCREENSCRAPER ANSWERED WITH AN ERROR. TRY AGAIN LATER.");
 1018 		break;
 1019 	}
 1020 
 1021 	// The pair alone, first. A rejected pair answers 200 with a sentence,
 1022 	// not XML; an accepted one lists the systems with or without an account
 1023 	// (tested with the public JELOS pair, 2026-09-13: systemesListe.php
 1024 	// answers the pair alone with 200 XML while ssuserInfos.php gives the
 1025 	// same pair 403). So the probe settles the pair before the account is
 1026 	// looked at. It used to run only once an account was set, and a player
 1027 	// with a mistyped pair and no account was told to add an account, added
 1028 	// one, and failed again on the pair -- two failures where one would do
 1029 	// (#151 PL-06).
 1030 	HttpReq probe(config.API_URL_BASE + "/systemesListe.php?" + screenScraperDevLogin()
 1031 		+ "&softname=" + HttpReq::urlEncode(VERSIONED_SOFT_NAME) + "&output=xml");
 1032 	probe.wait();
 1033 	// Three answers, not two: accepted (200 and XML), rejected (200 and a
 1034 	// sentence), and nothing worth reading (a timeout, a 429, a maintenance
 1035 	// page, a link that dropped between the two requests). Only the second
 1036 	// blames the pair. The third used to, and sent a player whose link had
 1037 	// just gone to check a password that was fine (#151 PL-07).
 1038 	enum { PairAccepted, PairRejected, PairUnknown } pair = PairUnknown;
 1039 	if (probe.status() == HttpReq::REQ_SUCCESS)
 1040 		pair = Utils::String::trim(probe.getContent()).find("<?xml") == 0 ? PairAccepted : PairRejected;
 1041 	LOG(LogInfo) << "ScreenScraper developer pair alone: HTTP " << probe.status()
 1042 		<< (pair == PairAccepted ? ", accepted" : pair == PairRejected ? ", rejected" : ", no usable answer");
 1043 	if (pair == PairUnknown)
 1044 		return _("COULDN'T REACH SCREENSCRAPER. TRY AGAIN.");
 1045 	if (pair == PairRejected)
 1046 	{
 1047 #if defined(SCREENSCRAPER_DEV_LOGIN)
 1048 		return _("SCREENSCRAPER REJECTED THIS SYSTEM'S ACCESS.\nCHECK FOR A SYSTEM UPDATE OR REPORT THE PROBLEM.");
 1049 #else
 1050 		return _("SCREENSCRAPER REJECTED THE DEVELOPER ID OR PASSWORD.\nCHECK THEM UNDER SCRAPER > ACCOUNTS.");
 1051 #endif
 1052 	}
 1053 
 1054 	// The pair is fine and the API still refused: it needs an account on
 1055 	// this request and on every game request, so with none configured the
 1056 	// account is what is missing. Say that, rather than that a password
 1057 	// they never typed was rejected.
 1058 	if (Settings::getInstance()->getString("ScreenScraperUser").empty() || Settings::getInstance()->getString("ScreenScraperPass").empty())
 1059 		return _("SCREENSCRAPER NEEDS YOUR ACCOUNT TO SCRAPE.\nADD IT UNDER SCRAPER > ACCOUNTS.");
 1060 	return _("SCREENSCRAPER REJECTED YOUR USERNAME OR PASSWORD.\nCHECK THEM UNDER SCRAPER > ACCOUNTS.");
 1061 }
 1062 
```

## ES 3178b832b8d1:es-core/src/Settings.cpp

```text
  310 
  311 	mBoolMap["VideoAudio"] = true;
  312 	mBoolMap["ScreenSaverVideoMute"] = false;
  313 	mBoolMap["VideoLowersMusic"] = true;
  314 	mBoolMap["VolumePopup"] = Settings::_VolumePopup;
  315 	mBoolMap["RightStickVolume"] = true;
  316 
  317 	mIntMap["MusicVolume"] = 128;
  318 
  319 	// Audio out device for Video playback using OMX player.
  320 	mStringMap["OMXAudioDev"] = "both";
  321 	mStringMap["CollectionSystemsAuto"] = "favorites,recent"; // 2players,4players,favorites,recent
  322 	mStringMap["CollectionSystemsCustom"] = "";
  323 	mBoolMap["SortAllSystems"] = true; 
  324 	mStringMap["SortSystems"] = "manufacturer";
  325 	
  326 	mStringMap["UseCustomCollectionsSystemEx"] = "";
  327 	
  328 	mBoolMap["HiddenSystemsShowGames"] = false;
  329 	mBoolMap["CollectionShowSystemInfo"] = true;
```

## Built frozen Dolphin6094cfcf:Source/Core/DolphinNoGUI/MainNoGUI.cpp

```text
    1 // Copyright 2008 Dolphin Emulator Project
    2 // SPDX-License-Identifier: GPL-2.0-or-later
    3 
    4 #include "DolphinNoGUI/Platform.h"
    5 
    6 #include <OptionParser.h>
    7 #include <csignal>
    8 #include <cstdio>
    9 #include <string>
   10 #include <vector>
   11 
   12 #ifndef _WIN32
   13 #include <unistd.h>
   14 #else
   15 #include <Windows.h>
   16 #endif
   17 
   18 #include "Common/ScopeGuard.h"
   19 #include "Core/Boot/Boot.h"
   20 #include "Core/BootManager.h"
   21 #include "Core/Core.h"
   22 #include "Core/DolphinAnalytics.h"
   23 #include "Core/Host.h"
   24 #include "Core/System.h"
   25 
   26 #include "UICommon/CommandLineParse.h"
   27 #ifdef USE_DISCORD_PRESENCE
   28 #include "UICommon/DiscordPresence.h"
   29 #endif
   30 #include "UICommon/UICommon.h"
   31 
   32 static std::unique_ptr<Platform> s_platform;
   33 
   34 static void signal_handler(int)
   35 {
   36   constexpr char message[] = "A signal was received. A second signal will force Dolphin to stop.\n";
   37 #ifdef _WIN32
   38   puts(message);
   39 #else
   40   if (write(STDERR_FILENO, message, sizeof(message)) < 0)
   41   {
   42   }
   43 #endif
   44 
   45   s_platform->RequestShutdown();
   46 }
   47 
   48 std::vector<std::string> Host_GetPreferredLocales()
   49 {
   50   return {};
   51 }
   52 
   53 void Host_PPCSymbolsChanged()
   54 {
   55 }
   56 
   57 void Host_PPCBreakpointsChanged()
   58 {
   59 }
   60 
   61 bool Host_UIBlocksControllerState()
   62 {
   63   return false;
   64 }
   65 
   66 void Host_Message(const HostMessageID id)
   67 {
   68   if (id == HostMessageID::WMUserStop)
   69     s_platform->Stop();
   70 }
   71 
   72 void Host_UpdateTitle(const std::string& title)
   73 {
   74   s_platform->SetTitle(title);
   75 }
   76 
   77 void Host_UpdateDisasmDialog()
   78 {
   79 }
   80 
   81 void Host_JitCacheInvalidation()
   82 {
   83 }
   84 
   85 void Host_JitProfileDataWiped()
   86 {
   87 }
   88 
   89 void Host_RequestRenderWindowSize(int width, int height)
   90 {
   91 }
   92 
   93 bool Host_RendererHasFocus()
   94 {
   95   return s_platform->IsWindowFocused();
   96 }
   97 
   98 bool Host_RendererHasFullFocus()
   99 {
  100   // Mouse capturing isn't implemented
  101   return Host_RendererHasFocus();
  102 }
  103 
  104 bool Host_RendererIsFullscreen()
  105 {
  106   return s_platform->IsWindowFullscreen();
  107 }
  108 
  109 bool Host_TASInputHasFocus()
  110 {
  111   return false;
  112 }
  113 
  114 void Host_YieldToUI()
  115 {
  116 }
  117 
  118 void Host_TitleChanged()
  119 {
  120 #ifdef USE_DISCORD_PRESENCE
  121   Discord::UpdateDiscordPresence();
  122 #endif
  123 }
  124 
  125 void Host_UpdateDiscordClientID(const std::string& client_id)
  126 {
  127 #ifdef USE_DISCORD_PRESENCE
  128   Discord::UpdateClientID(client_id);
  129 #endif
  130 }
  131 
  132 bool Host_UpdateDiscordPresenceRaw(const std::string& details, const std::string& state,
  133                                    const std::string& large_image_key,
  134                                    const std::string& large_image_text,
  135                                    const std::string& small_image_key,
  136                                    const std::string& small_image_text,
  137                                    const int64_t start_timestamp, const int64_t end_timestamp,
  138                                    const int party_size, const int party_max)
  139 {
  140 #ifdef USE_DISCORD_PRESENCE
  141   return Discord::UpdateDiscordPresenceRaw(details, state, large_image_key, large_image_text,
  142                                            small_image_key, small_image_text, start_timestamp,
  143                                            end_timestamp, party_size, party_max);
  144 #else
  145   return false;
  146 #endif
  147 }
  148 
  149 std::unique_ptr<GBAHostInterface> Host_CreateGBAHost(std::weak_ptr<HW::GBA::Core> core)
  150 {
  151   return nullptr;
  152 }
  153 
  154 static std::unique_ptr<Platform> GetPlatform(const optparse::Values& options)
  155 {
  156   std::string platform_name = static_cast<const char*>(options.get("platform"));
  157 
  158 #ifdef HAVE_WAYLAND
  159   if (platform_name == "wayland")
  160     return Platform::CreateWaylandPlatform();
  161 #endif
  162 
  163 #if HAVE_X11
  164   if (platform_name == "x11" || platform_name.empty())
  165     return Platform::CreateX11Platform();
  166 #endif
  167 
  168 #ifdef __linux__
  169   if (platform_name == "fbdev" || platform_name.empty())
  170     return Platform::CreateFBDevPlatform();
  171 #endif
  172 
  173 #ifdef _WIN32
  174   if (platform_name == "win32" || platform_name.empty())
  175     return Platform::CreateWin32Platform();
  176 #endif
  177 #ifdef __APPLE__
  178   if (platform_name == "macos" || platform_name.empty())
  179     return Platform::CreateMacOSPlatform();
  180 #endif
  181 
  182   if (platform_name == "headless" || platform_name.empty())
  183     return Platform::CreateHeadlessPlatform();
  184 
  185   return nullptr;
  186 }
  187 
  188 #ifdef _WIN32
  189 #define main app_main
  190 #endif
  191 
  192 int main(const int argc, char* argv[])
  193 {
  194   const auto parser =
  195       CommandLineParse::CreateParser(CommandLineParse::ParserOptions::OmitGUIOptions);
  196   parser->add_option("-p", "--platform")
  197       .action("store")
  198       .help("Window platform to use [%choices]")
  199       .choices({"headless"
  200 #ifdef __linux__
  201                 ,
  202                 "fbdev"
  203 #endif
  204 #if HAVE_X11
  205                 ,
  206                 "x11"
  207 #endif
  208 #ifdef HAVE_WAYLAND
  209                 ,
  210                 "wayland"
  211 #endif
  212 #ifdef _WIN32
  213                 ,
  214                 "win32"
  215 #endif
  216 #ifdef __APPLE__
  217                 ,
  218                 "macos"
  219 #endif
  220       });
  221 
  222   optparse::Values& options = CommandLineParse::ParseArguments(parser.get(), argc, argv);
  223   std::vector<std::string> args = parser->args();
  224 
  225   std::optional<std::string> save_state_path;
  226   if (options.is_set("save_state"))
  227   {
  228     save_state_path = static_cast<const char*>(options.get("save_state"));
  229   }
  230 
  231   std::unique_ptr<BootParameters> boot;
  232   bool game_specified = false;
  233   if (options.is_set("exec"))
  234   {
  235     const std::list<std::string> paths_list = options.all("exec");
  236     const std::vector<std::string> paths{std::make_move_iterator(std::begin(paths_list)),
  237                                          std::make_move_iterator(std::end(paths_list))};
  238     boot = BootParameters::GenerateFromFile(
  239         paths, BootSessionData(save_state_path, DeleteSavestateAfterBoot::No));
  240     game_specified = true;
  241   }
  242   else if (options.is_set("nand_title"))
  243   {
  244     const std::string hex_string = static_cast<const char*>(options.get("nand_title"));
  245     if (hex_string.length() != 16)
  246     {
  247       fprintf(stderr, "Invalid title ID\n");
  248       parser->print_help();
  249       return 1;
  250     }
  251     const u64 title_id = std::stoull(hex_string, nullptr, 16);
  252     boot = std::make_unique<BootParameters>(BootParameters::NANDTitle{title_id});
  253   }
  254   else if (args.size())
  255   {
  256     boot = BootParameters::GenerateFromFile(
  257         args.front(), BootSessionData(save_state_path, DeleteSavestateAfterBoot::No));
  258     args.erase(args.begin());
  259     game_specified = true;
  260   }
  261   else
  262   {
  263     parser->print_help();
  264     return 0;
  265   }
  266 
  267   std::string user_directory;
  268   if (options.is_set("user"))
  269     user_directory = static_cast<const char*>(options.get("user"));
  270 
  271   s_platform = GetPlatform(options);
  272   if (!s_platform || !s_platform->Init())
  273   {
  274     fprintf(stderr, "No platform found, or failed to initialize.\n");
  275     return 1;
  276   }
  277 
  278   const WindowSystemInfo wsi = s_platform->GetWindowSystemInfo();
  279 
  280   UICommon::SetUserDirectory(user_directory);
  281   UICommon::Init();
  282   UICommon::InitControllers(wsi);
  283 
  284   Common::ScopeGuard ui_common_guard([] {
  285     UICommon::ShutdownControllers();
  286     UICommon::Shutdown();
  287   });
  288 
  289   if (save_state_path && !game_specified)
  290   {
  291     fprintf(stderr, "A save state cannot be loaded without specifying a game to launch.\n");
  292     return 1;
  293   }
  294 
  295   auto core_state_changed_hook = Core::AddOnStateChangedCallback([](const Core::State state) {
  296     if (state == Core::State::Uninitialized)
  297       s_platform->Stop();
  298   });
  299 
  300 #ifdef _WIN32
  301   std::signal(SIGINT, signal_handler);
  302   std::signal(SIGTERM, signal_handler);
  303 #else
  304   // Shut down cleanly on SIGINT and SIGTERM
  305   struct sigaction sa;
  306   sa.sa_handler = signal_handler;
  307   sigemptyset(&sa.sa_mask);
  308   sa.sa_flags = SA_RESTART | SA_RESETHAND;
  309   sigaction(SIGINT, &sa, nullptr);
  310   sigaction(SIGTERM, &sa, nullptr);
  311 #endif
  312 
  313   DolphinAnalytics::Instance().ReportDolphinStart("nogui");
  314 
  315   if (!BootManager::BootCore(Core::System::GetInstance(), std::move(boot), wsi))
  316   {
  317     fprintf(stderr, "Could not boot the specified file\n");
  318     return 1;
  319   }
  320 
  321 #ifdef USE_DISCORD_PRESENCE
  322   Discord::UpdateDiscordPresence();
  323 #endif
  324 
  325   s_platform->MainLoop();
  326   Core::Stop(Core::System::GetInstance());
  327 
  328   Core::Shutdown(Core::System::GetInstance());
  329   s_platform.reset();
  330 
  331   return 0;
  332 }
  333 
  334 #ifdef _WIN32
  335 int wmain(int, wchar_t*[], wchar_t*[])
  336 {
  337   std::vector<std::string> args = Common::CommandLineToUtf8Argv(GetCommandLineW());
  338   const int argc = static_cast<int>(args.size());
  339   std::vector<char*> argv(args.size());
  340   for (size_t i = 0; i < args.size(); ++i)
  341     argv[i] = args[i].data();
  342 
  343   return main(argc, argv.data());
  344 }
  345 
  346 #undef main
  347 #endif
```

## Built frozen Dolphin6094cfcf:Source/Core/Core/AchievementManager.cpp

```text
    1 // Copyright 2023 Dolphin Emulator Project
    2 // SPDX-License-Identifier: GPL-2.0-or-later
    3 
    4 #ifdef USE_RETRO_ACHIEVEMENTS
    5 
    6 #include "Core/AchievementManager.h"
    7 
    8 #include <memory>
    9 
   10 #include <fmt/format.h>
   11 
   12 #include "Common/BitUtils.h"
   13 #include "Common/CommonPaths.h"
   14 #include "Common/Config/Config.h"
   15 #include "Common/FileUtil.h"
   16 #include "Common/HttpRequest.h"
   17 #include "Common/IOFile.h"
   18 #include "Common/JsonUtil.h"
   19 #include "Common/Logging/Log.h"
   20 #include "Common/ScopeGuard.h"
   21 #include "Common/StringUtil.h"
   22 #include "Common/Version.h"
   23 #include "Common/WorkQueueThread.h"
   24 #include "Core/AchievementApprovedHash.h"
   25 #include "Core/ActionReplay.h"
   26 #include "Core/Config/AchievementSettings.h"
   27 #include "Core/Config/FreeLookSettings.h"
   28 #include "Core/Config/MainSettings.h"
   29 #include "Core/ConfigLoaders/GameConfigLoader.h"
   30 #include "Core/ConfigManager.h"
   31 #include "Core/Core.h"
   32 #include "Core/GeckoCode.h"
   33 #include "Core/HW/Memmap.h"
   34 #include "Core/HW/VideoInterface.h"
   35 #include "Core/PatchEngine.h"
   36 #include "Core/PowerPC/MMU.h"
   37 #include "Core/System.h"
   38 #include "DiscIO/Blob.h"
   39 #include "UICommon/DiscordPresence.h"
   40 #include "VideoCommon/Assets/CustomTextureData.h"
   41 #include "VideoCommon/OnScreenDisplay.h"
   42 #include "VideoCommon/VideoEvents.h"
   43 
   44 #ifdef RC_CLIENT_SUPPORTS_RAINTEGRATION
   45 #include <libloaderapi.h>
   46 #include <rcheevos/include/rc_client_raintegration.h>
   47 #include <shlwapi.h>
   48 #endif  // RC_CLIENT_SUPPORTS_RAINTEGRATION
   49 
   50 #ifdef ANDROID
   51 static const Common::HttpRequest::Headers USER_AGENT_HEADER = {
   52     {"User-Agent", Common::GetUserAgentStr() + " (Android)"}};
   53 #else   // ANDROID
   54 static const Common::HttpRequest::Headers USER_AGENT_HEADER = {
   55     {"User-Agent", Common::GetUserAgentStr()}};
   56 #endif  // ANDROID
   57 
   58 AchievementManager& AchievementManager::GetInstance()
   59 {
   60   static AchievementManager s_instance;
   61   return s_instance;
   62 }
   63 
   64 void AchievementManager::Init(void* hwnd)
   65 {
   66   LoadDefaultBadges();
   67   if (!m_client && Config::Get(Config::RA_ENABLED))
   68   {
   69     {
   70       std::lock_guard lg{m_lock};
   71       m_client = rc_client_create(MemoryPeeker, Request);
   72     }
   73     std::string host_url = Config::Get(Config::RA_HOST_URL);
   74     if (!host_url.empty())
   75       rc_client_set_host(m_client, host_url.c_str());
   76     rc_client_set_event_handler(m_client, EventHandler);
   77     rc_client_enable_logging(m_client, RC_CLIENT_LOG_LEVEL_VERBOSE,
   78                              [](const char* message, const rc_client_t* client) {
   79                                INFO_LOG_FMT(ACHIEVEMENTS, "{}", message);
   80                              });
   81     m_config_changed_callback_id = Config::AddConfigChangedCallback([this] { SetHardcoreMode(); });
   82     SetHardcoreMode();
   83     m_queue.Reset("AchievementManagerQueue");
   84     m_image_queue.Reset("AchievementManagerImageQueue");
   85 
   86 #ifdef RC_CLIENT_SUPPORTS_RAINTEGRATION
   87     // Attempt to load the integration DLL from the directory containing the main client executable.
   88     // In x64 build, will look for RA_Integration-x64.dll, then RA_Integration.dll.
   89     // In non-x64 build, will only look for RA_Integration.dll.
   90     rc_client_begin_load_raintegration(
   91         m_client, UTF8ToWString(File::GetExeDirectory()).c_str(), reinterpret_cast<HWND>(hwnd),
   92         "Dolphin", Common::GetScmDescStr().c_str(), LoadIntegrationCallback, NULL);
   93 #else   // RC_CLIENT_SUPPORTS_RAINTEGRATION
   94     if (HasAPIToken())
   95       Login("");
   96     INFO_LOG_FMT(ACHIEVEMENTS, "Achievement Manager Initialized");
   97 #endif  // RC_CLIENT_SUPPORTS_RAINTEGRATION
   98   }
   99 }
  100 
  101 picojson::value AchievementManager::LoadApprovedList()
  102 {
  103   picojson::value temp;
  104   std::string error;
  105   if (!JsonFromFile(fmt::format("{}{}{}", File::GetSysDirectory(), DIR_SEP,
  106                                 ACHIEVEMENT_APPROVED_LIST_FILENAME),
  107                     &temp, &error))
  108   {
  109     WARN_LOG_FMT(ACHIEVEMENTS, "Failed to load approved game settings list {}",
  110                  ACHIEVEMENT_APPROVED_LIST_FILENAME);
  111     WARN_LOG_FMT(ACHIEVEMENTS, "Error: {}", error);
  112     return {};
  113   }
  114   auto context = Common::SHA1::CreateContext();
  115   context->Update(temp.serialize());
  116   auto digest = context->Finish();
  117   if (digest != ACHIEVEMENT_APPROVED_LIST_HASH)
  118   {
  119     WARN_LOG_FMT(ACHIEVEMENTS, "Failed to verify approved game settings list {}",
  120                  ACHIEVEMENT_APPROVED_LIST_FILENAME);
  121     WARN_LOG_FMT(ACHIEVEMENTS, "Expected hash {}, found hash {}",
  122                  Common::SHA1::DigestToString(ACHIEVEMENT_APPROVED_LIST_HASH),
  123                  Common::SHA1::DigestToString(digest));
  124     return {};
  125   }
  126   return temp;
  127 }
  128 
  129 void AchievementManager::Login(const std::string& password)
  130 {
  131   if (!m_client)
  132   {
  133     ERROR_LOG_FMT(
  134         ACHIEVEMENTS,
  135         "Attempted login to RetroAchievements server without achievement client initialized.");
  136     return;
  137   }
  138   if (password.empty())
  139   {
  140     rc_client_begin_login_with_token(m_client, Config::Get(Config::RA_USERNAME).c_str(),
  141                                      Config::Get(Config::RA_API_TOKEN).c_str(), LoginCallback,
  142                                      nullptr);
  143   }
  144   else
  145   {
  146     rc_client_begin_login_with_password(m_client, Config::Get(Config::RA_USERNAME).c_str(),
  147                                         password.c_str(), LoginCallback, nullptr);
  148   }
  149 }
  150 
  151 bool AchievementManager::HasAPIToken() const
  152 {
  153   return !Config::Get(Config::RA_API_TOKEN).empty();
  154 }
  155 
  156 void AchievementManager::LoadGame(const DiscIO::Volume* volume)
  157 {
  158   if (!Config::Get(Config::RA_ENABLED) || !HasAPIToken())
  159   {
  160     return;
  161   }
  162   if (!m_client)
  163   {
  164     ERROR_LOG_FMT(ACHIEVEMENTS,
  165                   "Attempted to load game achievements without achievement client initialized.");
  166     return;
  167   }
  168   if (volume == nullptr)
  169   {
  170     WARN_LOG_FMT(ACHIEVEMENTS, "Software format unsupported by AchievementManager.");
  171     if (rc_client_get_game_info(m_client))
  172     {
  173       OSD::AddMessage("Unsupported media change; disabling achievements.", OSD::Duration::VERY_LONG,
  174                       OSD::Color::RED);
  175       CloseGame();
  176     }
  177     else
  178     {
  179       rc_client_begin_load_game(m_client, "", LoadGameCallback, NULL);
  180     }
  181     return;
  182   }
  183   rc_client_set_unofficial_enabled(m_client, Config::Get(Config::RA_UNOFFICIAL_ENABLED));
  184   rc_client_set_encore_mode_enabled(m_client, Config::Get(Config::RA_ENCORE_ENABLED));
  185   rc_client_set_spectator_mode_enabled(m_client, Config::Get(Config::RA_SPECTATOR_ENABLED));
  186   {
  187     std::lock_guard lg{m_lock};
  188 #ifdef RC_CLIENT_SUPPORTS_RAINTEGRATION
  189     const auto& names = volume->GetLongNames();
  190     if (const auto it = names.find(DiscIO::Language::English); it != names.end())
  191       m_title_estimate = it->second;
  192     else if (!names.empty())
  750     }
  751   }
  752   p.DoMarker("AchievementManager");
  753 }
  754 
  755 void AchievementManager::CloseGame()
  756 {
  757   m_queue.Cancel();
  758   m_image_queue.Cancel();
  759   {
  760     std::lock_guard lg{m_lock};
  761     m_active_challenges.clear();
  762     m_active_leaderboards.clear();
  763     m_game_badge.width = 0;
  764     m_game_badge.height = 0;
  765     m_game_badge.data.clear();
  766     m_unlocked_badges.clear();
  767     m_locked_badges.clear();
  768     m_leaderboard_map.clear();
  769     m_rich_presence.fill('\0');
  770     m_system.store(nullptr, std::memory_order_release);
  771     if (Config::Get(Config::RA_DISCORD_PRESENCE_ENABLED))
  772       Discord::UpdateDiscordPresence();
  773     if (rc_client_get_game_info(m_client))
  774       rc_client_unload_game(m_client);
  775     INFO_LOG_FMT(ACHIEVEMENTS, "Game closed.");
  776   }
  777 
  778   update_event.Trigger(UpdatedItems{.all = true});
  779 }
  780 
  781 void AchievementManager::Logout()
  782 {
  783   {
  784     CloseGame();
  785     std::lock_guard lg{m_lock};
  786     m_player_badge.width = 0;
  787     m_player_badge.height = 0;
  788     m_player_badge.data.clear();
  789     Config::SetBaseOrCurrent(Config::RA_API_TOKEN, "");
  790   }
  791 
  792   update_event.Trigger(UpdatedItems{.all = true});
  793   INFO_LOG_FMT(ACHIEVEMENTS, "Logged out from server.");
  794 }
  795 
  796 void AchievementManager::Shutdown()
  797 {
  798   if (m_client)
  799   {
  800     CloseGame();
  801     m_queue.Shutdown();
  802     Config::RemoveConfigChangedCallback(m_config_changed_callback_id);
  803     std::lock_guard lg{m_lock};
  804     // DON'T log out - keep those credentials for next run.
  805     rc_client_destroy(m_client);
  806     m_client = nullptr;
  807     m_dll_found = false;
  808     INFO_LOG_FMT(ACHIEVEMENTS, "Achievement Manager shut down.");
  809   }
  810 }
  811 
  812 void* AchievementManager::FilereaderOpen(const char* path_utf8)
  813 {
  814   auto state = std::make_unique<FilereaderState>();
  815   {
  816     auto& instance = GetInstance();
  817     std::lock_guard lg{instance.GetLock()};
  818     state->volume = std::move(instance.GetLoadingVolume());
  819   }
  820   if (!state->volume)
  821     return nullptr;
  822   return state.release();
  823 }
  824 
  825 void AchievementManager::FilereaderSeek(void* file_handle, int64_t offset, int origin)
  875     return RC_CONSOLE_WII;
  876   default:
  877     return RC_CONSOLE_UNKNOWN;
  878   }
  879 }
  880 
  881 void AchievementManager::LoadDefaultBadges()
  882 {
  883   std::lock_guard lg{m_lock};
  884 
  885   std::string directory = File::GetSysDirectory() + DIR_SEP + RESOURCES_DIR + DIR_SEP;
  886 
  887   if (m_default_player_badge.data.empty())
  888   {
  889     if (!LoadPNGTexture(&m_default_player_badge,
  890                         fmt::format("{}{}", directory, DEFAULT_PLAYER_BADGE_FILENAME)))
  891     {
  892       ERROR_LOG_FMT(ACHIEVEMENTS, "Default player badge '{}' failed to load",
  893                     DEFAULT_PLAYER_BADGE_FILENAME);
  894     }
  895   }
  896 
  897   if (m_default_game_badge.data.empty())
  898   {
  899     if (!LoadPNGTexture(&m_default_game_badge,
  900                         fmt::format("{}{}", directory, DEFAULT_GAME_BADGE_FILENAME)))
  901     {
  902       ERROR_LOG_FMT(ACHIEVEMENTS, "Default game badge '{}' failed to load",
  903                     DEFAULT_GAME_BADGE_FILENAME);
  904     }
  905   }
  906 
  907   if (m_default_unlocked_badge.data.empty())
  908   {
  909     if (!LoadPNGTexture(&m_default_unlocked_badge,
  910                         fmt::format("{}{}", directory, DEFAULT_UNLOCKED_BADGE_FILENAME)))
  911     {
  912       ERROR_LOG_FMT(ACHIEVEMENTS, "Default unlocked achievement badge '{}' failed to load",
  913                     DEFAULT_UNLOCKED_BADGE_FILENAME);
  914     }
  915   }
  916 
  917   if (m_default_locked_badge.data.empty())
  918   {
  919     if (!LoadPNGTexture(&m_default_locked_badge,
  920                         fmt::format("{}{}", directory, DEFAULT_LOCKED_BADGE_FILENAME)))
  921     {
  922       ERROR_LOG_FMT(ACHIEVEMENTS, "Default locked achievement badge '{}' failed to load",
  923                     DEFAULT_LOCKED_BADGE_FILENAME);
  924     }
  925   }
  926 }
  927 
  928 void AchievementManager::LoginCallback(int result, const char* error_message, rc_client_t* client,
  929                                        void* userdata)
  930 {
  931   auto& instance = AchievementManager::GetInstance();
  932   if (result != RC_OK)
```

## Built frozen Dolphin6094cfcf:Source/Core/Core/AchievementManager.h

```text
  225   static void LeaderboardEntriesCallback(int result, const char* error_message,
  226                                          rc_client_leaderboard_entry_list_t* list,
  227                                          rc_client_t* client, void* userdata);
  228 
  229   static void HandleAchievementTriggeredEvent(const rc_client_event_t* client_event);
  230   static void HandleLeaderboardStartedEvent(const rc_client_event_t* client_event);
  231   static void HandleLeaderboardFailedEvent(const rc_client_event_t* client_event);
  232   static void HandleLeaderboardSubmittedEvent(const rc_client_event_t* client_event);
  233   static void HandleLeaderboardTrackerUpdateEvent(const rc_client_event_t* client_event);
  234   static void HandleLeaderboardTrackerShowEvent(const rc_client_event_t* client_event);
  235   static void HandleLeaderboardTrackerHideEvent(const rc_client_event_t* client_event);
  236   static void HandleAchievementChallengeIndicatorShowEvent(const rc_client_event_t* client_event);
  237   static void HandleAchievementChallengeIndicatorHideEvent(const rc_client_event_t* client_event);
  238   static void HandleAchievementProgressIndicatorShowEvent(const rc_client_event_t* client_event);
  239   static void HandleGameCompletedEvent(const rc_client_event_t* client_event, rc_client_t* client);
  240   static void HandleResetEvent(const rc_client_event_t* client_event);
  241   static void HandleServerErrorEvent(const rc_client_event_t* client_event);
  242 
  243   static void Request(const rc_api_request_t* request, rc_client_server_callback_t callback,
  244                       void* callback_data, rc_client_t* client);
  245   static u32 MemoryPeeker(u32 address, u8* buffer, u32 num_bytes, rc_client_t* client);
  246   void FetchBadge(Badge* badge, u32 badge_type, BadgeNameFunction function,
  247                   UpdatedItems callback_data);
  248   static void EventHandler(const rc_client_event_t* event, rc_client_t* client);
  249 
  250 #ifdef RC_CLIENT_SUPPORTS_RAINTEGRATION
  251   static void LoadIntegrationCallback(int result, const char* error_message, rc_client_t* client,
  252                                       void* userdata);
  253   static void RAIntegrationEventHandler(const rc_client_raintegration_event_t* event,
  254                                         rc_client_t* client);
  255   static void MemoryPoker(u32 address, u8* buffer, u32 num_bytes, rc_client_t* client);
  256   static void GameTitleEstimateHandler(char* buffer, u32 buffer_size, rc_client_t* client);
  257 #endif  // RC_CLIENT_SUPPORTS_RAINTEGRATION
  258 
  259   rc_client_t* m_client{};
  260   std::atomic<Core::System*> m_system{};
  261   std::unique_ptr<DiscIO::Volume> m_loading_volume;
  262   Config::ConfigChangedCallbackID m_config_changed_callback_id;
  263   Badge m_default_player_badge;
  264   Badge m_default_game_badge;
  265   Badge m_default_unlocked_badge;
  266   Badge m_default_locked_badge;
  267   std::atomic_bool m_background_execution_allowed = true;
  268   Badge m_player_badge;
  269   Badge m_game_badge;
  270   bool m_display_welcome_message = false;
  271   std::unordered_map<AchievementId, Badge> m_unlocked_badges;
  272   std::unordered_map<AchievementId, Badge> m_locked_badges;
  273   RichPresence m_rich_presence;
  274   std::chrono::steady_clock::time_point m_last_rp_time = std::chrono::steady_clock::now();
  275   std::chrono::steady_clock::time_point m_last_progress_message = std::chrono::steady_clock::now();
```

## Built frozen Dolphin6094cfcf:Source/Core/UICommon/UICommon.cpp

```text
   50 #include "VideoCommon/VideoConfig.h"
   51 
   52 #ifdef HAVE_QTDBUS
   53 #include "UICommon/DBusUtils.h"
   54 #endif
   55 
   56 #ifdef __APPLE__
   57 #include <IOKit/pwr_mgt/IOPMLib.h>
   58 #endif
   59 
   60 namespace UICommon
   61 {
   62 static Config::ConfigChangedCallbackID s_config_changed_callback_id;
   63 static Common::HookableEvent<> s_flush_unsaved_data_event_hook;
   64 
   65 static void CreateDumpPath(std::string path)
   66 {
   67   if (!path.empty())
   68     File::SetUserPath(D_DUMP_IDX, std::move(path));
   69   File::CreateFullPath(File::GetUserPath(D_DUMPAUDIO_IDX));
   70   File::CreateFullPath(File::GetUserPath(D_DUMPDSP_IDX));
   71   File::CreateFullPath(File::GetUserPath(D_DUMPSSL_IDX));
   72   File::CreateFullPath(File::GetUserPath(D_DUMPFRAMES_IDX));
   73   File::CreateFullPath(File::GetUserPath(D_DUMPOBJECTS_IDX));
   74   File::CreateFullPath(File::GetUserPath(D_DUMPTEXTURES_IDX));
   75   File::CreateFullPath(File::GetUserPath(D_DUMPDEBUG_IDX));
   76   File::CreateFullPath(File::GetUserPath(D_DUMPDEBUG_BRANCHWATCH_IDX));
   77   File::CreateFullPath(File::GetUserPath(D_DUMPDEBUG_JITBLOCKS_IDX));
   78 }
   79 
   80 static void CreateLoadPath(std::string path)
   81 {
   82   if (!path.empty())
   83     File::SetUserPath(D_LOAD_IDX, std::move(path));
   84   File::CreateFullPath(File::GetUserPath(D_HIRESTEXTURES_IDX));
   85   File::CreateFullPath(File::GetUserPath(D_RIIVOLUTION_IDX));
   86   File::CreateFullPath(File::GetUserPath(D_GRAPHICSMOD_IDX));
   87   File::CreateFullPath(File::GetUserPath(D_DYNAMICINPUT_IDX));
   88 }
   89 
   90 static void CreateResourcePackPath(std::string path)
   91 {
   92   if (!path.empty())
   93     File::SetUserPath(D_RESOURCEPACK_IDX, std::move(path));
   94 }
   95 
   96 static void CreateWFSPath(const std::string& path)
   97 {
   98   if (!path.empty())
   99     File::SetUserPath(D_WFSROOT_IDX, path + '/');
  100 }
  101 
  102 static void InitCustomPaths()
  103 {
  104   File::SetUserPath(D_WIIROOT_IDX, Config::Get(Config::MAIN_FS_PATH));
  105   CreateLoadPath(Config::Get(Config::MAIN_LOAD_PATH));
  106   CreateDumpPath(Config::Get(Config::MAIN_DUMP_PATH));
  107   CreateResourcePackPath(Config::Get(Config::MAIN_RESOURCEPACK_PATH));
  108   CreateWFSPath(Config::Get(Config::MAIN_WFS_PATH));
  109   File::SetUserPath(F_WIISDCARDIMAGE_IDX, Config::Get(Config::MAIN_WII_SD_CARD_IMAGE_PATH));
  110   File::SetUserPath(D_WIISDCARDSYNCFOLDER_IDX,
  111                     Config::Get(Config::MAIN_WII_SD_CARD_SYNC_FOLDER_PATH));
  112   File::CreateFullPath(File::GetUserPath(D_WIISDCARDSYNCFOLDER_IDX));
  113 #ifdef HAS_LIBMGBA
  114   File::SetUserPath(F_GBABIOS_IDX, Config::Get(Config::MAIN_GBA_BIOS_PATH));
  115   File::SetUserPath(D_GBASAVES_IDX, Config::Get(Config::MAIN_GBA_SAVES_PATH));
  116   File::CreateFullPath(File::GetUserPath(D_GBASAVES_IDX));
  117 #endif
  118 }
  119 
  120 static void RefreshConfig()
  121 {
  122   Common::SetEnableAlert(Config::Get(Config::MAIN_USE_PANIC_HANDLERS));
  123   Common::SetAbortOnPanicAlert(Config::Get(Config::MAIN_ABORT_ON_PANIC_ALERT));
  124 }
  125 
  126 void Init()
  127 {
  128   Core::RestoreWiiSettings(Core::RestoreReason::CrashRecovery);
  129 
  130   Config::Init();
  131   const auto config_changed_callback = [] {
  132     InitCustomPaths();
  133     RefreshConfig();
  134   };
  135   s_config_changed_callback_id = Config::AddConfigChangedCallback(config_changed_callback);
  136   Config::AddLayer(ConfigLoaders::GenerateBaseConfigLoader());
  137   SConfig::Init();
  138   g_Config.Init();
  139   Discord::Init();
  140   Common::Log::LogManager::Init();
  141   VideoBackendBase::ActivateBackend(Config::Get(Config::MAIN_GFX_BACKEND));
  142   Statistics::Init();
  143 
  144   RefreshConfig();
  145 }
  146 
  147 void Shutdown()
  148 {
  149   Config::RemoveConfigChangedCallback(s_config_changed_callback_id);
  150 
  151   Statistics::Shutdown();
  152   GCAdapter::Shutdown();
  153   WiimoteReal::Shutdown();
  154   Common::Log::LogManager::Shutdown();
  155   Discord::Shutdown();
  156   g_Config.Shutdown();
  157   SConfig::Shutdown();
  158   Config::Shutdown();
  159 }
  160 
  161 [[nodiscard]] Common::EventHook AddFlushUnsavedDataCallback(std::function<void()> callback)
  162 {
  163   return s_flush_unsaved_data_event_hook.Register(std::move(callback));
  164 }
  165 
  166 void FlushUnsavedData()
  167 {
  168   INFO_LOG_FMT(CORE, "Flushing unsaved data...");
  169   s_flush_unsaved_data_event_hook.Trigger();
  170 }
  171 
  172 void InitControllers(const WindowSystemInfo& wsi)
  173 {
  174   if (g_controller_interface.IsInit())
  175     return;
  176 
  177   g_controller_interface.Initialize(wsi);
  178 
  179   if (!g_controller_interface.HasDefaultDevice())
  180   {
  181     // Note that the CI default device could be still temporarily removed at any time
  182     WARN_LOG_FMT(CONTROLLERINTERFACE, "No default device has been added in time. Premade control "
  183                                       "mappings intended for the default device may not work.");
  184   }
  185 
  186   GCAdapter::Init();
  187   Pad::Initialize();
  188   Pad::InitializeGBA();
  189   Keyboard::Initialize();
  190   Wiimote::Initialize(Wiimote::InitializeMode::DO_NOT_WAIT_FOR_WIIMOTES);
  191   HotkeyManagerEmu::Initialize();
  192   FreeLook::Initialize();
  193 }
  194 
  195 void ShutdownControllers()
  196 {
  197   Pad::Shutdown();
  198   Pad::ShutdownGBA();
  199   Keyboard::Shutdown();
  200   Wiimote::Shutdown();
  201   HotkeyManagerEmu::Shutdown();
  202   FreeLook::Shutdown();
  203 
  204   g_controller_interface.Shutdown();
  205 }
  206 
  207 void SetLocale(std::string locale_name)
  208 {
  209   auto set_locale = [](const std::string& locale) {
  210 #ifdef __linux__
  211     std::string adjusted_locale = locale;
  212     if (!locale.empty())
  213       adjusted_locale += ".UTF-8";
  214 #else
  215     const std::string& adjusted_locale = locale;
```

## Built frozen Dolphin6094cfcf:Source/Core/DolphinQt/MainWindow.cpp

```text
  250 
  251 #if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
  252   connect(QGuiApplication::styleHints(), &QStyleHints::colorSchemeChanged, this,
  253           [this](Qt::ColorScheme colorScheme) {
  254             Settings::Instance().ApplyStyle();
  255             if (m_skylander_window)
  256               m_skylander_window->RefreshList();
  257           });
  258 #endif
  259 
  260 #ifdef USE_RETRO_ACHIEVEMENTS
  261   connect(m_game_list, &GameList::OpenAchievementSettings, this,
  262           &MainWindow::ShowAchievementSettings);
  263 #endif  // USE_RETRO_ACHIEVEMENTS
  264 
  265   InitCoreCallbacks();
  266 
  267   NetPlayInit();
  268 
  269 #ifdef USE_RETRO_ACHIEVEMENTS
  270   AchievementManager::GetInstance().Init(reinterpret_cast<void*>(winId()));
  271   if (AchievementManager::GetInstance().IsHardcoreModeActive())
  272     Settings::Instance().SetDebugModeEnabled(false);
  273   // This needs to trigger on both RA_HARDCORE_ENABLED and RA_ENABLED
  274   m_config_changed_callback_id = Config::AddConfigChangedCallback(
  275       [this] { QueueOnObject(this, [this] { this->OnHardcoreChanged(); }); });
  276   // If hardcore is enabled when the emulator starts, make sure it turns off what it needs to
  277   if (Config::Get(Config::RA_HARDCORE_ENABLED))
  278     OnHardcoreChanged();
  279 #endif  // USE_RETRO_ACHIEVEMENTS
  280 
  281 #if defined(__unix__) || defined(__unix) || defined(__APPLE__)
  282   auto* daemon = new SignalDaemon(this);
  330   }
  331 
  332   Host::GetInstance()->SetMainWindowHandle(reinterpret_cast<void*>(winId()));
  333 
  334   if (m_pending_boot != nullptr)
  335   {
  336     StartGame(std::move(m_pending_boot));
  337     m_pending_boot.reset();
  338   }
  339 }
  340 
  341 MainWindow::~MainWindow()
  342 {
  343   // Shut down NetPlay first to avoid race condition segfault
  344   Settings::Instance().ResetNetPlayClient();
  345   Settings::Instance().ResetNetPlayServer();
  346 
  347 #ifdef USE_RETRO_ACHIEVEMENTS
  348   Config::RemoveConfigChangedCallback(m_config_changed_callback_id);
  349   AchievementManager::GetInstance().Shutdown();
  350 #endif  // USE_RETRO_ACHIEVEMENTS
  351 
  352   delete m_render_widget;
  353   delete m_netplay_dialog;
  354 
  355   for (int i = 0; i < 4; i++)
  356   {
  357     delete m_gc_tas_input_windows[i];
  358     delete m_gba_tas_input_windows[i];
  359     delete m_wii_tas_input_windows[i];
```

## Built frozen Dolphin6094cfcf:Source/Core/Common/FileUtil.cpp

```text
  757   return PathToString(StringToPath(GetExePath()).parent_path());
  758 }
  759 
  760 static std::string CreateSysDirectoryPath()
  761 {
  762 #if defined(_WIN32) || defined(LINUX_LOCAL_DEV)
  763 #define SYSDATA_DIR "Sys"
  764 #elif defined __APPLE__
  765 #define SYSDATA_DIR "Contents/Resources/Sys"
  766 #else
  767 #ifdef DATA_DIR
  768 #define SYSDATA_DIR DATA_DIR "sys"
  769 #else
  770 #define SYSDATA_DIR "sys"
  771 #endif
  772 #endif
  773 
  774 #if defined(__APPLE__)
  775   const std::string sys_directory = GetBundleDirectory() + DIR_SEP SYSDATA_DIR DIR_SEP;
  776 #elif defined(_WIN32) || defined(LINUX_LOCAL_DEV)
  777   const std::string sys_directory = GetExeDirectory() + DIR_SEP SYSDATA_DIR DIR_SEP;
  778 #elif defined ANDROID
  779   const std::string sys_directory = s_android_sys_directory + DIR_SEP;
  780   ASSERT_MSG(COMMON, !s_android_sys_directory.empty(), "Sys directory has not been set");
  781 #else
  782   const std::string sys_directory = SYSDATA_DIR DIR_SEP;
  783 #endif
  784 
  785   INFO_LOG_FMT(COMMON, "CreateSysDirectoryPath: Setting to {}", sys_directory);
  786   return sys_directory;
  787 }
  788 
  789 const std::string& GetSysDirectory()
  790 {
  791   static const std::string sys_directory = CreateSysDirectoryPath();
  792   return sys_directory;
  793 }
  794 
  795 #ifdef ANDROID
  796 void SetSysDirectory(const std::string& path)
  797 {
  798   INFO_LOG_FMT(COMMON, "Setting Sys directory to {}", path);
  799   ASSERT_MSG(COMMON, s_android_sys_directory.empty(), "Sys directory already set to {}",
  800              s_android_sys_directory);
  801   s_android_sys_directory = path;
  802 }
  803 
  804 void SetGpuDriverDirectories(const std::string& path, const std::string& lib_path)
  805 {
```

## Built frozen Dolphin6094cfcf:CMakeLists.txt

```text
  160 # Support functions
  161 include(CheckAndAddFlag)
  162 include(CheckCCompilerFlag)
  163 include(CheckSymbolExists)
  164 include(DolphinCompileDefinitions)
  165 include(DolphinDisableWarningsMSVC)
  166 include(DolphinLibraryTools)
  167 include(GNUInstallDirs)
  168 include(RemoveCompileFlag)
  169 
  170 # Enable folders for IDE
  171 set_property(GLOBAL PROPERTY USE_FOLDERS ON)
  172 
  173 # Set up paths
  174 set(datadir ${CMAKE_INSTALL_FULL_DATADIR}/dolphin-emu CACHE PATH "datadir")
  175 add_definitions(-DDATA_DIR="${datadir}/")
  176 
  177 if(CMAKE_SYSROOT)
  178   # If we should use a sysroot, tell pkg-config to search for packages in there, not on the host
  179   set(ENV{PKG_CONFIG_LIBDIR} "${CMAKE_SYSROOT}/usr/lib/pkgconfig:${CMAKE_SYSROOT}/usr/share/pkgconfig")
  180   set(ENV{PKG_CONFIG_SYSROOT_DIR} "${CMAKE_SYSROOT}")
  845   message(STATUS "Unit tests are disabled")
  846 endif()
  847 
  848 ########################################
  849 # Process Dolphin source now that all setup is complete
  850 #
  851 add_subdirectory(Source)
  852 
  853 ########################################
  854 # Install shared data files
  855 #
  856 if(NOT CMAKE_SYSTEM_NAME MATCHES "Darwin|Windows")
  857   install(DIRECTORY Data/Sys/ DESTINATION ${datadir}/sys PATTERN)
  858 endif()
  859 if(NOT CMAKE_SYSTEM_NAME MATCHES "Linux|FreeBSD|OpenBSD|Darwin")
  860   install(FILES COPYING DESTINATION ${datadir})
  861   install(DIRECTORY LICENSES DESTINATION ${datadir}/LICENSES PATTERN)
  862 endif()
  863 if(CMAKE_SYSTEM_NAME MATCHES "Linux|FreeBSD|OpenBSD")
  864   # Install the application icon and menu item
```

## Built frozen Dolphin6094cfcf:Source/Core/Core/ConfigLoaders/GameConfigLoader.cpp

```text
  175 // INI Game layer configuration loader
  176 class INIGameConfigLayerLoader final : public Config::ConfigLayerLoader
  177 {
  178 public:
  179   INIGameConfigLayerLoader(std::string id, u16 revision, bool global)
  180       : ConfigLayerLoader(global ? Config::LayerType::GlobalGame : Config::LayerType::LocalGame),
  181         m_id(std::move(id)), m_revision(revision)
  182   {
  183   }
  184 
  185   void Load(Config::Layer* layer) override
  186   {
  187     Common::IniFile ini;
  188     if (layer->GetLayer() == Config::LayerType::GlobalGame)
  189     {
  190       for (const std::string& filename : GetGameIniFilenames(m_id, m_revision))
  191         ini.Load(File::GetSysDirectory() + GAMESETTINGS_DIR DIR_SEP + filename, true);
  192     }
  193     else
  194     {
  195       for (const std::string& filename : GetGameIniFilenames(m_id, m_revision))
  196         ini.Load(File::GetUserPath(D_GAMESETTINGS_IDX) + filename, true);
  197     }
  198 
  199     const auto& system_sections = ini.GetSections();
  200 
  201     for (const auto& section : system_sections)
  202     {
  203       LoadFromSystemSection(layer, section);
  204     }
  205 
  206     LoadControllerConfig(layer);
  207   }
```

## Built frozen Dolphin6094cfcf:Source/Core/Core/ConfigManager.cpp

```text
  520 Common::IniFile SConfig::LoadLocalGameIni() const
  521 {
  522   return LoadLocalGameIni(GetGameID(), m_revision);
  523 }
  524 
  525 Common::IniFile SConfig::LoadGameIni() const
  526 {
  527   return LoadGameIni(GetGameID(), m_revision);
  528 }
  529 
  530 Common::IniFile SConfig::LoadDefaultGameIni(std::string_view id, std::optional<u16> revision)
  531 {
  532   Common::IniFile game_ini;
  533   for (const std::string& filename : ConfigLoaders::GetGameIniFilenames(id, revision))
  534     game_ini.Load(File::GetSysDirectory() + GAMESETTINGS_DIR DIR_SEP + filename, true);
  535   return game_ini;
  536 }
  537 
  538 Common::IniFile SConfig::LoadLocalGameIni(std::string_view id, std::optional<u16> revision)
  539 {
  540   Common::IniFile game_ini;
  541   for (const std::string& filename : ConfigLoaders::GetGameIniFilenames(id, revision))
  542     game_ini.Load(File::GetUserPath(D_GAMESETTINGS_IDX) + filename, true);
  543   return game_ini;
  544 }
  545 
  546 Common::IniFile SConfig::LoadGameIni(std::string_view id, std::optional<u16> revision)
  547 {
  548   Common::IniFile game_ini;
  549   for (const std::string& filename : ConfigLoaders::GetGameIniFilenames(id, revision))
  550     game_ini.Load(File::GetSysDirectory() + GAMESETTINGS_DIR DIR_SEP + filename, true);
  551   for (const std::string& filename : ConfigLoaders::GetGameIniFilenames(id, revision))
  552     game_ini.Load(File::GetUserPath(D_GAMESETTINGS_IDX) + filename, true);
  553   return game_ini;
  554 }
  555 
  556 std::string SConfig::GetGameTDBImageRegionCode(bool wii, DiscIO::Region region) const
  557 {
  558   switch (region)
```

## Original installed Dolphin baseline stderr native-owner/case/baseline-enabled/stderr

```text
43:47:775 Core/AchievementManager.cpp:775 I[RetroAchievements]: Game closed.
43:47:775 Core/ConfigManager.cpp:251 N[CORE]: Active title: 
43:47:776 Core/AchievementManager.cpp:775 I[RetroAchievements]: Game closed.
43:47:776 Core/Core.cpp:237 I[BOOT]: Starting core = GameCube mode
43:47:776 Core/Core.cpp:238 I[BOOT]: CPU Thread separate = Yes
43:49:423 Core/Boot/Boot.cpp:541 N[BOOT]: Booting from executable: /run/pix-installed-native/loop.dol
43:49:423 Core/AchievementManager.cpp:164 E[RetroAchievements]: Attempted to load game achievements without achievement client initialized.
A signal was received. A second signal will force Dolphin to stop.
[NUL]43:51:678 Core/AchievementManager.cpp:775 I[RetroAchievements]: Game closed.
43:51:678 Core/Core.cpp:286 I[CONSOLE]: Stop [Main Thread]		---- Shutting down ----
43:51:678 Core/Core.cpp:289 I[CONSOLE]: Stop [Main Thread 0]	Stop CPU
43:51:678 Core/Core.cpp:491 I[CONSOLE]: Stop [Main Thread 0]	Wait for Video Loop to exit ...
43:51:678 Core/Core.cpp:482 I[CONSOLE]: Stop [Video Thread 0]	Video Loop Ended
43:51:679 Core/Core.cpp:494 I[CONSOLE]: Stop [Main Thread 0]	GPU thread stopped.
43:51:679 Core/Core.cpp:587 I[CONSOLE]: Stop [Video Thread 0]	Shutting down HW
43:51:687 Core/Core.cpp:589 I[CONSOLE]: Stop [Video Thread 0]	HW shutdown
43:51:689 Core/Core.cpp:524 I[CONSOLE]: Stop		---- Shutdown complete ----

```

## Original installed Dolphin baseline process/operation fields

```text
{
  "argv": [
    "/usr/bin/dolphin-emu-nogui",
    "-p",
    "headless",
    "-v",
    "Null",
    "-a",
    "HLE",
    "-u",
    "/run/pix-installed-native/baseline-enabled/user",
    "-e",
    "/run/pix-installed-native/loop.dol"
  ],
  "binary_sha256": "e6c6207d663f7ab53ca6f9fe3c836c98751545b45b869cf32477f7f130e0170b",
  "enabled": true,
  "badboot": false,
  "signals": [
    "normal SIGTERM"
  ],
  "original_exit": 0,
  "initialized": 0,
  "shutdown": 0,
  "boot_error": false,
  "requests": [],
  "remaining_dolphin": [],
  "elapsed_seconds": 4.290780294000001
}
```

## Original relink compile preprocessor/source flags

```text
{
  "argv": [
    "<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/bin/x86_64-rocknix-linux-gnu-g++",
    "-DDATA_DIR=\"/usr/share/dolphin-emu/\"",
    "-DHAS_OPENGL",
    "-DHAS_VULKAN",
    "-DHAVE_CPPIPC",
    "-DHAVE_CUBEB",
    "-DHAVE_EGL=1",
    "-DHAVE_LIBEVDEV=1",
    "-DHAVE_LIBSYSTEMD",
    "-DHAVE_LIBUDEV=1",
    "-DHAVE_SDL3=1",
    "-DHAVE_WAYLAND=1",
    "-DHAVE_X11=1",
    "-DHAVE_XRANDR=1",
    "-DQT_CORE_LIB",
    "-DQT_DBUS_LIB",
    "-DQT_NO_DEBUG",
    "-DRC_CLIENT_SUPPORTS_HASH",
    "-DSFML_STATIC",
    "-DUSE_MEMORYWATCHER=1",
    "-DUSE_PIPES=1",
    "-DUSE_RETRO_ACHIEVEMENTS",
    "-DUSE_UPNP",
    "-D_ARCH_64=1",
    "-D_DEFAULT_SOURCE",
    "-D_FILE_OFFSET_BITS=64",
    "-D_LARGEFILE_SOURCE",
    "-D_M_X86_64=1",
    "-D__LIBUSB__",
    "-D__STDC_CONSTANT_MACROS",
    "-D__STDC_LIMIT_MACROS",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Source/Core",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/picojson",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/.x86_64-rocknix-linux-gnu/Source/Core",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/.x86_64-rocknix-linux-gnu/Source/Core/DolphinNoGUI",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/fmt/fmt/include",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/mbedtls/include",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/minizip-ng/minizip-ng",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/SFML/SFML/include",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/expr/include",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/cubeb/cubeb/include",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/.x86_64-rocknix-linux-gnu/exports",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/rcheevos",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/build/dolphin-sa-6094cfcf7b8fba733b3116fdf3414d51c1c0e4a4/Externals/cpp-optparse/cpp-optparse",
    "-isystem",
    "<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/libusb-1.0",
    "-isystem",
    "<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/hidapi",
    "-isystem",
    "<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/QtDBus",
    "-isystem",
    "<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include/QtCore",
    "-isystem",
    "<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/mkspecs/linux-g++",
    "-march=x86-64-v3",
    "-mtune=generic",
    "-Wall",
    "-pipe",
    "-O2",
    "-fomit-frame-pointer",
    "-DNDEBUG",
    "-std=c++23",
    "-flto=auto",
    "-fno-fat-lto-objects",
    "-I<DISTRO_WORKTREES>/m7-pixelelated/build.pixelelated-GENERIC_X64.x86_64/toolchain/x86_64-rocknix-linux-gnu/sysroot/usr/include",
    "-msse2",
    "-fdiagnostics-color",
    "-fno-strict-aliasing",
    "-fno-exceptions",
    "-fvisibility-inlines-hidden",
    "-fvisibility=hidden",
    "-fomit-frame-pointer",
    "-Wall",
    "-Wtype-limits",
    "-Wsign-compare",
    "-Wignored-qualifiers",
    "-Wuninitialized",
    "-Wlogical-op",
    "-Wshadow",
    "-Winit-self",
    "-Wmissing-declarations",
    "-Wno-stringop-truncation",
    "-Werror=format",
    "-Wno-trigraphs",
    "-fPIC",
    "-o",
    "/work/MainNoGUI.cpp.o",
    "-c",
    "/work/MainNoGUI.cpp",
    "-MD",
    "-MF",
    "/work/MainNoGUI.d"
  ],
  "original_exit": 0,
  "reaped": true
}
```

## Auditor read-only staged-tree observation, Phase3 before cache move

```text
Frozen image/system/usr read:
share/dolphin-emu: exists False, symlink False
share/dolphin-emu/sys: exists False, symlink False
share/dolphin-emu/sys/Resources/achievements_game.png: exists False
config/dolphin-emu/Resources/achievements_game.png: exists True
This is a direct host staged-tree observation, not a new guest command.
```

## Original14 complete Steam caller records, selected readback fields

```text
[
  {
    "case": "01-fresh-profile-dot",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "02-fresh-profile-dot-absent",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "03-valid-existing-alias",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 9,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "04-existing-profile-dot",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "05-self-updated-client",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "06-partial-before-profile",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "07-marker-missing-core",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "08-metadata-conflict-after-profile",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "09-unknown-stage-before-profile",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "10-download-failure-retry",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      },
      {
        "attempt": 2,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "11-validation-failure-retry",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      },
      {
        "attempt": 2,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "12-publication-failure-retry",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      },
      {
        "attempt": 2,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "13-metadata-failure-retry",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      },
      {
        "attempt": 2,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  },
  {
    "case": "14-interrupt-prepared-retry",
    "source_sha256": "fab7cdb4ad8adbcea147be54092bb7ce2005010447be4ab8192c94d8bbe9229d",
    "status": "PASS",
    "protected_prefixes": [
      ".local/share/Steam/steamapps",
      ".local/share/Steam/userdata",
      ".local/share/Steam/depotcache",
      ".local/share/Steam/linuxarm64",
      ".local/share/Steam/custom-root-file",
      ".local/share/Steam/compatibilitytools.d/GE-Protonold-aarch64",
      ".local/share/Steam/compatibilitytools.d/proton-cachyos-old-arm64",
      "games-external",
      "games-internal/roms/other-library",
      "games-internal/roms/steam/unrelated",
      ".steam/fixture-existing",
      ".local/share/fex-emu/RootFS/OtherRoot",
      ".local/share/fex-emu/RootFS/ArchLinux.sqsh"
    ],
    "protected_original_keys": 38,
    "protected_changes": [],
    "remaining_descendants": [],
    "namespace_remaining_descendants": [],
    "parent_equality": true,
    "attempts": [
      {
        "attempt": 1,
        "installer_exit": 1,
        "trace_driver_exit": 1,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      },
      {
        "attempt": 2,
        "installer_exit": 0,
        "trace_driver_exit": 0,
        "client_executed": false,
        "native_client_success": false,
        "cleanup_exits": [],
        "remaining_traced": []
      }
    ]
  }
]
```

## Installed proxy-native original installed-result.json

```text
{
  "status": "PASS",
  "scope": "installed bytecode/native ISO/NONE/Zstd/CHD continuation; no gameplay or Wii AES data proof",
  "hashes": [
    {
      "name": "synthetic.iso",
      "sha256": "83c6dacc46797bc7d4bdcb4aa2dd253c290316c07c4cda8f6ca1afb889c44121",
      "candidates": [
        "118545082f24fc195a446d1ee7bbf816"
      ],
      "error": null
    },
    {
      "name": "dolphin-none.rvz",
      "sha256": "4526c1597cf8f2c00a236796fcf5433ce56a81d7d4a157f4ae75f58a307bc48f",
      "candidates": [
        "118545082f24fc195a446d1ee7bbf816"
      ],
      "error": null
    },
    {
      "name": "dolphin-zstd.rvz",
      "sha256": "bb3c40134d089fdcf97502f2cff30db9f3b7073ddd61c39adb993a2d24b4d2b9",
      "candidates": [
        "118545082f24fc195a446d1ee7bbf816"
      ],
      "error": null
    },
    {
      "name": "saturn.chd",
      "sha256": "00c0dde6752938cf74d815fd5ca37df00a2da4b483284c003f0408f30fefe88b",
      "candidates": [
        "4cd9c8e41cd8d137be15bbe6a93ae1d8"
      ],
      "error": null
    }
  ],
  "verification_sha256": "ceb051f88b91de761b1a128c6dc2f7c40cf0421293e8ac4f8aa3eac50e2e5272",
  "system": {
    "bytes": 2073112576,
    "sha256": "cca91bec2513aa32cfb713a81042acee720f12619bb66431019c7a76dc3eb6a0"
  },
  "source": "d6a87f05c1935516115b2cca1af22151a0209224",
  "es_commit": "3178b832b8d134198b2b4eede4f725d4ed283f8c",
  "boot_id": "d72ab4d6-0403-4d86-a3e8-727acbfcd94c",
  "pid": 1975,
  "preparation_sha256": "6b8a4e39bd418c130efaea7025f0ef03d280aa9dc0a0c869c3e4feadd53ff4d7",
  "library_names": {
    "rchash": "libraproxy_rchash.so",
    "zstd": "libzstd.so.1",
    "crypto": "libcrypto.so.3"
  },
  "modules": {
    "raofflineproxy": {
      "path": "/usr/lib/python3.14/site-packages/raofflineproxy/__init__.pyc",
      "sha256": "566e3e650d785f969bc634728dc327f8a67f76784fa26374279d260dbcb816b2"
    },
    "raofflineproxy.native_codecs": {
      "path": "/usr/lib/python3.14/site-packages/raofflineproxy/native_codecs.pyc",
      "sha256": "ca3a4d8264d9cd6c286160a8cb7351f8a73451409d2a8d88be5e797b9d5d857a"
    },
    "raofflineproxy.rom_hashing": {
      "path": "/usr/lib/python3.14/site-packages/raofflineproxy/rom_hashing.pyc",
      "sha256": "c5164554539843de5928d411f5432a589407ddf98657952236f4830753a2cf68"
    },
    "raofflineproxy.rvz_datasource": {
      "path": "/usr/lib/python3.14/site-packages/raofflineproxy/rvz_datasource.pyc",
      "sha256": "c2f8053db96b46ff51316032e0c2aeb0a16aecde655805f387fe60e615397978"
    }
  },
  "installed": {
    "etc/os-release": {
      "bytes": 710,
      "sha256": "6ed9c64ec54f0275653a8a0a63ecddad422d071799190362c3dbbf7e71f33034",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/etc/os-release",
        "links": []
      }
    },
    "usr/bin/python3": {
      "bytes": 14304,
      "sha256": "1324452a1b3437ef26e0d39794ede6fb7c1c2c0c5960a050feace157ffe50b33",
      "mode": "-rwxr-xr-x",
      "link_chain": {
        "resolved": "/usr/bin/python3.14",
        "links": [
          {
            "path": "/usr/bin/python3",
            "target": "python3.14"
          }
        ]
      }
    },
    "usr/lib/libraproxy_rchash.so": {
      "bytes": 390096,
      "sha256": "6c484a2947a5f2a7c187e60dd93de73593d5fa98d57309bfb4b5f07bf390220d",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/libraproxy_rchash.so",
        "links": []
      }
    },
    "usr/lib/libzstd.so.1": {
      "bytes": 659232,
      "sha256": "8526c748a90b34d9872159fdd311071ed1c391c879b41295848282fcace4e2f4",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/libzstd.so.1.5.7",
        "links": [
          {
            "path": "/usr/lib/libzstd.so.1",
            "target": "libzstd.so.1.5.7"
          }
        ]
      }
    },
    "usr/lib/libcrypto.so.3": {
      "bytes": 6181168,
      "sha256": "66d713b67c3d811ab73894b294ff40d7985a3273d26f493bdc9f59b79f2e2f77",
      "mode": "-rwxr-xr-x",
      "link_chain": {
        "resolved": "/usr/lib/libcrypto.so.3",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/__init__.pyc": {
      "bytes": 279,
      "sha256": "566e3e650d785f969bc634728dc327f8a67f76784fa26374279d260dbcb816b2",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/__init__.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/auth.pyc": {
      "bytes": 5971,
      "sha256": "04c4cce4335d1b5e25ed4632126ac582433af42b9aa4c9753c77db901c0043da",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/auth.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/award_signing.pyc": {
      "bytes": 2582,
      "sha256": "870c5e772c6c38c65a2fe8821af0a95b6ac513d56b0a0a7492153d75b4e2245c",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/award_signing.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/batocera_conf.pyc": {
      "bytes": 9498,
      "sha256": "e13ea0f8a94c2590ec284d6708efcca55a230814cd1393ab01634f9867c87bd2",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/batocera_conf.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/boot.pyc": {
      "bytes": 4086,
      "sha256": "7aac3bc7ab3954b84b44281f270b60ee38a0fae51b27a19fcf0530dcd05f4226",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/boot.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/cache_budget.pyc": {
      "bytes": 8044,
      "sha256": "bf07a9babe2a7a3b0e0c15e2f2f962db9a30c3370c4e4323fa6e9d75c13d07d5",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/cache_budget.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/cache_keys.pyc": {
      "bytes": 6173,
      "sha256": "15e554208db8ac2185ad55ce4ca27791d8d50c2645bd3cc8719600de9cc06630",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/cache_keys.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/cache_queue.pyc": {
      "bytes": 16252,
      "sha256": "1092159fd9f64565f133ea27e31438a49fe47472dec277cb656df3a773d090f9",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/cache_queue.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/config.pyc": {
      "bytes": 28252,
      "sha256": "7d4d78e451332042ec28c068939d42c9af23b69210d7353c462c0a9940f695ea",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/config.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/darkos_service.pyc": {
      "bytes": 13223,
      "sha256": "88cd85a0aca686cd0942991b434d1b58012875c3ea0f4e940f9761826c6c8b5c",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/darkos_service.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/dolphin_cfg.pyc": {
      "bytes": 9376,
      "sha256": "89419439276367d380c43c001c5d9a24ade8b145e650e04de1f5f8808b534455",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/dolphin_cfg.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/es_export.pyc": {
      "bytes": 5035,
      "sha256": "5b4f2a3a37decf1a1847e57e1eb8ad9a9f48c0925ab4875a792cf4aa9aa842e8",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/es_export.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/flusher.pyc": {
      "bytes": 23155,
      "sha256": "bd83b2a034abfd0022d1ddc29e2b8c11f0632641b624f3d48899c2d54ba7cb47",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/flusher.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/game_meta.pyc": {
      "bytes": 4032,
      "sha256": "a6eb6366545e20ed5d20e2befd77dd0d52df23cbdd1171324a787baff8292160",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/game_meta.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/image_cache.pyc": {
      "bytes": 25659,
      "sha256": "afce22a2afc67b2a8214cde959f7b587b05c975a6e90b52e6841677f65b4275e",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/image_cache.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/knulli_service.pyc": {
      "bytes": 4476,
      "sha256": "4de7c687b70347a7fa46f3de26e831c63b1b41c4ebc1aaf9c29c4d7ade5285aa",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/knulli_service.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/last_played.pyc": {
      "bytes": 4455,
      "sha256": "8fafd64d87c5771b13fdaa1cf40c54d7329377eb1f7665beb31baa2cbcfb7a63",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/last_played.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/log_uploader.pyc": {
      "bytes": 20856,
      "sha256": "57b887f92c7e496640827b0810b97c41bd5ea6ec3ad1f3da6c854b63a4ed1465",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/log_uploader.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/lowerdeck.pyc": {
      "bytes": 6523,
      "sha256": "5f45d7f58a38c3810afb7b6548195490ec95640e2c553505bdb446ffafd584e8",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/lowerdeck.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/main.pyc": {
      "bytes": 41810,
      "sha256": "8f736b2540c8ffa682b3a3d3e1a393fd482f196b646ac0a5e67c7fc91663734b",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/main.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/menu_input.pyc": {
      "bytes": 5198,
      "sha256": "8d3e59d5f7dccfa77046bb7eaf1f0af1b56b62439394e980622230550e7f1cb6",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/menu_input.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/menu_sdl.pyc": {
      "bytes": 174624,
      "sha256": "e3d1561d38027fbbebebd1898655bc31fce3faed31dacd651e0058a2441917a1",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/menu_sdl.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/native_codecs.pyc": {
      "bytes": 8926,
      "sha256": "ca3a4d8264d9cd6c286160a8cb7351f8a73451409d2a8d88be5e797b9d5d857a",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/native_codecs.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/network.pyc": {
      "bytes": 33602,
      "sha256": "c7285011a638cfed76ec0195ea3f06fb2a9b55f5336486b02801b7736b630ab8",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/network.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/pending_awards.pyc": {
      "bytes": 8957,
      "sha256": "ae451225b48ad40bb76fb06d9689153c69427f937226d972a1bf23b68cb492c6",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/pending_awards.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/platform.pyc": {
      "bytes": 24948,
      "sha256": "81a7945a8b078a248692b38431b6c966638a91f0ddffeda2b677408a7758f948",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/platform.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/ppsspp_cfg.pyc": {
      "bytes": 9668,
      "sha256": "6e5f460d53129c6483c825ae64a4b238a71527bf8c8e284bab36c04066816804",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/ppsspp_cfg.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/proxy_service.pyc": {
      "bytes": 81816,
      "sha256": "b6951e3015337407b43ea42d715646c4ae552ea0c547a7f7b52eba564ac2b28e",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/proxy_service.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/rate_limit.pyc": {
      "bytes": 3655,
      "sha256": "55054583b217079586d3c90b118597e3aa9d46908b7c0e640b6adbcdef0282aa",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/rate_limit.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/retroarch_cfg.pyc": {
      "bytes": 31410,
      "sha256": "d2404488ba6fe79a08d583813871640c7dcf344cea11d2fcdfe357218adc3219",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/retroarch_cfg.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/rom_browser.pyc": {
      "bytes": 71953,
      "sha256": "8f64842d6313237d6da0efa59d644d0efbffc5bf9910c3a01350061f5c70be6d",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/rom_browser.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/rom_cache.pyc": {
      "bytes": 25900,
      "sha256": "d927394f2d4bc627f6f092d031d7399351b7ad4260d519f296c28f51ca45ba24",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/rom_cache.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/rom_hashing.pyc": {
      "bytes": 14300,
      "sha256": "c5164554539843de5928d411f5432a589407ddf98657952236f4830753a2cf68",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/rom_hashing.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/rvz_datasource.pyc": {
      "bytes": 41939,
      "sha256": "c2f8053db96b46ff51316032e0c2aeb0a16aecde655805f387fe60e615397978",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/rvz_datasource.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/service.pyc": {
      "bytes": 20457,
      "sha256": "02b4e38ca427b9f630bf56d8e23382d9297dcb4f37eb02214b217b304d6ad07a",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/service.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/smart_cache.pyc": {
      "bytes": 39461,
      "sha256": "bd5792bb3f370e0325b1d0432d1cac50266a9e1e294a11b7ee251580c74a2181",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/smart_cache.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/state.pyc": {
      "bytes": 8732,
      "sha256": "eab1660a54673d276f4fb7e3d0eabbd127ecc868c458a8dbd2ade42f6f47c0de",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/state.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/storage.pyc": {
      "bytes": 78516,
      "sha256": "99e14148a1ac9f80d8dd005c6433982eb02f4bc4508dd28747ff3538c2b31d29",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/storage.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/storage_corruption.pyc": {
      "bytes": 4074,
      "sha256": "ed14fcf0fe2c155fbce9cc3bb9ff69d925e0d3628d5fd03963f196c9c7c81661",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/storage_corruption.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/ui.pyc": {
      "bytes": 22535,
      "sha256": "66dc726cb7203f556ed8959fdfcd0295babc96ebdd31bf2a9d9cd5b9aa0d0418",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/ui.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/update.pyc": {
      "bytes": 40444,
      "sha256": "0088b2164067c9e6d6be019376e41432b61d9411af069a6c6b11a56dddb9d02d",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/update.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/usage_report.pyc": {
      "bytes": 11759,
      "sha256": "7c72676553759ad4c90f6ef47cc5b045978dc55a21a77b35b19971aa1745ec37",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/usage_report.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/usage_stats.pyc": {
      "bytes": 22490,
      "sha256": "7e5993266737d003ac4d0c00becc374d10d5a9b7ce2333cb23b0bae7dc6edec9",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/usage_stats.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/utils.pyc": {
      "bytes": 8151,
      "sha256": "577a6432626ec8f1078a3fb3a8c155b92a677be48452b1117559bd74fe52fbc4",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/utils.pyc",
        "links": []
      }
    },
    "usr/lib/python3.14/site-packages/raofflineproxy/watch_folders.pyc": {
      "bytes": 11788,
      "sha256": "88dea0d23e26dfabc75af73d614b7d7bb94d4444de7ef99c9112416234fd47c6",
      "mode": "-rw-r--r--",
      "link_chain": {
        "resolved": "/usr/lib/python3.14/site-packages/raofflineproxy/watch_folders.pyc",
        "links": []
      }
    }
  },
  "native_maps_sha256": "007e4d71050e9187033f6396e3f2b28baf6930e3643d5ebd9f7194cda365c770",
  "elapsed": 0.05816386400000084
}
```

## Local audit command readback baseline-unchanged-inputs.json

```text
{
  "command": [
    "git",
    "diff",
    "--exit-code",
    "bc9dfe8141d9561dc1d8502313d00a84c4566ee8",
    "fac608ff89940ce358ea9b8a95e9a08a6fe26568",
    "--",
    "scripts/image",
    "projects/ROCKNIX/packages/rocknix/sources/scripts/usbgadget",
    "projects/ROCKNIX/packages/rocknix/sources/scripts/start_es.sh",
    "projects/ROCKNIX/packages/rocknix/sources/scripts/backuptool",
    "projects/ROCKNIX/packages/rocknix/sources/scripts/rocknix-info",
    "projects/ROCKNIX/packages/network/rclone/sources/cloud_restore",
    "projects/ROCKNIX/packages/network/rclone/sources/cloud_backup"
  ],
  "exit_code": 0,
  "stdout": "",
  "stderr": "",
  "purpose": "Explicit delta-scope exclusion of previously accepted baseline behavior; not new runtime proof."
}

```

## Local audit command readback static-checks-resumed.json

```text
{
  "recorded": "2026-10-15T00:36:29.660839+00:00",
  "cwd": "<DISTRO_WORKTREES>/m7-player-setup",
  "checks": [
    {
      "argv": [
        "tools/rules-check"
      ],
      "exit_code": 0,
      "summary": "30 rule files, every one front-mattered and indexed"
    },
    {
      "argv": [
        "tools/register-check"
      ],
      "exit_code": 0,
      "summary": "639 IDs, each once; every citation in live documents names a row"
    },
    {
      "argv": [
        "tools/work-log-index",
        "--check"
      ],
      "exit_code": 0,
      "summary": "work-log index: current"
    }
  ],
  "scope": "Actual independent read-only invocations; product/fixture/runtime not changed"
}

```

## Evidence locator and scope map

```text
The following are locators and bounded observations, not full raw evidence embedded in this packet. Do not issue an independent PASS based only on them. Request specific missing bytes if they determine a finding.

AC001–015: inherited baseline exclusions. baseline-unchanged-inputs.json contains actual selected Git comparisons.
AC016–025: upstream foundation merge and new generic build. Candidate install image SHA256 d816d36abc66b292500b0719e672c98c33eb0cd4fc7fc0bf19f7e26e4108bb16. Whole image qualification remains separate from source/helper proof.
AC026–035: state-isolation controls143; actual clean-first-boot and retained-update backup originals; library03 selected account/config/rclone/active/stamp equality. Historical source-device account origin remains unknown. Actual library imports include ROM-only and gamelist history; Recent membership is not itself preservation proof.
AC036–043: ScreenScraper developer identity compile/hidden-row/player-account controls and EN/FR640/1280 frames; conditional offline index matrix with simulated ctl plus actual installed ES3178/ctl compiled top-up (readiness1→2; prior cache unchanged; no award claim). docs/qa-logs/2026-10-14-offline-components and2026-10-14-installed-topup-result retain originals.
AC044–050: ES actual malloc_trim baseline/candidate RSS medians114596/34236/34408/113812KiB; separate loaded-public-page witness and native phone field input.48 current phone locale frames retained,24 viewed by primary; failed earlier34 separate. No real-provider login/physical touch assertion.
AC051–054: GStreamer tool/network library packaging, missing-library negative1 and supplied0; actual final installed ldd/gst-inspect/controller/network/scanner/dlopen checks. No claim a real scanner child was traced.
AC055–058: dated upstream/adoption research, current rule/register/work-log checks; no private provider call by primary auditor.
AC059–066: RVZ/Dolphin native integration and standalone capability boundary. Native prepared fixtures are not gameplay/save results. Actual selected system/emulator/core/effective-setting binding remains incomplete.
AC067–072: complete Wi-Fi sources above; prior UI/source controls plus actual installed WiFi03 with controlled lower iwctl/nmcli. Scan failure retains3rows, next scan2rows, disconnected selection fallback; connected Home and forget CafeA while CafeB/Home unchanged.27started/27ended children. Restored5selected configs; es_settings.cfg.backup not covered. Physical radio behavior excluded. Public docs separately tracked.
AC073–076: fresh settingsfavorites,recent and explicit-token preservation; original c045 syntax check5C++files exit0, these sources unchanged through3178. Not a separate3178 invocation.
AC077–093: FEX43/helper runtime39/Proton56 cases; full-client9earlier plus14new unchanged callers. Native ARM exec deliberately denied in full-caller fixtures. Real public client archive contract55members with5backslashnames; old/new dictionaries agree after explicit type-label normalization. Process kill/retry is not sudden power loss.
AC094–107: proxy RVZ source126unaligned old mismatches→0candidate,72aligned/6invalid/44listing controls; original baseline startup service missed flush, fixed actual service/installed unit queued1→0 and one flush. Older native result source_pins_verified:false is not relabeled current. Installed proxy-native fields embedded above. External real awards and gameplay remain distinct.
AC108–111: original final baseline7script assertions failed; harness fixed adopted-child waitpid observation, explicit source root and waiting-state DOM predicate. Original continuation scripts521s/SFTP67s/S3111s exit0, no cleanup survivors. Original65unclaimed frame comparison is retained; later host-only claim repair belongs to a separate source/results packet.
AC112–115: audit primary independently assessed115criteria before opening prior per-criterion verdicts. External two-pass review and final lint/punch-list/resolution are not completed by preparing this packet.

```

# Post-dispatch read-only clarification of blind packet limits

These are local source observations after the final refutation prompt was sealed. They are not a third external call or a modification of the dispatched packet.

- Exit250: frozen `runemu.sh:595–606` checks Dolphin launch, numeric250 and a real non-symlink `/tmp/launch_error.log` with the fixed Dolphin ownership title, strips that title, then propagates250. ES3178 `FileData.cpp:742–758` reads and removes the custom message file and returns its text. This settles the source-routing question; existing localized refusal frames provide distinct behavioral evidence.
- Locale: frozen `es_settings:17–43` reads system.language, prepares the locale, exports LANG/LANGUAGE and imports those into the systemd environment. This is source evidence of intended propagation, not proof for every service/device combination.
- Dolphin host scheme: pinned rcheevos `rc_client.c:6802–6826` saves the supplied host; `rapi/rc_api_common.c:1193–1217` detects absence of `://` and prepends `http://` when constructing the dorequest URL. This plus the separately preserved actual installed loopback request resolves the scheme hypothesis for that path. It does not prove real-provider authorization or awards.

Current-image loader/registry originals already resolve installed dependencies within their specific scope; no scanner child-exec trace was supplied. All-device ROM mount/FEX-directory assumptions, current native ARM assets and upstream hardware effects remain explicit scope boundaries.

Pinned rcheevos rc_api_common.c SHA256`601d932f4152fb2f611c15633aef561c7df8458cddd3593b8e6e78fdfef9d493`:

```c
1193: void rc_api_url_build_dorequest_url(rc_api_request_t* request, const rc_api_host_t* host) {
1194:   #define DOREQUEST_ENDPOINT "/dorequest.php"
1195:   rc_buffer_init(&request->buffer);
1196: 
1197:   if (!host || !host->host) {
1198:     request->url = RETROACHIEVEMENTS_HOST DOREQUEST_ENDPOINT;
1199:   }
1200:   else {
1201:     const size_t endpoint_len = sizeof(DOREQUEST_ENDPOINT);
1202:     const size_t host_len = strlen(host->host);
1203:     const size_t protocol_len = (strstr(host->host, "://")) ? 0 : 7;
1204:     const size_t url_len = protocol_len + host_len + endpoint_len;
1205:     uint8_t* url = rc_buffer_reserve(&request->buffer, url_len);
1206: 
1207:     if (protocol_len)
1208:       memcpy(url, "http://", protocol_len);
1209: 
1210:     memcpy(url + protocol_len, host->host, host_len);
1211:     memcpy(url + protocol_len + host_len, DOREQUEST_ENDPOINT, endpoint_len);
1212:     rc_buffer_consume(&request->buffer, url, url + url_len);
1213: 
1214:     request->url = (char*)url;
1215:   }
1216:   #undef DOREQUEST_ENDPOINT
1217: }
1218: 
```


## F-10 grading correction after historical contract inspection

The installed `/etc/profile` reads both system and `/storage/.config/profile.d/*` user snippets. System profile absence alone cannot refute a custom-profile incompatibility. The original root-preservation packet at Git `ba0c530bf0f4626ff99daedf65a18a7ead69111c:docs/qa-logs/2026-10-13-steam-root-source/README.md` explicitly states that roots become readonly before profiles, environment overrides remain supported, and a profile trying to reassign them now fails. The October14 contract-alternatives packet also cites this deliberate boundary. Final primary grade is therefore **agree, narrowed** to the documented input restriction, not a new source defect and not an assertion that user snippets cannot set these variables. The final refutation prompt's earlier grade remains preserved as dispatched; compare it transparently with this later correction.


Sanitizer limitation confirmed during final reconciliation: the local structural fallback excerpt uses the variable correctly, but final packet cleaning again replaced the fallback expression. The refutation reviewer noticed that and withdrew the unused-variable lead on primary attestation. Direct original frozen recipe count is three (declaration plus two uses). No third external call is warranted for this trivial source property; preserve the limitation and the exact original response.
